// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/
// Converted to Typst by tao2typ: "2026-10-14T16:37:02.629183+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Online reading seminar for Zhang’s “bounded gaps between primes”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Online reading seminar for Zhang’s “bounded gaps between primes”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")[#text("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In a ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("recent paper")]#text(", Yitang Zhang has proven the following theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Bounded gaps between primes)")]#text(" ")#metadata(none) <tao-5e1cf42878df58fea7bf>#text(" There exists a natural number ")#mi("{H}")#text(" such that there are infinitely many pairs of distinct primes ")#mi("{p,q}")#text(" with ")#tao-math("{\\left|p-q\\right| \\leq H}", block: false)#text(".")
]

#text("Zhang obtained the explicit value of ")#mi("{70,000,000}")#text(" for ")#mi("{H}")#text(". A ")#link("http://polymathprojects.org/2013/06/04/polymath-proposal-bounded-gaps-between-primes")[#text("polymath project has been proposed")]#text(" to lower this value and also to improve the understanding of Zhang’s results; as of this time of writing, ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("the current “world record”")]#text(" is ")#mi("{H = 4,802,222}")#text(" (and the link given should stay updated with the most recent progress.")

#text("Zhang’s argument naturally divides into three steps, which we describe in reverse order. The last step, which is the most elementary, is to deduce the above theorem from the following weak version of the Dickson-Hardy-Littlewood (DHL) conjecture for some ")#mi("{k_0}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" (")#mi("{DHL[k_0,2]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be an admissible ")#mi("{k_0}")#text("-tuple, that is to say a tuple of ")#mi("{k_0}")#text(" distinct integers which avoids at least one residue class mod ")#mi("{p}")#text(" for every prime ")#mi("{p}")#text(". Then there are infinitely many translates of ")#mi("{{\\mathcal H}}")#text(" that contain at least two primes.")
]

#text("Zhang obtained ")#mi("{DHL[k_0,2]}")#text(" for ")#mi("{k_0 = 3,500,000}")#text(". The current best value of ")#mi("{k_0}")#text(" is ")#mi("{341,640}")#text(", as discussed in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this previous blog post")]#text(". To get from ")#mi("{DHL[k_0,2]}")#text(" to Theorem ")#link(<tao-5e1cf42878df58fea7bf>)[#text("1")]#text(", one has to exhibit an admissible ")#mi("{k_0}")#text("-tuple of diameter at most ")#mi("{H}")#text(". For instance, with ")#mi("{k_0 = 341,640}")#text(", the narrowest admissible ")#mi("{k_0}")#text("-tuple that we can construct has diameter ")#mi("{4,802,222}")#text(", which explains the current world record. There is an active discussion on trying to improve the constructions of admissible tuples at ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart")[#text("this blog post")]#text("; it is conceivable that some combination of computer search and clever combinatorial constructions could obtain slightly better values of ")#mi("{H}")#text(" for a given value of ")#mi("{k_0}")#text(". The relationship between ")#mi("{H}")#text(" and ")#mi("{k_0}")#text(" is approximately of the form ")#mi("{H \\approx k_0 \\log k_0}")#text(" (and a ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("classical estimate of Montgomery and Vaughan")]#text(" tells us that we cannot make ")#mi("{H}")#text(" much narrower than ")#mi("{\\frac{1}{2} k_0 \\log k_0}")#text(", see ")#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/")[#text("this previous post")]#text(" for some related discussion).")

#text("The second step in Zhang’s argument, which is somewhat less elementary (relying primarily on the sieve theory of Goldston, Yildirim, Pintz, and Motohashi), is to deduce ")#mi("{DHL[k_0,2]}")#text(" from a certain conjecture ")#mi("{MPZ[\\varpi,\\delta]}")#text(" for some ")#mi("{\\varpi,\\delta > 0}")#text(". Here is one formulation of the conjecture, more or less as (implicitly) stated in Zhang’s paper:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3")]#text(" (")#mi("{MPZ[\\varpi,\\delta]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be an admissible tuple, let ")#mi("{h_i}")#text(" be an element of ")#mi("{{\\mathcal H}}")#text(", let ")#mi("{x}")#text(" be a large parameter, and define")

#tao-aligned(keep: true)[


#tao-math("D  & := x^{1/4+\\varpi},", block: true)



#tao-math("{\\mathcal P}  & := \\prod_{p: p < x^{\\delta}} p,", block: true)



#tao-math("P(n)  & := \\prod_{h \\in {\\mathcal H}} (n+h),", block: true)



#tao-math("C_i(d)  & := \\{ c \\in {\\bf Z}/d{\\bf Z}: (c,d) = 1; P(c-h_i) = 0 \\text{ mod } d \\}", block: true)
]

#text("for any natural number ")#mi("{d}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\gamma;d,c) = \\sum_{x \\leq n \\leq 2x: n = c \\text{ mod } d} \\gamma(n) - \\frac{1}{\\varphi(d)} \\sum_{x \\leq n \\leq 2x: (n,d) = 1} \\gamma(n)")]]

#text("for any function ")#mi("{\\gamma: {\\bf N} \\rightarrow {\\bf C}}")#text(". Let ")#mi("{\\theta(n)}")#text(" equal ")#mi("{\\log p}")#text(" when ")#mi("{n}")#text(" is a prime ")#mi("{p}")#text(", and ")#mi("{\\theta(n)=0}")#text(" otherwise. Then one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d < D^2; d|{\\mathcal P}} \\sum_{c \\in C_i(d)} \\left|\\Delta(\\theta; d, c )\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A > 0}")#text(".")
]

#text("Note that this is slightly different from the formulation of ")#mi("{MPZ[\\varpi]}")#text(" in the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("previous post")]#text("; I have reverted to Zhang’s formulation here as the primary purpose of this post is to read through Zhang’s paper. However, I have distinguished two separate parameters here ")#mi("{\\varpi,\\delta}")#text(" instead of one, as it appears that there is some room to optimise by making these two parameters different.")

#text("In the ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("previous post")]#text(", I described how one can deduce ")#mi("{DHL[k_0,2]}")#text(" from ")#mi("{MPZ[\\varpi,\\delta]}")#text(". Ignoring an exponentially small error ")#mi("{\\kappa}")#text(", it turns out that one can deduce ")#mi("{DHL[k_0,2]}")#text(" from ")#mi("{MPZ[\\varpi,\\delta]}")#text(" whenever one can find a smooth function ")#mi("{g: [0,1] \\rightarrow {\\bf R}}")#text(" vanishing to order at least ")#mi("{k_0}")#text(" at ")#mi("{1}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("k_0 \\int_0^1 g^{(k_0-1)}(x)^2 \\frac{x^{k_0-2}}{(k_0-2)!}\\ dx > \\frac{4}{1+4\\varpi} \\int_0^1 g^{(k_0)}(x)^2 \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx.")]]

#text("By selecting ")#mi("{g(x) := \\frac{1}{(k_0+l_0)!} (1-x)^{k_0+l_0}}")#text(" for a real parameter ")#mi("{l_0>0}")#text(" to optimise over, and ignoring the technical ")#mi("{\\kappa}")#text(" term alluded to previously (which is the only quantity here that depends on ")#mi("{\\delta}")#text("), this gives ")#mi("{DHL[k_0,2]}")#text(" from ")#mi("{MPZ[\\varpi,\\delta]}")#text(" whenever ")#metadata(none) <tao-5147a6de6c26ca2472e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("k_0 > (\\sqrt{1+4\\varpi} - 1)^{-2}")]]

#text("It may be possible to do better than this by choosing smarter choices for ")#mi("{g}")#text(", or performing some sort of numerical calculus of variations or spectral theory; people interested in this topic are invited to discuss it in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("the previous post")]#text(".")

#text("The final, and deepest, part of Zhang’s work is the following theorem (Theorem 2 from Zhang’s paper, whose proof occupies Sections 6-13 of that paper, and is about 32 pages long):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Zhang)")]#text(" ")#metadata(none) <tao-14bbfb46cb710ab5cf47>#text(" ")#mi("{MPZ[\\varpi,\\varpi]}")#text(" is true for all ")#mi("{0 < \\varpi \\leq \\frac{1}{1168}}")#text(".")
]

#text("The significance of the fraction ")#mi("{1/1168}")#text(" is that Zhang’s argument proceeds for a general choice of ")#mi("{\\varpi > 0}")#text(", but ultimately the argument only closes if one has")

#align(center)[#tao-fit-display[#mitex("\\frac{31}{32} + 36 \\varpi \\leq 1 - \\frac{\\varpi}{2}")]]

#text("(see page 53 of Zhang) which is equivalent to ")#mi("{\\varpi \\leq 1/1168}")#text(". Plugging in this choice of ")#mi("{\\varpi}")#text(" into ")#link(<tao-5147a6de6c26ca2472e0>)[#text("(1)")]#text(" then gives ")#mi("{DHL[k_0,2]}")#text(" with ")#mi("{k_0 = 341,640}")#text(" as stated previously.")

#text("Improving the value of ")#mi("{\\varpi}")#text(" in Theorem ")#link(<tao-14bbfb46cb710ab5cf47>)[#text("4")]#text(" would lead to improvements in ")#mi("{k_0}")#text(" and then ")#mi("{H}")#text(" as discussed above. The purpose of this reading seminar is then twofold:")

#enum(start: 1, 
[#text("Going through Zhang’s argument in order to improve the value of ")#mi("{\\varpi}")#text(" (perhaps by decreasing ")#mi("{\\delta}")#text("); and")],
[#text("Gaining a more holistic understanding of Zhang’s argument (and perhaps to find some more “global” improvements to that argument), as well as related arguments such as the prior work of Bombieri, Fouvry, Friedlander, and Iwaniec that Zhang’s work is based on.")]
)

#text("In addition to reading through ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text(", the following material is likely to be relevant:")

#list(
[#text("A ")#link("http://blogs.ethz.ch/kowalski/2013/06/04/bounded-gaps-between-primes-some-grittier-details/")[#text("recent blog post of Emmanuel Kowalski")]#text(" on the technical details of Zhang’s argument.")],
[#link("http://www.math.ethz.ch/~kowalski/zhang-notes.pdf")[#text("Scanned notes from a talk related to the above blog post")]#text(".")],
[#text("A recent ")#link("http://www.math.ethz.ch/~kowalski/zhang-notes.pdf")[#text("expository note by Fouvry, Kowalski, and Michel")]#text(" on a Friedlander-Iwaniec character sum relevant to this argument.")],
[#text("This ")#link("http://www.math.ethz.ch/~kowalski/fouvry-iwaniec-on-a-theorem.pdf")[#text("1981 paper of Fouvry and Iwaniec")]#text(" which is the first result in the literature which is roughly of the type ")#mi("{MPZ[\\varpi,\\delta]}")#text(". (This paper seems to give a related result for ")#mi("{\\varpi=1/42}")#text(" and ")#mi("{\\delta = 1/883}")#text(", if I read it correctly; I don’t yet understand what prevents this result or modifications thereof from being used in place of Theorem ")#link(<tao-14bbfb46cb710ab5cf47>)[#text("4")]#text(".)")]
)

#text("I envisage a loose, unstructured format for the reading seminar. In the comments below, I am going to post my own impressions, questions, and remarks as I start going through the material, and I encourage other participants to do the same. The most obvious thing to do is to go through Zhang’s Sections 6-13 in linear order, but it may make sense for some participants to follow a different path. One obvious near-term goal is to carefully go through Zhang’s arguments for ")#mi("{MPZ[\\varpi,\\delta]}")#text(" instead of ")#mi("{MPZ[1/1168,1/1168]}")#text(", and record exactly how various exponents depend on ")#mi("{\\varpi,\\delta}")#text(", and what inequalities these parameters need to obey for the arguments to go through. It may be that this task can be done at a fairly superficial level without the need to carefully go through the analytic number theory estimates in that paper, though of course we should also be doing that as well. This may lead to some “cheap” optimisations of ")#mi("{\\varpi}")#text(" which can then propagate to improved bounds on ")#mi("{k_0}")#text(" and ")#mi("{H}")#text(" thanks to the other parts of the Polymath project.")

#text("Everyone is welcome to participate in this project (as per the usual ")#link("http://polymathprojects.org/general-polymath-rules/")[#text("polymath rules")]#text("); however I would request that “meta” comments about the project that are not directly related to the task of reading Zhang’s paper and related works be placed instead on the ")#link("http://polymathprojects.org/2013/06/04/polymath-proposal-bounded-gaps-between-primes/")[#text("polymath proposal page")]#text(". (Similarly, comments regarding the optimisation of ")#mi("{k_0}")#text(" given ")#mi("{\\varpi}")#text(" and ")#mi("{\\delta}")#text(" should be placed at ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this post")]#text(", while comments on the optimisation of ")#mi("{H}")#text(" given ")#mi("{k_0}")#text(" should be given at ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart")[#text("this post")]#text(". On the other hand, asking questions about Zhang’s paper, even (or especially!) ")#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")[#text("“dumb” ones")]#text(", would be very appropriate for this post and such questions are encouraged.")

#heading(level: 1)[#text("Comments (140)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-2/#comment-238006")[#strong[#text("The p-group fixed point theorem | Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")]

#text("[…] into bounds on the former, and this has various applications, for example the original proof of Zhang’s theorem on bounded gaps between primes (although my understanding is that this step is unnecessary just to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-2/#comment-247245")[#strong[#text("zhang twin prime breakthru vs academic track/grind | Turing Machine")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")]

#text("[…] 7. Online reading seminar for Zhang’s “bounded gaps between primes” | What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-2/#comment-251677")[#strong[#text("An online reading seminar from Terry Tao’s blog | The Conscious Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-prim&#8230")[#text("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-prim&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83b9dcc8285290245c7bc84cb055ccc61078e9f7ab92cd5b10d5c4c8649f09cb-c3e50af6ac910a19569b304785443f44ef200b7071cb8c56143bee76346d9acf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 大数学家张益唐的唐诗舒怀 | Chinoiseries 《汉瀚》")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-2/#comment-379955")[#strong[#text("大数学家张益唐的唐诗舒怀 | Chinoiseries 《汉瀚》")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-prim&#8230")[#text("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-prim&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcce52dd50a93956dfef2a36fc14ebd28d8b045b7548794dea14bf0f7702d0eb-452786fe4a33d26d1588035ad1265d94c9c110f7259698ad39358ac48f8291cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 王晓明")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-2/#comment-445390")[#strong[#text("王晓明")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("从张益唐论文不能发表评数学批判家王晓明的批判艺术")

#text("开场白：")

#text("张益唐的论文因为王晓明的搅局，至今没有发表，这是因为王晓明在2014年3月20日写信给美国【数学年刊】编辑部，阻止了原计划在5月出版的179-3期杂志，不能按照正常时间出版。如今已经12月中旬，以后是否能够发表暂且不说，仅仅一个无名之辈就让大名鼎鼎的【数学年刊】改变计划，足以证明王晓明出手不凡。王晓明是怎么样的批评，能够让世界上数一数二的杂志接受批评呢？")

#text("也有人说张益唐是遭到嫉妒，木秀于林风必摧之，如果张益唐文章没有致命错误，什么妖风可以摧毁呢？")

#text("如果王晓明是一个平庸之人，他的意见都是无稽之谈，没有思想的利器，他给【数学年刊】的信件只会成为笑柄。这是因为在所有学科中，数学的证明最严格，可以做到没有任何歧义，可以做到让全世界数学家都可以接受的严密程度。")

#text("是什么原因让王晓明去挑战全世界最权威的数学家已经认可的理论？王晓明难道就是一个数学无赖存心与科学界捣蛋吗？这样做王晓明可以得到什么呢？")

#text("一定是这个命题的魅力，永不凋谢的青春产生神秘的诱惑，在她的入口处，正向在地狱的入口处一样。张益唐没有通过凯旋门，而是走到了地狱。")

#text("第一刀：")

#text("王晓明杀入张益唐的第一刀是什么？")

#text("数学批判一般有三个批判点，第一是论（命）题批判，第二的论据批判，第三是论证方法批判。")

#text("对张益唐结论的杀伤力无疑最强烈，这是因为，否定了结论就彻底否定了整个工作。")

#text("张益唐公式：")

#text("一开始就让人感觉丑陋，不等式左边表明一种性质，下确界是针对一组数据，极限针对函数和序列，而右边70000000是说左边的素数对，好了，破绽就在这里。小于70000000的素数对是一个“集合概念”。集合概念反映的是集合体，集合体有什么不对吗？")

#text("概念的种类：")

#text("1，单独概念和普遍概念")

#text("a，单独概念反映独一无二的概念，例如，上海，孙中山，，，。它们反映的概念都是独一无二的。")

#text("b，普遍概念，普遍概念反映的是一个对象以上的概念，反映的是一个“类”，例如：工人，无论“石油工人”，“钢铁工人”，还是“中国工人”，“德国工人”，它们必然地具有“工人”的基本属性。")

#text("2，集合概念和非集合概念。")

#text("a，集合概念反映的是集合体，例如“中国工人阶级”，集合体的每一个个体不是必然具备集合体的基本属性，例如某一个“中国工人”，不是必然具有“中国工人阶级”的基本属性。")

#text("b，非集合概念（省略）。")

#text("大家明白了吗？张益唐如果要说不超过70000000的素数对具有无穷性质，必须对所有小于70000000的素数对逐一证明，就是要使用完全归纳法：")

#text("1）相差2的素数对（这是一个类）无穷。")

#text("2）相差4的素数对（类）无穷。")

#text("3）相差6的素数对（类）无穷。")

#text("…….")

#text("35000000）相差7000000的素数对（类）无穷。")

#text("张益唐没有确定相差不超过70000000的素数对都是无穷的。张益唐等于什么也没有说。")

#text("第二刀")

#text("什么是判断？判断就是对思维对象有所断定的形式。")

#text("判断的基本性质：")

#text("1，有所肯定或者有所否定。")

#text("2，判断有真假。")

#text("张益唐没有确定任何一个类是无穷或者有限，张益唐什么也没有说。就是说，张益唐的证明违背了一个判断的基本要求，暂且不说对与错。就连一个明确的判断都没有。")

#text("数学证明就是要求对数学对象给予一个明确的判断。")

#text("第三刀")

#text("就算张益唐想说：“相差不超过70000000的素数对至少有一对是无穷的”。这个也没有做到一个定理的要求啊？张益唐是说“有些A是B”,这是一种“特称判断”这样的说法不能作为数学定理，因为数学定理要求明确的“全称判断”，就是“一切都A是B”。特称判断在日常生活中使用没有问题，甚至在其它学科也没有问题，例如物理学。唯独在数学证明中特称判断无效。")

#text("第四刀")

#text("一个定理陈述一个给定类的所有数学元素不变的关系，适用于无限大的类，在任何时候都无区别成立。张益唐公式左边的变量部分输入一个值，得出结果是需要区别的，就不是定理了，这些结果，人们无法知道，张益唐自己也无法知道：“无穷还是有限”。或者说右边70000000以内的任何一个值对应左边是什么？是无法知道的。")

#text("第五刀")

#text("特称判断为什么不能作为定理？因为特称判断暗含“假定存在”的非逻辑前提，数学证明是严禁使用非逻辑前提，在逻辑学也不允许引入非逻辑前提。这是我们数学中常常发现一个显然的事实却不能成为定理的困难。如果可以引入非逻辑前提，那么数学难题就不会有这么多了。")

#text("小节")

#text("浪漫情怀不能代替严肃的证明，迷信和伪科学让人们不动脑筋就可以欢欣鼓舞，迷信迎合人们懒得思考的需求。而科学是在逐一消除错误的基础之上发展起来的。张益唐的错误工作被否定，私人感情当然受到伤害，但是这种否证公认为科学的核心。")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-2/#comment-462485")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2015")])]

#text("Reblogged this on ")#link("https://tomcircle.wordpress.com/2015/11/27/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-2/#comment-467352")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2016")]

#strong[#text("What math problem has never been solved?")]

#text("If you’re referring to the twin primes hypothesis, the hypothesis is just that there are infinite primes that satisfy the condition (only one integer apart from another prime). The hypothesis is *not* that all primes are twin primes. A very, very weak…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("I haven’t yet read Sections 6-13 of Zhang’s paper in detail yet, but plan to begin very shortly. A few obvious questions come to mind: firstly, how exactly does Zhang’s results differ from previous results of Fouvry-Iwaniec, Friedlander-Iwaniec, and Bombieri-Friedlander-Iwaniec? (Later on I guess we can ask the question of what is the new twist in Zhang’s work that is not present in the previous works, but first I want to understand why the results are different. For instance Fouvry-Iwaniec’s result already looks extremely similar to Zhang’s result; Zhang has more than one residue class mod q whereas FI has just one residue class mod q but otherwise it looks about the same.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232633")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("One issue with Fouvry-Iwaniec is that they do not detect primes, but almost-883-primes. This is in general much easier. On a more technical basis, the relevant counting function akin to Lambda decomposes into suitable bilinear convolutions. This is not true for Lambda, as they state in the middle of page 136 (the decomposition is unsuited).")

#text("Another issue you state is that the residue is fixed as the modulus varies, though Zhang has a different method to deal with that.")

#text("For BFI, they are able to detect primes, but not with the correct sort of arithmetic in the convolutions to get true error bounds. They describe this well in their introduction. For instance, in their Theorem 8, one lacks the absolute value in the PNT error. In their Theorem 9, they are able to handle some products of moduli, but again the error over some of them is cancellative, not in absolute value. In their Theorem 10, they are not able to obtain that the sign function is well-factorable (as they indicate page 207), so again they don’t get this with absolute value.")

#text("I am not too familiar with Friedlander-Iwaniec (at least this paper), and it seems written in a different ansatz. Perhaps one can just say that Zhang (among all other things) imitates and enlarges their work for the ternary divisor function to Lambda.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("When reading through a technical portion of a paper for the first time I find it convenient to activate some “cheats” to factor out some difficulties in the paper. Here are some such “cheats” that I plan to use (some of them suggested to me by Ben Green):")

#text("1. In order to get the basic ideas of the argument we may want to not keep track of exactly how many multiples of ")#mi("\\varpi")#text(" we are losing at each stage, and just use notation such as ")#mi("O(\\varpi)")#text(" instead. Of course, this conflicts with our other goal of trying to numerically optimise ")#mi("\\varpi")#text(" as much as possible, but perhaps we can run these two goals in parallel, with one set of comments trying to get the “big picture” without being too careful with explicit constants, and the other set of comments focusing instead on the numerical details.")

#text("2. Given that the final bound in MPZ gains an arbitrary power ")#mi("\\log^{-A} x")#text(" of a logarithm, we should be very happy to lose factors of ")#mi("\\log^{O(1)} x")#text(" at various places in the argument. So factors such as the divisor function ")#mi("\\tau(n)")#text(", which has logarithmic order on the average, are likely to be harmless. So we might pretend as a first approximation that all numbers of interest have only ")#mi("O(1)")#text(" divisors.")

#text("3. Ben Green suggests replacing ")#mi("\\theta(n)")#text(" (or ")#mi("\\Lambda(n)")#text(") by the Mobius function ")#mi("\\mu(n)")#text(", as this has slightly better cancellation properties and the Heath-Brown type identities for this function are a bit cleaner. Up to logarithmic factors (which by 2. should be practically irrelevant), the von Mangoldt and Mobius functions should morally be about the same for this analysis.")

#text("4. Let’s pretend that rough cutoffs (such as restricting n to ")#mi("x < n < 2x")#text(") behave \"as if\" they are smooth, in particular \"boundary issues\" coming from the edges of a rough cutoff should be negligible in practice.")

#text("5. If we ignore all small primes (e.g. by the W-trick), then almost any pair of \"independent\" natural numbers should be coprime/squarefree, so it should be safe to pretend that this in fact occurs all the time (except when dealing with pairs of natural numbers which are forced by design to have a common factor or a square factor, of course).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232629")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Sections 6-12 of Zhang are basically BFI, which I consider the most readable of that genre (specially the intro, though they usually describe what they are doing quite well). The most pressing trick Zhang has to take account of is, particularly Section 10, that he not dealing with just one residue class per modulus, per those with a multiplicative CRT structure.")

#text("Zhang 6 is the “endgame” decomposition that BFI applies to various target problems in their 15-17.")

#text("Zhang 7 is BFI 3, Zhang 8 is BFI 4, Zhang 9 is BFI 5, Zhang 10 is BFI 6-7 (page 37 and 10.11 is the 6/7 divider). Zhang 11&12 probably are best read directly, as BFI have multiple sections to handle R_1 in various ways and I see no absolute correlative. Zhang’s methods largely follow his previous parts (he calls it analogous himself). He uses a slight Kloostermann variant (Lemma 11) than the literature ascribes, but I don’t feel there is a lot new in that.")

#text("I might actually suggest starting reading 13 and 14 first (after 6 perhaps, to give motivation about why one cares about trliinear estimates), as they are independent, and that is more what is new. I extended a post on Mathoverflow to give a brief overview of what he does.")

#link("http://mathoverflow.net/questions/131185/philosophy-behind-yitang-zhangs-work-on-the-twin-primes-conjecture/132701#132701")[#text("http://mathoverflow.net/questions/131185/philosophy-behind-yitang-zhangs-work-on-the-twin-primes-conjecture/132701#132701")]

#text("See the second half, starting with “Let me try again”. Maybe it can be copied here somehow.")

#text("I have actually not perused the earlier sections (4&5) too carefully, but I take it they have already been sorted out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232630")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Thanks for this! Yes, Sections 4 and 5 seem pretty well understood, my ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("previous blog post")]#text(" gives an alternate presentation for this material that leads to better constants for a given value of ")#mi("\\varpi")#text(".")

#text("One thing that puzzles me is why having to deal with many residue classes per modulus is such a big deal. Suppose for instance that one could prove ")#mi("MPZ[\\varpi,\\delta]")#text(" with just a single residue class mod d for every d, more precisely that")

#tao-math("\\sum_{d < D^2: d | {\\mathcal P}} \\left|\\Delta(\\theta; d, a \\text{ mod } d)\\right| \\ll x \\log^{-A} x", block: false)

#text("for every residue class ")#mi("a \\text{ mod } {\\mathcal P}")#text(". If one then selects the residue class ")#mi("a")#text(" at random over all classes in ")#mi("C_i({\\mathcal P})")#text(" and then takes expectations, one concludes that")

#tao-math("\\sum_{d < D^2: d | {\\mathcal P}} \\left|C_i(d)\\right|^{-1} \\sum_{c \\in C_i(d)} \\left|\\Delta(\\theta; d, c)\\right| \\ll x \\log^{-A} x.", block: false)

#text("On the other hand, from crude estimates one has")

#tao-math("\\sum_{d < D^2: d | {\\mathcal P}} |C_i(d)| \\sum_{c \\in C_i(d)} \\left|\\Delta(\\theta; d, c)\\right| \\ll x \\log^{O(1)} x", block: false)

#text("so from Cauchy-Schwarz one gets Zhang's bound ")#mi("MPZ[\\varpi,\\delta]")#text(". So it seems to me that one could reduce to the case of a single residue class per modulus pretty easily. (Even if there was something wrong with the above argument, I would certainly use the \"one residue class per modulus\" hypothesis as a \"cheat\" when reading through the paper for the first time.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232637")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("I am sorry, I did not explain this well (I am not really in this field, just did analytic number theory may be a decade ago). First I should specify to make clear (though you have it right), It is not just a “single residue class” per modulus as I announced, but a *fixed* value as the modulus varies. The issue, then I suspect (did not think completely) is that the ")#mi("a")#text("-uniformity in your first display is horrid, perhaps nonexistent as you allow it to be as big as ")#mi("P")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232665")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Ah, got it – the dependence on a is key. Extrapolating from this, it suggests that Zhang’s argument must use at some point that the coefficients of the polynomial ")#mi("P_i(n) = \\prod_{h \\in {\\mathcal H}} (n+h-h_i)")#text(" are fixed rather than growing in ")#mi("x")#text("; I guess we’ll see how the polynomial P is used (beyond just the Chinese Remainder Theorem) as we continue reading through the paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232639")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Some remarks:")

#text("(1) The oldest Fouvry-Iwaniec paper was written before Heath-Brown’s identity was known, so there is some inefficiency there.")

#text("(2) For the later papers and Bombieri-Friedlander-Iwaniec, there is a dependency in the residue class ")#mi("a")#text(", which is seen as a positive integer, when applying spectral theory of automorphic forms; this dependency is polynomial in ")#mi("a")#text(" (so one can handle all ")#mi("a")#text(" up to a a power of logarithm, but not more).")

#text("(3) Combining the two: in the “old” Fouvry-Iwaniec paper, the result is expressed for a single class ")#mi("a")#text(", but the implied constant is uniform for ")#mi("1\\leq a\\leq x")#text(" (where looking at integers up to ")#mi("x")#text("), so summing over ")#mi("\\ll (log x)^A")#text(" residue classes is OK, wherever they are located.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232634")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("In the definition of ")#mi("C_i(d)")#text(" in Conjecture 3 I think it should be ")#mi("P(c-h_i) = 0 \\text{ mod } d")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232635")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Just starting to look at Section 6 of Zhang. There are two easy reductions: by using Bombieri-Vinogradov, one restricts the range of ")#mi("d")#text(" from ")#mi("d < x^{1/2+2\\varpi}")#text(" to ")#mi("x^{1/2-\\varepsilon} < d < x^{1/2+\\varpi}")#text(" for some arbitrarily small ")#mi("\\varepsilon")#text(", and one also replaces ")#mi("\\theta")#text(" by the von Mangoldt function ")#mi("\\Lambda")#text(". Another reduction is to let ")#mi("d")#text(" mostly avoid all small primes, in that ")#mi("(d, \\prod_{p < \\exp( \\log^{1/k_0} x)} p ) < x^\\varpi")#text(". This latter restriction seems analogous to the W-trick; as a \"cheat\", I take it to mean that we can assume that d is in fact not divisible by any small prime (e.g. smaller than ")#mi("\\exp( \\log^{1/k_0} x)")#text(").")

#text("Then comes the first tricky thing, which is some Heath-Brown type decomposition of ")#mi("\\Lambda")#text(" into many different Dirichlet convolutions, which are then classified as \"Type I\", \"Type II\", and \"Type III\". It will take some time for me to digest what this decomposition is doing and what Type I, Type II, and Type III are (presumably they are related to the Type I and Type II sums in the Vinogradov-Vaughan estimation of exponential sums in terms of linear and bilinear sums; and presumably the earlier papers of FI and BFI will be helpful here). All the Dirichlet convolutions have to obey a certain Siegel-Walfisz theorem (hypothesis A_2 on page 7) but this is presumably standard. That's about as far as I've got for now; I have to do some other things for a few hours but will return to this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232642")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("I don’t think Type I and II are as different here as they are in some works in this genre, and indeed dispersion handles them on an equal basis for awhile.")

#text("The idea behind the decomposition is to write Lambda as a convolution of (say) 20 things, with each thing in a dyadic (or such) interval at a certain size parameter. Then just by combinatorics, some subproduct of the 20 things must (hopefully) have a factor in a desirable range, that is, one to which a bilinear form can be admirably applied. You group the subproduct and its complement, calling these ")#mi("\\alpha_u")#text(" and ")#mi("\\beta_v")#text(" with the A-conditons on pages 6&7 met. The nuance between whether something is Type I or II only comes up a lot later, and indeed Zhang just declares this ")#mi("x_2")#text(" parameter to be the dividing line.")

#text("Type III is sort of the “leftovers” from the bilinear parts, where you could not force a divisor in a desired range. Maybe the way you go thinking about it is: I know I can prove a suitable bound for such-and-such bilinear forms with these parameters – now, what is left in the decomposition? In fact (top page 26), the only time you get Type III (that is, don’t get Type I/II) is when ")#mi("\\nu_2+\\nu_3\\ge 5/8-8\\omega")#text(" but ")#mi("\\nu_1\\le 3/8+8\\omega")#text(", which is rather restricted, given that the ")#mi("\\nu")#text(" decrease.")

#text("Section 15 of BFI has a picture/cartoon of what is going in their case.")

#text("I’ve seen Type II estimates dealt with by bounding them in terms of linear ones (for instance Duke/Friedlander/Iwaniec, Annals paper on equidistrbution of roots to prime moduli), and here is seems Type I estimates are dealt with “bilinearly”, and the whole nomenclature is confusing to me at least, for authors differ.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232647")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("The closest that BFI has to a trilinear type estimate is their section 11 (Theorem 4), and if you read their Section 15 carefully (bottom half of page 247), you can see that in a similar sense to Zhang, this is the “leftover” of to what bilinear does not apply. I am no expert on BFI though, only looking at this maybe a decade ago on a request from someone else. They handle")

#text("The picture for Zhang is actually much easier than in BFI (for they use a multitude of methods in different ranges). If there is a partial sum in the range ")#mi("[3/8+8\\omega,5/8-8\\omega]")#text(" you win (either directly or by reflection in switching the labels about 1/2) via applying the dispersion method to the relevant bilinear form. Also if ")#mi("\\nu_1\\ge 1/2+3\\omega")#text(" (maybe ")#mi("2+\\epsilon")#text(" rather than 3) the desired result is trivial. So you need everything in the decomposition to be in rather specific ranges for this to go bad. Essentially they either have to be small, or to be at least ")#mi("1/4-16\\omega")#text(" (the scope of that interval). They have to total 1, and having 4 of them large puts the sum of 2 of them near enough 1/2. Similarly, if only 2 are large, then ")#mi("\\nu_1")#text(" will exceed 3/8 by enough (upon defining “small” appropriately, which also has to do with how many items are in the decomposition, 20 in Zhang’s case), and if only ")#mi("\\nu_1")#text(" is large, as noted above the result is trivial. This leaves the middleroad case as there being 3 large ")#mi("\\nu")#text(" values.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232645")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Should equation (1) have a \\varpi instead of \\pi?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232661")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("OK, I think I have chased down much of the error analysis of ")#mi("\\delta")#text(" versus ")#mi("\\omega")#text(" in the later sections. The notation of 7-12 conflicts with that of 13&14 to partial degree. In the former, I think one needs ")#mi("R\\ll x^{1/2-2\\omega}")#text(" on a distribution basis, and the worst bound seems to come near the bottom of page 43, where I think Zhang’s display (third from bottom, with ")#mi("Q^6")#text(") actually is wrong (too small) by a factor of ")#mi("Q")#text(", and I end up getting the necessitated ")#mi("Q^9\\ll x/N")#text(", or in essence ")#mi("Q\\ll x^{1/18}")#text(". This bothers ")#mi("\\delta")#text(", as one must be able to choose ")#mi("r\\sim R")#text(" in a sufficient interval via Lemma 4, and this cannot be done while keeping ")#mi("QR")#text(" small unless the ")#mi("R")#text("-region is large. I get ")#mi("\\delta\\le 1/18-2\\omega")#text(" from all this (maybe there is a quadratic ")#mi("\\omega")#text(" correction, I was not that careful).")

#text("I have not totally checked 13&14 yet (where one swaps Q and R to some flavor). I think the main ")#mi("\\delta")#text("-dependence should be here. The upper bound from (14.8) seems ")#mi("r\\ll x^{1/12-6\\omega}")#text(" though this depends on the precise Section 6 decomposition. You also need ")#mi("r\\gg x^{40\\omega}")#text(" or the like to win in the first place. This means Lemma 4 must produce a divisor ")#mi("r")#text(" in a range of length ")#mi("x^{1/12-46\\omega}")#text(" to win, or ")#mi("\\delta\\le 1/12-46\\omega")#text(" and ")#mi("\\delta\\le 1/24-3\\omega")#text(" with Lemma 4 as/is (the latter from ")#mi("D_1^2\\le R^\\star")#text(" condition). The first limitation is more stringent for ")#mi("\\omega")#text(" of probable interest, even if 46 becomes 20 or 30. Namely, even with ")#mi("1/12-20\\omega")#text(" this is zero at ")#mi("\\omega\\sim 1/240")#text(", which is what I suggested the argument could handle elsewhere. So there could be a dual optimization with ")#mi("\\omega")#text(" and ")#mi("\\delta")#text(" if this is in fact correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232667")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Great! I am several sections behind with the reading but hopefully I or someone else) will be able to confirm your calculations in the near future when I catch up. In the meantime, I’ll enter your value for ")#mi("\\varpi")#text(" provisionally on the wiki page (")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#World_records")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#World_records")]#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232673")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Well, there is also an issue with the ")#mi("d_1(Kr)^2")#text(" term in Section 14, as I get that one needs ")#mi("r\\ll x/dMN_1\\sim x^{1/8-10\\omega}")#text(". Again if I assume various optimizations can be made, it is around ")#mi("\\omega\\sim 1/240")#text(" that there is no room for ")#mi("r")#text(" or ")#mi("\\delta\\le 0")#text(". But I would say this is more of a “limit” of what I could see working in the current form, rather than a “record”, even provisionally. I suspect that the “record” as in what I could currently write down – is maybe three times smaller.")

#text("It could also be the case, if ")#mi("\\delta")#text(" is more prevalent for prime gaps, that one could aim to make ")#mi("\\omega")#text(" smaller so as to enlarge reflexively ")#mi("\\delta")#text(". In this aspect, I find the above ")#mi("\\delta\\le 1/24-3\\omega")#text(" to be the worst, though maybe the Fourier analysis with the ")#mi("1/12")#text(" in Section 14 can be improved (the ")#mi("r")#text("-bound there is a bit unneeded IMO, but I have yet to detail it out). That would leave something like ")#mi("\\delta\\le 1/18-2\\omega")#text(" as the limit. Is there an automated method to determine a prime gap size from a given ")#mi("\\delta")#text(" and ")#mi("\\omega")#text(" yet? I don’t want to aim to optimize the wrong one, though I admit all I have done so far is catalogue the error terms of Zhang, to see what looks feasible, and maybe level of distribution is in interest by its own.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232677")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("OK, I will annotate these values accordingly onthe wiki.")

#text("Basically, the dependence of ")#mi("k_0")#text(" on ")#mi("\\delta")#text(" and ")#mi("\\varpi")#text(" is almost independent of ")#mi("\\delta")#text(": ")#mi("k_0")#text(" is basically ")#mi("(2\\varpi)^{-2}")#text(" (up to a small correction) as long as ")#mi("\\delta")#text(" is not incredibly small (e.g. ")#mi("\\delta > 1/10000")#text(" should be OK). So as a first approximation one could even treat ")#mi("\\delta")#text(" as being negligible and see if that helps increase the value of ")#mi("\\varpi")#text(". (The prime gap H one gets at the end of the day is roughly ")#mi("k_0 \\log k_0")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232694")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("I see some improvement room in 13&14. Essentially, in 14.8 Zhang uses ")#mi("N_3^{\\prime}\\ll x^{1/3}")#text(" while in 13.11 he uses ")#mi("MN_3^{\\prime}\\sim x^{3/8+8\\omega}")#text(" as the worst possible ")#mi("N_3^{\\prime}")#text(" value. But since ")#mi("MN_1^{\\prime}N_2^{\\prime}N_3^{\\prime}\\sim x")#text(": when the first condition holds, then ")#mi("M")#text(" is small. So in fact, one gets an improved 14.8. If I did this correctly, one achieves that ")#mi("d_1^{3/2}\\ge x/MN_3^{\\prime}\\ge N_3^{\\prime 2}")#text(" (else a trivial bound applies), and then in the worst case one gets 14.8 as ")#mi("N_3^{\\prime}/d_1\\le 1/d_1^{1/4}\\le x^{-5/48+3\\omega/2}")#text(" from 13.11 (which is itself improvable, as Zhang saves ")#mi("\\omega")#text(" rather than epsilon). Zhang essentially bounds ")#mi("N_3^{\\prime}/d_1\\le 1/N_3^{\\prime 1/3}")#text(" instead. So one only needs ")#mi("r\\ll x^{5/48-3\\omega/2}")#text(" in (14.8). This is still worse that the bound I computed wth (14.5). I am still also not sure that (14.8) is all needed with the Fourier bound below.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232714")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("If I have computed correctly, with my assumed improvements to how Zhang wins with his choice of ")#mi("r")#text(", you will need in Sections 13 and 14 to have ")#mi("5/48-\\omega\\ge 32\\omega")#text(" and ")#mi("1/8-(6+2)\\omega\\ge 32\\omega")#text(", so the ballpark is ")#mi("\\omega\\sim 1/320")#text(". This includes my reworking of his ")#mi("x_1")#text(" definition to be ")#mi("x^{3/8+(3\\cdot 2)\\omega}")#text(" rather than ")#mi("(4\\cdot 2)\\omega")#text(". Again I say this is the “goal”, not something I have written down. It might be that the ")#mi("32\\omega")#text(" could be reduced to ")#mi("24\\omega")#text(", I don’t really know. Zhang right now has essentially ")#mi("4(2+4\\cdot 2)\\omega")#text(" there as the margin that the ")#mi("r")#text(" needs to beat the Fourier losses, but I can see the room to improve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232749")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("In fact it might be a bit better than this. You can also use a 2-variable estimate in 13.7 in some cases (highly nontrivial Deligne result, but applied directly), see (2.4) of Friedlander/Iwaniec. I think this means that when ")#mi("d_1^2M<x")#text(" you are Ok, which again pokes up the ")#mi("N_3^{\\prime}/d_1")#text(" bound of (14.8), to ")#mi("N_3^{\\prime}/d_1\\le 1/d_1^{1/3}")#text(". This then now gives ")#mi("r\\ll x^{5/36-2\\omega}")#text(", and by now this term is better in all ways that the ")#mi("r\\ll x^{1/8-10\\omega}")#text(" from (14.5) and congruence sums.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232892")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("In reply to my comment about the 2-variable Deligne estimate as in (2.4) of FI for Zhang’s 13.7: you can also try to use the FI Theorem 4. This produces nontrivial results for some more ")#mi("d")#text("-ranges, though by now I think the Section 14 ")#mi("r")#text("-limit is elsewhere. However, with ")#mi("d\\sim x^{1/2+2\\omega}, N_i\\sim x^{5/16-4\\omega}, M\\sim x^{1/16+12\\omega}")#text(" (this worst case appears on Kowalski blog too), the bound from FI Theorem 4 is ")#mi("x^{21\\omega/2}")#text(" too large. All too, this seems to be what Zhang means near the very end of introduction, as he says FI gives an efficient estimate valid only for ")#mi("MN_1\\ll x^{3/8-5\\omega/2}")#text(" while he needs ")#mi("MN_1")#text(" as large as ")#mi("x^{3/8+8\\omega}")#text(", and the difference in exponents is exactly so.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Back to reading Section 6 of Zhang. The basic decomposition of the von Mangoldt function ")#mi("\\Lambda")#text(" is via the Heath-Brown identity (Lemma 6 of Zhang). I have not had occasion to use this identity before (relying instead on the Vaughan identity when I needed to decompose von Mangoldt into truncated Dirichlet convolutions), so I am recording here how the identity is proven. If ")#mi("L(n) := \\log n")#text(", then we have the Dirichlet convolution identities")

#mi("\\Lambda = \\mu * L")#text(" and ")#mi("\\delta = \\mu * 1")

#text("and hence")

#mi("\\Lambda = \\mu^{*10} * 1^{*9} * L")#text(" (*)")

#text("where ")#mi("f^{*n}")#text(" is the n-fold Dirichlet convolution of f.")

#text("Now let ")#mi("x_*")#text(" be a little bit bigger than ")#mi("x^{1/10}")#text(" (it seems to me by the way that there is a tiny misprint in Lemma 6 of Zhang in that ")#mi("x_*")#text(" needs to be larger than ")#mi("(2x)^{1/10}")#text(" rather than ")#mi("x^{1/10}")#text(" but this is surely irrelevant). We split ")#mi("\\mu = \\mu_{\\leq x_*} + \\mu_{>x_*}")#text(" where ")#mi("\\mu_{\\leq x_*}")#text(" is ")#mi("\\mu")#text(" restricted to the interval ")#mi("[1,x_*]")#text(" and similarly for ")#mi("\\mu_{>x_*}")#text(". Then on the interval ")#mi("[x,2x]")#text(" we have")

#mi("\\mu_{>x_*}^{*10} * 1^{*9} * L = 0")

#text("since one cannot factor an element of [x,2x] as the product of 10 elements larger than ")#mi("x_*")#text(" times a bunch of other factors. Splitting ")#mi("\\mu_{>x_*} = \\mu - \\mu_{\\leq x_*}")#text(" and expanding out using the binomial formula and (*), one eventually gets to write ")#mi("\\Lambda")#text(" on [x_*,2x_*] as a whole bunch of convolutions:")

#mi("\\Lambda = \\sum_{j=1}^{10} (-1)^{j-1} \\binom{10}{j} \\mu_{\\leq x_*}^{*j} * 1^{*j-1} * L")#text(".")

#text("This is the Heath-Brown identity of order 10. (Why does Zhang use 10? Could this be a parameter to optimise over?)")

#text("After some routine dyadic decomposition and dealing with some minor error terms, we can thus approximately express ")#mi("\\Lambda")#text(" as a combination of a polylogarithmic number of convolutions basically of the form")

#mi("(\\log N_1) \\mu \\chi_{M_1} * \\ldots * \\mu \\chi_{M_j} * \\chi_{N_j} * \\ldots * \\chi_{N_1}")#text(" (**)")

#text("for some ")#mi("1 \\leq j \\leq 10")#text(" and parameters ")#mi("M_1,\\ldots,M_j,N_1,\\ldots,N_j")#text(" with (roughly speaking) ")#mi("M_1,\\ldots,M_j \\leq x^{1/10}")#text(" and ")#mi("M_1 \\ldots M_j N_1 \\ldots N_j \\sim x")#text(". Here ")#mi("\\chi_N")#text(" is a dyadic (or slightly finer than dyadic) localisation to scale ")#mi("N")#text(" whose precise definition does not seem to be terribly important. Presumably the log factor ")#mi("\\log N_1")#text(" is irrelevant since we are going to be gaining lots of log factors eventually.")

#text("There is one class of convolution (**) which is easy to dispose of, and that is the contributions when one of the ")#mi("N_j")#text(", say ")#mi("N_1")#text(", is very large, say bigger than ")#mi("x^{1/2+3\\varpi}")#text(". This is because in this case (**) becomes a combination of indicator functions of quite long arithmetic progressions of spacing less than ")#mi("x^{1/2-3\\varpi}")#text(", and so from the Chinese remainder theorem they are going to be very well distributed modulo ")#mi("d")#text(" for (almost) every ")#mi("d \\leq x^{1/2+2\\varpi}")#text(". (Here it is clear, as v08ltu said, that there are several places where Zhang has been using a ")#mi("\\varpi")#text(" where he could have used an infinitesimal epsilon instead, so there should be some cheap opportunities to save some factors of ")#mi("\\varpi")#text(" here and there. I won’t try to seriously optimise these things though until maybe a second pass through these sections when I understand things better.)")

#text("For the remaining convolutions of the form (*), Zhang classifies them into “Type I”, “Type II”, or “Type III”, depending on the various sizes of the ")#mi("M_1,\\ldots,M_j,N_1,\\ldots,N_j")#text(". I have not yet digested what these types are, but that is probably what I will turn to next in my reading.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232717")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Zhang uses 10 to make ")#mi("M\\le x^{1/10}")#text(" be small. This is used in the last sentence on page 25, when ")#mi("j=2")#text(" he gets ")#mi("\\nu_1\\ge 2/5\\ge 3/8+8\\omega")#text(" from it. I don’t think there is much to be had from fiddling with this, if you take 10 to be 1000, the argument is the same in the convolutions. You can get by with 9, if ")#mi("\\omega")#text(" is small enough.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c18b01ce7045b846d4b345c7e6a1f00fc78b7920dad1c72e409ae7ea7096c624-59149e3910509c0e2baab70107bfb50470121150beec3e39523e9f8ae21d2669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of castover")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232719")[#strong[#text("castover")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Reblogged this on ")#link("http://riemannianhunger.wordpress.com/2013/06/05/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")[#text("riemannian hunger")]#text(" and commented:")#linebreak()#text(" Dr. Terence Tao has arranged for an online reading seminar to go through Dr. Yitang Zhang’s recent proof of the “Bounded Gaps Conjecture.” To say that this is a wonderful opportunity to pick something valuable up regarding a field that’s very hot right now in the research community would be the ultimate understatement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232741")[#strong[#text("The polymath project: massively collaborative mathematics | Adsu's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")]

#text("[…] raiz del post de Tao Online reading seminar for Zhang’s “bounded gaps between primes”, he sabido de la existencia del proyecto polymath […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02242c47c189bdeee6118d74b2f6d153f67b1257413b83486b2a8af92c31af13-2924c613ac702b4e69366a83b09c13ca5a2388f04ed910d1e729ca540e073d0d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath Project | Math Online Tom Circle")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232793")[#strong[#text("Polymath Project | Math Online Tom Circle")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-prim&#8230")[#text("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-prim&#8230")]#text("; […]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d62cc495739d57c707a5605bfbbe47d8850217cccc8444136ea1793fa3dc38b4-3c12148a12ed29af8284811eb104bf992392f47d631f55c40850feee831ab232.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Lange")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232798")[#strong[#text("Klaus Lange")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Wonderful work so far. But with this methods I think H < 10^3 isn't reachable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232830")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I think ")#mi("H<10^5")#text(" is realistic in the light of comments on ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")]#text(" and ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart/")[#text("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87b9c73bde5b0aaf898dcb44dfd94cda8891ee9da095a40da63a779c83b7e8ea-3841db76a0c5d1981882970b6dd393579be341ce5df3a8562da8db1dcf7a9dee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232832")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("It seems that after the serious attacks began (Morrison, Tao, et al.) and the polymath project launched they may have reduced the bound by a factor 200 in about 1 week. It will probably not go that fast from now on, but it looks very promising in my eyes.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232869")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I have a very naive background question. Suppose instead of “primes” you ask about integers with odd number of (all) distinct prime factors (namely mobius function=1). What is known then about gaps?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232890")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I think one can get gaps of size at most 2 by the following argument. Let ")#mi("w")#text(" be a moderately large number, and let ")#mi("W := \\prod_{p<w} p")#text(" be the product of all the primes less than w. By the Chinese Remainder Theorem we can find three consecutive residue classes ")#mi("b, b+1, b+2 \\text{ mod } W^2")#text(" which are square-free mod W^2, which implies that about ")#mi("1-O(1/w)")#text(" of each of these classes will consist of square-free numbers. On the other hand from the prime number theorem in arithmetic progressions we know that ")#mi("\\mu(n)")#text(" takes the values +1 and -1 asymptotically equally often in each of these three residue classes. Thus the density of ")#mi("\\{ n: \\mu(n) = -1 \\}")#text(" in each of these three classes is ")#mi("1/2 - O(1/w)")#text(", which is greater than 1/3 for w large enough (actually w only needs to be as big as 11 or so), and the claim then follows from the pigeonhole principle.")

#text("This argument comes really really close to the optimal gap of size 1, but I don't see a way to prevent the absurd possibility that mu alternates in sign on every connected block of squarefree numbers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27a32c47a0bb624b554c02f628b2a94362fed73bea1cf1cbd01049ab1aabea20-d67d36ca3fba5f314749153a396e9ee97f9d249b83b4616dbf0e35cc35a642d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghaith")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232941")[#strong[#text("Ghaith")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I don’t follow the first part of the argument where one finds three consecutive residue classes each consisting mostly of square-free numbers. Can you clarify that part please? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232954")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("One can take for instance the residue classes ")#mi("1 \\text{ mod } W^2")#text(", ")#mi("2 \\text{ mod } W^2")#text(", and ")#mi("3 \\text{ mod } W^2")#text("; in each such class the density of square-free numbers is ")#mi("\\prod_{p \\geq w} (1-\\frac{1}{p^2}) = 1 - O(1/w)")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27a32c47a0bb624b554c02f628b2a94362fed73bea1cf1cbd01049ab1aabea20-d67d36ca3fba5f314749153a396e9ee97f9d249b83b4616dbf0e35cc35a642d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ghaith")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233196")[#strong[#text("Ghaith")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Thanks, though my question was really about the density ")#mi("\\prod_{p\\ge w} (1-1/p^2)")#text(" (whether it was simple to see it somehow); sorry I wasn’t being more precise. In any case, I had figured something shortly after.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232948")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Maybe I am misunderstanding the question. For $\\lambda$, Hildebrand showed that all eight ")#mi("\\pm 1")#text(" sequences of length 3 occur infinitely often, while Buttkewitz and Elsholtz improved this to length 4 in AP.")

#link("http://mathoverflow.net/questions/78623/fluctuations-of-liouville-function")[#text("http://mathoverflow.net/questions/78623/fluctuations-of-liouville-function")]

#link("http://jlms.oxfordjournals.org/content/84/3/578")[#text("http://jlms.oxfordjournals.org/content/84/3/578")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232895")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I want to clairfy, is this a question about ")#mi("\\mu")#text(" or ")#mi("\\lambda")#text(" (the Carmichael function)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233578")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Dear v08ltu, I asked about ")#mi("\\mu")#text(" but my main point was to ask if it may provide a simpler “toy question” for some of the issues/techniques for the prime case, (so ")#mi("\\lambda")#text(" also qualifies for that).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A (partial) answer to my Goedelian conundrum? | cartesian product")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232879")[#strong[#text("A (partial) answer to my Goedelian conundrum? | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("[…] Online reading seminar for Zhang’s “bounded gaps between primes” (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yitang Zhang latest… | cartesian product")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232893")[#strong[#text("Yitang Zhang latest… | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("[…] Online reading seminar for Zhang’s “bounded gaps between primes” (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232912")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("A comment from having a look at Section 6 today, without any books to hand, is that it was deeply unclear to me how these “Siegel-Walfisz” statements are supposed to hold for such large moduli (the Siegel-Walfisz result for primes only allows moduli up to ")#mi("\\log^{O(1)} x")#text("). It seems, however, that all of the ")#mi("\\beta")#text(" for which this is claimed are Dirichlet convolutions of two things, and I believe that gets you out of jail as you can expand into characters modulo ")#mi("q")#text(" and use Parseval. I haven’t checked the details of that, but it definitely makes Section 6 tough going for the uninitiated! I may also have overlooked something obvious. Terry, in answer to your comment above, I’m not sure there’s any good reason he applies HB with parameter 10; I think it could equally well be 10000. Maybe 10 is the smallest workable value.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232913")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("In the middle of page 246 of BFI, they similarly give 0 details about applying S-W. I had wondered about this at one point, but then I thought you just executed an innermost sum and got cancellation from that. Maybe I need to think more.")

#text("In another comment, I pointed out that Zhang has 10 so that (bottom page 25) ")#mi("\\nu_1\\ge 2/5=(10-2)/10/2\\ge 3/8+8\\omega")#text(" when ")#mi("j=2")#text(", making his decomposition go through as-is. Here 9 also works if ")#mi("\\omega")#text(" is small enough.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Lewko")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232916")[#strong[#text("Mark Lewko")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Where in section 6 is he making use of a Siegel-Walfisz-type estimate for large moduli? (not that I’m not having my own issues with the section)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232918")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I think the point is: for moduli ")#mi("r")#text(" larger than ")#mi("\\log(x)^{200A}")#text(", the bound is in A2 is trivial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233020")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Yes, I see that in my comment on SW I was mistaken in thinking that large moduli are required. I was confused by the fact that no restrictions are replaced on r – however, as pointed out by v08ltu, the way the bound is stated means that it is trivial unless r is less than ")#mi("\\log^{O(1)} x")#text(". So I’m happy that nothing at all underhand is going on here! I guess that for the purposes of initial discussion we should pretty much ignore this SW condition.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Returning to Section 6 again. Zhang is using the Heath-Brown identity to decompose ")#mi("\\Lambda")#text(" (on ")#mi("[x,2x]")#text(") into components that factor as Dirichlet convolutions of factors supported at moderate scales (in particular, one doesn’t want to sum “rough” functions like ")#mi("\\mu")#text(" over very large scales, e.g at scales close to ")#mi("x")#text(").")

#text("I’m more used to the ")#link("http://en.wikipedia.org/wiki/Vaughan's_identity")[#text("Vaughan identity")]#text(", which in this context would split")

#mi("\\Lambda = \\mu_{\\leq U} * L - \\mu_{\\leq U} * \\Lambda_{\\leq V} * 1 + \\mu_{>U} * \\Lambda_{>V} * 1")

#text("for some ")#mi("U, V")#text(" with ")#mi("UV < x")#text(". This splits ")#mi("\\Lambda")#text(" into Type I sums ")#mi("\\mu_{\\leq U} * L")#text(" and ")#mi("\\mu_{\\leq U} * \\Lambda_{\\leq V} * 1")#text(" (which contain one smoothly varying factor at a large scale, so that linear exponential sum or equidistribution estimates may be applied) and a Type II sum ")#mi("\\mu_{>U} * \\Lambda_{>V} * 1")#text(" (which contain two rough factors ")#mi("\\mu_{>U}")#text(", ")#mi("\\Lambda_{>V}")#text(" that both span large scales and for which one can hope to use bilinear estimates)")

#text("With Heath-Brown, one instead splits ")#mi("\\Lambda")#text(" into convolutions of the shape")

#mi("\\mu \\chi_{M_1} * \\ldots * \\mu \\chi_{M_j} * \\chi_{N_j} * \\ldots * \\chi_{N_1}")#text(" (*)")

#text("where ")#mi("M_1 \\ldots M_j N_1 \\ldots N_j \\sim x")#text(" and ")#mi("M_1,\\ldots,M_j")#text(" are small (less than ")#mi("x^{1/10}")#text(", say); also we can easily dispose of those sums where one of the ")#mi("N_i")#text(" is huge (larger than ")#mi("x^{1/2+3\\varpi}")#text("). There are some log factors here which do not appear to be important and so I omit them here.")

#text("The remaining components of ")#mi("\\Lambda")#text(" are then classified into three types, which are roughly as follows (pages 6-7 of Zhang):")

#text("* TYPE I: convolutions that can be expressed as ")#mi("\\alpha * \\beta")#text(", where ")#mi("\\beta")#text(" lives at some scale between ")#mi("x^{3/8+8\\varpi}")#text(" and ")#mi("x^{1/2-4\\varpi}")#text(", which forces ")#mi("\\alpha")#text(" to live at the opposite scale between ")#mi("x^{1/2+4\\varpi}")#text(" and ")#mi("x^{5/8-8\\varpi}")#text(" (ignoring some small factors).")

#text("* TYPE II: These are similar to Type I, i.e. expressions of the form ")#mi("\\alpha*\\beta")#text(", but now ")#mi("\\beta")#text(" lives at scales very close to ")#mi("x^{1/2}")#text(" (between ")#mi("x^{1/2-4\\varpi}")#text(" and ")#mi("x^{1/2}")#text("), so ")#mi("\\alpha")#text(" also lives close to ")#mi("x^{1/2}")#text(" (between ")#mi("x^{1/2}")#text(" and ")#mi("x^{1/2+4\\varpi}")#text(").")

#text("* TYPE III: These convolutions factor as ")#mi("\\alpha * \\chi_{N_1} * \\chi_{N_2} * \\chi_{N_3}")#text(" where ")#mi("\\alpha")#text(" is supported at some scale M with ")#mi("M N_i \\leq x^{3/8+8\\varpi}")#text(" for all i (or equivalently ")#mi("N_i N_{i^{\\prime}} \\geq x^{5/8-8\\varpi}")#text(" for all ")#mi("1 \\leq i < i^{\\prime} \\leq 3")#text(".")

#text("In the Type I and Type II cases, the ")#mi("\\beta")#text(" factor is required to obey a Siegel-Walfisz property (A_2), namely good equidistribution properties in progressions of very small moduli (polylogarithmic in size), but this property is automatic for any of the factors ")#mi("\\mu \\chi_{M_i}")#text(" or ")#mi("\\chi_{N_i}")#text(" once it is of non-trivial size (with the former coming from the Siegel-Walfisz theorem), and the property is preserved by convolution, so this does not seem to be an issue.")

#text("Now we claim that all convolutions (*) can be factored into one of the three types I,II,III (after excluding the case when one of the ")#mi("N_i")#text(" is larger than ")#mi("x^{1/2+3\\varpi}")#text(").")

#text("If there is any subset of the factors in (*) that multiply to something at scale between ")#mi("x^{3/8+8\\varpi}")#text(" and ")#mi("x^{5/8-8\\varpi}")#text(" then one is going to be in Type I or II by calling that product either ")#mi("\\alpha")#text(" or ")#mi("\\beta")#text(" as appropriate. So the only remaining case is in the rather unusual situation in which all subproducts in (*) have scale either less than ")#mi("x^{3/8+8\\varpi}")#text(" or ")#mi("x^{5/8-8\\varpi}")#text(". Let’s call this the “gap property”.")

#text("Now order ")#mi("N_1 > N_2 > \\ldots > N_j")#text(". If ")#mi("N_2 N_3 > x^{5/8-8\\varpi}")#text(" then we are in type III (taking ")#mi("\\alpha")#text(" to be everything except for the ")#mi("N_1,N_2,N_3")#text(" terms). So by the previous discussion we may assume that ")#mi("N_2 N_3 < x^{3/8+8\\varpi}")#text(". In particular this makes ")#mi("N_i < x^{3/16+4\\varpi}")#text(" for ")#mi("i > 3")#text(", and also ")#mi("N_1 N_4 \\ldots N_j M_1 \\ldots M_j > x^{5/8-8\\varpi}")#text(". But if we remove all the small factors ")#mi("N_4,\\ldots,N_j,M_1,\\ldots,M_j")#text(" one by one using the gap property we conclude that ")#mi("N_1 > x^{5/8-8\\varpi}")#text(", a contradiction. So everybody gets to be in Type I, Type II, or Type III. I begin to see what v08ltu and Ben were saying that the 10 in Heath-Brown could be replaced by any larger constant without much impact on this decomposition (other than to pile on some more logarithmic factors which are going to eventually become irrelevant anyway).")

#text("Zhang says that Type I and Type II sums are to be controlled by the dispersion method and Type III sums require the Birch-Bombieri result on some sort of Kloosterman sum (Lemma 12). I guess this will become clearer in later sections…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232933")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("It might be better to think of it: we can bound well-enough the relevant ensuing sums, bilinear or trilinear – in range A via some method, in range B for via some other method (here closely related), and in range C by some third method (and maybe in range D for trivial reasons). Fortunately these ranges cover all possibilities. Compare Section 15 of BFI (where the methods for the applied Theorem 1-3 differ, and they need a couple of additional “special” cases a la Zhang’s trilinear work to make it all glue).")

#text("When going through the later parts, it is worthy to pin down exactly what ranges the various arguments indeed work (they return nontrivial estimates in larger ranges than merely A-C as Zhang demands). Some of the FI papers in this genre deliberately leave the combinatorial arguments to the end, trying to shine on the other parts, and write them to maximum flexibility in the parameters. Zhang does not gives this emphasis. For instance the Type I/II splitting point is essentially freely-chosen by him to be as close as possible to ")#mi("\\sqrt {x}")#text(" with Type I still valid (evident in Section 11), while he instead could have determined how low the Type II estimates really work. Away from endpoints of ranges, he is winning by a power of ")#mi("x")#text(" in each Type, so there is room to phrase it either way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232955")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("That’s not a bad philosophy to keep in mind going forward. I guess as a cartoon, the Type I/II/III distinction is as follows:")

#text("* Type I/II components take the form ")#mi("\\alpha*\\beta")#text(" where ")#mi("\\alpha,\\beta")#text(" are supported at medium sized scales (more precisely, between ")#mi("x^{3/8+8\\varpi}")#text(" to ")#mi("x^{5/8-8\\varpi}")#text(", but presumably this precise range will be negotiable);")

#text("* Type III components take the form ")#mi("\\alpha * \\chi_{N_1} * \\chi_{N_2} * \\chi_{N_3}")#text(" where ")#mi("\\chi_{N_1}, \\chi_{N_2}, \\chi_{N_3}")#text(" are supported at medium sized scales and are “smoothly varying” on their support (indeed they are constant on their support).")

#text("* Type 0 components (which were disposed of very quickly) take the form ")#mi("\\alpha * \\chi_{N_1}")#text(" where ")#mi("N_1")#text(" is huge (at least ")#mi("x^{1/2+3\\varpi}")#text(", to be precise).")

#text("I got confused for a while because I thought Type I and Type II here somehow corresponded to Type I and Type II in Vingradov-Vaughan exponential sums, but there does not seem to be such a correspondence after all (here Type I and Type II look to be much closer to each other than to Type III). If anything, Type I in Vinogradov-Vaughan is a bit like Type 0 here, and Type II in Vinogradov-Vaughan is like Type I/II here.")

#text("Incidentally, for my own edification, I extracted the precise combinatorial lemma Zhang is relying on in Section 6 (though as you say we may end up doing a different combinatorial optimisation once we figure out what the limits of the Type I, Type II, and Type III analyses are):")

#strong[#text("Lemma")]#text(" Let ")#mi("1/10 < \\alpha < 1/2")#text(", and let ")#mi("x_1,\\ldots,x_n")#text(" be non-negative numbers summing to 1. Then at least one of the following three statements hold:")

#text("(Type I/II): There is a partial sum ")#mi("\\sum_{i \\in S} x_i")#text(" that lies in ")#mi("[1/2-\\alpha,1/2]")#text(".")

#text("(Type 0): There is an ")#mi("x_i")#text(" that is larger than ")#mi("1/2+\\alpha")#text(".")

#text("(Type III): There exist distinct ")#mi("i,j,k")#text(" with ")#mi("2\\alpha < x_i,x_j,x_k < 1/2-\\alpha")#text(" and ")#mi("x_i+x_j,x_i+x_k,x_j+x_k >   1/2+\\alpha")#text(". (This case can only occur for ")#mi("\\alpha \\leq 1/6")#text(".)")

#text("Zhang basically applies this lemma for ")#mi("\\alpha = 1/8 - 8\\varpi")#text(". (This already restricts to ")#mi("\\varpi \\leq 1/320")#text(", but there may be room to maneuver here.)")

#strong[#text("Proof")]#text(" Suppose Type I/II never occurs, then every partial sum is either “small” in the sense that it is less than ")#mi("1/2-\\alpha")#text(", or “large” in the sense that it is greater than ")#mi("1/2+\\alpha")#text(".")

#text("Call a summand ")#mi("x_i")#text(" “useless” if it cannot be used to turn a small partial sum into a large partial sum, thus there are no ")#mi("S \\subset \\{1,\\ldots,n\\} \\backslash \\{i\\}")#text(" such that ")#mi("\\sum_{j \\in S} x_j")#text(" is small and ")#mi("x_i + \\sum_{j \\in S} x_j")#text(" is large. We then split ")#mi("\\{1,\\ldots,n\\} = A \\cup B")#text(" where ")#mi("A")#text(" are the useless elements and ")#mi("B")#text(" are the useful elements.")

#text("By induction we see that if ")#mi("S \\subset B")#text(" and ")#mi("\\sum_{i \\in S} x_i")#text(" is small, then ")#mi("\\sum_{i \\in S} x_i + \\sum_{i \\in A} x_i")#text(" is also small. Thus every sum of useful elements is either less than ")#mi("1/2-\\alpha-\\sum_{i \\in A} x_i")#text(" or larger than ")#mi("1/2+\\alpha")#text(". Since a useful element must be able to convert a small sum to a large sum, we conclude that every useful element has size greater than ")#mi("2\\alpha + \\sum_{i \\in A} x_i")#text(". We may assume we are not in Type 0, then every useful element is larger than ")#mi("2\\alpha + \\sum_{i \\in A} x_i")#text(" and is less than ")#mi("1/2 - \\alpha - \\sum_{i \\in A} x_i")#text(". In particular, there have to be at least three useful elements, otherwise ")#mi("\\sum_{i=1}^n x_i")#text(" cannot be as large as 1. As ")#mi("\\alpha > 1/10")#text(", we have ")#mi("4\\alpha > 1/2-\\alpha")#text(", and we conclude that the sum of any two useful elements is large. Taking ")#mi("x_i,x_j,x_k")#text(" to be three useful elements we land in Type I/II.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232957")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("In the statement of (Type I/II) I perceive the interval should be ")#mi("1/2-\\alpha,1/2+\\alpha]")#text(", not ")#mi("[1/2-\\alpha,1/2]")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232958")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Well, it’s equivalent: if ")#mi("\\sum_{i \\in S} x_i")#text(" lies in ")#mi("[1/2,1/2+\\alpha]")#text(" then the complementary sum ")#mi("\\sum_{i \\not \\in S} x_i")#text(" lies in ")#mi("[1/2-\\alpha,1/2]")#text(". (I guess I should have explicitly mentioned that I was relying on that symmetry though.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232934")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Just a note, the dispersion method also requires Kloosterman sums (well known ones), this will be clearer later… The idea is that you approximate the characteristic function of an interval smoothly, and with congruence conditions modulo ")#mi("d")#text(" this gives a sum artistically like ")#mi("\\sum_{h\\le H}\\sum{n_2}\\sum_{n_3}e_d(h\\overline{n_2n_3}))")#text(" with small error when ")#mi("H")#text(" is of decent size. In this dispersion context, what you do is square the discrepancy ")#mi("\\Delta")#text(" via Cauchy, giving ")#mi("(X-Y)^2=X^2-2XY+Y^2")#text(" and the above ")#mi("h=0")#text(" contributions from the 3 parts all cancel out. So you are left to handle the higher harmonics, and this is where an appeal to (incomplete) Kloostermann sums shall avail.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232935")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Bah, that triple sum is written wrong (and is perhaps more complicated than need be). It should also contain ")#mi("\\hat f(h/d)")#text(" of course, where ")#mi("f")#text(" is the smooth approximant. That’s what Fourier analysis is all about (Lemma 7) changing a sum over ")#mi("f")#text(" into the transform.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-232962")[#strong[#text("More narrow admissible sets | Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")]

#text("[…] A reading seminar on Zhang’s Theorem 2. 2) A discussion on sieve theory, bridging the gap begin Zhang’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c4699af39d6e67f42f26e4f37f3764ee24c183deb651e3957ec0129bfcb3ca-7a803e7c9ef94a2af874c1479a84d6eda02163a89803ab17c35b84ba75194a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.L. Wisty")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233022")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Reblogged this on ")#link("http://jsandber.wordpress.com/2013/06/06/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")[#text("Pink Iguana")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233027")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("There’s a typo in ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#World_records")[#text("Polymath1 World records")]#text(": instead of 397,974 should be 387,974.")

#emph[#text("[Hmm, I can’t locate this error – maybe it has already been fixed. In any event, anyone can register to edit on the wiki. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233034")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("If you increase the number of terms in Heath-Brown’s identity upwards from 10, it looks ever more like Linnik’s identity, which asserts that ")#mi("\\frac{\\Lambda(n)}{\\log n} = \\sum_k \\frac{(-1)^k}{k} \\tau^{\\prime}_k(n)")#text(", where ")#mi("\\tau^{\\prime}_k(n)")#text(" is the number of representations ")#mi("n = n_1\\dots n_k")#text(" with each ")#mi("n_i > 1")#text(". In fact, the two identities may be proven in a very similar way by looking at Dirichlet series: for Linnik, one looks at")

#mi("\\log(\\zeta(s)) = \\sum_{k=1}^{\\infty} \\frac{(-1)^{k-1}}{k} (\\zeta(s) - 1)^k")#text(",")

#text("whereas for Heath-Brown one replaces ")#mi("\\zeta(s)")#text(" here by ")#mi("\\zeta(s) M_z(s)")#text(", where ")#mi("M_z(s) = \\sum_{n \\leq z} \\mu(n) n^{-s}")#text(". Zhang takes ")#mi("z = X^{1/10}")#text(".")

#text("One advantage of Heath-Brown over Linnik is that every term in Heath-Brown is going to be bounded by a fixed power of the divisor function (20, in fact, as in the discussion at the bottom of page 6 of Zhang). The disadvantage is that one has all those terms ")#mi("\\mu \\chi_{M_j}")#text(" that are destined for nothing more than to be triangle-inequalitied or Cauchy-Schwarzed away, but otherwise seem somewhat harmless.")

#text("I wonder whether, for the purposes of gaining a handle on what Zhang is doing, we should pretend we are working with the conceptually simpler Linnik identity, but have magically truncated it after (say) 100 terms.")

#text("I guess one starts analysing ")#mi("\\tau^{\\prime}_k(n)")#text(" by first dividing into (sub)dyadic ranges for the factors ")#mi("n_i")#text(", let’s say ")#mi("n_i \\sim N_i")#text(". The critical case for Zhang would appear to be when ")#mi("k = 3")#text(" and ")#mi("N_1 \\sim X^{3/8}, N_1 \\leq N_2 \\leq N_3")#text(". Emmanuel Kowalski mentioned this on his blog, and also mentioned the paper of Friedlander and Iwaniec on level of distribution of the ternary divisor function. I haven’t looked at all at that paper, but I wonder if anyone could say why the techniques there aren’t in fact directly applicable here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233066")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("I think I vaguely answered part of this in a couple of comments above (1:46pm June 5).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")[#text("Online reading seminar for Zhang’s “bounded gaps between primes”")]
]

#text("Note that the “main” term of Theorem 4 of FI (page 335) is the first one, and also when compared to Zhang’s 13.7, there needs to be a ")#mi("\\hat f(h/d)")#text(" term included in ")#mi("S(H,M,N)")#text(" of FI, which is of size ")#mi("N_1")#text(". In their remark on Theorem 4, FI say that one might do better with Holder than Cauchy. I am not sure, but I do not think the main term would be improved by this.")

#text("Then for comparison plug in to Theorem 4 for the values with ")#mi("M=N_3, H=d/N_1, N=N_2, q=d")#text(" comparing to a desired Zhang goal of ")#mi("x/M")#text(". I get that ")#mi("q^{3/4}H^{1/2}M^{1/2}=d^{5/4}\\sqrt{N_3/N_1}")#text(", and we want ")#mi("N_1")#text(" times this to be less than ")#mi("x/M")#text(". So when ")#mi("d\\sim x^{1/2+2\\omega}, N_i\\sim x^{5/16-4\\omega}, M\\sim x^{1/16+12\\omega}")#text(" you lose by ")#mi("x^{21\\omega/2}")#text(", which is (essentially?!) what Zhang will save from a convenient factor ")#mi("r")#text(" of ")#mi("d")#text(", that is (see 13.12) he needs ")#mi("r")#text(" to be at least the fourth power of this (he wins by ")#mi("sqrt r")#text(", and there is a Cauchy).")

#text("Via Lemma 4, we will be able to choose ")#mi("r")#text(" in a ratio-interval of size ")#mi("x^\\delta")#text(", and we need ")#mi("r\\ll x^{1/8-10\\omega}")#text(" or something to get the rest of Sect 14 to work (namely expanding the ")#mi("n_3")#text(" sum modulo ")#mi("r")#text(" and later Fourier analysis). This is where I get my ")#mi("\\omega")#text(" estimates BTW, namely to choose ")#mi("r")#text(" desirously we need vaguely ")#mi("\\delta+42\\omega\\le 1/8-(8+2)\\omega")#text(". Incidentally, I expect that ")#mi("x^{3/8+8\\omega}")#text(", which sits the borderline between Type I/III for Zhang, can be lowered to ")#mi("3/8+6\\omega")#text(", maybe ")#mi("3/8+4\\omega")#text(", which allows larger ")#mi("\\omega")#text(" to be taken. But writing down the optimal conditions will be easier when everything is spread.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233044")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("A continuation of my last post. First of all, there was a misprint: in the last paragraph I meant ")#mi("N_1 \\geq N_2 \\geq N_3")#text(".")

#text("Next, a Google search for ternary divisor problem revealed that Emmanuel Kowalski (and Fouvry and Michel) very recently (April 2013) wrote a paper")

#link("http://arxiv.org/abs/1304.3199")[#text("http://arxiv.org/abs/1304.3199")]

#text("on the distribution of ")#mi("\\tau_3(n)")#text(" in progressions. Looking at the paper, I guess these three must be seriously up on the Bombieri-Fouvry-Friedlander-Iwaniec stuff. They obtain a level of distribution for this problem of ")#mi("\\frac{1}{2} + \\frac{1}{46}")#text(", without any assumption of the modulus ")#mi("q")#text(" being well-factorable. Indeed it works for prime moduli.")

#text("This led me to re-examine my question above, namely why these techniques aren’t directly applicable here, and actually the answer is reasonably obvious I think (though please correct me): there are Type III sums coming from the terms with ")#mi("k \\geq 4")#text(" in Linnik’s formula. A particularly sensitive case would seem to be (say) ")#mi("N_4 = N^{1/16}")#text(" and ")#mi("N_1 = N_2 = N_3 = N^{5/16}")#text(". This is Type III (take ")#mi("\\alpha = \\chi_{N_4}")#text("). This actually seems to me to be a pretty good test case in which to examine Zhang’s Type III argument.")

#text("By the way, I completely agree with v08ltu that the correct way to work out the best value of ")#mi("\\varpi")#text(" is to write out each estimate in Zhang with all the parameters initially unspecified, then optimise at the end. On the other hand (for me at least) this is somehow the opposite of the right way to understand the paper on a conceptual level.")

#text("Finally, one could perhaps venture that the Fouvry-Kowalski-Michel exponent of ")#mi("1/46")#text(" is an absolute upper limit of what one can expect for ")#mi("\\varpi")#text(" (and most probably we won’t get a value this good). I guess that if things could be taken that far then, by the discussion on the other blogs, the value of ")#mi("k")#text(" would decrease by something like ")#mi("(25)^{3/2}")#text(", and hence the gap between primes by a factor of maybe ")#mi("k \\log k \\sim 150")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233161")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("It might be well to say why the sensitive case is well-poised. Here it is, from the decomposition you need 4 pieces in 2 parts, and by philosophy the sizes in a part should be the same at worst, so ")#mi("MN^3\\sim x")#text(". The FI work of Deligne bound for 13.7 returns from Cauchy ")#mi("M\\cdot\\sqrt{dN^2}\\sqrt{d^{3/2}}\\sim d^{5/4}MN")#text(" needing to beat ")#mi("x")#text(", and ")#mi("d\\sim x^{1/2}")#text(" is critical. Writing ")#mi("M=x^a,N=x^b")#text(", this is ")#mi("a+3b=1")#text(" and ")#mi("5/8+a+b\\le 1")#text(", so ")#mi("(a,b)=(1/16,5/16)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233549")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Actually, we can (currently) only handle prime moduli for the distribution of the ternary divisor, although an extension to squarefree moduli should be relatively straightforward. (The reason is that we rely on earlier work depending on different relatively fine aspects of the theory of sums over finite fields, as in my recent Cambridge seminar talk…)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233057")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Just starting to look at Section 7, which introduces the dispersion method to treat Type I/II sums. As I understand it, this part is more or less standard (similar to BFI), with the Type III analysis being the most original, but I am not so familiar with the dispersion method so I thought I would go through these sections first. But I might perhaps skip the Type II analysis which looks a tiny bit trickier than the Type I analysis.")

#text("Anyway, let’s take say a Type I component to ")#mi("\\Lambda")#text(", which takes the form ")#mi("\\gamma = \\alpha * \\beta")#text(" where ")#mi("\\alpha")#text(" is supported on some scale M that is somewhat less (but not too much less) than ")#mi("x^{1/2}")#text(", and ")#mi("\\beta")#text(" on the opposite scale ")#mi("N \\sim x/M")#text(" that is somewhat larger than ")#mi("x^{1/2}")#text(". These weights also obey some basic bounds (controlled by some power of the divisor function, and ")#mi("\\beta")#text(" also has to obey some sort of Siegel-Walfisz type theorem) but I will ignore these technicalities here. (My guess is that the ")#mi("\\alpha,\\beta")#text(" are destined to be eliminated fairly soon by Cauchy-Schwarz, so their finer structure won’t be so relevant.)")

#text("Our objective is to get a ")#mi("\\log^{-A} x")#text(" saving over the trivial bound for")

#tao-math("\\sum_d \\sum_{c \\in C_i(d)} \\left|\\Delta(\\gamma; d,c)\\right|", block: false)

#text("where ")#mi("d")#text(" is basically constrained to be a little bit larger than ")#mi("x^{1/2}")#text(" (think of ")#mi("d \\sim x^{1/2+2\\varpi}")#text("), and is also squarefree and ")#mi("x^\\delta")#text("-smooth (no prime factor larger than ")#mi("x^\\delta")#text("), and having essentially no really tiny prime factor (as a model case, let’s say no prime factor less than ")#mi("D_0 = \\exp( \\log^{1/k_0} x)")#text("). Here ")#mi("\\Delta")#text(" is the irregularity of ")#mi("\\gamma")#text(" in the residue class ")#mi("c \\text{ mod } d")#text(":")

#mi("\\Delta(\\gamma;d,c) = \\sum_{x \\leq n \\leq 2x; n = c \\text{ mod } d} \\gamma(n) - \\frac{1}{\\phi(d)} \\sum_{x \\leq n \\leq 2x} \\gamma(n)")#text(".")

#text("The first step is to factor ")#mi("d")#text(" as ")#mi("d = qr")#text(" where ")#mi("r")#text(" is now a little bit less than ")#mi("x^{1/2}")#text(" (think of something like ")#mi("x^{1/2-\\varpi/2}")#text(") which makes q something like ")#mi("x^{3\\varpi/2}")#text(", say; one can also ensure that the small factor q has no tiny prime factors. Applying the Chinese remainder theorem, it then suffices to gain a ")#mi("\\log^{-A} x")#text(" saving over the trivial bound for")

#tao-math("\\sum_r \\sum_{a \\in C_i(r)} \\sum_q \\sum_{b \\in C_i(q)} \\left|\\Delta(\\gamma;  r,a; q,b)\\right|", block: false)

#text("where ")#mi("r")#text(" ranges over squarefree numbers of size something like ")#mi("x^{1/2-\\varpi/2}")#text(", ")#mi("q")#text(" ranges over squarefree ")#mi("x^{\\delta}")#text("-smooth numbers with no tiny prime factors (and coprime to r), and ")#mi("\\Delta(\\gamma; r,a; q,b)")#text(" measures the irregularity of ")#mi("\\gamma")#text(" in the joint residue class ")#mi("a \\text{ mod } r, b \\text{ mod } q")#text(".")

#text("The rest of Section 7 is concerned with some standard-looking Cauchy-Schwarz maneuvers designed to eliminate the role of ")#mi("\\alpha")#text(", but at the cost of introducing a new factor, the sign ")#mi("c(r,a;q,b)")#text(" of ")#mi("\\Delta(\\gamma; r,a; q,b)")#text(". The sharp cutoff of ")#mi("\\alpha")#text(" to scale M is also replaced by a smoother cutoff ")#mi("f")#text(" (constructed in Lemma 7) which will have better equidistribution in arithmetic progressions (basically thanks to Poisson summation).")

#text("Sections 8-12 are then devoted to estimating the resulting sums ")#mi("S_1,S_2,S_3")#text(" that come out of this Cauchy-Schwarz. It appears that the Type I and Type II analysis is unified all the way through to Section 10, but then there is a tricky sum R_1 that needs separate treatment in the Type I and Type II cases (Sections 11 and 12 respectively). Given the standard-looking nature of the moves in the rest of Section 7, I will probably skip over this part of the paper and start reading Sections 8-12 instead (but I might skip Section 12 for now).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233071")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("One comment that might be made about the signs ")#mi("c(r,a;q,b)")#text(" (I might have called them ")#mi("\\epsilon")#text(", not ")#mi("c")#text("): you can’t get any cancellation from them, because you know nothing about them. Stare at the display above 7.7, you can only get cancellation from the inner parenthesis, which is indeed squared via Cauchy in 7.7. Similarly, you only have ")#mi("m")#text(" and ")#mi("n_1,n_2")#text(" to see cancellative effect in the ")#mi("S_i")#text(". These signs ")#mi("c")#text(" just come along for the ride, and the main terms (frequency 0 in the Fourier expansion of ")#mi("f")#text(") in the ")#mi("S_1-2S_2+S_3")#text(" expansion will all contain them and cancel out. The higher frequencies are bounded by absolute values in any event, so there they shall not matter either.")

#text("Also, one nicety (that BFI exploit too) is for each ")#mi("S_i")#text(" estimation to implore a gcd-condition on ")#mi("q_1,q_2")#text(", which wins because ")#mi("D_0")#text(" beats all logs. Same again, to say ")#mi("q/\\phi(q)\\sim 1+O(\\tau(q)/D_0)")#text(", when achieving main terms of ")#mi("S_i")#text(" to cancel exactly.")

#text("You have a typo, it should be that ")#mi("q")#text(" ranges over squarefree ")#mi("x^\\delta")#text(" smooth numbers, not ")#mi("x^\\omega")#text(".")

#text("I find Section 11 and 12 to be quite similar, the only difference is that (surprise) one uses a joint “bilinear” bound on pairs ")#mi("(q_1,q_2)")#text(" for “Type II” in 12, while in 11 for “Type I” one estimates over ")#mi("q_2")#text(" “linearly”. Both follow 9, if you can grok that, they should be easy (perhaps even repetitive). At the end of day, one uses a bound for incomplete Kloostermann sums, sometimes Lemma 11 in its full power, or sometimes just the more standard (3.13). Note that 9 has no Type I contribution, as the Fourier approximation is quite short here: ")#mi("H_2=QR/M\\ll x^{1/2+2\\omega}(N/x)=N/x^{1/2-2\\omega}")#text(", so unless ")#mi("N")#text(" is near ")#mi("x^{1/2}")#text(", this is less than 1. But 11 and 12 have larger ")#mi("H_1\\sim Q^2R")#text(" (see 10.7). Perhaps this point should be explained more when it is reached.")

#text("The hardest (and longest) part of 8-12 might be 10, which BFI split into 2 parts. Essentially you have to show that ")#mi("S_1")#text(" is on average what you want it to be so that the main terms cancel in ")#mi("S_1-2S_2+S_3")#text(", up to errors that are then estimated in 11 and 12. And Zhang has to worry about his ")#mi("C_i")#text(" structure here.")

#emph[#text("[Corrected, thanks. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233075")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Typo: I meant ")#mi("H_1\\sim Q^2R/M")#text(" in (10.7). Still, the effect of ")#mi("Q^2")#text(" rather than ")#mi("Q")#text(" is evident between these ")#mi("H")#text(" values (and 13 and 14 will see yet another specification of ")#mi("H")#text(", which is really just handed to us as the length one needs to reach infinitesimal error in the Fourier expansion, given a modulus).")

#text("Note that ")#mi("Q")#text(" will be small for Type II in any event, since ")#mi("R")#text(" (via ")#mi("N")#text(") is so close to ")#mi("\\sqrt {x}")#text(". This what in reality forces a border between these Types, namely that when ")#mi("N")#text(" is near enough to ")#mi("R")#text(" one can estimate bilinearly in ")#mi("q_1,q_2")#text(" with little loss because ")#mi("Q")#text(" is small, while otherwise when ")#mi("N")#text(" is small, the diagonal terms (see above 11.3) can be estimated trivially in the sum over the ")#mi("n")#text("-variable, because this sum is so “short” comparatively.")

#text("Also, to again complain about the nomenclature, although S9 is concerned with only “Type II” as I say, the ")#mi("q")#text("-effect is done “linearly”, that is one inner ")#mi("q")#text("-variable by itself. I guess the difference in entanglement with “linear” and “bilinear” is that in S9 and S11 Zhang has a “diagonal” ")#mi("hq^{\\prime}=h^{\\prime}q")#text(" and in S12 he has the diagonal as ")#mi("h^{\\prime}q_1q_2=hq_1^{\\prime}q_2^{\\prime}")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233086")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("The aim of these notes is to follow Sections 13 and 14 of Zhang’s paper in a particular somewhat critical case. Namely, we shall look at the estimation of the Type III sum")

#mi("\\mathbf{E}_{n \\leq X, n \\equiv c (d)} \\alpha \\ast \\psi_{N_1} \\ast \\psi_{N_2} \\ast \\psi_{N_3}")

#text("where ")#mi("\\alpha = \\psi_{N^{1/16}}")#text(" and ")#mi("N_1, N_2, N_3 \\sim X^{5/16}")#text(", and ")#mi("d \\sim X^{1/2}")#text(". Here ")#mi("\\psi_M")#text(" denotes a suitably smooth cutoff to a (sub-) dyadic interval around ")#mi("M")#text(". I’m using the additive combinatorialists’ convention of using ")#mi("\\mathbf{E}")#text(" for averaging, because I find it helps keep track of what the trivial estimate is that we’re trying to beat. I write ")#mi("\\mathbf{E}_{x(d)}")#text(" for the expectation over all ")#mi("x")#text(" mod ")#mi("d")#text(".")

#text("In this first post I will try and evaluate this without any condition on ")#mi("d")#text(". We shall see that we just fail to get a nontrivial estimate, even with the Bombieri-Birch bound. The crucial saving comes from factoring ")#mi("d = qr")#text(". I’ll try and say why that helps in the next post.")

#text("I will make all manner of unwarranted assumptions and simplifications. In particular, I will use the following “fact”: If ")#mi("P \\mod{d}")#text(" is an arithmetic progression of length ")#mi("L")#text(", and if ")#mi("f")#text(" is some function, then we have")

#tao-math("\\mathbf{E}_{n \\in P} f(n) = \\sum_{\\left|h\\right| < d/L} \\mathbf{E}_{n(d)} f(n) e(-hn).", block: false)

#text("A rigorous version of this follows from a suitable smoothing of ")#mi("P")#text(" and some Fourier analysis; I've assumed here that the ")#mi("\\mod{d}")#text(" Fourier transform of ")#mi("1_P")#text(" takes the constant value ")#mi("L/d")#text(" for ")#tao-math("\\left|h\\right| < d/L", block: false)#text(", and is zero otherwise, obviously an oversimplification of the truth. Zhang calls this a truncated Poisson summation formula, and it corresponds to his Lemma 7. I'll call it completion of sums: it's inefficient, and in fact is the main source of inefficiency in the argument.")

#text("Let's begin. The sum we're interested in is")

#mi("\\mathbf{E}_{m \\sim X^{1/16}} \\mathbf{E}_{n_2, n_3 \\sim X^{5/16}} \\mathbf{E}_{n_1 = \\overline{mn_2 n_3}c (d)} \\psi_{X^{5/16}}(n_1).")

#text("By completion of sums, we get a main term coming from ")#mi("h = 0")#text(" plus an error of")

#mi("\\sum_{0 < h < X^{3/16}} \\mathbf{E}_{m \\sim X^{1/16}} \\mathbf{E}_{n_2, n_3 \\sim X^{5/16}} e_d(\\frac{-ch}{mn_2n_3}).")

#text("We want to show that this is ")#mi("o(1)")#text(" (in fact we want to win by a small power of ")#mi("X")#text("). The completion of sums has already hurt us, because the trivial bound is ")#mi("X^{3/16}")#text(".")

#text("Thus we want")

#mi("\\mathbf{E}_{h < X^{3/16}} \\mathbf{E}_{m \\sim X^{1/16}} \\mathbf{E}_{n_2, n_3 \\sim X^{5/16}} e_d(\\frac{ch}{mn_2n_3}) = o(X^{-3/16}).")

#text("Let's delete the averaging over ")#mi("m")#text("; thus we are shooting for the stronger bound")

#mi("\\mathbf{E}_{h < X^{3/16}}  \\mathbf{E}_{n_2, n_3 \\sim X^{5/16}} e_d(\\frac{bh}{n_2n_3}) = o(X^{-3/16})")

#text("uniformly in ")#mi("b")#text(".")

#text("We'll introduce shifts over the range ")#mi("K \\sim X^{1/8}")#text("; thus it suffices to show that")

#mi("\\mathbf{E}_{k \\sim X^{1/8}}\\mathbf{E}_{h < X^{3/16}}  \\mathbf{E}_{n_2, n_3 \\sim X^{5/16}} e_d(\\frac{-bh}{(n_2 + hk)n_3}) = o(X^{-3/16}).")

#text("The key point here is that ")#mi("kh < X^{5/16}")#text(", so shifting ")#mi("n_2")#text(" to ")#mi("n_2 + kh")#text(" doesn't change much (I guess perhaps ")#mi("k")#text(" should be a tiny bit smaller; I don't think this is very important).")

#text("We're going to make the substitution ")#mi("\\ell = n_2/h \\mod{d}")#text(". Now observe that as ")#mi("n_2")#text(" ranges over ")#mi("\\sim X^{5/16}")#text(" and ")#mi("h")#text(" ranges over ")#mi("X^{3/16}")#text(" the ratio ")#mi("\\ell = n_2/h \\mod{d}")#text(" ranges over all ")#mi("\\ell \\mod{d}")#text(" pretty much uniformly. Thus we'd like to replace ")#mi("\\mathbf{E}_{n_2 \\sim X^{5/16}} \\mathbf{E}_{h < X^{3/16}}")#text(" by ")#mi("\\mathbf{E}_{\\ell \\mod{d}}")#text(". In fact this turns out to be a little bit too much of a fudge, and Zhang writes ")#mi("\\nu(\\ell)")#text(" for the number of ways in which ")#mi("\\ell = n_2/h")#text(" in this manner, then shows that the square mean of ")#mi("\\nu")#text(" is bounded. By Cauchy-Schwarz, our task is then to show that")

#tao-math("\\mathbf{E}_{\\ell (d) } \\left| \\mathbf{E}_{k \\sim X^{1/8}}  \\mathbf{E}_{n_3 \\sim X^{5/16}} e_d(\\frac{-b}{(\\ell + k)n_3}) \\right|^2 = o(X^{-3/8}).", block: false)

#text("(Is it too much to hope to remove this application of Cauchy?)")#linebreak()#text(" Expanding this out, matters reduce to showing that")

#mi("\\mathbf{E}_{\\ell (d)} \\mathbf{E}_{k, k^{\\prime} \\sim X^{1/8}} \\mathbf{E}_{n, n^{\\prime} \\sim X^{5/16}} e_d ( \\frac{b}{(\\ell + k) n} - \\frac{b}{(\\ell + k^{\\prime}) n^{\\prime}}) = o(X^{-3/8}).")

#text("One can simplify this a little to pretty much")

#mi("\\mathbf{E}_{\\ell (d)} \\mathbf{E}_{k\\sim X^{1/8}} \\mathbf{E}_{n, n^{\\prime} \\sim X^{5/16}} e_d ( \\frac{b}{\\ell n} - \\frac{b}{(\\ell + k) n^{\\prime}}) = o(X^{-3/8}),")

#text("by substituting ")#mi("\\tilde\\ell = \\ell + k")#text(" and ")#mi("\\tilde k = k^{\\prime} - k")#text(" (and then removing the tildes).")

#text("Now we take the hit of completion of sums once again, replacing the averages over ")#mi("n, n^{\\prime} \\sim X^{5/16}")#text(" with averages over all of ")#mi("n \\mod{d}")#text(" and ")#mi("n^{\\prime} \\mod{d}")#text(". This reduces things to showing that")

#mi("\\sum_{h, h^{\\prime} < X^{3/16}} \\mathbf{E}_{k \\sim X^{1/8}} \\mathbf{E}_{\\ell, n, n^{\\prime} (d)} e_d ( \\frac{b}{\\ell  n} - \\frac{b}{(\\ell + k) n^{\\prime}} + h n + h^{\\prime} n^{\\prime}) = o(X^{-3/8}).")

#text("The somewhat trivial manoeuvre of replacing the sum over ")#mi("h, h^{\\prime}")#text(" with an expectation reduces this to")

#mi("\\mathbf{E}_{h,h^{\\prime},k} \\mathbf{E}_{\\ell, n, n^{\\prime} (d)} e_d ( \\frac{b}{\\ell n} - \\frac{b}{(\\ell + k) n^{\\prime}} + h n + h^{\\prime} n^{\\prime}) = o(X^{-3/4}).")

#text("But, lo and behold, the inner average over ")#mi("\\ell, n, n^{\\prime}")#text(" was estimated by Bombieri and Birch using the full force of Deligne and it is ")#mi("d^{-3/2} \\sim X^{-3/4}")#text(". Thus the ")#mi("\\ell")#text("-adic machinery just fails to help us beat the trivial bound.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233089")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("This doesn’t render so well for me… I can try another version without strict inequality signs – or did I do something else wrong? Also, in the last display ")#mi("\\ell + k")#text(" and ")#mi("\\ell + k^{\\prime}")#text(" should be ")#mi("\\ell")#text(" and ")#mi("\\ell + k")#text(" respectively.")

#emph[#text("[Ben – I’ve cleaned up what I could; if there’s anything else to fix you can email me and I’ll deal with it. By the way, very nice writeup! -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233093")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("BTW, you should compare the proof of Theorem 4 in FI (p335), it gets the same results as you annuciated, and indeed is a bit simplified from Zhang’s setting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233097")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Another detail of 13&14: regarding the choice of ")#mi("K")#text(" (number of shifts), this is completely transponded from the error in Weyl shifts (13.14) where it is made as large as possible. In the gyrations of S14, generically the errors have ")#mi("K^2")#text(", and there is a diagonal contributant (bottom page 50 and top page 51) with only ")#mi("K")#text(" – when ")#mi("K")#text(" is as large as (13.14) allows, this diagonal part is contained sufficiently, as it is a factor ")#mi("K")#text(" less than the goal (up to smaller losses elsewhere).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233092")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("This is a fairly good rehearsal of why applying Deligne fails w/o the extra trick that will be seen later (of shifting not generically by ")#mi("hk")#text(", but by a multiple of divisor ")#mi("r")#text(" namely ")#mi("hkr")#text("). I don’t think one can avoid Cauchy. To my view in these shifts by products (which FI p333 say go back to Vinogradov, and were used close to this context by Karatsuba for Burgess) you are always going to have that. There is a (very) nice PAMS paper of FI, indeed in this similar circular of ideas, that derives Burgess (a bit beyond even) via akin techniques and again you have to digress via Cauchy/Holder, counting multiplicative solutions to a modulus.")

#link("http://www.jstor.org/stable/2159916")[#text("http://www.jstor.org/stable/2159916")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233102")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Thanks for these comments! You seem to know your way around this stuff amazingly well. I didn’t quite understand what you say about ")#mi("K")#text(", by the way – are you saying that the choice is delicate, or not? I didn’t work it through, but obviously you’ll need to take ")#mi("K")#text(" at least somewhat large to avoid the diagonal terms becoming important, the Bombieri-Birch estimate only being effective when ")#mi("k \\neq 0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233106")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("I’m just saying that there is a balance for ")#mi("K")#text(", and was trying to verbalize what that was. This parameter needs to be of some size to stop the diagonal ")#mi("k_1=k_2")#text(" from dominating (I guess this is a bit obvious a statement, but still should be made I suppose). Other than that, you can take it as large as the (congruential?) losses from Weyl shifts allow.")

#text("So there has to be room to choose ")#mi("K")#text(" large enough so as to beat any prior losses (like from ")#mi("H")#text(" in the Fourier expansion, though by the time you get to p50-51 he has been rewritten by his value ")#mi("d/N_1")#text(") when the diagonal is considered, but small enough so that the amount you lose at each shift (which is in essence ")#mi("HMN_1N_3r=dMN_3r\\sim X^{7/8}r")#text(", the last in your special case and I included ")#mi("M")#text(" multiplied throughout, so we are trying to beat ")#mi("x")#text(") does not total up.")

#text("I think Zhang just takes ")#mi("K")#text(" as large as allowed, namely ")#mi("K\\sim x^{1/8}")#text(" in your special case, subtracting off enough ")#mi("\\omega")#text(" multiples in the exponent to allow space for ")#mi("r")#text(". Then the losses from the diagonal in S14 are only (if I compute correctly) ")#mi("dMN_1\\sqrt{N_3}/sqrt(K)\\sim x^{33/32}/\\sqrt {K}")#text(" in your special case (again I included the ")#mi("M")#text("-effect throughout here). Hmm, that was a bit different than I expected, as it seems that you really do need to take ")#mi("K")#text(" a bit largish, like ")#mi("x^{1/16}")#text(", to win here (I had mentally expected something in terms of ")#mi("\\omega")#text(" multiples).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233109")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("OK, it was good for me to do that calculation, in the critical case. The fact that ")#mi("K")#text(" is not all that small changes the ")#mi("\\omega")#text(" optimization. Namely I get that we need something like ")#mi("15/16+26\\omega + 42\\omega+\\delta\\le 1")#text(", which is essentially Zhang’s value, up to middling constants. I figure we can save some multiples of ")#mi("\\omega")#text(", maybe even halve them, but the ")#mi("15/16")#text(" looks less movable (I had ")#mi("7/8")#text(" before, but now the distance to 1 should be split with ")#mi("K")#text("). So all my previous ")#mi("\\omega")#text(" guesses probably need to be cut in half or so.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233111")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Here are some further comments on Section 14 of Zhang. I may expand on this a little in due course. In my earlier post we saw a convoluted argument which, even with the application of an optimal bound coming from Deligne’s work, failed (just) to recover the trivial bound.")

#text("Recall that we had reduced our goal (of estimating a certain Type III sum – I refer the reader to the previous post for details) to proving that")

#mi("\\mathbf{E}_{\\ell (d)} \\mathbf{E}_{k\\sim X^{1/8}} \\mathbf{E}_{n, n^{\\prime} \\sim X^{5/16}} e_d ( \\frac{b}{\\ell n} - \\frac{b}{(\\ell + k) n^{\\prime}}) = o(X^{-3/8}).")

#text("Suppose now that ")#mi("d")#text(" has the specific form ")#mi("d = qr")#text(", with ")#mi("r \\sim X^{\\delta}")#text(" for some very small ")#mi("\\delta")#text(". At the expense of reducing ")#mi("X^{1/8}")#text(" by a tiny bit, we could have averaged over shifts ")#mi("kr")#text(" that are multiples of ")#mi("r")#text(" instead of over all shifts ")#mi("k")#text(" as above. Thus, it suffices to show that")

#mi("\\mathbf{E}_{\\ell (d)} \\mathbf{E}_{k\\sim X^{1/8}} \\mathbf{E}_{n, n^{\\prime} \\sim X^{5/16}} e_d ( \\frac{b}{\\ell n} - \\frac{b}{(\\ell + kr) n^{\\prime}}) = o(X^{-3/8}).")

#text("Now the idea is to write ")#mi("n = mr + s")#text(", ")#mi("n^{\\prime} = m^{\\prime} r + s^{\\prime}")#text(" with ")#mi("0 \\leq s, s^{\\prime} \\leq r")#text(" the remainders upon division by ")#mi("r")#text(". The average ")#mi("\\mathbf{E}_{n,n^{\\prime} \\sim X^{5/16}}")#text(" will be replaced by ")#mi("\\mathbf{E}_{m,m^{\\prime} \\sim X^{5/16}/r} \\mathbf{E}_{s, s^{\\prime} \\leq r}")#text(", and we shall (by the Chinese remainder theorem) replace the average ")#mi("\\mathbf{E}_{\\ell(d)}")#text(" with averages ")#mi("\\mathbf{E}_{\\ell^{\\prime}(q)}\\mathbf{E}_{\\ell^{\\prime\\prime}(r)}")#text(", where ")#mi("\\ell = \\ell^{\\prime} r + \\ell^{\\prime\\prime} q")#text(". There is then a short calculation at the bottom of page 49 of Zhang, which reveals that the expression ")#mi("e_d(\\frac{b}{\\ell n} - \\frac{b}{(\\ell + kr) n^{\\prime}})")#text(" factors as")

#mi("e_q \\big{\\left(\\frac{b}{r^2 \\ell^{\\prime} (m r + s)} - \\frac{b}{r^2 (\\ell^{\\prime} + k)(m^{\\prime} r + s^{\\prime})}   \\right)} e_r \\big{\\left( \\frac{s^{\\prime} - s}{q^2 s s^{\\prime} \\ell^{\\prime\\prime}}  \\right)} .")

#text("(or something morally equivalent to this!)")#linebreak()#text(" I shan’t write out the whole expression that comes from substituting this into what we had before. The argument henceforth is (pretty roughly) as follows: the expectation over ")#mi("\\ell^{\\prime\\prime}")#text(" is zero unless ")#mi("s = s^{\\prime}")#text(", so the expectation ")#mi("\\mathbf{E}_{\\ell^{\\prime\\prime}, s, s^{\\prime}}")#text(" gives us a factor of ")#mi("r^{-2}")#text(". (In the paper, this step is quite a bit more complicated; in particular the expectation is not over all ")#mi("\\ell^{\\prime\\prime}")#text(", but only over those ")#mi("\\ell^{\\prime\\prime}")#text(" coprime to ")#mi("r")#text(", so one has instead a Ramanujan sum. But this still has very good cancellation properties, better than square root, albeit not quite as good as the sum over all ")#mi("\\ell^{\\prime\\prime}")#text(". The elaboration of this crucial estimate deserves a further post at some point.")

#text("We compute the average over everything else more-or-less exactly as before, except that where we had ")#mi("d")#text(" before we now have ")#mi("q")#text(". Note that the incomplete sums now have shorter length ")#mi("X^{5/16}/r")#text(", but to compensate the modulus ")#mi("q")#text(" has been reduced too: it is now ")#mi("d/r")#text(". Proceeding pretty much as before, using the Bombieri-Birch bound, we pull out a factor of ")#mi("q^{-3/2}")#text(".")

#text("The upshot of this is an estimate ")#mi("q^{-3/2} r^{-2}")#text(" which, miraculously, saves the all-important factor of ")#mi("r^{-1/2}")#text(" over what went before. My guess is that somehow this is the heart of Zhang’s new argument?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233115")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("I would simply not say that ")#mi("r\\sim x^\\delta")#text(" “for some very small ")#mi("\\delta")#text("” – in fact, one whole idea is that ")#mi("r")#text(" should be as *large* as you can take it elsewhere, for indeed this is where the savings are. I might say, “where ")#mi("r")#text(" exceeds a small power and satisfies ")#mi("Kr\\le x^{1/8}")#text(" in this special testcase” – then indicate that ")#mi("K\\ge x^{1/16}")#text(" is mandated and suffices with these parameters to quell the diagonal, so there is room for ")#mi("r")#text(", if one can factor ")#mi("d=qr")#text(" with some ")#mi("x^{A\\omega} r\\ll x^{1/16-B\\omega}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233219")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("You’re right, of course. All this hopefully addressed in my latest post.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233113")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("My understanding is that for this application, the length of an incomplete sum does not matter too much. See for instance 3.13, the ")#mi("N")#text("-dependence is almost nil unless you have a large gcd. Though this is maybe this is a difference in phrasing, from what you are saying with the Fourier expansion, as the higher harmonics will dirty the error terms.")

#text("On the other hand, the FI work (also BFI) is (at least more directly) delved toward such balanced estimates, with sundry nontrivial results for choices of sizes of the sum-length and modulus.")

#text("I think the savings in Zhang, which as you say is the heart, is from the arithmetization of the ")#mi("r")#text(" factor, in that when you Weyl shift by multiples of ")#mi("r")#text(", this Ramanujan sum of size O(1) rather than ")#mi("\\sqrt{(}r)")#text(" pops out. But AFAIK, even experts are puzzling over exactly why it all works, and how it can be applied elsewhere.")

#text("To compare (I have not done it explicitly), see if you just shift by ")#mi("hk")#text(" and still try to factor ")#mi("e_d()")#text(" down to ")#mi("e_q()e_r()")#text(" as page 50 – it perhaps should work, but the ")#mi("e_r")#text(" will not be anything of speciality, so ")#mi("r^{3/2}")#text(" will arise. You would still have shorter incomplete sums, but any effect would just be lost in the roundabouts of the three ")#mi("r")#text(" sums.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233121")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Reading Section 8 now, which estimates the third (and easiest) of the three terms ")#mi("S_1,S_2,S_3")#text(" coming out of the Cauchy-Schwarz performed in Section 7. (The reason for the three terms is that the discrepancy ")#mi("\\Delta(\\gamma;r,a;q,b)")#text(" is a difference of two terms, so when you square it you get three terms.) More precisely, we seek a good bound on")

#mi("\\sum_r \\sum_{a \\in C_i(r)} (S_1-2S_2+S_3)(r,a)")#text(" (*)")

#text("where “good bound” means “gains at least ")#mi("\\log^{-A} x")#text(" over the trivial bound”, ")#mi("r")#text(" ranges over squarefree numbers in a scale ")#mi("R")#text(" a bit less than ")#mi("x^{1/2}")#text(", and ")#mi("S_1,S_2,S_3(r,a)")#text(" are certain complicated sums. However for all three sums one expects an approximation of the form")

#mi("S_i(r,a) \\approx \\hat f(0) X(r,a)")#text(" (**)")

#text("for i=1,2,3, where ")#mi("X(r,a)")#text(" is a certain expression that comes from approximately performing the ")#mi("m")#text(" summation (this is the variable that ")#mi("\\alpha")#text(" used before it was killed by Cauchy-Schwarz). The approximation (**) can be established in a pointwise sense for the easier sums ")#mi("S_2(r,a), S_3(r,a)")#text(" but only in an average sense for the more difficult sum ")#mi("S_1(r,a)")#text(", but this is all still good enough to get a good bound for (*) which is good enough to control Type I/II sums. It seems that the precise value of ")#mi("X(r,a)")#text(" is not going to be important as it will cancel itself out when we get to ")#mi("S_1-2S_2+S_3")#text(". (I suspect that by making sure that ")#mi("\\beta")#text(" has at least one factor of ")#mi("\\mu")#text(" in its Dirichlet convolution, one could in fact ensure that ")#mi("X(r,a)")#text(" was very small, that the second term in ")#mi("\\Delta(r,a;q,b)")#text(" was negligible, and that one could skip over the S_3,S_2 analysis and jump straight to S_1, but this would be a relatively minor simplification.)")

#strike[#text("Section 7")]#text(" Section 8 is devoted to establishing (**) for S_3, which is the easiest expression as one does not have congruence conditions such as ")#mi("nm = a(r)")#text(" or ")#mi("nm=b(q)")#text(" here. ")#mi("S_3(r,a)")#text(" is the quantity")

#mi("\\sum_{q_1,q_2} \\sum_{b_1 \\in C_i(q_1), b_2 \\in C_i(q_2)} \\frac{c(r,a;q_1,b_1) c(r,a;q_2,b_2)}{\\phi(q_1 r) \\phi(q_2 r)}")

#mi("\\times \\sum_{n_1,n_2} \\beta(n_1) \\beta(n_2) \\sum_{m: (m,q_1q_2 r)=1} f(m)")

#text("where")

#text("* ")#mi("q_1,q_2")#text(" are squarefree, coprime to mr, ")#mi("x^\\varpi")#text("-smooth, have no tiny prime factors, and range over a scale that is something like ")#mi("x^{2\\varpi}")#text(",")

#text("* ")#mi("n_1,n_2")#text(" are coprime to ")#mi("q_1r, q_2r")#text(" respectively;")

#text("* ")#mi("f")#text(" is a smooth localisation to a scale M somewhat less than ")#mi("x^{1/2}")#text(", thus ")#mi("m")#text(" is also localised to this scale;")

#text("* ")#mi("c(r,a;q,b)")#text(" are quantities that are bounded but otherwise uncontrolled,")

#text("* ")#mi("\\beta")#text(" is controlled by some power of the divisor function and obeys Siegel-Walfisz type estimates.")

#text("From Poisson summation the innermost sum is very well controlled, basically")

#mi("\\sum_{m: (m,q_1q_2 r)=1} f(m) \\approx \\frac{\\varphi(q_1q_2r)}{q_1q_2 r} \\hat f(0)")#text(".")

#text("Applying this approximation we get the desired representation (**) (with ")#mi("X(r,a)")#text(" defined to basically be all the mess that remains after applying this approximation and factoring out ")#mi("\\hat f(0)")#text(".)")

#text("I will probably skip Section 9 (which treats the cross term S_2) and plunge straight into Section 10, which tackles the S_3 term which is the heart of the Type I/II analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233124")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("For your first bullet point, I think ")#mi("q_1,q_2")#text(" can be as large as ")#mi("d^{1/2+2\\omega}/R\\approx d^{1/2+3\\omega}/N")#text(" and ")#mi("N")#text(" can be as small as ")#mi("x^{3/8+8\\omega}")#text(". So they can actually be of some size (and indeed this reasons why Type I has a lower limit on ")#mi("N")#text(").")

#text("Zhang is terse on the Mobius inversion to get 8.2 (as are BFI), but you spin out the gcd condition as ")#mi("\\sum_{e|\\gcd}\\mu(e)")#text(", swap variables, clip any large ")#mi("e")#text(" ahead of time and apply Lemma 7 to the resulting progressions which thus have an extra multiplier of ")#mi("e")#text(" on the free variable. Standard perhaps, but can be quizzical if never seen. BFI do explain a bit more something vaguely similar (but much more complicated) near the bottom of p240.")

#text("You also seem to have renumbered Zhang’s sections.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233137")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("János Pintz increased Zhang’s ")#mi("\\varpi")#text(", see ")#link("http://arxiv.org/abs/1306.1497")[#text("http://arxiv.org/abs/1306.1497")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233191")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("It looks as though Pintz has gone through Zhang’s argument and worked out a better (possibly optimal) exponent ")#mi("\\varpi")#text(": he seems to get the value ")#mi("\\varpi = 1/488")#text(". I guess this will be a useful check for our reading seminar once we get to the point where we fully understand the interdependence of parameters. It seems to me as though Pintz is unaware of the work on the other blog at the GPY ends of things, because his arguments are not so optimised there (so far as I can tell).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233202")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("More generally it looks like Pintz shows we can take any ")#mi("\\varpi,\\delta")#text(" satisfying ")#mi("119\\varpi+19\\delta<\\frac14")#text(". He then chooses ")#mi("\\delta=\\frac{3\\varpi}{19}")#text(", giving the specific value of ")#mi("\\varpi")#text(". I don't see why he made that choice for ")#mi("\\delta")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233268")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("On the other page, I computed that ")#mi("(\\omega,\\delta,k_0)=(1/538,1/23044,10719)")#text(" works, and that this ")#mi("\\omega")#text(" minimizes ")#mi("k_0")#text(" (at least locally). One simply has ")#mi("\\delta")#text(" determined by the constraint ")#mi("119\\omega+19\\delta=1/4")#text(", as this Type I/III barrier dominates the analysis (in fact, I find Zhang has an error or two in Type II statements, but these do not bother the Pintz analysis as far as I can see). From the critical case analysis I (now) do get the same 1/16 in 2.39 as Pintz, and I trust that he has counted/optimized ")#mi("\\omega")#text(" multiples correctly. One annoyance is that “Q” and “R” are parameters that are re-used in 7-12 and 13&14, but are different in the two parts (as you split ")#mi("d")#text(" differently).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233218")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("(Edited)")#linebreak()#text(" This is the third of my postings on Zhang’s treatment of the Type III sums in Sections 13 and 14 of his papers. I’m now going to sketch out the argument with a more general choice of parameters, rather than simply in a model critical case as before. Thus we’ll consider now the problem of estimating")

#mi("\\mathbf{E}_{n \\equiv c(d)} \\alpha \\ast \\psi_{N_1} \\ast \\psi_{N_2} \\ast \\psi_{N_3} (n),")

#text("where ")#mi("\\alpha")#text(" is supported on the subdyadic range ")#mi("\\sim M")#text(" and ")#mi("M \\sim X^{\\mu}")#text(", ")#mi("N_1 \\sim X^{\\nu_1}")#text(", ")#mi("N_2 \\sim X^{\\nu_2}")#text(", ")#mi("N_3 \\sim X^{\\nu_3}")#text(", ")#mi("\\nu_3 \\leq \\nu_2 \\leq \\nu_1 \\leq \\frac{1}{2}")#text(", and ")#mi("d \\sim X^{1/2 + 2\\varpi}")#text(". Here, ")#mi("\\varpi")#text(" is the quantity we’re really interested in, and we’d like to take it as large as possible. On a first run through the calculation, detailed below, I get the constraint")

#mi("16 \\varpi \\leq 4 \\nu_1 + 4 \\nu_2 + 5 \\nu_3 - 4 - \\delta.")

#text("Here, ")#mi("\\delta")#text(" is the parameter used in the smoothed truncation of the GPY sieve, thus ")#mi("d")#text(" is comprised only of prime factors less than ")#mi("X^{\\delta}")#text(". This is going to give flexibility in factoring ")#mi("d")#text(" as ")#mi("qr")#text(" later on.")

#text("There are a couple of possible sources of error here: first my arithmetic could be dodgy, though this should be easily ironed out. Secondly, it’s possible I’ve overlooked some important feature of the argument that places some nontrivial further constraint. Hopefully other readers of this blog can flag up any likely issues in this regard.")

#text("I’m broadly following the lines of my earlier pair of posts, so will be a little brief with explanations here.")

#text("The quantity to be estimated is")

#mi("\\mathbf{E}_{m \\sim X^{\\mu}} \\alpha(m) \\mathbf{E}_{n_2 \\sim X^{\\nu_2}} \\mathbf{E}_{n_3 \\sim X^{\\nu_3}} \\mathbf{E}_{n_1 \\equiv \\overline{m n_2 n_3} c (d)} \\psi_{X^{\\nu_1}}(n_1).")

#text("Completing sums and taking out the main term with ")#mi("h = 0")#text(", the task is then to show that")

#mi("\\mathbf{E}_{0 \\leq h \\leq X^{1/2 + 2\\varpi - \\nu_1}} \\mathbf{E}_{n_2 \\sim X^{\\nu_2}} \\mathbf{E}_{n_3 \\sim X^{\\nu_3}} e_d (\\frac{bh}{n_2 n_3}) = o(X^{\\nu_1 - \\frac{1}{2} - 2\\varpi}).")

#text("uniformly in ")#mi("b")#text(". I also took out the sum over ")#mi("m")#text(", by the way, which serves no further purpose in proceedings.")

#text("Now we introduce a shift. Later on we’re going to factor ")#mi("d = qr")#text(", with ")#mi("r \\sim X^{\\rho}")#text(". We average over shifts of ")#mi("n_2")#text(" by ")#mi("khr")#text(", for ")#mi("K \\leq X^{\\kappa}")#text(". Thus the preceding is replaced by")

#mi("\\mathbf{E}_{k \\sim X^{\\kappa}} \\mathbf{E}_{0 \\leq h \\leq X^{1/2 + 2\\varpi - \\nu_1}} \\mathbf{E}_{n_2 \\sim X^{\\nu_2}} \\mathbf{E}_{n_3 \\sim X^{\\nu_3}} e_d (\\frac{bh}{ (n_2 + khr) n_3}) = o(X^{\\nu_1 - \\frac{1}{2} - 2\\varpi}).")

#text("Now this is only permissible if ")#mi("khr \\leq X^{\\nu_2}")#text(", and this gives us our first key constraint, which I’ll call (1):")

#mi("\\kappa \\leq \\nu_1 + \\nu_2 - 2\\varpi - \\rho - \\frac{1}{2}.")

#text("Later on, ")#mi("\\kappa")#text(" will also be required to satisfy a lower bound (so that a certain diagonal contribution is negligible) and this will ultimately put a strain on how big ")#mi("\\rho")#text(" can be.")

#text("Now as ")#mi("n_2")#text(" varies over ")#mi("\\sim X^{\\nu_2}")#text(" and ")#mi("h")#text(" varies over ")#mi("\\sim X^{\\frac{1}{2} + 2\\varpi - \\nu_1}")#text(", ")#mi("n_2/h")#text(" varies over ")#mi("\\sim X^{\\frac{1}{2} + 2\\varpi + \\nu_2 - \\nu_1}")#text(" values of ")#mi("\\ell")#text(" modulo ")#mi("d")#text(". Write ")#mi("v(\\ell)")#text(" for the number of representations of ")#mi("\\ell")#text(" in this form; thus ")#mi("\\nu(\\ell)")#text(" is roughly ")#mi("1")#text(" for ")#mi("\\sim X^{\\frac{1}{2} + 2\\varpi + \\nu_2 - \\nu_1}")#text(" values of ")#mi("\\ell")#text(", and zero otherwise. The estimate we now want is")

#mi("X^{\\nu_1 - \\nu_2} \\mathbf{E}_{\\ell (d)} v(\\ell) \\mathbf{E}_{k \\sim X^{\\kappa}} \\mathbf{E}_{n_2 \\sim X^{\\nu_2}} \\mathbf{E}_{n_3 \\sim X^{\\nu_3}} e_d (\\frac{b}{(\\ell + kr) n_3} ) = o(X^{\\nu_1 - \\frac{1}{2} - 2\\varpi}).")

#text("(The weight ")#mi("X^{\\nu_1 - \\nu_2}")#text(" has been included because we are now taking expectations over all of mod ")#mi("d")#text("; this was the error in the previous version).")

#text("Applying Cauchy in ")#mi("\\ell")#text(", and using the estimate (coming from the remarks above)")

#mi("\\mathbf{E}_{\\ell(d)} \\nu(\\ell)^2 \\sim X^{\\nu_2 - \\nu_1},")#text(" we see that the task is reduced to showing that")

#tao-math("\\mathbf{E}_{\\ell(d)} \\left| \\mathbf{E}_{k \\sim X^{\\kappa}} \\mathbf{E}_{n_3 \\sim X^{\\nu_3}} e_d ( \\frac{b}{(\\ell + kr) n_3} ) \\right|^2 = o(X^{\\nu_1 + \\nu_2 - 1 - 4\\varpi}).", block: false)

#text("Expanding out the square, this is")

#mi("\\mathbf{E}_{\\ell(d)} \\mathbf{E}_{k, k^{\\prime} \\sim X^{\\kappa}} \\mathbf{E}_{n, n^{\\prime} \\sim X^{\\nu_3}} e_d (\\frac{b}{\\ell n} - \\frac{b}{(\\ell + (k - k^{\\prime})r) n^{\\prime}} ) = o(X^{\\nu_1 + \\nu_2 - 1 - 4\\varpi}).")

#text("Now (and this is a point I glossed over without proper comment in my previous posts) we need to remove the diagonal contribution ")#mi("k = k^{\\prime}")#text(", because the Bombieri-Birch bound does not give as much cancellation in that case. As I’ve written things in this rough workthrough, the contribution from ")#mi("k = k^{\\prime}")#text(" is")

#mi("X^{-\\kappa} \\mathbf{E}_{n, n^{\\prime} \\sim X^{\\nu_3}} \\mathbf{E}_{\\ell(d)} e_d (\\overline{\\ell} (\\frac{b}{n} - \\frac{b}{n^{\\prime}})).")#linebreak()#text(" The inner expectation will be zero unless ")#mi("n = n^{\\prime}")#text(", in which case it’s 1, so we get an estimate of ")#mi("X^{-\\kappa - \\nu_3}")#text(" for this diagonal term. In a rigorous writeup (such as Zhang’s!) this step is more complicated and one must estimate a Ramanujan sum, but I think the constraint is pretty much the same.")

#text("Comparing this with our aims, we see that in order for this diagonal contribution not to ruin our hopes we must have")

#mi("\\kappa  \\geq 1 - \\nu_1 - \\nu_2 - \\nu_3 + 4\\varpi.")

#text("We now have upper and lower bounds for ")#mi("\\kappa")#text(", but for the argument to work there must be some legal choice for ")#mi("\\kappa")#text(". Thus, comparing with constraint (1), we see that")

#mi("1 -\\nu_1 - \\nu_2 - \\nu_3 + 4\\varpi \\leq \\nu_1 + \\nu_2 - 2\\varpi - \\rho - \\frac{1}{2},")#text(" which tells us that")

#mi("\\rho \\leq 2\\nu_1 + 2\\nu_2 + \\nu_3 - 6\\varpi - \\frac{3}{2}.")

#text("I’ll call this constraint (2). Note that in the model case discussed before, namely ")#mi("\\mu = \\frac{1}{16}")#text(" and ")#mi("\\nu_1 = \\nu_2 = \\nu_3 = \\frac{5}{16}")#text(" and ")#mi("\\varpi = 0")#text(", we didn’t see this issue; ")#mi("\\kappa")#text(" could have been chosen to be anything in the range ")#mi("\\frac{1}{16} \\leq \\kappa \\leq \\frac{1}{8} - \\rho")#text(".")

#text("Let’s suppose from now on that constraint (2) is satisfied, and that we have chosen an appropriate value of ")#mi("\\kappa")#text(" (it doesn’t matter which). Thus our task now is to show")

#mi("\\mathbf{E}_{\\ell(d)} \\mathbf{E}_{k \\sim X^{\\kappa}, k \\neq 0} \\mathbf{E}_{n, n^{\\prime} \\sim X^{\\nu_3}} e_d (\\frac{b}{\\ell n} - \\frac{b}{(\\ell + k r) n^{\\prime}} ) = o(X^{\\nu_1 + \\nu_2 - 1 - 4\\varpi}).")

#text("Now we complete sums again to replace the averages over ")#mi("n,n^{\\prime}")#text(" by averages over all ")#mi("n,n^{\\prime} \\mod{d}")#text(", and must prove")

#mi("\\sum_{h, h^{\\prime} \\leq X^{\\frac{1}{2} + \\varpi - \\nu_3}} \\mathbf{E}_{\\ell(d)} \\mathbf{E}_{k \\sim X^{\\kappa}, k \\neq 0} \\mathbf{E}_{n, n^{\\prime} (d)} e_d (\\frac{b}{\\ell n} - \\frac{b}{(\\ell + k r) n^{\\prime}} ) = o(X^{\\nu_1 + \\nu_2 - 1 - 4\\varpi}),")

#text("thus")#linebreak()#text(" ")#mi("\\mathbf{E}_{h, h^{\\prime} \\leq X^{\\frac{1}{2} + 2\\varpi - \\nu_3}}  \\mathbf{E}_{k \\sim X^{\\kappa}, k \\neq 0} \\mathbf{E}_{n, n^{\\prime} ,\\ell(d)} e_d (\\frac{b}{\\ell n} - \\frac{b}{(\\ell + k r) n^{\\prime}} ) = o(X^{\\nu_1 + \\nu_2 + 2\\nu_3 - 2 - 8\\varpi}).")

#text("The inner sum is ")#mi("\\ll d^{-3/2}")#text(" by Bombieri-Birch (BB) but, as we saw before, this does not give a nontrivial estimate. To get one, employ Zhang’s trick of writing ")#mi("d = qr")#text(" and factoring")

#mi("e_d(BB) = e_q(BB) e_r(Ramanujan).")#text(" The estimate is now the crucially stronger ")#mi("q^{-3/2} r^{-2} = d^{-3/2} r^{-1/2}")#text(", which is ")#mi("\\sim X^{-\\frac{3}{4} - 3\\varpi - \\frac{1}{2}\\rho}")#text(".")

#text("Comparing this with our aim, we see that victory may be declared if")

#mi("\\frac{1}{2}\\rho \\geq \\frac{5}{4} + 5\\varpi - 2\\nu_1 - 2\\nu_2 - 4\\nu_3.")

#text("Finally, we compare this with constraint (2), which gave an upper bound on ")#mi("\\rho")#text(" of")

#mi("\\rho \\leq 2\\nu_1 +2\\nu_2+ \\nu_3 - 6\\varpi - \\frac{3}{2}.")

#text("Now we are assuming that ")#mi("d")#text(" is comprised of primes less than ")#mi("X^{\\delta}")#text(", so we are free to choose ")#mi("\\rho")#text(" in any range of length at least ")#mi("\\delta")#text(". Thus in order for there to be room for us to be able to factor ")#mi("d = qr")#text(" with ")#mi("r \\sim X^{\\rho}")#text(" being of an appropriate size we need")

#mi("2\\nu_1 + 2\\nu_2 + \\nu_3 - 6\\varpi - \\frac{3}{2} \\geq 2 ( \\frac{5}{4} + 5\\varpi - 2\\nu_1 - 2 \\nu_2 - 4\\nu_3) + \\delta,")

#text("which gives")

#mi("16 \\varpi \\leq 4\\nu_1 + 4\\nu_2 + 5\\nu_3 - 4 - \\delta.")

#text("We remark that under the constraints ")#mi("\\nu_1 \\geq \\nu_2 \\geq \\nu_3")#text(" and ")#mi("\\nu_2 + \\nu_3 \\geq \\frac{5}{8}")#text(" the right hand side is at least ")#mi("\\frac{1}{16}")#text(". Equality occurs when ")#mi("\\nu_1 = \\nu_2 = \\nu_3 = \\frac{5}{16}")#text(". This appears to set an upper limit of ")#mi("\\frac{1}{256}")#text(" for what we can hope for, but more stringent upper bounds may be required in the Type I and II analyses. I am told by v08ltu that the condition ")#mi("\\nu_2 + \\nu_3 \\geq \\frac{5}{8}")#text(" needs to be weakened still further, to ")#mi("\\nu_2 + \\nu_3 \\geq \\frac{5}{8} - C\\varpi")#text(", to accommodate the limits of the Type I/II analysis; this will weaken the bound still further.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233274")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("First statement: you say ")#mi("d\\sim x^{1/2+\\omega}")#text(", but I think our rendition is that ")#mi("d\\sim x^{1/2+2\\omega}")#text(". Multiply by 2 throughout.")

#text("“Comparing this with our aim we see victory may be declared”: I think you mulitplied the ")#mi("\\nu_1,\\nu_2,\\nu_3")#text(" by 2, but not the other parts (possibly thinking of ")#mi("\\rho/2")#text(")? I just get")#linebreak()#text(" ")#mi("rho/2\\ge 5/4 + 5\\omega/2 -  \\nu_1 - \\nu_2 - 2\\nu_3")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233277")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("OK, now I see, the next big displays make the same typographical error then rectify it. In the “appropriate size we need” display the RHS ")#mi("\\nu_i")#text(" inside parenthesis should be divided by 2, but in the very next line you get the math correct I think.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233283")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("You have not stated the final constraints in most precision. It is not just ")#mi("\\nu_2+\\nu_3 \\ge 5/8")#text(", but ")#mi("5/8-8\\omega")#text(" (in current form). A worst case of ")#mi("\\nu_i=5/16-4\\omega")#text(" might be closer to valid, though as I say, you have multiplied ")#mi("\\omega")#text(" by 2 from its definition. And the Type I/III barrier will be optimized itself, not being ")#mi("8\\omega")#text(" but ")#mi("(11\\omega+3\\delta)/2")#text(" in Pintz.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233315")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("In the other thread (about optimizing ")#mi("k_0")#text("), I noted that Pintz appears to have made a math error, which I detected when trying to reconcile your estimates (which I determined matched what he wrote in 2.30 and 2.35, but then he screws up in 2.39). I am getting ")#mi("1/4\\ge 207\\omega+43\\delta")#text(" after correcting his work, and indeed get the same from your estimates with the Pintz choice (optimal I think) of the Type I/III split. Plug in ")#mi("\\nu_i=5/16-11\\omega/4")#text(" into your final bound, multiply ")#mi("\\omega")#text(" by 2 for the right normalization, and get ")#mi("16\\omega\\ge 13(5/16-11\\omega/4-3\\delta/4)-4-\\delta")#text(", or ")#mi("207\\omega+43\\delta\\le 1/4")#text(". It remains to see that Pintz is correct about Type I/III splitting, which is the top line of page 4, coming from Section 11.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233322")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Thanks for these – corrected ")#mi("\\varpi")#text(" to ")#mi("2\\varpi")#text(" throughout.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233401")[#strong[#text("Bound on prime gaps bound decreasing by leaps and bounds | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")]

#text("[…] Interested followers should take a look at an online reading seminar conducted by Terry Tao which is going through the original paper. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of List of Misconceptions and Prime Gap Checkin | Pink Iguana")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233412")[#strong[#text("List of Misconceptions and Prime Gap Checkin | Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("[…] Interested followers should take a look at an online reading seminar conducted by Terry Tao which is going through the original paper. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233414")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Maybe I should make the point that a lot of features of the Type I analysis will be very familiar to people who have worked with the method of bilinear forms, or in other areas such additive combinatorics where one has an expression such as ")#mi("\\mathbf{E}_{x \\in X, y \\in Y} f(x) g(y) \\psi(x,y)")#text(" with the functions ")#mi("f")#text(" and ")#mi("g")#text(" unknown. Two applications of Cauchy-Schwarz will destroy them, leaving a quantity like")

#mi("\\mathbf{E}_{x, x^{\\prime} \\in X, y, y^{\\prime} \\in Y} \\psi(x,y) \\psi(x^{\\prime},y) \\psi(x,y^{\\prime}) \\psi(x^{\\prime}, y^{\\prime})")#text(".")

#text("The argument above was like this, but with an intermediate step of Fourier expanding a cutoff ")#mi("1_{m \\equiv c \\mod{d}}")#text(" before the second Cauchy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I’ve started a section on the wiki on Errata at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#Errata")[#text("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#Errata")]

#text("v08ltu, I was unable to see the issue in (9.9) of Zhang you reported. Could you elaborate on why the ")#mi("x^{-3\\varpi}")#text(" factor there should be ")#mi("N^{-3\\varpi}")#text(" instead? Also, if you have found any other errata for Zhang’s paper it could be useful to state them explicitly there (or as a comment here), even if they end up having no significant impact on the final bounds.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233458")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Ok, I am wrong, I rewrote the definition in (7.2) wrong (I thought the ")#mi("x^{-3\\omega}")#text(" parameter was ")#mi("N^{-3\\omega}")#text(", it made more sense to write it in terms of ")#mi("N")#text(" rather than ")#mi("x")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233427")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("(Edited version of an earlier post, now deleted, clarifying a few points.) In this post I’m going to examine the Type I case. Combining this with our previous analysis of the Type III case, we shall see what happens at the border between these two cases, which seems to be critical in determining the efficiency of Zhang’s argument. In particular I believe I can confirm the analysis of v08ltu, who showed that Zhang’s argument in fact leads to the constraint The point of this very lengthy post, in addition to trying to demonstrate this bound, is to explain the analysis of the Type I case. Thus I’m going to examine how to get bounds on where is supported on a dyadic interval and is supported near . Here, is the set of residue classes mod at which the polynomial vanishes. Our conclusion will be that the Type I analysis works if and if . Remember that the parameter is coming from the assumed smoothness of : is comprised only of primes less than . Thus we see that the analysis is effective (for some , and if is sufficiently small) provided that lies in the open interval . To deal with the case of very small (and in particular ) we need the Type II analysis. I plan to post on this soon, but I do not expect it to be a quantitative bottleneck in the argument. To deal with we need the Type III analysis, which seems to be the major new input of Zhang’s work. Let’s get down to business. The above expression is already not quite what Zhang looks at, because from our term he subtracts a term inside the modulus signs. As Terry has been remarking in his study of this Type I situation, taking account of these terms basically takes up Sections 8 and 9 of Zhang’s paper. In fact, because Zhang looks at the average of the square , one ends up having to analyse terms with , and . In the notation of his paper, these correspond to the sums and respectively on page 28. As Terry notes, it seems as though the business end of proceedings is the analysis of , and indeed a glance at the relative lengths of/seriousness of input to the corresponding sections would seem to back this up. Thus, following Terry’s lead, I’m going to completely ignore and proceed straight to Section 10 of Zhang’s paper. Set and . Now Zhang cannot say anything about the average itself. He must restrict only to those that are nicely factorable as with and in some favoured ranges. I’m going to suppose that this can be done with and , where is a quantity to be specified later. For the benefit of anyone reading through this, let me say that if we assume then we shall take . A factorisation like this also appeared in the analysis of the Type III method. Emmanuel Kowalski made the nice remark that the factorisation appears to be a technical trick (albeit a completely crucial one) in the analysis of the Type III sums, but is absolutely intrinsic to the analysis of the Type I sums. We will see this now. What we need to estimate, then, is The averages over and are rather minor, being of essentially bounded size, so I’m going to delete them in the ensuing discussion and just assume that and are fixed. It is important (perhaps this is the only thing that is important in this regard) that (by the Chinese remainder theorem). (A very minor issue is that it seems lexicographically eccentric that Zhang pairs with and with , but I don’t want to deviate from broadly following the notation of his paper here). Now we begin properly. Let me warn the reader that, even with many simplifying cheats, things are going to get a bit horrific: quite a bit worse than the analysis of the Type III sums. This really is unavoidable. Thus we look at We want to show that this is (in fact we want to win by a small power of ). Opening up the convolution, this is where here is just some sign. We shan’t be able to say anything useful about it (there was a discussion between Terry and v08ltu about this) and it is destined only to be annihilated by Cauchy. Was it valid to invert modulo and ? We simply won’t care about this kind of issue and many others like it, which add a lot of additional complexity to Zhang’s paper but do not affect the substance. Now we Cauchy to eliminate , reducing our task to Expand out the square, and ditch the averaging over . This reduces things to showing that for all . Call this expression (1). Here I wrote mod for the solution to the congruences . Note that the signs also depend on but we have now supressed this. I should say at this point that pages 34, 35 and the first half of page 36 of Zhang are devoted to showing that we can basically neglect the contribution from everything in which have a common factor; I’m going to completely ignore this point, hoping that it isn’t the point at which serious constraints are placed on the analysis (I think this is right). In the preceding expression, I want to draw attention to the fact that in the crucial range of parameters we’ll have , so typically the inside expectation over is empty. Otherwise, the analysis would actually be quite easy (and somehow this is one of the main points of why sieve theory is difficult: if then the number of with is either 0 or 1, but it’s hard to know which). Somewhat schematically, we have the Fourier expansion Call this expression (2). Here, and so , and for the argument to work we need this to be positive. This Fourier expansion is an important step (it’s the first place one sees a hint of things that may lead to Kloosterman sums) so I’ll elaborate a bit. Those wanting to get to the point can skip this section. Writing mod for the solution to the congruences , we detect by orthogonality. Taking expectations over , the left hand side of (2) can then be expressed as But the inner expecation is the Fourier transform mod of the dyadic range , and roughly speaking it is for and zero else. This is an oversimplification, of course, and also the dyadic range will need to be smoothed appropriately. Details are in Zhang’s Lemma 7; this is basically the same thing as the “completion of sums” I talked about in the Type III analysis. Finally I factored as a product ; for the routine details see Zhang, top of page 38. Now let’s return to the main line of argument. We combine expressions (1) and (2) above to see that our task is reduced to showing that Note that the trivial bound is now only , not ; we’ve seen this issue that completion of sums can hurt before, in the analysis of the Type III sums. The term with is a kind of main term, which (as it turns out) cancels out with other similar terms coming from the analysis of and , a part of Zhang’s argument that we’re glossing over. Thus we’ll assume from now on that . Make ths substitutions and and replace by the average . This is only permissible if , which imposes the constraint This trumps our earlier constraint coming from the requirement than be positive, so we may now forget that constraint. Then delete the average over , reducing our task to showing that Now we know that we’re going to have to Cauchy away the unknown coefficients as some point. Taking a deep breath, by Cauchy with the variables on the “outside” and on the “inside” this reduces matters to Call this expression (3). The case is singular here, and it is this feature which makes the analysis ineffective in the limit as and necessitates the Type II analysis. The number of solutions to with and is bounded by . Thus we can estimate the contribution from these singular terms by essentially . For this to be a win, we thus need . Since , this implies the constraint . This shows why the analysis breaks down as (the Type I/II border), but this constraint is irrelevant for the Type I/III border. Assume henceforth that we have successfully despatched this singular case. Then our inner expectation has the form where and , and . This is, I believe, a fairly standard type of sum and it is estimated using completion techniques and the Weil estimates for Kloosterman sums. This is Lemma 11 of Zhang and I shall write a short post on it presently, in the simplified language used so far in these posts. Anyhow, the bound obtained is . Finally the whole of expression (3) is bounded by times this, that is to say by . Hence we win if . Call this (A). This condition is, of course, least damaging when is taken as small as possible. Our constraint on is that . Clearly we should try and take . Remember, however, that we cannot necessarily factor with having exactly any desired size: we are assuming that the divisors of are smooth. However we can take some . Constraint (A) now becomes . Call this (B). Finally, let’s use this to confirm v08ltu’s constraint on and coming from the Type I/III border. Here will be in the vicinity of . Recall that the Type III estimate was (Here, we were looking at averages over progressions of some , with supported on the dyadic range and .) I think the worst situation is when Then we have a choice whether to use Type III or Type I. If we use Type III we obtain the bound Alternatively, we could use Type I (with and ) with parameter . then we obtain the bound The worst case is when these bounds are equal, which appear to confirm the constraint found by v08ltu.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233465")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("It is correct the ")#mi("q_1,q_2")#text(" with a nontrivial gcd contribute nothing, due to his imposition that they have no prime factors smaller than ")#mi("e^{(\\log x)^{1/k}}")#text(" beating all logs. Compare S6 of BFI. However, I think 34-36 with this estimation, are the only places where he uses the multiplicative structure of his residue system.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233473")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Another point is that the estimates in S10 are where the Siegel-Walfisz bound A2 is used. This is used to show that the principal terms (")#mi("h=0")#text(") asymptote the same (it is here where small moduli matter). BFI calls this a Barban-Davenport-Halberstam theorem, and split Zhang 10 into S6&7, which is perhaps easier to digest (the borderline being about 10.11 of Zhang).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233478")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Interesting points, both of these. I’ll try and edit my posts to mention them in due course. I have to say I’d been complete ignoring the SW condition on my first reading.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233487")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("There is a discussion of dispersion (I actually found this link from an earlier 2012(?) post on this blog) at the Encyclopedia of Math.")#linebreak()#text(" ")#link("http://www.encyclopediaofmath.org/index.php/Dispersion_method")[#text("http://www.encyclopediaofmath.org/index.php/Dispersion_method")]

#emph[#text("[An informative link, thanks! (I may not have read that link in full when I encountered it last, or maybe it was not as well developed as it is now. I’ve added the link to the wiki. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233490")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I spotted this during a recent Google search. It’s not incredibly easy to see how it sheds light on the present situation, I have to say, except for the formal similarity with the sum ")#mi("\\Sigma_1 - 2\\Sigma_2 + \\Sigma_3")#text(" and some notion that setting up multiplicative convolutions and hence bilinear forms is a good thing. But I would be interested to learn more about the dispersion method in general.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233491")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("One rationale for why you never have to worry about whether it was “valid” to invert ")#mi("m")#text(" modulo whatever, is that I guess you get a gcd condition when it is not (in Lemma 11), but these are “small” gcds compared to the “singular” ")#mi("hq^{\\prime}-h^{\\prime}q")#text(" contribution (which is a gcd with 0, as it were). Zhang’s phrase in S11 (after 11.5) is “a much sharper bound for the second term … can be obtained”, and similarly with 9.11-9.15 and 12.5-12.6 the same is true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233437")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("For the errata: in Zhang’s paper equation (12.3) has a the divisor function to the power ")#mi("B")#text("; I think ")#mi("B = 2")#text(". I guess he does say that ")#mi("B")#text(" can be any positive constant, not the same at each occurrence, but I think it would be perverse not to take it to be ")#mi("2")#text(" at this particular point.")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233449")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("In this post I shall finally get to the Type II sums, the analysis of which is Section 12 of Zhang’s paper. Notationally, this might be the most forbidding of the three cases.")

#text("Similarly to the Type I case, we shall be interested in estimates for")

#tao-math("\\mathbf{E}_{c \\in P(d)} \\mathbf{E}_{d \\sim X^{1/2 + 2\\varpi}} \\left|\\mathbf{E}_{x \\sim X, x = c(d)} (\\alpha \\ast \\beta)(x) \\right|", block: false)

#text("where ")#mi("\\alpha")#text(" is supported on a dyadic interval near ")#mi("M \\sim X^{1/2 + \\epsilon}")#text(" and ")#mi("\\beta")#text(" is supported near ")#mi("N \\sim X^{1/2 - \\epsilon}")#text(".")

#text("I aim to show that the Type II analysis is nontrivial for ")#mi("\\epsilon \\in [0,\\frac{1}{10})")#text(" (and, crucially, at the point ")#mi("\\epsilon = 0")#text(" left out from the Type I analysis). Moreover in this range we shall establish that the constraint imposed on ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(" is")

#mi("24 \\varpi + 7 \\delta \\leq \\frac{1}{2} - 5 \\epsilon.")

#text("We follow the Type I analysis, defining parameters ")#mi("Q \\sim X^{\\phi}")#text(" and ")#mi("R \\sim X^{1/2 + 2\\varpi - \\phi}")#text(" (the aim being to factor ")#mi("d = qr")#text(" with ")#mi("q \\sim Q")#text(" and ")#mi("r \\sim R")#text(").")

#text("Continue to the point just before the second application of Cauchy, where we had reduced matters to establishing that")

#tao-math("\\sum_{\\left|h\\right| \\leq X^{\\eta}} \\mathbf{E}_{q_1, q_2 \\sim Q} c(q_1) c(q_2) \\mathbf{E}_{n \\sim N} \\beta(n) \\beta(n + kr) e_r( \\frac{ah}{q_2q_1 n}) \\times", block: false)

#mi("\\times e_{q_1} ( \\frac{b_1 h}{q_2 r n}) e_{q_2}( \\frac{b_2 h}{q_1 r (n + kr)} ) = o(1).")

#text("We can assume ")#mi("h \\neq 0")#text(". Here, ")#mi("k")#text(" is some parameter, and")

#mi("\\eta = 2\\omega + \\phi - \\epsilon.")

#text("To make matters proceed smoothly to this point, we needed to assume the constraint")

#mi("\\phi \\geq \\epsilon + 2 \\varpi.")

#text("At this point the analysis diverges from the Type I case, and we instead despatch the unknown (and unwanted) quantities ")#mi("\\beta")#text(" by the triangle inequality, reducing things to proving that")

#tao-math("\\mathbf{E}_{n \\sim N} \\big{\\left|  \\sum_{h < X^{\\eta}} \\mathbf{E}_{q_1, q_2 \\sim Q} c(q_1) c(q_2) e_r( \\frac{ah}{q_2q_1 n}) e_{q_1} ( \\frac{b_1 h}{q_2 r n}) e_{q_2}( \\frac{b_2 h}{q_1 r (n + kr)} )   \\right|} = o(1).", block: false)

#text("Now apply Cauchy, so we need to prove that")

#mi("\\sum_{h, h^{\\prime} \\leq X^{\\eta}} \\mathbf{E}_{q_1, q_2, q^{\\prime}_1, q^{\\prime}_2 \\sim Q} c(q_1)c(q^{\\prime}_1) c(q_2) c(q^{\\prime}_2) \\mathbf{E}_{n \\sim N} e_r\\big{\\left(  \\frac{a}{n} (\\frac{h}{q_1 q_2} - \\frac{h^{\\prime}}{q_1 q_2}) \\right)} e_{q_1}\\big{\\left( \\frac{b_1h}{nrq_2}  \\right)} \\times")#linebreak()#text(" ")#mi("\\times e_{q^{\\prime}_1}\\big{\\left( \\frac{b_1h^{\\prime}}{nrq^{\\prime}_2}  \\right)}e_{q_2}\\big{\\left( \\frac{b_1h}{(n+ kr)rq_1}  \\right)}e_{q^{\\prime}_2}\\big{\\left( \\frac{b_1h^{\\prime}}{(n+ kr)rq^{\\prime}_1}  \\right)} = o(1).")

#text("(It might have been better to say that we Cauchy with just ")#mi("n")#text(" on the “outside” and all of ")#mi("h, q_1, q_2")#text(" on the inside; before, we Cauchy’d with ")#mi("n")#text(" and ")#mi("q_1")#text(" on the outside.)")

#text("As before, there is a \"singular\" case in which ")#mi("h^{\\prime} q_1 q_2 = h q^{\\prime}_1 q^{\\prime}_2")#text(". The number of solutions to this equation is bounded by")

#mi("\\sum_{h \\sim X^{\\eta}, q_1, q_2 \\sim Q} \\tau(h q_1 q_2)^2,")#text(" which is essentially ")#mi("X^{\\eta} Q^2 \\sim X^{\\eta + 2\\phi}")#text(". Thus the contribution to our main expression from these singular cases is basically at most ")#mi("X^{2\\eta - \\eta - 2\\phi}")#text(", and we win if ")#mi("2\\phi \\geq \\eta")#text(". Note that, crucially, this is a weaker condition than in the Type I case, where we need ")#mi("\\phi \\geq \\eta")#text(". Unfortunately the bounds imposed by subsequent parts of the argument become weaker as ")#mi("\\epsilon")#text(" increases, and for ")#mi("\\epsilon \\in [\\frac{1}{10}, \\frac{1}{8})")#text(" the Type II argument gives nothing whereas the Type I argument is nontrivial. This condition ")#mi("2\\phi \\geq \\eta")#text(" is automatically satisfied given our earlier stipulation that ")#mi("\\phi \\geq \\epsilon + 2\\varpi")#text(".")

#text("Thus we can ignore these singular cases. In the nonsingular cases the inner expectation over ")#mi("n")#text(" is, after a certain amount of messing around, basically of the form")

#mi("\\mathbf{E}_{n \\sim N} e_{d_1}(\\frac{c}{n}) e_{d_2}(\\frac{c^{\\prime}}{n + l}),")

#text("where ")#mi("d_1 = q_1 q^{\\prime}_1 r \\sim Q^2 R")#text(" and ")#mi("d_2 = q_2 q^{\\prime}_2 \\sim Q^2")#text(" (and ")#mi("l = kr")#text("). We can apply the same estimate for incomplete Kloosterman sums as before (Lemma 11 in Zhang) to conclude that this is bounded by ")#mi("(d_1 d_2)^{1/2}/N \\sim Q^2 R^{1/2}/N")#text(". I calculated this to be ")#mi("X^{-\\frac{1}{4} + \\frac{3}{2}\\phi + \\varpi + \\epsilon}")#text(".")

#text("Not forgetting that we still need to sum over ")#mi("h, h^{\\prime} \\leq X^{\\eta}")#text(", we see that the problem surrenders if")

#mi("2\\eta - \\frac{1}{4} + \\frac{3}{2}\\phi + \\varpi + \\epsilon \\leq 0.")#linebreak()#text(" Recalling that")

#mi("\\eta = 2\\varpi + \\phi - \\epsilon,")

#text("this gives")

#mi("5 \\varpi \\leq \\frac{1}{4} - \\frac{7}{2}\\phi + \\epsilon.")

#text("We want to take ")#mi("\\phi")#text(" as small as possible subject to the constraint ")#mi("\\phi \\geq \\epsilon + 2 \\varpi")#text(", but remember we only get to specify ")#mi("\\phi")#text(" up to a tolerance of ")#mi("\\delta")#text(". Thus the constraint is now")

#mi("5 \\varpi \\leq \\frac{1}{4} - \\frac{7}{2}(\\epsilon + 2\\varpi + \\delta) + \\epsilon,")#text(" which can be rearranged as")

#mi("24 \\varpi + 7 \\delta \\leq \\frac{1}{2} - 5 \\epsilon,")

#text("as claimed.")

#text("Note that improving this part of the argument is going to be pretty futile, because this dependence is vastly better than that imposed by the Type I/III border.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233500")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("To spell it out a bit differently, the unfortunate reason why the bounds become weaker as ")#mi("\\epsilon")#text(" increases, is that you took two ")#mi("q")#text("‘s in the Cauchy here (rather than one in “Type I”), and so have ")#mi("Q^2")#text(" rather than ")#mi("Q")#text(" appearing. As ")#mi("Q\\sim x^{\\epsilon+2\\omega(+\\delta)}")#text(", this becomes problematic as ")#mi("\\epsilon")#text(" progresses larger. On the other hand, in the ")#mi("\\epsilon\\rightarrow 0")#text(" limit, you don’t have an extra term outside the Cauchy, sothereby saving (a needed) ")#mi("Q")#text(" on the diagonal. In other words for Type II, the sum over ")#mi("q\\sim Q")#text(" is short enough that you can square its length without bother, and doing so saves (relatively) on the diagonal.")

#text("In other contexts there are similar instances with such short sums and Holder can profit more (see the proof of Burgess in “Estimates for Character Sums” by FI), but here that is not needed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233450")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Another small correction to Zhang’s paper: in the first display on page 5 ")#mi("\\mathcal{E}")#text(" should be multiplied by ")#mi("\\mathcal{L}^{2k_0+2l_0}")#text(", because ")#mi("\\lambda(n)^2")#text(" in (2.2) can be that large, cf. (2.4)")

#emph[#text("[Added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233467")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Some of Zhang’s most annoying errors occur right at the end. For instance, in 14.17 he garbly puts ")#mi("k_1,k_2")#text(", when he only wants this a single sum over ")#mi("k")#text(" (same on RHS). Three displays before the ")#mi("q")#text(" should be in a denominator. The penultimate display on page 51 has a trivial typo (two commas), as does the top line of page 49. The display below 10.5 has an unnecessary subscript on the ")#mi("J")#text(", the last line of the definition of ")#mi("R_1")#text(" below 10.14 has the ")#mi("k")#text(" in the 8-fold ")#mi("\\xi")#text(" in the wrong place (compare next display).")

#text("One previous problem I had was following (12.5), but I think that is Ok now (I had used a generic bound on ")#mi("1/d_1\\ll 1/QR")#text(", but by the definition on line 3 of page 43 it cancels an lcm).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I recorded all of these errata except for the (14.17) one, since it appears to me that what he is doing is splitting the ")#mi("k")#text(" variable of summation in (14.15) as ")#mi("k = k_1 r_2 + k_2")#text(", and then ")#mi("k_2")#text(" is relabeled ")#mi("k")#text(" and ")#mi("m_1+m_2+k_1r_2")#text(" is simply denoted ")#mi("m")#text(".")

#text("Thanks to your and Ben’s exposition I think I might be able to read through all of Zhang and summarise it for the next rollover post (it’s about time for this thread to roll over at any rate). It may take a few days though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233481")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Sounds like a plan! I’m more or less done at this point, or at least I’m prepared to let the dust settle for a while. I’ll pen a short post about the incomplete Kloosterman sum estimate (Lemma 11) and possibly also revisit Section 6, but I think Sections 7 to 14 are covered now at least to the first level of detail (which, for the most part, is probably as far as things need to go on this blog except for the occasional interesting comment like v08ltu’s one above about getting ")#mi("q_1, q_2")#text(" coprime). Sections 8 and 9 have been given short shrift, but they seem to be similar to, but strictly easier than, Section 10.")

#text("One observation is that one could make the ")#mi("207 \\varpi + 43 \\delta \\leq \\frac{1}{4}")#text(" bound completely rigorous just by reference to Zhang’s paper (because, indeed, that bound comes from working out the optimal exponents everywhere in what he does). If any conceptual improvements come to light, though, it might be much more painful as the second (and third…) levels of detail may need to be penetrated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I’m slowly beginning the writing up of our numerically optimised version of Zhang’s Theorem 2 with various notational simplifications. One question: now that you have gone through the paper, what properties of the residue classes ")#mi("C(q)")#text(" (or ")#mi("C_i(q)")#text(") do you see used by Zhang, other than cardinality bounds and the Chinese remainder theorem ")#mi("C(qr) \\equiv C(q) C(r)")#text("? Is the fixed nature of the polynomial ")#mi("P(n) = \\prod_{h \\in {\\mathcal H}}(n+h)")#text(" used to define the classes used at some point? Presumably yes (otherwise one is very close to proving Elliot-Halberstam, at least on the smooth moduli) but I don’t yet see where it is actually used.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233501")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Yes, this is in Section 10, see (10.6) and the display above in particular, and the resulting divisor-sum estimates.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233511")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Thanks! That’s a relatively crude use of the bounded coefficient nature of the polynomial P – it seems to me that it would suffice for the coefficients of P to be of polynomial size ")#mi("O( x^{O(1)})")#text(" and one would still get comparable results. If this were the case (and the bounded coefficient nature of the polynomial P is not used elsewhere in the proof of Theorem 2), this would allow one to delete Sections 8 and 9 of Zhang by the following trick: instead of looking at discrepancies such as")

#mi("\\sum_{n = c\\ (d)} \\gamma(n) - \\frac{1}{\\phi(d)} \\sum_{(n,d) = 1} \\gamma(n)")

#text("that compare one congruence class to the mean, instead look at discrepancies such as")

#mi("\\sum_{n = c\\ (d)} \\gamma(n) - \\sum_{n = c+t\\ (d)} \\gamma(n)")

#text("that compare one congruence class to a shift of that class by some integer t of polynomial size, which is essentially amounting to translating the polynomial P by a polynomial size shift (which keeps all coefficients of polynomial size). If one squares this sort of thing out then one only gets S_3 type terms and no S_1,S_2 terms and the key point is that all the cross terms should end up giving a contribution that is essentially independent of the shift t. Averaging over all t of size up to, say, x^10, we should get back the classical discrepancies (there is a bit of book-keeping to ensure that one only works with primitive residues, but I think this can be managed by some relatively simple combinatorial manipulations).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233538")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Incidentally, related to the above discussion, I believe that the estimate on the third display of page 36 needs some factors of ")#mi("\\tau(q_0r)")#text(" because it is possible that ")#mi("a_j + h_\\mu - h_i")#text(" has some large common factor with ")#mi("q_0 r")#text(", but this does not significantly impact the later analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233540")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I must admit that I found the top of page 36 too hard to parse, and made my own argument there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233546")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Note that Zhang does not win by a power in this part, but only by ")#mi("e^{(\\log x)^{1/k}}")#text(". Maybe this can be ")#mi("e^{\\log/\\log\\log}")#text(", or whatever what you call the ")#mi("W")#text("-trick can handle. For a divisor-bound, this might demand more uniformity than varying the ")#mi("P")#text("-coefficients allows.")

#text("His method essentially says ")#mi("\\tau(P(n-h_i))=\\prod_{i=1}^k \\tau(n-h_i)\\le\\sum_i \\tau(n-h-i)^k")#text(", and then estimates this over ")#mi("n")#text(" in AP.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233483")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Another minor error, on the display after Mobius inversion on page 47, the condition on the inner sum should have ")#mi("l\\in I_i(sh)")#text(" I think (the inversion replaced ")#mi("h")#text(" by ")#mi("sh")#text(").")

#emph[#text("[Added, thanks. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233485")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("The display on the bottom of page 14 is missing a right parenthesis on the second condition in the summation.")

#emph[#text("[Corrected, thanks -T.]")]

#text("I just (14.17) is Ok after your explanation, though I have not convinced myself that what he does is a bit superfluous compared to something more direct (given his goals).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233575")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Since Zhang wins in the “main” term in S13&14, it may be useful to think about how to improve the secondary terms (eg the diagonal), to optimize the error. In their rendition, FI Theorem 4, they get the main term that Zhang would get w/o the factor-trick, and various secondary terms. In their remarks, they say that one might improve, for instance by using Holder instead of Cauchy. An idea along these lines might be to shift by ")#mi("hk_1k_2r")#text(" instead of ")#mi("hkr")#text(" (the idea of shifting by a product in essence), where ")#mi("k_1k_2\\sim K")#text(" but can be in convenient subranges, say $k_1$ small and Holder that variable (somehow). This might help quell the diagonal, though I suspect the losses elsewhere (completion?) will ruin it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233623")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("It seems as though the “Level 1” structure of Zhang’s paper has now been mostly discussed on this blog. I thought I’d start looking at the “Level 2” structure of the paper, just to check that no unforeseen constraints or difficulties are lurking there. By “Level 2” structure I mean certain technical issues that one would definitely not mention in a seminar on the subject, but which are more important than “Level 3” issues such as checking that cutoffs can be smoothed out, book-keeping of coprimality constraints, and so on.")

#text("By the way, I should say that this top down method is my favoured one for reading papers, and is probably something to be borne in mind when writing them (though I am certainly guilty of not paying attention to this principle).")

#text("The most worrying piece of Level 2 structure for me is the material on pages 34, 35 and 36 of Zhang’s paper. It has been discussed to some extent by Terry and v08ltu above. In my discussion of the Type I case, I had mentioned how things are reduced to showing that")

#mi("\\mathbf{E}_{q_1, q_2 \\sim Q} c(q_1) c(q_2) \\mathbf{E}_{n_1, n_2 \\sim N, n_1 = n_2(r)} \\beta(n_1) \\beta(n_2) \\mathbf{E}_{m \\sim M} 1_{m = a\\overline{n_1}(r), b \\overline{n_1} (q_1), b \\overline{n_2}(q_2)}")

#mi("= o(\\frac{1}{Q^2 R}).")

#text("Call this (1).")

#text("(I am assuming familiarity with that post, though the notation there is similar to Zhang’s paper).")

#text("I then remarked that pages 34, 35 and 36 of Zhang are devoted to showing that one may restrict the expectation just to those ")#mi("q_1, q_2")#text(" that are coprime.")

#text("I now realise, following comments from others, that to make this happen requires a few modifications that make the argument look even more complicated than it already is.")

#text("Remember that ")#mi("d = qr")#text(", and that we have attained this factorisation using the fact that ")#mi("d")#text(" is ")#mi("X^{\\delta}")#text("-smooth. It turns out that one should also make sure that ")#mi("q")#text(" does not have any small prime factors: the right notion is that we should have ")#mi("p | q \\Rightarrow p \\geq \\exp(\\log^{1/k_0} X)")#text(". I will explain this more in a subsequent post. Now this cannot be attained automatically; one instead has to go right back to the start of what we are trying to do, and observe that in our goal of trying to estimate")

#tao-math("\\mathbf{E}_{c \\in \\mathcal{C}_i(d)}\\mathbf{E}_{d \\sim X^{1/2 + 2\\varpi}} \\left|\\mathbf{E}_{x = c(d)} (\\alpha \\ast \\beta)(x)\\right|", block: false)#text(",")

#text("we can in fact ignore the contribution of those ")#mi("d")#text(" for which")

#mi("\\prod_{p | d \\Rightarrow p \\leq \\exp (\\log^{1/k_0} X)} p \\geq X^{\\delta}")#text(",")

#text("essentially because there are very few such ")#mi("d")#text(". Zhang notes that this can be done by “trivial estimation”, but the definition of trivial here is a little niche and that is why a MathOverflow question was devoted to this point:")

#link("http://mathoverflow.net/questions/131825/a-technical-question-related-to-zhangs-result-of-bounded-prime-gaps")[#text("http://mathoverflow.net/questions/131825/a-technical-question-related-to-zhangs-result-of-bounded-prime-gaps")]

#text("The question was answered by Sungjin Kim of UCLA, and it *is* trivial, at least if you have really known your way around estimates for divisor-like functions for a few years.")

#text("Incidentally Zhang performs this step before he decomposes ")#mi("\\Lambda")#text(" using Heath-Brown’s identity, but I think it is only required in the analysis of the Type I and II sums, and is technical, so perhaps it should be moved over there.")

#text("So now we know that we can assume ")#mi("d = qr")#text(", with ")#mi("q")#text(" and ")#mi("r")#text(" being within ")#mi("X^{\\delta}")#text(" of any given power we like, and furthermore with ")#mi("q")#text(" having no small prime factors (smaller than ")#mi("\\exp (\\log^{1/k_0} X)")#text(". The point about doing this is that the variables ")#mi("q_1, q_2")#text(" in the expression (1) now satisfy a dichotomy: either they’re coprime (the case we saw, at least roughly, how to analyse before) or else they share a common factor ")#mi("q_0 \\geq \\exp (\\log^{1/k_0} X)")#text(". In this case we end up winning by a factor of ")#mi("1/q_0")#text(" which, because it beats all powers of ")#mi("\\log X")#text(", is fine for our purposes.")

#text("I’ll post details of this calculation in a second post, which I do not have time to write right now. There is an additional key point, which is that for once it is a bit too simplistic to simply delete (as I did right at the start) the extra averagings over ")#mi("a \\in \\mathcal{C}_i(r)")#text(" and ")#mi("b \\in \\mathcal{C}_i(q)")#text(", which I dismissed before as being “essentially bounded”. The problem is that taking account of these sets leads to functions behaving a bit like the divisor function, which can grow as big as ")#mi("\\exp (C \\log x/\\log \\log x)")#text(", so if we’re not careful the factor of ")#mi("q_0")#text(" won’t be enough to kill these contributions. (This was not an issue anywhere else, where we always got power savings. As noted by v08ltu, we do not get power savings from this part of the argument).")

#text("As it turns out the factor of ")#mi("q_0")#text(" does still kill these potentially unruly contributions, but we must check this carefully and here (and only here) we use something of the specific structure of the residue sets ")#mi("\\mathcal{C}_i(d)")#text(" beyond mere multiplicativity. Recall that these are defined to be those ")#mi("n \\mod d")#text(" for which ")#mi("(n,d) = 1")#text(" and ")#mi("d| \\prod_{j = 1}^{k_0} (n + h_i - h_j)")#text(".")

#text("I’ll say more about this in the next post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233646")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Dear Ben,")

#text("I was grappling with this issue too as I try to write up a post on Zhang’s theorem (and am currently trying to deal with Section 10). The issue isn’t so much the cardinality of the ")#mi("{\\mathcal C}_i(q)")#text(" (actually I have a randomisation trick that allows one to reduce to the case ")#tao-math("\\left|{\\mathcal C}_i(q)\\right|=1", block: false)#text("), but rather the size of the “divisor function” ")#tao-math("\\tau_{{\\mathcal C}_i}(n) := \\left| \\{ q: n \\ (q) \\in {\\mathcal C}_i(q) \\}\\right|", block: false)#text(". As you say, sup-norm bounds on this function (i.e. the divisor bound) are too weak to be absorbed by the tiny gain of ")#mi("1/q_0 \\ll \\exp( - \\log^{1/k_0} x)")#text(". Instead one needs ")#mi("\\ell^2")#text(" type bounds on this quantity along any non-trivial arithmetic progression (length ")#mi("\\gg x^\\varepsilon")#text(") with bounds that are basically polylogarithmic in nature. For this Zhang appeals to a standard bound in the literature (Brun-Titchmarsh for multiplicative functions, see Lemma 8 and [11]).")

#text("Abstractly, the only axioms for C(q) = C_i(q) that appear to be necessary in Zhang’s argument are:")

#text("* Primitivity: ")#mi("C(q) \\subset ({\\bf Z}/q{\\bf Z})^\\times")

#text("* Chinese remainder theorem ")#mi("C(q) \\times C(r) \\equiv C(qr)")

#text("* Bounded size at primes: ")#tao-math("\\left|C(p)\\right| = O(1)", block: false)

#text("* ")#mi("\\ell^2")#text(" divisor bound: ")#mi("\\sum_{n \\sim x: n = a\\ (q)} \\tau_C(n)^2 \\ll \\frac{x}{q} \\tau(q)^{O(1)} \\log^{O(1)} x + x^{o(1)}")

#text("where ")#tao-math("\\tau_C(n) := \\left| \\{ q: n\\ (q) \\in C(q) \\}\\right|", block: false)#text(". For the application at hand ")#mi("\\tau_C(n)")#text(" can be controlled by a polynomial combination of functions of the form ")#mi("\\tau( n + h )")#text(" for various ")#mi("h")#text(", but one could imagine other applications of Zhang’s theorem involving fancier systems of congruence classes ")#mi("C(q)")#text(".")

#text("Anyway, if one abstracts the above axioms on ")#mi("C(q)")#text(", one gets a convenient consequence: one can then pass for free to the singleton case ")#tao-math("\\left|C(q)\\right|=1", block: false)#text(". The idea is to just pick randomly one representative of ")#mi("C(p)")#text(" for each prime ")#mi("p")#text(" and use Chinese remainder to then form a singleton congruence class for each ")#mi("q")#text(". If one can then prove Zhang’s theorem for these singleton classes, take expectations and one recovers Zhang’s theorem for the original classes ")#mi("C(q)")#text(" (there is now a weight of ")#tao-math("1/\\left|C(q)\\right|", block: false)#text(" but this weight may be easily disposed of by the usual Cauchy-Schwarz with a trivial bound with the opposite weight of ")#tao-math("\\left|C(q)\\right|", block: false)#text(" and no ")#mi("\\log^{-A} x")#text(" gain).")

#text("On the other hand, the other trick I was proposing before, namely to replace the usual discrepancy ")#mi("\\sum_{n=a\\ (q)} - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1}")#text(" with a more symmetric discrepancy ")#mi("\\sum_{n=a\\ (q)} - \\sum_{n=a^{\\prime}\\ (q)}")#text(", does not interact well with the stage of the argument where one is trying to get q_1 and q_2 to be coprime. My trick kills off the S_2 and S_3 terms, and replaces the S_1 term with a more general version of this term in which the moduli b_1, b_2 are completely unrelated (one lies in C_1(q_1) and one lies in C_2(q_2) for different systems of congruence classes C_1(q), C_2(q). I had thought that this generalisation was harmless but actually it seems to screw up the argument that eliminates the case when q_1, q_2 have a common factor. (But there is a chance that the screw up actually works in one’s favor. Still working to clear this up…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Regarding ways to modify the discrepancy: I did find that when computing a discrepancy for a combined residue class ")#mi("n = b\\ (q), n = a\\ (r)")#text(" as is done in the treatment of Type I/II sums, it was slightly convenient to split up the full discrepancy")

#mi("\\displaystyle \\sum_{n= b\\ (q); n=a\\ (r)} - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr) = 1}")

#text("as the sum of two subdiscrepancies, namely")

#mi("\\displaystyle \\sum_{n= b\\ (q); n=a\\ (r)} - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)}")

#text("and")

#mi("\\displaystyle \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n=a\\ (r)} - \\frac{1}{\\phi(qr)} \\sum_{n: (n,q)=(n,r)=1}.")

#text("The second discrepancy can be handled by Bombieri-Vinogradov (because the r parameter lies safely below ")#mi("x^{1/2-\\varepsilon}")#text("); it is the first discrepancy which is the main one. But the point is that when one Cauchy-Schwarz’es this discrepancy instead of the full discrepancy, one gets the constraint ")#mi("n_1 = n_2\\ (r)")#text(" for free (which seems to be rather essential to the analysis, since we need the key reparameterisation ")#mi("n_2 = n_1 + kr")#text(" for the Type I argument). (Doing things this way substitutes for the arguments on pages 37-38 of Zhang and demystified for me why we had two slightly different h=0 terms, X(r,a) and X^*(r,a), in the analysis.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233673")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Yes, in 37&38 (or BFI S7) the idea is that the asymptotic ")#mi("h=0")#text(" terms cancel up to a small error (distinction between X and X*), and this extra bit is bounded via a B-V style argument with the large sieve (see the proof of BFI Theorem 0, cited in Zhang Lemma 10) ending with more of a Barban-Davenport-Halberstam result (Zhang Lemma 10, BFI S7) upon the Cauchy.")

#text("The input to make this B-V machinery work is the small moduli Siegel-Walfisz bound, and then the large sieve induces what is wanted for moduli up to sqrt. I think Ben Green in his prior confusion over A2 ended up rederiving the same, that once one has the bootstrap from S-W, the rest is a large sieve (in some guise).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233655")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2013")])]

#text("Terry: thanks, yes, you’re right that it isn’t the size of these sets ")#mi("\\mathcal{C}_i(q), \\mathcal{C}_i(r)")#text(" themselves that causes the problem. I edited my post slightly in the light of your comment. The size of the set ")#mi("\\mathcal{C}_i(q_0)")#text(" does come into play – I think this leads to the term ")#mi("\\varrho_2(q_0)^2")#text(" (for whose definition you have to go back to Sections 1 and 3) on page 36. But this particular term will not harm the gain from ")#mi("1/q_0")#text(",")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233766")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Given my mathematical background I was certainly proposing to take the estimate of Bombieri and Birch, namely")

#mi("\\mathbf{E}_{n, n^{\\prime} \\ell} e_p ( \\frac{c_1}{\\ell n} + \\frac{c_2}{(\\ell + k) n^{\\prime}} + hn + h^{\\prime} n^{\\prime}) = O( p^{-3/2})")#text(",")

#text("as a black box.")

#text("However while looking at Friedlander-Iwaniec “Incomplete Kloosterman sums and a divisor problem”, which seems to have been a big inspiration for Zhang, I did realise what I suppose is a pretty obvious point: that after the substitution ")#mi("x_1 = c_1/\\ell n")#text(", ")#mi("x_2 = c_2/(\\ell + k) n^{\\prime}")#text(", ")#mi("x_3 = hn")#text(", ")#mi("x_4 = h^{\\prime}n^{\\prime}")#text(" this exponential sum may be written in the more suggestive form")

#mi("\\mathbf{E}_{(x_1, x_2,x_3,x_4) \\in V} e_p(x_1 + x_2 + x_3 + x_4)")#text(",")

#text("where ")#mi("V")#text(" is the variety ")#mi("\\alpha x_2 x_4 + \\beta x_1 x_3 = k x_1 x_2 x_3 x_4")#text(" with ")#mi("\\alpha = c_2h^{\\prime}")#text(", ")#mi("\\beta = -c_1 h")#text(". This then links things to a much more general discussion of exponential sums of this type, to which Chapter 11 of Iwaniec-Kowalski seems to me to be a superb introduction for the nonspecialist.")

#text("The discussion of this sum by Fouvry, Kowalski and Michel here")

#link("http://www.math.ethz.ch/~kowalski/friedlander-iwaniec-sum.pdf")[#text("Click to access friedlander-iwaniec-sum.pdf")]

#text("doesn’t seem to want to write it in this way, though: I’m not sure why.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233841")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("We prefer writing the sum as in the note essentially because writing it as a sum of products of two Kloosterman sums at different arguments allows us to have a very simple conceptual argument (quasi-orthogonality) for the Birch-Bombieri estimate, instead of involving the geometry of algebraic threefolds, which is a rather delicate matter (though this is the way Birch and Bombieri give the first of their two proofs of the square-root cancellation estimate).")

#text("For instance, it’s not immediately obvious — to me — that the sum you write is of size at most p^2, whereas this is the “trivial” bound from the Kloosterman sum point of view.")

#text("Also, the Kloosterman sum expression (with slightly different arguments) turns out to appear in quite a few other papers of analytic number theory (Pitt, Munshi, our — F-K-M — own work on algebraic twists of modular forms). This seems unlikely to be a coincidence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233847")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Emmanuel, but would you say that writing things as ")#mi("\\mathbf{E}_{\\vec{x} \\in V} e_p(x_1 + \\dots + x_n)")#text(", even if it’s not the quickest way to proceed in this context, affords one the most general access to the deep theory? I ask mainly in case we start trying to mess about with Zhang’s argument, trying different Cauchys, etc. By the way I do enjoy your use of the word trivial here… are you sure the quotation marks are even necessary?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233922")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("I think it is harder to prove square-root cancellation in many-variable character sums, absent extra information, than in one-variable sums with more complicated arguments than character values. More importantly here, the fact that the sums arise from Kloosterman sums seems to be such a piece of extra information that should be kept in view.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233781")[#strong[#text("Online reading seminar for Zhang’s “bounded gaps between primes” | Apparel ego")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")]

#text("[…] Read more… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233806")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Just a note to say that I am about halfway through the writeup of Zhang’s Theorem 2 (in our notation, and with dependencies on ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(" optimised and made explicit). More specifically, I have confirmed (modulo verifying the exponential sum estimates) that the Type I/II analysis works whenever")

#mi("11 \\varpi + 3\\delta + 2 \\sigma < \\frac{1}{4}")

#text("and")

#mi("37\\varpi + 5 \\delta < \\frac{1}{4}")#text(".")

#text("The first condition was already identified by both Ben and v08ltu (and in the corrected version of Pintz). The second one is needed for the Type II analysis to work, but in practice this condition is a bit weaker than the current ranges of ")#mi("\\varpi,\\delta")#text(" that we are currently faced with. (But if we want to break past, say, ")#mi("\\varpi = 1/168")#text(", then we will need to tighten the Type II analysis somehow.) A minor remark: in the Type II analysis, it turns out that the second term in the exponential sum bound ends up dominating over the first term for the purposes of determining constraints on parameters, in particular even when ")#mi("\\varpi,\\delta \\approx 0")#text(" this term ends up killing the estimate once ")#mi("\\sigma")#text(" exceeds 1/14 rather than 1/10 (which is what Ben computed as the threshold using the first term in the exponential sum estimate instead). It's fortunate though that the Type II analysis is not critical to any immediate optimisation goals, and one can afford to be a bit sloppy here.")

#text("Also the Cauchy-Schwarz for Type I and Type II is actually very similar. In both cases one is estimating a bilinear expression of the form")

#mi("\\sum_{h,q_1,q_2} \\sum_n a_{h,q_1,q_2} b_n \\Phi(h,q_1,q_2;n)")

#text("where ")#mi("a_{h,q_1,q_2}, b_n")#text(" are more or less arbitrary coefficients of controlled size, and ")#mi("\\Phi")#text(" is a certain explicit phase function (with some technical localisations to enforce some coprimality constraints). In Type II one Cauchy-Schwarz'es in n and then applies the triangle inequality to end up with estimating")

#tao-math("\\sum_{h,q_1,q_2,h^{\\prime},q^{\\prime}_1,q^{\\prime}_2} \\left|\\sum_n \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right|", block: false)

#text("whereas in Type I one Cauchy-Schwarz'es in ")#mi("n,h_1")#text(" and then applies the triangle inequality to instead estimate")

#tao-math("\\sum_{h,q_1,q_2,h^{\\prime},q^{\\prime}_2} \\left|\\sum_n \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right|", block: false)

#text("i.e. one keeps ")#mi("q_1,q^{\\prime}_1")#text(" equal. This constraint ")#mi("q_1=q^{\\prime}_1")#text(" improves the exponential sum bound in the non-diagonal case, but makes the diagonal case denser, and it is this tradeoff which is causing the Type I/Type II barrier.")

#text("It just occurred to me that one might be able to squeeze a better bound than the trivial bound out of the treatment of the diagonal case ")#mi("h^{\\prime} q_2 = h q^{\\prime}_2")#text(" in Type I, but then I realised that this just improves the Type I/II boundary and has no discernible effect on the final constraints on ")#mi("\\varpi,\\delta")#text(".")

#text("Starting on the Type III analysis now. The trick of factoring a Ramanujan sum (which has better than square root cancellation!) out of a Bombieri-Birch sum is pretty cool, and I guess is ultimately the most powerful new idea in Zhang's paper (though one which can only be seen after applying all the powerful old ideas).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233928")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("A small comment: the coefficients ")#mi("a_{h,q_1,q_2}")#text(" that get killed by the triangle inequality in the above analysis are not completely arbitrary; they basically factor as ")#mi("a_{q_1} a_{q_2}")#text(" times a smooth cutoff on ")#mi("h")#text(" (admittedly there is this ")#mi("\\hat f(\\frac{h}{q_1 q_2 r})")#text(" that ostensibly provides some more coupling here, but this is a smoothly varying factor and I think it can be more or less ignored). Potentially this extra structure could be used to squeeze out a bit more cancellation here by working with a Gowers box norm which corresponds to a higher dimensional exponential sum (and thus, in principle, a higher dimensional square root gain) but perhaps the gain here is worse than the price one would have to pay from completion of sums.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/72ea9506a8fb064ca33e1274316b9c84a40688ea23862e524fb0e6f7c49e439d-de04381cb4b04ef82414d1c9f13abb48fa2449415656dd437c3d5867c9ce47c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233811")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("Thanks Terry. I’ll go back and modify what I wrote on Type II so that there’s nothing (too grossly) incorrect on your blog. Am currently preparing to give a general audience lecture on this tomorrow in Cambridge…..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233872")[#strong[#text("Polymath8: Bounded Gaps Between Primes | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")]

#text("[…] Zhang’s proof and improving the upper bound for the gaps. Here are links for three posts (I, II, III) on Terry Tao’s blog and for a post on the polymath blog. And here is the table for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d62cc495739d57c707a5605bfbbe47d8850217cccc8444136ea1793fa3dc38b4-3c12148a12ed29af8284811eb104bf992392f47d631f55c40850feee831ab232.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klaus Lange")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-233997")[#strong[#text("Klaus Lange")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("Now on arxiv I found a new paper from Pintz et. al. about finding small gaps between consecutive primes (regarding optimal weight function): ")#link("http://arxiv.org/pdf/1306.2133.pdf")[#text("http://arxiv.org/pdf/1306.2133.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type I and Type II sums | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-234211")[#strong[#text("Estimation of the Type I and Type II sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("[…] is one of the continuations of the online reading seminar of Zhang’s paper for the polymath8 project. (There are two other continuations; this previous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type III sums | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-234518")[#strong[#text("Estimation of the Type III sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("[…] is the final continuation of the online reading seminar of Zhang’s paper for the polymath8 project. (There are two other continuations; this previous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-234523")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Now that all the followup posts have been written, it’s time to close this particular thread and continue the polymath discussion at one of the followup threads:")

#text("* discussion of the Type I/II sums at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("Estimation of the Type I and Type II sums")]
]

#text("* discussion of the Type III sums at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("Estimation of the Type III sums")]
]

#text("* everything else about the Zhang paper at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("A combinatorial subset sum problem associated with bounded prime gaps")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a42cba640f2f48d3f054903d909fb2ce11e1a826b0a5390f8e42d4684bea591b-5dce9a925b3fb33ba098ac4f22ed772ccac177173e57b03a627300d00316757a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The proof that frightened Pythagoras | cartesian product")]], [#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/comment-page-1/#comment-235595")[#strong[#text("The proof that frightened Pythagoras | cartesian product")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("[…] Online reading seminar for Zhang’s “bounded gaps between primes” (terrytao.wordpress.com) […]")
]
