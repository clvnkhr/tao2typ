// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/
// Converted to Typst by tao2typ: "2026-10-14T15:16:52.497257+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The divisor bound", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The divisor bound")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 September 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given a positive integer ")#mi("n")#text(", let ")#mi("d(n)")#text(" denote the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("number of divisors")]#text(" of n (including 1 and n), thus for instance d(6)=4, and more generally, if n has a prime factorisation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("n = p_1^{a_1} \\ldots p_k^{a_k}")]]

#text("then (by the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(")")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("d(n) = (a_1+1) \\ldots (a_k+1).")]]

#text("Clearly, ")#mi("d(n) \\leq n")#text(". The ")#emph[#text("divisor bound")]#text(" asserts that, as ")#mi("n")#text(" gets large, one can improve this trivial bound to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("d(n) \\leq C_\\varepsilon n^\\varepsilon")]]

#text("for any ")#mi("\\varepsilon > 0")#text(", where ")#mi("C_\\varepsilon")#text(" depends only on ")#mi("\\varepsilon")#text("; equivalently, in ")#link("http://en.wikipedia.org/wiki/Big_O_notation")[#text("asymptotic notation")]#text(" one has ")#mi("d(n) = n^{o(1)}")#text(". In fact one has a more precise bound")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("d(n) \\leq n^{O( 1/ \\log \\log n)} = \\exp( O( \\frac{\\log n}{\\log \\log n} ) ).")]]

#text("The divisor bound is useful in many applications in number theory, harmonic analysis, and even PDE (on periodic domains); it asserts that for any large number n, only a “logarithmically small” set of numbers less than n will actually divide n exactly, even in the worst-case scenario when n is ")#link("http://en.wikipedia.org/wiki/Smooth_number")[#text("smooth")]#text(". (The average value of d(n) is much smaller, being about ")#mi("\\log n")#text(" on the average, as can be seen easily from the ")#link("http://en.wikipedia.org/wiki/Double_counting_(proof_technique)")[#text("double counting")]#text(" identity")

#align(center)[#mi("\\sum_{n \\leq N} d(n) = \\# \\{ (m,l) \\in {\\Bbb N} \\times {\\Bbb N}: ml \\leq N \\} = \\sum_{m=1}^N \\lfloor \\frac{N}{m}\\rfloor \\sim N \\log N")#text(",")]

#text("or from the heuristic that a randomly chosen number m less than n has a probability about 1/m of dividing n, and ")#mi("\\sum_{m<n} \\frac{1}{m} \\sim \\log n")#text(". However, (4) is the correct “worst case” bound, as I discuss below.)")

#text("The divisor bound is elementary to prove (and not particularly difficult), and I was asked about it recently, so I thought I would provide the proof here, as it serves as a case study in how to establish worst-case estimates in elementary multiplicative number theory.")

#text("[")#emph[#text("Update")]#text(", Sep 24: some applications added.]")

#metadata(none) <tao-2ef5c289b4a67c1dfca2>

#heading(level: 1)[#text("— Proof of (3) —")]

#text("Let’s first prove the weak form of the divisor bound (3), which is already good enough for many applications (because a loss of ")#mi("n^{o(1)}")#text(" is often negligible if, say, the final goal is to extract some polynomial factor in n in one’s eventual estimates). By rearranging a bit, our task is to show that for any ")#mi("\\varepsilon > 0")#text(", the expression")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{d(n)}{n^\\varepsilon}")]]

#text("is bounded uniformly in n by some constant depending on ")#mi("\\varepsilon")#text(". Using (1) and (2), we can express (5) as a product")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\prod_{j=1}^k \\frac{a_j+1}{p_j^{\\varepsilon a_j}}")]]

#text("where each term involves a different prime ")#mi("p_j")#text(", and the ")#mi("a_j")#text(" are at least 1. We have thus “localised” the problem to studying the effect of each individual prime independently. (We are able to do this because d(n) is a ")#link("http://en.wikipedia.org/wiki/Multiplicative_function")[#text("multiplicative function")]#text(".)")

#text("Let’s fix a prime ")#mi("p_j")#text(" and look at a single term ")#mi("\\displaystyle \\frac{a_j+1}{p_j^{\\varepsilon a_j}}")#text(". The numerator is linear in ")#mi("a_j")#text(", while the denominator is exponential. Thus, as per ")#link("http://en.wikipedia.org/wiki/Malthus")[#text("Malthus")]#text(", we expect the denominator to dominate, at least when ")#mi("a_j")#text(" is large. But, because of the ")#mi("\\varepsilon")#text(", the numerator might be able to exceed the denominator when ")#mi("a_j")#text(" is small – but only if ")#mi("p_j")#text(" is also small.")

#text("Following these heuristics, we now divide into cases. Suppose that ")#mi("p_j")#text(" is large, say ")#mi("p_j \\geq \\exp(1/\\varepsilon)")#text(". Then ")#mi("p_j^{\\varepsilon a_j} \\geq \\exp(a_j) \\geq 1+a_j")#text(" (by Taylor expansion), and so the contribution of ")#mi("p_j")#text(" to the product (6) is at most 1. So all the large primes give a net contribution of at most 1 here.")

#text("What about the small primes, in which ")#mi("p_j < \\exp(1/\\varepsilon)")#text("? Well, by Malthus, we know that the sequence ")#mi("\\frac{a+1}{p_j^{\\varepsilon a}}")#text(" goes to zero as ")#mi("a \\to \\infty")#text(". Since convergent sequences are bounded, we therefore have some bound of the form ")#mi("\\frac{a_j+1}{p_j^{\\varepsilon a_j}} \\leq C_{p_j,\\varepsilon}")#text(" for some ")#mi("C_{p_j,\\varepsilon}")#text(" depending only on ")#mi("p_j")#text(" and ")#mi("\\varepsilon")#text(", but not on ")#mi("a_j")#text(". So, each small prime gives a bounded contribution to (6) (uniformly in n). But the number of small primes is itself bounded (uniformly in n). Thus the total product in (6) is also bounded uniformly in n, and the claim follows.")

#heading(level: 1)[#text("— Proof of (4) —")]

#text("One can refine the above analysis to get a more explicit value of ")#mi("C_\\varepsilon")#text(", which will let us get (4), as follows.")

#text("Again consider the product (6) for some ")#mi("\\varepsilon > 0")#text(". As discussed previously, each prime larger than ")#mi("\\exp(1/\\varepsilon)")#text(" gives a contribution of at most 1. What about the small primes? Here we can estimate the denominator from below by Taylor expansion:")

#align(center)[#tao-fit-display[#mitex("p_j^{\\varepsilon a_j} = \\exp( \\varepsilon a_j \\log p_j ) \\geq 1 + \\varepsilon a_j \\log p_j")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\frac{a_j+1}{p_j^{\\varepsilon a_j}} \\leq \\frac{a_j+1}{1+\\varepsilon a_j \\log p_j} \\leq O( \\frac{1}{\\varepsilon \\log p_j} )")]]

#text("(the point here being that our bound is uniform in ")#mi("a_j")#text("). One can of course use undergraduate calculus to try to sharpen the bound here, but it turns out not to improve by too much, basically because the Taylor approximation ")#mi("\\exp(x) \\approx 1+x")#text(" is quite accurate when x is small, which is the important case here.")

#text("Anyway, inserting this bound into (6), we see that (6) is in fact bounded by")

#align(center)[#tao-fit-display[#mitex("\\prod_{p < \\exp(1/\\varepsilon)} O( \\frac{1}{\\varepsilon \\log p} ).")]]

#text("Now let’s be very crude and bound ")#mi("\\log p")#text(" from below by ")#mi("\\log 2")#text(", and bound the number of primes less than ")#mi("\\exp(1/\\varepsilon)")#text(" by ")#mi("\\exp(1/\\varepsilon)")#text(". (One can of course be more efficient about this, but again it turns out not to improve the final bounds too much. A general principle is that when one estimating an expression such as ")#mi("A^B")#text(", or more generally the product of B terms, each of size about A, then it is far more important to get a good bound for B than to get a good bound for A, except in those cases when A is very close to 1.) We thus conclude that")

#align(center)[#mi("\\displaystyle (6) \\leq O( \\frac{1}{\\varepsilon} )^{\\exp(1/\\varepsilon)} = \\exp( \\exp( O(1/\\varepsilon) ) )")#text(";")]

#text("unwinding what this means for (3), we obtain")

#align(center)[#tao-fit-display[#mitex("d(n) \\leq \\exp( \\exp( O( 1/\\varepsilon ) ) ) n^\\varepsilon")]]

#text("for all ")#mi("n \\geq 1")#text(" and ")#mi("\\varepsilon > 0")#text(". If we now set ")#mi("\\varepsilon = C/\\log \\log n")#text(" for a sufficiently large C, then the second term of the RHS dominates the first (as can be seen by taking logarithms), and the claim (4) follows.")

#text("The above argument also suggests the counterexample that will demonstrate that (4) is basically sharp. Pick ")#mi("\\varepsilon > 0")#text(", and let n be the product of all the primes up to ")#mi("\\exp(1/\\varepsilon)")#text(". The ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(" tells us that ")#mi("\\log n \\sim \\exp( 1/\\varepsilon)")#text(". On the other hand, the prime number theorem also tells us that the number of primes dividing n is ")#mi("\\sim \\varepsilon \\exp( 1/\\varepsilon )")#text(", so by (2), ")#mi("\\log d(n) \\sim \\varepsilon \\exp( 1 / \\varepsilon )")#text(". Using these numbers we see that (4) is tight up to constants. [If one does not care about the constants, then one does not need the full strength of the prime number theorem to show that (4) is sharp; the more elementary bounds of Chebyshev, that say that the number of primes up to N is comparable to ")#mi("N/\\log N")#text(" up to constants, would suffice.]")

#heading(level: 1)[#text("— Why is the divisor bound useful? —")]

#text("One principal application of the divisor bound (and some generalisations of that bound) is to control the number of solutions to a ")#link("http://en.wikipedia.org/wiki/Diophantine_equation")[#text("Diophantine equation")]#text(". For instance, (3) immediately implies that for any fixed positive n, the number of solutions to the equation")

#align(center)[#tao-fit-display[#mitex("xy = n")]]

#text("with x,y integer, is only ")#mi("n^{o(1)}")#text(" at most. (For x and y real, the number of solutions is of course infinite.) This can be leveraged to some other Diophantine equations by high-school algebra. For instance, thanks to the identity ")#mi("x^2-y^2 = (x+y)(x-y)")#text(", we conclude that the number of integer solutions to")

#align(center)[#tao-fit-display[#mitex("x^2 - y^2 = n")]]

#text("is also at most ")#mi("n^{o(1)}")#text("; similarly, the identity ")#mi("x^3+y^3=(x+y)(x^2-xy+y^2)")#text(" implies that the number of integer solutions to")

#align(center)[#tao-fit-display[#mitex("x^3+y^3=n")]]

#text("is at most ")#mi("n^{o(1)}")#text(". (Note from ")#link("http://en.wikipedia.org/wiki/Bezout%27s_theorem")[#text("Bezout’s theorem")]#text(" (or direct calculation) that ")#mi("x+y")#text(" and ")#mi("x^2-xy+y^2")#text(" determine ")#mi("x,y")#text(" up to at most a finite ambiguity.)")

#text("Now consider the number of solutions to the equation")

#align(center)[#mi("x^2+y^2 = n")#text(".")]

#text("In this case, ")#mi("x^2+y^2")#text(" does not split over the rationals ")#mi("{\\Bbb Q}")#text(", and so one cannot directly exploit the divisor bound for the rational integers ")#mi("{\\Bbb Z}")#text(". However, we can factor ")#mi("x^2 + y^2 = (x+iy) (x-iy)")#text(" over the ")#link("http://en.wikipedia.org/wiki/Gaussian_integers")[#text("Gaussian rationals")]#text(" ")#mi("{\\Bbb Q}[\\sqrt{-1}]")#text(". Happily, the Gaussian integers ")#mi("{\\Bbb Z}[\\sqrt{-1}]")#text(" enjoy essentially the same divisor bound as the rational integers ")#mi("{\\Bbb Z}")#text("; the Gaussian integers have unique factorisation, but perhaps more importantly they only have a finite number of ")#link("http://en.wikipedia.org/wiki/Unit_(ring_theory)")[#text("units")]#text(" (")#mi("\\{-1,+1,-i,+i\\}")#text(" to be precise). Because of this, one can easily check that ")#mi("x^2+y^2=n")#text(" also has at most ")#mi("n^{o(1)}")#text(" solutions.")

#text("One can similarly exploit the divisor bound on other ")#link("http://en.wikipedia.org/wiki/Number_field")[#text("number fields")]#text("; for instance the divisor bound for ")#mi("{\\Bbb Z}[\\sqrt{-3}]")#text(" lets one count solutions to ")#mi("x^2+xy+y^2=n")#text(" or ")#mi("x^2-xy+y^2=n")#text(". On the other hand, not all number fields have the divisor bound. For instance, ")#mi("{\\Bbb Z}[\\sqrt{2}]")#text(" has an infinite number of units, which means that the number of solutions to ")#link("http://en.wikipedia.org/wiki/Pell%27s_equation")[#text("Pell’s equation")]

#align(center)[#tao-fit-display[#mitex("x^2-2y^2 = 1")]]

#text("is infinite.")

#text("Another application of the divisor bound comes up in ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve theory")]#text(". Here, one is often dealing with functions of the form ")#mi("\\nu(n) := \\sum_{d|n} a_d")#text(", where the sieve weights ")#mi("a_d")#text(" typically have size ")#mi("O(n^{o(1)})")#text(", and the sum is over all d that divide n. The divisor bound (3) then implies that the sieve function ")#mi("\\nu(n)")#text(" also has size ")#mi("O(n^{o(1)})")#text(". This bound is too crude to deal with the most delicate components of a sieve theory estimate, but is often very useful for dealing with error terms (especially those which have gained a factor of ")#mi("n^{-c}")#text(" relative to the main terms for some ")#mi("c > 0")#text(").")

#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8a5af20c50a7d7724a4ba118259f1acbfae79ce228188cc91911d7da24ccadd9-294703c515e4321a4d100bc42d11f010d32d2bbd3c6ed7c1e90d35305338cc68.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous Rex")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32657")[#strong[#text("Anonymous Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("Is the constant known in (4) as it is in the prime number theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32658")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("Terry,")

#text("The divisor bound is indeed surprisingly powerful, and is a good way of importing the information contained in the unique factorization theorem for the integers into analytic number theory (and other subjects, as you remark). It is always nice when some algebraic theory gives a highly portable tool that us analysts can use; another example would be the Weil bound for Kloosterman sums.")

#text("A good example in analytic number theory where the use of the divisor bound is critical is Hua’s result placing a good upper bound on the number of solutions to ")#mi("x_1^k + \\dots + x_s^k = y_1^k + \\dots + y_s^k")#text(" with ")#mi("x_i,y_i \\leq N")#text(", provided that ")#mi("s \\geq 2^{k-1}")#text(". One may read about this in Vaughan’s book on the Hardy-Littlewood method.")

#text("I only recently came to realise how subtle the bound is, when I found myself wishing for a similar-looking estimate. Let ")#mi("\\theta")#text(" be some fixed number (say ")#mi("\\theta = \\sqrt{2}")#text("). We say that ")#mi("m")#text(" is a generalised divisor of ")#mi("n")#text(" if there is some ")#mi("m^{\\prime}")#text(" such that ")#tao-math("\\left|(m + \\theta)(m^{\\prime} + \\theta) - (n + \\theta)\\right| < 1", block: false)#text(". So one is trying to do a kind of generalised arithmetic, in which the integers have been shifted by ")#mi("\\theta")#text(". Can you show that ")#mi("n")#text(" has ")#mi("O_{\\epsilon}(n^{\\epsilon})")#text(" generalised divisors, perhaps even uniformly in the choice of ")#mi("\\theta \\in [0,1)")#text("?")

#text("I pretty soon realised that there is no sensible theory of factorisation for these generalised integers, and then I found another way to tackle the problem I was actually interested in. Still, I would be interested to see a solution to this question!")

#text("I asked Roger Heath-Brown about the divisor function estimate, and he said that the best bounds known by “robust” methods are something like ")#mi("d(n) \\ll_{\\epsilon} n^{1/4 + \\epsilon}")#text(". He mentioned something about a paper of Bombieri and Pila but I forget the details.")

#text("One more thing – it is perhaps worth remarking (not to you in particular, as we have used this in a couple of our papers :-) ) that if one only wants an ")#mi("\\ell^p")#text(" bound then it is possible to do better. Namely,")

#mi("\\frac{1}{N} \\sum_{n \\leq N} d(n)^A \\ll \\log^{C_A} N,")#linebreak()#text(" where I think one can take ")#mi("C_A = 2^A - 1")#text(" when ")#mi("A")#text(" is an integer. I’m not sure if anyone has studied the case of fractional powers – seeing as one is losing powers of log anyway, it is hard to care too much about this.")

#text("Enjoy the rest of your two-week hiatus")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32660")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("Indeed, the higher moments are given by")

#mi("\\frac{1}{x}\\sum_{n\\leq x}{d(n)^k}\\sim (\\log x)^{2^k-1}")

#text("for any fixed integer ")#mi("k")#text(" (and it does work also with arbitrary complex values of ")#mi("k")#text(", or at least with positive real part — one has to look at the Selberg-Delange method to see if all complex ")#mi("k")#text(" are possible). The exponential growth of the exponent ")#mi("2^k")#text(" is another indication that large values of the divisor function are not so infrequent.")

#text("I think it was Ramanujan who first gave an elementary proof of these estimates, but nowadays it’s probably simpler to see it as a special case of general results on sums of multiplicative functions. The exponent is ")#mi("2^k-1")#text(" because ")#mi("d(p)^k=2^k")#text(" (the ")#mi("-1")#text(" comes from summing ")#mi("d(n)^k")#text(" instead of ")#mi("d(n)^k/n")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b806e9f01365749797ef51c20c7d863044ad3b87029e59dfa5812705fd91350a-c94ef3d08703b3dd37d5a77e002ac403544e8b7a748f3ac987ffe47163e2137e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Espino")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-492460")[#strong[#text("John Espino")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2018")])]

#text("Would you be able to provide more information on where I can find this relation?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/457aab69fb8349551d9071521e6adf5d7a4f5d5588ee3c2b1d265d0fde90f636-58a22c35f6ead2020417cc243f471d516bcf64dfecc6a3132a657becb176ec0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Overholt")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32661")[#strong[#text("Marius Overholt")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("The constant in (4) is ")#mi("\\log(2) + \\epsilon")#text(". This is due to the Swedish mathematician Severin Wigert around 1908. There is a multiplicative constant ")#mi("c_k")#text(" in Ramanujan’s asymptotic relation for the summatory function of ")#mi("d(n)^k")#text(", for example")

#mi("\\sum_{n \\leq x}d(n)^2 \\sim \\frac{1}{{\\pi}^2}x\\log^3(x).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5ab5db2f7a432411e3fd5aeff0ba4725fbccb03c97b4dbfbae0703923d9f7cd-ad7daca1bca2f42cec03afa9fc426d34a3bc0df52024aca58cf3f3da00063889.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald Hanche-Olsen")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32662")[#strong[#text("Harald Hanche-Olsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("On a (much) lighter note, I enjoyed (and was startled by) the reference to Malthus that you casually threw in there. As I teach elementary calculus this year, I have an opportunity to steal this idea in order to enliven the subject a bit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32664")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2008")])]

#text("Yes, I had indeed forgotten the leading constant in the asymptotic formula of Ramanujan…")

#text("I just checked in Tenenbaum’s book that, as suspected, there is an asymptotic formula (with suitable leading constant again) for all complex powers of ")#mi("d(n)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32665")[#strong[#text("The Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2008")])]

#text("Not that much related – but enjoyable. Given a positive integer ")#mi("a")#text(", construct recursively a sequence with the first term ")#mi("a")#text(" and")#linebreak()#text(" each subsequent term equal to the number of divisors of the previous")#linebreak()#text(" term: ")#mi("a,d(a),d(d(a)),d(d(d(a))),...")#text(" What is the set of those")#linebreak()#text(" ")#mi("a")#text(" such that this sequence does not contain a square?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82ffbf8eaa7a250a781ebcf19edb106eebc0b0c2407d1ee738571b48833de6f5-93eac67c2d0fb68768fc575653f4126207e9bba19c8a3d50bbae6d0375b144ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-479270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("Null set ! it will eventually end with a 2 , and if the term before is an odd prime ,it has definitely from a perfect square …")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDE")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32669")[#strong[#text("PDE")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2008")])]

#text("Prof. Tao:")

#text("Could you give a more specific application of the divisor bound in PDEs?")

#text("Many thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32675")[#strong[#text("Giovanni")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2008")])]

#text("Dear Prof. Tao")

#text("What do you think about a relation with p-adic analysis ?")

#text("Best regards")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f25cfe2e0171970212c1b595a209ebbd956d579ee413a8a7323fecc39d50bc9d-943d6efe2ee974645653eed52575c4e69048f0a8aea99a85a6c257fef9499ff2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Montuerto")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32676")[#strong[#text("Jaime Montuerto")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2008")])]

#text("Jaime Montuerto")#linebreak()#text(" Prime Number Distributions")

#text("26 Sept 2008")

#text("Dear Terry and Ben,")

#text("I have a hypothesis that might interest you both and related to this area. I have been interested in factoring algorithms and")#linebreak()#text(" related areas in number theory, although I’m not sure how elementary or obvious it might seem because there are so many")#linebreak()#text(" references about this. I do not know how to write this in the formalized way that you all are familiar with so please bear with me")#linebreak()#text(" about this. So I will call it a hypothesis.")

#text("The hypothesis is that every Mersenne number has at least one prime number in a one-to-one mapping with it and that the caliper signature (my term, explained below) of that prime number is the order of the Mersenne. Putting it differently, every prime number divides a unique smallest mersenne and the definition of caliper signature is the order of that mersenne.")

#text("A prime Mersenne number is the actual prime itself. A composite Mersenne would have at least two factors or more. The special prime number in question has a unique property compared to the rest of the prime factors.")

#text("This caliper signature is a function very much related to Euler totient functions and Carmichael functions with a subtle but very important difference. The analysis is done in binary numbers or multiple of 2’s. This is where this function makes sense and also applies only to odd numbers. To handle even numbers, you just factor out the 2^k factor and consider the odd factor for analysis.")

#text("Here are some of the related properties of the Caliper Signature (J): (Note: the equal sign is actually a congruence relation)")

#text("a^(p-1) = 1 (mod p) By Fermat")#linebreak()#text(" a^phi(p) = 1 (mod p) By Euler")#linebreak()#text(" a^Y(p) = 1 (mod p) By Carmichael early 20th")#linebreak()#text(" 2^phi(p) = 1 (mod p) By Boniakovsky 19th")

#text("2^J(p) = 1 (mod p) the Caliper Signature Hypothesis.")

#text("1) J(p) | phi(p) Then a prime number or pseudoprimes. And an extra test for pseudoprimes and carmichael numbers.")

#text("2) J(abc..) = LCM{a,b,c,…} This is similar to Carmichael numbers for the composite numbers.")

#text("3) J(a^e1 * b^e2 * c^e3 * …) = LCM{J(a),a^(e1-1),J(b),b^(e2-1),J(c),c^(e3-1),….}")

#text("Again this is different from both totient and Carmichael functions.")

#text("3) J(Mersenne) = order or width of the Mersenne.")

#text("This is where it differs from both totient and carmichael functions, the caliper signature is half of both. This is can be done by algorithmic calculation. There are several algorithms I have been developing.")

#text("4) Algorithm for calculating Caliper Signature of an integer, N.")

#text("I think this is the simplest and elegant one, and though it’s not the most efficient it’s a beautiful algorithm. The remainders will cycle back to 1.")

#text("a) Starting from 1 as first remainder, double it.")#linebreak()#text(" b) If the result is more than N, subtract/remove N. This is the mod operation.")#linebreak()#text(" c) Double again the resulting remainder.")#linebreak()#text(" d) Repeat the process until the remainder 1 is reached. This is the end of the cycle.")#linebreak()#text(" e) Count the number of processes or doublings, and that is the Caliper Signature.")

#text("e.g. I used the convention of starting at the right side as LSB (least significant bit). Also the number Mersenne 4 (M4) is the order not the actual value. So 7 is M3, where the 3 is the caliper signature or the order of mersenne.")

#text("N= 11 J= 10 12->1,6,14->3,18->7,20->9,10,16->5,8,4,2,1")#linebreak()#text(" {1,6,3,7,9,10,5,8,4,2,1}")

#text("N= 15 J= 4 {1,8,4,2,1}")

#text("N= 3 J= 2 {1,2,1}")#linebreak()#text(" Both 3 and 5 are factors of M4 = 15 but only 5 has")#linebreak()#text(" N= 5 J= 4 {1,4,2,1}")

#text("N= 23 J= 11 {1,12,6,3,13,18,9,16,8,4,2,1}")#linebreak()#text(" N= 89 J= 11 {1,45,67,78,39,64,32,16,8,4,2,1}")

#text("N= 7 J= 3 {1,4,2,1}")

#text("N= 17 J= 8 {1,9,13,15,16,8,4,2,1} This is Fermat number.")

#text("Fermat numbers have a special quick formulation J(Fermat number,Fn= a^n + 1) = 2*n.")

#text("Applications of Caliper Signature:")

#text("The caliper signature has deeper connections with number theory. Its binary number operation is important because there is an inherent property that does not appear in other number systems, though this id not saying that other bases or models are not important. First it makes sense only in the binary system, but importantly this system shows, I believe, natural formation and patterns of properties let alone the one-to-one mapping of the binary system to the number system.")

#text("Some of the most important properties of this hypothesis are the determination of primes distribution, the calculations of numbers of divisors, primality tests specially on pseudo primes and carmichael numbers test and possibly binary bits compression.")

#text("A. PRIME NUMBER DISTRIBUTION:")

#text("Mersenne numbers are so vital and central to this hypothesis. Such that every prime number is linked to a specific Mersenne so that, given a mersenne, there is an algorithmic process to find THE prime number and vice versa. This might shed light on the enigma of prime distributions. It’s explicit in the hypothesis that ALL mersennes give off one or more primes, and there is a one-to-one mapping of this relationship. Every prime number is mapped singly to a specific mersenne but not the other way around. Mersenne M11 gives 23 and 89 as prime numbers. So both 23 and 89 have caliper signature of 11 (see above example). Importantly, not all prime factors of composite mersennes have the same caliper signature of the mersenne. The prime factor/s that have caliper signatures of the order of mersenne are the ones of interest in the prime distribution.")

#text("Since all primes are linked to a specific mersenne, it follows then that the distribution of prime numbers is directly linked to the distribution of all mersennes in progression. The progression of mersennes is a recurrence relation that is Mnext = 2*Mprevious + 1, 15 = 2*7 + 1. This distribution of mersennes fits neatly to the statistic distribution, prime number theorem and Gauss estimates of logx. Now what’s really interesting is that the ordering of values of primes does not follow the ordering sizes of its corresponding mersennes. Sometimes a bigger mersenne has a much lower prime association than a few order smaller mersennes. This behaviour that made the prime distribution seems paradodixal and chaotic. And this mechanism explains why twin primes and clustering of primes are possible. Again the relationship of neighboring mersennes doubles its neighbor but the primes lag more often to its")#linebreak()#text(" mersennes. Some mersennes have several primes and perhaps as the mersenne get bigger, it might have more primes in it, and this affects the density of primes, given a range.")

#text("TERRY, when you were here last at SYdney University a few months ago giving your lecture, I was honored to meet and talk to you/ In fact I tried to explain this to you at that time but everyone was wanting to talk to you and there was not time to explain fully. Though I was pleased to be able to canvas what I did at the time. I tried to show the list of first set of mersennes with their corresponding primes.")

#text("And here it is – a very small list but.")

#text("Mersenne -> the prime number link.")

#text("{M1=>1, M2=>3, M3->7, M4->5, M5->31, M6->* (strictly 3), M7->127, M8->17, M9->73, M10->11, M11->23 and 89,")

#text("M12->13, M13->8191, M14->43, M15->151, M16->257, M17->131071, M18->19, M19->524287, M20->41, M21->337, M22->683,")

#text("M23->47, M24->241, M25->601 and 1801, M26->2731, M27->262657, M28->29 and 113, M29->233, M30->331, ….}")

#text("I have been isolated about this for quite a while and it’s good to share this, specially on your blog. Thanks for this and I hope for any comments, corrections, questions and any other verifications that you feel you could make.")

#text("Thanks in anticipation")

#text("Jaime Montuerto")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32682")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2008")])]

#text("The precise bound ")#mi("d(n)\\leq n^{(\\log 2+o(1))/\\log\\log n}")#text(" was first proved by Wigert in 1906 using the prime number theorem, while Ramanujan in 1914 observed its elementary character. In fact we can prove the inequality even without knowing unique factorization! All we need to know is that ")#mi("a|bc")#text(" and ")#mi("\\gcd(a,b)=1")#text(" imply ")#mi("a|c")#text(". This property implies ")#mi("d(mn)\\leq d(m)d(n)")#text(" as one can inject the set of divisors of ")#mi("mn")#text(" into the set of pairs formed of a divisor of ")#mi("m")#text(" and a divisor of ")#mi("n")#text(": to ")#mi("u|mn")#text(" assign the pair ")#mi("(\\gcd(u,m),u/\\gcd(u,m))")#text(". Once we know ")#mi("d(mn)\\leq d(m)d(n)")#text(" we can see for any positive integer ")#mi("k")#text(" that ")#mi("\\sum_{m\\leq n}d(m)^k/m\\leq (\\sum_{m\\leq n}d(m)^{k-1}/m)^2")#text(". It follows that ")#mi("\\sum_{m\\leq n}d(m)^k/m\\leq (\\sum_{m\\leq n}1/m)^{2^k}")#text(", whence also ")#mi("d(n)\\leq n^{1/k}(\\log(3n))^{2^k/k}")#text(". Now the second exponent ")#mi("2^k/k")#text(" changes by a factor less than 2 whenever ")#mi("k")#text(" is increased by 1, so we can certainly find a ")#mi("k")#text(" with ")#mi("2^k/k\\asymp\\log(n)/(\\log\\log n)^3")#text(". This choice furnishes Wigert’s estimate upon observing that ")#mi("1/k=(\\log 2+o(1))/\\log\\log n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32684")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2008")])]

#text("Dear Ben,")

#text("Your question is very close to that of counting lattice points on (or very close to) a generic curve (in this case, a hyperbola). There is an example of Jarnik of a curve in ")#mi("{}[1,N] \\times [1,N]")#text(" that passes through about ")#mi("N^{1/3}")#text(" lattice points despite having curvature uniformly bounded from below, so in analogy to this, I would not expect any bounds better than ")#mi("N^{1/6}")#text(" for your problem (given that the hyperbola ")#mi("\\{ (x+\\theta) (y+\\theta) = N \\}")#text(" spends some time in a square of length about ")#mi("\\sqrt{N}")#text(") without using some additional arithmetic structure in the problem (if such exists).")

#text("Dear PDE,")

#text("The divisor bound is used to establish ")#mi("L^p")#text(" type bounds for solutions to linear PDE on periodic domains (and hence to certain nonlinear PDE, by standard perturbation theory techniques). This was noticed in particular by Bourgain around 1991. As an example, a periodic solution to the Airy equation ")#mi("u_t + u_{xxx} = 0")#text(" takes the form ")#mi("u(t,x) = \\sum_n a_n e^{2\\pi i (n x + n^3 t)}")#text(". Typically, one has ")#mi("L^2")#text(" type control on ")#mi("u")#text(", which by Plancherel’s theorem leads to ")#mi("l^2")#text(" type control on the coefficients ")#mi("a_n")#text(". If one wished to compute, say, the ")#mi("L^6_{t,x}")#text(" norm of u (say on a bounded time interval), standard Fourier analysis and Cauchy-Schwarz manipulations eventually lead one to controlling the multiplicity of solutions ")#mi("(n_1,n_2,n_3)")#text(" to the problem ")#mi("n_1+n_2+n_3=a")#text(", ")#mi("n_1^3+n_2^3+n_3^3=b")#text(" for various a, b. It turns out that by some high school algebra similar to that at the end of my post, and in particular by using the identity")

#mi("(n_1+n_2+n_3)^3 - n_1^3 - n_2^3 - n_3^3 = 3 (n_1+n_2) (n_1+n_3) (n_2+n_3)")#text(",")

#text("one can control this multiplicity using the divisor bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32697")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2008")])]

#text("Is there a geometric analog of the divisor bound for curves over finite fields? E.g. a way to bound the no. of ideals that contain a given polynomial.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-32701")[#strong[#text("The divisor bound ( from T.Tao ’s blog ) « Khatuanminh’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2008")]

#text("[…] 23 September, 2008 at 6:39 pm […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dilettante Arithmetician")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-35552")[#strong[#text("Dilettante Arithmetician")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2009")])]

#text("Prof. Tao,")

#text("I am a graduate student and found this article very informative. I am getting a taste of analytic number theory from your and Kowalski’s blogs.")

#text("I would be indebted to you if it is possible for you to write up a similar blog post about the Weil bound for Kloosterman sums, in a similar lucid style.")

#text("Thanks,")#linebreak()#text(" g.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05e698325003fae8671f9fda2a14e50de0fd9e5f132870cb043f265d2b1cb39e-f3bc27f69b64813f842a0714308350dce3ed0ada7434b4ee79cf781f34105601.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raitis")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-46525")[#strong[#text("Raitis")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2010")])]

#text("Does anybody know better estimates of ")#mi("d(n)")#text(" than classical S. Wigert’s result obtained in 1906? Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c09fba6f648ea4acea364d32f2bfad4d46e552b7a5dea9b93eda309abfb6bbff-f03c5460e748d6d7c8ab5fa544708d03b72ac8cdc40ef151e41d344337764b5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-47941")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2010")])]

#text("Better estimates for d(n) appear in my MSC thesis (from 1984) at the Technion. For example, by the exponent ")#mi("(\\log 2/\\log \\log n)*(1+c/\\log \\log n)")#linebreak()#text(" where c=2 is permissible but can’t be reduced to c=1.93")#linebreak()#text(" Moreover, by assuming Riemann hypothesis, an asymptotic expansion for the exponent in terms of negative powers of log log n where derived.")#linebreak()#text(" Similarly, the constant ")#mi("C_\\epsilon")#text(" is less than ")#mi("c*(\\epsilon^2)*2^{1/\\epsilon}")#linebreak()#text(" where c=3 is permissible but can’t be reduced to c=2.795")#linebreak()#text(" Related information may be found in the doctoral thesis (from 1983) of Guy Robin.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c09fba6f648ea4acea364d32f2bfad4d46e552b7a5dea9b93eda309abfb6bbff-f03c5460e748d6d7c8ab5fa544708d03b72ac8cdc40ef151e41d344337764b5a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-47968")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("Some corrections to my last comment:")

#text("1. ")#mi("C_\\epsilon")#text(" should be replaced by ")#mi("\\log C_\\epsilon")#text(".")

#text("2. The asymptotic expansion for the exponent was found by an elementary method (using only the prime number theorem with simple remainder term)")#linebreak()#text(" Similar asymptotic expansion was found for ")#mi("\\log C_\\epsilon")#text(" in terms of powers of ")#mi("\\epsilon")#text(" – also by an elementary method.")#linebreak()#text(" By assuming Riemann hypothesis, only the remainder term can be improved.")

#text("3. The first (analytic) proof for asymptotic expansions (with remainder term) for sums of powers of d(n) was apparently given by B. M. Wilson in his paper “Proofs of some formulae enunciated by Ramanujan” Proc. London Math. Soc. (2) 21 (1922), 235-255.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/05e698325003fae8671f9fda2a14e50de0fd9e5f132870cb043f265d2b1cb39e-f3bc27f69b64813f842a0714308350dce3ed0ada7434b4ee79cf781f34105601.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raitis Ozols")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-48035")[#strong[#text("Raitis Ozols")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2010")])]

#text("Thank You!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the number of solutions to 4/p = 1/n_1 + 1/n_2 + 1/n_3 « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-55198")[#strong[#text("On the number of solutions to 4/p = 1/n_1 + 1/n_2 + 1/n_3 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2011")])]

#text("[…] familiar with analytic number theory will recognise the right-hand side from the divisor bound, which indeed plays a role in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos’ divisor bound « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-59953")[#strong[#text("Erdos’ divisor bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("[…] of some error terms in the proof of (6). These should be compared with what one can obtain from the divisor bound and the trivial bound , giving the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Counting the number of solutions to the Erdös-Straus equation on unit fractions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-62344")[#strong[#text("Counting the number of solutions to the Erdös-Straus equation on unit fractions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2011")])]

#text("[…] torsor of the Cayley surface.) By optimising between these parameterisations and exploiting the divisor bound, we obtain some bounds on the worst-case behaviour of and , […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-116201")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")])]

#text("[…] such , the number of with and is . For each fixed and , the expression is of size ; by the divisor bound, there are thus ways to factor into . Thus, we obtain a final bound […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-116210")[#strong[#text("254B, Notes 3: Quasirandom groups, expansion, and Selberg’s 3/16 theorem | t1u")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2011")]

#text("[…] such , the number of with and is . For each fixed and , the expression is of size ; by the divisor bound, there are thus ways to factor into . Thus, we obtain a final bound […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The probabilistic heuristic justification of the ABC conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-172291")[#strong[#text("The probabilistic heuristic justification of the ABC conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2012")])]

#text("[…] to apply probabilistic heuristics to. For Step 3, we need the following lemma, reminiscent of the classical divisor bound: Lemma 3 Let be a square-free integer. Then there are at most integers less than with radical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-224557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2013")])]

#text("What’s known about the estimate on d(n, Q), the number of divisors of n less than Q? Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A combinatorial subset sum problem associated with bounded prime gaps | What's new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-233903")[#strong[#text("A combinatorial subset sum problem associated with bounded prime gaps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("[…] (i.e. a Brun-Titchmarsh type inequality for powers of the divisor function); this estimate follows from this paper of Shiu or this paper of Barban-Vehov, and can also be proven using the methods in this previous blog post. (The factor of is needed to account for the possibility that is not primitive, while the term accounts for the possibility that is as large as .) Finally, (16) follows from the standard divisor bound; see this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type I and Type II sums | What's new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-234216")[#strong[#text("Estimation of the Type I and Type II sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("[…] and similarly (using the crude divisor bound) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-235687")[#strong[#text("Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("[…] , and said to be bounded if . Another convenient notation: we write for . Thus for instance the divisor bound asserts that if has polynomial size, then the number of divisors of is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-431193")[#strong[#text("A New Provable Factoring Algorithm | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2014")]

#text("[…] “” hides sub-linear terms including coming from the divisor bound, logarithmic terms from the overhead in nearly-linear time integer multiplication, and related […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d57d55e60f821c1d05e39e34c9f7770b30a9a51ebc94969c5c6db5cd7bae3144-2d1d60be21e3bf6a907ac9aa471919572194be3ccb33d6dbea29fe5343b9132d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hiklicepleh")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-452007")[#strong[#text("hiklicepleh")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2015")])]

#text("Dear Terence Tao,")#linebreak()#text(" Without assuming the Riemann hypothesis, Robin revealed – ")#mi("\\displaystyle \\sum_{d|n} d < {e}^{\\gamma}n \\log \\log n + \\frac{0.6483n}{\\log\\log n}")#linebreak()#text(" for all ")#mi("\\displaystyle n \\geq 3")#linebreak()#text(" ")#mi("\\displaystyle d(n)")#text(" – number of divisors of ")#mi("\\displaystyle n")#text(".")#linebreak()#text(" Now apply some tricks.")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{d|n} d = \\sum_{d|n} \\frac{n}{d}")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{d|n} \\frac{1}{d} \\leq \\sum_{d \\leq d(n)} \\frac{1}{d}")#linebreak()#text(" And finally, ")#mi("\\displaystyle d(n) < \\log^{{e}^{\\gamma}+\\epsilon}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d57d55e60f821c1d05e39e34c9f7770b30a9a51ebc94969c5c6db5cd7bae3144-2d1d60be21e3bf6a907ac9aa471919572194be3ccb33d6dbea29fe5343b9132d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hiklicepleh")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-452037")[#strong[#text("hiklicepleh")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2015")])]

#text("Not sure where the error is. Could you tell?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-452056")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2015")])]

#text("There is an n missing in the last line, but more importantly, the inequalities do not go the right way (")#mi("A < B")#text(" and ")#mi("A \\leq C")#text(" do not imply ")#mi("B < C")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-454302")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2015")]

#strong[#text("What are some tight upper bounds on the number of factors of a number [math]n[/math]?")]

#text("Yes, we can do much better. Let [math]d(n)=\\sum_{d|n}1[/math] be the number of divisors of [math]n[/math]. Then not only is this number less than [math]n^{1/2}[/math] as you suggested, it is in fact less than [math]n^\\epsilon[/math] any positive [mat…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gninrepoli")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-457961")[#strong[#text("gninrepoli")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2015")])]

#text("What about the upper bound for the ")#mi("d_{k}(n)")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-458482")[#strong[#text("Heath-Brown’s theorem on prime twins and Siegel zeroes | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2015")])]

#text("[…] if one replaces with for . For fixed , the number of such pairs is at least , thanks to the divisor bound. Thus it will suffice to establish the fourth moment […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Erdos discrepancy problem via the Elliott conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-459082")[#strong[#text("The Erdos discrepancy problem via the Elliott conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2015")])]

#text("[…] or , the inner sum is , which by the divisor bound gives a negligible contribution. Thus we may restrict to . Note that as is already restricted to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The two-dimensional case of the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-463464")[#strong[#text("The two-dimensional case of the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("[…] when combined with the divisor bound, shows that each is associated to choices of excluding diagonal cases when two of the collide, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd38eb79dd005d5091b9b3c49f40aa47236e21b5345b6381eb83aeb04189483f-5365fee31be4687d5ae998e23aecae25e9205b8b4871e5cef48d4a499c1db808.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-506781")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2018")])]

#text("What about a bound for the number ")#mi("d_b(n)")#text(" of divisors of ")#mi("n")#text(" of size at most ")#mi("b")#text("? Given that ")#mi("\\text{lcm}\\{1, \\dots, b\\} = \\exp((1+o(1))b)")#text(", I would expect to get a nontrivial bound whenever ")#mi("b")#text(" is much smaller than ")#mi("\\log n")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-530880")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2019")])]

#text("Dear Prof. Tao,")

#text("Here is how I am looking at the argument:")#linebreak()#text(" 1) The divisors formed from large primes (primes> log n) are at most exp( logn/loglogn) –because there are at most logn/loglogn such prime factors. This corresponds to your truncation $p> exp(1/\\epsilon)$")#linebreak()#text(" 2) And for small primes also you get the same bound. But in your argument, this happens by comparing with n^\\epsilon where you start with d(n)/n^\\epsilon and show that these quantities are bounded by 1/epsilon logp and using mutliplicativity.")#linebreak()#text(" If I want to bound it without the comparison with the n^{\\epsilon}, what kind of argument do we need to deal with the small primes?")#linebreak()#text(" If I can somehow argue that the worst case is when you have product of all these small primes, –you have logn/loglogn of them and hence the number of divisors is exp(O(logn/loglogn). But in the prime factorization there could be a high multiplicity of say very small primes by sacrificing a slightly large prime, or a high multiplicity for a prime by sacrificing a lot of small primes and these cases might potentially give more divisors.(Not true, but how do we see this?)")#linebreak()#text(" How do you think we can see this? Basically I want to “see” the following part of the bound without the comparison with n^{epsilon} and somehow directly argue that divisors from small prime factors are not too many. (I need this for reasons having to deal with “level” lowering trick in a problem involving divisors– I want to know how these n^{\\epsilon} is “seeing” the small prime factors of n )")

#tao-fit-display[#mitex("\\frac{a_j+1}{p_j^{\\varepsilon a_j}} \\leq \\frac{a_j+1}{1+\\varepsilon a_j \\log p_j} \\leq O( \\frac{1}{\\varepsilon \\log p_j} )” title=”\\displaystyle \\frac{a_j+1}{p_j^{\\varepsilon a_j}} \\leq \\frac{a_j+1}{1+\\varepsilon a_j \\log p_j} \\leq O( \\frac{1}{\\varepsilon \\log p_j} )")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-530881")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2019")])]

#text("We could just say that we bound (k+1) by loglogn/log p p^{k/loglogn} — and then apply multiplicativity– But what does this bound mean? Why are bounding the divisors from a fixed prime factor in terms of a quantity that again involving the contribution from the prime factor ? 9Yes, the bounds multiply to become n^{1/loglogn}– but still– what is happening here? What kind of argument is it?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/25690ae895f20a58d0b57914861dbb49bfe662b949364062c4df69af6b5e48b2-c889e1941410cf89e1392b7ce3b2001d740cf668bf1104f1d28dffcc1800b7ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo Nogueira")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-542168")[#strong[#text("Marcelo Nogueira")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")])]

#text("Dear Prof. Tao, as discussed above, to get satisfactory bounds")#linebreak()#text(" (i.e., of the form ")#mi("O(N^{\\alpha})")#text(", ")#mi("\\alpha 0")#text(", is a complicated problem.")

#text("It is possible to use some idea by mean of the")#linebreak()#text(" Decoupling Theorems (Bourgain-Demeter) to obtain satisfactory bounds to the sets ")#mi("X_{ab}")#text(" above?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-542170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2020")])]

#text("Remark:")

#tao-math("X_{a,b}= \\{ (x, y) \\in \\mathbb{Z}^2; \\left|x\\right|, \\left|y\\right| \\leq N \\; \\text{ and } a x^2 - b y^2 = L\\}", block: false)

#text("where ")#mi("a, b, L >0")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/#comment-670805")[#strong[#text("asymptotic form of divisor bound – Mathematics – Forum")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2022")]

#text("[…] $d(n)$ denote the divisor function, the number of divisors of $n$. Following this post of Tao, ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")]#text(" I have managed to show that $d(n) leq C_{epsilon}n^{epsilon}$ for any $epsilon > […]")
]
