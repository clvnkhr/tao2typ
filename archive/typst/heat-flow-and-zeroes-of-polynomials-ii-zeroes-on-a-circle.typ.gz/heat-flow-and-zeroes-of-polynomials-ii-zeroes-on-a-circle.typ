// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/
// Converted to Typst by tao2typ: "2026-10-14T10:45:48.644615+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Heat flow and zeroes of polynomials II: zeroes on a circle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Heat flow and zeroes of polynomials II: zeroes on a circle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 June 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/")[#text("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a sequel to ")#link("https://terrytao.wordpress.com/2017/10/17/heat-flow-and-zeroes-of-polynomials/")[#text("this previous blog post")]#text(", in which we discussed the effect of the heat flow evolution")

#align(center)[#tao-fit-display[#mitex("\\partial_t P(t,z) = \\partial_{zz} P(t,z)")]]

#text("on the zeroes of a time-dependent family of polynomials ")#mi("{z \\mapsto P(t,z)}")#text(", with a particular focus on the case when the polynomials ")#mi("{z \\mapsto P(t,z)}")#text(" had real zeroes. Here (inspired by some discussions I had during a recent conference on the Riemann hypothesis in Bristol) we record the analogous theory in which the polynomials instead have zeroes on a circle ")#tao-math("{\\{ z: \\left|z\\right| = \\sqrt{q} \\}}", block: false)#text(", with the heat flow slightly adjusted to compensate for this. As we shall discuss shortly, a key example of this situation arises when ")#mi("{P}")#text(" is the numerator of the zeta function of a curve.")

#text("More precisely, let ")#mi("{g}")#text(" be a natural number. We will say that a polynomial")

#align(center)[#tao-fit-display[#mitex("P(z) = \\sum_{j=0}^{2g} a_j z^j")]]

#text("of degree ")#mi("{2g}")#text(" (so that ")#mi("{a_{2g} \\neq 0}")#text(") obeys the ")#emph[#text("functional equation")]#text(" if the ")#mi("{a_j}")#text(" are all real and")

#align(center)[#tao-fit-display[#mitex("a_j = q^{g-j} a_{2g-j}")]]

#text("for all ")#mi("{j=0,\\dots,2g}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("P(\\overline{z}) = \\overline{P(z)}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P(q/z) = q^g z^{-2g} P(z)")]]

#text("for all non-zero ")#mi("{z}")#text(". This means that the ")#mi("{2g}")#text(" zeroes ")#mi("{\\alpha_1,\\dots,\\alpha_{2g}}")#text(" of ")#mi("{P(z)}")#text(" (counting multiplicity) lie in ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" and are symmetric with respect to complex conjugation ")#mi("{z \\mapsto \\overline{z}}")#text(" and inversion ")#mi("{z \\mapsto q/z}")#text(" across the circle ")#tao-math("{\\{ \\left|z\\right| = \\sqrt{q}\\}}", block: false)#text(". We say that this polynomial ")#emph[#text("obeys the Riemann hypothesis")]#text(" if all of its zeroes actually lie on the circle ")#mi("{\\{ z = \\sqrt{q}\\}}")#text(". For instance, in the ")#mi("{g=1}")#text(" case, the polynomial ")#mi("{z^2 - a_1 z + q}")#text(" obeys the Riemann hypothesis if and only if ")#tao-math("{\\left|a_1\\right| \\leq 2\\sqrt{q}}", block: false)#text(".")

#text("Such polynomials arise in number theory as follows: if ")#mi("{C}")#text(" is a projective curve of genus ")#mi("{g}")#text(" over a finite field ")#mi("{\\mathbf{F}_q}")#text(", then, as ")#link("https://en.wikipedia.org/wiki/Weil_conjectures")[#text("famously proven by Weil")]#text(", the associated local zeta function ")#mi("{\\zeta_{C,q}(z)}")#text(" (as defined for instance in ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("this previous blog post")]#text(") is known to take the form")

#align(center)[#tao-fit-display[#mitex("\\zeta_{C,q}(z) = \\frac{P(z)}{(1-z)(1-qz)}")]]

#text("where ")#mi("{P}")#text(" is a degree ")#mi("{2g}")#text(" polynomial obeying both the functional equation and the Riemann hypothesis. In the case that ")#mi("{C}")#text(" is an elliptic curve, then ")#mi("{g=1}")#text(" and ")#mi("{P}")#text(" takes the form ")#mi("{P(z) = z^2 - a_1 z + q}")#text(", where ")#mi("{a_1}")#text(" is the number of ")#mi("{{\\bf F}_q}")#text("-points of ")#mi("{C}")#text(" minus ")#mi("{q+1}")#text(". The Riemann hypothesis in this case is a ")#link("https://en.wikipedia.org/wiki/Hasse%27s_theorem_on_elliptic_curves")[#text("famous result of Hasse")]#text(".")

#text("Another key example of such polynomials arise from rescaled characteristic polynomials ")#metadata(none) <tao-f629bcb2cb96adf89fe1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("P(z) := \\det( 1 - \\sqrt{q} F )")]]

#text("of ")#mi("{2g \\times 2g}")#text(" matrices ")#mi("{F}")#text(" in the ")#link("https://en.wikipedia.org/wiki/Symplectic_group#Sp(n)")[#text("compact symplectic group")]#text(" ")#mi("{Sp(g)}")#text(". These polynomials obey both the functional equation and the Riemann hypothesis. The ")#link("https://en.wikipedia.org/wiki/Sato%E2%80%93Tate_conjecture")[#text("Sato-Tate conjecture")]#text(" (in higher genus) asserts, roughly speaking, that “typical” polyomials ")#mi("{P}")#text(" arising from the number theoretic situation above are distributed like the rescaled characteristic polynomials ")#link(<tao-f629bcb2cb96adf89fe1>)[#text("(1)")]#text(", where ")#mi("{F}")#text(" is drawn uniformly from ")#mi("{Sp(g)}")#text(" with Haar measure.")

#text("Given a polynomial ")#mi("{z \\mapsto P(0,z)}")#text(" of degree ")#mi("{2g}")#text(" with coefficients")

#align(center)[#tao-fit-display[#mitex("P(0,z) = \\sum_{j=0}^{2g} a_j(0) z^j,")]]

#text("we can evolve it in time by the formula")

#align(center)[#tao-fit-display[#mitex("P(t,z) = \\sum_{j=0}^{2g} \\exp( t(j-g)^2 ) a_j(0) z^j,")]]

#text("thus ")#mi("{a_j(t) = \\exp(t(j-g)) a_j(0)}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(". Informally, as one increases ")#mi("{t}")#text(", this evolution accentuates the effect of the extreme monomials, particularly, ")#mi("{z^0}")#text(" and ")#mi("{z^{2g}}")#text(" at the expense of the intermediate monomials such as ")#mi("{z^g}")#text(", and conversely as one decreases ")#mi("{t}")#text(". This family of polynomials obeys the heat-type equation ")#metadata(none) <tao-9230471ebdabeae4d61c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial_t P(t,z) = (z \\partial_z - g)^2 P(t,z).")]]

#text("In view of ")#link("https://arxiv.org/abs/1504.00350")[#text("the results of Marcus, Spielman, and Srivastava")]#text(", it is also very likely that one can interpret this flow in terms of expected characteristic polynomials involving conjugation over the compact symplectic group ")#mi("{Sp(n)}")#text(", and should also be tied to some sort of “")#mi("{\\beta=\\infty}")#text("” version of Brownian motion on this group, but we have not attempted to work this connection out in detail.")

#text("It is clear that if ")#mi("{z \\mapsto P(0,z)}")#text(" obeys the functional equation, then so does ")#mi("{z \\mapsto P(t,z)}")#text(" for any other time ")#mi("{t}")#text(". Now we investigate the evolution of the zeroes. Suppose at some time ")#mi("{t_0}")#text(" that the zeroes ")#mi("{\\alpha_1(t_0),\\dots,\\alpha_{2g}(t_0)}")#text(" of ")#mi("{z \\mapsto P(t_0,z)}")#text(" are distinct, then")

#align(center)[#tao-fit-display[#mitex("P(t_0,z) = a_{2g}(0) \\exp( t_0g^2 ) \\prod_{j=1}^{2g} (z - \\alpha_j(t_0) ).")]]

#text("From the inverse function theorem we see that for times ")#mi("{t}")#text(" sufficiently close to ")#mi("{t_0}")#text(", the zeroes ")#mi("{\\alpha_1(t),\\dots,\\alpha_{2g}(t)}")#text(" of ")#mi("{z \\mapsto P(t,z)}")#text(" continue to be distinct (and vary smoothly in ")#mi("{t}")#text("), with")

#align(center)[#tao-fit-display[#mitex("P(t,z) = a_{2g}(0) \\exp( t g^2 ) \\prod_{j=1}^{2g} (z - \\alpha_j(t) ).")]]

#text("Differentiating this at any ")#mi("{z}")#text(" not equal to any of the ")#mi("{\\alpha_j(t)}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t P(t,z) = P(t,z) ( g^2 - \\sum_{j=1}^{2g} \\frac{\\alpha^{\\prime}_j(t)}{z - \\alpha_j(t)})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_z P(t,z) = P(t,z) ( \\sum_{j=1}^{2g} \\frac{1}{z - \\alpha_j(t)})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_{zz} P(t,z) = P(t,z) ( \\sum_{1 \\leq j,k \\leq 2g: j \\neq k} \\frac{1}{(z - \\alpha_j(t))(z - \\alpha_k(t))}).")]]

#text("Inserting these formulae into ")#link(<tao-9230471ebdabeae4d61c>)[#text("(2)")]#text(" (expanding ")#mi("{(z \\partial_z - g)^2}")#text(" as ")#mi("{z^2 \\partial_{zz} - (2g-1) z \\partial_z + g^2}")#text(") and canceling some terms, we conclude that")

#tao-aligned(keep: true)[


#tao-math("- \\sum_{j=1}^{2g} \\frac{\\alpha^{\\prime}_j(t)}{z - \\alpha_j(t)}  & = z^2 \\sum_{1 \\leq j,k \\leq 2g: j \\neq k} \\frac{1}{(z - \\alpha_j(t))(z - \\alpha_k(t))}", block: true)



#tao-math(" & - (2g-1) z \\sum_{j=1}^{2g} \\frac{1}{z - \\alpha_j(t)}", block: true)
]

#text("for ")#mi("{t}")#text(" sufficiently close to ")#mi("{t_0}")#text(", and ")#mi("{z}")#text(" not equal to ")#mi("{\\alpha_1(t),\\dots,\\alpha_{2g}(t)}")#text(". Extracting the residue at ")#mi("{z = \\alpha_j(t)}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("- \\alpha^{\\prime}_j(t) = 2 \\alpha_j(t)^2 \\sum_{1 \\leq k \\leq 2g: k \\neq j} \\frac{1}{\\alpha_j(t) - \\alpha_k(t)} - (2g-1) \\alpha_j(t)")]]

#text("which we can rearrange as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\alpha^{\\prime}_j(t)}{\\alpha_j(t)} = - \\sum_{1 \\leq k \\leq 2g: k \\neq j} \\frac{\\alpha_j(t)+\\alpha_k(t)}{\\alpha_j(t)-\\alpha_k(t)}.")]]

#text("If we make the change of variables ")#mi("{\\alpha_j(t) = \\sqrt{q} e^{i\\theta_j(t)}}")#text(" (noting that one can make ")#mi("{\\theta_j}")#text(" depend smoothly on ")#mi("{t}")#text(" for ")#mi("{t}")#text(" sufficiently close to ")#mi("{t_0}")#text("), this becomes ")#metadata(none) <tao-0d27a2aee8d6e2dac949>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t \\theta_j(t) = \\sum_{1 \\leq k \\leq 2g: k \\neq j} \\cot \\frac{\\theta_j(t) - \\theta_k(t)}{2}.")]]

#text("Intuitively, this equation asserts that the phases ")#mi("{\\theta_j}")#text(" repel each other if they are real (and attract each other if their difference is imaginary). If ")#mi("{z \\mapsto P(t_0,z)}")#text(" obeys the Riemann hypothesis, then the ")#mi("{\\theta_j}")#text(" are all real at time ")#mi("{t_0}")#text(", then the ")#link("https://en.wikipedia.org/wiki/Picard%E2%80%93Lindel%C3%B6f_theorem")[#text("Picard uniqueness theorem")]#text(" (applied to ")#mi("{\\theta_j(t)}")#text(" and its complex conjugate) then shows that the ")#mi("{\\theta_j}")#text(" are also real for ")#mi("{t}")#text(" sufficiently close to ")#mi("{t_0}")#text(". If we then define the entropy functional")

#align(center)[#tao-fit-display[#tao-math("H(\\theta_1,\\dots,\\theta_{2g}) := \\sum_{1 \\leq j < k \\leq 2g} \\log \\frac{1}{\\left|\\sin \\frac{\\theta_j-\\theta_k}{2}\\right| }", block: true)]]

#text("then the above equation becomes a gradient flow")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\theta_j(t) = - 2 \\frac{\\partial H}{\\partial \\theta_j}( \\theta_1(t),\\dots,\\theta_{2g}(t) )")]]

#text("which implies in particular that ")#mi("{H(\\theta_1(t),\\dots,\\theta_{2g}(t))}")#text(" is non-increasing in time. This shows that as one evolves time forward from ")#mi("{t_0}")#text(", there is a uniform lower bound on the separation between the phases ")#mi("{\\theta_1(t),\\dots,\\theta_{2g}(t)}")#text(", and hence the equation can be solved indefinitely; in particular, ")#mi("{z \\mapsto P(t,z)}")#text(" obeys the Riemann hypothesis for all ")#mi("{t > t_0}")#text(" if it does so at time ")#mi("{t_0}")#text(". Our argument here assumed that the zeroes of ")#mi("{z \\mapsto P(t_0,z)}")#text(" were simple, but this assumption can be removed by the usual limiting argument.")

#text("For any polynomial ")#mi("{z \\mapsto P(0,z)}")#text(" obeying the functional equation, the rescaled polynomials ")#mi("{z \\mapsto e^{-g^2 t} P(t,z)}")#text(" converge locally uniformly to ")#mi("{a_{2g}(0) (z^{2g} + q^g)}")#text(" as ")#mi("{t \\rightarrow +\\infty}")#text(". By Rouche’s theorem, we conclude that the zeroes of ")#mi("{z \\mapsto P(t,z)}")#text(" converge to the equally spaced points ")#mi("{\\{ e^{2\\pi i(j+1/2)/2g}: j=1,\\dots,2g\\}}")#text(" on the circle ")#tao-math("{\\{ \\left|z\\right| = \\sqrt{q}\\}}", block: false)#text(". Together with the symmetry properties of the zeroes, this implies in particular that ")#mi("{z \\mapsto P(t,z)}")#text(" obeys the Riemann hypothesis for all sufficiently large positive ")#mi("{t}")#text(". In the opposite direction, when ")#mi("{t \\rightarrow -\\infty}")#text(", the polynomials ")#mi("{z \\mapsto P(t,z)}")#text(" converge locally uniformly to ")#mi("{a_g(0) z^g}")#text(", so if ")#mi("{a_g(0) \\neq 0}")#text(", ")#mi("{g}")#text(" of the zeroes converge to the origin and the other ")#mi("{g}")#text(" converge to infinity. In particular, ")#mi("{z \\mapsto P(t,z)}")#text(" fails the Riemann hypothesis for sufficiently large negative ")#mi("{t}")#text(". Thus (if ")#mi("{a_g(0) \\neq 0}")#text("), there must exist a real number ")#mi("{\\Lambda}")#text(", which we call the ")#emph[#text("de Bruijn-Newman constant")]#text(" of the original polynomial ")#mi("{z \\mapsto P(0,z)}")#text(", such that ")#mi("{z \\mapsto P(t,z)}")#text(" obeys the Riemann hypothesis for ")#mi("{t \\geq \\Lambda}")#text(" and fails the Riemann hypothesis for ")#mi("{t < \\Lambda}")#text(". The situation is a bit more complicated if ")#mi("{a_g(0)}")#text(" vanishes; if ")#mi("{k}")#text(" is the first natural number such that ")#mi("{a_{g+k}(0)}")#text(" (or equivalently, ")#mi("{a_{g-j}(0)}")#text(") does not vanish, then by the above arguments one finds in the limit ")#mi("{t \\rightarrow -\\infty}")#text(" that ")#mi("{g-k}")#text(" of the zeroes go to the origin, ")#mi("{g-k}")#text(" go to infinity, and the remaining ")#mi("{2k}")#text(" zeroes converge to the equally spaced points ")#mi("{\\{ e^{2\\pi i(j+1/2)/2k}: j=1,\\dots,2k\\}}")#text(". In this case the de Bruijn-Newman constant remains finite except in the degenerate case ")#mi("{k=g}")#text(", in which case ")#mi("{\\Lambda = -\\infty}")#text(".")

#text("For instance, consider the case when ")#mi("{g=1}")#text(" and ")#mi("{P(0,z) = z^2 - a_1 z + q}")#text(" for some real ")#mi("{a_1}")#text(" with ")#tao-math("{\\left|a_1\\right| \\leq 2\\sqrt{q}}", block: false)#text(". Then the quadratic polynomial")

#align(center)[#tao-fit-display[#mitex("P(t,z) = e^t z^2 - a_1 z + e^t q")]]

#text("has zeroes")

#align(center)[#tao-fit-display[#mitex("\\frac{a_1 \\pm \\sqrt{a_1^2 - 4 e^{2t} q}}{2e^t}")]]

#text("and one easily checks that these zeroes lie on the circle ")#tao-math("{\\{ \\left|z\\right|=\\sqrt{q}\\}}", block: false)#text(" when ")#tao-math("{t \\geq \\log \\frac{\\left|a_1\\right|}{2\\sqrt{q}}}", block: false)#text(", and are on the real axis otherwise. Thus in this case we have ")#tao-math("{\\Lambda = \\log \\frac{\\left|a_1\\right|}{2\\sqrt{q}}}", block: false)#text(" (with ")#mi("{\\Lambda=-\\infty}")#text(" if ")#mi("{a_1=0}")#text("). Note how as ")#mi("{t}")#text(" increases to ")#mi("{+\\infty}")#text(", the zeroes repel each other and eventually converge to ")#mi("{\\pm i \\sqrt{q}}")#text(", while as ")#mi("{t}")#text(" decreases to ")#mi("{-\\infty}")#text(", the zeroes collide and then separate on the real axis, with one zero going to the origin and the other to infinity.")

#text("The arguments in my paper with Brad Rodgers (discussed in ")#link("https://terrytao.wordpress.com/2018/01/19/the-de-bruijn-newman-constant-is-non-negativ/")[#text("this previous post")]#text(") indicate that for a “typical” polynomial ")#mi("{P}")#text(" of degree ")#mi("{g}")#text(" that obeys the Riemann hypothesis, the expected time to relaxation to equilibrium (in which the zeroes are equally spaced) should be comparable to ")#mi("{1/g}")#text(", basically because the average spacing is ")#mi("{1/g}")#text(" and hence by ")#link(<tao-0d27a2aee8d6e2dac949>)[#text("(3)")]#text(" the typical velocity of the zeroes should be comparable to ")#mi("{g}")#text(", and the diameter of the unit circle is comparable to ")#mi("{1}")#text(", thus requiring time comparable to ")#mi("{1/g}")#text(" to reach equilibrium. Taking contrapositives, this suggests that the de Bruijn-Newman constant ")#mi("{\\Lambda}")#text(" should typically take on values comparable to ")#mi("{-1/g}")#text(" (since typically one would not expect the initial configuration of zeroes to be close to evenly spaced). I have not attempted to formalise or prove this claim, but presumably one could do some numerics (perhaps using some of the examples of ")#mi("{P}")#text(" given previously) to explore this further.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-501385")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2018")])]

#text("It seems that Riemann zeta function (whose zeros are pseudo-randomly distributed) can’t be interpreted (in any sense) as some “limiting case” of the above local zeta functions (having uniformly distributed zeros.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65179a0a2990cb3f202e42ff1cdc130a3591fd28db1db8b4ec50447a9226f910-3e6a66333d973b31582e529a16574a0a01d2832ac78c4f7cde55659737f5dcef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-501447")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2018")])]

#text("I would have the intuition that maybe the value of ")#mi("\\Lambda")#text(" should be closer to zero than ")#mi("-1/g")#text(" because of the zeros which are close to each other: if the closest pair of zeros has distance ")#mi("d")#text(" and if we run the flow backwards, then they attract each other with speed about ")#mi("1/d")#text(", and then would collide at time about ")#mi("d^2")#text(" if we neglect the other zeros (which are at much larger distance). For characteristic polynomial of ")#mi("CUE")#text(" where ")#mi("d")#text(" has order ")#mi("g^{-4/3}")#text(", I would expect ")#mi("\\Lambda")#text(" of about ")#mi("-g^{-8/3}")#text(" if my intuition is correct.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-501474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2018")])]

#text("Hmm, I think you’re right; the time to relaxation to equilibrium gives a lower bound on ")#mi("\\Lambda")#text(" but it is far from optimal.")

#text("In the case of zeroes on the real line, there is a criterion of Csordas, Smith and Varga (see Theorem 1 of ")#link("https://link.springer.com/article/10.1007/BF01205170")[#text("https://link.springer.com/article/10.1007/BF01205170")]#text(" ) that says, roughly speaking, that if one has a pair of zeroes at separation ")#mi("d")#text(", and the other zeroes are significantly further away from this pair than ")#mi("d")#text(", then ")#mi("\\Lambda \\geq -c/d^2")#text(". It may well be that an analogous result holds on the circle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65179a0a2990cb3f202e42ff1cdc130a3591fd28db1db8b4ec50447a9226f910-3e6a66333d973b31582e529a16574a0a01d2832ac78c4f7cde55659737f5dcef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-501496")[#strong[#text("Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2018")])]

#text("I think it is equivalent to have points on the circle or all the determinations of their arguments on the real line (which gives a ")#mi("2 \\pi")#text("-periodic set), because of the formula ")#mi("(1/2) \\cot (x/2) = \\sum_{k \\in \\mathbb{Z}} 1/(x-k)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-501476")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2018")])]

#text("The third display above (3) is too wide.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-501479")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2018")])]

#text("It should possible to obtain the “time to relaxation” upper bound using only the middle coefficient. It has variance ")#mi("\\lfloor g/2\\rfloor +1")#text(", so it is presumably typically of size ")#mi("\\approx  \\sqrt{g/2}")#text(", meaning at time ")#mi("-2 \\log 2 /g")#text(", it is of size ")#mi("\\approx 2^{ 2 g}")#text(" compared to the first and last coefficients, compared to the bound ")#mi("{2g \\choose g} \\leq 2^{2g}")#text(" for polynomials with all roots on the unit circle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-501734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2018")])]

#text("Dear Terry,")#linebreak()#text(" I am not an expert mathematician.But I think the Riemann’s difficult level is 5 times more than Poincare.Because one only needs one way to go to the destination,Riemann must has 5 ways done:straight and then go back,attack the middle point,the first point and then the final point.And not enough, you must go with the first step on the old road many times.I know Terry very well.Someday not so long,the community of maths has amusing news from Terry.")#linebreak()#text(" Best wishes,")#linebreak()#text(" (Company of Pro.Tao -two decades)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/644708a37ad48d1e5cbd2d36dedfa9c0ff955e0805dc868d5e897da67e7b7dc7-94d2ea3a8a07e14c36ae8110096e78c755a5494a0ae9d746642939e3495301d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of curious")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-502132")[#strong[#text("curious")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2018")])]

#text("Does the entropy here have anything do with information?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tatenda Kubalalika")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-503997")[#strong[#text("Tatenda Kubalalika")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("Dear Prof. Tao, according to equation ")#mi("(15)")#text(" of your paper with Prof. Rodgers, “the de Bruijn-newman constant is nonnegative”, the de Bruijn-Newman constant seems to be equal to ")#mi("0")#text(".")

#text("Indeed, for ")#mi("t<0")#text(", we have")

#tao-math("\\displaystyle H_{t}(z)=\\frac{1}{\\sqrt{4\\pi}}\\int_{\\mathbb{R}} e^{-r^{2}/4}H_{0}(z+r\\left|t\\right|^{1/2}) \\mathrm{d}r. \\quad (1)", block: false)

#text("Notice that the right-hand side is invariant under the transformation ")#mi("t\\mapsto -t")#text(", thus we have")

#mi("\\displaystyle H_{t}(z)=H_{-t}(z) \\quad (2)")

#text("for all ")#mi("t\\neq 0")#text(". Suppose that ")#mi("H_{y}(z)=0")#text(" for some real ")#mi("y\\neq 0")#text(" hence ")#mi("H_{-y}(z)=0")#text(". But we know by a result of Rodgers and Tao that ")#mi("H_{Y}(z) \\neq 0")#text(" for any ")#mi("Y<0")#text(" and ")#mi("z\\in \\mathbb{R}")#text(". Thus we arrive at a contradiction,, which entails that our supposition must be false, and the desired result follows. ")#mi("\\square")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504000")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("Unfortunately, the identity (1) is only valid for ")#mi("t \\leq 0")#text(" (as you point out), hence the identity (2) is only valid when ")#mi("t, -t \\leq 0")#text(", that is to say it is only established in the case ")#mi("t=0")#text(" (where it is trivial). Actually, one can check numerically that (2) is false in general.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("Since in (1) (for ")#mi("t < 0")#text(") ")#tao-math("\\left|t\\right|", block: false)#text(" can be replaced by ")#mi("-t")#text(", is it possible that this modification of (1) (with the resulting branch point at ")#mi("t=0")#text(" due to ")#mi("(-t)^{1/2}")#text(") still holds for some analytic continuation (with respect to ")#mi("t")#text(") of the modified integral ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504041")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2018")])]

#text("For positive t, one has")

#tao-math("\\displaystyle H_t(z) = \\frac{1}{\\sqrt{4\\pi}} \\int_{\\bf R} e^{-r^2/4} H_0(z + ir\\left|t\\right|^{1/2})\\ dr;", block: false)

#text("(see the equation before (35) in ")#link("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")[#text("https://github.com/km-git-acc/dbn_upper_bound/blob/master/Writeup/debruijn.pdf")]#text(" ).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tatenda Kubalalika")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504001")[#strong[#text("Tatenda Kubalalika")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("Thank you for your response. Do you have any specific $t$ (or t’s) in mind for which (2) is false ? Because it seems to me that $H_{t}(z)$ is the Fourier transform of $\\phi(t)e^{zt^2}$, which is an even function. This seems to imply that $H_t$ should also be even. That is, $H_{t}(z)=H_{-t}(z)$ for all real $t$. Of course, my reasoning could be flawed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of TK")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504003")[#strong[#text("TK")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2018")])]

#text("My mistake indeed in the last comment: i made a typo in the above Fourier transform, which invalidates the argument.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tate. I. K")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504260")[#strong[#text("Tate. I. K")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("Indeed, the de Bruijn-Newman constant could be equal to zero.")

#text("Suppose there exists some pair ")#mi("(T, z)")#text(" of real numbers with ")#mi("T\\neq 0")#text(", such that")#linebreak()#text(" $\\latex H_{T}(z)=0.$ We shall refer to this as equation ")#mi("(1)")#text(". It is a classical fact that ")#mi("H_0")#text(" as many real zeros, and let ")#mi("z+a")#text(" be one such zero, where ")#mi("a")#text(" is some real number. That is, ")#mi("H_{0}(z+a)=0.")#text(" We shall refer to this as equation ")#mi("(2)")#text(". Combining equations ")#mi("(1)")#text(" and ")#mi("(2)")#text(" yields")#linebreak()#text(" ")#mi("H_{T}(z)=H_{0}(z+a).")#text(" We shall refer to this as equation ")#mi("(3)")#text(" As noted in Rodgers and Tao’s paper (page 3), one can view ")#mi("H_{T}(z)")#text(" as the evolution of ")#mi("H_{0}(z)")#text(" under the backwards heat equation ")#mi("\\partial_{T}H_{T}(z)=-\\partial_{zz}H_{T}(z)")#text(", where ")#mi("T")#text(" denotes the time. Hence from equation ")#mi("(3)")#text(" we deduce that,“one can view ")#mi("H_{0}(z+a)")#text(" as the EVOLUTION of ")#mi("H_{0}(z)\\cdots")#text("” But this quoted statement is meaningless, since both ")#mi("H_{0}(z)")#text(" and ")#mi("H_{0}(z+a)")#text(" represent the same time ")#mi("T=0")#text(".")

#text("We therefore conclude that our supposition must be false, and the desired result follows. $\\square$ equal to zero.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504293")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("(a) There certainly do exist pairs ")#mi("(T,z)")#text(" of real numbers with ")#mi("T \\neq 0")#text(" and ")#mi("H_T(z)=0")#text(". In fact, it is a ")#link("http://citeseerx.ist.psu.edu/viewdoc/download?doi=10.1.1.164.5595&rep=rep1&type=pdf")[#text("result of Ki, Kim and Lee")]#text(" that for ")#mi("T>0")#text(", there are infinitely many zeroes of ")#mi("H_T")#text(", all but finitely many of which are real.")

#text("(b) You have only shown that the equation ")#mi("H_T(z) = H_0(z+a)")#text(" holds for a single value of ")#mi("z")#text(", not for all ")#mi("z")#text(". The evolution of the heat equation does not depend only on the pointwise value of the initial data at a single value of ")#mi("z")#text(", but on the values at all other positions as well (the heat equation has infinite speed of propagation).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26ec5cbb5a29eeaea0c7f381ffb9e9a70f70f531466f28953e4140136691895b-9a59fc1c500957e47469f5039d746b5bd22eb1f5564e490c2ed07f88ec5e5ad7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous commenter.")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-504261")[#strong[#text("Anonymous commenter.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("@Tate. I. K, it really seems that you have demonstrated that ")#mi("\\Lambda=0")#text(". However, your argument is suspiciously short. It will be truly strange if such a long-standing problem as the RH could have such a short solution. I suggest that you submit your work to a formal journal, and goodluck !")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db83070b3edda7319c7de3c8dcc84432c33096222cc207b161916e9517cac908-e284318ad20939ec5f59d35f8c412291bb87c967f806a5075d45fe57af3a33b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian C. Hall")]], [#link("https://terrytao.wordpress.com/2018/06/07/heat-flow-and-zeroes-of-polynomials-ii-zeroes-on-a-circle/#comment-643236")[#strong[#text("Brian C. Hall")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2022")])]

#text("In Section 2.3 of a recent preprint of mine with Ching-Wei Ho, we studied (essentially) this evolution from a random matrix point of view. Suppose, for example, that you start with the characteristic polynomial of a Brownian motion in the unitary group and then evolve toward negative time. We conjecture that the roots will rapidly move off the unit circle and that they will eventually resemble the eigenvalues of a Brownian motion in the general linear group. See ")#link("https://arxiv.org/abs/2202.09660")[#text("https://arxiv.org/abs/2202.09660")]
]
