// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T16:39:29.124210+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Wimbledon, the U.S. Open, and the future of mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Wimbledon, the U.S. Open, and the future of mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/")[#text("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://www.stevenstrogatz.com/")[#text("Steven Strogatz")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#link("https://www.wired.com/story/mathematician-steven-strogatz-grapples-with-ai-recent-breakthroughs/")[#text("WIRED reported today")]#text(" that I began to cry while talking about AI and mathematics. But the article didn’t explain what moved me.")

#text("The truth is, I’m not entirely sure myself.")

#text("(A disclosure upfront: ChatGPT helped me write this post. I’m tweaking it a little to sound more like myself.)")

#metadata(none) <tao-1fa9a01b82b8c4c8543f>

#text("First, thanks to WIRED reporter Isabella Ward. She had the difficult job of distilling a long, wide-ranging conversation into a timely piece about the amazing events of the past week. And she had to put it together in one day! A lot inevitably got left out.")

#text("OK, so why did I get choked up? It wasn’t about AI taking my job. I’m 67 and nearing retirement. I also love playing around with AI and find it exhilarating. I use it in research, brainstorming, and learning—and, as you can see, to put this post together.")

#text("So what was it then? I think it was when I tried to convey the magnificent 4,000-year story of our subject to the reporter. Mathematics, I said, is more than its results. It’s a human way of seeing and understanding, a conversation in which one generation explains to the next not only what is true, but why. The pleasure of that understanding, and the new discoveries it makes possible, are part of what mathematics is for.")

#text("It’s an honor to be part of that long conversation—all the beautiful and important work, and the benefits that have accrued to humanity.")

#text("Then, suddenly, the tidal wave of AI hits math in 2026.")

#text("Something about the grandeur of the tradition and the suddenness of the change may have conspired to get me worked up.")

#text("But I’m not sure it was that. It might have been when I started riffing about ")#link("https://cims.nyu.edu/~tristanb/statement.pdf")[#text("Tristan Buckmaster")]#text(". I don’t know him, but from what I’ve read over this unsettling past week, he reminds me of many mathematicians I’ve known: pure, clear, and scrupulous, committed to truth, and perhaps unprepared for the corporate world.")

#text("During the WIRED interview, I mentioned Wimbledon four times as an analogy. To me, Buckmaster represents the Wimbledon of mathematics: white clothes, tradition, etiquette, and the ideal of being a gentle person. How you play the game matters.")

#text("The U.S. Open is different: louder, brasher, full of individual style, crassness, energy, and orientation toward the future. It’s also more open and democratic than Wimbledon. I get what’s appealing about that.")

#text("With the men’s final coming tomorrow, I find myself wondering whether AI could make mathematics at the cutting edge more like the U.S. Open than Wimbledon. It could open the gates, allowing millions of people without years of specialized training to pour in and make discoveries.")

#text("That’s thrilling. And I don’t want to be the stodgy old guard. So yes, I love the U.S. Open … and I also love Wimbledon. (I went for the first time a few years ago, and got choked up then too!)")

#text("For the past two years, ")#link("https://math.cornell.edu/alex-townsend")[#text("Alex Townsend")]#text(" and I have been writing a book that traces the marvelous ideas that brought humanity to this dizzying moment: the power unleashed by supercharging math with computers, the gifts it has given us, and what may be yet to come.")

#text("So all of that, I think, may have been what set me off: the grandeur of a 4,000-year human tradition, the inconceivability of what may lie ahead—and the possibility that something precious may disappear along the way.")

#heading(level: 1)[#text("Comments (22)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1bcac5c0061d3f1a018432d430b3e718d2b9de867249dfed47532e4d45373a2-ccd2d53b46ddc019e58983442dd7cf7f1aaba05973395dd74bdfdd7ad3d2e8d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sukessh Velusamy")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695005")[#strong[#text("Sukessh Velusamy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Great post, Steven! One thing I find curious is the fact that ChatGPT helped you write the post, but I didn’t get any ‘LLM smell’ when reading this at all! And then when I put it into Pangram, it came back as 100% human generated! Did you actually even use ChatGPT? Or did you edit it so much any trace of ‘LLMese’ disappeared?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Strogatz")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695071")[#strong[#text("Steven Strogatz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thanks Sukessh! I first dictate a lot of rough ideas directly into the ChatGPT app on my phone — just me talking, free associating, letting the goats out (as a friend of mine once taught me, if I remember the Freudian farm analogy). Then I tell ChatGPT to regard that raw material as the “pile” to draw from, and ask it to put the best pile material together into a larger organizational structure, but not too large, just a few paragraphs at most.")

#text("The key is, I don’t let it rewrite anything on the pile. The pile is to be used verbatim, or as close to it as possible. I give it permission to provide minimal connective phrases as needed, but nothing else.")

#text("My experience has been that ChatGPT can write a series of a few paragraphs at most before going off the rails and sounding too much like itself. But for a few paragraphs it’s good. After it generates a first draft, I step in and recast any new transitional material in my own voice as well.")

#text("The whole process is fast and easy, and it works pretty well!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I notice a lot of sentiment similar to ")#link("https://www.reddit.com/r/mathmemes/s/IbbbF5U76g")[#text("https://www.reddit.com/r/mathmemes/s/IbbbF5U76g")]#text(" and I have a nagging question.")

#text("Why does even an incomprehensible lean verified proof of an unsolved problem prevent people from trying to solve it?")

#text("Like why could you not continue looking in to the problem and just ignore the fact that a solution exists? I mean it’s incomprehensible any way (in this contrived example).")

#text("It makes it seem like the acclaim is the most important part, and that seems like a problem. A problem uncovered by, not caused by ai.")

#text("Now I will not condone any form of foul play if that were to occur (as is possibly a factor in NS). But in a hypothetical world, where ai genuinely blazed ahead in a manner that elucidates little but proves much, I would pose the question above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62f5e75dd5d1b84462a93fda2757d25279ed40d7abfe639eb97c2d3c4360bac0-20128771c050417854a2a39358afc5479821fc71248c3788ac63054a269a920d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tim Ktitarev")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695096")[#strong[#text("Tim Ktitarev")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I think it comes down to curiosity and funding.")

#text("One of the most interesting parts of mathematics is not knowing the answer. Working on an open problem, one has to build intuition by trying different approaches to either prove the problem (or an easier version thereof) or spend time constructing counter-examples. Eventually one has enough intuition to state a conjecture and will focus more time on either proving or disproving the problem. In the case of the Navier-Stokes equations, the mathematical community was more and more convinced that there exists a breakdown, motivated both by results from easier equations and also numerical experiments. The construction of the counter-examples is interesting in itself and perhaps people would have tried also other approaches to the breakdown. Now that the problem is solved, the curiosity is gone. Why bother trying to build some complicated counter-example to a problem whose answer we already know?")

#text("This leads to the problem of funding. Surely, this is a problem of how mathematics is presented to the outside, but right now a major motivation of funding mathematics is solving problems because this is easy to justify to someone without expertise in the field. I can, however, imagine that it would be much more difficult to secure funding to work on a problem that has already been solved, even if only through AI. It becomes difficult to explain exactly what the benefits of throwing money at a solved problem are. Of course this is true also for many open problems in (pure) mathematics, but at least there a person not familiar with the topic can be convinced by the fact that there is ")#emph[#text("some")]#text(" question that one wants to give an answer to, even if this is not the actual motivation for the proposed research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d74ee354cc775976595e73270bfc5c01624ec0906863b2fdfb60b355c78217a7-197aba0c7db902e809c951d3ed918d7ca3ae4cac05aec2c6b9b350f0aabbaaaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edward Dunne")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695123")[#strong[#text("Edward Dunne")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("“If a theorem is worth proving, it is worth proving many ways” is a quote I remember from my undergraduate days, but I don’t recall who is credited with it. (I would guess either Paul Halmos or George Pólya, two favorites of my professor.) We can learn much about the theorem, but also about mathematics, by finding different proofs of the same result. The example from my undergraduate class was the infinitude of primes. At a higher level, there is Szemerédi’s theorem, which, if I recall correctly, Gowers proved two different ways, after Szemerédi had already provided the original proof. Searching the internet, one can easily find many more examples of theorems with multiple proofs.")

#text("Yes, not knowing whether or not a result is true provides energy for trying to prove it. There is the excitement of the race. On the other hand, knowing the result, but trying to understand it (and prove it) from a different point of view is also very helpful. For example, my advisor never liked case-by-case analyses to prove a theorem. He felt that the only thing you learned was that the theorem is true, not why it is true. In my niche of the mathematical world (representations of real semi-simple Lie groups), there are different schools: the analysts (Gelfand, Harish Chandra, et al.), the geometers (Schmid, Miličić, et al.), the algebraists (Vogan, Zuckerman, et al.), to name three. Langlands classified the irreducible representations in the early 1970s. Nevertheless, the schools have produced different variations of the classification. One impetus of trying different approaches to this classification is to make progress on the next harder problem: classifying all the unitary irreducible representations. Some amazing mathematics has resulted from these attempts, including two proofs of the Kazhdan-Lusztig conjectures using $\\mathcal{D}$-modules, one from Beilinson-Bernstein (algebraic) and another from Brylinski-Kashiwara (analytic).")

#text("It does feel like AI clobbering famous open problems is taking some of the fun out mathematics. Not many researchers have access to millions or billions of tokens to use on a cutting edge LLM. When the dust settles, I hope, and even expect, that there will still be plenty of room for mathematicians working with pen and paper, or in groups with whiteboard and marker, to continue to make progress, big and small, in mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("To me the NS proof by OAI was the typical American way: storm en masse a field, trample everything and everybody on the way, put a flag on it, declare: we were first (in the name of freedom), then left, giving no added value tothe humanity. Leaving ground broken, people wounded and shocked, and left alone to clean the mess. All that in the name of money and “freedom” (for the rich).")

#text("I hope mathematics is strong enough to recover.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695033")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("With the men’s final coming tomorrow, I find myself wondering whether AI could make mathematics at the cutting edge more like the U.S. Open than Wimbledon. It could open the gates, allowing millions of people without years of specialized training to pour in and make discoveries.")

#text("That’s thrilling. And I don’t want to be the stodgy old guard. So yes, I love the U.S. Open … and I also love Wimbledon. (I went for the first time a few years ago, and got choked up then too!)")
]

#text("How is this thrilling? What about the several young people who put in the hours to gain specialization?? How can you be so crass as to completely ignore the youth in mathematics??")

#text("How are you going to justify non-specialized people producing LLM generated proofs of mathematical facts that they don’t understand but have verified in LEAN?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Strogatz")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695103")[#strong[#text("Steven Strogatz")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I’m sorry my remark came across as crass. My point (maybe clumsily expressed) was that AI can be viewed as a democratizing force. The non-specialized people you mention might be youth themselves, as in this example described by Quanquan Gu: ")#link("https://x.com/QuanquanGu/status/2098858841903681902?s=20")[#text("https://x.com/QuanquanGu/status/2098858841903681902?s=20")]#text(". He tweeted: “Just got this incredible news from UCLA Math Circle. Two high school students, Aayush Bathija and Prince Rohatgi, working with postdoc Daniel Soskin through the UCLA Math Circle, have solved a problem that Fields Medalist June Huh had previously worked on without solving. The paper was heavily AI-assisted. Whatever your view on AI in mathematics, enabling high school students to push the frontier of mathematical research is something worth celebrating.” ")#link("https://arxiv.org/abs/2609.05341")[#text("https://arxiv.org/abs/2609.05341")]

#text("I can imagine a scenario where students get drawn into mathematics by the excitement of working with AI and fellow human mathematicians in this fashion — so excited, in fact, that they then want to understand what they and the AI discovered together. In other words, they might “put in the hours to gain specialization” AFTER they’ve been part of a cool discovery.")

#text("That reverses the traditional order of things, and I know it may sound bizarre. But we are in bizarre times, and I’m just trying to see how we can all move forward in ways that are healthy for us and for the future of our subject.")

#text("But believe me, I’m ambivalent. And, like you, I worry that something precious may be lost if we go in this direction — especially if producing and verifying proofs comes to replace understanding them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6507213ca2d5413896c379329b584cc9280aa876aa8c4a4a6e0c9959648fb8c8-3b5925f54b6407a4de5449b4b5ce46ce38647167877e93a3279eb8909dc266d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Soskin")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695362")[#strong[#text("Daniel Soskin")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Respectfully, I reject the implication that your scenario happened to the High Schools students I worked with. I followed a long tradition of research supervision when students and I work to understand and formulate the questions, using a heavy computer assistance to compute the examples (some accomplished via vibe coding), and then working together to formulate the working conjecture based on these examples. Along the way the students developed a remarkable understanding presenting new deep insights into the matter. In particular, back in March the students made a presentation for their peers and faculty showing progress they had made. So, this work is not a result of few prompts. Once much of the substance was understood, ChatGPT and Claude were extremely helpful to obtain the proofs of various technical lemmas. The final paper is a technical 70+ page work, which would not be possible to write in reasonable time without the heavy use of AI. In summary, I find the tone of the comment somewhat demeaning and undermining the excellence the students exhibited while working on the project.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695140")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("What is there to justify? Such a thing seems as though it would provide zero or more value.")

#text("People won’t read things that people don’t want to read. There will likely be sources with well curated, human readable material and sources with very little care for such things.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695040")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("in the past, the knowledge that another team of mathematicians have solved the problem is usually enough to spur another independent team of mathematicians to solve the problem. Does AI refuting the smoothness and existence questions of the Navier-Stokes Equation under forcing spur or discourage human mathematicians from arriving at their own intelligble solution, in contrast?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695049")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Before I address some of the topics of this post: some context on myself, I recently completed my PhD in mathematics and am forty years younger than Prof. Strogatz; I say this in the event somebody thinks my perhaps rather “old-fashioned” view is any function of my age, which it is not.")

#text("Firstly, the claim, “then, suddenly, the tidal wave of AI hits math in 2026.” In particular, the word “suddenly.” There was nothing “sudden” about this at all. The warning signs of the dangers of this technology to mathematics, and, more importantly, to the world as a whole, have been around for years. As Prof. Strogatz himself wrote, “I also love playing around with AI and find it exhilarating. I use it in research, brainstorming, and learning—and, as you can see, to put this post together.” If you have used it in all these ways, there should be nothing sudden about this.")

#text("The only reason for the astonishment of the (hitherto not already concerned members of the) mathematical community is the following: it finally hit influential people where it hurts. My graduate school friends and I had discussed all of our concerns about AI for well over a year now: the academic dishonesty, plagiarism, increased potential for scooping of ideas/projects, and so on. It is not because we are better trained in mathematics or more experienced in it. This is obviously far from true, and I would be delusional to even suggest it. Rather, it is because my friends and I are among the weakest members of our community (graduate students), and are therefore much more likely to see the world for what it is, as opposed to what we would like it to be, because, whether we like it or not, our livelihood depends on it.")

#text("I would also like to comment on the use of artificial intelligence in mathematics, particularly to the extent that it generates ideas or solves questions. I am not here to make a general prescription for whether one should or should not use AI, although I have very strong thoughts on this matter, as you will see below. To quote one of my favorite mathematicians, Armand Borel, “I feel that what mathematics needs least are pundits who issue prescriptions or guidelines for presumably less enlightened mortals.” I am simply stating my opinion.")

#text("Imagine I had a research question in mind, and I asked a human being about it, to which he/she provided me, to my astonishment, a document out of thin air with an answer to this question. Maybe it was very difficult to comprehend, with very strange / unmotivated / convoluted arguments, which led me to struggle quite a bit to understand it. But suppose nonetheless that I eventually succeeded, and wrote a paper with myself as the author, leaving to the acknowledgements “this person provided me with this argument, which I reviewed, edited… I take full responsibility for the content of this paper.”")

#text("I ask myself now: does it make any sense to do this? Is this ethical? The answer in my mind is an emphatic “no!” To me, this is tantamount to plagiarism. However, the exact same thing is happening each and every day, with greater abundance, on the arXiv, and somehow we are not batting an eyelid (or at least not saying anything). I am reminded every day of what Grigori Perelman said in 2006 when Yau tried to downplay his work and promote what Cao and Zhu were doing (see ")#link("https://en.wikipedia.org/wiki/Grigori_Perelman")[#text("https://en.wikipedia.org/wiki/Grigori_Perelman")]#text("):")

#text("“I can’t say I’m outraged. Other people do worse. Of course, there are many mathematicians who are more or less honest. But almost all of them are conformists. They are more or less honest, but they tolerate those who are not honest. […] It is not people who break ethical standards who are regarded as aliens. It is people like me who are isolated.” — Grigori Perelman")

#text("This is how I feel about AI generated mathematics in general, and, in particular, about the recent “results of people” that have appeared: the Jacobian conjecture, the Hopf problem, the work around Navier–Stokes, and so on…")

#text("I cannot in good conscience use artificial intelligence in such a manner (I do not use it at all, but this is an even longer discussion to be had).")

#text("Maybe I am an idiot, maybe my analysis is completely incorrect. But I take comfort in knowing that at the very least it is MY analysis, and not that of a technology which is incomprehensible to anyone and which, in accordance to Clarke’s third law (see ")#link("https://en.wikipedia.org/wiki/Clarke%27s_three_laws")[#text("https://en.wikipedia.org/wiki/Clarke%27s_three_laws")]#text("), is indistinguishable from magic.")

#text("As Dostoevsky says in Crime and Punishment: “better to be wrong in your own way than correct in someone else’s.” In particular, no LLM was used to write this post, just my own brain.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Tears in my eyes. Nothing else.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Wonderful. I love the tennis analogy, Steve. Go Ben!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695094")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Psychologically, mathematicians may have the hardest time adapting to the new AI world.")

#text("Those who are good at math are singled-out from an early age for accolades. Math ability correlates very highly with academic ability in general, so they succeed spectacularly at school and university. If they’re one of the tippy-top, they win gold medals at international competitions at a young age. They get recruited into top schools, perhaps even starting much earlier than their peers. They do PhDs under famous mathematicians. They publish groundbreaking work in their early 20s. Maybe even win a Fields medal.")

#text("In short, they’re told they are special their whole life.")

#text("So what has happened in the last 6 months with AI is more than just a threat to the profession. It’s a threat to mathematicians’ very identity.")

#emph[#text("“When everyone is super, no-one will be”")]#text(" — Syndrome, The Incredibles.")

#text("It’s definitely one of the most disruptive eras in the history of humanity since the industrial revolution, and perhaps even more disruptive. Most top software engineers probably haven’t written a line of code in months. I don’t hear them calling for a halt on AI’s coding powers.")

#text("(What has happened is that one now spends time discussing high-level design with the AI, which the AI then implements. That will probably be how things go in math too. Humans still ask much better questions than the AI).")

#emph[#text("“Welcome to the party, pal.”")]#text(" — John McClane, Die Hard.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3945b7809286abba658ee75af873a597740719d68beca61d78cbadb5d7042e9f-6896ba09db6278899bf781123736697877abbcb81ebd9c03118def76a04abd9d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Johnsrude")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695107")[#strong[#text("Ben Johnsrude")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This strikes me as a very odd analysis. The story you’ve told describes a vanishingly small proportion of mathematicians. Why would that have much to do with the ~5500 (at current count) of endorsers of the mathandai statement?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695119")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This is in essence the “democratization of X” argument, which Silicon Valley has used to promote any X in the last 30 years while getting rich in the process and enslaving the users.")

#text("Almost nothing is “democratized”. The money goes to the financial and tech elite. In case the bubble bursts, the risk and the bailouts will be democratized like with the Silicon Valley Bank rescue.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695120")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I’m a postdoc in a math-adjacent field and think I’m throwing in the towel. I’m sure some interesting mathematics will come out of all this, but the idea of competing for tenure as all of our systems for credit-assignment crumble is… not appealing. I didn’t devote years of my life to studying mathematics so that I could spend my time prompting AI agent swarms (likely while they train on my input to make me further redundant).")

#text("My only optimism with these visible advancements in math is that they might make the general public take the political/economic realities of competent AI systems more seriously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/942eff4986ea20877a73654cefd9fb536fb92443b5f8e7e4bffe6657bae4063a-33858a3c567bbfaa7a1e77d01dfc47391d116c5bf4bde3cade8d7f09f644c8d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ziad Baroudi")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695161")[#strong[#text("Ziad Baroudi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("To read a Steven Strogatz post on a Terence Tao blog is such a pleasure: Two of the most recognisable names in mathematics, at least to a general audience, bringing us something about the humanity that’s inherent in the practice of mathematics. I also happen to be reading Francis Su’s “Mathematics for human flourishing” at the moment. Most maths teachers don’t know that there is a world of current mathematicians who open a window onto their practice for the rest of us to peek through it. Most people leave teachers’ college having only seen the subject from the point of view of textbooks. Students almost never hear “stories” in maths class. Yet these great mathematicians talk about style, tradition, caring about the truth, and human flourishing. All I can say to them is: “Thank you”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Strogatz")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695283")[#strong[#text("Steven Strogatz")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Reading the comments, I realize I had a blind spot. The truth is, when I was speaking to the WIRED reporter, I didn’t think about the effect all this could have on graduate students and postdocs. I was just telling the truth about what made me get choked up.")

#text("Maybe one reason is that I don’t have graduate students or postdocs at the moment. I stopped taking them a few years ago because I didn’t want to retire in the middle of their work and leave them stranded. But that also made me a little oblivious to their plight.")

#text("So, mea culpa. I still meant what I said about finding the democratizing possibilities of AI thrilling. But I should also have acknowledged how upsetting and frightening this moment must be for young mathematicians who have put in years of work and are wondering whether there will be a place for them. I’m sorry I didn’t.")

#text("And thanks to everybody here who helped open my eyes to something I should have seen earlier.")

#text("— Steven Strogatz")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/203c8dca3e9a34fcc2fedd19d9a0b5ea61aefe722c9a4eacf6eadf9cc77b0000-1bed95d342e1877f384f48bec5d9aba195e1ae8adfe019dacbee8ccf707ba200.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kel A")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695375")[#strong[#text("Kel A")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Math will eventually evolve in the long-run; I have no doubt about it.")#linebreak()#text("But if I wanted to do something right now and I had any power in the math community, I would rally journal editorial boards to have serious conversations on what publishing will look like in the days to come.")

#text("This, in my opinion, is the single most effective lever that the community can wield to adapt on its own terms.")#linebreak()#text("Everything else will (almost surely) be a trickle-down consequence: The future of problem solving, communication of mathematical insights, careers in academia, teaching/lecturing, etc.")

#text("Sure, there will be some fine-tuning to do as we go along, but doing this quickly enough will provide some stability in the short-term and perhaps a promise of a more rigorous long term equilibrium.")

#text("IMO, it is far too unpredictable trying to regulate AI use or expecting AI companies to slow down.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/12/wimbledon-the-u-s-open-and-the-future-of-mathematics/#comment-695600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Steven I think one thing you’re missing (which Jacob Tsimerman appears to have understood based on his most recent talk at HLF and his jumping ship to work at OAI) is that math is the beginning. In the micro sense, undergraduates are being dissuaded from the study, which is now transitioning to postdocs and PhDs becoming disillusioned. Those jobs will dry up…and then in the more macro sense, it will be followed by the rest of the knowledge work. The robotics will improve, and then the rest will go from there. As we saw during the idle handed years of Covid — then the violence will start in earnest.")
]
