// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/
// Converted to Typst by tao2typ: "2026-10-14T15:18:03.441467+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A proof of the Fredholm alternative", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A proof of the Fredholm alternative")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 April 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/")[#text("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A few days ago, I found myself needing to use the ")#link("http://en.wikipedia.org/wiki/Fredholm_alternative")[#text("Fredholm alternative")]#text(" in functional analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Fredholm alternative)")]#text(" Let ")#mi("{X}")#text(" be a Banach space, let ")#mi("{T: X \\rightarrow X}")#text(" be a ")#link("http://en.wikipedia.org/wiki/Compact_operator")[#text("compact operator")]#text(", and let ")#mi("{\\lambda \\in {\\bf C}}")#text(" be non-zero. Then exactly one of the following statements hold:")

#list(
[#text("(Eigenvalue) There is a non-trivial solution ")#mi("{x \\in X}")#text(" to the equation ")#mi("{Tx = \\lambda x}")#text(".")],
[#text("(Bounded resolvent) The operator ")#mi("{T-\\lambda}")#text(" has a bounded inverse ")#mi("{(T-\\lambda)^{-1}}")#text(" on ")#mi("{X}")#text(".")]
)
]

#text("Among other things, the Fredholm alternative can be used to establish the ")#link("http://en.wikipedia.org/wiki/Spectral_theory_of_compact_operators")[#text("spectral theorem for compact operators")]#text(". A hypothesis such as compactness is necessary; the shift operator ")#mi("{U}")#text(" on ")#mi("{\\ell^2({\\bf Z})}")#text(", for instance, has no eigenfunctions, but ")#mi("{U-z}")#text(" is not invertible for any unit complex number ")#mi("{z}")#text(". The claim is also false when ")#mi("{\\lambda=0}")#text("; consider for instance the multiplication operator ")#mi("{Tf(n) := \\frac{1}{n} f(n)}")#text(" on ")#mi("{\\ell^2({\\bf N})}")#text(", which is compact and has no eigenvalue at zero, but is not invertible.")

#text("It had been a while since I had studied the spectral theory of compact operators, and I found that I could not immediately reconstruct a proof of the Fredholm alternative from first principles. So I ")#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")[#text("set myself the exercise")]#text(" of doing so. I thought that I had managed to establish the alternative in all cases, but as pointed out in comments, my argument is restricted to the case where the compact operator ")#mi("{T}")#text(" is ")#emph[#text("approximable")]#text(", which means that it is the limit of finite rank operators in the uniform topology. Many Banach spaces (and in particular, all Hilbert spaces) have the ")#link("http://en.wikipedia.org/wiki/Approximation_property")[#text("approximation property")]#text(" that implies (by a ")#link("http://www.ams.org/mathscinet-getitem?mr=75539")[#text("result of Grothendieck")]#text(") that all compact operators on that space are almost finite rank. For instance, if ")#mi("{X}")#text(" is a Hilbert space, then any compact operator is approximable, because any compact set can be approximated by a finite-dimensional subspace, and in a Hilbert space, the orthogonal projection operator to a subspace is always a contraction. (In more general Banach spaces, finite-dimensional subspaces are still complemented, but the operator norm of the projection can be large.) Unfortunately, there are examples of Banach spaces for which the approximation property fails; the first such examples were discovered ")#link("http://www.ams.org/mathscinet-getitem?mr=402468")[#text("by Enflo")]#text(", and a subsequent paper of ")#link("http://www.ams.org/mathscinet-getitem?mr=0355661")[#text("by Alexander")]#text(" demonstrated the existence of compact operators in certain Banach spaces that are not approximable.")

#text("I also found out that this argument was essentially also discovered independently by ")#link("http://www.ams.org/mathscinet-getitem?mr=2418022")[#text("by MacCluer-Hull")]#text(" and ")#link("http://arxiv.org/pdf/1011.2933v1")[#text("by Uuye")]#text(". Nevertheless, I am ")#link("https://terrytao.wordpress.com/career-advice/write-down-what-youve-done/")[#text("recording this argument here")]#text(", together with two more traditional proofs of the Fredholm alternative (based on the Riesz lemma and a continuity argument respectively).")

#metadata(none) <tao-59760acc1a5ff5caaa3f>

#heading(level: 1)[#strong[#text(" — 1. First proof (approximable case only) — ")]]

#text("In the finite-dimensional case, the Fredholm alternative is an immediate consequence of the ")#link("http://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text(", and the finite rank case can be easily deduced from the finite dimensional case by some routine algebraic manipulation. The main difficulty in proving the alternative is to be able to take limits and deduce the approximable case from the finite rank case. The key idea of the proof is to use compactness to establish a lower bound on ")#mi("{T-\\lambda I}")#text(" that is stable enough to allow one to take such limits. There is an additional subtlety (pointed out in comments) that when ")#mi("{X}")#text(" is not a Hilbert space, it is not necessarily the case that ")#mi("{T}")#text(" can be approximated by finite rank operators; but a modification of the argument still suffices in this case.")

#text("Fix a non-zero ")#mi("{\\lambda}")#text(". It is clear that ")#mi("{T}")#text(" cannot have both an eigenvalue and bounded resolvent at ")#mi("{\\lambda}")#text(", so now suppose that ")#mi("{T}")#text(" has no eigenvalue at ")#mi("{\\lambda}")#text(", thus ")#mi("{T-\\lambda}")#text(" is injective. We claim that this implies a lower bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Lower bound)")]#text(" ")#metadata(none) <tao-8c6fb1e9e37a1aea1d30>#text(" Let ")#mi("{\\lambda \\in {\\bf C}}")#text(" be non-zero, and suppose that ")#mi("{T: X \\rightarrow X}")#text(" be a compact operator that has no eigenvalue at ")#mi("{\\lambda}")#text(". Then there exists ")#mi("{c>0}")#text(" such that ")#tao-math("{\\left\\|(T-\\lambda) x \\right\\| \\geq c \\left\\|x\\right\\|}", block: false)#text(" for all ")#mi("{x \\in X}")#text(".")
]

#emph[#text("Proof:")]#text(" By homogeneity, it suffices to establish the claim for unit vectors ")#mi("{x}")#text(". Suppose this is not the case; then we can find a sequence of unit vectors ")#mi("{x_n}")#text(" such that ")#mi("{(T-\\lambda) x_n}")#text(" converges strongly to zero. Since ")#mi("{\\lambda x_n}")#text(" has norm bounded away from zero (here we use the non-zero nature of ")#mi("{\\lambda}")#text("), we conclude in particular that ")#mi("{y_n := Tx_n}")#text(" has norm bounded away from zero for sufficiently large ")#mi("{n}")#text(". By compactness of ")#mi("{T}")#text(", we may (after passing to a subsequence) assume that the ")#mi("{y_n}")#text(" converge strongly to a limit ")#mi("{y}")#text(", which is thus also non-zero.")

#text("On the other hand, applying the bounded operator ")#mi("{T}")#text(" to the strong convergence ")#mi("{(T-\\lambda) x_n \\rightarrow 0}")#text(" (and using the fact that ")#mi("{T}")#text(" commutes with ")#mi("{T-\\lambda}")#text(") we see that ")#mi("{(T-\\lambda) y_n}")#text(" converges strongly to ")#mi("{0}")#text(". Since ")#mi("{y_n}")#text(" converges strongly to ")#mi("{y}")#text(", we conclude that ")#mi("{(T-\\lambda) y = 0}")#text(", and thus we have an eigenvalue of ")#mi("{T}")#text(" at ")#mi("{\\lambda}")#text(", contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note that this argument is ")#emph[#text("ineffective")]#text(" in that it provides no explicit value of ")#mi("{c}")#text(" (and thus no explicit upper bound for the operator norm of the resolvent ")#mi("{(T-\\lambda)^{-1}}")#text("). This is not surprising, given that the fact that ")#mi("{T}")#text(" has no eigenvalue at ")#mi("{\\lambda}")#text(" is an open condition rather than a closed one, and so one does not expect bounds that utilise this condition to be uniform. (Indeed, the resolvent needs to blow up as one approaches the spectrum of ")#mi("{T}")#text(".)")
]

#text("From the lower bound, we see that to prove the bounded invertibility of ")#mi("{T-\\lambda}")#text(", it will suffice to establish surjectivity. (Of course, we could have also obtained this reduction by using the ")#link("http://en.wikipedia.org/wiki/Open_mapping_theorem")[#text("open mapping theorem")]#text(".) In other words, we need to establish that the range ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" of ")#mi("{T-\\lambda}")#text(" is all of ")#mi("{X}")#text(".")

#text("Let us first deal with the easy case when ")#mi("{T}")#text(" has ")#link("http://en.wikipedia.org/wiki/Finite_rank_operator")[#text("finite rank")]#text(", so that ")#mi("{\\text{Ran}(T)}")#text(" is some finite-dimension ")#mi("{n}")#text(". This implies that the kernel ")#mi("{Ker(T)}")#text(" has codimension ")#mi("{n}")#text(", and we may thus split ")#mi("{X = Ker(T) + Y}")#text(" for some ")#mi("{n}")#text("-dimensional space ")#mi("{Y}")#text(". The operator ")#mi("{T-\\lambda}")#text(" is a non-zero multiple of the identity on ")#mi("{Ker(T)}")#text(", and so ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" already contains ")#mi("{Ker(T)}")#text(". On the other hand, the operator ")#mi("{T(T-\\lambda)}")#text(" maps the ")#mi("{n}")#text("-dimensional space ")#mi("{Y}")#text(" to the ")#mi("{n}")#text("-dimensional space ")#mi("{\\text{Ran}(T)}")#text(" injectively (since ")#mi("{Y}")#text(" avoids ")#mi("{Ker(T)}")#text(" and ")#mi("{T-\\lambda}")#text(" is injective), and thus also surjectively (by the ")#link("http://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text("). Thus ")#mi("{T(\\text{Ran}(T-\\lambda))}")#text(" contains ")#mi("{\\text{Ran}(T)}")#text(", and thus (by the short exact sequence ")#mi("{0 \\rightarrow Ker(T) \\rightarrow X \\rightarrow \\text{Ran}(T) \\rightarrow 0}")#text(") ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is in fact all of ")#mi("{X}")#text(", as desired.")

#text("Finally, we deal with the case when ")#mi("{T}")#text(" is approximable. The lower bound in Lemma ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("2")]#text(" is stable, and will extend to the finite rank operators ")#mi("{S_n}")#text(" for ")#mi("{n}")#text(" large enough (after reducing ")#mi("{c}")#text(" slightly). By the preceding discussion for the finite rank case, we see that ")#mi("{\\text{Ran}(S_n-\\lambda)}")#text(" is all of ")#mi("{X}")#text(". Using Lemma ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("2")]#text(" for ")#mi("{S_n}")#text(", and the convergence of ")#mi("{S_n}")#text(" to ")#mi("{T}")#text(" in the operator norm topology, we conclude that ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is dense in ")#mi("{X}")#text(". On the other hand, we observe that the space ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is necessarily closed, for if ")#mi("{(T-\\lambda) x_n}")#text(" converges to a limit ")#mi("{y}")#text(", then (by Lemma ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("2")]#text(" and the assumption that ")#mi("{X}")#text(" is Banach) ")#mi("{x_n}")#text(" will also converge to some limit ")#mi("{x}")#text(", and so ")#mi("{y = (T-\\lambda) x}")#text(". As ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is now both dense and closed, it must be all of ")#mi("{X}")#text(", and the claim follows.")

#heading(level: 1)[#strong[#text(" — 2. Second proof — ")]]

#text("We now give the standard proof of the Fredholm alternative based on the ")#link("http://en.wikipedia.org/wiki/Riesz's_lemma")[#text("Riesz lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Riesz lemma)")]#text(" ")#metadata(none) <tao-54b6b89043d400f11f5a>#text(" If ")#mi("{Y}")#text(" is a proper closed subspace of a Banach space ")#mi("{X}")#text(", and ")#mi("{\\epsilon > 0}")#text(", then there exists a unit vector ")#mi("{x}")#text(" whose distance ")#mi("{\\text{dist}(x,Y)}")#text(" to ")#mi("{Y}")#text(" is at least ")#mi("{1-\\epsilon}")#text(".")
]

#emph[#text("Proof:")]#text(" By the ")#link("http://en.wikipedia.org/wiki/Hahn-Banach_theorem")[#text("Hahn-Banach theorem")]#text(", one can find a non-trivial linear functional ")#mi("{\\phi: X \\rightarrow {\\bf C}}")#text(" on ")#mi("{X}")#text(" which vanishes on ")#mi("{Y}")#text(". By definition of the operator norm ")#tao-math("{\\left\\|\\phi\\right\\|_{op}}", block: false)#text(" of ")#mi("{\\phi}")#text(", one can find a unit vector ")#mi("{x}")#text(" such that ")#tao-math("{\\left|\\phi(x)\\right| \\geq (1-\\epsilon) \\left\\|\\phi\\right\\|_{op}}", block: false)#text(". The claim follows. ")#mi("\\Box")

#text("The strategy here is not to use finite rank approximations (as they are no longer available), but instead to try to contradict the compactness of ")#mi("{T}")#text(" by exhibiting a bounded set whose image under ")#mi("{T}")#text(" is not ")#link("http://en.wikipedia.org/wiki/Totally_bounded")[#text("totally bounded")]#text(".")

#text("Let ")#mi("{T: X \\rightarrow X}")#text(" be a compact operator on a Banach space, and let ")#mi("{\\lambda}")#text(" be a non-zero complex number such that ")#mi("{T}")#text(" has no eigenvalue at ")#mi("{\\lambda}")#text(". As in the first proof, we have the lower bound from Lemma ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("2")]#text(", and we know that ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is a closed subspace of ")#mi("{X}")#text("; in particular, the map ")#mi("{T-\\lambda}")#text(" is a Banach space isomorphism from ")#mi("{X}")#text(" to ")#mi("{\\text{Ran}(T-\\lambda)}")#text(". Our objective is again to show that ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is all of ")#mi("{X}")#text(".")

#text("Suppose for contradiction that ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is a proper closed subspace of ")#mi("{X}")#text(". Applying the Banach space isomorphism ")#mi("{T-\\lambda}")#text(" repeatedly, we conclude that for every natural number ")#mi("{m}")#text(", the space ")#mi("{V_{m+1} := \\text{Ran}((T-\\lambda)^{m+1})}")#text(" is a proper closed subspace of ")#mi("{V_{m} := \\text{Ran}((T-\\lambda)^{m})}")#text(". From the Riesz lemma, we may thus find unit vectors ")#mi("{x_{m}}")#text(" in ")#mi("{V_{m}}")#text(" for ")#mi("{m=0,1,2,\\ldots}")#text(" whose distance to ")#mi("{V_{m+1}}")#text(" is at least ")#mi("{1/2}")#text(" (say).")

#text("Now suppose that ")#mi("{n > m \\geq 0}")#text(". By construction, ")#mi("{x_n, (T-\\lambda) x_n, (T-\\lambda) x_m}")#text(" all lie in ")#mi("{V_{m+1}}")#text(", and thus ")#mi("{T x_n - T x_m \\in \\lambda x_m + V_{m+1}}")#text(". Since ")#mi("{x_m}")#text(" lies at a distance at least ")#mi("{1/2}")#text(" from ")#mi("{V_{m+1}}")#text(", we conclude the separation proeprty")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T x_n - T x_m \\right\\| \\geq \\frac{\\left|\\lambda\\right|}{2}.", block: true)]]

#text("But this implies that the sequence ")#mi("{\\{ T x_n: n \\in {\\bf N} \\}}")#text(" is not totally bounded, contradicting the compactness of ")#mi("{T}")#text(".")

#heading(level: 1)[#strong[#text(" — 3. Third proof — ")]]

#text("Now we give another textbook proof of the Fredholm alternative, based on Fredholm index theory. The basic idea is to observe that the Fredholm alternative is easy when ")#mi("{\\lambda}")#text(" is large enough (and specifically, when ")#tao-math("{\\left|\\lambda\\right| > \\left\\|T\\right\\|_{op}}", block: false)#text("), as one can then invert ")#mi("{T-\\lambda}")#text(" using ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series")]#text(". One can then attempt to continously pertrb ")#mi("{\\lambda}")#text(" from large values to small values, using stability results (such as Lemma ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("2")]#text(") to ensure that invertibility does not suddenly get destroyed during this process. Unfortunately, there is an obstruction to this strategy, which is that during the perturbation process, ")#mi("{\\lambda}")#text(" may pass through an eigenvalue of ")#mi("{T}")#text(". To get around this, we will need to abandon the hypothesis that ")#mi("{T}")#text(" has no eigenvalue at ")#mi("{\\lambda}")#text(", and work in the more general setting in which ")#mi("{\\text{ker}(T-\\lambda)}")#text(" is allowed to be non-trivial. This leads to a lengthier proof, but one which lays the foundation for much of ")#link("http://en.wikipedia.org/wiki/Fredholm_theory")[#text("Fredholm theory")]#text(" (which is more powerful than the Fredholm alternative alone).")

#text("Fortunately, we still have analogues of much of the above theory in this setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-6c1ff09db3a73dc4a854>#text(" Let ")#mi("{\\lambda \\in {\\bf C}}")#text(" be non-zero, and let ")#mi("{T: X \\rightarrow X}")#text(" be a compact operator on a Banach space ")#mi("{X}")#text(". Then the following statements hold;")

#enum(start: 1, 
[#text("(Finite multiplicity) ")#mi("{\\text{ker}(T-\\lambda)}")#text(" is finite-dimensional.")],
[#text("(Lower bound) There exists ")#mi("{c>0}")#text(" such that ")#tao-math("{\\left\\|Tx\\right\\| \\geq c \\text{dist}(x, \\text{ker}(T-\\lambda))}", block: false)#text(" for all ")#mi("{x \\in X}")#text(".")],
[#text("(Closure) ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" is a closed subspace of ")#mi("{X}")#text(".")],
[#text("(Finite comultiplicity) ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" has finite codimension in ")#mi("{X}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" We begin with finite multiplicity. Suppose for contradiction that ")#mi("{\\text{ker}(T-\\lambda)}")#text(" was infinite dimensional, then it must contain an infinite nested sequence ")#mi("{\\{0\\} = V_0 \\subsetneq V_1 \\subsetneq V_2 \\subsetneq \\ldots}")#text(" of finite-dimensional (and thus closed) subspaces. Applying the Riesz lemma, we may find for each ")#mi("{n=1,2,\\ldots}")#text(", a unit vector ")#mi("{x_n \\in V_n}")#text(" of distance at least ")#mi("{1/2}")#text(" from ")#mi("{V_{n-1}}")#text(". Since ")#mi("{T x_n = \\lambda x_n}")#text(", we see that the sequence ")#mi("{\\{ T x_n: n=1,2,\\ldots\\}}")#text(" is then ")#tao-math("{\\left|\\lambda\\right|/2}", block: false)#text("-separated and thus not totally bounded, contradicting the compactness of ")#mi("{T}")#text(".")

#text("The lower bound follows from the argument used to prove Lemma ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("2")]#text(" after quotienting out the finite-dimensional space ")#mi("{\\text{ker}(T-\\lambda)}")#text(", and the closure assertion follows from the lower bound (again after quotienting out the kernel) as before.")

#text("Finally, we establish finite comultiplicity. Suppose for contradiction that the closed subspace ")#mi("{\\text{Ran}(T-\\lambda)}")#text(" had infinite codimension, then by properties of ")#mi("{T-\\lambda}")#text(" already established, we see that ")#mi("{\\text{Ran}((T-\\lambda)^{m+1})}")#text(" is closed and has infinite codimension in ")#mi("{\\text{Ran}((T-\\lambda)^{m})}")#text(" for each ")#mi("{m}")#text(". One can then argue as in the second proof to contradict total boundedness as before. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The above arguments also work if ")#mi("{\\lambda}")#text(" is replaced by an invertible linear operator on ")#mi("{X}")#text(", or more generally by a ")#link("http://en.wikipedia.org/wiki/Fredholm_operator")[#text("Fredholm operator")]#text(".")
]

#text("We can now define the ")#link("http://en.wikipedia.org/wiki/Linear_transformation#Index")[#text("index")]#text(" ")#mi("{\\text{ind}(T-\\lambda)}")#text(" to be the dimension of the kernel of ")#mi("{T-\\lambda}")#text(", minus the codimension of the range. To establish the Fredholm alternative, it suffices to show that ")#mi("{\\text{ind}(T-\\lambda)=0}")#text(" for all ")#mi("{\\lambda}")#text(", as this implies surjectivity of ")#mi("{T-\\lambda}")#text(" whenever there is no eigenvalue. Note that Note that when ")#mi("{\\lambda}")#text(" is sufficiently large, and in particular when ")#tao-math("{\\left|\\lambda\\right| > \\left\\|T\\right\\|_{op}}", block: false)#text(", then ")#mi("{T-\\lambda}")#text(" is invertible by Neumann series and so one already has index zero in this case. To finish the proof, it suffices by the discrete nature of the index function (which takes values in the integers) to establish continuity of the index:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Continuity of index)")]#text(" Let ")#mi("{T: X \\rightarrow X}")#text(" be a compact operator on a Banach space. Then the function ")#mi("{\\lambda \\mapsto \\text{ind}(T-\\lambda)}")#text(" is continuous from ")#mi("{{\\bf C} \\backslash \\{0\\}}")#text(" to ")#mi("{{\\bf Z}}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\lambda}")#text(" be non-zero. Our task is to show that")

#align(center)[#tao-fit-display[#mitex("\\text{ind} (T-\\lambda^{\\prime}) = \\text{ind} (T - \\lambda)")]]

#text("for all ")#mi("{\\lambda^{\\prime}}")#text(" sufficiently close to ")#mi("{\\lambda}")#text(".")

#text("In the model case when ")#mi("{T-\\lambda}")#text(" is invertible (and thus has index zero), the claim is easy, because ")#mi("{(T-\\lambda^{\\prime}) (T-\\lambda)^{-1} = 1 + (\\lambda-\\lambda^{\\prime}) (T-\\lambda)^{-1}}")#text(" can be inverted by Neumann series for ")#mi("{\\lambda^{\\prime}}")#text(" close enough to ")#mi("{\\lambda}")#text(", giving rise to the invertibility of ")#mi("{T-\\lambda}")#text(".")

#text("Now we handle the general case. As every finite dimensional space is complemented, we can split ")#mi("{X = \\text{ker}(T-\\lambda) + V}")#text(" for some closed subspace ")#mi("{V}")#text(" of ")#mi("{X}")#text(", and similarly split ")#mi("{X = \\text{Ran}(T-\\lambda) + W}")#text(" for some finite-dimensional subspace ")#mi("{W}")#text(" of ")#mi("{X}")#text(" with dimension ")#mi("{\\text{codim} \\text{Ran}(T-\\lambda)}")#text(".")

#text("From the lower bound we see that ")#mi("{T-\\lambda}")#text(" is a Banach space isomorphism from ")#mi("{V}")#text(" to ")#mi("{\\text{Ran}(T-\\lambda)}")#text(". For ")#mi("{\\lambda^{\\prime}}")#text(" close to ")#mi("{\\lambda}")#text(", we thus see that ")#mi("{(T-\\lambda^{\\prime})(V)}")#text(" is close to ")#mi("{\\text{Ran}(T-\\lambda)}")#text(", in the sense that one can map the latter space to the former by a small perturbation of the identity (in the operator norm). Since ")#mi("{W}")#text(" complements ")#mi("{\\text{Ran}(T-\\lambda)}")#text(", it also complements ")#mi("{(T-\\lambda^{\\prime})(V)}")#text(" for ")#mi("{\\lambda^{\\prime}}")#text(" sufficiently close to ")#mi("{\\lambda}")#text(". (To see this, observe that the composition of the obvious maps")

#align(center)[#tao-fit-display[#mitex("X \\mapsto W \\times \\text{Ran}(T-\\lambda) \\rightarrow W \\times V \\rightarrow W \\times (T-\\lambda^{\\prime})(V) \\rightarrow X")]]

#text("is a small perturbation of the identity map and is thus invertible for ")#mi("{\\lambda^{\\prime}}")#text(" close to ")#mi("{\\lambda}")#text(".)")

#text("Let ")#mi("{\\pi: X \\rightarrow W}")#text(" be the projection onto ")#mi("{W}")#text(" with kernel ")#mi("{(T-\\lambda^{\\prime})(V)}")#text(". Then ")#mi("{\\pi (T-\\lambda^{\\prime})}")#text(" maps the finite-dimensional space ")#mi("{\\text{ker}(T-\\lambda)}")#text(" to the finite-dimensional space ")#mi("{W}")#text(". By the ")#link("http://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text(", this map has index equal to ")#mi("{\\text{dim} \\text{ker}(T-\\lambda) - \\text{dim}(W) = \\text{ind}(T-\\lambda)}")#text(". Gluing this with the Banach space isomorphism ")#mi("{T-\\lambda^{\\prime}: V \\rightarrow \\text{Ran}(T-\\lambda^{\\prime})}")#text(", we see that ")#mi("{T-\\lambda^{\\prime}}")#text(" also has index ")#mi("{\\text{ind}(T-\\lambda)}")#text(", as desired. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Again, this result extends to more general Fredholm operators, with the result being that the index of a Fredholm operator is stable with respect to continuous deformations in the operator norm topology.")
]

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51570")[#strong[#text("Y")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("With the same assumption, can theorem 1 be restated as “")#mi("T-\\lambda")#text(" is either ‘1-1 and onto’ or ‘neither 1-1 nor onto'”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/425b5e7ce8a3177722b83f666dc73db2187d304c7b7c01f809a32c891a9df920-058bdb93b350639608b14dfa7aa4e05501c2b9e3b1f93c49944b359e45674b43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ARS")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51574")[#strong[#text("ARS")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("The hypothesis of compactness is necessary. I think you mean to say: Some condition is necessary. There is a theory of Fredholm operators, which does not assume they come from compact perturbations of he idendity. The above theorem then says: $\\lambda I-T$ is Fredholm whenever $T$ compact and $\\lambda \\neq 0$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51579")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("Why is a compact operator on a Banach Space limit of finite rank operators?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51583")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("To elaborate on Anonymous’ hint/suggestion: there are Banach spaces which support compact operators that are not limits (in the operator norm) of sequences of finite rank operators. The norm closure of the ideal of finite rank operators is the so-called algebra of approximable operators; every approximable operator is compact, but the converse does not always hold. It does work for operators on $L^p$-spaces, though, since these have the approximation property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9040bac26d9a740f9318df61e97779ca8729000df38e4d9aed7ead17b4525756-d4b843ec87daf04a3f02fc66e356632cef15aa27155f9df47406b0c63a31109f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doormat")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51585")[#strong[#text("Doormat")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2011")])]

#text("AFAIK, the question of approximating a compact operator by finite ranks is not quite equivalent to the approximation property; the first example (which can be taken to be a subspace of \\ell_p) of a Banach space X which admits a compact, non-approximable, operator is given in:")

#text("Alexander, Freda E.")#linebreak()#text(" Compact and finite rank operators on subspaces of lp.")#linebreak()#text(" Bull. London Math. Soc. 6 (1974), 341–342.")

#link("http://www.ams.org/mathscinet-getitem?mr=0355661")[#text("http://www.ams.org/mathscinet-getitem?mr=0355661")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51586")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("I knew I should just have waited for you to comment instead ;) Yes, I see that I gave a misleading impression; I knew that if X has the AP then A(X)=K(X) and so just gave that as a sufficient condition.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51600")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("Oops, that was a silly mistake to make. (I carelessly thought that since every compact set is approximable by a finite-dimensional set, and every finite-dimensional space is complemented, that every compact operator is approximated by a finite rank one; but the projection to the finite-dimensional space can have large operator norm if one is not in a nice ambient space such as a Hilbert space.) I’ve reworked the text, with my proof (which I also found was discovered by MacCluer-Hull and Uuye) restricted to the approximable setting, and with the two standard proofs of the alternative given for comparison.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9040bac26d9a740f9318df61e97779ca8729000df38e4d9aed7ead17b4525756-d4b843ec87daf04a3f02fc66e356632cef15aa27155f9df47406b0c63a31109f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doormat")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51605")[#strong[#text("Doormat")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("Well, it is a question which defeated Banach ;-> (I think it’s asked in his book if every Banach space has the approximation property, which as Yemon and I discussed above is almost, but not quite, the same as asking if every compact operator can be approximated by finite-ranks. It took Enflo until 1973 to find a counter-example. It’s still, IMHO, a poorly understood phenomena in Banach space theory– it’s also rather a recherche area…)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neo")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51613")[#strong[#text("Neo")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2011")])]

#text("Why the term alternative? Is it just because there are two alternatives in the theorem and exactly one should be true?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51691")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Yes, I believe this is the origin of the term. (I suppose that the result could also have been called the “Fredholm dichotomy”, but the existing name is too entrenched in the literature to try changing it now.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62253317f0175d3a86b01a81f820b407a959f07ceee6d41854a2c99d754603b8-3b893021e902771bda50dcfe439f4d59c3e6f148eae5407ae3bcec49d0ba3d98.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jesús")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51630")[#strong[#text("jesús")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2011")])]

#text("What about if the operator under consideration is only closed? There is an analogous for Fredholm alternative theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51689")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Dear Prof. Tao,")

#text("is the Laplacian a compact operator on ")#mi("C^2(K)")#text(", say K is a bounded domain in ")#mi("\\bf{R}^d")#text(" or equal to ")#mi("\\bf{R}^d")#text("?")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("No; it is not even bounded or everywhere defined from ")#mi("C^2(K)")#text(" to ")#mi("C^2(K)")#text(", let alone continuous. However, resolvents such as ")#mi("(1-\\Delta)^{-1}")#text(" are bounded and compact on ")#mi("C^2(K)")#text(" (this is a variant of the Rellich compactness theorem), and this can be used to start building a spectral theory for the Laplacian on bounded domains (and in particular, to show that the spectrum consists only of eigenvalues).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51699")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("Prof.Tao, I am a little bit confused. why is not everywhere defined? can not we apply Laplacian to any ")#mi("C^2")#text(" function? isn’t it true that a linear continuous operator also bounded?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51702")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("The Laplacian of a C^2 function will merely be in C^0, not in C^2, and so the Laplacian is not a bounded operator from C^2 to itself.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8da44bcb835c035ee24440a4032ae37db743296247f0c956349ff22ebf78010e-77a998b3c083b3a33c844c20b6509885af389a048df2caa232b801ad7657fb9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Donald")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51704")[#strong[#text("Donald")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2011")])]

#text("I see. Thanks for the explanation Prof. Tao.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d240c281a46fde20efac261b188db21fb7bf293236931595b44ebea0b4ddff64-640f028c8fec79aae038cfe296c56135e89d8655b4c6da7693ef1b46827d623a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Orr")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51832")[#strong[#text("Orr")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2011")])]

#text("Thanks for the post. 3 lines above the end of the proof of lemma 5, you must have meant dim(W), not dim(V). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51876")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("Following up on the question of Donald, why do we prefer Holder spaces over C^k with integer k? I read in a book that C^k are somehow not the right spaces for elliptic differential equations, but I cannot come up with any tangible argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51877")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("Holder spaces are more stable with respect to fractional and singular integrals, and do not “lose” any regularity when inverting elliptic operators. For instance, if ")#mi("\\Delta u")#text(" lies in ")#mi("C^{0,\\alpha}({\\bf R}^n)")#text(" for some ")#mi("0 < \\alpha < 1")#text(", then ")#mi("u")#text(" will lie in ")#mi("C^{2,\\alpha}({\\bf R}^n)")#text("; of course, the converse implication is trivial. In contrast, if ")#mi("\\Delta u")#text(" lies in ")#mi("C^0({\\bf R}^n)")#text(", then it is not necessarily the case that ")#mi("u")#text(" lies in ")#mi("C^2({\\bf R}^n)")#text(" (basically because the Riesz transforms ")#mi("\\nabla^2 \\Delta^{-1}")#text(" are not bounded on ")#mi("C^0")#text(").")

#text("Ultimately this is because the fractional Holder spaces have a nice Littlewood-Paley representation as Besov spaces (interactions between different frequency scales can be represented by a convergent geometric series), while the classical ")#mi("C^k")#text(" spaces do not (the interactions between frequency scales can be logarithmically divergent). (There are stable substitutes for the ")#mi("C^k")#text(" spaces available, such as Zygmund space or VMO (vanishing mean oscillation), but these are not particularly convenient to use for elliptic regularity theory, except perhaps as endpoints to interpolate from, as they do not behave so well with respect to pointwise multiplication.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A proof of the Fredholm alternative « IMAGINATION of MATH")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51937")[#strong[#text("A proof of the Fredholm alternative « IMAGINATION of MATH")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2011")])]

#text("[…] we deal with the case when is approximable. The lower bound in Lemma 2 is stable, and will extend to the finite rank operators for large enough (after reducing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-51962")[#strong[#text("Fourth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2011")]

#text("[…] Terence Tao: A proof of the Fredholm alternative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52190")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2011")])]

#text("Dear Prof. Tao,")

#text("Thanks for the nice post!")

#text("I have a (most probably trivial) question for the second proof. If we assume that ")#mi("Ran(\\lambda-T)")#text(" is a proper subspace of ")#mi("X")#text(", how to derive")#linebreak()#text(" ")#mi("V_{m+1} \\subset V_m")#text("? For instance, for the orthogonal projection ")#mi("P")#text(", we always have ")#mi("P^2=P")#text(". Of course, this example is not suitable here since ")#mi("P")#text(" is not injective. But it shows some flavor of my question.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2011")])]

#text("I mean that how to show that ")#mi("V_{m+1}")#text(" is also a proper subspace of ")#mi("V_m")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2011")])]

#text("By induction on m, using the fact that the map ")#mi("T-\\lambda")#text(" is injective.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ugroh")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52276")[#strong[#text("ugroh")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("Riesz Lemma")

#text("Terence, I worked through your great post because of my lecture and I got finally a problem with the proof of the Riesz lemma. I guess you proof is as following: ")#mi("{ M }")#text(" is a closed subspace of ")#mi("{ X }")#text(", thus ")#mi("{ X/M }")#text(" is a normed vector space. Take ")#mi("{ \\phi \\in X^{\\prime}}")#text(" of norm one and ")#mi("{ \\hat{x} \\in X/M }")#text(" of norm one with ")#tao-math("{ \\left|\\phi(\\hat{x})\\right| \\geq (1-\\epsilon)}", block: false)#text(". Then ")#tao-math("{(1-\\epsilon) \\leq \\left|\\phi(\\hat{x})\\right| \\leq \\left\\| \\hat{x} \\right\\| = \\inf \\left\\| x - y \\right\\| }", block: false)#text(" for all ")#mi("{ x \\in \\hat{x}}")#text(" and all ")#mi("{ y \\in M}")#text(". But why can you choose a ")#mi("{ x \\in \\hat{x}}")#text(" of norm one? The canonical map from ")#mi("{ X}")#text(" to ")#mi("{ X/M}")#text(" is open but in general not closed, nor is the boundary of the unit ball of ")#mi("{ X }")#text(" maped onto the boundary of the unit ball of ")#mi("{ X/M }")#text("? Or do I miss something?")

#text("Thanks Ulrich")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("Dear Ulrich,")

#text("One does not have to explicitly work in the quotient space. First, one uses the Hahn-Banach theorem to find a non-trivial bounded linear functional ")#mi("\\phi \\in X^{\\prime}")#text(" that vanishes on M. This functional need not have norm 1 (in ")#mi("X^{\\prime}")#text(", not in ")#mi("(X/M)^{\\prime}")#text(") initially, but it can be normalised as such by multiplying by a constant. By the definition of the X’ norm, this implies that there exists a unit vector ")#mi("x \\in X")#text(" such that ")#tao-math("\\left|\\phi(x)\\right| \\geq 1-\\varepsilon", block: false)#text(". Since ")#tao-math("\\left\\|\\phi\\right\\|_{X^{\\prime}}=1", block: false)#text(", this already forces ")#mi("\\text{dist}(x,M) \\geq 1-\\varepsilon")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5b71f6516927a87676910349d15761dfeae3786ad5922d00fe89d4def7d8dfd-12bbf3ac74b52cd72ba208ea634fe48580c63ec9f0761af42154e78e591561a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("Dear Prof. Tao, dear Prof. Ulrich")

#text("A well-known proof without Hahn-Banach: take any v in X, outside of")#linebreak()#text(" Y and let d>0 be its distance to Y. Take now a vector y in Y such that the")#linebreak()#text(" norm of v-y is smaller than 1+d\\varepsilon. Dividing v-y by its norm")#linebreak()#text(" gives a suitable vector x (direct verification).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5b71f6516927a87676910349d15761dfeae3786ad5922d00fe89d4def7d8dfd-12bbf3ac74b52cd72ba208ea634fe48580c63ec9f0761af42154e78e591561a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("Sorry, it’s me again. I’d like to add that, for class purposes, you can even act this out: hold a pen slanted over a desk. Take a point P on the desk very close to the tip of the orthogonal projection of the pen. Points directly between P and the tip")#linebreak()#text(" of the pen have their distances to the desk very close to their distances to P.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Effective limiting absorption principles, and applications « What’s new")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52292")[#strong[#text("Effective limiting absorption principles, and applications « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2011")])]

#text("[…] at zero, then an argument (based on (a variant of) the Fredholm alternative, which as discussed in this recent blog post gives ineffective bounds) gives a bound of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9600342ea6c4a9d9b3c467fc166a1c600cb8a5a49b7acc1a145414977e095f9a-e44c4910e771211e44bed0cc8479a2c89f24a6b6a9c6908e32ecf8da5d7ecfcb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ugroh")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-52311")[#strong[#text("ugroh")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2011")])]

#text("Dear Terence, thanks for the remark. It opened the eyes.")

#text("@anonymous: This way of proving the lemma is known and will be used usual. The Hahn-Banch-argument was new to me (and because I will not teach the HB-Thorem unfortunately not applicable).")

#text("Ulrich")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-132072")[#strong[#text("The asymptotic distribution of a single eigenvalue gap of a Wigner matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2012")])]

#text("[…] (and specifically, the operator norm, Hilbert-Schmidt norm, and nuclear norm). Amusingly, the Fredholm alternative makes a key appearance, as I end up having to invert a compact perturbation of the identity at one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97c847de8247f0d959cb20954038792d7647fec86b2a4bdb63b0563dfd937262-bcbb8b802dbed18938a87124c56bfc7e96797508e0cbda561d035cd23db59df3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ahmed")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-448720")[#strong[#text("ahmed")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("I need to prove the A* Ax = A* b by use Fredholm Alternative Theorem")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-473399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("In the first alternative of Theorem 1, do we have the extra property that the eigen-space (the null space of ")#mi("T-\\lambda")#text(") is of finite dimension?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-473401")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("Yes, because the unit ball in an infinite-dimensional normed vector space cannot be precompact (basically thanks to iterating the Riesz lemma).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-473402")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("I’ve seen a version of the Fredholm alternative in the setting of Hilbert space that says the following:")

#text("If ")#mi("T:H\\to H")#text(" is a compact operator on the Hilbert space ")#mi("H")#text(" then")

#text("(1) ")#mi("N(1-T)")#text(" is of finite dimension,")#linebreak()#text(" (2) ")#mi("R(1-T)")#text(" is closed,")#linebreak()#text(" (3) ")#mi("R(1-T)=N(1-K^*)^\\perp")#text(",")#linebreak()#text(" (4) ")#mi("N(1-T)=\\{0\\}")#text(" iff ")#mi("R(1-T)=H")#text(",")#linebreak()#text(" (5) ")#mi("\\text{dim} N(1-K)=\\text{dim} N(1-K^*)")#text(".")

#text("Is it equivalent to Theorem 1 in the setting of Hilbert space (or can one deduce completely from Theorem 1)?")

#text("Does the version about give any more information than Theorem 1?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/#comment-473403")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2016")])]

#text("The version stated here only directly gives (4), and the Riesz lemma only directly gives (1), but these are the man ingredients in the proof of the remaining components (2), (3), (5) of the Fredholm alternative in the Hilbert space case (combined with some fairly standard tools such as the Riesz representation theorem for Hilbert spaces, and understanding how concepts such as null space, range, and adjoint change when passing to finite codimension closed subspaces). I would imagine that any functional analysis text that covers Fredholm theory would work out these derivations in detail.")
]
]
