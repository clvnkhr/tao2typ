// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/07/the-barriers-of-perception/
// Converted to Typst by tao2typ: "2026-10-14T15:21:26.501355+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The barriers of perception", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The barriers of perception")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/07/the-barriers-of-perception/")[#text("https://terrytao.wordpress.com/2026/10/07/the-barriers-of-perception/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://raghumeka.github.io/")[#text("Raghu Meka")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("“This problem has been tried by several famous mathematicians.” “There is a heuristic argument for why these methods cannot work.” “Getting this algorithm would give new circuit lower bounds.” Observations like these can take on a life of their own, almost like a game of telephone. A limitation of a particular approach, or an implication whose difficulty we do not fully understand, becomes a reason to believe that a problem is beyond reach, and eventually a reason not to think about it at all.")

#metadata(none) <tao-5a83ff96a4f63f86e795>

#text("Over the past few weeks, I have been thinking about the role such perceived barriers have played in theory as I know it, and perhaps more broadly in mathematics. The recent articles on this blog about what it means to do mathematics in the age of AI have been very helpful in understanding and gathering my own thoughts. Looking back at several great results from the past year or so, a few of them (small fraction, admittedly) make me think that perhaps we lost some edge by imagining barriers–“social” hardness or limitations of approaches passed down as folklore–where none existed.")

#text("At least some of the solutions coming out of AI models, while brilliant, are also not completely alien. Yet these were problems we had almost stopped trying to solve, apart from small pockets of researchers. Of course, it is easy to say this post hoc. But in some sense, we have seen more `similarly brilliant’ solutions to newer problems than to these older ones. This makes me wonder how much our inherited perceptions have shaped where we were willing to look.")

#text("This has also made me think about some things from my early research days as a graduate student.")

#text("When I was a graduate student, I gave a talk on a small result. A very perceptive member of the audience (")#link("https://www.cs.utexas.edu/~klivans/")[#text("Adam Klivans")]#text(", if you are reading this!) asked a question that I thought was a great one. But I also thought there were barriers around it, and it did not seem doable. Later, an answer to that question turned out to be an important piece in others’ resolution of a central question. The point of the story is not whether I would have solved the problem; probably not. The point is that the perceived barrier kept me from making even a half-decent attempt at it.")

#text("On a personal level, my progress in research was slow. If you are in mathematics, this might not seem that odd, but in theoretical computer science, having only one paper after five years, and that too not in one of the flagship conferences, could generally be taken to mean you had fallen well behind the curve. I nearly left theory. It was my mentors who pointed out that even if the results were not there, the failed attempts showed intent and progress, and that the absence of results was not evidence of a limitation I had begun to imagine. That support got me through then. They taught me not only how to do research, but how to love it.")

#text("Several times, I have had an initial impression that there were well-known methodological barriers, or a certain “social hardness” attached to the names of people who had attempted specific problems and directions. The research wisdom of some colleagues, and curiosity itself, helped me get past these impressions and engage with the questions. Pure curiosity is one force that can mitigate these perceived barriers; having people who are very optimistic (research-wise) or encourage that curiosity is another. Perhaps we need to cultivate this more.")

#text("Coming back to the present, I think this moment calls for extra care in resisting the trap of perceived barriers, and for revisiting several such accepted hurdles with less deference. We seem to have a mighty tool that can break through some of them. There are many problems whose solutions I thought I would never see, but now, by the universe’s grace, I will likely have the fortune to see them (perhaps some are already gathering dust on servers).")

#text("Relatedly, I also see a temptation to put implicit barriers on what “human mathematicians” can contribute. I wonder whether this might become the latest received wisdom that we accept too quickly. My predictive powers are quite limited. But even so, perhaps the epiphany I am having now is that the downside of not believing there is a barrier is far less than that of believing there is one. The cost of disbelieving has, after all, also come down because of the additional firepower we can now call upon. I would like to give curiosity a little more room before deciding what we can contribute, or what ")#emph[#text("we")]#text(" cannot do.")

#text("To take poetic liberty, and borrow the words of ")#link("https://en.wikipedia.org/wiki/The_Marriage_of_Heaven_and_Hell")[#text("Blake")]#text(" that gave ")#link("https://en.wikipedia.org/wiki/The_Doors_of_Perception")[#text("Huxley")]#text(" his title: “If the doors of perception were cleansed every thing would appear to man as it is, infinite.”")

#text("Acknowledgements: I thank several friends who gave useful feedback on the first draft. AI was used to correct grammatical errors and polish sentences.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9aac05a558797d32c15f55d878a48d42da70b746702d86f0d119ed7c3d5d3f7-271938281befc09d4e62e209f9ef583576efda8ebe21909421f3a2ddbe083be5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Oliver")]], [#link("https://terrytao.wordpress.com/2026/10/07/the-barriers-of-perception/#comment-696910")[#strong[#text("William Oliver")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("This is a wonderful post that beautifully puts into words what I have been unable to.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I also see a temptation to put implicit barriers on what “human mathematicians” can contribute. … the downside of not believing there is a barrier is far less than that of believing there is one. The cost of disbelieving has, after all, also come down because of the additional firepower we can now call upon. I would like to give curiosity a little more room before deciding what we can contribute, or what ")#emph[#text("we")]#text(" cannot do.")
]

#text("The subjects of learning and the mind and the nature of mathematics and what mathematics ‘really is’ remains incredibly mysterious, and my number one frustration with AI is that there is a sense in which culturally it is entrenching the view that these are not worthwhile or tractable mysteries. We should not treat them as settled, nor should we treat them as so far out of reach that we cannot settle them. We should try to understand what is really going on, and keep an open mind to the various possibilities, regardless of whether or not they require of us ‘non standard’ ideas, or if it seems impossible to solve. There is a sense in which the various reactions of mathematicians have not had this open mindedness. The optimism for the future of AI seems to have entirely replaced a genuine investigation into its long term effects. Instead, it seems as though we are simply saying “well, no one can predict the future, but I think things will work out for the best”.")

#text("But we are mathematicians, and AI is essentially a mathematical object. We should be able to do better than that!")

#text("and its relationship with ")#emph[#text("mathematics itself")]#text(" and human intelligence.")

#text("We do not know what AI is capable of because we do not truly know what humans are capable of.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/607da8e1251e335425cfc888cd580b3242b4e8c72115ec70987ccb27b650688b-c5793af2ae104cc41e93eef6949b50d7204c2b68c02b654912152878cd948552.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of radiant19af09d1e8")]], [#link("https://terrytao.wordpress.com/2026/10/07/the-barriers-of-perception/#comment-697347")[#strong[#text("radiant19af09d1e8")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("In some sense, AI is representing what humans have already done, but no human had connected the dots because the volume of results had gotten so large. From all the “results” AI has presented so far, I see recombinations, new connections, vast computations, and extensive deductive inferences from already existing mathematics. These methods can produce amazing results to be sure, and most mathematical literature is just that. But the initial inventions, creation of whole new fields of mathematics which never existed before, envisioning new mathematical objects and ways of reframing mathematics itself… I don’t see any hints of that in these dumps from OpenAI. I don’t see the mysterious creative genius of a Galois, Cantor, Grothendieck etc… where something completely new and deductively unattainable from past results seemed to strike like lightning.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/07/the-barriers-of-perception/#comment-697038")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("also the classic by jacques hadamarrd")

#text("psycchology of invention in math")

#text("dovsr reprint 1976")
]
