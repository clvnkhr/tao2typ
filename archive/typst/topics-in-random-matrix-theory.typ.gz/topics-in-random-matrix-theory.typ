// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/
// Converted to Typst by tao2typ: "2026-10-14T16:36:25.965135+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Topics in random matrix theory", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Topics in random matrix theory")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 February 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/")[#text("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’ve just finished writing the first draft of my second book coming out of the 2010 blog posts, namely “")#link("https://terrytao.wordpress.com/books/topics-in-random-matrix-theory/")[#text("Topics in random matrix theory")]#text("“, which was based primarily on ")#link("https://terrytao.wordpress.com/category/teaching/254a-random-matrices/")[#text("my graduate course in the topic")]#text(", though it also contains material from ")#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/")[#text("some")]#link("https://terrytao.wordpress.com/2010/10/23/the-dyson-and-airy-kernels-of-gue-via-semiclassical-analysis/")[#text(" additional")]#text(" ")#link("https://terrytao.wordpress.com/2010/07/15/the-golden-thompson-inequality/")[#text("posts")]#text(" related to random matrices on the blog. ")#link("https://terrytao.wordpress.com/wp-content/uploads/2011/02/matrix-book.pdf")[#text("It is available online here")]#text(". As usual, comments and corrections are welcome. There is also a ")#link("https://terrytao.wordpress.com/books/topics-in-random-matrix-theory/")[#text("stub page")]#text(" for the book, which at present does not contain much more than the above link.")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50380")[#strong[#text("Tweets that mention Topics in random matrix theory « What’s new -- Topsy.com")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2011")]

#text("[…] This post was mentioned on Twitter by Olivier Grisel, Christophe Lalanne and Memo Olicón, Probability Fact. Probability Fact said: Topics in random matrix theory ")#link("http://ow.ly/3ZXvz")[#text("http://ow.ly/3ZXvz")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d54534b486854684e1dc703fbea7ab93e9ca553f4d189fd5c4fc5617168046f-bbd4b7678e524c3005160021bcad8053fdf3cacd177055e7dd634ebda6a8d2ad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Blake Stacey")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50436")[#strong[#text("Blake Stacey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2011")])]

#text("Typo alert: in section 1.1.2 (random variables), at the bottom of p. 8, the closing quotation mark is typeset in math mode.")

#emph[#text("[Corrected for the next revision, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be2d3ce1a072042a1ee1ab8979c9b165cacd5e2b0952c75d079352f5dce945aa-e2baeff00724eef5066cd22e980f7404b848ee963bff37db3aedcb73173e9a6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50461")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("— For maps, I think the correct spacing around the colon is obtained with “\\colon” instead of “:”.")

#text("— When writing a dash, one should use “—” instead of “ – ”.")

#text("— P. 7, l. 8 and l. -6: Capital O.")

#text("— P. 8, l. -1: Wrong quotation mark.")

#text("— P. 10, l. -4: Text in the (right) margin.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50462")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2011")])]

#text("— P. 28, l. 10: Text in the margin.")

#text("— P. 31, l. -2: One should `glue’ togther “Exercise” and “1.1.21” with a tilde (~) in order to avoid the linebreak.")

#text("— P. 33, l. 10: I do not know the expression “iid signed”. Is it correct?")

#text("— P. 35, l. 15: Text in the margin.")

#text("— P. 36, l. 1: One should `glue’ togther “Example” and “1.1.24” with a tilde (~) in order to avoid the linebreak.")

#text("— P. 36, l. 14: No space between “identity” and the footnote mark.")

#text("— P. 39, l. 11: Text in the margin.")

#text("— P. 40, l. 10: One should `glue’ togther “Exercise” and “1.1.25(vi)” with a tilde (~) in order to avoid the linebreak.")

#emph[#text("[Thanks! Most of these types of changes should be implemented when the ms is professionally typeset for publication. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2011")])]

#text("Prof. Tao, which course are you going to teach next semester? We can start to read some background material")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50526")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2011")])]

#text("I will be teaching 245C (real analysis) in the spring. However, I will be re-using my older notes (and now book) for this, which are already on the blog at ")#link("https://terrytao.wordpress.com/category/teaching/245c-real-analysis/")[#text("https://terrytao.wordpress.com/category/teaching/245c-real-analysis/")]#text(" or ")#link("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")[#text("https://terrytao.wordpress.com/books/an-epsilon-of-room-pages-from-year-three-of-a-mathematical-blog/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2011")])]

#text("Prof. Tao,")

#text("Do you have any plan to teach grad level complex analysis? it would be great if you do so.")

#text("Thanks")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50480")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2011")])]

#text("Here is the typos I found in the rest of chapter 1:")

#text("— P. 44, l. 8: Text in the margin.")

#text("— P. 44, l. 12 + 14 and p. 45, l. 4 + 5 + 10 + 12 + 18 + 19: Is it suppose to be a lowercase o?")

#text("— P. 46, l. 10 + 11 and p. 47, l. 5 + 6: I think dots between binary operators are suppose to be vertically centered. LaTeX often gets it right if one uses \\dots (resp. \\dot).")

#text("— P. 47, l. 13: “matrix(2.80)” –> “matrix (2.80)”.")

#text("— P. 49, l. 5: I think dots between relation symbols are suppose to be vertically centered. Again, LaTeX often gets it right if one uses \\dots (resp. \\dot).")

#text("— P. 49, l. 11: The “th” should not be in italic mode.")

#text("— P. 49, l. 11: Text in the margin.")

#text("— P. 50, l. -5 + -3 + -2 + -1 and p. 51, l. 6 + 12 + 20 + 21: I think dots between binary operators should be vertically centered.")

#text("— P. 52, l. 11 + 12: Shouldn’t there be a space immediately before the references?")

#text("— P. 52, l. 19 + 21 + 25 and p. 53, l. 4 + 8–10: The lowered dots.")

#text("— P.52 , l. -1: Two full stops after the reference.")

#text("— P. 54, l. 5: Remove “)”.")

#text("— P. 54, l. 13–15: The lowered dots.")

#text("— P. 54, l. 21: The lowered dots in the c^* expression.")

#text("— P. 55, l. 2: Missing a “(” (or a “)” too much).")

#text("— P. 57, l. -2 + -1: The subscript “op” should not be in italic mode.")

#text("— P. 58, l. 15: Space before reference and text in margin.")

#text("— P. 60, l. 20: The lowered dots.")

#text("— P. 60, l. 21: The lowered dots and text in margin.")

#text("— P. 61, l. 2–5 + 15 + 20 + 22 + 26 + 29: The lowered dots.")

#text("— P. 61, l. 7: The “th” should not be in italic mode.")

#text("— P. 61, l. -2: The subscript “op” should not be in italic mode. (Two times.)")

#text("— P. 62, l. 4: The lowered dots.")

#emph[#text("[Thanks, these corrections will be taken into consideration for the next revision. Incidentally, the o() notation is not a typo; see Definition 1.1.2. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mads")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50481")[#strong[#text("Mads")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2011")])]

#text("Oh, yes; sometimes you write lowercase o instead of a capital O. Is this correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-50507")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2011")])]

#text("Dear Mads,")

#text("Please consult any text on order notations. As Prof. Tao pointed out, even this text defines the big-oh and small-oh notation in def. 1.1.2 (asymptotic notation).")

#text("Also, note that this is is an advanced graduate text and so the reader is expected to have a minimum level of familiarity with probability, linear algebra, etc.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-51165")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2011")])]

#text("– page ix, line -3 : “will” -> “well”")

#text("– page 304 : confusions between N and n in X_n (and X_n)")

#text("Thanks a lot for letting the file in open access !")

#emph[#text("[Thanks, this will appear in the next revision. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-51765")[#strong[#text("Topics in Random Matrix Theory | Ebooks Forge")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2011")]

#text("[…] Author Links […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-594492")[#strong[#text("Polynomial magic III : Hermite polynomials – Machine Learning Research Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")]

#text("[…] of kernels within machine learning such as dot-product kernels [3], in random matrix theory (see here), in statistics for Edgeworth expansions, and of course for Gauss-Hermite […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-687933")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")])]

#text("Hello Professor Tao, at Page 122 it says")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("“Remark 2.2.12. […] We will see this when we discuss the ")#strong[#text("four moment theorem")]#text(" of Van Vu and myself in later lectures, which (very) roughly speaking asserts that the spectral statistics of two random matrices are asymptotically indistinguishable if their coefficients have matching moments to fourth order.”")
]

#text("But I don’t see any further discussion of the four moment theorem in the book.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/02/20/topics-in-random-matrix-theory/#comment-687941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")])]

#text("Ah, yes, I ended up not covering that topic in my lecture notes, and that remark can be deleted.")
]
]
