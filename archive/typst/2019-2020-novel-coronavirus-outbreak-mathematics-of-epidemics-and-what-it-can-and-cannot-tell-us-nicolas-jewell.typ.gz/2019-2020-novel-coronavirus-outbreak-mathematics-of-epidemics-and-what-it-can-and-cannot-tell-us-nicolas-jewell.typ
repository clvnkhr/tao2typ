// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/
// Converted to Typst by tao2typ: "2026-10-14T16:38:44.394826+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "2019-2020 Novel Coronavirus outbreak: mathematics of epidemics, and what it can and cannot tell us (Nicolas Jewell)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("2019-2020 Novel Coronavirus outbreak: mathematics of epidemics, and what it can and cannot tell us (Nicolas Jewell)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 March 2020")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/")[#text("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("At the most recent ")#link("https://www.msri.org/general_events/23186")[#text("MSRI board of trustees meeting")]#text(" on Mar 7 (conducted online, naturally), ")#link("https://publichealth.berkeley.edu/people/nicholas-jewell/")[#text("Nicolas Jewell")]#text(" (a Professor of Biostatistics and Statistics at Berkeley, also affiliated with the Berkeley School of Public Health and the London School of Health and Tropical Disease), gave a ")#link("https://www.youtube.com/watch?v=MZ957qhzcjI")[#text("presentation on the current coronavirus epidemic")]#text(" entitled “2019-2020 Novel Coronavirus outbreak: mathematics of epidemics, and what it can and cannot tell us”. The presentation (updated with Mar 18 data), hosted by ")#link("https://en.wikipedia.org/wiki/David_Eisenbud")[#text("David Eisenbud")]#text(" (the director of MSRI), together with a question and answer session, is now on Youtube:")

#text("(I am on this board, but could not make it to this particular meeting; I caught up on the presentation later, and thought it would of interest to several readers of this blog.) While there is some mathematics in the presentation, it is relatively non-technical.")

#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57a792d73121dadf0e0a55c6cc51a38a5e8c7080ec4aa43ecfbcdb2255bd8021-8b7f9bd838d2ca72121ba94bf232cf771ed8a6a068a7a04a7fb8cac463dae6a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bernard Ikhimwin")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547199")[#strong[#text("Bernard Ikhimwin")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Many thanks Terence for sharing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbdca2030b956f45e4f08f9ce93bbeb9582eced200b1ffbe082f913fc946ca6d-2c832edb72c0376bda63aac56b51128fee68b578b032d16b4d1a4c88f0134407.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre Magal")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547213")[#strong[#text("Pierre Magal")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Unreported cases may play an important role for COVID-19. You may find a related paper here: ")#link("https://www.math.u-bordeaux.fr/~pmagal100p/LMSW-corona2-Mar11.pdf")[#text("https://www.math.u-bordeaux.fr/~pmagal100p/LMSW-corona2-Mar11.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5847598cef89ebfd89cb8344d98b46a512b6f1c4e441fb0199808c51393e20c4-56773ff39d82059705f4d1baa5cd2e38c7321b5ecf33209b31e72d1e04107ff1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liberoculto")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547215")[#strong[#text("Liberoculto")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Indeed, in a small Italian town (Vo’), where systematic mass testing have been made, a lot of asymptomatic have been detected (some of them even highly contagious).")#linebreak()#text(" ")#link("https://www.theguardian.com/world/2020/mar/18/scientists-say-mass-tests-in-italian-town-have-halted-covid-19")[#text("https://www.theguardian.com/world/2020/mar/18/scientists-say-mass-tests-in-italian-town-have-halted-covid-19")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("According to this report, not only that systematic mass testing (of asymptomatic population) is clearly required, but also it shows that the “two weeks isolation” rule is not(!) sufficient and should be extended.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d48155c2341ba90790470bbba07d96b4aa63cb05cd10a08c05ef459b5e1e7a1-0d9d8594be0b14bc4f86bc83e75f58fadcb912efa0918f545fa66ecc6dbe2bd8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Rosenzweig")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547228")[#strong[#text("Matt Rosenzweig")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("Thank you for sharing!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/053e475474d925de7352f63c518c64354752a60cfd1373d30482f210005962fe-371800e92d7df1404d23f34fae53f399a217d85c4f5ba0ba7aefa45eae2096e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547268")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2020")])]

#text("What about places where social distancing is extremely difficult if not impossible like in South Asia?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c99a7f83f25c881a900c9ada802169bf37ca04c82b9fb7f16472697cd91161a7-377187ff17920d58f1d49e61956aca9463fb774a9758f137ce406906b6134a21.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547367")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Perhaps it will run its course in South Asia?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39c14d19d22ca6476779f5c83efe1bb4ca9ba5a560f8bde235050b4193dc02df-8345212a0215563e0535c71fa811dfd882400eda7a6c3bc175da349c5638bda2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-548012")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2020")])]

#text("Bill Gates is not directly giving an answer to this either.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0b92b84e5c652880410cd3e4f3ef8ab6d3363a8fd2812e5d32de3e2a43f0166-44f5d9e12584eecafdb7f66863e70e15b02be10076601103432fc3307f2d438b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Imran Qureshi")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547280")[#strong[#text("Imran Qureshi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("This was a great talk and very informative on why COVID is serious and requires social distancing.")

#text("Unfortunately, most mathematical models don’t seem to be so useful at this point given the huge variation of population outcomes from small changes in inputs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e8152f46397789f8640cde48e81fad22bb225fc0060f1e78fa7190c045491ab-534fb5acbea61bfa6442ed4622a1fd9619913bc55d4b52a9d43d64841ad6035a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bastián Núñez")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547724")[#strong[#text("Bastián Núñez")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("A highly chaotic system, mathematically speaking.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547351")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("2018/2019 flu statistics (estimates) in the US from ")#link("https://www.cdc.gov/flu/about/burden/index.html")[#text("https://www.cdc.gov/flu/about/burden/index.html")]#text(":")

#text("Symptomatic (!) illnesses: 35,520,883")#linebreak()#text(" Medical Visits: 16,520,350")#linebreak()#text(" Hospitalizations: 490,561")#linebreak()#text(" Deaths: 34,157")#linebreak()#text(" Death rate among hospitalizations: 7%")#linebreak()#text(" Death rate among medical visits: 0.2%")

#text("Recent estimate from Wuhan about covid death rate: 0.8%. However, covid testing and medical visits have much stricter guidelines than flu, so 0.8% could easily become 0.2% if we allow for 16 million medical visits for covid. Also, flu 7% hospitalization death rate is not far even from the covid death rate in Italy, 8%, which is what it should really be compared to. Look at this article:")

#link("https://www.bloomberg.com/news/articles/2020-03-18/99-of-those-who-died-from-virus-had-other-illness-italy-says")[#text("https://www.bloomberg.com/news/articles/2020-03-18/99-of-those-who-died-from-virus-had-other-illness-italy-says")]

#text("The average age of people who died in Italy is 79.5, and 99% of them had other conditions like high blood pressure (75%), diabetes (35%), and heart disease (30%).")

#text("I think sceptics are being too generous when comparing covid with flu. I think it won’t be 10 times deadlier once compared accurately (i.e. in the imaginary control group where the world has not panicked). My guess it would not be worse than n1h1 outbreak.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547352")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Flu hospitalisation death rates do seem to be comparable to COVID-19 hospitalisation death rates, but on the other hand the proportion of people with flu requiring hospitalisation (about 1.4% by your data) is much less than the proportion of people with COVID-19 requiring hospitalisation (about 12% according to this study in ")#link("https://www.cdc.gov/mmwr/volumes/69/wr/mm6912e2.htm")[#text("https://www.cdc.gov/mmwr/volumes/69/wr/mm6912e2.htm")]#text(" ). So the “COVID-19 is 10 times deadlier than flu” claim is still unchanged; you’ve just moved it into the ratio ")#mi("\\mathrm{hospitalised}/\\mathrm{infected}")#text(" rather than ")#mi("\\mathrm{deaths}/\\mathrm{infected}")#text(" (which is of course mathematically equivalent to the claim that the ratios ")#mi("\\mathrm{deaths}/\\mathrm{hospitalised}")#text(" for both diseases are comparable). Indeed one could argue that the hospitalisation ratio is far more relevant than the death ratio anyway, given the urgent need to flatten the curve of hospitalisations to stay within the capacity of our health care systems.")

#text("This blog post of Luca Trevisan from Italy suggests that the current situation in Lombardy would not, in fact, be comparable to the background flu noise: ")#link("https://lucatrevisan.wordpress.com/2020/03/20/what-is-next/")[#text("https://lucatrevisan.wordpress.com/2020/03/20/what-is-next/")]

#text("This video that made the rounds recently (I am refraining from using the phrase “gone viral”) on obituaries in Bergamo also illustrates the comparison with a “control group”: ")#link("https://twitter.com/davcarretta/status/1238791068071661568")[#text("https://twitter.com/davcarretta/status/1238791068071661568")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547354")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Terry, I think you would agree that doctors and hospitals treat COVID more like SARS and out of abundance of caution hospitalized almost everyone if they can (especially, at the beginning of the outbreak). In fact, that is why hospitals are overwhelmed. Another reason is that when people are in a state of anxiety or panic attack do not breath properly and, overall, are much more vulnerable. Watch this video, please: ")#link("https://youtu.be/H2E1t3yMXgE")[#text("https://youtu.be/H2E1t3yMXgE")]#text(" At some point the guy says that once he started doing breathing exercises, his condition improved dramatically. Finally, I am not calling this a hoax; and the video you linked to is truly sad. But current situation looks like an overreaction to me that will cause more misery than the virus itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("You can’t have it both ways: you can claim “COVID-19 is comparable to flu because the death rates are similar among hospitalised patients”, or you can claim “doctors are over-hospitalising COVID-19 patients relative to flu patients out of an abundance of caution”, but you can’t claim both simultaneously. By your logic, if doctors treated COVID-19 patients with the same low level of caution as flu patients, then only the most severe cases of COVID-19 would be hospitalised and the death rate for COVID-19 hospitalisations would be much higher than that for flu hospitalisations.")

#text("There are many ways to slice up the ratio ")#mi("\\mathrm{deaths}/\\mathrm{infected}")#text(", but no matter how one slices it, the consensus of the data is indeed that COVID-19 is roughly ten times deadlier than the regular flu.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547359")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Hospitalization number you mentioned, 12%, comes from the US on March 16 out of a very small number of 4,226 cases. Also, we do not know the denominator INFECTED even approximately in the US on that day. Even if I knew the hospitalization number in Wuhan, it would not be a fair comparison because filling a stadium with beds is not real hospitalization. You can not accuse me of being illogical while using irrelevant or unrelated data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547369")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("We are not discussing a comparison between COVID-US data and COVID-Wuhan data; we are instead comparing COVID-US data with flu-US data. Using the best available CDC data for both, hospitalisation rates for COVID are roughly an order of magnitude greater than that for the flu. (If you have any better data than the ones we are using here, please feel free to share it.)")

#text("The data sets from the US, Italy, and China would of course exhibit some fluctuations between each other, which will cause some deviations from exact equality in ")#mi("A/B = (A/C) \\times (C/B)")#text(" type identities if one is forced to use different data sets to compute different terms in the identity, but the available evidence indicates that such fluctuations (and other uncertainties in the data) are much smaller than the order of magnitude difference between COVID and flu fatality rates that is the topic of discussion here. (Or are you seriously claiming that (say) Wuhan hospitalisation rates could be anywhere close to 10 times higher than the US? Though I fail to see the relevance of Wuhan hospitalisation rate to the current discussion in any case.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547361")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("And I admit I do not know. Perhaps, it is 10 times deadlier among 75 plus year old due its particular ability to cause pneumonia. That video from Italy is truly sad, so I do not ask this question lightly, but: how many of people over 75 in Italy were lifelong smokers? Again, 99% of them had other serious conditions, and average age of deaths was 79 years old. Honestly, even if it’s ten time deadlier among 75+, I’ll take it if among 10- it’s ten times milder. Sorry if I sound insensitive.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f276b47fc1f6bb0afb07eda16ac5b740e0de54337421424b53915cd30bd4e4dc-00f4cfeb408803421a4947ccabbc79246a54624bf619e37004a928a36f748e9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547368")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("The blog also says 13 days after Shelter in place. If it is not that effective there why would it be here with only 20% having any Shelter in place at all?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547440")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("No, I was not trying to discuss or compare hospitalization rates at all, because US numbers are estimates at time 0, while we are trying to discuss asymptotics at infinity. I only compared D1= [Flu death rate among hospitalizations in the USA: 7%] to D2= [Over all COVID death rate in Italy now], because pretty much most sick people in Italy are old and hospitalized (although I admit that the level of care might be not comparable).")

#text("But my main point was that we have two decent estimates at infinity. Death rate in Wuhan among “Medical Visits = aka detected infections”")#linebreak()#text(" was 0.8%; and flu death rate among detected “medical visits” infections in the US in 2018/2019 was 0.2%. This is only a factor of 4 difference. And CDC data confidence intervals even allow for 0.36% or so, about a factor of 3 difference.")

#text("And so based on this my guess was (just a guess, not a strong claim) that, because of the current panic, more serious cases were caught in Wuhan compared to flu in the US, where old people (in Wuhan) who would have stayed at home and, thus, would have died without being included detected, were counted. Another way to put it is, if panic was stirred during a normal flu season in the US, more old people would have been counted instead of dying at home undetected and 0.2% could have become 0.8%. Perhaps, panic can account for that factor of 3 or 4 above.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547355")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("By the way, 12% hospitalization rate you mentioned is the rate among 4,226 cases in the United States as of March 16. Let us see what percentage will be hospitalized when the number of Medical Visits reaches 16,520,350.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547363")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Terry, people will automatically believe what you say, especially, when two fractions are part of your argument. But I want to point out that you wrote A/B with subscript “Wuhan” and wrote it as A/C x C/B where the second ratio has subscript “USA”. And you concluded that something does not add up.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547504")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("Bill, I am sorry, you seem to be meaning well, but you have no idea what you are talking about and your spreading of misinformation is dangerous so you need to stop. And very sadly if, as I assume, you live in the USA, the next two weeks will prove you terribly wrong and hit you hard.")

#text("The scientific consensus all over the world is that COVID-19 is indeed ten times deadlier than the flu, and yes, those people who published peer-reviewed articles in Science about it did check for the trivial latent factors you keep mentioning (or do you really believe you are a genius who discover things that none of the top virologists in the world have thought of yet?).")

#text("Rather than the number of flu deaths per year, you might want to check the current *daily* death reports in Europe. The daily death rate is up 20% in Italy, and 80% in Lombardy. That is, over *ALL possible causes of death*. Still want to keep claiming it’s an over-blown flu? Are all these deaths just made up? These are data from 5 days ago, and the number of COVID-19 deaths/day keeps growing *exponentially* in Italy as of today (you might want to double check the meaning of exponentially, if not done yet). Heavy lock down measures taken there are still to show any effects.")

#text("But maybe you think Italians are just really bad at handling this crisis? But then Spain, France, Germany and the UK also are since they are currently following the exact same trajectory, just a few days behind. And yes, sorry, the USA do follow the exact same trajectory too, despite the travel bans having bought them about two weeks compared to Europe.")#linebreak()#text(" If there is any data worth looking at, it is this graph updated daily by John Burn-Murdoch on twitter: ")#link("https://twitter.com/jburnmurdoch/status/1241463928271581185/photo/1")[#text("https://twitter.com/jburnmurdoch/status/1241463928271581185/photo/1")]#text(".")

#text("Please be safe, stay at home and practice social distancing. Not often in your life will you have the opportunity to literally save tens if not hundreds of lives through your actions (or in that case, limitation of your actions).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547518")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("People like to use the word *exponential*. Does not flu follow *exponential* growth as well? What is the point of this?")

#text("And again I am not denying that this new virus causes havoc in Italy among old sick people because of its ability to cause pneumonia. Sadly, many of them will die, perhaps, a year earlier on average (average covid death age in Italy is 79.5 years while life expectancy if 82.5 years). But panic that is caused by scientists and media and politicians is not helping anybody. You will surely die if you expect to die. And locking countries down will cause more misery overall, in my opinion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("BILL,")

#text("“But panic that is caused by scientists and media and politicians is not helping anybody.”")

#text("Nonsensical anti-science assertion like this is not going to help anybody.")

#text("“You will surely die if you expect to die.”")

#text("It is one thing that you die happily and naturally; it is a damn tragedy if you die from a disease next week because of actions that could save your life having not been done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547539")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("(cont.) If you have no idea what “exponential” means and how block down would work, take a look at this visualization on twitter:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("This is a nice visualization. (Also briefly made me wonder whether \"healthNerds\" is an anagram of \"Netherlands\".) ")#link("https://t.co/HxAcJcrlAI")[#text("https://t.co/HxAcJcrlAI")]

#text("— Timothy Gowers @wtgowers (@wtgowers) ")#link("https://twitter.com/wtgowers/status/1241698905030561793?ref_src=twsrc%5Etfw")[#text("March 22, 2020")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2020")])]

#text("Another nice visualization:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Brilliant demonstration.")#link("https://twitter.com/hashtag/StayHomeSaveLives?src=hash&ref_src=twsrc%5Etfw")[#text("#StayHomeSaveLives")]

#text("by ")#link("https://twitter.com/memotv?ref_src=twsrc%5Etfw")[#text("@memotv")]#link("https://t.co/8Qonbg0Biv")[#text("pic.twitter.com/8Qonbg0Biv")]

#text("— Lionel Page (@page_eco) ")#link("https://twitter.com/page_eco/status/1242409266633297920?ref_src=twsrc%5Etfw")[#text("March 24, 2020")]
]
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547364")[#strong[#text("Paris-Dauphine : coronavirus et numérique – Libres pensées d'un mathématicien ordinaire")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")]

#text("[…] s’est intéressé aux liens entre épidémiologie et théorie des jeux. Terence Tao a écrit un billet sur les mathématiques de l’épidémiologie. À propos d’épidémiologie, des ressources sur l’usage des mathématiques dans ce […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb6d82eb070e95b1687d3f83d9440a3bdeb8f4f4fe87033b575d1761cc22ca57-6002689b8e543f883cd78b86f9e8e899d1c266daf2baba04bc8fd23ac89f9d2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sibusiso Sibisi")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547366")[#strong[#text("Sibusiso Sibisi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Excellent talk, thank you. South Africa currently has some 250 cases with no deaths yet. Measures to flatten the curve have been announced. How stringent should such measures be? Lockdown now? The talk mentions that greater flattening means higher susceptibility to a second infection wave. How much should we worry about this at this stage? Can we meaningfully talk of an optimal flattening strategy, taking other factors into account, such as that SA has a median age of 27?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb6d82eb070e95b1687d3f83d9440a3bdeb8f4f4fe87033b575d1761cc22ca57-6002689b8e543f883cd78b86f9e8e899d1c266daf2baba04bc8fd23ac89f9d2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sibusiso Sibisi")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547718")[#strong[#text("Sibusiso Sibisi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("Update: President Cyril Ramaphosa has just announced a 21-day national lockdown, with reported cases standing at 402 but growing fast.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf9889fe80e2090c4d4cebd6ccbb80afe6ee25035b62299e6178e28f28e4de49-d56f6206851ea722a9d8b1b110982344a3be3d2ddf23b9f73bd4738f2dbb98e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547370")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("What is the point of flattening the curve if second time infections occur as often? Flattening the curve cushions the impact on hospitals. If there are second time infections how does the curve fall down? As long as there is adequate infections per day even localized containment is not possible. What is this game of flattening and why not focus on getting it to 0 right from the start? How do we know this intermediate possibility exists. Perhaps your mathematical models do not work for all infection size regimes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2db3d3ac6f5bbc29e6d9056dfc17331802da49622ce8a085d8008d8887a2aa-f704729e456ab8b0c75ecbbdad1e654d446fa263afdcb68a5449cfa07e96e419.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547372")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Are we playing the curve flattening game to lose? ")#link("https://www.nj.com/coronavirus/2020/03/im-going-to-get-it-we-all-are-njs-top-health-official-says-as-she-leads-the-states-coronavirus-war.html")[#text("https://www.nj.com/coronavirus/2020/03/im-going-to-get-it-we-all-are-njs-top-health-official-says-as-she-leads-the-states-coronavirus-war.html")]#text(" Without 0 this thing will keep causing crisis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/23f663e81a0747bc42cb064c24757ad9608d5e221c2e7e3227b040ebaea6d461-4e20f9b3f6e26361642d0945714c027f1c637520955402092aa61d11ffa3d127.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Song")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547371")[#strong[#text("Song")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2020")])]

#text("Professor Jewell was not sure why Japan’s COVID-19 cases do not grow as fast as that in Italy and the US.")

#text("Well, it is because Japanese wear face masks. In Japan, it is almost a culture tradition that people wear face masks in the winter to prevent from catching flu. Wearing face mask is as important as social distancing and washing hands, if not more, in preventing flu and COVID-19. After all COVID-19 is also a respiratory disease. With much fewer patients, Japanese health system has the disease under control, the death rate in Japan is also much lower, although Japan’s older population is even larger than that of Italy. The curve has been bent from the beginning in Japan.")

#text("According to a doctor working on COVID-19 in Shanghai, COVID-19 is “preventable and controllable” if everyone does “social distancing, wearing face mask and washing hands”. Up to now, Japan, Hong Kong and Singapore have COVID-19 under control by doing exactly that without shutting down any city. We will soon find out how Europe and US fare by advising people not to wear face masks.")

#text("I really hope Professor Jewell can do some research on the effect of wearing face masks in the prevention of COVID-19. The results of the research will save lives.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe0ef876daa22fb724efbaa7c962b52d6334dec420920635dd68181527d2d492-9cd33212bfc809c0c4dd901da1651b7446a896e94ae70c7ae696149a8b6f2587.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tonda")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547410")[#strong[#text("Tonda")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("It is not true, that in Europe all states advise people not to wear face masks. Some countries have mandatory (!) face masks since the last two weeks (more or less) if you leave your home and people get fined if they disobey (it is controlled by police).")#linebreak()#text(" E.g.")#linebreak()#text(" Slovakia: ")#link("https://spectator.sme.sk/c/22364638/matovic-government-appointed.html")[#text("https://spectator.sme.sk/c/22364638/matovic-government-appointed.html")]#linebreak()#text(" Czech republic: ")#link("https://news.expats.cz/health-medical/breaking-face-coverings-to-be-mandatory-in-all-public-spaces-across-the-czech-republic-as-of-midnight/")[#text("https://news.expats.cz/health-medical/breaking-face-coverings-to-be-mandatory-in-all-public-spaces-across-the-czech-republic-as-of-midnight/")]

#text("Basically you don’t meet anyone without a covered face nowadays in these states. So far, there are no death cases and spreading is slower than in other countries. But, truth is, that these may be exceptions in Europe. Let’s see if this “Asian” style of dealing with epidemic will work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547447")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("You are right. The news today is that Japan is reopening schools, parks, etc. And businesses were never closed. Europe and US are shooting themselves in the foot. People who support complete shutdown should realize that 50% of people in the US will be in debt in one month without work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f44fe5eddb40e6f70ecca6076841d6a7f3c6fbe5a4c80c5f2e7a877b582f1f28-f25b9750343a89b3aac5b149ededf310bd7ffeeef29384cea988f81e3f12dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gönenç Onay")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547506")[#strong[#text("Gönenç Onay")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("Very informative talk which successfully sums up almost all the modelling discussions currently available on social media. But most importantly, as title suggests, it also makes clear that any model has a limit, in particular it makes precise the tautological fact that models are not predictions of the future. Hence distinguishes itself by this ethical behavior.")

#text("On the other hand, as far as I see, both the Germany’s data and its interpretation is almost completely missing. However, maybe the Germany’s data is the most interesting one. Now more than 24000 cases overall, there is only about 90 deaths (compared for example to France where number of cases is around 14000 and deaths are around 600, while France executes much more restrictive shutdown policies since 1 week). So it is now only")#linebreak()#text(" about 0.35% (computed only via tested cases) while Prof Jewels thinks that already 1% of final death rates would be positively surprising.")

#text("One may ask, why Germany allowed the big Carnival on NRW (where the virus then first detected in Germany) on mid-February. Moreover knowing that some cases in Berlin already appeared via a night club in the beginning of March, Germany allowed big night clubs (about 400 in the city) until March 14th, where people stay there 10 to 20 hours in weekends. Restaurants were allowed until yesterday and young people were partying in the parks until March 18th. Only some hours ago they forbid to gather more than 2 people.")

#text("I’m wondering if this means that Germany applies implicitly some kind of controlled herd immunity, by allowing young and supposedly healthy people to get infected at first quickly, follows their paths to test possibly infected people, then may be applying strict lock-downs for relatively short amounts of time (1-2 weeks). It is also interesting that Germany does not make as much test as they can do, contrary to S.Korea.")

#text("I would be very happy if one can comment on Germany’s strategy (which seems until now, quite successful).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547511")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("I am asking myself the same question as you on why does Germany’s death rate appears much lower than in France, Italy, Spain etc.")

#text("I don’t know, but as much as I’d love the answer to be “because their strategy/their hospitals are much better”, I think the most plausible explanation is that they run much more tests than any of these countries, hence blowing up the number of positive detections and artificially lowering the death rate. Germany has already performed 5 times more tests than France and Spain despite its number of deaths still being respectively 7 and 18 times lower. Sadly, Germany seems to be on the exact same exponential death trajectory as everyone else in Europe (trailing just a few days behind, maybe due to its specific decentralised demography): ")#link("https://twitter.com/jburnmurdoch/status/1241463928271581185/photo/1")[#text("https://twitter.com/jburnmurdoch/status/1241463928271581185/photo/1")]

#text("Nevertheless, it may very well be that their strategy of testing much more people will prove successful in slowing down the epidemics within the next weeks (as it did in some Asian countries). I definitely hope so!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547527")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("In my opinion the most important point is that Germany has an independent institution, the Robert Koch Institute, that advises the gouvernment. This helps to eliminate political partisanship from the process.")

#text("Their explanation for the low mortality rate compared to all other countries is that by developing the test early on Germany was able to test a lot, especially young members in the infection chains. Not just the old ones showing symptoms. Since young adults die less often this lowers the result. In the end the numbers will converge, they say. A herd immunity strategy at this early stage was not considered a viable strategy.")

#text("The social distancing measures are now in their second week with details depending on the local government. In any case schools and universities are closed. In some regions people are not allowed to leave their home, but the general rule is that no more than two people are allowed to be together in public.")

#text("Whether this strategy of testing a lot, pumping up hospital capacitíes (we are currently even treating french cases while waiting for the impact) and comparatively mild social distancing is successful can only be judged in a couple of months.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neez Duts")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547565")[#strong[#text("Neez Duts")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("Can someone please explain to me why young people can’t go out and party in the US? The only explanation I’ve heard is that they might then go infect grandpa back at home, which is utterly idiotic. The young people going out to party then can just make sure they don’t come into contact with old people. I currently live in a studio apartment (alone) and will make sure I don’t come into contact with essentially anyone not partying with me. Sure I might catch the coronavirus, but that’s on me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f44fe5eddb40e6f70ecca6076841d6a7f3c6fbe5a4c80c5f2e7a877b582f1f28-f25b9750343a89b3aac5b149ededf310bd7ffeeef29384cea988f81e3f12dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gönenç Onay")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547568")[#strong[#text("Gönenç Onay")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("An article on Spiegel claims that Germany follows another strategy than South Korea does, namely by not making so much tests (maybe this is already much more than what Italy, France or Spain can do)")

#link("https://www.spiegel.de/wissenschaft/medizin/coronavirus-testet-deutschland-zu-wenig-im-vergleich-zu-suedkorea-a-4fb86f9e-1a5f-4434-b05f-7fad3dda34f4")[#text("https://www.spiegel.de/wissenschaft/medizin/coronavirus-testet-deutschland-zu-wenig-im-vergleich-zu-suedkorea-a-4fb86f9e-1a5f-4434-b05f-7fad3dda34f4")]

#text("I agree that the role of RKI is very central and the government also accepted that they are following their advises. But than I am rather confused that they have allowed during almost a month huge gatherings after the first case appeared. Especially while in NRW there were already an important number of cases, and the first case was detected in Berlin, they did almost nothing for more than 10 days.")

#text("So I wonder if RKI has suggested not to apply a strict lock-down immediately when the first cases appeared. If yes, this is against to what Prof. Jewels would suggests but closer to a selective/controlled herd immunity strategy, non?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e0fd56049a8189a380fda42273fee0bc2b9ce50a7a224700afce1fe96194008-d71b4d207f9bb85a02159d9eb02ffc3ded2bfbce61de425e7d3d85b4f53db867.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Uwe Stroinski")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547607")[#strong[#text("Uwe Stroinski")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("Now I see what you mean.")

#text("The RKI was always against indiskriminate testing. This would overwhelm our testing capacity, they said.")

#text("For us germans this is obviously a bitter pill to swallow. Having respiratory problems and not getting tested for covid 19 (because the probability of not having it is huge) touches our sense of security. Whether this results in another strategy than South Korea, I cannot judge.")

#text("Publicly the RKI does not propose or comment measures. Imposing measures has to be done by the government and by the local administrations.")

#text("Since we have a federal organisation there is no consistent strategy. This is, by the way, the reason for much insecurity and criticism. I think, before people understood what has happened in northern Italy, it was simply impossible for a politician to shut down carnival or football.")

#text("The RKI has stated that a pandemy comes in waves.")

#text("In my understanding that implies that full lock down is not necessarily a good measure as long as you still have viable other options. Once you lift full lock down the pandemy comes back and then what? The goal seems to be to let people have just enough contact for the medical system not to break down. For this you need accurate numbers, we seem to have them and thus this might work in theory.")

#text("Actually. one can observe a flattening of the exponential growth of the number of infected in Germany. However the RKI stated this is due to an error that will be fixed over time. The effect is not real.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f44fe5eddb40e6f70ecca6076841d6a7f3c6fbe5a4c80c5f2e7a877b582f1f28-f25b9750343a89b3aac5b149ededf310bd7ffeeef29384cea988f81e3f12dc49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gönenç Onay")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-548226")[#strong[#text("Gönenç Onay")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2020")])]

#text("“In my understanding that implies that full lock down is not necessarily a good measure as long as you still have viable other options. Once you lift full lock down the pandemy comes back and then what? The goal seems to be to let people have just enough contact for the medical system not to break down. For this you need accurate numbers, we seem to have them and thus this might work in theory.”")

#text("I agree completely.")

#text("My point was rather the following:")

#text("Prof. Jewel claims strongly that one should react immediately after the very first cases and he shows some graphics comparing some Italian towns supporting clearly his claim.")

#text("On the other hand, even after more than 1000 cases, Germany took almost no measure: at Mar 7 there was already around 800 cases, and more than 28 cases in Berlin, with first infections having taken place in nightclubs. The first restriction came only one week after. Bars and nightclubs are closed on 14.03. Restaurants stayed open until 21.03 (between time some bars converted into “restaurants”, and “spaeties” became the new bars).")

#text("I do not claim that the above behavior of German authorities was wrong or right. But as far I understand Prof. Jewels point of view, according to him, this behavior was definitely wrong.")

#text("So my point, is just the following question: If this behavior was really wrong, how a country like Germany, which, already in 2012 prepared a detailed pandemy crisis scenario [1] after supposedly muted Sars-Cov (like exactly the one we are having right now) made such a mistake.")

#text("So, for me, it is non negligible that was a conscious choice and not a mistake. I would say, they saw maybe (following gps data?) that the virus was spreading mostly among the young persons, hence they permitted the virus spread a little bit more. At the end, ~70% of the population won’t need a professional healthcare, so there is no harm to let virus spread among those 70% (of course we don’t know who are these %70 person, but maybe RKI and/or gouverment has a rough approximation of it). But of course this is just a guess. I do not claim anything.")

#text("[1] ")#link("https://medium.com/@stevenmai555/coronavirus-german-bundestag-knew-about-sars-cov-2-since-2012-4c0c91a147c7")[#text("https://medium.com/@stevenmai555/coronavirus-german-bundestag-knew-about-sars-cov-2-since-2012-4c0c91a147c7")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec63391549c20d029fe21f24716b8bf7c797cc520cdf14ccc475d1457e87685b-bda1615a15b7fa1158807c8db0b663b704f5a1b2b51defec7dddf7cba622952c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547575")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("Hi, Terry! Mathematically the problem is formulated quite simply: We have a matrix of social interactions. How should we reduce/restructure it within limits compatible with functionality and resource limitations to minimize the maximal eigenvalue? There are simple questions like should you go shopping once a week or twice a week or who should wear masks: the servers or the clients and difficult ones like should you work shifts always with the same people or is it more beneficial to rotate. I don’t know the answer but my feeling is that we should split into small isolated communities with minimal interaction between them (so shifts with the same people, shopping at the same store as long as it is not known to be infected and closed, etc.). I have never seen any simple but reasonable model with 3-6 categories of people that would answer these questions but, hey, I have never seen the question asked this way either. We are doing it by common sense and trial and error now and in China it worked, but it would be nice if somebody smarter than I could come up with at least some approximation. At this moment I should say that the Israeli approach makes most sense to me and it more or less agrees with my intuition but their exponent hasn’t established yet. What would you say?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec63391549c20d029fe21f24716b8bf7c797cc520cdf14ccc475d1457e87685b-bda1615a15b7fa1158807c8db0b663b704f5a1b2b51defec7dddf7cba622952c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedja")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547582")[#strong[#text("fedja")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2020")])]

#text("More precisely. You run a local shop with 4 sellers 2 of which are needed every day to maintain the operation. The sellers are indistinguishable in their rate of emission to the outside community (both professional and private). Then it should be pretty obvious why when one random one of them gets infected, you are better off with 2+2 scheme than with the rotation one (each seller paired with each one) both in terms of the internal transmission and emission to the outside community (not to say that you can still possibly operate with the other pair if you cannot shut the store). The question is “by how much”. We can compute that (or just simulate, what the heck, the time is running out fast). The same question can be asked for every more complicated model of an operating unit and technically every business should have a restructuring plan for that like a fire evacuation one. The university one is simple, but many units are in a more sophisticated positions…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb6d82eb070e95b1687d3f83d9440a3bdeb8f4f4fe87033b575d1761cc22ca57-6002689b8e543f883cd78b86f9e8e899d1c266daf2baba04bc8fd23ac89f9d2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sibusiso Sibisi")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547717")[#strong[#text("Sibusiso Sibisi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2020")])]

#text("One of the gems in this talk is the quote: “the key is usually not that [models] are ‘right’, but that they provide an unexpected insight”. Such insights may lurk in diverse modelling approaches.")

#text("For example, one might consider a network of connected nodes representing individuals, households, communities, cities or countries. As applicable, each node might have attributes like age, population density etc. Connections between nodes might be direct transmissions or just social interactions between individuals (where such data is available). Or cities with attributes like distance or traffic volume between them (with judgement calls on when cities may be deemed to be spatially disconnected, informed by travel restrictions).")

#text("The network model might then be a random graph, with probabilistic assignments on infections and associated variables. There might be a fixed set of cities and variable connections as travel restrictions change deterministically or as other connection attributes vary probabilistically. This is akin to the Erdos-Renyi random graph model, which is well studied.")

#text("Alternatively, the graph might grow as a randomly branching directed tree for individual transmissions or as undirected (two-way) attachments between nodes representing clusters of people. The growth process might be degree-biased, like the Barabasi-Albert preferential attachment model or variants of it that allow for extended degree influence. Perhaps the latter might relate to Fedja’s post above on eigenvalues of a social interaction matrix.")

#text("An interesting variant (Bianconi-Barabasi) is the combination of preferential attachment and node “fitness” or, to be literal, lack of it in this case as it correlates to age. This can produce “condensation phase transitions” that might well be the unexpected insight for such modelling. If borne out, it might help with studying formation of infection “super-hubs” in the network.")

#text("Off-the-wall speculation perhaps, but these are times that demand it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-547894")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2020")])]

#text("Several models in epidemiology appear in")#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Compartmental_models_in_epidemiology")[#text("https://en.wikipedia.org/wiki/Compartmental_models_in_epidemiology")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93e96e92814988f219c345834b8f68260488ff657fe3f9cd2769dd5c3acd3bbf-211925cbb7abc01f70ce3beaacb095d6de2519fb91a58901cb536872456e1f73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-548390")[#strong[#text("George")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2020")])]

#text("Is a deck of the presentation slides available?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/621c63bcb90c9ca8e6d18cddbc410ba951f1f436b1ec7c90e4d0beb3b8c874f2-c673c35e70d080f73ba7083e7df0a2f7a785bd8db3b58e8f2e29efa414765e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of José Manuel Rodríguez Caballero")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-549691")[#strong[#text("José Manuel Rodríguez Caballero")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2020")])]

#text("Let’s assume that the maximum number of tests for COVID-19 per day is constant, whereas the number of cases grows exponentially. Then, there will be a moment when the number of cases will look like linear growth, but this will be just the effect of the inaccuracy of the measurement.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb6d82eb070e95b1687d3f83d9440a3bdeb8f4f4fe87033b575d1761cc22ca57-6002689b8e543f883cd78b86f9e8e899d1c266daf2baba04bc8fd23ac89f9d2f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sibusiso Sibisi")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-550028")[#strong[#text("Sibusiso Sibisi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2020")])]

#text("The growth in the number of deaths would continue to tell a different story.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-550551")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("Terry, I want to add one more question. Why people compare covid19 to flu, but not to pneumonia caused by all sorts of cold viruses, including coronaviruses? For example, if you look at weakly deaths from pneumonia here (")#link("https://gis.cdc.gov/grasp/fluview/mortality.html")[#text("https://gis.cdc.gov/grasp/fluview/mortality.html")]#text(") over the last several years, you can see that there is between 3,000-4,000 weakly pneumonia deaths in the US during the cold season. And covid19 did not affect this number at all. You might argue that lockdowns worked, but last weeks peak death numbers came from people getting infected before these lockdowns. Again, I don’t understand why hospital ICUs are overwhelmed now, while at the same time the number of pneumonia deaths is very typical? My only answer is that in the absence of panic, pneumonia deaths were allowed to occur naturally outside of ICUs. What is happening now is maybe the main reason why doctors and nurses in ICUs are exposed to high viral loads.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423b9edd6cabc6d205096f9a31574b20ee234a2fd9b10ccf9ad72a22cc48e352-dae76dcdccd62669d1088ead427e8b08a47cf40ca240c6a9fd147a782e85fd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-550578")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("Bill,")

#text("Your link is actually pretty convincing proof that you are completely off with your narrative of COVID being “just a flu”. Look carefully: the most recent data on the link you shared are for week 12 of 2020, ending March 21. On that week, only 232 COVID deaths had been reported across the US. The total US COVID death toll was 301 back then. No wonder that this doesn’t show any effect on the average ~3,000 pneumonia deaths a week!")

#text("Today, 16 days later, the death toll is 9,616 in the US, including 6,475 in the past 7 days only (x3 in a week). But these numbers are still growing *exponentially* (once again, emphasis on exponentially), so the number of deaths in the coming 7 days is going to be much higher, likely between 10,000 and 20,0000. Not to mention that these data are likely far below reality, since many people are dying from COVID in nursing homes or at home without being reported.")

#text("So yeah, as repeated over and over for the past months by expert virologist all over the world, this is much worse than the flu, or indeed, worse than any health crisis humanity has experienced in the past century. But in fact, these numbers could keep growing much faster and higher without proper mitigation policies, in particular as hospitals are getting saturated by COVID cases (non-COVID patients still need to be treated as well).")

#text("You keep talking about panic like it’s causing deaths, but I don’t believe there is any evidence supporting this. As far as we know, the main effect of what you call “global panic” so far is to make people buy more toilet paper. Big deal. And on the other hand, having the threat taken seriously by people makes them stay home and avoid contacts, which saves hundreds of thousands of lives.")

#text("I understand that you very much want COVID to be just like a flu (we all do!), but going around the internet making completely unsupported and random claims about it is not going to change reality. It is not helping anyone and is in fact dangerously spreading falsehood. I just wish you would use a bit more critical thinking and double check your own data source before posting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-550586")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("I am not spreading anything, I am just asking questions. So you are saying that next week will be maybe twice as bad as week 3 in 2018 season (which at the time was also growing exponentially). Isn’t next week supposed to be the peak? Look, I am completely open to what you and others are saying. I just want to know why 5,000 pneumonia deaths per week do not overwhelm hospitals in a normal year while now 6,000 pneumonia deaths last week did?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423b9edd6cabc6d205096f9a31574b20ee234a2fd9b10ccf9ad72a22cc48e352-dae76dcdccd62669d1088ead427e8b08a47cf40ca240c6a9fd147a782e85fd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-550595")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2020")])]

#text("Because this time cases are much more concentrated on urban epicentres like New York City (currently 50% of all US deaths), rather than spread all over the country, hence the saturation of local hospitals. We are having the same problem here in France, one small region in the east is much more affected than the others, so we have to transport patients to ICUs of other regions every day by train, plane and helicopters. They did similar things in Italy.")

#text("But the key thing to understand is that if we keep business as usual, literally *every city* will eventually become such an epicentre. This means complete collapses of national healthcare systems and death tolls I don’t even want to start imagining.")

#text("And unfortunately, in lack of a vaccine, a treatment, or a production capacity of billions of masks and millions of tests per week, national lockdown is currently the only way known by science to prevent this worst-case scenario to happen :/")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-551795")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("Watch this video and stop spreading the panic: ")#link("https://youtu.be/lGC5sGdz4kg")[#text("https://youtu.be/lGC5sGdz4kg")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-551796")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2020")])]

#text("He clearly explains that social distancing will result in more overall deaths among older people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423b9edd6cabc6d205096f9a31574b20ee234a2fd9b10ccf9ad72a22cc48e352-dae76dcdccd62669d1088ead427e8b08a47cf40ca240c6a9fd147a782e85fd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-552756")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2020")])]

#text("Bill,")

#text("*ALWAYS* check the reliability of your source of information. This is particularly true when watching random videos on YouTube.")

#text("In the case of “Professor Knut Wittkowski, for twenty years head of The Rockefeller University’s Department of Biostatistics, Epidemiology, and Research Design”, as cited in the caption of the video, it took me exactly 5 seconds of Google search to find this: ")#link("https://www.rockefeller.edu/news/27872-rockefeller-university-releases-statement-concerning-dr-knut-wittkowski/")[#text("https://www.rockefeller.edu/news/27872-rockefeller-university-releases-statement-concerning-dr-knut-wittkowski/")]

#text("This man has never been a professor at Rockefeller, and the university (which no longer employs him) just made the effort of explicitely distancing itself from him, most likely because of the dubious statements he is making on COVID.")

#text("Given this, I know I don’t need to waste my time watching the video (I haven’t).")

#text("Neither you, or me, or most of the readers of this blog are expert epidemiologists. Hence, the only way we can usefully share information on COVID is by only citing highly reputable scientific journals and universities, or highly reputable news sources that quote such highly reputable institutions. Only this way can we get closer to the truth and shield ourselves from the obscurentism spread by disinformation networks.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/423b9edd6cabc6d205096f9a31574b20ee234a2fd9b10ccf9ad72a22cc48e352-dae76dcdccd62669d1088ead427e8b08a47cf40ca240c6a9fd147a782e85fd63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-551247")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2020")])]

#text("Have you heard of pool testing?")

#text("This idea is both genius and simple: instead of analysing individual patients’ samples, mix a bunch of samples together, say 8, and run the test on this cocktail. If the result is negative, you can reliably conclude that none of the 8 patients were infected, from one single test. If the test is positive, just divide your samples into two groups of 4 and repeat, until either a negative result is reached or a single sample is left.")

#text("A pool-testing procedure for SARS-CoV-2 has recently been tested by German researchers: ")#link("https://aktuelles.uni-frankfurt.de/englisch/pool-testing-of-sars-cov-02-samples-increases-worldwide-test-capacities-many-times-over/")[#text("https://aktuelles.uni-frankfurt.de/englisch/pool-testing-of-sars-cov-02-samples-increases-worldwide-test-capacities-many-times-over/")]#text(". There is also this recent paper from Israel: ")#link("https://www.medrxiv.org/content/10.1101/2020.03.26.20039438v1")[#text("https://www.medrxiv.org/content/10.1101/2020.03.26.20039438v1")]

#text("This could multiply by 5 ore more the testing capacity of any country, right now, without the need for extra equipment.")

#text("It seems to me that the idea has received very little attention as of yet. It would be great to make it gain momentum! For those interested, I just wrote a blog post about the maths behind it: ")#link("https://members.loria.fr/ADeleforge/the-maths-of-pool-testing-mixing-samples-to-speed-up-covid-19-detection/")[#text("https://members.loria.fr/ADeleforge/the-maths-of-pool-testing-mixing-samples-to-speed-up-covid-19-detection/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-554688")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("Well, now we know that about 2.7 million NYC residents were infected. With 15000 deaths in NYC, a death rate is about 0.055, half of flu. Of course, there were 300% more deaths than normal in NYC over the last month because people do not have immunity, so the virus spread more and resulted in more deaths among immunocompromised people, which unfortunately includes many over 70.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf3f9333bb27c9fb137983ab09a8db8725a027dcd044600f2e413952e4d54d0c-9ee43cbbf03da69a499125c671343b88ad746a582b357e7a884cd38238030077.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-554721")[#strong[#text("Bill")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("I meant 0.0055, half percent. In other words, in line with extra death numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f13224c8222ecf9e922f2cb7a23fa7318601236e08a991a60359178ae1d2559e-c84b0356280b902603d9ed15bd7f802461e367837cb50fc09c90946332a76828.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zar")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-554728")[#strong[#text("Zar")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2020")])]

#text("The flu mortality rate is 0.1 percent not 1 percent, and that 0.1 percent is of symptomatic cases. There are asymptomatic cases of the flu as well, which makes the mortality rate even lower than 0.1 percent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2020/03/20/2019-2020-novel-coronavirus-outbreak-mathematics-of-epidemics-and-what-it-can-and-cannot-tell-us-nicolas-jewell/#comment-587323")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2020")])]

#text("The only issue I have with computing statistics in this manner (deaths or hospitalizations over predicted number of infected) is there is no way of knowing the accuracy and we can only speculate with crude figures on what that accuracy is… even simple things like counting the number of Covid-19 deaths is difficult since many of the people that die from Corona are old and have other complications. Additionally, there is some inaccuracy in the antibody tests from what I have heard.")

#text("I agree the death rate seems pretty low. Based on the antibody tests and the fact that most people that died had a bunch of other illnesses (only 6-9% according to the CDC died of only Corona), it seems like the “true” death rate (whatever that means) is hovering around .05% to .1%. This is based on the fact that roughly .1% to .9% is the estimated death rate using the antibody tests to count the number of infected, and since 6%-9% of infected were pure Corona deaths, I am guessing only 20% at most I would consider died due to Corona, giving .2*.1 %= .02% to .2*.9 % = .18 % as my range for the “true” death rate, which in my opinion is not scary.")

#text("My personal opinion on this matter is that at the beginning we needed to curb the spread of Covid since the hospitals were already near capacity. At this point in time though I think the restrictions should be lifted.")

#text("Slightly off topic, but I wanted to mention that I disagree with the notion of spreading “misinformation” some people have put forth. I think it is perfectly acceptable since it opens up the discussion to new ideas, even if those ideas are faulty and promulgate lies throughout the internet. Also, academics are circumscribed to only use quantitative arguments, which are more rigorous but often ignore intuition, which I think (with no proof of course) can be a better way of making decisions.")
]
]
