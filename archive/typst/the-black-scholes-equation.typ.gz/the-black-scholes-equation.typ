// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:16:49.837689+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Black-Scholes equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Black-Scholes equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 July 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/")[#text("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Some time ago, I wrote a ")#link("http://www.math.ucla.edu/~tao/preprints/Expository/Black-Scholes.dvi")[#text("short unpublished note")]#text(" (mostly for my own benefit) when I was trying to understand the derivation of the ")#link("http://en.wikipedia.org/wiki/Black-Scholes_equation")[#text("Black-Scholes equation")]#text(" in financial mathematics, which computes the price of various options under some assumptions on the underlying financial model. In order to avoid issues relating to ")#link("http://en.wikipedia.org/wiki/Stochastic_calculus")[#text("stochastic calculus")]#text(", ")#link("http://en.wikipedia.org/wiki/It%C5%8D%27s_lemma")[#text("Itō’s formula")]#text(", etc. I only considered a discrete model rather than a continuous one, which makes the mathematics much more elementary. I was recently asked about this note, and decided that it would be worthwhile to expand it into a blog article here. The emphasis here will be on the simplest models rather than the most realistic models, in order to emphasise the beautifully simple basic idea behind the derivation of this formula.")

#text("The basic type of problem that the Black-Scholes equation solves (in particular models) is the following. One has an ")#link("http://en.wikipedia.org/wiki/Underlying_instrument")[#text("underlying financial instrument")]#text(" S, which represents some asset which can be bought and sold at various times t, with the per-unit price ")#mi("S_t")#text(" of the instrument varying with t. (For the mathematical model, it is not relevant what type of asset S actually is, but one could imagine for instance that S is a stock, a commodity, a currency, or a bond.) Given such an underlying instrument S, one can create ")#link("http://en.wikipedia.org/wiki/Option_%28finance%29")[#text("options")]#text(" based on S and on some future time ")#mi("t_1")#text(", which give the buyer and seller of the options certain rights and obligations regarding S at an ")#link("http://en.wikipedia.org/wiki/Expiration_%28options%29")[#text("expiration time")]#text(" ")#mi("t_1")#text(". For instance,")

#enum(start: 1, 
[#text("A ")#link("http://en.wikipedia.org/wiki/Call_option")[#text("call option")]#text(" for S at time ")#mi("t_1")#text(" and at a ")#link("http://en.wikipedia.org/wiki/Strike_price")[#text("strike price")]#text(" P gives the buyer of the option the right (but not the obligation) to buy a unit of S from the seller of the option at price P at time ")#mi("t_1")#text(" (conversely, the seller of the option has the obligation but not the right to sell a unit of S to the buyer of the option at time ")#mi("t_1")#text(", if the buyer so requests).")],
[#text("A ")#link("http://en.wikipedia.org/wiki/Put_option")[#text("put option")]#text(" for S at time ")#mi("t_1")#text(" and at a strike price P gives the buyer of the option the right (but not the obligation) to sell a unit of S to the seller of the option at price P at time ")#mi("t_1")#text(" (and conversely, the seller of the option has the obligation but not the right to buy a unit of S from the buyer of the option at time ")#mi("t_1")#text(", if the buyer so requests).")],
[#text("More complicated options, such as ")#link("http://en.wikipedia.org/wiki/Straddle")[#text("straddles")]#text(" and ")#link("http://en.wikipedia.org/wiki/Collar_(finance)")[#text("collars")]#text(", can be formed by taking linear combinations of call and put options, e.g. simultaneously buying or selling a call and a put option. One can also consider “")#link("http://en.wikipedia.org/wiki/Option_style#American_and_European_options")[#text("American options")]#text("” which offer rights and obligations for an interval of time, rather than the “European options” described above which only apply at a fixed time ")#mi("t_1")#text(". The Black-Scholes formula applies only to European options, though extensions of this theory have been applied to American options.")]
)

#text("The problem is this: what is the “correct” price, at time ")#mi("t_0")#text(", to assign to an European option (such as a put or call option) at a future expiration time ")#mi("t_1")#text("? Of course, due to the volatility of the underlying instrument S, the future price ")#mi("S_{t_1}")#text(" of this instrument is not known at time ")#mi("t_0")#text(". Nevertheless – and this is really quite a remarkable fact – it is still possible to compute deterministically, at time ")#mi("t_0")#text(", the price of an option that depends on that unknown price ")#mi("S_{t_1}")#text(", under certain assumptions (one of which is that one knows exactly ")#emph[#text("how")]#text(" volatile the underlying instrument is).")

#metadata(none) <tao-d598f393e6c263cde281>

#heading(level: 1)[#text("— How to compute price —")]

#text("Before we do any mathematics, we must first settle a fundamental financial question – how can one compute the price of some asset A? In most economic situations, such a price would depend on many factors, such as the supply and demand of A, ")#link("http://en.wikipedia.org/wiki/Transaction_cost")[#text("transaction costs")]#text(" in buying or selling A, legal regulations concerning A, or more intangible factors such as the current market sentiment regarding A. Any model that attempted to accurately describe all of these features would be hideously complicated and involve a large number of parameters that would be nearly impossible to measure directly. So, in general, one cannot hope to compute such prices mathematically.")

#text("But the situation is much simpler for purely financial products, such as options, at least when one has a highly ")#link("http://en.wikipedia.org/wiki/Market_depth")[#text("deep")]#text(" and ")#link("http://en.wikipedia.org/wiki/Market_liquidity")[#text("liquid")]#text(" market for the underlying instrument S. More precisely, we will make the following (unrealistic) assumptions:")

#list(
[#strong[#text("Infinite liquidity.")]#text(" Market participants can buy or sell a unit of the underlying instrument S at any time. [In principle, the participant would need a certain amount of cash, or a certain amount of S, in order to buy or sell S, but see the infinite credit and short selling assumptions below.]")],
[#strong[#text("Infinite depth.")]#text(" Each sale of a unit of S of does not affect the price of futher sales of units of S.")],
[#strong[#text("No transaction costs.")]#text(" The purchase price and sale price of an asset is the same: in other words, the money spent by a buyer in a sale is exactly equal to the money earned by the seller.")],
[#strong[#text("No ")#link("http://en.wikipedia.org/wiki/Arbitrage")[#text("arbitrage")]#text(".")]#text(" There do not exist risk-free opportunities for market participants to instantaneously make money.")]
)

#text("With these assumptions, the supply situation is simplified enormously, because any participant in this market can, in principle, use cash to create an option to sell to others (for instance one can sell a call option for S and cover it by buying a unit of S at any time before the expiration time), in contrast to physical assets (e.g. barrels of oil) which cannot be created purely from market transactions. This freedom of supply leads to upper bounds on the price of a financial asset A; if any market participant can instantaneously create a unit of A at time ")#mi("t_0")#text(" from market transactions using an amount X (or less) of cash, then clearly one should not assign such a unit of A a price greater than X at time ")#mi("t_0")#text(", otherwise there would exist an arbitrage opportunity.")

#text("As a simple example of such an upper bound, if a deep and liquid market allows one to repeatedly buy individual units of A at a price of X per unit, then for any integer ")#mi("k \\geq 1")#text(", the price of k units of A has an upper bound of kX. (The true price may be lower, due for instance to volume discounts, but in general the price of k units of A will be a ")#link("http://en.wikipedia.org/wiki/Subadditive")[#text("subadditive")]#text(" function of A. Note though that if the market is not infinitely deep, then each purchase of a unit may increase the price of the next unit, leading to ")#link("http://en.wikipedia.org/wiki/Superadditive")[#text("superadditive")]#text(" behaviour instead.)")

#text("As another example, the price at time ")#mi("t_0")#text(" of a put option for a unit of S at time ")#mi("t_1")#text(" at strike price P cannot exceed P, because any market participant can create (and then sell) such an option simply by setting aside P units of cash to cover the future expense of buying a unit of S. (This is an extremely crude upper bound, of course, as the option buyer might not exercise the option, in which case the P units of cash are recovered, or the option buyer does exercise in the option, in which case the seller is compensated for the P units of cash by a unit of S. Also, we are assuming here that there are no costs (e.g. security costs) associated with holding on an asset over time.) For similar reasons, the price at time ")#mi("t_0")#text(" of a call option for a unit of S at time ")#mi("t_1")#text(" cannot exceed ")#mi("S_{t_0}")#text(".")

#text("Dually to the above freedom of supply, there is also a freedom of demand: any participant can, in principle, purchase a financial asset and convert it into cash by combining the rights offered by that asset with other purchases. For instance, one could attempt to profit from a put option by buying a unit of the underlying instrument S and then (if the price is favourable) exercising the right to sell that unit to the option seller. This freedom of demand leads to ")#emph[#text("lower")]#text(" bounds on the price of an asset: if any market participant can instantaneously convert a unit of A using market transactions into an amount X of cash, then clearly one should not assign a unit of A any price lower than X, otherwise there would be an arbitrage opportunity.")

#text("To give a trivial example: any option has a lower bound of zero for its price, since one can convert an option into zero units of cash simply by refusing to exercise it. (Note that some financial assets can have a negative cash value – mortgages being a good example.)")

#text("To summarise so far: freedoms of supply give upper bounds on the price of an asset A, and freedoms of demand give lower bounds on the price of an asset A. The lower bounds cannot exceed the upper bounds, as this would provide an arbitrage opportunity. But if the lower bounds and upper bounds happen to be equal, then one can compute the price of A exactly. This is a rare occurrence – one almost never expects the upper and lower bounds to be so tight. But, amazingly, this will turn out to be the case for options in the Black-Scholes model.")

#text("To give a simple example of a situation in which upper and lower bounds match, let us make another assumption:")

#list(
[#strong[#text("Infinite credit. ")]#text("Market participants can borrow or lend arbitrary amounts of money at a risk-free interest rate of r. Thus, for instance, participants can deposit (or lend) X amount of cash at time ")#mi("t_0")#text(" and be guaranteed to receive ")#mi("\\exp( r(t_1-t_0) ) X")#text(" cash at time ")#mi("t_1")#text(", and conversely can borrow X amount of cash at time ")#mi("t_0")#text(" but pay back ")#mi("\\exp( r(t_1-t_0) ) X")#text(" cash at time ")#mi("t_1")#text(".")]
)

#strong[#text("Remark. ")]#text(" One can renormalise r to be zero, basically by using ")#link("http://en.wikipedia.org/wiki/Real_versus_nominal_value")[#text("real units of currency")]#text(" instead of nominal units, but we will not do so here. ")#mi("\\diamond")

#text("With this assumption one can now compute the ")#link("http://en.wikipedia.org/wiki/Time_value_of_money")[#text("time value of money")]#text(". Suppose one has a risk-free government bond A which is guaranteed to pay out X amount of cash at the maturity time ")#mi("t_1")#text(" of the bond. Then, at any time ")#mi("t_0")#text(" prior to the maturity time, one can convert A to an amount ")#mi("\\exp(-r(t_1-t_0) ) X")#text(" of cash, by borrowing this amount of cash at time ")#mi("t_0")#text(", and using the proceeds of the bond A to pay off the debt from this borrowing at time ")#mi("t_1")#text(". Thus there is a lower bound of ")#mi("\\exp(-r(t_1-t_0)) X")#text(" to the price of the bond A. Conversely, given an amount ")#mi("\\exp(-r(t_1-t_0)) X")#text(" of cash at time ")#mi("t_0")#text(", one can create the equivalent of the bond A simply by depositing or lending out this cash to obtain X amount of cash at time ")#mi("t_1")#text(". Thus, in this case the lower and upper bounds match exactly, and the price of the bond can be computed at time ")#mi("t_0")#text(" to be ")#mi("\\exp(-r(t_1-t_0)) X")#text(". (Because of this fact, the quantity r in the Black-Scholes model is usually set equal to the interest rate of an essentially risk-free asset, such as short-term Treasury bonds.)")

#text("One can use the time value of money to produce further upper and lower bounds on options. For instance, the price at time ")#mi("t_0")#text(" of a put option for a unit of S at time ")#mi("t_1")#text(" at strike price P cannot be lower than ")#mi("\\exp(-r(t_1-t_0)) P-S_{t_0}")#text(", since one can always convert the put option into this amount of cash by buying a unit of S at price ")#mi("S_{t_0}")#text(" at time ")#mi("t_0")#text(", holding on to this unit until time ")#mi("t_1")#text(", and selling at price P at time ")#mi("t_1")#text(", which has the equivalent cash value of ")#mi("\\exp(-r(t_1-t_0)) P")#text(" at time ")#mi("t_0")#text(". However, in order to make the lower and upper bounds match, we will need some additional assumptions on how the price ")#mi("S_t")#text(" of the underlying stock evolves with time.")

#heading(level: 1)[#text("— The Black-Scholes model —")]

#text("To simplify the computations, we shall assume")

#list(
[#strong[#text("Discrete time. ")]#text("The time variable t increases in discrete steps of some time unit dt. (At each time t, one can make an arbitrary number of purchases and sale of assets, but the price ")#mi("S_t")#text(" of the underlying instrument stays constant for each fixed t, as guaranteed by the infinite depth hypothesis.)")]
)

#text("For instance, one could imagine a market in which the price ")#mi("S_t")#text(" only changes once a day, so in this case dt would be a day in length. Similarly if ")#mi("S_t")#text(" only changes once a minute or once a second.")

#text("The Black-Scholes model then describes how the next price ")#mi("S_{t+dt}")#text(" of the underlying instrument depends on the current price ")#mi("S_t")#text(". The whole point, of course, is that there is to be some randomness (or risk) involved in this process. The simplest such model would be that of a simple ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("random walk")]

#align(center)[#tao-fit-display[#mitex("S_{t+dt} = S_t + \\epsilon_t \\sigma (dt)^{1/2}")]]

#text("where ")#mi("\\sigma > 0")#text(" is a constant (representing volatility) and ")#mi("\\epsilon_t = \\pm 1")#text(" is a random variable, equal to +1 or -1 with equal probability; thus in this model the price either jumps up or jumps down by ")#mi("\\sigma (dt)^{1/2}")#text(" for each time step ")#mi("dt")#text(". (The factor of ")#mi("(dt)^{1/2}")#text(" is a natural normalisation, required for this model to converge to ")#link("http://en.wikipedia.org/wiki/Wiener_process")[#text("Brownian motion")]#text(" in the continuous time limit ")#mi("dt \\to 0")#text(". with this normalisation, ")#mi("\\sigma^2")#text(" basically becomes the amount of variance produced in ")#mi("S_t")#text(" per unit time.) One can assume that the random variables ")#mi("\\epsilon_t")#text(" are jointly independent as t varies, but remarkably we will not need to use such an independence hypothesis in our analysis. Similarly, we will not use the fact that the probabilities of going up or down are both equal to 1/2; it will turn out, unintuitively enough, that these probabilities are irrelevant to the final option price.")

#text("This simple model has a number of deficiencies. Firstly, it does not reflect the fact that many assets, while risky, will tend to grow in value over time. Secondly, the model allows for the possiblity that the price ")#mi("S_t")#text(" becomes negative, which is clearly unrealistic. (A third deficiency, that it only allows two outcomes at each time step, is more serious, and will be discussed later.)")

#text("To address the first deficiency, one can add a drift term, thus leading to the model")

#align(center)[#tao-fit-display[#mitex("S_{t+dt} = S_t + \\mu dt + \\sigma \\epsilon_t (dt)^{1/2}")]]

#text("for some fixed ")#mi("\\mu \\in {\\Bbb R}")#text(" (which could be positive, zero, or negative), representing the expected rate of appreciation of a unit of S per unit time. A remarkable (and highly unintuitive) consequence of Black-Scholes theory is that the exact value of ")#mi("\\mu")#text(" will in fact have no impact on the final formula for the value of an option: an underlying instrument which is rising in value on average will have the same option pricing as one which is steady or even falling on the average!")

#text("To address the second deficiency, we work with the logarithm ")#mi("\\log S_t")#text(" of the price of S, rather than the price itself, since this will make the price positive no matter how we move the logarithm up and down (as long as we only move the logarithm a finite amount, of course). More precisely, we adopt the model")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\log S_{t+dt} = \\log S_t + \\mu dt + \\sigma \\epsilon_t (dt)^{1/2}")]]

#text("and so ")#mi("\\mu")#text(" now measures the expected ")#emph[#text("relative")]#text(" increase in value per unit time (as opposed to the expected absolute increase), and similarly ")#mi("\\sigma^2")#text(" measures the relative increase in variance per unit time. This model may seem complicated, but the key point is that, given ")#mi("S_t")#text(", there are only two possible values of ")#mi("S_{t+dt}")#text(".")

#heading(level: 1)[#text("— Pricing options —")]

#text("Now we begin the task of pricing an option with expiry date ")#mi("t_1")#text(" at time ")#mi("t_0")#text(". The interesting case is of course when ")#mi("t_0")#text(" is less than ")#mi("t_1")#text(", but to begin with let us first check what happens when ")#mi("t_0=t_1")#text(", so that we are pricing an option that is expiring immediately.")

#text("Consider first a call option. If one has the option to buy a unit of S at price P at time ")#mi("t_1")#text(", and ")#mi("S_{t_1}")#text(" was greater or equal to P, then it is clear that this option could be converted into ")#mi("S_{t_1}-P")#text(" units of cash, simply by exercising the option and then immediately selling the stock that was bought. Conversely, given ")#mi("S_{t_1}-P")#text(" units of cash, one could create such an option (and might even recover this money if the bearer of the option forgets to exercise it). So we see that when ")#mi("S_{t_1} \\geq P")#text(", the price of this option is ")#mi("S_{t_1}-P")#text(".")

#text("On the other hand, if ")#mi("S_{t_1}")#text(" is less than P (in the jargon, the option is “underwater” or “out of the money”), then it is intuitively clear that the call option is worthless (i.e. has a price of zero). To see this more rigorously, recall that any option has a lower bound of zero for its price. To get the upper bound, one can issue an underwater call option at no cost, since if someone is foolish enough to exercise that option, one can simply buy the stock from the open market at ")#mi("S_{t_1}")#text(" and sell it for P, and pocket or discard the difference. Putting all this together, we see that the price ")#mi("V_{t_1}")#text(" of the call option at time ")#mi("t_1")#text(" is a function of the price ")#mi("S_{t_1}")#text(" of the underlying instrument at that time, and is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("V_{t_1}(S_{t_1}) := \\max( S_{t_1} - P, 0 ).")]]

#text("For similar reasons, the price ")#mi("V_{t_1}")#text(" at time ")#mi("t_1")#text(" of a put option for a unit of S at expiry time ")#mi("t_1")#text(" and strike price P is given by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("V_{t_1}(S_{t_1}) := \\max( P - S_{t_1}, 0 ).")]]

#text("Thus we have worked out the price of both put and call options at the time of expiry. To handle the general case, we have to move backwards in time. For reasons that will become clearer shortly, we shall also need three final assumptions:")

#list(
[#strong[#text("Infinite divisibility")]#text(". Stock can be sold in arbitrary non-integer amounts.")],
[#strong[#link("http://en.wikipedia.org/wiki/Short_selling")[#text("Short selling")]#text(".")]#text(" Market participants can borrow arbitrary amounts of stock, at no interest, for arbitrary amounts of time.")],
[#strong[#text("No storage costs.")]#text(" Market participants can hold arbitrary amounts of stock at no cost for arbitrary amounts of time.")]
)

#text("The fundamental lemma here is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma. ")]#text("If a financial asset A has a price at time t that is a function ")#mi("V_t(S_t)")#text(" that depends only on the price ")#mi("S_t")#text(" of S at time t, then the same asset has a price at time t-dt that is a function ")#mi("V_{t-dt}(S_{t-dt})")#text(" of the price ")#mi("S_{t-dt}")#text(" of S at time t-dt, where ")#mi("V_{t-dt}")#text(" is given from ")#mi("V_t")#text(" by an explicit formula (see (5) below).")
]

#text("Iterating this lemma, starting from (2) and (3), and taking the limit as ")#mi("dt \\to 0")#text(", will ultimately lead to the Black-Scholes formula for the price of such options.")

#text("Let’s see how this lemma is proven. Suppose we are at time t-dt, and the price of S is currently ")#mi("s := S_{t-dt}")#text(". We do not know what the price ")#mi("S_t")#text(" of S at the next time step will be exactly, but thanks to (1), we know that it is one of two values, say ")#mi("s_-")#text(" and ")#mi("s_+")#text(" with ")#mi("s_+ > s_-")#text(". From (1) we have the explicit formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4).")])
#mitex("s_\\pm = s \\exp( \\mu dt \\pm \\sigma (dt)^{1/2} )")]]

#text("By hypothesis, we know that the instrument A has a price of ")#mi("V_t(s_+)")#text(" or ")#mi("V_t(s_-)")#text(" at time t, depending on whether S has a price of ")#mi("s_+")#text(" or ")#mi("s_-")#text(" at this time t. Our task is now to show that A has a price at time t-dt that depends only on s.")

#text("Let us first consider the easy case when ")#mi("V_t(s_+)")#text(" and ")#mi("V_t(s_-)")#text(" are both equal to the same value, say X. In this case, the instrument A is (for the purposes of pricing) identical to a bond which matures at time t with a value of X. By the previous discussion, we thus see that the price of A at time t-dt is equal to ")#mi("\\exp(-r dt) X")#text(".")

#text("Now consider the case when ")#mi("V_t(s_+)")#text(" and ")#mi("V_t(s_-)")#text(" are unequal. Then there is some risk in the value of A at time t. But – and this is the key point – one can ")#link("http://en.wikipedia.org/wiki/Hedge_%28finance%29")[#text("hedge")]#text(" this risk by buying or selling some units of S. Suppose for instance one owns one unit of A at time t-dt, and then buys k units of S at this time at the price s. At time t, one sells the k units of S, earning ")#mi("k s_+")#text(" units of cash at time ")#mi("t")#text(" if the price is ")#mi("s_+")#text(", and ")#mi("k s_-")#text(" units if the price is ")#mi("s_-")#text(". In effect, this hedging strategy adjusts ")#mi("V_t(s_+)")#text(" and ")#mi("V_t(s_-)")#text(" to ")#mi("V_t(s_+)+ks_+")#text(" and ")#mi("V_t(s_-)+ks_-")#text(" respectively, at the cost of paying ks at time t-dt. If ")#mi("V_t(s_+) < V_t(s_-)")#text(", then one can find a positive k so that the adjusted values ")#mi("V_t(s_+)+ks_+")#text(" and ")#mi("V_t(s_-)+ks_-")#text(" of the instrument are equal (indeed, k is simply ")#mi("k = (V_t(s_-)-V_t(s_+))/(s_+-s_-)")#text("). We have thus effectively converted A, at the cost of ks units of cash at time t-dt, into a bond that matures at time t with a value of")

#align(center)[#mi("\\displaystyle V_t(s_+)+ks_+=V_t(s_-)+ks_- = \\frac{s_+ V_t(s_-) - s_- V_t(s_+)}{s_+-s_-}")#text(".")]

#text("Conversely, we can convert such a bond into one unit of A and ks units of cash at time t-dt by reversing the above procedure. Namely, instead of buying k units of S at time t-dt to sell at time t, one instead ")#emph[#text("short sells")]#text(" k units of S at time t-dt to buy back at time t. More precisely, one borrows k units of stock at time t-dt to sell immediately, and then at time t buys them back again to repay the stock loan. (Mathematically, this is equivalent to buying -k units of stock at time t-dt to sell at time t; thus short selling effectively allows one to buy negative units of stock, in much the same way that divisibility allows one to buy fractional units of stock.) We thus conclude that in this case, A has a value of")

#align(center)[#tao-fit-display[#mitex("\\exp(-r dt) \\frac{s_+ V_t(s_-) - s_- V_t(s_+)}{s_+-s_-} - ks")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{(\\exp(-rdt) s_+-s) V_t(s_-) - (\\exp(-rdt) s_- - s) V_t(s_+)}{s_+-s_-}")]]

#text("This analysis was conducted in the case ")#mi("V_t(s_+) < V_t(s_-)")#text(", but one can get the same formula at the end in the opposite case ")#mi("V_t(s_+) > V_t(s_-)")#text("; k is now negative in this case, but since buying a negative amount of stock is equivalent to short-selling a positive amount of stock (and vice versa), the arguments go through as before. Substituting the formula for k, we have thus proven the lemma, with")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("V_{t-dt}(s) := \\frac{(\\exp(-r dt) s_+-s) V_t(s_-) - (\\exp(-rdt) s_- - s) V_t(s_+)}{s_+-s_-}.")]]

#text("This is a somewhat complicated formula, but it can be simplified by means of Taylor expansion (assuming for the moment that ")#mi("V_t")#text(" is smooth). To illustrate the idea, let us make the simplifying assumption that r=0. If we then Taylor expand")

#align(center)[#tao-fit-display[#mitex("V_t(s_\\pm)=V_t(s)+(s_\\pm-s)\\partial_s V_t(s)+\\frac{1}{2} (s_\\pm-s)^2 \\partial_{ss} {V_t(s)}+O((dt)^{3/2})")]]

#text("(cautioning here that the implied constants in the O() notation depend on all sorts of things, such as the third derivative of ")#mi("V_t")#text(") and note that ")#mi("s_+-s_-")#text(" is comparable to ")#mi("(dt)^{1/2}")#text(" in magnitude, then the right-hand side of (5) simplifies to")

#align(center)[#tao-fit-display[#mitex("V_t(s) - \\frac{1}{2} \\partial_{ss} V_t(s) (s_+-s)(s_- - s) + O( (dt)^{3/2} ).")]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("(s_+ - s) (s_- - s) = - s^2 \\sigma^2 dt + O( (dt)^{3/2} )")]]

#text("we thus obtain")

#align(center)[#mi("V_{t-dt}(s) = V_t(s) + \\frac{1}{2} s^2 \\sigma^2 \\partial_{ss} V_t(s) dt + O( (dt)^{3/2} )")#text(".")]

#text("Performing Taylor expansion in t, we thus conclude")

#align(center)[#tao-fit-display[#mitex("\\partial_t V_t(s) = - \\frac{1}{2} s^2 \\sigma^2 \\partial_{ss} V_t(s) + O( (dt)^{1/2} )")]]

#text("and so in the continuum limit ")#mi("dt \\to 0")#text(" one (formally, at least) obtains the backwards heat equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t V = - \\frac{1}{2} s^2 \\sigma^2 \\partial_{ss} V.")]]

#text("A similar (but more complicated) computation can be made in the ")#mi("r \\neq 0")#text(" case (or one can renormalise using real currency units, as remarked earlier), obtaining the ")#emph[#text("Black-Scholes PDE")]

#align(center)[#mi("\\partial_t V = - \\frac{1}{2} s^2 \\sigma^2 \\partial_{ss} V - r s \\partial_s V + rV")#text(".")]

#text("Using (2) or (3) as an initial condition, one can then solve for V at time ")#mi("t_0")#text("; the quantity ")#mi("V_{t_0}(S_{t_0})")#text(" is then the price of the option at time ")#mi("t_0")#text(". (V can be computed explicitly in terms of the ")#link("http://en.wikipedia.org/wiki/Error_function")[#text("error function")]#text(", leading to the ")#link("http://en.wikipedia.org/wiki/Black-Scholes_formula")[#text("Black-Scholes formula")]#text(".)")

#text("The above analysis was not rigorous because the error terms were not properly estimated when taking the continuum limit ")#mi("dt \\to 0")#text(", and also because the initial conditions (2), (3) were not smooth. The latter turns out to be a very minor difficulty, due to the smoothing nature of the Black-Scholes PDE (which is a parabolic equation) and also because one can use the comparison principle (which formalises the intuitively obvious fact that if a financial asset A is always worth more than an asset B at time t, then this is also the case at time t-dt) to approximate the non-smooth options (2), (3) by smooth ones. The former difficulty does require a certain amount of non-trivial analysis (e.g. Fourier analysis or ")#link("http://en.wikipedia.org/wiki/It%C5%8D%27s_lemma")[#text("Itō’s formula")]#text(") but I will not discuss this here.")

#text("There is an enormous amount of literature aimed at relaxing the idealised hypotheses in the above analysis, for instance adding transaction costs, fluctuations in volatility, or more complicated financial features such as dividends. In some of these more general models, the upper and lower bounds for the prices of options cease to match perfectly, due to transaction costs or the inability to perfectly hedge away the risk; this for instance starts occurring when the underlying price ")#mi("S_t")#text(" can fluctuate to three or more values from a fixed value of ")#mi("S_{t-dt}")#text(", as it then becomes impossible in general to make V constant for all of these values at once purely by buying and selling S. In particular, the reliability of the Black-Scholes model becomes suspect when the price movements of S differ significantly from the model (1), for instance if there are occasional very large price swings.")

#text("The other major issue with the Black-Scholes formula is that it requires one to compute the volatility ")#mi("\\sigma")#text(", which is difficult to do in practice. In fact, the formula is sometimes used in reverse, using the actual prices in option markets to deduce an ")#link("http://en.wikipedia.org/wiki/Implied_volatility")[#text("implied volatility")]#text(" for an underlying instrument.")

#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d707a7232d544292227e6c17fcb9cd17b598f1724070621f5c8eec56b6135102-a3ac8e32c47df3e2b4e9b1f672ea79b7ed3262754491a2810e1fa51eb3101b98.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30700")[#strong[#text("Kenny")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2008")])]

#text("It seems to me that the basic idea just has two parts. The time value of money lets us calculate the fair price for an option for some instrument S with a known future price at its known expiration time. If instead, the instrument S has an unknown future price, but there are exactly two values it could take, then we can either buy or sell (depending on which of the two future values gives rise to a higher current option price) some appropriate number of units of S currently to hedge the difference. Thus, we can calculate the fair price of the option in these terms.")

#text("If this is right, then it looks to me like the current price doesn’t depend on the probability of the underlying instrument reaching one value or the other, provided that both values are possible. This seems somewhat surprising. Did I miss something in the derivation? I can’t find any application of expected value in the derivation, so it looks like I didn’t.")

#text("At any rate, the important thing in the derivation is that one can always find some specific amount of hedging that makes the higher and lower potential future price of S both give the same value for the combination of option and hedge. Once there are three or more possible future prices, it looks like that should be generically impossible. Since in practice I would think there are infinitely many possible future prices (or at least, as many as there are subdivisions of the currency in which the price is expressed) this seems like a very serious flaw indeed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d707a7232d544292227e6c17fcb9cd17b598f1724070621f5c8eec56b6135102-a3ac8e32c47df3e2b4e9b1f672ea79b7ed3262754491a2810e1fa51eb3101b98.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenny")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30701")[#strong[#text("Kenny")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2008")])]

#text("In fact, this seems to suggest a generalization of this theorem under the conditions assumed (infinite liquidity, short selling, and all the rest). I’ll also express all prices in real units of money for simplicity.")

#text("Theorem: If there is a time ")#mi("t_0")#text(" at which it is certain that either goods X and Y will have prices ")#mi("x_0")#text(" and ")#mi("y_0")#text(" or they will have prices ")#mi("x_0^{\\prime}")#text(" and ")#mi("y_0^{\\prime}")#text(" (with ")#mi("x_0\\neq x_0^{\\prime}")#text(" and ")#mi("y_0\\neq y_0^{\\prime}")#text("), then there exist constants ")#mi("a,b,c")#text(" with ")#mi("a\\neq 0,b\\neq 0")#text(" such that at all times ")#mi("t<t_0")#text(" at which this fact is known, the prices ")#mi("x_t,y_t")#text(" of X and Y satisfy the equations ")#mi("ax_t+by_t=c")#text(".")

#text("Proof: By the assumptions, at time ")#mi("t")#text(" one knows the values of constants ")#mi("a,b,c")#text(" such that ")#mi("ax_0+by_0=ax_0^{\\prime}+by_0^{\\prime}=c")#text(". If ")#mi("ax_t+by_t < c")#text(" then one could arbitrage by borrowing money to buy ")#mi("a")#text(" units of ")#mi("X")#text(" and ")#mi("b")#text(" units of ")#mi("Y")#text(", and sell them back at ")#mi("t_0")#text(" for ")#mi("c")#text(" units of money. If ")#mi("ax_t+by_t > c")#text(" then one could arbitrage by short-selling a units of ")#mi("X")#text(" and ")#mi("b")#text(" units of ")#mi("Y")#text(" and buying them back at ")#mi("t_0")#text(" for ")#mi("c")#text(" units of money. QED.")

#text("Of course, I suppose that the option pricing formula is interesting because even though there is only one time at which the future prices are restricted to two options, you can trace the time evolution backwards to get constraints on the relations between the prices at all earlier times. Once some of the movements in price have been seen to happen or not, one then updates the values of various parameters in the equation, and the relation between the prices may change.")

#text("I at first thought that the lack of dependence on the probability might contradict expected value theory, but now I see that since everything is linear in both the prices of X and Y (the instrument and the option), changes in one expected value are exactly reflected in changes of the other expected value.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30703")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2008")])]

#text("Hi Terence,")

#text("Russian PhD physicist Kirill Ilinski discusses Black-Scholes [equation with analysis] extensively in his book ‘Physics of Finance: Gauge Modelling in Non-equilibrium Pricing’, 2001. The index lists numerous pages.")

#text("The search inside feature is available on Amazon ")#link("http://www.amazon.com/gp/reader/0471877387/ref=sib_dp_ptu#reader-link")[#text(" Physics of Finance")]#text(". He uses mathematical dynamics, fiber bundles and gauge symmetry for money flows.")

#text("Although listed on Google books, browsing is not yet available.")

#text("Ilinski does discuss Ito calculus. He also has in interesting comparison of the 1905 Einstein formula of Brownian motion with the 1900 Bachelier formula for stock market motion in the first chapter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2fec6cda624d52107a9ca52311a6e3b3cad0f6434789ff44cfdc285b2e0ffb7f-f83f3bcd84fabb4e452d15e87221de7935af17d8fcb74d23c84019c0917a31af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carlbrannen")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30709")[#strong[#text("carlbrannen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")])]

#text("One of the first people to work on this was a professor of economics and mathematics (I believe) at U. Cal., Irvine, ")#link("http://en.wikipedia.org/wiki/Edward_O._Thorp")[#text("Edward O. Thorpe")]#text(". I heard him give a talk on the subject back around 1984 at a particle physics conference. Surprisingly, it is the only lecture I remember from that conference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30713")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2008")])]

#text("Dear Kenny,")

#text("You are correct that the transition probabilities from one price to the next end up being irrelevant for the task of pricing options; I’ve added this to the text.")

#text("The fact that one needs at most two possible outcomes for the price at each time step is indeed a limitation of the theory, though in practice the pricing function ")#mi("f_t(s)")#text(" is often reasonably linear with respect to small fluctuations in s (i.e. it is mostly differentiable), thus making it possible to hedge away most (though not all) of the risk when there are three or more outcomes at each time step. Note also that in real-world exchanges, prices do tend to be discretised (e.g. in multiples of eights or tenths of a cent), so assuming that there are only a few outcomes at each time step is not too unreasonable when the time step is small.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c36abc819a6f677defa6ba3c408a97bffe2efa24e82fcfca5703ef73e9a87888-4e318a7da43897d74b01c84efb8d07bc264d85aa2fabd65ef866bc106874b4d5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Frank Morgan")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30719")[#strong[#text("Frank Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("Hi Terry,")

#text("Restricting to two outcomes is really no limitation, since for example Brownian motion, with its continuum of possibilities at each moment, is a limit of discrete random walks with two outcomes at each step. I have a little exposition of Black-Scholes at")

#link("http://www.williams.edu/Mathematics/fmorgan/MorganBlackScholes.pdf")[#text("Click to access MorganBlackScholes.pdf")]

#text("Incidentally, if one is willing to assume the existence of “risk neutral probability,” there is a relatively short, direct derivation of the Black-Scholes call formula; see Shreve’s excellent Stochastic Calculus for Finance II: Continuous-Time Models, Springer, 2004.")

#link("mailto:Frank.Morgan@williams.edu")[#text("Frank.Morgan@williams.edu")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e95661c25da059f5cf9d3272b8afe00da9eb5f4c965468b3e36f69195ee45c00-fed85588a2200bd475e70c984295c4e6d3cbd9592c9d9add012679190b28491c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tndal")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30725")[#strong[#text("tndal")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("Readers might be interested in Nicholas Nassim Taleb’s paper")#linebreak()#text(" “Why We Have Never Used the Black-Scholes-Merton Option Pricing Formula”")

#text("at ")#link("http://papers.ssrn.com/sol3/papers.cfm?abstract_id=1012075")[#text("http://papers.ssrn.com/sol3/papers.cfm?abstract_id=1012075")]

#text("from the abstract:")

#text("“we have historical evidence that")

#text("1) Black, Scholes and Merton did not invent any formula, just found an argument to make a well known (and used) formula compatible with the economics establishment, by removing the “risk” parameter through “dynamic hedging”,")

#text("2) Option traders use (and evidently have used since 1902) heuristics and tricks more compatible with the previous versions of the formula of Louis Bachelier and Edward O. Thorp (that allow a broad choice of probability distributions) and removed the risk parameter by using put-call parity.")

#text("3) Option traders did not use formulas after 1973 but continued their bottom-up heuristics.")

#text("The Bachelier-Thorp approach is more robust (among other things) to the high impact rare event. The paper draws on historical trading methods and 19th and early 20th century references ignored by the finance literature. It is time to stop calling the formula by the wrong name.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("It is worth noting how the Black-Scholes formula (or its more robust relatives, as described by Taleb) are used in practice.")

#text("1) First, it is *never* used to obtain the price of an option from only information about the underlying asset (e.g., IBM stock). In other words, the derivation of the formula, as described above and everywhere else, is a nice story, but the formula is never used literally in that fashion.")

#text("The key reason for this is that you do not know what volatility to use. If you didn’t know any better, you would use a volatility computed using historical IBM stock prices. But this will always give you the wrong answer for many reasons. One is that this works *only* if the stock price really does follow a geometric Brownian motion.")

#text("2) The first common usage of the formula is for quoting prices. Two traders are negotiating a price for an option. If they spoke in dollar terms, they would have to readjust the price every time IBM stock price moves (which is very often). This is a pain. So options traders have learned to quote option prices using “implied volatility”, i.e., the volatility that if you feed it into the formula gives the price you’re willing to buy or sell at. This allows the trader to quote a “price” that he is more willing to stand by for a period of time, as long as the stock price does not move too much.")

#text("Note that the formula need not be an exact pricing formula for this to work well. It only needs to capture first order (“:delta”) effects in the option price movement when the stock price moves. To the extent that it also captures second order (“gamma”) effects, that’s even better.")

#text("2) Another common usage is “nonlinear interpolation”. Standard IBM call and put options trade frequently on exchanges, and their prices are readily observed directly. But now you want to estimate the price of a non-standard (“exotic”) option on IBM stock. What volatility should you use? Well, the idea is to use the implied volatility of an appropriately chosen call/put option. This can be taken further. The BS formula can be extended to a volatility function (of stock price and time to exercise). This “volatility surface” can be calibrated to the implied volatilities of standard options and then used to price an exotic one.")

#text("But Taleb’s warning is quite relevant here. Adjustments to the B-S model are *always* used, especially if the strike price is very different from the current stock price. This is commonly known as a “skew adjustment”.")

#text("3) The third is for risk management. What happens to the value of your portfolio if stock prices move sharply upward or downward? Here, the assumption is that you *know* today’s value of each option in the portfolio, and you want to simulate price changes. The B-S and other mathematical models are commonly used for this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1986c1e320603c9eb08dcc67d1c39529f90b28c6dabe5d16382e95bf91f27d29-9703a1167f50ec886811bcb30b38bfa75e53bb05797cb27861375746265cabb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FSK")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30728")[#strong[#text("FSK")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("I wrote a series of posts on the Black-Scholes formula. The problem is not the formula derivation. The problem is that the underlying assumptions are wrong. If your axioms are wrong, no amount of calculation will get you a conclusion that isn’t nonsense.")

#link("http://fskrealityguide.blogspot.com/2008/03/black-scholes-formula-is-wrong-part_22.html")[#text("http://fskrealityguide.blogspot.com/2008/03/black-scholes-formula-is-wrong-part_22.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30732")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("Dear FSK,")

#text("I believe that Axiom 1 in your post (that the expected return ")#mi("\\mu")#text(" of a stock equals the risk-free rate r) is not actually used in the Black-Scholes derivation (for instance, it is not used in my post above; at no point do I postulate that ")#mi("\\mu")#text(" is equal to r). The more accurate statement, which you also note in Part 3 of your post, is that the expected rate of return is in fact irrelevant for the derivation of the Black-Scholes formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2be7063d30cc0fed6cc2d0e7de64272e793922643132ecec511f1a42d3c3fb8-4d12764af0ebffc13264c6e0143fa071fee6eeac8e9e5f72d89fea1d73a0bf1d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stevem")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30734")[#strong[#text("stevem")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("The start of your derivation seems reminiscent of the gamblers ruin problem in terms of a fair coin, modelled as a discrete random walk? You assume a fair game or martingale? (I have’nt had time to follow all the details through though.) I’m more familiar with the Black-Scholes equation from the persepective of the machinary of Ito calculas, stochastic DE and martingale theory, but this can become very technical when applied in detail to finance. From the Ito calculas, a geometric Brownian motion is quickly established as the underlying stochastic process for the Black-Scholes theory.")

#text("As regards the Black-Scholes model its main flaw is this underlying assumption of Gaussianility: Gaussian noises, Brownian motions etc. Gaussians are correct for many situations like diffusions and coin tossings, and physicists like them since they know from their experience with statistical mechanics and quantum mechanics (and even gauge theory) that they can usually get nice and solvable models.")

#text("However, many real world systems are not described by Gaussians: amplitudes in earthquakes, velocity distributions in turbulent fluids, heart rythyms, and importanty, statistical properties of financial time series. For financial data, Levy (power law) distributions are more realistic since they have “fat tails” or Pareto tails; in effect, rare/extreme events that a Gaussian suppresses can arise quite frequently for stochastic prcesses governed by a Levy distribution. (Mandelbrot first noticed this fat tail phenomena by analysing data from the cotton market.) These distributions are “leptokuric” in that the higher-order cumulants are nonvanishing unlike the Gaussian, and this can (and does) make a serious difference.")

#text("In effect, the underlying stochastic process associated with real financial data cannot (in the strictest sense anyway) be a geometric Brownian motion and the “riskless portfolio” is utimately just a mathematical idealisation–the hedge fund LTCM found this out the hard way. Nevertheless the B-S theory is still an elegant and interesting application of Ito calculas and stochastic DE.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1986c1e320603c9eb08dcc67d1c39529f90b28c6dabe5d16382e95bf91f27d29-9703a1167f50ec886811bcb30b38bfa75e53bb05797cb27861375746265cabb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FSK")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30744")[#strong[#text("FSK")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("The fallacy of the Black-Scholes formula occurs when you consider a retail customer buying an option.")

#text("As a bank or hedge fund, you may borrow at the risk free interest rate (or close to it). In that case, it makes almost no difference if you buy a call option or replicate it via a delta hedging strategy.")

#text("If you’re a retail customer, who can’t borrow at the risk-free interest rate, then buying a call option is a great deal. You may borrow at the risk-free interest rate via the option, which you couldn’t do otherwise.")

#text("Assuming a log-normal distribution of prices, the distribution is determined by two factors: mean and variance. The put-call parity formula guarantees that mean equals the risk-free interest rate. Otherwise, there would be an arbitrage opportunity for professional options traders, who may easily borrow/lend for close to the risk-free interest rate.")

#text("However, *EVERYONE* knows that the expected return of stocks is greater than the risk-free rate. Otherwise, why bother with stocks at all? Just lend your money at the risk-free interest rate.")

#text("This is the inherent contradiction. As a conclusion (not axiom), you price options as if mean equals risk-free rate. However, it’s obvious from actual market data that mean is greater than the risk free rate.")

#text("The problem is the inherent injustice in the US monetary system. There’s a division by zero error in every economic calculation. The long-term value of fiat money is zero, due to money supply inflation.")

#text("When a bank or hedge fund borrows at the risk-free rate, they aren’t borrowing from someone else. They’re borrowing brand new money into existence. This is the essence of what I call “The Compound Interest Paradox”.")

#text("The injustice of the US monetary system is that banks and hedge funds may borrow at the risk-free rate. Individuals and small business owners may only borrow at higher rates, or not at all. Essentially, this is a massive government subsidy of the financial industry, paid by everyone else as inflation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30747")[#strong[#text("uglychart.com: a blog about stocks » Blog Archive » links for 2008-07-04")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")]

#text("[…] The Black-Scholes equation « What’s new Nevertheless – and this is really quite a remarkable fact – it is still possible to compute deterministically, at time t_0, the price of an option that depends on that unknown price S_{t_1}, under certain assumptions (one of which is that one knows exactl (tags: finance stocks options) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30748")[#strong[#text("Notional Slurry » links for 2008-07-04")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")]

#text("[…] The Black-Scholes equation « What’s new (tags: via:arsyed finance financial-engineering mathematics models explanation Black-Scholes prediction) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/356d1e7f74e1644c06bf4b6548704f28194bfe6d29f13e5408d97c7ef65432c0-d997fe48c18725004e9e88b25e7b5fa227381cecf7cb8bbca614e7b7b137c6ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of josef teichmann")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30749")[#strong[#text("josef teichmann")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2008")])]

#text("The point in the “modern” derivation of the Black-Merton-Scholes formula is the unique existence of an equivalent martingale measure for the discounted price process.")

#text("If one agrees about a geometric Brownian motion (in its natural filtration) with whatever drift $ \\mu $ as historical model for the price process $ S $ (on a finite interval $[0,T]$) and constant interest rate $r$, then — due to the presence of trading — there is a unique solution for the following “trading equation”: let us denote by $ U $ the discounted price process $ U_t = \\exp(-rt) S_t $, then for every $ T > 0 $ there is a unique $ p > 0 $ and a unique square integrable strategy $ h $ such that")#linebreak()#text(" $$")#linebreak()#text(" {\\exp(-rT)(S_T -K)}_+ = p + \\int_0^T h_s dU_s")#linebreak()#text(" $$")#linebreak()#text(" holds true. This means economically that one can hedge all the risk of the European call $ {(S_T – K)}_+ $ if one receives the premia $ p > 0 $. The martingale measure appears in the solution of the previous equation, since if we have one, say $Q$, for $ U $ one can solve the trading equation by taking conditional expectations (for instance $ p = E_Q ({exp(-rT)(S_T -K)}_+$). However, we know by Girsanov’s theorem that there is precisely one martingale measure for $ U $. The PDE-approach appears for me as a second way of seeing things. The meaning of the measure $Q$ is obviously pricing (as a helper for the trading equation), not statistics at this level.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30766")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("Dear FSK,")

#text("The put-call parity formula is equivalent to the assertion that the present value of a stock future is equal to the present value of the stock itself (which in fact follows immediately from the premise that one can borrow stocks at no interest), since a stock future is equivalent to a linear combination of puts, calls, and cash. But the present value of a stock future is not the same as the discounted expectation of the future stock price, due to the presence of a risk premium in the latter but not the former. In particular, an arbitrageur cannot risklessly exploit a difference in the discounted expectation* of the future stock price and the present stock price (or equivalently, a difference between the mean growth of the stock and the risk-free growth rate) purely by options and futures; there is no way to hedge away the risk that the stock price in fact deviates from its expectation without cancelling the difference of that expectation from the risk-free rate that one is trying to exploit in the first place.")

#text("[*] Here, when I refer to expectation, I mean the expectation with respect to the actual (physical) probability distribution of the stock. This is distinct from the ")#link("http://en.wikipedia.org/wiki/Risk-neutral_measure")[#text("risk-neutral probability distribution")]#text(" of the stock. The expectation of any stock, by definition, does indeed increase at the risk-free rate with respect to the latter probability distribution, even though it is likely to increase at a higher rate with respect to the physical probability distributions. But because the probability distributions are different, one cannot arbitrage the difference between the two. The risk-free probability distribution is a mathematical tool which, when used correctly, is very convenient for the purposes of calculations such as those in the Black-Scholes theory, but should not be confused with the real (or assumed) physical probability distribution on the underlying stock.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9a8ed485efa51c7812dd91256a91ef3115dfcb9c435f3cba01c394bcccae188-1d883d9e5b42cce15e96876d1c22a77c54f70b3f5fd985ce56a391b0e15fd3c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiri Hoogland")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30768")[#strong[#text("Jiri Hoogland")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("Hi,")#linebreak()#text(" in light of your derivation of BS I thought you might be interested in the approach that is described in an article ")#link("http://arxiv.org/abs/cond-mat/0108137")[#text("http://arxiv.org/abs/cond-mat/0108137")]#linebreak()#text(" I wrote some time ago which makes explicit the underlying symmetry that is embodied in trading derivative instruments. The idea is that by making the symmetries explicit one in general simplifies/clarifies the structure of the problem at hand. In this case the trading and hedging of a derivative instrument on a bunch of tradable instruments.")

#text("I do not have to introduce the rather un-intuitive concept of a risk-neutral measure. The real point being that underneath that risk-neutral measure concept is hidden the fact that you can trade in and out of a position in tradables (in a complete market). This trading translates into a scaling symmetry on the prices of derivative instruments which provides a much cleaner way to look at a derivative price. It also allows one to relate seemingly unrelated instruments through symmetry operations. The only constraint one has to impose is that you work in proper coordinates, which in the context of finance, are self-financing portfolios.")

#text("It provides an alternative way of looking at pricing derivatives compared to the standard approach.")#linebreak()#text(" Regards,")#linebreak()#text(" Jiri")#linebreak()#text(" Obviously it ties to")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luke")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30771")[#strong[#text("Luke")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2008")])]

#text("@FSK")

#text("You have some misunderstandings. I’m a math major who went into finance; I understand this stuff quite well.")

#text("First, financial institutions do not borrow at the risk-free rate. Most borrow at LIBOR. Recently the Fed has extended its window to more institutions, but even that has a spread between borrow and lend. Hedge funds pay LIBOR or an even wider spread.")

#text("In other words, even financial institutions cannot delta hedge without cost. They may do it more cheaply than individuals, but still not without cost. This cost is passed on by the bid-ask spread (i.e. they sell options for more than they buy them).")

#text("Second, it’s true options are priced at risk-free rate growth, even though stocks grow (on average) at a faster rate. Hence, it’s true that you can make money on average buying call options (assuming the vol priced into the option is the real vol). However, now you’ve got risk. Whereas if you can delta hedge with no transaction cost, you have no risk. If you do the calculus, you’ll find that there’s a linear tradeoff between your risk and expected returns. Read up on CAPM if you’re interested in a simplified discussion of this, or read a math finance book for all the details.")

#text("Third, fiat money does not have 0 long term value. You are forgetting that money can be invested. *Any* individual can buy treasuries to get the risk-free rate (which is often much better than your bank will offer you!), or even buy inflation-protected treasuries. The rate on treasuries is basically always greater than inflation. Thus, your real (inflation-adjusted) money actually GROWS in value over time. (This is possible because GDP also grows over time.)")

#text("*Cash* has 0 long term value. You should not keep your money in cash, obviously.")

#text("Fourth, you are correct that money is created by lending. However, this is not the cause of inflation. Even if everyone lended the maximum they could, it would only amount to a finite money supply. Lending and borrowing are regulated by the Fed. Hence, money supply is ultimately regulated by the Fed. It is the Fed’s job to keep the money supply at the correct size. It is by no means an easy job. On the other hand, a gold standard could keep the money supply at a fixed size, but this makes no sense because GDP is growing, not to mention there is not enough gold in the world ($4 trillion at current prices) to match the value of all dollars in circulation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30778")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2008")])]

#text("There are some fascinating problems regarding markets for which the Black-Scholes formula is quite relevant. The first and most directly related is to explain the systematic bias in applying B-S for real option prices. A second question is to explain the very high volatility of prices, and a third question is to explain the phenomenon of crushes and bubbles. These looks like great scientific problems where mathematics has a lot to offer. Any thoughts on these questons, Terry?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-30794")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2008")])]

#text("Hi Terence,")

#text("I see that Kirill Ilinski and Jiri Hoogland are both members of ")#link("http://www.ge.infm.it/~ecph/community/index.php")[#text(" econophysics.org")]#text(". Kirill has about 9 of 26 arxiv papers in the statistical mechanics subsection and Jiri has about 7 of 18 arxiv papers in the condensed matter section of physics. Their concepts appear to be similar even though the terminology is slightly different.")

#text("Currently such papers linking various dialects of mathematical disciplines are difficult to find since only the arxiv for computer science has a section on finance.")

#text("I recall that you were able to relate Tropical Algebras [probably a type of discrete dynamics] to dynamic game theory [discrete or continuous] through degree mapping.")

#text("Gilbert Strang, ‘Linear Algebra’, page 419 also is able to show a relationship among physics, electrical and mechanical enginneering and economics.")

#text("Is this a means of unifying mathematics – through dynamics and stochastics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-31055")[#strong[#text("Giovanni")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2008")])]

#text("Dear Terence")

#text("I think the Black-Scholes equation is very “trendy” with eventually positive returns in short term in financial markets. But in the long term is not strategic because the physic of real economy answers at endogenous events that are expected such that the price of a option is equivalent to a price of share and so is more significant the fundamental value of the enterprise that issue credit notes.")

#text("Best regards")#linebreak()#text(" Giovanni")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-31127")[#strong[#text("Arrow’s Economics 1 « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2008")]

#text("[…] relevant blog post concerning financial mathematics is Tao’s recent description of the Black-Scholes formula. The systematic difference between the Black-Scholes formula and the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-31135")[#strong[#text("Market Based Control » Blog Archive » The Tao of Black-Scholes")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2008")]

#text("[…] Australia’s only Fields Medallist, Terry Tao, has a post about the Black-Scholes equation, here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28cd72d7a345d12cbcbadc82a344edc288e368536aac9db2f99943e265e4921a-ac69785e9ee3532d83488793935f1d719ea735d2fd5c0a9a05c1ecdf2a7d21e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Black Scholes code")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-31755")[#strong[#text("Black Scholes code")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2008")])]

#text("Black Scholes formula is widely used for vanilla option pricing, which is also easy to code, there is over 30 ways to program it, have fun.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mean field games « What’s new")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-43136")[#strong[#text("Mean field games « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("[…] uncertainty of future cost caused by the random noise. (A similar diffusive effect appears in the Black-Scholes equation for pricing options, for much the same […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9354464470063cea207300c28a7f069176a53746d28fe792746b2df45cc8efcc-75ec5d615a0ec6b35d944f012e374e2bb8746226788ca797274384450de22dd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-44164")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2010")])]

#text("What is exactly the Bachelier-Thorp approach, how is it different from BS formula, and did how Thorp, Taleb etc useit in practice?")

#text("Can anyone shed some light on this with also some examples, as the above mention only BS and its shortcomings.")

#text("Cheers")

#text("Mike")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0a41dda8180d9927854f63da8f8326d35f55f2c22caf954360bca0f3292e9f6-b846ed522da9d8239353100d5287578fec3ed744833b915e0bc8cb57dfef583a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DS")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-50924")[#strong[#text("DS")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2011")])]

#text("For you reference here is a Black-Scholes online calculator")

#link("http://indoorworkbench.com/?financerisk/black-scholes-option-calculator.html")[#text("http://indoorworkbench.com/?financerisk/black-scholes-option-calculator.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-111136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Hello Professor Tao,")

#text("In various books, I see people attempt to price options by solving the Black Scholes PDE with various boundary conditions (corresponding to the large number of different options) using a finite difference method. They usually use the Lax equivalence theorem, which requires that the problem be well-posed. However, I never see any discussion of the well posedness of the problem. I gather that well-posedness requires existence and uniqueness of a solution and some sort of stability. I was wondering whether you might be able to tell me what the stability condition is and also how one establishes existence and uniqueness. Since this is only tangentially related to your post, I’ll completely understand if you do not have time to answer it, but in that case, if it is not too much trouble, could you possibly suggest a reference? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rise and Fall of Personal Computing « Front to Back Books")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-124080")[#strong[#text("Rise and Fall of Personal Computing « Front to Back Books")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2012")])]

#text("[…] and Terry Tao on Black Scholes, here Advertisement LD_AddCustomAttr(\"AdOpt\", \"1\"); LD_AddCustomAttr(\"Origin\", \"other\"); […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Why Read the Heroes? « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-137026")[#strong[#text("Why Read the Heroes? « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2012")])]

#text("[…] the consistency of Peano Arithmetic as described here after winning a Fields Medal in 2006, see The Black Scholes Equation and Hilbert’s Fifth Problem and related […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-205638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2012")])]

#text("Hi Terence,")

#text("You mention that some justification is required when taking the continuum limit dt -> 0 (you mention Fourier analysis). Do you happen to have a reference for this (perhaps including the smoothing argument)?")

#text("Regards.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abe6eab269fff042f1571ccaaf72969c052df65c19be15a4980ea2e479d3a667-5aea2992ff98d23c82d9c71a2160c24761b581b231b51761246d1a40a84e18ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-322631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2014")])]

#text("The formula (4) is wrong. One has to delete the “1” term.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abe6eab269fff042f1571ccaaf72969c052df65c19be15a4980ea2e479d3a667-5aea2992ff98d23c82d9c71a2160c24761b581b231b51761246d1a40a84e18ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-344341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2014")])]

#text("You start from a brownian motion and take the log to keep the values positive. Then you arrive at equation (4) . Later you use only the first term taylor approximation of this formula. Basically, what you’ve done here is the derivation of the geometric brownian motion.")#linebreak()#text(" I think it would be more natural to start directly from the geometric brownian motion, because the amount of change of a stock price is relative to the current price.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-349821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2014")])]

#text("Mathematicians are not half as smart as they think they are and in reality they are the most gullible people in assistance; they will swallow anything.You surely don’t think that G.M.B. has anything to do with finance? It’s more likely to be a “Freudian Slip” where the Truth is unintentionally revealed. I was in the little boy’s having a problem because my GMB. was just much too big so I deduced that I need more Greens! Hope this helps.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b7e7e8ac4ff15f3c57a19cce156b32adf16045492076a55f1ca820a918687b00-84297b321d443d2fe29cd137930857f66e90c7b6e9903c5f7cb66330948410bc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgar's Creative")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-346344")[#strong[#text("Edgar's Creative")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2014")])]

#text("Reblogged this on ")#link("http://edgarventurescreative.wordpress.com/2014/05/19/the-black-scholes-equation/")[#text("Edgar's Creative")]#text(" and commented:")#linebreak()#text(" Terry Tao once upon a time on the Balck-Scholes Equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-456929")[#strong[#text("Option Pricing & Music Industry | Chhogori by HRW™")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2015")]

#text("[…] The Black–Scholes Equation Expository article by mathematician Terence Tao. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-464461")[#strong[#text("Batfish in Gotham (where is Laurent Schwartz? part 2) | Mathematics without Apologies, by Michael Harris")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2015")]

#text("[…] displayed in all its enigmatic majesty on p. 85, and although I did more or less manage to follow its derivation on Terry Tao’s blog, my command of the underlying concepts has always been shaky at best. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c935d3e0b69c3fe73a864a2de52513750618e1267ad7f7e5046377635d58c4ca-ae25666e2277e547f496e73140b31709b4b8ce234d70b62cbc1c158f9aea36c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tomcircle")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-466354")[#strong[#text("tomcircle")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2016")])]

#text("Reblogged this on ")#link("https://tomcircle.wordpress.com/2016/02/20/the-black-scholes-equation/")[#text("Math Online Tom Circle")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ff93f4e7e15999ef94c77de9b661b79bc05b2e0408a9d62a698e2753f94207-2973badff05aece490148e8bea3c8f572310e327a9bf689a7107707af2c8142e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isomorphismes")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-484476")[#strong[#text("isomorphismes")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2017")])]

#text("I think you should try to get a handle on how traders use the terms delta and vega—for example “buy X vega’s worth” or “Y deltas out”.")

#text("A couple resources you could look at: Natenberg 1988; Taleb 1999; the tastytrade youtube channel. It is important to hear veteran trader banter (especially when it’s mathematically incorrect, eg confusing speed with distance travelled) because there is a LOT of gobbledegook written by academics about this topic, for unsavoury reasons.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-658185")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2022")])]

#text("Buy x worth of S implies xS using the natural definition of the metric tensor over the tangent bundle. Please could you elaborate in a more sensible fashion. All these prices are quoted and continously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-658195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2022")])]

#text("Not really the problems are very major on the definitions of how the double limit auction works. You could ask what can we deduce from -37 oil ergo inflation. Conclusion price discovery and the invisible hand. Leverage the risk free rate and complete markets. Imagine talking nonsense all day about vega or ai. It’s a problem to be solved. I’m de-skilled")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-685062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("I have found a certain number of books and papers (for instance Quantum Finance, B. Baaquie, Cambridge University Press, 2004) applying the formalism of quantum mechanics to finance. Very often, the argument used is tha the BS equation (or the heat equation) can be transformed into the Schrodinger equation by taking “imaginary time”. Is this approach any good? Dispersive equations and diffusion equations are structurally different in any way I can think of, with totally different mathematical properties, and so I wonder if anything of value can come from this approach. Thank you for your thoughts in this matter.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-685065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2024")])]

#text("This technique is known as ")#link("https://en.wikipedia.org/wiki/Wick_rotation")[#text("Wick rotation")]#text(". Broadly speaking, Wick rotation can be a useful trick for transferring algebraic *identities* from diffusive to dispersive settings or vice versa; for instance, the fundamental solution of the free Schrodinger equation can be derived (via analytic continuation) as a Wick rotation of the fundamental solution (heat kernel) of the free heat equation. However, as you note, the analytic properties of these equations are radically different (in large part due to the infamous instability of analytic continuation); for instance, a local well-posedness result for a diffusive equation cannot, in general, be Wick rotated into an analogous local well-posedness for a dispersive equation. Thus, if one is more interested in the analysis of PDE rather than the algebraic structure of PDE, Wick rotation is generally not recommended.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-685079")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2024")])]

#text("Hello Terence, thank you so much for answering my question. It confirms my initial doubts on this subject…")

#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-686034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2024")])]

#text("Hi: It is probably obvious, but I do not see the justification for the expression: ")#mi("(s_+-s)(s_--s)= -s^2\\sigma^2(dt)+ ..")

#text("I´ll appreciate a better explanation. Is this true for the lognormal case? does one need to assume ")#mi("\\mu=0")#text("?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/07/01/the-black-scholes-equation/#comment-686050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2024")])]

#text("This follows (formally at least) from (4) after applying a Taylor expansion ")#mi("\\exp(x) = 1 + x + O(x^2)")#text(" and discarding all terms of higher order than ")#mi("dt")#text(" (as they will contribute higher than ")#mi("dt^2")#text(" to the product).")
]
]
