// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/
// Converted to Typst by tao2typ: "2026-10-14T16:35:57.678895+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An inverse theorem for the Gowers U^4 norm", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An inverse theorem for the Gowers U^4 norm")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/")[#text("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", ")#link("http://www.math.ias.edu/~tamar/")[#text("Tamar Ziegler")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/0911.5681")[#text("An inverse theorem for the Gowers ")#mi("U^4")#text(" norm")]#text("“. This paper establishes the next case of the inverse conjecture for the Gowers norm for the integers (after the ")#mi("U^3")#text(" case, which was done ")#link("http://front.math.ucdavis.edu/math.NT/0503014")[#text("by Ben and myself a few years ago")]#text("). This conjecture has a number of combinatorial and number-theoretic consequences, for instance by combining this new inverse theorem with previous results, one can now get the correct asymptotic for the number of arithmetic progressions of primes of length five in any large interval ")#mi("[N] = \\{1,\\ldots,N\\}")#text(".")

#text("To state the inverse conjecture properly requires a certain amount of notation. Given a function ")#mi("f: {\\Bbb Z} \\to {\\Bbb C}")#text(" and a shift ")#mi("h \\in {\\Bbb Z}")#text(", define the multiplicative derivative")

#align(center)[#tao-fit-display[#mitex("\\Delta_h f(x) := f(x+h) \\overline{f(x)}")]]

#text("and then define the Gowers ")#mi("U^{s+1}[N]")#text(" norm of a function ")#mi("f: [N] \\to {\\Bbb C}")#text(" to (essentially) be the quantity")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{U^{s+1}[N]} := ({\\Bbb E}_{h_1,\\ldots,h_{s+1} \\in [-N,N]} {\\Bbb E}_{x \\in [N]} \\left|\\Delta_{h_1} \\ldots \\Delta_{h_{s+1}} f(x)\\right|)^{1/2^{s+1}},", block: true)]]

#text("where we extend f by zero outside of ")#mi("[N]")#text(". (Actually, we use a slightly different normalisation to ensure that the function 1 has a ")#mi("U^{s+1}")#text(" norm of 1, but never mind this for now.)")

#text("Informally, the Gowers norm ")#tao-math("\\left\\|f\\right\\|_{U^{s+1}[N]}", block: false)#text(" measures the amount of bias present in the ")#mi("(s+1)^{st}")#text(" multiplicative derivatives of ")#mi("f")#text(". In particular, if ")#mi("f = e(P) := e^{2\\pi i P}")#text(" for some polynomial ")#mi("P: {\\Bbb Z} \\to {\\Bbb C}")#text(", then the ")#mi("(s+1)^{th}")#text(" derivative of ")#mi("f")#text(" is identically 1, and so is the Gowers norm.")

#text("However, polynomial phases are not the only functions with large Gowers norm. For instance, consider the function ")#mi("f(n) := e( \\lfloor \\sqrt{2} n \\rfloor \\sqrt{3} n )")#text(", which is what we call a ")#emph[#text("quadratic bracket polynomial phase")]#text(". This function isn’t quite quadratic, but it is close enough to being quadratic (because one has the approximate linearity relationship ")#mi("\\lfloor x+y \\rfloor = \\lfloor x \\rfloor + \\lfloor y \\rfloor")#text(" holding a good fraction of the time) that it turns out that third derivative is trivial fairly often, and the Gowers norm ")#tao-math("\\left\\|f\\right\\|_{U^3[N]}", block: false)#text(" is comparable to 1. This bracket polynomial phase can be modeled as a ")#emph[#text("nilsequence")]#text(" ")#mi("n \\mapsto F( g(n) \\Gamma )")#text(", where ")#mi("n \\mapsto g(n) \\Gamma")#text(" is a polynomial orbit on a nilmanifold ")#mi("G/\\Gamma")#text(", which in this case has step 2. (The function F is only piecewise smooth, due to the discontinuity in the floor function ")#mi("\\lfloor \\rfloor")#text(", so strictly speaking we would classify this as an ")#emph[#text("almost nilsequence")]#text(" rather than a nilsequence, but let us ignore this technical issue here.) In fact, there is a very close relationship between nilsequences and bracket polynomial phases, but I will detail this in a later post.")

#text("The inverse conjecture for the Gowers norm, GI(s), asserts that such nilsequences are the only obstruction to the Gowers norm being small. Roughly speaking, it goes like this:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Inverse conjecture, GI(s).")]#text(" (Informal statement) Suppose that ")#mi("f: [N] \\to {\\Bbb C}")#text(" is bounded but has large ")#mi("U^{s+1}[N]")#text(" norm. Then there is an s-step nilsequence ")#mi("n \\mapsto F( g(n) \\Gamma )")#text(" of “bounded complexity” that correlates with f.")
]

#text("This conjecture is trivial for s=0, is a short consequence of Fourier analysis when s=1, and was proven for s=2 by Ben and myself. In this paper we establish the s=3 case. An equivalent formulation in this case is that any bounded function ")#mi("f")#text(" of large ")#mi("U^4")#text(" norm must correlate with a “bracket cubic phase”, which is the product of a bounded number of phases from the following list")

#align(center)[#mi("e( \\alpha n^3 + \\beta n^2 + \\gamma n), e( \\lfloor \\alpha n \\rfloor \\beta n^2 ), e( \\lfloor \\alpha n \\rfloor \\lfloor \\beta n \\rfloor \\gamma n ), e( \\lfloor \\alpha n \\rfloor \\beta n )")#text(" (*)")]

#text("for various real numbers ")#mi("\\alpha,\\beta,\\gamma")#text(".")

#text("It appears that our methods also work in higher step, though for technical reasons it is convenient to make a number of adjustments to our arguments to do so, most notably a switch from standard analysis to non-standard analysis, about which I hope to say more later. But there are a number of simplifications available on the s=3 case which make the argument significantly shorter, and so we will be writing the higher s argument in a separate paper.")

#text("The arguments largely follow those for the s=2 case (which in turn are based on ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("this paper of Gowers")]#text("). Two major new ingredients are a deployment of a normal form and equidistribution theory for bracket quadratic phases, and a combinatorial decomposition of frequency space which we call the sunflower decomposition. I will sketch these ideas below the fold.")

#heading(level: 1)[#metadata(none) <tao-13b5979d37353237dbc3>#text("— Sketch of proof —")]

#text("We will use an inductive argument, relying on the known inverse theory for the ")#mi("U^3")#text(" norm to establish the ")#mi("U^4")#text(" result.")

#text("Let f be a function with large ")#mi("U^4")#text(" norm. The goal is to show that f correlates with some cubic object, such as something generated from the list (*). By definition of the ")#mi("U^4")#text(" norm, we already know that the derivatives ")#mi("\\Delta_h f")#text(" have large ")#mi("U^3")#text(" norm for many h. Applying the inverse theorem at the ")#mi("U^3")#text(" level, we conclude that for many such ")#mi("h")#text(", ")#mi("\\Delta_h f")#text(" correlates with a bracket quadratic phase ")#mi("\\chi_h")#text(", which one can write as a bounded product of phases of the form")

#align(center)[#tao-fit-display[#mitex("e( \\alpha_h n^2 + \\beta_h n ), e( \\lfloor \\xi_h n \\rfloor \\eta_h n )")]]

#text("for various frequencies ")#mi("\\alpha_h, \\beta_h, \\xi_h, \\eta_h")#text(" depending on ")#mi("h")#text(". To simplify the discussion let us ignore the pure quadratics ")#mi("e( \\alpha_h n^2 + \\beta_h n )")#text(" as lower order terms, and suppose that only a single bracket quadratic is present. We thus have")

#align(center)[#tao-fit-display[#mitex("\\Delta_h f(n) \\approx e( \\lfloor \\xi_h n \\rfloor \\eta_h n )")]]

#text("where we will be vague about exactly what the ")#mi("\\approx")#text(" symbol means here.")

#text("A key observation of Gowers is that the cocycle nature of ")#mi("\\Delta_h f")#text(" induces some non-trivial relationships between the frequencies ")#mi("\\xi_h, \\eta_h")#text(". For instance, if f had magnitude 1 throughout, then we would have the identity")

#align(center)[#tao-fit-display[#mitex("\\Delta_{h+k} f(n) = \\Delta_h f(n+k) \\Delta_k f(n)")]]

#text("which suggests (discarding lower order terms) that one has the relation")

#align(center)[#tao-fit-display[#mitex("e( \\lfloor \\xi_{h+k} n \\rfloor \\eta_{h+k} n ) \\approx")]]

#align(center)[#mi("e( \\lfloor \\xi_h n \\rfloor \\eta_h n + \\lfloor \\xi_k n \\rfloor \\eta_k n )")#text(" (**)")]

#text("for many h, k. (In practice, one actually obtains a slightly more complicated relationship, in which the additive triple ")#mi("(h,k,h+k)")#text(" is replaced by an additive quadruple ")#mi("(h_1,h_2,h_3,h_4)")#text(" with ")#mi("h_1+h_2=h_3+h_4")#text(", but never mind this technicality.)")

#text("The relation (**) suggests that one has an identity of the form")

#align(center)[#tao-fit-display[#mitex("\\lfloor \\xi_{h+k} n \\rfloor \\eta_{h+k} n \\approx \\lfloor \\xi_h n \\rfloor \\eta_h n + \\lfloor \\xi_k n \\rfloor \\eta_k n")]]

#text("modulo lower order terms (and also modulo 1). How can such an identity occur? There are two obvious ways this can happen:")

#enum(start: 1, 
[#text("The ")#mi("\\xi_h")#text(" are independent of h, and ")#mi("\\eta_h")#text(" varies linearly in h.")],
[#text("The ")#mi("\\eta_h")#text(" are independent of h, and ")#mi("\\xi_h")#text(" varies linearly in h. (The error caused by the failure of ")#mi("\\lfloor \\rfloor")#text(" to be exactly linear turns out to be lower order and will be absorbed into the vaguely defined ")#mi("\\approx")#text(" symbol.)")]
)

#text("It turns out that one can generalise these scenarios a little bit. Firstly, since we are only seeking structure for many h,k rather than for all h,k, one can replace “linearly in h” in the above scenarios by “bracket-linearly in h”, e.g. ")#mi("\\eta_h")#text(" could be given by ")#mi("\\lfloor \\alpha h \\rfloor \\beta")#text(" for some real numbers ")#mi("\\alpha,\\beta")#text(", as this would still be sufficiently close to linear to generate a relation such as (**). Secondly, one could modify the ")#mi("\\xi_h, \\eta_h")#text(" by integers (or more generally, by rational numbers with bounded denominator) without significantly affecting (**) due to the periodicity of the function e() modulo 1. Finally, there are some identities of bracket calculus that show some non-trivial relations between various quadratic expressions ")#mi("\\lfloor x \\rfloor y")#text(", such as")

#align(center)[#tao-fit-display[#mitex("\\lfloor qx \\rfloor \\frac{y}{q} \\approx \\lfloor x \\rfloor y")]]

#text("for any non-zero rational q with bounded numerator and denominator, and also the antisymmetry property")

#align(center)[#tao-fit-display[#mitex("\\lfloor x \\rfloor y \\approx - \\lfloor y \\rfloor x \\text{ mod } 1")]]

#text("(the point being that ")#mi("\\{x\\}\\{y\\} = (x-\\lfloor x \\rfloor) (y - \\lfloor y\\rfloor)")#text(" can be considered a lower order term, as can xy, and ")#mi("\\lfloor x \\rfloor \\lfloor y \\rfloor")#text(" vanishes modulo 1).")

#text("It turns out though that the above maneuvres basically exhaust all the possible ways in which a relation of the form (**) can occur. There are two main reasons for this:")

#enum(start: 1, 
[#text("One can show that if any two of the three pairs ")#mi("(\\xi_h, \\eta_h), (\\xi_k, \\eta_k), (\\xi_{h+k}, \\eta_{h+k})")#text(" are in “general position”, then no identity of the form (**) can occur.")],
[#text("If there is a frequency shared in common among all three frequency sets, e.g. if ")#mi("\\xi_h")#text(" is independent of h, then the other frequency ")#mi("\\eta_h")#text(" must essentially depend linearly (or bracket-linearly) in h.")]
)

#text("The reason for claim 1 ultimately reduces to the following simple algebraic lemma (which we call the “")#link("http://www.ams.org/mathscinet-getitem?mr=1412607")[#text("Furstenberg-Weiss trick")]#text("“, though it has appeared in some other contexts also, for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=943605")[#text("this paper of Hrushovski")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let H be a subgroup of a product ")#mi("G_1 \\times G_2 \\times G_3")#text(" of three groups. If the projection of H to ")#mi("G_1 \\times G_2")#text(" is surjective, and the projection of H to ")#mi("G_1 \\times G_3")#text(" is surjective, then H contains the subgroup ")#mi("[G_1,G_1] \\times \\{1\\} \\times \\{1\\}")#text(".")
]

#strong[#text("Proof.")]#text(" Let ")#mi("g, h")#text(" be two elements of ")#mi("G_1")#text(". By the first surjectivity property, H contains an element of the form ")#mi("(g, 1, *)")#text(" where * denotes an unspecified coefficient, and by the second property, H also contains ")#mi("(h,*,1)")#text(". Taking commutators yields ")#mi("([g,h],1,1)")#text(", and the claim follows. ")#mi("\\Box")

#text("Roughly speaking, the reason why this Lemma implies Claim 1 is because the joint orbit of ")#mi("\\lfloor \\xi_h n \\rfloor \\eta_h n")#text(", ")#mi("\\lfloor \\xi_k n \\rfloor \\eta_k n")#text(", ")#mi("\\lfloor \\xi_{h+k} n \\rfloor \\eta_{h+k} n")#text(" can be controlled, using ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner’ s theorem")]#text(" (or more precisely, a quantitative version of this theorem that ")#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("Ben and I worked out a few years ago")]#text(") by a certain subgroup H of the product of three Heisenberg groups (times an abelian group to take care of lower order errors, but let’s ignore this). The general position hypotheses give us the hypotheses of the lemma, and the conclusion basically tells us that the phase of ")#mi("\\lfloor \\xi_h n \\rfloor \\eta_h n")#text(" (say) can be varied independently of the other two phases, which prevents any relation of the form (**) occurring. A related argument also gives Claim 2.")

#text("Once one has Claim 1 and Claim 2, a combinatorial argument (which we call the ")#emph[#text("sunflower decomposition")]#text(") that separates the frequencies ")#mi("\\xi_h, \\eta_h")#text(" into “core” frequencies (shared by many h) and “petal” frequencies (which vary with h, so that the petals for h and petals for k are in general position for most h,k), and then using standard tools from additive combinatorics (notably the Balog-Szemeredi-Gowers lemma and Freiman’s theorem), one eventually concludes (possibly after reshuffling the bracket polynomials a bit, to take care of the ambiguities mentioned earlier) that of the two frequencies ")#mi("\\xi_h, \\eta_h")#text(" that appear, one is independent of h and the other varies bracket linearly in h. Thus we see now that ")#mi("\\Delta_h f")#text(" resembles an expression which is the product of a bounded number of terms such as")

#align(center)[#tao-fit-display[#mitex("e( \\lfloor \\xi n \\rfloor \\lfloor \\alpha h \\rfloor \\beta n )")]]

#text("and permutations. We write this as")

#align(center)[#tao-fit-display[#mitex("\\Delta_h f(n) \\approx e( T( h, n, n ) )")]]

#text("for some “trilinear” form T in three variables.")

#text("If T was symmetric in all three variables, then ")#mi("e(T(h,n,n))")#text(" would resemble the derivative ")#mi("\\Delta_h e( \\frac{1}{3} T(n,n,n) )")#text(" of ")#mi("e( \\frac{1}{3} T(n,n,n) )")#text(" (modulo lower order terms), which turns out to imply (after invoking the induction hypothesis GI(2) again) that ")#mi("f(n)")#text(" correlates with ")#mi("e(T(n,n,n))")#text(" (times lower order terms). But by construction, ")#mi("e( T(n,n,n) )")#text(" is a bracket cubic, and this would give the claim GI(3).")

#text("So one seeks to impose a “symmetry” property on T. The reason for this symmetry ultimately stems from the identity")

#align(center)[#tao-fit-display[#mitex("\\Delta_k \\Delta h f(n) = \\Delta_h \\Delta_k f(n)")]]

#text("which suggests that")

#align(center)[#tao-fit-display[#mitex("\\Delta_k e( T(h,n,n) ) \\approx \\Delta_h e( T( k, n, n ) )")]]

#text("which, when expanded, gives something reasonably close to the required symmetry property. One can make this argument precise using a carefully chosen sequence of applications of the Cauchy-Schwarz inequality. One initial obstacle is that the desired symmetry only holds for many pairs (h,k), rather than for all pairs (h,k), but it turns out that one can step over this obstacle by using a ")#link("http://www.ams.org/mathscinet-getitem?mr=1002119")[#text("theorem of Sarkozy")]#text(", which asserts that if H is a dense subset of [N], then a suitable sumset ")#mi("H+H+\\ldots+H")#text(" of bounded length will contain a long arithmetic progression (of size comparable to N). Combining this theorem with the trilinearity properties of T lets one pass from “many” to “all” (or more precisely, “all in a long arithmetic progression”, which is good enough for our purposes).")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0e391cd073c2fd47df886ed94d2c2bd2f6d415519f958ffb99a5ad2ae57d30e-b78ba549bc4f31a442ac6f575ad965afd8b1b9455c3325479c0c025ef7984832.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akhil Mathew")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42656")[#strong[#text("Akhil Mathew")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("I think one of your formulas does not parse (formula (**)). ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("I use Firefox version 3.5.5 and formula (**) still does not parse. ")#emph[#text("[Strange. I ended up splitting the LaTeX in two, which seems to resolve the glitch.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42663")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2009")])]

#text("Formula (**) still does not parse. Is it")#linebreak()#text(" ")#mi("e(\\left\\lfloor \\xi _{h+k}n\\right\\rfloor \\eta _{h+k}n)\\approx e(\\left\\lfloor\\xi _{h}n\\right\\rfloor \\eta _{h}n+\\left\\lfloor \\xi _{k}n\\right\\rfloor \\eta_{k}n)")#text(" ?")

#emph[#text("[Grr, I have no idea why the LaTeX keeps reverting to (and why the particular form of the LaTeX is causing errors). Hopefully now it’s fixed for good… -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42682")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2009")])]

#text("Info: I’m currently using IE8 and this formula is OK.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42667")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2009")])]

#text("Lemma 1 (and its proof) is very close to a lemma used by Ribet in “On ell-adic representations associated to modular forms”, Invent. math. 28, 1975 (Lemma 3.3, p. 252 there; Ribet attributes the nice tricky proof to Serre…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42674")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2009")])]

#text("That paper is freely accessible on the Göttinger Digitalisierungszentrum website ")#link("http://gdz.sub.uni-goettingen.de/dms/load/img/?PPN=PPN356556735_0028&DMDID=dmdlog28")[#text("here")]#text(".")

#text("Back to the U^4 paper: it seems that you reserve the word ‘almost’ (as in ‘almost polynomial nilsequence’) to objects which are close to some exact ones in a measure theoretic sense, while the word ‘approximate’ (as in ‘approximate homomorphism’) is used for algebraic structures, or is there something else implied?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42679")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2009")])]

#text("Terry – do you want that power of 2^{s+1} in the second displayed formula?")

#emph[#text("[Um, no I don’t. Thanks for pointing it out. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-42807")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] I will also discuss a two variants of both Theorem 1 and Theorem 2 which have actually shown up in my research. The first is that of the regularity lemma for polynomials over finite fields, which came up when studying the equidistribution of such polynomials (in this paper with Ben Green). The second comes up when is dealing not with a single finite collection of vectors, but rather with a family of such vectors, where ranges over a large set; this gives rise to what we call the sunflower lemma, and came up in this recent paper of myself, Ben Green, and Tamar Ziegler. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-43605")[#strong[#text("An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("[…] Ziegler have recently established (paper to be forthcoming shortly; the case of our argument is discussed here). The counting lemma is established through the quantitative equidistribution theory of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-44921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2010")])]

#text("Hello, May I ask what is the status of your paper with Green and Ziegler proving of the Gowers norm inverse conjecture for all d? I’ve noticed that this is listed as “submitted” in your papers for the Szemeredi birthday conference, however it hasn’t been made publicly available yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-44922")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2010")])]

#text("This paper is in the process of being rewritten and should be available within a few weeks.")

#text("We already have two more-or-less complete versions of the paper written up already, but we were not happy with the level of exposition with them; they required quite a huge amount of technical machinery and setup, and so we have been working to simplify the argument. (Page counts are only a very crude gauge of complexity, but our first version was 112 pages long; the second version was 86. The third version is likely to be a little longer, but much less dense.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]], [#link("https://terrytao.wordpress.com/2009/12/02/an-inverse-theorem-for-the-gowers-u4-norm/#comment-45210")[#strong[#text("254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("[…] soon after that. For a discussion of the history of the conjecture, including the cases , see our previous paper. Exercise 21 ( inverse […]")
]
