// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/
// Converted to Typst by tao2typ: "2026-10-14T16:34:58.404709+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Open question: deterministic UUP matrices", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Open question: deterministic UUP matrices")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/")[#text("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This problem in ")#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/")[#text("compressed sensing")]#text(" is an example of a ")#emph[#text("derandomisation problem")]#text(": take an object which, currently, can only be constructed efficiently by a probabilistic method, and figure out a deterministic construction of comparable strength and practicality. (For a general comparison of probabilistic and deterministic algorithms, I can point you to these ")#link("http://www.math.ias.edu/~avi/TALKS/LATIN.ppt")[#text("slides by Avi Wigderson")]#text(").")

#text("I will define exactly what UUP matrices (the UUP stands for “")#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/")[#text("uniform uncertainty principle")]#text("“) are later in this post. For now, let us just say that they are a generalisation of (rectangular) ")#link("http://en.wikipedia.org/wiki/Orthogonal_matrices")[#text("orthogonal matrices")]#text(", in which the columns are locally almost orthogonal rather than globally perfectly orthogonal. Because of this, it turns out that one can pack significantly more columns into a UUP matrix than an orthogonal matrix, while still capturing many of the desirable features of orthogonal matrices, such as stable and computable invertibility (as long as one restricts attention to ")#emph[#text("sparse")]#text(" or ")#emph[#text("compressible")]#text(" vectors). Thus UUP matrices can “squash” sparse vectors from high-dimensional space into a low-dimensional while still being able to reconstruct those vectors; this property underlies many of the recent results on compressed sensing today.")

#text("There are several constructions of UUP matrices known today (e.g. random normalised Gaussian matrices, random normalised Bernoulli matrices, or random normalised minors of a discrete Fourier transform matrix) but (if one wants the sparsity parameter to be large) they are all probabilistic in nature; in particular, these constructions are not 100% guaranteed to actually produce a UUP matrix, although in many cases the failure rate can be proven to be exponentially small in the size of the matrix. Furthermore, there is no fast (e.g. sub-exponential time) algorithm known to test whether any given matrix is UUP or not. The failure rate is small enough that this is not a problem for most applications (especially since many compressed sensing applications are for environments which are already expected to be noisy in many other ways), but is slightly dissatisfying from a theoretical point of view. One is thus interested in finding a deterministic construction which can locate UUP matrices in a reasonably rapid manner. (One could of course simply search through all matrices in a given class and test each one for the UUP property, but this is an exponential-time algorithm, and thus totally impractical for applications.) In analogy with error-correcting codes, it may be that algebraic or number-theoretic constructions may hold the most promise for such deterministic UUP matrices (possibly assuming some unproven conjectures on exponential sums); this has already been accomplished ")#link("http://www.dsp.ece.rice.edu/cs/Henryk.pdf")[#text("by de Vore")]#text(" for UUP matrices with small sparsity parameter.")

#metadata(none) <tao-13baf07425535938fe84>

#text("Before we define UUP matrices explicitly, let us first recall what an (rectangular) orthogonal matrix is. We will view an ")#mi("m \\times n")#text(" matrix (m rows and n columns) as a collection ")#mi("v_1, \\ldots, v_n")#text(" of column vectors in the (complex) vector space ")#mi("{\\Bbb C}^m")#text(", or equivalently as a means of linearly transformed an n-dimensional vector ")#mi("(a_1,\\ldots,a_n)")#text(" as an m-dimensional vector ")#mi("\\sum_{j=1}^n a_j v_j")#text(". I will call such a matrix orthogonal if these column vectors are ")#link("http://en.wikipedia.org/wiki/Orthonormal")[#text("orthonormal")]#text(", i.e. they all have unit length ")#tao-math("\\left\\|v_j\\right\\|=1", block: false)#text(" and are orthogonal to each other: ")#mi("\\langle v_j, v_k \\rangle = 0")#text(" whenever ")#mi("j \\neq k")#text(".")

#text("Orthonormal vectors have several pleasant properties. One of them is ")#link("http://en.wikipedia.org/wiki/Pythagoras%27_theorem")[#text("Pythagoras’ theorem")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\sum_{j=1}^n a_j v_j \\right\\|^2 = \\sum_{j=1}^n \\left|a_j\\right|^2", block: true)]]

#text("valid for all complex numbers ")#mi("a_1,\\ldots, a_n")#text(". In other words, the linear encoding ")#mi("(a_1,\\ldots,a_n) \\mapsto  \\sum_{j=1}^n a_j v_j")#text(" is an isometry. This implies that such an encoding can be inverted in a stable manner: given the encoded vector ")#mi("w = \\sum_{j=1}^n a_j v_j")#text(" one can uniquely recover the original coefficients ")#mi("a_1,\\ldots,a_n")#text(", and furthermore that small changes in w will not cause large fluctuations in ")#mi("a_1,\\ldots,a_n")#text(". Indeed, one can reconstruct the coefficients ")#mi("a_i")#text(" quickly and explicitly by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("a_j = \\langle w, v_j \\rangle.")]]

#text("One would like to make n as large as possible, and m as small as possible, so that one can transform as high-dimensional vectors as possible using only as low-dimensional space as possible to store the transformed vectors. There is however a basic obstruction to this, which is that an orthogonal matrix can only exist when ")#mi("n \\leq m")#text("; for if n is larger than m, then there are too many vectors ")#mi("v_1,\\ldots,v_n")#text(" to remain linearly independent in ")#mi("{\\Bbb C}^m")#text(", and one must have a non-trivial linear independence")

#align(center)[#tao-fit-display[#mitex("a_1 v_1 + \\ldots + a_n v_n = 0")]]

#text("for some ")#mi("(a_1,\\ldots,a_n) \\neq (0,\\ldots,0)")#text(", which is inconsistent with (1).")

#text("One can try to circumvent this restriction by weakening the condition (1) to (say)")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("0.9 \\sum_{j=1}^n \\left|a_j\\right|^2 \\leq \\left\\| \\sum_{j=1}^n a_j v_j \\right\\|^2 \\leq 1.1 \\sum_{j=1}^n \\left|a_j\\right|^2", block: true)]]

#text("for all complex numbers ")#mi("a_1,\\ldots,a_n")#text(". (The constants 0.9 and 1.1 are not terribly important for this discussion.) Thus we only require that Pythagoras’ theorem hold ")#emph[#text("approximately")]#text(" rather than exactly; this is equivalent to requiring that the transpose of this matrix forms a ")#link("http://en.wikipedia.org/wiki/Frame_of_a_vector_space")[#text("frame")]#text(". (In harmonic analysis, one would say that the vectors ")#mi("v_1,\\ldots,v_n")#text(" are ")#emph[#text("almost orthogonal")]#text(" rather than perfectly orthogonal.) This enlarges the class of matrices that one can consider, but unfortunately does not remove the condition ")#mi("n \\leq m")#text(", since the linear dependence argument which showed that ")#mi("n > m")#text(" was incompatible with (1), also shows that ")#mi("n > m")#text(" is incompatible with (3).")

#text("It turns out, though, that one can pack more than m vectors into ")#mi("{\\Bbb C}^m")#text(" if one ")#emph[#text("localises")]#text(" the almost orthogonality condition (3) so that it only holds for ")#emph[#text("sparse")]#text(" sets of coefficients ")#mi("a_1,\\ldots,a_n")#text(". Specifically, we fix a parameter S (less than m), and say that the matrix ")#mi("(v_1,\\ldots,v_n)")#text(" obeys the ")#emph[#text("UUP with sparsity S")]#text(" if one has the almost orthogonality condition (3) for any set of coefficients ")#mi("(a_1,\\ldots,a_n)")#text(", such that at most S of the ")#mi("a_j")#text(" are non-zero. [The UUP is also known as the ")#emph[#text("Restricted Isometry Property")]#text(" (RIP) in the literature.] In other words, we only assume that any S of the n vectors ")#mi("v_1,\\ldots,v_n")#text(" are almost orthogonal at one time. (It is important here that we require almost orthogonality rather than perfect orthogonality, since as soon as a set of vectors are pairwise perfectly orthogonal, they are of course jointly perfectly orthogonal. In contrast, the constants 0.9 and 1.1 in the UUP condition will deteriorate as S increases, so that local almost orthogonality does not imply global almost orthogonality.) The UUP property is more powerful (and hence more useful) when S is large; in particular one would like to approach the “information-theoretic limit” when S is comparable in magnitude to m.")

#text("Roughly speaking, a set of vectors ")#mi("(v_1,\\ldots,v_n)")#text(" which obey the UUP are “just as good” as an orthonormal set of vectors, so long as one doesn’t look at more than S of these vectors at a time. For instance, one can easily show that the map ")#mi("(a_1,\\ldots,a_n) \\mapsto \\sum_j a_j v_j")#text(" is still injective as long as one restricts attention to input vectors which are S/2-sparse or better (i.e. at most S/2 of the coefficients are allowed to be non-zero). This still leaves the question of how to efficiently recover the sparse coefficients ")#mi("(a_1,\\ldots,a_n)")#text(" from the transformed vector ")#mi("w = \\sum_j a_j v_j")#text(". The algorithm (2) is no longer accurate, however if the coefficients are just a little bit sparser than S/2 (e.g. S/3 will do) then one can instead use the algorithm of ")#emph[#text("basis pursuit")]#text(" to recover the coefficients ")#mi("(a_1,\\ldots,a_n)")#text(" perfectly. Namely, ")#link("http://arxiv.org/abs/math.MG/0502327")[#text("it turns out")]#text(" that among all the possible representations ")#mi("w = \\sum_j b_j v_j")#text(" of w, the one which minimises the ")#mi("l^1")#text(" norm ")#tao-math("\\sum_j \\left|b_j\\right|", block: false)#text(" will be the one which matches the S/3-sparse representation $\\sum_j a_j v_j$ exactly. (This has an interesting geometric interpretation: if we normalise all the vectors ")#mi("v_j")#text(" to have unit length, then this result says that the simplest (sparsest) way to get from 0 to w by moving in the directions ")#mi("v_1, \\ldots, v_n")#text(" is also the shortest way to get there.) There are also some related results regarding coefficients ")#mi("(a_1,\\ldots,a_n)")#text(" which are merely compressible instead of sparse, but these are a bit more technical; see ")#link("http://arxiv.org/abs/math.ST/0506081")[#text("my paper with Emmanuel Candes")]#text(" for details.")

#text("It turns out that UUP matrices can have many more columns than rows; indeed, as shown ")#link("http://www-stat.stanford.edu/~donoho/Reports/2004/l1l0EquivCorrected.pdf")[#text("by Donoho")]#text(", and ")#link("http://arxiv.org/abs/math.CA/0410542")[#text("by Candes and myself")]#text(", n can be as large as ")#mi("m \\exp( c m /S )")#text(" for some absolute constant c > 0. (Subsequent proofs also appeared ")#link("http://www.math.ucla.edu/~tao/preprints/FOCS05.pdf")[#text("by Candes, Rudelson, myself, and Vershynin")]#text(" and ")#link("http://www.dsp.ece.rice.edu/cs/JLCSfinalrevision1.pdf")[#text("by Baranuik, Davenport, de Vore, and Wakin")]#text(".) The construction is in fact very easy; one simply selects the vectors ")#mi("v_1, \\ldots, v_n")#text(" ")#emph[#text("randomly")]#text(", either as random unit vectors or as random normalised Gaussian vectors (so all coefficients of each ")#mi("v_i")#text(" are ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("iid")]#text(" ")#link("http://en.wikipedia.org/wiki/Normal_distribution")[#text("Gaussians")]#text(" with mean zero and variance 1/m). The point is that in a high-dimensional space such as ")#mi("{\\Bbb C}^m")#text(", any two randomly selected vectors are very likely to be almost orthogonal to each other; for instance, it is an easy computation that the dot product between two random normalised Gaussian vectors has a variance of only O(1/m), even though the vectors themselves have a magnitude very close to 1. Note though that control of these dot products is really only enough to obtain the UUP for relatively small S, e.g. ")#mi("S = O( \\sqrt{(}m) )")#text(". For large S, one needs slightly more advanced tools, such as large deviation bounds on the singular values of rectangular Gaussian matrices (which are closely related to the Johnson-Lindenstrauss lemma).")

#text("The results for small sparsity S are relatively easy to duplicate by deterministic means. In particular, the ")#link("http://www.dsp.ece.rice.edu/cs/Henryk.pdf")[#text("paper of de Vore")]#text(" mentioned earlier uses a polynomial construction to obtain UUP matrices with S close to ")#mi("\\sqrt{m}")#text(", and n equal to an arbitrarily large power of m, essentially by ensuring that all the column vectors have a low inner product with each other (of magnitude roughly ")#mi("\\sqrt{1/m}")#text(" or so, matching what the random construction gives, and almost certainly best possible). But to get to larger values of S (and in particular, to situations in which S is comparable to m) may require a more refined calculation (possibly involving higher moments of the ")#link("http://en.wikipedia.org/wiki/Gram_matrix")[#text("Gramian matrix")]#text(", as was done in a ")#link("http://front.math.ucdavis.edu/math.CA/0409186")[#text("paper of Candes, Romberg, and myself")]#text(" in the random case). Alternatively, one may rely on conjecture rather than rigorous results; for instance, it could well be that the matrices of de Vore satisfy the UUP for far larger sparsities S than are rigorously proven in that paper.")

#text("An alternate approach, and one of interest in its own right, is to work on improving the time it takes to verify that a given matrix (possibly one of a special form) obeys the UUP. The brute-force approach of checking the singular values of every set of S column vectors requires a run time comparable to ")#mi("\\binom{n}{S}")#text(" or worse, which is quite poor. (A variant approach has recently been proposed by Sharon, Wright, and Ma but has similar run time costs.) But perhaps there exist specially structured matrices for which the UUP is easier to verify, and for which it is still likely that the UUP holds. This would give a probablistic algorithm for producing rigorously certified UUP matrices with a reasonable average-case run time.")

#text("[")#emph[#text("Update")]#text(", July 9: Typos corrected.]")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-3647")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2007")])]

#text("Dear Terry,")

#text("You write :")#linebreak()#text(" “..Alternatively, one may rely on conjecture rather than rigorous results; for instance, it could well be that the matrices of de Vore satisfy the UUP for far larger sparsities S than are rigorously proven in that paper…”")#linebreak()#text(" Has there been any hint from numerical work to support that conjecture :i.e. DeVore’s construction leading to higher than sqrt(m) bound ?")

#text("Also, DeVore states “The Restricted Isometry Property is just a sufficient condition")#linebreak()#text(" to guarantee that a matrix \u{8} has good performance on classes. Two matrices can has exactly the same performance on classes and yet one will satisfy RIP and the other not. So there may be a more direct avenue to constructing good CS matrices by not going through RIP. ”")#linebreak()#text(" I wonder if you could comment on that ? I mean, are you unnecessarily restricting yourself when using RIP as a way to find good CS matrices ?")

#text("Also, a totally unrelated question, do you think that the normality (in the sense of commutation with its conjugate) or non-normality of matrix \\phi has an influence on its ability to fulfill RIP ?")

#text("Igor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CS Boy")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-3669")[#strong[#text("CS Boy")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2007")])]

#text("I think that another issue with the use of (random) CS matrix is that everybody use pseudo-random generated matrices. The point is that one needs the sensing matrix at decoding time, and usually one just keep track of the seed of the random generator. Maybe the difficulty in derandomizing CS is to have a bound on the actual length of this random seed in order to the effectiveness of the recovery.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-3730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2007")])]

#text("Dear Igor,")

#text("As I mentioned in the main post, it’s hard to verify the RIP numerically for large S because of the exponentially large number of different combinations of S column vectors one has to consider. I would not be surprised though if numerics showed that the RIP held for _most_ S-tuples of column vectors for de Vore’s matrices (or indeed for any other reasonable construction). Unfortunately, this “99%-RIP” type property seems to not be of use in applications; the problem is that if even a single S-tuple of column vectors behaved badly, they could in principle provided a better l^1 minimiser than the true sparse signal in a large number of cases, even when the true signal involves a completely different S-tuple of vectors.")

#text("My guess though is that de Vore’s construction will have to be modified a little bit though – it is optimised for sqrt(m) in some sense.")

#text("There are of course a few CS results which do not require the RIP property, for instance my first paper with Emmanuel on recovery of sparse signals worked even for oversampling ratios in which the RIP is only conjectured to be true. But in order to get robust results (i.e. ones which work for compressible signals rather than sparse, or in the presence of noise), as well as universal results (ones which work for all sparse/compressible data rather than generic sparse/compressible data) it seems that something very close to the RIP is needed.")

#text("Dear CS Boy: It is conceivable that a sufficiently sophisticated pseudorandom number generator could generate a good random matrix with probability 1, rather than very close to 1, but it would be hopeless with current technology to establish this rigorously (it comes dangerously close to trying to prove ")#mi("P = BPP")#text("). But perhaps this may form a basis for a ")#emph[#text("conjectural")]#text(" deterministic construction of UUP matrices.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/927b5d43d7b9c716986ffbcf8744112135a73af9a6adac81c5a2524a7662baed-7dc7bfe2252f25957b54848265da7f0c2b88b77d6ba7b28c8419362f26f919b1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nimbusgear")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-3897")[#strong[#text("nimbusgear")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Dear Terry, i’ve been following your posts for awhile now, and while i find a good portion of what you’re describing as a bit too intricate for myself to grasp at this point in time, i do pick up on some of it.. in this case, you mentioned the following feature:")

#text("“…The point is that in a high-dimensional space such as Cm, any two randomly selected vectors are very likely to be almost orthogonal to each other…”")

#text("is this implying that there is a level of informational reduction occuring?")#linebreak()#text(" where if you were to, for example, need to describe an angular measurement between two high dimensional vectors, you’d not need to specify 360*granularity degrees, but rather something like 3.6*granularity degrees?")

#text("particularly, this is the type of research that i’m really working on understanding fully.. the mechanism of compression in regards to the selection of the algorithm itself, being able to multiply the resultant information of the data.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8586b8fdaabd6702ead9f6479812b3c1c06b1816eaf01e29ec157da9c3ecdb81-4ebf1bdac9a89a0868225ec388d3e30682328ed652819b5723a6132ac2283463.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ajay Bangla")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-3898")[#strong[#text("Ajay Bangla")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Dear Prof. Tao,")

#text("You write :")#linebreak()#text(" “It turns out that UUP matrices can have many more rows than columns;…”")

#text("Shouldn’t it be UUP matrices can have many more columns than rows?")

#text("~Ajay")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-3906")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2007")])]

#text("Dear nimbusgear,")

#text("It is true that the angle between two vectors usually does not convey much information about those two vectors (except in those rare cases in which the angle is quite small). An analogy would be with an n-bit random string of 0s and 1s. Instead of measuring an “angle”, suppose one measures the total number of 1s in this string. In principle, this number could range all the way from 0 to n (just like angles can range from 0 to 180 degrees). However, in practice a “concentration of measure” occurs, and the total number of 1s is very close to n/2 (typically deviating from this mean by at most O(sqrt(n)), thanks to the law of large numbers or the central limit theorem), just like how the angle concentrates near 90 degrees with a standard deviation of O(1/sqrt(n)). Indeed, the Shannon entropy of this number-of-1s measurement is closer to 1/2 log n than to log n.")

#text("Dear Ajay: thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-4565")[#strong[#text("Yet Another Machine Learning Blog » Compressed sensing [Pierre Dangauthier]")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2007")]

#text("[…] in hight dimensional spaces, 2 random vectors are almost always orthogonal (with a slightly modified version of orthogonality), which guarantee non-correlation with high […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-7675")[#strong[#text("Yet Another Machine Learning Blog » Why 2 random vectors are orthogonal in high dimention? [Pierre Dangauthier]")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2007")]

#text("[…] gives the following graph. We clearly see the concentration phenomena that Terry was talking about. When s gets bigger, we obtain a narrower distribution, and the probability that a_1 is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Dantzig selector: Statistical estimation when p is much larger than n « What’s new")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-27520")[#strong[#text("The Dantzig selector: Statistical estimation when p is much larger than n « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2008")])]

#text("[…] 22 March, 2008 in math.ST, update Tags: compressed sensing, Dantzig selector, estimation, lasso selector, linear programming, mean square error, restricted isometry property More than two years ago, Emmanuel Candés and I submitted the paper “The Dantzig selector: Statistical estimation when is much larger than ” to the Annals of Statistics. This paper, which appeared last year, proposed a new type of selector (which we called the Dantzig selector, due to its reliance on the linear programming methods to which George Dantzig, who had died as we were finishing our paper, had contributed so much to) for statistical estimation, in the case when the number of unknown parameters is much larger than the number of observations. More precisely, we considered the problem of obtaining a reasonable estimate for an unknown vector of parameters given a vector of measurements, where is a known predictor matrix and is a (Gaussian) noise error with some variance . We assumed that the data matrix X obeyed the restricted isometry property (RIP), which roughly speaking asserts that has norm comparable to whenever the vector is sparse. This RIP property is known to hold for various ensembles of random matrices of interest; see my earlier blog post on this topic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CS_newuser")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-30166")[#strong[#text("CS_newuser")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Dear Prof. Terrence,")

#text("Please see the following quote from the above")

#text("“For instance, one can easily show that the map……… is still injective as long as one restricts attention to input vectors which are S/2-sparse or better (i.e. at most S/2 of the coefficients are allowed to be non-zero). This still leaves the question of how to efficiently recover the sparse coefficients from the transformed vector . The algorithm (2) is no longer accurate, however if the coefficients are just a little bit sparser than S/2 (e.g. S/3 will do) then one can instead use the algorithm of basis pursuit to recover the coefficients perfectly.”")

#text("As the signal is already S sparse then what has S/2 and S/3 has to do with it? Please explain. Whether instead of S/2 or S/3, it should be m/2 or m/3.")

#text("I am new to this subject, so in case my question sounds absurd, please forgive me however I would still request you please clarify it for me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-30189")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2008")])]

#text("Dear CS_newuser,")

#text("One can of course form the linear combination ")#mi("\\sum_{j=1}^n a_j v_j")#text(" for any choice of coefficients ")#mi("a_j")#text(" that one wishes, whether they are S/2-sparse, S-sparse, or not sparse at all. If they happen to be S-sparse or better, the UUP says something about the norm of this linear combination, but it is possible for two different S-sparse combinations ")#mi("\\sum_{j=1}^n a_j v_j")#text(", ")#mi("\\sum_{j=1}^n b_j v_j")#text(" to sum to the same value.")

#text("If however one considers S/2-sparse combinations ")#mi("\\sum_{j=1}^n a_j v_j")#text(", ")#mi("\\sum_{j=1}^n b_j v_j")#text(", then their difference will be an S-sparse combination or better. Applying the UUP to the difference, we see that if the coefficients ")#mi("b_j")#text(" are not identical to the coefficients ")#mi("a_j")#text(", then the difference has non-zero norm, and so we have injectivity for S/2-sparse combinations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bda3dbc4587f5cbb50f1ad4f7d7292c15e5f54c8a063273e1840587fa167d3e-dace2f2cdfc088d2c522359af5a124eca1ba5349c7d3d49a9cb36551602f43ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kanke")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-32357")[#strong[#text("Kanke")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")])]

#text("Dr Tao,")#linebreak()#text(" I have a quick question: Does the parameter ")#mi("S")#text(" for a UUP matrix have any possibility to be greater than ")#mi("m")#text("? The range of ")#mi("S")#text(" should be [1,n] (my opinion). If someone finds a UUP matrix with ")#mi("S")#text(" larger than m, can we still use Basic pursuit to recover the ")#mi("S")#text("-sparsity signal exactly? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-32381")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2008")])]

#text("Dear Kanke,")

#text("It is not possible for S to exceed m, because if one has more than m vectors in ")#mi("{\\Bbb C}^m")#text(", then there must be a non-trivial linear independence amongst those vectors, which is not compatible with the UUP (or RIP) condition (3).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d6c851bd914c80e04fa52f19b9828596ebe0f1a2bcf002a845568bbfc667fc8-9a0a7cf3f0f76a086365fd81a206c7f856ecb5af0278186739e5468ddb69265e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-38307")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Dr Tao:")

#text("Has there been any follow ups on this topic. I have not been able to find any literature on efficient methods for determining the RIP property of these matrices, in order to use the test in a practical scenario. Also have other necessary conditions been given for perfect recovery. Since the RIP is sufficient.")

#text("Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/397530fd2887f612fba57abd32459442958e156e9a8d23305eb271a9f74ca393-fab68614ef7c5f8b6cbacb2fd16cb80a62d3801234d373e83bcfdb326cc5e905.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oz")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-41065")[#strong[#text("oz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2009")])]

#text("Dear Prof. Tao,")

#text("I have a question which is somewhat related to this post. Are there any known results on sparse sensing matrices (whether deterministic or randomized)?")#linebreak()#text(" I’ll try to explain what I mean: It is known that random Bernoulli or Gaussian matrices satisfy the RIP with high probability. These matrices are dense. In many applications I would imagine that the number of non-zero entries in the matrix is itself of considerable cost (as they represent linear combinations of the signal, and each such entry requires access to a given coordinate of the signal, which can cost some hardware/time/etc.). So how low can you go with the matrix density and still keep the RIP property? For example, if we take random matrices with prob. 1-p being zero, and p/2 being 1 or -1, how low can we take p to be? Clearly, if the matrix becomes too sparse, then finally we reach the point where each line of the matrix measures a few or just one signal, and then we’ll need the number or rows to be roughly equal to the length of the input signal (far more than its sparsity). Thus the breakdown of RIP occurs sooner (i.e. for not completely sparse matrix). Is it known when does this happen? if it a gradual decline, or is there some ‘phase-transition’ and a threshold p? (or some other threshold, depending on the matrix size, e.g. maybe you need log N non-zero entries in each line?)")

#text("Thank you,")#linebreak()#text(" OZ")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-41066")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2009")])]

#text("There are some combinatorial examples of sparse matrices with good compressed sensing properties, though one uses a slight variant of RIP in this case, see")

#link("http://people.csail.mit.edu/indyk/report.pdf")[#text("Click to access report.pdf")]

#text("but I would imagine that the proof of RIP for iid matrices (which ultimately comes down to control on the singular values) would also work in the sparse case (for instance, in my first paper with Van Vu on the circular law, we found that the relevant singular value bounds for dense matrices could be adapted to sparse matrices without difficulty).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/397530fd2887f612fba57abd32459442958e156e9a8d23305eb271a9f74ca393-fab68614ef7c5f8b6cbacb2fd16cb80a62d3801234d373e83bcfdb326cc5e905.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oz")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-41069")[#strong[#text("oz")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2009")])]

#text("Thanks a lot for your rapid response – the papers look indeed quite relevant")#linebreak()#text(" (though will need some time to digest them..)")

#text("Best,")#linebreak()#text(" OZ")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c033680a7031a56d5380a562b2f1990eebd307b002b68918e46270ff342145a6-9ad8d3dc12d2258af9fa2b90e7f279455045186ba11804e5d2475312973c01a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of husveges")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-44487")[#strong[#text("husveges")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Dear Dr. Tao,")#linebreak()#text(" You describe UUP matrices with normalized columns and give a nice geometric interpretation that l1 minimization will retrieve not only the minimal coefficients of the columns in the l1 sense, but also the sparsest combination.")#linebreak()#text(" In Candes’ and Romberg’s l1 Magic guide they generate a Gaussian matrix with normalized rows, and then proceed with l1 minimization:")

#link("http://www.acm.caltech.edu/l1magic/downloads/l1magic.pdf")[#text("Click to access l1magic.pdf")]

#text("Why are they normalizing the rows? Does the same geometric intuition hold?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b50968307727912cde852ea162fe36ae6d09063969566379b9adf0eaeb4fe2d-29b3889fa44dcf5b293ae4261adee80c4f4259010ffd609eeeae44d592ffca18.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kishor")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-44516")[#strong[#text("Kishor")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Dear Sir")

#text("I read at many places (e.g. ")#link("http://sites.google.com/site/igorcarron2/cs")[#text("http://sites.google.com/site/igorcarron2/cs")]#text(") that to check whether a family of matrices satisfy RIP, is NP-hard. If that is the case, then do we expect to find a deterministic construction of matrices satisfying RIP?")

#text("Thanks")#linebreak()#text(" Kishor")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02e1a57fd0c917793907bc85f2843b2a9445fad397e2c6c7bf9c2a34154590bc-7337d18678c989e5944c6beea78b768ba9bb066a0b5242a16e6c3ea26c61225a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-129142")[#strong[#text("anon")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2012")])]

#text("Showing NP-hardness of a property does not mean it is neccesarily hard to produce satisfying instances. For example, checking if a Boolean formula is satisfable is NP-hard, yet it is very simple to give tons of constructions of satisfable Boolean formulas of any size.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-129103")[#strong[#text("The road to deterministic matrices with the restricted isometry property « Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2012")]

#text("[…] To reconstruct a sparse vector from relatively few measurements , it has become popular to find an estimate of minimal 1-norm. This estimate happens to be the sparsest vector in the preimage of provided satisfies the restricted isometry property (RIP). In words, an RIP matrix acts as a near-isometry on sufficiently sparse vectors, and since its introduction in 2004, this property has become an important subject of matrix design (see Terry Tao’s blog post on the problem). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-141302")[#strong[#text("Certifying the restricted isometry property is hard « Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2012")]

#text("[…] “An alternate approach, and one of interest in its own right, is to work on improving the time it takes to verify that a given matrix (possibly one of a special form) obeys the UUP.” – Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9bd5109b46e768c06024be4c8c45bd091cfee47b24d18f03c8f4c33210c5006-c9e5c4c05ac7ded601fc411783c09c85b4653992c8797cbf988ebc9cce2f3f38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-231360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")])]

#text("The work by Devore is just a repackaging of the Nisan-Wigderson designs studied long time back. Unfortunately he never cites those references.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-255181")[#strong[#text("Deterministic RIP matrices: Breaking the square-root bottleneck | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")]

#text("[…] years after Terry Tao posed this problem on his blog, the problem was partially solved in this breakthrough […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/732e49f443a9254d1a98379aadc5c07820ee2f390ee1c9a28fecf3dfcf1a249c-87d19d9583b9e3300d9cd8b47e5d99e7792ddae6e38c48b3abc6085c2d9bfb58.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Deterministic RIP matrices: a new cooperative online project | Relax and Conquer")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-255586")[#strong[#text("Deterministic RIP matrices: a new cooperative online project | Relax and Conquer")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("[…] started thinking about the problem of building deterministic RIP matrices 3 years ago, when, as a first year graduate student at Princeton, I was sharing an […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3205d8eeb9c554b4dd0cc3d073ee0fccb7caa8f5245405e7db9ef43dfd7e2b5-a4d99c4307912feff11c653ffa27243560eff8a237c725adfd34835995912cc1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The restricted isometry property. | I Can't Believe It's Not Random!")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-401555")[#strong[#text("The restricted isometry property. | I Can't Believe It's Not Random!")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2014")])]

#text("[…] dimensions which satisfies the restricted isometry property was explicitly formulated by Tao in his blog (he uses the term UUP instead of RIP, standing for uniform uncertainty principle). This paper […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/732e49f443a9254d1a98379aadc5c07820ee2f390ee1c9a28fecf3dfcf1a249c-87d19d9583b9e3300d9cd8b47e5d99e7792ddae6e38c48b3abc6085c2d9bfb58.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conditional Restricted Isometries | Relax and Conquer")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-433869")[#strong[#text("Conditional Restricted Isometries | Relax and Conquer")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2014")])]

#text("[…] problem of building deterministic RIP matrices that break the squareroot bottleneck was posed by Terry Tao in his blog more than 7 years ago. Since then, only one deterministic construction is known to break this bottleneck, due to Bourgain […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-464406")[#strong[#text("Genius at Play: The Curious Mind of John Horton Conway | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2015")]

#text("[…] keep 4 research problems in mind: A big problem (an open problem like matrix multiplication or deterministic RIP), a workable problem (the sort of problem that puts food on the table like clustering and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03bd96aa568a2bfe08b7992a471388a2e5e8e0a54c906839f294d15c7d33c7ae-4b99e89af69f8a8fa7619abe84447bbee02c3ec5ebca160e15bfb22279745467.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reza")]], [#link("https://terrytao.wordpress.com/2007/07/02/open-question-deterministic-uup-matrices/#comment-471879")[#strong[#text("reza")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("hello sir")#linebreak()#text(" i read the articles and don’t get why exactly picking the rows of a matrix need to be random,what is the benefit of randomness?and what about the deterministic approach that some people suggest(espacially in communication for subsampling the fourier matrix)?")
]
