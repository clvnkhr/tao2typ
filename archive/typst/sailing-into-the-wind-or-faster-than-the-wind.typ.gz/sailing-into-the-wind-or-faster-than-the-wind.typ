// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/
// Converted to Typst by tao2typ: "2026-10-14T15:17:06.997356+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sailing into the wind, or faster than the wind", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sailing into the wind, or faster than the wind")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/")[#text("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("One of the more unintuitive facts about sailing is that it is possible to harness the power of the wind to ")#link("http://en.wikipedia.org/wiki/Sailing_into_the_wind")[#text("sail in a direction ")#emph[#text("against")]#text(" that of the wind")]#text(" or to sail with a speed faster than the wind itself, even when the water itself is calm. It is somewhat less known, but nevertheless true, that one can (in principle) do both at the same time – sail against the wind (even ")#emph[#text("directly")]#text(" against the wind!) at speeds faster than the wind. This does not contradict any laws of physics, such as conservation of momentum or energy (basically because the reservoir of momentum and energy in the wind far outweighs the portion that will be transmitted to the sailboat), but it is certainly not obvious at first sight how it is to be done.")

#text("The key is to exploit all three dimensions of space when sailing. The most obvious dimension to exploit is the ")#link("http://en.wikipedia.org/wiki/Windward_and_leeward")[#text("windward/leeward")]#text(" dimension – the direction that the wind velocity ")#mi("v_0")#text(" is oriented in. But if this is the only dimension one exploits, one can only sail up to the wind speed ")#tao-math("\\left|v_0\\right|", block: false)#text(" and no faster, and it is not possible to sail in the direction opposite to the wind.")

#text("Things get more interesting when one also exploits the")#emph[]#text(" ")#link("http://en.wikipedia.org/wiki/Crosswind")[#text("crosswind")]#text(" dimension perpendicular to the wind velocity, in particular by ")#link("http://en.wikipedia.org/wiki/Tacking")[#text("tacking")]#text(" the sail. If one does this, then (in principle) it becomes possible to travel up to double the speed ")#tao-math("\\left|v_0\\right|", block: false)#text(" of wind, as we shall see below.")

#text("However, one still cannot sail against to the wind purely by tacking the sail. To do this, one needs to not just harness the power of the wind, but also that of the water ")#emph[#text("beneath")]#text(" the sailboat, thus exploiting (barely) the third available dimension. By combining the use of a sail in the air with the use of sails in the water – better known as ")#link("http://en.wikipedia.org/wiki/Keel")[#text("keels")]#text(", ")#link("http://en.wikipedia.org/wiki/Rudder")[#text("rudders")]#text(", and ")#link("http://en.wikipedia.org/wiki/Sailing_hydrofoil")[#text("hydrofoils")]#text(" – one can now sail in certain directions against the wind, and at certain speeds. In most sailboats, one relies primarily on the keel, which lets one sail against the wind but not directly opposite it. But if one tacks the rudder or other hydrofoils as well as the sail, then in fact one can (in principle) sail in arbitrary directions (including those directly opposite to ")#mi("v_0")#text("), and in arbitrary speeds (even those much larger than ")#tao-math("\\left|v_0\\right|", block: false)#text("), although it is quite difficult to actually achieve this in practice. It may seem odd that the water, which we are assuming to be calm (i.e. traveling at zero velocity) can be used to increase the range of available velocities and speeds for the sailboat, but we shall see shortly why this is the case.")

#text("If one makes several simplifying and idealised (and, admittedly, rather unrealistic in practice) assumptions in the underlying physics, then sailing can in fact be analysed by a simple two-dimensional geometric model which explains all of the above statements. In this post, I would like to describe this mathematical model and how it gives the conclusions stated above.")

#heading(level: 1)[#metadata(none) <tao-baa1c91401858e921be5>#text("— One-dimensional sailing —")]

#text("Let us first begin with the simplest case of one-dimensional sailing, in which the sailboat lies in a one-dimensional universe (which we describe mathematically by the real line ")#mi("{\\Bbb R}")#text("). To begin with, we will ignore the friction effects of the water (one might imagine sailing on an ")#link("http://en.wikipedia.org/wiki/Ice_boat")[#text("iceboat")]#text(" rather than a sailing boat). We assume that the air is blowing at a constant velocity ")#mi("v_0 \\in {\\Bbb R}")#text(", which for sake of argument we shall take to be positive. We also assume that one can do precisely two things with a sailboat: one can either ")#emph[#text("furl")]#text(" the sail, in which case the wind does not propel the sailboat at all, or one can ")#emph[#text("unfurl")]#text(" the sail, in order to exploit the force of the wind.")

#text("When the sail is furled, then (ignoring friction), the velocity ")#mi("v")#text(" of the boat stays constant, as per ")#link("http://en.wikipedia.org/wiki/Newton%27s_laws_of_motion")[#text("Newton’s first law")]#text(". When instead the sail is unfurled, the motion is instead governed by ")#link("http://en.wikipedia.org/wiki/Newton%27s_laws_of_motion")[#text("Newton’s second law")]#text(", which among other things asserts that the velocity ")#mi("v")#text(" of the boat will be altered in the direction of the net force exerted by the sail. This net force (which, in one dimension, is purely a ")#link("http://en.wikipedia.org/wiki/Drag_(physics)")[#text("drag")]#text(" force) is determined not by the true wind speed ")#mi("v_0")#text(" as measured by an observer at rest, but by the ")#link("http://en.wikipedia.org/wiki/Apparent_wind")[#text("apparent wind")]#text(" speed ")#mi("v_0 - v")#text(" as experienced by the boat, as per the (")#link("http://en.wikipedia.org/wiki/Galilean_invariance")[#text("Galilean")]#text(") ")#link("http://en.wikipedia.org/wiki/Principle_of_relativity")[#text("principle of relativity")]#text(". (Indeed, Galileo himself supported this principle with a ")#link("http://en.wikipedia.org/wiki/Galileo%27s_ship")[#text("thought-experiment on a ship")]#text(".) Thus, the sail can increase the velocity ")#mi("v")#text(" when ")#mi("v_0-v")#text(" is positive, and decrease it when ")#mi("v_0-v")#text(" is negative. We can illustrate the effect of an unfurled sail by the following vector field in velocity space:")

#heading(level: 4)[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/wind1.png")[#image("../assets/d1b8006ac8dcf56671812b0c64ff9230a9fef58a15086e33e4ea1dd421378f70-7ea819dcb964e5e0d2c0bb9931d555c74dfbc199cae82ae18e751b6306128bb4.png", width: 90%, alt: "wind1")]#text("Figure 1. The effect of a sail in one dimension.")]

#text("The line here represents the space of all possible velocities ")#mi("v")#text(" of a boat in this one-dimensional universe, including the rest velocity ")#mi("{}0")#text(" and the wind velocity ")#mi("v_0")#text(". The vector field at any given velocity ")#mi("v")#text(" represents the direction the velocity will move in if the sail is unfurled. We thus see that the effect of unfurling the sail will be to move the velocity of the sail towards v. Once one is at that speed, one is stuck there; neither furling nor unfurling the sail will affect one’s velocity again in this frictionless model.")

#text("Now let’s reinstate the role of the water. Let us use the crudest example of a water sail, namely an ")#link("http://en.wikipedia.org/wiki/Anchor")[#text("anchor")]#text(". When the anchor is raised, we assume that we are back in the frictionless situation above; but when the anchor is dropped (so that it is ")#link("http://en.wikipedia.org/wiki/Drag_(physics)")[#text("dragging")]#text(" in the water), it exerts a force on the boat which is in the direction of the apparent velocity ")#mi("0-v")#text(" of the water with respect to the boat, and which (ideally) has a magnitude proportional to square of the apparent speed ")#tao-math("\\left|0-v\\right|", block: false)#text(", thanks to the ")#link("http://en.wikipedia.org/wiki/Drag_equation")[#text("drag equation")]#text(". This gives a second vector field in velocity space that one is able to effect on the boat (displayed here as thick blue arrows):")

#heading(level: 4)[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/wind2.png")[#image("../assets/8e1e4331d481f151411011eba42f49d413ecf4bb29d1f53e2a590ba3c7ba86c9-0003791f9818a858d3452a514d48a3e908df16f64397af35798e5036deef80fa.png", width: 90%, alt: "wind2")]#text("Figure 2. The effects of a sail and an anchor in one dimension.")]

#text("It is now apparent that by using either the sail or the anchor, one can reach any given velocity between 0 and ")#mi("v_0")#text(". However, once one is in this range, one cannot use the sail and anchor to move faster than ")#mi("v_0")#text(", or to move at a negative velocity.")

#heading(level: 1)[#text("— Two-dimensional sailing —")]

#text("Now let us sail in a two-dimensional plane ")#mi("{\\Bbb R}^2")#text(", thus the wind velocity ")#mi("v_0")#text(" is now a vector in that plane. To begin with, let us again ignore the friction effects of the water (e.g. imagine one is ")#link("http://en.wikipedia.org/wiki/Ice_yachting")[#text("ice yachting")]#text(" on a two-dimensional frozen lake).")

#text("With the ")#link("http://en.wikipedia.org/wiki/Square_rig")[#text("square-rigged")]#text(" sails of the ancient era, which could only exploit drag, the net force exerted by an unfurled sail in two dimensions followed essentially the same law as in the one-dimensional case, i.e. the force was always proportional to the relative velocity ")#mi("v_0-v")#text(" of the wind and the ship, thus leading to the black vector field in the figure below:")

#heading(level: 4)[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/wind3.png")[#image("../assets/4ed7298d1d3af6d9a56d5b34307b12091cec1ff6c34438b2670a60558bee868f-3236dad30fa1d393a8e7cbda5c05393f89a28bb2b953f4a9eda9c50a845a8e57.png", width: 90%, alt: "wind3")]#text("Figure 3. The effects of a pure-drag sail (black) and an anchor (blue) in two dimensions.")]

#text("We thus see that, starting from rest ")#mi("v=0")#text(", the only thing one can do with such a sail is move the velocity ")#mi("v")#text(" along the line segment from 0 to ")#mi("v_0")#text(", at which point one is stuck (unless one can exploit water friction, e.g. via an anchor, to move back down that line segment to 0). No crosswind velocity is possible at all with this type of sail.")

#text("With the invention of the curved sail, which redirects the (apparent) wind velocity ")#mi("v_0 - v")#text(" to another direction rather than stalling it to zero, it became possible for sails to provide a ")#link("http://en.wikipedia.org/wiki/Lift_(force)")[#text("lift")]#text(" force which is essentially perpendicular to the (apparent) wind velocity, in contrast to the drag force that is parallel to that velocity. (Not co-incidentally, such a sail has essentially the same ")#link("http://en.wikipedia.org/wiki/Aerofoil")[#text("aerofoil")]#text(" shape as an airplane wing, and one can also explain the lift force via ")#link("http://en.wikipedia.org/wiki/Bernoulli%27s_principle")[#text("Bernoulli’s principle")]#text(".)")

#text("[Despite the name, the lift force is not a vertical force in this context, but instead a horizontal one; in general, lift forces are basically perpendicular to the orientation of the aerofoil providing the lift. Unlike airplane wings, sails are vertically oriented, so the lift will be horizontal in this case.]")

#text("By setting the sail in an appropriate direction, one can now use the lift force to adjust the velocity v of a sailboat in directions perpendicular to the apparent wind velocity ")#mi("v_0-v")#text(", while using the drag force to adjust v in directions parallel to this apparent velocity; of course, one can also adjust the velocity in all intermediate directions by combining both drag and lift. This leads to the following vector fields, displayed in red:")

#heading(level: 4)[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/wind5.png")[#image("../assets/76ba9a648c0c27c4ce78bcd09042ae9daeedd61179b499948e50b633184fc4ae-28ac0669fcfa9953a84edd724a820187d19acb2ec7a325b6712270fb6ea1540a.png", width: 90%, alt: "wind5")]#text("Figure 4. The effect of a pure-drag sail (black) and a pure-lift sail (red) in two dimensions. The disk enclosed by the dotted circle represents the velocities one can reach from these sails starting from the rest velocity ")#mi("v=0")#text(".")]

#text("Note that no matter how one orients the sail, the apparent wind speed ")#tao-math("\\left|v_0-v\\right|", block: false)#text(" will decrease (or at best stay constant); this can also be seen from the law of conservation of energy in the reference frame of the wind. Thus, starting from rest, and using only the sail, one can only reach speeds in the circle centred at ")#mi("v_0")#text(" with radius ")#tao-math("\\left|v_0\\right|", block: false)#text(" (i.e. the circle in Figure 4); thus one cannot sail against the wind, but one can at least reach speeds of twice the wind speed, at least in principle. (In practice, friction effects of air and water, such as ")#link("http://en.wikipedia.org/wiki/Wave_making_resistance")[#text("wave making resistance")]#text(", and the difficulty in forcing the sail to provide purely lift and no drag, mean that one cannot quite reach this limit, but it has still been possible to exceed the wind speed with this type of technique.)")

#heading(level: 1)[#text("— Three-dimensional sailing —")]

#text("Now we can turn to three-dimensional sailing, in which the sailboat is still largely confined to ")#mi("{\\Bbb R}^2")#text(" but one can use both air sails and water sails as necessary to control the velocity ")#mi("v")#text(" of the boat. (Some boats do in fact exploit the third dimension more substantially than this, e.g. using sails to vertically lift the boat to reduce water drag, but we will not discuss these more advanced sailing techniques here.)")

#text("As mentioned earlier, the crudest example of a water sail is an anchor, which, when dropped, exerts a pure drag force in the direction of ")#mi("0 - v")#text(" on the boat; this is displayed as the blue vector field in Figure 3. Comparing this with Figure 4(which is describing all the forces available from using the air sail) we see that such a device does not increase the range of velocities attainable from a boat starting at rest (although it does allow a boat moving with the wind to return to rest, as in the one-dimensional setting). Unsurprisingly, anchors are not used all that much for sailing in practice.")

#text("However, we can do better by using other water sails. For instance, the ")#link("http://en.wikipedia.org/wiki/Keel")[#text("keel")]#text(" of a boat is essentially a water sail oriented in the direction of the boat (which in practice is kept close to parallel to ")#mi("v")#text(", e.g. by use of the rudder, else one would encounter substantial (and presumably unwanted) water drag and torque effects). The effect of the keel is to introduce significant resistance to any lateral movement of the boat. Ideally, the effect this has on the net force acting on the boat is that it should orthogonally project that force to be parallel to the direction of the boat (which, as stated before, is usually parallel to ")#mi("v")#text("). Applying this projection to the vector fields arising from the air sail, we obtain some new vector fields along which we can modify the boat’s velocity:")

#align(center)[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/wind61.png")[#image("../assets/8cc6024fb331b085612771b9bd8d15ed4ad04df3104d32b0bf6d155a0286ba20-3252bcf20e294132c985df47bfe2bdd2631ce22947ed7973f73858ed6c574eaf.png", width: 90%, alt: "wind61")]]

#heading(level: 4)[#text("Figure 5. The effect of a pure-drag sail (black), a pure-lift sail (red), and a pure-lift sail combined with a keel (green). Note that one now has the ability to shift the velocity v away from both 0 and ")#mi("v_0")#text(" no matter how fast one is already traveling, so long as v is not collinear with 0 and ")#mi("v_0")#text(".")]

#text("In particular, it becomes possible to sail against the wind, or faster than the wind, so long as one is moving at a non-trivial angle to the wind (i.e. ")#mi("v")#text(" is not parallel to ")#mi("v_0")#text(" or ")#mi("-v_0")#text(").")

#text("What is going on here is as follows. By using lift instead of drag, and tacking the sail appropriately, one can make the force exerted by the sail be at any angle of up to ")#mi("90^\\circ")#text(" from the actual direction of apparent wind. By then using the keel, one can make the net force on the boat be at any angle up to ")#mi("90^\\circ")#text(" from the force exerted by the sail. Putting the two together, one can create a force on the boat at any angle up to ")#mi("180^\\circ")#text(" from the apparent wind speed – i.e. in any direction other than directly against the wind. (In practice, because it is impossible have a pure lift force free of drag, and because the keel does not perfectly eliminate all lateral forces, most sailboats can only move at angles up to about ")#mi("135^\\circ")#text(" or so from the apparent wind direction, though one can then create a net movement at larger angles by ")#link("http://en.wikipedia.org/wiki/Tack_(maneuver)")[#text("tacking")]#text(" and ")#link("http://en.wikipedia.org/wiki/Sailing#Sailing_upwind")[#text("beating")]#text(". For similar reasons, water drag prevents one from using these methods to move too much faster than the wind speed.)")

#text("In theory, one can also sail at any desired speed and direction by combining the use of an air sail (or ")#link("http://en.wikipedia.org/wiki/Airfoil")[#text("aerofoil")]#text(") with the use of a water sail (or ")#link("http://en.wikipedia.org/wiki/Sailing_hydrofoil")[#text("hydrofoil")]#text("). While water is a rather different fluid from air in many respects (it is far denser, and virtually incompressible), one could in principle deploy hydrofoils to exert lift forces on a boat perpendicular to the apparent water velocity ")#mi("0 - v")#text(", much as an aerofoil can be used to exert lift forces on the boat perpendicular to the apparent wind velocity ")#mi("v_0 - v")#text(". We saw in the previous section that if the effects of drag on the aerofoil could somehow be ignored, then one could use lift to alter the velocity ")#mi("v")#text(" along a circle centred at the true wind speed ")#mi("v_0")#text("; similarly, if the effects of drag on the hydrofoil could also be ignored (e.g. by ")#link("http://en.wikipedia.org/wiki/Planing_(sailing)")[#text("planing")]#text("), then one could alter the velocity ")#mi("v")#text(" along a circle centred at the true water speed ")#mi("{}0")#text(". By alternately using the aerofoil and hydrofoil, one could in principle reach arbitrarily large speeds and directions, as illustrated by the following diagram:")

#heading(level: 4)[#link("https://terrytao.wordpress.com/wp-content/uploads/2008/12/wind8.png")[#image("../assets/7944b8f0d0bd7ed9997902893daab398a9580349f696269c84189fd4635ddd3c-64a0e6a5935ef6c6649840dfe368b1edee19a2c35b47c5eac38935d6e71525d9.png", width: 90%, alt: "wind8")]#text("Figure 6. By alternating between a pure-lift aerofoil (red) and a pure-lift hydrofoil (purple), one can in principle reach arbitrarily large speeds in any direction.")]

#text("I do not know however if one could actually implement such a strategy with a physical sailing vessel.")

#text("It is reasonable (in light of results such as the ")#link("http://en.wikipedia.org/wiki/Kutta%E2%80%93Joukowski_theorem")[#text("Kutta-Joukowski theorem")]#text(") to assume that the amount of lift provided by an aerofoil or hydrofoil is linearly proportional to the apparent wind speed or water speed. If so, then some basic trigonometry then reveals that (assuming negligible drag) one can use either of the above techniques to increase one’s speed at what is essentially a constant rate; in particular, one can reach speeds of ")#tao-math("n\\left|v_0\\right|", block: false)#text(" for any ")#mi("n > 0")#text(" in time ")#mi("O(n)")#text(". On the other hand, as drag forces are quadratically proportional to apparent wind or water speed, one can ")#emph[#text("decrease")]#text(" one’s speed at an very rapid rate simply by dropping anchor; in fact one can drop speed from ")#tao-math("n\\left|v_0\\right|", block: false)#text(" to ")#tao-math("\\left|v_0\\right|", block: false)#text(" in ")#emph[#text("bounded")]#text(" time ")#mi("O(1)")#text(" no matter how large n is! (This fact is the time-reversal of the well-known fact that the ")#link("http://en.wikipedia.org/wiki/Riccati_equation")[#text("Riccati ODE")]#text(" ")#mi("u^{\\prime} = u^2")#text(" blows up in finite time.) These appear to be the best possible rates for acceleration or deceleration using only air and water sails, though I do not have a formal proof of this fact.")

#heading(level: 1)[#text("Comments (61)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37224")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("This is a clever construction that I assume is known? If it’s not previously known, then great! It seems related to the fact that even a glider plane can in theory reach unlimited velocities by diving.")

#text("The discussion reminds me of a simple construction in a totally different topic:")

#text("Consider a lottery in which in which everyone writes their own tickets, and the after-tax payout is high but less than 100%, according to the usual rule that the jackpot is split evenly among everyone who has a winning ticket. Suppose further that there is a field of contestants who each buy a few tickets that they chose at random. Then it is possible, if you buy enough tickets, for your expected return to be more than 100%. (But in real lotteries, the after-tax payout is so bad that it would not be profitable unless the other contestants used a bad non-random strategy.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11ab734296aa01e8ad6a700a068afbd11efc7372300cf0791f9ab5d29234ec1-e8b70f664a2e8b6094c407fb52e3efe89e9c42d67b0a043d4ab0b79305c54956.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37232")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("That was fascinating! I was about to open my text editor to do some writing, but got completely distracted by this. I’ve known about the capability of sailing into the wind for a long time, but never bothered to figure out how that works. If you’re onto something new, as Greg wondered, you may very well be approached by some of those very competitive sail boat racers wondering how they may be able to optimize their strategy. I’m guessing that this train of thought probably generalizes to other contexts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c9f6f3e3aae3efe19fba4a844623a2ddad2e4769f9d930efc1df96181d2f386-c22f941a6b734dee810d83f0d4da248cc7d6e1bfe7e70c0882720dad88b51586.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kurt")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37234")[#strong[#text("Kurt")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("Did you catch any of the discussion on the Web late last year about “directly downwind, faster than the wind” wind-powered travel? Quite a few armchair mathematicians were arguing that it was physically impossible to achieve. (A little summary with some links is available ")#link("http://learningcomputation.com/blog/2008/12/counter-intuitive-science.html")[#text("here")]#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37236")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("From “Two dimensional sailing”:")

#text("but one can at least reach speeds of twice the wind speed, at least in principle")

#text("Shouldn’t this be")

#text("but one can at least reach speeds of $\\sqrt(2)$ the wind speed, at least in principle")

#text("since the lift can achieve speed perpendicular to the wind at most $v$, and direct sail force can achieve speed parallel to the wind at most $v$? Or can the lift force increase the perpendicular speed beyond $v$?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/396b4a383665680ffd2998f99daf4538d4c2d9edb0a6fd51bb283bf5b16de979-da17ca0f216ea4695e928a42a808a2b5cb40badb4451e2f6c1083790dc16c8f4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of vzemlys")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37240")[#strong[#text("vzemlys")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2009")])]

#text("Awesome, totally awesome.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37242")[#strong[#text("Unscheduled Post: Faster than the speed of wind « Maxwell’s Demon")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")]

#text("[…] Post: Faster than the speed of wind Terence Tao has a beautiful analysis of sailing, in particular: One of the more unintuitive facts about sailing is that it is possible to harness […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1191a271dce8843dec588cbf5c298ec555e12a8e971d11d12bcef8c2fb1576f8-b5c230a6849acd916d5fe9967f74d1496870c9f17a586146a0b263c7f9826d35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Attila Smith")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37243")[#strong[#text("Attila Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("Dear Terence,")#linebreak()#text(" this confirms that you are a reincarnation of Euler: cf. his")#linebreak()#text(" “De promotione navium sine vi venti”")#linebreak()#text(" Of course you don’t believe in reincarnation but apparently, in true Niels Bohr spirit, it works even for skeptics .")#linebreak()#text(" Friendly greetings, A.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/895edba02bce6dc47f8eff750e9d9652c1b454f0380dbb0523ef2ec5a52a529e-f312f1ca54f892810c8e39351e793b4215d27e2070c8be4d5f8bbf91db676117.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of inAm")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37264")[#strong[#text("inAm")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("Great post indeed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37268")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("This also can apply if the momentum is transferred by photons to a solar sail. Assuming that you can electromagnetically couple to the solar (stellar) wind of the star that you’re accelerating away from or decelerating towards.")

#text("see: Project Solar Sail, ed. Arthur C. Clarke, David Brin, Jonathan V. Post, Roc, an imprint of Penguin Books USA Inc. (April 3, 1990), ISBN-13: 978-0451450029, still available via Amazon.")

#text("It’s a bit different if momentum is transferred by solar wind to a magnetic sail (which I qualitatively invented, as a variation on “ringsat” by James B. Stephens at JPL) while working a NASA Advanced Propulsion contract with Dr. Dana Andrews at Boeing. I came to JPL, and Dr. Bob Zubrin continued the magsail work, solved the key plasma physics equation, and co-patented with Dr. Andrews.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37282")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")]

#text("[…] Sailing into the wind, or faster than the wind One of the more unintuitive facts about sailing is that it is possible to harness the power of the wind to sail in a […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/458f19f1137c62e7359bde57a6e41d91e31a1efeea107ff6af7227841484d576-c84c4ed3eb8f847c2b1e859e3d84fc9a04ae305afcc0068fb38f50d050c7ca71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Izabella Laba")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37298")[#strong[#text("Izabella Laba")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("I don’t know your sailing experience, Terry, but I think that this is missing a couple of things.")

#text("First, and crucially, most boats have more than one sail. This is important because most of the lift force is in fact generated by the funnels between the sails, for example between the jib and main on a ketch. The entire configuration is really much more than the sum of its parts. However, that works better for some directions than for others. Once you’re too close to going straight downwind, you lose the funnel altogether and the jib is idling until you flip one of your sails over to the other side (the “butterfly”). That’s why you’ll often go faster on a broad reach than straight downwind.")

#text("It’s still possible to use the lift force while going downwind, for example by hoisting a spinnaker. However, you need to take it down before you can make any significant changes in direction. You really do. You don’t want to have a spinnaker wrapped around your shrouds.")

#text("Also, planing does not eliminate the effects of drag on the “hydrofoil”. In planing, the boat is mostly lifted out of the water so that there is very little drag on the *body* of the boat. If you’re going straight downwind in a dinghy and and start planing, you may want to lift up the centerboard and much of the rudder to decrease the drag forces further. That means, though, that the hydrofoil is not being used much, either drag-wise or lift-wise. If you’re planing on a reach, at least part of the centerboard and rudder have to stay under water. You need then to maintain the direction and there’s no way to retain that ability without also retaining some of the drag.")

#text("The situation you write about – one sail whose position and angle can be adjusted almost arbitrarily, negligible drag from the body of the boat – seems to be better matched to windsurfing than sailing. These things can move extremely fast and are propelled mostly by the apparent wind. Not in spiral trajectories, though, as far as I know.")

#text("Anyway, thanks for bringing up the subject.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/025185fc792882b07a48fa5d72f35ec2cfb0c8d123176630cb87e02396af4928-ae83e722bc11336ce3ddca20dd52e1ebc7af269437208793cc030e6abea08aba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37303")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("Dear Terry,")

#text("This is an impressive analysis. But there is something I do not know how you get it. That is,")

#text("¨one can reach speeds of n|v_0| for any n > 0 in time O(n).¨")

#text("how this O(n) get?")

#text("And the similar question about how time decrease exponentially? at O(log n)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37305")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("David: the back-of-the-envelope problem is that viscous drag in turbulent fluids increases as O(v^3).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56088932c6318ccb5266580a9b56711e94d09198cd18769fe84da7450c5a37e1-4e778f5d223adde7456f58ac8d571d8db111c88a1bacec1396cf77cd762ac9d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of meichenl")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37313")[#strong[#text("meichenl")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")])]

#text("For an anchor dropped in water, viscosity is probably not very important, so I would expect drag to go roughly as ")#mi("v^2")#text(". (see ")#link("http://en.wikipedia.org/wiki/Drag_equation")[#text("drag equation")]#text("). I think that would let you decrease speed from ")#tao-math("n\\left\\|v\\right\\|", block: false)#text(" to ")#tao-math("\\left\\|v\\right\\|", block: false)#text(" in time ")#mi("t \\propto (n-1)")#text(" for ")#mi("n>1")#text(". Of course, this model also predicts that if you furl the sails and drop anchor, you’ll still coast infinitely far!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of conformal")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37326")[#strong[#text("conformal")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")])]

#text("Off-topic: the moonlandings delta-v “change in velocity” technique is quite sophisticated. ")#link("http://en.wikipedia.org/wiki/Delta-v")[#text("http://en.wikipedia.org/wiki/Delta-v")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37328")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")])]

#text("[…] Sailing into the wind, or faster than the wind […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebe27d6dea9c5693608e26ad3cb8652abcfc5b2fab0e05756a97dbc98cca8be0-5564893a832e3beec33b2dd9f005a246e8d045c87b860e57ba1e5fa50156c0b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kanyonman")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37466")[#strong[#text("kanyonman")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("According to this article:")

#link("http://www.nalsa.org/Articles/Cetus/Iceboat%20Sailing%20Performance-Cetus.pdf")[#text("Click to access Iceboat%20Sailing%20Performance-Cetus.pdf")]

#text("iceboats can routinely reach 6 times the wind-speed,")#linebreak()#text(" and in light wind, 10 times the wind-speed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ddd91b15dfaf85b702d2e71edfa503ce7dedde833e0b1d4408c94e1dfbb73193-1f0ff3e6421c4829865bf1c146e3cfca453fdbb31b072061fe2aec086ecc2278.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ano")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37493")[#strong[#text("Ano")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2009")])]

#text("Interesting video ")#link("http://www.youtube.com/watch?v=1BRvYZd81AQ&feature=related")[#text("http://www.youtube.com/watch?v=1BRvYZd81AQ&feature=related")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03fc988c741b7e7ea461d8d06f746a9472ec91efb30a2b9c212da662da4c5a51-af6b8bdd73832066b7c834ffdd34e1d9f08be00fbd40d8664c76b2f91cb5f4e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Billy & Grace Tao")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37505")[#strong[#text("Billy & Grace Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("Hi Terry,")

#text("Just for my interest, when you wrote down your calculations were you actually thinking of a land vehicle (such as the greenbird) sailing on ice, or a boat in water as most other people had assumed? see:")

#link("http://www.greenmuze.com/climate/travel/969-greenbird-sets-record.html")[#text("http://www.greenmuze.com/climate/travel/969-greenbird-sets-record.html")]

#text("Billy")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/401cd0f886df20679a74ea0bf8a3f6216fee397483fa9dda22c17627ada47731-36826793129a2924643b19829e1554b024009e413ad87451794f5f08351e7e42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Carnahan")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37517")[#strong[#text("Scott Carnahan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("This is really cool – I was getting mental pictures of sailboats following bizarre oscillating trajectories to slingshot themselves to the finish line.")

#text("It seems like if we keep our idealized keel and rudder parallel, we are constrained to a fixed linear trajectory, i.e., the pure-lift force is projected to the direction of motion. Without friction, the parallel component of this force is independent of the water-speed, so we can already achieve arbitrary speeds perpendicular to the wind without actively using a hydrofoil to steer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/458f19f1137c62e7359bde57a6e41d91e31a1efeea107ff6af7227841484d576-c84c4ed3eb8f847c2b1e859e3d84fc9a04ae305afcc0068fb38f50d050c7ca71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Izabella Laba")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37519")[#strong[#text("Izabella Laba")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("Scott:")

#emph[#text("It seems like if we keep our idealized keel and rudder parallel, we are constrained to a fixed linear trajectory, i.e., the pure-lift force is projected to the direction of motion.")]

#text("Not exactly. Most windsurfing boards have only a very small *fixed* rudder (you can’t move it around) and no keel or centerboard. To change directions, you move the sail forward (to bear off) or backward (to head up).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/409852574e4160a0b5ff0c94f05a3de6a7734d6368aedee8d2b69944d80b4f5b-0e37a36edc40552579fad44820a515d6e8f5a1d7afb53b2d8fc9e2f7bf2d0594.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-524217")[#strong[#text("Liam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2019")])]

#text("I can do this on a bermuda rig by adjusting tension on the main (round up) or jib (bear away), while maintaining a fixed rudder position.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/401cd0f886df20679a74ea0bf8a3f6216fee397483fa9dda22c17627ada47731-36826793129a2924643b19829e1554b024009e413ad87451794f5f08351e7e42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott Carnahan")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37520")[#strong[#text("Scott Carnahan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("Izabella,")

#text("Sorry if I was unclear. I wanted to work in a simplified context where my motion was constrained to a line (in any direction not parallel to the wind), so I imagined a boat with a huge, frictionless centerboard and rudder. In the case where the sail is a pure lifting body for which the force on the boat has direction perpendicular to the apparent wind and proportional magnitude, there will be a constant forward resulting force on the boat, because the water speed component of the apparent wind speed is projected to zero. This causes acceleration at a rate that only depends on the sine of the angle between your boat direction and the absolute wind direction, and the boat accelerates to arbitrary speeds.")

#text("The steering mechanism in windsurfing has always seemed quite strange to me. It seems to work by using the wind force on the sail to create torque between your feet and the point where the sail is anchored to the board.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/458f19f1137c62e7359bde57a6e41d91e31a1efeea107ff6af7227841484d576-c84c4ed3eb8f847c2b1e859e3d84fc9a04ae305afcc0068fb38f50d050c7ca71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Izabella Laba")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37522")[#strong[#text("Izabella Laba")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("Scott,")

#text("It is indeed torque, but not as you describe – that would only reorient the board without changing the actual direction in which it’s moving. Rather, it’s the torque between the point where the lift force is centered (roughly, the centerpoint of the sail) and the point where the drag force on the board is centered.")

#text("By the way, it’s also possible (if somewhat difficult) to steer a sailboat by adjusting the sails – without using the rudder. That comes in handy when your rudder is broken or otherwise unusable.")

#text("The point I’ve tried to make earlier, and should have perhaps made clearer, is this. There are few basic principles that apply to all kinds of sailing: apparent wind, lift force, etc. However, once you get around to discussing specifics such as the relative magnitude and direction of the various forces, the velocity of the boat/board/whatever, etc., there are very significant differences between windsurfing, small boat sailing, large boat sailing, and I suppose ice sailing. (I have no experience in the latter but it looks closest to windsurfing.) “Significant” means that they’re not negligible compared to the basic mechanism – more like, they’re a big part of it. For example, the range of directions in which a usable lift force can actually be obtained depends very much on your set-up. Terry’s analysis illustrates the basic principles very nicely. But you shouldn’t necessarily expect actual boats to behave quite as described.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37525")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("It does seem that iceboating comes the closest to the idealised model in my main post. An ice skater (or skier, for that matter) can adjust his or her velocity in a manner which is effectively equivalent to that of the idealised pure-lift hydrofoil, so I can imagine that an iceboat could do likewise. So perhaps a windsurfer on ice skates might actually be able to implement Figure 6, though I would not recommend that someone try this. :-)")

#text("Incidentally, if all one has to work with is the air sail(s), then one cannot do any better than what is depicted in Figure 4, no matter how complicated the rigging. This can be seen by looking at the law of conservation of energy in the reference frame of the wind. In that frame, the air is at rest and thus has zero kinetic energy, while the sailboat has kinetic energy ")#tao-math("\\frac{1}{2} m \\left|v_0\\right|^2", block: false)#text(". The water in this frame has an enormous reservoir of kinetic energy, but if one is not allowed to interact with this water, then the kinetic energy of the boat cannot exceed ")#tao-math("\\frac{1}{2} m \\left|v_0\\right|^2", block: false)#text(" in this frame, and so the boat velocity is limited to the region inside the dotted circle. In particular, no arrangement of sails can give a negative drag force.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37559")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("Dear meichenl: good point about the drag equation; I’ve adjusted the analysis accordingly. Interestingly, if drag is proportional to the square of the speed, then one can slow down from speed n|v_0| to |v_0| in bounded time O(1) now, even for n arbitrarily large – this is the time reversal of the fact that the equation ")#mi("\\dot v = v^2")#text(" blows up in finite time. In practical terms, this means that even a small amount of drag will significantly limit the extent to which one can greatly exceed the wind speed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Argon")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-37600")[#strong[#text("Argon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("This is a very nice way to visualize sailing!")

#text("Just a few more thoughts: It’s pretty easy to convince oneself, that the fastest a sail-powered iceboat can go is simply the lift-to-drag ratio of the sail times the wind speed. Presumably, the fastest a sail-powered water boat can go (ignoring the large hull drag) is some function of the lift-to-drag ratio of the sail, the wind speed, the lift-to-drag ratio of the keel, and the water current. It’d be interesting to know what this relation is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-38141")[#strong[#text("Exciting New Blogs and New Posts « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")]

#text("[…] very eraly on (in 1995,) a scientifically useful home page. And finally Terry Tao had a beautiful post on sailing into the wind in higher speed than the wind. Possibly related posts: (automatically […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-38678")[#strong[#text("Let’s Read the Internet! week 10 « Arcsecond")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")]

#text("[…] Sailing Into the Wind, or Faster than the Wind Terry Tao at What’s New […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-42792")[#strong[#text("Sailing Mathematics « Casual Nano")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2009")]

#text("[…] 11, 2009 in Expository | Tags: Sailing This is a very interesting post about sailing into the wind or faster than the wind from Terry Tao. Using some assumptions about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf15b41f24cb2f9320038c37d9a0aa4806923d7a4b962d071b6874deb46577a-135dd0fa4b8db77b38ca8cf3146f47b2a94493b5149b651d8460da83066ee5a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tinos")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43134")[#strong[#text("Tinos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Hi Terence. Nice post! I disagree with your reference to Bernoulli’s principle, though. All it explains is why the airflow around the front of the wing is faster (because there’s a lower pressure). Bernoulli’s principle just says that a pressure difference produces a fluid velocity, it can’t possibly explain lift.")

#text("Argon, I disagree with your lift to drag ratio comment. The lift to drag ratio must equal 1 at the top speed. The ratio gradually reduces to this as the vehicle speeds up. Hmm, I should look at doing a computer model!")

#text("I think the ")#link("http://www.youtube.com/watch?v=iJLFQ-1nGz0")[#text("Greenbird")]#text(" is awesome!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("Bernoulli’s principle can interpreted causally both ways: either as a statement that a pressure difference causes changes in fluid velocity, or that changes in fluid velocity cause changes in pressure. The mathematical formulation of the laws is agnostic as to which causal interpretation one “should” take here. Since velocity around an aerofoil or hydrofoil can be solved for (under ideal conditions, at least) by the various equations of fluid mechanics, one can certainly use Bernoulli’s principle to derive the existence of lift. Of course, one could also do it from first principles also (e.g. via Newton’s laws).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf15b41f24cb2f9320038c37d9a0aa4806923d7a4b962d071b6874deb46577a-135dd0fa4b8db77b38ca8cf3146f47b2a94493b5149b651d8460da83066ee5a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tinos")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43161")[#strong[#text("Tinos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("I agree the maths doesn’t imply causation either way. I think that in practice, though, the pressure difference always causes the fluid movement.")

#text("For example, ")#link("http://en.wikipedia.org/wiki/Venturi_effect")[#text("these diagrams")]#text(" are used to suggest the greater water speed is causing the lower pressure, when really it’s the pressure difference causing the fluid movement. In the first (purple) diagram, I believe the pressure at the end is determined by what’s to the right, and is the same as the pressure read at the centre. Bernoulli’s principle doesn’t apply to the second joint because heat is created. I might be wrong though, as I’ve never run the experiment. If you disagree I’ll have to make a visit to the hardware store!")

#text("Admittedly, if a kind of ")#link("http://en.wikipedia.org/wiki/Maxwell%27s_demon")[#text("Maxwell’s Demon")]#text(" went in and redirected the molecules of water to move in some direction without adding energy, the static pressure would be reduced as a result of changing fluid velocity. Nothing like this ever happens in real life, though.")

#text("I find people often confuse the ")#link("http://en.wikipedia.org/wiki/Coanda_effect")[#text("Coanda effect")]#text(" with Bernoulli’s principle. A fast moving jet of air entrains the air around it. That’s how the ")#text("spider rifle")#text(" works. Also in the purple venturi diagram it means the static pressure after the second joint would be a bit less than the pressure at the centre, I think.")

#text("Two things observed above an aeroplane wing are lower than atmospheric pressure & greater fluid velocity. The former is the cause of lift, while (in my opinion) the latter is caused by Bernoulli’s principle (low pressure sucks air). If we try to explain the lift (i.e. low pressure) with Bernoulli’s principle, then the greater fluid velocity needs to be explained in some other way.")

#text("Admittedly I haven’t actually done the maths, but I imagine the low pressure is caused by the wing cutting across the air.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf15b41f24cb2f9320038c37d9a0aa4806923d7a4b962d071b6874deb46577a-135dd0fa4b8db77b38ca8cf3146f47b2a94493b5149b651d8460da83066ee5a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tinos")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43162")[#strong[#text("Tinos")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("Oops, that should be “")#link("http://www.youtube.com/watch?v=MnKJzCUy9Tw")[#text("spider rifle")]#text("“.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43177")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("In many cases (e.g. incompressible fluid flows), the pressure can be eliminated from the fluid equations (e.g. incompressible Euler) and one can solve for the velocity directly, e.g. by using the Biot-Savart law to express the velocity in terms of the vorticity (which in turn can be solved for by a variety of laws, e.g. the Kutta condition). One can then use the Bernoulli equation to solve for pressure in terms of velocity, which then gives lift. (The vortex panel method in computational fluid dynamics is one example of this paradigm.)")

#text("Of course, the mathematics can be shuffled around in any number of ways; for instance one can use the Kutta-Joukowski theorem to bypass pressure altogether and derive lift directly from changes in the velocity field. I suppose one could try solving for the pressure first and then deriving the velocity and lift next, though I don’t actually see this done all that much in computational fluid dynamics.")

#text("If one takes a dynamical perspective (introducing a time variable), it becomes mathematically meaningful to discern cause from effect, but in practice, we compute quantities such as lift, pressure, and velocity from static equations rather than dynamic ones (i.e. we assume equilibrium). For such equations, cause and effect are largely interchangeable (")#mi("X=f(Y)")#text(" if and only if ")#mi("Y = f^{-1}(X)")#text(", if ")#mi("f")#text(" is invertible), and can be rearranged according to whatever is most convenient for the mathematical computations.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf15b41f24cb2f9320038c37d9a0aa4806923d7a4b962d071b6874deb46577a-135dd0fa4b8db77b38ca8cf3146f47b2a94493b5149b651d8460da83066ee5a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tinos")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43189")[#strong[#text("Tinos")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("Ah, unfortunately ")#link("http://en.wikipedia.org/wiki/Thin_airfoil_theory#Derivation_of_thin_airfoil_theory")[#text("thin aerofoil theory")]#text(" is a bit over my head at this point. I’ll have to do some more maths courses (@ UQ). It seems that velocity fields are more convenient to work with than pressure fields, though.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf15b41f24cb2f9320038c37d9a0aa4806923d7a4b962d071b6874deb46577a-135dd0fa4b8db77b38ca8cf3146f47b2a94493b5149b651d8460da83066ee5a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tinos")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43135")[#strong[#text("Tinos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Ah, sorry Argon, I take that back. I just did the trigonometry. The lift to drag ratio times wind speed does give the max speed. I’ve assumed perpendicular wind.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0827c98a7a77ed4dfce9cf2b3f4f68c66e23261e8a14fb09da799c6c6ab35394-2b704e8592135d4166c6a6d80ec917415037f3e78678063ad9e2d0f47875c24c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jane @ marine supplies")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43246")[#strong[#text("Jane @ marine supplies")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2010")])]

#text("I agree with you Tino’s, had a similar misconception about the max speed. +rep Argon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40881452d9361fe8aca7b8bf47139c0f8aa7f6d75e6e14becfc32923a9cb4cfa-ffed9a2b27c1f9385f4f79f1befcdfdb9db8a87b98cfcceccddc3288749f0d78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of themotorman")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-43474")[#strong[#text("themotorman")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2010")])]

#text("It seems that since a sail boat can move directly against the direction of the wind by “tacking” it should be possible to move directly against the wind by a high speed version of tacking where the tacking was made in very small increments. If the increments are made smaller and smaller to ultimately reach zero we should still be going against the wind ..Where’s the problem with this?")#linebreak()#text(" Also an airplane can fly with flat wings i.e no airfoil is needed.. check out model planes with flat wings to see how well they do.. it is simply that the momentum of air pushed down is high enough to provide “lift” This is true for planes with an airfoil wing , you still have to push air down for the plane to stay up. No free lunch even with airfoils!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-462651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("flat wings do not work by momentum transfer: they still work with fluid lift. see: ")#link("http://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/19670003842.pdf")[#text("http://ntrs.nasa.gov/archive/nasa/casi.ntrs.nasa.gov/19670003842.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6f39d6c08cecd79f223cf3342f4b2e6193657d286c4bce56403755f120effd-21736ab9949c5921ec0afd6b58d3268776b137114be6b6b81c4203c38bf7446f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Ruina")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-462668")[#strong[#text("Andy Ruina")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("If one specifies the lift to drag ratios of the air-foil (sail) and water foil (keel) than that does indeed bound the upwind and downwind performance of the vehicle. Because there is not theoretical limit to these ratios, there is no theoretical limit to the upwind and downwind performance.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/347c906d990851e7a60430f929d0d83727f041a3506e6b5645a9922f2984c88c-54c04690abb0aacea15ac78565d703c2ef102715a4510e2e74d599b14b94785d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of seacliffsailor")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-44218")[#strong[#text("seacliffsailor")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2010")])]

#text("I just posted a video to youtube with a tinny “sail boat” that can sail directly into the wind – ")#link("http://www.youtube.com/watch?v=ZlFIxmJwlcU")[#text("http://www.youtube.com/watch?v=ZlFIxmJwlcU")]#text(". as far as i know, this has never been done before???")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6f39d6c08cecd79f223cf3342f4b2e6193657d286c4bce56403755f120effd-21736ab9949c5921ec0afd6b58d3268776b137114be6b6b81c4203c38bf7446f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andy ruina")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-44229")[#strong[#text("andy ruina")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2010")])]

#text("A few things:")

#text("1) I didn’t see reference to Lanchester’s course theorem. It seems relevant and is pretty.")#linebreak()#text(" It relates the set of all achievable speeds and directions to the wind speed and")#linebreak()#text(" the lift to drag ratios of the keel and sail. The locus is mating circles each")#linebreak()#text(" with a cord cut off.")

#text("2) A nice paper about sailing theory in general terms, mentioning Lanchester’s thm, is this:")

#text("V. Radhakrishnan: “From square sails to wing sails: The physics of sailing craft.”")#linebreak()#text(" Current Science, Vol. 73, No. 6, 25 September 1997.")

#link("http://dspace.rri.res.in/bitstream/2289/1002/1/1997%20CS%20V73%20p503.pdf")[#text("Click to access 1997%20CS%20V73%20p503.pdf")]

#text("3) I wrote a paper about sailing downwind faster than the wind (DWFTTW) in 1978.")#linebreak()#text(" Actually my first paper. Its still in revision for Am. J. Physics. It has a few")#linebreak()#text(" explanations of things that I think were there before other places. Its on my")#linebreak()#text(" www page. Its all tangled up in this parameter called “a”. That’s because I")#linebreak()#text(" wrote it in reaction to a paper I didn’t like that used that parameter. Ignore that")#linebreak()#text(" and just read the analogies and such like. That paper")#linebreak()#text(" is on my www site:")

#link("http://ruina.tam.cornell.edu/research/topics/miscellaneous/index.php")[#text("http://ruina.tam.cornell.edu/research/topics/miscellaneous/index.php")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b8a2333b1d94820627766fb5a401d829eb22e7371d3df299902026dc84f3be2-103ea7f11a2862e8dca7fcec7ec74d89b8cc94fc070ad976ea9ce370d12ea675.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcin Kostur")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-48074")[#strong[#text("Marcin Kostur")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2010")])]

#text("I put some comments and matlab code simulating the mechanics of sailing:")#linebreak()#text(" ")#link("http://goo.gl/TtEfM")[#text("http://goo.gl/TtEfM")]

#text("DWFTTW can be explained too.")

#text("Also: In the article you mention that:")

#text("“It is reasonable (in light of results such as the Kutta-Joukowski theorem) to assume that the amount of lift provided by an aerofoil or hydrofoil is linearly proportional to the apparent wind speed or water speed”")

#text("which is not precise as in the Kuttta formula there is circulation which depends on velocity too ;-), thus lift and drag can be approximated rather by v^2, see e.g. ")#link("http://en.wikipedia.org/wiki/Lift_(force)")[#text("http://en.wikipedia.org/wiki/Lift_(force)")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c1519a2fee916982da8c661c255c4fc0d5ae6c03b6ae7c03b9b5f08730ca32d-1fea97456fc32f63aeb6f507905517091ca6e43da450b2c500b22deda4c4d893.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beating the Breeze | Metaverse Sailing")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-48698")[#strong[#text("Beating the Breeze | Metaverse Sailing")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("[…] just to highlight a year-old, nicely written blog post by Terrance Tao on the RL physics of “Sailing into the wind, or faster than the wind.” For a pretty inscrutable topic with a numbers-laden discussion, it’s impressive […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bfa0191fd024c428ce0dee88b93b02e505111eaa8f0ea3c59d2a1e8d11532e4-a48b3475ccef4143a519a6a72aaec809e600f0b91da36481179632886262680a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Intensive Therapy")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-86700")[#strong[#text("Intensive Therapy")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2011")])]

#text("In the case where the sail is a pure lifting body for which the force on the boat has direction perpendicular to the apparent wind and proportional magnitude, there will be a constant forward resulting force on the boat, because the water speed component of the apparent wind speed is projected to zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-108501")[#strong[#text("Sail of the century | Degree of Freedom")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2011")]

#text("[…] vector addition it’s possible to attain higher speeds than the wind itself. (There’s a detailed discussion on Terence Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3ca0f5fbffd1ef4c9291190b29fe44121a69010d9aeefb2a081098d9750d00f-258a14d3e00d996fbdc9f563c9d53051808c8d074346d14f13fa742992d229ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sailing")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-142145")[#strong[#text("Sailing")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2012")])]

#text("Interesting view on how the wind works during Sailing, gonna pass this one through for the newbies!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b12ea6ddf3808bcfdc0f494dfd176567e096f3325485054518e98268e4915839-a9f325d5b154b9ec4c6887c108276349bb4903b6d6ee3e92f5c1680771c40627.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave L")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-261459")[#strong[#text("Dave L")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("Goofy “scholars”. I stumbled upon this fantasy and it is interesting how absolutely far off it is in reality. Many high speed sail power “vehicles” are possible when there is no need to go from A to B. Ice boats will always have an edge because of the low drag number.")

#text("2013 America’s Cup was not even close to this fantasy, Google cavitation. There is a very long way left to go to see a sailboat sail straight upwind. Jiggle your numbers around, then go out in the elements, if you can even make it back with any meaningful data, please post.")

#text("Thanks, Dave.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-291637")[#strong[#text("Quora")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2014")]

#strong[#text("How much should I care if I’m failing high school chemistry?")]

#text("You don’t have to like it. You can go on to be Joe sixpack. The most successful students I know we’re the ones who very early made a decision. Whilst teaching SQL and database one of my students came to me after and asked how to become a DBA. From th…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40881452d9361fe8aca7b8bf47139c0f8aa7f6d75e6e14becfc32923a9cb4cfa-ffed9a2b27c1f9385f4f79f1befcdfdb9db8a87b98cfcceccddc3288749f0d78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ron Doctors")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-443114")[#strong[#text("Ron Doctors")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2014")])]

#text("If you imagine a three spoked wheel where the axis is fixed in space to be in the ocean then at the end.of each spoke you place a sailboat then it will be possible for the wheel to be constantly rotated regardless of wind direction. EACH BOAT WOULD CONSTANTLY NEED TO CHANGE THE SAIL AND RUDDER POSITIONS.")#linebreak()#text(" There is thus no time when all three boats cannot “sail” around a circular path. It would then be possible extract work from this wheel. This idea would the start of a VAWG.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/282bbac6a8edea6466147cf3e301097b2228c38d62b167141ab92bd9cabba15c-36aa4fc98642cd290214f3b3d22701c4daa382f30aec959bd3820edde2cdc4ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ancient mariner")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-450851")[#strong[#text("Ancient mariner")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2015")])]

#text("Extraordinary! Do any of you actually put to sea?")#linebreak()#text(" Ancient Mariner")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40881452d9361fe8aca7b8bf47139c0f8aa7f6d75e6e14becfc32923a9cb4cfa-ffed9a2b27c1f9385f4f79f1befcdfdb9db8a87b98cfcceccddc3288749f0d78.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ron Doctors")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-450852")[#strong[#text("Ron Doctors")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2015")])]

#text("Actually yes. I have sailed 14 ft dinghy s and 12 meter yachts. I was not proposing anything other than a stationary vertical windmill using what i know from sailing. AFAIK there are no vawt’s that use a jib, foresail ,to enhance the leading edge effects.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-450860")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2015")])]

#text("Can this be generalized to (3D) “solar sailing” (using the “solar wind”)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-451108")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2015")])]

#text("Eytan, did you see Jonathan Vos Post’s comment above?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-451114")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2015")])]

#text("Thanks for the information! (I missed his very detailed comment.)")#linebreak()#text(" Perhaps I may add that since the “solar wind” is not a usual fluid, the sailing method should be adapted to its particular properties (e.g. radial direction from the Sun, flux density inversly proportional to the distance from the Sun, lift & drag equations, etc.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45b9585ae480b61c5077b52366b0af36d10e08fb64ebc09e572f687b7c6e4d87-21b8412d62058fb4a056616f19410cf02990ddad547c675ea0e8b29fd302c6e1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dynamics | 3d art and animation")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-459229")[#strong[#text("Dynamics | 3d art and animation")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2015")])]

#text("[…] Sailing into the wind or faster than the wind: ")#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/")[#text("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-462654")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")])]

#text("It seems to me that there are two important errors in this explanation: 1) that it is possible to eliminate drag, and 2) that lift is always perpendicular to the direction of the movement. Regarding the first point, I must highlight that drag comes from various factors (i.e. turbulence drag, surface drag, etc) but is ultimately linked to the viscosity of the fluid. If you remove viscosity, as in a Bose-Einstein condensate, then drag disappears but so does lift! Hence: no zero-drag foil ever possible. Regarding the second point, to have any lift generated, a foil must have an angle-of-attack, that is the chord of the foil must diverge by some angle from the direction of the motion of the fluid.")#linebreak()#text(" Therefore, as one goes closer to the wind, the angle of attack of the airfoil gets progressively smaller, while drag never goes to zero. As the lift is reduced, so does the speed of the vessel relative to the water. Reduced speed will increase the angle of attack needed by the hydrofoil to counterbalance the side-force exerted by the airfoil, hence will increase the leeway.")#linebreak()#text(" It is clear that even theoretically it is not possible to travel directly against the wind, and that the top performance of a vessel is ultimately dependent on the lift-to-drag ratio of its foils.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-607815")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2020")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2020/12/04/sailing-into-the-wind-or-faster-than-the-wind/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ceba0d69f24964d05016c71c60997eb0f8f5d4026c2125e158ec79e7c2bc43d8-90ea8956636b3e6272ba5975b6df96217988116b26943fdac7d29b80ae7ee17b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jim Blasiak")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-633388")[#strong[#text("Jim Blasiak")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2021")])]

#text("Hurricane Ida is now aiming for the US Gulf coast. I know that the kinetic energy increases with the square of velocity and therefore that 100 mph winds pack 4 times the kinetic energy of 50 mph winds. That’s one reason hurricanes can be so dangerous. But is there any evidence that some objects can be accelerated in the wind beyond the wind speed (as with the sailboat)? Suppose my neighbor has a lawn chair that is not tied down. Can that chair get picked up by a 100 mph wind and hit my house at 100+mph? Or is this effect limited to sailboats. Or is the effect so small or random not to make a real difference?")

#text("If certain objects in a windstorm can accelerate beyond the wind speed I assume that effect would hold true at any wind speed. Is the increase in kinetic energy proportional to the increase in speed or is it non-linear?")

#text("We keep hearing that with climate change there will be more frequent and more powerful hurricanes. I guess my basic question is how that increase in storm energy gets translated into effects on the ground?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac6f39d6c08cecd79f223cf3342f4b2e6193657d286c4bce56403755f120effd-21736ab9949c5921ec0afd6b58d3268776b137114be6b6b81c4203c38bf7446f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Ruina")]], [#link("https://terrytao.wordpress.com/2009/03/23/sailing-into-the-wind-or-faster-than-the-wind/#comment-633395")[#strong[#text("Andy Ruina")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2021")])]

#text("A bunch of responses to the constellation of thoughts above.")

#text("As you say, Jim, the kinetic energy of a bit of air goes up with the square of the wind speed. But the amount of air that gets deflected by a given object, per unit time, is also proportional to the wind speed. So the power of the wind, per unit area, goes up with the cube of the wind speed. Twice the wind speed is 8X the power (not just 4X).")

#text("Can a 100 mph wind cause an object to go 110 mph. The technical answer is yes and no, depending. And the practical answer is no.")

#text("If a passive rigid object that is drag like and _in_ the wind, all it will do is accelerate up to the wind speed and no more. So that’s a no, the object will only get up to 100 mph and no more. The sailing downwind stuff depends on there being contact with the wind _and_ another media, like still ground or still water. But, an object that starts at rest on the ground and then gets accelerated by the wind could, in effect, bounce off of the wind and end up at twice the wind speed. If you release from rest, relative to the wind, a model glider pointing into a 20 mph wind, then you could steer it to down wind and it would still be going almost 20 mph, relative to the wind, and thus 40 mph relative to the ground. So, that is possible. And a more elaborate device could repeatedly bounce off of the wind and the ground and go arbitrarily fast.")

#text("However, I do not think that any one of a thousand random household objects would naturally take advantage of the possibilities described above. That is, practically speaking, I don’t think any lawn chairs, or even any model airplanes that are lying around (but not optimally controlled) go faster than the wind the drags them.")

#text("Short summary: the force of the wind goes up with the square of the speed. The power of the wind, relevant for some kinds of damage, goes up with the cube of the wind speed. Objects picked up by the wind could theoretically be brought up to any speed, even much faster than the wind, but the chances that random objects would/will do that is essentially zero.")

#text("So I think. My 2 cents.")
]
]
