// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/
// Converted to Typst by tao2typ: "2026-10-14T07:05:28.650745+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Marker lecture III: “Small gaps between primes”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Marker lecture III: “Small gaps between primes”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/")[#text("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the third ")#link("http://www.math.psu.edu/seminars/marker2008.php")[#text("Marker lecture")]#text(", I would like to discuss the recent progress, particularly by Goldston, Pintz, and Yıldırım, on finding small ")#link("http://en.wikipedia.org/wiki/Prime_gap")[#text("gaps")]#text(" ")#mi("p_{n+1}-p_n")#text(" between consecutive primes. (See also the surveys ")#link("http://arxiv.org/abs/math/0512436")[#text("by Goldston-Pintz-Yıldırım")]#text(", ")#link("http://arxiv.org/abs/0710.0823")[#text("by Green")]#text(", and ")#link("http://arxiv.org/abs/math/0605696")[#text("by Soundararajan")]#text(" on the subject; the material here is based to some extent on these prior surveys.)")

#metadata(none) <tao-706a8dac36ae733e9e19>#text("The ")#link("http://en.wikipedia.org/wiki/Twin_prime_conjecture")[#text("twin prime conjecture")]#text(" can be rephrased as the assertion that ")#mi("p_{n+1}-p_n")#text(" attains the value of 2 infinitely often, where ")#mi("p_1=2, p_2=3, p_3=5, \\ldots")#text(" are the primes. As discussed in previous lectures, this conjecture remains out of reach at present, at least with the techniques centred around counting solutions to linear equations in primes. However, there is another direction to pursue towards the twin prime conjecture which has shown significant progress recently (though, again, there appears to be a significant difficulty in pushing it all the way to the full conjecture). This is to try to show that ")#mi("p_{n+1}-p_n")#text(" is unexpectedly small for many n. Let us make this a bit more quantitative by posing the following question:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Question")]#text(". Let N be a large number. What is the smallest value of ")#mi("p_{n+1}-p_n")#text(", where ")#mi("p_n")#text(" is a prime between N and 2N?")
]

#text("The twin prime conjecture (or more precisely, the quantitative form of this conjecture coming from the prime tuples conjecture) would assert that the answer to this question is 2 for all sufficiently large N.")

#text("There are various ways to get upper bounds on this question. For instance, from ")#link("http://en.wikipedia.org/wiki/Bertrand%27s_postulate")[#text("Bertrand’s postulate")]#text(" (which can be ")#link("http://en.wikipedia.org/wiki/Proof_of_Bertrand%27s_postulate")[#text("proven by elementary means")]#text(") we know that ")#mi("p_{n+1}-p_n = O(N)")#text(" for all ")#mi("N \\leq p_n \\leq 2N")#text(". The ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("prime number theorem")]#text(" asserts that ")#mi("p_n = (1+o(1)) n \\log n")#text(", which gives ")#mi("p_{n+1}-p_n = o(N)")#text("; using various non-trivial facts known about the zeroes of the zeta function, one can improve this to ")#mi("O(N^c)")#text(" for various c (the best value of c known unconditionally is ")#mi("0.525")#text(", a result of ")#link("http://www.ams.org/mathscinet-getitem?mr=1851081")[#text("Baker, Harman, and Pintz")]#text("). The ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" gives a significantly more precise asymptotic formula for ")#mi("p_n")#text(", which ultimately leads to the bound ")#mi("p_{n+1}-p_n = O(\\sqrt{N} \\log N)")#text(". These bounds hold for all n in the given range, and so in fact bound the ")#emph[#text("largest")]#text(" value of ")#mi("p_{n+1}-p_n")#text(", not just the smallest. As far as I know, the ")#mi("O(\\sqrt{N} \\log N)")#text(" bound for the largest prime gap has not been improved even after one assumes the Riemann hypothesis, though this gap is generally expected to be much smaller than this. (In particular, the old conjecture that there always exists at least one prime between two consecutive square numbers remains open, even assuming RH. ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér conjectured")]#text(" a bound of ")#mi("(1+o(1)) \\log^2 N")#text(", though it is possible that the constant 1 here may need to be revised upwards to ")#mi("2e^\\gamma \\approx 1.1229")#text(" where ")#mi("\\gamma")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler-Mascheroni_constant")[#text("Euler-Mascheroni constant")]#text(", see this ")#link("http://www.ams.org/mathscinet-getitem?mr=1349149")[#text("paper of Granville")]#text(" for details.) In the converse direction, the best result is due ")#link("http://www.ams.org/mathscinet-getitem?mr=160767")[#text("to Rankin")]#text(", who showed the somewhat unusual bound")

#align(center)[#tao-fit-display[#mitex("p_{n+1}-p_n \\geq c \\log N \\frac{(\\log \\log N) (\\log \\log \\log \\log N)}{(\\log \\log \\log N)^2}")]]

#text("for some n and some absolute constant ")#mi("c>0")#text(" (in fact one can take c arbitrarily close to ")#mi("2e^\\gamma")#text("). Remarkably, this type of right-hand side appears to be a genuine limit of what current methods can achieve (Paul Erdős in fact offered $10,000 to anyone who could improve the rate of growth of the right-hand side in N).")

#text("But for the smallest value of ")#mi("p_{n+1}-p_n")#text(", much more is known. The prime number theorem already tells us that there are ")#mi("(1+o(1)) N/\\log N")#text(" primes between N and 2N, so from the ")#link("http://en.wikipedia.org/wiki/Pigeonhole_principle")[#text("pigeonhole principle")]#text(" we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("p_{n+1}-p_n \\leq (1+o(1)) \\log N")]]

#text("for some n.")

#text("This bound should not be sharp, since this would imply that the primes are almost equally spaced by ")#mi("\\log N")#text(", which is suspiciously regular behaviour for a sequence as irregular as the primes. To get some intuition as to what to expect, we turn to random models of the primes. In particular, we begin with ")#link("http://en.wikipedia.org/wiki/Cram%C3%A9r%27s_conjecture")[#text("Cramér’s random model")]#text(" for the primes, which asserts that the primes between N and 2N behave as if each integer in this range had an independent chance of about ")#mi("1/\\log N")#text(" of being prime. Standard probability theory then shows that the primes are distributed like a ")#link("http://en.wikipedia.org/wiki/Poisson_process")[#text("Poisson process")]#text(" of intensity ")#mi("1/\\log N")#text(". In particular, if one takes an random interval ")#mi("I_\\lambda")#text(" in ")#mi("{}[N,2N]")#text(" of length ")#mi("\\lambda \\log N")#text(" for some ")#mi("\\lambda > 0")#text(", the number of primes ")#tao-math("\\left|I_\\lambda \\cap {\\mathcal P}\\right|", block: false)#text(" that ")#mi("I_\\lambda")#text(" captures is expected to behave like a Poisson random variable of mean ")#mi("\\lambda")#text("; in other words, we expect")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\Bbb P}( \\left|I_\\lambda \\cap {\\mathcal P}\\right| = k ) \\approx \\frac{e^{-\\lambda} \\lambda^k}{k!}", block: true)]]

#text("for ")#mi("k=0,1,2,\\ldots")#text(". (In contrast, the prime number theorem only gives the much weaker statement ")#tao-math("{\\Bbb E} \\left|I_\\lambda \\cap {\\mathcal P}\\right| = \\lambda + o(1)", block: false)#text(".)")

#text("Now, as discussed in previous lectures, Cramér’s random model is not a completely accurate model for the primes, because it does not reflect the fact that primes very strongly favour the odd numbers, the numbers coprime to 3, and so forth. However, it turns out that even after one corrects for these local irregularities, the predicted Poisson random variable behaviour (2) does not change significantly for any fixed ")#mi("\\lambda")#text(" (e.g. a Poisson process of intensity ")#mi("2/\\log N")#text(" on the odd numbers looks much the same as a Poisson process of intensity ")#mi("1/\\log N")#text(" on the natural numbers, when viewed at scales comparable to ")#mi("\\log N")#text("). This computation was worked out fully ")#link("http://www.ams.org/mathscinet-getitem?mr=409385")[#text("by Gallagher")]#text(" as a rigorous consequence of the Hardy-Littlewood prime tuples conjecture. (On the other hand, these corrections to the Cramér model ")#emph[#text("do")]#text(" disrupt (2) for very large values of ")#mi("\\lambda")#text("; see this ")#link("http://www.dms.umontreal.ca/~andrew/PDFNATO/sound.pdf")[#text("paper of Soundararajan")]#text(" for more discussion.)")

#text("Applying (2) for small values of ")#mi("\\lambda")#text(" (but still independent of N), we see that intervals of length ")#mi("\\lambda \\log N")#text(" are still expected to contain two or more primes with non-zero probability, which in particular would imply that ")#mi("p_{n+1}-p_n \\leq \\lambda \\log N")#text(" for at least one value of n. So one path to creating small gaps between primes is to show that ")#tao-math("\\left|I_\\lambda \\cap {\\mathcal P}\\right|", block: false)#text(" can exceed 1 for as small a value of ")#mi("\\lambda")#text(" as one can manage.")

#text("One approach to this proceeds by controlling the ")#emph[#text("second moment")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("{\\Bbb E} \\left|I_\\lambda \\cap {\\mathcal P}\\right|^2;", block: true)]]

#text("the heuristic (2) predicts that this second moment should be ")#mi("\\lambda^2 + \\lambda + o(1)")#text(" (reflecting the fact that the Poisson distribution has both mean and variance equal to ")#mi("\\lambda")#text("). On the other hand, the prime number theorem gives the first moment estimate ")#tao-math("{\\Bbb E} \\left|I_\\lambda \\cap {\\mathcal P}\\right| = \\lambda + o(1)", block: false)#text(". Also, if ")#tao-math("\\left|I_\\lambda \\cap {\\mathcal P}\\right|", block: false)#text(" never exceeds 1, then the first and second moments are equal. Thus if one could get the right bound for the second moment, one would be able to show that ")#mi("p_{n+1}-p_n \\leq \\lambda \\log N")#text(" is possible for arbitrarily small ")#mi("\\lambda")#text(".")

#text("Second moments such as (3) are very amenable to tools from Fourier analysis or complex analysis; applying such tools, we soon see that (3) can be re-expressed easily in terms of zeroes to the Riemann zeta function, and one can use various standard facts (or hypotheses) about these zeroes to gain enough control on (3) to obtain non-trivial improvements to (1). This approach was pursued by many mathematicians including Hardy-Littlewood, Rankin, ")#link("http://www.ams.org/mathscinet-getitem?mr=1759")[#text("Erdős")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=199165")[#text("Bombieri-Davenport")]#text("; leading to non-trivial unconditional results for any ")#mi("\\lambda \\geq 1/2")#text(", but it seems difficult to push the method much beyond this. It was later shown ")#link("http://www.ams.org/mathscinet-getitem?mr=1018376")[#text("by Goldston and Montgomery")]#text(" that the correct asymptotic for (3) is essentially equivalent to the Riemann hypothesis combined with a certain statement on pair correlations between zeroes, and thus well out of reach of current technology.")

#text("Another method, introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=783576")[#text("by Maier")]#text(", is based on finding some (rare) intervals ")#mi("I_\\lambda")#text(" of numbers of length ")#mi("\\lambda \\log N")#text(" for some moderately large ")#mi("\\lambda")#text(" which contain significantly more primes than average value of ")#mi("\\lambda")#text("; if for instance one can find such an interval with over ")#mi("(k+1) \\lambda")#text(" primes in it, then from the pigeonhole principle one must be able to find a prime gap of size at most ")#mi("\\frac{1}{k} \\log N")#text(". The ability to do this stems from the remarkable and unintuitive fact that the regularly distributed nature of primes in long arithmetic progressions, together with the tendency of primes to avoid certain residue classes, forces the primes to be ")#emph[#text("irregularly")]#text(" distributed in ")#emph[#text("short")]#text(" intervals. This phenomenon (which has now been systematically studied as an “uncertainty principle” for equidistribution ")#link("http://www.ams.org/mathscinet-getitem?mr=2299742")[#text("by Granville and Soundararajan")]#text("), is related to the following curious failure of naive probabilistic heuristics to correctly predict the prime number theorem. Indeed, consider the question of asking how likely it is that a randomly chosen number n between N and 2N is to be prime. Well, n will have about a ")#mi("1-\\frac{1}{2}")#text(" chance of being coprime to 2, a ")#mi("1 - \\frac{1}{3}")#text(" chance of being coprime to 3, and so forth; the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese remainder theorem")]#text(" also suggests that these events behave independently. Thus one might expect that the probability would be something like")

#align(center)[#mi("\\prod_{p < N} (1 - \\frac{1}{p})")#text(".")]

#text("We then invoke ")#link("http://en.wikipedia.org/wiki/Mertens%27_theorems")[#text("Mertens’ theorem")]#text(", which provides the asymptotic")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\prod_{p < N} (1 - \\frac{1}{p}) = (e^{-\\gamma} + o(1)) \\frac{1}{\\log N}.")]]

#text("But this is off by a factor of ")#mi("e^{\\gamma}")#text(" from what the prime number theorem says the true probability of being prime is, which is ")#mi("(1+o(1)) \\frac{1}{\\log N}")#text(". This discrepancy reflects the difficulty in cutting off the product in primes (4) at the right place (for instance, the ")#link("http://en.wikipedia.org/wiki/Sieve_of_Eratosthenes")[#text("sieve of Eratosthenes")]#text(" suggests that one might want to cut off at ")#mi("\\sqrt{N}")#text(" instead) and I might discuss this topic further in a future blog post. At any rate, this ")#mi("e^\\gamma")#text(" discrepancy can be exploited to find intervals with an above-average number of primes by a “first moment” argument (known as the ")#emph[#text("Maier matrix method")]#text(") that we sketch as follows. Let w be a moderately large number, and let W be the product of all the primes less than w. If we pick a random number n between N and 2N, then as mentioned before, the prime number theorem says that this number will be prime with probability about ")#mi("\\frac{1}{\\log N}")#text(". But if in addition we know that the number is coprime to W, then by the prime number theorem in arithmetic progressions this information boosts the probability of being prime to about ")#mi("\\prod_{p < w} (1-\\frac{1}{p})^{-1} \\frac{1}{\\log N}")#text(", which by (4) is about ")#mi("e^\\gamma \\frac{\\log w}{\\log N}")#text(".")

#text("Now we restrict attention to numbers n which are equal to a mod W for some ")#mi("1 \\leq a \\leq w")#text(". By the prime number theorem, about ")#mi("\\frac{w}{\\log w}")#text(" of the a are prime and thus coprime to W. Combining this with the previous discussion, we see that the total probability that such a number n is prime is about ")#mi("\\frac{1}{\\log w} \\times e^\\gamma \\frac{\\log w}{\\log N} = e^\\gamma \\frac{1}{\\log N}")#text(".")

#text("On the other hand, the set of numbers n which are equal to a mod W for some ")#mi("1 \\leq a \\leq w")#text(" is given by a sequence of intervals of length w. By the pigeonhole principle, we must therefore have an interval of length w on which the density of primes is at least ")#mi("e^\\gamma \\frac{1}{\\log N}")#text(" – which is greater than the expected density by a factor of ")#mi("e^\\gamma")#text(".")

#text("One can make the above arguments rigorous for certain ranges of interval length, and by combining this with the pigeonhole principle one can eventually improve (1) by a factor of ")#mi("e^{\\gamma}")#text(":")

#align(center)[#mi("p_{n+1}-p_n \\leq (e^{-\\gamma}+o(1)) \\log N")#text(".")]

#text("This is better than the bound of ")#mi("(\\frac{1}{2}+o(1)) \\log N")#text(" obtained by the second moment method, but on the other hand the latter method establishes that a positive proportion of primes have small gaps; Maier’s method, by its very nature, is restricted to a very sparse set of primes (note that w is much smaller than W).")

#text("In a series of papers, Goldston and Yıldırım improved the numerical constants in these results by a variety of methods including those mentioned above, as well as replacing some of the reliance on information on zeroes of the zeta function with tools from sieve theory instead. To oversimplify substantially, the latter idea is to try to control the set of primes ")#mi("{\\mathcal P}")#text(" in terms of a larger set ")#mi("{\\mathcal AP}")#text(" of ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost primes")]#text(" – numbers with few prime factors. (Strictly speaking, one does not actually work with a set of almost primes, but rather with a weight function or sieve which is large on almost primes and small for non-almost primes, but let us ignore this important technical detail to simplify the exposition.) For instance, to control the second moment ")#tao-math("{\\Bbb E} \\left|I_\\lambda \\cap {\\mathcal P}\\right|^2", block: false)#text(", one can take advantage of the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb E} \\left|I_\\lambda \\cap {\\mathcal P}\\right|^2 \\geq \\frac{{\\Bbb E} \\left|I_\\lambda \\cap {\\mathcal P}\\right| \\left|I_\\lambda \\cap {\\mathcal AP}\\right|}{\\left|I_\\lambda \\cap {\\mathcal AP}\\right|^2}.", block: true)]]

#text("The denominator on the right-hand side involves only almost primes and can be computed easily by sieve theory methods. The numerator involves primes, but only one prime at a time; note that this quantity is roughly counting the set of pairs ")#mi("p, q")#text(" where p is prime, q is almost prime, and p and q differ by at most ")#mi("\\lambda \\log N")#text(". This is in contrast to the left-hand side, which is counting pairs p, q that are both prime and differ by at most ")#mi("\\lambda \\log N")#text(". We do not know how to use sieve theory to count the latter type of pattern (involving more than one prime); but sieve theory is perfectly capable of counting the former type of pattern, so long as we understand the distribution of primes in relatively sparse arithmetic progressions. The standard tool for this is the ")#link("http://en.wikipedia.org/wiki/Bombieri%E2%80%93Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(", which roughly speaking asserts that the primes from N to 2N are well distributed in “most” residue classes q, as long as q stays significantly smaller than ")#mi("\\sqrt{N}")#text("; it can be viewed as an averaged version of the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_Hypothesis")[#text("generalised Riemann hypothesis")]#text(" that can be proven unconditionally. (The key point here is that while it is possible for the primes to be irregular with respect to a few such small moduli, the “orthogonality” of these moduli with respect to each other makes it impossible for the primes to be simultaneously irregular with respect to many of these moduli at once. I may comment more on this topic in a future post.) Using such tools, various improvements to (1) were established. Finally, in 2005, in a series ")#link("http://arxiv.org/abs/math/0508185")[#text("of")]#text(" ")#link("http://arxiv.org/abs/0710.2728")[#text("papers")]#text(" by Goldston, Pintz, and Yıldırım, it was shown that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("p_{n+1} - p_n \\leq \\lambda \\log N")]]

#text("held for some n and any ")#mi("\\lambda > 0")#text(" (provided N was large enough depending on ")#mi("\\lambda")#text("), or equivalently that ")#mi("p_{n+1}-p_n = o(\\log N)")#text("; this was later improved ")#link("http://arxiv.org/abs/0710.2728")[#text("further")]#text(", to ")#mi("p_{n+1} - p_n = O( \\sqrt{\\log N} (\\log \\log N)^2 )")#text(". Assuming a strong version of the Bombieri-Vinogradov theorem (in which q is allowed now to get close to N rather than to ")#mi("\\sqrt{N}")#text("), known as the ")#link("http://en.wikipedia.org/wiki/Elliott%E2%80%93Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text("), this was improved further to the striking result")

#align(center)[#tao-fit-display[#mitex("p_{n+1} - p_n \\leq 16,")]]

#text("thus there are infinitely many pairs of primes which differ by at most 16. This is a remarkable “near miss” to the twin prime conjecture, though it seems clear that substantial new ideas would be needed to reduce 16 all the way to 2.")

#text("Let’s now discuss some of the ideas involved. As with the previous arguments, the key idea is to find groups of integers which tend to contain more primes than average. Suppose for instance one could find a certain random distribution of integers n where n, n+2, and n+6 each had a probability strictly greater than 1/3 of being prime. (We choose these separations for our discussion because it is not possible to make three large prime numbers bunch up any closer than this; for instance, n, n+2, n+4 cannot be all be prime for ")#mi("n>3")#text(", since at least one of these numbers must be divisible by 3.) By linearity of expectation, we thus see that the expected number of primes in the set ")#mi("\\{n,n+2,n+6\\}")#text(" exceeds 1; thus, with positive probability, there will be at least two primes in this set, which then necessarily differ by at most 6.")

#text("Now, of course, the prime number theorem tells us that for n chosen uniformly at random from N to 2N, the probability that n, n+2, or n+6 are prime is only about ")#mi("1/\\log N")#text(". So for this type of strategy to work, one would have to pick a highly non-uniform distribution for n, in which n, n+2, and n+6 are already close to being prime already. The extreme choice would be to pick n uniformly among all choices for which n, n+2, and n+6 are simultaneously prime, but we of course don’t even know that any such primes exist (this is strictly harder than the twin prime conjecture!) But what we can do instead is pick n uniformly among all choices such that n, n+2, and n+6 are ")#emph[#text("almost prime")]#text(" (where we shall be vague for now about what “almost prime” means). Thanks to sieve theory, we ")#emph[#text("can")]#text(" assert the existence of many numbers n of this form, and get a good count as to how many there are. Also, since the primes have positive density inside the almost primes, it is quite reasonable that the conditional probabilities")

#align(center)[#mi("{\\Bbb P}( n \\text{ prime } | n, n+2, n+6 \\text{ almost prime} )")#text(",")]

#align(center)[#mi("{\\Bbb P}( n+2 \\text{ prime } | n, n+2, n+6 \\text{ almost prime} )")#text(",")]

#align(center)[#mi("{\\Bbb P}( n+6 \\text{ prime } | n, n+2, n+6 \\text{ almost prime} )")#text(",")]

#text("are large. Indeed, using sieve theory techniques (and the Bombieri-Vinogradov theorem), we can bound each of these probabilities from below by a positive constant (plus a o(1) error). Unfortunately, even if we optimise the sieve that produces the almost primes, this constant is too small (typically one gets numbers of the order of 1/20 or so, rather than 1/3). Assuming the Elliot-Halberstam conjecture (which allows us to raise the level of sieving substantially) yields a significant improvement, but one that still falls short of the desired goal. One can of course also add more numbers to the mix than just ")#mi("n, n+2, n+6")#text(", e.g. looking at those n for which ")#mi("n+h_1,\\ldots,n+h_k")#text(" are simultaneously almost prime, for some suitably chosen ")#mi("h_1,\\ldots,h_k")#text("; on the one hand this lowers the threshold of probability (currently at 1/3) that one needs to obtain, but unfortunately this is more than canceled out by the multidimensional sieving one needs to do when restricting all of these numbers to be almost prime.")

#text("To get around this, a new idea was introduced: instead of requiring numbers such as n, n+2, and n+6 to separately be almost prime, ask instead for the ")#emph[#text("product")]#text(" n(n+2)(n+6) to be almost prime (for a somewhat more relaxed notion of “almost prime”). This turns out to be more efficient, as it lowers the number of summations involved in the sieve. One has to carefully select how one defines almost prime here (it is roughly like asking for the product ")#mi("(n+h_1) \\ldots (n+h_k)")#text(" to have at most ")#mi("2k+o(k)")#text(" prime factors, with the o(k) factor being remarkably crucial to the delicate analysis); but to cut a long story short, one can establish probability bounds of the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("{\\Bbb P}( n+h_j \\text{ prime } | (n+h_1) \\ldots (n+h_k) \\text{ almost prime} ) \\geq \\frac{c-o(1)}{k}")]]

#text("for all ")#mi("1 \\leq j \\leq k")#text(" and some absolute constant ")#mi("c > 0")#text(". [More formally, one needs to compute sums such as ")#mi("\\sum_{n=1}^N \\Lambda(n+h_j) \\Lambda_R( (n+h_1) \\ldots (n+h_k) )^2")#text(", where ")#mi("\\Lambda")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(" and ")#mi("\\Lambda_R")#text(" is a ")#link("http://en.wikipedia.org/wiki/Selberg_sieve")[#text("Selberg sieve")]#text("-type approximation to that function.]")

#text("As soon as one assumes any non-trivial portion of the Elliott-Halberstam conjecture, the quantity c in the above inequality can be made to exceed 1 (for k large enough), leading to the conclusion that there exist infinitely many bounded prime gaps, ")#mi("p_{n+1}-p_n = O(1)")#text("; pushing the machinery to their limit (taking ")#mi("\\{h_1,\\ldots,h_k\\} = \\{7,11,13,17,19,23\\}")#text(" to be the first six primes larger than 6), one obtains the bound of 16. But without this conjecture, and just using Bombieri-Vinogradov, then after optimising everything in sight, one can get c arbitrarily close to 1, but not quite exceeding 1. To compensate for this, the authors also started looking at the nearby numbers n+h where h was not equal to ")#mi("h_1,\\ldots,h_k")#text(". Here, of course, there is no particularly good reason for n+h to be prime, since it is not involved as a factor to the almost prime quantity ")#mi("(n+h_1)\\ldots(n+h_k)")#text("; but one can show that, for generic values of h, one has")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( n+h \\text{ prime } | (n+h_1) \\ldots (n+h_k) \\text{ almost prime} ) \\geq \\frac{c^{\\prime}+o(1)}{\\log N}")]]

#text("for some ")#mi("c^{\\prime}>0")#text(" (there is an additional singular series factor involving the prime factors of ")#mi("h-h_j")#text(" which can be easily dealt with, that I am suppressing here.) Thus, for any ")#mi("\\lambda > 0")#text(", we expect (from linearity of expectation) that for ")#mi("(n+h_1)\\ldots(n+h_k)")#text(" almost prime, the expected number of ")#mi("h = O(\\lambda \\log N)")#text(" (including the k values ")#mi("h_1,\\ldots,h_k")#text(") for which n+h is prime is at least")

#align(center)[#mi("k( \\frac{c}{k} +o(1)) + \\lambda \\log N \\frac{c^{\\prime}+o(1)}{\\log N} = c + c^{\\prime} \\lambda + o(1)")#text(".")]

#text("Since we can make c arbitrarily close to 1, the extra term ")#mi("c^{\\prime} \\lambda")#text(" can push this expectation to exceed 1 for any choice of ")#mi("\\lambda")#text(", and this leads to the desired bound (5) for any ")#mi("\\lambda > 0")#text(". (The subsequent improvement to (5) proceeds by enlarging k substantially, and by a preliminary sieving of the small primes, but we will not discuss these technical details here.)")

#text("It is tempting to continue to optimise these methods to improve the various constants, and I would imagine that the bound of 16, in particular, can be lowered somewhat (still assuming the Elliott-Halberstam conjecture). But there seems to be a significant obstacle to pushing things all the way to 2. Indeed, the ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("parity problem")]#text(" tells us that for any reasonable definition of “almost prime” which is amenable to sieve theory, the primes themselves can have density at most 1/2 in these almost primes. Since we need the density to exceed 1/k in order for the above argument to work, it is necessary to play with at least three numbers (e.g. n, n+2, n+6), which forces the bound on the prime gaps to be at least 6. (Indeed, this bound has been obtained for ")#link("http://en.wikipedia.org/wiki/Semiprime")[#text("semiprimes")]#text(" – which are subject to the same parity problem restriction as primes, but are slightly better distributed – by ")#link("http://arxiv.org/abs/math/0609615")[#text("Goldston, Graham, Pintz, and Yıldırım")]#text(".) But it may be that a combination of these techniques with some substantially new ideas may push things even further.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-33581")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2008")])]

#text("That’s a very nice discussion!")

#text("Maybe I can also direct the interested reader to ")#link("http://www.math.ethz.ch/~kowalski/goldston-pintz-yildirim.pdf")[#text("my own survey")]#text(" (a Bourbaki seminar report), in particular to the last section which contains more discussion of the obstacles and possibilities in trying to work beyond the Bombieri-Vinogradov theorem — there are results of Fouvry, Bombieri, Friedlander, Iwaniec that go beyond the ")#mi("\\sqrt{N}")#text(" bound for moduli of primes in arithmetic progressions, although they are not of the right type of results to get bounded gaps between primes.")

#text("Also it may be of interest to mention that one can generalize fairly easily Gallagher’s conditional argument leading to a Poisson distribution to show that — under the same assumption — the number of (say) twin primes between ")#mi("N")#text(" and ")#mi("N+t(log N)^2")#text(" should also asymptotically be Poisson distributed (with parameter ")#mi("ct")#text(" where ")#mi("c")#text(" is the twin-prime constant).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-33603")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2008")])]

#text("Dear Emmanuel,")

#text("Thanks for the reference and the comments!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c29e84c0c4597e0c074f4339f7ff2487033be1e0762c8ac692f11533bd6c3ef-853569db70f48f661553e8a39bae130f5ae188cdf4a11319a8e2f3476ab44e07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mike")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-33987")[#strong[#text("mike")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2008")])]

#text("do you have any information on how the twin prime constant was derived?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b42c8356f40c026a298bf5435324a099ce55af459de3714812a510faa4c0941a-0cb85f426b56e361453c720fe33c67973d8b376a602da290637121e3617a8fe9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peter acquaah")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-40765")[#strong[#text("peter acquaah")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2009")])]

#text("you are simply great!")#linebreak()#text(" In fact, I think you should check this idea.")

#link("http://www.geocities.com/SoHo/Exhibit/8033/pgtow/pgtow.html")[#text("http://www.geocities.com/SoHo/Exhibit/8033/pgtow/pgtow.html")]

#text("I was working on something like that and I agree with the author’s work.")#linebreak()#text(" Keep it up Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/053e15e1b46493ddb5d313834fad25f2a41808115024acbbc2ea48b9557ecfa9-19006dba89b053575b2042e5a7a847f2665f30205a61fef272dab60d27f88231.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EGME")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-106232")[#strong[#text("EGME")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2011")])]

#text("Dear Terry,")

#text("Consider the following: let t be a generator( of a twin prime pair) if 6t+1, 6t-1 are primes. Let f be a sequence, for example, the sequence {5p}, where p is a prime, and let g be the largest gap between generators contained in f up to f(n), where f(n) is a generator contained in f. I speculate the following. Between f(n) and f(n+2g)there is another element of f which is a generator. How might one appproach this problem probabilistically, for example, show that the probability of finding such a generator is greater than 0?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/053e15e1b46493ddb5d313834fad25f2a41808115024acbbc2ea48b9557ecfa9-19006dba89b053575b2042e5a7a847f2665f30205a61fef272dab60d27f88231.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of EGME")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-108351")[#strong[#text("EGME")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2011")])]

#text("More precisely,")

#text("Let f(i)={5*p(i)} be a sequence where p(i) is the i-th prime. Suppose that that there is a maximum gap, for i<=n, of g, meaning, that for any for any m<=n")#linebreak()#text(" { f(p(m+1)),…f(p(m+g+1)) } has as at least one twin prime generator, and for any some q20, there is a generator in {f(p(n)),…,f(p(n+2g))}. I have checked this up to n=700 meg. Moreover, between i=100 million and i=700 million, there is no increase in max gap size. max gap increases sligtly from i=700 meg to 800 meg, as expected from observing the behavior in the first 70 meg entries..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-111250")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2011")])]

#text("Prof Tao, in this article you wrote “This discrepancy reflects the difficulty in cutting off the product in primes (4) at the right place (for instance, the sieve of Eratosthenes suggests that one might want to cut off at instead) and I might discuss this topic further in a future blog post. ” Did you ever elaborate on this issue in a later article? I’m interested to explore this further.")

#text("Thanks,")

#text("Pete")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-119196")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2011")])]

#text("Professor Tao,")

#text("the link to Granville’s paper above, referred here:")

#text("“Cramér conjectured a bound of —, though it is possible that the constant 1 here may need to be revised upwards to — where is the Euler-Mascheroni constant, see this paper of Granville for details.)”")

#text("appears to be dead. Is it possible to re-identify the paper you’d linked? I’m very interested to explore this aspect in a bit more detail if possible.")

#text("Best for the holidays,")

#text("Pete")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c514ac24f83e4b5cff3f5a8f7e69c7739d466a090d3ebc0000c588118688049e-fe4a375bd51d7782ba3def1fd9da15f0083a08a89282e2849f5d6a48a1048243.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of petequinn")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-119197")[#strong[#text("petequinn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2011")])]

#text("Apologies, ignore the last. I see the paper citation at the referred link, thanks")

#text("Pete")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-230911")[#strong[#text("The Beauty of Bounded Gaps | sladisworld")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2013")]

#text("[…] concerning the remainders obtained after division by many different integers. From this (following a path laid out by Goldston, Pintz, and Yıldırım, the last people to make any progress on prime gaps) he can show that the prime numbers look random […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Sands")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-447682")[#strong[#text("George Sands")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2014")])]

#text("I am not a mathematician though I work at a high level in a closely related field. I am trying to be helpful in my comments here. I think I know enough to know, but if I am “trolled” or “facebooked” in any way, I will request that my comments be deleted. I believe math should be kind and collegial, only. Latex problems are a function of the format.")

#text("Let us consider the Twin Prime Conjecture, and suppose that it is false for purposes of this post.")

#text("This means that there is a prime number, ")#mi("p_N \\in \\mathbb P")#text(", such that the pair ")#mi("\\{p_{N-1}, p_N\\}")#text(" has the property that ")#mi("(p_N - p_{N-1}) = 2")#text(" but that there is no larger such pair of primes.")

#text("Call ")#mi("X_N")#text(" the infinite set of primes that excludes the first N primes. One can then consider the set ")#mi("M_{X(N)}")#text(", which is generated by sum, products, and differences of elements of ")#mi("X_N")#text(". If one adds the number 1 to the set ")#mi("M_{X(N)}")#text(" and then generates a ring, it turns out that the resultant ring is all the integers. This follows from the fact that if ")#mi("a, b")#text(" are relatively prime integers, then there are integers ")#mi("m, n")#text(" such that ")#mi("ma + nb = 1")#text(". The reader should check this. It is a well-known result we learned in kindergarten Number Theory, as a friend is fond of saying (a funny friend, meant humorously).")

#text("Since the ring is the integers, we know that 2 is the difference of two “generators” — elements ")#mi("c, d \\in M_{X(N)}")#text(" such that ")#mi("c - d = 2")#text(". The question on which this post focuses, and there are “deep” reasons for starting with this suggestion to others to look at the problem in this way, is what “shape” can c and d take, without generating a contradiction with our starting point: suppose that the Twin Prime Conjecture is false. Our hope is to generate contradictions.")

#text("1. We know that c and d cannot be prime since this would create a contradiction.")

#text("2. If c and d are minimal in the sense that we have no smaller pair, in the sense of ")#tao-math("S = \\left|c + d\\right|", block: false)#text(", S is minimal, can either c or d be a prime number?")

#text("I suggest that the assembled readers of the blog can prove relatively quickly that neither c or d can be prime.")

#text("3. If c and d are minimal in the sense that we have no smaller pair, in the sense of ")#tao-math("S = \\left|c + d\\right|", block: false)#text(", S is minimal, it is apparent that c and d must be coprime.")

#text("4. Furthermore, I think it is the case that if c is the product of several prime numbers (greater than ")#mi("p_N")#text(" of course) and so is d, and c and d are minimal in the sense defined above, then we know that the exponents of the prime numbers that factor c, and the exponents of the prime numbers that factor d, cannot ")#mi("\\textbf{all}")#text(" have a common divisor. For example, we cannot have ")#mi("c = p^2")#text(" and ")#mi("d = q^2")#text(".")

#text("Why? This is left to the reader to verify.")

#text("Of the steps laid out so far, step 2 is by far the hardest, but very attainable. To motivate ideas, take ")#mi("c = 127")#text(" and ")#mi("d = 5^3 = 125")#text(". This is a convenient example for seeing how to prove step 2. It is sufficently “rich” and sufficiently “simple.” That, I think, should be enough of a hint for many readers.")

#text("One readers post answers to all of these parts, I will post the next steps, along with associated “suggestions” or “hints.” The beginning mathematician will want to verify that the ring generated by ")#mi("M_{X(N)}")#text(" and 1 is in fact the integers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Sands")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-447683")[#strong[#text("George Sands")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2014")])]

#text("Regarding step 2, I meant to include this. Start with the case where one supposes ")#mi("c = p \\in \\mathbb P")#text(" and ")#mi("d = q^k, q \\in \\mathbb P")#text(". Exclude from consideration, at this juncture, d that factor into multiple primes (all greater than of course ")#mi("p_N")#text(" as we have defined ")#mi("p_N")#text(".")

#text("Hope that helps make step 2 a bit more reachable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60dec13f54f8d27f9f78e38ec9efeced152243d0e09c80053be4daa048326009-a2bd7bddf796799e53b0ae6e759beb1a9e629ef1c8051d95c94281a2ea88fc5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-447887")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2014")])]

#text("Question. Let N be a large number. What is the smallest value of p_{n+1}-p_n, where p_n is a prime between N and 2N?")

#text("To answer this question, the Riemann Hypothesis is not that helpful. In other words, one cannot do particularly well with assuming RH is true. Why? That’s the subject of a paper itself.")

#text("What is instead needed to do better is to understand the distribution function for the zeros of the ")#mi("\\zeta")#text(" function along the critical line, whether or not there are zeros elsewhere in the critical strip. Why? Well consider Riemann’s original formula for the function ")#mi("\\xi(t)")#text(" along the line ")#mi("1/2 + it")#text(" (the critical line — refer the reader to the original paper, which is translated into English in various papers — for that function). In the integrand is a function which Riemann calls ")#mi("\\psi(x)")#text(". ")#mi("\\psi(x) = sum_1^\\infty e^{-\\pi n^2 x}")#text(". Think about it for a while.")

#text("Maybe I’ve said too much, given the Clay Prize. However, I think people will have enough trouble seeing why they should focus attention on JUST the zeros on the critical line, Riemann’s formula for ")#mi("\\xi(t)")#text(", and why the function ")#mi("\\psi(x)")#text(" relates to the distribution of zeros along the line as well as to the prime numbers themselves. It shouldn’t be THAT hard, but sometimes it is not that easy to see either.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/19/marker-lecture-iii-small-gaps-between-primes/#comment-474165")[#strong[#text("A huge discovery about prime numbers – Emmanuel A. Otchere's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2016")]

#text("[…] concerning the remainders obtained after division by many different integers. From this (following a path laid out by Goldston, Pintz, and Yıldırım, the last people to make any progress on prime gaps) he can show that the prime numbers look random […]")
]
