// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/
// Converted to Typst by tao2typ: "2026-10-14T11:14:05.732380+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Lean companion to “Analysis I”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Lean companion to “Analysis I”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 31 May 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/")[#text("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Almost 20 years ago, I wrote a textbook in real analysis called “")#link("https://terrytao.wordpress.com/books/analysis-i/")[#text("Analysis I")]#text("“. It was intended to complement the many good available analysis textbooks out there by focusing more on foundational issues, such as the construction of the natural numbers, integers, rational numbers, and reals, as well as providing enough set theory and logic to allow students to develop proofs at high levels of rigor.")

#text("While some proof assistants such as Coq or Agda were well established when the book was written, formal verification was not on my radar at the time. However, now that I have had some experience with this subject, I realize that the content of this book is in fact very compatible with such proof assistants; in particular, the ‘naive type theory’ that I was implicitly using to do things like construct the standard number systems, dovetails well with the dependent type theory of Lean (which, among other things, has excellent support for quotient types).")

#text("I have therefore decided to launch a ")#link("https://github.com/teorth/analysis")[#text("Lean companion to “Analysis I”")]#text(", which is a “translation” of many of the definitions, theorems, and exercises of the text into Lean. In particular, this gives an alternate way to perform the exercises in the book, by instead filling in the corresponding “sorries” in the Lean code. (I do not however plan on hosting “official” solutions to the exercises in this companion; instead, feel free to create forks of the repository in which these sorries are filled in.)")

#text("Currently, the following sections of the text have been translated into Lean:")

#list(
[#link("https://teorth.github.io/analysis/docs/Analysis/Section_2_1.html")[#text("Section 2.1: The natural numbers")]],
[#link("https://teorth.github.io/analysis/docs/Analysis/Section_2_2.html")[#text("Section 2.2: Addition")]],
[#link("https://teorth.github.io/analysis/docs/Analysis/Section_2_3.html")[#text("Section 2.3: Multiplication")]],
[#link("https://teorth.github.io/analysis/docs/Analysis/Section_2_epilogue.html")[#text("Chapter 2 epilogue: Isomorphism with the Mathlib natural numbers")]],
[#link("https://teorth.github.io/analysis/docs/Analysis/Section_3_1.html")[#text("Section 3.1: Basic set theory")]],
[#link("https://teorth.github.io/analysis/docs/Analysis/Section_4_1.html")[#text("Section 4.1: The integers")]]
)

#text("The formalization has been deliberately designed to be separate from the standard Lean math library ")#link("https://leanprover-community.github.io/mathlib4_docs/")[#text("Mathlib")]#text(" at some places, but reliant on it at others. For instance, Mathlib already has a standard notion of the natural numbers ")#mi("{{\\bf N}}")#text(". In the Lean formalization, I first develop “by hand” an alternate construction ")#raw("Chapter2.Nat")#text(" of the natural numbers (or just ")#raw("Nat")#text(", if one is working in the ")#raw("Chapter2")#text(" namespace), setting up many of the basic results about these alternate natural numbers which parallel similar lemmas about ")#mi("{{\\bf N}}")#text(" that are already in Mathlib (but with many of these lemmas set as exercises to the reader, with the proofs currently replaced with “sorries”). Then, in an epilogue section, isomorphisms between these alternate natural numbers and the Mathlib natural numbers are established (or more precisely, set as exercises). From that point on, the Chapter 2 natural numbers are deprecated, and the Mathlib natural numbers are used instead. I intend to continue this general pattern throughout the book, so that as one advances into later chapters, one increasingly relies on Mathlib’s definitions and functions, rather than directly referring to any counterparts from earlier chapters. As such, this companion could also be used as an introduction to Lean and Mathlib as well as to real analysis (somewhat in the spirit of the “")#link("https://adam.math.hhu.de/")[#text("Natural number game")]#text("“, which in fact has significant thematic overlap with Chapter 2 of my text).")

#text("The code in this repository compiles in Lean, but I have not tested whether all of the (numerous) “sorries” in the code can actually be filled (i.e., if all the exercises can actually be solved in Lean). I would be interested in having volunteers “playtest” the companion to see if this can actually be done (and if the helper lemmas or “API” provided in the Lean files are sufficient to fill in the sorries in a conceptually straightforward manner without having to rely on more esoteric Lean programming techniques). Any other feedback will of course also be welcome.")

#text("[UPDATE, May 31: moved the companion to a standalone repository.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688207")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("Your book sounds similar to Edmund Landau’s Grundlagen der Analysis in its objectives. He constructs in succession the number systems from the naturals to the complex numbers using tools such as quotienting and Dedekind cuts. This book was formalised by Jutting in 1977 to demonstrate the power of de Bruijn’s ")#link("https://www.cs.ru.nl/~freek/aut/")[#text("AUTOMATH")]#text(" system.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5e55e5acc3ddd1f28e54a70fed35b82449715a3ee9c08586a01363834ab10498-78882d0fe9b1276141e6cb7e47508c963ce26f822422c351beb8bc431c12fc06.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hendrik Boom")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688217")[#strong[#text("Hendrik Boom")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("Jutting did formalize the entire Grundlagen into the Automath version of type theory. Many of the documents relating to this have been collected at ")#link("https://automath.win.tue.nl/")[#text("https://automath.win.tue.nl/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688208")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("Dear Prof. Tao,")

#text("Would you like to accept contributions of new Exercises, or more generally, interesting propositions, to the companion?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688214")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("I think these would be better suited for downstream forks of the repository (and similarly for solutions to exercises); I plan to keep the core repository faithful to the original source material.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("Maybe there can be something like a community appendix with additional exercises.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688257")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("I have no objection to a community fork of the repository to hold this sort of additional content (and I believe the Apache 2.0 licence I selected is compatible with this).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688209")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("The links to the different sections doesn’t seem to work for me. I get 404.")

#emph[#text("[Fixed, thanks -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("The link behind “Web page for this project” should be “https://teorth.github.io/analysis/”, not “https://teorth.github.io/Analysis/”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2025")])]

#text("The broken link I was talking about is in the following file: “https://github.com/teorth/analysis/blob/main/README.md”")

#emph[#text("[This has now been fixed. In general, fixes to the Github repository are best handled through the issues and pull request pages. -T]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Gent")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688215")[#strong[#text("Peter Gent")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("Thanks for sharing this project, Prof. Tao. ")#emph[#text("Analysis I")]#text(" is my favourite maths textbook. It helped me learn a lot about mathematics, but more importantly, it taught me about clear writing and exposition.")

#text("There’s something poetic about seeing some of Leibniz’s most elegant results now being formalized in a way that AI systems can readily interact with them. It’s his ")#emph[#text("calculus ratiocinator")]#text(" coming to life.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688218")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2025")])]

#text("Is Type theory of VV related?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vatsa")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688223")[#strong[#text("Vatsa")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2025")])]

#text("This should be a course at UCLA!")

#text("Here’s an analogous course on programming language theory")

#link("https://plfa.github.io/")[#text("https://plfa.github.io/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2025")])]

#text("related (in spirit):")#linebreak()#text("“The Number Systems: Foundations of Algebra and Analysis” by Solomon Feferman: https://bookstore.ams.org/chel-333/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc7e813c193034379f0c2a39dd865613d3a3eb3aa6c5ce50ef937f9aebfd600f-f21f051f9cd9e578539f7a8b110b2f1452487b2e8820da80a1dce358de4aca11.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thmataignef165189892")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688235")[#strong[#text("thmataignef165189892")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2025")])]

#text("I am willing to use Lean to follow your work, but after installing it on Windows 11 my anti-virus G-Data complains about several files:")

#text("Virus: Win64.Trojan.Agent.XXMXQQ (Moteur B)Fichier: lean.exeDossier: C:Usersthmat.elanbin")

#text("No real problem for me, I just asked to put the files in quarantine, but I am a bit surprised.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2025")])]

#text("I think the section 2.2 is still pointing to the older location. It should be ")#link("https://teorth.github.io/analysis/docs/Analysis/Section_2_2.html")[#text("https://teorth.github.io/analysis/docs/Analysis/Section_2_2.html")]

#text("-Nagu")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688243")[#strong[#text("Daily Links: Tuesday, Jun 3rd, 2025 | From Pixels to Particles")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2025")]

#text("[…] A Lean companion to “Analysis I”: Almost 20 years ago, I wrote a textbook in real analysis called “Analysis I”. It was intended to complement the many good available analysis textbooks out there by focusing more on foun… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688248")[#strong[#text("Double Maths First Thing: Issue 27 | The Aperiodical")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2025")]

#text("[…] the Fields medallists doing interesting things beat, Terry Tao has launched a Lean companion to Analysis I — Lean is a “formal verification system” that checks your proofs hold water. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2025")])]

#text("Hello this seems quite interesting and I’ve started working through it.")

#text("What sorts of comments on the exercises do you find useful?")

#text("I found that 2.2.10 was quite hard from a lean perspective as you just got dropped in the deep end of proving an exists unique with no other examples surrounding it proving this new syntax and also I thought 2.2.12 (b) (greater than is transitive) was a bit hard as I think the way you need to do it is to get the value out of the ∃ symbol in each of the two hypotheses but there weren’t any examples of doing that in the surrounding text. (I used obtain to do this)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2025")])]

#text("Thanks, this is useful feedback! I have been focusing on formalizing the statements of the exercises and the main text, and have not had the time to “playtest” the proofs of the exercises, so this sort of field report is very useful. I’ve added some comments to Section 2.2 along these lines.")

#text("In the future I may end up formalizing Appendix A (the basics of mathematical logic), which could also serve as a dual role of providing some introduction to Lean basics such as the `obtain` tactic. But for now my main focus is on formalizing the “analysis” part of the text (I just finished sequences, am currently starting on series, and then there is also continuity, differentiation, and integration to get to).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2025")])]

#text("Dear Professor Tao, Thank you for your efforts in formalizing proofs. I am personally not familiar with Lean, but I have a general question. Say Group 1 proves a Theorem A and it’s peer-reviewed and published in a reputable journal. Then say a Group 2 formalizes it, and they conclude that it’s incorrect. How can one verify whether Group 2 formalizes is correct or whether they made a mistake in coding it. I am just personally concerned about the false positive situation in Lean. Can someone “prove” that their formalizes is correct? Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2025")])]

#text("If both groups formalized in the same version of Lean, one can try to merge the two proofs together and see if one can obtain a genuine contradiction. Most likely, what would have happened is that one (or both) of the groups would have formalized a definition, or the statement of the result, incorrectly, for instance by not handling an edge case (e.g., if a key parameter vanishes) correctly. Probably the effort of trying to reconcile the results (by trying to find a “minimal working example” (MWE) of the contradiction) will zero in on the precise discrepancy, in a way that would be faster than if one or both proofs were informal.")

#text("If the two proofs were formalized in incompatible formal languages (e.g., Lean and Rocq) then the situation is more complicated, but one could still try to isolate subtheorems that can be proven true in one formalization and false in another, again to try to find the MWE of the contradiction. It may be a time-consuming process, but having the ability to formally verify consequences of either formalization will make this a more efficient (and hopefully less acrimonious) process than if one only had informal proofs to work with.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cf55003cb9c661a0d6e195b3cc4cebcd1905ebbbec641eac16822b846f8097d-9790dd8f2eea1497d22d07af6c6662a48e4141e4c2368957cb9b504ecb48d13b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JL")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688335")[#strong[#text("JL")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2025")])]

#text("I think what Anonymous is asking about is the situation where one of the group writes a pen and paper proof and the other writes the proof in Lean. They are basically asking if it’s possible to prove that the Lean compiler is correct.")

#text("To answer that question: kind of. You can actually prove mathematically that a piece of code does what you want it to do. So you could prove the code of the Lean compiler is correct.")

#text("But then what about the compiler that compiles the Lean compiler? You can prove that to be correct too. But then there is the compiler that compiles the compiler that compiles the Lean compiler. It is basically turtles all the way down (though I guess in theory you could keep going down the chain of compilers until you go so low that you start proving things about circuits, but this is practically impossible).")

#text("In practice, since Lean is widely used, if there was some sort of bug, it would probably be brought to attention and fixed. Of course, this isn’t a 100% guarantee, but I personally would definitely trust the Lean proof over the pen and paper proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688345")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2025")])]

#text("Dear JL,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("You can actually prove mathematically that a piece of code does what you want it to do.")
]

#text("Can we? I have the impression that there’s no way to formally prove that a formal system is a faithful abstraction of our informal understanding of something, as we can’t formally reason about things in our brain. After all, we have to have an idea of meaning when we want to prove a formal system means what we mean, and for that we can only rely on our informal and intuitive understanding of it inside our brain.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688435")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2025")])]

#text("Analysis I is now completely formalized (except for the introduction chapter, which has a significantly less formal style and is more concerned with (incorrect) informal arguments that do *not* translate into formal proofs).")

#align(center)[
#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/")[#text("A Lean companion to “Analysis I”")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688442")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2025")])]

#text("Happy Birthday to Terence Tao :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2025")])]

#text("If it’s ok to ask this here, why has the math world moved from Rocq to Lean? Are they much different? I’ve looked at Rocq a little (the Software Foundations books) and I know it’s been used for some major formalizations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688560")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2025")])]

#text("I came to this subject only the last few years, so cannot speak with much authority on the early history of this, but my sense is that Rocq is more well adapted to computer science applications, such as formally verifying the soundness of computer languages, while Lean (particularly with its Mathlib model of a single, standardized library) is more well adapted to how a working mathematician actually writes and thinks about proofs. Certainly I found the design choices of Lean and Mathlib to harmonize quite well with my undergraduate Analysis I textbook when I formalized it a few months ago: for instance, Lean’s support of quotient types made the construction of number systems such as the integers, rationals, or reals quite straightforward, with a pretty close match between what was in my text (which was in some sense implementing a “naive” version of type theory with quotient types) with the formalism in Lean. I have not attempted to accomplish a similar exercise in Rocq, but my understanding is that they made some different fundamental design choices, in which quotients were made more difficult to work with in order to preserve some more technical type theoretic properties of the language of interest to computer scientists.")

#text("That said, I hope that advances in auto-formalization will eventually allow proofs in one formal language such as Rocq to be translated semi-automatically to another language such as Lean (or vice versa), though there are some fundamental issues here regarding differences in idiomatic proof writing style, and substantially different libraries for basic mathematical concepts such as the real numbers, which are non-trivial issues to overcome here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2025")])]

#text("this seems like a big deal:")

#link("https://x.com/sebastienbubeck/status/1958198661139009862?s=46")[#text("https://x.com/sebastienbubeck/status/1958198661139009862?s=46")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2025")])]

#text("Would formalizing Analysis II be more difficult than Analysis I? How about the graduate analysis sequence 245ABC?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-688825")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2025")])]

#text("I am teaching 245A (measure theory) right now, and concurrently beginning the process of formalizing the text, see ")#link("https://github.com/teorth/analysis/tree/main/analysis/Analysis/MeasureTheory")[#text("https://github.com/teorth/analysis/tree/main/analysis/Analysis/MeasureTheory")]#text(" . I am hoping to get some of the students in the class involved in the process, and maybe also test out some newer autoformalization tools. If successful, I could try to replicate this for Analysis II, but this is not currently a priority for me.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/31/a-lean-companion-to-analysis-i/#comment-692072")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2026")])]

#text("This is great! Are you interested in pull requests for the ‘sorry’s in the proofs (that weren’t left as exercises to the reader). I haven’t gotten too far in, but I see a couple in WellFoundedLT.partialOrder (Lemma 8.5.14).")

#text("Thanks.")
]
