// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/
// Converted to Typst by tao2typ: "2026-10-14T07:04:10.081079+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Non-measurable sets via non-standard analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Non-measurable sets via non-standard analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 October 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/")[#text("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")[#text("Last year on this blog")]#text(", I sketched out a non-rigorous probabilistic argument justifying the following well-known theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1.")]#text(" (Non-measurable sets exist) There exists a subset ")#mi("E")#text(" of the unit interval ")#mi("{}[0,1]")#text(" which is not ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue-measurable")]#text(".")
]

#text("The idea was to let E be a “random” subset of ")#mi("{}[0,1]")#text(". If one (non-rigorously) applies the ")#link("https://terrytao.wordpress.com/2008/06/18/the-strong-law-of-large-numbers/")[#text("law of large numbers")]#text(", one expects E to have “density” 1/2 with respect to every subinterval of ")#mi("{}[0,1]")#text(", which would contradict the ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(".")

#text("I was recently asked whether I could in fact make the above argument rigorous. This turned out to be more difficult than I had anticipated, due to some technicalities in trying to make the concept of a random subset of ")#mi("{}[0,1]")#text(" (which requires an uncountable number of “coin flips” to generate) both rigorous and useful. However, there is a simpler variant of the above argument which can be made rigorous. Instead of letting E be a “random” subset of ")#mi("{}[0,1]")#text(", one takes E to be an “alternating” set that contains “every other” real number in ")#mi("{}[0,1]")#text("; this again should have density 1/2 in every subinterval and thus again contradict the Lebesgue differentiation theorem.")

#text("Of course, in the standard model of the real numbers, it makes no sense to talk about “every other” or “every second” real number, as the real numbers are not discrete. If however one employs the language of ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("non-standard analysis")]#text(", then it is possible to make the above argument rigorous, and this is the purpose of my post today. I will assume some basic familiarity with non-standard analysis, for instance as discussed in this ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("earlier post of mine")]#text(".")

#metadata(none) <tao-dea9892905ae07c444dd>

#text("We begin by selecting a non-principal ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text(" ")#mi("p \\in \\beta {\\Bbb N} \\backslash {\\Bbb N}")#text(" and use it to construct non-standard models ")#mi("{}*{\\Bbb N}, *[0,1]")#text(" of the natural numbers ")#mi("{\\Bbb N}")#text(" and the unit interval ")#mi("{}[0,1]")#text(" by the usual ")#link("http://en.wikipedia.org/wiki/Ultrapower")[#text("ultrapower")]#text(" construction. We then let ")#mi("N \\in *{\\Bbb N}")#text(" be an unlimited non-standard number, i.e. a non-standard natural number larger than any standard natural number. (For instance, one could take N to be the equivalence class in ")#mi("{}*{\\Bbb N}")#text(" of the sequence ")#mi("1, 2, 3, \\ldots")#text(".)")

#text("We can partition the non-standard unit interval ")#mi("{}*[0,1]")#text(" into ")#mi("2^N")#text(" (non-standard) intervals ")#mi("J_j := {}[j/2^N, (j+1)/2^N]")#text(" for ")#mi("j=0,\\ldots,2^N-1")#text(" (the overlap of these intervals will have a negligible impact in our analysis). We then define the non-standard set ")#mi("{}*E \\subset *[0,1]")#text(" to be the union of those ")#mi("J_j")#text(" with j odd; this is the formalisation of the idea of “every other real number” in the introduction. The key property about *E that we need here is the following symmetry property: if ")#mi("I = [a/2^n, (a+1)/2^n]")#text(" is any standard ")#link("http://en.wikipedia.org/wiki/Dyadic_interval")[#text("dyadic interval")]#text(", then the (non-standard counterpart to the) interval I can be partitioned (modulo (non-standard) rationals) as the set ")#mi("{}*E \\cap I")#text(" and its reflection ")#mi("(2a+1)/2^n - (*E \\cap I)")#text(". This demonstrates in particular that ")#mi("{}*E")#text(" has (non-standard) density 1/2 inside I, but we will need to use the symmetry property directly, rather than the non-standard density property, because the former is much easier to transfer to the standard setting than the latter.")

#text("We now return to the standard world, and introduce the ")#emph[#text("standard")]#text(" set ")#mi("E \\subset [0,1]")#text(", defined as the collection of all standard ")#mi("x \\in [0,1]")#text(" whose non-standard representative ")#mi("{}*x")#text(" lies in ")#mi("{}*E")#text(". This is certainly a standard subset of ")#mi("{}[0,1]")#text(". We claim that it is not Lebesgue measurable, thus establishing Theorem 1. To see this, recall for any standard dyadic interval ")#mi("I = [a/2^n,(a+1)/2^n]")#text(", that every non-standard irrational element of I lies in exactly one of *E or ")#mi("(2a+1)/2^n - *E")#text(". Applying the transfer principle, we conclude that every standard irrational element of I lies in exactly one of E or ")#mi("(2a+1)/2^n - E")#text(". Thus, if E were measurable, the density of E in the dyadic interval I must be exactly 1/2. But this contradicts the ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(", and we are done.")

#strong[#text("Remark 1.")]#text(" One can eliminate the non-standard analysis from this argument and rely directly on the non-principal ultrafilter p. Indeed, if one inspects the ultrapower construction carefully, one sees that (outside of the terminating binary rationals, which do not have a unique binary expansion), E consists of those numbers in ")#mi("{}[0,1]")#text(" whose 1s in the binary expansion lie in p. The symmetry property of E then reflects the non-principal ultrafilter nature of p, in particular the fact that membership of a set ")#mi("A \\subset {\\Bbb N}")#text(" in p is insensitive to any finite modification of A, and reversed by replacing A with its complement. On the other hand, one cannot eliminate the non-principal ultrafilter entirely; once one drops the axiom of choice, there exist models of the real line in which every set is Lebesgue measurable, and so it is necessary to have ")#emph[#text("some")]#text(" step in the proof of Theorem 1 that involves this axiom. In the above argument, choice is used to find the non-principal ultrafilter p. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" It is tempting to also make the original argument, based on randomness, work, but I was unable to push it through completely. Certainly, if one sets ")#mi("{}*E")#text(" to be a (non-standardly) random collection of the ")#mi("J_j")#text(", then with probability infinitesimally close to 1, the (non-standard) density of ")#mi("{}*E")#text(" in any standard dyadic interval (or indeed, any standard interval) is infinitesimally close to 1/2, thanks to the law of large numbers. However, I was not able to transfer this fact to tell me anything about E; indeed, I could not even show that E was non-empty. (Question: does there exist a non-standard subset of ")#mi("{}*[0,1]")#text(" of positive (non-infinitesimal) measure which avoids all standard real numbers? I don’t know the answer to this.) ")#mi("\\diamond")

#text("[")#emph[#text("Update")]#text(", Oct 14: some LaTeX quirks fixed.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a382183d3ed7cf33b841b9044414e6aa0b91df1f4ea991fed59aa4ff2caf406-aa091041e3d91f48464237b83b2439f11d347b3a9aaa0c27dc2e4ef3724cb570.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33002")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")])]

#text("Typo alert: in the paragraph beginning “We begin”, you’re missing the star on the first instance of *N. ")#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33006")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")])]

#text("That reminds me of a proof I once spotted of the existence of non-Ramsey colourings of the infinite subsets of the natural numbers. (I don’t claim to have been the first to spot it though.) Recall that a non-Ramsey colouring is a red-blue colouring where every infinite set of natural numbers has at least one red subset and at least one blue subset. The usual proof that such colourings exist is to call two sets equivalent if they have a finite symmetric difference, to choose one set from each equivalence class (using the axiom of choice) and to colour each set red if it differs from the representative of its equivalence class by an even amount and blue otherwise. But one can achieve the same in a rather pretty way using a non-principal ultrafilter ")#mi("\\beta")#text(". Given an infinite set ")#mi("A")#text(", define a set ")#mi("\\pi(A)")#text(" to be the set of all ")#mi("n")#text(" such that the size of ")#mi("A\\cap\\{1,2,\\dots,n\\}")#text(" is even. Then if ")#mi("A")#text(" is infinite, so is ")#mi("\\pi(A)")#text(". Now colour ")#mi("A")#text(" red if ")#mi("\\pi(A)")#text(" belongs to ")#mi("\\beta")#text(". Then if you change one element of ")#mi("A")#text(", you end up changing every element of ")#mi("\\pi(A)")#text(" from that point on. Thus, if ")#mi("B")#text(" differs from ")#mi("A")#text(" by a single element, then ")#mi("\\pi(B)")#text(" is differs from the complement of ")#mi("\\pi(A)")#text(" by a finite amount. So the colour of ")#mi("\\pi(B)")#text(" is different from the colour of ")#mi("\\pi(A)")#text(". I like to think of this as assigning a “parity” to the infinite sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33009")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")])]

#text("PS Two further tiny comments. First, in what I said above the fact that if ")#mi("A")#text(" is infinite then so is ")#mi("\\pi(A)")#text(" is irrelevant. Secondly, there’s a sort of not-quite-typo at the beginning of your second paragraph, where you have a pair of nested turnings out. And while I’m at it, you have “recall that … that” in the middle of the last paragraph before remark 1. ")#emph[#text("[Fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33013")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2008")])]

#text("Dear Terry,")

#text("Could you please compare your construction to the “classical” constructions?")#linebreak()#text(" I’m not sure that I understood correctly but it seems that your construction – similarly to previous examples – finds a tiling of [0,1] and chooses exactly one element from each tile to get E. In classical examples one can choose an everywhere dense countable additive subgroup and its cosets for tiling. Your tiling seems to be more general. Anyways, if you could point out the basic differences/similarities that would be very helpful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33015")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Somehow this question of yours won’t let me go, and I’ve thought of a rather strange way of producing a random subset of [0,1]. In fact, it’s strange enough that I think I may have made a mistake, as I’ll explain later.")

#text("The idea is very simple, however. I’ll choose a random set of 01-sequences rather than reals, because it’s more convenient. I begin by choosing a random collection ")#mi("\\mathcal{F}")#text(" of ")#emph[#text("finite")]#text(" 01-strings. That is, for each string of length ")#mi("n")#text(", I randomly decide whether or not it belongs to ")#mi("\\mathcal{F}")#text(". I also let ")#mi("\\beta")#text(" be a non-principal ultrafilter. And then for each infinite string ")#mi("\\sigma")#text(" I let ")#mi("A(\\sigma)")#text(" be the set of all ")#mi("n")#text(" such that the ")#mi("n")#text("th initial segment of ")#mi("\\sigma")#text(" belongs to ")#mi("\\mathcal{F}")#text(". I then choose ")#mi("\\sigma")#text(" if and only if ")#mi("A(\\sigma)")#text(" belongs to ")#mi("\\beta")#text(".")

#text("Now I’ll argue slightly less rigorously, so if there’s a mistake anywhere then it’s here. I want to claim that the choices I’ve just made are independent in the strongest possible sense: that if ")#mi("\\sigma")#text(" is a string and I know for every other string ")#mi("\\tau")#text(" whether I’ve chosen it or not, then the probability that I’ve chosen ")#mi("\\sigma")#text(" is still 1/2. To prove this, WLOG ")#mi("\\sigma")#text(" is the string of all zeros. I claim that if I change the choices I made about which strings of the form ")#mi("000\\dots 0")#text(" belong to ")#mi("\\mathcal{F}")#text(", then the only infinite string that I can affect is the all-zero string. And indeed, that is the case because for all other strings I’ve affected at most finitely many initial segments and therefore perturbed ")#mi("A(\\sigma)")#text(" by at most a finite set, which doesn’t affect whether or not it belongs to ")#mi("\\beta")#text(". But since what I do to finite strings of zeros is completely arbitrary, the probability that ")#mi("A(000\\dots 0)\\in\\beta")#text(" is 1/2.")

#text("It’s at this point that I see my mistake. Since an ultrafilter is a non-measurable set, I can’t in fact talk about the probability that a random sequence belongs to it. Nevertheless, I’ll leave this comment here as for me at any rate it clarified the problem. I was going to go on to point out a “paradox”: that I made countably many independent choices and used them to generate uncountably many independent choices.")

#text("Having said that, since one is trying to construct a non-measurable set, it is in a sense necessary that one will not in fact be able to prove rigorous probabilistic statements. So perhaps the above construction isn’t a complete waste of time. In some sense, it really does feel as though the probability that ")#mi("A(000\\dots 0)\\in\\beta")#text(" is 1/2, since if you reverse all your decisions about whether the initial segments belong to ")#mi("\\mathcal{F}")#text(", then you reverse the outcome. So that feels like a bijective proof that the probability is 1/2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f46355445e7f9735ecc9e92b43fa52dfb3742ea27ef04cf06f3ab636dd79948-5437b5c3afa2e4f083c9f7e713bde462f38622e4262ea2c3fc50b851c227aac0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33018")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("To Jozsef: the tiling of the unit interval is by pairs of numbers whose sets of ones in their binary expansion are complementary; the ultrafilter picks one from each pair.")#linebreak()#text(" As such it is akin to Van Vleck’s construction, which can be found on jstor:")#linebreak()#text(" * On Non-Measurable Sets of Points, with an Example")#linebreak()#text(" * Edward B. Van Vleck")#linebreak()#text(" * Transactions of the American Mathematical Society, Vol. 9, No. 2 (Apr., 1908), pp. 237-244")#linebreak()#text(" * Published by: American Mathematical Society")#linebreak()#text(" * Stable URL: ")#link("http://www.jstor.org/stable/1988654")[#text("http://www.jstor.org/stable/1988654")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33019")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("It’s a matter of taste, of course, but I find the following exposition of the definition of ")#mi("E")#text(" simpler. Let ")#mi("N")#text(" be an unlimited (i.e., infinite) natural number, and ")#mi("E \\subset [0,1]")#text(" is the set of (standard) irrational real numbers ")#mi("x")#text(" for which the ")#mi("N")#text("-th binary digit of ")#mi("\\ast x")#text(" is 1.")

#text("By the way, this construction (and a proof of Ramsey’s theorem akin to gowers’ comment) can be found in Goldblatt’s magnificent introduction to nonstandard analysis “Lectures on the Hyperreals”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f46355445e7f9735ecc9e92b43fa52dfb3742ea27ef04cf06f3ab636dd79948-5437b5c3afa2e4f083c9f7e713bde462f38622e4262ea2c3fc50b851c227aac0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33020")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Addendum:")#linebreak()#text(" here is Sierpinski’s proof that from an ultrafilter one can construct directly a non-measurable subset of [0,1]:")

#link("http://matwbn.icm.edu.pl/ksiazki/fm/fm30/fm30116.pdf")[#text("Click to access fm30116.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3aaca4e7dce24a7777f3d9c35c5d5552d8732db7cc4fdd614f0fef8b9bebb023-718cbbb8ae67944febce5d69a4b2451b3e651ba16d61c8c72917f507c071ecc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wonghang")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33021")[#strong[#text("wonghang")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Hi Terry,")

#text("I am not a expert in mathematics. Hope that I do not misunderstand your argument.")

#text("I do not understand what do you mean by “E is nonempty”? E is a random set, how to define nonempty random set? To prove there is a non-measurable set using randomness argument. We are trying to use Law of Large Numbers, which is talking about “average” behavior. Do we need to define a “expected value” of a random set in order to prove the theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33025")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2008")])]

#text("Dear Tim: Somewhat amusingly, even if your argument doesn’t quite construct a random subset of [0,1], it does at least achieve (non-constructively) the original aim in this post, namely to construct a non-measurable set, since if the event that the random sequence lies in the ultrafilter is non-measurable, it is not hard to convert that fact to produce a non-measurable subset of [0,1]. So I guess this does achieve a proof of the existence of non-measurable sets which is somewhat in the spirit of my original intention…")

#text("Dear Jozsef: the textbook construction of nonmeasurable sets follows quite directly from the axiom of choice, whereas the one here is very closely tied to the existence of an ultrafilter (one can, for instance, recover the ultrafilter from the set E). The existence of non-principal ultrafilters follows easily from Zorn’s lemma, of course, but I don’t know of any way to build these objects directly from the axiom of choice without basically repeating the entire proof of Zorn’s lemma, which is not entirely trivial. So I would imagien that the two constructions are genuinely different from each other, even if tiling is the key idea in both of them.")

#text("Dear Wonghang: I corrected some slight LaTeX errors in the post. My main question can be stated without randomness: does there exist a nonstandard subset *E of the nonstandard interval *[0,1] of positive (non-infintesimal) Lebesgue measure, such that the standard portion E of *E is empty (i.e. *E contains no standard real numbers)? I don’t know the answer to this. I am specifically interested in the case when *E is a random collection of intervals of length 2^{-n} for some unlimited integer n, in which case I would like the statement to be true for “generic” choices of such sets (whatever that means).")

#text("Dear Kevin and K.P.: Thanks for the references!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f46355445e7f9735ecc9e92b43fa52dfb3742ea27ef04cf06f3ab636dd79948-5437b5c3afa2e4f083c9f7e713bde462f38622e4262ea2c3fc50b851c227aac0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33070")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2008")])]

#text("For those who like to go back to the sources: here are links to papers of")#linebreak()#text(" Ulam: ")#link("http://matwbn.icm.edu.pl/ksiazki/fm/fm14/fm14118.pdf")[#text("http://matwbn.icm.edu.pl/ksiazki/fm/fm14/fm14118.pdf")]#text(" and")#linebreak()#text(" Tarski: ")#link("http://matwbn.icm.edu.pl/ksiazki/fm/fm15/fm1515.pdf")[#text("http://matwbn.icm.edu.pl/ksiazki/fm/fm15/fm1515.pdf")]#linebreak()#text(" Both construct non-trivial finitely additive 0-1-valued measures that vanish on singletons; the sets of measure 1 form an ultrafilter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6fea08bcd8e355ff4c626f9f6daf2fb31143843b2e48383ccac918567505ccb-b5e352eef1ac29d496a74a762ee2800c45be92702cd1f650ddd02ce8be1bbd58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jhusdhui")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33096")[#strong[#text("jhusdhui")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2008")])]

#text("Dear Terry,")#linebreak()#text(" Can you elaborate on the original question: how to prove that a “random” subset of the reals isn’t measurable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d1d40d3a289c50fe58f765cc18b7d0f4b0f272106066ce8a87f37b11d8d9ce7-7a5842fad415dec268b6d6a0321b4b3728a3a83df45ec7cb2938273046bf1e38.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K. P. Hart")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-33169")[#strong[#text("K. P. Hart")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2008")])]

#text("In (at least) one sense this cannot be done. A subset of [0,1] is a point in the product $\\latex 2^{[0,1]}$ and this product carries a product measure induced by the measure $\\latex \\mu(\\{0\\})=\\mu(\\{1\\})=1/2$. Every element of the sigma-algebra generated by the cylinders is determined by countably many coordinates, which means that every such set of positive measure contains both points that represent measurable sets and points that represent non-measurable sets. This implies that the sets M (points that represent measurable sets) and N (points that represent non-measurable sets) both have outer measure 1 and hence are not measurable with respect to the coin-tossing measure. This means that tossing a coin once for each real does not automatically lead to a non-measurable set.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 1: Lebesgue measure « What’s new")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-46920")[#strong[#text("245A, Notes 1: Lebesgue measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("[…] events as “ is Lebesgue measurable”. (For some further discussion of this point, see this post.) So we now turn to more rigorous arguments that establish the existence of non-measurable sets. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ae3095d32387e9cdbf0c3f111b4c0cd771a7fcc9231e372af282ba21c35743a-47afd6308db3dcec79069499c29ce86a068c40c7446e3cf580cbac6efa35225d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koushik Ghosh")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-250815")[#strong[#text("Koushik Ghosh")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2013")])]

#text("Sir, is it not possible to make the argument free of non-standard analysis language.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4ae3095d32387e9cdbf0c3f111b4c0cd771a7fcc9231e372af282ba21c35743a-47afd6308db3dcec79069499c29ce86a068c40c7446e3cf580cbac6efa35225d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koushik Ghosh")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-250817")[#strong[#text("Koushik Ghosh")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2013")])]

#text("i mean also ultrafilter. a elementary language proof")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-454114")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2015")])]

#text("sir help me about the topics & exa. cauchy pde of first order")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2a1ad7d1352d6b37bf652f0348dd3fb5b07c6ff9c724a77826bcd1ec2d42451-20dd2889b32a34f3741a4b2176439eb46f3e75426e8d67e07da851e352169905.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexander Pruss")]], [#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/#comment-498705")[#strong[#text("Alexander Pruss")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2018")])]

#text("For what it’s worth, if we have enough saturation in the non-standard model, there will be a *-finite internal set F containing every element of the standard interval [0,1]. Then *[0,1] \\ F will have full *-measure but won’t meet any reals. I assume, though, your non-standard model is based on an ultrafilter on the naturals, so this trivial observation won’t help you.")
]
