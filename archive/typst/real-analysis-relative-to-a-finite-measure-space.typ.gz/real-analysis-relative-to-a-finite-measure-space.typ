// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/
// Converted to Typst by tao2typ: "2026-10-14T15:19:07.849403+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Real analysis relative to a finite measure space", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Real analysis relative to a finite measure space")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 July 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/")[#text("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the traditional foundations of probability theory, one selects a probability space ")#mi("{(\\Omega, {\\mathcal B}, {\\mathbf P})}")#text(", and makes a distinction between ")#emph[#text("deterministic")]#text(" mathematical objects, which do not depend on the sampled state ")#mi("{\\omega \\in \\Omega}")#text(", and ")#emph[#text("stochastic")]#text(" (or ")#emph[#text("random")]#text(") mathematical objects, which do depend (but in a measurable fashion) on the sampled state ")#mi("{\\omega \\in \\Omega}")#text(". For instance, a ")#emph[#text("deterministic real number")]#text(" would just be an element ")#mi("{x \\in {\\bf R}}")#text(", whereas a ")#emph[#text("stochastic real number")]#text(" (or ")#emph[#text("real random variable")]#text(") would be a measurable function ")#mi("{x: \\Omega \\rightarrow {\\bf R}}")#text(", where in this post ")#mi("{{\\bf R}}")#text(" will always be endowed with the Borel ")#mi("{\\sigma}")#text("-algebra. (For readers familiar with ")#link("http://en.wikipedia.org/wiki/Non-standard_analysis")[#text("nonstandard analysis")]#text(", the adjectives “deterministic” and “stochastic” will be used here in a manner analogous to the uses of the adjectives “standard” and “nonstandard” in nonstandard analysis. The analogy is particularly close when comparing with the “cheap nonstandard analysis” discussed in ")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("this previous blog post")]#text(". We will also use “relative to ")#mi("{\\Omega}")#text("” as a synonym for “stochastic”.)")

#text("Actually, for our purposes we will adopt the philosophy of identifying stochastic objects that agree almost surely, so if one was to be completely precise, we should define a stochastic real number to be an ")#emph[#text("equivalence class")]#text(" ")#mi("{[x]}")#text(" of measurable functions ")#mi("{x: \\Omega \\rightarrow {\\bf R}}")#text(", up to almost sure equivalence. However, we shall often abuse notation and write ")#mi("{[x]}")#text(" simply as ")#mi("{x}")#text(".")

#text("More generally, given any ")#link("http://en.wikipedia.org/wiki/Measurable_space")[#text("measurable space")]#text(" ")#mi("{X = (X, {\\mathcal X})}")#text(", we can talk either about deterministic elements ")#mi("{x \\in X}")#text(", or about stochastic elements of ")#mi("{X}")#text(", that is to say equivalence classes ")#mi("{[x]}")#text(" of measurable maps ")#mi("{x: \\Omega \\rightarrow X}")#text(" up to almost sure equivalence. We will use ")#mi("{\\Gamma(X|\\Omega)}")#text(" to denote the set of all stochastic elements of ")#mi("{X}")#text(". (For readers familiar with ")#link("http://en.wikipedia.org/wiki/Sheaf_(mathematics)")[#text("sheaves")]#text(", it may helpful for the purposes of this post to think of ")#mi("{\\Gamma(X|\\Omega)}")#text(" as the space of measurable ")#link("http://en.wikipedia.org/wiki/Section_(fiber_bundle)#Local_and_global_sections")[#text("global sections")]#text(" of the trivial ")#mi("{X}")#text("–")#link("http://en.wikipedia.org/wiki/Fiber_bundle")[#text("bundle")]#text(" over ")#mi("{\\Omega}")#text(".) Of course every deterministic element ")#mi("{x}")#text(" of ")#mi("{X}")#text(" can also be viewed as a stochastic element ")#mi("{x|\\Omega \\in \\Gamma(X|\\Omega)}")#text(" given by (the equivalence class of) the constant function ")#mi("{\\omega \\mapsto x}")#text(", thus giving an embedding of ")#mi("{X}")#text(" into ")#mi("{\\Gamma(X|\\Omega)}")#text(". We do not attempt here to give an interpretation of ")#mi("{\\Gamma(X|\\Omega)}")#text(" for sets ")#mi("{X}")#text(" that are not equipped with a ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal X}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("my previous post on the foundations of probability theory")]#text(", I emphasised the freedom to extend the sample space ")#mi("{(\\Omega, {\\mathcal B}, {\\mathbf P})}")#text(" to a larger sample space whenever one wished to inject additional sources of randomness. This is of course an important freedom to possess (and in the current formalism, is the analogue of the important operation of ")#link("http://en.wikipedia.org/wiki/Base_change")[#text("base change")]#text(" in algebraic geometry), but in this post we will focus on a single fixed sample space ")#mi("{(\\Omega, {\\mathcal B}, {\\mathbf P})}")#text(", and not consider extensions of this space, so that one only has to consider two types of mathematical objects (deterministic and stochastic), as opposed to having many more such types, one for each potential choice of sample space (with the deterministic objects corresponding to the case when the sample space collapses to a point).")
]

#text("Any (measurable) ")#mi("{k}")#text("-ary operation on deterministic mathematical objects then extends to their stochastic counterparts by applying the operation pointwise. For instance, the addition operation ")#mi("{+: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" on deterministic real numbers extends to an addition operation ")#mi("{+: \\Gamma({\\bf R}|\\Omega) \\times \\Gamma({\\bf R}|\\Omega) \\rightarrow \\Gamma({\\bf R}|\\Omega)}")#text(", by defining the class ")#mi("{[x]+[y]}")#text(" for ")#mi("{x,y: \\Omega \\rightarrow {\\bf R}}")#text(" to be the equivalence class of the function ")#mi("{\\omega \\mapsto x(\\omega) + y(\\omega)}")#text("; this operation is easily seen to be well-defined. More generally, any measurable ")#mi("{k}")#text("-ary deterministic operation ")#mi("{O: X_1 \\times \\dots \\times X_k \\rightarrow Y}")#text(" between measurable spaces ")#mi("{X_1,\\dots,X_k,Y}")#text(" extends to an stochastic operation ")#mi("{O: \\Gamma(X_1|\\Omega) \\times \\dots \\Gamma(X_k|\\Omega) \\rightarrow \\Gamma(Y|\\Omega)}")#text(" in the obvious manner.")

#text("There is a similar story for ")#mi("{k}")#text("-ary relations ")#mi("{R: X_1 \\times \\dots \\times X_k \\rightarrow \\{\\text{true},\\text{false}\\}}")#text(", although here one has to make a distinction between a deterministic reading of the relation and a stochastic one. Namely, if we are given stochastic objects ")#mi("{x_i \\in \\Gamma(X_i|\\Omega)}")#text(" for ")#mi("{i=1,\\dots,k}")#text(", the relation ")#mi("{R(x_1,\\dots,x_k)}")#text(" does not necessarily take values in the deterministic Boolean algebra ")#mi("{\\{ \\text{true}, \\text{false}\\}}")#text(", but only in the stochastic Boolean algebra ")#mi("{\\Gamma(\\{ \\text{true}, \\text{false}\\}|\\Omega)}")#text(" – thus ")#mi("{R(x_1,\\dots,x_k)}")#text(" may be true with some positive probability and also false with some positive probability (with the event that ")#mi("{R(x_1,\\dots,x_k)}")#text(" being stochastically true being determined up to null events). Of course, the deterministic Boolean algebra embeds in the stochastic one, so we can talk about a relation ")#mi("{R(x_1,\\dots,x_k)}")#text(" being determinstically true or deterministically false, which (due to our identification of stochastic objects that agree almost surely) means that ")#mi("{R(x_1(\\omega),\\dots,x_k(\\omega))}")#text(" is almost surely true or almost surely false respectively. For instance given two stochastic objects ")#mi("{x,y}")#text(", one can view their equality relation ")#mi("{x=y}")#text(" as having a stochastic truth value. This is distinct from the way the equality symbol ")#mi("{=}")#text(" is used in mathematical logic, which we will now call “equality in the deterministic sense” to reduce confusion. Thus, ")#mi("{x=y}")#text(" in the deterministic sense if and only if the stochastic truth value of ")#mi("{x=y}")#text(" is equal to ")#mi("{\\text{true}}")#text(", that is to say that ")#mi("{x(\\omega)=y(\\omega)}")#text(" for almost all ")#mi("{\\omega}")#text(".")

#text("Any universal identity for deterministic operations (or universal implication between identities) extends to their stochastic counterparts: for instance, addition is commutative, associative, and cancellative on the space of deterministic reals ")#mi("{{\\bf R}}")#text(", and is therefore commutative, associative, and cancellative on stochastic reals ")#mi("{\\Gamma({\\bf R}|\\Omega)}")#text(" as well. However, one has to be more careful when working with mathematical laws that are not expressible as universal identities, or implications between identities. For instance, ")#mi("{{\\bf R}}")#text(" is an integral domain: if ")#mi("{x_1,x_2 \\in {\\bf R}}")#text(" are deterministic reals such that ")#mi("{x_1 x_2=0}")#text(", then one must have ")#mi("{x_1=0}")#text(" or ")#mi("{x_2=0}")#text(". However, if ")#mi("{x_1, x_2 \\in \\Gamma({\\bf R}|\\Omega)}")#text(" are ")#emph[#text("stochastic")]#text(" reals such that ")#mi("{x_1 x_2 = 0}")#text(" (in the deterministic sense), then it is no longer necessarily the case that ")#mi("{x_1=0}")#text(" (in the deterministic sense) or that ")#mi("{x_2=0}")#text(" (in the deterministic sense); however, it is still true that “")#mi("{x_1=0}")#text(" or ")#mi("{x_2=0}")#text("” is true in the deterministic sense if one interprets the boolean operator “or” stochastically, thus “")#mi("{x_1(\\omega)=0}")#text(" or ")#mi("{x_2(\\omega)=0}")#text("” is true for almost all ")#mi("{\\omega}")#text(". Another way to properly obtain a stochastic interpretation of the integral domain property of ")#mi("{{\\bf R}}")#text(" is to rewrite it as")

#align(center)[#tao-fit-display[#mitex("x_1,x_2 \\in {\\bf R}, x_1 x_2 = 0 \\implies x_i=0 \\text{ for some } i \\in \\{1,2\\}")]]

#text("and then make all sets stochastic to obtain the true statement")

#align(center)[#tao-fit-display[#mitex("x_1,x_2 \\in \\Gamma({\\bf R}|\\Omega), x_1 x_2 = 0 \\implies x_i=0 \\text{ for some } i \\in \\Gamma(\\{1,2\\}|\\Omega),")]]

#text("thus we have to allow the index ")#mi("{i}")#text(" for which vanishing ")#mi("{x_i=0}")#text(" occurs to also be stochastic, rather than deterministic. (A technical note: when one proves this statement, one has to select ")#mi("{i}")#text(" in a measurable fashion; for instance, one can choose ")#mi("{i(\\omega)}")#text(" to equal ")#mi("{1}")#text(" when ")#mi("{x_1(\\omega)=0}")#text(", and ")#mi("{2}")#text(" otherwise (so that in the “tie-breaking” case when ")#mi("{x_1(\\omega)}")#text(" and ")#mi("{x_2(\\omega)}")#text(" both vanish, one always selects ")#mi("{i(\\omega)}")#text(" to equal ")#mi("{1}")#text(").)")

#text("Similarly, the law of the excluded middle fails when interpreted deterministically, but remains true when interpreted stochastically: if ")#mi("{S}")#text(" is a stochastic statement, then it is not necessarily the case that ")#mi("{S}")#text(" is either deterministically true or deterministically false; however the sentence “")#mi("{S}")#text(" or not-")#mi("{S}")#text("” is still deterministically true if the boolean operator “or” is interpreted stochastically rather than deterministically.")

#text("To avoid having to keep pointing out which operations are interpreted stochastically and which ones are interpreted deterministically, we will use the following convention: if we assert that a mathematical sentence ")#mi("{S}")#text(" involving stochastic objects is true, then (unless otherwise specified) we mean that ")#mi("{S}")#text(" is deterministically true, assuming that all relations used inside ")#mi("{S}")#text(" are interpreted stochastically. For instance, if ")#mi("{x,y}")#text(" are stochastic reals, when we assert that “Exactly one of ")#mi("{x < y}")#text(", ")#mi("{x=y}")#text(", or ")#mi("{x>y}")#text(" is true”, then by default it is understood that the relations ")#mi("{<}")#text(", ")#mi("{=}")#text(", ")#mi("{>}")#text(" and the boolean operator “exactly one of” are interpreted stochastically, and the assertion is that the sentence is deterministically true.")

#text("In the above discussion, the stochastic objects ")#mi("{x}")#text(" being considered were elements of a deterministic space ")#mi("{X}")#text(", such as the reals ")#mi("{{\\bf R}}")#text(". However, it can often be convenient to generalise this situation by allowing the ambient space ")#mi("{X}")#text(" to also be stochastic. For instance, one might wish to consider a stochastic vector ")#mi("{v(\\omega)}")#text(" inside a stochastic vector space ")#mi("{V(\\omega)}")#text(", or a stochastic edge ")#mi("{e}")#text(" of a stochastic graph ")#mi("{G(\\omega)}")#text(". In order to formally describe this situation within the classical framework of measure theory, one needs to place all the ambient spaces ")#mi("{X(\\omega)}")#text(" inside a measurable space. This can certainly be done in many contexts (e.g. when considering random graphs on a deterministic set of vertices, or if one is willing to work up to equivalence and place the ambient spaces inside a suitable moduli space), but is not completely natural in other contexts. For instance, if one wishes to consider stochastic vector spaces of potentially unbounded dimension (in particular, potentially larger than any given cardinal that one might specify in advance), then the class of all possible vector spaces is so large that it becomes a ")#link("http://en.wikipedia.org/wiki/Class_(set_theory)")[#text("proper class")]#text(" rather than a set (even if one works up to equivalence), making it problematic to give this class the structure of a measurable space; furthermore, even once one does so, one needs to take additional care to pin down what it would mean for a random vector ")#mi("{\\omega \\mapsto v_\\omega}")#text(" lying in a random vector space ")#mi("{\\omega \\mapsto V_\\omega}")#text(" to depend “measurably” on ")#mi("{\\omega}")#text(".")

#text("Of course, in any reasonable application one can avoid the set theoretic issues at least by various ")#emph[#text("ad hoc")]#text(" means, for instance by restricting the dimension of all spaces involved to some fixed cardinal such as ")#mi("{2^{\\aleph_0}}")#text(". However, the measure-theoretic issues can require some additional effort to resolve properly.")

#text("In this post I would like to describe a different way to formalise stochastic spaces, and stochastic elements of these spaces, by viewing the spaces as measure-theoretic analogue of a ")#link("http://en.wikipedia.org/wiki/Sheaf_(mathematics)")[#text("sheaf")]#text(", but being over the probability space ")#mi("{\\Omega}")#text(" rather than over a topological space; stochastic objects are then ")#emph[#text("sections")]#text(" of such sheaves. Actually, for minor technical reasons it is convenient to work in the slightly more general setting in which the base space ")#mi("{\\Omega}")#text(" is a finite measure space ")#mi("{(\\Omega, {\\mathcal B}, \\mu)}")#text(" rather than a probability space, thus ")#mi("{\\mu(\\Omega)}")#text(" can take any value in ")#mi("{[0,+\\infty)}")#text(" rather than being normalised to equal ")#mi("{1}")#text(". This will allow us to easily localise to subevents ")#mi("{\\Omega^{\\prime}}")#text(" of ")#mi("{\\Omega}")#text(" without the need for normalisation, even when ")#mi("{\\Omega^{\\prime}}")#text(" is a null event (though we caution that the map ")#mi("{x \\mapsto x|\\Omega^{\\prime}}")#text(" from deterministic objects ")#mi("{x}")#text(" ceases to be injective in this latter case). We will however still continue to use probabilistic terminology. despite the lack of normalisation; thus for instance, sets ")#mi("{E}")#text(" in ")#mi("{{\\mathcal B}}")#text(" will be referred to as ")#emph[#text("events")]#text(", the measure ")#mi("{\\mu(E)}")#text(" of such a set will be referred to as the ")#emph[#text("probability")]#text(" (which is now permitted to exceed ")#mi("{1}")#text(" in some cases), and an event whose complement is a null event shall be said to hold ")#emph[#text("almost surely")]#text(". It is in fact likely that almost all of the theory below extends to base spaces which are ")#mi("{\\sigma}")#text("-finite rather than finite (for instance, by damping the measure to become finite, without introducing any further null events), although we will not pursue this further generalisation here.")

#text("The approach taken in this post is “")#link("http://en.wikipedia.org/wiki/Topos")[#text("topos")]#text("-theoretic” in nature (although we will not use the language of topoi explicitly here), and is well suited to a “pointless” or “point-free” approach to probability theory, in which the role of the stochastic state ")#mi("{\\omega \\in \\Omega}")#text(" is suppressed as much as possible; instead, one strives to always adopt a “relative point of view”, with all objects under consideration being viewed as stochastic objects relative to the underlying base space ")#mi("{\\Omega}")#text(". In this perspective, the stochastic version of a set is as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Stochastic set)")]#text(" Unless otherwise specified, we assume that we are given a fixed finite measure space ")#mi("{\\Omega = (\\Omega, {\\mathcal B}, \\mu)}")#text(" (which we refer to as the ")#emph[#text("base space")]#text("). A ")#emph[#text("stochastic set")]#text(" (relative to ")#mi("{\\Omega}")#text(") is a tuple ")#mi("{X|\\Omega = (\\Gamma(X|E)_{E \\in {\\mathcal B}}, ((|E))_{E \\subset F, E,F \\in {\\mathcal B}})}")#text(" consisting of the following objects:")

#list(
[#text("A set ")#mi("{\\Gamma(X|E)}")#text(" assigned to each event ")#mi("{E \\in {\\mathcal B}}")#text("; and")],
[#text("A ")#emph[#text("restriction map")]#text(" ")#mi("{x \\mapsto x|E}")#text(" from ")#mi("{\\Gamma(X|F)}")#text(" to ")#mi("{\\Gamma(X|E)}")#text(" to each pair ")#mi("{E \\subset F}")#text(" of nested events ")#mi("{E,F \\in {\\mathcal B}}")#text(". (Strictly speaking, one should indicate the dependence on ")#mi("{F}")#text(" in the notation for the restriction map, e.g. using ")#mi("{x \\mapsto x|(E \\leftarrow F)}")#text(" instead of ")#mi("{x \\mapsto x|E}")#text(", but we will abuse notation by omitting the ")#mi("{F}")#text(" dependence.)")]
)

#text("We refer to elements of ")#mi("{\\Gamma(X|E)}")#text(" as ")#emph[#text("local stochastic elements")]#text(" of the stochastic set ")#mi("{X|\\Omega}")#text(", localised to the event ")#mi("{E}")#text(", and elements of ")#mi("{\\Gamma(X|\\Omega)}")#text(" as ")#emph[#text("global stochastic elements")]#text(" (or simply ")#emph[#text("elements")]#text(") of the stochastic set. (In the language of sheaves, one would use “sections” instead of “elements” here, but I prefer to use the latter terminology here, for compatibility with conventional probabilistic notation, where for instance measurable maps from ")#mi("{\\Omega}")#text(" to ")#mi("{{\\bf R}}")#text(" are referred to as real random variables, rather than sections of the reals.)")

#text("Furthermore, we impose the following axioms:")

#list(
[#text("(Category) The map ")#mi("{x \\mapsto x|E}")#text(" from ")#mi("{\\Gamma(X|E)}")#text(" to ")#mi("{\\Gamma(X|E)}")#text(" is the identity map, and if ")#mi("{E \\subset F \\subset G}")#text(" are events in ")#mi("{{\\mathcal B}}")#text(", then ")#mi("{((x|F)|E) = (x|E)}")#text(" for all ")#mi("{x \\in \\Gamma(X|G)}")#text(".")],
[#text("(Null events trivial) If ")#mi("{E \\in {\\mathcal B}}")#text(" is a null event, then the set ")#mi("{\\Gamma(X|E)}")#text(" is a singleton set. (In particular, ")#mi("{\\Gamma(X|\\emptyset)}")#text(" is always a singleton set; this is analogous to the convention that ")#mi("{x^0=1}")#text(" for any number ")#mi("{x}")#text(".)")],
[#text("(Countable gluing) Suppose that for each natural number ")#mi("{n}")#text(", one has an event ")#mi("{E_n \\in {\\mathcal B}}")#text(" and an element ")#mi("{x_n \\in \\Gamma(X|E_n)}")#text(" such that ")#mi("{x_n|(E_n \\cap E_m) = x_m|(E_n \\cap E_m)}")#text(" for all ")#mi("{n,m}")#text(". Then there exists a unique ")#mi("{x\\in \\Gamma(X|\\bigcup_{n=1}^\\infty E_n)}")#text(" such that ")#mi("{x_n = x|E_n}")#text(" for all ")#mi("{n}")#text(".")]
)

#text("If ")#mi("{\\Omega^{\\prime}}")#text(" is an event in ")#mi("{\\Omega}")#text(", we define the ")#emph[#text("localisation")]#text(" ")#mi("{X|\\Omega^{\\prime}}")#text(" of the stochastic set ")#mi("{X|\\Omega}")#text(" to ")#mi("{\\Omega^{\\prime}}")#text(" to be the stochastic set")

#align(center)[#tao-fit-display[#mitex("X|\\Omega^{\\prime} := (\\Gamma(X|E)_{E \\in {\\mathcal B}; E \\subset \\Omega^{\\prime}}, ((|E))_{E \\subset F \\subset \\Omega^{\\prime}, E,F \\in {\\mathcal B}})")]]

#text("relative to ")#mi("{\\Omega^{\\prime}}")#text(". (Note that there is no need to renormalise the measure on ")#mi("{\\Omega^{\\prime}}")#text(", as we are not demanding that our base space have total measure ")#mi("{1}")#text(".)")
]

#text("The following fact is useful for actually verifying that a given object indeed has the structure of a stochastic set:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that to verify the countable gluing axiom of a stochastic set, it suffices to do so under the additional hypothesis that the events ")#mi("{E_n}")#text(" are disjoint. (Note that this is quite different from the situation with sheaves over a topological space, in which the analogous gluing axiom is often trivial in the disjoint case but has non-trivial content in the overlapping case. This is ultimately because a ")#mi("{\\sigma}")#text("-algebra is closed under all Boolean operations, whereas a topology is only closed under union and intersection.)")
]

#text("Let us illustrate the concept of a stochastic set with some examples.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1 (Discrete case)")]#text(" A simple case arises when ")#mi("{\\Omega}")#text(" is a discrete space which is at most countable. If we assign a set ")#mi("{X_\\omega}")#text(" to each ")#mi("{\\omega \\in \\Omega}")#text(", with ")#mi("{X_\\omega}")#text(" a singleton if ")#mi("{\\mu(\\{\\omega\\})=0}")#text(". One then sets ")#mi("{\\Gamma(X|E) := \\prod_{\\omega \\in E} X_\\omega}")#text(", with the obvious restriction maps, giving rise to a stochastic set ")#mi("{X|\\Omega}")#text(". (Thus, a local element ")#mi("{x}")#text(" of ")#mi("{\\Gamma(X|E)}")#text(" can be viewed as a map ")#mi("{\\omega \\mapsto x(\\omega)}")#text(" on ")#mi("{E}")#text(" that takes values in ")#mi("{X_\\omega}")#text(" for each ")#mi("{\\omega \\in E}")#text(".) Conversely, it is not difficult to see that any stochastic set over an at most countable discrete probability space ")#mi("{\\Omega}")#text(" is of this form up to isomorphism. In this case, one can think of ")#mi("{X|\\Omega}")#text(" as a bundle of sets ")#mi("{X_\\omega}")#text(" over each point ")#mi("{\\omega}")#text(" (of positive probability) in the base space ")#mi("{\\Omega}")#text(". One can extend this bundle interpretation of stochastic sets to reasonably nice sample spaces ")#mi("{\\Omega}")#text(" (such as standard Borel spaces) and similarly reasonable ")#mi("{X}")#text("; however, I would like to avoid this interpretation in the formalism below in order to be able to easily work in settings in which ")#mi("{\\Omega}")#text(" and ")#mi("{X}")#text(" are very “large” (e.g. not separable in any reasonable sense). Note that we permit some of the ")#mi("{X_\\omega}")#text(" to be empty, thus it can be possible for ")#mi("{\\Gamma(X|\\Omega)}")#text(" to be empty whilst ")#mi("{\\Gamma(X|E)}")#text(" for some strict subevents ")#mi("{E}")#text(" of ")#mi("{\\Omega}")#text(" to be non-empty. (This is analogous to how it is possible for a sheaf to have local sections but no global sections.) As such, the space ")#mi("{\\Gamma(X|\\Omega)}")#text(" of global elements does not completely determine the stochastic set ")#mi("{X|\\Omega}")#text("; one sometimes needs to localise to an event ")#mi("{E}")#text(" in order to see the full structure of such a set. Thus it is important to distinguish between a stochastic set ")#mi("{X|\\Omega}")#text(" and its space ")#mi("{\\Gamma(X|\\Omega)}")#text(" of global elements. (As such, it is a slight abuse of the ")#link("http://en.wikipedia.org/wiki/Axiom_of_extensionality")[#text("axiom of extensionality")]#text(" to refer to global elements of ")#mi("{X|\\Omega}")#text(" simply as “elements”, but hopefully this should not cause too much confusion.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Measurable spaces as stochastic sets)")]#text(" Returning now to a general base space ")#mi("{\\Omega}")#text(", any (deterministic) measurable space ")#mi("{X}")#text(" gives rise to a stochastic set ")#mi("{X|\\Omega}")#text(", with ")#mi("{\\Gamma(X|E)}")#text(" being defined as in previous discussion as the measurable functions from ")#mi("{E}")#text(" to ")#mi("{X}")#text(" modulo almost everywhere equivalence (in particular, ")#mi("{\\Gamma(X|E)}")#text(" a singleton set when ")#mi("{E}")#text(" is null), with the usual restriction maps. The constraint of measurability on the maps ")#mi("{x: E \\rightarrow \\Omega}")#text(", together with the quotienting by almost sure equivalence, means that ")#mi("{\\Gamma(X|E)}")#text(" is now more complicated than a plain Cartesian product ")#mi("{\\prod_{\\omega \\in E} X_\\omega}")#text(" of fibres, but this still serves as a useful first approximation to what ")#mi("{\\Gamma(X|E)}")#text(" is for the purposes of developing intuition. Indeed, the measurability constraint is so weak (as compared for instance to topological or smooth constraints in other contexts, such as sheaves of continuous or smooth sections of bundles) that the intuition of essentially independent fibres is quite an accurate one, at least if one avoids consideration of an uncountable number of objects simultaneously.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Extended Hilbert modules)")]#text(" ")#metadata(none) <tao-7218c092c768a68d7c37>#text(" This example is the one that motivated this post for me. Suppose that one has an extension ")#mi("{(\\tilde \\Omega, \\tilde {\\mathcal B}, \\tilde \\mu)}")#text(" of the base space ")#mi("{(\\Omega, {\\mathcal B},\\mu)}")#text(", thus we have a measurable factor map ")#mi("{\\pi: \\tilde \\Omega \\rightarrow \\Omega}")#text(" such that the pushforward of the measure ")#mi("{\\tilde \\mu}")#text(" by ")#mi("{\\pi}")#text(" is equal to ")#mi("{\\mu}")#text(". Then we have a conditional expectation operator ")#mi("{\\pi_*: L^2(\\tilde \\Omega,\\tilde {\\mathcal B},\\tilde \\mu) \\rightarrow L^2(\\Omega,{\\mathcal B},\\mu)}")#text(", defined as the adjoint of the pullback map ")#mi("{\\pi^*: L^2(\\Omega,{\\mathcal B},\\mu) \\rightarrow L^2(\\tilde \\Omega,\\tilde {\\mathcal B},\\tilde \\mu)}")#text(". As is well known, the conditional expectation operator also extends to a contraction ")#mi("{\\pi_*: L^1(\\tilde \\Omega,\\tilde {\\mathcal B},\\tilde \\mu) \\rightarrow L^1(\\Omega,{\\mathcal B}, \\mu)}")#text("; by monotone convergence we may also extend ")#mi("{\\pi_*}")#text(" to a map from measurable functions from ")#mi("{\\tilde \\Omega}")#text(" to the extended non-negative reals ")#mi("{[0,+\\infty]}")#text(", to measurable functions from ")#mi("{\\Omega}")#text(" to ")#mi("{[0,+\\infty]}")#text(". We then define the “extended Hilbert module” ")#mi("{L^2(\\tilde \\Omega|\\Omega)}")#text(" to be the space of functions ")#mi("{f \\in L^2(\\tilde \\Omega,\\tilde {\\mathcal B},\\tilde \\mu)}")#text(" with ")#tao-math("{\\pi_*(\\left|f\\right|^2)}", block: false)#text(" finite almost everywhere. This is an extended version of the Hilbert module ")#mi("{L^\\infty_{\\Omega} L^2(\\tilde \\Omega|\\Omega)}")#text(", which is defined similarly except that ")#tao-math("{\\pi_*(\\left|f\\right|^2)}", block: false)#text(" is required to lie in ")#mi("{L^\\infty(\\Omega,{\\mathcal B},\\mu)}")#text("; this is a Hilbert module over ")#mi("{L^\\infty(\\Omega, {\\mathcal B}, \\mu)}")#text(" which is of particular importance in the Furstenberg-Zimmer structure theory of measure-preserving systems. We can then define the stochastic set ")#mi("{L^2_\\pi(\\tilde \\Omega)|\\Omega}")#text(" by setting")

#align(center)[#tao-fit-display[#mitex("\\Gamma(L^2_\\pi(\\tilde \\Omega)|E) := L^2( \\pi^{-1}(E) | E )")]]

#text("with the obvious restriction maps. In the case that ")#mi("{\\Omega,\\Omega^{\\prime}}")#text(" are standard Borel spaces, one can ")#emph[#text("disintegrate")]#text(" ")#mi("{\\mu^{\\prime}}")#text(" as an integral ")#mi("{\\mu^{\\prime} = \\int_\\Omega \\nu_\\omega\\ d\\mu(\\omega)}")#text(" of probability measures ")#mi("{\\nu_\\omega}")#text(" (supported in the fibre ")#mi("{\\pi^{-1}(\\{\\omega\\})}")#text("), in which case this stochastic set can be viewed as having fibres ")#mi("{L^2( \\tilde \\Omega, \\tilde {\\mathcal B}, \\nu_\\omega )}")#text(" (though if ")#mi("{\\Omega}")#text(" is not discrete, there are still some measurability conditions in ")#mi("{\\omega}")#text(" on the local and global elements that need to be imposed). However, I am interested in the case when ")#mi("{\\Omega,\\Omega^{\\prime}}")#text(" are not standard Borel spaces (in fact, I will take them to be algebraic probability spaces, as defined in ")#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("this previous post")]#text("), in which case disintegrations are not available. However, it appears that the stochastic analysis developed in this blog post can serve as a substitute for the tool of disintegration in this context.")
]

#text("We make the remark that if ")#mi("{X|\\Omega}")#text(" is a stochastic set and ")#mi("{E, F}")#text(" are events that are equivalent up to null events, then one can identify ")#mi("{\\Gamma(X|E)}")#text(" with ")#mi("{\\Gamma(X|F)}")#text(" (through their common restriction to ")#mi("{\\Gamma(X|(E \\cap F))}")#text(", with the restriction maps now being bijections). As such, the notion of a stochastic set does not require the full structure of a concrete probability space ")#mi("{(\\Omega, {\\mathcal B}, {\\mathbf P})}")#text("; one could also have defined the notion using only the abstract ")#mi("{\\sigma}")#text("-algebra consisting of ")#mi("{{\\mathcal B}}")#text(" modulo null events as the base space, or equivalently one could define stochastic sets over the algebraic probability spaces defined in ")#link("https://terrytao.wordpress.com/2014/06/28/algebraic-probability-spaces/")[#text("this previous post")]#text(". However, we will stick with the classical formalism of concrete probability spaces here so as to keep the notation reasonably familiar.")

#text("As a corollary of the above observation, we see that if the base space ")#mi("{\\Omega}")#text(" has total measure ")#mi("{0}")#text(", then all stochastic sets are trivial (they are just points).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" If ")#mi("{X|\\Omega}")#text(" is a stochastic set, show that there exists an event ")#mi("{\\Omega^{\\prime}}")#text(" with the property that for any event ")#mi("{E}")#text(", ")#mi("{\\Gamma(X|E)}")#text(" is non-empty if and only if ")#mi("{E}")#text(" is contained in ")#mi("{\\Omega^{\\prime}}")#text(" modulo null events. (In particular, ")#mi("{\\Omega^{\\prime}}")#text(" is unique up to null events.) ")#emph[#text("Hint:")]#text(" consider the numbers ")#mi("{\\mu( E )}")#text(" for ")#mi("{E}")#text(" ranging over all events with ")#mi("{\\Gamma(X|E)}")#text(" non-empty, and form a maximising sequence for these numbers. Then use all three axioms of a stochastic set.")
]

#text("One can now start take many of the fundamental objects, operations, and results in set theory (and, hence, in most other categories of mathematics) and establish analogues relative to a finite measure space. Implicitly, what we will be doing in the next few paragraphs is endowing the category of stochastic sets with the structure of an ")#link("http://en.wikipedia.org/wiki/Topos")[#text("elementary topos")]#text(". However, to keep things reasonably concrete, we will not explicitly emphasise the topos-theoretic formalism here, although it is certainly lurking in the background.")

#text("Firstly, we define a ")#emph[#text("stochastic function")]#text(" ")#mi("{f: X|\\Omega \\rightarrow Y|\\Omega}")#text(" between two stochastic sets ")#mi("{X|\\Omega, Y|\\Omega}")#text(" to be a collection of maps ")#mi("{f: \\Gamma(X|E) \\rightarrow \\Gamma(Y|E)}")#text(" for each ")#mi("{E \\in {\\mathcal B}}")#text(" which form a natural transformation in the sense that ")#mi("{f(x|E) = f(x)|E}")#text(" for all ")#mi("{x \\in \\Gamma(X|F)}")#text(" and nested events ")#mi("{E \\subset F}")#text(". In the case when ")#mi("{\\Omega}")#text(" is discrete and at most countable (and after deleting all null points), a stochastic function is nothing more than a collection of functions ")#mi("{f_\\omega: X_\\omega \\rightarrow Y_\\omega}")#text(" for each ")#mi("{\\omega \\in \\Omega}")#text(", with the function ")#mi("{f: \\Gamma(X|E) \\rightarrow \\Gamma(Y|E)}")#text(" then being a direct sum of the factor functions ")#mi("{f_\\omega}")#text(":")

#align(center)[#tao-fit-display[#mitex("f( (x_\\omega)_{\\omega \\in E} ) = ( f_\\omega(x_\\omega) )_{\\omega \\in E}.")]]

#text("Thus (in the discrete, at most countable setting, at least) stochastic functions do not mix together information from different states ")#mi("{\\omega}")#text(" in a sample space; the value of ")#mi("{f(x)}")#text(" at ")#mi("{\\omega}")#text(" depends only on the value of ")#mi("{x}")#text(" at ")#mi("{\\omega}")#text(". The situation is a bit more subtle for continuous probability spaces, due to the identification of stochastic objects that agree almost surely, nevertheness it is still good intuition to think of stochastic functions as essentially being “pointwise” or “local” in nature.")

#text("One can now form the stochastic set ")#mi("{\\text{Hom}(X \\rightarrow Y)|\\Omega}")#text(" of functions from ")#mi("{X|\\Omega}")#text(" to ")#mi("{Y|\\Omega}")#text(", by setting ")#mi("{\\Gamma(\\text{Hom}(X \\rightarrow Y)|E)}")#text(" for any event ")#mi("{E}")#text(" to be the set of local stochastic functions ")#mi("{f: X|E \\rightarrow Y|E}")#text(" of the localisations of ")#mi("{X|\\Omega, Y|\\Omega}")#text(" to ")#mi("{E}")#text("; this is a stochastic set if we use the obvious restriction maps. In the case when ")#mi("{\\Omega}")#text(" is discrete and at most countable, the fibre ")#mi("{\\text{Hom}(X \\rightarrow Y)_\\omega}")#text(" at a point ")#mi("{\\omega}")#text(" of positive measure is simply the set ")#mi("{Y_\\omega^{X_\\omega}}")#text(" of functions from ")#mi("{X_\\omega}")#text(" to ")#mi("{Y_\\omega}")#text(".")

#text("In a similar spirit, we say that one stochastic set ")#mi("{Y|\\Omega}")#text(" is a (stochastic) subset of another ")#mi("{X|\\Omega}")#text(", and write ")#mi("{Y|\\Omega \\subset X|\\Omega}")#text(", if we have a stochastic inclusion map, thus ")#mi("{\\Gamma(Y|E) \\subset \\Gamma(X|E)}")#text(" for all events ")#mi("{E}")#text(", with the restriction maps being compatible. We can then define the power set ")#mi("{2^X|\\Omega}")#text(" of a stochastic set ")#mi("{X|\\Omega}")#text(" by setting ")#mi("{\\Gamma(2^X|E)}")#text(" for any event ")#mi("{E}")#text(" to be the set of all stochastic subsets ")#mi("{Y|E}")#text(" of ")#mi("{X|E}")#text(" relative to ")#mi("{E}")#text("; it is easy to see that ")#mi("{2^X|\\Omega}")#text(" is a stochastic set with the obvious restriction maps (one can also identify ")#mi("{2^X|\\Omega}")#text(" with ")#mi("{\\text{Hom}(X, \\{\\text{true},\\text{false}\\})|\\Omega}")#text(" in the obvious fashion). Again, when ")#mi("{\\Omega}")#text(" is discrete and at most countable, the fibre of ")#mi("{2^X|\\Omega}")#text(" at a point ")#mi("{\\omega}")#text(" of positive measure is simply the deterministic power set ")#mi("{2^{X_\\omega}}")#text(".")

#text("Note that if ")#mi("{f: X|\\Omega \\rightarrow Y|\\Omega}")#text(" is a stochastic function and ")#mi("{Y^{\\prime}|\\Omega}")#text(" is a stochastic subset of ")#mi("{Y|\\Omega}")#text(", then the inverse image ")#mi("{f^{-1}(Y^{\\prime})|\\Omega}")#text(", defined by setting ")#mi("{\\Gamma(f^{-1}(Y^{\\prime})|E)}")#text(" for any event ")#mi("{E}")#text(" to be the set of those ")#mi("{x \\in \\Gamma(X|E)}")#text(" with ")#mi("{f(x) \\in \\Gamma(Y^{\\prime}|E)}")#text(", is a stochastic subset of ")#mi("{X|\\Omega}")#text(". In particular, given a ")#mi("{k}")#text("-ary relation ")#mi("{R: X_1 \\times \\dots \\times X_k|\\Omega \\rightarrow \\{\\text{true}, \\text{false}\\}|\\Omega}")#text(", the inverse image ")#mi("{R^{-1}( \\{ \\text{true} \\}|\\Omega )}")#text(" is a stochastic subset of ")#mi("{X_1 \\times \\dots \\times X_k|\\Omega}")#text(", which by abuse of notation we denote as")

#align(center)[#tao-fit-display[#mitex("\\{ (x_1,\\dots,x_k) \\in X_1 \\times \\dots \\times X_k: R(x_1,\\dots,x_k) \\text{ is true} \\}|\\Omega.")]]

#text("In a similar spirit, if ")#mi("{X^{\\prime}|\\Omega}")#text(" is a stochastic subset of ")#mi("{X|\\Omega}")#text(" and ")#mi("{f: X|\\Omega \\rightarrow Y|\\Omega}")#text(" is a stochastic function, we can define the image ")#mi("{f(X^{\\prime})|\\Omega}")#text(" by setting ")#mi("{\\Gamma(f(X^{\\prime})|E)}")#text(" to be the set of those ")#mi("{f(x)}")#text(" with ")#mi("{x \\in \\Gamma(X^{\\prime}|E)}")#text("; one easily verifies that this is a stochastic subset of ")#mi("{Y|\\Omega}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One should caution that in the definition of the subset relation ")#mi("{Y|\\Omega \\subset X|\\Omega}")#text(", it is important that ")#mi("{\\Gamma(Y|E) \\subset \\Gamma(X|E)}")#text(" for all events ")#mi("{E}")#text(", not just the global event ")#mi("{\\Omega}")#text("; in particular, just because a stochastic set ")#mi("{X|\\Omega}")#text(" has no global sections, does not mean that it is contained in the stochastic empty set ")#mi("{\\emptyset|\\Omega}")#text(".")
]

#text("Now we discuss Boolean operations on stochastic subsets of a given stochastic set ")#mi("{X|\\Omega}")#text(". Given two stochastic subsets ")#mi("{X_1|\\Omega, X_2|\\Omega}")#text(" of ")#mi("{X|\\Omega}")#text(", the stochastic intersection ")#mi("{(X_1 \\cap X_2)|\\Omega}")#text(" is defined by setting ")#mi("{\\Gamma((X_1 \\cap X_2)|E)}")#text(" to be the set of ")#mi("{x \\in \\Gamma(X|E)}")#text(" that lie in both ")#mi("{\\Gamma(X_1|E)}")#text(" and ")#mi("{\\Gamma(X_2|E)}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\Gamma(X_1 \\cap X_2)|E) := \\Gamma(X_1|E) \\cap \\Gamma(X_2|E).")]]

#text("This is easily verified to again be a stochastic subset of ")#mi("{X|\\Omega}")#text(". More generally one may define stochastic countable intersections ")#mi("{(\\bigcap_{n=1}^\\infty X_n)|\\Omega}")#text(" for any sequence ")#mi("{X_n|\\Omega}")#text(" of stochastic subsets of ")#mi("{X|\\Omega}")#text(". One ")#emph[#text("could")]#text(" extend this definition to uncountable families if one wished, but I would advise against it, because some of the usual laws of Boolean algebra (e.g. the de Morgan laws) may break down in this setting.")

#text("Stochastic unions are a bit more subtle. The set ")#mi("{\\Gamma((X_1 \\cup X_2)|E)}")#text(" should not be defined to simply be the union of ")#mi("{\\Gamma(X_1|E)}")#text(" and ")#mi("{\\Gamma(X_2|E)}")#text(", as this would not respect the gluing axiom. Instead, we define ")#mi("{\\Gamma((X_1 \\cup X_2)|E)}")#text(" to be the set of all ")#mi("{x \\in \\Gamma(X|E)}")#text(" such that one can cover ")#mi("{E}")#text(" by measurable subevents ")#mi("{E_1,E_2}")#text(" such that ")#mi("{x_i|E_i \\in \\Gamma(X_i|E_i)}")#text(" for ")#mi("{i=1,2}")#text("; then ")#mi("{(X_1 \\cup X_2)|\\Omega}")#text(" may be verified to be a stochastic subset of ")#mi("{X|\\Omega}")#text(". Thus for instance ")#mi("{\\{0,1\\}|\\Omega}")#text(" is the stochastic union of ")#mi("{\\{0\\}|\\Omega}")#text(" and ")#mi("{\\{1\\}|\\Omega}")#text(". Similarly for countable unions ")#mi("{(\\bigcup_{n=1}^\\infty X_n)|\\Omega}")#text(" of stochastic subsets ")#mi("{X_n|\\Omega}")#text(" of ")#mi("{X|\\Omega}")#text(", although for uncountable unions are extremely problematic (they are disliked by both the measure theory and the countable gluing axiom) and will not be defined here. Finally, the stochastic difference set ")#mi("{\\Gamma((X_1 \\backslash X_2)|E)}")#text(" is defined as the set of all ")#mi("{x|E}")#text(" in ")#mi("{\\Gamma(X_1|E)}")#text(" such that ")#mi("{x|F \\not \\in \\Gamma(X_2|F)}")#text(" for any subevent ")#mi("{F}")#text(" of ")#mi("{E}")#text(" of positive probability. One may verify that in the case when ")#mi("{\\Omega}")#text(" is discrete and at most countable, these Boolean operations correspond to the classical Boolean operations applied separately to each fibre ")#mi("{X_{i,\\omega}}")#text(" of the relevant sets ")#mi("{X_i}")#text(". We also leave as an exercise to the reader to verify the usual ")#link("http://en.wikipedia.org/wiki/Boolean_algebra#Laws")[#text("laws of Boolean arithmetic")]#text(", e.g. the ")#link("http://en.wikipedia.org/wiki/De_Morgan%27s_laws")[#text("de Morgan laws")]#text(", provided that one works with at most countable unions and intersections.")

#text("One can also consider a stochastic finite union ")#mi("{(\\bigcup_{n=1}^N X_n)|\\Omega}")#text(" in which the number ")#mi("{N}")#text(" of sets in the union is itself stochastic. More precisely, let ")#mi("{X|\\Omega}")#text(" be a stochastic set, let ")#mi("{N \\in {\\bf N}|\\Omega}")#text(" be a stochastic natural number, and let ")#mi("{n \\mapsto X_n|\\Omega}")#text(" be a stochastic function from the stochastic set ")#mi("{\\{ n \\in {\\bf N}: n \\leq N\\}|\\Omega}")#text(" (defined by setting ")#mi("{\\Gamma(\\{n \\in {\\bf N}: n\\leq N\\}|E) := \\{ n \\in {\\bf N}|E: n \\leq N|E\\}}")#text(")) to the stochastic power set ")#mi("{2^X|\\Omega}")#text(". Here we are considering ")#mi("{0}")#text(" to be a natural number, to allow for unions that are possibly empty, with ")#mi("{{\\bf N}_+ := {\\bf N} \\backslash \\{0\\}}")#text(" used for the positive natural numbers. We also write ")#mi("{(X_n)_{n=1}^N|\\Omega}")#text(" for the stochastic function ")#mi("{n \\mapsto X_n|\\Omega}")#text(". Then we can define the stochastic union ")#mi("{\\bigcup_{n=1}^N X_n|\\Omega}")#text(" by setting ")#mi("{\\Gamma(\\bigcup_{n=1}^N X_n|E)}")#text(" for an event ")#mi("{E}")#text(" to be the set of local elements ")#mi("{x \\in \\Gamma(X|E)}")#text(" with the property that there exists a covering of ")#mi("{E}")#text(" by measurable subevents ")#mi("{E_{n_0}}")#text(" for ")#mi("{n_0 \\in {\\bf N}_+}")#text(", such that one has ")#mi("{n_0 \\leq N|E_{n_0}}")#text(" and ")#mi("{x|E_{n_0} \\in \\Gamma(X_{n_0}|E_{n_0})}")#text(". One can verify that ")#mi("{\\bigcup_{n=1}^N X_n|\\Omega}")#text(" is a stochastic set (with the obvious restriction maps). Again, in the model case when ")#mi("{\\Omega}")#text(" is discrete and at most countable, the fibre ")#mi("{(\\bigcup_{n=1}^N X_n)_\\omega}")#text(" is what one would expect it to be, namely ")#mi("{\\bigcup_{n=1}^{N(\\omega)} (X_n)_\\omega}")#text(".")

#text("The Cartesian product ")#mi("{(X \\times Y)|\\Omega}")#text(" of two stochastic sets may be defined by setting ")#mi("{\\Gamma((X \\times Y)|E) := \\Gamma(X|E) \\times \\Gamma(Y|E)}")#text(" for all events ")#mi("{E}")#text(", with the obvious restriction maps; this is easily seen to be another stochastic set. This lets one define the concept of a ")#mi("{k}")#text("-ary operation ")#mi("{f: (X_1 \\times \\dots \\times X_k)|\\Omega \\rightarrow Y|\\Omega}")#text(" from ")#mi("{k}")#text(" stochastic sets ")#mi("{X_1,\\dots,X_k}")#text(" to another stochastic set ")#mi("{Y}")#text(", or a ")#mi("{k}")#text("-ary relation ")#mi("{R: (X_1 \\times \\dots \\times X_k)|\\Omega \\rightarrow \\{\\text{true}, \\text{false}\\}|\\Omega}")#text(". In particular, given ")#mi("{x_i \\in X_i|\\Omega}")#text(" for ")#mi("{i=1,\\dots,k}")#text(", the relation ")#mi("{R(x_1,\\dots,x_k)}")#text(" may be deterministically true, deterministically false, or have some other stochastic truth value.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" In the degenerate case when ")#mi("{\\Omega}")#text(" is null, stochastic logic becomes a bit weird: all stochastic statements are deterministically true, as are their stochastic negations, since every event in ")#mi("{\\Omega}")#text(" (even the empty set) now holds with full probability. Among other pathologies, the empty set now has a global element over ")#mi("{\\Omega}")#text(" (this is analogous to the notorious convention ")#mi("{0^0=1}")#text("), and any two deterministic objects ")#mi("{x,y}")#text(" become equal over ")#mi("{\\Omega}")#text(": ")#mi("{x|\\Omega=y|\\Omega}")#text(".")
]

#text("The following simple observation is crucial to subsequent discussion. If ")#mi("{(x_n)_{n \\in {\\bf N}_+}}")#text(" is a sequence taking values in the global elements ")#mi("{\\Gamma(X|\\Omega)}")#text(" of a stochastic space ")#mi("{X|\\Omega}")#text(", then we may also define global elements ")#mi("{x_n \\in \\Gamma(X|\\Omega)}")#text(" for ")#emph[#text("stochastic")]#text(" indices ")#mi("{n \\in {\\bf N}_+|\\Omega}")#text(" as well, by appealing to the countable gluing axiom to glue together ")#mi("{x_{n_0}}")#text(" restricted to the set ")#mi("{\\{ \\omega \\in \\Omega: n(\\omega) = n_0\\}}")#text(" for each deterministic natural number ")#mi("{n_0}")#text(" to form ")#mi("{x_n}")#text(". With this definition, the map ")#mi("{n \\mapsto x_n}")#text(" is a stochastic function from ")#mi("{{\\bf N}_+|\\Omega}")#text(" to ")#mi("{X|\\Omega}")#text("; indeed, this creates a one-to-one correspondence between external sequences (maps ")#mi("{n \\mapsto x_n}")#text(" from ")#mi("{{\\bf N}_+}")#text(" to ")#mi("{\\Gamma(X|\\Omega)}")#text(") and stochastic sequences (stochastic functions ")#mi("{n \\mapsto x_n}")#text(" from ")#mi("{{\\bf N}_+|\\Omega}")#text(" to ")#mi("{X|\\Omega}")#text("). Similarly with ")#mi("{{\\bf N}_+}")#text(" replaced by any other at most countable set. This observation will be important in allowing many deterministic arguments involving sequences will be able to be carried over to the stochastic setting.")

#text("We now specialise from the extremely broad discipline of set theory to the more focused discipline of real analysis. There are two fundamental axioms that underlie real analysis (and in particular distinguishes it from real ")#emph[#text("algebra")]#text("). The first is the ")#link("http://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean property")]#text(", which we phrase in the “no infinitesimal” formulation as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Archimedean property)")]#text(" Let ")#mi("{x \\in {\\bf R}}")#text(" be such that ")#mi("{x \\leq 1/n}")#text(" for all positive natural numbers ")#mi("{n}")#text(". Then ")#mi("{x \\leq 0}")#text(".")
]

#text("The other is the ")#link("http://en.wikipedia.org/wiki/Least_upper_bound_axiom")[#text("least upper bound axiom")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Least upper bound axiom)")]#text(" ")#metadata(none) <tao-d0afe5ed2bd67151d4dd>#text(" Let ")#mi("{S}")#text(" be a non-empty subset of ")#mi("{{\\bf R}}")#text(" which has an upper bound ")#mi("{M \\in {\\bf R}}")#text(", thus ")#mi("{x \\leq M}")#text(" for all ")#mi("{x \\in S}")#text(". Then there exists a unique real number ")#mi("{\\sup S \\in {\\bf R}}")#text(" with the following properties:")

#list(
[#mi("{x \\leq \\sup S}")#text(" for all ")#mi("{x \\in S}")#text(".")],
[#text("For any real ")#mi("{L < \\sup S}")#text(", there exists ")#mi("{x \\in S}")#text(" such that ")#mi("{L < x \\leq \\sup S}")#text(".")],
[#mi("{\\sup S \\leq M}")#text(".")]
)

#text("Furthermore, ")#mi("{\\sup S}")#text(" does not depend on the choice of ")#mi("{M}")#text(".")
]

#text("The Archimedean property extends easily to the stochastic setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4 (Stochastic Archimedean property)")]#text(" ")#metadata(none) <tao-7a9c94a8c201bcc22857>#text(" Let ")#mi("{x \\in \\Gamma({\\bf R}|\\Omega)}")#text(" be such that ")#mi("{x \\leq 1/n}")#text(" for all deterministic natural numbers ")#mi("{n}")#text(". Then ")#mi("{x \\leq 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Here, incidentally, is one place in which this stochastic formalism deviates from the nonstandard analysis formalism, as the latter certainly permits the existence of infinitesimal elements. On the other hand, we caution that stochastic real numbers are permitted to be unbounded, so that formulation of Archimedean property is not valid in the stochastic setting.")
]

#text("The proof is easy and is left to the reader. The least upper bound axiom also extends nicely to the stochastic setting, but the proof requires more work (in particular, our argument uses the monotone convergence theorem):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Stochastic least upper bound axiom)")]#text(" ")#metadata(none) <tao-4518761c6486a56ae336>#text(" Let ")#mi("{S|\\Omega}")#text(" be a stochastic subset of ")#mi("{{\\bf R}|\\Omega}")#text(" which has a global upper bound ")#mi("{M \\in {\\bf R}|\\Omega}")#text(", thus ")#mi("{x \\leq M}")#text(" for all ")#mi("{x \\in \\Gamma(S|\\Omega)}")#text(", and is globally non-empty in the sense that there is at least one global element ")#mi("{x \\in \\Gamma(S|\\Omega)}")#text(". Then there exists a unique stochastic real number ")#mi("{\\sup S \\in \\Gamma({\\bf R}|\\Omega)}")#text(" with the following properties:")

#list(
[#mi("{x \\leq \\sup S}")#text(" for all ")#mi("{x \\in \\Gamma(S|\\Omega)}")#text(".")],
[#text("For any stochastic real ")#mi("{L < \\sup S}")#text(", there exists ")#mi("{x \\in \\Gamma(S|\\Omega)}")#text(" such that ")#mi("{L < x \\leq \\sup S}")#text(".")],
[#mi("{\\sup S \\leq M}")#text(".")]
)

#text("Furthermore, ")#mi("{\\sup S}")#text(" does not depend on the choice of ")#mi("{M}")#text(".")
]

#text("For future reference, we note that the same result holds with ")#mi("{{\\bf R}}")#text(" replaced by ")#mi("{{\\bf N} \\cup \\{+\\infty\\}}")#text(" throughout, since the latter may be embedded in the former, for instance by mapping ")#mi("{n}")#text(" to ")#mi("{1 - \\frac{1}{n+1}}")#text(" and ")#mi("{+\\infty}")#text(" to ")#mi("{1}")#text(". In applications, the above theorem serves as a reasonable substitute for the countable axiom of choice, which does not appear to hold in unrestricted generality relative to a measure space; in particular, it can be used to generate various extremising sequences for stochastic functionals on various stochastic function spaces.")

#emph[#text("Proof:")]#text(" Uniqueness is clear (using the Archimedean property), as well as the independence on ")#mi("{M}")#text(", so we turn to existence. By using an order-preserving map from ")#mi("{{\\bf R}}")#text(" to ")#mi("{(-1,1)}")#text(" (e.g. ")#mi("{x \\mapsto \\frac{2}{\\pi} \\text{arctan}(x)}")#text(") we may assume that ")#mi("{S|\\Omega}")#text(" is a subset of ")#mi("{(-1,1)|\\Omega}")#text(", and that ")#mi("{M < 1}")#text(".")

#text("We observe that ")#mi("{\\Gamma(S|\\Omega)}")#text(" is a lattice: if ")#mi("{x, y \\in \\Gamma(S|\\Omega)}")#text(", then ")#mi("{\\max(x,y)}")#text(" and ")#mi("{\\min(x,y)}")#text(" also lie in ")#mi("{\\Gamma(S|\\Omega)}")#text(". Indeed, ")#mi("{\\max(x,y)}")#text(" may be formed by appealing to the countable gluing axiom to glue ")#mi("{y}")#text(" (restricted the set ")#mi("{\\{ \\omega \\in \\Omega: x(\\omega) < y(\\omega) \\}}")#text(") with ")#mi("{x}")#text(" (restricted to the set ")#mi("{\\{ \\omega \\in \\Omega: x(\\omega) \\geq y(\\omega) \\}}")#text("), and similarly for ")#mi("{\\min(x,y)}")#text(". (Here we use the fact that relations such as ")#mi("{<}")#text(" are Borel measurable on ")#mi("{{\\bf R}}")#text(".)")

#text("Let ")#mi("{A \\in {\\bf R}}")#text(" denote the deterministic quantity")

#align(center)[#tao-fit-display[#mitex("A := \\sup \\{ \\int_\\Omega x(\\omega)\\ d\\mu(\\omega): x \\in \\Gamma(S|\\Omega) \\}")]]

#text("then (by Proposition ")#link(<tao-d0afe5ed2bd67151d4dd>)[#text("3")]#text("!) ")#mi("{A}")#text(" is well-defined; here we use the hypothesis that ")#mi("{\\mu(\\Omega)}")#text(" is finite. Thus we may find a sequence ")#mi("{(x_n)_{n \\in {\\bf N}}}")#text(" of elements ")#mi("{x_n}")#text(" of ")#mi("{\\Gamma(S|\\Omega)}")#text(" such that ")#metadata(none) <tao-a700b5e5ac5b7a657654>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\int_\\Omega x_n(\\omega)\\ d\\mu(\\omega) \\rightarrow A \\text{ as } n \\rightarrow \\infty.")]]

#text("Using the lattice property, we may assume that the ")#mi("{x_n}")#text(" are non-decreasing: ")#mi("{x_n \\leq x_m}")#text(" whenever ")#mi("{n \\leq m}")#text(". If we then define ")#mi("{\\sup S(\\omega) := \\sup_n x_n(\\omega)}")#text(" (after choosing measurable representatives of each equivalence class ")#mi("{x_n}")#text("), then ")#mi("{\\sup S}")#text(" is a stochastic real with ")#mi("{\\sup S \\leq M}")#text(".")

#text("If ")#mi("{x \\in \\Gamma(S|\\Omega)}")#text(", then ")#mi("{\\max(x,x_n) \\in \\Gamma(S|\\Omega)}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\max(x,x_n)\\ d\\mu(\\omega) \\leq A.")]]

#text("From this and ")#link(<tao-a700b5e5ac5b7a657654>)[#text("(1)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\max(x-x_n,0) \\rightarrow 0 \\text{ as } n \\rightarrow \\infty.")]]

#text("From monotone convergence, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_\\Omega \\max(x-\\sup S,0) = 0")]]

#text("and so ")#mi("{x \\leq \\sup S}")#text(", as required.")

#text("Now let ")#mi("{L < \\sup S}")#text(" be a stochastic real. After choosing measurable representatives of each relevant equivalence class, we see that for almost every ")#mi("{\\omega \\in \\Omega}")#text(", we can find a natural number ")#mi("{n(\\omega)}")#text(" with ")#mi("{x_{n(\\omega)} > L}")#text(". If we choose ")#mi("{n(\\omega)}")#text(" to be the first such positive natural number when it exists, and (say) ")#mi("{1}")#text(" otherwise, then ")#mi("{n}")#text(" is a stochastic positive natural number and ")#mi("{L < x_n}")#text(". The claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" One can abstract away the role of the measure ")#mi("{\\mu}")#text(" here, leaving only the ideal of null sets. The property that the measure is finite is then replaced by the more general property that given any non-empty family of measurable sets, there is an at most countable union of sets in that family that is an upper bound modulo null sets for all elements in that faily.")
]

#text("Using Proposition ")#link(<tao-7a9c94a8c201bcc22857>)[#text("4")]#text(" and Theorem ")#link(<tao-4518761c6486a56ae336>)[#text("5")]#text(", one can then revisit many of the other foundational results of deterministic real analysis, and develop stochastic analogues; we give some examples of this below the fold (focusing on the Heine-Borel theorem and a case of the spectral theorem). As an application of this formalism, we revisit some of the Furstenberg-Zimmer structural theory of measure-preserving systems, particularly that of relatively compact and relatively weakly mixing systems, and interpret them in this framework, basically as stochastic versions of compact and weakly mixing systems (though with the caveat that the shift map is allowed to act non-trivially on the underlying probability space). As this formalism is “point-free”, in that it avoids explicit use of fibres and disintegrations, it will be well suited for generalising this structure theory to settings in which the underlying probability spaces are not standard Borel, and the underlying groups are uncountable; I hope to discuss such generalisations in future blog posts.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" Roughly speaking, stochastic real analysis can be viewed as a restricted subset of classical real analysis in which all operations have to be “measurable” with respect to the base space. In particular, indiscriminate application of the axiom of choice is not permitted, and one should largely restrict oneself to performing countable unions and intersections rather than arbitrary unions or intersections. Presumably one can formalise this intuition with a suitable “countable transfer principle”, but I was not able to formulate a clean and general principle of this sort, instead verifying various assertions about stochastic objects by hand rather than by direct transfer from the deterministic setting. However, it would be desirable to have such a principle, since otherwise one is faced with the tedious task of redoing all the foundations of real analysis (or whatever other base theory of mathematics one is going to be working in) in the stochastic setting by carefully repeating all the arguments.")

#text("More generally, topos theory is a good formalism for capturing precisely the informal idea of performing mathematics with certain operations, such as the axiom of choice, the law of the excluded middle, or arbitrary unions and intersections, being somehow “prohibited” or otherwise “restricted”.")
]

#heading(level: 1)[#strong[#text(" — 1. Metric spaces relative to a finite measure space — ")]]

#text("The definition of a metric space carries over in the obvious fashion to the stochastic setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 6 (Stochastic metric spaces)")]#text(" A ")#emph[#text("stochastic metric space")]#text(" ")#mi("{X|\\Omega = (X|\\Omega,d)}")#text(" is defined to be a stochastic set ")#mi("{X|\\Omega}")#text(", together with a stochastic function ")#mi("{d: X|\\Omega \\times X|\\Omega \\rightarrow [0,+\\infty)|\\Omega}")#text(" that obeys the following axioms for each event ")#mi("{\\Omega^{\\prime}}")#text(":")

#list(
[#text("(Non-degeneracy) If ")#mi("{x,y \\in X|\\Omega^{\\prime}}")#text(", then ")#mi("{d(x,y)=0}")#text(" if and only if ")#mi("{x=y}")#text(".")],
[#text("(Symmetry) If ")#mi("{x,y \\in X|\\Omega^{\\prime}}")#text(", then ")#mi("{d(x,y) = d(y,x)}")#text(".")],
[#text("(Triangle inequality) If ")#mi("{x,y,z \\in X|\\Omega^{\\prime}}")#text(", then ")#mi("{d(x,z) \\leq d(x,y)+d(y,z)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" One could potentially interpret the non-degeneracy axiom in two ways; either deterministically (")#mi("{d(x,y)=0}")#text(" is deterministically true if and only if ")#mi("{x=y}")#text(" is deterministically true) or stochastically (“")#mi("{d(x,y)=0}")#text(" if and only if ")#mi("{x=y}")#text("” is deterministically true). However, it is easy to see by a gluing argument that the two interpretations are logically equivalent. Also, if ")#mi("{X|\\Omega}")#text(" is globally non-empty, then one only needs to verify the metric space axioms for ")#mi("{\\Omega^{\\prime}=\\Omega}")#text(", as one can then obtain the ")#mi("{\\Omega^{\\prime} \\subsetneq \\Omega}")#text(" cases by gluing with a global section on ")#mi("{\\Omega \\backslash \\Omega^{\\prime}}")#text(". However, when ")#mi("{X|\\Omega}")#text(" has no global elements, it becomes necessary to work locally.")
]

#text("Note that if ")#mi("{(X,d)}")#text(" is a deterministic measurable metric space (thus ")#mi("{X}")#text(" is a measurable space equipped with a measurable metric ")#mi("{d}")#text("), then its stochastic counterpart ")#mi("{(X|\\Omega, d)}")#text(" is a stochastic metric space. (As usual, we do not attempt to interpret ")#mi("{(X|\\Omega, d)}")#text(" when there is no measurable structure present for ")#mi("{X}")#text(".) In the case of a discrete at most countable ")#mi("{\\Omega}")#text(" (and after deleting any points of measure zero), a stochastic metric space ")#mi("{(X|\\Omega,d)}")#text(" is essentially just a bundle ")#mi("{(X_\\omega,d_\\omega)_{\\omega \\in \\Omega}}")#text(" of metric spaces, with no relations constraining these metric spaces with each other (for instance, the cardinality of ")#mi("{X_\\omega}")#text(" may vary arbitrarily with ")#mi("{\\omega}")#text(").")

#text("We extend the notion of convergence in stochastic metric spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7 (Stochastic convergence)")]#text(" Let ")#mi("{X|\\Omega = (X|\\Omega,d)}")#text(" be a stochastic metric space, and let ")#mi("{(x_n)_{n \\in {\\bf N}_+}}")#text(" be a sequence in ")#mi("{\\Gamma(X|\\Omega)}")#text(" (which, as discussed earlier, may be viewed as a stochastic function ")#mi("{n \\mapsto x_n}")#text(" from ")#mi("{{\\bf N}_+|\\Omega}")#text(" to ")#mi("{X|\\Omega}")#text("). Let ")#mi("{x}")#text(" be an element of ")#mi("{\\Gamma(X|\\Omega)}")#text(".")

#list(
[#text("We say that ")#mi("{x_n}")#text(" ")#emph[#text("stochastically converges")]#text(" to ")#mi("{x}")#text(" if, for every stochastic real ")#mi("{\\epsilon>0}")#text(", there exists a stochastic positive natural number ")#mi("{N \\in {\\bf N}_+|\\Omega}")#text(" such that ")#mi("{d(x_n,x) < \\epsilon}")#text(" for all stochastic positive natural numbers ")#mi("{n \\in {\\bf N}_+|\\Omega}")#text(" with ")#mi("{n \\geq N}")#text(".")],
[#text("We say that ")#mi("{x_n}")#text(" is ")#emph[#text("stochastically Cauchy")]#text(" if, for every stochastic real ")#mi("{\\epsilon>0}")#text(", there exists a stochastic natural number ")#mi("{N \\in {\\bf N}_+|\\Omega}")#text(" such that ")#mi("{d(x_n,x_m) < \\epsilon}")#text(" for all stochastic natural numbers ")#mi("{n,m \\in {\\bf N}_+|\\Omega}")#text(" with ")#mi("{n,m \\geq N}")#text(".")],
[#text("We say that ")#mi("{X|\\Omega}")#text(" is ")#emph[#text("stochastically complete")]#text(" if every stochastically Cauchy sequence is stochastically convergent, and furthermore for any event ")#mi("{\\Omega^{\\prime}}")#text(" in ")#mi("{\\Omega}")#text(", any stochastically Cauchy sequence relative to ")#mi("{\\Omega^{\\prime}}")#text(" is stochastically convergent relative to ")#mi("{\\Omega^{\\prime}}")#text(".")]
)
]

#text("As usual, the additional localisation in the definition of stochastic completeness to an event ")#mi("{\\Omega^{\\prime}}")#text(" is needed to avoid a stochastic set being stochastically complete for the trivial reason that one of its fibres happens to be empty, so that there are no global elements of the stochastic set, only local elements. (This localisation is not needed for the notions of stochastic convergence or the stochastic Cauchy property, as these automatically are preserved by localisation.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Show that to verify stochastic convergence, it suffices to restrict attention to errors ")#mi("{\\epsilon}")#text(" of the form ")#mi("{\\epsilon = 1/m}")#text(" for deterministic positive natural numbers ")#mi("{m}")#text(". Similarly for the stochastically Cauchy property.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{X}")#text(" be a measurable metric space. Show that ")#mi("{X|\\Omega}")#text(" is stochastically complete if and only if ")#mi("{X}")#text(" is complete. Thus for instance ")#mi("{{\\bf R}|\\Omega}")#text(" is stochastically complete.")
]

#text("In the case when ")#mi("{\\Omega}")#text(" is discrete and at most countable, or when ")#mi("{X|\\Omega}")#text(" is the stochastic version of a deterministic measurable space ")#mi("{X}")#text(", stochastic convergence is just the familiar notion of almost sure convergence: ")#mi("{x_n \\in \\Gamma(X|\\Omega)}")#text(" converges stochastically to ")#mi("{x \\in \\Gamma(X|\\Omega)}")#text(" if and only if, for almost every ")#mi("{\\omega \\in \\Omega}")#text(", ")#mi("{x_n(\\omega)}")#text(" converges to ")#mi("{x(\\omega)}")#text(" in ")#mi("{X_\\omega}")#text(". There is no uniformity of convergence in the ")#mi("{\\omega}")#text(" parameter; such a uniformity could be imposed by requiring the quantity ")#mi("{N}")#text(" in the above definition to be a deterministic natural number rather than a stochastic one, but we will not need this notion here. Similarly for the stochastic Cauchy property. Stochastic completeness in this context is then equivalent to completeness of ")#mi("{X_\\omega}")#text(" for each ")#mi("{\\omega}")#text(" that occurs with positive probability. (As noted previously, it is important here that we define stochastic completeness with localisation, in case some of the fibres ")#mi("{X_\\omega}")#text(" are empty.)")

#text("In a stochastic metric space ")#mi("{X|\\Omega}")#text(", we can form the balls ")#mi("{B(x,r)|\\Omega}")#text(" for any ")#mi("{x \\in \\Gamma(X|\\Omega)}")#text(" and stochastic real ")#mi("{r>0}")#text(", by setting ")#mi("{\\Gamma(B(x,r)|E)}")#text(" to be the set of all ")#mi("{y \\in \\Gamma(X|E)}")#text(" such that ")#mi("{d(x,y) < r}")#text(" locally on ")#mi("{E}")#text("; these are stochastic subsets of ")#mi("{X|\\Omega}")#text(" (indeed, ")#mi("{B(x,r)}")#text(" is the inverse image of ")#mi("{\\{ r^{\\prime} \\in [0,+\\infty): r^{\\prime} < r \\}|\\Omega}")#text(" under the pinned distance map ")#mi("{y \\mapsto d(x,y)}")#text(").")

#text("By chasing the definitions, we see that if ")#mi("{(x_n)_{n \\in {\\bf N}_+}}")#text(" is a sequence of elements ")#mi("{x_n \\in \\Gamma(X|\\Omega)}")#text(" of a stochastic metric space ")#mi("{X|\\Omega}")#text(", and ")#mi("{x}")#text(" is an element of ")#mi("{\\Gamma(X|\\Omega)}")#text(", then ")#mi("{x_n}")#text(" stochastically converges to ")#mi("{x}")#text(" if and only if, for every stochastic ")#mi("{\\epsilon>0}")#text(", there exists a stochastic natural positive number ")#mi("{N \\in \\Gamma({\\bf N}_+|\\Omega)}")#text(" such that ")#mi("{x_n \\in \\Gamma(B(x,\\epsilon)|\\Omega)}")#text(" for all stochastic positive natural numbers ")#mi("{n \\geq N}")#text(".")

#text("Given a sequence ")#mi("{(x_n)_{n \\in {\\bf N}_+}}")#text(" of elements ")#mi("{x_n \\in \\Gamma(X|\\Omega)}")#text(" of a stochastic metric space ")#mi("{X|\\Omega}")#text(", we define a ")#emph[#text("stochastic subsequence")]#text(" ")#mi("{(x_{n_j})_{j \\in {\\bf N}_+}}")#text(" to be a sequence of the form ")#mi("{j \\mapsto x_{n_j}}")#text(", where ")#mi("{(n_j)_{j \\in {\\bf N}_+}}")#text(" is a sequence of stochastic natural numbers ")#mi("{n_j \\in {\\bf N}_+|\\Omega}")#text(", which stochastically go to infinity in the following sense: for every stochastic positive natural number ")#mi("{N \\in \\Gamma({\\bf N}_+|\\Omega)}")#text(", there exists a stochastic positive natural number ")#mi("{J}")#text(" such that ")#mi("{n_j \\geq N}")#text(" for all stochastic positive natural numbers ")#mi("{j \\geq J}")#text(". Note that when ")#mi("{\\Omega}")#text(" is discrete and at most countable, this operation corresponds to selecting a subsequence ")#mi("{(x_{n_j(\\omega),\\omega})_{j \\in {\\bf N}_+}}")#text(" of ")#mi("{(x_{n,\\omega})_{n \\in {\\bf N}_+}}")#text(" for each ")#mi("{\\omega}")#text(" occurring with positive probability, with the indices ")#mi("{n_j(\\omega)}")#text(" of the subsequence permitted to vary in ")#mi("{\\omega}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-3f22f007dace5d04260f>#text(" Let ")#mi("{(x_n)_{n \\in{\\bf N}_+}}")#text(" be a sequence of elements ")#mi("{\\Gamma(X|\\Omega)}")#text(" of a stochastic metric space ")#mi("{X|\\Omega}")#text(", and let ")#mi("{x \\in \\Gamma(X|\\Omega)}")#text(".")

#list(
[#text("(i) Show that ")#mi("{x_n}")#text(" can converge stochastically to at most one element of ")#mi("{\\Gamma(X|\\Omega)}")#text(".")],
[#text("(ii) Show that if ")#mi("{x_n}")#text(" converges stochastically to ")#mi("{x}")#text(", then every stochastic subsequence ")#mi("{(x_{n_j})_{j \\in {\\bf N}_+}}")#text(" also converges stochastically to ")#mi("{x}")#text(".")],
[#text("(iii) Show that if ")#mi("{x_n}")#text(" is stochastically Cauchy, and some stochastic subsequence of ")#mi("{x_n}")#text(" converges stochastically to ")#mi("{x}")#text(", then the entire sequence ")#mi("{x_n}")#text(" converges stochastically to ")#mi("{x}")#text(".")],
[#text("(iv) Show that there exists an event ")#mi("{E}")#text(", unique up to null events, with the property that ")#mi("{x_n|E}")#text(" converges stochastically to ")#mi("{x|E}")#text(", and that there exists a stochastic ")#mi("{\\epsilon>0}")#text(" over the complement ")#mi("{E^c}")#text(" of ")#mi("{E}")#text(", with the property that for any stochastic natural number ")#mi("{N|E^c}")#text(" on ")#mi("{E^c}")#text(", there exists ")#mi("{n|E^c \\geq N|E^c}")#text(" such that ")#mi("{d(x,x_n)|E^c \\geq \\epsilon}")#text(". (Informally, ")#mi("{E}")#text(" is the set of states for which ")#mi("{x_n}")#text(" converges to ")#mi("{x}")#text("; the key point is that this set is automatically measurable.)")],
[#text("(v) (Urysohn subsequence principle) Show that ")#mi("{x_n}")#text(" converges stochastically to ")#mi("{x}")#text(" if and only if every stochastic subsequence ")#mi("{(x_{n_j})_{j \\in {\\bf N}_+}}")#text(" of ")#mi("{(x_n)_{n \\in {\\bf N}_+}}")#text(" has a further stochastic subsequence ")#mi("{(x_{n_{j_k}})_{k \\in {\\bf N}_+}}")#text(" that converges stochastically to ")#mi("{x}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" All of these exercises can be established through consideration of the events ")#mi("{E_{n,k}}")#text(" for ")#mi("{n,k \\in {\\bf N}_+}")#text(", defined up to null events as the event that ")#mi("{d( x_n, x ) < \\frac{1}{k}}")#text(" holds stochastically.)")
]

#text("Next, we define the stochastic counterpart of total boundedness.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8 (Total boundedness)")]#text(" A stochastic metric space ")#mi("{X|\\Omega}")#text(" is said to be ")#emph[#text("stochastically totally bounded")]#text(" if, for every stochastic real ")#mi("{\\epsilon>0}")#text(", there exists a stochastic natural number ")#mi("{N \\in {\\bf N}|\\Omega}")#text(" and a stochastic function ")#mi("{n \\mapsto x_n}")#text(" from the stochastic set ")#mi("{\\{ n \\in {\\bf N}_+: n \\leq N \\}|\\Omega}")#text(" to ")#mi("{X|\\Omega}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("X|\\Omega = \\bigcup_{n=1}^N B(x_n,\\epsilon)|\\Omega.")]]

#text("(Note that we allow ")#mi("{N}")#text(" to be zero locally or globally; thus for instance the empty set ")#mi("{\\emptyset|\\Omega}")#text(" is considered to be totally bounded.) We will denote this stochastic function ")#mi("{n \\mapsto x_n}")#text(" as ")#mi("{(x_n)_{n=1}^N|\\Omega}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" If ")#mi("{\\Omega}")#text(" is discrete and at most countable, show that ")#mi("{X|\\Omega}")#text(" is stochastically totally bounded if and only if for each ")#mi("{\\omega}")#text(" of positive probability, the fibre ")#mi("{X_\\omega}")#text(" is totally bounded in the deterministic sense.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" ")#metadata(none) <tao-7aa5ae9ecf82f6fc5208>#text(" Show that to verify the stochastic total boundedness of a stochastic metric space, it suffices to do so for parameters ")#mi("{\\epsilon}")#text(" of the form ")#mi("{\\epsilon=1/k}")#text(" for some deterministic positive natural number ")#mi("{k}")#text(".")
]

#text("We have a stochastic version of (a fragment of) the ")#link("http://en.wikipedia.org/wiki/Heine-borel_theorem")[#text("Heine-Borel theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Stochastic Heine-Borel theorem)")]#text(" ")#metadata(none) <tao-a523f355a7725c8aeca6>#text(" Let ")#mi("{X|\\Omega}")#text(" be a stochastic metric space. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{X|\\Omega}")#text(" is stochastically complete and stochastically totally bounded.")],
[#text("(ii) Every sequence in ")#mi("{\\Gamma(X|\\Omega)}")#text(" has a stochastic subsequence that is stochastically convergent. Furthermore, for any event ")#mi("{\\Omega^{\\prime}}")#text(", every sequence in ")#mi("{\\Gamma(X|\\Omega^{\\prime})}")#text(" has a stochastic subsequence that is stochastically convergent relative to ")#mi("{\\Omega^{\\prime}}")#text(".")]
)
]

#text("As with the definition of stochastic completeness, the second part of (ii) is necessary: if for instance ")#mi("{\\Omega}")#text(" is discrete and countable, and one of the fibres ")#mi("{X_\\omega}")#text(" happens to be empty, then there are no global elements of ")#mi("{X|\\Omega}")#text(" and the first part of (ii) becomes trivially true, even if other fibres of ")#mi("{X_\\omega}")#text(" fail to be complete or totally bounded.")

#text("Inspired by the above theorem, we will call a stochastic metric space ")#mi("{X|\\Omega}")#text(" ")#emph[#text("stochastically compact")]#text(" if (i) or (ii) holds. Note that this only recovers a fragment of the deterministic Heine-Borel theorem, as the characterisation of compactness in terms of open covers is missing. I was not able to set up a characterisation of this form, since one was only allowed to use countable unions; but perhaps some version of this characterisation can be salvaged.")

#emph[#text("Proof:")]#text(" The basic idea here is to mimic the classical proof of this fragment of the Heine-Borel theorem, taking care to avoid any internal appeal to the countable axiom of choice in order to keep everything measurable. (However, we can and will use the axiom of countable choice ")#emph[#text("externally")]#text(" in the ambient set theory.)")

#text("Suppose first that ")#mi("{X|\\Omega}")#text(" fails to be stochastically complete. Then we can find an event ")#mi("{\\Omega^{\\prime}}")#text(" and a stochastically Cauchy sequence ")#mi("{x_n \\in \\Gamma(X|\\Omega^{\\prime})}")#text(" for ")#mi("{n \\in {\\bf N}}")#text(" that fails to be stochastically convergent in ")#mi("{\\Gamma(X|\\Omega^{\\prime})}")#text(". By Exercise ")#link(<tao-3f22f007dace5d04260f>)[#text("5")]#text(", no stochastic subsequence of ")#mi("{x_n}")#text(" can be stochastically convergent in ")#mi("{X|\\Omega^{\\prime}}")#text(" either, and so (ii) fails.")

#text("Now suppose that ")#mi("{X|\\Omega}")#text(" fails to be stochastically bounded. Then one can find a stochastic real number ")#mi("{\\epsilon>0}")#text(", such that it is not possible to find any stochastic natural number ")#mi("{N \\in \\Gamma({\\bf N}|\\Omega)}")#text(" and a stochastic sequence ")#mi("{(x_n)_{n=1}^N|\\Omega}")#text(" (that is, a stochastic function ")#mi("{n \\mapsto x_n}")#text(" from ")#mi("{\\{ n \\in {\\bf N}_+: n \\leq N \\}|\\Omega}")#text(" to ")#mi("{X|\\Omega}")#text("), such that")

#align(center)[#tao-fit-display[#mitex("X|\\Omega = \\bigcup_{n=1}^N B(x_n,\\epsilon)|\\Omega.")]]

#text("(By Exercise ")#link(<tao-7aa5ae9ecf82f6fc5208>)[#text("7")]#text(" one could take ")#mi("{\\epsilon=1/k}")#text(" for a deterministic positive natural ")#mi("{k}")#text(", but we will not need to do so here.)")

#text("Let ")#mi("{S}")#text(" be the set of those ")#mi("{N \\in \\Gamma({\\bf N}|\\Omega)}")#text(" for which one can find a stochastic sequence ")#mi("{(x_n)_{n=1}^N|\\Omega}")#text(" which is ")#emph[#mi("{\\epsilon}")#text("-separated")]#text(" in the sense that ")#mi("{d(x_n,x_m) \\geq \\epsilon}")#text(" for all distinct ")#mi("{n,m \\in {\\bf N}_+|\\Omega}")#text(" with ")#mi("{n,m \\leq N}")#text(", and more generally for any event ")#mi("{\\Omega^{\\prime}}")#text(", that ")#mi("{d(x_n,x_m) \\geq \\epsilon}")#text(" relative to ")#mi("{\\Omega^{\\prime}}")#text(" for all distinct ")#mi("{n,m \\in{\\bf N}_+|\\Omega^{\\prime}}")#text(" with ")#mi("{n,m \\leq N|\\Omega^{\\prime}}")#text(". (We need to relativise to ")#mi("{\\Omega^{\\prime}}")#text(" here to properly manage the case that ")#mi("{N}")#text(" sometimes vanishes.) It is easy to see that ")#mi("{S}")#text(" can be given the structure of a stochastic subset of ")#mi("{{\\bf N}|\\Omega}")#text(", and contains ")#mi("{0|\\Omega}")#text(". By Theorem ")#link(<tao-4518761c6486a56ae336>)[#text("5")]#text(", there is thus a well-defined supremum ")#mi("{\\sup S \\in ({\\bf N} \\cup \\{+\\infty\\})|\\Omega}")#text(". We claim that ")#mi("{\\sup S}")#text(" is stochastically infinite with positive probability. Suppose for contradiction that this were not the case, then ")#mi("{\\sup S \\in {\\bf N}|\\Omega}")#text(". By definition of supremum (taking ")#mi("{L = \\max(\\sup S - 1, 0)}")#text(" in Theorem ")#link(<tao-4518761c6486a56ae336>)[#text("5")]#text("), we conclude that ")#mi("{\\sup S \\in S}")#text(", thus there exists a stochastic sequence ")#mi("{(x_n)_{n=1}^{\\sup S}|\\Omega}")#text(" which is ")#mi("{\\epsilon}")#text("-separated. We now claim that ")#metadata(none) <tao-aaad5f787082990ecac2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("X|\\Omega = \\bigcup_{n=1}^{\\sup S} B(x_n,\\epsilon)|\\Omega,")]]

#text("which contradicts the hypothesis that ")#mi("{X|\\Omega}")#text(" is not stochastically totally bounded. Indeed, if ")#link(<tao-aaad5f787082990ecac2>)[#text("(2)")]#text(" failed, then there must exist some local element ")#mi("{x \\in \\Gamma(X|\\Omega^{\\prime})}")#text(" of ")#mi("{X|\\Omega}")#text(" which does not lie in ")#mi("{\\Gamma(\\bigcup_{n=1}^{\\sup S} B(x_n,\\epsilon)|\\Omega^{\\prime})}")#text(". In particular, there must exist an event ")#mi("{\\Omega^{\\prime\\prime} \\subset \\Omega^{\\prime}}")#text(" of positive probability such that ")#mi("{d(x,x_n) \\geq \\epsilon}")#text(" on ")#mi("{\\Omega^{\\prime\\prime}}")#text(" for all ")#mi("{n \\in {\\bf N}_+|\\Omega^{\\prime\\prime}}")#text(" with ")#mi("{n \\leq \\sup S|\\Omega^{\\prime\\prime}}")#text(". If we then define ")#mi("{x_{\\sup S + 1}}")#text(" on ")#mi("{\\Omega^{\\prime\\prime}}")#text(" by ")#mi("{x_{\\sup S + 1} := x|\\Omega^{\\prime\\prime}}")#text(", then we see that ")#mi("{n \\mapsto x_n}")#text(" on ")#mi("{\\{ n \\in {\\bf N}_+: n \\leq \\sup S+1\\}|\\Omega^{\\prime\\prime}}")#text(" is ")#mi("{\\epsilon}")#text("-separated on ")#mi("{\\Omega^{\\prime\\prime}}")#text(", and on gluing with the original ")#mi("{n \\mapsto x_n}")#text(" on the complement of ")#mi("{\\Omega^{\\prime\\prime}}")#text(", we see that ")#mi("{\\sup_S + 1_{\\Omega^{\\prime\\prime}}}")#text(" lies in ")#mi("{S}")#text(", contradicting the maximal nature of ")#mi("{\\sup_S}")#text(". Thus ")#mi("{\\sup S}")#text(" is stochastically infinite with positive probability.")

#text("We may now pass to an event ")#mi("{\\Omega^{\\prime}}")#text(" of positive probability on which ")#mi("{\\sup S = +\\infty}")#text(". By definition of the supremum, we conclude that for every deterministic natural number ")#mi("{N}")#text(", we may find a sequence ")#mi("{x_{N,1},\\dots,x_{N,N} \\in \\Gamma(X|\\Omega^{\\prime})}")#text(" which are ")#mi("{\\epsilon}")#text("-separated. Observe that if ")#mi("{n < N}")#text(" is a deterministic natural number and we have elements ")#mi("{y_1,\\dots,y_n \\in \\Gamma(X|\\Omega^{\\prime})}")#text(", then we can find a stochastic ")#mi("{m \\leq N}")#text(" on ")#mi("{\\Omega^{\\prime}}")#text(" such that ")#mi("{d(x_{N,m}, y_i) \\geq \\epsilon/2}")#text(" for all ")#mi("{i=1,\\dots,N}")#text(", since each ")#mi("{x_{N,m}}")#text(" can stochastically lie within ")#mi("{\\epsilon/2}")#text(" of at most one ")#mi("{y_i}")#text(". (To see this rigorously, one can consider the Boolean geometry of the events on which ")#mi("{d(x_{N,n},y_i) \\geq \\epsilon/2}")#text(" stochastically hold for various ")#mi("{n,i}")#text(".) By iterating this construction (and applying the axiom of countable choice ")#emph[#text("externally")]#text("), we may find an infinite sequence ")#mi("{y_1,y_2,\\dots}")#text(" in ")#mi("{\\Gamma(X|\\Omega^{\\prime})}")#text(" which is ")#mi("{\\epsilon/2}")#text("-separated, but then this sequence cannot have a convergent subsequence, and so (ii) fails.")

#text("Now suppose that ")#mi("{X|\\Omega}")#text(" is stochastically complete and stochastically totally bounded, and let ")#mi("{(x_n)_{n \\in {\\bf N}_+}}")#text(" be a sequence of local elements ")#mi("{x_n \\in \\Gamma(X|\\Omega^{\\prime})}")#text(" of ")#mi("{X|\\Omega}")#text(" for some event ")#mi("{\\Omega^{\\prime}}")#text(", which we may assume without loss of generality to have positive probability. By stochastic completeness, it suffices to find a stochastic subsequence ")#mi("{(x_{n_j})_{j \\in {\\bf N}_+}}")#text(" which is stochastically Cauchy on ")#mi("{\\Omega^{\\prime}}")#text(".")

#text("By stochastic total boundedness, one can find a stochastic natural number ")#mi("{M_1 \\in {\\bf N}|\\Omega^{\\prime}}")#text(" and a stochastic map ")#mi("{m \\mapsto y_{1,m}}")#text(" from ")#mi("{\\{ m \\in {\\bf N}_+: m \\leq M_1\\}|\\Omega^{\\prime}}")#text(" to ")#mi("{X|\\Omega^{\\prime}}")#text(", such that ")#metadata(none) <tao-b0cadfefcb538a4a3f4e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("X|\\Omega^{\\prime} = \\bigcup_{m=1}^{M_1} B(y_{1,m},M_1)|\\Omega^{\\prime}.")]]

#text("For each deterministic positive natural numbers ")#mi("{m, n \\in {\\bf N}_+}")#text(", we define ")#mi("{E_{m,n}}")#text(" to be the event in ")#mi("{\\Omega^{\\prime}}")#text(" that the assertions ")#mi("{m \\leq M_1}")#text(" and ")#mi("{d(x_n,y_{1,m})}")#text(" both hold stochastically; this event is determined up to null events. From ")#link(<tao-b0cadfefcb538a4a3f4e>)[#text("(3)")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\bigcup_{m=1}^{M_1} E_{n,m} = \\Omega^{\\prime}")]]

#text("holds up to null events for all ")#mi("{n \\in {\\bf N}_+}")#text(". In particular, we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=1}^{M_1} 1_{E_{n,m}} \\geq 1")]]

#text("almost surely on ")#mi("{\\Omega^{\\prime}}")#text(" for all ")#mi("{n \\in {\\bf N}_+}")#text(", and so on summing in ")#mi("{n}")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=1}^{M_1} \\sum_{n \\in {\\bf N}_+} 1_{E_{n,m}} = +\\infty")]]

#text("almost surely on ")#mi("{\\Omega^{\\prime}}")#text(". By selecting ")#mi("{m \\in {\\bf N}_+|\\Omega^{\\prime}}")#text(" stochastically to be the least ")#mi("{m}")#text(" for which ")#mi("{\\sum_{n \\in {\\bf N}_+} 1_{E_{n,m}}}")#text(" is infinite, we have ")#mi("{m \\leq M_1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf N}_+} 1_{E_{n,m}} = +\\infty")]]

#text("almost surely on ")#mi("{\\Omega^{\\prime}}")#text(". We can then stochastically choose a sequence ")#mi("{j_{1,1} < j_{1,2} < \\dots}")#text(" in ")#mi("{{\\bf N}_+|\\Omega^{\\prime}}")#text(" such that ")#mi("{E_{n_{j_{1,i}},m}}")#text(" holds almost surely on ")#mi("{\\Omega^{\\prime}}")#text(" for each ")#mi("{i \\in {\\bf N}_+}")#text(", or equivalently that the stochastic subsequence ")#mi("{(x_{n_{j_{1,i}}})_{i \\in {\\bf N}_+}}")#text(" lies in ")#mi("{\\Gamma( B(y_{1,m},1) | \\Omega^{\\prime} )}")#text(". Writing ")#mi("{z_1 := y_{1,m}}")#text(", we have thus localised this stochastic subsequence to a stochastic unit ball ")#mi("{B(z_1,1)}")#text(".")

#text("By repeating this argument, we may find a further stochastic subsequence ")#mi("{(x_{n_{j_{2,i}}})_{i \\in {\\bf N}_+}}")#text(" of ")#mi("{(x_{n_{j_{1,i}}})_{i \\in {\\bf N}_+}}")#text(" that lies in ")#mi("{\\Gamma( B(z_2,1/2 )|\\Omega^{\\prime})}")#text(" for some ")#mi("{z_2 \\in \\Gamma( X|\\Omega^{\\prime})}")#text(", a yet further subsequence ")#mi("{(x_{n_{j_{3,i}}})_{i \\in {\\bf N}_+}}")#text(" that lies in ")#mi("{\\Gamma( B( z_3, 1/3)|\\Omega^{\\prime} )}")#text(" for some ")#mi("{z_3 \\in \\Gamma(X|\\Omega^{\\prime})}")#text(", and so forth. It is then easy to see that the diagonal sequence ")#mi("{(x_{n_{j_{i,i}}})_{i \\in {\\bf N}_+}}")#text(" is stochastically Cauchy, and the claim follows. ")#mi("\\Box")

#text("For future reference, we remark that the above arguments also show that if ")#mi("{Y|\\Omega}")#text(" is a stochastically totally bounded subset of a stochastically complete metric space ")#mi("{X|\\Omega}")#text(", then every sequence in ")#mi("{\\Gamma(Y|\\Omega)}")#text(" has a stochastic susbequence which converges in ")#mi("{\\Gamma(X|\\Omega)}")#text(".")

#heading(level: 1)[#strong[#text(" — 2. Hilbert-Schmidt operators relative to a finite measure space — ")]]

#text("One could continue developing stochastic versions of other fundamental results in real analysis (for instance, working out the basic theory of stochastic continuous functions between metric spaces); roughly speaking, it appears that most of these results will go through as long as one does not require the concept of an uncountable union or intersection or the axiom of choice (in particular, I do not see how to develop a stochastic theory of arbitrary topological spaces, although the first countable case may be doable; also, any result reliant on the Hahn-Banach theorem or the non-sequential version of Tychonoff’s theorem will likely not have a good stochastic analogue). I will however focus on the results leading up to the stochastic version of the spectral theorem for Hilbert-Schmidt operators, as this is the application that motivated my post.")

#text("Let us first define the concept of a stochastic (real) Hilbert space, in more or less complete analogy with the deterministic counterpart:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 10 (Stochastic Hilbert spaces)")]#text(" A ")#emph[#text("stochastic vector space")]#text(" is a stochastic set ")#mi("{V|\\Omega}")#text(" equipped with an element ")#mi("{0 \\in \\Gamma(V|\\Omega)}")#text(", an addition map ")#mi("{+: V|\\Omega \\times V|\\Omega \\rightarrow V|\\Omega}")#text(", and a scalar multiplication map ")#mi("{\\cdot: {\\bf R}|\\Omega \\times V|\\Omega \\rightarrow V|\\Omega}")#text(" which obeys the usual vector space axioms. In other words, when localising to any event ")#mi("{E}")#text(", the addition map ")#mi("{+: \\Gamma(V|E) \\times \\Gamma(V|E) \\rightarrow \\Gamma(V|E)}")#text(" is commutative and associative with identity ")#mi("{0|E}")#text(", and the scalar multiplication map ")#mi("{\\cdot: \\Gamma({\\bf R}|E) \\times \\Gamma(V|E) \\rightarrow \\Gamma(V|E)}")#text(" is bilinear over ")#mi("{\\Gamma({\\bf R}|\\mathop{\\bf E})}")#text(". In other words, ")#mi("{\\Gamma(V|E)}")#text(" is a module over the commutative ring ")#mi("{\\Gamma({\\bf R}|E)}")#text(". As is usual, we define the subtraction map ")#mi("{-: V|\\Omega \\times V|\\Omega \\rightarrow V|\\Omega}")#text(" by the formula ")#mi("{v-w := v + (-1) \\cdot w}")#text(".")

#text("A ")#emph[#text("stochastic inner product space")]#text(" is a stochastic vector space ")#mi("{V|\\Omega}")#text(" equipped with an inner product map ")#mi("{\\langle,\\rangle: V|\\Omega \\times V|\\Omega \\rightarrow {\\bf R}|\\Omega}")#text(" which obeys the following axioms for any event ")#mi("{E}")#text(":")

#list(
[#text("(Symmetry) The map ")#mi("{\\langle,\\rangle: \\Gamma(V|E) \\times \\Gamma(V|E) \\rightarrow \\Gamma({\\bf R}|E)}")#text(" is symmetric.")],
[#text("(Bilinearity) The map ")#mi("{\\langle,\\rangle: \\Gamma(V|E) \\times \\Gamma(V|E) \\rightarrow \\Gamma({\\bf R}|E)}")#text(" is bilinear over ")#mi("{\\Gamma({\\bf R}|E)}")#text(".")],
[#text("(Positive semi-definiteness) For any ")#mi("{v \\in\\Gamma(V|E)}")#text(", we have ")#mi("{\\langle v,v \\rangle \\geq 0}")#text(", with equality if and only if ")#mi("{v=0}")#text(".")]
)

#text("By repeating the usual deterministic arguments, it is easy to see that any stochastic inner product space becomes a stochastic metric space with ")#tao-math("{d(v,w) := \\left\\|v-w\\right\\|}", block: false)#text(", where ")#tao-math("{\\left\\|v\\right\\| := \\langle v,v \\rangle^{1/2}}", block: false)#text(".")

#text("A ")#emph[#text("stochastic Hilbert space")]#text(" is a stochastic inner product space ")#mi("{H}")#text(" which is also stochastically complete. We denote the inner product on such spaces by ")#mi("{\\langle,\\rangle_H}")#text(" and the norm by ")#mi("{\\| \\|_H}")#text(".")
]

#text("As usual, in the model case when ")#mi("{\\Omega}")#text(" is discrete and at most countable, a stochastic Hilbert space ")#mi("{H|\\Omega}")#text(" is just a bundle of deterministic Hilbert spaces ")#mi("{H_\\omega}")#text(" for each ")#mi("{\\omega \\in \\Omega}")#text(" occurring with positive probability, with no relationships between the different fibres ")#mi("{H_\\omega}")#text(" (in particular, their dimensions may vary arbitrarily in ")#mi("{\\omega}")#text("). In the continuous case, the notion of a stochastic Hilbert space ")#mi("{H|\\Omega}")#text(" is very closely related to that of (an extended version of) a ")#link("http://en.wikipedia.org/wiki/Hilbert_module")[#text("Hilbert module")]#text(" over the commutative Banach algebra ")#mi("{L^\\infty(\\Omega)}")#text("; indeed, it is easy to see that the space of global elements ")#mi("{v \\in \\Gamma(H|\\Omega)}")#text(" of a stochastic Hilbert space ")#mi("{H|\\Omega}")#text(" which are ")#emph[#text("bounded")]#text(" in the sense that ")#tao-math("{\\left\\|v\\right\\| \\leq M}", block: false)#text(" for some deterministic real ")#mi("{M}")#text(" forms a Hilbert module over ")#mi("{L^\\infty(\\Omega)}")#text(". (Without the boundedness restriction, one obtains instead a module over ")#mi("{\\Gamma({\\bf R}|\\Omega)}")#text(".)")

#text("Note that we do not impose any separability hypothesis on our Hilbert spaces. Despite this, much of the theory of Hilbert spaces turns out to still be of “countable complexity” in some sense, so that it can be extended to the stochastic setting without too much difficulty.")

#text("We now extend the familiar notion of an ")#link("http://en.wikipedia.org/wiki/Orthonormality")[#text("orthonormal system")]#text(" in a Hilbert space to the stochastic setting. A key point is that we allow the number of elements in this system to also be stochastic.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 11 (Orthonormal system)")]#text(" Let ")#mi("{H|\\Omega}")#text(" be a stochastic Hilbert space. A ")#emph[#text("stochastic orthonormal system")]#text(" ")#mi("{(e_n)_{n=1}^N|\\Omega}")#text(" in ")#mi("{H|\\Omega}")#text(" consists of a stochastic extended natural number ")#mi("{N \\in {\\bf N} \\cup \\{+\\infty\\}|\\Omega}")#text(", together with a stochastic map ")#mi("{n \\mapsto e_n}")#text(" from ")#mi("{\\{ n \\in {\\bf N}_+: n \\leq N \\}|\\Omega}")#text(" to ")#mi("{H|\\Omega}")#text(", such that one has ")#mi("{\\langle e_n, e_m \\rangle = 1_{n=m}}")#text(" on ")#mi("{E}")#text(" for any event ")#mi("{E}")#text(" and any ")#mi("{n, m \\in {\\bf N}_+|E}")#text(" with ")#mi("{n,m \\leq N|E}")#text(". (Note that we allow ")#mi("{N}")#text(" to vanish with positive probability, so that the orthonormal system can be stochastically empty.)")
]

#text("Now we can define the notion of a stochastic ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Schmidt_operator")[#text("Hilbert-Schmidt operator")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 12 (Stochastic Hilbert-Schmidt operator)")]#text(" Let ")#mi("{H|\\Omega}")#text(" and ")#mi("{H^{\\prime}|\\Omega}")#text(" be stochastic Hilbert spaces. A ")#emph[#text("stochastic linear operator")]#text(" ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" is a stochastic function such that for each event ")#mi("{E}")#text(", the localised maps ")#mi("{T: \\Gamma(H|E) \\rightarrow \\Gamma(H^{\\prime}|E)}")#text(" are linear over ")#mi("{\\Gamma({\\bf R}|E)}")#text(". Such an operator is said to be ")#emph[#text("stochastically bounded")]#text(" if there exists a non-negative stochastic real ")#mi("{A \\in \\Gamma([0,+\\infty)|\\Omega)}")#text(" such that one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tv \\right\\|_{H^{\\prime}} \\leq A|E", block: true)]]

#text("for all events ")#mi("{E}")#text(" and local elements ")#mi("{v \\in \\Gamma(H|E)}")#text(". By (the negation of) Theorem ")#link(<tao-4518761c6486a56ae336>)[#text("5")]#text(", there is a least such ")#mi("{A}")#text(", which we denote as ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} \\in \\Gamma([0,+\\infty)|\\Omega)}", block: false)#text(".")

#text("Similarly, we say that a stochastic linear operator ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" is ")#emph[#text("stochastically Hilbert-Schmidt")]#text(" if there exists a non-negative stochastic real ")#mi("{A \\in \\Gamma([0,+\\infty)|\\Omega)}")#text(" such that one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^N \\sum_{m=1}^M \\left|\\langle T e_n, f_m \\rangle\\right|^2 \\leq A^2|E", block: true)]]

#text("for all events ")#mi("{E}")#text(" and all stochastic orthonormal systems ")#mi("{(e_n)_{n=1}^N|E, (f_m)_{m=1}^M|E}")#text(" on ")#mi("{H|E}")#text(" and ")#mi("{H^{\\prime}|E}")#text(" respectively. Again, there is a least such ")#mi("{A}")#text(", which we denote as ")#tao-math("{\\left\\|T\\right\\|_{HS(H \\rightarrow H^{\\prime})} \\in \\Gamma([0,+\\infty)|\\Omega)}", block: false)#text(".")

#text("A stochastic linear operator ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" is said to be ")#emph[#text("compact")]#text(" if the image ")#tao-math("{T( \\{ v \\in H: \\left\\|v\\right\\| \\leq 1 \\} )|\\Omega}", block: false)#text(" of the unit ball ")#tao-math("{\\{v \\in H: \\left\\|v\\right\\| \\leq 1\\}|\\Omega}", block: false)#text(" is stochastically totally bounded in ")#mi("{H^{\\prime}|\\Omega}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" ")#metadata(none) <tao-a60ec1cf58f49cd2fab6>#text(" Show that any stochastic Hilbert-Schmidt operator ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" obeys the bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^N \\left\\| T e_n \\right\\|_{H^{\\prime}}^2 \\leq \\left\\|T\\right\\|_{HS(H \\rightarrow H^{\\prime})}^2|E", block: true)]]

#text("for all events ")#mi("{E}")#text(" and all stochastic orthonormal systems ")#mi("{(e_n)_{n=1}^N|E}")#text(" on ")#mi("{H|E}")#text(". Conclude in particular that ")#mi("{T}")#text(" is stochastically bounded with ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} \\leq \\left\\|T\\right\\|_{HS(H \\rightarrow H^{\\prime})}}", block: false)#text(".")
]

#text("We have the following basic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13")]#text(" Any stochastic Hilbert-Schmidt operator ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" is stochastically compact.")
]

#emph[#text("Proof:")]#text(" Suppose for contradiction that we could find a stochastic Hilbert-Schmidt operator ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" which is not stochastically compact, thus ")#tao-math("{T( \\{ v \\in H: \\left\\|v\\right\\| \\leq 1 \\} )|\\Omega}", block: false)#text(" is not stochastically totally bounded. By repeating the arguments used in the proof of Theorem ")#link(<tao-a523f355a7725c8aeca6>)[#text("9")]#text(", this means that there exists an event ")#mi("{\\Omega^{\\prime}}")#text(" of positive probability, a stochastic real ")#mi("{\\epsilon > 0}")#text(" on ")#mi("{\\Omega^{\\prime}}")#text(", and an infinite sequence ")#tao-math("{x_n \\in \\Gamma(\\{ v \\in H: \\left\\|v\\right\\| \\leq 1 \\}|\\Omega^{\\prime})}", block: false)#text(" for ")#mi("{n\\in {\\bf N}_+}")#text(" such that the ")#mi("{Tx_n}")#text(" are ")#mi("{\\epsilon}")#text("-separated on ")#mi("{\\Omega^{\\prime}}")#text(".")

#text("We will need a stronger separation property. Let us say that a sequence ")#mi("{y_m \\in \\Gamma(H^{\\prime}|\\Omega^{\\prime})}")#text(" is ")#emph[#text("linearly ")#mi("{\\epsilon/4}")#text("-separated")]#text(" if one has ")#metadata(none) <tao-f07d989f1acc093b83de>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| y_m - c_1 y_1 - \\dots - c_{m-1} y_{m-1} \\right\\|_{H^{\\prime}} \\geq \\epsilon/4", block: true)]]

#text("on ")#mi("{\\Omega^{\\prime}}")#text(" for any deterministic ")#mi("{m \\in{\\bf N}_+}")#text(" and any stochastic reals ")#mi("{c_1,\\dots,c_{m-1} \\in {\\bf R}|\\Omega^{\\prime}}")#text(". We claim that ")#tao-math("{\\Gamma(T(\\{ v \\in H: \\left\\|v\\right\\| \\leq 1 \\})|\\Omega^{\\prime})}", block: false)#text(" contains an infinite sequence ")#mi("{y_m}")#text(" that is linearly ")#mi("{\\epsilon/4}")#text("-separated. Indeed, suppose that we have already found a finite sequence ")#mi("{y_1,\\dots,y_{m-1}}")#text(" in ")#tao-math("{\\Gamma(T(\\{ v \\in H: \\left\\|v\\right\\| \\leq 1 \\})|\\Omega^{\\prime})}", block: false)#text(" that is linearly ")#mi("{\\epsilon/4}")#text("-separated for some ")#mi("{m \\geq 1}")#text(", and wish to add on a further element ")#mi("{y_m}")#text(" while preserving the linear ")#mi("{\\epsilon}")#text("-separation property, that is to say we wish to have ")#link(<tao-f07d989f1acc093b83de>)[#text("(4)")]#text(" for all ")#mi("{c_1,\\dots,c_{m-1} \\in {\\bf R}|\\Omega^{\\prime}}")#text(". By Exercise ")#link(<tao-a60ec1cf58f49cd2fab6>)[#text("8")]#text(", such a ")#mi("{y_m}")#text(" would already lie in the closed ball ")#tao-math("{B( 0, \\left\\|T\\right\\|_{HS(H \\rightarrow H^{\\prime})})}", block: false)#text(". Now, by elementary geometry (applying a Gram-Schmidt process to the ")#mi("{y_1,\\dots,y_{m-1}}")#text(") one can cover the stochastic set")

#align(center)[#tao-fit-display[#tao-math("\\{ y \\in H^{\\prime}: \\left\\|y\\right\\| \\leq \\left\\|T\\right\\|_{HS(H \\rightarrow H^{\\prime})}; \\left\\| y - c_1 y_1 - \\dots - c_{m-1} y_{m-1} \\right\\|_{H^{\\prime}} < \\epsilon/4 \\text{ for some } c_1,\\dots,c_{m-1} \\in {\\bf R} \\}|\\Omega^{\\prime}", block: true)]]

#text("by a finite union of balls")

#align(center)[#tao-fit-display[#mitex("\\bigcup_{i=1}^N B( z_i, \\epsilon/2 )")]]

#text("for some stochastic ")#mi("{N \\in {\\bf N}|\\Omega^{\\prime}}")#text(" and some stochastic finite sequence ")#mi("{(z_i)_{i=1}^N|\\Omega^{\\prime}}")#text(" of points in ")#mi("{H^{\\prime}|\\Omega^{\\prime}}")#text(". Stochastically, each of these balls ")#mi("{B(z_i,\\epsilon/2)}")#text(" may contain at most one of the ")#mi("{x_n}")#text("; if we then define the stochastic positive natural number ")#mi("{n \\in {\\bf N}_+|\\Omega^{\\prime}}")#text(" to be the least ")#mi("{x_n}")#text(" that stochastically lies outside all of the ")#mi("{B(z_i,\\epsilon/2)}")#text(", then ")#mi("{n}")#text(" is well-defined, and if we set ")#mi("{y_m := x_n}")#text(", we obtain the desired property ")#link(<tao-f07d989f1acc093b83de>)[#text("(4)")]#text(".")

#text("As each ")#mi("{y_m}")#text(" lies in ")#tao-math("{\\Gamma(T(\\{ v \\in H: \\left\\|v\\right\\| \\leq 1 \\})|\\Omega^{\\prime})}", block: false)#text(", we have ")#mi("{y_m = T v_m}")#text(" for some ")#mi("{v_m \\in \\Gamma(H|\\Omega^{\\prime})}")#text(" with ")#tao-math("{\\left\\|v_m\\right\\|_H \\leq 1}", block: false)#text(". From the Gram-Schmidt process, one may find an orthonormal system ")#mi("{(e_n)_{n=1}^N|\\Omega^{\\prime}}")#text(" in ")#mi("{\\Gamma(H|\\Omega^{\\prime})}")#text(" for some ")#mi("{N \\in {\\bf N} \\cup\\{+\\infty\\}|\\Omega^{\\prime}}")#text(" such that each ")#mi("{v_m}")#text(" is a linear combination (over ")#mi("{\\Gamma({\\bf R}|\\Omega^{\\prime})}")#text(") of those ")#mi("{e_n}")#text(" with ")#mi("{n \\leq N, m}")#text(". We may similarly find an orthonormal system ")#mi("{(f_m)_{m=1}^M|\\Omega^{\\prime}}")#text(" in ")#mi("{\\Gamma(H^{\\prime}|\\Omega^{\\prime})}")#text(" for some ")#mi("{N \\in {\\bf N} \\cup\\{+\\infty\\}|\\Omega^{\\prime}}")#text(" such that each ")#mi("{y_m}")#text(" is a linear combination of those ")#mi("{f_i}")#text(" with ")#mi("{i \\leq M,m}")#text(". From ")#link(<tao-f07d989f1acc093b83de>)[#text("(4)")]#text(" we conclude that ")#mi("{M=+\\infty}")#text(" and that for each deterministic ")#mi("{m \\in {\\bf N}_+}")#text(", the ")#mi("{f_m}")#text(" coefficient of ")#mi("{y_m}")#text(" has magnitude at least ")#mi("{\\epsilon/4}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle T x_m, f_m \\rangle\\right| \\geq \\epsilon/4", block: true)]]

#text("and thus by the Pythagoras theorem")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^N \\left|\\langle T e_n, f_m \\rangle\\right|^2 \\geq \\epsilon^2/16", block: true)]]

#text("on ")#mi("{\\Omega^{\\prime}}")#text("; summing in ")#mi("{m}")#text(", we contradict the Hilbert-Schmidt nature of ")#mi("{T}")#text(". ")#mi("\\Box")

#text("Next, we establish the existence of adjoints:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Adjoint operator)")]#text(" Let ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" be a stochastically bounded linear operator. Then there exists a unique stochastically bounded linear operator ")#mi("{T^*: H^{\\prime}|\\Omega \\rightarrow H|\\Omega}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\langle Tv, w \\rangle_{H^{\\prime}} = \\langle v, T^* w \\rangle_H")]]

#text("on any event ")#mi("{E}")#text(" and any ")#mi("{v \\in \\Gamma(H|E)}")#text(", ")#mi("{w \\in \\Gamma(H^{\\prime}|E)}")#text(". In particular we have ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} = \\left\\|T^*\\right\\|_{B(H^{\\prime} \\rightarrow H)}}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" Uniqueness is an easy exercise that we leave to the reader, so we focus on existence. The point here is that the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem for Hilbert spaces")]#text(" is sufficiently “constructive” that it can be translated to the stochastic setting.")

#text("Let ")#mi("{E}")#text(" be an event and ")#mi("{w \\in \\Gamma(H^{\\prime}|E)}")#text(" be a local element of ")#mi("{H^{\\prime}}")#text(". We let ")#mi("{S}")#text(" be the stochastic set on ")#mi("{E}")#text(" defined by setting ")#mi("{\\Gamma(S|F)}")#text(" for ")#mi("{F \\subset E}")#text(" to be the set of all stochastic real numbers of the form ")#mi("{\\langle T v, w \\rangle_{H^{\\prime}}}")#text(", where ")#mi("{v \\in \\Gamma(H|F)}")#text(" with ")#tao-math("{\\left\\|v\\right\\|_H \\leq 1}", block: false)#text(". By Theorem ")#link(<tao-4518761c6486a56ae336>)[#text("5")]#text(", we may then find a sequence ")#mi("{v_n \\in \\Gamma(H|E)}")#text(" for ")#mi("{n \\in {\\bf N}_+}")#text(" such that ")#mi("{\\langle T v_n, w \\rangle_{H^{\\prime}}}")#text(" converges stochastically to ")#mi("{\\sup S}")#text(" on ")#mi("{E}")#text(". For any two ")#mi("{n,m \\in{\\bf N}_+}")#text(", we have from the parallelogram law that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\frac{v_n+v_m}{2} \\right\\|_H \\leq (1 - \\frac{1}{2} \\left\\|v_n-v_m\\right\\|_H^2)^{1/2}", block: true)]]

#text("and hence by homogeneity")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} ( \\langle T v_n, w \\rangle_H + \\langle T v_m, w \\rangle_H ) \\leq (1 - \\frac{1}{2} \\left\\|v_n-v_m\\right\\|_H^2)^{1/2} \\sup S", block: true)]]

#text("on ")#mi("{E}")#text(" combining this with the stochastic convergence of ")#mi("{\\langle T v_n, w \\rangle_{H^{\\prime}}}")#text(", we conclude that ")#mi("{v_n}")#text(" is stochastically Cauchy on the event in ")#mi("{E}")#text(" that ")#mi("{\\sup S}")#text(" is non-zero. Setting ")#mi("{v_\\infty \\in \\Gamma(H|E)}")#text(" to be the stochastic limit of the ")#mi("{v_n}")#text(" on this event (and set to ")#mi("{0}")#text(" on the complementary event), we see that ")#tao-math("{\\left\\|v_\\infty\\right\\|_H \\leq 1}", block: false)#text(" and")

#align(center)[#tao-fit-display[#mitex("\\langle Tv_\\infty, w \\rangle_{H^{\\prime}} = \\sup S.")]]

#text("On the event that ")#mi("{\\sup S}")#text(" is non-zero, ")#mi("{v_\\infty}")#text(" is thus non-zero, and consideration of the vectors ")#mi("{v_\\infty + tu}")#text(" for stochastic real ")#mi("{t}")#text(" and stochastic vectors ")#mi("{u}")#text(" soon reveals that")

#align(center)[#tao-fit-display[#mitex("\\langle Tu, w \\rangle_{H^{\\prime}} = 0")]]

#text("whenever ")#mi("{\\langle u, v_\\infty \\rangle_H = 0}")#text(", which by elementary linear algebra gives a representation of the form")

#align(center)[#tao-fit-display[#mitex("\\langle Tv, w \\rangle_{H^{\\prime}} = \\langle v, T^* w \\rangle_{H}")]]

#text("for some ")#mi("{T^* w}")#text(" (a scalar multiple of ")#mi("{v_\\infty}")#text("); when ")#mi("{\\sup S}")#text(" vanishes, we simply take ")#mi("{T^* w=0}")#text(". It is then a routine matter to verify that ")#mi("{T^*}")#text(" is a stochastically bounded linear operator, and the claim follows. ")#mi("\\Box")

#text("We use this to relativise the spectral theorem (or more precisely, the ")#link("http://en.wikipedia.org/wiki/Singular_value_decomposition")[#text("singular value decomposition")]#text(") for compact operators:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Spectral theorem for stochastically compact operators)")]#text(" ")#metadata(none) <tao-59ee2eccd8eb8f9bd5ae>#text(" Let ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" be a stochastically compact linear operator, with ")#mi("{T^*}")#text(" also stochastically compact. Then there exists ")#mi("{N \\in \\Gamma({\\bf N} \\cup \\{+\\infty\\}|\\Omega)}")#text(", orthonormal systems ")#mi("{(e_n)_{n=1}^N|\\Omega}")#text(" and ")#mi("{(f_n)_{n=1}^N|\\Omega}")#text(" of ")#mi("{H|\\Omega}")#text(" and ")#mi("{H^{\\prime}|\\Omega}")#text(" respectively, and a stochastic sequence ")#mi("{(\\sigma_n)_{n=1}^N|\\Omega}")#text(" in ")#mi("{(0,+\\infty)|\\Omega}")#text(" such that ")#mi("{\\sigma_n \\geq \\sigma_m}")#text(" on an event ")#mi("{E}")#text(" whenever ")#mi("{1 \\leq m \\leq n \\leq N}")#text(" are stochastic natural numbers on ")#mi("{E}")#text(", and such that the ")#mi("{\\sigma_n}")#text(" go to zero in the sense that for any stochastic real ")#mi("{\\epsilon>0}")#text(" on an event ")#mi("{E}")#text(", there exist a stochastic natural number ")#mi("{N_\\epsilon}")#text(" on ")#mi("{E}")#text(" such that ")#mi("{\\sigma_n \\leq \\epsilon}")#text(" on ")#mi("{E}")#text(" whenever ")#mi("{N_\\epsilon \\leq n \\leq N}")#text(" is a stochastic natural number on ")#mi("{E}")#text(". Furthermore, for any event ")#mi("{E}")#text(" and ")#mi("{v \\in \\Gamma(H|E)}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("Tv = \\sum_{n=1}^N \\sigma_n \\langle v, e_n \\rangle_H f_n")]]

#text("on ")#mi("{E}")#text(". (Note that a Bessel inequality argument shows that the series is convergent; indeed it is even unconditionally convergent.)")
]

#text("It is likely that the hypothesis that ")#mi("{T^*}")#text(" be stochastically compact is redundant, in that it is implied by the stochastically compact nature of ")#mi("{T}")#text(", but I did not attempt to prove this rigorously as it was not needed for my application (which is focused on the Hilbert-Schmidt case).")

#text("To prove this theorem, we first establish a fragment of it for the top singular value ")#mi("{n=1}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16 (Largest singular value)")]#text(" ")#metadata(none) <tao-30585c6e3bfbd14b52bb>#text(" Let ")#mi("{T: H|\\Omega \\rightarrow H^{\\prime}|\\Omega}")#text(" be a stochastically compact linear operator, and let ")#mi("{\\Omega^{\\prime}}")#text(" be the event where ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} > 0}", block: false)#text(" (this event is well-defined up to a null event). Then there exist ")#mi("{e \\in \\Gamma(H|\\Omega^{\\prime})}")#text(", ")#mi("{f \\in \\Gamma(H^{\\prime}|\\Omega^{\\prime})}")#text(" with ")#tao-math("{\\left\\|e\\right\\|_H = \\left\\|f\\right\\|_{H^{\\prime}} = 1}", block: false)#text(" on ")#mi("{\\Omega^{\\prime}}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("Te = \\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} f", block: true)]]

#text("and dually that")

#align(center)[#tao-fit-display[#tao-math("T^* f = \\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} e", block: true)]]

#text("on ")#mi("{\\Omega^{\\prime}}")#text(".")
]

#emph[#text("Proof:")]#text(" Note that ")#mi("{H,H^{\\prime}}")#text(" are necessarily non-trivial on ")#mi("{\\Omega^{\\prime}}")#text(". Let ")#mi("{S}")#text(" denote the set of all expressions of the form ")#mi("{\\langle Te, f\\rangle}")#text(" on ")#mi("{\\Omega^{\\prime}}")#text(", where ")#mi("{e \\in \\Gamma(H|\\Omega^{\\prime})}")#text(", ")#mi("{f \\in \\Gamma(H^{\\prime}|\\Omega^{\\prime})}")#text(" with ")#tao-math("{\\left\\|e\\right\\|_H = \\left\\|f\\right\\|_{H^{\\prime}} = 1}", block: false)#text(" on ")#mi("{\\Omega^{\\prime}}")#text(", then ")#mi("{S}")#text(" is a globally non-empty stochastic subset of ")#mi("{[0,+\\infty)|\\Omega^{\\prime}}")#text(" which has ")#tao-math("{\\left\\|T\\right\\|_{op}}", block: false)#text(" as an upper bound. Indeed, from Theorem ")#link(<tao-4518761c6486a56ae336>)[#text("5")]#text(" and the definition of ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})}}", block: false)#text(", it is not hard to see that ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} = \\sup S}", block: false)#text(". From this, we may construct a sequence in ")#mi("{S}")#text(" that converges stochastically to ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})}}", block: false)#text(" on ")#mi("{\\Omega^{\\prime}}")#text(", and hence we may find sequences ")#mi("{e_n \\in \\Gamma(H|\\Omega^{\\prime})}")#text(", ")#mi("{f_n \\in \\Gamma(H^{\\prime}|\\Omega^{\\prime})}")#text(" for ")#mi("{n \\in{\\bf N}}")#text(" with ")#tao-math("{\\left\\|e_n\\right\\|_H = \\left\\|f_n\\right\\|_{H^{\\prime}} = 1}", block: false)#text(" on ")#mi("{\\Omega^{\\prime}}")#text(" with ")#mi("{\\langle Te_n, f_n\\rangle}")#text(" stochastically convergent to ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})}}", block: false)#text(". By the Cauchy-Schwarz inequality, this implies that ")#tao-math("{\\left\\|Te_n\\right\\|_{H^{\\prime}}}", block: false)#text(" is stochastically convergent to ")#tao-math("{\\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})}}", block: false)#text("; from the parallelogram law applied to ")#mi("{f_n}")#text(" and ")#tao-math("{Te_n / \\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})}}", block: false)#text(", we conclude that ")#tao-math("{f_n - Te_n / \\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})}}", block: false)#text(" converges stochastically to zero. On the other hand, as ")#mi("{T}")#text(" is compact, we can pass to a stochastic subsequence and ensure that ")#mi("{Te_n}")#text(" is stochastically convergent, thus ")#mi("{f_n}")#text(" is also stochastically convergent to some limit ")#mi("{f \\in \\Gamma(H^{\\prime}|\\Omega)}")#text(". Similar considerations using the adjoint operator ")#mi("{T^*}")#text(" allow us to assume that ")#mi("{e_n}")#text(" is stochastically convergent to some limit ")#mi("{e \\in \\Gamma(H|\\Omega)}")#text(". It is then routine to verify that ")#tao-math("{\\left\\|e\\right\\|_H = \\left\\|f\\right\\|_{H^{\\prime}} = 1}", block: false)#text(", ")#tao-math("{f - Te / \\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} = 0}", block: false)#text(", and ")#tao-math("{e - T^* e / \\left\\|T\\right\\|_{B(H \\rightarrow H^{\\prime})} = 0}", block: false)#text(", giving the claim. ")#mi("\\Box")

#text("Now we prove Theorem ")#link(<tao-59ee2eccd8eb8f9bd5ae>)[#text("15")]#text(".")

#emph[#text("Proof:")]#text(" (Proof of Theorem ")#link(<tao-59ee2eccd8eb8f9bd5ae>)[#text("15")]#text(".) Define a ")#emph[#text("partial singular value decomposition")]#text(" to consist of the following data:")

#list(
[#text("A stochastic extended natural number ")#mi("{N \\in \\Gamma({\\bf N} \\cup \\{+\\infty\\}|\\Omega)}")#text(";")],
[#text("A stochastic orthonormal system ")#mi("{(e_n)_{n=1}^N|\\Omega}")#text(" of ")#mi("{H|\\Omega}")#text(";")],
[#text("A stochastic orthonormal system ")#mi("{(f_n)_{n=1}^N|\\Omega}")#text(" of ")#mi("{H^{\\prime}|\\Omega}")#text("; and")],
[#text("A non-increasing stochastic sequence ")#mi("{(\\sigma_n)_{n=1}^N|\\Omega}")#text(" in ")#mi("{(0,+\\infty)|\\Omega}")]
)

#text("such that, for any event ")#mi("{E}")#text(", and any ")#mi("{n \\in {\\bf N}_+|E}")#text(" with ")#mi("{n \\leq N|E}")#text(",")

#list(
[#mi("{Te_n = \\sigma_n f_n}")#text(" on ")#mi("{E}")#text(".")],
[#mi("{T^* f_n = \\sigma_n e_n}")#text(" on ")#mi("{E}")#text(".")],
[#text("Whenever ")#mi("{v \\in H|E}")#text(" is orthogonal to ")#mi("{e_m}")#text(" for all ")#mi("{m \\leq n}")#text(", one has ")#tao-math("{\\left\\|T v \\right\\|_{H^{\\prime}} \\leq \\sigma_n \\left\\|v\\right\\|_H}", block: false)#text(" on ")#mi("{E}")#text(".")],
[#text("Whenever ")#mi("{n \\in {\\bf N}_+|E}")#text(" with ")#mi("{n \\leq N|E}")#text(" and ")#mi("{w \\in H^{\\prime}|E}")#text(" is orthogonal to ")#mi("{f_m}")#text(" for all ")#mi("{m \\leq n}")#text(", one has ")#tao-math("{\\left\\|T^* w \\right\\|_{H} \\leq \\sigma_n \\left\\|v\\right\\|_{H^{\\prime}}}", block: false)#text(" on ")#mi("{E}")#text(".")]
)

#text("We let ")#mi("{S}")#text(" be the set of all ")#mi("{N}")#text(" that can arise from a partial singular value decomposition; then ")#mi("{S}")#text(" is a stochastic subset of ")#mi("{{\\bf N} \\cup \\{\\infty\\}|\\Omega}")#text(" that contains ")#mi("{0|\\Omega}")#text(", and by Theorem ")#link(<tao-4518761c6486a56ae336>)[#text("5")]#text(" we can form the supremum ")#mi("{\\sup S \\in {\\bf N} \\cup \\{\\infty\\}|\\Omega}")#text(".")

#text("Let us first localise to the event ")#mi("{\\Omega^{\\prime}}")#text(" that ")#mi("{\\sup S}")#text(" is stochastically finite. As in the proof of the Heine-Borel theorem, we can use the discrete nature of the natural numbers to conclude that ")#mi("{\\sup S \\in S}")#text(" on ")#mi("{\\Omega^{\\prime}}")#text(". Thus there exists a partial singular value decomposition on ")#mi("{\\Omega^{\\prime}}")#text(" with ")#mi("{N=\\sup S}")#text(".")

#text("Define ")#mi("{\\tilde H}")#text(" on ")#mi("{\\Omega^{\\prime}}")#text(" by setting ")#mi("{\\Gamma(\\tilde H|E)}")#text(" for ")#mi("{E \\subset \\Omega^{\\prime}}")#text(" to be the set of all ")#mi("{v \\in \\Gamma(H|E)}")#text(" that are orthogonal to all the ")#mi("{e_n}")#text(" with ")#mi("{n \\leq N}")#text("; this can easily be seen to be a stochastic Hilbert space (a stochastically finite codimension subspace of ")#mi("{H}")#text("). Similarly define ")#mi("{\\tilde H^{\\prime}}")#text(" on ")#mi("{\\Omega^{\\prime}}")#text(" by setting ")#mi("{\\Gamma(\\tilde H^{\\prime}|E)}")#text(" to be the set of all ")#mi("{w \\in \\Gamma(H^{\\prime}|E)}")#text(" that are orthogonal to all the ")#mi("{f_n}")#text(" with ")#mi("{n \\leq N}")#text(". As ")#mi("{Te_n = \\sigma_n f_n}")#text(" and ")#mi("{T^* f_n = \\sigma_n e_n}")#text(", we see that ")#mi("{T}")#text(" maps ")#mi("{\\tilde H}")#text(" to ")#mi("{\\tilde H^{\\prime}}")#text(", and ")#mi("{T^*}")#text(" maps ")#mi("{\\tilde H^{\\prime}}")#text(" to ")#mi("{\\tilde H}")#text("; from the remaining axioms of a partial singular value decomposition we see that ")#tao-math("{\\left\\|T\\right\\|_{B(\\tilde H \\rightarrow \\tilde H^{\\prime})}}", block: false)#text(" on ")#mi("{\\Omega^{\\prime}}")#text(". If ")#tao-math("{\\left\\|T\\right\\|_{B(\\tilde H \\rightarrow \\tilde H^{\\prime})}}", block: false)#text(" vanishes, then ")#mi("{T}")#text(" vanishes on ")#mi("{\\tilde H}")#text(", and one easily obtains the required singular value decomposition in ")#mi("{\\Omega^{\\prime}}")#text(". Now suppose for contradiction that ")#tao-math("{\\left\\|T\\right\\|_{B(\\tilde H \\rightarrow \\tilde H^{\\prime})}}", block: false)#text(" does not (deterministically) vanish, so there is a subevent ")#mi("{E}")#text(" of ")#mi("{\\Omega^{\\prime}}")#text(" of positive probability on which ")#tao-math("{\\left\\|T\\right\\|_{B(\\tilde H \\rightarrow \\tilde H^{\\prime})}}", block: false)#text(" is positive. By Theorem ")#link(<tao-30585c6e3bfbd14b52bb>)[#text("16")]#text(", we can then find unit vectors ")#mi("{e_{N+1} \\in \\Gamma(\\tilde H|E)}")#text(" and ")#mi("{f_{N+1} \\in \\Gamma(\\tilde H^{\\prime}|E)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("Te_{N+1} = \\left\\|T\\right\\|_{B(\\tilde H \\rightarrow \\tilde H^{\\prime})} f_{N+1}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("T^* f_{N+1} = \\left\\|T\\right\\|_{B(\\tilde H \\rightarrow \\tilde H^{\\prime})} e_{N+1}.", block: true)]]

#text("If we then set ")#tao-math("{\\sigma_{N+1} := \\left\\|T\\right\\|_{B(\\tilde H \\rightarrow \\tilde H^{\\prime})}}", block: false)#text(", we can obtain a partial singular value decomposition on ")#mi("{E}")#text(" with ")#mi("{N}")#text(" now set to ")#mi("{\\sup S+1}")#text("; gluing this with the original partial singular value of decomposition on the complement of ")#mi("{E}")#text(", we contradict the maximality of ")#mi("{S}")#text(". This concludes the proof of the spectral theorem on the event that ")#mi("{\\sup S < \\infty}")#text(".")

#text("Now we localise to the complementary event ")#mi("{\\Omega^{\\prime\\prime}}")#text(" that ")#mi("{\\sup S}")#text(" is infinite. Now we need to run a compactness argument before we can ensure that ")#mi("{\\sup S}")#text(" actually lies in ")#mi("{S}")#text(". Namely, for any deterministic natural number ")#mi("{M}")#text(", we can find a partial singular value decomposition with data ")#mi("{N_M, (e_{M,n})_{n=1}^{N_M}, (f_{M,n})_{n=1}^{N_M}, (\\sigma_{M,n})_{n=1}^{N_M}}")#text(" on ")#mi("{\\Omega^{\\prime\\prime}}")#text(" such that ")#mi("{N_M \\geq M}")#text(". We now claim that the ")#mi("{\\sigma_{M,n}}")#text(" decay in ")#mi("{n}")#text(" uniformly in ")#mi("{M}")#text(" in the following sense: for any deterministic real ")#mi("{\\epsilon > 0}")#text(", there exists a stochastic ")#mi("{L_\\epsilon \\in \\Gamma({\\bf N}|\\Omega^{\\prime\\prime})}")#text(" such that ")#mi("{\\sigma_{M,n} \\leq \\epsilon}")#text(" whenever ")#mi("{m \\in {\\bf N}}")#text(" and ")#mi("{n \\in \\Gamma({\\bf N}|\\Omega^{\\prime\\prime})}")#text(" are such that ")#mi("{L_\\epsilon < n \\leq N_M}")#text(". Indeed, from the total boundedness of ")#tao-math("{T \\{ v \\in H: \\left\\|v\\right\\|_H \\leq 1\\}|\\Omega^{\\prime\\prime}}", block: false)#text(", one can cover this space by a union ")#mi("{\\bigcup_{i=1}^{L_\\epsilon} B(w_i, \\epsilon/2)}")#text(" of balls of radius ")#mi("{\\epsilon/2}")#text(" for some ")#mi("{L_\\epsilon \\in \\Gamma({\\bf N}|\\Omega^{\\prime\\prime})}")#text(". If ")#mi("{L_\\epsilon < n \\leq N_M}")#text(" is such that ")#mi("{\\sigma_{M,n} > \\epsilon}")#text(" on some event ")#mi("{E \\subset \\Omega^{\\prime\\prime}}")#text(" of positive probability, then the vectors ")#mi("{T e_{M,m} = \\sigma_{M,m} f_{M,m}}")#text(" for ")#mi("{m \\leq n}")#text(" are ")#mi("{\\epsilon}")#text("-separated on ")#mi("{E}")#text(" by Pythagoras’s theorem, leading to a contradiction since each ball ")#mi("{B(w_i,\\epsilon/2)}")#text(" can capture at most one of these vectors. This gives the claim.")

#text("By repeatedly passing to stochastic subsequences and diagonalising, we may assume that ")#mi("{\\sigma_{M,n}}")#text(" converges stochastically to a limit ")#mi("{\\sigma_n \\in [0,+\\infty)}")#text(" as ")#mi("{M \\rightarrow \\infty}")#text(" for each ")#mi("{n \\in {\\bf N}}")#text(" which is non-increasing. By compactness of ")#mi("{T}")#text(", we may also assume that the ")#mi("{T e_{M,m} = \\sigma_{M,m} f_{M,m}}")#text(" are stochastically convergent in ")#mi("{M}")#text(" for each fixed ")#mi("{m}")#text(", which implies that the ")#mi("{f_{M,m}}")#text(" converge stochastically to a limit ")#mi("{f_m}")#text(" whenever ")#mi("{\\sigma_m > 0}")#text(". A similar argument using the compactness of ")#mi("{T^*}")#text(" allows us to assume that ")#mi("{e_{M,m}}")#text(" converges stochastically to a limit ")#mi("{e_m}")#text(" whenever ")#mi("{\\sigma_m > 0}")#text(". One then easily verifies that the ")#mi("{e_m}")#text(" and ")#mi("{f_m}")#text(" are orthonormal systems when restricted to those ")#mi("{m}")#text(" for which ")#mi("{\\sigma_m> 0}")#text(". Furthermore, a limiting argument shows that whenever ")#mi("{\\epsilon>0}")#text(" is a deterministic real, ")#mi("{E \\subset \\Omega^{\\prime\\prime}}")#text(" is an event, and ")#mi("{v \\in \\Gamma(H|E)}")#text(" is a unit vector orthogonal to ")#mi("{e_m}")#text(" for those ")#mi("{m \\leq L_\\epsilon}")#text(" with ")#mi("{\\sigma_m > 0}")#text(", then ")#tao-math("{\\left\\|Tv\\right\\|_H \\leq \\epsilon}", block: false)#text(". From this and a decomposition into orthonormal bases and a limiting argument we see that")

#align(center)[#tao-fit-display[#mitex("Tv = \\sum_{1 \\leq n \\leq N; \\sigma_n > 0} \\sigma_n \\langle v, e_n \\rangle_H f_n")]]

#text("on ")#mi("{E}")#text(" for any ")#mi("{v \\in \\Gamma(H|E)}")#text(", and the claim follows. ")#mi("\\Box")

#text("Finally, we specialise to the example of Hilbert modules from Example ")#link(<tao-7218c092c768a68d7c37>)[#text("3")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 17 (Singular value decomposition on Hilbert modules)")]#text(" Let ")#mi("{\\Omega_1, \\Omega_2}")#text(" be extensions of a finite measure space ")#mi("{\\Omega}")#text(", with factor maps ")#mi("{\\pi_1: \\Omega_1 \\rightarrow \\Omega}")#text(" and ")#mi("{\\pi_2: \\Omega_2 \\rightarrow \\Omega}")#text(". Let ")#mi("{T: L^2(\\Omega_1) \\rightarrow L^2(\\Omega_2)}")#text(" be a bounded linear map (in the ")#mi("{L^2}")#text(" sense) which is also linear over ")#mi("{L^\\infty(\\Omega)}")#text(" (which embeds via pullback into ")#mi("{L^\\infty(\\Omega_1)}")#text(" and ")#mi("{L^\\infty(\\Omega_2)}")#text("); note that ")#mi("{T}")#text(" may be extended to a linear map from ")#mi("{L^2(\\Omega_1|\\Omega)}")#text(" to ")#mi("{L^2(\\Omega_2|\\Omega)}")#text(". Assume the following Hilbert-Schmidt property: there exists a measurable ")#mi("{A: \\Omega \\rightarrow [0,+\\infty)}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m=1}^M \\sum_{n=1}^N \\left|(\\pi_2)_*( (T e_n) f_m )\\right|^2 \\leq A^2", block: true)]]

#text("for all measurable ")#mi("{M,N: \\Omega \\rightarrow {\\bf N} \\cup \\{\\infty\\}}")#text(" and all ")#mi("{e_n \\in L^2(\\Omega_1), f_m \\in L^2(\\Omega_2)}")#text(" that are orthonormal systems over ")#mi("{L^\\infty(\\Omega_1)}")#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("(\\pi_1)_*(e_n e_{n^{\\prime}}) = 1_{n=n^{\\prime}}")]]

#text("whenever ")#mi("{n,n^{\\prime} \\leq N}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("(\\pi_2)_*(f_m f_{m^{\\prime}}) = 1_{m=m^{\\prime}}")]]

#text("whenever ")#mi("{m,m^{\\prime} \\leq M}")#text(". Then one can find a measurable ")#mi("{N: \\Omega \\rightarrow {\\bf N} \\cup \\{\\infty\\}}")#text(", orthonormal systems ")#mi("{e_n, f_n \\in L^2(\\Omega_1)}")#text(", and ")#mi("{\\sigma_n: \\Omega \\rightarrow (0,+\\infty)}")#text(" defined for ")#mi("{n \\leq N}")#text(" that are non-increasing and decay to zero as ")#mi("{n \\rightarrow \\infty}")#text(" (in the case ")#mi("{N=+\\infty}")#text("), such that")

#align(center)[#tao-fit-display[#mitex("T g = \\sum_{n=1}^N \\sigma_n (\\pi_1)_*(g e_n) f_n")]]

#text("for all ")#mi("{g \\in L^2(\\Omega_1)}")#text(".")
]

#text("In the case that ")#mi("{\\Omega}")#text(" and ")#mi("{\\Omega^{\\prime}}")#text(" are standard Borel, one can obtain this result from the classical spectral theorem via a disintegration argument. However, without such a standard Borel assumption, the most natural way to proceed appears to be through the above topos-theoretic machinery. This result can be used to establish some of the basic facts of the Furstenberg-Zimmer structure theory of measure-preserving systems, and specifically that weakly mixing functions relative to a given factor form the orthogonal complement to compact extensions of that factor, and that such compact extensions are the inverse limit of finite rank extensions. With the above formalism, this can be done even for measure spaces that are not standard Borel, and actions of groups that are not countable; I hope to discuss this in a subsequent post.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4f464b256cb646d314d1b1c994848f488a4cc1449429b88a20cec57318aa75c-651526cac5604a49a5646d164adfb73a8c98f609a696cff6d9523f29a1f9e777.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kawhi w")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-394787")[#strong[#text("kawhi w")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("Oh, my. You get up so early if you are now in LA!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Babuji")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-394951")[#strong[#text("Babuji")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("What a brilliant synthesis. Mozart at work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19d5dfb679cf7c4457f55d1203432e5054280bc9fe83f56cd0df014dfe76731d-153cbbb4646d2aa531c68d1981388e03e617fcb89a8dbd7ad3f6d073c4c62181.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Purves")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-395015")[#strong[#text("Roger Purves")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("A trifling comment, but In the third paragraph, I would have expected you to start with a measure space, since a measure (or some sort of sigma-ideal appended to a measurable space) is required to get to the almost sure equalities.")

#text("(Thank you for the wonderful and generous blog.)")

#text("Roger Purves")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-395020")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2014")])]

#text("To describe almost sure equivalence of two maps ")#mi("f, f^{\\prime}: \\Omega \\to X")#text(", the base ")#mi("\\Omega")#text(" needs to be a measure space, but the range ")#mi("X")#text(" only needs to be a measurable space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/19d5dfb679cf7c4457f55d1203432e5054280bc9fe83f56cd0df014dfe76731d-153cbbb4646d2aa531c68d1981388e03e617fcb89a8dbd7ad3f6d073c4c62181.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger Purves")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-395519")[#strong[#text("Roger Purves")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2014")])]

#text("Oops! I am feeling a little sheepish about reading so carelessly. Thank you for taking the time to spell it out.")

#text("RP")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/385c9b61df9e8936545ffb89ef4d3a06c20d53805661bc8f913e8956198e2179-f163f5396cc358a7c4dc754f361e42ab3100ff341696b58b519c918e65fe0723.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Lacruz")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-395793")[#strong[#text("Miguel Lacruz")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2014")])]

#text("The display before Theorem 15 reads ")#mi("\\langle Tv,w \\rangle_{H^\\prime} =  \\langle v,T^\\ast w \\rangle_{H^\\prime}")#text(" and it should read ")#mi("\\langle Tv,w \\rangle_{H^\\prime} =  \\langle v,T^\\ast w \\rangle_{H}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7bf107c3783d7a6ca4e01321852ac52a13bf66490351ef74eb3fb30513dffd1c-8ac4bb51243c74382155f8362324925734c9c1107b8513baf7076451b3a35ec6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-396176")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("I am thrown off. You are doing analysis with respect to “finite” measure spaces. How should I think of ")#mi("\\Omega")#text("? Should I think of ")#mi("\\omega \\in \\{ 0,1 \\}")#text(" or ")#mi("\\omega \\in \\{ 0,1 \\}^\\mathbb{Z}")#text(" ? What is finite here?")

#text("In any case, I think ")#mi("\\Omega")#text(" the space of exogenous “stuff” we can’t account for.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-396602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2014")])]

#text("A ")#link("http://en.wikipedia.org/wiki/%CE%A3-finite_measure")[#text("finite measure space")]#text(" is a measure space ")#mi("\\Omega = (\\Omega, {\\mathcal B}, \\mu)")#text(" whose total measure ")#mi("\\mu(\\Omega)")#text(" is finite; for instance, the unit interval ")#mi("[0,1]")#text(" with Lebesgue measure is a finite measure space, and more generally all probability spaces are finite measure spaces.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/751699ccd697d6f401249dc303b98764de17c228d28587a956ed7538f3181d77-a9c52c32a66111f400b8375a02f5c48bec598b6678e17dde69c9491754974cd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hongseok Yang")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-400544")[#strong[#text("Hongseok Yang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2014")])]

#text("Would you spell out the definitions of the stochastic sets ")#mi("{\\bf N} | \\Omega")#text(" and ")#mi("\\{true, false\\} | \\Omega")#text("? Thanks.")

#emph[#text("[See Example 2. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b10df79fa1bdfae913029bd9b0875b0257105583782793619523aef9b0e5dba3-356beaa61e0fef4d201395f7a10b2622a2eaad96cf6d5a3097693799b0f13e08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dan Lacker")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-400783")[#strong[#text("Dan Lacker")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2014")])]

#text("Really lovely post! And since I’m new here, I must thank you for maintaining a fantastic blog.")

#text("I want to point out a striking resemblance between much of this post and the theory of “conditional sets,” developed recently in ")#link("http://arxiv.org/abs/1309.6903")[#text("this paper")]#text(". (See also ")#link("http://edoc.hu-berlin.de/dissertationen/jamneshan-asgar-2014-02-07/PDF/jamneshan.pdf")[#text("this PhD thesis")]#text(" for a more thorough account.)")

#text("To summarize: A conditional set is like a stochastic set, except that ")#mi("\\Gamma(X|E)")#text(" may be indexed by elements ")#mi("E")#text(" of a fixed complete Boolean algebra ")#mi("\\mathcal{A}")#text(" (satisfying an important additional assumption). A notable special case is when ")#mi("\\mathcal{A}")#text(" is the family of measurable subsets of some finite measure space, modulo null sets. In your definition of stochastic set, it seems natural to index ")#mi("\\Gamma(X|E)")#text(" by ")#mi("\\mathcal{B}")#text("-modulo-null-sets, rather than by ")#mi("\\mathcal{B}")#text(" itself, in which case a stochastic set would be a special case of conditional set. The above papers also work through some natural notions of analysis relative to conditional sets, parallel to the first part of this post (up to section 2), as well as general topological spaces. If you work modulo null sets, the measure algebra satisfies the countable chain condition, which appears to be essentially what allows the authors to make sense of uncountable unions of (and thus general topological spaces built on) conditional sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/351ceccad3063e90a1587e715eee458868a3dc6350e67f2c8f66d7a2aad154e8-9af408dc951102f1d7ee5e87dd07fa3cb3ab2771227cef402eb960ae0e11cea1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A nonstandard analysis proof of Szemeredi’s theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-457539")[#strong[#text("A nonstandard analysis proof of Szemeredi’s theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2015")])]

#text("[…] the relative spectral theorem for relative Hilbert-Schmidt operators (see Corollary 17 of this blog post), we may thus find relatively orthonormal systems in and respectively over and a non-increasing […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/07/15/real-analysis-relative-to-a-finite-measure-space/comment-page-1/#comment-684572")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2024")])]

#text("Professor Tao … I have deep feeling for the mathematical notions you discuss here but I do not have the particular mathematical linguistic fluency to participate in the accepted technical lexicon of your discussions. I am able to describe some mathematical objects in my own language and vocabulary which you would have to intuit and translate into your own parallel orthodox thought image.")#linebreak()#text(" I have a question regarding ‘deterministic’ objects and ‘stochastic’ objects. I follow many of your lectures such as Correlations of Multiplicative Functions, Erdos Discrepancy Problem, Pseudorandomness of the Liouville function and other end of the line discussion on the seive Parity problem. I work on the Parity problem … and have found some answers.")

#text("Do you consider a list of consecutive primes a deterministic object or a stochastic object? … do you consider the number of primes less than a number n,say Pi(n), to be a deterministically defined number or only approachable by randomness study?")#linebreak()#text(" In your public addresses you always preface that a synthesis of the distribution of the primes is the fundamental drive of Number theory, besides being your avowed personal quest/hobby … You have made many advances in understanding relationships between individual elements of the set of primes … have you ever considered the set of primes as a set with one element? … that element being the full, or some finite set, of the primes. In some sense such an outlook might suggest looking for relationships between individual anonymous primes is a bit meaningless and history suggests that it has never been all that fruitfull. Maybe all one has to do his figure out how to make ONE element. Maybe ALL the primes are made in one fell swoop. Such as maybe by applying one operation to the number 1 … division is the operation that comes to mind for me but many might say multiplication could be the trigger for a massive instantaneous avalanche of the infinite set of individual primes as the lone element of the set of primes. Inside this lone element lets stick to some cut off point n in the natural numbers ie make it finite. Then the number of elements inside this single element of the set of primes is Pi(n)")

#text("Now Pi(n) is precisely and exactly our number n, minus, the number of composite numbers less than n. More accurately it is (n-1) minus the number of composite numbers, call C(n) less/equal to n.")#linebreak()#text(" C(n) is absolutely 100% deterministically combinatorically computer countable from the list of primes up to n/2 … very simple beautiful algorithm extracted from non-repeating Eratothsenes seive-like multiplication procedure to count the composite numbers less than n. Pi(n) = (n-1)- C(n) is 100% direct simple exact countable function of Pi(n/2) … pure deterministic relationship between the two numbers at x and 2x. So what I’m saying here Professor Tao is: give me the list of primes up to x and I will give you the EXACT number of primes up to 2x … on a simple PC with no factorization of any numbers after x required … tested to n = 10^15 takes about ten hours")

#text("A simple equivalent output of the algorithm which incidentally carries ALL information on the Liouville function produces the sum of the Liouville function … my seive identifies the parity of every number less than n from only information on numbers less than n/2 … the secret is in the ordered harmonic structure of the algorithm")#linebreak()#text(" Jenda Vondra")
]
