// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/
// Converted to Typst by tao2typ: "2026-10-14T15:20:40.205425+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Varieties of general type with many vanishing plurigenera, and optimal sine and sawtooth inequalities", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Varieties of general type with many vanishing plurigenera, and optimal sine and sawtooth inequalities")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 July 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/")[#text("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://www.math.ucla.edu/~esserl/")[#text("Louis Esser")]#text(", ")#link("https://www.math.ucla.edu/~totaro/")[#text("Burt Totaro")]#text(", ")#link("https://sites.google.com/view/hyd6flw")[#text("Chengxi Wang")]#text(", and myself have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2107.11058")[#text("Varieties of general type with many vanishing plurigenera, and optimal sine and sawtooth inequalities")]#text("“. This is an interdisciplinary paper that arose because in order to optimize a certain algebraic geometry construction it became necessary to solve a purely analytic question which, while simple, did not seem to have been previously studied in the literature. We were able to solve the analytic question exactly and thus fully optimize the algebraic geometry construction, though the analytic question may have some independent interest.")

#text("Let us first discuss the algebraic geometry application. Given a smooth complex ")#mi("{n}")#text("-dimensional projective variety ")#mi("{X}")#text(" there is a standard line bundle ")#mi("{K_X}")#text(" attached to it, known as the ")#link("https://en.wikipedia.org/wiki/Canonical_bundle")[#text("canonical line bundle")]#text("; ")#mi("{n}")#text("-forms on the variety become sections of this bundle. The bundle may not actually admit global sections; that is to say, the dimension ")#mi("{h^0(X, K_X)}")#text(" of global sections may vanish. But as one raises the canonical line bundle ")#mi("{K_X}")#text(" to higher and higher powers to form further line bundles ")#mi("{mK_X}")#text(", the number of global sections tends to increase; in particular, the dimension ")#mi("{h^0(X, mK_X)}")#text(" of global sections (known as the ")#mi("{m^{th}}")#text(" ")#link("https://en.wikipedia.org/wiki/Kodaira_dimension#The_plurigenera")[#text("plurigenus")]#text(") always obeys an asymptotic of the form")

#align(center)[#tao-fit-display[#mitex("h^0(X, mK_X) = \\mathrm{vol}(X) \\frac{m^n}{n!} + O( m^{n-1} )")]]

#text("as ")#mi("{m \\rightarrow \\infty}")#text(" for some non-negative number ")#mi("{\\mathrm{vol}(X)}")#text(", which is called the ")#emph[#text("volume")]#text(" of the variety ")#mi("{X}")#text(", which is an invariant that reveals some information about the ")#link("https://en.wikipedia.org/wiki/Birational_geometry")[#text("birational geometry")]#text(" of ")#mi("{X}")#text(". For instance, if the canonical line bundle is ")#link("https://en.wikipedia.org/wiki/Ample_line_bundle")[#text("ample")]#text(" (or more generally, ")#link("https://en.wikipedia.org/wiki/Nef_line_bundle")[#text("nef")]#text("), this volume is equal to the ")#link("https://en.wikipedia.org/wiki/Intersection_number")[#text("intersection number")]#text(" ")#mi("{K_X^n}")#text(" (roughly speaking, the number of common zeroes of ")#mi("{n}")#text(" generic sections of the canonical line bundle); this is a special case of the ")#link("https://en.wikipedia.org/wiki/Hirzebruch%E2%80%93Riemann%E2%80%93Roch_theorem#Asymptotic_Riemann-Roch")[#text("asymptotic Riemann-Roch theorem")]#text(". In particular, the volume ")#mi("{\\mathrm{vol}(X)}")#text(" is a natural number in this case. However, it is possible for the volume to also be fractional in nature. One can then ask: how small can the volume get ")#mi("{\\mathrm{vol}(X)}")#text(" without vanishing entirely? (By definition, varieties with non-vanishing volume are known as ")#link("https://en.wikipedia.org/wiki/Kodaira_dimension#General_type")[#text("varieties of general type")]#text(".)")

#text("It follows from a deep result obtained independently by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2242631")[#text("Hacon–McKernan")]#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2242627")[#text("Takayama")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2360948")[#text("Tsuji")]#text(" that there is a uniform lower bound for the volume ")#mi("{\\mathrm{vol}(X)}")#text(" of all ")#mi("{n}")#text("-dimensional projective varieties of general type. However, the precise lower bound is not known, and the current paper is a contribution towards probing this bound by constructing varieties of particularly small volume in the high-dimensional limit ")#mi("{n \\rightarrow \\infty}")#text(". Prior to this paper, the best such constructions of ")#mi("{n}")#text("-dimensional varieties basically had exponentially small volume, with a construction of volume at most ")#mi("{e^{-(1+o(1))n \\log n}}")#text(" given ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3169486")[#text("by Ballico–Pignatelli–Tasin")]#text(", and an improved construction with a volume bound of ")#mi("{e^{-\\frac{1}{3} n \\log^2 n}}")#text(" given by ")#link("https://arxiv.org/abs/2104.12200")[#text("Totaro and Wang")]#text(". In this paper, we obtain a variant construction with the somewhat smaller volume bound of ")#mi("{e^{-(1-o(1)) n^{3/2} \\log^{1/2} n}}")#text("; the method also gives comparable bounds for some other related algebraic geometry statistics, such as the largest ")#mi("{m}")#text(" for which the pluricanonical map associated to the linear system ")#tao-math("{\\left|mK_X\\right|}", block: false)#text(" is not a birational embedding into projective space.")

#text("The space ")#mi("{X}")#text(" is constructed by taking a general hypersurface of a certain degree ")#mi("{d}")#text(" in a ")#link("https://en.wikipedia.org/wiki/Weighted_projective_space")[#text("weighted projective space")]#text(" ")#mi("{P(a_0,\\dots,a_{n+1})}")#text(" and resolving the singularities. These varieties are relatively tractable to work with, as one can use standard algebraic geometry tools (such as the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=605348")[#text("Reid")]#text("–")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=669424")[#text("Tai")]#text(" inequality) to provide sufficient conditions to guarantee that the hypersurface has only ")#link("https://en.wikipedia.org/wiki/Canonical_singularity")[#text("canonical")]#text(" singularities and that the canonical bundle is a ")#link("https://en.wikipedia.org/wiki/Reflexive_sheaf")[#text("reflexive sheaf")]#text(", which allows one to calculate the volume exactly in terms of the degree ")#mi("{d}")#text(" and weights ")#mi("{a_0,\\dots,a_{n+1}}")#text(". The problem then reduces to optimizing the resulting volume given the constraints needed for the above-mentioned sufficient conditions to hold. After working with a particular choice of weights (which consist of products of mostly consecutive primes, with each product occuring with suitable multiplicities ")#mi("{c_0,\\dots,c_{b-1}}")#text("), the problem eventually boils down to trying to minimize the total multiplicity ")#mi("{\\sum_{j=0}^{b-1} c_j}")#text(", subject to certain congruence conditions and other bounds on the ")#mi("{c_j}")#text(". Using crude bounds on the ")#mi("{c_j}")#text(" eventually leads to a construction with volume at most ")#mi("{e^{-0.8 n^{3/2} \\log^{1/2} n}}")#text(", but by taking advantage of the ability to “dilate” the congruence conditions and optimizing over all dilations, we are able to improve the ")#mi("{0.8}")#text(" constant to ")#mi("{1-o(1)}")#text(".")

#text("Now it is time to turn to the analytic side of the paper by describing the optimization problem that we solve. We consider the ")#emph[#text("sawtooth")]#text(" function ")#mi("{g: {\\bf R} \\rightarrow (-1/2,1/2]}")#text(", with ")#mi("{g(x)}")#text(" defined as the unique real number in ")#mi("{(-1/2,1/2]}")#text(" that is equal to ")#mi("{x}")#text(" mod ")#mi("{1}")#text(". We consider a (Borel) probability measure ")#mi("{\\mu}")#text(" on the real line, and then compute the average value of this sawtooth function")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_\\mu g(x) := \\int_{\\bf R} g(x)\\ d\\mu(x)")]]

#text("as well as various dilates")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E}_\\mu g(kx) := \\int_{\\bf R} g(kx)\\ d\\mu(x)")]]

#text("of this expectation. Since ")#mi("{g}")#text(" is bounded above by ")#mi("{1/2}")#text(", we certainly have the trivial bound")

#align(center)[#tao-fit-display[#mitex("\\min_{1 \\leq k \\leq m} \\mathop{\\bf E}_\\mu g(kx) \\leq \\frac{1}{2}.")]]

#text("However, this bound is not very sharp. For instance, the only way in which ")#mi("{\\mathop{\\bf E}_\\mu g(x)}")#text(" could attain the value of ")#mi("{1/2}")#text(" is if the probability measure ")#mi("{\\mu}")#text(" was supported on half-integers, but in that case ")#mi("{\\mathop{\\bf E}_\\mu g(2x)}")#text(" would vanish. For the algebraic geometry application discussed above one is then led to the following question: for a given choice of ")#mi("{m}")#text(", what is the best upper bound ")#mi("{c^{\\mathrm{saw}}_m}")#text(" on the quantity ")#mi("{\\min_{1 \\leq k \\leq m} \\mathop{\\bf E}_\\mu g(kx)}")#text(" that holds for all probability measures ")#mi("{\\mu}")#text("?")

#text("If one considers the deterministic case in which ")#mi("{\\mu}")#text(" is a Dirac mass supported at some real number ")#mi("{x_0}")#text(", then the ")#link("https://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(" tells us that there is ")#mi("{1 \\leq k \\leq m}")#text(" such that ")#mi("{x_0}")#text(" is within ")#mi("{\\frac{1}{m+1}}")#text(" of an integer, so we have")

#align(center)[#tao-fit-display[#mitex("\\min_{1 \\leq k \\leq m} \\mathop{\\bf E}_\\mu g(kx) \\leq \\frac{1}{m+1}")]]

#text("in this case, and this bound is sharp for deterministic measures ")#mi("{\\mu}")#text(". Thus we have")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{m+1} \\leq c^{\\mathrm{saw}}_m \\leq \\frac{1}{2}.")]]

#text("However, both of these bounds turn out to be far from the truth, and the optimal value of ")#mi("{c^{\\mathrm{saw}}_m}")#text(" is comparable to ")#mi("{\\frac{\\log 2}{\\log m}}")#text(". In fact we were able to compute this quantity precisely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Optimal bound for sawtooth inequality)")]#text(" Let ")#mi("{m \\geq 1}")#text(".")

#list(
[#text("(i) If ")#mi("{m = 2^r}")#text(" for some natural number ")#mi("{r}")#text(", then ")#mi("{c^{\\mathrm{saw}}_m = \\frac{1}{r+2}}")#text(".")],
[#text("(ii) If ")#mi("{2^r < m \\leq 2^{r+1}}")#text(" for some natural number ")#mi("{r}")#text(", then ")#mi("{c^{\\mathrm{saw}}_m = \\frac{2^r}{2^r(r+1) + m}}")#text(".")]
)

#text("In particular, we have ")#mi("{c^{\\mathrm{saw}}_m = \\frac{\\log 2 + o(1)}{\\log m}}")#text(" as ")#mi("{m \\rightarrow \\infty}")#text(".")
]

#text("We establish this bound through duality. Indeed, suppose we could find non-negative coefficients ")#mi("{a_1,\\dots,a_m}")#text(" such that one had the pointwise bound ")#metadata(none) <tao-0e84c1a9816e66b9e790>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{k=1}^m a_k g(kx) \\leq 1")]]

#text(" ")#text(" for all real numbers ")#mi("{x}")#text(". Integrating this against an arbitrary probability measure ")#mi("{\\mu}")#text(", we would conclude")

#align(center)[#tao-fit-display[#mitex("(\\sum_{k=1}^m a_k) \\min_{1 \\leq k \\leq m} \\mathop{\\bf E}_\\mu g(kx) \\leq \\sum_{k=1}^m a_k \\mathop{\\bf E}_\\mu g(kx) \\leq 1")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("c^{\\mathrm{saw}}_m \\leq \\frac{1}{\\sum_{k=1}^m a_k}.")]]

#text("Conversely, one can find lower bounds on ")#mi("{c^{\\mathrm{saw}}_m}")#text(" by selecting suitable candidate measures ")#mi("{\\mu}")#text(" and computing the means ")#mi("{\\mathop{\\bf E}_\\mu g(kx)}")#text(". The theory of ")#link("https://en.wikipedia.org/wiki/Dual_linear_program")[#text("linear programming duality")]#text(" tells us that this method must give us the optimal bound, but one has to locate the optimal measure ")#mi("{\\mu}")#text(" and optimal weights ")#mi("{a_1,\\dots,a_m}")#text(". This we were able to do by first doing some extensive numerics to discover these weights and measures for small values of ")#mi("{m}")#text(", and then doing some educated guesswork to extrapolate these examples to the general case, and then to verify the required inequalities. In case (i) the situation is particularly simple, as one can take ")#mi("{\\mu}")#text(" to be the discrete measure that assigns a probability ")#mi("{\\frac{1}{r+2}}")#text(" to the numbers ")#mi("{\\frac{1}{2}, \\frac{1}{4}, \\dots, \\frac{1}{2^r}}")#text(" and the remaining probability of ")#mi("{\\frac{2}{r+2}}")#text(" to ")#mi("{\\frac{1}{2^{r+1}}}")#text(", while the optimal weighted inequality ")#link(<tao-0e84c1a9816e66b9e790>)[#text("(1)")]#text(" turns out to be")

#align(center)[#tao-fit-display[#mitex("2g(x) + \\sum_{j=1}^r g(2^j x) \\leq 1")]]

#text("which is easily proven by telescoping series. However the general case turned out to be significantly tricker to work out, and the verification of the optimal inequality required a delicate case analysis (reflecting the fact that equality was attained in this inequality in a large number of places).")

#text("After solving the sawtooth problem, we became interested in the analogous question for the sine function, that is to say what is the best bound ")#mi("{c^{\\sin}_m}")#text(" for the inequality")

#align(center)[#tao-fit-display[#mitex("\\min_{1 \\leq k \\leq m} \\mathop{\\bf E}_\\mu \\sin(kx) \\leq c^{\\sin}_m.")]]

#text("The left-hand side is the smallest imaginary part of the first ")#mi("{m}")#text(" Fourier coefficients of ")#mi("{\\mu}")#text(". To our knowledge this quantity has not previously been studied in the Fourier analysis literature. By adopting a similar approach as for the sawtooth problem, we were able to compute this quantity exactly also:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2")]#text(" For any ")#mi("{m \\geq 1}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("c^{\\sin}_m = \\frac{m+1}{2 \\sum_{1 \\leq j \\leq m: j \\text{ odd}} \\cot \\frac{\\pi j}{2m+2}}.")]]

#text("In particular,")

#align(center)[#tao-fit-display[#mitex("c^{\\sin}_m = \\frac{\\frac{\\pi}{2} + o(1)}{\\log m}.")]]
]

#text("Interestingly, a closely related cotangent sum recently appeared in ")#link("https://mathoverflow.net/questions/368803/the-cotangent-sum-sum-k-0n-1-1k-cot-big-frac-pi4n2k1-big-n/")[#text("this MathOverflow post")]#text(". Verifying the lower bound on ")#mi("{c^{\\sin}_m}")#text(" boils down to choosing the right test measure ")#mi("{\\mu}")#text("; it turns out that one should pick the probability measure supported the ")#mi("{\\frac{\\pi j}{2m+2}}")#text(" with ")#mi("{1 \\leq j \\leq m}")#text(" odd, with probability proportional to ")#mi("{\\cot \\frac{\\pi j}{2m+2}}")#text(", and the lower bound verification eventually follows from a classical identity")

#align(center)[#tao-fit-display[#mitex("\\frac{m+1}{2} = \\sum_{1 \\leq j \\leq m; j \\text{ odd}} \\cot \\frac{\\pi j}{2m+2} \\sin \\frac{\\pi jk}{m+1}")]]

#text("for ")#mi("{1 \\leq k \\leq m}")#text(", first posed by Eisenstein in 1844 and proved by Stern in 1861. The upper bound arises from establishing the trigonometric inequality")

#align(center)[#tao-fit-display[#mitex("\\frac{2}{(m+1)^2} \\sum_{1 \\leq k \\leq m; k \\text{ odd}}")]]

#align(center)[#tao-fit-display[#mitex("\\cot \\frac{\\pi k}{2m+2} ( (m+1-k) \\sin kx + k \\sin(m+1-k)x ) \\leq 1")]]

#text("for all real numbers ")#mi("{x}")#text(", which to our knowledge is new; the left-hand side has a Fourier-analytic intepretation as convolving the Fejér kernel with a certain discretized square wave function, and this interpretation is used heavily in our proof of the inequality.")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-631941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("Is it possible to generalize the above optimal sawtooth and sine inequalities to similar inequalities for a general class of periodic functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632039")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2021")])]

#text("I think there should be analogous results for any periodic function that vanishes near the origin, though perhaps not with as precise a bound as we found for the sawtooth and sine functions. Perhaps one reasonable conjecture is that the optimal bound for, say, a trigonometric polynomial vanishing at the origin, is always comparable to ")#mi("\\frac{1}{\\log m}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/143c544571e80a3cf438085cc22cdd6ee5f18e956de7a0f03326247396a9c295-1cd0848b805096874077c387ff9b4ebbbdb0dd350cf3e18158aef72a34e6a0b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duck_master")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-634219")[#strong[#text("duck_master")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2021")])]

#text("I’ve devoted quite a bit of thought to this conjecture. Here’s what I have so far. For notational consistency I’ll refer to the trigonometric polynomial* which we’re studying as ")#mi("g")#text(" as you’ve done (when trying to estimate ")#mi("\\text{min}_{1\\leq k\\leq m} E_{\\mu} g(kx)")#text("). WARNING: this is an unusually long comment.")

#text("First of all, one should restrict ")#mi("g")#text(" to be odd, or at the very least to be a function of expectation zero over its entire period. If ")#mi("g")#text(" has a positive expectation, the uniform measure ")#mi("\\mu_{unif}")#text(" over the entire period already scores at ")#mi("E_{\\mu_{unif}} g(x)")#text(" with respect to what we’re trying to optimize, which is within a constant factor of the trivial upper bound ")#mi("\\text{max} g")#text(".* I expect similar things to hold for other functions that are periodic but not odd.")

#text("However, if we restrict ")#mi("g")#text(" to be odd (so that we can write ")#mi("g(x) = \\sum_h a_h\\sin(hx)")#text("), then the two halves of this conjecture – upper and lower bounds – still vastly differ in difficulty. Upper bounds are easy: we know that ")#tao-math("\\left|\\sum_{k\\leq m} \\frac{\\sin(kx)}{k}\\right|", block: false)#text(" is always bounded (I believe strictly by 2 from graphing, though I lack a reference or proof for this at hand), so by the triangle inequality we can trivially conclude that ")#tao-math("\\left|\\sum_{k\\leq m}\\frac{g(kx)}{k}\\right| \\leq C\\sum_h \\left|a_h\\right|", block: false)#text(", so that ")#mi("\\text{min}_{1\\leq k\\leq m} E_{\\mu} g(kx) \\lesssim\\frac{1}{\\log(m)}")#text(".")

#text("In contrast with upper bounds, lower bounds for odd ")#mi("g")#text(" are far more difficult, though I’ve managed (I think) to obtain the desired lower bound when ")#mi("\\sum_h a_h\\neq 0")#text(". As in each case I considered, we just use the measure ")#mi("\\mu := \\frac{1_{\\frac{1}{m}\\leq x\\leq 1}dx}{x\\log(m)}")#text(".*** **** To illustrate the difficulties I encountered in the ")#mi("\\sum_h a_h = 0")#text(" case, it suffices to consider the case ")#mi("g_1(x) := \\sin(2\\pi x) - \\sin(\\pi x)")#text("; we can compute ")#mi("E_{\\mu} g_1(kx) = \\int_{\\frac{k}{m}}^k \\frac{g_1(x)}{x\\log(m)} = \\int_0^{\\infty} \\frac{g_1(x)}{x\\log(m)} - \\int_0^{\\frac{k}{m}} \\frac{g_1(x)}{x\\log(m)} - \\int_k^{\\infty} \\frac{g_1(x)}{x\\log(m)}")#text(". Ordinarily, the first term would be the main term and be about ")#mi("\\frac{\\sum_h a_h}{\\log(m)}")#text(", whereas the other terms would be like error terms; however, in this case, the main term *cancels*! The second term is about ")#mi("\\pi \\frac{k}{m\\log(m)}")#text(" since ")#mi("\\lim_{x\\to 0}\\frac{g_1(x)}{x} = \\pi")#text(", and the third term is about some factor of ")#mi("\\frac{1}{k\\log(m)}")#text(" (I believe that ")#mi("\\int_k^{\\infty}\\frac{\\sin(\\pi x)}{x} \\approx \\sum_t\\frac{C_t}{k^t}")#text(" for appropriate constants ")#mi("C_t")#text(" and integers ")#mi("k\\to\\infty")#text(", though I again lack a reference or proof for this). Optimizing with respect to k using standard AM-GM trickery, we obtain a lower bound of ")#mi("\\frac{1}{m^{1/2}\\log(m)}")#text(", which is still respectable, but far below what we want. (A generalization of this argument would give ")#mi("\\text{min}_{1\\leq k\\leq m} E_{\\mu} g(kx)\\gtrsim \\frac{1}{m^A \\log(m)}")#text(", where A is a positive rational number.)")

#text("*Though I expect this to hold for functions that are much less regular, such as all analytic functions, or perhaps even all functions for which each successive derivative is only undefined at a set of measure zero.")

#text("**I actually discovered this while pondering the model case of the “even sawtooth” ")#mi("g_{evensaw}")#text(", which we can define as the only function of period 1 satisfying ")#tao-math("\\forall x\\in[-1/2, 1/2): g_{evensaw}(x) = \\left|x\\right|", block: false)#text(". Naturally, if we are allowed to study arbitrary functions ")#mi("g")#text(", then a natural approach is to find nice pointwise bounds ")#mi("g_L\\leq g\\leq g_U")#text(" and to then estimate ")#mi("\\text{min}_{1\\leq k\\leq m} E_{\\mu} g_L(kx), \\text{min}_{1\\leq k\\leq m} E_{\\mu} g_U(kx)")#text(". The oddness constraint obviously makes this approach unavailable.")

#text("***Inspiration for this choice: I noticed that each of the optimal measures you constructed devoted roughly equal weight to the scales ")#mi("[1/2, 1), [1/4, 1/2), ... [1/2^r, 1/2^{r - 1})")#text(" where $r:=\\lceil\\log_2(m)\\rceil$, so I decided to choose a smooth measure that also shared this feature. Also, if ")#mi("\\sum_h a_h")#text(" is negative, or the analogue of that, then simply flip this measure to the opposite side of zero.")

#text("****I have a heuristic argument for this: Dyadically divide your measure ")#mi("\\mu")#text(" into the scales measured at the previous footnote. The contribution to ")#mi("E_{\\mu} g(kx)")#text(" from scales that are much smaller than ")#mi("\\frac{1}{k}")#text(" is close to zero because ")#mi("g(kx) \\approx 0")#text(" if ")#mi("x")#text(" belongs to such a scale. The contribution from scales much *larger* than ")#mi("\\frac{1}{k}")#text(" is also close to zero because multiplication by ")#mi("k")#text(" causes the distribution at this scale modulo period to resemble the uniform distribution (in the sense, at least, of distributions converging in probability), so its contribution will be about the expectation of ")#mi("g")#text(", which is also zero. Hence the only significant contributions will come from the scales close to that of ")#mi("\\frac{1}{k}")#text(", which will have to be about a constant times the measure of such a scale. Since ")#mi("\\mu")#text(" has ")#mi("\\log(m)")#text(" scales to accommodate, the mimimum expectation must be at most ")#mi("\\frac{1}{\\log(m)}")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62702c255859093acbd9621566fb06a68327033876fd3d049dc908168b773bc0-ce155a2d9b59db5fc41869cf040d67fc060e22e3402d48c0b6ce3e5dbb86d698.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-631974")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("You once told me it’d be a cold day in Hell when you wrote an algebraic geometry paper, with snow expected, so maybe I shouldn’t press you on the following issues (but I will!). If you want to talk about the “canonical line bundle”, you should probably ask that your variety be smooth. (Technically, it’s enough that your variety be Gorenstein.) Later (in “The space X” paragraph) it seems that you don’t actually want to require X smooth, and indeed don’t actually want the canonical sheaf to be a line bundle, just a reflexive sheaf. But you mention resolving the singularities, so maybe your varieties actually _are_ smooth?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632038")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2021")])]

#text("Fair enough, I’ve now added the hypothesis that the variety is smooth, though my understanding is that if the variety has only canonical singularities (and the canonical sheaf is reflexive) then any smooth resolution of the variety will produce the same volume. So one can just as well work with smooth models in this case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1d380eed1b8ce19b306ee631f0f7fe4ba8d1640f6aa7c87ba99c149981c1db51-0db9cb72e4fcae65beb249711891235ac47b6fffa63daa1b48a69b7c6c0c9b05.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of h0sane")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632899")[#strong[#text("h0sane")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2021")])]

#text("Sorry I’m still a beginner, but by variety do you mean algebraic varieties ? Sorry if silly question I’m barely applying for PhDs this year so forgive me for my naive ness. I briefly studied them in my intro to Riemann surface course via Algebraic Curves & Riemann surfaces by Miranda. Thank you – fellow math student.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-631981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2021")])]

#text("Minor typos: The last equation is missing an equals sign and the last paragraph is trying to put the accent over the j and not the second e in Fej\\’er")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632049")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2021")])]

#text("What do you mean by ")#mi("{mK_X}")#text(" in the phrase “for which ")#mi("{mK_X}")#text(" does not admit a birational embedding into projective space”. The divisor?")

#emph[#text("[Yeah, or more precisely a complete linear system of divisors. I guess this is more commonly denoted ")#tao-math("\\left|mK_X\\right|", block: false)#text(", will edit to reflect this. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632098")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2021")])]

#text("Let me spell this out just to make sure I understand correctly. We are saying there is no birational embedding of ")#mi("X")#text(" into a projective space such that the pullback of (the linear system of) ")#mi("\\mathscr{O}(1)")#text(" gives the linear system ")#tao-math("\\left|mK_X\\right|", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632205")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2021")])]

#text("I’m not sure that’s an equivalent formulation. The way it is normally phrased is that each natural number ")#mi("m")#text(" induces a morphism (called the ")#mi("m^{th}")#text(" pluricanonical map) from ")#mi("X")#text(" to the projective space ")#mi("\\mathbb{P}( H^0({\\mathcal O}_X(mK_X)) )")#text(" formed by evaluating the linear system ")#tao-math("\\left|mK_X\\right|", block: false)#text(" at every point and projectivising. The property of being of general type is precisely equivalent to this canonical map being a birational embedding for large enough ")#mi("m")#text(". The result of Hacon-McKernan, Takayama, and Tsuji referred to in the blog post asserts that the bound for “large enough” can be made uniform in the dimension ")#mi("n")#text(" of ")#mi("X")#text(" (this is related to the “")#link("https://en.wikipedia.org/wiki/Minimal_model_program")[#text("minimal model program")]#text("” in algebraic geometry, though I am not familiar with the details). The examples we have show that the bound still needs to grow quite quickly in ")#mi("n")#text(" (at least ")#mi("\\exp( (1-o(1)) n^{1/2} \\log^{1/2} n)")#text(", to be precise). But as far as I know, this does not rule out the possibility of having a non-pluricanonical birational embedding into a lower dimensional projective space. I’ve modified the text in the blog post to try to clarify this point.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BabaEpsilon")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632527")[#strong[#text("BabaEpsilon")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2021")])]

#text("Hi Terence Tao the Great,")#linebreak()#text(" The legend says that every field of mathematics you get into, you advance the field.")#linebreak()#text(" I would like you to get into Geometric complexity theory because it is the most promising approach towards solving P vs NP we have right now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2021")])]

#text("Don’t worry verry much,")#linebreak()#text(" You wait a little time , Pro Tao certainly makes maths community going from this amazing to another amazing. ProTao is still very young, but he has published more 300 papers within short time, this has not been made by any other mathematician in the world if considering the same his generation. By the way, he is still a human , he is not a machine, he needs much time to rest, he spends a little time in caring his family . But , I really inform you that pro Tao has made a great breakthrough on Navier Stokes existence and smoothness this year. Only owner of this Clay miillenium award is pro Tao. I am allowed to reveal my name, but I am always near pro Tao every minute, every hour.")#linebreak()#text(" Bye,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69120b2d94527eaa02aefe22d5f672410fc779d79d92c251f1ed9a809f58cb3d-0eb934424fd4d4ca0af0ca4835c73021d943705259df81193b49f32f8c4bbb85.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twocents")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632589")[#strong[#text("twocents")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2021")])]

#text("If you noticed he does not get into speculative stuff (which includes geometric complexity theory) but observes ‘expert’ opinion which he gets a lot and there are a lot of self-proclaimed experts out there and he only goes in after a convincing argument. He is not Gauss but we know he is more talented than anyone anyone has known.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a85e534696ef6a0b6a5de0f1f3f2b205d025b177f4c552a5cde01e8ac58998c-a21243e72d71594e72e6ae5e24a36cb646d0820c1842d239a68e887d4d7403c2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 🔜 i’ll get it: Varieties of general type with many vanishing plurigenera, and optimal sine and sawtooth inequalities. #TerenceTheGoat – Mathematics, for all Mankind!")]], [#link("https://terrytao.wordpress.com/2021/07/26/varieties-of-general-type-with-many-vanishing-plurigenera-and-optimal-sine-and-sawtooth-inequalities/#comment-632898")[#strong[#text("🔜 i’ll get it: Varieties of general type with many vanishing plurigenera, and optimal sine and sawtooth inequalities. #TerenceTheGoat – Mathematics, for all Mankind!")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2021")])]

#text("[…] Varieties of general type with many vanishing plurigenera, and optimal sine and sawtooth inequalitie… […]")
]
