// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/
// Converted to Typst by tao2typ: "2026-10-14T15:16:58.393314+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245B, notes 2: Amenability, the ping-pong lemma, and the Banach-Tarski paradox (optional)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245B, notes 2: Amenability, the ping-pong lemma, and the Banach-Tarski paradox (optional)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")[#text("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#strong[#text("Notational convention:")]#text(" In this post only, I will colour a statement ")#text("red")#text(" if it assumes the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(". (For the rest of the course, the axiom of choice will be implicitly assumed throughout.) ")#mi("\\diamond")

#text("The famous ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski paradox")]#text(" asserts that one can take the unit ball in three dimensions, divide it up into finitely many pieces, and then translate and rotate each piece so that their union is now two disjoint unit balls. As a consequence of this paradox, it is not possible to create a finitely additive measure on ")#mi("{\\Bbb R}^3")#text(" that is both translation and rotation invariant, which can measure every subset of ")#mi("{\\Bbb R}^3")#text(", and which gives the unit ball a non-zero measure.")#text(" This paradox helps explain why ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(" (which is countably additive and both translation and rotation invariant, and gives the unit ball a non-zero measure) cannot measure every set, instead being restricted to measuring sets that are Lebesgue measurable.")

#text("On the other hand, it is not possible to replicate the Banach-Tarski paradox in one or two dimensions; the unit interval in ")#mi("{\\Bbb R}")#text(" or unit disk in ")#mi("{\\Bbb R}^2")#text(" cannot be rearranged into two unit intervals or two unit disks using only finitely many pieces, translations, and rotations, ")#text("and indeed there do exist non-trivial finitely additive measures on these spaces. ")#text(" However, it is possible to obtain a Banach-Tarski type paradox in one or two dimensions using ")#emph[#text("countably")]#text(" many such pieces; this rules out the possibility of extending Lebesgue measure to a countably additive translation invariant measure on all subsets of ")#mi("{\\Bbb R}")#text(" (or any higher-dimensional space).")

#text("In these notes I would like to establish all of the above results, and tie them in with some important concepts and tools in modern group theory, most notably ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenability")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Ping-pong_lemma")[#text("ping-pong lemma")]#text(". This material is not required for the rest of the course, but nevertheless has some independent interest.")

#heading(level: 1)[#metadata(none) <tao-c4600411430e9dbbec3d>#text("— One-dimensional equidecomposability —")]

#text("Before we study the three-dimensional situation, let us first review the simpler one-dimensional situation. To avoid having to say “X can be cut up into finitely many pieces, which can then be moved around to create Y” all the time, let us make a convenient definition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" (Equidecomposability) Let ")#mi("G = (G,\\cdot)")#text(" be a group ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("acting")]#text(" on a space X, and let A, B be subsets of X.")

#enum(start: 1, 
[#text("We say that A, B are ")#emph[#text("finitely G-equidecomposable")]#text(" if there exist finite partitions ")#mi("A = \\bigcup_{i=1}^n A_i")#text(" and ")#mi("B = \\bigcup_{i=1}^n B_i")#text(" and group elements ")#mi("g_1,\\ldots,g_n \\in G")#text(" such that ")#mi("B_i = g_i A_i")#text(" for all ")#mi("1 \\leq i \\leq n")#text(".")],
[#text("We say that A, B are ")#emph[#text("countably G-equidecomposable")]#text(" if there exist countable partitions ")#mi("A = \\bigcup_{i=1}^\\infty A_i")#text(" and ")#mi("B = \\bigcup_{i=1}^\\infty B_i")#text(" and group elements ")#mi("g_1, g_2, \\ldots \\in G")#text(" such that ")#mi("B_i = g_i A_i")#text(" for all i.")],
[#text("We say that A is ")#emph[#text("finitely G-paradoxical")]#text(" if it can be partitioned into two subsets, each of which is finitely G-equidecomposable with A.")],
[#text("We say that A is ")#emph[#text("countably G-paradoxical")]#text(" if it can be partitioned into two subsets, each of which is countably G-equidecomposable with A.")]
)

#text("One can of course make similar definitions when ")#mi("G = (G,+)")#text(" is an additive group rather than a multiplicative one.")
]

#text("Clearly, finite G-equidecomposability implies countable G-equidecomposability, but the converse is not true. Observe that any finitely (resp. countably) additive and G-invariant measure on X that measures every single subset of X, must give either a zero measure or an infinite measure to a finitely (resp. countably) G-paradoxical set. Thus, paradoxical sets provide significant obstructions to constructing additive measures that can measure all sets.")

#strong[#text("Example 1.")]#text(" If ")#mi("{\\Bbb R}")#text(" acts on itself by translation, then ")#mi("{}[0,2]")#text(" is finitely ")#mi("{\\Bbb R}")#text("-equidecomposable with ")#mi("{}[10,11) \\cup [21,22]")#text(", and ")#mi("{}{\\Bbb R}")#text(" is finitely ")#mi("{\\Bbb R}")#text("-equidecomposable with ")#mi("(-\\infty,-10] \\cup (10,+\\infty)")#text(". ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" If G acts transitively on X, then any two finite subsets of X are finitely ")#mi("G")#text("-equidecomposable iff they have the same cardinality, and any two countably infinite sets of X are countably ")#mi("G")#text("-equidecomposable. In particular, any countably infinite subset of X is countably G-paradoxical. ")#mi("\\diamond")

#strong[#text("Exercise 1.")]#text(" Show that finite G-equidecomposability and countable G-equidecomposability are both equivalence relations. ")#mi("\\diamond")

#strong[#text("Exercise 2.")]#text(" (Banach-Schroder-Bernstein theorem) Let G act on X, and let A, B be subsets of X.")

#enum(start: 1, 
[#text("If A is finitely G-equidecomposable with a subset of B, and B is finitely G-equidecomposable with a subset of A, show that A and B are finitely G-equidecomposable with each other. (Hint: adapt the proof of the ")#link("http://en.wikipedia.org/wiki/Schroder-Bernstein_theorem")[#text("Schroder-Bernstein theorem")]#text(".)")],
[#text("If A is finitely G-equidecomposable with a superset of B, and B is finitely G-equidecomposable with a superset of A, show that A and B are finitely G-equidecomposable with each other. (Hint: use part 1.)")],
[#text("Show that claims 1 and 2 hold when “finitely” is replaced by “countably”. ")#mi("\\diamond")]
)

#strong[#text("Exercise 3.")]#text(" Show that if G acts on X, A is a subset of X which is finitely (resp. countably) G-paradoxical, and ")#mi("x \\in X")#text(", then the ")#emph[#text("recurrence set")]#text(" ")#mi("\\{ g \\in G: gx \\in A \\}")#text(" is also finitely (resp. countably) G-paradoxical (where G acts on itself by translation). ")#mi("\\diamond")

#text("Let us first establish countable equidecomposability paradoxes in the reals.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let ")#mi("{\\Bbb R}")#text(" act on itself by translations. Then ")#mi("{}[0,1]")#text(" and ")#mi("{\\Bbb R}")#text(" are countably ")#mi("{\\Bbb R}")#text("-equidecomposable.")
]

#strong[#text("Proof. ")]#text(" By Exercise 2, it will suffice to show that some set contained in ")#mi("{}[0,1]")#text(" is countably ")#mi("{\\Bbb R}")#text("-equidecomposable with ")#mi("{\\Bbb R}")#text(". Consider the space ")#mi("{\\Bbb R}/{\\Bbb Q}")#text(" of all cosets ")#mi("x+{\\Bbb Q}")#text(" of the rationals. ")#text("By the axiom of choice, we can express each such coset as ")#mi("x+{\\Bbb Q}")#text(" for some ")#mi("x \\in [0,1/2]")#text(", thus we can partition ")#mi("{\\Bbb R} = \\bigcup_{x \\in E} x + {\\Bbb Q}")#text(" for some ")#mi("E \\subset [0,1/2]")#text(".")#text(" By Example 2, ")#mi("{\\Bbb Q} \\cap [0,1/2]")#text(" is countably ")#mi("{\\Bbb Q}")#text("-equidecomposable with ")#mi("{\\Bbb Q}")#text(", ")#text("which implies that ")#mi("\\bigcup_{x \\in E} x + ({\\Bbb Q} \\cap [0,1/2])")#text(" is countably ")#mi("{\\Bbb R}")#text("-equidecomposable with ")#mi("\\bigcup_{x \\in E} x + {\\Bbb Q}")#text(". Since latter set is ")#mi("{\\Bbb R}")#text(" and the former set is contained in [0,1], the claim follows.")#text(" ")#mi("\\Box")

#text("Of course, the same proposition holds if [0,1] is replaced by any other interval. As a quick consequence of this proposition and Exercise 2, we see that any subset of ")#mi("{\\Bbb R}")#text(" containing an interval is ")#mi("{\\Bbb R}")#text("-equidecomposable with ")#mi("{\\Bbb R}")#text(". In particular, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1.")]#text(" Any subset of ")#mi("{\\Bbb R}")#text(" containing an interval is countably ")#mi("{\\Bbb R}")#text("-paradoxical.")
]

#text("In particular, we see that any countably additive translation-invariant measure that measures every subset of ")#mi("{\\Bbb R}")#text(", must assign a zero or infinite measure to any set containing an interval. In particular, it is not possible to extend Lebesgue measure to measure all subsets of ")#mi("{\\Bbb R}")#text(".")

#text("We now turn from countably paradoxical sets to finitely paradoxical sets. Here, the situation is quite different: we can rule out many sets from being finitely paradoxical. The simplest example is that of a finite set:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" If G acts on X, and A is a non-empty finite subset of X, then A is not finitely (or countably) G-paradoxical.")
]

#strong[#text("Proof.")]#text(" One easily sees that any two sets that are finitely or countably G-equidecomposable must have the same cardinality. The claim follows. ")#mi("\\Box")

#text("Now we consider the integers.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3. ")]#text(" Let the integers ")#mi("{\\Bbb Z}")#text(" act on themselves by translation. Then ")#mi("{\\Bbb Z}")#text(" is not finitely ")#mi("{\\Bbb Z}")#text("-paradoxical.")
]

#strong[#text("Proof.")]#text(" The integers are of course infinite, and so Proposition 2 does not apply directly. However, the key point is that the integers can be efficiently ")#emph[#text("truncated")]#text(" to be finite, and so we will be able to adapt the Proposition 2 argument in our case.")

#text("Let’s see how. Suppose for contradiction that we could partition ")#mi("{\\Bbb Z}")#text(" into two sets A and B, which are in turn partitioned into finitely many pieces ")#mi("A = \\bigcup_{i=1}^n A_i")#text(" and ")#mi("B = \\bigcup_{j=1}^m B_j")#text(", such that ")#mi("{\\Bbb Z}")#text(" can be partitioned as ")#mi("{\\Bbb Z} = \\bigcup_{i=1}^n A_i + a_i")#text(" and ")#mi("{\\Bbb Z} = \\bigcup_{j=1}^m B_j + b_j")#text(" for some integers ")#mi("a_1, \\ldots,a_n,b_1,\\ldots,b_m")#text(".")

#text("Now let N be a large integer (much larger than ")#mi("n,m,a_1,\\ldots,a_n,b_1,\\ldots,b_m")#text("). We truncate ")#mi("{\\Bbb Z}")#text(" to the interval ")#mi("{}[-N,N] := \\{-N,\\ldots,N\\}")#text(". Clearly")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A \\cap [-N,N] = \\bigcup_{i=1}^n A_i \\cap [-N,N].")]]

#text("and")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{}[-N,N] = \\bigcup_{i=1}^n (A_i + a_i) \\cap [-N,N].")]]

#text("From (2) we see that the set ")#mi("\\bigcup_{i=1}^n (A_i \\cap [-N,N]) + a_i")#text(" differs from ")#mi("{}[-N,N]")#text(" by only O(1) elements, where the bound in the O(1) expression can depend on ")#mi("n,a_1,\\ldots,a_n")#text(" but does not depend on N. (The point here is that [-N,N] is “almost” translation-invariant in some sense.) Comparing this with (1) we see that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|[-N,N]\\right| \\leq \\left|A \\cap [-N,N]\\right| + O(1).", block: true)]]

#text("Similarly with A replaced by B. Summing, we obtain")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("2 \\left|[-N,N]\\right| \\leq \\left|[-N,N]\\right| + O(1),", block: true)]]

#text("but this is absurd for N sufficiently large, and the claim follows. ")#mi("\\Box")

#strong[#text("Exercise 4.")]#text(" Use the above argument to show that in fact no infinite subset of ")#mi("{\\Bbb Z}")#text(" is finitely ")#mi("{\\Bbb Z}")#text("-paradoxical; combining this with Example 2, we see that the only finitely ")#mi("{\\Bbb Z}")#text("-paradoxical set of integers is the empty set. ")#mi("\\diamond")

#text("The above argument can be generalised to an important class of groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (Amenability) Let ")#mi("G = (G,\\cdot)")#text(" be a discrete, at most countable, group. A ")#emph[#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Følner sequence")]]#text(" is a sequence ")#mi("F_1, F_2, F_3, \\ldots")#text(" of finite subsets of G with ")#mi("\\bigcup_{N=1}^\\infty F_N = G")#text(" with the property that ")#tao-math("\\lim_{N \\to \\infty} \\frac{\\left|g F_N \\Delta F_N\\right|}{\\left|F_N\\right|} = 0", block: false)#text(" for all ")#mi("g \\in G")#text(", where ")#mi("\\Delta")#text(" denotes symmetric difference. A discrete, at most countable, group G is ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenable")]#text(" if it contains at least one Følner sequence. Of course, one can define the same concept for additive groups ")#mi("G = (G,+)")#text(".")
]

#strong[#text("Remark 1.")]#text(" One can define amenability for uncountable groups by replacing the notion of a Følner sequence with a Følner ")#link("http://en.wikipedia.org/wiki/Net_(mathematics)")[#text("net")]#text(". Similarly, one can define amenability for ")#link("http://en.wikipedia.org/wiki/Locally_compact_space")[#text("locally compact")]#text(" ")#link("http://en.wikipedia.org/wiki/Hausdorff_space")[#text("Hausdorff")]#text(" groups equipped with a ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(" by using that measure in place of cardinality in the above definition. However, we will not need these more general notions of amenability here. The notion of amenability was first introduced (though not by this name, or by this definition) by von Neumann, precisely in order to study these sorts of decomposition paradoxes. ")#mi("\\diamond")

#strong[#text("Example 3. ")]#text(" The sequence ")#mi("{}[-N,N]")#text(" for ")#mi("N=1,2,3,\\ldots")#text(" is a Følner sequence for the integers ")#mi("{\\Bbb Z}")#text(", which are hence an amenable group. ")#mi("\\diamond")

#strong[#text("Exercise 5.")]#text(" Show that any abelian discrete group that is at most countable, is amenable. ")#mi("\\diamond")

#strong[#text("Exercise 6.")]#text(" Show that any amenable discrete group G that is at most countable is not finitely G-paradoxical, when acting on itself. Combined with Exercise 3, we see that if such a group G acts on a non-empty space X, then X is not finitely G-paradoxical. ")#mi("\\diamond")

#strong[#text("Remark 2.")]#text(" Exercise 6 suggests that an amenable group G should be able to support a non-trivial finitely additive measure which is invariant under left-translations, and can measure all subsets of G. ")#text("Indeed, one can even create a finitely additive probability measure, for instance by selecting a non-principal ")#link("https://terrytao.wordpress.com/2007/06/25/ultrafilters-nonstandard-analysis-and-epsilon-management/")[#text("ultrafilter")]#text(" ")#mi("p \\in {\\beta } {\\Bbb N}")#text(" and a Følner sequence ")#mi("(F_n)_{n=1}^\\infty")#text(" and defining ")#tao-math("\\mu(A) := \\lim_{n \\to p} \\left|A \\cap F_n\\right|/\\left|F_n\\right|", block: false)#text(" for all ")#mi("A \\in G")#text(".")#text(" ")#mi("\\diamond")

#text("The reals ")#mi("{\\Bbb R} = ({\\Bbb R},+)")#text(" (which we will give the discrete topology!) are uncountable, and thus not amenable by the narrow definition of Definition 2. However, observe from Exercise 5 that any ")#link("http://en.wikipedia.org/wiki/Finitely_generated_group")[#text("finitely generated")]#text(" subgroup of the reals is amenable (or equivalently, that the reals themselves with the discrete topology are amenable, using the Følner net generalisation of Definition 2). Also, we have the following easy observation:")

#strong[#text("Exercise 7.")]#text(" Let G act on X, and let A be a subset of X which is finitely G-paradoxical. Show that there exists a finitely generated subgroup H of G such that A is finitely H-paradoxical. ")#mi("\\diamond")

#text("From this, we see that ")#mi("{\\Bbb R}")#text(" is not finitely ")#mi("{\\Bbb R}")#text("-paradoxical. But we can in fact say much more:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4.")]#text(" Let A be a non-empty subset of ")#mi("{\\Bbb R}")#text(". Then A is not finitely ")#mi("{\\Bbb R}")#text("-paradoxical.")
]

#strong[#text("Proof.")]#text(" Suppose for contradiction that we can partition A into two sets ")#mi("A = A_1 \\cup A_2")#text(" which are both finitely ")#mi("{\\Bbb R}")#text("-equidecomposable with A. This gives us two maps ")#mi("f_1: A \\to A_1")#text(", ")#mi("f_2: A \\to A_2")#text(" which are piecewise given by a finite number of translations; thus there exists a finite set ")#mi("g_1,\\ldots,g_d \\in {\\Bbb R}")#text(" such that ")#mi("f_i(x) \\in x + \\{g_1,\\ldots,g_d\\}")#text(" for all ")#mi("x \\in A")#text(" and ")#mi("i=1,2")#text(".")

#text("For any integer ")#mi("N \\geq 1")#text(", consider the ")#mi("2^N")#text(" composition maps ")#mi("f_{i_1} \\circ \\ldots \\circ f_{i_N}: A \\to A")#text(" for ")#mi("i_1,\\ldots,i_N \\in \\{1,2\\}")#text(". From the disjointness of ")#mi("A_1,A_2")#text(" and an easy induction we see that the ranges of all these maps are disjoint, and so for any ")#mi("x \\in A")#text(" the ")#mi("2^N")#text(" quantities ")#mi("f_{i_1} \\circ \\ldots \\circ f_{i_N}(x)")#text(" are distinct. On the other hand, we have")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("f_{i_1} \\circ \\ldots \\circ f_{i_N}(x) \\in x + \\{g_1,\\ldots,g_d\\} + \\ldots + \\{g_1,\\ldots,g_d\\}.")]]

#text("Simple combinatorics (relying primarily on the abelian nature of ")#mi("({\\Bbb R},+)")#text(" shows that the number of values on the RHS of (5) is at most ")#mi("N^d")#text(". But for sufficiently large N, we have ")#mi("2^N > N^d")#text(", giving the desired contradiction. ")#mi("\\Box")

#text("Let us call a group G ")#emph[#text("supramenable ")]#text("if every non-empty subset of G is not finitely G-paradoxical; thus ")#mi("{\\Bbb R}")#text(" is supramenable. From Exercise 3 we see that if a supramenable group acts on any space X, then the only finitely G-paradoxical subset of X is the empty set.")

#strong[#text("Exercise 8.")]#text(" We say that a group ")#mi("G = (G,\\cdot)")#text(" has ")#emph[#text("subexponential growth")]#text(" if for any finite subset S of G, we have ")#tao-math("\\lim_{n \\to \\infty} \\left|S^n\\right|^{1/n} = 1", block: false)#text(", where ")#mi("S^n = S \\cdot \\ldots \\cdot S")#text(" is the set of n-fold products of elements of S. Show that every group of subexponential growth is supramenable. ")#mi("\\diamond")

#strong[#text("Exercise 9.")]#text(" Show that every abelian group has subexponential growth (and is thus supramenable. More generally, show that every ")#link("http://en.wikipedia.org/wiki/Nilpotent_group")[#text("nilpotent")]#text(" group has subexponential growth and is thus also supramenable. ")#mi("\\diamond")

#strong[#text("Exercise 10.")]#text(" Show that if two finite unions of intervals in ")#mi("{\\Bbb R}")#text(" are finitely ")#mi("{\\Bbb R}")#text("-equidecomposable, then they must have the same total length. (Hint: reduce to the case when both sets consist of a single interval. First show that the lengths of these intervals cannot differ by more than a factor of two, and then ")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("amplify")]#text(" this fact by iteration to conclude the result.) ")#mi("\\diamond")

#strong[#text("Remark 3.")]#text(" ")#text("We")#text(" already saw that amenable groups G admit finitely additive translation-invariant probability measures that measure all subsets of G (Remark 2 can be extended to the uncountable case); in fact, this turns out to be an equivalent definition of amenability. It turns out that supramenable groups G enjoy a stronger property, namely that given any non-empty set A on G, there exists a finitely additive translation-invariant measure on G that assigns the measure 1 to A; this is basically a deep result of Tarski.")#text(" ")#mi("\\diamond")

#heading(level: 1)[#text("— Two-dimensional equidecomposability —")]

#text("Now we turn to equidecomposability on the plane ")#mi("{\\Bbb R}^2")#text(". The nature of equidecomposability depends on what group G of symmetries we wish to act on the plane.")

#text("Suppose first that we only allow ourselves to translate various sets in the planes, but not to rotate them; thus ")#mi("G = {\\Bbb R}^2")#text(". As this group is abelian, it is supramenable by Exercise 9, and so any non-empty subset A of the plane will not be finitely ")#mi("{\\Bbb R}^2")#text("-paradoxical; ")#text("indeed, by Remark 3, there exists a finitely additive translation-invariant measure that gives A the measure 1. On the other hand, it is easy to adapt Corollary 1 to see that any subset of the plane containing a ball will be countably ")#mi("{\\Bbb R}^2")#text("-paradoxical")#text(".")

#text("Now suppose we allow both translations and rotations, thus G is now the group ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(" of (orientation-preserving) isometries ")#mi("x \\mapsto e^{i\\theta} x + v")#text(" for ")#mi("v \\in {\\Bbb R}^2")#text(" and ")#mi("\\theta \\in {\\Bbb R}/2\\pi {\\Bbb Z}")#text(", where ")#mi("e^{i\\theta}")#text(" denotes the anti-clockwise rotation by ")#mi("\\theta")#text(" around the origin. This group is no longer abelian, or even nilpotent, so Exercise 9 no longer applies. Indeed, it turns out that G is no longer supramenable. This is a consequence of the following three lemmas:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let G be a group which contains a free semigroup on two generators (in other words, there exist group elements ")#mi("g, h \\in G")#text(" such that all the words involving g and h (but not ")#mi("g^{-1}")#text(" or ")#mi("h^{-1}")#text(") are distinct). Then G contains a non-empty finitely G-paradoxical set. In other words, G is not supramenable.")
]

#strong[#text("Proof.")]#text(" Let S be the semigroup generated by g and h (i.e. the set of all words formed by g and h, including the empty word (i.e. group identity). Observe that gS and hS are disjoint subsets of S that are clearly G-equidecomposable with S. The claim then follows from Exercise 2. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2.")]#text(" (Semigroup ")#link("http://en.wikipedia.org/wiki/Ping-pong_lemma")[#text("ping-pong lemma")]#text(") Let G act on a space X, let g, h be elements of G, and suppose that there exists a non-empty subset A of X such that gA and hA are disjoint subsets of A. Then g, h generate a free semigroup.")
]

#strong[#text("Proof. ")]#text(" As in the proof of Proposition 4, we see from induction that for two different words w, w’ generated by g, h, the sets wA and w’A are disjoint, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3.")]#text(" The group ")#mi("G = SO(2) \\ltimes {\\Bbb R}^2")#text(" contains a free semigroup on two generators.")
]

#strong[#text("Proof. ")]#text(" It is convenient to identify ")#mi("{\\Bbb R}^2")#text(" with the complex plane ")#mi("{\\Bbb C}")#text(". We set g to be the rotation ")#mi("g x := \\omega x")#text(" for some ")#link("http://en.wikipedia.org/wiki/Transcendental_number")[#text("transcendental")]#text(" phase ")#mi("\\omega = e^{2\\pi i \\theta}")#text(" be such that ")#mi("\\omega := e^{2\\pi i \\theta}")#text(" is transcendental (such a phase must exist, since the set of algebraic complex numbers is countable), and let ")#mi("h")#text(" be the translation ")#mi("hx := x+1")#text(". Observe that g and h act on the set A of polynomials in ")#mi("\\omega")#text(" with non-negative integer coefficients, and that gA and hA are disjoint. The claim now follows from Lemma 2. ")#mi("\\Box")

#text("Combining Lemma 1 and Lemma 3 to create a countable, finitely paradoxical subset of ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(", and then letting that set act on a generic point in the plane (noting that each group element in ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(" has at most one fixed point), we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2.")]#text(" (Sierpinski-Mazurkiewicz paradox) There exist non-empty finitely ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text("-paradoxical subsets of the plane.")
]

#text("We have seen that the group of rigid motions is not supramenable. Nevertheless, it is still amenable, thanks to the following lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4.")]#text(" Suppose one has a ")#link("http://en.wikipedia.org/wiki/Short_exact_sequence")[#text("short exact sequence")]#text(" ")#mi("0 \\to H \\to G \\to K \\to 0")#text(" of discrete, at most countable, groups, and suppose one has a choice function ")#mi("\\phi: K \\to G")#text(" that inverts the projection of G to K (the existence of which follows for instance from the well-orderability of G). If H and K are amenable, then so is G.")
]

#strong[#text("Proof. ")]#text("Let ")#mi("(A_n)_{n=1}^\\infty")#text(" and ")#mi("(B_n)_{n=1}^\\infty")#text(" be Følner sequences for H and K respectively. Let ")#mi("f: {\\Bbb N} \\to {\\Bbb N}")#text(" be a rapidly growing function, and let ")#mi("(F_n)_{n=1}^\\infty")#text(" be the set ")#mi("F_n := \\bigcup_{x \\in B_n} \\phi(x) \\cdot A_{f(n)}")#text(". One easily verifies that this is a Følner sequence for G if f is sufficiently rapidly growing. (Strictly speaking, these ")#mi("F_n")#text(" do not necessarily cover G, but this can be achieved by right-translating the ")#mi("F_n")#text(" suitably. This can be done without choice because an at most countable set is always well-ordered.) ")#mi("\\Box")

#strong[#text("Exercise 11.")]#text(" Show that any finitely generated ")#link("http://en.wikipedia.org/wiki/Solvable_group")[#text("solvable")]#text(" group is amenable. More generally, show that any discrete, at most countable, solvable group is amenable. ")#mi("\\diamond")

#strong[#text("Exercise 12.")]#text(" Show that any finitely generated subgroup of ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(" is amenable. (Hint: use the short exact sequence ")#mi("0 \\to {\\Bbb R}^2 \\to SO(2) \\ltimes {\\Bbb R}^2 \\to SO(2) \\to 0")#text(", which shows that ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(" is solvable (in fact it is ")#link("http://en.wikipedia.org/wiki/Metabelian")[#text("metabelian")]#text(")). Conclude that ")#mi("{\\Bbb R}^2")#text(" is not finitely ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text("-paradoxical. ")#mi("\\diamond")

#text("Finally, we show a result of Banach.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5.")]#text(" The unit disk D in ")#mi("{\\Bbb R}^2")#text(" is not finitely ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text("-paradoxical.")
]

#strong[#text("Proof.")]#text(" If the claim failed, then D would be finitely ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text("-equidecomposable with a disjoint union of two copies of D, say D and D+v for some vector v of length greater than 2. By Exercise 7, we can then find a subgroup G of ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(" generated by a finite number of rotations ")#mi("x \\mapsto e^{i\\theta_j} x")#text(" for ")#mi("j=1,\\ldots,J")#text(" and translations ")#mi("x \\mapsto x +v_k")#text(" for ")#mi("k=1,\\ldots,K")#text(" such that D and ")#mi("D \\cup (D+v)")#text(" are finitely G-equidecomposable. Indeed, we may assume that the rigid motions that move pieces of D to pieces of ")#mi("D \\cup (D+v)")#text(" are of the form ")#mi("x \\mapsto e^{i\\theta_j} x + v_k")#text(" for some ")#mi("1 \\leq j \\leq J, 1 \\leq k \\leq K")#text(", thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("D \\cup (D+v) = \\bigcup_{j=1}^J \\bigcup_{k=1}^K e^{i\\theta_j} D_{j,k} + v_k")]]

#text("for some partition ")#mi("D = \\bigcup_{j=1}^J \\bigcup_{k=1}^K D_{j,k}")#text(" of the disk. By incrementing ")#mi("K")#text(" if necessary we may assume that ")#mi("v")#text(" is one of the ")#mi("v_k")#text(".")

#text("By amenability of the rotation group SO(2), one can find a finite set ")#mi("\\Phi \\subset SO(2)")#text(" of rotations such that ")#mi("e^{i\\theta_j} \\Phi")#text(" differs from ")#mi("\\Phi")#text(" by at most ")#tao-math("0.01 \\left|\\Phi\\right|", block: false)#text(" elements for all ")#mi("1 \\leq j \\leq J")#text(". Let N be a large integer, and let ")#mi("\\Gamma_N \\subset {\\Bbb R}^2")#text(" be the set of all linear combinations of ")#mi("e^{i\\theta} v_k")#text(" for ")#mi("\\theta \\in \\Phi")#text(" and ")#mi("1 \\leq k \\leq K")#text(" with coefficients in ")#mi("\\{-N,\\ldots,N\\}")#text(". Observe that ")#mi("\\Gamma_N")#text(" is a finite set whose cardinality grows at most polynomially in N. Thus, by the pigeonhole principle, one can find arbitrarily large N such that")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|D \\cap \\Gamma_{N+10}\\right| \\leq 1.01 |D \\cap \\Gamma_N|.", block: true)]]

#text("On the other hand, from (6) and the rotation-invariance of the disk we have")

#tao-aligned(keep: true)[


#tao-math("2 \\left|D \\cap \\Gamma_N\\right|  & = 2 \\left|e^{i\\theta}(D) \\cap \\Gamma_N\\right|", block: true)



#tao-math(" & \\leq \\left|e^{i\\theta}(D \\cup (D+v)) \\cap \\Gamma_{N+5}\\right|", block: true)



#tao-math(" & \\leq \\sum_{j=1}^J \\sum_{k=1}^K \\left|e^{i(\\theta+\\theta_j)} D_{j,k} \\cap \\Gamma_{N+10}\\right|", block: true, numbering: n => [#text("(8)")])
]

#text("for all ")#mi("\\theta \\in \\Phi")#text(". Averaging this over all ")#mi("\\theta \\in \\Phi")#text(" we conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("2 \\left|D \\cap \\Gamma_N\\right| \\leq 1.01 \\left|D \\cap \\Gamma_{N+10}\\right|,", block: true)]]

#text("contradicting (7). ")#mi("\\Box")

#strong[#text("Remark 4.")]#text(" Banach in fact showed the slightly stronger statement that any two finite unions of polygons of differing area were not finitely ")#mi("SO(2) \\times {\\Bbb R}^2")#text("-equidecomposable. (The converse is also true, and is known as the ")#link("http://en.wikipedia.org/wiki/Bolyai%E2%80%93Gerwien_theorem")[#text("Bolyai-Gerwien theorem")]#text(".) ")#mi("\\diamond")

#strong[#text("Exercise 13.")]#text(" Show that all the claims in this section continue to hold if we replace ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(" by the slightly larger group ")#mi("\\text{Isom}({\\Bbb R}^2) = O(2) \\ltimes {\\Bbb R}^2")#text(" of isometries (not necessarily orientation-preserving. ")#mi("\\diamond")

#strong[#text("Remark 5.")]#text(" As a consequence of Remark 4, the unit square is not ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text("-paradoxical. However, it is ")#mi("SL(2) \\ltimes {\\Bbb R}^2")#text("-paradoxical; this is known as the ")#link("http://en.wikipedia.org/wiki/Von_Neumann_paradox")[#text("von Neumann paradox")]#text(". ")#mi("\\diamond")

#heading(level: 1)[#text("— Three-dimensional equidecomposability —")]

#text("We now turn to the three-dimensional setting. The new feature here is that the group ")#mi("SO(3) \\times {\\Bbb R}^3")#text(" of rigid motions is no longer abelian (as in one dimension) or solvable (as in two dimensions), but now contains a free group on two generators (not just a free semigroup, as per Lemma 3). The significance of this fact comes from")

#align(center)[#strong[#text("Lemma 5.")]#text(" The free group ")#mi("F_2")#text(" on two generators is finitely ")#mi("F_2")#text("-paradoxical.")]

#strong[#text("Proof.")]#text(" Let a, b be the two generators of ")#mi("F_2")#text(". We can partition ")#mi("F_2 = \\{1\\} \\cup W_a \\cup W_b \\cup W_{a^{-1}} \\cup W_{b^{-1}}")#text(", where ")#mi("W_c")#text(" is the collection of ")#link("http://en.wikipedia.org/wiki/Reduced_word#Reduced_words")[#text("reduced words")]#text(" of ")#mi("F_2")#text(" that begin with c. From the identities")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("W_{a^{-1}} = a^{-1} \\cdot (F_2 \\backslash W_a); \\quad W_{b^{-1}} = b^{-1} \\cdot (F_2 \\backslash W_b)")]]

#text("we see that ")#mi("F_2")#text(" is finitely ")#mi("F_2")#text("-equidecomposable with both ")#mi("W_a \\cup W_{a^{-1}}")#text(" and ")#mi("W_b \\cup W_{b^{-1}}")#text(", and the claim now follows from Exercise 2. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3. ")]#text(" Suppose that ")#mi("F_2")#text(" acts freely on a space X (i.e. ")#mi("gx \\neq x")#text(" whenever ")#mi("x \\in X")#text(" and ")#mi("g \\in F_2")#text(" is not the identity). Then X is finitely ")#mi("F_2")#text("-paradoxical.")
]

#strong[#text("Proof. ")]#text(" Using the axiom of choice, we can partition X as ")#mi("X = \\bigcup_{x \\in \\Gamma} F_2 x")#text(" for some subset ")#mi("\\Gamma")#text(" of X. The claim now follows from Lemma 5. ")#mi("\\Box")

#text("Next, we embed the free group inside the rotation group SO(3) using the following useful lemma (cf. Lemma 2).")

#strong[#text("Exercise 14")]#text(" (")#link("http://en.wikipedia.org/wiki/Ping-pong_lemma")[#text("ping-pong lemma")]#text("). Let G act on a set X. Suppose that there exist disjoint subsets ")#mi("A_+, A_-, B_+, B_-")#text(" of X, whose union is not all of X, and elements ")#mi("a, b \\in G")#text(", such that")

#tao-aligned(keep: true)[


#tao-math("a (X \\backslash A_-)  & \\subset A_+; \\quad a^{-1} (X \\backslash A_+) \\subset A_-;", block: true)



#tao-math("b(X \\backslash B_-)  & \\subset B_+; \\quad b^{-1}(X \\backslash B_+) \\subset B_-.", block: true, numbering: n => [#text("(9)")])
]

#text("Then a, b generate a free group. (If drawn correctly, a diagram of the inclusions (9) resembles a game of doubles ping-pong of ")#mi("A_+, A_-")#text(" versus ")#mi("B_+, B_-")#text(", hence the name.) ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6.")]#text(" ")#mi("SO(3)")#text(" contains a copy of the free group on two generators.")
]

#strong[#text("Proof.")]#text(" It suffices to find a space X that two elements of ")#mi("SO(3)")#text(" act on in a way that Exercise 14 applies. There are many such constructions. One is given (and motivated) in this ")#link("http://sbseminar.wordpress.com/2007/09/17/that-trick-where-you-embed-the-free-group-into-a-lie-group")[#text("blog post of David Speyer")]#text(", based on passing from the reals to the 5-adics, where -1 is a square root and so SO(3) becomes isomorphic to PSL(2). At the end of the day, one takes")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("a = \\begin{pmatrix} 3/5 & 4/5 & 0 \\\\ -4/5 & 3/5 & 0 \\\\ 0 & 0 & 1 \\end{pmatrix}; \\quad b = \\begin{pmatrix} 1 & 0 & 0 \\\\ 0 & 3/5 & -4/5 \\\\ 0 & 4/5 & 3/5 \\end{pmatrix}")]]

#text("and")

#tao-aligned(keep: true)[


#tao-math("A_\\pm  & := 5^{{\\Bbb Z}} \\cdot \\{ \\begin{pmatrix} x \\\\y \\\\ z \\end{pmatrix}: x,y,z \\in {\\Bbb Z}, x=\\pm 3y \\text{ mod } 5, z = 0 \\text{ mod } 5 \\}", block: true)



#tao-math("B_\\pm  & := 5^{{\\Bbb Z}} \\cdot \\{ \\begin{pmatrix} x \\\\y \\\\ z \\end{pmatrix}: x,y,z \\in {\\Bbb Z}, z=\\pm 3y \\text{ mod } 5, x = 0 \\text{ mod } 5 \\}", block: true, numbering: n => [#text("(11)")])
]

#align(center)[#mi("X := A_- \\cup A_+ \\cup B_- \\cup B_+ \\cup \\{ \\begin{pmatrix} 0 & 1 & 0 \\end{pmatrix} \\}")#text(",")]

#text("where ")#mi("5^{{\\Bbb Z}}")#text(" denotes the integer powers of 5 (which act on column vectors in the obvious manner). The verification of the ping-pong inclusions (9) is a routine application of ")#link("http://en.wikipedia.org/wiki/Modular_arithmetic")[#text("modular arithmetic")]#text(". ")#mi("\\Box")

#strong[#text("Remark 6.")]#text(" This is a special case of the ")#link("http://en.wikipedia.org/wiki/Tits_alternative")[#text("Tits alternative")]#text(". ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4.")]#text(" (")#link("http://en.wikipedia.org/wiki/Hausdorff_paradox")[#text("Hausdorff paradox")]#text(") There exists a countable subset E of the sphere ")#mi("S^2")#text(" such that ")#mi("S^2 \\backslash E")#text(" is finitely ")#mi("SO(3)")#text("-paradoxical, where ")#mi("SO(3)")#text(" of course acts on ")#mi("S^2")#text(" by rotations.")#linebreak()
]

#strong[#text("Proof. ")]#text(" Let ")#mi("F_2 \\subset SO(3)")#text(" be a copy of the free group on two generators, as given by Proposition 6. Each rotation in ")#mi("F_2")#text(" fixes exactly two points on the sphere. Let E be the union of all these points; this is countable since ")#mi("F_2")#text(" is countable. The action of ")#mi("F_2")#text(" on ")#mi("S^2 \\backslash E")#text(" is free, and the claim now follows from Corollary 3. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5.")]#text(" (")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Tarski_paradox")[#text("Banach-Tarski paradox")]#text(" on the sphere) ")#mi("S^2")#text(" is finitely ")#mi("SO(3)")#text("-paradoxical.")
]

#strong[#text("Proof.")]#text(" (Sketch) Iterating the Hausdorff paradox, we see that ")#mi("S^2 \\backslash E")#text(" is finitely ")#mi("SO(3)")#text("-equidecomposable to four copies of ")#mi("S^2 \\backslash E")#text(", which can easily be used to cover two copies of ")#mi("S^2")#text(" (with some room to spare), by randomly rotating each of the copies. The claim now follows from Exercise 2. ")#mi("\\Box")

#strong[#text("Exercise 15.")]#text(" (Banach-Tarski paradox on ")#mi("{\\Bbb R}^3")#text(") Show that the unit ball in ")#mi("{\\Bbb R}^3")#text(" is finitely ")#mi("SO(3) \\ltimes {\\Bbb R}^3")#text("-paradoxical. ")#mi("\\diamond")

#strong[#text("Exercise 16. ")]#text(" Extend these three-dimensional paradoxes to higher dimensions. ")#mi("\\diamond")#linebreak()

#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34792")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("In exercise 6, do you mean finitely G-paradoxical or countably G-paradoxical?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34793")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("Also – is it just me, or are your semidirect products SO(n) times R^n pointing in the wrong way? (Surely the triangle bit of the “times” sign should be a “normal subgroup” sign written in the right direction?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harald")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34794")[#strong[#text("Harald")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("Isn’t a step missing in the proof of Corollary 2? Most elements of the semidirect product R^n ><| SO(n) do have fixed points when they act on R^2 (all rotations do).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34795")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34800")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("There’s a stronger version of the Banach-Tarski paradox that was proved recently (by one of my friends) which says that there is a paradoxical decomposition of a sphere in which the pieces move continuously from the original sphere to the two new spheres while remaining disjoint the whole time. The ")#link("http://projecteuclid.org/DPubS?verb=Display&version=1.0&service=UI&handle=euclid.jsl/1122038921&page=record")[#text("article")]#text(" is pretty short, just 6 pages. BTW, I like the use of red to indicate which things rely on choice, it’s much nicer stylistically than writing “depends on choice” or something like that in each paragraph.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("While the axiom of choice was used in various places as indicated above, what is known if you are not allowed the axiom of choice? Namely, is it known that there is no Banach-Tarski like result if you do not assume the axiom choice? Perhaps a more concrete question is if you can construct nonmeasurable sets without the axiom choice (I haven’t seen any).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lieven")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34809")[#strong[#text("Lieven")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2009")])]

#text("Solovay proved that ZF + the existence of an inaccessible cardinal + the existence of a Lebesgue measure over all sets of reals is equiconsistent with ZF. Shelah showed later that the use of an inaccessible cardinal is necessary. So in that sense, the use of choice is necessary to “construct” nonmeasurable sets of reals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87cda33277ed0e36ed08b37f23e619ddd55a49872f3f50b63023f93e6c8be7f3-3f316aed179e1d32e236bab92992d498def6db375b3fb8bbc752ac1236a1a3d8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marlowe, PI")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34815")[#strong[#text("Marlowe, PI")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("It has been proved that the assertion “every set (in ")#mi("\\mathbb R")#text(") is (Lebesgue) measurable” + All other axioms of set theory save for choice is consistent iff the usual theory is consistent. Therefor, if you take out Choice and just keep the other axioms of set theory, you can¿t construct non measurable sets.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("Less than epsilon, LA")

#text("Dear Prof. Tao,")

#text("Thank you very much for your excellent blog. It is really helping us too much.")

#text("In some research papers and books, Laplace and Fourier transform of measures are used. Could you please explain those concepts and clarify the point which transformation uniquely determines the measure(for finite and infinite case)")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34821")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2009")])]

#text("Dear anonymous #1: you might be interested in the related discussion in the comments to Notes 0,")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/01/01/245b-notes-0-a-quick-review-of-measure-and-integration-theory/")[#text("245B, notes 0: A quick review of measure and integration theory")]
]

#text("Dear anonymous #2: I plan to discuss this topic when I come to the Stone-Weierstrass theorem, as these sort of unique reconstruction questions are often obtainable directly as consequences of this theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34833")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("Dear Professor Tao:")

#text("I didn’t quite follow Exercise 10. Are all the intervals with the same length. Could you explain the hint a little more?")

#text("Xiaochuan")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34836")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("Dear Xiaochuan,")

#text("The two unions of intervals can consist of intervals of different lengths, but the exercise is to show that the two unions are equidecomposable if and only if their _total_ lengths are the same. But it is not difficult to see that any finite union of intervals is equidecomposable with a single interval of the same total length, so one can quickly reduce to the case of a single interval.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34857")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2009")])]

#text("Dear Professor Tao:")

#text("To make (8) hold, should ")#mi("\\Phi")#text(" be asked to contain ")#mi("\\theta_0=0")#text("?")

#text("Also, is the first equation of (8) correct? And in Prop. 5 and the proof, is ")#mi("SO(2) \\times {\\Bbb R}^2")#text(" actually ")#mi("SO(2) \\ltimes {\\Bbb R}^2")#text(" or not?")

#text("Xiaochuan")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34865")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2009")])]

#text("While one can place 0 inside ")#mi("\\Phi")#text(" if one wishes, it is not necessary for the proof. There was a factor of 2 missing in the second expression in (8) which has now been corrected, and the direct product should indeed have been a semidirect product.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-34947")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2009")])]

#text("Anonymous #1 (8 January @ 8:26 pm), the Wikipedia article on the Banach-Tarski paradox has a section about the strength of set theory needed to prove the paradox. You don’t need the full axiom of choice as given in ZFC, but you can’t quite do it in ZF. You can do it with a somewhat weakened version of AC.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, Notes 7: Well-ordered sets, ordinals, and Zorn’s lemma (optional) « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-35304")[#strong[#text("245B, Notes 7: Well-ordered sets, ordinals, and Zorn’s lemma (optional) « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2009")])]

#text("[…] induction, well-ordered sets, Zorn’s lemma | by Terence Tao Notational convention: As in Notes 2, I will colour a statement red if it assumes the axiom of choice. We will, of course, rely on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 实分析0-10 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-35895")[#strong[#text("实分析0-10 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2009")])]

#text("[…] 第二节是全新的内容，我本人没有任何基础，讲的是Banach-Tarski悖论。该悖论是说，一个三维空间的单位球可以被拆成有限个部分，然后仅仅通过平移和旋转，就变成两个单位球。这够令人惊讶的了！但是存在性的证明，并没有具体给出如何拆的方法。而且一步步的看到最后，多少有点被绕糊涂了，没有整体的感觉，有兴趣的恐怕还的看看原始论文了。这篇帖子做了一个很不错的尝试，将所有跟选择公理有关的文字用红色表达。后来有些帖子涉及选择公理比较多的，也是这般处理的。此帖子中我还发现了一个很不多的博客，是由berkeley的几个博士生和博士们合写的。名字叫做Secret Blogging Seminar,叫做SB讨论班，链接在这里。本节中用到的关于将一个自由群嵌入到一个李群中去的方法，那个博客中有一个更清楚的帖子，做了更详细的阐述，我还没来得及细看。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some notes on amenability « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-38183")[#strong[#text("Some notes on amenability « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2009")])]

#text("[…] Remark 2 The non-amenability of the free group is related to the Banach-Tarski paradox (see my earlier lecture notes on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A computational perspective on set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-43938")[#strong[#text("A computational perspective on set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2010")])]

#text("[…] dimensional cases is that the free group is not amenable, whereas is amenable. See these previous blog posts for further discussion.) Possibly related posts: (automatically generated)The “no […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df2243dadb007d57642abdd9e03c4963b81affa53b7c8fd858bd3f97b683bc31-e5338233ceec169d3b8c4df07dd2896c8f66bfc1830c8689ba39e63aabee53a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phobos99")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-44236")[#strong[#text("Phobos99")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2010")])]

#text("Hi, I was wondering if somebody knows a book or a paper that contais the proof of Proposition 1, because I’d like to quote it in my own work and I don’t like quoting a web page.")

#text("Thanks,")#linebreak()#text(" Phobos99")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-44246")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2010")])]

#text("I believe the result goes back to Vitali; see ")#link("http://en.wikipedia.org/wiki/Vitali_set")[#text("http://en.wikipedia.org/wiki/Vitali_set")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df2243dadb007d57642abdd9e03c4963b81affa53b7c8fd858bd3f97b683bc31-e5338233ceec169d3b8c4df07dd2896c8f66bfc1830c8689ba39e63aabee53a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phobos99")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-44253")[#strong[#text("Phobos99")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2010")])]

#text("Thanks for a reply, bud I already knew that.) I talked to my advisor and he sees no problem in quoting this web page = problem solved:)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/82e1b386e902885d97ea288c91542f3c6923379c3d093e709ff15775063b000b-94f7b243bec7ad017d8d84cf49ddd297bfe5b5f6046280fe8361a2385758bd0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kestutis Cesnavicius")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-45485")[#strong[#text("Kestutis Cesnavicius")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2010")])]

#text("Several typos:")

#text("1. In Remark 2 “group G hould be” —> “group G should be”")#linebreak()#text(" 2. The proof of Lemma 4 needs some additional argument: the sets ")#mi("F_n")#text(" need not cover ")#mi("G")#text(". If ")#mi("y \\in B_1")#text(" does not happen to be in the subsequent ")#mi("B_n")#text("‘s, the corresponding coset ")#mi("\\phi(y)\\cdot H")#text(" will not be fully covered.")#linebreak()#text(" 3. Proof of Proposition 5: in the 4th line direct product should be semidirect product; same in Remarks 4, 5, and the beginning of the last section.")#linebreak()#text(" 4. Exercise 13: Isom(R)^2 should be Isom(R^2).")#linebreak()#text(" 5. Last line of the proof of Lemma 5: c should be b.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-45517")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2010")])]

#text("Thanks for the corrections! Regarding Lemma 4, this can be fixed by right-translating each of the sets in the Folner sequence to cover the whole space (to do this without choice, one can use the fact that all at most countable sets are well-ordered.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, prologue: The problem of measure « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-46783")[#strong[#text("245A, prologue: The problem of measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("[…] in three dimensions and higher, for reasons having to do with the property of amenability; see this blog post for further discussion of this interesting topic, which is unfortunately too much of a digression […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-47274")[#strong[#text("[Maths]Le lemme de Ping-Pong[*Inachevé] « Yichao's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2010")]

#text("[…] [ref 3] : ")#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach")[#text("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach")]#text("… […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8039d8c51546f8d33961f011a21a53eaa262e82c691400f28a84dae84fa3aac-f0783670193f177353a81b6d45a2b552a40564672819c4764df5bd2e53d6b536.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Banach-Tarski Paradox « Introduction to Ramsey Theory")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-89897")[#strong[#text("The Banach-Tarski Paradox « Introduction to Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2011")])]

#text("[…] Terry Tao’s blog is, as always, a valuable […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-390172")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("Dear Professor Tao, and other readers.")#linebreak()#text(" I hope someone will still look at this comment section after all those years. I can’t figure out the 2 inequalities in (8) for Proposition 5. I still don’t understand how they can be derived, and the mysterious role of the N+5. I hope someone can explain this. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-390278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2014")])]

#text("First hint: One might try first proving the inequalities without the restrictions to the various ")#mi("\\Gamma")#text("‘s (ignoring for now the fact that the disks ")#mi("D")#text(" have infinite cardinality, and focusing on finding the right subset inclusions that give the cardinality bounds), as this is an easier exercise that will guide you for the full problem.")

#text("It is also worth trying to draw all of the relevant sets to see how they fit together.")

#text("More complete solution:")

#text("For the first inequality, use the fact that when one translates ")#mi("e^{i\\theta}(D) \\cap \\Gamma_N")#text(" by ")#mi("e^{i\\theta} v")#text(", one gets a new set disjoint from the first, and which is still contained in ")#mi("e^{i\\theta}(D \\cup (D+v)) \\cap \\Gamma_{N+5}")#text(".")

#text("For the second inequality, use (6) and the fact that ")#mi("(e^{i(\\theta+\\theta)} D_{j,k} + e^{i \\theta} v_k) \\cap \\Gamma_{N+5}")#text(" is contained in ")#mi("e^{i(\\theta+\\theta_j)} D_{j,k} \\cap \\Gamma_{N+10} + e^{i\\theta} v_k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08375cec724870c30e716e94b5c0b95ab418f0211204e1465021574c0b3c96c0-5080eda75ca3341edb7a89c6895eb48cae10aa2ef7fa312eedb19e447b273add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465881")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2016")])]

#text("On the second to last paragraph, why is ")#mi("e^{i\\theta}(D) \\cap \\Gamma_N")#text(" translated by ")#mi("e^{i\\theta}v")#text(" contained in ")#mi("e^{i\\theta}(D\\cup (D+v)) \\cap \\Gamma_{N+5}")#text("? (I see it is contained in the other rotated copy of the disk, but not the “linear combination of ")#mi("e^{i\\theta}v_k")#text("” part) Are we assuming from the get-go that ")#mi("v= v_k")#text(" for some ")#mi("k")#text(" (which it seems one could do)?")

#text("Also, is there a reason for choosing ")#mi("N+5")#text(" and ")#mi("N+10")#text(" in the proof instead of ")#mi("N+1")#text(" and ")#mi("N+2")#text("? Would that work just as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465888")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2016")])]

#mi("e^{i\\theta}(D) + e^{i\\theta} v")#text(" is equal to ")#mi("e^{i\\theta}(D+v)")#text(", and ")#mi("\\Gamma_N + e^{i\\theta} v")#text(" is contained in ")#mi("\\Gamma_{N+5}")#text(". (The definition of ")#mi("\\Gamma_N")#text(" should have allowed linear combinations of ")#mi("v")#text(" in addition to ")#mi("v_1,\\dots,v_K")#text(" (or alternatively one can simply enlarge the list ")#mi("v_1,\\dots,v_K")#text(" by one to accomodate ")#mi("v")#text(") – I have updated the post to reflect this.)")

#text("One can certainly replace 5 and 10 here by smaller quantities, but this does not significantly impact the remainder of the argument. It is general practice in mathematics to use round numbers such as 5, 10, or 100 as choices for absolute constants whose exact value is of little importance to the argument.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-435197")[#strong[#text("Assioma della Scelta e Paradosso di Banach-Tarski | Analisi Matematica 1")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2014")]

#text("[…] che e’ lunga e difficile; il lettore interessato puo’ approfondire l’argomento in questo post (ma servono conoscenze molto piu’ avanzate di quelle del corso di Analisi […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08375cec724870c30e716e94b5c0b95ab418f0211204e1465021574c0b3c96c0-5080eda75ca3341edb7a89c6895eb48cae10aa2ef7fa312eedb19e447b273add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465358")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2016")])]

#text("Professor Tao:")

#text("Concerning Lemma 4, why does inverting the projection require choice? Couldn’t one well-order G (which is at most countable) and then define ")#mi("\\phi : G/H (\\cong K) \\rightarrow G")#text(" by \\phi(gH)=min(gH)?")

#emph[#text("[Good point; I’ve modified the parenthetical accordingly – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2016")])]

#text("Well-ordering doesn’t imply the existence of minimums; the set of all integers is well-ordered, but it has infinitely many subsets that don’t have a minimal element.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465374")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2016")])]

#link("https://en.wikipedia.org/wiki/Well-order")[#text("https://en.wikipedia.org/wiki/Well-order")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2016")])]

#text("Oh, right. I forgot that the integers are not well-ordered by the usual order. Maybe the statement of Lemma 4 is slightly wrong; I don’t think G needs to be countable, as long as it’s well-ordered.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465477")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2016")])]

#text("Amenability was only defined for at most countable groups.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465621")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2016")])]

#text("Wouldn’t exercise 11 have to be modified accordingly as well?")

#emph[#text("[Fair enough – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a257d9674cea0c80c56ed50cc4a50f7ddc5cfac0fa679b4e8e11d35c7f4c34b1-29f1c5f93bdfde6c4e09994d76d4e62c32f0bc66aa528f5ffd27169175ee350b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yotas Trejos")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465705")[#strong[#text("Yotas Trejos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2016")])]

#text("I’ve been studying this article and I’ve been struggling to understand some of the details in the proofs of Lemma 4 and Proposition 5. I would be very thankful if you could shed some light on this. My doubts are the following:")

#text("– In the proof of Lemma 4, I’d had trouble proving that ")#mi("Fn")#text(" is a Folner sequence, could you please give me some additional hints?")

#text("– In the proof of Proposition 5, I don’t quite understand how (or why) you partition a set using sums of sets.")

#text("– How does inequality (7) follow from the Pigeonhole Principle? (I verified it supposing by contradiction that the inequality is eventually false for large enough N, and concluded that the sequence grows exponentially, but this argument doesn’t seem to use the Pigeonhole Principle at all)")

#text("Thank you in advance")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-465706")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2016")])]

#text("For Lemma 4, one has to show (roughly speaking) that for fixed ")#mi("g")#text(", that ")#mi("g F_n")#text(" is close to ")#mi("F_n")#text(" when ")#mi("n")#text(" is large. The point is that for most ")#mi("x")#text(" in ")#mi("B_n")#text(", ")#mi("gx")#text(" still lies in ")#mi("B_n")#text(", and for ")#mi("f(n)")#text(" large enough, ")#mi("g \\phi(x) A_{f(n)}")#text(" will be close to ")#mi("\\phi(gx) A_{f(n)}")#text(". It is an instructive exercise to make the above informal argument rigorous by using epsilons and deltas.")

#text("The sum in Proposition 5 was a typo which has now been corrected.")

#text("For (7), one can pigeonhole the quantities ")#tao-math("\\left|D \\cap \\Gamma_N\\right|", block: false)#text(", where ")#mi("N")#text(" ranges over the multiples of 10 between 1 and some large number ")#mi("N_0")#text(", into pigeonholes of the form ")#mi("[(1.01)^j, (1.01)^{j+1}]")#text(", where ")#mi("j")#text(" ranges up to about ")#mi("O(\\log N_0)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08375cec724870c30e716e94b5c0b95ab418f0211204e1465021574c0b3c96c0-5080eda75ca3341edb7a89c6895eb48cae10aa2ef7fa312eedb19e447b273add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-466023")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("Professor Tao:")

#text("Is this argument correct to justify, in Corollary ")#strike[#text("4")]#text(" 5, that two copies ")#mi("C_1")#text(", ")#mi("C_2")#text(" of ")#mi("S^2 \\backslash E")#text(" may be used to cover the whole sphere, or is the justification a lot more trivial than this?")

#text("The idea is to leave ")#mi("C_1")#text(" intact and then rotate ")#mi("C_2")#text(" once to cover the remaining holes. We take as axis of rotation some line ")#mi("l")#text(" through the origin that has empty intersection with ")#mi("E")#text(". Then, if we project each hole along the great circle passing through the hole and the poles into the maximum circle orthogonal to ")#mi("l")#text(", one sees that the problem is reduced to rotating this newly punctured maximum circle in such a way that every hole is covered. If, say ")#mi("E^{\\prime}=\\{e^{ix_1},e^{ix_2},\\ldots\\}")#text(" is the set of holes, one simply needs to find some angle of rotation ")#mi("\\theta")#text(" such that ")#mi("\\{e^{i(x_1-\\theta)},e^{i(x_2-\\theta)},\\ldots\\}")#text(" is disjoint from ")#mi("E")#text(". But if these sets have non-empty intersection, so that ")#mi("e^{ix_n}=e^{i(x_m-\\theta)}")#text(", it follows that ")#mi("\\theta=x_m-x_n+2k\\pi")#text(". But the right side of this equation takes countably many values, so we may pick an adequate real number ")#mi("\\theta")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-466024")[#strong[#text("Ian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("You probably meant Corollary 5.")

#emph[#text("[Corrected – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-466030")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("This will work; one can also rotate ")#mi("E")#text(" and ")#mi("S^2 \\backslash E")#text(" by a random element ")#mi("R")#text(" of the orthogonal group (drawn using Haar measure). For any ")#mi("x_i, x_j \\in E")#text(", the probability that ")#mi("R")#text(" maps ")#mi("x_i")#text(" to ")#mi("x_j")#text(" is zero (as this restricts ")#mi("R")#text(" to a positive codimension subset of the orthogonal group). Hence by countable additivity, one almost surely has ")#mi("R(E)")#text(" disjoint from ")#mi("E")#text(", and so ")#mi("S^2 \\backslash E")#text(" and ")#mi("R(S^2 \\backslash E)")#text(" cover ")#mi("S^2")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08375cec724870c30e716e94b5c0b95ab418f0211204e1465021574c0b3c96c0-5080eda75ca3341edb7a89c6895eb48cae10aa2ef7fa312eedb19e447b273add.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-466031")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2016")])]

#text("Professor Tao:")

#text("The question I posted earlier today seems to have dissappeared, and more importantly your answer (which you seem to have posted recently according to the blog history) is also unreadable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-466044")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2016")])]

#text("Re broken comments: this appears to be due to the wordpress “paged comments” misfeature. (There is never any reason to ever “page” web content, because “scrolling” has existed long before the web did. Just say no!)")

#text("Based on nothing but googling “comment-page-1” and “wordpress”, it may be that turning off “")#link("https://en.support.wordpress.com/comment-display-options/view-all/")[#text("Break comments into pages with XXX top-level comments")]#text("” in the admin interface /wp-admin/options-discussion.php might do the trick.")

#text("Or this might be a new bug in the rotten guts of wordpress.com")

#emph[#text("[Comments reverted to an unbroken page. (A previous commenter had requested the change due to some pages with 100+ comments being slow to load.) -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-491736")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I was not quite sure where to post, or whether this is of any value to you, but while tidying up, I was reading through some things on my to-do list, among them this writeup:")

#link("https://www.math.ucla.edu/~tao/preprints/Expository/banach-tarski.pdf")[#text("Click to access banach-tarski.pdf")]

#text("I’m not sure whether the decomposition in the second equation* in the proof of thm. 1.1 holds true, because we e.g. have that the word ")#mi("A A^{-1} A")#text(" represents the same group element as the word ")#mi("A")#text(".")

#text("The argument is of course still correct, and the fix is trivial: One only has to exclude all the elements which occur in both sets from one of the two.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92efc118645641ff5f74829dd06f58ee398368d4c3e27b28860a2e0332778138-fde5f227727d0cffd8e97dab0b3b5fb1aee50084cdc6ec1c8fceef4d332a52fc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-491738")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2018")])]

#text("I see you mean REDUCED words. OK.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80c774921d70f7c0b06c050ee281750417eac45aa39a7e1a7613005cd881e532-873c9e956a60231b050e579e82101ec270345943011fc21f2469326a7bfe29ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ahmad Hussein")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-642518")[#strong[#text("Ahmad Hussein")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("Dear professor Tao,")

#text("In the proof of the Hausdorff paradox, you write: “the action of F2 on SO(3)\\E is free”. I think it should be S2\\E rather than SO(3)\\E. Am I wrong?")

#text("Thank you and best regards.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-691588")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Dear professor Tao:")

#text("For Exercise 2, if one can partition ")#mi("A")#text(" and ")#mi("B")#text(" into equidecomposable pairs then the original two sets are equidecomposable. Can you elaborate a little on how the back-and-forth mapping proof of the Schroder-Berstein theorem helps to construct this explicit partition? Are we using induction here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-691595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("I am ")#link("https://chatgpt.com/share/696e702c-0ba0-800e-8a41-a1bf6cf0dd88")[#text("outsourcing this question to an AI")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-691596")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Thank you so much professor Tao.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/01/08/245b-notes-2-amenability-the-ping-pong-lemma-and-the-banach-tarski-paradox-optional/#comment-691600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Now AI can answer all the undergraduate course questions and beyond. The only thing that AI can’t do now is mathematical research? Wonder what is the future of math?")

#emph[#text("[I have several thoughts on this topic recorded on ")#link("https://terrytao.wordpress.com/mastodon-posts/")[#text("this page")]#text(". -T]")]
]
]
]
