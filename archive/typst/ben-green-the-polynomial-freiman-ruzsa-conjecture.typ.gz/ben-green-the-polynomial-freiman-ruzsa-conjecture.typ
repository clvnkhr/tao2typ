// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:34:51.849466+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Ben Green) The Polynomial Freiman-Ruzsa conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Ben Green) The Polynomial Freiman-Ruzsa conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 March 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("[")#emph[#text("This post is authored by ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(", who has kindly “guest blogged” this week’s “open problem of the week”.")]#text(" – T.]")

#text("In ")#link("https://terrytao.wordpress.com/2007/03/02/open-question-noncommutative-freiman-theorem/")[#text("an earlier blog post")]#text(" Terry discussed Freiman’s theorem. The name of Freiman is attached to a growing body of theorems which take some rather “combinatorial” hypothesis, such that the sumset |A+A| of some set A is small, and deduce from it rather “algebraic” information (such that A is contained in a subspace or a grid).")

#text("The easiest place to talk about Freiman’s theorem is in the finite field model ")#mi("{\\Bbb F}_2^n")#text(" (see ")#link("http://www.ams.org/mathscinet-getitem?mr=2187732")[#text("my survey article on this subject ")]#text("for a full discussion). Here it was ")#link("http://www.ams.org/mathscinet-getitem?mr=1701207")[#text("shown by Ruzsa")]#text(" that if |A+A| is at most ")#tao-math("K \\left|A\\right|", block: false)#text(" then A is contained in a subspace of size no more than about ")#tao-math("2^{K^4}\\left|A\\right|", block: false)#text(". The exponent has been improved a few times since Ruzsa’s paper, the best result currently in print being ")#link("http://arxiv.org/abs/math.NT/0605523")[#text("due to Sanders")]#text(", who obtains an upper bound of ")#tao-math("2^{K^{3/2}\\log K}\\left|A\\right|", block: false)#text(". Terry and I are in the process of writing a paper which obtains ")#tao-math("2^{2K + o(K)}\\left|A\\right|", block: false)#text(", which is best possible in view of the example ")#mi("A := \\{e_1,...,e_m\\}")#text(" where ")#mi("m := 2K + O(1)")#text("; this set has doubling roughly K but is not contained in a subspace of dimension smaller than 2K.")

#text("This result has an air of finality (except for the true nature of the o(K) term, which represents an interesting open problem). This is something of an illusion, however. Even using this theorem, one loses an exponential every time one tries to transition between “combinatorial” structure and “algebraic” structure and back again. Indeed if one knows that A is contained in a subspace of size ")#tao-math("2^{2K}\\left|A\\right|", block: false)#text(" then the strongest assertion one can make about the doubling of A is that it is at most ")#mi("2^{2K}")#text(".")

#text("The ")#emph[#text("Polynomial Freiman-Ruzsa conjecture")]#text(" (PFR), in ")#mi("{\\Bbb F}_2^n")#text(", hypothesises a more precise structure theorem for sets with small doubling. Using this")#linebreak()#text(" conjecture, one may flit back and forth between combinatorial and algebraic structure with only ")#strong[#text("polynomial")]#text(" losses. ")#link("http://www.ams.org/mathscinet-getitem?mr=1701207")[#text("Ruzsa attributes")]#text(" the conjecture to")#linebreak()#text(" Marton: it states that if A has doubling at most K then A is contained in the union of ")#mi("K^{O(1)}")#text(" translates of some subspace H of size at most |A|.")

#metadata(none) <tao-14ab81287cc740a18c23>#text("Various equivalent formulations of this may be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=2187732")[#text("my survey article referenced above")]#text(". They are all due to Imre Ruzsa and here is one I find particularly tantalising: suppose that ")#mi("f : {\\Bbb F}_2^n \\to {\\Bbb F}_2^n")#text(" is a function such that the size of the set ")#mi("\\{f(x+y) - f(x) - f(y): x,y \\in {\\Bbb F}_2^n\\}")#text(" is at most K. Then f can be written as g + h, where g is linear and the cardinality ")#tao-math("\\left|h({\\Bbb F}_2^n)\\right|", block: false)#text(" of the image of h is bounded by a polynomial in K. It is fairly clear that h can be made at most ")#mi("2^K")#text("; simply define f on the basis vectors and extend linearly. Now I come to think of it, for ")#strong[#text("this")]#text(" variant of the problem I’m not sure a bound much better than ")#mi("2^K")#text(" is known at all.")

#text("The main open problem in the area is to prove the PFR. There are two other groups of problems which might be highlighted here:")

#enum(start: 1, 
[#emph[#text("Generalising the PFR to other groups")]#text(". Even for the group ")#mi("\\Bbb Z")#text(", there is some controversy about the statement of PFR. I’d be happy enough to")#linebreak()#text(" formulate the following conjecture: If the doubling of A is at most K then there is a convex body P of dimension ")#mi("O(\\log K)")#text(" and volume at most |A|")#linebreak()#text(" together with an affine map ")#mi("\\phi : P \\to {\\Bbb Z}")#text(" such that A lies in the union of at most ")#mi("K^C")#text(" translates of A.It may be that some slightly technical “roundness” condition on P is desirable for applications. It is not clear at present whether P can be")#linebreak()#text(" taken to be a box; this seems to involve some rather tricky geometry of numbers issues though one suspects the answer may be “no”.")],
[#emph[#text("Applications")]#text(". The PFR seems to be the key to unlocking the relationship between combinatorial and algebraic structure. But what applications does")#linebreak()#text(" it have? It could be very helpful in the theory of sum-product estimates; I know for example that it easily implies a (very difficult) ")#link("http://www.ams.org/mathscinet-getitem?mr=2051619")[#text("result of")#linebreak()#text(" Bourgain and Chang")]#text(" which states that ")#tao-math("\\text{max}( \\left|kA\\right|, \\left|A^k\\right| ) \\gg \\left|A\\right|^{f(k)}", block: false)#text(", where f(k) tends to infinity with k. Could it be helpful with, say, ")#link("http://en.wikipedia.org/wiki/Waring's_problem")[#text("Waring’s problem")]#text("? If the ")#mi("k^{th}")#text(" powers A are not a basis of small order then the iterated sumset ")#mi("(i+1)A")#text(" must be closer than one expects to ")#mi("iA")#text(", for some i. One might then hope to show that the ")#mi("k^{th}")#text(" powers have some kind of weak algebraic structure, a possibility which could be eliminated by other (number-theoretical means). I don’t have any idea how to do either part of this at the moment.")],
[#text("Another possible application might be to the following very nice question: If A is a set of square numbers, is ")#tao-math("\\left|A+A\\right| \\gg \\left|A\\right|^{1+c}", block: false)#text(" for some positive c? Again, one could use PFR to show that if this is not the case then there is a set of squares with high density on a “grid” (image of a convex body). One might then hope to adapt techniques of ")#link("http://www.ams.org/mathscinet-getitem?mr=1949479")[#text("Bombieri, Zannier")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1167100")[#text("Granville and Pintz")]#text(" which showed that squares cannot concentrate overly much on a progression. I particularly like this question because it seems very closely related to a lovely ")#link("http://www.ams.org/mathscinet-getitem?mr=116177")[#text("question of Rudin")]#text(": Are the squares ")#mi("\\{ n^2: n \\in {\\Bbb N}\\}")#text(" a ")#mi("\\Lambda(p)")#text(" set for some p less than 4? I refer the reader to ")#link("http://www.ams.org/mathscinet-getitem?mr=1863693")[#text("Bourgain’s survey article")]#text(" on ")#mi("\\Lambda(p)")#text(" sets for more information.")]
)

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-88")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2007")])]

#text("Marton’s conjecture and the many equivalent formulation by Ruzsa are very beautiful. Let me mention something little that I find interesting: You have these two equivalent formulations (1) and (2) (from Green’s paper). (1) says that we can find inside A a subset A’ of size at least ")#tao-math("\\left|A\\right|/C_1(K)", block: false)#text(" which is contained in a coset of size at most ")#tao-math("\\left|A\\right|", block: false)#text(". (2) says that you can cover |A| with ")#mi("C_2(K)")#text(" such sets A’. The non trivial implication (1) –> (2) is rather easy in view of Ruzsa’s lemma 1.2 (in Green’s paper).")

#text("In abstract combinatorial settings you can expect (if things go your way and you can maintain the assumptions after deleting A’) an additional factor of ")#tao-math("\\log \\left|A\\right|", block: false)#text(" moving from (1) to (2). Some sort of integrality gap. And getting rid of it is at times impossible, at times open, and at times hard. Here, somehow the additive structure makes (1) and (2) quite easily, almost the same. (In combinatorial geometry you also sometimes see similar phenomena.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-89")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2007")])]

#text("Dear Gil,")

#text("I tend to view the Freiman-Ruzsa theory as more of an “approximate group theory” than a purely combinatorial theory, to emphasise the additional algebraic (rather than combinatorial) structure present.")

#text("For instance, if H and L are two finite subgroups of an abelian group G, and K is an integer, then it is not hard to show that the following two statements are equivalent: (1) H has a subset of size at least ")#tao-math("\\left|H\\right|/K", block: false)#text(" which is contained in a coset of L, and (2) H is covered by K translates of L. Indeed, the equivalence is essentially the first homomorphism theorem from undergraduate algebra. Ruzsa’s lemma is thus the robust version of this theorem.")

#text("I am hoping that eventually we will be able to “robustify” many other results in group theory (or ring theory, etc.) to extend to approximate groups. For instance, as I mentioned in an earlier post, Freiman’s theorem can be viewed as a robust version of the classification of finite abelian groups as the direct product of cyclic groups (or perhaps, a classification of the finitely generated abelian groups as the direct product of cyclic groups and copies of Z). Ultimately we might hope to manipulate “1%-structured objects” (such as sets which are closed under addition 1% of the time) with the almost the same degree of versatility as we currently enjoy while manipulating “100%-structured objects” (such as sets which are closed under addition 100% of the time, i.e. groups). An intermediate stage in this program would be to study “99%-structured objects”, e.g. a finite group with 1% of its elements removed and another 1% of garbage elements added. Here we seem to have a very good theory, due to the use of majority-vote and similar tools to “clean up” all the noise.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-90")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2007")])]

#text("On the general subject of robust versions of results in group theory, there is the theorem of Ben-Or, Coppersmith, Luby, and Rubinfeld that an approximate homomorphism between two finite groups is close to a group homomorphism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ben green")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-91")[#strong[#text("ben green")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2007")])]

#text("Greg,")

#text("Yes, indeed there is. They definitely beat us additive combinatorialists to this whole game of making exact algebraic structures out of approximate ones. But I recently discovered that essentially the same idea occurs in a paper of Fournier from 1977 called “")#link("http://www.ams.org/mathscinet-getitem?mr=461034")[#text("Sharpness of Young’s inequality for convolution")]#text("“.")

#text("He is interested in the following question: for which groups G is the Young inequality, which states (say) that ")#tao-math("\\left\\|f*f\\right\\|_{L^2} \\leq \\left\\|f\\right\\|_{L^{4/3}}^2", block: false)#text(", basically sharp? I.e. in which circumstances can you improve it to the statement that ")#tao-math("\\left\\|f*f \\right\\|_{L^2} \\leq c \\left\\|f\\right\\|_{L^{4/3}}^2", block: false)#text(", where c is less than one?")

#text("He shows that one can do this provided that G does not have compact open subgroups (note that G does not need to be abelian).")

#text("You can sort of see the connection to what we’re talking about here – if there is some f for which ")#tao-math("\\left\\|f*f\\right\\|_{L^2}", block: false)#text(" is about as big as ")#tao-math("\\left\\|f\\right\\|_{L^{4/3}}^2", block: false)#text(" then this means (after expanding out) that the support of f has got to be 99 percent closed under addition. He then goes on to show that the support must be close to a true subgroup.")

#text("So I sort of think of Fournier as the father of approximate, or “99 percent” theory, unless someone can point me to an earlier paper :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freiman's theorem in finite fields via extremal set theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-160")[#strong[#text("Freiman's theorem in finite fields via extremal set theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2007")])]

#text("[…] theorem in the 2-torsion case, and in particular getting some partial results on the polynomial Freiman-Ruzsa conjecture. Specifically, we show that if has doubling constant at most K, thus , then A can be contained in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A counterexample to a strong polynomial Freiman-Ruzsa conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-33476")[#strong[#text("A counterexample to a strong polynomial Freiman-Ruzsa conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2008")])]

#text("[…] open problems in additive combinatorics is the polynomial Freiman-Ruzsa conjecture, which Ben Green guest blogged about here some time ago. It has many equivalent formulations, but here is one involving […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Non-commutative Freiman theorems, and model theory « What’s new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-42725")[#strong[#text("Non-commutative Freiman theorems, and model theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2009")])]

#text("[…] description of sets of small doubling. (For more on the question of improving the constants, see this guest blog post of Ben […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 4: The Bourgain-Gamburd expansion machine « What’s new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-122233")[#strong[#text("254B, Notes 4: The Bourgain-Gamburd expansion machine « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2012")])]

#text("[…] which are qualitatively similar in spirit, but have much worse quantitative bounds (though there is some hope in the case of Freiman’s theorem to only lose polynomial bounds with some improvement of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Metric entropy analogues of sum set theory | What's new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-277057")[#strong[#text("Metric entropy analogues of sum set theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2014")])]

#text("[…] does, however the known bounds in the latter theorem are worse than polynomial in (although it is conjectured otherwise), whereas the elementary estimates are almost all polynomial in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-529414")[#strong[#text("Khot,Minzer,Safra on approximate sections of sheaves | Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2019")]

#text("[…] is meant to recall the principle from additive number theory that an approximate subgroup is approximately a subgroup, as in e.g. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sumsets and entropy revisited | What's new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-679077")[#strong[#text("Sumsets and entropy revisited | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2023")])]

#text("[…] preprint “Sumsets and entropy revisited“. This paper uses entropy methods to attack the Polynomial Freiman-Ruzsa (PFR) conjecture, which we study in the following two […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-679080")[#strong[#text("Sumsets and entropy revisited | What's new - Being Teaching 2023")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2023")]

#text("[…] “Sumsets and entropy revisited“. This paper makes use of entropy strategies to assault the Polynomial Freiman-Ruzsa (PFR) conjecture, which we examine within the following two […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-679082")[#strong[#text("Sumsets and entropy revisited | What's new - Gud Learn")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2023")]

#text("[…] and entropy revisited“. This paper makes use of entropy techniques to assault the Polynomial Freiman-Ruzsa (PFR) conjecture, which we research in the adhering to 2 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-680575")[#strong[#text("Sumsets and entropy revisited | What's new - keiseronlineuniversity.com")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2023")]

#text("[…] “Sumsets and entropy revisited“. This paper makes use of entropy strategies to assault the Polynomial Freiman-Ruzsa (PFR) conjecture, which we examine within the following two […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-682236")[#strong[#text("Marton’s “Polynomial Freiman-Rusza” Conjecture was Settled by the A-Team. | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")]

#text("[…] conjecture” was certainly a holy grail of additive combinatorics. (Here is a 2007 short blog post by Ben Green presenting the problem.) Tim Gowers, Ben Green, Freddie Manners and Terry Tao have now solved it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On a conjecture of Marton | What's new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-682241")[#strong[#text("On a conjecture of Marton | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("[…] paper “On a conjecture of Marton“. This paper establishes a version of the notorious Polynomial Freiman–Ruzsa conjecture (first proposed by Katalin […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-682245")[#strong[#text("On a conjecture of Marton - Gud Learn")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")]

#text("[…] paper “On a conjecture of Marton“. This paper develops a variation of the well-known Polynomial Freiman–Ruzsa conjecture (very first proposed by Katalin […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marton’s conjecture in abelian groups with bounded torsion | What's new")]], [#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/#comment-684659")[#strong[#text("Marton’s conjecture in abelian groups with bounded torsion | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2024")])]

#text("[…] This paper fully resolves a conjecture of Katalin Marton (the bounded torsion case of the Polynomial Freiman–Ruzsa conjecture (first proposed by Katalin […]")
]
