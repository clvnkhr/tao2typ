// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/08/22/bill-thurston/
// Converted to Typst by tao2typ: "2026-10-14T15:18:27.346994+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Bill Thurston", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Bill Thurston")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 August 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/")[#text("https://terrytao.wordpress.com/2012/08/22/bill-thurston/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://en.wikipedia.org/wiki/William_Thurston")[#text("Bill Thurston")]#text(", who made fundamental contributions to our understanding of low-dimensional manifolds and related structures, ")#link("http://www.math.cornell.edu/News/news.html")[#text("died on Tuesday")]#text(", aged 65.")

#text("Perhaps Thurston’s best known achievement is the proof of the ")#link("http://en.wikipedia.org/wiki/Hyperbolization_theorem")[#text("hyperbolisation theorem")]#text(" for ")#link("http://en.wikipedia.org/wiki/Haken_manifold")[#text("Haken manifolds")]#text(", which showed that 3-manifolds which obeyed a certain number of topological conditions, could always be given a hyperbolic geometry (i.e. a Riemannian metric that made the manifold isometric to a quotient of the hyperbolic 3-space ")#mi("H^3")#text("). This difficult theorem connecting the topological and geometric structure of 3-manifolds led Thurston to give his influential ")#link("http://en.wikipedia.org/wiki/Thurston_conjecture")[#text("geometrisation conjecture")]#text(", which (in principle, at least) completely classifies the topology of an arbitrary compact 3-manifold as a combination of eight model geometries (now known as ")#emph[#text("Thurston model geometries")]#text("). This conjecture has many consequences, including Thurston’s hyperbolisation theorem and (most famously) the ")#link("http://en.wikipedia.org/wiki/Poincar%C3%A9_conjecture")[#text("Poincaré conjecture")]#text(". Indeed, by placing that conjecture in the context of a conceptually appealing general framework, of which many other cases could already be verified, Thurston provided one of the strongest pieces of evidence towards the truth of the Poincaré conjecture, until the ")#link("http://arxiv.org/abs/math/0211159")[#text("work of")]#text(" ")#link("http://arxiv.org/abs/math/0303109")[#text("Grisha")]#text(" ")#link("http://arxiv.org/abs/math/0307245")[#text("Perelman")]#text(" in 2002-2003 proved both the Poincaré conjecture and the geometrisation conjecture by developing Hamilton’s Ricci flow methods. (There are now several variants of Perelman’s proof of both conjectures; in the ")#link("http://arxiv.org/abs/0706.2065")[#text("proof of geometrisation by Bessieres, Besson, Boileau, Maillot, and Porti")]#text(", Thurston’s hyperbolisation theorem is a crucial ingredient, allowing one to bypass the need for the theory of Alexandrov spaces in a key step in Perelman’s argument.)")

#text("One of my favourite results of Thurston’s is his elegant method for ")#link("http://en.wikipedia.org/wiki/Smale's_paradox")[#text("everting the sphere")]#text(" (smoothly turning a sphere ")#mi("S^2")#text(" in ")#mi("{\\bf R}^3")#text(" inside out without any folds or singularities). The fact that sphere eversion can be achieved at all is highly unintuitive, and is often referred to as ")#link("http://en.wikipedia.org/wiki/Smale's_paradox")[#text("Smale’s paradox")]#text(", as Stephen Smale was the first to give a proof that such an eversion exists. However, prior to Thurston’s method, the known constructions for sphere eversion were quite complicated. Thurston’s method, relying on corrugating and then twisting the sphere, is sufficiently conceptual and geometric that it can in fact be explained quite effectively in non-technical terms, as was done in the following excellent video entitled “")#link("http://www.geom.uiuc.edu/docs/outreach/oi/")[#text("Outside In")]#text("“, and produced by ")#link("http://en.wikipedia.org/wiki/The_Geometry_Center")[#text("the Geometry Center")]#text(":")

#text("In addition to his direct mathematical research contributions, Thurston was also an amazing mathematical expositor, having the rare knack of being able to describe the ")#emph[#text("process")]#text(" of mathematical thinking in addition to the ")#emph[#text("results")]#text(" of that process and the ")#emph[#text("intuition")]#text(" underlying it. His wonderful essay “")#link("http://arxiv.org/abs/math.HO/9404236")[#text("On proof and progress in mathematics")]#text("“, which I highly recommend, is the quintessential instance of this; more recent examples include his ")#link("http://mathoverflow.net/users/9062/bill-thurston")[#text("many insightful questions and answers on MathOverflow")]#text(".")

#text("I unfortunately never had the opportunity to meet Thurston in person (although we did correspond a few times online), but I know many mathematicians who have been profoundly influenced by him and his work. His death is a great loss for mathematics.")

#heading(level: 1)[#text("Comments (37)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162065")[#strong[#text("Bill Thurston, 1946-2012 | Not Even Wrong")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")]

#text("[…] Terry Tao has more about Thurston and his work here. This entry was posted in Uncategorized. Bookmark the permalink. ← This Week’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")])]

#text("a silly question: why is he called Bill Thurston instead of William Thurson?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf4b649fbe41fc8248a12e887c13c1ebbb1112f647db66ce692eb66a4f9ec7f2-0e01e49d5fafc01da33cc52603ce86dbbe6d68b2069d42f14d59dea685c85dc9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162156")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")])]

#text("Uh, because everyone called him Bill (which is a common short form of William).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162090")[#strong[#text("William Thurston, 1946 – 2012 « Series divergentes")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")]

#text("[…] Bill Thurston, What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162106")[#strong[#text("Remembering Bill Thurston « Portrait of the Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")]

#text("[…] Terry Tao has a much more mathematically complete obituary.] Like this:LikeBe the first to like […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162148")[#strong[#text("Bill Thurston: 1946 – 2012 | OU Math Club")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")]

#text("[…] read more about Dr. Thurston’s work, check out Terry Tao’s post about his work. In particular, read about Dr. Thurston’s proof of Smale’s result commonly called […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162170")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2012")])]

#text("I remember very vividly how William Thurston back in 1977 at Cornell May Topology Festival presented his deep understandings of topology and geometry of 3-manifolds and how John Milnor posed questions which eventually lead to the solution of Poincare conj. by Perelman.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162300")[#strong[#text("Ha muerto William Thurston (1946-2012) - Gaussianos | Gaussianos")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2012")]

#text("[…] Bill Thurston en el blog de Terence Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162394")[#strong[#text("William Thurston e a Matemática com Empreendimento Humano | True Singularity")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2012")]

#text("[…] Thurston. Não sobre a obra dele em particular, informações que você pode encontrar aqui ou aqui por exemplo. Quero falar sobre suas contribuições que transcendem a mera contribuição à […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162479")[#strong[#text("‘t Hooft and quantum computation « The Gauge Connection")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2012")]

#text("[…] Gerard ‘t Hooft is one of greatest living physicists, one of the main contributors to the Standard Model. He has been awarded the Nobel prize in physics on 1999. I have had the opportunity to meet him in Piombino (Italy) at a conference on 2006 where he was there to talk about his view on foundations of quantum mechanics. He is trying to understand the layer behind quantum mechanics and this question has been a source of discussions here where he tried to find a fair audience to defend his view. Physics StackExchange, differently from MathOverflow or mathematicians, has not reached the critical mass with most of the community, Fields medalists included for the latter, where the stars of the physics community take time to contribute. The reason is in the different approaches of these communities that can make a hard life for a Nobel winner while mathematicians’ approach appears polite and often very helpful. This can also be seen with the recent passing away of the great mathematician William Thurston (see here). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a38a0f6dccf26b776c611c66b3544b32522610f511e6da71d573ef644036ed56-370b8b7d8bf4578f5cab198d5785e5cecb44ba93d40b6702a7edc273029cb625.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Wolff")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162612")[#strong[#text("George Wolff")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2012")])]

#text("I had a fine English professor at Washington Univ in St Louis in the 1950s–Jarvis Thurston, who worked through his doctorate in mathematics. I wonder if he and William Thurston were related. Anyone know?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c968c52c454574800e4339dcbf349c75d14a4bdfddfd806442de28c84df70d33-892b8bd5c0053abdabe5e066d3aee028b3297680af408699b00f6f334e438890.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burhan")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162632")[#strong[#text("Burhan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2012")])]

#text("I remember that he also dabbled a bit as fashion designer for Issey Miyake.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c968c52c454574800e4339dcbf349c75d14a4bdfddfd806442de28c84df70d33-892b8bd5c0053abdabe5e066d3aee028b3297680af408699b00f6f334e438890.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burhan")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162637")[#strong[#text("Burhan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2012")])]

#text("Sorry, I didn’t know that the video gets embedded automatically if you post a youtube link.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of unreal")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162761")[#strong[#text("unreal")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("Hm, regarding the sphere inversion: Is there a special reason to use eight belts in the center, why aren’t 3 enough?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-163040")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("One can use fewer belts, although one needs to increase the amount of corrugation to compensate for this. See the comments at ")#link("http://www.scottaaronson.com/blog/?p=279")[#text("http://www.scottaaronson.com/blog/?p=279")]#text(" for some related discussion (including some by the creators of that video).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162778")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("Terry, you should call Perelman by Grigori instead of Grisha. It is not proper to write his name like this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-162994")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("Grisha is the name Perelman goes by in ")#link("http://arxiv.org/abs/math/0211159")[#text("his own")]#text(" ")#link("http://arxiv.org/abs/math/0303109")[#text("research")]#text(" ")#link("http://arxiv.org/abs/math/0307245")[#text("papers")]#text(", which is the usual standard for determining how to formally refer to an author. (It is true that there ")#link("http://english.pravda.ru/science/tech/28-04-2011/117727-Grigori_Perelman-0/")[#text("was an alleged interview")]#text(" claiming otherwise in Perelman’s case, but ")#link("http://english.pravda.ru/society/stories/06-05-2011/117816-grigori_perelman-0/")[#text("this interview appears to be suspect")]#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-163166")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("I see. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-168271")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2012")])]

#text("I wonder who down voted this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/680171dc78c80bd8820dc89c6589ab936e646fe12cbe1b0adf01f5612fa70a88-14f626dfd791b19f757cff15bafa94be9184aea65306a62e5aa4da22acc50a2e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zuchongzhi")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-168391")[#strong[#text("zuchongzhi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2012")])]

#text("Calling Perelman with Grisha as a stranger is not appropriate because Russian people usually use the first name with patronymic and not the colloquial short name to show proper respect. However as Terry pointed out Perelman used Grisha as his first name in his papers. I guess the first down-voting my post might share a different opinion and not bothered to post in here, as the matter is quite trivial.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William P. Thurston « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-163030")[#strong[#text("William P. Thurston « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("[…] Bill Thurston, here. Has the video link for Outside In where everting the sphere is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3adc0fa641826475281b39d307e467688e2b452369f6781defe6603b6a4abc19-f2dcfa2ced2b5fc884708f28459df8b4bb1d73f56df813ca7a2de457990a8ae6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timrriley")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-163147")[#strong[#text("timrriley")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")])]

#text("There is a page up at Cornell in tribute to Thurston:")#linebreak()#text(" ")#link("http://www.math.cornell.edu/News/2012-2013/thurston.html")[#text("http://www.math.cornell.edu/News/2012-2013/thurston.html")]#linebreak()#text(" It includes a place for posting remembrances and a selection of quotes from Thurston, assembled by his son Dylan.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-163204")[#strong[#text("Two well-known mathematicians died this week « God plays dice")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2012")]

#text("[…] Terry Tao briefly summarizes some of Thurston’s work. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-163856")[#strong[#text("Bill Thurston « What’s new « Magno Valdetaro | Feedshare")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2012")]

#text("[…] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-164001")[#strong[#text("Bill Thurston « algebrafm")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2012")]

#text("[…] Bill Thurston. Share this:TwitterFacebookMe gusta:Me gustaBe the first to like this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71057e2fd53f41ae3af7bc11e4f9ba881ea0dba8c065e4fe79054cfae8d21198-ad7d545c36596c57166e06dff42a29681b48b6a192da658762b824911786a028.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ay Carumba!")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-164810")[#strong[#text("Ay Carumba!")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2012")])]

#text("Is the Latimes going to report this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-165659")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2012")])]

#text("My BibTeX file contains many more quotes by Bill Thurston than any other mathematician, and as a tribute I have posted ")#strong[#link("http://rjlipton.wordpress.com/2012/08/23/do-we-need-mysticism-in-theory/#comment-24950")[#text("two of Thurston’s meditations")]]#text(" on ")#emph[#text("Gödel’s Lost Letter and P=NP")]#text(", as comments under the topic “Do We Need Mysticism In Theory?” (there was no intent to impute mysticism to either of Thurston’s eminently practical comments).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-165746")[#strong[#text("Descance en paz, William P. Thurston (1946-2012) « Francis (th)E mule Science's News")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2012")]

#text("[…] información en los blogs de Peter Woit y Terence Tao, en su universidad (Cornell), Scientific American, The New York Times, MacTutor, y muchos […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-199862")[#strong[#text("Bill Thurston « Follow the Beauty of Mathematics")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")]

#text("[…] Bill Thurston. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50489bf23f86ddf39137bc1a17b2aec82b28aaa0ee64e372deeab90e3bc3f7c5-09b5ca86140344057955e603142f9529447f24b84f302546edc69bdbe31bc8b7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of changbing")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-199867")[#strong[#text("changbing")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2012")])]

#text("Reblogged this on ")#link("http://changbing.wordpress.com/2012/12/06/37/")[#text("Follow the Beauty of Mathematics")]#text(" and commented:")#linebreak()#text(" 19世纪最伟大的数学成就之一是从拓扑观点对二维曲面进行分类，也就是把它们看成橡皮膜，只要不撕破就可以任意变形。从抽象的观点来看，一个鼓胀的球和一个干瘪的球都是同一球面；另一方面，一个球面和一个救生圈是不同的曲面，因为球面不可能在不被破坏的条件下变形成为一个救生圈。在二维曲面的分类完成以后，自然的一步就是对三维曲面进行分类。这一工程在二十世纪七十年代由瑟斯顿开始。甚至这项工作还没有完成，他的成就就导致他获得1982年的菲尔兹奖。他证明：任何三维流形均容许一个几何分解，分解后的“零部件”拥有8种可能的几何结构之一,并指出庞加莱猜想只是几何化猜想的一个特例。")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f6c8741a0e27a5b7f8c3ed5c9a564a9b5f4e13c3813b1a372078dfe0caa40816-842b45d6579e14b6782f1c5abe81bf949e91929e70cdcf7776825c85e8df116a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauldepstein")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-224069")[#strong[#text("pauldepstein")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2013")])]

#text("I read that, during the 1980’s, Thurston introduced computers to the pure maths dept. However, the funds only included the costs of the actual computers, with no additional funding for employing staff. Therefore, according to this account, much of the necessary infrastructural work, such as laying cables for the machines etc, had to be undertaken by Thurston himself. Does anyone know why raising the funds was so difficult? I would never have thought that Princeton University Maths Dept. was so cash-starved.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45b3c56e5215cbaaef87156c4f14b44a86b87155f97ab8d581d6b697580662f5-a77b2aa127f70574f3f9bd6009e92d70107d70d1bf90fe0728cf96436adf6707.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ¿Qué nos motiva a hacer matemáticas? | p-fold")]], [#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-231229")[#strong[#text("¿Qué nos motiva a hacer matemáticas? | p-fold")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2013")])]

#text("[…] poco se dio la noticia del fallecimiento del matemático William Thurston. En el blog de Terence Tao puede leerse acerca del trabajo de Thurston, se muestra un video muy interesante sobre la eversión […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-244820")[#strong[#text("William Thurston | ENJOYING...")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")]

#text("[…] terrence tao: https://terrytao.wordpress.com/2012/08/22/bill-thurston/ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-300327")[#strong[#text("Descanse en paz, William P. Thurston (1946-2012) | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2014")]

#text("[…] información en los blogs de Peter Woit y Terence Tao, en su universidad (Cornell), Scientific American, The New York Times, MacTutor, y muchos […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-449740")[#strong[#text("Bill Thurston | The Lumber Room")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2015")]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/")[#text("https://terrytao.wordpress.com/2012/08/22/bill-thurston/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-642806")[#strong[#text("菲爾茲獎得主Thurston與龐加萊猜想 – 嘎嘎酷")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2022")]

#text("[…] Bill Thurston […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/08/22/bill-thurston/#comment-665574")[#strong[#text("菲尔兹奖得主Thurston与 施拉姆公式(关于施拉姆公式的简 | 生活号")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2022")]

#text("[…] Bill Thurston […]")
]
