// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/
// Converted to Typst by tao2typ: "2026-10-14T16:38:57.330030+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Singmaster’s conjecture in the interior of Pascal’s triangle", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Singmaster’s conjecture in the interior of Pascal’s triangle")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 June 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/")[#text("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://users.utu.fi/ksmato/")[#text("Kaisa Matomäki")]#text(", ")#link("http://www.its.caltech.edu/~maksym/")[#text("Maksym Radziwill")]#text(", ")#link("https://math.as.uky.edu/users/xsh228")[#text("Xuancheng Shao")]#text(", ")#link("https://sites.google.com/view/joniteravainen/")[#text("Joni Teräväinen")]#text(", and myself have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2106.03335")[#text("Singmaster’s conjecture in the interior of Pascal’s triangle")]#text("“. This paper leverages the theory of exponential sums over primes to make progress on a ")#link("https://en.wikipedia.org/wiki/Singmaster%27s_conjecture")[#text("well known conjecture of Singmaster")]#text(" which asserts that any natural number larger than ")#mi("{1}")#text(" appears at most a bounded number of times in Pascal’s triangle. That is to say, for any integer ")#mi("{t \\geq 2}")#text(", there are at most ")#mi("{O(1)}")#text(" solutions to the equation ")#metadata(none) <tao-08db7388d6ae05e03912>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\binom{n}{m} = t")]]

#text(" ")#text(" with ")#mi("{1 \\leq m < n}")#text(". Currently, the largest number of solutions that is known to be attainable is eight, with ")#mi("{t}")#text(" equal to")

#tao-aligned(keep: true)[


#tao-math("3003  & = \\binom{3003}{1} = \\binom{78}{2} = \\binom{15}{5} = \\binom{14}{6} = \\binom{14}{8} = \\binom{15}{10}", block: true)



#tao-math(" & = \\binom{78}{76} = \\binom{3003}{3002}.", block: true)
]

#text("Because of the symmetry ")#mi("{\\binom{n}{m} = \\binom{n}{n-m}}")#text(" of Pascal’s triangle it is natural to restrict attention to the left half ")#mi("{1 \\leq m \\leq n/2}")#text(" of the triangle.")

#text("Our main result settles this conjecture in the “interior” region of the triangle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Singmaster’s conjecture in the interior of the triangle)")]#text(" ")#metadata(none) <tao-0d6e4079e36703ebd37c>#text(" If ")#mi("{0 < \\varepsilon < 1}")#text(" and ")#mi("{t}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(", there are at most two solutions to ")#link(<tao-08db7388d6ae05e03912>)[#text("(1)")]#text(" in the region")

#metadata(none) <tao-748d8735530048af931c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\exp( \\log^{2/3+\\varepsilon} n ) \\leq m \\leq n/2")]]

#text("and hence at most four in the region")

#align(center)[#tao-fit-display[#mitex("\\exp( \\log^{2/3+\\varepsilon} n ) \\leq m \\leq n - \\exp( \\log^{2/3+\\varepsilon} n ).")]]

#text("Also, there is at most one solution in the region")

#align(center)[#tao-fit-display[#mitex("\\exp( \\log^{2/3+\\varepsilon} n ) \\leq m \\leq n/\\exp(\\log^{1-\\varepsilon} n ).")]]
]

#text("To verify Singmaster’s conjecture in full, it thus suffices in view of this result to verify the conjecture in the boundary region ")#metadata(none) <tao-50e021f7e58f6004350f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("2 \\leq m < \\exp(\\log^{2/3+\\varepsilon} n)")]]

#text(" ")#text(" (or equivalently ")#mi("{n - \\exp(\\log^{2/3+\\varepsilon} n) < m \\leq n}")#text("); we have deleted the ")#mi("{m=1}")#text(" case as it of course automatically supplies exactly one solution to ")#link(<tao-08db7388d6ae05e03912>)[#text("(1)")]#text(". It is in fact possible that for ")#mi("{t}")#text(" sufficiently large there are no further collisions ")#mi("{\\binom{n}{m} = \\binom{n^{\\prime}}{m^{\\prime}}=t}")#text(" for ")#mi("{(n,m), (n^{\\prime},m^{\\prime})}")#text(" in the region ")#link(<tao-50e021f7e58f6004350f>)[#text("(3)")]#text(", in which case there would never be more than eight solutions to ")#link(<tao-08db7388d6ae05e03912>)[#text("(1)")]#text(" for sufficiently large ")#mi("{t}")#text(". This is latter claim known for bounded values of ")#mi("{m,m^{\\prime}}")#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1689495")[#text("by Beukers, Shorey, and Tildeman")]#text(", with the main tool used being ")#link("https://en.wikipedia.org/wiki/Siegel%27s_theorem_on_integral_points")[#text("Siegel’s theorem on integral points")]#text(".")

#text("The upper bound of two here for the number of solutions in the region ")#link(<tao-748d8735530048af931c>)[#text("(2)")]#text(" is best possible, due to the infinite family of solutions to the equation ")#metadata(none) <tao-2c47e90be506ec56f4f8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\binom{n+1}{m+1} = \\binom{n}{m+2}")]]

#text(" ")#text(" coming from ")#mi("{n = F_{2j+2} F_{2j+3}-1}")#text(", ")#mi("{m = F_{2j} F_{2j+3}-1}")#text(" and ")#mi("{F_j}")#text(" is the ")#mi("{j^{th}}")#text(" Fibonacci number.")

#text("The appearance of the quantity ")#mi("{\\exp( \\log^{2/3+\\varepsilon} n )}")#text(" in Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(" may be familiar to readers that are acquainted with Vinogradov’s bounds on exponential sums, which ends up being the main new ingredient in our arguments. In principle this threshold could be lowered if we had stronger bounds on exponential sums.")

#text("To try to control solutions to ")#link(<tao-08db7388d6ae05e03912>)[#text("(1)")]#text(" we use a combination of “")#link("https://en.wikipedia.org/wiki/Archimedean_property")[#text("Archimedean")]#text("” and “non-Archimedean” approaches. In the “Archimedean” approach (following earlier ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2373115")[#text("work of Kane")]#text(" on this problem) we view ")#mi("{n,m}")#text(" primarily as real numbers rather than integers, and express ")#link(<tao-08db7388d6ae05e03912>)[#text("(1)")]#text(" in terms of the Gamma function as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\Gamma(n+1)}{\\Gamma(m+1) \\Gamma(n-m+1)} = t.")]]

#text("One can use this equation to solve for ")#mi("{n}")#text(" in terms of ")#mi("{m,t}")#text(" as")

#align(center)[#tao-fit-display[#mitex("n = f_t(m)")]]

#text("for a certain real analytic function ")#mi("{f_t}")#text(" whose asymptotics are easily computable (for instance one has the asymptotic ")#mi("{f_t(m) \\asymp m t^{1/m}}")#text("). One can then view the problem as one of trying to control the number of lattice points on the graph ")#mi("{\\{ (m,f_t(m)): m \\in {\\bf R} \\}}")#text(". Here we can take advantage of the fact that in the regime ")#mi("{m \\leq f_t(m)/2}")#text(" (which corresponds to working in the left half ")#mi("{m \\leq n/2}")#text(" of Pascal’s triangle), the function ")#mi("{f_t}")#text(" can be shown to be convex, but not too convex, in the sense that one has both upper and lower bounds on the second derivative of ")#mi("{f_t}")#text(" (in fact one can show that ")#mi("{f^{\\prime\\prime}_t(m) \\asymp f_t(m) (\\log t/m^2)^2}")#text("). This can be used to preclude the possibility of having a cluster of three or more nearby lattice points on the graph ")#mi("{\\{ (m,f_t(m)): m \\in {\\bf R} \\}}")#text(", basically because the area subtended by the triangle connecting three of these points would lie between ")#mi("{0}")#text(" and ")#mi("{1/2}")#text(", contradicting ")#link("https://en.wikipedia.org/wiki/Pick%27s_theorem")[#text("Pick’s theorem")]#text(". Developing these ideas, we were able to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2")]#text(" ")#metadata(none) <tao-b82099d75a2979b46a73>#text(" Let ")#mi("{\\varepsilon>0}")#text(", and suppose ")#mi("{t}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(". If ")#mi("{(m,n)}")#text(" is a solution to ")#link(<tao-08db7388d6ae05e03912>)[#text("(1)")]#text(" in the left half ")#mi("{m \\leq n/2}")#text(" of Pascal’s triangle, then there is at most one other solution ")#mi("{(m^{\\prime},n^{\\prime})}")#text(" to this equation in the left half with")

#align(center)[#tao-fit-display[#tao-math("\\left|m-m^{\\prime}\\right| + \\left|n-n^{\\prime}\\right| \\ll \\exp( (\\log\\log t)^{1-\\varepsilon} ).", block: true)]]
]

#text("Again, the example of ")#link(<tao-2c47e90be506ec56f4f8>)[#text("(4)")]#text(" shows that a cluster of two solutions is certainly possible; the convexity argument only kicks in once one has a cluster of three or more solutions.")

#text("To finish the proof of Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(", one has to show that any two solutions ")#mi("{(m,n), (m^{\\prime},n^{\\prime})}")#text(" to ")#link(<tao-08db7388d6ae05e03912>)[#text("(1)")]#text(" in the region of interest must be close enough for the above proposition to apply. Here we switch to the “non-Archimedean” approach, in which we look at the ")#link("https://en.wikipedia.org/wiki/P-adic_order")[#mi("{p}")#text("-adic valuations")]#text(" ")#mi("{\\nu_p( \\binom{n}{m} )}")#text(" of the binomial coefficients, defined as the number of times a prime ")#mi("{p}")#text(" divides ")#mi("{\\binom{n}{m}}")#text(". From the fundamental theorem of arithmetic, a collision")

#align(center)[#tao-fit-display[#mitex("\\binom{n}{m} = \\binom{n^{\\prime}}{m^{\\prime}}")]]

#text("between binomial coefficients occurs if and only if one has agreement of valuations")

#metadata(none) <tao-1e2a7776cbcf61a6ea4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\nu_p( \\binom{n}{m} ) = \\nu_p( \\binom{n^{\\prime}}{m^{\\prime}} ).")]]

#text("From the ")#link("https://en.wikipedia.org/wiki/Legendre%27s_formula")[#text("Legendre formula")]

#align(center)[#tao-fit-display[#mitex("\\nu_p(n!) = \\sum_{j=1}^\\infty \\lfloor \\frac{n}{p^j} \\rfloor")]]

#text("we can rewrite this latter identity ")#link(<tao-1e2a7776cbcf61a6ea4d>)[#text("(5)")]#text(" as")

#metadata(none) <tao-68dbf73d03d3a5107eda>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{j=1}^\\infty \\{ \\frac{m}{p^j} \\} + \\{ \\frac{n-m}{p^j} \\} - \\{ \\frac{n}{p^j} \\} = \\sum_{j=1}^\\infty \\{ \\frac{m^{\\prime}}{p^j} \\} + \\{ \\frac{n^{\\prime}-m^{\\prime}}{p^j} \\} - \\{ \\frac{n^{\\prime}}{p^j} \\},")]]

#text("where ")#mi("{\\{x\\} := x - \\lfloor x\\rfloor}")#text(" denotes the fractional part of ")#mi("{x}")#text(". (These sums are not truly infinite, because the summands vanish once ")#mi("{p^j}")#text(" is larger than ")#mi("{\\max(n,n^{\\prime})}")#text(".)")

#text("A key idea in our approach is to view this condition ")#link(<tao-68dbf73d03d3a5107eda>)[#text("(6)")]#text(" ")#emph[#text("statistically")]#text(", for instance by viewing ")#mi("{p}")#text(" as a prime drawn randomly from an interval such as ")#mi("{[P, P + P \\log^{-100} P]}")#text(" for some suitably chosen scale parameter ")#mi("{P}")#text(", so that the two sides of ")#link(<tao-68dbf73d03d3a5107eda>)[#text("(6)")]#text(" now become random variables. It then becomes advantageous to compare correlations between these two random variables and some additional test random variable. For instance, if ")#mi("{n}")#text(" and ")#mi("{n^{\\prime}}")#text(" are far apart from each other, then one would expect the left-hand side of ")#link(<tao-68dbf73d03d3a5107eda>)[#text("(6)")]#text(" to have a higher correlation with the fractional part ")#mi("{\\{ \\frac{n}{p}\\}}")#text(", since this term shows up in the summation on the left-hand side but not the right. Similarly if ")#mi("{m}")#text(" and ")#mi("{m^{\\prime}}")#text(" are far apart from each other (although there are some annoying cases one has to treat separately when there is some “unexpected commensurability”, for instance if ")#mi("{n^{\\prime}-m^{\\prime}}")#text(" is a rational multiple of ")#mi("{m}")#text(" where the rational has bounded numerator and denominator). In order to execute this strategy, it turns out (after some standard Fourier expansion) that one needs to get good control on exponential sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{P \\leq p \\leq P + P\\log^{-100} P} e( \\frac{N}{p} + \\frac{M}{p^j} )")]]

#text("for various choices of parameters ")#mi("{P, N, M, j}")#text(", where ")#mi("{e(\\theta) := e^{2\\pi i \\theta}}")#text(". Fortunately, the methods of Vinogradov (which more generally can handle sums such as ")#mi("{\\sum_{n \\in I} e(f(n))}")#text(" and ")#mi("{\\sum_{p \\in I} e(f(p))}")#text(" for various analytic functions ")#mi("{f}")#text(") can give useful bounds on such sums as long as ")#mi("{N}")#text(" and ")#mi("{M}")#text(" are not too large compared to ")#mi("{P}")#text("; more specifically, Vinogradov’s estimates are non-trivial in the regime ")#mi("{N,M \\ll \\exp( \\log^{3/2-\\varepsilon} P )}")#text(", and this ultimately leads to a distance bound")

#align(center)[#tao-fit-display[#mitex("m^{\\prime} - m \\ll_\\varepsilon \\exp( \\log^{2/3 +\\varepsilon}(n+n^{\\prime}) )")]]

#text("between any colliding pair ")#mi("{(n,m), (n^{\\prime},m^{\\prime})}")#text(" in the left half of Pascal’s triangle, as well as the variant bound")

#align(center)[#tao-fit-display[#mitex("n^{\\prime} - n \\ll_\\varepsilon \\exp( \\log^{2/3 +\\varepsilon}(n+n^{\\prime}) )")]]

#text("under the additional assumption")

#align(center)[#tao-fit-display[#mitex("m^{\\prime}, m \\geq \\exp( \\log^{2/3 +\\varepsilon}(n+n^{\\prime}) ).")]]

#text("Comparing these bounds with Proposition ")#link(<tao-b82099d75a2979b46a73>)[#text("2")]#text(" and using some basic estimates about the function ")#mi("{f_t}")#text(", we can conclude Theorem ")#link(<tao-0d6e4079e36703ebd37c>)[#text("1")]#text(".")

#text("A modification of the arguments also gives similar results for the equation ")#metadata(none) <tao-fc74de5b79d22c90b074>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("(n)_m = t")]]

#text(" ")#text(" where ")#mi("{(n)_m := n (n-1) \\dots (n-m+1)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Falling_and_rising_factorials")[#text("falling factorial")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" If ")#mi("{0 < \\varepsilon < 1}")#text(" and ")#mi("{t}")#text(" is sufficiently large depending on ")#mi("{\\varepsilon}")#text(", there are at most two solutions to ")#link(<tao-fc74de5b79d22c90b074>)[#text("(7)")]#text(" in the region")

#metadata(none) <tao-b0b5ce1a02ba8604d69d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\exp( \\log^{2/3+\\varepsilon} n ) \\leq m < n.")]]
]

#text("Again the upper bound of two is best possible, thanks to identities such as")

#align(center)[#tao-fit-display[#mitex("(a^2-a)_{a^2-2a} = (a^2-a-1)_{a^2-2a+1}.")]]

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22637e1725c3cb9b711ad85ac0378a867778aef3a26016879ce13d153edfc0d9-885970856acb059ec5c0c4b2761f2adab008a0e7e8a1b2a5353bc9dc19277cb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Verreault")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629583")[#strong[#text("William Verreault")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2021")])]

#text("What a coincidence, I was a coauthor on a paper that only recently appeared in Integers on Singmaster’s conjecture, called ”Repetitions of Multinomial Coefficients and a Generalization of Singmaster’s Conjecture”.")

#text("It is #A34 on Integers 2021 page: ")#link("http://math.colgate.edu/~integers/current.html")[#text("http://math.colgate.edu/~integers/current.html")]

#text("It’d be interesting to see how these ideas hold up in higher dimensions!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2021")])]

#text("Thanks for the reference! It does seem plausible that the methods will extend to multinomial equations such as ")#mi("\\binom{n}{m_1,m_2,m_3} = t")#text(" in the interior of the simplex ")#mi("\\{ (m_1,m_2,m_3,n): n = m_1 + m_2 + m_3 \\}")#text(". It is tempting for instance to work in the region ")#mi("m_1 \\leq m_2 \\leq m_3")#text(" and express ")#mi("n")#text(" as an analytic function ")#mi("n = f_t(m_1,m_2)")#text(" of ")#mi("m_1, m_2")#text(" for a given ")#mi("t")#text(". If one can establish some convexity bounds on this function ")#mi("f_t")#text(" then the Archimedean arguments should largely go through (though now clusters can have three solutions instead of two). The types of correlations we compute in the non-Archimedean arguments would also be computable in the multinomial case, but the case analysis is likely to be more complicated. Still one should be able to get some partial results at least in this case (optimistically one could hope for an upper bound of three solutions in the interior of the simplex when ")#mi("m_1 \\leq m_2 \\leq m_3")#text(", and thus at most ")#mi("3 \\times 3! = 18")#text(" solutions without the order restriction, but there may be technical issues preventing one from getting this far).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22637e1725c3cb9b711ad85ac0378a867778aef3a26016879ce13d153edfc0d9-885970856acb059ec5c0c4b2761f2adab008a0e7e8a1b2a5353bc9dc19277cb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Verreault")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629914")[#strong[#text("William Verreault")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2021")])]

#text("That sounds good, I’ll have to try to work it out!")

#text("Have you looked at whether one can improve these results (and possibly prove Singmaster’s conjecture) conditionally on other various conjectures (e.g. GRH to get better exponential sum estimates, bounds on gaps between primes to modify the regions where you work, possibly abc conjecture, etc.)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("This is briefly discussed in the footnote on page 2. The main thing that is needed in our arguments are estimates of the form")

#mi("\\displaystyle \\sum_{P \\leq p \\leq 2P} e( N/p ) = o( \\frac{P}{\\log P} )")

#text("for various large ")#mi("P,N")#text(" (this is roughly the same as asking that the fractional parts ")#mi("\\{N/p\\}")#text(" for prime ")#mi("p \\asymp P")#text(" are uniformly distributed). [Actually for technical reasons (involving the need to also control prime powers ")#mi("p^j")#text(") we work with a slightly shorter interval than ")#mi("[P,2P]")#text(" and need a slightly more general phase and slightly stronger error terms, but never mind these complications for now.] The estimates of Vinogradov basically let us get something like this as long as ")#mi("N \\ll \\exp( \\log^{3/2-\\varepsilon} P )")#text(", but pseudorandomness heuristics predict a much larger range of ")#mi("N")#text(" such as ")#mi("N \\ll \\exp(P^c)")#text(" for some ")#mi("c>0")#text(" (perhaps even ")#mi("c")#text(" arbitrarily close to 1), which would lead to widening the applicability of our results to something like ")#mi("\\log^C n \\leq m \\leq n - \\log^C n")#text(". In comparison, the Riemann hypothesis would (morally, at least) give results of the form")

#mi("\\displaystyle \\sum_{P \\leq p \\leq 2P} e( N \\log p ) = o( \\frac{P}{\\log P} )")

#text("for such a wide range of ")#mi("N")#text(", which certainly looks similar, but we could not obtain a direct connection between the two types of estimates.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d7b18f4bf51605ded3b4baf65a123d44fc0a113da9bcf6285370c61cb0f3b22-7de5a7582d7357cf880df6eb394c64b654d081910191a2025340df7bb1781be2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 思")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-633131")[#strong[#text("思")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2021")])]

#text("Hello,professor. I am a Chinese student about to enter freshman year. These days, I think about the “3N + 1” conjecture. I think I should prove it. I wonder if you could have a look. If you can, please reply me! esteem it a favor!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2021")])]

#text("Typo in the formula after (5): the sum should be over $P \\le p \\le P + P \\log^{-100} P$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629608")[#strong[#text("Simple unsolved math problem, 5 | Yet Another Mathblog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2021")]

#text("[…] Xuancheng Shao, Joni Teräväinen, and Terrance Tao solved the conjecture below recently (see T. Tao’s blog post with the link to the paper and a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2021")])]

#text("Is it possible to extend these results (beyond binomial coefficients) for a larger class of functions ")#mi("f(m, n)")#text(" (having certain regularity properties and sufficiently fast growth rate)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629663")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2021")])]

#text("Such hypotheses would suffice for the “Archimedean” parts of the argument, but for the “non-Archimedean” parts one needs to know information about the prime factorisation of ")#mi("f(m,n)")#text(". For instance, a basic property about the prime factorisation of ")#mi("\\binom{n}{m}")#text(" for ")#mi("1 \\leq m \\leq n/2")#text(" is that this binomial coefficient is divisible by every prime between ")#mi("n-m+1")#text(" and ")#mi("n")#text(", but not by any prime larger than ")#mi("n")#text(". This fact alone is already enough to establish non-collision ")#mi("\\binom{n}{m} \\neq \\binom{n^{\\prime}}{m^{\\prime}}")#text(" for a reasonable number of pairs ")#mi("(n,m), (n^{\\prime},m^{\\prime})")#text("; the argument we employ evolved from various attempts to try to generalise this type of argument (which already appears in an early work on this problem by Abbott, Erdos, and Hansen).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b020389eef2bc3690bde17366b40ce012901feebfc86f1729f17178ac842abdc-2a3c307e99cf70a450f660067124b98bac8efa9bb0ddce5f76efa04afeb27fed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2021")])]

#text("Non twin prime")

#text("After adding 1 and 3 to each natural number in the natural number set n, a pair of new numbers with 1 and 3 bits can be formed. If the pair of numbers are twin primes, the corresponding elements in the n set are put into the a set, otherwise they are put into the B set. For example, after adding the numbers 1 and 3 to the number “4” in the n set, two new numbers 41 and 43 are formed, which are a pair of twin prime numbers, then “4” is put into the a set.")

#text("For example, natural numbers within 10 can be divided into two categories as follows:")

#text("Class 1: there are four numbers, specifically 1, 4, 7 and 10. According to this rule, they should be put into a set,")

#text("Class 2: there are six numbers: 2, 3, 5, 6, 8, 9. According to this rule, they should be put into b set.")

#text("Obviously, a and B sets complement each other and refer to four pairs of twin primes, twin primes and six pairs of non twin primes with 1 and 3 in natural number 109 respectively.")

#text("Can we say that the elements in B set are “non twin primes” and complement of twin primes?")

#text("Here, we only study the twin prime numbers 11-13 and 41-43, which are 1 and 3.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629633")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2021")])]

#text("How can I read the inequalities if e.g. ")#mi("\\epsilon=\\frac{1}{3}")#text("? For Eq. (2) one gets ")#mi("n \\leq m \\leq \\frac{n}{2}")#text(" which is…weird.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aunonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629659")[#strong[#text("Aunonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2021")])]

#text("I mean, what he said is true. The interval is just empty.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629670")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2021")])]

#text("Maksym’s webpage is mis-linked.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629679")[#strong[#text("Singmaster and Pascal – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2021")]

#text("[…] Kaisa Matomäki, Maksym Radziwill, Xuancheng Shao, Joni Teräväinen, and myself have just uploaded to the arXiv our preprint “Singmaster’s conjecture in the interior of Pascal’s triangle“. This paper leverages the theory of exponential sums over primes to make progress on a well known conjecture of Singmaster which asserts that any natural number larger than {1} appears at most a bounded number of times in Pascal’s triangle. … (Terry Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629695")[#strong[#text("Singmaster’s conjecture – SPP 2026")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2021")]

#text("[…] learned about this conjecture by a blog post of Terence Tao on his own blog. There he reported on recent progress on this conjecture […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine Deleforge")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629707")[#strong[#text("Antoine Deleforge")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2021")])]

#text("Really nice work! I noticed one small inconsistency between the elementary examples in your paper and the ones given on the Wikipedia page on Singmaster’s conjecture (")#link("https://en.wikipedia.org/wiki/Singmaster%27s_conjecture")[#text("https://en.wikipedia.org/wiki/Singmaster%27s_conjecture")]#text("): you give (52, 22, 3) while the wikipedia page seems to give (56, 22, 3). Do you know which one is correct?")

#emph[#text("[Thanks for locating this typo; it will be corrected in the next version of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2021")])]

#text("It is not clear from the statement of the conjecture (both here and in the arXiv paper) if the number of solutions to (1) is dependent on ")#mi("t")#text(" (i.e. ")#mi("O_t(1)")#text(") or is uniformly bounded wrt ")#mi("t")#text(".")

#emph[#text("[Uniformly bounded in ")#mi("t")#text(", otherwise we would have used ")#mi("O_t(1)")#text(" as in Section 1.5 of the paper. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d92e6d2f406fd5549c6badab69cba5f40fcdc60dc338f3626950264f6aae3c6-0ddcc3018318c497ab03477866894285248d990a285fcce31ce7c6b569bc7e2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629835")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2021")])]

#text("The upper bound of two here for the number of solutions in the region (8)")#linebreak()#text(" should be changed to")#linebreak()#text(" The upper bound of two here for the number of solutions in the region (2)")#linebreak()#text(" perhaps?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/004e8635b32280ae0ae934c93cde527d9fe232da84d7f11e282d3b5f6855200f-9413a8a6e48b60b20f5c34d4bd14ffee77b6afa6cdb14782384373494dd4b965.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629840")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2021")])]

#text("I don’t believe any random ways,")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629921")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2021")])]

#text("The part of the argument where a set of integer points on a real-analytic subvariety (in this case three points on a curve) can’t cluster together too closely because the area of the simplex they determine would be too small (but also nonzero) feels reminiscent of the work of Bombieri and Pila, which also gives bounds for the number of integer points on a curve with bounded coordinates, those bounds being uniform in the curve in the same way your bounds are uniform in t. Did you have this stuff in mind and do you think there’s any relation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629946")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2021")])]

#text("Nice observation! We were not directly inspired by the Bombieri–Pila determinant method (the argument we use comes instead from a paper of Kane) but now that you mention it, there is definitely a similarity that we will mention in the next revision of the ms.")

#text("This does raise the possibility though that it might be possible to use the determinant method (in either the Archimedean or non-Archimedean form) to improve the upper bound for the total number of solutions to ")#mi("\\binom{n}{m} = t")#text("; the best bound currently is ")#mi("O( \\log t \\log\\log\\log t / (\\log\\log t)^3)")#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2373115")[#text("due to Kane")]#text(", and relying primarily on derivative estimates for this real-analytic curve. There the problem comes more from the edge of Pascal’s triangle than the interior, and I don’t think the rest of the methods in our paper are directly useful for this problem, but perhaps it is something for an expert in the determinant method to take a look at. (The key difficulty would be to get good quantitative estimates on the number of intersection points between the solution set ")#mi("\\{ (n,m) \\in {\\bf N}: \\binom{n}{m} = t \\}")#text(" and an algebraic curve of a given degree.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-629922")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/06/16/singmasters-conjecture-in-the-interior-of-pascals-triangle/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/143c544571e80a3cf438085cc22cdd6ee5f18e956de7a0f03326247396a9c295-1cd0848b805096874077c387ff9b4ebbbdb0dd350cf3e18158aef72a34e6a0b1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of duck_master")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630036")[#strong[#text("duck_master")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2021")])]

#text("In retrospect, the idea of comparing the valuations for a *random* prime number is extremely clever. (I had thought about comparing valuations before; however, I initially tried studying ")#mi("p = 2, 3, 5")#text(", but I gave up because this has to do with base-2, base-3, base-5, etc. expansions, and these don’t generally relate simply to each other.)")

#text("Also, to simplify the proof: you could sample your choice of ")#mi("p")#text(" for the application of valuation-comparison with probability ")#mi("\\propto\\Lambda(p)")#text(". On the “back-end” (the actual computation of the correlations), this gets rid of the now-unnecessary summation-by-parts on (in the latest version as of the time of writing) the top of page 22, which serves as the transition from naïve uniform sampling to my proposed version of sampling; on the “front-end” (the application of the correlations to restricting solutions of ")#mi("\\binom{n}{m} = \\binom{n^{\\prime}}{m^{\\prime}} = t")#text("), this is perfectly okay because the failure probability of the identity is at most ")#mi("\\approx\\frac{\\log P}{P}")#text(" and the difference of the two sides in cases of failure is at most ")#mi("\\approx\\log P")#text(" anyways, which introduces a perfectly-manageable error term of ")#mi("\\approx\\frac{\\log^2 P}{P}")#text(" for the correlation equation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630323")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")])]

#text("Yes, these two sampling methods are basically equivalent and which one to use is mostly a matter of personal preference. The weighting ")#mi("\\Lambda")#text(" is often more convenient in proving the estimates, but the naive weighting involving primes drawn at random is conceptually simpler and is often the formulation used in describing many theorems or conjectures about the primes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22637e1725c3cb9b711ad85ac0378a867778aef3a26016879ce13d153edfc0d9-885970856acb059ec5c0c4b2761f2adab008a0e7e8a1b2a5353bc9dc19277cb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Verreault")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630251")[#strong[#text("William Verreault")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2021")])]

#text("I would like to know where your motivation to work on Singmaster’s conjecture came from since it is not as well-known as other conjectures. Did it come from your co-authors? If so, what was their motivation to look at Singmaster’s conjecture? Were you motivated by something else first?")

#text("I know you said in another comment that these arguments evolved from trying to generalize arguments that use the prime factorization of ")#mi("\\binom{n}{m}")#text(", but did you find Kane’s ”archimedean” approach first and then figured out a way to improve the proof with non-archimedean arguments?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630326")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")])]

#text("The five of us are working on a related project involving exponential sums over primes that we hope to finalise soon. At one point in that project, one of us realised a possible connection of our work to Singmaster’s conjecture, although it turned out in the end that we were able to get our results using just the standard Vinogradov estimates on exponential sums on primes rather than the ones we have been working on.")

#text("The connection between equidistribution properties over primes (or equivalently, exponential sums over primes) and Singmaster started with the basic observation that when ")#mi("1 \\leq m \\leq n/2")#text(", the binomial coefficient ")#mi("\\binom{n}{m}")#text(" is divisible by every prime between ")#mi("n-m+1")#text(" and ")#mi("n")#text(", but not divisible by any prime larger than ")#mi("n")#text(". This is already enough to get decent results in the regime ")#mi("\\varepsilon n \\leq m \\leq n/2")#text(" (and was already exploited in an old paper of Abbott, Erdos, and Hansen), though for much smaller values of ")#mi("m")#text(" this is less useful as the interval ")#mi("[n-m+1,n]")#text(" is too short to provably contain primes. Our starting point was then the heuristic variant of the above observation (say in the region ")#mi("n^{1/2+\\varepsilon} \\leq m \\leq n/2")#text(" to avoid dealing with contributions of powers of primes) that ")#mi("\\binom{n}{m}")#text(" tended to be divisible by most primes in ")#mi("[m,(1+\\varepsilon) m]")#text(" but very few primes in ")#mi("[(1-\\varepsilon) m,m]")#text(", and this could be used to separate ")#mi("\\binom{n}{m}")#text(" from ")#mi("\\binom{n^{\\prime}}{m^{\\prime}}")#text(", for instance if ")#mi("(1+\\varepsilon/2)m \\leq m^{\\prime} \\leq (1+\\varepsilon)m")#text(". This idea then went through several iterations and refinements (for instance we mostly started with first moment estimates on fractional parts ")#mi("\\{ \\frac{n}{p}\\}, \\{ \\frac{m}{p}\\}")#text(" and only later realised the utility of second moment estimates, i.e., correlation estimates) until reaching the current form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/618cf1f04f8a18eecb1f10f266821e7393feeb97598d32289f48ad8030cb9938-cfc0ce0b3d592e30da34d56ba5b8e4e05f67604304a8cea7731d51a12818b5ce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630348")[#strong[#text("Richard")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")])]

#text("Thanks for both this comment and your reponse. It’s so interesting to glimpse insights into these (partial? Partial? PARTIAL? More than I could ever dream of!) results are realised, and how collaborations alight on them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22637e1725c3cb9b711ad85ac0378a867778aef3a26016879ce13d153edfc0d9-885970856acb059ec5c0c4b2761f2adab008a0e7e8a1b2a5353bc9dc19277cb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Verreault")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630508")[#strong[#text("William Verreault")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2021")])]

#text("Thank you for the very detailed answer. It is always nice to have insight into where these new ideas come from!")

#text("This basic observation on the divisibility of ")#mi("\\binom{n}{m}")#text(" makes me think that these new techniques can’t help when considering the similar question on solutions to n!m!=t (as studied by Kane using the same Archimedean arguments in ”On the number of ways of writing t as a product of factorials”). Is that right?")

#text("To be more precise, he proved that the ")#mi("\\limsup_{t\\to\\infty}")#text(" of the number of solutions to the previous equation is 6, but conjectured it is the maximum, and I would find it interesting to see if this can be improved using your ideas (whether by obtaining effective bounds on ”large values of t” that could help numerically verify this conjecture or by obtaining similar results for n_1!…n_k!=t).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2021")])]

#text("For the equation ")#mi("n! m! = t")#text(" studied by Kane, as well as the similar equation ")#mi("n!/m! = t")#text(" studied in the last section of our paper, it seems the ")#mi("2")#text("-valuation ")#mi("\\nu_2")#text(" already gives quite a lot of information; for ")#mi("n!/m! = t")#text(" we experimented with working with more general ")#mi("p")#text("-valuations ")#mi("\\nu_p")#text(" as we did for ")#mi("\\binom{n}{m} = t")#text(", but the information we could extract from the other valuations was not as strong as what one could already get using ")#mi("\\nu_2")#text(". Similarly, in Kane’s paper it seems the ")#mi("2")#text("-valuation already pinpoints ")#mi("n+m")#text(" to an accuracy of ")#mi("O(\\log\\log t)")#text(", which looks much better than what one could hope to accomplish through other valuations.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cc7c56e6d34fb1da2e9a2b3ca3b7c416d0cd7ebf18519295ed3085193a1a2af9-c2ba8b8ab6312bf32e2b0e0d7e3f3e77fbdd90afa63ad2608f4ad6f49268da5d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Healthy Social Media, Secrets of Pascal’s Triangle and Venus’ Tectonics – Phil Beaudoin")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630751")[#strong[#text("Healthy Social Media, Secrets of Pascal’s Triangle and Venus’ Tectonics – Phil Beaudoin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2021")])]

#text("[…] “ I have no idea which number it is, but it probably appears infinitely many times. ” Well, thanks to Terrence Tao and Waverly, I learned this week about the Singmaster’s conjecture which says that no number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a403a1c399719bb8b9fab73031e0601a19ef10b902ccc0cf09677672880163c4-175ecd054c7acc50664bea49f6f77b0d0af2e5646980109e263ce457e3b769c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Glenn Wouda")]], [#link("https://terrytao.wordpress.com/2021/06/07/singmasters-conjecture-in-the-interior-of-pascals-triangle/#comment-630869")[#strong[#text("Glenn Wouda")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2021")])]

#text("Dear professor Tao, I am trying to get to the errata for your book “Analysis I (third edition)” but the page ")#link("https://terrytao.wordpress.com/books/analysis-i/")[#text("https://terrytao.wordpress.com/books/analysis-i/")]#text(" freezes and there is a pop-up saying that the the page is waiting to load.")

#text("I have tried on several occasions and also with several different browsers but the problem persists.")

#text("Having the errata available would help me a lot while reading and studying your book.")

#text("Thanks in advance")

#emph[#text("[I have changed the comment settings to only display the most recent 50 comments, which seems to alleviate this loading issue -T.]")]
]
