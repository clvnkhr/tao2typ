// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/
// Converted to Typst by tao2typ: "2026-10-14T15:18:21.190361+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 4: The Bourgain-Gamburd expansion machine", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 4: The Bourgain-Gamburd expansion machine")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 January 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")[#text("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We have now seen two ways to construct expander Cayley graphs ")#mi("{Cay(G,S)}")#text(". The first, discussed in ")#link("https://terrytao.wordpress.com/2011/12/06/254b-notes-2-cayley-graphs-and-kazhdans-property-t/")[#text("Notes 2")]#text(", is to use Cayley graphs that are projections of an infinite Cayley graph on a group with Kazhdan’s property (T). The second, discussed in ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("Notes 3")]#text(", is to combine a quasirandomness property of the group ")#mi("{G}")#text(" with a flattening hypothesis for the random walk.")

#text("We now pursue the second approach more thoroughly. The main difficulty here is to figure out how to ensure flattening of the random walk, as it is then an easy matter to use quasirandomness to show that the random walk becomes mixing soon after it becomes flat. In the case of Selberg’s theorem, we achieved this through an explicit formula for the heat kernel on the hyperbolic plane (which is a proxy for the random walk). However, in most situations such an explicit formula is not available, and one must develop some other tool for forcing flattening, and specifically an estimate of the form ")#metadata(none) <tao-55515f3b299c6a2be09d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\mu^{(n)} \\right\\|_{\\ell^2(G)} \\ll \\left|G\\right|^{-1/2+\\epsilon}", block: true)]]

#text("for some ")#tao-math("{n = O(\\log \\left|G\\right|)}", block: false)#text(", where ")#mi("{\\mu}")#text(" is the uniform probability measure on the generating set ")#mi("{S}")#text(".")

#text("In 2006, ")#link("http://www.ams.org/mathscinet-getitem?mr=2227746")[#text("Bourgain and Gamburd")]#text(" introduced a general method for achieving this goal. The intuition here is that the main obstruction that prevents a random walk from spreading out to become flat over the entire group ")#mi("{G}")#text(" is if the random walk gets ")#emph[#text("trapped")]#text(" in some proper subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" (or perhaps in some coset ")#mi("{xH}")#text(" of such a subgroup), so that ")#mi("{\\mu^{(n)}(xH)}")#text(" remains large for some moderately large ")#mi("{n}")#text(". Note that")

#align(center)[#tao-fit-display[#mitex("\\mu^{(2n)}(H) \\geq \\mu^{(n)}(H x^{-1}) \\mu^{(n)}(xH) = \\mu^{(n)}(xH)^2,")]]

#text("since ")#mi("{\\mu^{(2n)} = \\mu^{(n)} * \\mu^{(n)}}")#text(", ")#mi("{H = (H x^{-1}) \\cdot (xH)}")#text(", and ")#mi("{\\mu^{(n)}}")#text(" is symmetric. By iterating this observation, we seethat if ")#mi("{\\mu^{(n)}(xH)}")#text(" is too large (e.g. of size ")#tao-math("{\\left|G\\right|^{-o(1)}}", block: false)#text(" for some ")#mi("{n}")#text(" comparable to ")#tao-math("{\\log \\left|G\\right|}", block: false)#text("), then it is not possible for the random walk ")#mi("{\\mu^{(n)}}")#text(" to converge to the uniform distribution in time ")#tao-math("{O(\\log \\left|G\\right|)}", block: false)#text(", and so expansion does not occur.")

#text("A potentially more general obstruction of this type would be if the random walk gets trapped in (a coset of) an ")#emph[#text("approximate")]#text(" group ")#mi("{H}")#text(". Recall that a ")#emph[#mi("{K}")#text("-approximate group")]#text(" is a subset ")#mi("{H}")#text(" of a group ")#mi("{G}")#text(" which is symmetric, contains the identity, and is such that ")#mi("{H \\cdot H}")#text(" can be covered by at most ")#mi("{K}")#text(" left-translates (or equivalently, right-translates) of ")#mi("{H}")#text(". Such approximate groups were studied extensively in last quarter’s course. A similar argument to the one given previously shows (roughly speaking) that expansion cannot occur if ")#mi("{\\mu^{(n)}(xH)}")#text(" is too large for some coset ")#mi("{xH}")#text(" of an approximate group.")

#text("It turns out that this latter observation has a converse: if a measure does not concentrate in cosets of approximate groups, then some flattening occurs. More precisely, one has the following combinatorial lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Weighted Balog-Szemerédi-Gowers lemma)")]#text(" ")#metadata(none) <tao-c22051c3f481b4bd916b>#text(" Let ")#mi("{G}")#text(" be a group, let ")#mi("{\\nu}")#text(" be a finitely supported probability measure on ")#mi("{G}")#text(" which is symmetric (thus ")#mi("{\\nu(g)=\\nu(g^{-1})}")#text(" for all ")#mi("{g \\in G}")#text("), and let ")#mi("{K \\geq 1}")#text(". Then one of the following statements hold:")

#list(
[#text("(i) (Flattening) One has ")#tao-math("{\\left\\| \\nu * \\nu \\right\\|_{\\ell^2(G)} \\leq \\frac{1}{K} \\left\\|\\nu\\right\\|_{\\ell^2(G)}}", block: false)#text(".")],
[#text("(ii) (Concentration in an approximate group) There exists an ")#mi("{O(K^{O(1)})}")#text("-approximate group ")#mi("{H}")#text(" in ")#mi("{G}")#text(" with ")#tao-math("{\\left|H\\right| \\ll K^{O(1)} / \\left\\| \\nu \\right\\|_{\\ell^2(G)}^2}", block: false)#text(" and an element ")#mi("{x \\in G}")#text(" such that ")#mi("{\\nu(xH) \\gg K^{-O(1)}}")#text(".")]
)
]

#text("This lemma is a variant of the more well-known ")#emph[#text("Balog-Szemerédi-Gowers lemma")]#text(" in additive combinatorics ")#link("http://www.ams.org/mathscinet-getitem?mr=1631259")[#text("due to Gowers")]#text(" (which roughly speaking corresponds to the case when ")#mi("{\\mu}")#text(" is the uniform distribution on some set ")#mi("{A}")#text("), which in turn is a polynomially quantitative version of an earlier lemma of ")#link("http://www.ams.org/mathscinet-getitem?mr=1305895")[#text("Balog and Szemerédi")]#text(". We will prove it below the fold.")

#text("The lemma is particularly useful when the group ")#mi("{G}")#text(" in question enjoys a ")#emph[#text("product theorem")]#text(", which roughly speaking says that the only medium-sized approximate subgroups of ")#mi("{G}")#text(" are trapped inside genuine proper subgroups of ")#mi("{G}")#text(" (or, contrapositively, medium-sized sets that generate the entire group ")#mi("{G}")#text(" cannot be approximate groups). The fact that some finite groups (and specifically, the bounded rank finite simple groups of Lie type) enjoy product theorems is a non-trivial fact, and will be discussed in later notes. For now, we simply observe that the presence of the product theorem, together with quasirandomness and a non-concentration hypothesis, can be used to demonstrate expansion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Bourgain-Gamburd expansion machine)")]#text(" ")#metadata(none) <tao-91239da3b902ad5edfdd>#text(" Suppose that ")#mi("{G}")#text(" is a finite group, that ")#mi("{S \\subseteq G}")#text(" is a symmetric set of ")#mi("{k}")#text(" generators, and that there are constants ")#mi("{0 < \\kappa < 1 < \\Lambda}")#text(" with the following properties.")

#enum(start: 1, 
[#text("(Quasirandomness). The smallest dimension of a nontrivial representation ")#mi("{\\rho: G \\rightarrow GL_d({\\bf C})}")#text(" of ")#mi("{G}")#text(" is at least ")#tao-math("{\\left|G\\right|^{\\kappa}}", block: false)#text(";")],
[#text("(Product theorem). For all ")#mi("{\\delta > 0}")#text(" there is some ")#mi("{\\delta^{\\prime} = \\delta^{\\prime}(\\delta) > 0}")#text(" such that the following is true. If ")#mi("{H \\subseteq G}")#text(" is a ")#tao-math("{\\left|G\\right|^{\\delta^{\\prime}}}", block: false)#text("-approximate subgroup with ")#tao-math("{\\left|G\\right|^{\\delta} \\leq \\left|H\\right| \\leq \\left|G\\right|^{1 - \\delta}}", block: false)#text(" then ")#mi("{H}")#text(" generates a proper subgroup of ")#mi("{G}")#text(";")],
[#text("(Non-concentration estimate). There is some even number ")#tao-math("{n \\leq \\Lambda\\log \\left|G\\right|}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sup_{H < G}\\mu^{(n)}(H) < \\left|G\\right|^{-\\kappa},", block: true)]]

#text("where the supremum is over all proper subgroups ")#mi("{H < G}")#text(".")]
)

#text("Then ")#mi("{Cay(G,S)}")#text(" is a two-sided ")#mi("{\\epsilon}")#text("-expander for some ")#mi("{\\epsilon > 0}")#text(" depending only on ")#mi("{k,\\kappa, \\Lambda}")#text(", and the function ")#mi("{\\delta^{\\prime}(\\cdot )}")#text(" (and this constant ")#mi("{\\epsilon}")#text(" is in principle computable in terms of these constants).")
]

#text("This criterion for expansion is implicitly contained in ")#link("http://www.ams.org/mathscinet-getitem?mr=2415383")[#text("this paper of Bourgain and Gamburd")]#text(", who used it to establish the expansion of various Cayley graphs in ")#mi("{SL_2(F_p)}")#text(" for prime ")#mi("{p}")#text(". This criterion has since been applied (or modified) to obtain expansion results in many other groups, as will be discussed in later notes.")

#metadata(none) <tao-e28f555c1ce14bf55576>

#heading(level: 1)[#strong[#text(" — 1. The Balog-Szemerédi-Gowers lemma — ")]]

#text("The Balog-Szemerédi-Gowers lemma (Lemma ")#link(<tao-c22051c3f481b4bd916b>)[#text("1")]#text(") is ostensibly a statement about group structure, but the main tool in its proof is a remarkable graph-theoretic lemma (also known as the Balog-Szemerédi-Gowers lemma) that allows one to upgrade a “statistical” structure (a structure which is only valid a small fraction of the time, say 1% of the time) to a “complete” structure (one which is valid 100% of the time), by shrinking the size of the structure slightly (and in particular, with losses of polynomial type, as opposed to exponential or worse). This is in contrast to other structure-improving results (such as ")#link("http://en.wikipedia.org/wiki/Ramsey's_theorem")[#text("Ramsey’s theorem")]#text(", ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("Szemerédi’s theorem")]#text(", or ")#link("http://en.wikipedia.org/wiki/Freiman's_theorem")[#text("Freiman’s theorem")]#text("), which are qualitatively similar in spirit, but have much worse quantitative bounds (though ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("there is some hope")]#text(" in the case of Freiman’s theorem to only lose polynomial bounds with some improvement of existing arguments).")

#text("As we shall see later, the property of ")#tao-math("{\\left\\|\\nu*\\nu\\right\\|_{\\ell^2(G)}}", block: false)#text(" being large is a statistical assertion about ")#mi("{\\nu}")#text(" (it asserts that ")#mi("{\\nu*\\nu}")#text(" collides with itself somewhat often), whereas approximate groups ")#mi("{H}")#text(" represent a more complete sort of structure (")#emph[#text("all")]#text(" products of ")#mi("{H \\cdot H}")#text(" are trapped in a small set, whereas only ")#emph[#text("many")]#text(" of the products in ")#mi("{\\nu * \\nu}")#text(" are so constrained). The graph-theoretic Balog-Szemerédi lemma is the key to moving from the former type of structure to the latter with only polynomial losses.")

#text("We need some notation. Define a ")#emph[#text("bipartite graph")]#text(" ")#mi("{G = G(A,B,E)}")#text(" to be a graph whose vertex set ")#mi("{V := A \\cup B}")#text(" is partitioned into two non-empty sets ")#mi("{A, B}")#text(", and the edge set ")#mi("{E}")#text(" consists only of edges between ")#mi("{A}")#text(" and ")#mi("{B}")#text(". If a finite bipartite graph ")#mi("{G = G(A,B,E)}")#text(" is ")#emph[#text("dense")]#text(" in the sense that its edge density ")#tao-math("{\\left|E\\right|/\\left|A\\right|\\left|B\\right|}", block: false)#text(" is large, then for many vertices ")#mi("{a \\in A}")#text(" and ")#mi("{b \\in B}")#text(", ")#mi("{a}")#text(" and ")#mi("{b}")#text(" are connected by a path of length one (i.e. an edge). It is thus intuitive that many pairs of vertices ")#mi("{a \\in A}")#text(" and ")#mi("{a^{\\prime} \\in A}")#text(" will be connected by many paths of length two. Perhaps surprisingly, one can upgrade “many pairs” here to “almost all pairs”, provided that one is willing to shrink the set ")#mi("{A}")#text(" slightly. More precisely, one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Balog-Szemerédi-Gowers lemma: paths of length two)")]#text(" ")#metadata(none) <tao-2c38b22f1197f330c40a>#text(" Let ")#mi("{G(A,B,E)}")#text(" be a finite bipartite graph with ")#tao-math("{\\left|E\\right| \\geq \\left|A\\right| \\left|B\\right| / K}", block: false)#text(". Let ")#mi("{\\epsilon > 0}")#text(". Then there exists a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" with ")#tao-math("{\\left|A^{\\prime}\\right| \\geq \\frac{\\left|A\\right|}{\\sqrt{2} K}}", block: false)#text(" such that at least ")#tao-math("{(1-\\epsilon)\\left|A^{\\prime}\\right|^2}", block: false)#text(" of the pairs ")#mi("{(a,a^{\\prime}) \\in A^{\\prime} \\times A^{\\prime}}")#text(" are such that ")#mi("{a,a^{\\prime}}")#text(" are connected by at least ")#tao-math("{\\frac{\\epsilon}{2K^2} \\left|B\\right|}", block: false)#text(" paths of length two (i.e. there exists at least ")#tao-math("{\\frac{\\epsilon}{2K^2} \\left|B\\right|}", block: false)#text(" vertices ")#mi("{b \\in B}")#text(" such that ")#mi("{\\{a,b\\}, \\{a^{\\prime},b\\}}")#text(" both lie in ")#mi("{E}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" It is not possible to remove the ")#mi("{\\epsilon}")#text(" entirely from this lemma; see Exercise 6.4.2 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2289012")[#text("my book with Van Vu")]#text(" for a counterexample (involving Hamming balls).")
]

#emph[#text("Proof:")]#text(" The idea here is to use a probabilistic construction, picking ")#mi("{A^{\\prime}}")#text(" to be a neighbourhood of a randomly selected element ")#mi("{b}")#text(" of ")#mi("{B}")#text(". The rationale here is that if a pair ")#mi("{a,a^{\\prime}}")#text(" of vertices in ")#mi("{A}")#text(" are not connected by many paths of length two, then they are unlikely to lie in the same neighbourhood, and so are unlikely to “wreck” the construction.")

#text("We turn to the details. Let ")#mi("{b \\in B}")#text(" be chosen uniformly at random, and let ")#mi("{A^{\\prime} := \\{ a \\in A: (a,b) \\in E \\}}")#text(" be the neighbourhood of ")#mi("{b}")#text(". Observe that the expected size of ")#mi("{A^{\\prime}}")#text(" is")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|A^{\\prime}\\right| = \\frac{1}{\\left|B\\right|} \\left|E\\right| \\geq \\frac{\\left|A\\right|}{K}.", block: true)]]

#text("By Cauchy-Schwarz, we conclude in particular that ")#metadata(none) <tao-7e24b1711480f0c2c73a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\bf E} \\left|A^{\\prime}\\right|^2 \\geq \\frac{\\left|A\\right|^2}{K^2}.", block: true)]]

#text("Now, call a pair ")#mi("{(a,a^{\\prime})}")#text(" ")#emph[#text("bad")]#text(" if it is connected by fewer than ")#tao-math("{\\frac{\\epsilon \\left|B\\right|}{2K^2}}", block: false)#text(" paths of length two, and let ")#mi("{N}")#text(" be the number of bad pairs ")#mi("{(a,a^{\\prime})}")#text(" in ")#mi("{A^{\\prime} \\times A^{\\prime}}")#text(". We consider the quantity ")#mi("{{\\bf E} N}")#text(". Observe that if ")#mi("{(a,a^{\\prime})}")#text(" is a bad pair in ")#mi("{A \\times A}")#text(", then there are at most ")#tao-math("{\\frac{\\epsilon \\left|B\\right|}{2K^2}}", block: false)#text(" values of ")#mi("{b}")#text(" for which ")#mi("{a}")#text(" and ")#mi("{a^{\\prime}}")#text(" will both lie in ")#mi("{A^{\\prime}}")#text(", and so this bad pair contributes at most ")#mi("{\\frac{\\epsilon}{2K^2}}")#text(" to the expectation. Since there are at most ")#tao-math("{\\left|A\\right|^2}", block: false)#text(" bad pairs, we conclude that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} N \\leq \\frac{\\epsilon \\left|A\\right|^2}{2K^2}.", block: true)]]

#text("Combining this with ")#link(<tao-7e24b1711480f0c2c73a>)[#text("(2)")]#text(", we see that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|A^{\\prime}\\right|^2 - \\frac{N}{\\epsilon} - \\frac{\\left|A\\right|^2}{2K^2} \\geq 0.", block: true)]]

#text("In particular, there exists a choice of ")#mi("{b}")#text(" for which the expression on the left-hand side is non-negative. This implies that")

#align(center)[#tao-fit-display[#tao-math("N \\leq \\epsilon \\left|A^{\\prime}\\right|^2", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime}\\right|^2 \\geq \\frac{\\left|A\\right|^2}{2K^2}", block: true)]]

#text("and the claim follows. ")#mi("\\Box")

#text("Given that almost all pairs ")#mi("{a,a^{\\prime}}")#text(" in ")#mi("{A^{\\prime}}")#text(" are joined by many paths of length two, it is then plausible that almost all pairs ")#mi("{a \\in A^{\\prime}}")#text(", ")#mi("{b \\in B^{\\prime}}")#text(" are joined by many paths of length three, for some large subset ")#mi("{B^{\\prime}}")#text(" of ")#mi("{B}")#text(". Remarkably, one can now upgrade “almost all” pairs here to ")#emph[#text("all")]#text(" pairs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (Balog-Szemerédi-Gowers lemma: paths of length three)")]#text(" ")#metadata(none) <tao-928b07a1ebe453db4aab>#text(" Let ")#mi("{G(A,B,E)}")#text(" be a finite bipartite graph with ")#tao-math("{\\left|E\\right| \\geq \\left|A\\right| \\left|B\\right| / K}", block: false)#text(". Then there exists subsets ")#mi("{A^{\\prime}, B^{\\prime}}")#text(" of ")#mi("{A, B}")#text(" respectively with ")#tao-math("{\\left|A^{\\prime}\\right| \\gg K^{-O(1)} \\left|A\\right|}", block: false)#text(" and ")#tao-math("{\\left|B^{\\prime}\\right| \\gg K^{-O(1)} \\left|B\\right|}", block: false)#text(", such that for every ")#mi("{a \\in A}")#text(" and ")#mi("{b \\in B}")#text(", ")#mi("{a}")#text(" and ")#mi("{b}")#text(" are joined by ")#tao-math("{\\gg K^{-O(1)} \\left|A\\right| \\left|B\\right|}", block: false)#text(" paths of length three.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" A lemma similar to this was first established ")#link("http://www.ams.org/mathscinet-getitem?mr=1305895")[#text("by Balog and Szemerédi")]#text(", as a consequence of the ")#link("http://en.wikipedia.org/wiki/Szemer%C3%A9di_regularity_lemma")[#text("Szemereédi regularity lemma")]#text(". However, as a consequence of using that lemma, the polynomial bounds ")#mi("{K^{-O(1)}}")#text(" in the above lemma had to be replaced by much worse bounds (of tower-exponential type in ")#mi("{K}")#text("), which turns out to be far too weak for the purposes of establishing expansion.")
]

#emph[#text("Proof:")]#text(" The idea is to first prune a few “unpopular” vertices from ")#mi("{A}")#text(" and ")#mi("{B}")#text(" and then apply the preceding lemma.")

#text("Let ")#mi("{A_1}")#text(" be the vertices in ")#mi("{A}")#text(" of degree at least ")#tao-math("{\\left|B\\right|/2K}", block: false)#text(", and let ")#mi("{E_1}")#text(" be the edges connecting ")#mi("{A_1}")#text(" and ")#mi("{B}")#text(". Note that the vertices in ")#mi("{A \\backslash A_1}")#text(" are connected to a total of at most ")#tao-math("{\\left|A\\right| \\left|B\\right|/2K}", block: false)#text(" edges, and so ")#tao-math("{\\left|E_1\\right| \\geq \\left|A\\right| \\left|B\\right|/2K \\geq \\left|A_1\\right| \\left|B\\right|/2K}", block: false)#text(". Since ")#tao-math("{\\left|E_1\\right| \\leq \\left|A_1\\right| \\left|B\\right|}", block: false)#text(", we conclude in particular that ")#tao-math("{\\left|A_1\\right| \\ge \\left|A\\right|/2K}", block: false)#text(".")

#text("Let ")#mi("{\\epsilon > 0}")#text(" be a sufficiently small quantity (depending on ")#mi("{K}")#text(") to be chosen later. Applying Lemma ")#link(<tao-2c38b22f1197f330c40a>)[#text("3")]#text(", one can find a subset ")#mi("{A_2}")#text(" of ")#mi("{A_1}")#text(" of cardinality ")#tao-math("{\\left|A_2\\right| \\gg \\left|A_1\\right|/K \\gg \\left|A\\right|/K^2}", block: false)#text(" such that at most ")#tao-math("{\\epsilon \\left|A_2\\right|^2}", block: false)#text(" of the pairs ")#mi("{(a,a^{\\prime}) \\in A_2 \\times A_2}")#text(" are ")#emph[#text("bad")]#text(" in the sense that they are connected by ")#tao-math("{\\gg \\epsilon/K^2 \\left|B\\right|}", block: false)#text(" paths of length two.")

#text("Let ")#mi("{A^{\\prime}}")#text(" be those vertices ")#mi("{a}")#text(" in ")#mi("{A_2}")#text(" for which there are at most ")#tao-math("{\\sqrt{\\epsilon} \\left|A_2\\right|}", block: false)#text(" elements ")#mi("{a^{\\prime}}")#text(" of ")#mi("{A_2}")#text(" for which ")#mi("{(a,a^{\\prime})}")#text(" is bad. By Markov’s inequality, ")#mi("{A^{\\prime}}")#text(" consists of all but at most ")#tao-math("{\\sqrt{\\epsilon} \\left|A_2\\right|}", block: false)#text(" elements of ")#mi("{A_2}")#text(".")

#text("Let ")#mi("{E_2}")#text(" be the edges connecting ")#mi("{A_2}")#text(" with ")#mi("{B}")#text(". Since each vertex in ")#mi("{A_2}")#text(" has degree at least ")#tao-math("{\\left|B\\right|/2K}", block: false)#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|E_2\\right| \\geq \\left|A_2\\right| \\left|B\\right| / 2K \\gg \\left|A\\right| \\left|B\\right| / K^3.", block: true)]]

#text("We may thus find a subset ")#mi("{B^{\\prime}}")#text(" of ")#mi("{B}")#text(" of cardinality ")#tao-math("{\\left|B^{\\prime}\\right| \\gg \\left|B\\right|/K^3}", block: false)#text(" such that each ")#mi("{b \\in B^{\\prime}}")#text(" is adjacent to ")#tao-math("{\\gg \\left|A\\right|/K^3}", block: false)#text(" elements of ")#mi("{A_2}")#text(".")

#text("Now let ")#mi("{a \\in A^{\\prime}}")#text(" and ")#mi("{b \\in B^{\\prime}}")#text(". We know that ")#mi("{b}")#text(" is adjacent to ")#tao-math("{\\gg \\left|A\\right|/K^3}", block: false)#text(" elements ")#mi("{a^{\\prime}}")#text(" of ")#mi("{A_2}")#text(", and that at most ")#tao-math("{\\sqrt{\\epsilon} \\left|A_2\\right|}", block: false)#text(" of these elements are such that ")#mi("{(a,a^{\\prime})}")#text(" is bad. If we choose ")#mi("{\\epsilon}")#text(" to be a sufficiently small multiple of ")#mi("{1/K^6}")#text(", we conclude that there are ")#tao-math("{\\gg \\left|A\\right|/K^3}", block: false)#text(" elements ")#mi("{a^{\\prime}}")#text(" which are adjacent to ")#mi("{b}")#text(" and for which ")#mi("{(a,a^{\\prime})}")#text(" is not bad. One thus has ")#tao-math("{\\gg (\\left|A\\right|/K^3) (\\epsilon/K^2) \\left|B\\right| \\gg \\left|A\\right| \\left|B\\right| / K^{11}}", block: false)#text(" paths of length three connecting ")#mi("{a}")#text(" to ")#mi("{b}")#text(", and the claim follows. ")#mi("\\Box")

#text("The exponents in ")#mi("{K}")#text(" here can be improved slightly, but we will not attempt to obtain the optimal numerology here.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The above results are analogous to a phenomenon in additive combinatorics, namely that a “1%-structured” set (such as a small density subset of a group) can often be upgraded to a “99%-structured” set (such as the complement of a small density subset of a group) by applying a single “convolution” or “sumset” operation, and then upgraded further to a “100%-structured” set (such as a genuine group) by applying a further convolution or sumset operation. (This is basically why, for instance, it is known that almost all even natural numbers are the sum of two primes, and all but finitely many odd natural numbers are the sum of three primes; but it is not known whether all but finitely many even natural numbers are the sum of two primes.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Weighted Balog-Szemerédi-Gowers theorem)")]#text(" Let ")#mi("{(X,\\mu)}")#text(" and ")#mi("{(Y,\\nu)}")#text(" be probability spaces, and let ")#mi("{E \\subset X \\times Y}")#text(" have measure ")#mi("{\\mu \\times \\nu(E) \\geq 1/K}")#text(" for some ")#mi("{K \\geq 1}")#text(".")

#list(
[#text("(i) Show that for any ")#mi("{\\epsilon > 0}")#text(", there exists a subset ")#mi("{X^{\\prime}}")#text(" of ")#mi("{X}")#text(" of measure ")#mi("{\\mu(X^{\\prime}) \\geq \\frac{1}{\\sqrt{2}K}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\mu \\times \\mu( \\{ (x,x^{\\prime}) \\in X^{\\prime} \\times X^{\\prime}:")]]

#align(center)[#tao-fit-display[#mitex("\\int_Y 1_E(x,y) 1_E(x^{\\prime},y)\\ d\\nu(y) < \\frac{\\epsilon}{2K^2} \\} ) \\leq \\epsilon \\mu(X^{\\prime})^2.")]]],
[#text("(ii) Show that there exists subsets ")#mi("{X^{\\prime}, Y^{\\prime}}")#text(" of ")#mi("{X,Y}")#text(" of measure ")#mi("{\\mu(X^{\\prime}) \\gg K^{-O(1)}}")#text(" and ")#mi("{\\nu(Y^{\\prime}) \\gg K^{-O(1)}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_X \\int_Y 1_E(x,y^{\\prime}) 1_E(x^{\\prime},y^{\\prime}) 1_E(x^{\\prime},y)\\ d\\mu(x^{\\prime}) d\\nu(y^{\\prime}) \\gg K^{-O(1)}")]]

#text("for all ")#mi("{x \\in X^{\\prime}}")#text(" and ")#mi("{y \\in Y^{\\prime}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (99% Balog-Szemerédi theorem)")]#text(" Let ")#mi("{G(A,B,E)}")#text(" be a finite bipartite graph with ")#tao-math("{\\left|E\\right| \\geq (1-\\epsilon) \\left|A\\right| \\left|B\\right|}", block: false)#text(".")

#list(
[#text("(i) Show that there exists a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" of size ")#tao-math("{\\left|A^{\\prime}\\right| \\geq (1-O(\\sqrt{\\epsilon})) \\left|A\\right|}", block: false)#text(" such that for every ")#mi("{a,a^{\\prime} \\in A^{\\prime}}")#text(", ")#mi("{a}")#text(" and ")#mi("{a^{\\prime}}")#text(" are connected by at least ")#tao-math("{(1-O(\\sqrt{\\epsilon})) \\left|B\\right|}", block: false)#text(" paths of length ")#mi("{2}")#text(". (")#emph[#text("Hint:")]#text(" select ")#mi("{A^{\\prime}}")#text(" to be those vertices in ")#mi("{A^{\\prime}}")#text(" that are connected to “almost all” the vertices in ")#mi("{B}")#text(".)")],
[#text("(ii) Show that there also exists a subset ")#mi("{B^{\\prime}}")#text(" of ")#mi("{B}")#text(" of size ")#tao-math("{\\left|B^{\\prime}\\right| \\geq (1-O(\\sqrt{\\epsilon})) \\left|B\\right|}", block: false)#text(" such that for every ")#mi("{a \\in A^{\\prime}}")#text(" and ")#mi("{b \\in B^{\\prime}}")#text(", ")#mi("{a}")#text(" and ")#mi("{b}")#text(" are connected by at least ")#tao-math("{(1-O(\\sqrt{\\epsilon})) \\left|A\\right| \\left|B\\right|}", block: false)#text(" paths of length ")#mi("{3}")#text(".")]
)
]

#text("We now apply the graph-theoretic lemma to the group context. The main idea here is to show that various sets (e.g. product sets ")#mi("{A \\cdot B}")#text(") are small by showing that they are in the high-multiplicity region of some convolution (e.g. ")#mi("{1_{A_1} * \\ldots * 1_{A_k}}")#text("), or equivalently that elements ")#mi("{g}")#text(" of such sets have many representations as a product ")#mi("{g = a_1 \\ldots a_k}")#text(" with ")#mi("{a_1 \\in A_1, \\ldots, a_k \\in A_k}")#text(". One can then use Markov’s inequality and the trivial identity ")#tao-math("{\\left\\| 1_{A_1} * \\ldots * 1_{A_k} \\right\\|_{\\ell^1(G)} = \\left|A_1\\right| \\ldots \\left|A_k\\right|}", block: false)#text(" to get usable size bounds on such sets.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (Balog-Szemerédi lemma, product set form)")]#text(" ")#metadata(none) <tao-ce89fd03bd3c39f12ccb>#text(" let ")#mi("{A, B}")#text(" be finite non-empty subsets of a group ")#mi("{G = (G,\\cdot)}")#text(", and suppose that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|1_A * 1_B \\right\\|_{\\ell^2(G)} \\geq \\left|A\\right|^{3/4} \\left|B\\right|^{3/4}/K", block: true)]]

#text("for some ")#mi("{K \\geq 1}")#text(". (This hypothesis should be compared with the upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|1_A * 1_B \\right\\|_{\\ell^2(G)} \\leq \\left\\|1_A\\right\\|_{\\ell^{4/3}(G)} \\left\\|1_B\\right\\|_{\\ell^{4/3}(G)} = \\left|A\\right|^{3/4} \\left|B\\right|^{3/4}", block: true)]]

#text("arising from Young’s inequality.) Then there exists subsets ")#mi("{A^{\\prime}, B^{\\prime}}")#text(" of ")#mi("{A, B}")#text(" respectively with ")#tao-math("{\\left|A^{\\prime}\\right| \\gg K^{-O(1)} \\left|A\\right|}", block: false)#text(" and ")#tao-math("{\\left|B^{\\prime}\\right| \\gg K^{-O(1)} \\left|B\\right|}", block: false)#text(" with ")#tao-math("{\\left|A^{\\prime} \\cdot B^{\\prime}\\right| \\ll K^{O(1)} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}}", block: false)#text(" and ")#tao-math("{\\left|A^{\\prime} \\cdot (A^{\\prime})^{-1}\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(".")
]

#text("The quantity ")#tao-math("{\\left\\|1_A *1_B\\right\\|_{\\ell^2(G)}^2}", block: false)#text(" (or equivalently, the number of solutions to the equation ")#mi("{ab=a^{\\prime}b^{\\prime}}")#text(" with ")#mi("{a,a^{\\prime} \\in A}")#text(" and ")#mi("{b,b^{\\prime} \\in B}")#text(") is also known as the ")#emph[#text("multiplicative energy")]#text(" of ")#mi("{A}")#text(" and ")#mi("{B}")#text(", and is sometimes denoted ")#mi("{E(A,B)}")#text(" in the literature.")

#emph[#text("Proof:")]#text(" By hypothesis, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{(a,b) \\in A \\times B} 1_A * 1_B(ab) = \\left\\|1_A * 1_B \\right\\|_{\\ell^2(G)}^2 \\geq \\left|A\\right|^{3/2} \\left|B\\right|^{3/2} / K^2.", block: true)]]

#text("Since")

#align(center)[#tao-fit-display[#tao-math("\\sum_{(a,b) \\in A \\times B: 1_A * 1_B(ab) \\leq \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}/2K^2} 1_A * 1_B(ab) \\leq \\left|A\\right|^{3/2} \\left|B\\right|^{3/2} / 2K^2,", block: true)]]

#text("we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{(a,b) \\in A \\times B: 1_A * 1_B(ab) > \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}/2K^2} 1_A * 1_B(ab) \\geq \\left|A\\right|^{3/2} \\left|B\\right|^{3/2} / 2K^2.", block: true)]]

#text("Since, by Cauchy-Schwarz (or Young’s inequality), we have ")#tao-math("{1_A*1_B(ab) \\leq \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}}", block: false)#text(", we conclude that there is a set ")#mi("{E \\subset A \\times B}")#text(" with ")#tao-math("{\\left|E\\right| \\geq \\left|A\\right| \\left|B\\right|/2K^2}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("1_A * 1_B(ab) > \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}/2K^2", block: true)]]

#text("for all ")#mi("{(a,b) \\in E}")#text(".")

#text("By slight abuse of notation (arising from the fact that ")#mi("{A}")#text(", ")#mi("{B}")#text(" are not necessarily disjoint, and that ")#mi("{E}")#text(" is a set of ordered pairs rather than unordered pairs), we can view the triplet ")#mi("{(A,B,E)}")#text(" as a bipartite graph. Applying Lemma ")#link(<tao-928b07a1ebe453db4aab>)[#text("4")]#text(", we can find subsets ")#mi("{A^{\\prime}, B^{\\prime}}")#text(" of ")#mi("{A, B}")#text(" respectively with ")#tao-math("{\\left|A^{\\prime}\\right| \\gg K^{-O(1)} \\left|A\\right|}", block: false)#text(" and ")#tao-math("{\\left|B^{\\prime}\\right| \\gg K^{-O(1)} \\left|B\\right|}", block: false)#text(" such that for all ")#mi("{a \\in A^{\\prime}}")#text(" and ")#mi("{b \\in B^{\\prime}}")#text(", one can find ")#tao-math("{\\gg K^{-O(1)} \\left|A\\right| \\left|B\\right|}", block: false)#text(" elements ")#mi("{a^{\\prime} \\in A, b^{\\prime} \\in B}")#text(" such that ")#mi("{(a,b^{\\prime}), (a^{\\prime},b^{\\prime}), (a^{\\prime},b) \\in E}")#text(". In particular, we see that ")#metadata(none) <tao-e22115b5d76640e2389b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sum_{a^{\\prime} \\in G} \\sum_{b^{\\prime} \\in G} 1_A * 1_B(ab^{\\prime}) 1_A * 1_B(a^{\\prime}b^{\\prime}) 1_A*1_B(a^{\\prime}b) \\gg K^{-O(1)} \\left|A\\right|^{5/2} \\left|B\\right|^{5/2}.", block: true)]]

#text("Observe that ")#mi("{1_A * 1_B(a^{\\prime}b^{\\prime}) = 1_{B^{-1}}*1_{A^{-1}} ((b^{\\prime})^{-1} (a^{\\prime})^{-1} )}")#text(". Using the identity ")#mi("{(ab^{\\prime}) ((b^{\\prime})^{-1} (a^{\\prime})^{-1}) (a^{\\prime} b) = ab}")#text(", we note that triples ")#mi("{(ab^{\\prime}, (b^{\\prime})^{-1} (a^{\\prime})^{-1}, a^{\\prime}b)}")#text(" for ")#mi("{a^{\\prime},b^{\\prime} \\in G}")#text(" are precisely those triples ")#mi("{(g_1,g_2,g_3) \\in G \\times G}")#text(" with ")#mi("{g_1g_2g_3 = ab}")#text(". Thus the left-hand side of ")#link(<tao-e22115b5d76640e2389b>)[#text("(3)")]#text(" is equal to ")#mi("{F(ab)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("F := 1_A * 1_B * 1_{B^{-1}} * 1_{A^{-1}} * 1_A * 1_B.")]]

#text("But since")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{\\ell^1} = \\left|A\\right| \\left|B\\right| \\left|B^{-1}\\right| \\left|A^{-1}\\right| \\left|A\\right| \\left|B\\right| = \\left|A\\right|^3 \\left|B\\right|^3,", block: true)]]

#text("we see from Markov’s inequality that there are at most ")#tao-math("{O(K^{O(1)} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2})}", block: false)#text(" possible values for ")#mi("{ab}")#text(", which gives the bound ")#tao-math("{\\left|A^{\\prime} \\cdot B^{\\prime}\\right| \\ll K^{O(1)} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}}", block: false)#text(".")

#text("The second bound ")#tao-math("{\\left|A^{\\prime} \\cdot (A^{\\prime})^{-1}\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(" can be proven similarly to the first (noting that any ")#mi("{a,a^{\\prime} \\in A^{\\prime}}")#text(" are connected by ")#tao-math("{\\gg K^{-O(1)} \\left|A\\right|^2 \\left|B\\right|^2}", block: false)#text(" paths of length six), but can also from the former bound as follows. Observe that any element ")#mi("{a (a^{\\prime})^{-1} \\in A^{\\prime} \\cdot (A^{\\prime})^{-1}}")#text(" has at least ")#tao-math("{\\left|B^{\\prime}\\right|}", block: false)#text(" representations of the form ")#mi("{a(a^{\\prime})^{-1} = (ab) (a^{\\prime}b)^{-1}}")#text(" with ")#mi("{b \\in B^{\\prime}}")#text(", and hence ")#mi("{ab,a^{\\prime}b \\in A^{\\prime} \\cdot B^{\\prime}}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("1_{A^{\\prime}B^{\\prime}} * 1_{(A^{\\prime}B^{\\prime})^{-1}} \\geq \\left|B^{\\prime}\\right| \\gg K^{-O(1)} \\left|B\\right|", block: true)]]

#text("on ")#mi("{A^{\\prime} (A^{\\prime})^{-1}}")#text(". On the other hand, the left-hand side has an ")#mi("{\\ell^1(G)}")#text(" norm of ")#tao-math("{\\left|A^{\\prime}B^{\\prime}\\right| \\left|(A^{\\prime}B^{\\prime})^{-1}\\right| \\ll K^{O(1)} \\left|A\\right| \\left|B\\right|}", block: false)#text(", and the bound ")#tao-math("{\\left|A^{\\prime} \\cdot (A^{\\prime})^{-1}\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(" then follows from Markov’s inequality. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-73f615112038fbbbada6>#text(" In the converse direction, show that if ")#mi("{A, B}")#text(" are non-empty finite subsets of ")#mi("{G}")#text(" with ")#tao-math("{\\left|AB\\right| \\leq K \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}}", block: false)#text(", then ")#tao-math("{\\left\\|1_A * 1_B \\right\\|_{\\ell^2(G)} \\geq \\left|A\\right|^{3/4} \\left|B\\right|^{3/4} / K^{1/2}}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" If ")#mi("{A, B, C}")#text(" are three non-empty finite subsets of ")#mi("{G}")#text(", establish the ")#emph[#text("Ruzsa triangle inequality")]#text(" ")#tao-math("{\\left|A \\cdot C^{-1}\\right| \\leq \\frac{\\left|A \\cdot B^{-1}\\right| \\left|B \\cdot C^{-1}\\right|}{\\left|B\\right|}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" mimic the final part of the proof of Corollary ")#link(<tao-ce89fd03bd3c39f12ccb>)[#text("5")]#text(".)")
]

#text("We now give a variant of this corollary involving approximate groups.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Balog-Szemerédi lemma, approximate group form)")]#text(" ")#metadata(none) <tao-2a949367a5b8d62d87c3>#text(" Let ")#mi("{A}")#text(" be a finite symmetric subset of a group ")#mi("{G = (G,\\cdot)}")#text(", and suppose that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|1_A * 1_A \\right\\|_{\\ell^2(G)} \\geq \\left|A\\right|^{3/2}/K", block: true)]]

#text("for some ")#mi("{K \\geq 1}")#text(". Then there exists a ")#mi("{K^{O(1)}}")#text("-approximate group ")#mi("{H}")#text(" with ")#tao-math("{\\left|H\\right| \\ll K^{O(1)} \\left|A\\right|}", block: false)#text(" such that ")#tao-math("{\\left|A \\cap gH\\right| \\gg K^{-O(1)} \\left|A\\right|}", block: false)#text(" for some ")#mi("{g \\in H}")#text(".")
]

#emph[#text("Proof:")]#text(" By Corollary ")#link(<tao-ce89fd03bd3c39f12ccb>)[#text("5")]#text(", we may find a subset ")#mi("{A^{\\prime} \\subset A}")#text(" with ")#tao-math("{\\left|A^{\\prime}\\right| \\gg K^{-O(1)} \\left|A\\right|}", block: false)#text(" such that ")#metadata(none) <tao-6c6b49c1b4e7ead684cb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left|A^{\\prime} (A^{\\prime})^{-1}\\right| \\ll K^{O(1)} |A|.", block: true)]]

#text("By Exercise ")#link(<tao-73f615112038fbbbada6>)[#text("3")]#text(", this implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_{A^{\\prime}} * 1_{(A^{\\prime})^{-1}} \\right\\|_{\\ell^2(G)}^2 \\gg K^{-O(1)} \\left|A\\right|^3.", block: true)]]

#text("Observe that the left-hand side is equal to")

#align(center)[#tao-fit-display[#mitex("1_{A^{\\prime}} * 1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}} * 1_{(A^{\\prime})^{-1}} (1)")]]

#tao-aligned(keep: true)[


#tao-math(" & = 1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}} * 1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}}(1)", block: true)



#tao-math(" & = \\left\\| 1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}} \\right\\|_{\\ell^2(G)}^2.", block: true)
]

#text("We conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{s \\in G} (1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}}(s))^2 \\gg K^{-O(1)} \\left|A\\right|^3.", block: true)]]

#text("On the other hand, we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{s \\in G} 1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}}(s) = \\left|A^{\\prime}\\right| \\left|A^{\\prime}\\right| \\leq \\left|A\\right|^2.", block: true)]]

#text("As a consequence, we see that if we set")

#align(center)[#tao-fit-display[#tao-math("S := \\{ s \\in G: 1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}}(s) \\geq C^{-1} K^{-C} \\left|A\\right| \\}", block: true)]]

#text("for some sufficiently large absolute constant ")#mi("{C}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{s \\in G \\backslash S} (1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}}(s))^2 \\leq C^{-1} K^{-C} \\left|A\\right|^3,", block: true)]]

#text("and thus (for ")#mi("{C}")#text(" large enough)")

#align(center)[#tao-fit-display[#tao-math("\\sum_{s \\in S} (1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}}(s))^2 \\gg K^{-O(1)} \\left|A\\right|^3.", block: true)]]

#text("Since ")#tao-math("{1_{(A^{\\prime})^{-1}} * 1_{A^{\\prime}}(s) \\leq\\left|A^{\\prime}\\right| \\leq \\left|A\\right|}", block: false)#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|S\\right| \\gg K^{-O(1)} |A|.", block: true)]]

#text("Also, ")#mi("{S}")#text(" is clearly symmetric and contains the origin.")

#text("Now let us consider an element ")#mi("{g = a_0 s_1 \\ldots s_5 b_6^{-1}}")#text(" of the product ")#mi("{(A^{\\prime}) S^5 (A^{\\prime})^{-1}}")#text(". By construction of ")#mi("{S}")#text(", we can write each ")#mi("{s_i}")#text(" as a product ")#mi("{b_i^{-1} a_i}")#text(" with ")#mi("{a_i,b_i \\in A^{\\prime}}")#text(" in at least ")#tao-math("{C^{-1} K^{-C} \\left|A\\right|}", block: false)#text(" ways. Doing so for each ")#mi("{i=1,\\ldots,5}")#text(" gives rise to a factorisation")

#align(center)[#tao-fit-display[#mitex("g = g_1 \\ldots g_6")]]

#text("where ")#mi("{g_i := a_{i-1} b_i^{-1} \\in A^{\\prime} (A^{\\prime})^{-1}}")#text("; as the ")#mi("{g_1,\\ldots,g_6}")#text(" uniquely determine the ")#mi("{a_i,b_i}")#text(" (for fixed ")#mi("{a_0,s_1,\\ldots,s_5,b_6}")#text("), we conclude that each element ")#mi("{g}")#text(" of ")#mi("{(A^{\\prime}) S^5 (A^{\\prime})^{-1}}")#text(" has at least ")#tao-math("{\\gg K^{-O(1)} \\left|A\\right|^5}", block: false)#text(" such factorisations. But by ")#link(<tao-6c6b49c1b4e7ead684cb>)[#text("(4)")]#text(", there are at most ")#tao-math("{O(K^{O(1)}\\left|A\\right|^6)}", block: false)#text(" such tuples ")#mi("{g_1,\\ldots,g_6}")#text(", and so there are at most ")#tao-math("{O(K^{O(1)} \\left|A\\right|)}", block: false)#text(" possible values for ")#mi("{g}")#text(", thus ")#metadata(none) <tao-c73289615c6ec821c505>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|(A^{\\prime}) S^5 (A^{\\prime})^{-1}\\right| \\ll K^{O(1)} |A|.", block: true)]]

#text("In particular,")

#align(center)[#tao-fit-display[#tao-math("\\left|S^5\\right| \\ll K^{O(1)} |S|.", block: true)]]

#text("By the Ruzsa covering lemma (see the exercise below), this implies that ")#mi("{S^4}")#text(" is covered by ")#mi("{O(K^{O(1)})}")#text(" left-translates of ")#mi("{S^2}")#text(", and so ")#mi("{H := S^2}")#text(" is a ")#mi("{K^{O(1)}}")#text("-approximate group. Finally, from ")#link(<tao-c73289615c6ec821c505>)[#text("(5)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime} H\\right| \\ll K^{O(1)} \\left|A\\right|", block: true)]]

#text("and thus by Exercise ")#link(<tao-73f615112038fbbbada6>)[#text("3")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_{A^{\\prime}} * 1_H \\right\\|_{\\ell^2(G)} \\gg K^{-O(1)} \\left|A\\right|^{3/2}.", block: true)]]

#text("In particular, since the support of ")#mi("{1_{A^{\\prime}} * 1_H}")#text(" has size ")#tao-math("{O(K^{O(1)} \\left|A\\right|)}", block: false)#text(", one has")

#align(center)[#tao-fit-display[#tao-math("1_{A^{\\prime}} * 1_H(g) \\gg K^{-O(1)} \\left|A\\right|", block: true)]]

#text("for some ")#mi("{g \\in G}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime} \\cap Hg\\right| \\gg K^{-O(1)} |A|.", block: true)]]

#text("Increasing ")#mi("{A^{\\prime}}")#text(" to ")#mi("{A}")#text(" and taking inverses, we conclude that ")#tao-math("{\\left|gH \\cap A\\right| \\ll K^{-O(1)} \\left|A\\right|}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Ruzsa covering lemma)")]#text(" Let ")#mi("{A, B}")#text(" be finite non-empty subsets of a group ")#mi("{G}")#text(". Show that ")#mi("{A}")#text(" can be covered by at most ")#tao-math("{\\frac{\\left|AB\\right|}{\\left|B\\right|}}", block: false)#text(" left-translates of ")#mi("{BB^{-1}}")#text(". (")#emph[#text("Hint:")]#text(" consider a maximal disjoint collection of translates ")#mi("{aB}")#text(" of ")#mi("{B}")#text(" with ")#mi("{a \\in A}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6 (Converse to Balog-Szemerédi-Gowers)")]#text(" Let ")#mi("{A}")#text(" be a finite symmetric subset of a group ")#mi("{G = (G,\\cdot)}")#text(", and suppose there exists a ")#mi("{K}")#text("-approximate group ")#mi("{H}")#text(" with ")#tao-math("{\\left|H\\right| \\leq K \\left|A\\right|}", block: false)#text(" such that ")#tao-math("{\\left|A \\cap gH\\right| \\geq \\left|A\\right|/K}", block: false)#text(" for some ")#mi("{g \\in H}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|1_A * 1_A\\right\\|_{\\ell^2(G)} \\geq K^{-3} \\left|A\\right|^{3/2}.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{A, B}")#text(" be finite non-empty subsets of a group ")#mi("{G}")#text(", and suppose that ")#tao-math("{\\left\\|1_A * 1_B \\right\\|_{\\ell^2(G)} \\geq \\left|A\\right|^{3/2} \\left|B\\right|^{3/2} / K}", block: false)#text(". Show that there exists a ")#mi("{O(K^{O(1)})}")#text("-approximate group ")#mi("{H}")#text(" with ")#tao-math("{K^{-O(1)} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2} \\leq \\left|H\\right| \\leq K^{O(1)} \\left|A\\right|^{1/2} \\left|B\\right|^{1/2}}", block: false)#text(" and elements ")#mi("{g, h \\in G}")#text(" such that ")#tao-math("{\\left|A \\cap gH\\right| \\gg K^{-O(1)} \\left|H\\right|}", block: false)#text(" and ")#tao-math("{\\left|B \\cap Hh\\right| \\gg K^{-O(1)} \\left|H\\right|}", block: false)#text(".")
]

#text("Finally, we can prove Lemma ")#link(<tao-c22051c3f481b4bd916b>)[#text("1")]#text(". Fix ")#mi("{G, \\nu, K}")#text(". We may assume that ")#metadata(none) <tao-7467b914d771fcfd9291>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| \\nu * \\nu \\right\\|_{\\ell^2(G)} > \\frac{1}{K} \\left\\|\\nu\\right\\|_{\\ell^2(G)}", block: true)]]

#text("and we need to use this to locate an ")#mi("{O(K^{O(1)})}")#text("-approximate group ")#mi("{H}")#text(" in ")#mi("{G}")#text(" with ")#tao-math("{\\left|H\\right| \\ll K^{O(1)} / \\left\\| \\nu \\right\\|_{\\ell^2(G)}^2}", block: false)#text(" and an element ")#mi("{x \\in G}")#text(" such that ")#mi("{\\nu(xH) \\gg K^{-O(1)}}")#text(".")

#text("Let us write ")#tao-math("{M := 1/\\left\\|\\nu\\right\\|_{\\ell^2(G)}^2}", block: false)#text(". Intuitively, ")#mi("{M}")#text(" represents the “width” of the probability meaure ")#mi("{\\nu}")#text(", as can be seen by considering the model example ")#mi("{\\nu = \\frac{1}{M} 1_A}")#text(" where ")#mi("{A}")#text(" is a symmetric set of cardinality ")#mi("{M}")#text(" (i.e. ")#mi("{\\nu}")#text(" is the uniform probability measure on ")#mi("{A}")#text("). If we were actually in this model case, we could apply Lemma ")#link(<tao-2a949367a5b8d62d87c3>)[#text("6")]#text(" immediately and be done. Of course, in general, ")#mi("{\\nu}")#text(" need not be a uniform measure on a set of size ")#mi("{M}")#text(". However, it turns out that one can use ")#link(<tao-7467b914d771fcfd9291>)[#text("(6)")]#text(" to conclude that the “bulk” of ")#mi("{\\nu}")#text(" is basically of this form.")

#text("More precisely, let us split ")#mi("{\\nu = \\nu_{<}+\\nu_{>}+\\nu_=}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("\\nu_{<}  & := \\nu 1_{\\nu \\leq \\frac{1}{100K^2M}}", block: true)



#tao-math("\\nu_{>}  & := \\nu 1_{\\nu \\geq \\frac{10K}{M}}", block: true)



#tao-math("\\nu_=  & := \\nu - \\nu_{<} - \\nu_{>}.", block: true)
]

#text("Observe that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu_{<}\\right\\|_{\\ell^2(G)}^2 \\leq \\frac{1}{100K^2M} \\left\\| \\nu \\right\\|_{\\ell^1(G)} = \\frac{1}{100K^2M}", block: true)]]

#text("and so by Young’s inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu_{<} * \\nu \\right\\|_{\\ell^2(G)} = \\left\\| \\nu * \\nu_{>} \\right\\|_{\\ell^2(G)} \\leq \\frac{1}{10KM^{1/2}}.", block: true)]]

#text("In a similar vein, we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu_{>} \\right\\|_{\\ell^1(G)} \\leq \\frac{M}{10K} \\left\\| \\nu \\right\\|_{\\ell^2(G)}^2 = \\frac{1}{10K}", block: true)]]

#text("and thus by Young’s inequality (and the normalisation ")#tao-math("{\\left\\|\\nu\\right\\|_{\\ell^2(G)} = 1/M^{1/2}}", block: false)#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu_{>} * \\nu \\right\\|_{\\ell^2(G)} = \\left\\| \\nu * \\nu_{<} \\right\\|_{\\ell^2(G)} \\leq \\frac{1}{10KM^{1/2}}.", block: true)]]

#text("Finally, from ")#link(<tao-7467b914d771fcfd9291>)[#text("(6)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu * \\nu \\right\\|_{\\ell^2(G)} \\geq \\frac{1}{K M^{1/2}}.", block: true)]]

#text("Subtracting using the triangle inequality (ignoring some slight double-counting), we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nu_= * \\nu_= \\right\\|_{\\ell^2(G)} \\gg \\frac{1}{KM^{1/2}}.", block: true)]]

#text("If we then set ")#mi("{A := \\{ g \\in G: \\nu(g) > \\frac{1}{100K^2 M} \\}}")#text(", we conclude in particular that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * 1_A \\right\\|_{\\ell^2(G)} \\gg K^{-O(1)} M^{3/2}.", block: true)]]

#text("On the other hand, from Markov’s inequality one has ")#tao-math("{\\left|A\\right| \\ll K^2 M}", block: false)#text(". Applying Lemma ")#link(<tao-2a949367a5b8d62d87c3>)[#text("6")]#text(", we conclude the existence of a ")#mi("{O(K^{O(1)})}")#text("-approximate group ")#mi("{H}")#text(" with ")#tao-math("{\\left|H\\right| \\ll K^{O(1)} M}", block: false)#text(" such that ")#tao-math("{\\left|A \\cap gH\\right| \\gg K^{-O(1)} M}", block: false)#text(" for some ")#mi("{g \\in G}")#text(", which by definition of ")#mi("{A}")#text(" implies that ")#mi("{\\nu(gH) \\gg K^{-O(1)}}")#text(", and the claim follows.")

#heading(level: 1)[#strong[#text(" — 2. The Bourgain-Gamburd expansion machine — ")]]

#text("We can now prove Theorem ")#link(<tao-91239da3b902ad5edfdd>)[#text("2")]#text(". We can assume that ")#tao-math("{\\left|G\\right|}", block: false)#text(" is sufficiently large depending on the parameters ")#mi("{k,\\kappa,\\Lambda,\\delta^{\\prime}}")#text(", since the claim is trivial for bounded ")#mi("{G}")#text(" (note that as ")#mi("{S}")#text(" generates ")#mi("{G}")#text(", the Cayley graph ")#mi("{Cay(G,S)}")#text(" will be an ")#mi("{\\epsilon}")#text("-expander for some ")#mi("{\\epsilon>0}")#text("). Henceforth we allow all implied constants in the asymptotic notation to depend on ")#mi("{k,\\kappa,\\Lambda,\\delta^{\\prime}}")#text(".")

#text("To show expansion, it suffices from the quasirandomness hypothesis (and ")#link("https://terrytao.wordpress.com/2011/12/16/254b-notes-3-quasirandom-groups-expansion-and-selbergs-316-theorem/")[#text("Proposition 4 from the preceding notes")]#text("), it will suffice to show that ")#metadata(none) <tao-cb9c245f6cf4910aca44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\| \\mu^{(n)} \\right\\|_{\\ell^2(G)} \\leq \\left|G\\right|^{-1/2+\\kappa/2}", block: true)]]

#text("for some ")#tao-math("{n = O(\\log \\left|G\\right|)}", block: false)#text(".")

#text("From Young’s inequality, ")#tao-math("{\\left\\| \\mu^{(n)}\\right\\|_{\\ell^2(G)}}", block: false)#text(" is decreasing in ")#mi("{n}")#text(", and is initially equal to ")#mi("{1}")#text(" when ")#mi("{n=0}")#text(". We need to “flatten” the ")#mi("{\\ell^2(G)}")#text(" norm of ")#mi("{\\mu^{(n)}}")#text(" as ")#mi("{n}")#text(" increases. We first use the non-concentration hypothesis to obtain an initial amount of flattening:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" For any ")#tao-math("{n \\geq \\frac{1}{2} \\Lambda \\log \\left|G\\right|}", block: false)#text(", one has ")#metadata(none) <tao-52cb0d6bdd35222e877d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\| \\mu^{(n)} \\right\\|_{\\ell^2(G)} \\leq \\left|G\\right|^{-\\kappa/4}.", block: true)]]

#text("Furthermore, we have ")#metadata(none) <tao-3d875611ebb4e617e2d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\mu^{(n)}(gH) \\leq \\left|G\\right|^{-\\kappa/2}", block: true)]]

#text("for all proper subgroups ")#mi("{H}")#text(" of ")#mi("{G}")#text(" and all ")#mi("{g \\in G}")#text(".")
]

#emph[#text("Proof:")]#text(" By the non-concentration hypothesis, we can find ")#tao-math("{n_0 \\leq \\frac{1}{2} \\Lambda \\log \\left|G\\right|}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\mu^{(2n_0)}(H) \\leq \\left|G\\right|^{-\\kappa}", block: true)]]

#text("for all proper subgroups ")#mi("{H}")#text(" of ")#mi("{G}")#text(". If we write ")#mi("{\\mu^{(2n_0)}(H)}")#text(" as ")#mi("{\\mu^{(n_0)}*\\mu^{(n_0)}( Hg g^{-1} H)}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\mu^{(2n_0)}(H) \\geq \\mu^{(n_0)}(Hg) \\mu^{(n_0)}(g^{-1} H)")]]

#text("for all ")#mi("{g \\in G}")#text(". By symmetry, ")#mi("{\\mu^{(n_0)}(g^{-1} H) = \\mu^{(n_0)}(Hg)}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\sup_{g \\in G} \\mu^{(n_0)}(gH) \\leq \\left|G\\right|^{-\\kappa/2}.", block: true)]]

#text("If ")#tao-math("{n \\geq \\frac{1}{2} \\Lambda \\log \\left|G\\right|}", block: false)#text(", then we may write ")#mi("{\\mu^{(n)}}")#text(" as the convolution of a probability measure ")#mi("{\\mu^{(n-n_0)}}")#text(" and ")#mi("{\\mu^{(n_0)}}")#text(". From this, we see that")

#align(center)[#tao-fit-display[#tao-math("\\mu^{(n)}(g^{\\prime} H) \\leq \\sup_{g \\in G} \\mu^{(n_0)}(gH) \\leq \\left|G\\right|^{-\\kappa/2}", block: true)]]

#text("for all ")#mi("{g^{\\prime} \\in G}")#text(", giving the claim ")#link(<tao-3d875611ebb4e617e2d6>)[#text("(9)")]#text(". Specialising this to the case when ")#mi("{H}")#text(" is the trivial group, one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{(n)} \\right\\|_{\\ell^\\infty(G)} \\leq \\left|G\\right|^{-\\kappa/2}.", block: true)]]

#text("Since we also have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{(n)} \\right\\|_{\\ell^1(G)} = 1,", block: true)]]

#text("the claim ")#link(<tao-52cb0d6bdd35222e877d>)[#text("(8)")]#text(" then follows from Hölder’s inequality. ")#mi("\\Box")

#text("Now we obtain additional flattening using the product theorem hypothesis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8 (Flattening lemma)")]#text(" Suppose ")#tao-math("{n \\geq \\frac{1}{2} \\Lambda \\log \\left|G\\right|}", block: false)#text(" is such that ")#metadata(none) <tao-adfb752111880940407c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| \\mu^{(n)} \\right\\|_{\\ell^2(G)} \\geq \\left|G\\right|^{-1/2+\\kappa/2}.", block: true)]]

#text("Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{(n)} * \\mu^{(n)} \\right\\|_{\\ell^2(G)} \\leq \\left|G\\right|^{-\\epsilon} \\left\\| \\mu^{(n)} \\right\\|_{\\ell^2(G)}", block: true)]]

#text("for some ")#mi("{\\epsilon>0}")#text(" depending only on ")#mi("{\\kappa}")#text(" and ")#mi("{\\delta^{\\prime}}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose the claim fails for some ")#mi("{\\epsilon}")#text(" to be chosen later, thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mu^{(n)} * \\mu^{(n)} \\right\\|_{\\ell^2(G)} > \\left|G\\right|^{-\\epsilon} \\left\\| \\mu^{(n)} \\right\\|_{\\ell^2(G)}.", block: true)]]

#text("Applying Lemma ")#link(<tao-c22051c3f481b4bd916b>)[#text("1")]#text(", we may thus find a ")#tao-math("{O(\\left|G\\right|^{O(\\epsilon)})}", block: false)#text("-approximate group ")#mi("{H}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\ll \\left|G\\right|^{O(\\epsilon)} / \\left\\| \\mu^{(n)} \\right\\|_{\\ell^2(G)}^2", block: true)]]

#text("and ")#mi("{g \\in G}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\mu^{(n)}(gH) \\gg \\left|G\\right|^{-O(\\epsilon)}.", block: true)]]

#text("Since ")#tao-math("{\\mu^{(n)}\\|_{\\ell^\\infty(G)} \\leq \\left|G\\right|^{-\\kappa/2}}", block: false)#text(" by ")#link(<tao-3d875611ebb4e617e2d6>)[#text("(9)")]#text(", we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\gg \\left|G\\right|^{\\kappa/2-O(\\epsilon)}.", block: true)]]

#text("Meanwhile, from ")#link(<tao-adfb752111880940407c>)[#text("(10)")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|H\\right| \\ll \\left|G\\right|^{1-\\kappa + O(\\epsilon)}.", block: true)]]

#text("Applying the product hypothesis (assuming ")#mi("{\\epsilon}")#text(" sufficiently small depending on ")#mi("{\\kappa}")#text(" and ")#mi("{\\delta}")#text("), we conclude that ")#mi("{H}")#text(" generates a proper subgroup ")#mi("{K}")#text(" of ")#mi("{G}")#text(", and thus")

#align(center)[#tao-fit-display[#tao-math("\\mu^{(n)}(gK) \\gg \\left|G\\right|^{-O(\\epsilon)}.", block: true)]]

#text("But this contradicts ")#link(<tao-3d875611ebb4e617e2d6>)[#text("(9)")]#text(" (again if ")#mi("{\\epsilon}")#text(" is sufficiently small). ")#mi("\\Box")

#text("Iterating the above lemma ")#mi("{O(1)}")#text(" times we obtain ")#link(<tao-cb9c245f6cf4910aca44>)[#text("(7)")]#text(" for some ")#tao-math("{n = O(\\log \\left|G\\right|)}", block: false)#text(", as desired.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Roughly speaking, the three hypotheses in Theorem ")#link(<tao-91239da3b902ad5edfdd>)[#text("2")]#text(" govern three separate stages of the life cycle of the random walk and its distributions ")#mi("{\\mu^{(n)}}")#text(". In the early stage ")#tao-math("{n = o(\\log \\left|G\\right|)}", block: false)#text(", the non-concentration hypotheses creates some initial spreading of this random walk, in particular ensuring that the walk “escapes” from cosets of proper subgroups. In the middle stage ")#tao-math("{n \\sim \\log \\left|G\\right|}", block: false)#text(", the product theorem steadily flattens the distribution of the random walk, until it is very roughly comparable to the uniform distribution. Finally, in the late stage ")#tao-math("{n \\gg \\log \\left|G\\right|}", block: false)#text(", the quasirandomness property can smooth out the random walk almost completely to obtain the mixing necessary for expansion.")
]

#heading(level: 1)[#text("Comments (8)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-124703")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2012")])]

#text("(Somehow this post was not announced on Google Reader, so I only saw it yesterday…)")

#text("One remark that may be worth adding is that, if one is interested in explicit expansion bounds, this argument has a big loss at the stage of Lemma 8 (“flattening”), since it gives bounds for cycles of length exponentially large in terms of the gain it provides. However, with a little adaptation, this loss is in fact not needed (as described in my “Explicit expansion” notes for the case of SL_2.)")

#emph[#text("[Editor’s note: it turns out that the situation is a bit more complicated than this; see ")#link("http://blogs.ethz.ch/kowalski/2012/07/30/various-updates/")[#text("http://blogs.ethz.ch/kowalski/2012/07/30/various-updates/")]#text(" -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]], [#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-126688")[#strong[#text("254B, Notes 5: Product theorems, pivot arguments, and the Larsen-Pink non-concentration inequality « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2012")])]

#text("[…] the previous set of notes, we saw that one could derive expansion of Cayley graphs from three ingredients: non-concentration, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: Non-concentration in subgroups « What’s new")]], [#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-128465")[#strong[#text("254B, Notes 6: Non-concentration in subgroups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2012")])]

#text("[…] the last three notes, we discussed the Bourgain-Gamburd expansion machine and two of its three ingredients, namely […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-132348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2012")])]

#text("I think in Exercise 3, the conclusion should be |A|^{3/4}|B|^{3/4}, rather than 3/2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-132351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2012")])]

#text("Which also appears to affect both the statement and proof of Lemma 6.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-135653")[#strong[#text("On Endre Szemerédi’s Gifts to Computer Science « Windows On Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2012")]

#text("[…] will upper bound by . The proof of this magic lemma is also quite simple (e.g., see Lemma 4 in this blog post). Roughly speaking, if you choose to be a neighborhood of a random point , then we almost get what […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-244506")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] The current paper also uses the “Bourgain-Gamburd machine”, as discussed in these lecture notes of mine, to demonstrate expansion. This machine shows how expansion of a Cayley graph follows from three […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2012/01/13/254b-notes-4-the-bourgain-gamburd-expansion-machine/#comment-675360")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2023")])]

#text("In Lemma 5, one can easily get $|A’|\\gg \\delta |A|$, $|B’|\\gg \\delta |B|$ and $\\gg \\delta^5 |A| |B|$ paths (but then of course you know this).")
]
