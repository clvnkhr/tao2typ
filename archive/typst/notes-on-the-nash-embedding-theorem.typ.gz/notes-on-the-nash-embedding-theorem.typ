// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:19:41.936394+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on the Nash embedding theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on the Nash embedding theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 May 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/")[#text("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Throughout this post we shall always work in the smooth category, thus all manifolds, maps, coordinate charts, and functions are assumed to be smooth unless explicitly stated otherwise.")

#text("A (real) ")#link("https://en.wikipedia.org/wiki/Manifold")[#text("manifold")]#text(" ")#mi("{M}")#text(" can be defined in at least two ways. On one hand, one can define the manifold ")#emph[#text("extrinsically")]#text(", as a subset of some standard space such as a Euclidean space ")#mi("{{\\bf R}^d}")#text(". On the other hand, one can define the manifold ")#emph[#text("intrinsically")]#text(", as a topological space equipped with an ")#link("https://en.wikipedia.org/wiki/Atlas_(topology)")[#text("atlas")]#text(" of coordinate charts. The fundamental ")#emph[#text("embedding theorems")]#text(" show that, under reasonable assumptions, the intrinsic and extrinsic approaches give the same classes of manifolds (up to isomorphism in various categories). For instance, we have the following (special case of) the ")#link("https://en.wikipedia.org/wiki/Whitney_embedding_theorem")[#text("Whitney embedding theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Whitney embedding theorem)")]#text(" Let ")#mi("{M}")#text(" be a compact manifold. Then there exists an ")#link("https://en.wikipedia.org/wiki/Embedding")[#text("embedding")]#text(" ")#mi("{u: M \\rightarrow {\\bf R}^d}")#text(" from ")#mi("{M}")#text(" to a Euclidean space ")#mi("{{\\bf R}^d}")#text(".")
]

#text("In fact, if ")#mi("{M}")#text(" is ")#mi("{n}")#text("-dimensional, one can take ")#mi("{d}")#text(" to equal ")#mi("{2n}")#text(", which is often best possible (easy examples include the circle ")#mi("{{\\bf R}/{\\bf Z}}")#text(" which embeds into ")#mi("{{\\bf R}^2}")#text(" but not ")#mi("{{\\bf R}^1}")#text(", or the Klein bottle that embeds into ")#mi("{{\\bf R}^4}")#text(" but not ")#mi("{{\\bf R}^3}")#text("). One can also relax the compactness hypothesis on ")#mi("{M}")#text(" to second countability, but we will not pursue this extension here. We give a “cheap” proof of this theorem below the fold which allows one to take ")#mi("{d}")#text(" equal to ")#mi("{2n+1}")#text(".")

#text("A significant strengthening of the Whitney embedding theorem is (a special case of) the ")#link("https://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("Nash embedding theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Nash embedding theorem)")]#text(" ")#metadata(none) <tao-bb527b1ed178e754edcf>#text(" Let ")#mi("{(M,g)}")#text(" be a compact ")#emph[#text("Riemannian")]#text(" manifold. Then there exists a ")#link("https://en.wikipedia.org/wiki/Isometric_embedding")[#text("isometric embedding")]#text(" ")#mi("{u: M \\rightarrow {\\bf R}^d}")#text(" from ")#mi("{M}")#text(" to a Euclidean space ")#mi("{{\\bf R}^d}")#text(".")
]

#text("In order to obtain the isometric embedding, the dimension ")#mi("{d}")#text(" has to be a bit larger than what is needed for the Whitney embedding theorem; in ")#link("http://www.ams.org/mathscinet-getitem?mr=1159298")[#text("this article of Gunther")]#text(" the bound ")#metadata(none) <tao-36a4c607b55e51dac83d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("d = \\max( n(n+5)/2, n(n+3)/2 + 5)")]]



#text(" is attained, which I believe is still the record for large ")#mi("{n}")#text(". (In the converse direction, one cannot do better than ")#mi("{d = \\frac{n(n+1)}{2}}")#text(", basically because this is the number of degrees of freedom in the Riemannian metric ")#mi("{g}")#text(".) Nash’s original proof of theorem used what is now known as ")#link("https://en.wikipedia.org/wiki/Nash%E2%80%93Moser_theorem")[#text("Nash-Moser inverse function theorem")]#text(", but a subsequent ")#link("http://www.ams.org/mathscinet-getitem?mr=1159298")[#text("simplification of Gunther")]#text(" allowed one to proceed using just the ordinary inverse function theorem (in Banach spaces).")

#text("I ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("recently had the need")]#text(" to invoke the Nash embedding theorem to establish a blowup result for a nonlinear wave equation, which motivated me to go through the proof of the theorem more carefully. Below the fold I give a proof of the theorem that does not attempt to give an optimal value of ")#mi("{d}")#text(", but which hopefully isolates the main ideas of the argument (as simplified by Gunther). One advantage of not optimising in ")#mi("{d}")#text(" is that it allows one to freely exploit the very useful tool of ")#emph[#text("pairing")]#text(" together two maps ")#mi("{u_1: M \\rightarrow {\\bf R}^{d_1}}")#text(", ")#mi("{u_2: M \\rightarrow {\\bf R}^{d_2}}")#text(" to form a combined map ")#mi("{(u_1,u_2): M \\rightarrow {\\bf R}^{d_1+d_2}}")#text(" that can be closer to an embedding or an isometric embedding than the original maps ")#mi("{u_1,u_2}")#text(". This lets one perform a “divide and conquer” strategy in which one first starts with the simpler problem of constructing some “partial” embeddings of ")#mi("{M}")#text(" and then pairs them together to form a “better” embedding.")

#text("In preparing these notes, I found the articles ")#link("http://www.deaneyang.com/papers/gunther.pdf")[#text("of Deane Yang")]#text(" and ")#link("http://www.math.mcgill.ca/gantumur/math580f12/siyuan.lu.pdf")[#text("of Siyuan Lu")]#text(" to be helpful.")

#metadata(none) <tao-aafe9f6f4c963f4dc1a8>

#heading(level: 1)[#strong[#text(" — 1. The Whitney embedding theorem — ")]]

#text("To prove the Whitney embedding theorem, we first prove a weaker version in which the embedding is replaced by an ")#link("https://en.wikipedia.org/wiki/Immersion_(mathematics)")[#text("immersion")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Weak Whitney embedding theorem)")]#text(" Let ")#mi("{M}")#text(" be a compact manifold. Then there exists an immersion ")#mi("{u: M \\rightarrow {\\bf R}^d}")#text(" from ")#mi("{M}")#text(" to a Euclidean space ")#mi("{{\\bf R}^d}")#text(".")
]

#emph[#text("Proof:")]#text(" Our objective is to construct a map ")#mi("{u: M \\rightarrow {\\bf R}^d}")#text(" such that the derivatives ")#mi("{\\partial_\\alpha u(x)}")#text(" are linearly independent in ")#mi("{{\\bf R}^d}")#text(" for each ")#mi("{x \\in M}")#text(". For any given point ")#mi("{x_0 \\in M}")#text(", we have a coordinate chart ")#mi("{\\phi_{x_0}: U_{x_0} \\rightarrow {\\bf R}^n}")#text(" from some neighbourhood ")#mi("{U_{x_0}}")#text(" of ")#mi("{x_0}")#text(" to ")#mi("{{\\bf R}^n}")#text(". If we set ")#mi("{u_{x_0}: M \\rightarrow {\\bf R}^n}")#text(" to be ")#mi("{\\phi_{x_0}}")#text(" multiplied by a suitable cutoff function supported near ")#mi("{x_0}")#text(", we see that ")#mi("{u_{x_0}}")#text(" is an immersion in a neighbourhood of ")#mi("{x_0}")#text(". Pairing together finitely many of the ")#mi("{u_{x_0}}")#text(" and using compactness, we obtain the claim. ")#mi("\\Box")

#text("Now we upgrade the immersion ")#mi("{u}")#text(" from the above theorem to an embedding by further use of pairing. First observe that as ")#mi("{M}")#text(" is smooth and compact, an embedding is nothing more than an immersion that is injective. Let ")#mi("{u: M \\rightarrow {\\bf R}^d}")#text(" be an immersion. Let ")#mi("{\\Sigma \\subset M \\times M}")#text(" be the set of pairs ")#mi("{(x_1,x_2)}")#text(" of distinct points ")#mi("{(x_1,x_2)\\in M}")#text(" such that ")#mi("{u(x_1)=u(x_2)}")#text("; note that this set is compact since ")#mi("{u}")#text(" is an immersion (and so there is no failure of injectivity when ")#mi("{(x_1,x_2)}")#text(" is near the diagonal). If ")#mi("{\\Sigma}")#text(" is empty then ")#mi("{u}")#text(" is injective and we are done. If ")#mi("{\\Sigma}")#text(" contains a point ")#mi("{(x_1,x_2)}")#text(", then by pairing ")#mi("{u}")#text(" with some scalar function ")#mi("{\\eta: M \\rightarrow {\\bf R}}")#text(" that separates ")#mi("{x_1}")#text(" and ")#mi("{x_2}")#text(", we can replace ")#mi("{u}")#text(" by another immersion (in one higher dimension ")#mi("{{\\bf R}^{d+1}}")#text(") such that a neighbourhood of ")#mi("{x_1}")#text(" and a neighbourhood of ")#mi("{x_2}")#text(" get mapped to disjoint sets, thus effectively removing an open neighbourhood of ")#mi("{(x_1,x_2)}")#text(" from ")#mi("{\\Sigma}")#text(". Repeating these procedures finitely many times, using the compactness of ")#mi("{\\Sigma}")#text(", we end up with an immersion which is injective, giving the Whitney embedding theorem.")

#text("At present, the embedding ")#mi("{u: M \\rightarrow {\\bf R}^d}")#text(" of an ")#mi("{n}")#text("-dimensional compact manifold ")#mi("{M}")#text(" could be extremely high dimensional. However, if ")#mi("{d > 2n+1}")#text(", then it is possible to project ")#mi("{u}")#text(" from ")#mi("{{\\bf R}^d}")#text(" to ")#mi("{{\\bf R}^{d-1}}")#text(" by the random projection trick (discussed in ")#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("this previous post")]#text("). Indeed, if one picks a random element ")#mi("{\\omega \\in S^{d-1}}")#text(" of the unit sphere, and then lets ")#mi("{T: {\\bf R}^d \\rightarrow \\omega^\\perp}")#text(" be the (random) orthogonal projection to the hyperplane ")#mi("{\\omega^\\perp}")#text(" orthogonal to ")#mi("{\\omega}")#text(", then it is geometrically obvious that ")#mi("{T \\circ u: M \\rightarrow \\omega^\\perp}")#text(" will remain an embedding unless ")#mi("{\\omega}")#text(" either is of the form ")#tao-math("{\\pm \\frac{u(x)-u(y)}{\\left\\|u(x)-u(y)\\right\\|}}", block: false)#text(" for some distinct ")#mi("{x,y \\in M}")#text(", or lies in the tangent plane to ")#mi("{u(M)}")#text(" at ")#mi("{u(x)}")#text(" for some ")#mi("{x \\in M}")#text(". But the set of all such excluded ")#mi("{\\omega}")#text(" is of dimension at most ")#mi("{2n}")#text(" (using, for instance, the Hausdorff notion of dimension), and so for ")#mi("{d > 2n+1}")#text(" almost every ")#mi("{\\omega}")#text(" in ")#mi("{S^{d-1}}")#text(" will avoid this set. Thus one can use these projections to cut the dimension ")#mi("{d}")#text(" down by one for ")#mi("{d>2n+1}")#text("; iterating this observation we can end up with the final value of ")#mi("{d=2n+1}")#text(" for the Whitney embedding theorem.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The Whitney embedding theorem for ")#mi("{d=2n}")#text(" is more difficult to prove. Using the random projection trick, one can arrive at an immersion ")#mi("{u: M \\rightarrow {\\bf R}^{2n}}")#text(" which is injective except at a finite number of “double points” where ")#mi("{u(M)}")#text(" meets itself transversally (think of projecting a knot in ")#mi("{{\\bf R}^3}")#text(" randomly down to ")#mi("{{\\bf R}^2}")#text("). One then needs to “push” the double points out of existence using a device known as the “Whitney trick”.")
]

#heading(level: 1)[#strong[#text(" — 2. Reduction to a local isometric embedding theorem — ")]]

#text("We now begin the proof of the Nash embedding theorem. In this section we make a series of reductions that reduce the “global” problem of isometric embedding a compact manifold to a “local” problem of turning a near-isometric embedding of a torus into a true isometric embedding.")

#text("We first make a convenient (though not absolutely necessary) reduction: in order to prove Theorem ")#link(<tao-bb527b1ed178e754edcf>)[#text("2")]#text(", it suffices to do so in the case when ")#mi("{M}")#text(" is a torus ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" (equipped with some metric ")#mi("{g}")#text(" which is not necessarily flat). Indeed, if ")#mi("{M}")#text(" is not a torus, we can use the Whitney embedding theorem to embed ")#mi("{M}")#text(" (non-isometrically) into some Euclidean space ")#mi("{{\\bf R}^m}")#text(", which by rescaling and then quotienting out by ")#mi("{{\\bf Z}^m}")#text(" lets one assume without loss of generality that ")#mi("{M}")#text(" is some submanifold of a torus ")#mi("{({\\bf R}/{\\bf Z})^m}")#text(" equipped with some metric ")#mi("{g}")#text(". One can then use a smooth version of the Tietze extension theorem to extend the metric ")#mi("{g}")#text(" smoothly from ")#mi("{M}")#text(" to all of ")#mi("{({\\bf R}/{\\bf Z})^m}")#text("; this extended metric ")#mi("{\\tilde g}")#text(" will remain positive definite in some neighbourhood of ")#mi("{M}")#text(", so by using a suitable (smooth) partition of unity and taking a convex combination of ")#mi("{\\tilde g}")#text(" with the flat metric on ")#mi("{({\\bf R}/{\\bf Z})^m}")#text(", one can find another extension ")#mi("{g^{\\prime}}")#text(" of ")#mi("{g}")#text(" to ")#mi("{({\\bf R}/{\\bf Z})^m}")#text(" that remains positive definite (and symmetric) on all of ")#mi("{({\\bf R}/{\\bf Z})^m}")#text(", giving rise to a Riemannian torus ")#mi("{(({\\bf R}/{\\bf Z})^{m}, g^{\\prime})}")#text(". Any isometric embedding of this torus into ")#mi("{{\\bf R}^d}")#text(" will induce an isometric embedding of the original manifold ")#mi("{M}")#text(", completing the reduction.")

#text("The main advantage of this reduction to the torus case is that it gives us a global system of (periodic) coordinates on ")#mi("{M}")#text(", so that we no longer need to work with local coordinate charts. Also, one can easily use Fourier analysis on the torus to verify the ellipticity properties of the Laplacian that we will need later in the proof. These are however fairly minor conveniences, and it would not be difficult to continue the argument below without having first reduced to the torus case.")

#text("Henceforth our manifold ")#mi("{M}")#text(" is assumed to be the torus ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" equipped with a Riemannian metric ")#mi("{g = g_{\\alpha \\beta}}")#text(", where the indices ")#mi("{\\alpha,\\beta}")#text(" run from ")#mi("{1}")#text(" to ")#mi("{n}")#text(". Our task is to find an injective map ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" which is isometric in the sense that it obeys the system of partial differential equations")

#align(center)[#tao-fit-display[#mitex("\\partial_\\alpha u \\cdot \\partial_\\beta u = g_{\\alpha \\beta}")]]

#text("for ")#mi("{\\alpha,\\beta=1,\\dots,n}")#text(", where ")#mi("{\\cdot}")#text(" denotes the usual dot product on ")#mi("{{\\bf R}^d}")#text(". Let us write this equation as")

#align(center)[#tao-fit-display[#mitex("Q(u) = g")]]

#text("where ")#mi("{Q(u)}")#text(" is the symmetric tensor")

#align(center)[#tao-fit-display[#mitex("Q(u)_{\\alpha \\beta} := \\partial_\\alpha u \\cdot \\partial_\\beta u.")]]

#text("The operator ")#mi("{Q}")#text(" is a nonlinear differential operator, but it behaves very well with respect to pairing: ")#metadata(none) <tao-f9f5cf73e6038b91418b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("Q( (u_1,u_2) ) = Q(u_1) + Q(u_2).")]]



#text(" We can use ")#link(<tao-f9f5cf73e6038b91418b>)[#text("(2)")]#text(" to obtain a number of very useful reductions (at the cost of worsening the eventual value of ")#mi("{d}")#text(", which as stated in the introduction we will not be attempting to optimise). First we claim that we can drop the injectivity requirement on ")#mi("{u}")#text(", that is to say it suffices to show that every Riemannian metric ")#mi("{g}")#text(" on ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" is of the form ")#mi("{g = Q(u)}")#text(" for some map ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" into some Euclidean space ")#mi("{{\\bf R}^d}")#text(". Indeed, suppose that this were the case. Let ")#mi("{u_1: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" be any (not necessarily isometric) embedding (the existence of which is guaranteed by the Whitney embedding theorem; alternatively, one can use the usual exponential map ")#mi("{\\theta \\mapsto (\\cos \\theta, \\sin \\theta)}")#text(" to embed ")#mi("{{\\bf R}/{\\bf Z}}")#text(" into ")#mi("{{\\bf R}^2}")#text("). For ")#mi("{\\varepsilon>0}")#text(" small enough, the map ")#mi("{\\varepsilon u_1}")#text(" is ")#link("https://en.wikipedia.org/wiki/Metric_map")[#text("short")]#text(" in the sense that ")#mi("{Q(\\varepsilon u_1) < g}")#text(" pointwise in the sense of symmetric tensors (or equivalently, the map ")#mi("{\\varepsilon u_1}")#text(" is a contraction from ")#mi("{(M,g)}")#text(" to ")#mi("{{\\bf R}^d}")#text("). For such an ")#mi("{\\varepsilon}")#text(", we can write ")#mi("{g = Q(\\varepsilon u_1) + g^{\\prime}}")#text(" for some Riemannian metric ")#mi("{g^{\\prime}}")#text(". If we then write ")#mi("{g^{\\prime} = Q(u^{\\prime})}")#text(" for some (not necessarily injective) map ")#mi("{u^{\\prime}: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^{d^{\\prime}}}")#text(", then from ")#link(<tao-f9f5cf73e6038b91418b>)[#text("(2)")]#text(" we see that ")#mi("{g = Q( (\\varepsilon u_1, u^{\\prime}) )}")#text("; since ")#mi("{(\\varepsilon u_1, u^{\\prime})}")#text(" inherits its injectivity from the component map ")#mi("{u_1}")#text(", this gives the desired isometric embedding.")

#text("Call a metric ")#mi("{g}")#text(" on ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" ")#emph[#text("good")]#text(" if it is of the form ")#mi("{Q(u)}")#text(" for some map ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" into a Euclidean space ")#mi("{{\\bf R}^d}")#text(". Our task is now to show that every metric is good; the relation ")#link(<tao-f9f5cf73e6038b91418b>)[#text("(2)")]#text(" tells us that the sum of any two good metrics is good.")

#text("In order to make the local theory work later, it will be convenient to introduce the following notion: a map ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" is said to be ")#emph[#text("free")]#text(" if, for every point ")#mi("{x \\in ({\\bf R}/{\\bf Z})^n}")#text(", the ")#mi("{n}")#text(" vectors ")#mi("{\\partial_\\alpha u(x)}")#text(", ")#mi("{\\alpha=1,\\dots,n}")#text(" and the ")#mi("{\\frac{n(n+1)}{2}}")#text(" vectors ")#mi("{\\partial_\\alpha \\partial_\\beta u(x)}")#text(", ")#mi("{1 \\leq \\alpha \\leq \\beta \\leq n}")#text(" are all linearly independent; equivalently, given a further map ")#mi("{v: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(", there are no dependencies whatsoever between the ")#mi("{n + \\frac{n(n+1)}{2}}")#text(" scalar functions ")#mi("{\\partial_\\alpha u \\cdot v}")#text(", ")#mi("{\\alpha=1,\\dots,n}")#text(" and ")#mi("{\\partial_{\\alpha \\beta} u \\cdot v}")#text(", ")#mi("{1 \\leq \\alpha \\leq \\beta \\leq n}")#text(". Clearly, a free map into ")#mi("{{\\bf R}^d}")#text(" is only possible for ")#mi("{d \\geq n + \\frac{n(n+1)}{2}}")#text(", and this explains the bulk of the formula ")#link(<tao-36a4c607b55e51dac83d>)[#text("(1)")]#text(" of the best known value of ")#mi("{d}")#text(".")

#text("For any natural number ")#mi("{m}")#text(", the “Veronese embedding” ")#mi("{\\iota: {\\bf R}^m \\rightarrow {\\bf R}^{m + \\frac{m(m+1)}{2}}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\iota(x_1,\\dots,x_m) := ( (x_\\alpha)_{1 \\leq \\alpha \\leq m}, (x_\\alpha x_\\beta)_{1 \\leq \\alpha \\leq \\beta \\leq m} )")]]

#text("can easily be verified to be free. From this, one can construct a free map ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^{m + \\frac{m(m+1)}{2}}}")#text(" by starting with an arbitrary immersion ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^m}")#text(" and composing it with the Veronese embedding (the fact that the composition is free will follow after several applications of the chain rule).")

#text("Given a Riemannian metric ")#mi("{g}")#text(", one can find a free map ")#mi("{u}")#text(" which is ")#emph[#text("short")]#text(" in the sense that ")#mi("{Q(u) < g}")#text(", by taking an arbitrary free map and scaling it down by some small scaling factor ")#mi("{\\varepsilon>0}")#text(". This gives us a decomposition")

#align(center)[#tao-fit-display[#mitex("g = Q(u) + g^{\\prime}")]]

#text("for some Riemannian metric ")#mi("{g^{\\prime}}")#text(".")

#text("The metric ")#mi("{Q(u)}")#text(" is clearly good, so by ")#link(<tao-f9f5cf73e6038b91418b>)[#text("(2)")]#text(" it would suffice to show that ")#mi("{g^{\\prime}}")#text(" is good. What is easy to show is that ")#mi("{g^{\\prime}}")#text(" is ")#emph[#text("approximately good")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 5")]#text(" ")#metadata(none) <tao-ce552f91e9dc79133d2c>#text(" Let ")#mi("{g^{\\prime}}")#text(" be a Riemannian metric on ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(". Then there exists a smooth symmetric tensor ")#mi("{h}")#text(" on ")#mi("{({\\bf R}/{\\bf Z})^n}")#text(" with the property that ")#mi("{g^{\\prime} + \\varepsilon^2 h}")#text(" is good for every ")#mi("{\\varepsilon>0}")#text(".")
]

#emph[#text("Proof:")]#text(" Roughly speaking, the idea here is to use “tightly wound spirals” to capture various “rank one” components of the metric ")#mi("{g^{\\prime}}")#text(", the point being that if a map ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" “oscillates” at some high frequency ")#mi("{\\xi \\in {\\bf R}^n}")#text(" with some “amplitude” ")#mi("{A}")#text(", then ")#mi("{Q(u)}")#text(" is approximately equal to the rank one tensor ")#mi("{A \\xi_\\alpha \\xi_\\beta}")#text(". The argument here is related to the technique of ")#emph[#text("convex integration")]#text(", which among other things leads to one way to establish the ")#link("https://en.wikipedia.org/wiki/Homotopy_principle")[#mi("{h}")#text("-principle")]#text(" of Gromov.")

#text("By the spectral theorem, every positive definite tensor ")#mi("{g_{\\alpha \\beta}}")#text(" can be written as a positive linear combination of symmetric rank one tensors ")#mi("{v_\\alpha v_\\beta}")#text(" for some vector ")#mi("{v \\in {\\bf R}^n}")#text(". By adding some additional rank one tensors if necessary, one can make this decomposition stable, in the sense that any nearby tensor ")#mi("{g_{\\alpha \\beta}}")#text(" is also a positive linear combination of the ")#mi("{v_\\alpha v_\\beta}")#text(". One can think of ")#mi("{v_\\alpha}")#text(" as the gradient ")#mi("{\\partial_\\alpha \\psi}")#text(" of some linear function ")#mi("{\\psi: {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(". Using compactness and a smooth partition of unity, one can then arrive at a decomposition")

#align(center)[#tao-fit-display[#mitex("g^{\\prime}_{\\alpha \\beta} = \\sum_{i=1}^m (\\eta^{(i)})^2 \\partial_\\alpha \\psi^{(i)} \\partial_\\beta \\psi^{(i)}")]]

#text("for some finite ")#mi("{m}")#text(", some smooth scalar functions ")#mi("{\\eta^{(i)}, \\psi^{(i)}: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}}")#text(" (one can take ")#mi("{\\psi^{(i)}}")#text(" to be linear functions on small coordinate charts, and ")#mi("{\\eta^{(i)}}")#text(" to basically be cutoffs to these charts).")

#text("For any ")#mi("{\\varepsilon>0}")#text(" and ")#mi("{i=1,\\dots,m}")#text(", consider the “spiral” map ")#mi("{u_\\varepsilon^{(i)}: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^2}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("u_\\varepsilon^{(i)} := \\varepsilon \\eta^{(i)} ( \\cos( \\frac{\\psi^{(i)}}{\\varepsilon} ), \\sin( \\frac{\\psi^{(i)}}{\\varepsilon} ) )")]]

#text("Direct computation shows that")

#tao-aligned(keep: true)[


#tao-math("Q(u_\\varepsilon^{(i)})_{\\alpha \\beta}  & = (\\eta^{(i)})^2 \\partial_\\alpha \\psi^{(i)} \\partial_\\beta \\psi^{(i)}", block: true)



#tao-math(" & + \\varepsilon^2 \\eta^{(i)}_\\alpha \\eta^{(i)}_\\beta", block: true)
]

#text("and the claim follows by summing in ")#mi("{i}")#text(" (using ")#link(<tao-f9f5cf73e6038b91418b>)[#text("(2)")]#text(") and taking ")#mi("{h := \\sum_{i=1}^m \\eta^{(i)}_\\alpha \\eta^{(i)}_\\beta}")#text(". ")#mi("\\Box")

#text("The claim then reduces to the following local (perturbative) statement, that shows that the property of being good is stable around a free map:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Local embedding)")]#text(" ")#metadata(none) <tao-770e607624d689265ca6>#text(" Let ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" be a free map. Then ")#mi("{Q(u)+h}")#text(" is good for all symmetric tensors ")#mi("{h}")#text(" sufficiently close to zero in the ")#mi("{C^\\infty}")#text(" topology.")
]

#text("Indeed, assuming Theorem ")#link(<tao-770e607624d689265ca6>)[#text("6")]#text(", and with ")#mi("{h}")#text(" as in Proposition ")#link(<tao-ce552f91e9dc79133d2c>)[#text("5")]#text(", we have ")#mi("{Q(u) - \\varepsilon^2 h}")#text(" good for ")#mi("{\\varepsilon}")#text(" small enough. By ")#link(<tao-f9f5cf73e6038b91418b>)[#text("(2)")]#text(" and Proposition ")#link(<tao-ce552f91e9dc79133d2c>)[#text("5")]#text(", we then have ")#mi("{g = (Q(u) - \\varepsilon^2 h) + (g^{\\prime} + \\varepsilon^2 h)}")#text(" good, as required.")

#text("The remaining task is to prove Theorem ")#link(<tao-770e607624d689265ca6>)[#text("6")]#text(". This is a problem in perturbative PDE, to which we now turn.")

#heading(level: 1)[#strong[#text(" — 3. Proof of local embedding — ")]]

#text("We are given a free map ")#mi("{u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" and a small tensor ")#mi("{h}")#text(". It will suffice to find a perturbation ")#mi("{u+v: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" of ")#mi("{u}")#text(" that solves the PDE")

#align(center)[#tao-fit-display[#mitex("Q(u+v) = Q(u) + h.")]]

#text("We can expand the left-hand side and cancel off ")#mi("{Q(u)}")#text(" to write this as ")#metadata(none) <tao-f136cd2b5205eca54350>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("L(v)= h - Q(v)")]]



#text(" where the symmetric tensor-valued first-order linear operator ")#mi("{L}")#text(" is defined (in terms of the fixed free map ")#mi("{u}")#text(") as")

#align(center)[#tao-fit-display[#mitex("L(v)_{\\alpha \\beta} := \\partial_\\alpha u \\partial_\\beta v + \\partial_\\beta u \\partial_\\alpha v.")]]

#text("To exploit the free nature of ")#mi("{u}")#text(", we would like to write the operator ")#mi("{L}")#text(" in terms of the inner products ")#mi("{\\partial_\\alpha u \\cdot v}")#text(" and ")#mi("{\\partial_{\\alpha \\beta} u \\cdot v}")#text(". After some rearranging using the product rule, we arrive at the representation")

#align(center)[#tao-fit-display[#mitex("L(v) = \\partial_\\beta ( \\partial_\\alpha u \\cdot v) + \\partial_\\alpha( \\partial_\\beta u \\cdot v ) - 2 \\partial_{\\alpha \\beta} u \\cdot v.")]]

#text("Among other things, this allows for a way to right-invert the underdetermined linear operator ")#mi("{L}")#text(". As ")#mi("{u}")#text(" is free, we can use Cramer’s rule to find smooth maps ")#mi("{w_{\\alpha \\beta}: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" for ")#mi("{\\alpha,\\beta=1,\\dots,n}")#text(" (with ")#mi("{w_{\\alpha \\beta} = w_{\\beta \\alpha}}")#text(") that is dual to ")#mi("{\\partial_{\\alpha \\beta} u}")#text(" in the sense that")

#tao-aligned(keep: true)[


#tao-math("\\partial_\\alpha u \\cdot w_{\\alpha^{\\prime} \\beta^{\\prime}}  & = 0", block: true)



#tao-math("\\partial_{\\alpha \\beta} u \\cdot w_{\\alpha^{\\prime} \\beta^{\\prime}}  & = \\delta_{\\alpha \\alpha^{\\prime}} \\delta_{\\beta \\beta^{\\prime}} + \\delta_{\\alpha \\beta^{\\prime}} \\delta_{\\beta \\alpha^{\\prime}}", block: true)
]

#text("where ")#mi("{\\delta}")#text(" denotes the Kronecker delta. If one then defines the linear zeroth-order operator ")#mi("{M}")#text(" from symmetric tensors ")#mi("{f = f_{\\alpha \\beta}}")#text(" to maps ")#mi("{Mf: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("Mf := -\\frac{1}{4} \\sum_{1 \\leq \\alpha,\\beta \\leq n} f_{\\alpha \\beta} w_{\\alpha \\beta}")]]

#text("then direct computation shows that ")#mi("{LMf = f}")#text(" for any sufficiently regular ")#mi("{F}")#text(". As a consequence of this, one could try to use the ansatz ")#mi("{v = Mf}")#text(" and transform the equation ")#link(<tao-f136cd2b5205eca54350>)[#text("(3)")]#text(" to the fixed point equation ")#metadata(none) <tao-65a43d67eb9316856831>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f = h - Q(Mf).")]]



#text(" One can hope to solve this equation by standard perturbative techniques, such as the inverse function theorem or the contraction mapping theorem, hopefully exploiting the smallness of ")#mi("{h}")#text(" to obtain the required contraction. Unfortunately we run into a fundamental ")#emph[#text("loss of derivatives problem")]#text(", in that the quadratic differential operator ")#mi("{Q}")#text(" loses a degree of regularity, and this loss is not recovered by the operator ")#mi("{M}")#text(" (which has no smoothing properties).")

#text("We know of two ways around this difficulty. The original argument of Nash used what is now known as the ")#link("https://en.wikipedia.org/wiki/Nash%E2%80%93Moser_theorem")[#text("Nash-Moser iteration scheme")]#text(" to overcome the loss of derivatives by replacing the simple iterative scheme used in the contraction mapping theorem with a much more rapidly convergent scheme that generalises ")#link("https://en.wikipedia.org/wiki/Newton%27s_method")[#text("Newton’s method")]#text("; see ")#link("https://terrytao.wordpress.com/2015/04/14/newton-iteration-and-the-siegel-linearisation-theorem/")[#text("this previous blog post")]#text(" for a similar idea. The other way out, due to Gunther, is to observe that ")#mi("{Q(v)}")#text(" can be factored as ")#metadata(none) <tao-41a093100bbbb59e31dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("Q(v) = L Q_0(v)")]]



#text(" where ")#mi("{Q_0}")#text(" is a ")#emph[#text("zeroth order")]#text(" quadratic operator ")#mi("{Q_0}")#text(", so that ")#link(<tao-f136cd2b5205eca54350>)[#text("(3)")]#text(" can be written instead as")

#align(center)[#tao-fit-display[#mitex("L( v + Q_0(v) ) = h,")]]

#text("and using the right-inverse ")#mi("{M}")#text(", it now suffices to solve the equation ")#metadata(none) <tao-b52ee3a44bd6d803d75b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("v = Mh - Q_0(v)")]]



#text(" (compare with ")#link(<tao-65a43d67eb9316856831>)[#text("(4)")]#text("), which can be done perturbatively if ")#mi("{Q_0}")#text(" is indeed zeroth order (e.g. if it is bounded on Hölder spaces such as ")#mi("{C^{2,\\alpha}}")#text(").")

#text("It remains to achieve the desired factoring ")#link(<tao-41a093100bbbb59e31dc>)[#text("(5)")]#text(". We can bilinearise ")#mi("{Q(v)}")#text(" as ")#mi("{\\frac{1}{2} B(v,v)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("B(v,w)_{\\alpha \\beta} := \\partial_\\alpha v \\cdot \\partial_\\beta w + \\partial_\\beta v \\cdot \\partial_\\alpha w.")]]

#text("The basic point is that when ")#mi("{v}")#text(" is much higher frequency than ")#mi("{w}")#text(", then ")#metadata(none) <tao-160e3d1804c75a22f437>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("B(v,w)_{\\alpha \\beta} \\approx \\partial_\\alpha ( v \\cdot \\partial_\\beta w ) + \\partial_\\beta ( v \\cdot \\partial_\\alpha w )")]]



#text(" which can be approximated by ")#mi("{L}")#text(" applied to some quantity relating to the vector field ")#mi("{v \\cdot \\partial_\\beta w}")#text("; similarly if ")#mi("{w}")#text(" is much higher frequency than ")#mi("{v}")#text(". One can formalise these notions of “much higher frequency” using the machinery of ")#link("https://en.wikipedia.org/wiki/Paraproduct")[#text("paraproducts")]#text(", but one can proceed in a slightly more elementary fashion by using the Laplacian operator ")#mi("{\\Delta = \\sum_{\\alpha=1}^n \\partial_{\\alpha \\alpha}}")#text(" and its (modified) inverse operator ")#mi("{(1-\\Delta)^{-1}}")#text(" (which is easily defined on the torus using the Fourier transform, and has good smoothing properties) as a substitute for the paraproduct calculus. We begin by writing")

#align(center)[#tao-fit-display[#mitex("Q(v) = \\frac{1}{2} B(v,v) = \\frac{1}{2} (1 - \\Delta)^{-1} ( B(v,v) - \\Delta B(v,v) ).")]]

#text("The dangerous term here is ")#mi("{\\Delta B(v,v)}")#text(". Using the product rule and symmetry, we can write")

#align(center)[#tao-fit-display[#mitex("\\Delta B(v,v) = 2 B(\\Delta v, v) + 2 \\sum_{\\gamma=1}^n B(\\partial_\\gamma v, \\partial_\\gamma v).")]]

#text("The second term will be “lower order” in that it only involves second derivatives of ")#mi("{v}")#text(", rather than third derivatives. As for the higher order term ")#mi("{B(\\Delta v, v)}")#text(", the main contribution will come from the terms where ")#mi("{\\Delta v}")#text(" is higher frequency than ")#mi("{v}")#text(" (since the Laplacian accentuates high frequencies and dampens low frequencies, as can be seen by inspecting the Fourier symbol of the Laplacian). As such, we can profitably use the approximation ")#link(<tao-160e3d1804c75a22f437>)[#text("(7)")]#text(" here. Indeed, from the product rule we have")

#align(center)[#tao-fit-display[#mitex("B(\\Delta v, v)_{\\alpha \\beta} = \\partial_\\alpha ( \\Delta v \\cdot \\partial_\\beta v) + \\partial_\\beta (\\Delta v \\cdot \\partial_\\alpha v) - 2 \\Delta v \\cdot \\partial_{\\alpha \\beta} v.")]]

#text("Putting all this together, we obtain the decomposition")

#align(center)[#tao-fit-display[#mitex("Q(v)_{\\alpha \\beta} = \\partial_\\alpha Q_\\beta(v) + \\partial_\\beta Q_\\alpha(v) + Q^{\\prime}_{\\alpha \\beta}(v)")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("Q_\\alpha(v) := - (1-\\Delta)^{-1} ( \\Delta v \\cdot \\partial_\\alpha v )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("Q^{\\prime}_{\\alpha \\beta}(v) := (1-\\Delta)^{-1} ( \\frac{1}{2} B(v,v)_{\\alpha \\beta} - \\sum_{\\gamma=1}^n B(\\partial_\\gamma v, \\partial_\\gamma v)_{\\alpha \\beta} + 2 \\Delta v \\cdot \\partial_{\\alpha \\beta} v ).")]]

#text("If we then use Cramer’s rule to create smooth functions ")#mi("{w_\\alpha}")#text(" dual to the ")#mi("{\\partial_\\alpha u}")#text(" in the sense that")

#tao-aligned(keep: true)[


#tao-math("\\partial_\\alpha u \\cdot w_{\\alpha^{\\prime}}  & = \\delta_{\\alpha \\alpha^{\\prime}}", block: true)



#tao-math("\\partial_{\\alpha \\beta} u \\cdot w_{\\alpha^{\\prime} \\beta^{\\prime}}  & = 0", block: true)
]

#text("then we obtain the desired factorisation ")#link(<tao-41a093100bbbb59e31dc>)[#text("(5)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("Q_0(v) := \\sum_{\\alpha=1}^n Q_\\alpha(v) w_\\alpha - \\frac{1}{4} \\sum_{1 \\leq \\alpha,\\beta \\leq n} Q^{\\prime}_{\\alpha \\beta} w_{\\alpha \\beta}.")]]

#text("Note that ")#mi("{Q_0(v)}")#text(" is the smoothing operator ")#mi("{(1-\\Delta)^{-1}}")#text(" applied to quadratic expressions of up to two derivatives of ")#mi("{v}")#text(". As such, one can show using elliptic (")#link("https://en.wikipedia.org/wiki/Schauder_estimates")[#text("Schauder")]#text(") estimates to show that ")#mi("{Q_0}")#text(" is Lipschitz continuous in the Holder spaces ")#mi("{C^{2,\\alpha}(({\\bf R}/{\\bf Z})^n)}")#text(" for ")#mi("{0 < \\alpha < 1}")#text(" (with the Lipschitz constant being small when ")#mi("{v}")#text(" has small norm); this together with the contraction mapping theorem in the Banach space ")#mi("{C^{2,\\alpha}}")#text(" is already enough to solve the equation ")#link(<tao-b52ee3a44bd6d803d75b>)[#text("(6)")]#text(" in this space if ")#mi("{h}")#text(" is small enough. This is not quite enough because we also need ")#mi("{v}")#text(" to be smooth; but it is possible (using Schauder estimates and product Hölder estimates) to establish bounds of the form")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Q_0(v) \\right\\|_{C^{k,\\alpha}} \\lesssim \\left\\| v \\right\\|_{C^{k,\\alpha}} \\left\\|v\\right\\|_{C^{2,\\alpha}} + O_k( \\left\\|v\\right\\|_{C^{k-1,\\alpha}}^2 )", block: true)]]

#text("for any ")#mi("{k \\geq 2}")#text(" (with implied constants depending on ")#mi("{\\alpha,u}")#text(" but independent of ")#mi("{k}")#text("), which can be used (for ")#mi("{k}")#text(" small enough) to show that the solution ")#mi("{v}")#text(" constructed by the contraction mapping principle lies in ")#mi("{C^{k,\\alpha}}")#text(" for any ")#mi("{k \\geq 2}")#text(" (by showing that the iterates used in the construction remain bounded in these norms), and is thus smooth.")

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468530")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("Does theorem 2 imply that space-time around a star can be imbedded in some higher dimensional euclidean space?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468549")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("Spacetime is pseudo-Riemannian rather than Riemannian, and so cannot be embedded in any Riemannian space. I guess the natural conjecture would be that a ")#mi("d+1")#text("-dimensional spacetime may be locally isometrically embedded into some high dimensional Minkowski spacetime, but I don’t know if there are such results in the literature. (Global embedding is unrealistic because the spacetime may contain causal loops, which Minkowski spacetime, which of course doesn’t have any.) There are at least two obstacles to extending the arguments in this post to the pseudo-Riemannian setting: firstly, the Cartesian product of two Minkowski spacetimes is not a Minkowski spacetime, making the pairing operation much less useful; and secondly, the d’Lambertian (the natural analogue of the Laplacian in this setting) is no longer elliptic. But the latter obstacle at least might still be manageable using the original Nash-Moser method, which can tolerate some loss of derivatives in the nonlinearity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ecc1cf3e3f8ae8b35236d7ba48ebc8a97a5a5eccfa020162de288559471cea6-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harshvardhan Tandon")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468552")[#strong[#text("Harshvardhan Tandon")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("Sir I am a high school student and a big fan of yours. I was a bit curious regarding your thoughts about the hotly debated ABC conjecture(about which I believe you must have given some thought). So what do you think about the enormous proof posed by Shinichi Mochizuki?Is it anywhere close to being correct or is it just a pointless and confusing pursuit which will not lead to anything important?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468560")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("This recent post by Brian Conrad is probably the best summary of the current state of affairs: ")#link("https://mathbabe.org/2015/12/15/notes-on-the-oxford-iut-workshop-by-brian-conrad/")[#text("https://mathbabe.org/2015/12/15/notes-on-the-oxford-iut-workshop-by-brian-conrad/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38716e7e6617518d49d923a5f8fa757732fa4c2e639e07b88e2d984484d4faeb-93c048f0d982cd473774eb5a3fe9877d9f53dc86b6518162ad8cfc35cdb803fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Olaf Müller")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-471863")[#strong[#text("Olaf Müller")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("Fortunately, your conjecture has a positive answer Miguel Sánchez and I found some years ago:")

#link("https://arxiv.org/abs/0812.4439")[#text("https://arxiv.org/abs/0812.4439")]

#text("As you say, noncausality is an obstruction to the existence of an isometric embedding into a Minkowski space-time. An equivalent characterization for the existence is the existence of a steep temporal function, i.e. a function whose gradient v satisfies g(v,v) <-1, and such a function exists in every globally hyperbolic space-time. (If we asked for a conformal embedding instead of an isometric one, then the embeddable space-times would be exactly the stably causal ones.)")#linebreak()#text(" Now, if we focus on the local question, then we can use that in every space-time, every point has a globally hyperbolic neighborhood, thus, indeed, the local question is unobstructed.")

#text("Best,")#linebreak()#text(" -olaf.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c452aeb7466293c4d827463d0019c9e7e83db8113210de3cd436ad5a6093b6c-55babe53ec9286a3e73d2949aab1cc1cf2290a7ce6922e82b05f568081353233.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of rogerwest")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-583260")[#strong[#text("rogerwest")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2020")])]

#text("What is meant by “causal” here? And why does it surface here, while the main article doesn’t allude to it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-583835")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2020")])]

#text("Lorenztial spacetimes have ")#link("https://en.wikipedia.org/wiki/Causal_structure")[#text("causal structure")]#text(", but Riemannian manifolds (the focus of the main article) do not.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27d5c0388bffd75334ff76059464937cb908d7aa4c2ecb53b45ae32f168ebf1f-8caf87f26fba616d2171056e55d77d04998ac9e726dc7ea0126c60edcb34098a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lewallen")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468578")[#strong[#text("lewallen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("Thanks a lot for the notes, great reading. I was a bit confused early on until I realized that by “pairing” two functions you meant the cartesian product (is that right?) — I’d never seen that particular terminology. What do you think about making that more explicit (e.g. in the proof of the Whitney immersion theorem)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27d5c0388bffd75334ff76059464937cb908d7aa4c2ecb53b45ae32f168ebf1f-8caf87f26fba616d2171056e55d77d04998ac9e726dc7ea0126c60edcb34098a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lewallen")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468579")[#strong[#text("lewallen")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2016")])]

#text("hah I just noticed that you explicitly defined it in the introduction, in fact it’s a central technique is you point out ;). Ok, sorry about that!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/695d57638ca57345f4568da57218d7ef902274f617b435b93f7a7a6ee888671c-60f312f5658bc8146b4e9c33ecf6e1c89ff08d847d3a7f8c1bb96cdb1199d567.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Bryan")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468598")[#strong[#text("Paul Bryan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("The paragraph on upgrading the weak Whitney theorem to an embedding is a little unclear. The immersion ")#mi("u")#text(" is locally an embedding, so is injective in a neighbourhood of any point. The statement, “if ")#mi("x_1 = x_2")#text(", then ")#mi("u")#text(" is injective on a neighbourhood of ")#mi("x_1")#text("…” is thus a little odd. It may also be helpful to remark that, although an injective immersion is not in general an embedding, for ")#mi("M")#text(" compact, it is since any continuous bijection from a compact space to a Hausdorff space is a homeomorphism.")

#emph[#text("[Text modified, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468625")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2016")])]

#text("nice")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468656")[#strong[#text("Notes on the Nash embedding theorem — What’s new | wendaliblog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2016")]

#text("[…] via Notes on the Nash embedding theorem — What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67ed9732e4b8b3509ad13381ebfc93cfab11595df593fb001c7a76218c3a06a6-f65d67da753b3ef2d4fbf5fedcee96869fb233db04b9ea79e86858b40a792a55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luiz Botelho -Físico Matemático de Altas energias e Turbulencia estocástica.")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-468699")[#strong[#text("Luiz Botelho -Físico Matemático de Altas energias e Turbulencia estocástica.")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2016")])]

#text("Terence")#linebreak()#text(" Beautiful argument .I think it can work for sigma compact Riemannian Manifolds .Relate to the General Relativity Problem , it is usual to postulate that you can complexify your pseudo Riemann manifold to a Complex Manifold with a Complex bilinear form as the Riemanian metric ,if this makes sense at all and thus apply Nash theorem for the Euclidean Manifold section (Now a truly Rieman Manifold!) .Any chance to extend this result by analytic continuation to the whole , now a complex manifold ?.Of course that some deep topological restrictions must be imposed , like Manifold Global orientability (By the way , if you consider orientability -Global , can this simplifies the Theorem ?).Being a spin manifold , etc….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hu")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-472406")[#strong[#text("Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2016")])]

#text("there is a very very little mistake with symbol：")#linebreak()#text(" Call a metric {g} on {({\\bf R}/{\\bf Z})^d} good if it is of the form {Q(u)} for some map {u: ({\\bf R}/{\\bf Z})^n \\rightarrow {\\bf R}^d} into a Euclidean space {{\\bf R}^d}. Our task is now to show that every metric is good; the relation (2) tells us that the sum of any two good metrics is good.")#linebreak()#text(" {({\\bf R}/{\\bf Z})^d} should be {({\\bf R}/{\\bf Z})^n}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ae02257f8b8fe1ebfde3e255e1403ac4ee84520d409a12cf282a56f1b79a94e-1143f347aa7ca80b056613dad83af8ff89d4db7978190750d39a1b962a152e89.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haduonght")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-474689")[#strong[#text("haduonght")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2016")])]

#text("Reblogged this on ")#link("https://haduonght.wordpress.com/2016/11/27/notes-on-the-nash-embedding-theorem/")[#text("Eniod's Blog")]#text(" and commented:")#linebreak()#text(" Terence Tao notes on embedding theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-507735")[#strong[#text("Embedding the Heisenberg group into a bounded dimensional Euclidean space with optimal distortion | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2018")])]

#text("[…] has some formal similarities with the isometric embedding problem (discussed for instance in this previous post), which can be viewed as the problem of solving an equation of the form , where is a Riemannian […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 255B, Notes 2: Onsager’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-510687")[#strong[#text("255B, Notes 2: Onsager’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("[…] is a celebrated theorem of Nash (discussed in this previous blog post) that the isometric embedding problem is possible in the smooth category if the dimension is large […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d3790c4736828b1541a369fb6f6433b334a8ef8cad673cfa3a72dc4183232c4a-d38e94be7afc3cc41ee6a1ce5d760cc1f8aa9073bd101b21b3233e6ff9e95933.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maria")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-512592")[#strong[#text("maria")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2019")])]

#text("Professor Tao, could you maybe explain the decomposition of g_{\\alpha,\\beta} in the proof of proposition 5? As far as I understand, one can write a symmetric positive definite matrix as a product V^T\\times V where the rows of V are the eigenvectors of the matrix multiplied by the square root of the positive eigenvalues. Hence, if \\psi(x)=V\\times x, then g_{\\alpha,\\beta}is given by the inner product of \\partial_\\alpha \\psi and \\partial_\\beta \\psi.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-512637")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2019")])]

#text("This gives the required decomposition at a single point ")#mi("x")#text(". To make a decomposition that applies for an open set of ")#mi("x")#text(" one needs a more stable decomposition than the spectral decomposition; see Lemma 16 of my more recent notes ")#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")[#text("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")]#text(" for details.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68b2b057f9d296967dfbfd5c092a04c78fb1474b0d1a126ef6dbb482525770fc-965994263b210d9eeabf059f613992693973dd84a4480a0e645699950b6e521e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-540638")[#strong[#text("Brian")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2020")])]

#text("I notice that both arguments of the max operator are second degree polynomials. A gross but true overestimate then for the d in Nash’s embedding theorem would be, for large enough n, n^3.")

#text("In fact, it seems 3 is the minimum of k such that n^k (the monomial) is a bound for d for all n after a certain point.")

#text("Why is this? I guess another way to ask is why is the bound Gunther found second degree? Why not first, third, or more than third?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-540730")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2020")])]

#text("Well, the equation ")#mi("Q(u) = g")#text(" is ")#mi("\\frac{n(n+1)}{2}")#text(" distinct equations in ")#mi("d")#text(" unknowns, so one should certainly expect smooth embedding to only be possible for ")#mi("d \\geq \\frac{n(n+1)}{2}")#text(" (this can be made rigorous by computing the dimension of the image of the Taylor coefficients at the origin of ")#mi("Q(u)")#text(" up to some large order as $u$ varies over smooth maps, and comparing this with the dimension of the space of Taylor coefficients of ")#mi("g")#text("; I give an argument of this form for instance in Section 3 of ")#link("https://arxiv.org/abs/1902.06313")[#text("https://arxiv.org/abs/1902.06313")]#text(" ).")

#text("The main constraint in the known arguments for Nash embedding require one to begin with a smooth (but not isometric) embedding ")#mi("u")#text(" which is free in the sense that the first derivatives ")#mi("\\partial_\\alpha u")#text(" and the second derivatives ")#mi("\\partial_{\\alpha \\beta} u")#text(" are linearly independent (after taking into account the obvious symmetry ")#mi("\\partial_{\\alpha \\beta} u = \\partial_{\\beta \\alpha} u")#text(". This forces ")#mi("d \\geq \\frac{n(n+1)}{2}+n")#text(" at a bare minimum. It remains an open question what the precise optimal dependence on ")#mi("d")#text(" and ")#mi("n")#text(" is.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-543743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2020")])]

#text("After (5), it states “")#mi("L(v- Q_{0}(v)) = h, ... v = Mh + Q_{0}(v)")#text("”. Isn’t the sign off? In other words, should it not be “")#mi("L(v + Q_{0}()) = h ... v = Mh - Q_{0}(v)")#text("”? Also, later there is a definition of “")#mi("Q_{\\alpha}(v) : = -(1- \\Delta)^{-1} (\\Delta v \\cdot \\partial_{\\beta} v)")#text("” Surely this must be ")#mi("Q_{\\beta}(v)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/076558b35a38495b60d41bfaf6758a34ee6b35681e674dae4dea31957970c5c4-00ea771c4bcd9fc0e84e710e259a4d42ebe5768b2a0f39f4032cce529c0058be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Ondrejat")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-548865")[#strong[#text("Martin Ondrejat")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2020")])]

#text("Concerning the smoothness of the solution (the final step) the proof seems to be using uniform boundedness of the operator norms of ")#mi("(1-\\Delta)^{-1}")#text(" from ")#mi("C^{k,\\alpha}")#text(" to ")#mi("C^{k+2,\\alpha}")#text(" with respect to all ")#mi("k")#text(" positive. Is this really true? If one realizes that the number of derivatives of ")#mi("k")#text("-th order does not increase in ")#mi("k")#text(" linearly, this would be surprising to hold …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-548950")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("The operator ")#mi("(1-\\Delta)^{-1}")#text(" commutes with all constant coefficient differential operators, and in particular with ")#mi("\\nabla^k")#text(". Because of this, once one knows that ")#mi("(1-\\Delta)^{-1}")#text(" maps ")#mi("C^{0,\\alpha}")#text(" to ")#mi("C^{2,\\alpha}")#text(", it is immediate that it also maps ")#mi("C^{k,\\alpha}")#text(" to ")#mi("C^{k+2,\\alpha}")#text(". (To put it another way: the operator ")#mi("(1-\\Delta)^{-1}")#text(" is a Fourier multiplier and thus does not change the frequency of the function it is applied to, only the amplitude. Varying the regularity exponent in Holder or Sobolev norms such as ")#mi("C^{k,\\alpha}")#text(" corresponds to multiplying the norm by some power of the frequency (at least for functions that are localised to a single frequency annulus). If the frequency doesn’t change, then this makes the ")#mi("C^{k,\\alpha}")#text(" norm effectively a scalar multiple of the norm ")#mi("C^{0,\\alpha}")#text(" for the function, and ")#mi("C^{k+2,\\alpha}")#text(" the same scalar multiple of ")#mi("C^{2,\\alpha}")#text(" of the output, so the effect of increasing $k$ on both sides cancels out.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/076558b35a38495b60d41bfaf6758a34ee6b35681e674dae4dea31957970c5c4-00ea771c4bcd9fc0e84e710e259a4d42ebe5768b2a0f39f4032cce529c0058be.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Ondrejat")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-548982")[#strong[#text("Martin Ondrejat")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2020")])]

#text("I can see that what you write works in the scale of the Sobolev spaces W^{k,2} (because there, everything can be transfered to the language of coordinates with respect to the orthonormal basis). And it is actually sufficient for the proof. One does not even need the (difficult) Schauder estimates for C^{k,\\alpha} which can be replaced by (easy) estimates in the Sobolev W^{k,2} spaces (which are also an algebra for large k). And then the proof is really simple. Great!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Green")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-586212")[#strong[#text("James Green")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2020")])]

#text("Hello,")

#text("I went to read the proof of the Nash Embedding theorem after I read your notes above. When you mention ” loss of derivatives problem” is this overcome in the original proof , by Nash, by using mollification in the convolution in Nash’s paper?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-586213")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2020")])]

#text("Yes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-615004")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2021")])]

#text("Can you comment on paraproduct machinery?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-616422")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2021")])]

#text("In the formula after “If we then use Cramer’s rule to create smooth functions”, should it be delta_{…} instead of 0?")

#emph[#text("[No. One could augment the ")#mi("w_{\\alpha \\beta}")#text(" to a more complete dual basis by also locating vectors ")#mi("w_{\\alpha}")#text(" that are dual to the ")#mi("\\partial_\\alpha u")#text(", but these are not necessary for this argument. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0338fbb9082c9daccd0351f6c87c5bcf3ec595894727f83c8152f0f5215e4ea5-d09376d45e9b755b5364c22a2a33d2db14dcf10502a769f3733e3b71378f16b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Nash embedding theorem – Nguyễn Tiến Mạnh")]], [#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/#comment-687750")[#strong[#text("Notes on the Nash embedding theorem – Nguyễn Tiến Mạnh")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2025")])]

#text("[…] Notes on the Nash embedding theorem […]")
]
