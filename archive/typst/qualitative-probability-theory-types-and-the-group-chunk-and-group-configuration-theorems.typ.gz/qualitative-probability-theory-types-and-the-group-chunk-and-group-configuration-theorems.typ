// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/
// Converted to Typst by tao2typ: "2026-10-14T16:37:15.649142+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Qualitative probability theory, types, and the group chunk and group configuration theorems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Qualitative probability theory, types, and the group chunk and group configuration theorems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 November 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/")[#text("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The classical foundations of probability theory (discussed for instance in ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this previous blog post")]#text(") is founded on the notion of a probability space ")#mi("{(\\Omega, {\\cal E}, {\\bf P})}")#text(" – a space ")#mi("{\\Omega}")#text(" (the ")#link("http://en.wikipedia.org/wiki/Sample_space")[#text("sample space")]#text(") equipped with a ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\cal E}}")#text(" (the ")#link("http://en.wikipedia.org/wiki/Event_(probability_theory)")[#text("event space")]#text("), together with a countably additive probability measure ")#mi("{{\\bf P}: {\\cal E} \\rightarrow [0,1]}")#text(" that assigns a real number in the interval ")#mi("{[0,1]}")#text(" to each event.")

#text("One can generalise the concept of a probability space to a ")#emph[#text("finitely additive")]#text(" probability space, in which the event space ")#mi("{{\\cal E}}")#text(" is now only a Boolean algebra rather than a ")#mi("{\\sigma}")#text("-algebra, and the measure ")#mi("{\\mu}")#text(" is now only finitely additive instead of countably additive, thus ")#mi("{{\\bf P}( E \\vee F ) = {\\bf P}(E) + {\\bf P}(F)}")#text(" when ")#mi("{E,F}")#text(" are disjoint events. By giving up countable additivity, one loses a fair amount of measure and integration theory, and in particular the notion of the expectation of a random variable becomes problematic (unless the random variable takes only finitely many values). Nevertheless, one can still perform a fair amount of probability theory in this weaker setting.")

#text("In this post I would like to describe a further weakening of probability theory, which I will call ")#emph[#text("qualitative probability theory")]#text(", in which one does not assign a precise numerical probability value ")#mi("{{\\bf P}(E)}")#text(" to each event, but instead merely records whether this probability is zero, one, or something in between. Thus ")#mi("{{\\bf P}}")#text(" is now a function from ")#mi("{{\\cal E}}")#text(" to the set ")#mi("{\\{0, I, 1\\}}")#text(", where ")#mi("{I}")#text(" is a new symbol that replaces all the elements of the open interval ")#mi("{(0,1)}")#text(". In this setting, one can no longer compute quantitative expressions, such as the mean or variance of a random variable; but one can still talk about whether an event holds almost surely, with positive probability, or with zero probability, and there are still usable notions of independence. (I will refer to classical probability theory as ")#emph[#text("quantitative")]#text(" probability theory, to distinguish it from its qualitative counterpart.)")

#text("The main reason I want to introduce this weak notion of probability theory is that it becomes suited to talk about random variables living inside algebraic varieties, even if these varieties are defined over fields other than ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(". In algebraic geometry one often talks about a “generic” element of a variety ")#mi("{V}")#text(" defined over a field ")#mi("{k}")#text(", which does not lie in any specified variety of lower dimension defined over ")#mi("{k}")#text(". Once ")#mi("{V}")#text(" has positive dimension, such generic elements do not exist as classical, deterministic ")#mi("{k}")#text("-points ")#mi("{x}")#text(" in ")#mi("{V}")#text(", since of course any such point lies in the ")#mi("{0}")#text("-dimensional subvariety ")#mi("{\\{x\\}}")#text(" of ")#mi("{V}")#text(". There are of course several established ways to deal with this problem. One way (which one might call the “Weil” approach to ")#link("http://en.wikipedia.org/wiki/Generic_point")[#text("generic points")]#text(") is to extend the field ")#mi("{k}")#text(" to a sufficiently transcendental extension ")#mi("{\\tilde k}")#text(", in order to locate a sufficient number of generic points in ")#mi("{V(\\tilde k)}")#text(". Another approach (which one might dub the “Zariski” approach to generic points) is to work ")#link("http://en.wikipedia.org/wiki/Scheme_(mathematics)")[#text("scheme-theoretically")]#text(", and interpret a generic point in ")#mi("{V}")#text(" as being associated to the zero ideal in the function ring of ")#mi("{V}")#text(". However I want to discuss a third perspective, in which one interprets a generic point not as a deterministic object, but rather as a ")#emph[#text("random variable")]#text(" ")#mi("{{\\bf x}}")#text(" taking values in ")#mi("{V}")#text(", but which lies in any given lower-dimensional subvariety of ")#mi("{V}")#text(" with probability zero. This interpretation is intuitive, but difficult to implement in classical probability theory (except perhaps when considering varieties over ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(") due to the lack of a natural probability measure to place on algebraic varieties; however it works just fine in qualitative probability theory. In particular, the algebraic geometry notion of being “generically true” can now be interpreted probabilistically as an assertion that something is “almost surely true”.")

#text("It turns out that just as qualitative random variables may be used to interpret the concept of a generic point, they can also be used to interpret the concept of a ")#link("http://en.wikipedia.org/wiki/Type_(model_theory)")[#text("type")]#text(" in model theory; the type of a random variable ")#mi("{x}")#text(" is the set of all predicates ")#mi("{\\phi(x)}")#text(" that are almost surely obeyed by ")#mi("{x}")#text(". In contrast, model theorists often adopt a Weil-type approach to types, in which one works with deterministic representatives of a type, which often do not occur in the original structure of interest, but only in a sufficiently saturated extension of that structure (this is the analogue of working in a sufficiently transcendental extension of the base field). However, it seems that (in some cases at least) one can equivalently view types in terms of (qualitative) random variables on the original structure, avoiding the need to extend that structure. (Instead, one reserves the right to extend the ")#emph[#text("sample space")]#text(" of one’s probability theory whenever necessary, as part of the “probabilistic way of thinking” discussed in ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this previous blog post")]#text(".) We illustrate this below the fold with two related theorems that I will interpret through the probabilistic lens: the “group chunk theorem” of Weil (and later developed by Hrushovski), and the “group configuration theorem” of Zilber (and again later developed by Hrushovski). For sake of concreteness we will only consider these theorems in the theory of algebraically closed fields, although the results are quite general and can be applied to many other theories studied in model theory.")

#metadata(none) <tao-fc33599eea1931fe9970>

#heading(level: 1)[#strong[#text(" — 1. Qualitative probability theory – generalities — ")]]

#text("We begin by setting up the foundations of qualitative probability theory, proceeding by close analogy with the more familiar quantitative probability theory (though of course we will have to jettison various quantitative concepts, such as mean and variance, from the theory).")

#text("As discussed in the introduction, we are replacing the unit interval ")#mi("{[0,1]}")#text(" by the three-element set ")#mi("{\\{0,I,1\\}}")#text("; one could view this as the quotient space of ")#mi("{[0,1]}")#text(" in which the interior ")#mi("{(0,1)}")#text(" has been contracted to a single point ")#mi("{I}")#text(". This space is still totally ordered: ")#mi("{0 < I < 1}")#text(". The addition relation ")#mi("{x+y=z}")#text(" on ")#mi("{[0,1]}")#text(" contracts to an “addition” relation ")#mi("{x+y \\sim z}")#text(" on ")#mi("{\\{0,I,1\\}}")#text(", defined by the following rules:")

#tao-aligned(keep: true)[


#tao-math("0 + 0  & \\sim 0; 0 + I \\sim I; 0 + 1 \\sim 1", block: true)



#tao-math("I+0  & \\sim I; 1 + 0 \\sim 1", block: true)



#tao-math("I + I  & \\sim I; I + I \\sim 1", block: true)
]

#text("with no other relations of the form ")#mi("{x+y \\sim z}")#text(" in ")#mi("{\\{0,I,1\\}}")#text(". Strictly speaking, ")#mi("{+}")#text(" is not a binary operation here, as ")#mi("{I+I}")#text(" can evaluate to ")#mi("{I}")#text(" or to ")#mi("{1}")#text(", but we keep the notation ")#mi("{+}")#text(" in order to emphasise the analogy with quantitative probability theory.")

#text("A ")#emph[#text("qualitative probability space")]#text(" ")#mi("{X = (X, {\\cal X}, \\mu)}")#text(" is then a space ")#mi("{X}")#text(" equipped with a Boolean algebra ")#mi("{{\\cal X}}")#text(" (the measurable subsets of ")#mi("{X}")#text(") and a function ")#mi("{\\mu: {\\cal X} \\rightarrow \\{0,I,1\\}}")#text(" with ")#mi("{\\mu(X)=1}")#text(", which is finitely additive in the sense that ")#mi("{\\mu(E) + \\mu(F) \\sim \\mu(E \\vee F)}")#text(" whenever ")#mi("{E, F \\in {\\cal X}}")#text(" are disjoint. It is easy to see that these measures are monotone (thus ")#mi("{\\mu(E) \\leq \\mu(F)}")#text(" whenever ")#mi("{E \\subset F}")#text("), and that ")#mi("{\\mu(\\emptyset)=0}")#text(". A measurable subset ")#mi("{E}")#text(" of ")#mi("{X}")#text(" is called a ")#emph[#mi("{\\mu}")#text("-null set")]#text(" if ")#mi("{\\mu(E)=0}")#text(", and a ")#emph[#mi("{\\mu}")#text("-full set")]#text(", a ")#emph[#mi("{\\mu}")#text("-conull set")]#text(", or a ")#emph[#mi("{\\mu}")#text("-generic set")]#text(" if ")#mi("{\\mu(E)=1}")#text("; note that ")#mi("{\\mu}")#text("-full sets are the complements of ")#mi("{\\mu}")#text("-null sets and vice versa. A property ")#mi("{P(x)}")#text(" of points ")#mi("{x \\in X}")#text(" is said to hold ")#emph[#mi("{\\mu}")#text("-almost everywhere")]#text(" or for ")#emph[#mi("{\\mu}")#text("-generic ")#mi("{x}")]#text(" if it holds outside of a ")#mi("{\\mu}")#text("-null set (or equivalently, if it holds on a ")#mi("{\\mu}")#text("-generic set).")

#text("One can describe a qualitative probability measure ")#mi("{\\mu}")#text(" on a Boolean space ")#mi("{(X,{\\cal X})}")#text(" purely through its ")#emph[#text("null ideal")]#text(" ")#mi("{\\text{null}(\\mu) := \\{ E \\in {\\cal X}: \\mu(E)=0 \\}}")#text(" of null sets, or equivalently through its ")#emph[#text("full filter")]#text(" ")#mi("{\\text{full}(\\mu) := \\{ E \\in {\\cal X}: \\mu(E)=1\\}}")#text(" of full sets. Conversely, if a subset ")#mi("{{\\cal F}}")#text(" of ")#mi("{{\\cal X}}")#text(" is the full filter of some qualitative probability measure on ")#mi("{(X,{\\cal X})}")#text(" if it obeys the following ")#link("http://en.wikipedia.org/wiki/Filter_(mathematics)")[#text("filter axioms")]#text(":")

#list(
[#text("(Empty set) ")#mi("{\\emptyset \\not \\in {\\cal F}}")#text(" and ")#mi("{X \\in {\\cal F}}")#text(".")],
[#text("(Monotonicity) If ")#mi("{E \\subset F}")#text(" are in ")#mi("{{\\cal X}}")#text(", and ")#mi("{E \\in {\\cal F}}")#text(", then ")#mi("{F \\in {\\cal F}}")#text(".")],
[#text("(Intersection) If ")#mi("{E, F \\in {\\cal F}}")#text(", then ")#mi("{E \\cap F\\in {\\cal F}}")#text(".")]
)

#text("Furthermore ")#mi("{\\mu}")#text(" is completely determined by the filter ")#mi("{{\\cal F}}")#text(". Similarly for the null ideal (with suitably inverted axioms, of course). Thus, if one wished, one could replace the concept of a qualitative probability measure with the concept of an ideal or filter, but we retain the use of ")#mi("{\\mu}")#text(" to emphasise the probabilistic interpretation of these objects.")

#text("One obvious way to create a qualitative probability measure is to start with a quantitative probability measure and “forget” the quantitative aspect of this measure by quotienting ")#mi("{[0,1]}")#text(" down to ")#mi("{\\{0,I,1\\}}")#text(". Under some reasonable hypotheses, one can reverse this procedure and view many qualitative probability measures as quantitative probability measures to which this forgetful process has been applied. However, this reversal is usually not unique, and we will not try to use it here.")

#text("In quantitative probability theory, one can take two quantitative probability measures ")#mi("{\\mu,\\nu}")#text(" on the same space ")#mi("{X}")#text(" and form an average ")#mi("{(1-\\theta) \\mu + \\theta \\nu}")#text(" for some ")#mi("{0 < \\theta < 1}")#text(", which is another quantitative probability measure. For instance, if ")#mi("{\\mu}")#text(" is a probability measure and ")#mi("{E}")#text(" is a set with measure between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", then ")#mi("{\\mu}")#text(" can be expressed as an average of the conditioned measures ")#mi("{(\\mu|E) := \\frac{1}{\\mu(E)} \\mu\\downharpoonright_E}")#text(" and ")#mi("{(\\mu|X \\backslash E) := \\frac{1}{\\mu(X \\backslash E)} \\mu\\downharpoonright_{X \\backslash E}}")#text(".")

#text("In analogy with this, we can take two qualitative measures ")#mi("{\\mu,\\nu}")#text(" on the same space ")#mi("{X}")#text(" and form the average ")#mi("{I \\mu + I \\nu}")#text(", defined by setting ")#mi("{I\\mu+I\\nu(E) = 1}")#text(" if and only if ")#mi("{\\mu(E)=\\nu(E)=1}")#text(" (or equivalently, ")#mi("{I\\mu+I\\nu(E) = 0}")#text(" if and only if ")#mi("{\\mu(E)=\\nu(E)=0}")#text("). If ")#mi("{\\mu}")#text(" is a qualitative probability measure and ")#mi("{E}")#text(" is a set with measure ")#mi("{I}")#text(", then we can form the conditioned measure ")#mi("{(\\mu|E)}")#text(", defined by setting ")#mi("{(\\mu|E)(F) = 1}")#text(" if ")#mi("{\\mu(F \\backslash E) = 0}")#text(" (or equivalently ")#mi("{(\\mu|E)(F)=0}")#text(" if ")#mi("{\\mu(E \\cup (X \\backslash F))=1}")#text("), and then one can check that ")#mi("{\\mu}")#text(" is the average of the conditioned measures ")#mi("{(\\mu|E)}")#text(" and ")#mi("{(\\mu|X \\backslash E)}")#text(".")

#text("We call a qualitative probability measure ")#emph[#text("irreducible")]#text(" if it does not assign any set the intermediate measure of ")#mi("{I}")#text(" (or equivalently, the full filter is an ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("ultrafilter")]#text("); thus, irreducible qualitative probability measures are the same concept as finitely additive ")#mi("{\\{0,1\\}}")#text("-valued probability measures (which, as is well known, are essentially the same concept as ultrafilters). By the previous discussion, we see that a qualitative probability measure is irreducible if and only if it is not the average of two other measures.")

#text("In this paper we will primarily work with irreducible measures, but will occasionally have to deal with reducible measures, for instance when taking the conditional product (or pullback) of two irreducible measures over a third.")

#text("Given a measurable map ")#mi("{f: X \\rightarrow Y}")#text(" between two Boolean spaces ")#mi("{(X, {\\cal X})}")#text(", ")#mi("{(Y, {\\cal Y})}")#text(" (thus the pre-image of any measurable set in ")#mi("{Y}")#text(" by ")#mi("{f}")#text(" is measurable in ")#mi("{X}")#text("), we can define the ")#emph[#text("pushforward")]#text(" ")#mi("{f_* \\mu}")#text(" of any qualitative probability measure ")#mi("{\\mu}")#text(" on ")#mi("{X}")#text(" to be the qualitative probability measure on ")#mi("{Y}")#text(" defined by the usual formula ")#mi("{f_* \\mu(E) := \\mu(f^{-1}(E))}")#text(". In particular, if ")#mi("{X}")#text(" embeds into ")#mi("{Y}")#text(", then any measure ")#mi("{\\mu}")#text(" on ")#mi("{X}")#text(" can also be viewed as a measure on ")#mi("{Y}")#text(", which we call the ")#emph[#text("extension")]#text(" of ")#mi("{\\mu}")#text(" to ")#mi("{Y}")#text(".")

#text("We now discuss the issue of product measures in the qualitative setting. Here we will deviate a little from the usual probability formalism, in which one usually defines a product algebra ")#mi("{{\\cal X} \\times {\\cal Y}}")#text(" to be the minimal algebra that contains the Cartesian product of ")#mi("{{\\cal X}}")#text(" and ")#mi("{{\\cal Y}}")#text(". Here, it turns out to be more useful to have a more flexible (but not unique) notion of a product, in which more measurable sets are permitted. Namely, given two Boolean spaces ")#mi("{(X, {\\cal X})}")#text(", ")#mi("{(Y, {\\cal Y})}")#text(", we say that a Boolean space ")#mi("{(X \\times Y, {\\cal X} \\times {\\cal Y})}")#text(" is ")#emph[#text("a")]#text(" product of the two spaces if ")#mi("{X \\times Y}")#text(" is the Cartesian product of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(", and the following axioms are obeyed:")

#list(
[#text("(Products) If ")#mi("{E \\in {\\cal X}}")#text(" and ")#mi("{F \\in {\\cal Y}}")#text(", then ")#mi("{E \\times F \\in {\\cal X} \\times {\\cal Y}}")#text(".")],
[#text("(Slicing) If ")#mi("{E \\in {\\cal X} \\times {\\cal Y}}")#text(", then ")#mi("{E_x := \\{ y \\in Y: (x,y) \\in E \\} \\in {\\cal Y}}")#text(" for all ")#mi("{x \\in X}")#text(", and ")#mi("{E^y := \\{ x \\in X: (x,y) \\in E \\} \\in {\\cal X}}")#text(" for all ")#mi("{y \\in Y}")#text(".")]
)

#text("These axioms do not uniquely specify ")#mi("{{\\cal X} \\times {\\cal Y}}")#text(", but in practice each product space ")#mi("{X \\times Y}")#text(" will have a canonical choice for ")#mi("{{\\cal X} \\times {\\cal Y}}")#text(" attached to it.")

#text("Given two qualitative probability spaces ")#mi("{(X, {\\cal X}, \\mu)}")#text(", ")#mi("{(Y, {\\cal Y}, \\nu)}")#text(", a qualitative probability space ")#mi("{(X \\times Y, {\\cal X} \\times {\\cal Y}, \\mu \\times \\nu)}")#text(" is ")#emph[#text("a")]#text(" product of the two spaces if ")#mi("{(X \\times Y, {\\cal X} \\times {\\cal Y})}")#text(" is a product of ")#mi("{(X, {\\cal X})}")#text(" and ")#mi("{(Y, {\\cal Y})}")#text(", and the following assertions are equivalent for any ")#mi("{E \\in {\\cal X} \\times {\\cal Y}}")#text(":")

#list(
[#mi("{\\mu\\times \\nu(E) = 1}")#text(".")],
[#text("For ")#mi("{\\mu}")#text("-almost every ")#mi("{x \\in X}")#text(", ")#mi("{\\nu(E_x) = 1}")#text(".")],
[#text("For ")#mi("{\\nu}")#text("-almost every ")#mi("{y \\in Y}")#text(", ")#mi("{\\mu(E^y) = 1}")#text(".")]
)

#text("Of course, one could replace ")#mi("{1}")#text(" by ")#mi("{0}")#text(" here in the above equivalence, which can be thought of as a qualitative Fubini-Tonelli type theorem. Once one selects the product Boolean algebra ")#mi("{{\\cal X} \\times {\\cal Y}}")#text(", the product measure ")#mi("{\\mu \\times \\nu}")#text(" is uniquely specified, if it exists at all; but (as in the setting of classical measure theory if one is not working with ")#mi("{\\sigma}")#text("-finite measures), existence is not always automatic. (But in our applications, it will be.)")

#text("One can define products of more than two (but still finitely many) qualitative probability spaces in a similar fashion; we leave the details to the reader.")

#text("Now we are ready to set up qualitative probability theory. We need a qualitative probability space ")#mi("{(\\Omega, {\\cal E}, {\\bf P})}")#text(" to serve as the sample space, event space, and probability measure. An event in ")#mi("{{\\cal E}}")#text(" is said to occur ")#emph[#text("almost surely")]#text(" if it occurs on a ")#mi("{{\\bf P}}")#text("-full set. Given an Boolean space ")#mi("{X = (X, {\\cal X})}")#text(", a ")#emph[#text("random variable")]#text(" is then a measurable map ")#mi("{{\\bf x}: \\Omega \\rightarrow X}")#text(". We permit random variables that are only defined almost surely, thus ")#mi("{{\\bf x}}")#text(" is now a partial function defined on a ")#mi("{{\\bf P}}")#text("-full event in ")#mi("{\\Omega}")#text("; as in quantitative probability theory or measure theory, we view random variables that agree almost surely as being essentially equivalent to each other. The ")#emph[#text("law")]#text(" or ")#emph[#text("distribution")]#text(" of ")#mi("{{\\bf x}}")#text(" is the pushforward ")#mi("{{\\bf x}_* {\\bf P}}")#text(" of the qualitative probability measure; this is then a qualitative measure on ")#mi("{X}")#text(". We say that two random variables ")#mi("{{\\bf x}, {\\bf x}^{\\prime}: \\Omega \\rightarrow X}")#text(" ")#emph[#text("agree in distribution")]#text(", and write ")#mi("{{\\bf x} \\equiv {\\bf x}^{\\prime}}")#text(", if they have the same law.")

#text("Two random variables ")#mi("{{\\bf x}: \\Omega \\rightarrow X}")#text(", ")#mi("{{\\bf y}: \\Omega \\rightarrow Y}")#text(" are said to be ")#emph[#text("independent")]#text(" if the distribution of the joint random variable ")#mi("{({\\bf x},{\\bf y}): \\Omega \\rightarrow X \\times Y}")#text(" is the product of the distributions of ")#mi("{{\\bf x}}")#text(" and ")#mi("{{\\bf y}}")#text(" separately. Here we need to specify a product Boolean algebra ")#mi("{{\\cal X} \\times {\\cal Y}}")#text(" on the product space ")#mi("{X \\times Y}")#text(" to make this definition well-defined, but in the applications we will consider, we will always have a canonical product algebra to select. One can define independence of more than two random variables in a similar fashion.")

#text("At the opposite extreme to independence, we say that a random variable ")#mi("{{\\bf y}: \\Omega\\rightarrow Y}")#text(" is ")#emph[#text("determined")]#text(" by another random variable ")#mi("{{\\bf x}: \\Omega \\rightarrow X}")#text(" if there is a measurable map ")#mi("{f: X \\rightarrow Y}")#text(" such that ")#mi("{f({\\bf x})={\\bf y}}")#text(" almost surely. The constrast between independence and determination (as well as a weaker property than determination we will consider later, namely ")#emph[#text("algebraicity")]#text(") will be the focus of the group chunk and group configuration theorems discussed in later sections.")

#text("As discussed in ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("this previous blog post")]#text(", in quantitative probability theory we often reserve the right to ")#emph[#text("extend")]#text(" the underlying probability space ")#mi("{(\\Omega, {\\cal E}, {\\bf P})}")#text(", in order to introduce new sources of randomness, without destroying the probabilistic properties of existing random variables (such as their independence and determination properties). We say that an ")#emph[#text("extension")]#text(" of a qualitative probability space ")#mi("{(\\Omega, {\\cal E}, {\\bf P})}")#text(" is another qualitative probability space ")#mi("{(\\Omega^{\\prime}, {\\cal E}^{\\prime}, {\\bf P}^{\\prime})}")#text(" together with a measurable map ")#mi("{\\pi: \\Omega^{\\prime} \\rightarrow \\Omega}")#text(" such that ")#mi("{\\pi_* {\\bf P}^{\\prime} = {\\bf P}}")#text(". One can then pull back any random variable ")#mi("{{\\bf x}: \\Omega \\rightarrow X}")#text(" to a random variable ")#mi("{{\\bf x} \\circ \\pi: \\Omega^{\\prime} \\rightarrow X}")#text(" on the new probability space; by abuse of notation, we continue to refer to ")#mi("{{\\bf x} \\circ \\pi}")#text(" as ")#mi("{{\\bf x}}")#text(". Probabilistic notions such as independence, law, or determination remain unchanged under such an extension.")

#heading(level: 1)[#strong[#text(" — 2. Qualitative probability theory on definable sets — ")]]

#text("For the purposes of this post, the qualitative probability measures we will care about will live in the theory of algebraically closed fields. We will assume some basic familiarity with algebraic geometry concepts, such as the ")#link("http://en.wikipedia.org/wiki/Dimension_of_a_variety")[#text("dimension of a variety")]#text(". The exact choice of field ")#mi("{k}")#text(" will not be important here, but one could work with the complex field ")#mi("{k={\\bf C}}")#text(" if desired (in which case one could (somewhat artificially) model the qualitative probability measures here by quantitative probability measures on complex varieties if one wished).")

#text("Henceforth ")#mi("{k}")#text(" is fixed; in contrast to usual model theory practice, we will not need to introduce some sufficiently large extension of ")#mi("{k}")#text(" to work in. The notion of measurability here will be given by the model-theoretic concept of ")#emph[#text("definability")]#text(". Namely, a ")#link("http://en.wikipedia.org/wiki/Definable_set")[#text("definable set")]#text(" is a set ")#mi("{X \\subset k^n}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("X = \\{ x \\in k^n: \\phi(x) \\text{ true} \\}")]]

#text("for some predicate ")#mi("{\\phi(x)}")#text(" that can be expressed in terms of the field operations ")#mi("{+,\\cdot}")#text(", a finite number of variables and constants in ")#mi("{k}")#text(", the boolean symbols ")#mi("{\\vee,\\wedge, \\neg}")#text(", the equality sign, the quantifiers ")#mi("{\\forall, \\exists}")#text(" (with all variables being quantified over ")#mi("{k}")#text("), and punctuation symbols (parentheses and colons). A ")#emph[#text("definable map")]#text(" ")#mi("{f: X \\rightarrow Y}")#text(" between two definable sets is a function whose graph ")#mi("{\\{ (x, f(x)): x \\in X \\}}")#text(" is a definable set.")

#text("As ")#mi("{k}")#text(" is algebraically closed, the definable sets can be described quite simply. Define an ")#link("http://en.wikipedia.org/wiki/Quasiprojective_variety")[#text("irreducible quasiprojective variety")]#text(", or ")#emph[#text("variety")]#text(" for short, to be a Zariski-open dense subset of an ")#link("http://en.wikipedia.org/wiki/Irreducible_variety")[#text("irreducible")]#text(" ")#link("http://en.wikipedia.org/wiki/Affine_variety")[#text("affine variety")]#text(" over ")#mi("{k}")#text(". One can show (using ")#link("http://en.wikipedia.org/wiki/Elimination_of_quantifiers")[#text("elimination of quantifiers")]#text(" in algebraically closed fields, the existence of which follows from ")#link("https://terrytao.wordpress.com/2007/11/26/hilberts-nullstellensatz/")[#text("Hilbert’s nullstellensatz")]#text(") that a set is definable if and only if it is the union of a finite number of disjoint varieties.")

#text("We equip each definable set ")#mi("{X}")#text(" with the Boolean algebra ")#mi("{{\\cal D}_X}")#text(" of definable subsets of ")#mi("{X}")#text("; this will be the only algebra we shall ever place on a definable set. Note that if ")#mi("{X,Y}")#text(" are definable, then ")#mi("{(X \\times Y, {\\cal D}_{X \\times Y})}")#text(" is a product space of ")#mi("{(X, {\\cal D}_X)}")#text(" and ")#mi("{(Y, {\\cal D}_Y)}")#text(" as per the previous definition.")

#text("If ")#mi("{\\mu}")#text(" is a qualitative probability measure on a definable set ")#mi("{X}")#text(", the ")#emph[#text("support")]#text(" of ")#mi("{\\mu}")#text(" is defined to be the intersection of all the Zariski-closed sets of ")#mi("{\\mu}")#text("-full measure. As the Zariski topology is ")#link("http://en.wikipedia.org/wiki/Noetherian_ring")[#text("Noetherian")]#text(", the support is always a closed set of full measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can describe a qualitative probability measure ")#mi("{\\mu}")#text(" through its ")#emph[#text("type")]#text(", defined as the set of all predicates ")#mi("{\\phi(x)}")#text(" which hold for ")#mi("{\\mu}")#text("-almost all ")#mi("{x}")#text(". This concept is essentially the same as the ")#link("http://en.wikipedia.org/wiki/Type_(model_theory)")[#text("concept of a type in model theory")]#text("; the measure ")#mi("{\\mu}")#text(" is irreducible if and only if the type is complete. In this post, we have essentially replaced the notion of a type with that of a qualitative probability measure, and so types will not appear explicitly in the rest of the post.")
]

#text("We now give some basic examples of qualitative probability measures on definable sets.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" If ")#mi("{X}")#text(" is a non-empty definable set of some dimension ")#mi("{d}")#text(" (that is, ")#mi("{d}")#text(" is the largest dimension of all components of ")#mi("{X}")#text(" (or of its closure)), then the ")#emph[#text("qualitative uniform probability measure")]#text(" ")#mi("{\\mu_X}")#text(" on ")#mi("{X}")#text(" (or ")#emph[#text("uniform measure")]#text(", for short) is defined by setting all subsets of dimension ")#mi("{d-1}")#text(" or less to have measure zero, or equivalently all generic subsets of ")#mi("{X}")#text(" (that is, ")#mi("{X}")#text(" with finitely many sets of dimension ")#mi("{d-1}")#text(" removed) to have full measure. (Sets which contain a generic subset of some, but not all, of the ")#mi("{d}")#text("-dimensional components of ")#mi("{X}")#text(", then are assigned the intermediate measure.) The support of this measure is then the closure of the union of the ")#mi("{d}")#text("-dimensional components. This measure is irreducible if and only if ")#mi("{X}")#text(" is ")#emph[#text("almost irreducible")]#text(" in the sense that it only has one ")#mi("{d}")#text("-dimensional component. Note that the algebraic geometry notion of genericity now coincides with the (qualitative) probabilistic notion of almost sureness: a (definable) property on ")#mi("{X}")#text(" holds generically if and only if it holds almost surely with respect to the uniform measure on ")#mi("{X}")#text(".")

#text("If ")#mi("{X, Y}")#text(" are definable sets, then the uniform measure on ")#mi("{X \\times Y}")#text(" is the product of the uniform measure on ")#mi("{X}")#text(" and the uniform measure on ")#mi("{Y}")#text("; the proof of the Fubini-Tonelli type statement that justifies this may be found for instance in Lemma 13 of ")#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")[#text("this paper of mine")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" If ")#mi("{X}")#text(" is almost irreducible and ")#mi("{f: X \\rightarrow Y}")#text(" is a definable map, then the uniform measure ")#mi("{\\mu_X}")#text(" on ")#mi("{X}")#text(" pushes forward to the uniform measure of some almost irreducible subset ")#mi("{Z}")#text(" of ")#mi("{Y}")#text("; see e.g. Lemma A.8 of ")#link("https://terrytao.wordpress.com/2010/05/12/approximate-subgroups-of-linear-subgroups/")[#text("this previous paper of Breuillard, Green, and myself")]#text(". Also, generic points in ")#mi("{Z}")#text(" have fibres in ")#mi("{X}")#text(" of dimension ")#mi("{\\text{dim}(X)-\\text{dim}(Z)}")#text(", just as one would expect from naive dimension counting. If ")#mi("{X}")#text(" is not almost irreducible, the situation becomes a bit more complicated because the image on ")#mi("{f}")#text(" on different components of ")#mi("{X}")#text(" may have a different dimension, and so ")#mi("{f_* \\mu_X}")#text(" may become an average of uniform measures on sets of different dimension.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{\\mu}")#text(" be a qualitative probability measure on a definable set ")#mi("{X}")#text(".")

#list(
[#text("(i) Show that ")#mi("{\\mu}")#text(" is irreducible if and only if it is the uniform measure of some almost irreducible subset of ")#mi("{X}")#text(".")],
[#text("(ii) Show that ")#mi("{\\mu}")#text(" is the average of finitely many uniform measures if and only if there does not exist a countable family of disjoint subsets of ")#mi("{X}")#text(" of positive measure. (")#emph[#text("Hint:")]#text(" greedily select disjoint varieties of ")#mi("{\\mu}")#text(" of positive measure, starting with zero-dimensional varieties (points) and then increasing the dimension.)")]
)
]

#text("We now use the formalism of qualitative probability theory from the previous section, but always working within the definable category; thus we require the sample space ")#mi("{(\\Omega, {\\cal E}, {\\bf P})}")#text(" to also be a definable set, and that all random variables are required to be definable maps (or at least generically definable maps), which is a stronger condition than measurability.")

#heading(level: 1)[#strong[#text(" — 3. The group chunk theorem — ")]]

#text("Random variables can interact very nicely with groups ")#mi("{G}")#text(", if they come equipped with an appropriate invariant measure. To illustrate this, let us first return to the classical setting of quantitative probability theory, working exclusively with finite groups to avoid all measurability issues.")

#text("Given a finite group ")#mi("{G}")#text(", let ")#mi("{{\\bf g}_1,{\\bf g}_2}")#text(" be two elements of ")#mi("{G}")#text(" chosen uniformly and independently at random, and then form their product ")#mi("{{\\bf g}_3 := {\\bf g}_1 \\cdot {\\bf g}_2}")#text(". This gives us a triple ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3)}")#text(" of random variables taking values in ")#mi("{G}")#text(", which obey the following independence and determination properties:")

#list(
[#text("(i) (Uniform distribution) For any ")#mi("{i \\in \\{1,2,3\\}}")#text(", ")#mi("{{\\bf g}_i}")#text(" has the uniform distribution on ")#mi("{G}")#text(".")],
[#text("(ii) (Independence) For any distinct ")#mi("{i,j \\in \\{1,2,3\\}}")#text(", ")#mi("{{\\bf g}_i,{\\bf g}_j}")#text(" are independent.")],
[#text("(iii) (Determination) For any distinct ")#mi("{i,j,k \\in \\{1,2,3\\}}")#text(", ")#mi("{{\\bf g}_k}")#text(" is determined by ")#mi("{{\\bf g}_i,{\\bf g}_j}")#text(".")],
[#text("(iv) (Associativity) After extending the sample space as necessary, one can locate additional random variables ")#mi("{{\\bf g}_4,{\\bf g}_5,{\\bf g}_6}")#text(" taking values in ")#mi("{G}")#text(" such that ")#mi("{({\\bf g}_3,{\\bf g}_4,{\\bf g}_6) \\equiv ({\\bf g}_2,{\\bf g}_4,{\\bf g}_5) \\equiv ({\\bf g}_1,{\\bf g}_5,{\\bf g}_6) \\equiv ({\\bf g}_1,{\\bf g}_2,{\\bf g}_3)}")#text(" (see figure), and such that any other triple ")#mi("{({\\bf g}_i,{\\bf g}_j,{\\bf g}_k)}")#text(" for distinct ")#mi("{i,j,k \\in \\{1,\\ldots,6\\}}")#text(" which is not a permutation of the four triples already mentioned is jointly independent.")]
)

#text("Indeed, to see the associativity axiom, let ")#mi("{{\\bf g}_4}")#text(" be selected uniformly from ")#mi("{G}")#text(" independently of ")#mi("{{\\bf g}_1,{\\bf g}_2}")#text(", and set ")#mi("{{\\bf g}_5 := {\\bf g}_2 {\\bf g}_4}")#text(" and ")#mi("{{\\bf g}_6 := {\\bf g}_1 {\\bf g}_2 {\\bf g}_4}")#text(". The associativity is depicted graphically in the figure below, in which three points connected by a line or curve indicate a dependence, but triples of points not joined by such a line or curve being independent.")

#image("../assets/0e4c211c69548e54929b8a00beb3e1f0a26d05e49e904cb558fc961f4773a6d9-d5171298d6d9bf7b4906ebd70b2523646253eacd40e219b4d348cfc377d23fdf.png", width: 90%, alt: "Figure 1")

#text("In the converse direction, any triple ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3)}")#text(" on a finite set ")#mi("{G}")#text(" obeying the above axioms necessarily comes from an underlying group operation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Probabilistic description of a finite group)")]#text(" ")#metadata(none) <tao-f17b73d0601988c4e7c3>#text(" Let ")#mi("{G}")#text(" be a finite non-empty set, and let ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3}")#text(" be random variables on ")#mi("{G}")#text(" that obey axioms (i)-(iv). Then there exists a group structure ")#mi("{G = (G, 1, ()^{-1}, \\cdot)}")#text(" on ")#mi("{G}")#text(" such that ")#mi("{{\\bf g}_3 = {\\bf g}_1 \\cdot {\\bf g}_2}")#text(".")
]

#emph[#text("Proof:")]#text(" By axiom (iii), we have ")#mi("{{\\bf g}_3 = {\\bf g}_1 \\cdot {\\bf g}_2}")#text(" for ")#emph[#text("some")]#text(" binary operation ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(". From axiom (iv) we have")

#align(center)[#tao-fit-display[#mitex("({\\bf g}_1 \\cdot {\\bf g}_2) \\cdot {\\bf g}_4 = {\\bf g}_3 \\cdot {\\bf g}_4 = {\\bf g}_6 = {\\bf g}_1 \\cdot {\\bf g}_5 = {\\bf g}_1 \\cdot ({\\bf g}_2 \\cdot {\\bf g}_4)")]]

#text("almost surely (and hence surely, as ")#mi("{G}")#text(" is finite); also from axioms (i), (iv) we see that ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_4)}")#text(" is uniformly distributed in ")#mi("{G^3}")#text(". We conclude that the binary operation ")#mi("{\\cdot}")#text(" is associative, thus ")#mi("{(x \\cdot y) \\cdot z = x \\cdot (y \\cdot z)}")#text(" for all ")#mi("{x,y,z \\in G}")#text(".")

#text("By axiom (iii), we see that for fixed ")#mi("{{\\bf g}_1}")#text(", ")#mi("{{\\bf g}_2}")#text(" is determined by ")#mi("{{\\bf g}_3}")#text(" and vice versa; from axioms (i), (ii), this implies that for fixed ")#mi("{x \\in G}")#text(", the map ")#mi("{\\phi_x: y \\mapsto x \\cdot y}")#text(" is a bijection from ")#mi("{G}")#text(" to itself; similarly the map ")#mi("{\\psi_x: y \\mapsto y \\cdot x}")#text(" is a bijection from ")#mi("{G}")#text(" to itself. Note also from associativity that ")#mi("{\\phi_x}")#text(" commutes with the right-action of ")#mi("{G}")#text(" in the sense that ")#mi("{\\phi_x( y \\cdot z ) = \\phi_x( y ) \\cdot z}")#text(" for all ")#mi("{x,y,z \\in G}")#text(".")

#text("Conversely, given any bijection ")#mi("{\\phi: G \\rightarrow G}")#text(" that commutes with the right-action in the sense that ")#mi("{\\phi(y \\cdot z) = \\phi(y) \\cdot z}")#text(" for all ")#mi("{y,z \\in G}")#text(", we claim that ")#mi("{\\phi = \\phi_x}")#text(" for a unique ")#mi("{x \\in G}")#text(". Indeed, from axioms (i)-(iii), we know that ")#mi("{{\\bf g}_1}")#text(" is determined by ")#mi("{{\\bf g}_2,{\\bf g}_3}")#text(", and so for any given ")#mi("{y \\in G}")#text(", we may find ")#mi("{x \\in G}")#text(" such that ")#mi("{\\phi(y) = x \\cdot y}")#text(". If this holds for a single ")#mi("{y}")#text(", then it holds for all other ")#mi("{y}")#text(" by associativity, since ")#mi("{\\phi}")#text(" commutes with the right action, and the map ")#mi("{z \\mapsto y \\cdot z}")#text(" is a bijection. Thus we may identify ")#mi("{G}")#text(" with the space of bijections ")#mi("{\\phi: G \\rightarrow G}")#text(" that commute with the right-action. This is clearly a group, and the property ")#mi("{{\\bf g}_3 = {\\bf g}_1 \\cdot {\\bf g}_2}")#text(" is then clear from construction. ")#mi("\\Box")

#text("Now that we see that a finite group, at least, may be described in terms of the probabilistic language of independence and determination. It is natural to ask whether similar results hold for infinite groups (with the slight modification that we now only expect ")#mi("{{\\bf g}_3 = {\\bf g}_1 \\cdot {\\bf g}_2}")#text(" to hold almost surely rather than surely, as we now will have non-trivial events of probability zero). Here we run into the technical difficulty that many groups – such as non-compact Lie groups, or algebraic groups defined over fields other than ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(" – are not naturally equipped with a probability measure with which to define the concept of uniform distribution. However, if one is working in the definable category, one can use the language of qualitative probability theory instead and obtain the same result.")

#text("A ")#emph[#text("definable group")]#text(" ")#mi("{G}")#text(" is a group ")#mi("{G = (G, 1, ()^{-1}, \\cdot)}")#text(" which is a definable set, such that the group operations ")#mi("{()^{-1}: G \\rightarrow G}")#text(" and ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(" are definable maps. This notion is very close to, but subtly different from, that of the more commonly used notion of an ")#link("http://en.wikipedia.org/wiki/Algebraic_group")[#text("algebraic group")]#text("; the latter is a bit stricter because the group has to now be an algebraic variety, and the group operations have to be ")#link("http://en.wikipedia.org/wiki/Regular_function")[#text("regular maps")]#text(" and not just definable maps. However, the two notions are quite close to each other, particularly in characteristic zero when they become equivalent up to definable group isomorphism, although additional subtleties arise in positive characteristic ")#mi("{p}")#text(" due to the existence of things like the inverse Frobenius automorphism ")#mi("{x \\mapsto x^{1/p}}")#text(", which is definable but not regular, and which can be used to definably “twist” an algebraic group. We will not discuss these issues further here, but see ")#link("http://www.ams.org/mathscinet-getitem?mr=985345")[#text("this survey of Bouscaren")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1031890")[#text("this article of van den Dries")]#text(" for further discussion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Group chunk theorem)")]#text(" ")#metadata(none) <tao-6d8564c8c3e742cbcd97>#text(" Let ")#mi("{G}")#text(" be an almost irreducible definable set, and let ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3}")#text(" be qualitative random variables taking values in ")#mi("{G}")#text(", obeying axioms (i)-(iv). Then, after passing from ")#mi("{G}")#text(" to a generic subset, one may definably identify ")#mi("{G}")#text(" with a generic subset of an definable group ")#mi("{\\tilde G}")#text(", so that ")#mi("{{\\bf g}_1 \\cdot {\\bf g}_2 = {\\bf g}_3}")#text(" almost surely. (To put it another way, there is a definable bijection ")#mi("{\\iota}")#text(" between a generic subset of ")#mi("{G}")#text(" and a generic subset of ")#mi("{\\tilde G}")#text(", such that ")#mi("{\\iota({\\bf g}_1) \\cdot \\iota({\\bf g}_2) = \\iota({\\bf g}_3)}")#text(" almost surely.)")
]

#text("This theorem is essentially ")#link("http://www.ams.org/mathscinet-getitem?mr=74083")[#text("due to Weil")]#text(" (although he worked instead in the category of algebraic varieties and algebraic groups, rather than definable sets and definable groups). It was extended to many other model-theoretic contexts (and in particular to ")#link("http://en.wikipedia.org/wiki/Stable_theory")[#text("stable theories")]#text(") in the thesis of Hrushovski, although we will only focus on the classical algebraic geometry case here.")

#text("A typical example of a group chunk comes from taking a definable group and removing a lower dimensional subset of it, so that the group law is only generically defined (but this is still sufficient for defining ")#mi("{{\\bf g}_1 \\cdot {\\bf g}_2}")#text(" almost surely). For instance, one could let ")#mi("{G}")#text(" be the ")#mi("{2 \\times 2}")#text(" non-singular matrices ")#mi("{\\begin{pmatrix} a & b \\\\ 1 & d \\end{pmatrix}}")#text(", with (generically defined) group law given by matrix multiplication followed by projective normalisation to force the lower left coordinate to be ")#mi("{1}")#text(" (which is only defined if this coordinate does not vanish, of course). This can be viewed as an open dense subset of the projective special linear group ")#mi("{PSL_2(k)}")#text(", and the theorem is asserting that ")#mi("{G}")#text(" can be “completed” to this group, which can be interpreted as a definable group. (")#mi("{PSL_2(k)}")#text(" can be viewed as an affine variety using, for instance, the adjoint representation. In any event, even projective varieties can be interpreted affinely in a definable fashion by the artificial device of breaking up the variety into finitely many pieces, which can be all fit into a sufficiently large affine space.)")

#text("We now prove Theorem ")#link(<tao-6d8564c8c3e742cbcd97>)[#text("2")]#text(". By axioms (i)-(iii), there is a generically defined, and definable, map ")#mi("{\\cdot: G \\times G \\rightarrow G}")#text(" such that ")#mi("{{\\bf g}_1 \\cdot {\\bf g}_2 = {\\bf g}_3}")#text(" almost surely. From axiom (iii) we then conclude the following cancellation axioms:")

#list(
[#text("(vii) (Left cancellation) For generic ")#mi("{(g,h) \\in G \\times G}")#text(", there is a unique ")#mi("{k}")#text(" such that ")#mi("{k \\cdot g = h}")#text(".")],
[#text("(viii) (Right cancellation) For generic ")#mi("{(g,h) \\in G \\times G}")#text(", there is a unique ")#mi("{k}")#text(" such that ")#mi("{g \\cdot k = h}")#text(".")]
)

#text("The associativity axiom then also gives ")#mi("{(g \\cdot h) \\cdot k = g \\cdot (h \\cdot k)}")#text(" for generic ")#mi("{(g,h,k) \\in G^3}")#text(".")

#text("These axioms also imply the following variants:")

#list(
[#text("(vii’) (Left cancellation) For generic ")#mi("{(g, k) \\in G \\times G}")#text(", ")#mi("{k}")#text(" is the unique ")#mi("{k^{\\prime} \\in G}")#text(" such that ")#mi("{k \\cdot g = k^{\\prime} \\cdot g}")#text(".")],
[#text("(viii’) (Right cancellation) For generic ")#mi("{(g, k) \\in G \\times G}")#text(", ")#mi("{k}")#text(" is the unique ")#mi("{k^{\\prime} \\in G}")#text(" such that ")#mi("{g \\cdot k = g \\cdot k^{\\prime}}")#text(".")]
)

#text("Indeed, from axiom (vii), we have a generically defined map ")#mi("{(g,h) \\mapsto (g,k)}")#text(" that maps a generic pair ")#mi("{(g,h) \\in G \\times G}")#text(" to ")#mi("{(g,k)}")#text(", where ")#mi("{k}")#text(" is the unique ")#mi("{k \\in G}")#text(" such that ")#mi("{k \\cdot g = h}")#text(". This map is generically injective; as ")#mi("{G \\times G}")#text(" is essentally irreducible, this map has to be generically bijective also, which gives (vii’), and (viii’) is proven similarly. (We call a partially defined map ")#mi("{f: X \\rightarrow Y}")#text(" ")#emph[#text("generically bijective")]#text(" if it can be made into a total bijection by refining ")#mi("{X, Y}")#text(" to generic subsets.) We conclude that for generic ")#mi("{g \\in G}")#text(", the maps ")#mi("{k \\mapsto k \\cdot g}")#text(" and ")#mi("{k \\mapsto g \\cdot k}")#text(" are generically bijective.")

#text("To obtain a genuine group from ")#mi("{G}")#text(" rather than just a generic group, we perform a formal quotient construction, analogous to how the integers are formally constructed from the natural numbers (or the rationals from the integers). Define a ")#emph[#text("formal pre-group element")]#text(" to be a definable subset ")#mi("{\\Sigma}")#text(" of ")#mi("{G \\times G}")#text(" with the following properties:")

#list(
[#text("(ix) (Vertical line test) For generic ")#mi("{g \\in G}")#text(", there is exactly one ")#mi("{h\\in G}")#text(" such that ")#mi("{(g,h) \\in \\Sigma}")#text(".")],
[#text("(ix’) (Vertical line test) For generic ")#mi("{(g,h) \\in \\Sigma}")#text(", ")#mi("{h}")#text(" is the unique ")#mi("{h^{\\prime} \\in G}")#text(" such that ")#mi("{(g,h^{\\prime}) \\in \\Sigma}")#text(".")],
[#text("(x) (Horizontal line test) For generic ")#mi("{h \\in G}")#text(", there is exactly one ")#mi("{g\\in G}")#text(" such that ")#mi("{(g,h) \\in \\Sigma}")#text(".")],
[#text("(x’) (Horizontal line test) For generic ")#mi("{(g,h) \\in \\Sigma}")#text(", ")#mi("{g}")#text(" is the unique ")#mi("{g^{\\prime} \\in G}")#text(" such that ")#mi("{(g^{\\prime},h) \\in \\Sigma}")#text(".")],
[#text("(xi) (Translation invariance) For generic ")#mi("{((g,h),k) \\in \\Sigma \\times G}")#text(", ")#mi("{(g \\cdot k, h \\cdot k)}")#text(" lies in ")#mi("{\\Sigma}")#text(".")]
)

#text("The axioms (ix)-(x’) are asserting that ")#mi("{\\Sigma}")#text(" is a generic bijection. (Here and in the sequel we adopt the convention that a mathematical statement is automatically considered false if one or more of its terms are undefined; for instance, ")#mi("{(g \\cdot k, h \\cdot k) \\in \\Sigma}")#text(" is only true when ")#mi("{g \\cdot k}")#text(" and ")#mi("{h \\cdot k}")#text(" is well-defined. Similarly, when using ")#link("http://en.wikipedia.org/wiki/Set-builder_notation")[#text("set-builder notation")]#text(", we only include those elements in the set which are well-defined; for instance, in the set ")#mi("{\\{ (g \\cdot k, h \\cdot k): k \\in G\\}}")#text(", ")#mi("{k}")#text(" is implicitly restricted to those values for which ")#mi("{g \\cdot k}")#text(" and ")#mi("{h \\cdot k}")#text(" are well-defined.)")

#text("Call two formal pre-group elements ")#mi("{\\Sigma, \\Sigma^{\\prime}}")#text(" are ")#emph[#text("equivalent")]#text(" if they have a common generic subset, and then define a ")#emph[#text("formal group element")]#text(" to be an equivalence class ")#mi("{[\\Sigma]}")#text(" of formal pre-group elements ")#mi("{\\Sigma}")#text(", and let ")#mi("{\\tilde G}")#text(" be the space of formal group elements. At this point, we have to deal with the technical problem that ")#mi("{\\tilde G}")#text(" is not obviously a definable set. However, observe that if ")#mi("{\\Sigma}")#text(" is a formal pre-group element, then we have a definable generic bijection ")#mi("{g \\mapsto (g,h)}")#text(" from ")#mi("{G}")#text(" to ")#mi("{\\Sigma}")#text(", which makes ")#mi("{\\Sigma}")#text(" essentially irreducible. If we then define ")#mi("{\\overline{\\Sigma}}")#text(" to be the Zariski closure of the top dimensional component of ")#mi("{\\Sigma}")#text(" (i.e. the support of the uniform measure on ")#mi("{\\Sigma}")#text("), then ")#mi("{\\overline{\\Sigma}}")#text(" is an irreducible closed variety, which depends only on the equivalence class ")#mi("{[\\Sigma]}")#text(" of ")#mi("{\\Sigma}")#text(", with inequivalent pre-group elements giving distinct irreducible closed varieties. Finally, one can describe ")#mi("{\\overline{\\Sigma}}")#text(" in terms of a generic element ")#mi("{(g,h)}")#text(" of ")#mi("{\\Sigma}")#text(", as being the closure of the top-dimensional component of ")#mi("{\\{ (g \\cdot k, h \\cdot k): k\\in G \\}}")#text(", and generic elements ")#mi("{(g,h) \\in G \\times G}")#text(" produce such an objecft. As such, if we let ")#mi("{\\tilde G}")#text(" be the set of all ")#mi("{\\overline{\\Sigma}}")#text(", then ")#mi("{\\tilde G}")#text(" is in one-to-one correspondence with the space of formal group elements, and may be parameterised as a definable set using standard algebraic geometry tools (e.g. ")#link("http://en.wikipedia.org/wiki/Chow_coordinates")[#text("Chow coordinates")]#text(", the ")#link("http://en.wikipedia.org/wiki/Hilbert_scheme")[#text("Hilbert scheme")]#text(", or ")#link("http://en.wikipedia.org/wiki/Imaginary_element")[#text("elimination of imaginaries")]#text("), as being the image under a generically definable map ")#mi("{(g,h) \\mapsto \\overline{\\Sigma}}")#text(" of ")#mi("{G \\times G}")#text(" with fibres of dimension ")#mi("{\\text{dim}(G)}")#text(". In particular, as ")#mi("{G \\times G}")#text(" is essentially irreducible with dimension ")#mi("{2\\text{dim}(G)}")#text(", ")#mi("{\\tilde G}")#text(" is essentially irreducible with dimension ")#mi("{\\text{dim}(G)}")#text(".")

#text("We define the identity element of ")#mi("{\\tilde G}")#text(" to be the equivalence class of the diagonal ")#mi("{\\{ (g,g): g \\in G \\}}")#text(", and define the inverse of the equivalence class of a formal pre-group element ")#mi("{\\Sigma}")#text(" to be the equivalence class of the reflection ")#mi("{\\{ (h,g): (g,h) \\in\\Sigma \\}}")#text(" of ")#mi("{\\Sigma}")#text(". As for the group law, we use generic composition: given two formal pre-group elements ")#mi("{\\Sigma, \\Sigma^{\\prime}}")#text(", we define the composition ")#mi("{\\Sigma \\cdot\\Sigma^{\\prime}}")#text(" to be the set of all pairs ")#mi("{(g,k)}")#text(" such that there exists ")#mi("{h \\in G}")#text(" for which ")#mi("{h}")#text(" is the unique element with ")#mi("{(h,k)\\in\\Sigma^{\\prime}}")#text(", and ")#mi("{h}")#text(" is also the unique element with ")#mi("{(g,h) \\in \\Sigma}")#text(". One can check (somewhat tediously) that this descends to a well-defined operation on ")#mi("{\\tilde G}")#text(" that gives it the structure of a definable group.")

#text("Next, for generic ")#mi("{g \\in G}")#text(", the set ")#mi("{\\{ (g \\cdot k, k): k \\in G \\}}")#text(" is a formal pre-group element, giving a generically defined map ")#mi("{\\iota: G \\rightarrow \\tilde G}")#text(". One can verify that this map is generically definable, generically injective, and generically a homomorphism. The remaining task is to verify that ")#mi("{\\tilde G}")#text(" has the same dimension as ")#mi("{G}")#text(", as this together with essential irreducibility and generic injectivity gives generic bijectivity thanks to dimension counting. But for every formal pre-group element ")#mi("{\\Sigma}")#text(", we see that generic ")#mi("{g \\in G}")#text(", there is a unique ")#mi("{h \\in G}")#text(" with ")#mi("{(g,h) \\in \\Sigma}")#text(", and furthermore that ")#mi("{(g \\cdot k, h \\cdot k) \\in \\Sigma}")#text(" for generic ")#mi("{k \\in G}")#text("; in particular, ")#mi("{\\Sigma}")#text(" is equivalent to ")#mi("{\\{ (g \\cdot k, h\\cdot k):k\\in G \\}}")#text(" and can thus be recovered from ")#mi("{(g,h)}")#text("; conversely, generic ")#mi("{(g,h) \\in G \\times G}")#text(" gives rise to a formal group element by this construction. This sets up a generically bijective map ")#mi("{(\\overline{\\Sigma}, g) \\mapsto (g,h)}")#text(" from ")#mi("{\\tilde G\\times G}")#text(" to ")#mi("{G \\times G}")#text(", which shows that ")#mi("{\\tilde G}")#text(" has the same dimension as ")#mi("{G}")#text(", as required. This concludes the proof of Theorem ")#link(<tao-6d8564c8c3e742cbcd97>)[#text("2")]#text(".")

#heading(level: 1)[#strong[#text(" — 4. The group configuration theorem — ")]]

#text("We now discuss a variant of the group chunk theorem that characterises group actions, known as the ")#emph[#text("group configuration theorem")]#text(". Again, to motivate matters we start with the quantitative probabilistic setting in the finite case. If ")#mi("{G}")#text(" is a finite group acting on a finite set ")#mi("{X}")#text(", and ")#mi("{{\\bf g}_1,{\\bf g}_2}")#text(" are chosen independently and uniformly at random from ")#mi("{G}")#text(", and ")#mi("{{\\bf x}_3}")#text(" uniformly from ")#mi("{X}")#text(" (independently of ")#mi("{{\\bf g}_1,{\\bf g}_2}")#text("), and then one defines ")#mi("{{\\bf g}_3 := {\\bf g}_1^{-1} {\\bf g}_2^{-1}}")#text(", ")#mi("{{\\bf x}_1:= {\\bf g}_2 \\cdot {\\bf x}_3}")#text(",and ")#mi("{{\\bf x}_2:= {\\bf g}_1^{-1} \\cdot {\\bf x}_3}")#text(" (or, more symmetrically, we have the constraints ")#mi("{{\\bf g}_3 {\\bf g}_2 {\\bf g}_1 = 1}")#text(", ")#mi("{{\\bf g}_1 \\cdot {\\bf x}_2 = {\\bf x}_3}")#text(", ")#mi("{{\\bf g}_2 \\cdot {\\bf x}_3 = {\\bf x}_1}")#text(", and ")#mi("{{\\bf g}_3 \\cdot {\\bf x}_1 = {\\bf x}_2}")#text("), then we observe the following independence and determination axioms (setting ")#mi("{G_i := G}")#text(" and ")#mi("{X_i := X}")#text(" for ")#mi("{i=1,2,3}")#text("):")

#list(
[#text("(i’) (Uniform distribution) For any ")#mi("{i \\in \\{1,2,3\\}}")#text(", ")#mi("{{\\bf g}_i}")#text(" has the uniform distribution on ")#mi("{G_i}")#text(", and ")#mi("{{\\bf x}_i}")#text(" has the uniform distribution on ")#mi("{X_i}")#text(".")],
[#text("(ii’) (Independence) Any two of the random variables ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3}")#text(" are independent.")],
[#text("(iii’) (Determination) For any distinct ")#mi("{i,j,k \\in \\{1,2,3\\}}")#text(", ")#mi("{{\\bf g}_k}")#text(" is determined by ")#mi("{{\\bf g}_i,{\\bf g}_j}")#text(", and ")#mi("{{\\bf x}_k}")#text(" is determined by ")#mi("{{\\bf g}_i}")#text(" and ")#mi("{{\\bf x}_j}")#text(".")],
[#text("(v) (More independence) Any three of the random variables ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3}")#text(" that are not of the form ")#mi("{\\{{\\bf g}_i,{\\bf g}_j,{\\bf g}_k\\}}")#text(" or ")#mi("{\\{{\\bf g}_i,{\\bf x}_j,{\\bf x}_k\\}}")#text(" for distinct ")#mi("{i,j,k}")#text(" are independent.")]
)

#text("Axiom (ii’) is in fact a consequence of axiom (v), but we add it for emphasis. We refer to a sextet ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3)}")#text(" obeying the above axioms as a ")#emph[#text("group configuration")]#text(". It can be described graphically by the picture below, in which the collinearity of three random variables indicates a dependence between them, with non-collinear triples of variables being independent.")

#image("../assets/fa1d415a19461321fdaa9a883f3e91e42c53e24ed6e9a22bb3d3b1691e505d34-04b932a5467a7ce36545af6de63a3b0bcc36d0941f3fc07b74ed33517eb42f6c.png", width: 90%, alt: "Figure 2")

#text("The group configuration theorem concerns a generalisation of the above situation, in which the determination properties in axiom (iii’) are relaxed to the weaker properties of ")#emph[#text("algebraicity")]#text(". (In additive combinatorics, this would correspond to moving from a “99%” situation in which algebraic structure is present almost everywhere, to a “1%” settng in which it is only present a positive fraction of the time.) We say that one random variable ")#mi("{X}")#text(" taking values in one definable set ")#mi("{R}")#text(" is ")#emph[#text("algebraic")]#text(" with respect to another random variable ")#mi("{Y}")#text(" taking values in another definable set ")#mi("{R^{\\prime}}")#text(" if there is a relation ")#mi("{\\Sigma \\subset R \\times R^{\\prime}}")#text(" such that ")#mi("{(X,Y) \\in \\Sigma}")#text(" almost surely, and such that for each ")#mi("{y \\in R^{\\prime}}")#text(" there are only finitely many ")#mi("{x \\in R}")#text(" such that ")#mi("{(x,y) \\in \\Sigma}")#text(". More informally, ")#mi("{X}")#text(" is algebraic over ")#mi("{Y}")#text(" if ")#mi("{Y}")#text(" determines ")#mi("{X}")#text(" up to a finite ambiguity. For instance, if ")#mi("{X}")#text(" is uniformly distributed in ")#mi("{k}")#text(", then ")#mi("{X}")#text(" is algebraic with respect to any non-constant polynomial ")#mi("{P(X)}")#text(" of ")#mi("{P}")#text(".")

#text("Two random variables ")#mi("{X,Y}")#text(" are said to be ")#emph[#text("interalgebraic")]#text(" if they are each algebraic over each other. For instance, if ")#mi("{X}")#text(" is uniformly distributed in the affine line ")#mi("{k}")#text(", and ")#mi("{P, Q: k \\rightarrow k}")#text(" are two non-constant polynomials, then ")#mi("{P(X)}")#text(" and ")#mi("{Q(X)}")#text(" are interalgebraic. Note that interalgebraicity is an equivalence relation.")

#text("Now we can give the group configuration theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Group configuration theorem)")]#text(" ")#metadata(none) <tao-7a0d0e5a5c1e741c7341>#text(" Let ")#mi("{G_1,G_2,G_3,X_1,X_2,X_3}")#text(" be almost irreducible definable sets, and let ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3}")#text(" be random variables in ")#mi("{G_1,G_2,G_3,X_1,X_2,X_3}")#text(" respectively on a qualitative probability space obeying the following axioms:")

#list(
[#text("(i’) (Uniform distribution) For any ")#mi("{i \\in \\{1,2,3\\}}")#text(", ")#mi("{{\\bf g}_i}")#text(" has the uniform distribution on ")#mi("{G_i}")#text(", and ")#mi("{{\\bf x}_i}")#text(" has the uniform distribution on ")#mi("{X_i}")#text(".")],
[#text("(ii’) (Independence) Any two of the random variables ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3}")#text(" are independent.")],
[#text("(iii”) (Interalgebraicity) For any distinct ")#mi("{i,j,k \\in \\{1,2,3\\}}")#text(", ")#mi("{{\\bf g}_k}")#text(" is algebraic over ")#mi("{{\\bf g}_i,{\\bf g}_j}")#text(", and ")#mi("{{\\bf x}_k}")#text(" is algebraic over ")#mi("{{\\bf g}_i}")#text(" and ")#mi("{{\\bf x}_j}")#text(".")],
[#text("(v) (More independence) Any three of the random variables ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3}")#text(" that are not of the form ")#mi("{\\{{\\bf g}_i,{\\bf g}_j,{\\bf g}_k\\}}")#text(" or ")#mi("{\\{{\\bf g}_i,{\\bf x}_j,{\\bf x}_k\\}}")#text(" for distinct ")#mi("{i,j,k}")#text(" are independent.")],
[#text("(vi) (Irreducibility) The joint random variable ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3)}")#text(" has an irreducible distribution.")]
)

#text("Then, after extending the (qualitative) probability space if necessary, there exist a definable group ")#mi("{G}")#text(" that acts definably on a definable space ")#mi("{X}")#text(", as well as qualitative random variables ")#mi("{\\tilde {\\bf g}_i}")#text(" and ")#mi("{\\tilde {\\bf x}_i}")#text(" uniformly distributed in ")#mi("{G}")#text(" and ")#mi("{X}")#text(" respectively for ")#mi("{i=1,2,3}")#text(", with ")#mi("{\\tilde {\\bf g}_i}")#text(" algebraic over ")#mi("{{\\bf g}_i}")#text(" and ")#mi("{\\tilde {\\bf x}_i}")#text(" interalgebraic with ")#mi("{{\\bf x}_i}")#text(" with ")#mi("{i=1,2,3}")#text(", such that ")#metadata(none) <tao-e2ba41af03120f143f51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\tilde {\\bf g}_3 \\tilde {\\bf g}_2 \\tilde {\\bf g}_1 = 1, \\tilde {\\bf g}_1 \\cdot \\tilde {\\bf x}_2 = \\tilde {\\bf x}_3, \\tilde {\\bf g}_2 \\cdot \\tilde {\\bf x}_3 = \\tilde {\\bf x}_1, \\tilde {\\bf g}_3 \\cdot \\tilde {\\bf x}_1 = \\tilde {\\bf x}_2")]]

#text("almost surely, and with the ")#mi("{\\tilde {\\bf g}_i, \\tilde {\\bf x}_i}")#text(" obeying the same independence and irreducibility hypotheses as the ")#mi("{{\\bf g}_i, {\\bf x}_i}")#text(".")
]

#text("This theorem was first established by ")#link("http://www.ams.org/mathscinet-getitem?mr=746943")[#text("Zilber")]#text(", who worked in the more general setting of strongly minimal theories, and then strengthened significantly in the thesis of Hrushovski, who treated the case of stable theories. (However, in these more general situations, the space ")#mi("{X}")#text(" is restricted to be “one-dimensional” for technical reasons.) We give a proof below the fold, following an exposition of Hrushovski’s method ")#link("http://www.ams.org/mathscinet-getitem?mr=985348")[#text("by Bouscaren")]#text(". (See also a proof of a result very close to the above theorem, avoiding model-theoretic language, ")#link("http://www.ams.org/mathscinet-getitem?mr=3004808")[#text("by Elekes and Szabo")]#text(".) The irreducibility axiom (vi) can be relaxed, but then the conclusion becomes more complicated (there might not be a single group structure or group action involved, but rather an average of such actions).")

#text("The group configuration theorem has a number of applications to combinatorics; roughly speaking, this theorem is to “approximately associative” definable maps as ")#link("http://en.wikipedia.org/wiki/Freiman's_theorem")[#text("Freiman’s theorem")]#text(" is for sets of small doubling. The aforementioned paper of Elekes and Szabo is one example of the configuration theorem in action; another is Theorem 41 of ")#link("https://terrytao.wordpress.com/2012/11/14/expanding-polynomials-over-finite-fields-of-large-characteristic-and-a-regularity-lemma-for-definable-sets/")[#text("this paper of mine")]#text(", which I proved by a different method (based on Riemann surface arguments), but for which a stronger statement has since been proven using the group configuration theorem by Hrushovski (private communication).")

#text("Now we prove Theorem ")#link(<tao-7a0d0e5a5c1e741c7341>)[#text("3")]#text(". There are two main phases of the argument. The first phase involves upgrading several of the algebraicity hypotheses in axiom (iii”) to determination, by replacing several of the ")#mi("{{\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3}")#text(" using algebraic changes of variable. Once this is done, the second phase consists of applying a modification of the proof of the group chunk theorem to locate the definable group ")#mi("{G}")#text(" (and also the definable space ")#mi("{X}")#text(" that ")#mi("{G}")#text(" acts on), and to connect this action to the group configuration.")

#text("We begin with a simple dimension counting observation. By the axioms, the random variable ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3)}")#text(" has an irreducible distribution and is thus uniformly distributed on some almost irreducible definable set ")#mi("{V}")#text(", with ")#mi("{{\\bf g}_3}")#text(" algebraic over ")#mi("{({\\bf g}_1,{\\bf g}_2)}")#text(", which is uniformly distributed on ")#mi("{G_1 \\times G_2}")#text(". Taking dimensions, we conclude that ")#mi("{\\text{dim}(V) = \\text{dim}(G_1)+\\text{dim}(G_2)}")#text(". Similarly for permutations. This implies that")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(G_1)=\\text{dim}(G_2)=\\text{dim}(G_3) = d_G")]]

#text("for some natural number ")#mi("{d_G}")#text("; a similar argument using the ")#mi("{{\\bf g}_i,{\\bf x}_j,{\\bf x}_k}")#text(" triples shows that")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(X_1)=\\text{dim}(X_2)=\\text{dim}(X_3) = d_X")]]

#text("for some natural number ")#mi("{d_X}")#text(". Next, since ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf x}_3)}")#text(" are uniformly distributed on ")#mi("{G_1 \\times G_2 \\times X_3}")#text(", and the other three variables ")#mi("{{\\bf g}_3,{\\bf x}_1,{\\bf x}_2}")#text(" are algebraic over these variables, we see that the tuple ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3)}")#text(" is uniformly distributed on some almost irreducible definable set of dimension ")#mi("{2d_G+d_X}")#text(".")

#text("We now begin the first phase. Currently, by axiom (iii”), ")#mi("{{\\bf x}_2}")#text(" is algebraic over ")#mi("{{\\bf g}_1,{\\bf x}_3}")#text(". We now use further dimension counting upgrade this algebraicity relationship to determination, basically by removing some information from ")#mi("{{\\bf x}_2}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-cbf38e496835a79fe9ba>#text(" Let the assumptions be as in Theorem ")#link(<tao-7a0d0e5a5c1e741c7341>)[#text("3")]#text(". Then there exists a random variable ")#mi("{{\\bf x}^{\\prime\\prime}_2}")#text(" which is interalgebraic with ")#mi("{{\\bf x}_2}")#text(" and uniformly distributed in some almost irreducible set ")#mi("{X^{\\prime\\prime}_2}")#text(", such that ")#mi("{{\\bf x}^{\\prime\\prime}_2}")#text(" is determined by ")#mi("{{\\bf g}_1,{\\bf x}_3}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\Sigma}")#text(" be the support of ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3)}")#text(", and let ")#mi("{\\Sigma_2}")#text(" be the projection of ")#mi("{\\Sigma}")#text(" onto ")#mi("{X_1 \\times X_3 \\times G_1 \\times G_2 \\times G_3}")#text(", then ")#mi("{\\Sigma_2}")#text(" is a closed variety, and as ")#mi("{{\\bf x}_2}")#text(" is algebraic over ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_3)}")#text(", ")#mi("{\\Sigma_2}")#text(" is generically finite over ")#mi("{\\Sigma}")#text(". In particular, ")#mi("{\\Sigma_2}")#text(" also has dimension ")#mi("{2d_G + d_X}")#text(". We then form the pullback (or base change) ")#mi("{\\Sigma_2^2 := \\Sigma_2 \\times_\\Sigma \\Sigma_2}")#text(" of two copies of ")#mi("{\\Sigma_2}")#text(" over (a generic subset of) ")#mi("{\\Sigma}")#text("; we view ")#mi("{\\Sigma_2^2}")#text(" as a subset of ")#mi("{G_1 \\times G_2 \\times G_3 \\times X_1 \\times X_2 \\times X_2 \\times X_3}")#text(". This is a definable set, but is not necessarily almost irreducible.")

#text("Now consider the projection ")#mi("{S}")#text(" of ")#mi("{\\Sigma_2^2}")#text(" to ")#mi("{X_2 \\times X_2}")#text(". The set ")#mi("{S}")#text(" contains the diagonal ")#mi("{\\{(x_2,x_2): x_2 \\in X_2 \\}}")#text(" and thus has dimension at least ")#mi("{d_X}")#text(". We claim that ")#mi("{S}")#text(" in fact has dimension exactly ")#mi("{d_X}")#text(". Indeed, suppose this were not the case, then ")#mi("{S}")#text(" would contain an irreducible variety ")#mi("{S^{\\prime}}")#text(" of dimension ")#mi("{d_X+r}")#text(" for some positive ")#mi("{r}")#text(". Now observe that as ")#mi("{{\\bf x}_2}")#text(" is algebraic over ")#mi("{{\\bf g}_1,{\\bf x}_3}")#text(", the projection of ")#mi("{\\Sigma}")#text(" to ")#mi("{G_1 \\times X_3 \\times X_2}")#text(" is generically finite over ")#mi("{G_1 \\times X_3}")#text(", which has dimension ")#mi("{d_G+d_X}")#text("; taking pullback with itself, we conclude that the projection of ")#mi("{\\Sigma_2^2}")#text(" to ")#mi("{G_1 \\times X_3 \\times X_2 \\times X_2}")#text(" also has dimension ")#mi("{d_G+d_X}")#text(". Thus, over a generic point in ")#mi("{S^{\\prime} \\subset X_2 \\times X_2}")#text(", the fibre of ")#mi("{\\Sigma_2^2}")#text(" projected to ")#mi("{G_1 \\times X_3}")#text(" has dimension at most ")#mi("{d_G-r}")#text(". Similarly, the projection of this fibre to ")#mi("{G_3 \\times X_1}")#text(" has dimension at most ")#mi("{d_G-r}")#text(". Since ")#mi("{{\\bf g}_2}")#text(" is algebraic over ")#mi("{{\\bf g}_1,{\\bf g}_3}")#text(", we conclude that the generic fibre of ")#mi("{\\Sigma_2^2}")#text(" over a point in ")#mi("{S^{\\prime}}")#text(" has total dimensino at most ")#mi("{d_G-r + d_G-r}")#text(", so that the preimage of ")#mi("{S^{\\prime}}")#text(" in ")#mi("{\\Sigma_2^2}")#text(" has dimension at most")

#align(center)[#tao-fit-display[#mitex("(d_X+r) + (d_G-r) + (d_G-r) < d_X + 2d_G")]]

#text("and is thus a lower-dimensional component of ")#mi("{\\Sigma_2^2}")#text(" (or of ")#mi("{\\Sigma}")#text(" after projecting to either of the two copies of ")#mi("{\\Sigma}")#text("). Thus, if we pass to a suitable generic subset of ")#mi("{\\Sigma}")#text(", the projection ")#mi("{S}")#text(" of ")#mi("{\\Sigma_2^2}")#text(" to ")#mi("{X_2 \\times X_2}")#text(" has dimension ")#mi("{d_X}")#text(". Passing to a further generic subset if necessary, we may assume that ")#mi("{S}")#text(" is algebraic in the sense that any horizontal or vertical line in ")#mi("{X_2 \\times X_2}")#text(" meets ")#mi("{S}")#text(" in at most finitely many points. From the Noetherian property, we see that there is in fact a uniform upper bound ")#mi("{M}")#text(" on how many such points can lie on a line (this is basically the degree of ")#mi("{S}")#text(").")

#text("We now define the random variable ")#mi("{{\\bf x}^{\\prime\\prime}_2}")#text(" to be the set of all ")#mi("{y_2}")#text(" with ")#mi("{({\\bf x}_2,y_2) \\in S}")#text(", such that ")#mi("{({\\bf g}_1,y_2,{\\bf x}_3)}")#text(" lies in the projection of (the generic portion of ")#mi("{\\Sigma}")#text(" we are working with) to ")#mi("{G_1 \\times X_2 \\times X_3}")#text(". By the above discussion, this is a finite subset of ")#mi("{X}")#text(", and the set of all such possible ")#mi("{x^{\\prime\\prime}_2}")#text(" can be parameterised in a definable way (indeed, it lies inside the ")#mi("{m}")#text("-fold powers of ")#mi("{S}")#text(" over ")#mi("{X_2}")#text(" for ")#mi("{m=1,\\ldots,M}")#text("), and is interalgebraic with ")#mi("{{\\bf x}_2}")#text(". By construction, ")#mi("{{\\bf x}^{\\prime\\prime}_2}")#text(" is also determined by ")#mi("{({\\bf g}_1,{\\bf x}_3)}")#text("; as the latter is uniformly distributed on some almost irreducible set, ")#mi("{{\\bf x}^{\\prime\\prime}_2}")#text(" is also, and the claim follows. ")#mi("\\Box")

#text("A similar argument provides a random variable ")#mi("{x^{\\prime\\prime}_1}")#text(" interalgebraic with ")#mi("{{\\bf x}_1}")#text(" such that ")#mi("{{\\bf x}^{\\prime\\prime}_1}")#text(" is determined by ")#mi("{{\\bf g}_2,{\\bf x}_3}")#text(". By replacing ")#mi("{{\\bf x}_1,{\\bf x}_2,X_1,X_2}")#text(" with ")#mi("{{\\bf x}^{\\prime\\prime}_1, {\\bf x}^{\\prime\\prime}_2,X^{\\prime\\prime}_1,X^{\\prime\\prime}_2}")#text(" respectively, and checking that none of the axioms (i’). (ii’), (iii”), (v), (vi) are destroyed by this replacement, we see that we may reduce without loss of generality to the case in which we have the additional axiom")

#list(
[#text("(iii”‘) ")#mi("{{\\bf x}_1}")#text(" is determined by ")#mi("{{\\bf g}_2,{\\bf x}_3}")#text(", and ")#mi("{{\\bf x}_2}")#text(" is determined by ")#mi("{{\\bf g}_1,{\\bf x}_3}")#text(".")]
)

#text("Now we turn to the task of making ")#mi("{{\\bf x}_3}")#text(" determined both by ")#mi("{{\\bf g}_1,{\\bf x}_2}")#text(" and by ")#mi("{{\\bf g}_2,{\\bf x}_1}")#text(". We are unable to effectively utilise (suitable permutations of) Proposition ")#link(<tao-cbf38e496835a79fe9ba>)[#text("4")]#text(" here, because any replacement of ")#mi("{{\\bf x}_3}")#text(" by a random variable with less information content will likely destroy axiom (iii”‘). However, we can at least construct a random variable ")#mi("{{\\bf x}^{\\prime}_3}")#text(" interalgebraic with ")#mi("{{\\bf x}_3}")#text(" that is determined by the joint random variable ")#mi("{({\\bf g}_1,{\\bf x}_2,{\\bf g}_2,{\\bf x}_1)}")#text(". Indeed, the support ")#mi("{\\Gamma}")#text(" of ")#mi("{({\\bf g}_1,{\\bf x}_2,{\\bf g}_2,{\\bf x}_1,{\\bf x}_3)}")#text(" is generically finite over ")#mi("{({\\bf g}_1,{\\bf x}_2,{\\bf g}_2,{\\bf x}_1)}")#text(", and by repeating the dimension counting arguments from Proposition ")#link(<tao-cbf38e496835a79fe9ba>)[#text("4")]#text(", we see tht the projection ")#mi("{\\tilde S}")#text(" of the pullback ")#mi("{\\Gamma \\times_{G_1\\times X_2 \\times G_2 \\times X_1} \\Gamma}")#text(" to ")#mi("{X_3 \\times X_3}")#text(" has dimension at most ")#mi("{d_X}")#text(", and so has finite fibres after passing to a generic subset. If we then set ")#mi("{{\\bf x}^{\\prime}_3}")#text(" to be the fibre of ")#mi("{\\Gamma}")#text(" over ")#mi("{({\\bf g}_1,{\\bf x}_2,{\\bf g}_2,{\\bf x}_1)}")#text(", we conclude as before that ")#mi("{{\\bf x}^{\\prime}_3}")#text(" is interalgebraic with ")#mi("{{\\bf x}_3}")#text(", and is clearly determined by ")#mi("{({\\bf g}_1,{\\bf x}_2,{\\bf g}_2,{\\bf x}_1)}")#text(". Also, each element of ")#mi("{{\\bf x}^{\\prime}_3}")#text(", together with ")#mi("{{\\bf g}_1}")#text(", generically determines ")#mi("{{\\bf x}_2}")#text(" by axiom (iii”‘), and hence ")#mi("{{\\bf x}_2}")#text(" is determined by ")#mi("{{\\bf g}_1, {\\bf x}^{\\prime}_3}")#text("; similarly ")#mi("{{\\bf x}_1}")#text(" is determined by ")#mi("{{\\bf g}_1, {\\bf x}^{\\prime}_3}")#text(". Thus by replacing ")#mi("{{\\bf x}_3}")#text(" with ")#mi("{{\\bf x}^{\\prime}_3}")#text(", we may impose the additional axiom")

#list(
[#text("(vii) ")#mi("{{\\bf x}_3}")#text(" is determined by ")#mi("{{\\bf g}_1, {\\bf g}_2,{\\bf x}_1, {\\bf x}_2}")]
)

#text("while retaining all previous axioms.")

#text("Now we perform the following “doubling” trick, creating some new random variables by extending the probability space. As before, let ")#mi("{\\Sigma \\subset G_1 \\times G_2 \\times G_3 \\times X_1 \\times X_2 \\times X_3}")#text(" be the support of ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3)}")#text(". As ")#mi("{({\\bf g}_2, {\\bf g}_3, {\\bf x}_1)}")#text(" is uniformly distributed in ")#mi("{G_2 \\times G_3 \\times X_1}")#text(", we see that for generic ")#mi("{(g_1,g_2,g_3,x_1,x_2,x_3) \\in \\Sigma}")#text(" and generic ")#mi("{g^{\\prime}_3 \\in G_3}")#text(", there is a non-zero finite number of tuples ")#mi("{(g^{\\prime}_1, x^{\\prime}_2) \\in G_1 \\times X_2}")#text(" such that ")#mi("{(g^{\\prime}_1,g_2,g^{\\prime}_3,x_1,x^{\\prime}_2,x_3) \\in \\Sigma}")#text(". Similarly there are a non-zero finite number of tuples ")#mi("{(g^{\\prime}_2,x^{\\prime}_3)}")#text(" such that ")#mi("{(g_1,g^{\\prime}_2,g^{\\prime}_3,x^{\\prime}_1, x_2, x_3) \\in \\Sigma}")#text(". Thus, for generic ")#mi("{g^{\\prime}_3}")#text(", if we let ")#mi("{\\Lambda_{g^{\\prime}_3}}")#text(" be the set of all tuples")

#align(center)[#tao-fit-display[#mitex("(g_1,g^{\\prime}_1,g_2,g^{\\prime}_2,g_3,x_1,x^{\\prime}_1,x_2,x^{\\prime}_2,x_3)")]]

#text("such that")

#align(center)[#tao-fit-display[#mitex("(g_1,g_2,g_3,x_1,x_2,x_3), (g^{\\prime}_1,g_2,g^{\\prime}_3,x_1,x^{\\prime}_2,x_3), (g_1,g^{\\prime}_2,g^{\\prime}_3,x^{\\prime}_1,x_2,x_3) \\in \\Sigma")]]

#text("(see figure), then ")#mi("{\\Lambda_{g^{\\prime}_3}}")#text(" is a generically finite cover of ")#mi("{\\Sigma}")#text(" (projecting onto the ")#mi("{(g_1,g_2,g_3,x_1,x_2,x_3)}")#text(" coordinates). Thus, if we perform a base change of the probability space ")#mi("{\\Omega}")#text(" (which we view as lying over ")#mi("{\\Sigma}")#text(") to ")#mi("{\\Lambda_{g^{\\prime}_3}}")#text(", we may now create random variables")

#align(center)[#tao-fit-display[#mitex("({\\bf g}_1,{\\bf g}^{\\prime}_1,{\\bf g}_2,{\\bf g}^{\\prime}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}^{\\prime}_1,{\\bf x}_2,{\\bf x}^{\\prime}_2,{\\bf x}_3) \\in \\Lambda_{g^{\\prime}_3}")]]

#text("with the ")#mi("{{\\bf g}_i, {\\bf x}_i}")#text(" being an extension of the previous random variables of the same name.")

#image("../assets/d1e2f46ea188687a0d465d878571537cc35dabf75d6c210d68612fbde3dc4d82-f583fbb211ae64cc3ce047ea037207853fd44dbf291d41104d58b134a6f71c3a.png", width: 90%, alt: "Figure 3")

#text("Since ")#mi("{{\\bf x}_2}")#text(" is algebraic over ")#mi("{{\\bf x}_1, {\\bf g}_3}")#text(", we see (as ")#mi("{g^{\\prime}_3}")#text(" is generic and deterministic) that ")#mi("{{\\bf x}^{\\prime}_2}")#text(" is algebraic over ")#mi("{{\\bf x}_1}")#text(". Similarly ")#mi("{{\\bf x}^{\\prime}_1}")#text(" is algebraic over ")#mi("{{\\bf x}_2}")#text(", and also ")#mi("{{\\bf g}^{\\prime}_1}")#text(" is algebraic over ")#mi("{{\\bf g}_2}")#text(" and ")#mi("{{\\bf g}^{\\prime}_2}")#text(" is algebraic over ")#mi("{{\\bf g}_1}")#text(". From (iii) we also see that ")#mi("{{\\bf x}^{\\prime}_1}")#text(" is determined by ")#mi("{{\\bf g}^{\\prime}_2}")#text(" and ")#mi("{{\\bf x}_3}")#text(", and ")#mi("{{\\bf x}^{\\prime}_2}")#text(" is determined by ")#mi("{{\\bf g}^{\\prime}_1}")#text(" and ")#mi("{{\\bf x}_3}")#text(". Finally from (vii) we see that ")#mi("{{\\bf g}^{\\prime}_1, {\\bf g}_2, {\\bf x}_1, {\\bf x}^{\\prime}_2}")#text(" determine ")#mi("{{\\bf x}_3}")#text(", and similarly ")#mi("{{\\bf g}_1, {\\bf g}^{\\prime}_2, {\\bf x}^{\\prime}_1, {\\bf x}_2}")#text(" determine ")#mi("{{\\bf x}_3}")#text(". Thus if we set")

#tao-aligned(keep: true)[


#tao-math("\\tilde {\\bf g}_1  & := ({\\bf g}_1, {\\bf g}^{\\prime}_2)", block: true)



#tao-math("\\tilde {\\bf g}_2  & := ({\\bf g}_2, {\\bf g}^{\\prime}_1)", block: true)



#tao-math("\\tilde {\\bf g}_3  & := {\\bf g}_3", block: true)



#tao-math("\\tilde {\\bf x}_1  & := ({\\bf x}_1, {\\bf x}^{\\prime}_2)", block: true)



#tao-math("\\tilde {\\bf x}_2  & := ({\\bf x}_2, {\\bf x}^{\\prime}_1)", block: true)



#tao-math("\\tilde {\\bf x}_3  & := {\\bf x}_3", block: true)
]

#text("then we see that")

#list(
[#mi("{\\tilde {\\bf g}_i}")#text(" is interalgebraic with ")#mi("{{\\bf g}_i}")#text(" for ")#mi("{i=1,2,3}")#text(";")],
[#mi("{\\tilde {\\bf x}_i}")#text(" is interalgebraic with ")#mi("{{\\bf x}_i}")#text(" for ")#mi("{i=1,2,3}")#text(";")],
[#mi("{\\tilde {\\bf x}_3}")#text(" is determined by ")#mi("{\\tilde {\\bf g}_1, \\tilde {\\bf x}_2}")#text(";")],
[#mi("{\\tilde {\\bf x}_3}")#text(" is determined by ")#mi("{\\tilde {\\bf g}_2, \\tilde {\\bf x}_1}")#text(";")],
[#mi("{\\tilde {\\bf x}_2}")#text(" is determined by ")#mi("{\\tilde {\\bf g}_1, \\tilde {\\bf x}_3}")#text(";")],
[#mi("{\\tilde {\\bf x}_1}")#text(" is determined by ")#mi("{\\tilde {\\bf g}_2, \\tilde {\\bf x}_3}")#text(".")]
)

#text("Thus, by replacing ")#mi("{{\\bf g}_i}")#text(" and ")#mi("{{\\bf x}_i}")#text(" with ")#mi("{\\tilde {\\bf g}_i}")#text(" and ")#mi("{\\tilde {\\bf x}_i}")#text(", we may now obtain the additional axiom")

#list(
[#text("(vii’) ")#mi("{{\\bf x}_3}")#text(" is determined by ")#mi("{{\\bf g}_1, {\\bf x}_2}")#text(", and also ")#mi("{{\\bf x}_3}")#text(" is determined by ")#mi("{{\\bf g}_2, {\\bf x}_1}")#text(".")]
)

#text("We now have enough determination relations to begin the second phase of the argument, in which the arguments used to prove the group chunk theorem may be applied. Observe that ")#mi("{{\\bf g}_1, {\\bf x_2}}")#text(" determine ")#mi("{{\\bf x}_3}")#text(", and ")#mi("{{\\bf g}_1,{\\bf x}_3}")#text(" determine ")#mi("{{\\bf x}_2}")#text(". Thus, for generic ")#mi("{g_1 \\in G_1}")#text(", we have a generically bijective definable map ")#mi("{\\phi_{g_1}: X_2 \\rightarrow X_3}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\phi_{{\\bf g}_1}( {\\bf x}_2 ) = {\\bf x}_3")]]

#text("almost surely, with ")#mi("{\\phi_{g_1}}")#text(" also depending definably on ")#mi("{g_1}")#text(". Similarly, for generic ")#mi("{g_2 \\in G_2}")#text(", we have a generically bijective definable map ")#mi("{\\psi_{g_2}: X_1 \\rightarrow X_3}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\psi_{{\\bf g}_2}( {\\bf x}_1 ) = {\\bf x}_3")]]

#text("almost surely, with ")#mi("{\\psi_{g_2}}")#text(" also depending definably on ")#mi("{g_2}")#text(".")

#text("We now relate the ")#mi("{\\phi_{g_1}}")#text(" and ")#mi("{\\psi_{g_2}}")#text(" to each other:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5")]#text(" After extending the probability space if necessary, there exist random variables ")#mi("{{\\bf g}^{\\prime}_1, {\\bf g}^{\\prime}_2}")#text(" uniformly distributed in ")#mi("{G_1,G_2}")#text(" respectively, such that we almost surely have the identity ")#metadata(none) <tao-24a7324211e733dd3ebf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\phi_{{\\bf g}_1} \\circ \\phi_{{\\bf g}^{\\prime}_1}^{-1} = \\psi_{{\\bf g}_2} \\circ \\psi_{{\\bf g}^{\\prime}_2}^{-1}")]]

#text("holds generically. Furthermore, any three of the ")#mi("{{\\bf g}_1, {\\bf g}^{\\prime}_1, {\\bf g}_2, {\\bf g}^{\\prime}_2}")#text(" are independent, with the fourth being algebraic over these three.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\Sigma^{\\prime}}")#text(" be the generic subset of ")#mi("{\\Sigma}")#text(" consisting of those ")#mi("{(g_1,g_2,g_3,x_1,x_2,x_3)}")#text(" such that ")#metadata(none) <tao-8c39c63488260c318aea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\phi_{g_1}(x_2) = x_3; \\quad \\phi_{g_1}^{-1}(x_3) = x_2; \\psi_{g_2}(x_1) = x_3; \\psi_{g_2}^{-1}(x_3) = x_1")]]

#text("(recall from our conventions that these statements implicitly require that all expressions be well-defined, thus for instance ")#mi("{x_3}")#text(" must lie in the domain of ")#mi("{\\phi_{g_1}^{-1}}")#text(" for the second statement to be true). The set ")#mi("{\\Sigma^{\\prime}}")#text(" surjects onto a subset of ")#mi("{G_3 \\times X_1 \\times X_2}")#text(" of dimension ")#mi("{d_G + d_X}")#text(" (because ")#mi("{{\\bf x}_2}")#text(" is algebraic over ")#mi("{({\\bf g}_3, {\\bf x}_1)}")#text(", which is uniformly distributed over ")#mi("{G_3 \\times X_1}")#text("), so the generic fibres have dimension ")#mi("{(2d_G+d_X) - (d_G+d_X) = d_G}")#text(". If we let ")#mi("{\\Xi := \\Sigma^{\\prime} \\times_{G_3\\times X_1 \\times X_2} \\Sigma^{\\prime}}")#text(", then ")#mi("{\\Xi}")#text(" thus has dimension ")#mi("{(d_G+d_X) + d_G + d_G = 3d_G + d_X}")#text(". We view ")#mi("{\\Xi}")#text(" as a subset of ")#mi("{G_1^2 \\times G_2^2 \\times G_3 \\times X_1 \\times X_2 \\times X_3^2}")#text(" and parameterise it as")

#align(center)[#tao-fit-display[#mitex("(g_1,g^{\\prime}_1,g_2,g^{\\prime}_2,g_3,x_1,x_2,x_3,x_3^{\\prime}).")]]

#text("By a base change, we may then find a set of random variables")

#align(center)[#tao-fit-display[#mitex("({\\bf g}_1,{\\bf g}^{\\prime}_1,{\\bf g}_2,{\\bf g}^{\\prime}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3,{\\bf x}_3^{\\prime})")]]

#text("uniformly distributed in ")#mi("{\\Xi}")#text(", which restricts to the existing tuple ")#mi("{({\\bf g}_1,{\\bf g}_2,{\\bf g}_3,{\\bf x}_1,{\\bf x}_2,{\\bf x}_3)}")#text(" of random variables.")

#image("../assets/3b908da3691399f8589dab1e921bb2539710dc1b1aa11f09d72d564d3a52deb3-6226a93a77fddcd658b20f41bdc51a889c9c4ff90589c5f6020ad8c288e54f01.png", width: 90%, alt: "Figure 4")

#text("By construction, one has")

#align(center)[#tao-fit-display[#mitex("\\phi_{{\\bf g}_1} \\circ \\phi_{{\\bf g}^{\\prime}_1}^{-1}({\\bf x}^{\\prime}_3) = {\\bf x}_3 = \\psi_{{\\bf g}_2} \\circ \\psi_{{\\bf g}^{\\prime}_2}^{-1}({\\bf x}^{\\prime}_3)")]]

#text("almost surely. On the other hand, the support of ")#mi("{({\\bf g}_1, {\\bf g}_2, {\\bf g}^{\\prime}_1, {\\bf g}^{\\prime}_2, {\\bf g}_3)}")#text(" has dimension at most ")#mi("{3d_G}")#text(" (because ")#mi("{{\\bf g}_3, {\\bf g}^{\\prime}_2}")#text(" are algebraic over ")#mi("{{\\bf g}_1, {\\bf g}_2,{\\bf g}^{\\prime}_1}")#text(") and so for generic choices of these random variables, the set of possible ")#mi("{({\\bf x}_1, {\\bf x}_2, {\\bf x}_3, {\\bf x}^{\\prime}_3)}")#text(" has dimension at least ")#mi("{(3d_G+d_X)-3d_G=d_X}")#text("; since any one of these variables is algebraic over any other (once the ")#mi("{({\\bf g}_1, {\\bf g}_2, {\\bf g}^{\\prime}_1, {\\bf g}^{\\prime}_2, {\\bf g}_3)}")#text(" are fixed), we conclude that ")#mi("{{\\bf x}^{\\prime}_3}")#text(" cannot be restricted to any lower-dimensional set than ")#mi("{X}")#text(". We conclude that almost surely, ")#link(<tao-24a7324211e733dd3ebf>)[#text("(2)")]#text(" holds generically.")

#text("The above discussion shows that the support of ")#mi("{({\\bf g}_1, {\\bf g}_2, {\\bf g}^{\\prime}_1, {\\bf g}^{\\prime}_2, {\\bf g}_3)}")#text(" has dimension exactly ")#mi("{3d_G}")#text("; as any three of ")#mi("{{\\bf g}_1, {\\bf g}^{\\prime}_1, {\\bf g}_2, {\\bf g}^{\\prime}_2}")#text(" are such that the remaining two random variables in ")#mi("{({\\bf g}_1, {\\bf g}_2, {\\bf g}^{\\prime}_1, {\\bf g}^{\\prime}_2, {\\bf g}_3)}")#text(" are algebraic over these three, the final claims of the lemma follow. ")#mi("\\Box")

#text("We rewrite ")#link(<tao-24a7324211e733dd3ebf>)[#text("(2)")]#text(" as ")#metadata(none) <tao-29000b4abdf54eaf7787>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("[\\phi_{{\\bf g}_1}] \\circ [\\phi_{{\\bf g}^{\\prime}_1}]^{-1} = [\\psi_{{\\bf g}_2}] \\circ [\\psi_{{\\bf g}^{\\prime}_2}]^{-1}")]]

#text("almost surely, where ")#mi("{[f]}")#text(" is the equivalence class of a generically bijective, and definable, partial function ")#mi("{f: X \\rightarrow Y}")#text(" up to generic equivalence, and inversion and composition on such equivalence classes is defined in the obvious manner. This equivalence class can be made definable by identifying ")#mi("{[f]}")#text(" with the closure of the top-dimensional component of the graph ")#mi("{\\{ (x_3,f(x_3)): x_3 \\in X_3\\}}")#text(" of ")#mi("{f}")#text(", and then expressing this in Chow coordinates (or using the Hilbert scheme); this makes equivalence classes")

#align(center)[#tao-fit-display[#mitex("\\overline{{\\bf g}}_1 := [\\phi_{{\\bf g}_1}]; \\overline{{\\bf g}}^{\\prime}_1 := [\\phi_{{\\bf g}^{\\prime}_1}]; \\overline{{\\bf g}}_2 := [\\psi_{{\\bf g}_2}]; \\overline{{\\bf g}}^{\\prime}_2 := [\\psi_{{\\bf g}^{\\prime}_2}]")]]

#text("into random variables uniformly distributed in some definable sets ")#mi("{\\overline{G}_1,\\overline{G}_2}")#text(", which are definable images of ")#mi("{G_1,G_2}")#text(" and thus almost irreducible (after passing to generic subsets of ")#mi("{G_1,G_2}")#text(" if necessary). We thus see that any three of ")#mi("{\\overline{{\\bf g}}_1, \\overline{{\\bf g}}^{\\prime}_1, \\overline{{\\bf g}}_2, \\overline{{\\bf g}}^{\\prime}_2}")#text(" are independent, and we have the relation ")#metadata(none) <tao-4b13eb6c036c68f12f2e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\overline{{\\bf g}}_1 \\circ (\\overline{{\\bf g}}^{\\prime}_1)^{-1} = \\overline{{\\bf g}}_2 \\circ \\overline{{\\bf g}}^{\\prime}_2)^{-1}")]]

#text("almost surely.")

#text("In particular, for fixed choices of ")#mi("{\\overline{\\bf g}^{\\prime}_1}")#text(", ")#mi("{\\overline{\\bf g}^{\\prime}_2}")#text(", ")#mi("{\\overline{\\bf g}_1}")#text(" determines ")#mi("{\\overline{\\bf g}_2}")#text(" and vice versa. Thus ")#mi("{\\overline{G}_1}")#text(" and ")#mi("{\\overline{G}_2}")#text(" have the same dimension, say ")#mi("{d_{\\overline{G}}}")#text(". (This could be strictly less than ")#mi("{d_G}")#text(", basically because the original sets ")#mi("{G_1,G_2,G_3}")#text(" may contain superfluous degrees of freedom which do not interact with the spaces ")#mi("{X_1,X_2,X_3}")#text(".)")

#text("We now let ")#mi("{G}")#text(" be the set of all equivalence classes ")#mi("{[f]}")#text(" of generically bijective and definable partial functions ")#mi("{f: X_3 \\rightarrow X_3}")#text(" with the following properties:")

#list(
[#text("For generic ")#mi("{\\overline{g}_1 \\in \\overline{G}_1}")#text(", there exists ")#mi("{\\overline{g}^{\\prime}_1 \\in \\overline{G}_1}")#text(" such that ")#mi("{[f] = \\overline{g}_1 \\circ (\\overline{g}^{\\prime}_1)^{-1}}")#text(".")],
[#text("For generic ")#mi("{\\overline{g}^{\\prime}_1 \\in \\overline{G}_1}")#text(", there exists ")#mi("{\\overline{g}_1 \\in \\overline{G}_1}")#text(" such that ")#mi("{[f] = \\overline{g}_1 \\circ (\\overline{g}^{\\prime}_1)^{-1}}")#text(".")],
[#text("For generic ")#mi("{\\overline{g}_2 \\in \\overline{G}_2}")#text(", there exists ")#mi("{\\overline{g}^{\\prime}_2 \\in \\overline{G}_2}")#text(" such that ")#mi("{[f] = \\overline{g}_2 \\circ (\\overline{g}^{\\prime}_2)^{-1}}")#text(".")],
[#text("For generic ")#mi("{\\overline{g}^{\\prime}_2 \\in \\overline{G}_2}")#text(", there exists ")#mi("{\\overline{g}_2 \\in \\overline{G}_2}")#text(" such that ")#mi("{[f] = \\overline{g}_2 \\circ (\\overline{g}^{\\prime}_2)^{-1}}")#text(".")]
)

#text("This is a definable set; ")#mi("{G}")#text(" is contained in the image of ")#mi("{\\overline{G}_1 \\times \\overline{G}_1}")#text(" by the map ")#mi("{(g_1,g^{\\prime}_1) \\mapsto g_1 \\circ (g^{\\prime}_1)^{-1}}")#text(" with fibres of dimension at most ")#mi("{d_{\\overline{G}}}")#text(", and thus can have at most one component of dimension ")#mi("{d_{\\overline{G}}}")#text(" (and no larger dimensional components); on the other hand, from ")#link(<tao-4b13eb6c036c68f12f2e>)[#text("(5)")]#text(" ")#mi("{G}")#text(" contains the image of a generic subset of ")#mi("{\\overline{G}_1 \\times \\overline{G}_1}")#text("; thus ")#mi("{G}")#text(" has dimension exactly ")#mi("{d_{\\overline{G}}}")#text(" and is essentially irreducible.")

#text("By construction, ")#mi("{G}")#text(" contains the (equivalence class of) the identity map on ")#mi("{X_3}")#text(" and is closed under inversion. We also claim that it is closed under composition, which would make ")#mi("{G}")#text(" a definable group. Indeed, let ")#mi("{[f], [\\tilde f] \\in G}")#text(". For generic ")#mi("{\\overline{g}_1 \\in \\overline{G}_1}")#text(", there exists ")#mi("{\\overline{g}^{\\prime}_1 \\in \\overline{G}_1}")#text(" such that ")#mi("{[f] = \\overline{g}_1 \\circ (\\overline{g}^{\\prime}_1)^{-1}}")#text(". The map ")#mi("{\\overline{g}_1 \\rightarrow \\overline{g}^{\\prime}_1}")#text(" is a generic bijection and ")#mi("{\\overline{G}_1}")#text(" is almost irreducible, and so ")#mi("{\\overline{g}^{\\prime}_1}")#text(" is generic also. Thus, we may generically also find ")#mi("{\\overline{g}^{\\prime\\prime}_1 \\in \\overline{G}_1}")#text(" such that ")#mi("{[f^{\\prime}] = \\overline{g}^{\\prime}_1 \\circ (\\overline{g}^{\\prime\\prime}_1)^{-1}}")#text(", and hence ")#mi("{[f] \\circ [f^{\\prime}] = \\overline{g}_1 \\circ (\\overline{g}^{\\prime\\prime}_1)^{-1}}")#text(". This gives the first property required for ")#mi("{[f] \\circ [f^{\\prime}]}")#text(" to lie in ")#mi("{G}")#text(", and the other three are proven similarly.")

#text("Having located the definable group ")#mi("{G}")#text(", the next step is to locate a space ")#mi("{X}")#text(" that ")#mi("{G}")#text(" acts definably on. We first observe that ")#mi("{G}")#text(" generically acts on ")#mi("{X_3}")#text(", by defining ")#mi("{[f] \\cdot x_3 = x^{\\prime}_3}")#text(" whenever ")#mi("{x_3 \\in X_3}")#text(", ")#mi("{f \\in G}")#text(", and ")#mi("{x^{\\prime}_3}")#text(" is the unique element of ")#mi("{X_3}")#text(" such that ")#mi("{[f]}")#text(" (which, recall, is the closure of the top-dimensional component of the graph of ")#mi("{f}")#text(") contains ")#mi("{(x_3,x^{\\prime}_3)}")#text(". This is a definable, and generically defined operation which obeys the action axiom ")#mi("{(g \\cdot h) \\cdot x_3 = g \\cdot (h \\cdot x_3)}")#text(" for generic ")#mi("{(g,h,x_3) \\in G\\times G \\times X_3}")#text(".")

#text("To create a genuine action and not just a generic action, we perform yet another “quotient space construction” to extract a suitable space ")#mi("{X}")#text(" from ")#mi("{X_3}")#text(" as follows. Define a ")#emph[#text("formal pre-point")]#text(" to be a definable subset ")#mi("{\\Sigma}")#text(" of ")#mi("{G \\times X_3}")#text(" obeying the following axioms:")

#list(
[#text("(xv) (Vertical line test) For generic ")#mi("{g \\in G}")#text(", there is exactly one ")#mi("{x\\in X_3}")#text(" such that ")#mi("{(g,x) \\in \\Sigma}")#text(".")],
[#text("(xv’) (Vertical line test) For generic ")#mi("{(g,x) \\in \\Sigma}")#text(", ")#mi("{x}")#text(" is the unique ")#mi("{x^{\\prime} \\in X_3}")#text(" such that ")#mi("{(g,x^{\\prime}) \\in \\Sigma}")#text(".")],
[#text("(xvi) (Translation invariance) For generic ")#mi("{((g,x),h) \\in\\Sigma \\times G}")#text(", we have ")#mi("{(h \\cdot g, h \\cdot x) \\in \\Sigma}")#text(".")]
)

#text("Two formal pre-points are equivalent if they have a common definable subset, and a ")#emph[#text("formal point")]#text(" is an equivalence class of formal pre-points. We then let ")#mi("{X}")#text(" be the set of all formal points. If ")#mi("{\\Sigma}")#text(" is a formal pre-point and ")#mi("{(g,x)}")#text(" is a generic element of ")#mi("{\\Sigma}")#text(", then ")#mi("{\\Sigma}")#text(" is equivalent to ")#mi("{\\{ (h \\cdot g, h \\cdot x): h \\in G \\}}")#text(", and so is essentially irreducible; by similar arguments to before, we may now parameterise ")#mi("{X}")#text(" as a definable set, which is the image of the generically defined map ")#mi("{(g,x) \\mapsto \\Sigma}")#text(" described above with fibres of dimension at least ")#mi("{d_{\\overline{G}}}")#text(" and so has at most one component of dimension ")#mi("{d_X}")#text(" and no higher-dimensional components. The group ")#mi("{G}")#text(" acts on formal pre-points by the formula")

#align(center)[#tao-fit-display[#mitex("g \\cdot \\Sigma := \\{ (h \\cdot g^{-1}, x): (h,x) \\in \\Sigma \\};")]]

#text("one easily verifies that this is an action on formal pre-points which descends to a definable action on the space ")#mi("{X}")#text(" of formal points.")

#text("For generic ")#mi("{x \\in X_3}")#text(", the set ")#mi("{\\{ (g, g \\cdot x): g \\in G \\}}")#text(" can be verified to be a formal pre-point; this gives a definable, generically defined map ")#mi("{\\iota: X \\rightarrow \\tilde X}")#text(", which one can check to be generically injective; combined with the previous dimension control on ")#mi("{X}")#text(", we now see that ")#mi("{X}")#text(" has dimension ")#mi("{d_X}")#text(" and is almost irreducible, with ")#mi("{\\iota}")#text(" generically bijective. It can also be shown to generically preserve the action, in the sense that ")#mi("{\\iota( g \\cdot x ) = g \\cdot \\iota(x)}")#text(" for generic ")#mi("{(g,x) \\in G \\times X_3}")#text(".")

#text("Finally, we can set up the random variables ")#mi("{\\tilde {\\bf g}_i}")#text(" and ")#mi("{\\tilde {\\bf x}_i}")#text(" required for Theorem ")#link(<tao-7a0d0e5a5c1e741c7341>)[#text("3")]#text(". We choose generic elements ")#mi("{g_1^0 \\in G_1, g_2^0 \\in G_2}")#text(", and then set")

#tao-aligned(keep: true)[


#tao-math("\\tilde {\\bf g}_1  & := [\\phi_{{\\bf g}_1}] \\circ [\\phi_{g_1^0}]^{-1}", block: true)



#tao-math("\\tilde {\\bf g}_2  & := [\\psi_{g_2^0}] \\circ [\\psi_{{\\bf g}_2}]^{-1}", block: true)



#tao-math("\\tilde {\\bf g}_3  & := \\tilde {\\bf g}_1^{-1} \\circ \\tilde {\\bf g}_2^{-1}", block: true)



#tao-math("\\tilde {\\bf x}_1  & := \\iota( \\psi_{g_2^0}( {\\bf x}_1 ) )", block: true)



#tao-math("\\tilde {\\bf x}_2  & := \\iota( \\phi_{g_1^0}( {\\bf x}_2 ) )", block: true)



#tao-math("\\tilde {\\bf x}_3  & := \\iota( {\\bf x}_3 ).", block: true)
]

#text("It is clear that for generic ")#mi("{g_1^0,g_2^0}")#text(", the ")#mi("{\\tilde {\\bf x}_i}")#text(" are interalgebraic with ")#mi("{{\\bf x}_i}")#text(", and that the relations ")#link(<tao-e2ba41af03120f143f51>)[#text("(1)")]#text(" hold almost surely. Also, ")#mi("{\\tilde {\\bf g}_i}")#text(" is clearly algebraic over ")#mi("{{\\bf g}_i}")#text(" for ")#mi("{i=1,2}")#text(", and the ")#mi("{{\\bf x}_i}")#text(" are uniformly distributed in ")#mi("{X}")#text(". For ")#mi("{i=3}")#text(", we use the relation ")#mi("{\\tilde {\\bf g}_3 \\cdot \\tilde {\\bf x}_1 = \\tilde {\\bf x}_2}")#text(". As ")#mi("{{\\bf x}_2}")#text(" is algebraic over ")#mi("{{\\bf g}_3}")#text(" and ")#mi("{{\\bf x}_1}")#text(", ")#mi("{\\tilde{\\bf x}_2}")#text(" is algebraic over ")#mi("{{\\bf g}_3}")#text(" and ")#mi("{{\\bf x}_1}")#text(". Thus for generic ")#mi("{{\\bf g}_3}")#text(", there can only be finitely many possible values of ")#mi("{\\tilde {\\bf g}_3}")#text(", giving the desired algebraicity.")

#text("We see that ")#mi("{(\\tilde {\\bf g}_1, \\tilde {\\bf g}_2)}")#text(" is uniformly distributed in ")#mi("{G \\times G}")#text("; as ")#mi("{\\tilde {\\bf g}_3 = \\tilde {\\bf g}_1^{-1} \\circ \\tilde {\\bf g}_2^{-1}}")#text(" almost surely, we conclude that ")#mi("{\\tilde {\\bf g}_3}")#text(" is uniformly distributed over ")#mi("{G}")#text(". The independence requirements on the ")#mi("{\\tilde {\\bf g}_i, \\tilde {\\bf x}_i}")#text(" now follow from the corresponding independence hypotheses on the ")#mi("{{\\bf g}_i, {\\bf x}_i}")#text(".")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ff39422bba87564dc362dba86346d189c9f13ca60591c0da8772f2d6a73db39-476ea7aed1980e9919a56099f0ba871fd83e9da2e7284c64684097196a1c55a4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of omar aboura")]], [#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/#comment-251380")[#strong[#text("omar aboura")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2013")])]

#text("In the definition of “qualitative probability space” (third paragraph of Section 1), I think that the three ")#mi("R")#text(" must be ")#mi("X")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/#comment-251386")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("PSL_2(k) isn’t projective; it’s the image of the adjoint representation of SL_2(k). More specifically it’s affine, being SO(the Killing form).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/#comment-251446")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("I believe “projective” here is just referring to the name of PSL and not asserting any projectivity.")

#emph[#text("[Allen was referring to an earlier version of the text, now corrected, in which there was some confusion in this regard – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4db7f931b7831845d5ad9a27b1a6319cf65192de9454a28bb64b50d9e9f9875b-09b27acb458a076240e9968737c42ca77e5653b215ae746d53770326465c5608.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/#comment-261154")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2014")])]

#text("An oft-used countably additive qualitative probability measure, completely unrelated to any genuine measure, is Baire category in a complete metric space. Say that ")#mi("\\mu(A)=0")#text(" if ")#mi("A")#text(" is meagre and ")#mi("\\mu(A)=1")#text(" if ")#mi("A")#text(" is comeagre.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Goursat and Furstenberg-Weiss type lemmas | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/#comment-625822")[#strong[#text("Goursat and Furstenberg-Weiss type lemmas | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2021")])]

#text("[…] The ability to encode an abelian additive relation in terms of group-theoretic properties is vaguely reminiscent of the group configuration theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/16/qualitative-probability-theory-types-and-the-group-chunk-and-group-configuration-theorems/#comment-625999")[#strong[#text("Goursat and Furstenberg-Weiss type lemmas – scroo0ooge")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2021")]

#text("[…] The ability to encode an abelian additive relation in terms of group-theoretic properties is vaguely reminiscent of the group configuration theorem. […]")
]
