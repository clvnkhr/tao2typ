// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/
// Converted to Typst by tao2typ: "2026-10-14T06:53:03.381133+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "PCM article: Generalised solutions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("PCM article: Generalised solutions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/")[#text("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I’m continuing my ")#link("https://terrytao.wordpress.com/category/paper/companion/")[#text("series of articles")]#text(" for the ")#link("http://gowers.wordpress.com/2007/09/06/hello-world/")[#text("Princeton Companion to Mathematics")]#text(" ahead of the winter quarter here at UCLA (during which I expect this blog to become dominated by ergodic theory posts) with my article on ")#link("http://www.math.ucla.edu/~tao/preprints/generalized_solutions.pdf")[#text("generalised solutions")]#text(" to PDE. (I have three more PCM articles to release here, but they will have to wait until spring break.) This article ties in to some extent with my ")#link("https://terrytao.wordpress.com/2008/01/01/pcm-article-distributions/")[#text("previous PCM article on distributions")]#text(", because distributional solutions are one good example of a “generalised solution” or “weak solution” to a PDE. They are not the only such notion though; one also has variational and stationary solutions, viscosity solutions, penalised solutions, solutions outside of a singular set, and so forth. These notions of generalised solution are necessary when dealing with PDE that can exhibit singularities, shocks, oscillations, or other non-smooth behaviour. Also, in the foundational existence theory for many PDE, it has often been profitable to first construct a fairly weak solution and then use additional arguments to upgrade that solution to a stronger solution (e.g. a “classical” or “smooth” solution), rather than attempt to construct the stronger solution directly. On the other hand, there is a tradeoff between how easy it is to construct a weak solution, and how easy it is to upgrade that solution; solution concepts which are so weak that they cannot be upgraded at all seem to be significantly less useful in the subject, even if (or ")#emph[#text("especially")]#text(" if) existence of such solutions is a near-triviality. [This is one manifestation of the somewhat whimsical “law of conservation of difficulty”: in order to prove any genuinely non-trivial result, some hard work has to be done ")#emph[#text("somewhere")]#text(". In particular, it is often the case that the behaviour of PDE depends quite sensitively on the exact structure of that PDE (e.g. on the sign of various key terms), and so any result that captures such behaviour must, at some point, exploit that structure in a non-trivial manner; one usually cannot get very far in PDE by relying just on general-purpose theorems that apply to all PDE, regardless of structure.]")

#text("The Companion also has a section on history of mathematics; for instance, here is ")#link("http://www.tau.ac.il/~corry/")[#text("Leo Corry")]#text("‘s PCM article “")#link("http://www.tau.ac.il/~corry/publications/articles/pdf/proof%20PUP.pdf")[#text("The development of the idea of proof")]#text("“, covering the period from ")#link("http://en.wikipedia.org/wiki/Euclid")[#text("Euclid")]#text(" to ")#link("http://en.wikipedia.org/wiki/Gottlob_Frege")[#text("Frege")]#text(". We take for granted nowadays that we have precise, rigorous, and standard frameworks for proving things in set theory, number theory, geometry, analysis, probability, etc., but it is worth remembering that for the majority of the history of mathematics, this was not completely the case; even Euclid’s axiomatic approach to geometry contained some implicit assumptions about topology, order, and sets which were not fully formalised until the ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_axioms")[#text("work of Hilbert")]#text(" in the modern era. (Even nowadays, there are still a few parts of mathematics, such as mathematical quantum field theory, which still do not have a completely satisfactory formalisation, though hopefully the situation will improve in the future.)")

#text("[")#emph[#text("Update")]#text(", Jan 4: bad link fixed.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c625be66f01683e85d1a83275b12f8b4aa5f7c9accb665d2d56370c00f9243c6-7ef058e8d924fd94b552a49adcd8e57aca4e81ca3d8b76ccce583a64efa0a71a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberta")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-23059")[#strong[#text("Roberta")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2008")])]

#text("The development of the idea of proof (up to 1900)’s link is not working")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-23080")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2008")])]

#text("Sorry about that! It should be fixed now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-23152")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2008")])]

#text("I’ve cited this thread, and excerpted the wonderful Leo Corry’s article “The development of the idea of proof“, over at ")#link("http://golem.ph.utexas.edu/category/2008/01/two_cultures_in_the_philosophy.html#c014197")[#text("January 2, 2008")#linebreak()#text(" Two Cultures in the Philosophy of Mathematics?")#linebreak()#text(" Posted by David Corfield")]#text(", on the n-Category Cafe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2a7319b4c813add912eb7cbcb445bb0501c65e22a0d20ccf3125e288439487-15e66ce58b68b90fe19e4e74be7b94f81a691f4d226a6d01999f4f5193efe092.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedfan")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-23248")[#strong[#text("fedfan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2008")])]

#text("Hi, There appear to some duplicate file names, pointing to multiple")#linebreak()#text(" topics. In particular, Riemannian Metrics file is missing as the contents")#linebreak()#text(" discuss Knot Polynomials. I think there might be another?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad2a7319b4c813add912eb7cbcb445bb0501c65e22a0d20ccf3125e288439487-15e66ce58b68b90fe19e4e74be7b94f81a691f4d226a6d01999f4f5193efe092.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of fedfan")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-23249")[#strong[#text("fedfan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2008")])]

#text("Just to point out, the section III, The Exponential and Logarithmic Functions")#linebreak()#text(" is listed twice albeit the file contents are indeed about these topics :-)")

#text("Btw, this is a fantastic project! This blog is absolutely a gem. Please keep")#linebreak()#text(" it up.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c625be66f01683e85d1a83275b12f8b4aa5f7c9accb665d2d56370c00f9243c6-7ef058e8d924fd94b552a49adcd8e57aca4e81ca3d8b76ccce583a64efa0a71a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roberta")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-23692")[#strong[#text("Roberta")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("“Algebraic Numbers” by Barry Mazur is a very good article ( for the Princeton Companion to Mathematics ) ! :)")

#link("http://www.dms.umontreal.ca/~andrew/Courses/PDFcourses/Mazur.AlgNumbers.pdf")[#text("Click to access Mazur.AlgNumbers.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-23696")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")])]

#text("The Leo Corry PCM article “The development of the idea of proof“ is excellent.")

#text("However, is it incomplete by ignoring the possible contributions of other civilizations such as Egypt, China and India ")#link("http://en.wikipedia.org/wiki/Calculus")[#text(" section ‘Development’ in Calculus")]#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of survey")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-24291")[#strong[#text("survey")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2008")])]

#text("Dear Terry,")#linebreak()#text(" In the inviscid Burgers equation, nonuniqueness of weak solutions")#linebreak()#text(" always breaks down once discontinuities appear.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tricks Wiki: Give yourself an epsilon of room « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-36202")[#strong[#text("Tricks Wiki: Give yourself an epsilon of room « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 February 2009")])]

#text("[…] are measures, distributions, or some other concept of “generalised function” or “generalised solution“. For instance, the fundamental solution to a PDE is typically just a distribution or […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/01/04/pcm-article-generalised-solutions/#comment-190318")[#strong[#text("Advanced Analysis, Notes 8: Banach spaces (application: weak solutions to PDEs) « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2012")]

#text("[…] are other notions of generalized solutions, see also Terry Tao’s PCM article or the Wikipedia […]")
]
