// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/
// Converted to Typst by tao2typ: "2026-10-14T16:38:21.561567+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath15, eighth thread: going below 0.28", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath15, eighth thread: going below 0.28")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 April 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/")[#text("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("This is the eighth “research” thread of the ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("Polymath15 project")]#text(" to upper bound the ")#link("https://en.wikipedia.org/wiki/De_Bruijn%E2%80%93Newman_constant")[#text("de Bruijn-Newman constant")]#text(" ")#mi("{\\Lambda}")#text(", continuing ")#link("https://terrytao.wordpress.com/2018/03/28/polymath15-seventh-thread-going-below-0-48/")[#text("this post")]#text(". Discussion of the project of a non-research nature can continue for now in ")#link("https://terrytao.wordpress.com/2018/01/24/polymath-proposal-upper-bounding-the-de-bruijn-newman-constant/")[#text("the existing proposal thread")]#text(". Progress will be summarised at ")#link("http://michaelnielsen.org/polymath1/index.php?title=De_Bruijn-Newman_constant")[#text("this Polymath wiki page")]#text(".")

#text("Significant progress has been made since the last update; by implementing the “barrier” method to establish zero free regions for ")#mi("H_t")#text(" by leveraging the extensive existing numerical verification of the Riemann hypothesis (which establishes zero free regions for ")#mi("H_0")#text("), we have been able to improve our upper bound on ")#mi("\\Lambda")#text(" from 0.48 to 0.28. Furthermore, there appears to be a bit of further room to improve the bounds further by tweaking the parameters ")#mi("t_0, y_0, X")#text(" used in the argument (we are currently using ")#mi("t_0=0.2, y_0 = 0.4, X = 5 \\times 10^9")#text("); the most recent idea is to try to use exponential sum estimates to improve the bounds on the derivative of the approximation to ")#mi("H_t")#text(" that is used in the barrier method, which currently is the most computationally intensive step of the argument.")

#heading(level: 1)[#text("Comments (114)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("I have reorganised the writeup a bit to try to put the most interesting results in the introduction. Also I have written down a bound for both the x,y and t derivatives of the quantity ")#mi("A^{eff}+B^{eff}/B^{eff}_0")#text(", which in the writeup is now called ")#mi("f_t(x+iy)")#text(". These should presumably be useful in the barrier part of the argument. I like KM’s idea of using some exponential sum estimates to do even better; the estimates in the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2095256")[#text("paper of Cheng and Graham")]#text(" aren’t too fearsome, and it may be that all one needs to do is combine them with summation by parts to obtain reasonable estimates. The net savings could potentially be on the order of ")#mi("x^{1/4 - 1/6} = x^{1/12}")#text(" which could be significant at the scales we are considering (in principle we can place our barrier as far out as ")#mi("x = 6 \\times 10^{10}")#text("). I’ll take a look at it.")

#text("UPDATE: there is also ")#link("https://mathscinet.ams.org/mathscinet/search/publications.html?refcit=2095256&loc=refcit")[#text("some followup work to the Cheng-Graham paper")]#text(" by various authors which may also have some useable estimates in this regard.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("citizen scientists don’t have mathscinet")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496567")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("See e.g. the recent paper by Platt and Trudgian")

#link("https://arxiv.org/pdf/1402.3953.pdf")[#text("Click to access 1402.3953.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496562")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("It seems the t/4 factor in the ddt bound formula should be 1/4. Also, I was facing a authentication wall with the mathscinet link, so tried Google Scholar instead (")#link("https://scholar.google.co.uk/scholar?cites=874153760302881636&as_sdt=2005&sciodt=0,5&hl=en")[#text("link")]#text("), which provides links to many of the followup papers.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a09971234162a15562647a9298f2360626bba53001f4aeea0032eb6628efe388-14bee498c35907261aa2cb911d5eeecc8a147dde11ac3c0e361d90d8bcd34052.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Bauer")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496830")[#strong[#text("Bill Bauer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("There may be sign error in the denominator of definition (16), γ. It currently reads")

#text("(16) γ(x+iy) := Mₜ(t,(1-y+i*x)/2)/Mₜ(t,(1+y-i*x)/2)")

#text("It should, perhaps, read")

#text("(16) γ(x+iy) := Mₜ(t,(1-y+i*x)/2)/Mₜ(t,(1+y+i*x)/2)")

#text("The mean value theorem, used in the proof of Proposition 6.6 (estimates) suggests that log|Mₜ(t,(σ+i*x)/2)| should be a function of σ only which it would not be if the signs of ix were different in numerator and denominator.")

#text("Apologies if I’m missing something obvious. As far as I’ve checked computationally, the inequality seems to be true in either case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496836")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("The holomorphic function ")#mi("M_t")#text(" is real on the real axis and so obeys the reflection equation ")#mi("M_t(\\frac{1+y-ix}{2}) = \\overline{M_t(\\frac{1+y+ix}{2})}")#text(", so if one takes absolute values, the sign of the ")#mi("ix")#text(" term becomes irrelevant. I’ll add a line of explanation in the proof of Prop 6.6 to emphasise this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Bauer")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496851")[#strong[#text("William Bauer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("Thank you. Wish I’d seen that.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6803f451a822a44c3357dffe0946273ac8b678c1381d8f6f15471f78bf5064e-c0cdd6fbf9fa11cb38f669d32e0c33214ced4ab5f9e837265aa2a25f482e13f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496497")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("This is a question which is possibly a bit orthogonal to the main developments of this polymath, but may be able to be answered relatively easily using the insights that the contributors have gained. Is clear how far one can extend to other similar functions the result of Ki, Kim and Lee, that all but finitely many zeros of ")#mi("H_t(z)")#text(" lie on the real line for any ")#mi("t > 0")#text("? I’m thinking of a result along the lines of de Bruijn’s that applies generically to functions with zeros trapped in a certain strip, with the added condition that zeros become more dense away from the origin.")

#text("For instance is there a pathological example of an entire function ")#mi("G(x+iy)")#text(" (with rapidly decaying and even Fourier transform) with all zeroes in some strip ")#tao-math("\\{\\left|y\\right| \\leq c\\}", block: false)#text(", ")#mi("G_t(z)")#text(" still has infinitely many zeros off the real line? (One could even to make the question more precise suppose ")#mi("G(z)")#text(" even satisfies a Riemann- von Mangoldt formula with the same sort of error term as the Riemann xi-function.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496509")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("Well, here is a simple example: the functions ")#mi("G_t(z) := e^t \\cos z + c")#text(", for some constant ")#mi("c>0")#text(", has all zeroes in a strip that become all real at time ")#mi("\\log c")#text(", but has infinitely many zeroes off the line before then (the function is ")#mi("2\\pi")#text("-periodic). But this function doesn’t obey a Riemann von Mangoldt formula.")

#text("For a typical function obeying Riemann von Mangoldt, a complex zero above the real axis of real part ")#mi("T")#text(" would be expected to be attracted to the real axis at a velocity comparable to the ")#mi("\\log T")#text(" nearby zeroes, at least half of which will be at or below the real axis. So within time ")#mi("1/log T")#text(" one would expect such a zero to hit the real axis, suggesting that there are only finitely many non-real zeroes after any finite amount of time. But there could be some exceptional initial configurations of zeroes which somehow “defy gravity” – maybe “pulling each other up by their bootstraps” and stay above the real line for an unusually long period of time. I don’t know how to construct these, but on the other hand I can’t rule such a scenario out either – they seem somewhat inconsistent with physical intuition such as conservation of centre of mass, but I have not been able to make such intuition rigorous.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496526")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("It seems important to classify (e.g. by Cartan’s equivalence method) all the invariants of the zeros ODE dynamics – to get more information and bounds for this dynamics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496550")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("I’m not sure that there will be many invariants – this is a heat flow (with a very noticeable “arrow of time”) rather than a Hamiltonian flow. Since such flows tend to converge to an equilibrium state at infinity, it’s very hard to have any invariants (as they would have to match the value of the invariant at the equilibrium state). For such flows it is monotone (or approximately monotone) quantities, rather than invariant quantities, that tend to be more useful (such quantities played a key role in my paper with Brad, for instance). But there’s not really a systematic way (a la Cartan) to find monotone quantities (we found the ones we had by reasoning in analogy with quantities that were useful for a similar-looking flow, Dyson Brownian motion).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496920")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("Sounds a bit like there should be something like an entropy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496924")[#strong[#text("Raphael")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("I mean for the one the local entropy gain directly follows from the PDE, on the other hand side one could look at particular “subsystems”. I don’t know if the zeros can be interpreted meaningful as subsystems but in any case “phase change”s like what you suggest in your interpretation are nicely traceable with the entropy. Especially there is the interpretation of entropy as the number of degrees of freedom. In that sense if a zero can be complex or exclusively real directly goes into the entropy (like by a factor of two per particle). Just a loose thought.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496511")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("It occurs me that another way to attack the problem is to use a fixed ")#mi("x=x_0")#text(" and calculate a mesh barrier over the variables ")#mi("y,t")#text(" as ")#mi("t")#text(" varies from the verified upper bound of the de Bruijn-Newman constant, ")#mi("t_1")#text(" to a target upper bound, ")#mi("t_0")#text(" and as ")#mi("y")#text(" varies from 0 to an upper bound of the maximum possible ")#mi("y")#text(" for the current ")#mi("t,x")#text(". This mesh will take care of any zeroes coming from horizontal infinity.Then one can follow some zero, ")#mi("z(t)")#text(" greater than ")#mi("x_0")#text(" (at both ")#mi("t_1,t_0")#text(" through the reverse heat dynamics, and verify that the same number of zeroes exist on the real line up to ")#mi("z(t)")#text(". I am assuming that zeroes on the real line are able to join together then exit the real line as ")#mi("t")#text(" decreases, but if this is shown to be impossible for some ")#mi("t_0")#text(" close enough to ")#mi("t_1")#text(", then only the mesh calculation is required, not the counting of real zeroes.")

#text("The current method is working, yet someone may find this idea a useful starting point, as this method nicely recycles previous upper bounds of the constant. This sort of elementary idea is the only thing I see which I can submit that may help, given my shallow understanding of the project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496551")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("It’s a nice idea to try to move backwards in time from the previous best known bound of ")#mi("\\Lambda")#text(" rather than move forward in time from ")#mi("t=0")#text(" (which is our current approach that leverages numerical RH). The problem though is that when one moves backwards in time, the real zeroes become very “volatile” – it’s very hard to prevent them from colliding and then moving off the real axis (this basically would require one to somehow exclude “Lehmer pairs” at these values of t. One could potentially do so if one knew that the zeroes were all real at some earlier value of t, but this leads to circular-looking arguments, where one needs to lower the bound on ")#mi("\\Lambda")#text(" in order to lower the bound on ")#mi("\\Lambda")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421c1d09702cde925a0633de4ece70927f925ba23f59ce163101305acec8ff08-88817afe06097aa4f59473bd7da1f3fcf58d210d54f1bb5ac3ca9b23b7cfb9a1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nazgand")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496591")[#strong[#text("Nazgand")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("I do not understand what part of my argument is circular, as it is merely another way of verifying that the rectangular region of possible non-real zeroes of ")#mi("H_{t_0}")#text(" has no non-real zeroes. This is the same rectangular region of possible non-real zeroes the current method uses for fixed ")#mi("t=t_0")#text(".")

#text("If the zeroes are conserved expect for zeroes appearing from horizontal infinity and no zeroes pass through the barrier at ")#mi("x=x_0")#text(" then counting the number of real zeroes up to ")#mi("z(t)")#text(" for both ")#mi("H_{t_0}(z)")#text(" and ")#mi("H_{t_0}(z)")#text(" and verifying equality implies the rectangle is free of non-real zeroes. If zeroes collide and exit the real line, then the counts of real zeroes will not match.")

#text("Is your concern that multiple real zeroes near each other may be miscounted, and that avoiding such miscounts would be costly computation-wise? Much research has been done on counting real zeroes of ")#mi("H_0(z)")#text(", and applying similar methods to ")#mi("H_t(z)")#text(" is likely possible.")

#text("The idea that the counting of real zeroes might be skip-able is fluffy speculation based on the fact that one world only need to avoid colliding real zeroes for zeroes less than ")#mi("z(t)")#text(".")#linebreak()#text(" Without such a shortcut, counting real zeroes can be expensive for large ")#mi("x_0")#text(", yet the current method likely uses more computation to lower the bound to ")#mi("t_0")#text(" because a barrier mesh needs to be calculated which has width ")#mi("x_0")#text(", leaving only the cost of the mesh at ")#mi("x=x_0")#text(" to consider, which may be cheaper than the current mesh calculation required.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("If one is willing to try to count real zeroes of ")#mi("H_t")#text(" up to some large threshold ")#mi("X")#text(", then this approach could work in principle, but the time complexity of this is likely to scale like ")#mi("O(X^{3/2})")#text(" at best (to scan each unit interval for zeroes takes about ")#mi("O(X^{1/2})")#text(" time assuming that the Odlyzko-Schonhage algorithm can be adapted for ")#mi("H_t")#text("). We already had a somewhat similar scan in previous arguments using the argument principle for a rectangular region above the real axis, and even with the additional convergence afforded by having ")#mi("y")#text(" equal to 0.4 rather than 0, it took a while to reach ")#mi("X = 10^6")#text(" or so. In contrast, the barrier method only has to scan a single unit interval ")#mi("[X,X+1]")#text(" (albeit for multiple values of ")#mi("t")#text(", which is an issue), and we’ve been able to make it work for ")#mi("X")#text(" up to ")#mi("10^9")#text(" so far.")

#text("The circularity I was referring to would arise if one wanted to somehow avoid the computationally intensive process of counting real zeroes up to ")#mi("X")#text(". In order to do this one would have to somehow exclude the possibility that say ")#mi("H_{t_0}")#text(" has a Lehmer pair up to this height, as such a pair would make the count of real zeroes very sensitive to the value of ")#mi("t")#text(". Given that real zeroes repel each other, the non-existence of Lehmer pairs at ")#mi("t_0")#text(" is morally equivalent to ")#mi("H_t")#text(" having real zeroes (up to scale ")#mi("X")#text(", at least) for some ")#mi("t < t_0")#text(". Actually, now that I write this, I see that this is weaker than requiring one to already possess the bound ")#mi("\\Lambda < t_0")#text(", since one could still have zeroes off the real axis near horizontal infinity. So there need not be a circularity here. Still, I don't see a way to force the absence of Lehmer pairs without either a scan of length ")#mi("X")#text(" (and time complexity something like ")#mi("O(X^{3/2})")#text(" or a barrier method (outsourcing the length ")#mi("X")#text(" scan to the existing literature on numerical verification of RH).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe0ef876daa22fb724efbaa7c962b52d6334dec420920635dd68181527d2d492-9cd33212bfc809c0c4dd901da1651b7446a896e94ae70c7ae696149a8b6f2587.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pisoir")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496518")[#strong[#text("pisoir")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2018")])]

#text("Dear prof. Tao,")#linebreak()#text(" I have been watching carefully your (fast) progress on this problem and from my point of view I am confused about several of your comments.")

#text("To me it seems that you are aiming for ")#mi("\\Lambda \\leq 1/4")#text(", but from the progress made so far, I have the feeling that this is a rather “artificially” picked bound and if you wanted you could push it even further. Also you mention several times the numerical complexity of the problem, but according to the fast results by KM, Rudolph and others, this also does not seem to be a problem at the moment.")#linebreak()#text(" So my question is, are you aiming at some specific value of ")#mi("\\Lambda")#text(" and then close the project, because it could then go on forever (pushing the ")#mi("\\Lambda")#text(" by meaningless 0.01 each month) or you will try to push it as far as you can until you really hit the fundamental border of this method? Is there such border and what could that value be (can it go down to e.g. ")#mi("\\Lambda \\leq 0.001")#text(")?")#linebreak()#text(" Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d0c966f83956f88e0ae0569a5a0b03c90ac4da8d83a15599ca142d3f1d3503e6-6da5889455160fc1a4651d11d6dc54150c1eee35c9adbd8ae366b68451ab2690.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of goingtoinfinity")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496538")[#strong[#text("goingtoinfinity")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("“by meaningless 0.01 each month” – that would be rather surprising in july 2020.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496552")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("I view the bound on ")#mi("\\Lambda")#text(" as a nice proxy for progress on understanding the behaviour of the ")#mi("H_t")#text(", but one should not identify this proxy too strongly with progress itself (cf. ")#link("https://en.wikipedia.org/wiki/Goodhart%27s_law")[#text("Goodhart’s law")]#text("). Already, the existing efforts to improve the lower bound on ")#mi("\\Lambda")#text(" have revealed a number of useful new results and insights about ")#mi("H_t")#text(", such as an efficient Riemann-Siegel type approximation to ")#mi("H_t")#text(" for large values of x, an efficient integral representation to ")#mi("H_t")#text(" for small and medium values of x, a “barrier” technique to create large zero free regions for ")#mi("H_t")#text(" (assuming a corresponding zero free region for ")#mi("H_0")#text("), and an essentially complete understanding of the zeroes of ")#mi("H_t")#text(" at very large values of x (")#mi("x \\geq \\exp(C/t)")#text("). Hopefully as we keep pushing, more such results and observations will follow. If such results start drying up, and the bound on ")#mi("\\Lambda")#text(" slowly improves from month to month purely from application of ever increasing amounts of computer time, then that would indicate to me that the project has come close to its natural endpoint and it would be a good time to declare victory and write up the results.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496536")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("For a given measure of computational complexity (or “effort”), an interesting optimization problem is to find the optimal pair ")#mi("(t_0, y_0)")#text(" which minimize the bound ")#mi("t_0 + y_0^2 / 2")#text(" subject to a given computational complexity constraint.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496555")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("It might be worth resurrecting the toy approximation")

#mi("\\displaystyle \\frac{A^{toy} + B^{toy}}{B^{toy}_0} = \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2}+\\frac{t}{4} \\log \\frac{N^2}{n} - \\frac{\\pi i t}{8}}} + e^{i\\theta} N^{-y} \\sum_{n=1}^N \\frac{1}{n^{\\frac{1-y+ix}{2}+\\frac{t}{4} \\log \\frac{N^2}{n} + \\frac{\\pi i t}{8}}}")

#text("for this purpose, where ")#mi("N = \\lfloor \\sqrt{x/4\\pi} \\rfloor")#text(" and ")#mi("\\theta = (\\frac{x}{2} + \\frac{\\pi t}{8}) \\log \\frac{x}{4\\pi} - \\frac{x}{2} - \\frac{\\pi}{4}")#text(" (see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath15_test_problem")[#text("this page of wiki")]#text("). For the purposes of locating the most efficient choice of ")#mi("(t_0,y_0,X)")#text(" parameters that are still computationally feasible, we can just pretend that ")#mi("H_t / B^{toy}_0")#text(" is exactly equal to this toy approximation (thus totally ignoring ")#mi("Error_1,Error_2,Error_3")#text(" errors, and also replacing the somewhat messy ")#mi("\\alpha")#text(" factors by a simplified version). Once we locate the most promising choice, we can then return to the more accurate approximation ")#mi("A^{eff} + B^{eff} / B^{eff}_0")#text(" and combine it with upper bounds on ")#mi("Error_1, Error_2, Error_3")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496556")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("With regards to this toy problem at least, it seems like some version of the ")#link("https://en.wikipedia.org/wiki/Odlyzko%E2%80%93Sch%C3%B6nhage_algorithm")[#text("Odlyzko–Schönhage algorithm")]#text(" may be computationally efficient in the barrier verification step where we will have to evaluate ")#mi("A^{toy}+B^{toy}/B^{toy}_0(t, x+iy)")#text(" for many mesh points of ")#mi("(t,x,y)")#text(" (but with ")#mi("x")#text(" in a fixed unit interval ")#mi("[X, X+1]")#text(". The first basic idea of this algorithm is to transform this problem by performing an FFT in the x variable, so that one is now evaluating things like")

#mi("\\sum_{m=1}^M \\frac{A^{toy}+B^{toy}}{B^{toy}_0}( t, X + \\frac{m}{M} + iy ) e^{2\\pi i mk/M} \\quad (1)")

#text("for ")#mi("k=1,\\dots,M")#text(", where ")#mi("m")#text(" is a mesh size parameter. The point is that this FFT interacts nicely with the ")#mi("n^{\\pm ix/2}")#text(" factors in the toy approximation to give a sum which is substantially less oscillatory, and which can be approximated fairly accurately by dividing up the sum into blocks and using a Taylor expansion on each block, which can allow one to reuse a lot of calculations as ")#mi("k")#text(" varies (basically reducing the time complexity of evaluating (1) for all values of k from the naive cost of ")#mi("O(M^2)")#text(" to something much smaller like ")#mi("O(M \\log M)")#text("; also one should be able to reuse many of these calculations when one varies t and y as well, leading to further time complexity savings). One still has to do a FFT at the end, but this is apparently a very fast step and is definitely not the bottleneck. I’ll have to read up on the algorithm to figure out how to adapt it to this toy problem at least. (In our language, the algorithm is generally formulated to compute the sum ")#mi("\\sum_{n=1}^N \\frac{1}{n^{\\frac{1+ix}{2}}}")#text(" for many values of ")#mi("x \\in [X,X+1]")#text(" simultaneously.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496553")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Is it possible to derive (perhaps by using exponential sums estimates) for each given positive ")#mi("t_0, y_0")#text(" an explicit numerical threshold ")#mi("X(t_0, y_0)")#text(" with the property that ")#mi("H_{t_0}(x + i y) \\neq 0")#text(" whenever ")#mi("0 < y \\leq y_0")#text(" and ")#mi("x \\geq X(t_0, y_0)")#text(" ?")

#text("If so, then (clearly) ")#mi("X(t_0, y_0)")#text(" should decrease with increasing ")#mi("y_0")#text(" and therefore is preferable over the currently used ")#mi("X(t_0, 0) = \\exp (C/t_0)")#text(" (i.e. with ")#mi("y_0 = 0")#text(") in the barrier method.")

#text("Since ")#mi("X(t_0, y_0)")#text(" may also be used as a kind of \"computational complexity measure\", Is it possible that ")#mi("X(t_0, t_0^{1/2})")#text(" (i.e. with ")#mi("y_0 = t_0^{1/2}")#text(") grows much slower than ")#mi("X(t_0, 0)")#text(" as ")#mi("t_0 \\to  0")#text("? (while still giving the bound ")#mi("1.5 t_0")#text(" – comparable to the bound ")#mi("t_0")#text(" with ")#mi("y_0 = 0")#text(".)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496560")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("In general it gets harder and harder to keep ")#mi("H_t(x+iy)")#text(" away from zero as y gets smaller – after all, we expect to have a lot of zeroes ")#mi("H_t(x+iy)=0")#text(" with ")#mi("y=0")#text(". The two methods that we have been able to use to actually improve the bound on ")#mi("\\Lambda")#text(" only require keeping ")#mi("H_t(x+iy)")#text(" away from zero for ")#mi("y \\geq y_0")#text(", where ")#mi("y_0")#text(" is something moderately large like 0.4. While we do have some capability to probe near ")#mi("y=0")#text(" (in particular, in the asymptotics section there are some arguments using Jensen’s formula and the argument principle that make all the zeroes real beyond ")#mi("\\exp(C/t)")#text(" for some large absolute constant ")#mi("C")#text("), I think numerically this sort of control will be much weaker for computationally feasible values of ")#mi("x")#text(" than the control we can get for large values of ")#mi("y")#text(". (One can already see this when considering the main term ")#mi("\\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2} + \\frac{t}{4} \\log \\frac{N^2}{n} - \\frac{\\pi i t}{8}}}")#text(" of the toy expansion, in which the role of increasing y in improving the convergence of the sum is quite visible.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Correction: in the above required property of ")#mi("X(t_0, y_0)")#text(", it should be ")#mi("y \\geq y_0")#text(" (instead of ")#mi("0 < y \\leq y_0")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6344189f6b34a78ab355f05d4ed1a505e160ebb5f4d12847db80c142199f2499-5db31f2e08da92f6454b86092406fd9c89c7aa8b8cb364beeef0e715113903fb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496584")[#strong[#text("Mark")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("I haven’t been following this project at all, so apologies for the basic question which is perhaps covered in the discussion elsewhere:")

#text("But how much of a dictionary relating \\Lambda and zero-free regions do we have? The kinds of things that I mean by a “dictionary” might be:")#linebreak()#text(" 1) If we could prove there is a zero free strip, does that imply anything about \\Lambda?")#linebreak()#text(" 2) If there were only a single pair of off critical line zeros, can we convert this into a value of \\Lambda depending on their coordinates?")#linebreak()#text(" 3) If we knew \\lambda < 10^{-1000}, would that give us any usable zero-free region?")

#text("More philosophically, I'm curious why in the \"de Bruijn-Newman score system\" it feels like real progress on the Riemann-Hypothesis is being made while (and I'd love to be wrong here) it doesn't seem that the ideas being applied (numerical verification, etc) are circumventing any of the obstructions to progress in other the other \"score systems\" (zero-free regions, etc.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("wait, are you saying when we reach ")#mi("\\Lambda \\le 1/4")#text(" then we’re *not* really half way to proving rieman hypothesis???")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496598")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("The basic theorem here is due to de Bruijn (Theorem 13 of ")#link("https://pure.tue.nl/ws/files/1769368/597490.pdf")[#text("https://pure.tue.nl/ws/files/1769368/597490.pdf")]#text(" ), which in our language says that if ")#mi("H_{t_0}")#text(" has all zeroes in the strip ")#tao-math("\\left|y\\right| \\leq y_0", block: false)#text(", then one has the bound ")#mi("\\Lambda \\leq t_0 + \\frac{1}{2} y_0^2")#text(". For instance, the proof of the prime number theorem gives this for ")#mi("t_0 = 0, y_0=1")#text(", yielding de Bruijn’s bound ")#mi("\\Lambda \\leq 1/2")#text(". So zero free regions for zeta or for ")#mi("H_{t_0}")#text(" can give bounds on ")#mi("\\Lambda")#text(". However we don’t seem to have any converse implication, beyond the tautological assertion that ")#mi("H_t")#text(" has all real zeroes for all ")#mi("t \\geq \\Lambda")#text(". Having a really good upper bound on ")#mi("\\Lambda")#text(" such as ")#mi("\\Lambda \\leq 10^{-10}")#text(" may rule out certain scenarios very far from RH (such as having a single pair of zeroes far from the critical line, and also relatively far from all other zeroes) but it would be tricky to convert it into a clean statement about, say, a zero-free region. So perhaps one reason why we can make progress on bounding ")#mi("\\Lambda")#text(", but not on other approximations to RH, is that the implications only go in one direction.")

#text("If somehow we could show that RH is true with a single exceptional complex pair of zeroes, it should be possible to track that zero numerically with high precision and get a precise value on ")#mi("\\Lambda")#text(", assuming that pair was within reach of numerical verification. Otherwise one could use de Bruijn’s theorem to obtain a bound, though it would not be optimal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496601")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("I have a sort of statistical mechanics intuition for the zeroes of ")#mi("H_t")#text(" which may help clarify the situation. A bit like the three classical states of matter, the zeroes of ")#mi("H_t")#text(" seem to take one of three forms: “gaseous”, in which the zeroes are complex, “liquid”, in which the zeroes are real but not evenly spaced, and “solid” in which the zeroes are real and evenly spaced. (This should somehow correspond to the ")#mi("\\beta<0")#text(", ")#mi("\\beta=2")#text(", and ")#mi("\\beta=\\infty")#text(" limiting cases of beta ensembles, but I do not know how to make this intuition at all rigorous.) At time zero ")#mi("t = 0")#text(", the zeroes are some mixture of liquid and gaseous, and the RH (as well as supporting hypotheses such as GUE) asserts that it is purely liquid. At positive time, the situation is similar to ")#mi("t=0")#text(" in a region of the form ")#tao-math("\\left|x\\right| \\leq \\exp(C/t)", block: false)#text(" (though perhaps slightly \"cooler\", with some of the gas becoming liquid), but for ")#tao-math("\\left|x\\right| \\geq \\exp(C/t)", block: false)#text(" the zeroes have \"frozen\" into a solid state, so in particular there is only a finite amount of gas or liquid at positive time. As time advances, more of the gas (if any) condenses into liquid, and the liquid freezes into solid; by time ")#mi("\\Lambda")#text(", all the gas is gone, and pretty soon after that it all looks solid. In the reverse direction, we know that at any negative time, there is at least some gas.")

#text("With this perspective, the reason why it is easier to make progress on ")#mi("\\Lambda")#text(" than on other metrics towards RH is that we are dealing with an object ")#mi("H_t")#text(" which is already almost completely \"solidified\" into something well understood: the mysterious liquid and gaseous phases that make the Riemann zeta function so hard to understand only have a finite (albeit large) spatial extent, and so can be treated numerically, at least in principle.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496653")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("I really like the analogy and it makes me wonder what then is causing the phase-transitions between solid, liquid and gaseous. Here’s a free-flow of some thoughts, going backwards in time and assuming RH.")

#text("From solid to liquid:")#linebreak()#text(" When we were starting to ‘mollify’ the toy-model, I recall the surprise to still see a vestige of a partial Euler product even at ")#mi("t=0.4")#text(". So, with ")#mi("t \\rightarrow 0")#text(", we could reason that this partial Euler product needs to incrementally grow back towards its well-known infinite version at ")#mi("t=0")#text(". When we follow the trajectories of the real zeros going back in (positive) time, they will feel an increasing competitive pressure w.r.t. their neighbouring zeros to occupy the available space to encode all the required information about the primes. This increasingly ‘heated battle’ for available locations when ")#mi("t \\rightarrow 0")#text(", does ‘bend’ their trajectories and determines the angle and the velocity by which they hit the line ")#mi("t=0")#text(". Statistics will force some angles to become very small and these will then induce a Lehmer-pair. So, it could be the increasing need to encode an infinite amount of information about the primes, that turns up the ‘heat/pressure’ and moves the statistical ensembles of real lines from solid to liquid.")

#text("Liquid to gaseous:")#linebreak()#text(" Is there a need for an extra ‘heat/pressure’ source to explain why a perfect liquid at ")#mi("t=0")#text(" slowly turns into a gaseous state? I don’t think so, since the ‘heat is already on’ at the line ")#mi("t=0")#text(" and all the collision courses for the real zeros have been determined. The real zeros ‘plunge’ as it were into the domain below ")#mi("t =0")#text(" ((like particles flying into a bubble chamber) and their angles and velocities determine at which ")#mi("-t")#text(" a collision will occur. So, no extra heat source is needed and only the ‘backward heat flow’ logic is required to explain the trajectories below ")#mi("t=0")#text(".")

#text("Of course the key question is why the collisions of real zeros can only occur below ")#mi("t=0")#text(". What is it that suddenly allows liquidized real zeros to collide and send off some gaseous complex zeros in ")#mi("-t")#text("-steps? What has really changed below ")#mi("t=0")#text("? I looked at potential ‘switches’ in our formulae like the ")#mi("\\sqrt{t}")#text(" in the 3rd-approach integral, but that doesn’t lead us anywhere. The only thing that I can think of that is really different for ")#mi("t")#text(" below ")#mi("0")#text(", is that there is no longer extra ‘heat/pressure’ being added (since the infinite Euler product has been completed at ")#mi("t=0")#text("). It seems therefore that somehow this incremental ‘heat/pressure’ build-up when ")#mi("t \\rightarrow 0")#text(", is at the same time also the prohibiting force for real zeros to collide. And this feels like a circular reasoning and probably brings us back again to the duality between the primes and the non-trivial zeros…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496654")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("Couldn’t resist producing an illustrative ")#link("https://drive.google.com/open?id=1DpKwzWsjSdtO_GmSlqm0ZWdzPLfsAYK4")[#text("visual of the analogy.")]#text(". The trajectory of the real zeros is based on real data, I manually added fictitious data to reflect the trajectory of the complex zeros.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2018")])]

#text("Consider the model problem of evaluating")

#mi("\\displaystyle \\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2}+ \\frac{t}{4} \\log \\frac{N^2}{n} - \\pi it/8}}")

#text("for multiple choices of ")#mi("x,y,t")#text(", with ")#mi("x")#text(" in an interval ")#mi("[X,X+1]")#text(". If one does this naively, ")#mi("M")#text(" different evaluations of this sum would require about ")#mi("MN")#text(" operations. There is a relatively cheap way to cut down this computation (at the cost of a bit of accuracy) without any FFT, simply by performing a Taylor expansion on intervals. Namely, pick some ")#mi("H")#text(" between ")#mi("1")#text(" and ")#mi("N")#text(" and split the sum into about ")#mi("N/H")#text(" subsums of the form")

#mi("\\displaystyle \\sum_{n=n_0+1}^{n_0+H} \\frac{1}{n^{\\frac{1+y-ix}{2}+ \\frac{t}{4} \\log \\frac{N^2}{n} - \\pi it/8}}")

#text("(actually it is slightly more advantageous to use summation ranges centred around ")#mi("n_0")#text(", rather than to the right of ")#mi("n_0")#text(", but let us ignore this for the time being). Writing ")#mi("n = n_0 + h")#text(", and also ")#mi("x = X + \\theta")#text(", we can write this expression as")

#mi("\\displaystyle \\frac{1}{n_0^{\\frac{1+y-i\\theta}{2}+ \\frac{t}{4} \\log \\frac{N^2}{n_0} - \\pi it/8}}  \\sum_{h=1}^H (n_0+h)^{iX/2} \\times")#linebreak()#text(" ")#mi("\\displaystyle \\times \\exp( (-\\frac{1+y-i\\theta}{2} + \\pi it/8 - \\frac{t}{4} \\log \\frac{N^2}{n_0^2}) \\log(1+\\frac{h}{n_0}) + \\frac{t}{2} \\log^2(1+\\frac{h}{n_0}) ).")

#text("For ")#mi("H")#text(" small compared to ")#mi("n_0")#text(", we can hope to Taylor approximate ")#mi("\\log(1+\\frac{h}{n_0}) \\approx \\frac{h}{n_0}")#text(", leading eventually to the first-order approximation")

#mi("\\displaystyle \\frac{1}{n_0^{\\frac{1+y-i\\theta}{2}+ \\frac{t}{4} \\log \\frac{N^2}{n_0} - \\pi it/8}} \\times")#linebreak()#text(" ")#mi("\\displaystyle \\times ( \\sum_{h=1}^H (n_0+h)^{iX/2}  + (-\\frac{1+y-i\\theta}{2} + \\pi i t/8 - \\frac{t}{4} \\log \\frac{N^2}{n_0^2}) \\sum_{h=1}^H (n_0+h)^{iX/2} \\frac{h}{n_0}).")

#text("The point of this is that if one wants to evaluate this subsum at ")#mi("M")#text(" different choices of ")#mi("(\\theta,y,t)")#text(", one only needs ")#mi("O(M+H)")#text(" evaluations rather than ")#mi("O(MH)")#text(" because one only needs to compute the sums ")#mi("\\sum_{h=1}^H (n_0+h)^{iX/2}")#text(" and ")#mi("\\sum_{h=1}^H (n_0+h)^{iX/2} \\frac{h}{n_0}")#text(" once rather than ")#mi("M")#text(" times, as they can be reused across the evaluations. Putting together the ")#mi("N/H")#text(" subsums, this cuts down the time complexity from ")#mi("O(NM)")#text(" to ")#mi("O(\\frac{NM}{H} + N)")#text(". One can also Taylor expand to higher order than first-order which allows one to take ")#mi("H")#text(" larger at the cost of worsening the implied constant in the ")#mi("O()")#text(" notation. There is some optimisation to be done but this should already lead to some speedup, possibly as much an order of magnitude or so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496626")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("The “first sum” can be represented as")#linebreak()#text(" ")#mi("\\zeta (-i X/2, n_0 +1) - \\zeta (-i X/2, n_0 + H +1)")#linebreak()#text(" where ")#mi("zeta (s, a)")#text(" is Hurwitz Zeta function")#linebreak()#text(" ")#link("https://dlmf.nist.gov/25.11")[#text("https://dlmf.nist.gov/25.11")]#linebreak()#text(" ")#link("https://en.wikipedia.org/wiki/Hurwitz_zeta_function")[#text("https://en.wikipedia.org/wiki/Hurwitz_zeta_function")]

#text("The “second sum” is")

#mi("(1/n_0) \\sum_{n=n_0 +1} ^{n_0 + H} n^{1+ i X/2}")#text(" – “first sum”")

#text("which has a similar representation in terms of Hurwitz Zeta function.")

#text("Efficient algorithms for Hurwitz Zeta and related functions and oscillatory series are given in Vepstas’ paper")

#link("https://arxiv.org/pdf/math/0702243.pdf")[#text("Click to access 0702243.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496801")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2018")])]

#text("With H=10 and near X=6*10^10, I have been able to get a speedup of 3x to 4x (although more should be realizable) which increases gradually as M increases.")

#text("To keep H away from n0, the first few terms in the sum are computed exactly (currently I used first 1000 terms for this part), and approximate estimates are used for the remainder sum. Divergence from actual is near the 7th or 8 decimal point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496838")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("That’s promising! Do you have a rough estimate as to what M (the number of ")#mi("(x,y,t)")#text(" values that need to be evaluated) might be for the barrier computation, based on what happened back at ")#mi("t=0.2, y=0.4, X = 5 \\times 10^9")#text("? The main boost to speed should come in the large M regime. Also, if one uses symmetric sums ")#mi("\\sum_{n=n_0-H/2+1}^{n_0+H/2}")#text(" rather than asymmetric sums ")#mi("\\sum_{n=n_0+1}^{n_0+H}")#text(" then the error term should be a bit smaller (by a factor of 4 or so), which should allow one to make H a bit bigger for a given level of accuracy. One could also Taylor expand to second order rather than first to obtain significantly more accuracy, though the formulae get messier when one does so which may counteract the speedup. (Presumably one should start storing quantities such as ")#mi("\\frac{1+y-i\\theta}{2} + \\frac{t}{4} \\log \\frac{N^2}{n_0} - \\frac{\\pi i t}{8}")#text(" that appear multiple times in such formulae so that one does not compute them multiple times, though this is probably not the bottleneck in the computation.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496852")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("I checked the ddx bound at N=69098, y=0.3, t=0 and it comes out to around 1000. If we choose a strip where |(A+B)/B0| seems to stay high (for eg. X = 6*10^10 + 2099 + [0,1] looks good in this respect) and assume it will stay above 1, M too seems to be around 1000. At N=69098, y=0.3, t=0.2, the ddx bound drops significantly to around 5.")

#text("The earlier script was refined so that it is now 6x to 7x faster than direct summation. I will check how varying H, number of Taylor terms and optimizing further can result in further speedup.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496896")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("Writing the Taylor expansion of the exponential in a more general form, it seems possible to improve the accuracy to as much as desired. Also, retaining and not approximating the two log factors does not incur a noticeable cost (storing the repeatedly occuring quantities kind of offsets it) while improving accuracy a bit. For eg. at H=10 and 4 Taylor terms, accuracy improves to 12 digits, and with 10 terms improves to 28 digits taking only 1.5x more time).")

#text("Near X=6*10^10, with H=50 and 4 Taylor terms, I was able to get estimates for 1000 points in around 1.5 minutes with 9 digit accuracy, which was a 20x speedup vs direct estimation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("Sounds good! Could you expand a little on which log factors you found it better to not approximate? [EDIT: I guess you mean doing a Taylor expansion in ")#mi("\\delta := \\log(1+\\frac{h}{n_0})")#text(" rather than in ")#mi("h")#text("? I can see that that would be slightly more efficient.]")

#text("For some very minor accuracy improvements, one could work in a range ")#mi("x \\in X + [-1/2,1/2]")#text(" rather than ")#mi("x \\in X + [0,1]")#text("; also, since we have some lower bound ")#mi("y_0")#text(" on ")#mi("y")#text(", we can write ")#mi("y = y_0 + z")#text(" (say) and pull out a factor of ")#mi("(n_0+h)^{\\frac{-1-y_0+iX}{2}}")#text(" rather than ")#mi("(n_0+h)^{iX/2}")#text(" in order to replace the ")#mi("\\frac{1+y-i\\theta}{2}")#text(" factors with the slightly smaller ")#mi("\\frac{z-i\\theta}{2}")#text(". This should improve the accuracy of the Taylor expansions by a factor of two or so with each term in the expansion, especially in the most important case when t is close to 0 and y close to y_0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496935")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("I will try these out for more improvements. Also, it seems replacing log(N) +- i*Pi/8 with arrays of alpha(s) or alpha(1-s) values to get a close match to the exact (A+B)/B0 estimates also works. I was able to run the script for an entire rectangle (4000 points) in around 6 minutes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496940")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("For the n0 sums, I calculated and stored sums of the form")#linebreak()#text(" ")#mi("\\sum_{h=1}^H (n_0+h)^{\\pm iX/2} \\exp((t/4)\\log^2(1+\\frac{h}{n_0}))\\log^m(1+\\frac{h}{n_0})")#linebreak()#text(" where m ranges from 0 to T-1 and T is the number of desired Taylor terms which can be passed to the function to approximate the larger exponential.")#linebreak()#text(" Replacing ")#mi("\\exp((t/4)\\log^2(1+\\frac{h}{n_0}))")#text(" with ")#mi("1+\\frac {t h^2}{4 n_{0}^2}")#text(" in the sums did not result in a noticeable speed difference overall, so I kept it in its original form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496959")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("Thanks for the clarification. I guess that while we will need to evaluate at thousands of values of ")#mi("x")#text(" (and perhaps hundreds of values of ")#mi("y")#text(" as well), we won’t need as many values of ")#mi("t")#text(" to evaluate (and the evaluation becomes much faster as ")#mi("t")#text(" increases), so there is not much advantage to remove the t-dependence in the inner sums, so it makes sense to keep factors such as ")#mi("\\exp( (t/4) \\log^2(1+h/n_0))")#text(" unexpanded. In that case one can simplify the expressions a bit by writing")

#mi("\\displaystyle \\frac{1}{n^{\\frac{1+y-ix}{2} + \\frac{t}{4} \\log \\frac{N^2}{n} - \\frac{\\pi i t}{8}}}")

#text("for ")#mi("x = X + \\theta")#text(", ")#mi("y = y_0 + z")#text(", ")#mi("n = n_0 + h")#text(" as")

#mi("\\displaystyle \\frac{n_0^{\\frac{-z+i\\theta}{2}}}{(n_0+h)^{\\frac{1+y_0-iX}{2} + \\frac{t}{4} \\log \\frac{N^2}{n_0+h} - \\frac{\\pi i t}{8}}} \\exp( \\frac{-z+i\\theta}{2} \\log(1 + \\frac{h}{n_0}) )")

#text("and use Taylor expansion of the exponential to decouple the ")#mi("h")#text(" variable from the ")#mi("\\theta,z")#text(" variables.")

#text("It seems like we may have a choice of approximations to use: the ")#mi("A^{eff}+B^{eff}")#text(" approximation is our most accurate one (especially if we also insert the ")#mi("C^{eff}")#text(" correction), but the toy approximation ")#mi("A^{toy} + B^{toy}")#text(" may have acceptable accuracy at the ")#mi("x \\sim 6 \\times 10^{10}")#text(" level and will be easier to work with (for instance I’d be likely to make fewer typos with computing d/dt type expressions in the latter : ). Do you have a sense of how complicated it would be to adapt these Taylor expansion techniques to the sums that show up in the ")#mi("A^{eff}+B^{eff} / B^{eff}_0")#text(" expansion? If it is too messy or slow then it may be worth focusing efforts on establishing a barrier for ")#mi("A^{toy} + B^{toy} / B^{toy}_0")#text(" instead and reworking some of the writeup to provide effective estimates for the error of the toy approximation rather than the effective one.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497034")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2018")])]

#text("I have to still try out the y0+z form of the estimate, but in the earlier one it seems instead of calculating")#linebreak()#text(" ")#mi("\\frac{1}{n_0^{\\frac{t}{4}\\log n_0 - P_{n_0,\\theta,toy}}} \\sum\\limits_{m=0}^{T-1} \\frac{P_{n_0,\\theta,toy}^m S_{n_0,H,m}}{m!}")#linebreak()#text(" ")#mi("\\textrm{with } P_{n_0,\\theta,toy} =  -\\frac{1+y-i\\theta}{2} + \\pi it/8 - \\frac{t}{2} \\log \\frac{N}{n_0}")#linebreak()#text(" we calculate")#linebreak()#text(" ")#mi("\\frac{1}{n_0^{\\frac{t}{4}\\log n_0 - P_{n_0,\\theta,eff}}} \\sum\\limits_{m=0}^{T-1} \\frac{P_{n_0,\\theta,eff}^m S_{n_0,H,m}}{m!}")#linebreak()#text(" ")#mi("\\textrm{with } P_{n_0,\\theta,eff} = -\\frac{1+y-i\\theta}{2} - \\frac{t}{2} \\alpha(\\frac{1+y-i(X+\\theta)}{2}) + \\frac{t}{2}\\log n_0")#linebreak()#text(" and ")#mi("S_{n_0,H,m}")#text(" the sum in the earlier comment, and using an array of ")#mi("A_{0}^{eff}/B_{0}^{eff}")#text(" instead of ")#mi("\\frac{1}{N^y}")#text(" (also with appropriate adjustments for the A sum and when y varies instead of x),")#linebreak()#text(" we can switch from approximations of the toy model to approximations of the effective model, with some additional overhead (however the parigp library atleast does well and keeps the overhead small).")

#text("Also, on the discrepancy between the toy and effective estimates, at X=6*10^10, y=0.3, t=0.2 ")#mi("A^{toy}/A_{0}^{toy} \\approx A^{eff}/A_{0}^{eff} \\textrm{ and } B^{toy}/B_{0}^{toy} \\approx B^{eff}/B_{0}^{eff}")#text(" with divergence around the 6th or 7th decimal, but ")#mi("A_{0}^{eff}/B_{0}^{eff} \\textrm{ and } \\frac{1}{N^y}")#text(" are different.")

#text("Some sample values:")

#text("theta,[(A+B)/B0]_toy, [(A+B)/B0]_eff, [(A+B)/B0]_toy_with_exact_gamma")#linebreak()#text(" 0.0, 0.844 + 0.192i, 0.802 + 0.228i, 0.802 + 0.228i")#linebreak()#text(" 0.5, 0.812 + 0.165i, 0.792 + 0.199i, 0.792 + 0.199i")#linebreak()#text(" 1.0, 0.787 + 0.128i, 0.782 + 0.150i, 0.782 + 0.150i")

#text("the difference being only due to the different gamma factor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2018")])]

#text("OK, thanks for this. It sounds like the numerics will be able to handle the effective approximation without too much additional difficulty, so this looks to be a better path than trying to fix up the toy approximation to become more accurate (though this could probably be done by using a more careful Taylor expansion of gamma). It will be a bit messier to rigorously control the error in the Taylor expansion for the effective approximation than the toy approximation, but there should be a lot of room in the error bounds (it looks like we could in fact lose several orders of magnitude in the error bounds if we Taylor expand to a reasonably high order) so hopefully we could use relatively crude estimates to handle this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497120")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("After making the three changes (y0+z, [X-1/2,X+1/2], and symmetric n0 sums), accuracy seems to improve by 2-3 digits.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497202")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2018")])]

#text("Excellent! Hopefully we can trade in surplus accuracy for speed later by increasing the H parameter.")

#text("Since we have a fixed value of ")#mi("X")#text(", and the barrier computation is largely insensitive to the choice of ")#mi("t")#text(" (in particular, a barrier computation for large t can be re-used as is for any smaller value of t, or for any larger value of ")#mi("y")#text("), it seems the next thing to do is to figure out what the smallest value of ")#mi("y")#text(" is for which the barrier computation is feasible. Given that, the main numerical task remaining would be to find the best values of ")#mi("y,t")#text(" above this ")#mi("y")#text(" threshold for which the Euler product calculations work at ")#mi("X")#text(" and above; combining that with analytic error estimates and some treatment of the case of very large ")#mi("x")#text(" will then presumably yield a bound for ")#mi("\\Lambda")#text(" which is close to the limits of our methods.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2018")])]

#text("If t0 is small enough and X is carefully chosen, would it be possible to have y0=0 for the barrier computation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497213")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2018")])]

#text("Intriguing question, Anonymous!")

#text("Just a few thoughts on this, I might be incorrect. If ")#mi("y_0=0")#text(" would be in reach of numerical verification to achieve a ‘fully closed’ barrier, isn’t then the issue that at ")#mi("y_0=0")#text(" we will find real zeros when ")#mi("t")#text(" goes from ")#mi("0 \\cdots t_0")#text("? Of course, we could carefully pick a ")#mi("X")#text(" and avoid a known real zero at ")#mi("t=0")#text(", however we also have to account for all other real zeros that are ‘marching up leftwards’ and could travel through the barrier at ")#mi("y_0=0")#text(".")

#text("However, would we actually still require a ‘double’ barrier when the barrier reaches all the way to ")#mi("y_0=0")#text(" (i.e. no complex zeros can fly from right to left around the ")#mi("y_0")#text("-corner anymore)? If indeed not, then maybe the way out is to just count all real zeros on the line ")#mi("y_0=0")#text(" and ")#mi("t=0 \\cdots t_0")#text(" and subtract them from the total winding number found when scanning the entire barrier ‘rectangle’?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2018")])]

#text("Yes, it seems theoretically possible to achieve this, though it may require a stupendous amount of numerical accuracy to actually pull off. It will probably help to have ")#mi("X")#text(" vary a bit in time, moving to the left to stay away from zeroes. If we can find a continuously varying function ")#mi("X(t)")#text(" such that for all ")#mi("0 \\leq t \\leq t_0")#text(", there are no zeroes in the line segment ")#mi("\\{ X(t)+iy: 0 \\leq y \\leq 1 \\}")#text(" (including at the real endpoint ")#mi("X(t)")#text("), and all zeroes to the left of ")#mi("X(0)")#text(" are known to be real at time ")#mi("t=0")#text(", then this already implies that all zeroes to the left of ")#mi("X(t)")#text(" are real at times ")#mi("0 \\leq t \\leq t_0")#text(", since no complex zeroes can penetrate the barrier, and no real zeroes can become complex at later times. But this would require a very accurate approximation of ")#mi("H_t(x+iy)")#text(" near ")#mi("X(t)")#text(", since no matter where one places ")#mi("X(t)")#text(" one is going to be quite close to one of the real zeroes. In particular the ")#mi("A^{eff}+B^{eff}")#text(" type approximations we have been using may be inadequate for this, one may need to use ")#mi("A^{eff}+B^{eff}-C^{eff}")#text(" or an even higher order expansion. (My understanding is that similar higher order Riemann-Siegel expansions were what were already used in existing numerical verifications of RH. It may be that this is a task better suited for some experts in numerical RH verification, rather than our current Polymath group.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497234")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2018")])]

#text("> some experts in numerical RH verification, rather than our current Polymath group")

#text("it’s about 20 degrees cooler in this shade")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497298")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2018")])]

#text("At N=69098 and t=0.2, we are getting these lower bounds")

#text("y, Bound type, Bound value, verification required upto approx N")#linebreak()#text(" 0.20, Euler 5 Lemma, 0.0699, 1.5 million")#linebreak()#text(" 0.25, Euler 3 Triangle, 0.0270, 900k")

#text("The first one currently looks quite slow to compute and also requires a large verification range. The second one looks feasible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497394")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("OK, so I guess we can try to target ")#mi("t=2, y=0.25")#text(" then (which would give ")#mi("\\Lambda \\leq 0.23125")#text("). It all hinges on whether we can still compute enough of a mesh for the barrier though…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497299")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2018")])]

#text("Since the bound is ")#mi("\\Lambda \\leq t_0 + y_0^2 /2")#text(", it seems that it does not make sense for a given ")#mi("t_0")#text(" to expand much effort to reduce ")#mi("y_0^2 / 2")#text(" much below ")#mi("t_0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497419")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2018")])]

#text("Another possible strategy is to reduce slightly ")#mi("t_0")#text(" from 0.2 to 0.15 (say), and compensate for the added computational complexity by increasing(!) slightly ")#mi("y_0")#text(" from 0.25 to 0.3 (say), with the resulting bound ")#mi("\\Lambda \\leq 0.15 + 0.3^2/2 = 0.195")#text(" – (better even than the limiting choice ")#mi("y_0 = 0")#text(" for ")#mi("t_0 = 0.2")#text(").")

#text("The idea behind this optimization of ")#mi("t_0")#text(" and ")#mi("y_0")#text(" is that if ")#mi("y_0^2 /2")#text(" is sufficiently smaller than ")#mi("t_0")#text(", it seems better to reduce slightly ")#mi("t_0")#text(" and increase(!) slightly ")#mi("y_0")#text(" to keep reasonable computational complexity rather than the strategy of reducing both ")#mi("t_0")#text(" and ")#mi("y_0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497432")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2018")])]

#text("I was kind of intrigued by the n0 sums so have been working to optimize it further. Firstly, just like X, after making y0+z symmetric so that the anchor point is (1+y0)/2, it seems the accuracy is more consistent along the rectangle.")

#text("Eliminating any head or tail exact partial sums, making H=N, and increasing the number of Taylor terms to something like 30 or 50 (with 50 terms, we seem to get above 25 digit accuracy), the same rectangle (4000 mesh points) can be computed under 10 seconds (from 6 min earlier).")

#text("It seems this way the entire barrier strip can be covered within a day. Working now on combining this with the adaptive t mesh.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497492")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("Wow, that is surprisingly good performance! It actually surprises me that H can be taken as large as N, I would have expected the Taylor series expansion to start becoming very poorly convergent at this scale, but I guess the point is that by taking a huge number of Taylor terms one can compensate for this. An analogy would be computing ")#mi("\\exp(x)")#text(" by Taylor expansion (where for our purposes ")#mi("x")#text(" could be something on the order of ")#mi("\\frac{1}{2}\\log N")#text(" after the various symmetrising tricks). Normally one would only want to perform Taylor expansion for x in a range like [-1,1], but if one is willing to take 50 terms then I guess things are good up to something like [-10,10] (the Taylor series ")#mi("\\sum_n x^n/n!")#text(" for ")#mi("\\exp(x)")#text(" peaks at around ")#mi("n=x")#text(") and so perhaps one can indeed treat expressions that are of magnitude ")#mi("\\frac{1}{2} \\log N")#text(" or so for our current choice of ")#mi("N")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497463")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2018")])]

#text("The barrier strip X=6*10^10+2099 + [0,1] (N=69098), y=[0.2,1], t=[0,0.2] was covered (moving forward in t) and the output is kept ")#link("https://drive.google.com/open?id=1gEwNX3ZfAGgT7Hx3Y8vxCn-bbp-UpZsh")[#text("here")]#text(" and ")#link("https://drive.google.com/open?id=16-OBigZ3iM-VXdM4WaBJlYvCTTAz2bHJ")[#text("here")]#text(". The first file gives summary stats for each t in the adaptive t mesh, and the second file gives (A+B)/B0 values for all (x,y,t) mesh points considered. The winding number came out to be zero for each rectangle.")

#text("The multieval method with 50 Taylor terms was used to estimate (A+B)/B0 values along each rectangle. The overall computation time for the strip was around 2.5 hours. Since ddt bounds and ddx bounds take time to compute, they were updated only after every 100 rectangles. For each rectangle, the number of mesh points for each side was kept as ceil(ddx bound) (the strip was chosen where minabb = min rectangle mesh |(A+B)/B0| value was expected to be above 1, indicating an allowable step size above 1/(ddx bound)). This overcompensates a bit for the constant x sides since they are a bit shorter. The t jump used was minabb/(2*ddt bound).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497497")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("That’s great progress! What is the minimum distance of ")#mi("(A + B)/B_0")#text(" amongst the mesh points? At such large values of ")#mi("N,x")#text(", the error terms ")#mi("E_1,E_2,E_3")#text(" should be essentially negligible in this setting, though now that ")#mi("y")#text(" and ")#mi("t")#text(" are a bit lower than what we have dealt with in the past, one may have to be a bit more careful, particularly when ")#mi("t=0")#text(". However, there is a tradeoff between t and y that we could potentially exploit: I think it is possible to replace the condition ")#mi("y \\geq y_0")#text(" in the barrier with the slightly weaker ")#mi("y \\geq \\sqrt{y_0^2 + 2(t_0-t)} = \\sqrt{2(\\Lambda-t)}")#text(", thus one can make the barrier higher at small values of t and only reach ")#mi("y_0")#text(" at the final time ")#mi("t_0")#text(", basically because even if a zero sneaks underneath the elevated barrier at the earlier time it will still be attracted to its complex conjugate and eventually fall down to height ")#mi("y_0")#text(" or below at time ")#mi("t_0")#text(". I haven’t fully checked this claim and having such a moving barrier would also complicate the derivative analysis (one has to compute a total derivative rather than a partial derivative). But it looks like the numerics on the barrier side are now good enough that it is no longer the bottleneck (if I understand your previous comments correctly, the Euler mollifier component of the argument may now be the dominant remaining computation), so maybe this refinement is not needed at this stage.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497464")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2018")])]

#text("Also forgot to mention that y=[0.2,1] was used since the Euler 5 Lemma bound is positive at N=69098,y=0.2,t=0.2 and maybe there will be a faster way to calculate this up to the required N. Although right now I am finding it too slow, so will start with y=0.25, t=0.2 and the Euler 3 and 2 triangle bounds.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497481")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("Using KM’s latest script, a rerun for the same barrier strip ")#mi("X=6 \\cdot 10^{10}+2099 + [0,1], y=[0.2,1], t=[0,0.2]")#text(", but now recalculating the ddx and ddt-bounds for each rectangle, completed in 2 hours and 17 minutes. As expected the number of rectangles (or t-steps) to be verified, dropped from ")#mi("600")#text(" to ")#mi("440")#text(".")

#text("Here is the output:")

#link("https://drive.google.com/open?id=1ZiK1biuQS5oT4CcaMFXbFvC3WjFfwpIV")[#text("Summary per rectangle")]

#link("https://drive.google.com/open?id=1iG1S5XbDZ5G6D6Oq-CLljyt8miGEIsuN")[#text("Full detail")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497525")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("At t=0, y=0.2, N=69098, e_A + e_B + e_C,0 is 0.0012, hence not that small. For the t=0 rectangle, the gap between mesh points was taken as around 1/(ddx bound at t=0) for the sides where x varies and 0.8/ddx bound for the sides where y varies (using the ddx terminology for both ddx and ddy).")

#text("In this particular strip, the minimum |(A+B)/B0| for the t=0 mesh point set turned out to be around 2.374, and above 1.3 for the all the mesh points in all the rectangles considered. From this it seems that between the mesh points, |(A+B)/B0| here can’t go below about 1.185 for t=0 or below 0.65 for the other rectangles (or maybe a bit larger since the step size along the rectangles was conservative than what a adaptive ddx based mesh would have allowed).")

#text("Since t_next was set as t + min_|(A+B)/B0|_t / ddt_bound, it seems |(A+B)/B0| can’t go below 0.325 between the t points, though not sure whether the |f(z)|/2 concept can be applied in the t dimension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("It’s interesting that ")#tao-math("\\left|A+B\\right|/\\left|B_0\\right|", block: false)#text(" is now exceeding 1 at t=0. Is this the reason for selecting ")#mi("X = 6 \\times 10^{10} + 2099 + [0,1]")#text("? I would have expected this function to have average size comparable to 1, so the minimum would usually be less than 1.")

#text("I think the ")#tao-math("\\left|f(z)\\right|/2", block: false)#text(" lower bound should work in the t variable as it does in the x or y variables (as long as the quantity ")#tao-math("\\min\\left|(A+B)/B_0\\right|", block: false)#text(" is estimated on the entire contour, and not just on the mesh, so one also needs some control on x and y derivatives). But it does seem that there is plenty of room between ")#tao-math("\\left|A+B/B_0\\right|", block: false)#text(" and the error terms ")#mi("e_A+e_B+e_{C,0}")#text(" to accommodate any other errors we have to deal with (e.g. the error term in the 50-term Taylor expansion; I’m not sure how best to control that error yet, but given how small it is compared to everything else presumably we will be able to get away with a quite crude estimate here).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497535")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("Yes, this particular X was chosen after some exploration to get large jumps in t. |(A+B)/B0| does seem to have a tendency to jump sharply occasionally near t=0.")#linebreak()#text(" For example, I recently accidentally hit upon X=201062000500 (N=126491), y=0.2, t=0, where the estimate is 15.92 (error bound 0.0009). Changing y to 0.1 gives 23.16, and changing y to 0 gives 38.51. It seems local spikes of H_0 do not die down that quickly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497537")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("To accelerate the mollifier bounds calculations (2-b-a), can we use a strategy like this:")

#text("Suppose we know the bound at N and it is positive enough and we are trying to reuse it for the bound at N+1. The DN terms each for the A and B parts) for the bounds at N and N+1 are similar except for the (t/2)Re(alpha) factor. Hence we subtract the the extra D terms from the bound at N to get a conservative estimate for that at N+1. Similarly to get the bound at N+2 from that at N+1. The conservative bound slowly decreases towards a postive predetermined threshold and we then update the base N again with the exact bound. Actually it seems this looks quite similar to a N mesh except there are a few calculations for each N.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497549")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2018")])]

#text("This looks like it should work. Another variant, which may be a little simpler, is to take the current ")#mi("(A+B)/B_0")#text(" approximation, which I will call ")#mi("(A_N+B_N)/B_0")#text(" to make the dependence on ")#mi("N")#text(" explicit, and approximate it by ")#mi("(A_{N_0}+B_{N_0})/B_0")#text(" for ")#mi("N")#text(" in a mesh interval ")#mi("[N_0,N_0+H)")#text(". For ")#mi("H")#text(" small, say ")#mi("H = 10")#text(", one can hopefully estimate the error between the two approximations and keep it well under acceptable levels. Then we can apply the Euler mollifier method to ")#mi("(A_{N_0}+B_{N_0})/B_0")#text(" and bound this for all ")#mi("x")#text(" in the range with ")#mi("N_0 \\leq N < N_0+H")#text(". With this approach, one doesn't have to analyse the more complicated sums arising from the Euler mollifications of ")#mi("A_N+B_N")#text(".")

#text("Also, relating to Euler mollification: the vestige of the Euler product formula ")#mi("\\sum_{n=1}^\\infty \\frac{1}{n^s} = \\prod_p (1 + \\frac{1}{p^s} + \\frac{1}{p^{2s}} + \\dots)")#text(" suggests, heuristically at least, that ")#mi("H_t(x+iy)")#text(" will be a little larger than usual when the argument of ")#mi("p^{ix/2}")#text(" is close to zero for small primes ")#mi("p")#text(", or equivalently if ")#mi("\\frac{\\log p}{4\\pi} x")#text(" is close to an integer for (say) ")#mi("p=2,3,5")#text(". This heuristic seems to be in good agreement with your choice of ")#mi("x = 6 \\times 10^{10} + 2099")#text(", where ")#mi("\\frac{\\log 2}{4\\pi} x")#text(" has fractional part ")#mi("\\approx 0.068")#text(" and ")#mi("\\frac{\\log 3}{4\\pi} x")#text(" has fractional part ")#mi("\\approx 0.996")#text(" (though things are worse at p=5). It might be that one could use this heuristic to locate some promising further candidate scales x which one could then test numerically to see if they outperform the ones you already found. In particular, a partial Euler product ")#mi("\\prod_{p \\leq P} (1 - \\frac{1}{p^{\\frac{1-ix}{2}}})^{-1}")#text(" for some small value of ")#mi("P")#text(" (e.g. ")#mi("P=5")#text(") could perhaps serve as a proxy for how large one might expect ")#mi("H_t(x+iy)")#text(" to be. (Not coincidentally, these factors also show up in the Euler mollification method. One might also work with the more complicated variant ")#mi("\\prod_{p \\leq P} (1 - \\frac{1}{p^{\\frac{1+y-ix}{2}+\\frac{t}{2} \\alpha(\\frac{1+y-ix}{2}) -\\frac{t}{4} \\log p}})^{-1}")#text(", though this may not make too much difference especially since we are primarily concerned with ")#mi("t,y")#text(" near zero. )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2018")])]

#text("Dirichlet’s theorem on simultaneous Diophantine approximation (which follows from the pigeonhole principle) states that for any sequence of real numbers ")#mi("\\alpha_1, ..., \\alpha_n")#text(", any sequence of consecutive integers ")#mi("x_1, ... , x_Q")#text(" contains an integer ")#mi("x")#text(" such that")

#tao-math("\\left|\\left| \\alpha_j x \\right|\\right| < Q^{-1/n}", block: false)#text(" for ")#mi("j = 1, ... , n")

#text("Where ")#tao-math("\\left|\\left|x\\right|\\right|", block: false)#text(" denotes the distance from ")#mi("x")#text(" to its nearest integer.")

#text("Hence (with ")#mi("\\alpha_j := (\\log p_j) / (4 \\pi)")#text(") where ")#mi("p_j")#text(" denotes the j-th prime, it follows that for a mollifier based on three primes, and ")#mi("Q = 2100")#text(", it is possible to find ")#mi("x")#text(" such that")

#tao-math("\\left|\\left|\\alpha_j x\\right|\\right| < 2100^{-1/3} = 0.078...", block: false)#text(" (")#mi("j=1, 2, 3")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497587")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2018")])]

#text("By evaluating sum(||x * alpha_p||) or evaluating the Euler product for a large number of x (for eg. 6*10^10 + n, n the first 100k integers), and sorting to get small sums or large products, we get several candidates where |(A+B)/B0| is greater than 50. It seems this can be turned into a general method to choose a good barrier strip.")

#text("Some optimizations which further help are to compute the Euler products for x-0.5,x,x+0.5 and filter for x where all three are high, and to use a larger number of primes. Even with these the whole exercise is quite fast (about 2-3 minutes). Also since min |(A+B)/B0| for a rectangle generally occurs on the y=1 side, it helps to search for candidates using the Euler products at both y=0 and y=1.")

#text("Using first 5 primes and the above filters, I could find a candidate X=6*10^10+83952, where the estimate is 72.5 at y=0 and 5.13 at y=1. Running the barrier strip with X+[-0.5,0.5], y=[0.2,1], min |(A+B)/B0| started at 4.32 for the t=0 rectangle (2.374 for the earlier strip), and much fewer t steps were overall needed (280 instead of 440).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497617")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("KM’s idea (outlined a few posts back), for optimizing the ‘mollified’ computations that need to ensure that ")#mi("H_t")#text(" does not vanish in the range from the Barrier (N=69098) till the point where analytics take over (N=1,500,000), seems to work out very well! Only calculating a small number of incremental terms when moving from N to N+1, dramatically improves speed and indeed results in a slowly declining (hence more conservative) lower bound. We actually found the bound declines so slowly and stayed so far above a full-recomputation-threshold, that we never had to recompute the bound at all throughout the entire range. This implies we only require a full (relatively slow) compute of the first N in the range (i.e. at the Barrier) and this also enables the use of higher mollifiers again (for speed reasons we were considering moving back to ")#mi("t=0.2,y=0.25")#text(" with Euler 3, but now could easily use ")#mi("t=0.2,y=0.2")#text(" with Euler 5).")

#text("The run for ")#mi("t=y=0.2, N = 69098...1500000")#text(", step 1, Euler 5 mollifier, completed in just 60 minutes. ")#link("https://drive.google.com/open?id=1KEvwVlZ8YaCP8sGGxOLPH-OB-zfBu9Iq")[#text("Output run. Fields: N, bound")]#text(".")

#link("https://drive.google.com/open?id=12o1IF6JZEwFBTaxYjo1P8BZ7PZv3ffKZ")[#text("Here")]#text(" are also the upper error bounds for ")#mi("t=y=0.2, N = 60000...1510000")#text(" in steps of ")#mi("50000")#text(". Fields: ")#mi("N_0,  3 \\times e_B, e_{C,0}, total")#text(".")

#text("If all correct, this would bring us close to a ")#mi("\\Lambda \\le 0.22")#text(" :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497634")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("Great news! It seems like we have all the pieces needed to complete the proof of ")#mi("\\Lambda \\leq 0.22")#text(", I guess one has to check the analytic argument for ")#mi("N \\geq 1.5 \\times 10^6")#text(" but perhaps you have done this already. It looks like both of the big computations (the barrier computation and the Euler mollification bound computation) are now quite feasible, but I don’t know whether there is much hope to push ")#mi("y")#text(" and ")#mi("t")#text(" much further, at some point I would imagine the Euler mollification bounds will simply fail to prevent zeroes at ")#mi("N \\approx 60000")#text(" at which point we will be stuck (since it is probably not feasible to scan all of this region (as opposed to a narrow barrier) with direct evaluation of ")#mi("A+B/B")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497638")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("While computing the exact mollifier bounds with Euler 7 and higher looks generally infeasible at these heights, is it possible to use an estimate like this to check whether a bound with a high enough mollifier turns positive. Only the first N terms in the B and A mollified bounds are computed exactly, and the remainder is bounded using the approach in the Estimating a Sum wiki.")

#mi("\\textrm{For a given mollifier and N}")#linebreak()#text(" ")#mi("b^{t}_{n/d} = exp((\\frac{t}{4})\\log^{2}(\\frac{n}{d}))")#linebreak()#text(" ")#mi("= exp((\\frac{t}{4})(\\log^{2} n - 2 \\log n \\log d + \\log^{2} d))")#linebreak()#text(" ")#mi("= \\frac{b^{t}_{n} b^{t}_{d}}{n^{(t/2)\\log d}} < \\frac{b^{t}_{n} b^{t}_{d}}{N^{(t/2)\\log d}} \\textrm{..(for } n > N)")

#tao-math("\\textrm{Hence } \\left|\\beta_{n}\\right| = \\left|\\sum\\limits_{d=1}^{D} 1_{n<=dN} 1_{d|n} \\lambda_d b^{t}_{n/d}\\right| < b^{t}_{n} \\sum\\limits_{d=1}^{D} \\frac {b^{t}_{d}\\left|\\lambda_d\\right|}{N^{(t/2)\\log d}} = C_1 b^{t}_{n}", block: false)#linebreak()#text(" ")#mi("\\textrm{and similarly}")#linebreak()#text(" ")#tao-math("\\textrm{Hence } \\left|\\alpha_{n}\\right| < n^y b^{t}_{n} \\sum\\limits_{d=1}^{D} \\frac {b^{t}_{d}\\left|\\lambda_d\\right|}{d^y N^{(t/2)\\log d}} = C_2 n^y b^{t}_{n}", block: false)

#tao-math("\\sum\\limits_{n=1}^{DN}\\frac{\\left|\\beta_{n}\\right|}{n^\\sigma} <\\approx \\sum\\limits_{n=1}^{N}\\frac{\\left|\\beta_{n}\\right|}{n^\\sigma} + C_1 TS_{B,N,DN}", block: false)#linebreak()#text(" ")#tao-math("\\sum\\limits_{n=1}^{DN}\\frac{\\left|\\alpha_{n}\\right|}{n^\\sigma} <\\approx \\sum\\limits_{n=1}^{N}\\frac{\\left|\\alpha_{n}\\right|}{n^\\sigma} + C_2 TS_{A,N,DN}", block: false)#linebreak()#text(" ")#mi("\\textrm{ TS being the tail sum bound from the Estimating a Sum wiki assuming the toy model for the remainder N(D-1) terms}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497647")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2018")])]

#text("Yes, this should work, and also combines well with the strategy of grouping the ")#mi("N")#text(" into batches ")#mi("N \\in [N_0,N_0+H]")#text(" and trying to prove an Euler bound for an entire batch simultaneously. The tail bound could get rather messy though at Euler7.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497681")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("In practice decoupling n and d as above seems to give bounds which are quite different from the exact ones and the gap increases if a higher mollifier is used. Instead of the tail sum bound I also checked the exact value of ")#mi("\\sum\\limits_{N+1}^{DN}\\frac{b^{t}_{n}}{n^\\sigma}")#text(" which too is relatively large, so a bit stuck here.")

#text("The error between (A+B)/B_0 and (A+B)/B_0 truncated to N_0 terms is much smaller compared to |(A+B)/B_0| and seems roughly dependent on N_0. For eg. using N_0=60000, the error is around 10^-4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/df31c02018eb1ee603cf1fca89a7643818b1c392d34c357946b15317c6b95fe4-5b764827d2d71bf0b6dfedec02f4ed4def2e1272a8e822551845143ebc5bb26e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KM")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497707")[#strong[#text("KM")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("It seems the tail sum bound can be replaced with a sharper quantity")#linebreak()#text(" ")#tao-math("= \\sum\\limits_{d=2}^{D}(\\frac{b^{t}_{d}}{N^{(t/2)\\log d}}\\sum\\limits_{(N+1)/d}^{N}\\frac{b^{t}_{dn}}{(dn)^\\sigma}) \\left|\\lambda_d\\right|", block: false)#linebreak()#text(" ")#tao-math("< \\sum\\limits_{d=2}^{D}(\\frac{b^{t}_{d}}{N^{(t/2)\\log d}} \\max(N^{1-\\sigma_B -(t/4) \\log N}, (dN)^{1-\\sigma_B -(t/4) \\log (N/d)}) \\frac{\\log d}{d}) \\left|\\lambda_d\\right|", block: false)#linebreak()#text(" and with similar adjustments for the A tail sum")

#text("Also, if we then use a weaker mollifier with only prime terms and no interaction terms (for eg. ")#mi("[\\lambda_1,\\lambda_2,\\lambda_3,\\lambda_5,\\lambda_7,..]")#text(") the gap between the approximate and the actual bound decreases sharply (I think since the terms in the mollified sum all have the same sign), but the bound still becomes more negative as the mollifier is taken higher.")#linebreak()#text(" If we assume the tail terms take a trapezoid shape with a curved side instead of a convex shape (which should be the case for ")#mi("\\frac{t}{4}log n < \\frac{1 \\pm y}{2} + \\frac{t}{2}log N")#text(") we could use")#linebreak()#text(" ")#mi("\\frac {N^{1-\\sigma_B -(t/4) \\log N} + (dN)^{1-\\sigma_B -(t/4) \\log (N/d)}}{2}")#linebreak()#text(" instead of the max factor in the tail bound.")#linebreak()#text(" With this the bound does improve as we we keep on increasing the mollifier, although atleast with the triangle bound at N=69098 and t=y=0.2, it plateaud at a negative value. Will also now check the behavior for the approximate lemma bound.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497740")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("Thanks for this. The mollifier calculations seem to be getting quite complicated, we may well be near the limits of what can be done here even if we assume enough computational capacity to evaluate all the mollifier bounds. Do you have a sense of how badly things start breaking down if one tries to decrease t or y any further beyond 0.2? (Maybe one could continue this discussion on the new thread though, this one has become rather full.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496635")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("Dear Terry,")

#text("Your analogy is interesting and as the physical state of matter is essentially determined by two physical parameters, namely temperature and pressure, it could be useful to define analogues thereof and maybe to show that $ latex \\Lambda $ corresponds to the triple point of water, where it can exist under the three states solid liquid and gaseous simultaneously. This would be consistent with the seemingly “critical” nature of this constant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68605af64a1e6fdd351a77f2433b7adf2f9cd04727474b417cc1c845066a5e94-d8bc53556dd92c4d890688ebd3b5209234ccd686c220700ce921962010131f65.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sylvain JULIEN")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496636")[#strong[#text("Sylvain JULIEN")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("Perhaps a first step to do so would be to establish theoretically an analogue of the ideal gas relation $ \\latex P=nkT $ where $ P $ is the pressure, $ T $ the absolute temperature, k a universal constant and n the number of particles per unit volume. I guess the analogue of the latter would be the number of zeroes in a domain of area 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496691")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2018")])]

#text("How uniform is the ddt bound in lemma 8.2 in the writeup?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496750")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2018")])]

#text("It holds for all ")#mi("(x,y,t)")#text(" in the region given by (5).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2018")])]

#text("Perhaps “uniform” was the wrong word to use, but I don’t understand how a ddt bound for (x, y, t) helps to establish claim (i) unless the ddt bound applies to an interval, preferably an interval like (X <= x <= X+1, y0 <= y <= 1, t_i <= t <= t_j).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496840")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("Each individual term in the bound is either monotone decreasing or increasing in each of the variables ")#mi("x, y, t")#text(", so in a range such as the one you indicate, you can replace the occurrence of each variable by either its lower or its upper bound as appropriate. (In some cases one may need Lemma 5.1(vi) to establish monotonicity of terms such as ")#tao-math("\\frac{\\left|1+y+ix\\right|}{4\\pi} / (x-6)", block: false)#text(" in ")#mi("x")#text(".)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496857")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("Something strange is going on between gamma and lambda (both lower case) in the writeup. Should the instances of lambda that are not related to mollification be replaced by gamma?")

#emph[#text("[Yes, this is now fixed – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496865")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("There is a line in the writeup like “log lambda = (t/4)[…]” and later there is a line like “d/dt log gamma = (t/4)[…]”. Should the first line be changed to “log gamma = (t/4)[…]” and the second line be changed to “d/dt log gamma = (1/4)[…]”?")

#emph[#text("[Yes, this is now fixed – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496866")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2018")])]

#text("To me it looks like the “log gamma = …” and the “d/dt log gamma = …” lines conflict with each other. In the d/dt log gamma line, should t/4 be replaced by 1/4?")

#emph[#text("[Ah, I see now. Corrected in latest version – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496927")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("In github comments there is still some question about some of the terms in the d/dt bound in lemma 8.2. Specifically the derivation of the (pi/4)*log(n) term in both sums, and why the 2*log(n)/(x-6) term is in the first sum but not the second sum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("The second ")#mi("2 \\log n / (x-6)")#text(" was omitted by mistake, I have restored it. As for the first term, I have added an additional line of explanation: because we have")

#mi("\\displaystyle \\alpha( \\frac{ 1 \\pm y + ix}{2} ) = \\frac{1}{2} \\log \\frac{x}{4\\pi} + \\frac{\\pi i}{4} + O_{\\leq}( \\frac{4}{x-6} )")

#text("we can conjugate to obtain")

#mi("\\displaystyle \\alpha( \\frac{ 1 \\pm y - ix}{2} ) = \\frac{1}{2} \\log \\frac{x}{4\\pi} - \\frac{\\pi i}{4} + O_{\\leq}( \\frac{4}{x-6} ).")

#text("Incidentally, I do not know how to find the github comments you are referring to, do you have a link?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496944")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("If I understand the comments in github, the question is about the expression (1/4) log(n) log(x / 4 pi n) + (pi/4) log(n) in the first and second sums of the |d/dt| bound, and whether (pi/4) log(n) could be changed to (pi/8) log(n).")

#text("I think the reasoning was that the expression originally comes from (alpha((1 + y – ix)/2)/2) log(n), and that alpha((1 + y – ix)/2) is approximated by (1/2)log(x / 4 pi) – (pi i)/4 + …, so when this is divided by two and multiplied by log(n) and the triangle inequality is applied, it should end up with a (pi/8) log(n) term instead of a (pi/4) log(n) term.")

#text("The comment I was referring to is at ")#link("https://github.com/km-git-acc/dbn_upper_bound/pull/77#issuecomment-383368402")[#text("https://github.com/km-git-acc/dbn_upper_bound/pull/77#issuecomment-383368402")]#text(". The github for this project is not organized in a normal way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496956")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("Thanks for the clarification and the link. KM was correct, there was a typo and one could replace the ")#mi("\\pi/4")#text(" factor here by the ")#mi("\\pi/8")#text(" factor.")

#text("Perhaps the best thing to do, as suggested elsewhere by KM, is to replace the ")#mi("A^{eff}+B^{eff}")#text(" approximation by a very slightly less accurate approximation in which the rather messy ")#mi("\\alpha")#text(" factors are replaced by ")#mi("\\log N \\pm i \\pi/4")#text(", making the approximation resemble the ")#mi("A^{toy}+B^{toy}")#text(" approximation instead. Actually I am tempted to simply _use_ the toy approximation and derive effective error bounds for that approximation; this toy approximation was not so great at the previous values of ")#mi("x")#text(" we were working with, but with ")#mi("x")#text(" as large as ")#mi("6 \\times 10^{10}")#text(" it’s actually not that bad. (The error between the two is something of the order of ")#mi("O( \\log x / x )")#text(", I think.) I guess it should not be too difficult to do some numerical experimentation to get some idea of the discrepancy between ")#mi("A^{eff}+B^{eff} / B^{eff}_0")#text(" and ")#mi("A^{toy} + B^{toy} / B^{toy}_0")#text("; if the discrepancy is small enough, we can perhaps just use the toy approximation throughout which will make things like the d/dt calculations and Taylor expansion calculations a lot cleaner.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496929")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("In the writeup Lemma 8.2 applies to region (5) which includes 0 < t <= 1/2. Do either of the bounds in that lemma apply to t=0? In particular I would like to use the |d/dt| bound at t=0 as an upper bound of |d/dt| on some interval if possible.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-496933")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2018")])]

#text("Yes, ")#mi("H_t")#text(" varies smoothly in ")#mi("t")#text(", so one can extend these bounds to the ")#mi("t=0")#text(" case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2018")])]

#text("Is the change of ")#mi("arg(H_t(x + i y_0) / B_0(x + i y_0))")#text(" from ")#mi("x = 0")#text(" to ")#mi("x = X")#text(", being only ")#mi("O(\\log X)")#text(" for large ")#mi("X")#text(" ?")#linebreak()#text(" If so, it seems that tracking the argument changes can be done using only(!) ")#mi("O(\\log X)")#text(" values of ")#mi("x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497064")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2018")])]

#text("The ratio ")#mi("H_t(x+iy) / B_0(x+iy)")#text(" converges to 1 as ")#mi("x \\to \\infty")#text(" for any fixed ")#mi("y>0")#text(", and should also be quite close to 1 when y is large (e.g. ")#mi("y=10")#text(" and ")#mi("x \\geq 200")#text(" should suffice). So, assuming no zeroes of ")#mi("H_t")#text(" for ")#mi("y \\geq y_0")#text(", the total variation of argument of ")#mi("H_t(x+iy_0)/B_0(x+iy_0)")#text(" should be bounded from ")#mi("x=0")#text(" to ")#mi("x=X")#text(". But since we don’t actually know in advance that this is a zero free region, one would presumably have to scan the entire range ")#mi("0 \\leq x \\leq X")#text(" (or use something like the barrier argument we are currently using) in order to actually compute this variation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497089")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("It seems that you meant “as ")#mi("x \\to \\infty")#text("“. ")#emph[#text("[Corrected, thanks – T.]")]#linebreak()#text(" Anyway, if the real part of ")#mi("H_t(x) / B_0")#text(" is positive on an horizontal sub-interval ")#mi("[x_k + i y, x_{k+1} + i y]")#text(", the magnitude of its argument increment over this sub-interval should be less than ")#mi("\\pi")#text(". Is it possible to improve the adaptive mesh used to evaluate the winding number of ")#mi("H_t / B_0")#text(" around a given rectangle ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497105")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("Some improvement to previous winding number arguments are presumably possible. But the most extensive calculation we were able to accomplish so far was to scan a region ")#mi("0 \\leq x \\leq 1.13 \\times 10^6")#text(" at ")#mi("t = y = 0.4")#text(". Currently we are taking ")#mi("t,y")#text(" to be significantly smaller, and ")#mi("x")#text(" to be as large as ")#mi("6 \\times 10^{10}")#text(", so many orders of magnitude improvement over the previous state of the art for the argument principle methods would need to be established for these methods to be competitive.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497101")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("In page 4 of the paper, in the estimate (sixth line below (24))")

#mi("f_t(x + i y) = 1 + O(x^{- t \\log 2 / 4})")

#text("Is the constant of the O-term dependent on ")#mi("t")#text(" (and unbounded as ")#mi("t \\to 0")#text(")?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497342")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("Just for fun, here is a visual that (almost exactly) captures the trajectories of both the real and the complex zeros into a single 3D-plot for a certain range of ")#mi("x,y,t")#text(". For the evaluation of ")#tao-math("\\left|H_t(x+yi)\\right|", block: false)#text(" I used the third approach integral (the unbounded version).")

#text("The real zeros are calculated exactly, however for the complex zeros I used a proxy and stopped scanning when ")#tao-math("\\left|H_t(x+yi)\\right| \\le 0.03", block: false)#text(" for the first time. I normalised ")#tao-math("\\left|H_t\\right|", block: false)#text(" by simply multiplying it with ")#mi("10^{28}")#text(".")

#text("I believe the ")#link("https://drive.google.com/open?id=1g6xjKn-luJk-96JXQZj4i2bfu4ir3hwy")[#text("3D root trajectories")]#text(" look exactly as the theory predicts :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497345")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("This is interesting since one can use this plot by pairing known consecutive real roots of ")#mi("H_0")#text(" by going backwards in time to see from which double real root of ")#mi("H_{t_0}")#text(" (for some negative “initial time” ")#mi("t_0")#text(") they “emerge” and what is the value of their common “initial time” ")#mi("t_0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497348")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("Yes, that is indeed the case. You can make pairs of real roots and find common ‘initial time of birth’. There a snag though about the ‘known consecutive real roots at ")#mi("H_0")#text("‘. Just take a look at the attached 2D frame for ")#mi("y=0")#text(", that outlines a wider view of the trajectories of the real roots over time. It immediately becomes clear that pairs of real zeros are not necessarily consecutive (at ")#mi("H_0")#text(") and also that they could have been born out of complex pair collision a ‘long time ago’.")

#link("https://drive.google.com/open?id=1WeQCOYZyYXWkYN0ZHS95ColZuuD90xpu")[#text("Trajectories of real zeros")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497369")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("Yes, immediately after their “birth” (from a double zero) they are consecutive, but later a new pair may appear between them.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497392")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("General theory predicts that all complex zeros of ")#mi("H_t(x+iy)")#text(" must travel within a ‘hyperbolic tunnel’ ")#mi("y = \\sqrt{1-2t}")#text(", until they collide with their conjugates.")

#text("Using the ‘barrier approach’, we have shown that for ")#mi("t_0=0.2")#text(", the rectangle ")#mi("y=0.4..y_h, x=0 \\cdots \\infty")#text(" is zero-free, hence ")#mi("\\Lambda \\le 0.28")#text(". In ")#link("https://drive.google.com/open?id=1EoxubQRPbf1u-jSNmROwABUqB2co2_fR")[#text("this diagram")]#text(" I tried to visualise this situation. The zero-free rectangle is shown as a red ‘ceiling’ at ")#mi("t_0")#text(", where complex zeros can’t travel through (note that I exchanged ")#mi("y")#text(" and ")#mi("t")#text(" to obtain the blue hyperbola ")#mi("t = \\frac{1-y^2}{2}")#text("). The area directly above the red ceiling (marked in darker green) now also must be free of complex zeros.")

#text("I then wondered whether these red ‘ceilings’ also cast down a ‘zero-free shadow’, that further constrains the possible trajectories for the complex zeros below it. My logic would be that $\\Lambda \\le 0.28$ could be construed from many different ")#mi("t_0,y_0")#text("-combinations. E.g. ")#mi("y_0=0.6,t_0=0.1")#text(" or ")#mi("y_0=0.74833,t_0=0")#text(". These combinations are reflected as points on the smaller red-dashed hyperbola, with the greyed areas as the new zero-free regions. Is this reasoning correct?")

#text("If this is correct, then an idea could be to use a previously achieved result to further reduce the ")#mi("y")#text("-width of a new barrier to be verified (due to a smaller hyperbola). This of course only makes sense when the X-location of the barrier is moved further up in the new calculation, otherwise just lowering ")#mi("t_0")#text(" would allow full reuse of the already verified barrier.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497426")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2018")])]

#text("Oops. I suddenly saw where my logic fails. There are indeed many combinations of ")#mi("y_0,t_0")#text(" that lead to a ")#mi("\\Lambda = 0.28")#text(", however these combinations are not equivalent. I believe it is still true that a proven zero-free rectangle at ")#mi("t_0, y=y_0..y_h, x=0 \\cdots \\infty")#text(" makes all rectangles for combinations ")#mi("t_0^{\\prime}, y_0^{\\prime}")#text(" for the same ")#mi("\\Lambda")#text(" that occur ‘later’ (i.e. ")#mi("t_0^{\\prime} \\ge t_0")#text(") also zero-free, however the reverse is clearly not true.")

#text("Take for instance the rectangle ")#mi("t_0=0, y=0.74833..1, x=0 \\cdots \\infty")#text(" that resides way ‘earlier’ than the proven zero-free rectangle ")#mi("t_0=0.2, y=0.4..y_h, x=0 \\cdots \\infty")#text(". Both yield ")#mi("\\Lambda = 0.28")#text(", but still zeros could fly through the ‘earlier’ rectangle and collide on the real axis way below ")#mi("t=0.28")#text("…")

#text("I still believe that there is some sort of a ")#link("https://drive.google.com/open?id=16gZIXOIkYsb6CO4-upEdtMHRIIZLj1no")[#text("smaller zero-free")]#text(" ‘shade’ just below the proven rectangles. Is this correct?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("Nice visual! Unfortunately, while we have a lower bound on the rate at which the furthest zero falls towards the real axis, we don’t have an upper bound (in addition to the attraction that this zero feels to its complex conjugate, it will also be attracted to the infinitely many other zeroes). So I don’t know how to establish a zero free region of the sort you indicate; it could be that a zero stays close to the original de Bruijn bound until just before time ")#mi("t_0")#text(", when it decides for some random reason to fall very rapidly towards the real axis. This is a very unlikely scenario, and possibly one that can be eliminated to some extent with a more delicate analysis (based on some sort of statement asserting that if a zero experiences an unusually strong pull towards the real axis at time ")#mi("t_0")#text(", then it must also experience unusually strong pulls at some earlier times), but I don’t see a “cheap” way to do so.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2018")])]

#text("In the writeup, it seems that in the line below (32), “zero” should be “nonzero at ")#mi("0")#text("“.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc9590676e722e6daa601101796394362b089450c3374e62c63f9ca033bbc6d5-4e147817ebc75df7bb49fb4c207126256773c32d376548a3b637a7b578a29b3e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rudolph01")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497735")[#strong[#text("Rudolph01")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("Acknowledging that lowering ")#mi("t_0")#text(" towards ")#mi("t_0=0")#text(" or even below it, would make the verification of a zero-free region for ")#mi("H_{t_0}(x+iy)")#text(" probably exponentially harder, I would like to test a thought that I have outlined in ")#link("https://drive.google.com/open?id=162Ry9TKnjPn2WSyhywFLVZzPNFb-bXOs")[#text("this visual.")]

#text("There are many ")#mi("(t_0, y_0), t_0 \\le 0")#text(" combinations that would give a ")#mi("\\Lambda=0")#text(", e.g. ")#mi("(-0.5,1)")#text(". I believe the formula for the width of a particular ‘ceiling’ to be verified then is: ")#mi("\\sqrt{1-2t_0}-\\sqrt{-2t_0}")#text(". This would imply that when ")#mi("t \\rightarrow -\\infty")#text(", the ‘ceiling’ width to be verified becomes infinitely small. Is this indeed correct?")

#text("Going back in time, there will be a point when the number of complex zeros will stabilise, i.e. the point before which all real zeros have ‘collided’ and no new complex zeros will be ‘generated’ (up to a certain ")#mi("X")#text("). After the collision of two real zeros, the complex zeros will ‘take-off’ from the real line at a guaranteed minimum velocity (there is however no limit on the maximum take-off velocity), hence they will all move steadily away from the real line and travel closer and closer towards the edge of the De Bruijn hyperbola (blue curve in the visual). Could these movements imply that the situation at very large negative ")#mi("t")#text(" becomes less ‘gaseous’ and sufficiently ‘solid’ again, thereby potentially re-enabling the verification of a zero-free ‘ceiling’?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497739")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("Our understanding of the zeroes for negative time is rather poor. De Bruijn’s upper bound is only available at times ")#mi("t \\geq 0")#text(". In my paper with Brad Rodgers, we were not able to get a uniform bound on the imaginary parts of zeroes at negative times; instead we got the weaker bound ")#mi("y =O( \\log(1 + x))")#text(" which is undoubtedly not optimal, but is the best we could manage. One can already see the difficulty in the A+B approximation (it has not been rigorously proven yet that the A+B approximation is accurate in the negative t regime, but I could imagine that this could be done with some effort). This approximation contains terms like ")#mi("\\sum_{n=1}^N \\frac{1}{n^{\\frac{1+y-ix}{2} + \\frac{t}{4} \\log \\frac{N^2}{n}}}")#text(". For positive ")#mi("t")#text(", the ")#mi("\\frac{t}{4} \\log \\frac{N^2}{n}")#text(" factor eventually helps with the convergence and makes the ")#mi("n=1")#text(" term dominate, which is where the “freezing to solid” behavior is coming from. But for negative ")#mi("t")#text(", this term now hurts instead of helps, and makes the sum much wilder, particularly at large values of ")#mi("N")#text(". So I would expect it should become increasingly “gaseous”, though I don’t have a good intuition on exactly how much so.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, ninth thread: going below 0.22? | What's new")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-497737")[#strong[#text("Polymath15, ninth thread: going below 0.22? | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-499813")[#strong[#text("El proyecto Polymath15 logra reducir la cota superior de la constante de Bruijn-Newman | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2018")]

#text("[…] el método numérico [Tao, 28 Mar 2018], hasta alcanzar una cota de Λ ≤ 0.28 [Tao, 17 Apr 2018]. El método de la barrera desarrollado para el ataque analítico prometía […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fab5c6e1d654e936e051b891ff65b3ef4f806fc782404a222f763c7ce32f76f1-9c46a62e47e937a18673457c85da6190f2e6a04a63b11257bcb6fab45f78059e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JUN-HAO")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-501358")[#strong[#text("JUN-HAO")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2018")])]

#text("Dear Pro. Tao,")#linebreak()#text(" I am the high school student, and want to enter the university, but my parents say that major in math, it has disadvantages when I search occupation.Is that ok major in engeeniring or other science area,then, research math? And if you don’t mind,can you tell me what you major in university?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-504304")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2018")])]

#text("Is going below $0.28$ and for that matter below $\\epsilon>0$ a complexity theoretic problem? Can complexity theory say anything here substantial?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-504321")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2018")])]

#text("Very roughly speaking, getting ")#mi("\\Lambda")#text(" below ")#mi("\\varepsilon")#text(" is of comparable difficulty to establishing a zero-free region for the zeta function up to height ")#mi("\\exp( C/\\varepsilon)")#text(", where ")#mi("C>0")#text(" is an absolute constant. The known algorithms for verifying such a zero free region are polynomial in the height, so the verification time for proving ")#mi("\\Lambda \\leq \\varepsilon")#text(" currently is exponential in the reciprocal of ")#mi("\\varepsilon")#text(". Of course, if the Riemann hypothesis is ever proved, the verification time becomes ")#mi("O(1)")#text(". :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-504335")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2018")])]

#text("Still does not clarify if it is in $NP$ and perhaps there are approximations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-504337")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2018")])]

#text("The situation should again be broadly analogous to that of finding a zero-free region of the zeta function up to height ")#mi("\\exp(C/\\varepsilon)")#text(". At present there is no certificate known for verifying such a region that also does not require ")#mi("\\exp(C/\\varepsilon)")#text(" amount of time to verify (even assuming unlimited space). It’s possible though that there is a probabilistic algorithm that verifies in much smaller time but using an exponential amount of space, in the spirit of the PCP theorem, but I am not an expert on these matters.")

#text("Of course, as before, if one manages to find a proof of RH, all these tasks can then be done in O(1) time and space. :)")

#text("UPDATE: After looking up the statement of the PCP theorem, it seems that it can be applied directly to conclude that (assuming a zero free region of height ")#mi("\\exp(C/\\varepsilon)")#text(" exists) there exists a probabilistically checkable proof of length ")#mi("\\exp( O(1/\\varepsilon) )")#text(" that can be probabilistically verified (with, say, greater than 2/3 probability of accuracy) using only ")#mi("O(1)")#text(" query complexity. Of course, actually constructing this proof should still take exponential time…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-504349")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2018")])]

#text("Typically ‘proof’s do not change wrt to $\\epsilon$ (sort of the situation like P/poly where if something is in P/poly we expect to be in P). We may have to show a certain property for a sequence of 0’s and 1’s whose length depends on epsilon but typically for various epsilon we should expect the proof structure to be same (which can be extrapolated all the way to epsilon=0). This is consistent with the known fact that RH is a Pi_1 statement. May be there is an alternate route to going past 0.22 or so and may be all the way to 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3e70213003ccd073b80e315c81fe872823884f16498500131d5cd1f05259060-5b0be47db6542147f7d241ef2dc6c3e6600433181762f92f13a74211cd903572.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-504350")[#strong[#text("a")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2018")])]

#text("‘ something is in P/poly’ should ‘something that is provable, natural and not totally out of the world is in P/poly’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath15, tenth thread: numerics update | What's new")]], [#link("https://terrytao.wordpress.com/2018/04/17/polymath15-eighth-thread-going-below-0-28/#comment-504627")[#strong[#text("Polymath15, tenth thread: numerics update | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2018")])]

#text("[…] thread of the Polymath15 project to upper bound the de Bruijn-Newman constant , continuing this post. Discussion of the project of a non-research nature can continue for now in the existing proposal […]")
]
