// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/
// Converted to Typst by tao2typ: "2026-10-14T09:04:11.719431+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A, Notes 5: Differentiation theorems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A, Notes 5: Differentiation theorems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 October 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")[#text("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{[a,b]}")#text(" be a compact interval of positive length (thus ")#mi("{-\\infty < a < b < +\\infty}")#text("). Recall that a function ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" is said to be ")#emph[#text("differentiable")]#text(" at a point ")#mi("{x \\in [a,b]}")#text(" if the limit ")#metadata(none) <tao-4af4e217c06a9b00b977>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("F^{\\prime}(x) := \\lim_{y \\rightarrow x; y \\in [a,b] \\backslash \\{x\\}} \\frac{F(y)-F(x)}{y-x}")]]

#text("exists. In that case, we call ")#mi("{F^{\\prime}(x)}")#text(" the ")#emph[#text("strong derivative")]#text(", ")#emph[#text("classical derivative")]#text(", or just ")#emph[#text("derivative")]#text(" for short, of ")#mi("{F}")#text(" at ")#mi("{x}")#text(". We say that ")#mi("{F}")#text(" is ")#emph[#text("everywhere differentiable")]#text(", or ")#link("http://en.wikipedia.org/wiki/Differentiable_function")[#text("differentiable")]#text(" for short, if it is differentiable at all points ")#mi("{x \\in [a,b]}")#text(", and ")#emph[#text("differentiable almost everywhere")]#text(" if it is differentiable at almost every point ")#mi("{x \\in [a,b]}")#text(". If ")#mi("{F}")#text(" is differentiable everywhere and its derivative ")#mi("{F^{\\prime}}")#text(" is continuous, then we say that ")#mi("{F}")#text(" is ")#emph[#text("continuously differentiable")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("Much later in this sequence")]#text(", when we cover the theory of distributions, we will see the notion of a ")#emph[#text("weak derivative")]#text(" or ")#emph[#text("distributional derivative")]#text(", which can be applied to a much rougher class of functions and is in many ways more suitable than the classical derivative for doing “Lebesgue” type analysis (i.e. analysis centred around the Lebesgue integral, and in particular allowing functions to be uncontrolled, infinite, or even undefined on sets of measure zero). However, for now we will stick with the classical approach to differentiation.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-e1dd865cbf28ee943a8b>#text(" If ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" is everywhere differentiable, show that ")#mi("{F}")#text(" is continuous and ")#mi("{F^{\\prime}}")#text(" is measurable. If ")#mi("{F}")#text(" is almost everywhere differentiable, show that the (almost everywhere defined) function ")#mi("{F^{\\prime}}")#text(" is measurable (i.e. it is equal to an everywhere defined measurable function on ")#mi("{[a,b]}")#text(" outside of a null set), but give an example to demonstrate that ")#mi("{F}")#text(" need not be continuous.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Give an example of a function ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" which is everywhere differentiable, but not continuously differentiable. (")#emph[#text("Hint:")]#text(" choose an ")#mi("{F}")#text(" that vanishes quickly at some point, say at the origin ")#mi("{0}")#text(", but which also oscillates rapidly near that point.)")
]

#text("In single-variable calculus, the operations of integration and differentiation are connected by a number of basic theorems, starting with ")#link("http://en.wikipedia.org/wiki/Rolle's_theorem")[#text("Rolle’s theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Rolle’s theorem)")]#text(" Let ")#mi("{[a,b]}")#text(" be a compact interval of positive length, and let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be a differentiable function such that ")#mi("{F(a)=F(b)}")#text(". Then there exists ")#mi("{x \\in (a,b)}")#text(" such that ")#mi("{F^{\\prime}(x)=0}")#text(".")
]

#emph[#text("Proof:")]#text(" By subtracting a constant from ")#mi("{F}")#text(" (which does not affect differentiability or the derivative) we may assume that ")#mi("{F(a)=F(b)=0}")#text(". If ")#mi("{F}")#text(" is identically zero then the claim is trivial, so assume that ")#mi("{F}")#text(" is non-zero somewhere. By replacing ")#mi("{F}")#text(" with ")#mi("{-F}")#text(" if necessary, we may assume that ")#mi("{F}")#text(" is positive somewhere, thus ")#mi("{\\sup_{x \\in [a,b]} F(x) > 0}")#text(". On the other hand, as ")#mi("{F}")#text(" is continuous and ")#mi("{[a,b]}")#text(" is compact, ")#mi("{F}")#text(" must attain its maximum somewhere, thus there exists ")#mi("{x \\in [a,b]}")#text(" such that ")#mi("{F(x) \\geq F(y)}")#text(" for all ")#mi("{y \\in [a,b]}")#text(". Then ")#mi("{F(x)}")#text(" must be positive and so ")#mi("{x}")#text(" cannot equal either ")#mi("{a}")#text(" or ")#mi("{b}")#text(", and thus must lie in the interior. From the right limit of ")#link(<tao-4af4e217c06a9b00b977>)[#text("(1)")]#text(" we see that ")#mi("{F^{\\prime}(x) \\leq 0}")#text(", while from the left limit we have ")#mi("{F^{\\prime}(x) \\geq 0}")#text(". Thus ")#mi("{F^{\\prime}(x)=0}")#text(" and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Observe that the same proof also works if ")#mi("{F}")#text(" is only differentiable in the interior ")#mi("{(a,b)}")#text(" of the interval ")#mi("{[a,b]}")#text(", so long as it is continuous all the way up to the boundary of ")#mi("{[a,b]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Give an example to show that Rolle’s theorem can fail if ")#mi("{f}")#text(" is merely assumed to be almost everywhere differentiable, even if one adds the additional hypothesis that ")#mi("{f}")#text(" is continuous. This example illustrates that everywhere differentiability is a significantly stronger property than almost everywhere differentiability. We will see further evidence of this fact later in these notes; there are many theorems that assert in their conclusion that a function is almost everywhere differentiable, but few that manage to conclude ")#emph[#text("everywhere")]#text(" differentiability.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" It is important to note that Rolle’s theorem only works in the real scalar case when ")#mi("{F}")#text(" is real-valued, as it relies heavily on the least upper bound property for the domain ")#mi("{{\\bf R}}")#text(". If, for instance, we consider complex-valued scalar functions ")#mi("{F: [a,b] \\rightarrow {\\bf C}}")#text(", then the theorem can fail; for instance, the function ")#mi("{F: [0,1] \\rightarrow {\\bf C}}")#text(" defined by ")#mi("{F(x) := e^{2\\pi i x} - 1}")#text(" vanishes at both endpoints and is differentiable, but its derivative ")#mi("{F^{\\prime}(x) = 2\\pi i e^{2\\pi i x}}")#text(" is never zero. (Rolle’s theorem does imply that the real and imaginary parts of the derivative ")#mi("{F^{\\prime}}")#text(" both vanish somewhere, but the problem is that they don’t ")#emph[#text("simultaneously")]#text(" vanish at the same point.) Similar remarks to functions taking values in a finite-dimensional vector space, such as ")#mi("{{\\bf R}^n}")#text(".")
]

#text("One can easily amplify Rolle’s theorem to the ")#link("http://en.wikipedia.org/wiki/Mean_value_theorem")[#text("mean value theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8 (Mean value theorem)")]#text(" Let ")#mi("{[a,b]}")#text(" be a compact interval of positive length, and let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be a differentiable function. Then there exists ")#mi("{x \\in (a,b)}")#text(" such that ")#mi("{F^{\\prime}(x)=\\frac{F(b)-F(a)}{b-a}}")#text(".")
]

#emph[#text("Proof:")]#text(" Apply Rolle’s theorem to the function ")#mi("{x \\mapsto F(x) - \\frac{F(b)-F(a)}{b-a} (x-a)}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" As Rolle’s theorem is only applicable to real scalar-valued functions, the more general mean value theorem is also only applicable to such functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Uniqueness of antiderivatives up to constants)")]#text(" ")#metadata(none) <tao-f97a403df41788c34dab>#text(" Let ")#mi("{[a,b]}")#text(" be a compact interval of positive length, and let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" and ")#mi("{G: [a,b] \\rightarrow {\\bf R}}")#text(" be differentiable functions. Show that ")#mi("{F^{\\prime}(x)=G^{\\prime}(x)}")#text(" for every ")#mi("{x \\in [a,b]}")#text(" if and only if ")#mi("{F(x)=G(x)+C}")#text(" for some constant ")#mi("{C \\in {\\bf R}}")#text(" and all ")#mi("{x \\in [a,b]}")#text(".")
]

#text("We can use the mean value theorem to deduce one of the fundamental theorems of calculus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Second fundamental theorem of calculus)")]#text(" ")#metadata(none) <tao-56a426839b0d90577b49>#text(" Let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be a differentiable function, such that ")#mi("{F^{\\prime}}")#text(" is Riemann integrable. Then the Riemann integral ")#mi("{\\int_a^b F^{\\prime}(x)\\ dx}")#text(" of ")#mi("{F^{\\prime}}")#text(" is equal to ")#mi("{F(b) - F(a)}")#text(". In particular, we have ")#mi("{\\int_a^b F^{\\prime}(x)\\ dx = F(b)-F(a)}")#text(" whenever ")#mi("{F}")#text(" is continuously differentiable.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\varepsilon > 0}")#text(". By the definition of Riemann integrability, there exists a finite partition ")#mi("{a = t_0 < t_1 < \\ldots < t_k = b}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^k F^{\\prime}(t^*_j) (t_j - t_{j-1}) - \\int_a^b F^{\\prime}(x)\\right| \\leq \\varepsilon", block: true)]]

#text("for every choice of ")#mi("{t^*_j \\in [t_{j-1},t_j]}")#text(".")#linebreak()#text(" Fix this partition. From the mean value theorem, for each ")#mi("{1 \\leq j \\leq k}")#text(" one can find ")#mi("{t^*_j \\in [t_{j-1},t_j]}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(t^*_j) (t_j - t_{j-1}) = F(t_j) - F(t_{j-1})")]]

#text("and thus by telescoping series")

#align(center)[#tao-fit-display[#tao-math("\\left|(F(b)-F(a)) - \\int_a^b F^{\\prime}(x)\\right| \\leq \\varepsilon.", block: true)]]

#text("Since ")#mi("{\\varepsilon > 0}")#text(" was arbitrary, the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" Even though the mean value theorem only holds for real scalar functions, the fundamental theorem of calculus holds for complex or vector-valued functions, as one can simply apply that theorem to each component of that function separately.")
]

#text("Of course, we also have the other half of the fundamental theorem of calculus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (First fundamental theorem of calculus)")]#text(" ")#metadata(none) <tao-ca51debf22a72f0b6410>#text(" Let ")#mi("{[a,b]}")#text(" be a compact interval of positive length. Let ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(" be a continuous function, and let ")#mi("{F: [a,b] \\rightarrow {\\bf C}}")#text(" be the indefinite integral ")#mi("{F(x) := \\int_a^x f(t)\\ dt}")#text(". Then ")#mi("{F}")#text(" is differentiable on ")#mi("{[a,b]}")#text(", with derivative ")#mi("{F^{\\prime}(x) = f(x)}")#text(" for all ")#mi("{x \\in [a,b]}")#text(". In particular, ")#mi("{F}")#text(" is continuously differentiable.")
]

#emph[#text("Proof:")]#text(" It suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0^+} \\frac{F(x+h)-F(x)}{h} = f(x)")]]

#text("for all ")#mi("{x \\in [a,b)}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0^-} \\frac{F(x+h)-F(x)}{h} = f(x)")]]

#text("for all ")#mi("{x \\in (a,b]}")#text(". After a change of variables, we can write")

#align(center)[#tao-fit-display[#mitex("\\frac{F(x+h)-F(x)}{h} = \\int_0^1 f(x+ht)\\ dt")]]

#text("for any ")#mi("{x \\in [a,b)}")#text(" and any sufficiently small ")#mi("{h>0}")#text(", or any ")#mi("{x \\in (a,b]}")#text(" and any sufficiently small ")#mi("{h<0}")#text(". As ")#mi("{f}")#text(" is continuous, the function ")#mi("{t \\mapsto f(x+ht)}")#text(" converges uniformly to ")#mi("{f(x)}")#text(" on ")#mi("{[0,1]}")#text(" as ")#mi("{h \\rightarrow 0}")#text(" (keeping ")#mi("{x}")#text(" fixed). As the interval ")#mi("{[0,1]}")#text(" is bounded, ")#mi("{\\int_0^1 f(x+ht)\\ dt}")#text(" thus converges to ")#mi("{\\int_0^1 f(x)\\ dt = f(x)}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 14 (Differentiation theorem for continuous functions)")]#text(" ")#metadata(none) <tao-be32e232227df3ecd11c>#text(" Let ")#mi("{f: [a,b] \\rightarrow {\\bf C}}")#text(" be a continuous function on a compact interval. Then we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0^+} \\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt = f(x)")]]

#text("for all ")#mi("{x \\in [a,b)}")#text(",")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0^+} \\frac{1}{h} \\int_{[x-h,x]} f(t)\\ dt = f(x)")]]

#text("for all ")#mi("{x \\in (a,b]}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0^+} \\frac{1}{2h} \\int_{[x-h,x+h]} f(t)\\ dt = f(x)")]]

#text("for all ")#mi("{x \\in (a,b)}")#text(".")
]

#text("In these notes we explore the question of the extent to which these theorems continue to hold when the differentiability or integrability conditions on the various functions ")#mi("{F, F^{\\prime}, f}")#text(" are relaxed. Among the results proven in these notes are")

#list(
[#text("The ")#link("http://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(", which roughly speaking asserts that Corollary ")#link(<tao-be32e232227df3ecd11c>)[#text("14")]#text(" continues to hold for ")#emph[#text("almost")]#text(" every ")#mi("{x}")#text(" if ")#mi("{f}")#text(" is merely absolutely integrable, rather than continuous;")],
[#text("A number of ")#emph[#text("differentiation theorems")]#text(", which assert for instance that monotone, Lipschitz, or bounded variation functions in one dimension are almost everywhere differentiable; and")],
[#text("The second fundamental theorem of calculus for ")#link("http://en.wikipedia.org/wiki/Absolute_continuity")[#text("absolutely continuous")]#text(" functions.")]
)

#text("The material here is loosely based on Chapter 3 of Stein-Shakarchi. ")#metadata(none) <tao-cb3d29a109c8af1d0ebd>

#heading(level: 1)[#strong[#text(" — 1. The Lebesgue differentiation theorem in one dimension — ")]]

#text("The main objective of this section is to show")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Lebesgue differentiation theorem, one-dimensional case)")]#text(" ")#metadata(none) <tao-e518c28ceb674e246890>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function, and let ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(" be the definite integral ")#mi("{F(x) := \\int_{[-\\infty,x]} f(t)\\ dt}")#text(". Then ")#mi("{F}")#text(" is continuous and almost everywhere differentiable, and ")#mi("{F^{\\prime}(x)= f(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}}")#text(".")
]

#text("This can be viewed as a variant of Corollary ")#link(<tao-be32e232227df3ecd11c>)[#text("14")]#text("; the hypotheses are weaker because ")#mi("{f}")#text(" is only assumed to be absolutely integrable, rather than continuous (and can live on the entire real line, and not just on a compact interval); but the conclusion is weaker too, because ")#mi("{F}")#text(" is only found to be almost everywhere differentiable, rather than everywhere differentiable. (But such a relaxation of the conclusion is necessary at this level of generality; consider for instance the example when ")#mi("{f = 1_{[0,1]}}")#text(".)")#linebreak()#text(" The continuity is an easy exercise:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-a59d3e998adb7589495a>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function, and let ")#mi("{F: {\\bf R} \\rightarrow {\\bf C}}")#text(" be the definite integral ")#mi("{F(x) := \\int_{[-\\infty,x]} f(t)\\ dt}")#text(". Show that ")#mi("{F}")#text(" is continuous.")
]

#text("The main difficulty is to show that ")#mi("{F^{\\prime}(x)=f(x)}")#text(" for almost every ")#mi("{x \\in {\\bf R}}")#text(". This will follow from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 17 (Lebesgue differentiation theorem, second formulation)")]#text(" ")#metadata(none) <tao-82a516bbe898c33a8f1a>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function. Then ")#metadata(none) <tao-a821c62e8104f8519d63>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\lim_{h \\rightarrow 0^+} \\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt = f(x)")]]

#text("for almost every ")#mi("{x \\in {\\bf R}}")#text(", and ")#metadata(none) <tao-8693873cd8f8a2d9c7c5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\lim_{h \\rightarrow 0^+} \\frac{1}{h} \\int_{[x-h,x]} f(t)\\ dt = f(x)")]]

#text("for almost every ")#mi("{x \\in {\\bf R}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Show that Theorem ")#link(<tao-e518c28ceb674e246890>)[#text("15")]#text(" follows from Theorem ")#link(<tao-82a516bbe898c33a8f1a>)[#text("17")]#text(".")
]

#text("We will just prove the first fact ")#link(<tao-a821c62e8104f8519d63>)[#text("(2)")]#text("; the second fact ")#link(<tao-8693873cd8f8a2d9c7c5>)[#text("(3)")]#text(" is similar (or can be deduced from ")#link(<tao-a821c62e8104f8519d63>)[#text("(2)")]#text(" by replacing ")#mi("{f}")#text(" with the reflected function ")#mi("{x \\mapsto f(-x)}")#text(".")#linebreak()#text(" We are taking ")#mi("{f}")#text(" to be complex valued, but it is clear from taking real and imaginary parts that it suffices to prove the claim when ")#mi("{f}")#text(" is real-valued, and we shall thus assume this for the rest of the argument.")#linebreak()#text(" The conclusion ")#link(<tao-a821c62e8104f8519d63>)[#text("(2)")]#text(" we want to prove is a convergence theorem – an assertion that for all functions ")#mi("{f}")#text(" in a given class (in this case, the class of absolutely integrable functions ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text("), a certain sequence of linear expressions ")#mi("{T_h f}")#text(" (in this case, the right averages ")#mi("{T_h f(x) = \\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt}")#text(") converge in some sense (in this case, pointwise almost everywhere) to a specified limit (in this case, ")#mi("{f}")#text("). There is a general and very useful argument to prove such convergence theorems, known as the ")#emph[#text("density argument")]#text(". This argument requires two ingredients, which we state informally as follows:")

#enum(start: 1, 
[#text("A verification of the convergence result for some “dense subclass” of “nice” functions ")#mi("{f}")#text(", such as continuous functions, smooth functions, simple functions, etc.. By “dense”, we mean that a general function ")#mi("{f}")#text(" in the original class can be approximated to arbitrary accuracy in a suitable sense by a function in the nice subclass.")],
[#text("A quantitative estimate that upper bounds the maximal fluctuation of the linear expressions ")#mi("{T_h f}")#text(" in terms of the “size” of the function ")#mi("{f}")#text(" (where the precise definition of “size” depends on the nature of the approximation in the first ingredient).")]
)

#text("Once one has these two ingredients, it is usually not too hard to put them together to obtain the desired convergence theorem for general functions ")#mi("{f}")#text(" (not just those in the dense subclass). We illustrate this with a simple example:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 19 (Translation is continuous in ")#mi("{L^1}")#text(")")]#text(" ")#metadata(none) <tao-c61b2a1414fcad8f111d>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function, and for each ")#mi("{h \\in {\\bf R}^d}")#text(", let ")#mi("{f_h: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be the shifted function")

#align(center)[#tao-fit-display[#mitex("f_h(x) := f(x-h).")]]

#text("Then ")#mi("{f_h}")#text(" converges in ")#mi("{L^1}")#text(" norm to ")#mi("{f}")#text(" as ")#mi("{h \\rightarrow 0}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0} \\int_{{\\bf R}^d} |f_h(x) - f(x)|\\ dx = 0.")]]
]

#emph[#text("Proof:")]#text(" We first verify this claim for a dense subclass of ")#mi("{f}")#text(", namely the functions ")#mi("{f}")#text(" which are continuous and compactly supported (i.e. they vanish outside of a compact set). Such functions are continuous, and thus ")#mi("{f_h}")#text(" converges uniformly to ")#mi("{f}")#text(" as ")#mi("{h \\rightarrow 0}")#text(". Furthermore, as ")#mi("{f}")#text(" is compactly supported, the support of ")#mi("{f_h-f}")#text(" stays uniformly bounded for ")#mi("{h}")#text(" in a bounded set. From this we see that ")#mi("{f_h}")#text(" also converges to ")#mi("{f}")#text(" in ")#mi("{L^1}")#text(" norm as required.")#linebreak()#text(" Next, we observe the quantitative estimate ")#metadata(none) <tao-08e95543598aa1973b84>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\int_{{\\bf R}^d} |f_h(x) - f(x)|\\ dx \\leq 2 \\int_{{\\bf R}^d} |f(x)|\\ dx")]]

#text("for any ")#mi("{h \\in {\\bf R}^d}")#text(". This follows easily from the triangle inequality")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} |f_h(x) - f(x)|\\ dx \\leq \\int_{{\\bf R}^d} |f_h(x)|\\ dx + \\int_{{\\bf R}^d} |f(x)|\\ dx")]]

#text("together with the translation invariance of the Lebesgue integral:")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} |f_h(x)|\\ dx = \\int_{{\\bf R}^d} |f(x)|\\ dx.")]]

#text("Now we put the two ingredients together. Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be absolutely integrable, and let ")#mi("{\\varepsilon > 0}")#text(" be arbitrary. Applying Littlewood’s second principle (Theorem 15 from ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("Notes 2")]#text(") to the absolutely integrable function ")#mi("{f}")#text(", we can find a continuous, compactly supported function ")#mi("{g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} |f(x)-g(x)|\\ dx \\leq \\varepsilon.")]]

#text("Applying ")#link(<tao-08e95543598aa1973b84>)[#text("(4)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} |(f-g)_h(x)-(f-g)(x)|\\ dx \\leq 2\\varepsilon,")]]

#text("which we rearrange as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} |(f_h-f)(x)-(g_h-g)(x)|\\ dx \\leq 2\\varepsilon.")]]

#text("By the dense subclass result, we also know that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} |g_h(x)-g(x)|\\ dx \\leq \\varepsilon")]]

#text("for all ")#mi("{h}")#text(" sufficiently close to zero. From the triangle inequality, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} |f_h(x)-f(x)|\\ dx \\leq 3\\varepsilon")]]

#text("for all ")#mi("{h}")#text(" sufficiently close to zero, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" In the above application of the density argument, we proved the required quantitative estimate directly for all functions ")#mi("{f}")#text(" in the original class of functions. However, it is also possible to use the density argument a second time and initially verify the quantitative estimate just for functions ")#mi("{f}")#text(" in a nice subclass (e.g. continuous functions of compact support). In many cases, one can then extend that estimate to the general case by using tools such as ")#link("http://en.wikipedia.org/wiki/Fatou's_lemma")[#text("Fatou’s lemma")]#text(", which are particularly suited for showing that upper bound estimates are preserved with respect to limits.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(", ")#mi("{g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be Lebesgue measurable functions such that ")#mi("{f}")#text(" is absolutely integrable and ")#mi("{g}")#text(" is essentially bounded (i.e. bounded outside of a null set). Show that the ")#link("http://en.wikipedia.org/wiki/Convolution")[#text("convolution")]#text(" ")#mi("{f*g: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" defined by the formula")

#align(center)[#tao-fit-display[#mitex("f*g(x) = \\int_{{\\bf R}^d} f(y) g(x-y)\\ dy")]]

#text("is well-defined (in the sense that the integrand on the right-hand side is absolutely integrable) and that ")#mi("{f*g}")#text(" is a bounded, continuous function.")
]

#text("The above exercise is illustrative of a more general intuition, which is that convolutions tend to be ")#emph[#text("smoothing")]#text(" in nature; the convolution ")#mi("{f*g}")#text(" of two functions is usually at least as regular as, and often more regular than, either of the two factors ")#mi("{f, g}")#text(".")#linebreak()#text(" This smoothing phenomenon gives rise to an important fact, namely the ")#link("http://en.wikipedia.org/wiki/Steinhaus_theorem")[#text("Steinhaus theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Steinhaus theorem)")]#text(" ")#metadata(none) <tao-e8505d7df8b5a092d307>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be a Lebesgue measurable set of positive measure. Show that the set ")#mi("{E-E := \\{ x-y: x, y \\in E \\}}")#text(" contains an open neighbourhood of the origin. (")#emph[#text("Hint:")]#text(" reduce to the case when ")#mi("{E}")#text(" is bounded, and then apply the previous exercise to the convolution ")#mi("{1_E * 1_{-E}}")#text(", where ")#mi("{-E := \\{ -y: y \\in E \\}}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" A ")#emph[#text("homomorphism")]#text(" ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a map with the property that ")#mi("{f(x+y)=f(x)+f(y)}")#text(" for all ")#mi("{x,y \\in {\\bf R}^d}")#text(".")

#list(
[#text("Show that all measurable homomorphisms are continuous. (")#emph[#text("Hint:")]#text(" for any disk ")#mi("{D}")#text(" centered at the origin in the complex plane, show that ")#mi("{f^{-1}(z+D)}")#text(" has positive measure for at least one ")#mi("{z \\in {\\bf C}}")#text(", and then use the Steinhaus theorem from the previous exercise.)")],
[#text("Show that ")#mi("{f}")#text(" is a measurable homomorphism if and only if it takes the form ")#mi("{f(x_1,\\ldots,x_d) = x_1 z_1 +\\ldots + x_d z_d}")#text(" for all ")#mi("{x_1,\\ldots,x_d \\in {\\bf R}}")#text(" and some complex coefficients ")#mi("{z_1,\\ldots,z_d}")#text(". (")#emph[#text("Hint:")]#text(" first establish this for rational ")#mi("{x_1,\\ldots,x_d}")#text(", and then use the previous part of this exercise.)")],
[#text("(For readers familiar with ")#link("http://en.wikipedia.org/wiki/Zorn's_lemma")[#text("Zorn’s lemma")]#text(") Show that there exist homomorphisms ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" which are not of the form in the previous exercise. (Hint: view ")#mi("{{\\bf R}^d}")#text(" (or ")#mi("{{\\bf C}}")#text(") as a vector space over the rationals ")#mi("{{\\bf Q}}")#text(", and use the fact (from Zorn’s lemma) that every vector space – even an infinite-dimensional one – has at least one basis.) This gives an alternate construction of a non-measurable set to that given in previous notes.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 24")]#text(" One drawback with the density argument is it gives convergence results which are ")#emph[#text("qualitative")]#text(" rather than quantitative – there is no explicit bound on the rate of convergence. For instance, in Proposition ")#link(<tao-c61b2a1414fcad8f111d>)[#text("19")]#text(", we know that for any ")#mi("{\\varepsilon > 0}")#text(", there exists ")#mi("{\\delta > 0}")#text(" such that ")#mi("{\\int_{{\\bf R}^d} |f_h(x)-f(x)|\\ dx \\leq \\varepsilon}")#text(" whenever ")#tao-math("{\\left|h\\right| \\leq \\delta}", block: false)#text(", but we do not know exactly how ")#mi("{\\delta}")#text(" depends on ")#mi("{\\varepsilon}")#text(" and ")#mi("{f}")#text(". Actually, the proof does eventually give such a bound, but it depends on “how measurable” the function ")#mi("{f}")#text(" is, or more precisely how “easy” it is to approximate ")#mi("{f}")#text(" by a “nice” function. To illustrate this issue, let’s work in one dimension and consider the function ")#mi("{f(x) := \\sin(Nx) 1_{[0,2\\pi]}(x)}")#text(", where ")#mi("{N \\geq 1}")#text(" is a large integer. On the one hand, ")#mi("{f}")#text(" is bounded in the ")#mi("{L^1}")#text(" norm uniformly in ")#mi("{N}")#text(": ")#mi("{\\int_{\\bf R} |f(x)|\\ dx \\leq 2\\pi}")#text(" (indeed, the left-hand side is equal to ")#mi("{4}")#text("). On the other hand, it is not hard to see that ")#mi("{\\int_{\\bf R} |f_{\\pi/N}(x) - f(x)|\\ dx \\geq c}")#text(" for some absolute constant ")#mi("{c>0}")#text(". Thus, if one force ")#mi("{\\int_{\\bf R} |f_h(x) - f(x)|\\ dx}")#text(" to drop below ")#mi("{c}")#text(", one has to make ")#mi("{h}")#text(" at most ")#mi("{\\pi/N}")#text(" from the origin. Making ")#mi("{N}")#text(" large, we thus see that the rate of convergence of ")#mi("{\\int_{\\bf R} |f_h(x) - f(x)|\\ dx}")#text(" to zero can be arbitrarily slow, even though ")#mi("{f}")#text(" is bounded in ")#mi("{L^1}")#text(". The problem is that as ")#mi("{N}")#text(" gets large, it becomes increasingly difficult to approximate ")#mi("{f}")#text(" well by a “nice” function, by which we mean a uniformly continuous function with a reasonable ")#link("http://en.wikipedia.org/wiki/Modulus_of_continuity")[#text("modulus of continuity")]#text(", due to the increasingly oscillatory nature of ")#mi("{f}")#text(". See ")#link("https://terrytao.wordpress.com/2007/06/18/the-lebesgue-differentiation-theorem-and-the-szemeredi-regularity-lemma/")[#text("this blog post")]#text(" for some further discussion of this issue, and what quantitative substitutes are available for such qualitative results.")
]

#text("Now we return to the Lebesgue differentiation theorem, and apply the density argument. The dense subclass result is already contained in Corollary ")#link(<tao-be32e232227df3ecd11c>)[#text("14")]#text(", which asserts that ")#link(<tao-a821c62e8104f8519d63>)[#text("(2)")]#text(" holds for all continuous functions ")#mi("{f}")#text(". The quantitative estimate we will need is the following special case of the ")#link("http://en.wikipedia.org/wiki/Hardy-Littlewood_maximal_operator")[#text("Hardy-Littlewood maximal inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 25 (One-sided Hardy-Littlewood maximal inequality)")]#text(" ")#metadata(none) <tao-72dfdc86ee288882a51a>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function, and let ")#mi("{\\lambda > 0}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in {\\bf R}: \\sup_{h>0} \\frac{1}{h} \\int_{[x,x+h]} |f(t)|\\ dt \\geq \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\int_{\\bf R} |f(t)|\\ dt.")]]
]

#text("We will prove this lemma shortly, but let us first see how this, combined with the dense subclass result, will give the Lebesgue differentiation theorem. Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be absolutely integrable, and let ")#mi("{\\varepsilon, \\lambda > 0}")#text(" be arbitrary. Then by Littlewood’s second principle, we can find a function ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" which is continuous and compactly supported, with")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} |f(x)-g(x)|\\ dx \\leq \\varepsilon.")]]

#text("Applying the one-sided Hardy-Littlewood maximal inequality, we conclude that")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in {\\bf R}: \\sup_{h>0} \\frac{1}{h} \\int_{[x,x+h]} |f(t)-g(t)|\\ dt \\geq \\lambda \\} ) \\leq \\frac{\\varepsilon}{\\lambda}.")]]

#text("In a similar spirit, from Markov’s inequality we have")

#align(center)[#tao-fit-display[#tao-math("m( \\{ x \\in {\\bf R}: \\left|f(x)-g(x)\\right| \\geq \\lambda \\} ) \\leq \\frac{\\varepsilon}{\\lambda}.", block: true)]]

#text("By subadditivity, we conclude that for all ")#mi("{x \\in {\\bf R}}")#text(" outside of a set ")#mi("{E}")#text(" of measure at most ")#mi("{2\\varepsilon/\\lambda}")#text(", one has both ")#metadata(none) <tao-663a1780ecc5777679bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\frac{1}{h} \\int_{[x,x+h]} |f(t)-g(t)|\\ dt < \\lambda")]]

#text("and ")#metadata(none) <tao-73a5df6585245bf8f720>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|f(x)-g(x)\\right| < \\lambda", block: true)]]

#text("for all ")#mi("{h > 0}")#text(".")#linebreak()#text(" Now let ")#mi("{x \\in {\\bf R} \\backslash E}")#text(". From the dense subclass result (Corollary ")#link(<tao-be32e232227df3ecd11c>)[#text("14")]#text(") applied to the continuous function ")#mi("{g}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{h} \\int_{[x,x+h]} g(t)\\ dt - g(x)\\right| < \\lambda", block: true)]]

#text("whenever ")#mi("{h}")#text(" is sufficiently close to ")#mi("{0}")#text(". Combining this with ")#link(<tao-663a1780ecc5777679bd>)[#text("(5)")]#text(", ")#link(<tao-73a5df6585245bf8f720>)[#text("(6)")]#text(", and the triangle inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt - f(x)\\right| < 3\\lambda", block: true)]]

#text("for all ")#mi("{h}")#text(" sufficiently close to zero. In particular we have")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{h \\rightarrow 0} \\left|\\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt - f(x)\\right| < 3\\lambda", block: true)]]

#text("for all ")#mi("{x}")#text(" outside of a set of measure ")#mi("{2\\varepsilon/\\lambda}")#text(". Keeping ")#mi("{\\lambda}")#text(" fixed and sending ")#mi("{\\varepsilon}")#text(" to zero, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{h \\rightarrow 0} \\left|\\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt - f(x)\\right| < 3\\lambda", block: true)]]

#text("for almost every ")#mi("{x \\in {\\bf R}}")#text(". If we then let ")#mi("{\\lambda}")#text(" go to zero along a countable sequence (e.g. ")#mi("{\\lambda := 1/n}")#text(" for ")#mi("{n=1,2,\\ldots}")#text("), we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{h \\rightarrow 0} \\left|\\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt - f(x)\\right| = 0", block: true)]]

#text("for almost every ")#mi("{x \\in {\\bf R}}")#text(", and the claim follows.")#linebreak()#text(" The only remaining task is to establish the one-sided Hardy-Littlewood maximal inequality. We will do so by using the ")#link("http://en.wikipedia.org/wiki/Rising_sun_lemma")[#text("rising sun lemma")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 26 (Rising sun lemma)")]#text(" ")#metadata(none) <tao-f1ba3850c76ef570bacf>#text(" Let ")#mi("{[a,b]}")#text(" be a compact interval, and let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be a continuous function. Then one can find an at most countable family of disjoint non-empty open intervals ")#mi("{I_n = (a_n,b_n)}")#text(" in ")#mi("{[a,b]}")#text(" with the following properties:")

#enum(start: 1, 
[#text("For each ")#mi("{n}")#text(", either ")#mi("{F(a_n)=F(b_n)}")#text(", or else ")#mi("{a_n=a}")#text(" and ")#mi("{F(b_n) \\geq F(a_n)}")#text(".")],
[#text("If ")#mi("{x \\in (a,b]}")#text(" does not lie in any of the intervals ")#mi("{I_n}")#text(", then one must have ")#mi("{F(y) \\leq F(x)}")#text(" for all ")#mi("{x \\leq y \\leq b}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" To explain the name “rising sun lemma”, imagine the graph ")#mi("{\\{ (x, F(x)): x \\in [a,b] \\}}")#text(" of ")#mi("{F}")#text(" as depicting a hilly landscape, with the sun shining horizontally from the rightward infinity ")#mi("{(+\\infty,0)}")#text(" (or rising from the east, if you will). Those ")#mi("{x}")#text(" for which ")#mi("{F(y) \\leq F(x)}")#text(" are the locations on the landscape which are illuminated by the sun. The intervals ")#mi("{I_n}")#text(" then represent the portions of the landscape that are in shadow.")
]

#text("This lemma is proven using the following basic fact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" ")#metadata(none) <tao-76009e13a36711e60e65>#text(" Show that any open subset ")#mi("{U}")#text(" of ")#mi("{{\\bf R}}")#text(" can be written as the union of at most countably many disjoint non-empty open intervals, whose endpoints lie outside of ")#mi("{U}")#text(". (")#emph[#text("Hint:")]#text(" first show that every ")#mi("{x}")#text(" in ")#mi("{U}")#text(" is contained in a maximal open subinterval ")#mi("{(a,b)}")#text(" of ")#mi("{U}")#text(", and that these maximal open subintervals are disjoint, with each such interval containing at least one rational number.)")
]

#emph[#text("Proof:")]#text(" (Proof of rising sun lemma) Let ")#mi("{U}")#text(" be the set of all ")#mi("{x \\in (a,b)}")#text(" such that ")#mi("{F(y) > F(x)}")#text(" for at least one ")#mi("{x < y < b}")#text(". As ")#mi("{F}")#text(" is continuous, ")#mi("{U}")#text(" is open, and so ")#mi("{U}")#text(" is the union of at most countably many disjoint non-empty open intervals ")#mi("{I_n = (a_n,b_n)}")#text(", with the endpoints ")#mi("{a_n, b_n}")#text(" lying outside of ")#mi("{U}")#text(".")#linebreak()#text(" The second conclusion of the rising sun lemma is clear from construction, so it suffices to establish the first. Suppose first that ")#mi("{I_n = (a_n,b_n)}")#text(" is such that ")#mi("{a_n \\neq a}")#text(". As the endpoint ")#mi("{a_n}")#text(" does not lie in ")#mi("{U}")#text(", we must have ")#mi("{F(y) \\leq F(a_n)}")#text(" for all ")#mi("{a_n \\leq y \\leq b}")#text("; similarly we have ")#mi("{F(y) \\leq F(b_n)}")#text(" for all ")#mi("{b_n \\leq y \\leq b}")#text(". In particular we have ")#mi("{F(b_n) \\leq F(a_n)}")#text(". By the continuity of ")#mi("{F}")#text(", it will then suffice to show that ")#mi("{F(b_n) \\geq F(t)}")#text(" for all ")#mi("{a_n < t < b_n}")#text(".")#linebreak()#text(" Suppose for contradiction that there was ")#mi("{a_n < t < b_n}")#text(" with ")#mi("{F(b_n) < F(t)}")#text(". Let ")#mi("{A := \\{ s \\in [t,b]: F(s) \\geq F(t)\\}}")#text(", then ")#mi("{A}")#text(" is a closed set that contains ")#mi("{t}")#text(" but is disjoint from ")#mi("{[b_n,b]}")#text(", since ")#mi("{F(s) \\leq F(b_n) < F(t)}")#text(" for all ")#mi("{s \\in [b_n,b]}")#text(". Set ")#mi("{t_* := \\sup(A)}")#text(", then ")#mi("{t_* \\in [t,b_n) \\subset I_n \\subset U}")#text(", and thus there exists ")#mi("{t_* < y \\leq b}")#text(" such that ")#mi("{F(y) > F(t_*)}")#text(". Since ")#mi("{F(t_*) \\geq F(t) > F(b_n)}")#text(", and ")#mi("{F(b_n) \\geq F(z)}")#text(" for all ")#mi("{b_n \\leq z \\leq b}")#text(", we see that ")#mi("{y}")#text(" cannot exceed ")#mi("{b_n}")#text(", and thus lies in ")#mi("{A}")#text(", but this contradicts the fact that ")#mi("{t_*}")#text(" is the supremum of ")#mi("{A}")#text(".")#linebreak()#text(" The case when ")#mi("{a_n=a}")#text(" is similar and is left to the reader; the only difference is that we can no longer assert that ")#mi("{F(y) \\leq F(a_n)}")#text(" for all ")#mi("{a_n \\leq y \\leq b}")#text(", and so do not have the upper bound ")#mi("{F(b_n) \\leq F(a_n)}")#text(". ")#mi("\\Box")#linebreak()#text(" Now we can prove the one-sided Hardy-Littlewood maximal inequality. By upwards monotonicity, it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in [a,b]: \\sup_{h>0; [x,x+h] \\subset [a,b]} \\frac{1}{h} \\int_{[x,x+h]} |f(t)|\\ dt \\geq \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\int_{\\bf R} |f(t)|\\ dt")]]

#text("for any compact interval ")#mi("{[a,b]}")#text(". By modifying ")#mi("{\\lambda}")#text(" by an epsilon, we may replace the non-strict inequality here with strict inequality: ")#metadata(none) <tao-0488d503098a47eb3ec3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("m( \\{ x \\in [a,b]: \\sup_{h>0; [x,x+h] \\subset [a,b]} \\frac{1}{h} \\int_{[x,x+h]} |f(t)|\\ dt > \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\int_{\\bf R} |f(t)|\\ dt")]]

#text("Fix ")#mi("{[a,b]}")#text(". We apply the rising sun lemma to the function ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" defined as")

#align(center)[#tao-fit-display[#mitex("F(x) := \\int_{[a,x]} |f(t)|\\ dt - (x-a) \\lambda.")]]

#text("By Lemma ")#link(<tao-a59d3e998adb7589495a>)[#text("16")]#text(", ")#mi("{F}")#text(" is continuous, and so we can find an at most countable sequence of intervals ")#mi("{I_n = (a_n,b_n)}")#text(" with the properties given by the rising sun lemma. From the second property of that lemma, we observe that")

#align(center)[#tao-fit-display[#mitex("\\{ x \\in (a,b]: \\sup_{h>0; [x,x+h] \\subset [a,b]} \\frac{1}{h} \\int_{[x,x+h]} |f(t)|\\ dt > \\lambda \\} \\subset \\bigcup_n I_n,")]]

#text("since the property ")#mi("{\\frac{1}{h} \\int_{[x,x+h]} |f(t)|\\ dt > \\lambda}")#text(" can be rearranged as ")#mi("{F(x+h) > F(x)}")#text(". By countable additivity, we may thus upper bound the left-hand side of ")#link(<tao-0488d503098a47eb3ec3>)[#text("(7)")]#text(" by ")#mi("{\\sum_n (b_n-a_n)}")#text(". On the other hand, since ")#mi("{F(b_n)-F(a_n) \\geq 0}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\int_{I_n} |f(t)|\\ dt \\geq \\lambda (b_n-a_n)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_n (b_n-a_n) \\leq \\frac{1}{\\lambda} \\sum_n \\int_{I_n} |f(t)|\\ dt.")]]

#text("As the ")#mi("{I_n}")#text(" are disjoint intervals in ")#mi("{I}")#text(", we may apply monotone convergence and monotonicity to conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\int_{I_n} |f(t)|\\ dt \\leq \\int_{[a,b]} |f(t)|\\ dt,")]]

#text("and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Two-sided Hardy-Littlewood maximal inequality)")]#text(" ")#metadata(none) <tao-09831212b7cd45c85b50>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function, and let ")#mi("{\\lambda > 0}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("m( \\{ x \\in {\\bf R}: \\sup_{x \\in I} \\frac{1}{\\left|I\\right|} \\int_{I} |f(t)|\\ dt \\geq \\lambda \\} ) \\leq \\frac{2}{\\lambda} \\int_{\\bf R} |f(t)|\\ dt,", block: true)]]

#text("where the supremum ranges over all intervals ")#mi("{I}")#text(" of positive length that contain ")#mi("{x}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30 (Rising sun inequality)")]#text(" ")#metadata(none) <tao-f0f8270db484173c2e0e>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be an absolutely integrable function, and let ")#mi("{f^*: {\\bf R} \\rightarrow {\\bf R}}")#text(" be the one-sided signed Hardy-Littlewood maximal function")

#align(center)[#tao-fit-display[#mitex("f^*(x) := \\sup_{h>0} \\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt.")]]

#text("Establish the ")#emph[#text("rising sun inequality")]

#align(center)[#tao-fit-display[#mitex("\\lambda m( \\{ f^*(x) > \\lambda \\} ) \\leq \\int_{x: f^*(x) > \\lambda} f(x)\\ dx")]]

#text("for all real ")#mi("{\\lambda}")#text(" (note here that we permit ")#mi("{\\lambda}")#text(" to be zero or negative), and show that this inequality implies Lemma ")#link(<tao-72dfdc86ee288882a51a>)[#text("25")]#text(". (")#emph[#text("Hint:")]#text(" First do the ")#mi("{\\lambda=0}")#text(" case, by invoking the rising sun lemma.) See ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("these lecture notes")]#text(" for some further discussion of inequalities of this type, and applications to ergodic theory (and in particular the ")#link("http://en.wikipedia.org/wiki/Maximal_ergodic_theorem")[#text("maximal ergodic theorem")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" Show that the left and right-hand sides in Exercise ")#link(<tao-f0f8270db484173c2e0e>)[#text("30")]#text(" are in fact equal when ")#mi("{\\lambda>0}")#text(". (")#emph[#text("Hint:")]#text(" one may first wish to try this in the case when ")#mi("{f}")#text(" has compact support, in which case one can apply the rising sun lemma to a sufficiently large interval containing the support of ")#mi("{f}")#text(".)")
]

#heading(level: 1)[#strong[#text(" — 2. The Lebesgue differentiation theorem in higher dimensions — ")]]

#text("Now we extend the Lebesgue differentiation theorem to higher dimensions. Theorem ")#link(<tao-e518c28ceb674e246890>)[#text("15")]#text(" does not have an obvious high-dimensional analogue, but Theorem ")#link(<tao-82a516bbe898c33a8f1a>)[#text("17")]#text(" does:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 32 (Lebesgue differentiation theorem in high dimensions)")]#text(" ")#metadata(none) <tao-d840efe6bcd4e60acd57>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function. Then for almost every ")#mi("{x \\in {\\bf R}^d}")#text(", one has ")#metadata(none) <tao-7215d1384efb84579b44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\lim_{r \\rightarrow 0} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y) - f(x)|\\ dy = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lim_{r \\rightarrow 0} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} f(y)\\ dy = f(x),")]]

#text("where ")#tao-math("{B(x,r) := \\{ y \\in {\\bf R}^d: \\left|x-y\\right| < r \\}}", block: false)#text(" is the open ball of radius ")#mi("{r}")#text(" centred at ")#mi("{x}")#text(".")
]

#text("From the triangle inequality we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{1}{m(B(x,r))} \\int_{B(x,r)} f(y)\\ dy - f(x)\\right|", block: true)]]

#tao-aligned(keep: true)[


#tao-math(" & = \\left|\\frac{1}{m(B(x,r))} \\int_{B(x,r)} f(y) - f(x)\\ dy\\right|", block: true)



#tao-math(" & \\leq \\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y) - f(x)|\\ dy,", block: true)
]

#text("so we see that the first conclusion of Theorem ")#link(<tao-d840efe6bcd4e60acd57>)[#text("32")]#text(" implies the second. A point ")#mi("{x}")#text(" for which ")#link(<tao-7215d1384efb84579b44>)[#text("(8)")]#text(" holds is called a ")#emph[#text("Lebesgue point")]#text(" of ")#mi("{f}")#text("; thus, for an absolutely integrable function ")#mi("{f}")#text(", almost every point in ")#mi("{{\\bf R}^d}")#text(" will be a Lebesgue point for ")#mi("{{\\bf R}^d}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Call a function ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" ")#link("http://en.wikipedia.org/wiki/Locally_integrable_function")[#text("locally integrable")]#text(" if, for every ")#mi("{x \\in {\\bf R}^d}")#text(", there exists an open neighbourhood of ")#mi("{x}")#text(" on which ")#mi("{f}")#text(" is absolutely integrable.")

#list(
[#text("Show that ")#mi("{f}")#text(" is locally integrable if and only if ")#mi("{\\int_{B(0,r)} |f(x)|\\ dx < \\infty}")#text(" for all ")#mi("{r>0}")#text(".")],
[#text("Show that Theorem ")#link(<tao-d840efe6bcd4e60acd57>)[#text("32")]#text(" implies a generalisation of itself in which the condition of absolute integrability of ")#mi("{f}")#text(" is weakened to local integrability.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" ")#metadata(none) <tao-478fa0b31bb90e814b42>#text(" For each ")#mi("{h>0}")#text(", let ")#mi("{E_h}")#text(" be a subset of ")#mi("{B(0,h)}")#text(" with the property that ")#mi("{m(E_h) \\geq c m(B(0,h))}")#text(" for some ")#mi("{c>0}")#text(" independent of ")#mi("{h}")#text(". Show that if ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is locally integrable, and ")#mi("{x}")#text(" is a Lebesgue point of ")#mi("{f}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\lim_{h \\rightarrow 0} \\frac{1}{m(E_h)} \\int_{x+E_h} f(y)\\ dy = f(x).")]]

#text("Conclude that Theorem ")#link(<tao-d840efe6bcd4e60acd57>)[#text("32")]#text(" implies Theorem ")#link(<tao-82a516bbe898c33a8f1a>)[#text("17")]#text(".")
]

#text("To prove Theorem ")#link(<tao-d840efe6bcd4e60acd57>)[#text("32")]#text(", we use the density argument. The dense subclass case is easy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Show that Theorem ")#link(<tao-d840efe6bcd4e60acd57>)[#text("32")]#text(" holds whenever ")#mi("{f}")#text(" is continuous.")
]

#text("The quantitative estimate needed is the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 36 (Hardy-Littlewood maximal inequality)")]#text(" ")#metadata(none) <tao-c29c2c2f0fb17d069757>#text(" Let ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function, and let ")#mi("{\\lambda > 0}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in {\\bf R}^d: \\sup_{r>0} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y)|\\ dy \\geq \\lambda \\} )")]]

#align(center)[#tao-fit-display[#mitex("\\leq \\frac{C_d}{\\lambda} \\int_{{\\bf R}^d} |f(t)|\\ dt")]]

#text("for some constant ")#mi("{C_d>0}")#text(" depending only on ")#mi("{d}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 37")]#text(" The expression ")#mi("{\\sup_{r>0} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y)|\\ dy \\geq \\lambda \\}}")#text(" is known as the ")#link("http://en.wikipedia.org/wiki/Hardy-Littlewood_maximal_operator")[#text("Hardy-Littlewood maximal function")]#text(" of ")#mi("{f}")#text(", and is often denoted ")#mi("{Mf(x)}")#text(". It is an important function in the field of (real-variable) ")#link("http://en.wikipedia.org/wiki/Harmonic_analysis")[#text("harmonic analysis")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38")]#text(" Use the density argument to show that Theorem ")#link(<tao-c29c2c2f0fb17d069757>)[#text("36")]#text(" implies Theorem ")#link(<tao-d840efe6bcd4e60acd57>)[#text("32")]#text(".")
]

#text("In the one-dimensional case, this estimate was established via the rising sun lemma. Unfortunately, that lemma relied heavily on the ordered nature of ")#mi("{{\\bf R}}")#text(", and does not have an obvious analogue in higher dimensions. Instead, we will use the following covering lemma. Given an open ball ")#mi("{B = B(x,r)}")#text(" in ")#mi("{{\\bf R}^d}")#text(" and a real number ")#mi("{c > 0}")#text(", we write ")#mi("{cB := B(x,cr)}")#text(" for the ball with the same centre as ")#mi("{B}")#text(", but ")#mi("{c}")#text(" times the radius. (Note that this is slightly different from the set ")#mi("{c \\cdot B := \\{ cy: y \\in B \\}}")#text(" – why?) Note that ")#tao-math("{\\left|cB\\right| = c^d \\left|B\\right|}", block: false)#text(" for any open ball ")#mi("{B \\subset {\\bf R}^d}")#text(" and any ")#mi("{c>0}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 39 (Vitali-type covering lemma)")]#text(" Let ")#mi("{B_1,\\ldots,B_n}")#text(" be a finite collection of open balls in ")#mi("{{\\bf R}^d}")#text(" (not necessarily disjoint). Then there exists a subcollection ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(" of ")#emph[#text("disjoint")]#text(" balls in this collection, such that ")#metadata(none) <tao-56a0bb23bf2faa59b202>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\bigcup_{i=1}^n B_i \\subset \\bigcup_{j=1}^m 3 B^{\\prime}_j.")]]

#text("In particular, by finite subadditivity,")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{i=1}^n B_i ) \\leq 3^d \\sum_{j=1}^m m(B^{\\prime}_j).")]]
]

#emph[#text("Proof:")]#text(" We use a ")#link("http://en.wikipedia.org/wiki/Greedy_algorithm")[#text("greedy algorithm")]#text(" argument, selecting the balls ")#mi("{B^{\\prime}_i}")#text(" to be as large as possible while remaining disjoint. More precisely, we run the following algorithm:")

#list(
[#text("Step 0. Initialise ")#mi("{m=0}")#text(" (so that, initially, there are no balls ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(" in the desired collection).")],
[#text("Step 1. Look at all the balls ")#mi("{B_j}")#text(" that do not already intersect one of the ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(" (which, initially, will be all the balls ")#mi("{B_1,\\ldots,B_n}")#text("). If there are no such balls, STOP. Otherwise, go on to Step 2.")],
[#text("Step 2. Locate the largest ball ")#mi("{B_j}")#text(" that does not already intersect one of the ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(". (If there are multiple largest balls with exactly the same radius, break the tie arbitrarily.) Add this ball to the collection ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(" by setting ")#mi("{B^{\\prime}_{m+1} := B_j}")#text(" and then incrementing ")#mi("{m}")#text(" to ")#mi("{m+1}")#text(". Then return to Step 1.")]
)

#text("Note that at each iteration of this algorithm, the number of available balls amongst the ")#mi("{B_1,\\ldots,B_n}")#text(" drops by at least one (since each ball selected certainly intersects itself and so cannot be selected again). So this algorithm terminates in finite time. It is also clear from construction that the ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(" are a subcollection of the ")#mi("{B_1,\\ldots,B_n}")#text(" consisting of disjoint balls. So the only task remaining is to verify that ")#link(<tao-56a0bb23bf2faa59b202>)[#text("(9)")]#text(" holds at the completion of the algorithm, i.e. to show that each ball ")#mi("{B_i}")#text(" in the original collection is covered by the triples ")#mi("{3B^{\\prime}_j}")#text(" of the subcollection.")#linebreak()#text(" For this, we argue as follows. Take any ball ")#mi("{B_i}")#text(" in the original collection. Because the algorithm only halts when there are no more balls that are disjoint from the ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(", the ball ")#mi("{B_i}")#text(" must intersect at least one of the balls ")#mi("{B^{\\prime}_j}")#text(" in the subcollection. Let ")#mi("{B^{\\prime}_j}")#text(" be the first ball with this property, thus ")#mi("{B_i}")#text(" is disjoint from ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_{j-1}}")#text(", but intersects ")#mi("{B^{\\prime}_j}")#text(". Because ")#mi("{B^{\\prime}_j}")#text(" was chosen to be largest amongst all balls that did not intersect ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_{j-1}}")#text(", we conclude that the radius of ")#mi("{B_i}")#text(" cannot exceed that of ")#mi("{B^{\\prime}_j}")#text(". From the triangle inequality, this implies that ")#mi("{B_i \\subset 3B^{\\prime}_j}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" Technically speaking, the above algorithmic argument was not phrased in the standard language of formal mathematical deduction, because in that language, any mathematical object (such as the natural number ")#mi("{m}")#text(") can only be defined once, and not redefined multiple times as is done in most algorithms. Rewrite the above argument in a way that avoids redefining any variable. (")#emph[#text("Hint:")]#text(" introduce a “time” variable ")#mi("{t}")#text(", and recursively construct families ")#mi("{B^{\\prime}_{1,t},\\ldots,B^{\\prime}_{m_t,t}}")#text(" of balls that represent the outcome of the above algorithm after ")#mi("{t}")#text(" iterations (or ")#mi("{t_*}")#text(" iterations, if the algorithm halted at some previous time ")#mi("{t_* < t}")#text("). For this particular algorithm, there are also more ")#emph[#text("ad hoc")]#text(" approaches that exploit the relatively simple nature of the algorithm to allow for a less notationally complicated construction.) More generally, it is possible to use this time parameter trick to convert any construction involving a provably terminating algorithm into a construction that does not redefine any variable. (It is however dangerous to work with any algorithm that has an infinite run time, unless one has a suitably strong convergence result for the algorithm that allows one to take limits, either in the classical sense or in the more general sense of jumping to ")#link("http://en.wikipedia.org/wiki/Limit_ordinal")[#text("limit ordinals")]#text("; in the latter case, one needs to use ")#link("http://en.wikipedia.org/wiki/Transfinite_induction")[#text("transfinite induction")]#text(" in order to ensure that the use of such algorithms is rigorous.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 41")]#text(" The actual ")#link("http://en.wikipedia.org/wiki/Vitali_covering_lemma")[#text("Vitali covering lemma")]#text(" is slightly different to this one, as the linked Wikipedia page shows. Actually there is a family of related covering lemmas which are useful for a variety of tasks in harmonic analysis, see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=596037")[#text("this book by de Guzmán")]#text(" for further discussion.")
]

#text("Now we can prove the Hardy-Littlewood inequality, which we will do with the constant ")#mi("{C_d := 3^d}")#text(". It suffices to verify the claim with strict inequality,")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in {\\bf R}^d: \\sup_{r>0} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y)|\\ dy > \\lambda \\} ) \\leq \\frac{C_d}{\\lambda} \\int_{{\\bf R}^d} |f(t)|\\ dt")]]

#text("as the non-strict case then follows by perturbing ")#mi("{\\lambda}")#text(" slightly and then taking limits.")#linebreak()#text(" Fix ")#mi("{f}")#text(" and ")#mi("{\\lambda}")#text(". By inner regularity, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("m( K )\\leq \\frac{3^d}{\\lambda} \\int_{{\\bf R}^d} |f(t)|\\ dt")]]

#text("whenever ")#mi("{K}")#text(" is a compact set that is contained in ")#mi("{\\{ x \\in {\\bf R}^d: \\sup_{r>0} \\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y)|\\ dy > \\lambda \\}}")#text(".")#linebreak()#text(" By construction, for every ")#mi("{x \\in K}")#text(", there exists an open ball ")#mi("{B(x,r)}")#text(" such that ")#metadata(none) <tao-66cf042eb95cec136626>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\frac{1}{m(B(x,r))} \\int_{B(x,r)} |f(y)|\\ dy > \\lambda.")]]

#text("By compactness of ")#mi("{K}")#text(", we can cover ")#mi("{K}")#text(" by a finite number ")#mi("{B_1,\\ldots,B_n}")#text(" of such balls. Applying the Vitali-type covering lemma, we can find a subcollection ")#mi("{B^{\\prime}_1,\\ldots,B^{\\prime}_m}")#text(" of disjoint balls such that")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{i=1}^n B_i ) \\leq 3^d \\sum_{j=1}^m m(B^{\\prime}_j).")]]

#text("By ")#link(<tao-66cf042eb95cec136626>)[#text("(10)")]#text(", on each ball ")#mi("{B^{\\prime}_j}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("m(B^{\\prime}_j) < \\frac{1}{\\lambda} \\int_{B^{\\prime}_j} |f(y)|\\ dy;")]]

#text("summing in ")#mi("{j}")#text(" and using the disjointness of the ")#mi("{B^{\\prime}_j}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{i=1}^n B_i ) \\leq \\frac{3^d}{\\lambda} \\int_{{\\bf R}^d} |f(y)|\\ dy.")]]

#text("Since the ")#mi("{B_1,\\ldots,B_n}")#text(" cover ")#mi("{K}")#text(", we obtain Theorem ")#link(<tao-c29c2c2f0fb17d069757>)[#text("36")]#text(" as desired.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" Improve the constant ")#mi("{3^d}")#text(" in the Hardy-Littlewood maximal inequality to ")#mi("{2^d}")#text(". (")#emph[#text("Hint:")]#text(" observe that with the construction used to prove the Vitali covering lemma, the ")#emph[#text("centres")]#text(" of the balls ")#mi("{B_i}")#text(" are contained in ")#mi("{\\bigcup_{j=1}^m 2B^{\\prime}_j}")#text(" and not just in ")#mi("{\\bigcup_{j=1}^m 3B^{\\prime}_j}")#text(". To exploit this observation one may need to first create an epsilon of room, as the centers are not by themselves sufficient to cover the required set.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 43")]#text(" The optimal value of ")#mi("{C_d}")#text(" is not known in general, although a fairly recent ")#link("http://www.ams.org/mathscinet-getitem?mr=1973058")[#text("result of Melas")]#text(" gives the surprising conclusion that the optimal value of ")#mi("{C_1}")#text(" is ")#mi("{C_1 = \\frac{11+\\sqrt{61}}{12} = 1.56\\ldots}")#text(". It is known that ")#mi("{C_d}")#text(" grows at most linearly in ")#mi("{d}")#text(", thanks to a ")#link("http://www.ams.org/mathscinet-getitem?mr=727348")[#text("result of Stein and Strömberg")]#text(", but it is not known if ")#mi("{C_d}")#text(" is bounded in ")#mi("{d}")#text(" or grows as ")#mi("{d \\rightarrow \\infty}")#text(". See ")#link("https://terrytao.wordpress.com/2009/12/07/random-martingales-and-localization-of-maximal-inequalities/")[#text("this blog post")]#text(" for some further discussion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44 (Dyadic maximal inequality)")]#text(" If ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is an absolutely integrable function, establish the dyadic Hardy-Littlewood maximal inequality")

#align(center)[#tao-fit-display[#tao-math("m( \\{ x \\in {\\bf R}^d: \\sup_{x \\in Q} \\frac{1}{\\left|Q\\right|} \\int_{Q} |f(y)|\\ dy \\geq \\lambda \\} ) \\leq \\frac{1}{\\lambda} \\int_{{\\bf R}^d} |f(t)|\\ dt", block: true)]]

#text("where the supremum ranges over all dyadic cubes ")#mi("{Q}")#text(" that contain ")#mi("{x}")#text(". (")#emph[#text("Hint:")]#text(" the nesting property of dyadic cubes will be useful when it comes to the covering lemma stage of the argument, much as it was in Lemma 8 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45 (Besicovitch covering lemma in one dimension)")]#text(" Let ")#mi("{I_1,\\ldots,I_n}")#text(" be a finite family of open intervals in ")#mi("{{\\bf R}}")#text(" (not necessarily disjoint). Show that there exist a subfamily ")#mi("{I^{\\prime}_1,\\ldots,I^{\\prime}_m}")#text(" of intervals such that")

#enum(start: 1, 
[#mi("{\\bigcup_{i=1}^n I_n = \\bigcup_{j=1}^m I^{\\prime}_m}")#text("; and")],
[#text("Each point ")#mi("{x \\in {\\bf R}}")#text(" is contained in at most two of the ")#mi("{I^{\\prime}_m}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" First refine the family of intervals so that no interval ")#mi("{I_i}")#text(" is contained in the union of the the other intervals. At that point, show that it is no longer possible for a point to be contained in three of the intervals.) There is a variant of this lemma that holds in higher dimensions, known as the ")#link("http://en.wikipedia.org/wiki/Besicovitch_covering_theorem")[#text("Besicovitch covering lemma")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 46")]#text(" Let ")#mi("{\\mu}")#text(" be a Borel measure (i.e. a countably additive measure on the Borel ")#mi("{\\sigma}")#text("-algebra) on ")#mi("{{\\bf R}}")#text(", such that ")#mi("{0 < \\mu(I) < \\infty}")#text(" for every interval ")#mi("{I}")#text(" of positive length. Assume that ")#mi("{\\mu}")#text(" is ")#emph[#text("inner regular")]#text(", in the sense that ")#mi("{\\mu(E) = \\sup_{K \\subset E, \\text{ compact}} \\mu(K)}")#text(" for every Borel measurable set ")#mi("{E}")#text(". (As it turns out, from the theory of ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measures")]#text(", all locally finite Borel measures have this property, but we will not prove this here; see Exercise 12 of ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("these notes")]#text(".) Establish the Hardy-Littlewood maximal inequality")

#align(center)[#tao-fit-display[#mitex("\\mu( \\{ x \\in {\\bf R}: \\sup_{x \\in I} \\frac{1}{\\mu(I)} \\int_{I} |f(y)| \\ d\\mu(y) \\geq \\lambda \\} ) \\leq \\frac{2}{\\lambda} \\int_{\\bf R} |f(y)|\\ d\\mu(y)")]]

#text("for any absolutely integrable function ")#mi("{f \\in L^1(\\mu)}")#text(", where the supremum ranges over all open intervals ")#mi("{I}")#text(" that contain ")#mi("{x}")#text(". Note that this essentially generalises Exercise ")#link(<tao-09831212b7cd45c85b50>)[#text("29")]#text(", in which ")#mi("{\\mu}")#text(" is replaced by Lebesgue measure. (")#emph[#text("Hint:")]#text(" Repeat the proof of the usual Hardy-Littlewood maximal inequality, but use the Besicovitch covering lemma in place of the Vitali-type covering lemma. Why do we need the former lemma here instead of the latter?)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47 (Cousin’s theorem)")]#text(" ")#metadata(none) <tao-42e20cbe942249d85888>#text(" Prove ")#link("http://en.wikipedia.org/wiki/Cousin's_theorem")[#text("Cousin’s theorem")]#text(": given any function ")#mi("{\\delta: [a,b] \\rightarrow (0,+\\infty)}")#text(" on a compact interval ")#mi("{[a,b]}")#text(" of positive length, there exists a partition ")#mi("{a = t_0 < t_1 < \\ldots < t_k = b}")#text(" with ")#mi("{k \\geq 1}")#text(", together with real numbers ")#mi("{t^*_j \\in [t_{j-1},t_j]}")#text(" for each ")#mi("{1 \\leq j \\leq k}")#text(" and ")#mi("{t_j - t_{j-1} \\leq \\delta(t^*_j)}")#text(". (")#emph[#text("Hint:")]#text(" use the Heine-Borel theorem, which asserts that any open cover of ")#mi("{[a,b]}")#text(" has a finite subcover, followed by the Besicovitch covering lemma.) This theorem is useful in a variety of applications related to the second fundamental theorem of calculus, as we shall see below. The positive function ")#mi("{\\delta}")#text(" is known as a ")#emph[#text("gauge function")]#text(".")
]

#text("Now we turn to consequences of the Lebesgue differentiation theorem. Given a Lebesgue measurable set ")#mi("{E \\subset {\\bf R}^d}")#text(", call a point ")#mi("{x \\in {\\bf R}^d}")#text(" a ")#emph[#text("point of density")]#text(" for ")#mi("{E}")#text(" if ")#mi("{\\frac{m(E \\cap B(x,r))}{m(B(x,r))} \\rightarrow 1}")#text(" as ")#mi("{r \\rightarrow 0}")#text(". Thus, for instance, if ")#mi("{E = [-1,1] \\backslash \\{0\\}}")#text(", then every point in ")#mi("{(-1,1)}")#text(" (including the boundary point ")#mi("{0}")#text(") is a point of density for ")#mi("{E}")#text(", but the endpoints ")#mi("{-1, 1}")#text(" (as well as the exterior of ")#mi("{E}")#text(") are not points of density. One can think of a point of density as being an “almost interior” point of ")#mi("{E}")#text("; it is not necessarily the case that one can fit an small ball ")#mi("{B(x,r)}")#text(" centred at ")#mi("{x}")#text(" inside of ")#mi("{E}")#text(", but one can fit ")#emph[#text("most")]#text(" of that small ball inside ")#mi("{E}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 48")]#text(" ")#metadata(none) <tao-e1c09fe4da6ce5311650>#text(" If ")#mi("{E \\subset {\\bf R}^d}")#text(" is Lebesgue measurable, show that almost every point in ")#mi("{E}")#text(" is a point of density for ")#mi("{E}")#text(", and almost every point in the complement of ")#mi("{E}")#text(" is not a point of density for ")#mi("{E}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 49")]#text(" ")#metadata(none) <tao-495743e84ebedc618663>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be a measurable set of positive measure, and let ")#mi("{\\varepsilon > 0}")#text(".")

#enum(start: 1, 
[#text("Using Exercise ")#link(<tao-478fa0b31bb90e814b42>)[#text("34")]#text(" and Exercise ")#link(<tao-e1c09fe4da6ce5311650>)[#text("48")]#text(", show that there exists a cube ")#mi("{Q \\subset {\\bf R}^d}")#text(" of positive sidelength such that ")#mi("{m(E \\cap Q) > (1-\\varepsilon) m(Q)}")#text(".")],
[#text("Give an alternate proof of the above claim that avoids the Lebesgue differentiation theorem. (")#emph[#text("Hint:")]#text(" reduce to the case when ")#mi("{E}")#text(" is bounded, then approximate ")#mi("{E}")#text(" by an almost disjoint union of cubes.)")],
[#text("Use the above result to give an alternate proof of the Steinhaus theorem (Exercise ")#link(<tao-e8505d7df8b5a092d307>)[#text("22")]#text(").")]
)
]

#text("Of course, one can replace cubes here by other comparable shapes, such as balls. (Indeed, a good principle to adopt in analysis is that cubes and balls are “equivalent up to constants”, in that a cube of some sidelength can be contained in a ball of comparable radius, and vice versa. This type of mental equivalence is analogous to, though not identical with, the famous dictum that a topologist cannot distinguish a doughnut from a coffee cup.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 50")]

#list(
[#text("Give an example of a compact set ")#mi("{K \\subset {\\bf R}}")#text(" of positive measure such that ")#tao-math("{m(K \\cap I) < \\left|I\\right|}", block: false)#text(" for every interval ")#mi("{I}")#text(" of positive length. (")#emph[#text("Hint:")]#text(" first construct an open dense subset of ")#mi("{[0,1]}")#text(" of measure strictly less than ")#mi("{1}")#text(".)")],
[#text("Give an example of a measurable set ")#mi("{E \\subset {\\bf R}}")#text(" such that ")#tao-math("{0 < m(E \\cap I) < \\left|I\\right|}", block: false)#text(" for every interval ")#mi("{I}")#text(" of positive length. (")#emph[#text("Hint:")]#text(" first work in a bounded interval, such as ")#mi("{(-1,2)}")#text(". The complement of the set ")#mi("{K}")#text(" in the first example is the union of at most countably many open intervals, thanks to Exercise ")#link(<tao-76009e13a36711e60e65>)[#text("28")]#text(". Now fill in these open intervals and iterate.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 51 (Approximations to the identity)")]#text(" Define a ")#emph[#text("good kernel")]#text(" to be a measurable function ")#mi("{P: {\\bf R}^d \\rightarrow {\\bf R}^+}")#text(" which is non-negative, radial (which means that there is a function ")#mi("{\\tilde P: [0,+\\infty) \\rightarrow {\\bf R}^+}")#text(" such that ")#tao-math("{P(x) = \\tilde P(\\left|x\\right|)}", block: false)#text("), radially non-increasing (so that ")#mi("{\\tilde P}")#text(" is a non-increasing function), and has total mass ")#mi("{\\int_{{\\bf R}^d} P(x)\\ dx}")#text(" equal to ")#mi("{1}")#text(". The functions ")#mi("{P_t(x) := \\frac{1}{t^d} P(\\frac{x}{t})}")#text(" for ")#mi("{t>0}")#text(" are then said to be a ")#emph[#text("good family of approximations to the identity")]#text(".")

#list(
[#text("Show that the ")#link("http://en.wikipedia.org/wiki/Heat_kernel")[#text("heat kernels")]#text(" ")#tao-math("{P_t(x) := \\frac{1}{(4\\pi t^2)^{d/2}} e^{-\\left|x\\right|^2/4t^2}}", block: false)#text(" and ")#link("http://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernels")]#text(" ")#tao-math("{P_t(x) := c_d \\frac{t}{(t^2+\\left|x\\right|^2)^{(d+1)/2}}}", block: false)#text(" are good families of approximations to the identity, if the constant ")#mi("{c_d > 0}")#text(" is chosen correctly (in fact one has ")#mi("{c_d = \\Gamma((d+1)/2)/\\pi^{(d+1)/2}}")#text(", but you are not required to establish this). (Note that we have modified the usual formulation of the heat kernel by replacing ")#mi("{t}")#text(" with ")#mi("{t^2}")#text(" in order to make it conform to the notational conventions used in this exercise.)")],
[#text("Show that if ")#mi("{P}")#text(" is a good kernel, then")

#align(center)[#tao-fit-display[#mitex("c_d < \\sum_{n=-\\infty}^\\infty 2^{dn} \\tilde P(2^n) \\leq C_d")]]

#text("for some constants ")#mi("{0 < c_d < C_d}")#text(" depending only on ")#mi("{d}")#text(". (")#emph[#text("Hint:")]#text(" compare ")#mi("{P}")#text(" with such “horizontal wedding cake” functions as ")#tao-math("{\\sum_{n=-\\infty}^\\infty 1_{2^{n-1}< \\left|x\\right| \\leq 2^n} \\tilde P(2^n)}", block: false)#text(".)")],
[#text("Establish the quantitative upper bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\int_{{\\bf R}^d} f(y) P_t(x-y)\\ dy\\right| \\leq C^{\\prime}_d \\sup_{r>0} \\frac{1}{\\left|B(x,r)\\right|} \\int_{B(x,r)} |f(y)|\\ dy", block: true)]]

#text("for any absolutely integrable function ")#mi("{f}")#text(" and some constant ")#mi("{C^{\\prime}_d > 0}")#text(" depending only on ")#mi("{d}")#text(".")],
[#text("Show that if ")#mi("{f: {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is absolutely integrable and ")#mi("{x}")#text(" is a Lebesgue point of ")#mi("{f}")#text(", then the convolution")

#align(center)[#tao-fit-display[#mitex("f*P_t(x) := \\int_{{\\bf R}^d} f(y) P_t(x-y)\\ dy")]]

#text("converges to ")#mi("{f(x)}")#text(" as ")#mi("{t \\rightarrow 0}")#text(". (")#emph[#text("Hint:")]#text(" split ")#mi("{f(y)}")#text(" as the sum of ")#mi("{f(x)}")#text(" and ")#mi("{f(y)-f(x)}")#text(".) In particular, ")#mi("{f*P_t}")#text(" converges pointwise almost everywhere to ")#mi("{f}")#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Almost everywhere differentiability — ")]]

#text("As we see in undergraduate real analysis, not every continuous function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is differentiable, with the standard example being the absolute value function ")#tao-math("{f(x) := \\left|x\\right|}", block: false)#text(", which is continuous not differentiable at the origin ")#mi("{x=0}")#text(". Of course, this function is still almost everywhere differentiable. With a bit more effort, one can construct continuous functions that are in fact ")#link("http://en.wikipedia.org/wiki/Nowhere_differentiable")[#text("nowhere differentiable")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 52 (Weierstrass function)")]#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be the function")

#align(center)[#tao-fit-display[#mitex("F(x) := \\sum_{n=1}^\\infty 4^{-n} \\cos(16^n \\pi x).")]]

#enum(start: 1, 
[#text("Show that ")#mi("{F}")#text(" is well-defined (in the sense that the series is absolutely convergent) and that ")#mi("{F}")#text(" is a bounded continuous function.")],
[#text("Show that for every interval ")#mi("{[\\frac{j}{16^m}, \\frac{j+1}{16^m}]}")#text(" with ")#mi("{m \\geq 1}")#text(" and ")#mi("{j}")#text(" integer, one has ")#tao-math("{\\left|F(\\frac{j+1}{16^m}) - F(\\frac{j}{16^m})\\right| \\geq c 4^{-m}}", block: false)#text(" for some absolute constant ")#mi("{c>0}")#text(".")],
[#text("Show that ")#mi("{F}")#text(" is not differentiable at any point ")#mi("{x \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" argue by contradiction and use the previous part of this exercise.) Note that it is ")#emph[#text("not")]#text(" enough to formally differentiate the series term by term and observe that the resulting series is divergent – why not?")]
)
]

#text("The difficulty here is that a continuous function can still contain a large amount of ")#emph[#text("oscillation")]#text(", which can lead to breakdown of differentiability. However, if one can somehow limit the amount of oscillation present, then one can often recover a fair bit of differentiability. For instance, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 53 (Monotone differentiation theorem)")]#text(" ")#metadata(none) <tao-213336d76410c85ef961>#text(" Any function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" which is monotone (either monotone non-decreasing or monotone non-increasing) is differentiable almost everywhere.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 54")]#text(" Show that every monotone function is measurable.")
]

#text("To prove this theorem, we just treat the case when ")#mi("{F}")#text(" is monotone non-decreasing, as the non-increasing case is similar (and can be deduced from the non-decreasing case by replacing ")#mi("{F}")#text(" with ")#mi("{-F}")#text(").")#linebreak()#text(" We also first focus on the case when ")#mi("{F}")#text(" is continuous, as this allows us to use the rising sun lemma. To understand the differentiability of ")#mi("{F}")#text(", we introduce the four ")#link("http://en.wikipedia.org/wiki/Dini_derivative")[#text("Dini derivatives")]#text(" of ")#mi("{F}")#text(" at ")#mi("{x}")#text(":")

#list(
[#text("The upper right derivative ")#mi("{\\overline{D^+} F(x) := \\limsup_{h \\rightarrow 0^+} \\frac{F(x+h)-F(x)}{h}}")#text(";")],
[#text("The lower right derivative ")#mi("{\\underline{D^+} F(x) := \\liminf_{h \\rightarrow 0^+} \\frac{F(x+h)-F(x)}{h}}")#text(";")],
[#text("The upper left derivative ")#mi("{\\overline{D^-} F(x) := \\limsup_{h \\rightarrow 0^-} \\frac{F(x+h)-F(x)}{h}}")#text(";")],
[#text("The lower right derivative ")#mi("{\\underline{D^-} F(x) := \\liminf_{h \\rightarrow 0^-} \\frac{F(x+h)-F(x)}{h}}")#text(".")]
)

#text("Regardless of whether ")#mi("{F}")#text(" is differentiable or not (or even whether ")#mi("{F}")#text(" is continuous or not), the four Dini derivatives always exist and take values in the extended real line ")#mi("{[-\\infty,\\infty]}")#text(". (If ")#mi("{F}")#text(" is only defined on an interval ")#mi("{[a,b]}")#text(", rather than on the endpoints, then some of the Dini derivatives may not exist at the endpoints, but this is a measure zero set and will not impact our analysis.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 55")]#text(" If ")#mi("{F}")#text(" is monotone, show that the four Dini derivatives of ")#mi("{F}")#text(" are measurable. (")#emph[#text("Hint:")]#text(" the main difficulty is to reformulate the derivatives so that ")#mi("{h}")#text(" ranges over a countable set rather than an uncountable one.)")
]

#text("A function ")#mi("{F}")#text(" is differentiable at ")#mi("{x}")#text(" precisely when the four derivatives are equal and finite: ")#metadata(none) <tao-9c844717aa8098b204b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\overline{D^+} F(x) = \\underline{D^+} F(x) = \\overline{D^-} F(x) = \\underline{D^-} F(x) \\in (-\\infty,+\\infty).")]]

#text("We also have the trivial inequalities")

#align(center)[#tao-fit-display[#mitex("\\underline{D^+} F(x) \\leq \\overline{D^+} F(x); \\quad \\underline{D^-} F(x) \\leq \\overline{D^-} F(x).")]]

#text("If ")#mi("{F}")#text(" is non-decreasing, all these quantities are non-negative, thus")

#align(center)[#tao-fit-display[#mitex("0 \\leq \\underline{D^+} F(x) \\leq \\overline{D^+} F(x); \\quad 0 \\leq \\underline{D^-} F(x) \\leq \\overline{D^-} F(x).")]]

#text("The one-sided Hardy-Littlewood maximal inequality has an analogue in this setting:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 56 (One-sided Hardy-Littlewood inequality)")]#text(" ")#metadata(none) <tao-219e83c9a745f5180e5c>#text(" Let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be a continuous monotone non-decreasing function, and let ")#mi("{\\lambda > 0}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in [a,b]: \\overline{D^+} F(x) \\geq \\lambda \\} ) \\leq \\frac{F(b)-F(a)}{\\lambda}.")]]

#text("Similarly for the other three Dini derivatives of ")#mi("{F}")#text(".")#linebreak()#text(" If ")#mi("{F}")#text(" is not assumed to be continuous, then we have the weaker inequality")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in [a,b]: \\overline{D^+} F(x) \\geq \\lambda \\} ) \\leq C\\frac{F(b)-F(a)}{\\lambda}")]]

#text("for some absolute constant ")#mi("{C>0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 57")]#text(" Note that if one naively applies the fundamental theorems of calculus, one can ")#emph[#text("formally")]#text(" see that the first part of Lemma ")#link(<tao-219e83c9a745f5180e5c>)[#text("56")]#text(" is equivalent to Lemma ")#link(<tao-72dfdc86ee288882a51a>)[#text("25")]#text(". We cannot however use this argument rigorously because we have not established the necessary fundamental theorems of calculus to do this. Nevertheless, we can borrow the ")#emph[#text("proof")]#text(" of Lemma ")#link(<tao-72dfdc86ee288882a51a>)[#text("25")]#text(" without difficulty to use here, and this is exactly what we will do.")
]

#emph[#text("Proof:")]#text(" We just prove the continuous case and leave the discontinuous case as an exercise.")#linebreak()#text(" It suffices to prove the claim for ")#mi("{\\overline{D^+} F}")#text("; by reflection (replacing ")#mi("{F(x)}")#text(" with ")#mi("{-F(-x)}")#text(", and ")#mi("{[a,b]}")#text(" with ")#mi("{[-b,-a]}")#text("), the same argument works for ")#mi("{\\overline{D^-} F}")#text(", and then this trivially implies the same inequalities for ")#mi("{\\underline{D^+} F}")#text(" and ")#mi("{\\underline{D^-} F}")#text(". By modifying ")#mi("{\\lambda}")#text(" by an epsilon, and dropping the endpoints from ")#mi("{[a,b]}")#text(" as they have measure zero, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in (a,b): \\overline{D^+} F(x) > \\lambda \\} ) \\leq \\frac{F(b)-F(a)}{\\lambda}")]]

#text("We may apply the rising sun lemma (Lemma ")#link(<tao-f1ba3850c76ef570bacf>)[#text("26")]#text(") to the continuous function ")#mi("{G(x) := F(x) - \\lambda x}")#text(". This gives us an at most countable family of intervals ")#mi("{I_n = (a_n,b_n)}")#text(" in ")#mi("{(a,b)}")#text(", such that ")#mi("{G(b_n) \\geq G(a_n)}")#text(" for each ")#mi("{n}")#text(", and such that ")#mi("{G(y) \\leq G(x)}")#text(" whenever ")#mi("{a \\leq x \\leq y\\leq b}")#text(" and ")#mi("{x}")#text(" lies outside of all of the ")#mi("{I_n}")#text(".")#linebreak()#text(" Observe that if ")#mi("{x \\in (a,b)}")#text(", and ")#mi("{G(y) \\leq G(x)}")#text(" for all ")#mi("{x \\leq y \\leq b}")#text(", then ")#mi("{\\overline{D^+} F(x) \\leq \\lambda}")#text(". Thus we see that the set ")#mi("{\\{ x \\in (a,b): \\overline{D^+} F(x) > \\lambda \\}}")#text(" is contained in the union of the ")#mi("{I_n}")#text(", and so by countable additivity")

#align(center)[#tao-fit-display[#mitex("m( \\{ x \\in (a,b): \\overline{D^+} F(x) > \\lambda \\} ) \\leq \\sum_n b_n - a_n.")]]

#text("But we can rearrange the inequality ")#mi("{G(b_n) \\leq G(a_n)}")#text(" as ")#mi("{b_n - a_n \\leq \\frac{F(b_n)-F(a_n)}{\\lambda}}")#text(". From telescoping series and the monotone nature of ")#mi("{F}")#text(" we have ")#mi("{\\sum_n F(b_n)-F(a_n) \\leq F(b)-F(a)}")#text(" (this is easiest to prove by first working with a finite subcollection of the intervals ")#mi("{(a_n,b_n)}")#text(", and then taking suprema), and the claim follows.")#linebreak()#text(" The discontinuous case is left as an exercise. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 58")]#text(" Prove Lemma ")#link(<tao-219e83c9a745f5180e5c>)[#text("56")]#text(" in the discontinuous case. (")#emph[#text("Hint:")]#text(" the rising sun lemma is no longer available, but one can use either the Vitali-type covering lemma (which will give ")#mi("{C=3}")#text(") or the Besicovitch lemma (which will give ")#mi("{C=2}")#text("), by modifying the proof of Theorem ")#link(<tao-c29c2c2f0fb17d069757>)[#text("36")]#text(".")
]

#text("Sending ")#mi("{\\lambda \\rightarrow \\infty}")#text(" in the above lemma (cf. Exercise 18 from ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("Notes 2")]#text("), and then sending ")#mi("{[a,b]}")#text(" to ")#mi("{{\\bf R}}")#text(", we conclude as a corollary that all the four Dini derivatives of a continuous monotone non-decreasing function are finite almost everywhere. So to prove Theorem ")#link(<tao-213336d76410c85ef961>)[#text("53")]#text(" for continuous monotone non-decreasing functions, it suffices to show that ")#link(<tao-9c844717aa8098b204b2>)[#text("(11)")]#text(" holds for almost every ")#mi("{x}")#text(". In view of the trivial inequalities, it suffices to show that ")#mi("{\\overline{D_+} F(x) \\leq \\underline{D_-} F(x)}")#text(" and ")#mi("{\\overline{D_-} F(x) \\leq \\underline{D_+} F(x)}")#text(" for almost every ")#mi("{x}")#text(". We will just show the first inequality, as the second follows by replacing ")#mi("{F}")#text(" with its reflection ")#mi("{x \\mapsto -F(-x)}")#text(". It will suffice to show that for every pair ")#mi("{0 < r < R}")#text(" of real numbers, the set")

#align(center)[#tao-fit-display[#mitex("E = E_{r,R} := \\{ x \\in {\\bf R}: \\overline{D_+} F(x) > R > r > \\underline{D_-} F(x) \\}")]]

#text("is a null set, since by letting ")#mi("{R, r}")#text(" range over rationals with ")#mi("{R>r > 0}")#text(" and taking countable unions, we would conclude that the set ")#mi("{\\{ x \\in {\\bf R}: \\overline{D_+} F(x) > \\underline{D_-} F(x) \\}}")#text(" is a null set (recall that the Dini derivatives are all non-negative when ")#mi("{F}")#text(" is non-decreasing), and the claim follows.")#linebreak()#text(" Clearly ")#mi("{E}")#text(" is a measurable set. To prove that it is null, we will establish the following estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 59 (")#mi("{E}")#text(" has density less than one)")]#text(" For any interval ")#mi("{[a,b]}")#text(" and any ")#mi("{0 < r < R}")#text(", one has ")#tao-math("{m( E_{r,R} \\cap [a,b] ) \\leq \\frac{r}{R} \\left|b-a\\right|}", block: false)#text(".")
]

#text("Indeed, this lemma implies that ")#mi("{E}")#text(" has no points of density, which by Exercise ")#link(<tao-e1c09fe4da6ce5311650>)[#text("48")]#text(" forces ")#mi("{E}")#text(" to be a null set.")#linebreak()#text(" ")#emph[#text("Proof:")]#text(" We begin by applying the rising sun lemma to the function ")#mi("{G(x) := r x + F(-x)}")#text(" on ")#mi("{[-b,-a]}")#text("; the large number of negative signs present here is needed in order to properly deal with the lower left Dini derivative ")#mi("{\\underline{D_-} F}")#text(". This gives an at most countable family of disjoint intervals ")#mi("{-I_n = (-b_n,-a_n)}")#text(" in ")#mi("{(-b,-a)}")#text(", such that ")#mi("{G(-a_n) \\geq G(-b_n)}")#text(" for all ")#mi("{n}")#text(", and such that ")#mi("{G(-x) \\geq G(-y)}")#text(" whenever ")#mi("{-x \\leq -y \\leq -a}")#text(" and ")#mi("{-x \\in (-b,-a)}")#text(" lies outside of all of the ")#mi("{-I_n}")#text(". Observe that if ")#mi("{x \\in (a,b)}")#text(", and ")#mi("{G(-x) \\geq G(-y)}")#text(" for all ")#mi("{-x \\leq -y \\leq -a}")#text(", then ")#mi("{\\underline{D_-} F(x) \\geq r}")#text(". Thus we see that ")#mi("{E_{r,R} \\cap (a,b)}")#text(" is contained inside the union of the intervals ")#mi("{I_n = (a_n,b_n)}")#text(". On the other hand, from the first part of Lemma ")#link(<tao-219e83c9a745f5180e5c>)[#text("56")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("m( E_{r,R} \\cap (a_n,b_n) ) \\leq \\frac{F(b_n)-F(a_n)}{R}.")]]

#text("But we can rearrange the inequality ")#mi("{G(-a_n) \\geq G(-b_n)}")#text(" as ")#mi("{F(b_n) - F(a_n) \\leq r (b_n-a_n)}")#text(". From countable additivity, one thus has")

#align(center)[#tao-fit-display[#mitex("m( E_{r,R} \\cap [a,b] ) \\leq \\frac{r}{R} \\sum_n b_n - a_n.")]]

#text("But the ")#mi("{(a_n,b_n)}")#text(" are disjoint inside ")#mi("{(a,b)}")#text(", so from countable additivity again, we have ")#mi("{\\sum_n b_n - a_n \\leq b-a}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 60")]#text(" Note if ")#mi("{F}")#text(" was not assumed to be continuous, then one would lose a factor of ")#mi("{C}")#text(" here from the second part of Lemma ")#link(<tao-219e83c9a745f5180e5c>)[#text("56")]#text(", and one would then be unable to prevent ")#mi("{\\overline{D^+} F}")#text(" from being up to ")#mi("{C}")#text(" times as large as ")#mi("{\\underline{D_-} F}")#text(". So sometimes, even when all one is seeking is a qualitative result such as differentiability, it is still important to keep track of constants. (But this is the exception rather than the rule: for a large portion of arguments in analysis, the constants are not terribly important.)")
]

#text("This concludes the proof of Theorem ")#link(<tao-213336d76410c85ef961>)[#text("53")]#text(" in the continuous monotone non-decreasing case. Now we work on removing the continuity hypothesis (which was needed in order to make the rising sun lemma work properly). If we naively try to run the density argument as we did in previous sections, then (for once) the argument does ")#emph[#text("not")]#text(" work very well, as the space of continuous monotone functions are not sufficiently dense in the space of all monotone functions in the relevant sense (which, in this case, is in the ")#link("http://en.wikipedia.org/wiki/Total_variation")[#text("total variation")]#text(" sense, which is what is needed to invoke such tools as Lemma ")#link(<tao-219e83c9a745f5180e5c>)[#text("56")]#text(".). To bridge this gap, we have to supplement the continuous monotone functions with another class of monotone functions, known as the ")#emph[#text("jump functions")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 61 (Jump function)")]#text(" A ")#emph[#text("basic jump function")]#text(" ")#mi("{J}")#text(" is a function of the form")

#align(center)[#tao-fit-display[#mitex("J(x) := \\left\\{ \\begin{array}{ll} 0 & \\text{ when } x < x_0 \\\\ \\theta & \\text{ when } x = x_0 \\\\ 1 & \\text{ when } x > x_0 \\end{array} \\right.")]]

#text("for some real numbers ")#mi("{x_0 \\in {\\bf R}}")#text(" and ")#mi("{0 \\leq \\theta \\leq 1}")#text("; we call ")#mi("{x_0}")#text(" the ")#emph[#text("point of discontinuity")]#text(" for ")#mi("{J}")#text(" and ")#mi("{\\theta}")#text(" the ")#emph[#text("fraction")]#text(". Observe that such functions are monotone non-decreasing, but have a discontinuity at one point. A ")#emph[#text("jump function")]#text(" is any absolutely convergent combination of basic jump functions, i.e. a function of the form ")#mi("{F = \\sum_n c_n J_n}")#text(", where ")#mi("{n}")#text(" ranges over an at most countable set, each ")#mi("{J_n}")#text(" is a basic jump function, and the ")#mi("{c_n}")#text(" are positivereals with ")#mi("{\\sum_n c_n < \\infty}")#text(". If there are only finitely many ")#mi("{n}")#text(" involved, we say that ")#mi("{F}")#text(" is a ")#emph[#text("piecewise constant jump function")]#text(".")
]

#text("Thus, for instance, if ")#mi("{q_1, q_2, q_3, \\ldots}")#text(" is any enumeration of the rationals, then ")#mi("{\\sum_{n=1}^\\infty 2^{-n} 1_{[q_n,+\\infty)}}")#text(" is a jump function.")#linebreak()#text(" Clearly, all jump functions are monotone non-decreasing. From the absolute convergence of the ")#mi("{c_n}")#text(" we see that every jump function is the uniform limit of piecewise constant jump functions, for instance ")#mi("{\\sum_{n=1}^\\infty c_n J_n}")#text(" is the uniform limit of ")#mi("{\\sum_{n=1}^N c_n J_n}")#text(". One consequence of this is that the points of discontinuity of a jump function ")#mi("{\\sum_{n=1}^\\infty c_n J_n}")#text(" are precisely those of the individual summands ")#mi("{c_n J_n}")#text(", i.e. of the points ")#mi("{x_n}")#text(" where each ")#mi("{J_n}")#text(" jumps.")#linebreak()#text(" The key fact is that these functions, together with the continuous monotone functions, essentially generate all monotone functions, at least in the bounded case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 62 (Continuous-singular decomposition for monotone functions)")]#text(" ")#metadata(none) <tao-03042cf8100db386818c>#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a monotone non-decreasing function.")

#enum(start: 1, 
[#text("The only discontinuities of ")#mi("{F}")#text(" are jump discontinuities. More precisely, if ")#mi("{x}")#text(" is a point where ")#mi("{F}")#text(" is discontinuous, then the limits ")#mi("{\\lim_{y \\rightarrow x^-} F(y)}")#text(" and ")#mi("{\\lim_{y \\rightarrow x^+} F(y)}")#text(" both exist, but are unequal, with ")#mi("{\\lim_{y \\rightarrow x^-} F(y) <\\lim_{y \\rightarrow x^+} F(y)}")#text(".")],
[#text("There are at most countably many discontinuities of ")#mi("{F}")#text(".")],
[#text("If ")#mi("{F}")#text(" is bounded, then ")#mi("{F}")#text(" can be expressed as the sum of a continuous monotone non-decreasing function ")#mi("{F_c}")#text(" and a jump function ")#mi("{F_{pp}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 63")]#text(" This decomposition is part of the more general ")#link("http://en.wikipedia.org/wiki/Lebesgue's_decomposition_theorem")[#text("Lebesgue decomposition")]#text(", which we will discuss ")#link("https://terrytao.wordpress.com/2009/01/04/245b-notes-1-signed-measures-and-the-radon-nikodym-lebesgue-theorem/")[#text("later in this course")]#text(".")
]

#emph[#text("Proof:")]#text(" By monotonicity, the limits ")#mi("{F_-(x) := \\lim_{y \\rightarrow x^-} F(y)}")#text(" and ")#mi("{F^+(x) := \\lim_{y \\rightarrow x^+} F(y)}")#text(" always exist, with ")#mi("{F_-(x) \\leq F(x) \\leq F_+(x)}")#text(" for all ")#mi("{x}")#text(". This gives 1.")#linebreak()#text(" By 1., whenever there is a discontinuity ")#mi("{x}")#text(" of ")#mi("{F}")#text(", there is at least one rational number ")#mi("{q_x}")#text(" strictly between ")#mi("{F_-(x)}")#text(" and ")#mi("{F_+(x)}")#text(", and from monotonicity, each rational number can be assigned to at most one discontinuity. This gives 2.")#linebreak()#text(" Now we prove 3. Let ")#mi("{A}")#text(" be the set of discontinuities of ")#mi("{F}")#text(", thus ")#mi("{A}")#text(" is at most countable. For each ")#mi("{x \\in A}")#text(", we define the jump ")#mi("{c_x := F_+(x) - F_-(x) > 0}")#text(", and the fraction ")#mi("{\\theta_x := \\frac{F(x)-F_-(x)}{F_+(x)-F_-(x)} \\in [0,1]}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("F_+(x) = F_-(x) + c_x \\text{ and } F(x) = F_-(x) + \\theta_x c_x.")]]

#text("Note that ")#mi("{c_x}")#text(" is the measure of the interval ")#mi("{(F_-(x),F_+(x))}")#text(". By monotonicity, these intervals are disjoint; by the boundedness of ")#mi("{F}")#text(", their union is bounded. By countable additivity, we thus have ")#mi("{\\sum_{x \\in A} c_x < \\infty}")#text(", and so if we let ")#mi("{J_x}")#text(" be the basic jump function with point of discontinuity ")#mi("{x}")#text(" and fraction ")#mi("{\\theta_x}")#text(", then the function")

#align(center)[#tao-fit-display[#mitex("F_{pp} := \\sum_{x \\in A} c_x J_x")]]

#text("is a jump function.")#linebreak()#text(" As discussed previously, ")#mi("{F}")#text(" is discontinuous only at ")#mi("{A}")#text(", and for each ")#mi("{x \\in A}")#text(" one easily checks that")

#align(center)[#tao-fit-display[#mitex("(F_{pp})_+(x) = (F_{pp})_-(x) + c_x \\text{ and } F_{pp}(x) = (F_{pp})_-(x) + \\theta_x c_x")]]

#text("where ")#mi("{(F_{pp})_-(x) := \\lim_{y \\rightarrow x^-} F_{pp}(y)}")#text(", and ")#mi("{(F_{pp})_+(x) := \\lim_{y\\rightarrow x^+} F_{pp}(y)}")#text(". We thus see that the difference ")#mi("{F_c := F-F_{pp}}")#text(" is continuous. The only remaining task is to verify that ")#mi("{F_c}")#text(" is monotone non-decreasing. By continuity it suffices to verify this away from the (countably many) jump discontinuities, thus we need")

#align(center)[#tao-fit-display[#mitex("F_{pp}(b)-F_{pp}(a) \\leq F(b)-F(a)")]]

#text("for all ")#mi("{a < b}")#text(" that are not jump discontinuities. But the left-hand side can be rewritten as ")#mi("{\\sum_{x \\in A \\cap [a,b]} c_x}")#text(", while the right-hand side is ")#mi("{F_-(b)-+ F_+(a)}")#text(". As each ")#mi("{c_x}")#text(" is the measure of the interval ")#mi("{(F_-(x), F_+(x))}")#text(", and these intervals for ")#mi("{x \\in A \\cap [a,b]}")#text(" are disjoint and lie in ")#mi("{(F_+(a),F_-(b))}")#text(", the claim follows from countable additivity. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 64")]#text(" Show that the decomposition of a bounded monotone non-decreasing function ")#mi("{F}")#text(" into continuous ")#mi("{F_c}")#text(" and jump components ")#mi("{F_{pp}}")#text(" given by the above lemma is unique.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 65")]#text(" Find a suitable generalisation of the notion of a jump function that allows one to extend the above decomposition to unbounded monotone functions, and then prove this extension. (")#emph[#text("Hint:")]#text(" the notion to shoot for here is that of a “locally jump function”.)")
]

#text("Now we can finish the proof of Theorem ")#link(<tao-213336d76410c85ef961>)[#text("53")]#text(". As noted previously, it suffices to prove the claim for monotone non-decreasing functions. As differentiability is a local condition, we can easily reduce to the case of ")#emph[#text("bounded")]#text(" monotone non-decreasing functions, since to test differentiability of a monotone non-decreasing function ")#mi("{F}")#text(" in any compact interval ")#mi("{[a,b]}")#text(" we may replace ")#mi("{F}")#text(" by the bounded monotone non-decreasing function ")#mi("{\\max( \\min(F, F(b)), F(a))}")#text(" with no change in the differentiability in ")#mi("{[a,b]}")#text(" (except perhaps at the endpoints ")#mi("{a,b}")#text(", but these form a set of measure zero). As we have already proven the claim for continuous functions, it suffices by Lemma ")#link(<tao-03042cf8100db386818c>)[#text("62")]#text(" (and linearity of the derivative) to verify the claim for jump functions.")#linebreak()#text(" Now, finally, we are able to use the density argument, using the piecewise constant jump functions as the dense subclass, and using the second part of Lemma ")#link(<tao-219e83c9a745f5180e5c>)[#text("56")]#text(" for the quantitative estimate; fortunately for us, the density argument does not particularly care that there is a loss of a constant factor in this estimate.")#linebreak()#text(" For piecewise constant jump functions, the claim is clear (indeed, the derivative exists and is zero outside of finitely many discontinuities). Now we run the density argument. Let ")#mi("{F}")#text(" be a bounded jump function, and let ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{\\lambda > 0}")#text(" be arbitrary. As every jump function is the uniform limit of piecewise constant jump functions, we can find a piecewise constant jump function ")#mi("{F_\\varepsilon}")#text(" such that ")#tao-math("{\\left|F(x)-F_\\varepsilon(x)\\right| \\leq \\varepsilon}", block: false)#text(" for all ")#mi("{x}")#text(". Indeed, by taking ")#mi("{F_\\varepsilon}")#text(" to be a partial sum of the basic jump functions that make up ")#mi("{F}")#text(", we can ensure that ")#mi("{F-F_\\varepsilon}")#text(" is also a monotone non-decreasing function. Applying the second part of Lemma ")#link(<tao-219e83c9a745f5180e5c>)[#text("56")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("m(\\{ x \\in {\\bf R}: \\overline{D^+} (F-F_\\varepsilon)(x) \\geq \\lambda \\}) \\leq \\frac{2C\\varepsilon}{\\lambda}")]]

#text("for some absolute constant ")#mi("{C}")#text(", and similarly for the other four Dini derivatives. Thus, outside of a set of measure at most ")#mi("{8C\\varepsilon/\\lambda}")#text(", all of the Dini derivatives of ")#mi("{F-F_\\varepsilon}")#text(" are less than ")#mi("{\\lambda}")#text(". Since ")#mi("{F^{\\prime}_\\varepsilon}")#text(" is almost everywhere differentiable, we conclude that outside of a set of measure at most ")#mi("{8C\\varepsilon/\\lambda}")#text(", all the Dini derivatives of ")#mi("{F(x)}")#text(" lie within ")#mi("{\\lambda}")#text(" of ")#mi("{F^{\\prime}_\\varepsilon(x)}")#text(", and in particular are finite and lie within ")#mi("{2\\lambda}")#text(" of each other. Sending ")#mi("{\\varepsilon}")#text(" to zero (holding ")#mi("{\\lambda}")#text(" fixed), we conclude that for almost every ")#mi("{x}")#text(", the Dini derivatives of ")#mi("{F}")#text(" are finite and lie within ")#mi("{2\\lambda}")#text(" of each other. If we then send ")#mi("{\\lambda}")#text(" to zero, we see that for almost every ")#mi("{x}")#text(", the Dini derivatives of ")#mi("{F}")#text(" agree with each other and are finite, and the claim follows. This concludes the proof of Theorem ")#link(<tao-213336d76410c85ef961>)[#text("53")]#text(".")#linebreak()#text(" Just as the integration theory of unsigned functions can be used to develop the integration theory of the absolutely convergent functions (see ")#link("https://terrytao.wordpress.com/2010/09/19/245a-notes-2-the-lebesgue-integral/")[#text("Notes 2")]#text("), the differentiation theory of monotone functions can be used to develop a parallel differentiation theory for the class of functions of ")#link("http://en.wikipedia.org/wiki/Bounded_variation")[#text("bounded variation")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 66 (Bounded variation)")]#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a function. The ")#emph[#text("total variation")]#text(" ")#tao-math("{\\left\\|F\\right\\|_{TV({\\bf R})}}", block: false)#text(" (or ")#tao-math("{\\left\\|F\\right\\|_{TV}}", block: false)#text(" for short) of ")#mi("{F}")#text(" is defined to be the supremum")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{TV({\\bf R})} := \\sup_{x_0 < \\ldots < x_n} \\sum_{i=1}^n \\left|F(x_i) - F(x_{i-1})\\right|", block: true)]]

#text("where the supremum ranges over all finite increasing sequences ")#mi("{x_0,\\ldots,x_n}")#text(" of real numbers with ")#mi("{n \\geq 0}")#text("; this is a quantity in ")#mi("{[0,+\\infty]}")#text(". We say that ")#mi("{F}")#text(" has ")#emph[#text("bounded variation")]#text(" (on ")#mi("{{\\bf R}}")#text(") if ")#tao-math("{\\left\\|F\\right\\|_{TV({\\bf R})}}", block: false)#text(" is finite. (In this case, ")#tao-math("{\\left\\|F\\right\\|_{TV({\\bf R})}}", block: false)#text(" is often written as ")#tao-math("{\\left\\|F\\right\\|_{BV({\\bf R})}}", block: false)#text(" or just ")#tao-math("{\\left\\|F\\right\\|_{BV}}", block: false)#text(".)")#linebreak()#text(" Given any interval ")#mi("{[a,b]}")#text(", we define the total variation ")#tao-math("{\\left\\|F\\right\\|_{TV([a,b])}}", block: false)#text(" of ")#mi("{F}")#text(" on ")#mi("{[a,b]}")#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{TV([a,b])} := \\sup_{a \\leq x_0 < \\ldots < x_n \\leq b} \\sum_{i=1}^n \\left|F(x_i) - F(x_{i-1})\\right|;", block: true)]]

#text("thus the definition is the same, but the points ")#mi("{x_0,\\ldots,x_n}")#text(" are restricted to lie in ")#mi("{[a,b]}")#text(". Thus for instance ")#tao-math("{\\left\\|F\\right\\|_{TV({\\bf R})} = \\sup_{N \\rightarrow \\infty} \\left\\|F\\right\\|_{TV([-N,N])}}", block: false)#text(". We say that a function ")#mi("{F}")#text(" has ")#emph[#text("bounded variation")]#text(" on ")#mi("{[a,b]}")#text(" if ")#tao-math("{\\left\\|F\\right\\|_{BV([a,b])}}", block: false)#text(" is finite.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 67")]#text(" ")#metadata(none) <tao-ab0ba264b1147dd8ee71>#text(" If ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a monotone function, show that ")#tao-math("{\\left\\|F\\right\\|_{TV([a,b])} = \\left|F(b)-F(a)\\right|}", block: false)#text(" for any interval ")#mi("{[a,b]}")#text(", and that ")#mi("{F}")#text(" has bounded variation on ")#mi("{{\\bf R}}")#text(" if and only if it is bounded.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 68")]#text(" ")#metadata(none) <tao-d37a41e25fade34a56f0>#text(" For any functions ")#mi("{F, G: {\\bf R} \\rightarrow {\\bf R}}")#text(", establish the triangle property ")#tao-math("{\\left\\|F+G\\right\\|_{TV({\\bf R})} \\leq \\left\\|F\\right\\|_{TV({\\bf R})} + \\left\\|G\\right\\|_{TV({\\bf R})}}", block: false)#text(" and the homogeneity property ")#tao-math("{\\left\\|cF\\right\\|_{TV({\\bf R})} = \\left|c\\right| \\left\\|F\\right\\|_{TV({\\bf R})}}", block: false)#text(" for any ")#mi("{c \\in {\\bf R}}")#text(". Also show that ")#tao-math("{\\left\\|F\\right\\|_{TV}=0}", block: false)#text(" if and only if ")#mi("{F}")#text(" is constant.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 69")]#text(" If ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a function, show that ")#tao-math("{\\left\\|F\\right\\|_{TV([a,b])} + \\left\\|F\\right\\|_{TV([b,c])} = \\left\\|F\\right\\|_{TV([a,c])}}", block: false)#text(" whenever ")#mi("{a \\leq b \\leq c}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 70")]

#enum(start: 1, 
[#text("Show that every function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" of bounded variation is bounded, and that the limits ")#mi("{\\lim_{x \\rightarrow +\\infty} f(x)}")#text(" and ")#mi("{\\lim_{x \\rightarrow -\\infty} f(x)}")#text(", are well-defined.")],
[#text("Give a counterexample of a bounded, continuous, compactly supported function ")#mi("{f}")#text(" that is not of bounded variation.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 71")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be an absolutely integrable function, and let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be the indefinite integral ")#mi("{F(x) := \\int_{[-\\infty,x]} f(x)}")#text(". Show that ")#mi("{F}")#text(" is of bounded variation, and that ")#tao-math("{\\left\\|F\\right\\|_{TV({\\bf R})} = \\left\\|f\\right\\|_{L^1({\\bf R})}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" the upper bound ")#tao-math("{\\left\\|F\\right\\|_{TV({\\bf R})} \\leq \\left\\|f\\right\\|_{L^1({\\bf R})}}", block: false)#text(" is relatively easy to establish. To obtain the lower bound, use the density argument.)")
]

#text("Much as an absolutely integrable function can be expressed as the difference of its positive and negative parts, a bounded variation function can be expressed as the difference of two bounded monotone functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 72")]#text(" ")#metadata(none) <tao-6156d4791b9dc4f63995>#text(" A function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is of bounded variation if and only if it is the difference of two bounded monotone functions.")
]

#emph[#text("Proof:")]#text(" It is clear from Exercises ")#link(<tao-ab0ba264b1147dd8ee71>)[#text("67")]#text(", ")#link(<tao-d37a41e25fade34a56f0>)[#text("68")]#text(" that the difference of two bounded monotone functions is bounded. Now define the ")#emph[#text("positive variation")]#text(" ")#mi("{F^+: {\\bf R} \\rightarrow {\\bf R}}")#text(" of ")#mi("{F}")#text(" by the formula ")#metadata(none) <tao-5aef96240bca5582e6fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("F^+(x) := \\sup_{x_0 < \\ldots < x_n \\leq x} \\sum_{i=1}^n \\max(F(x_{i}) - F(x_{i-1}),0).")]]

#text("It is clear from construction that this is a monotone increasing function, taking values between ")#mi("{0}")#text(" and ")#tao-math("{\\left\\|F\\right\\|_{TV({\\bf R})}}", block: false)#text(", and is thus bounded. To conclude the proposition, it suffices to (by writing ")#mi("{F = F_+ - (F_+-F_-)}")#text(" to show that ")#mi("{F_+-F}")#text(" is non-decreasing, or in other words to show that")

#align(center)[#tao-fit-display[#mitex("F^+(b) \\geq F^+(a) + F(b)-F(a).")]]

#text("If ")#mi("{F(b)-F(a)}")#text(" is negative then this is clear from the monotone non-decreasing nature of ")#mi("{F^+}")#text(", so assume that ")#mi("{F(b)-F(a) \\geq 0}")#text(". But then the claim follows because any sequence of real numbers ")#mi("{x_0 < \\ldots < x_n \\leq a}")#text(" can be extended by one or two elements by adding ")#mi("{a}")#text(" and ")#mi("{b}")#text(", thus increasing the sum ")#mi("{\\sup_{x_0 < \\ldots < x_n} \\sum_{i=1}^n \\max(F(x_i) - F(x_{i-1}),0)}")#text(" by at least ")#mi("{F(b)-F(a)}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 73")]#text(" Let ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" be of bounded variation. Define the positive variation ")#mi("{F^+}")#text(" by ")#link(<tao-5aef96240bca5582e6fd>)[#text("(12)")]#text(", and the negative variation ")#mi("{F^-}")#text(" by")

#align(center)[#tao-fit-display[#mitex("F^-(x) := \\sup_{x_0 < \\ldots < x_n \\leq x} \\sum_{i=1}^n \\max(-F(x_{i}) + F(x_{i-i}),0).")]]

#text("Establish the identities")

#tao-aligned(keep: true)[


#tao-math("F(x)  & = F(-\\infty) + F^+(x) - F^-(x),", block: true)



#tao-math("\\left\\|F\\right\\|_{TV[a,b]}  & = F^+(b)-F^+(a) + F^-(b)-F^-(a),", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{TV} = F^+(+\\infty) + F^-(+\\infty)", block: true)]]

#text("for every interval ")#mi("{[a,b]}")#text(", where ")#mi("{F(-\\infty) := \\lim_{x \\rightarrow -\\infty} F(x)}")#text(", ")#mi("{F^+(+\\infty) := \\lim_{x \\rightarrow +\\infty} F^+(x)}")#text(", and ")#mi("{F^-(+\\infty) := \\lim_{x \\rightarrow +\\infty} F^-(x)}")#text(". (")#emph[#text("Hint:")]#text(" The main difficulty comes from the fact that a partition ")#mi("{x_0 < \\ldots < x_n \\leq x}")#text(" that is good for ")#mi("{F^+}")#text(" need not be good for ")#mi("{F^-}")#text(", and vice versa. However, this can be fixed by taking a good partition for ")#mi("{F^+}")#text(" and a good partition for ")#mi("{F^-}")#text(" and combining them together into a common refinement.)")
]

#text("From Proposition ")#link(<tao-6156d4791b9dc4f63995>)[#text("72")]#text(" and Theorem ")#link(<tao-213336d76410c85ef961>)[#text("53")]#text(" we immediately obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 74 (BV differentiation theorem)")]#text(" Every bounded variation function is differentiable almost everywhere.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 75")]#text(" ")#metadata(none) <tao-b598eb41f0272ee62da9>#text(" Call a function ")#emph[#text("locally of bounded variation")]#text(" if it is of bounded variation on every compact interval ")#mi("{[a,b]}")#text(". Show that every function that is locally of bounded variation is differentiable almost everywhere.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 76 (Lipschitz differentiation theorem, one-dimensional case)")]#text(" ")#metadata(none) <tao-8872c9951989fdb487ba>#text(" A function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is said to be ")#emph[#text("Lipschitz continuous")]#text(" if there exists a constant ")#mi("{C >0}")#text(" such that ")#tao-math("{\\left|f(x)-f(y)\\right| \\leq C\\left|x-y\\right|}", block: false)#text(" for all ")#mi("{x,y \\in {\\bf R}}")#text("; the smallest ")#mi("{C}")#text(" with this property is known as the ")#emph[#text("Lipschitz constant")]#text(" of ")#mi("{f}")#text(". Show that every Lipschitz continuous function ")#mi("{F}")#text(" is locally of bounded variation, and hence differentiable almost everywhere. Furthermore, show that the derivative ")#mi("{F^{\\prime}}")#text(", when it exists, is bounded in magnitude by the Lipschitz constant of ")#mi("{F}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 77")]#text(" The same result is true in higher dimensions, and is known as the ")#link("http://en.wikipedia.org/wiki/Rademacher%27s_theorem")[#text("Radamacher differentiation theorem")]#text(", but we will defer the proof of this theorem to subsequent notes, when we have the powerful tool of the ")#link("http://en.wikipedia.org/wiki/Fubini's_theorem")[#text("Fubini-Tonelli theorem")]#text(" available, that is particularly useful for deducing higher-dimensional results in analysis from lower-dimensional ones.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 78")]#text(" A function ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is said to be ")#link("http://en.wikipedia.org/wiki/Convex_function")[#text("convex")]#text(" if one has ")#mi("{f((1-t) x + ty) \\leq (1-t) f(x) + t f(y)}")#text(" for all ")#mi("{x < y}")#text(" and ")#mi("{0 < t < 1}")#text(". Show that if ")#mi("{f}")#text(" is convex, then it is continuous and almost everywhere differentiable, and its derivative ")#mi("{f^{\\prime}}")#text(" is equal almost everywhere to a monotone non-decreasing function, and so is itself almost everywhere differentiable. (")#emph[#text("Hint:")]#text(" Drawing the graph of ")#mi("{f}")#text(", together with a number of chords and tangent lines, is likely to be very helpful in providing visual intuition.) Thus we see that in some sense, convex functions are “almost everywhere twice differentiable”. Similar claims also hold for concave functions, of course.")
]

#heading(level: 1)[#strong[#text(" — 4. The second fundamental theorem of calculus — ")]]

#text("We are now finally ready to attack the second fundamental theorem of calculus in the cases where ")#mi("{F}")#text(" is not assumed to be continuously differentiable. We begin with the case when ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" is monotone non-decreasing. From Theorem ")#link(<tao-213336d76410c85ef961>)[#text("53")]#text(" (extending ")#mi("{F}")#text(" to the rest of the real line if needed), this implies that ")#mi("{F}")#text(" is differentiable almost everywhere in ")#mi("{[a,b]}")#text(", so ")#mi("{F^{\\prime}}")#text(" is defined a.e.; from monotonicity we see that ")#mi("{F^{\\prime}}")#text(" is non-negative whenever it is defined. Also, an easy modification of Exercise ")#link(<tao-e1dd865cbf28ee943a8b>)[#text("2")]#text(" shows that ")#mi("{F^{\\prime}}")#text(" is measurable.")#linebreak()#text(" One half of the second fundamental theorem is easy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 79 (Upper bound for second fundamental theorem)")]#text(" ")#metadata(none) <tao-faa7aab323de5d9213d1>#text(" Let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be monotone non-decreasing (so that, as discussed above, ")#mi("{F^{\\prime}}")#text(" is defined almost everywhere, is unsigned, and is measurable). Then")

#align(center)[#tao-fit-display[#mitex("\\int_{[a,b]} F^{\\prime}(x)\\ dx \\leq F(b)-F(a).")]]

#text("In particular, ")#mi("{F^{\\prime}}")#text(" is absolutely integrable.")
]

#emph[#text("Proof:")]#text(" It is convenient to extend ")#mi("{F}")#text(" to all of ")#mi("{{\\bf R}}")#text(" by declaring ")#mi("{F(x) := F(b)}")#text(" for ")#mi("{x>b}")#text(" and ")#mi("{F(x) := F(a)}")#text(" for ")#mi("{x<a}")#text(", then ")#mi("{F}")#text(" is now a bounded monotone function on ")#mi("{{\\bf R}}")#text(", and ")#mi("{F^{\\prime}}")#text(" vanishes outside of ")#mi("{[a,b]}")#text(". As ")#mi("{F}")#text(" is almost everywhere differentiable, the Newton quotients")

#align(center)[#tao-fit-display[#mitex("f_n(x) := \\frac{F(x+1/n) - F(x)}{1/n}")]]

#text("converge pointwise almost everywhere to ")#mi("{F^{\\prime}}")#text(". Applying Fatou’s lemma (Corollary 16 of ")#link("https://terrytao.wordpress.com/2010/09/25/245a-notes-3-integration-on-abstract-measure-spaces-and-the-convergence-theorems/")[#text("Notes 3")]#text("), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{[a,b]} F^{\\prime}(x)\\ dx \\leq \\liminf_{n \\rightarrow \\infty} \\int_{[a,b]} \\frac{F(x+1/n) - F(x)}{1/n}\\ dx.")]]

#text("The right-hand side can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\liminf_{n \\rightarrow \\infty} n (\\int_{[a+1/n,b+1/n]} F(y)\\ dy - \\int_{[a,b]} F(x)\\ dx)")]]

#text("which can be rearranged further as")

#align(center)[#tao-fit-display[#mitex("\\liminf_{n \\rightarrow \\infty} n (\\int_{[b,b+1/n]} F(x)\\ dx - \\int_{[a,a+1/n]} F(x)\\ dx).")]]

#text("Since ")#mi("{F}")#text(" is equal to ")#mi("{F(b)}")#text(" for the first integral and is at least ")#mi("{F(a)}")#text(" for the second integral, this expression is at most")

#align(center)[#tao-fit-display[#mitex("\\leq \\liminf_{n \\rightarrow \\infty} n (F(b)/n - F(a)/n) = F(b)-F(a)")]]

#text("and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 80")]#text(" ")#metadata(none) <tao-540dc93e34853e49267b>#text(" Show that any function of bounded variation has an (almost everywhere defined) derivative that is absolutely integrable.")
]

#text("In the Lipschitz case, one can do better:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 81 (Second fundamental theorem for Lipschitz functions)")]#text(" Let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be Lipschitz continuous. Show that ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx = F(b)-F(a)}")#text(". (")#emph[#text("Hint:")]#text(" Argue as in the proof of Proposition ")#link(<tao-faa7aab323de5d9213d1>)[#text("79")]#text(", but use the dominated convergence theorem in place of Fatou’s lemma.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 82 (Integration by parts formula)")]#text(" Let ")#mi("{F, G: [a,b] \\rightarrow {\\bf R}}")#text(" be Lipschitz continuous functions. Show that")

#tao-aligned(keep: true)[


#tao-math("\\int_{[a,b]} F^{\\prime}(x) G(x)\\ dx  & = F(b) G(b)-F(a) G(a)", block: true)



#tao-math(" & - \\int_{[a,b]} F(x) G^{\\prime}(x)\\ dx.", block: true)
]

#text("(")#emph[#text("Hint:")]#text(" first show that the product of two Lipschitz continuous functions on ")#mi("{[a,b]}")#text(" is again Lipschitz continuous.)")
]

#text("Now we return to the monotone case. Inspired by the Lipschitz case, one may hope to recover equality in Proposition ")#link(<tao-faa7aab323de5d9213d1>)[#text("79")]#text(" for such functions ")#mi("{F}")#text(". However, there is an important obstruction to this, which is that all the variation of ")#mi("{F}")#text(" may be concentrated in a set of measure zero, and thus undetectable by the Lebesgue integral of ")#mi("{F^{\\prime}}")#text(". This is most obvious in the case of a discontinuous monotone function, such as the (appropriately named) ")#link("http://en.wikipedia.org/wiki/Heaviside_step_function")[#text("Heaviside function")]#text(" ")#mi("{F := 1_{[0,+\\infty)}}")#text("; it is clear that ")#mi("{F^{\\prime}}")#text(" vanishes almost everywhere, but ")#mi("{F(b)-F(a)}")#text(" is not equal to ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx}")#text(" if ")#mi("{b}")#text(" and ")#mi("{a}")#text(" lie on opposite sides of the discontinuity at ")#mi("{0}")#text(". In fact, the same problem arises for all jump functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 83")]#text(" Show that if ")#mi("{F}")#text(" is a jump function, then ")#mi("{F^{\\prime}}")#text(" vanishes almost everywhere. (")#emph[#text("Hint:")]#text(" use the density argument, starting from piecewise constant jump functions and using Proposition ")#link(<tao-faa7aab323de5d9213d1>)[#text("79")]#text(" as the quantitative estimate.)")
]

#text("One may hope that jump functions – in which all the fluctuation is concentrated in a countable set – are the only obstruction to the second fundamental theorem of calculus holding for monotone functions, and that as long as one restricts attention to ")#emph[#text("continuous")]#text(" monotone functions, that one can recover the second fundamental theorem. However, this is still not true, because it is possible for all the fluctuation to now be concentrated, not in a countable collection of jump discontinuities, but instead in an uncountable set of zero measure, such as the middle thirds Cantor set (Exercise 10 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text("). This can be illustrated by the key counterexample of the ")#link("http://en.wikipedia.org/wiki/Cantor_function")[#text("Cantor function")]#text(", also known as the ")#emph[#text("Devil’s staircase function")]#text(". The construction of this function is detailed in the exercise below.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 84 (Cantor function)")]#text(" ")#metadata(none) <tao-c33915525e96fcd195f6>#text(" Define the functions ")#mi("{F_0, F_1, F_2, \\ldots: [0,1] \\rightarrow {\\bf R}}")#text(" recursively as follows:")

#enum(start: 1, 
[#text("Set ")#mi("{F_0(x) := x}")#text(" for all ")#mi("{x \\in [0,1]}")#text(".")],
[#text("For each ")#mi("{n=1,2,\\ldots}")#text(" in turn, define")

#align(center)[#tao-fit-display[#mitex("F_n(x) := \\left\\{ \\begin{array}{ll} \\frac{1}{2} F_{n-1}(3x) & \\text{ if } x \\in [0,1/3]; \\\\ \\frac{1}{2} & \\text{ if } x \\in (1/3,2/3); \\\\ \\frac{1}{2} + \\frac{1}{2} F_{n-1}(3x-2) & \\text{ if } x \\in [2/3,1] \\end{array} \\right.")]]]
)

#enum(start: 1, 
[#text("Graph ")#mi("{F_0}")#text(", ")#mi("{F_1}")#text(", ")#mi("{F_2}")#text(", and ")#mi("{F_3}")#text(" (preferably on a single graph).")],
[#text("Show that for each ")#mi("{n=0,1,\\ldots}")#text(", ")#mi("{F_n}")#text(" is a continuous monotone non-decreasing function with ")#mi("{F_n(0)=0}")#text(" and ")#mi("{F_n(1)=1}")#text(". (")#emph[#text("Hint:")]#text(" induct on ")#mi("{n}")#text(".)")],
[#text("Show that for each ")#mi("{n=0,1,\\ldots}")#text(", one has ")#tao-math("{\\left|F_{n+1}(x) - F_n(x)\\right| \\leq 2^{-n}}", block: false)#text(" for each ")#mi("{x \\in [0,1]}")#text(". Conclude that the ")#mi("{F_n}")#text(" converge uniformly to a limit ")#mi("{F: [0,1] \\rightarrow {\\bf R}}")#text(". This limit is known as the ")#emph[#text("Cantor function")]#text(".")],
[#text("Show that the Cantor function ")#mi("{F}")#text(" is continuous and monotone non-decreasing, with ")#mi("{F(0)=0}")#text(" and ")#mi("{F(1)=1}")#text(".")],
[#text("Show that if ")#mi("{x \\in [0,1]}")#text(" lies outside the middle thirds Cantor set (Exercise 10 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text("), then ")#mi("{F}")#text(" is constant in a neighbourhood of ")#mi("{x}")#text(", and in particular ")#mi("{F^{\\prime}(x)=0}")#text(". Conclude that ")#mi("{\\int_{[0,1]} F^{\\prime}(x)\\ dx = 0 \\neq 1 = F(1)-F(0)}")#text(", so that the second fundamental theorem of calculus fails for this function.")],
[#text("Show that ")#mi("{F( \\sum_{n=1}^\\infty a_n 3^{-n} ) = \\sum_{n=1}^\\infty \\frac{a_n}{2} 2^{-n}}")#text(" for any digits ")#mi("{a_1,a_2,\\ldots \\in \\{0,2\\}}")#text(". Thus the Cantor function, in some sense, converts base three expansions to base two expansions.")],
[#text("Let ")#mi("{I = [ \\sum_{i=1}^n \\frac{a_i}{3^i}, \\sum_{i=1}^n \\frac{a_i}{3^i} + \\frac{1}{3^n}]}")#text(" be one of the intervals used in the ")#mi("{n^{th}}")#text(" cover ")#mi("{I_n}")#text(" of ")#mi("{C}")#text(" (see Exercise 10 from ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text("), thus ")#mi("{n \\geq 0}")#text(" and ")#mi("{a_1,\\ldots,a_n \\in \\{0,2\\}}")#text(". Show that ")#mi("{I}")#text(" is an interval of length ")#mi("{3^{-n}}")#text(", but ")#mi("{F(I)}")#text(" is an interval of length ")#mi("{2^{-n}}")#text(".")],
[#text("Show that ")#mi("{F}")#text(" is not differentiable at any element of the Cantor set ")#mi("{C}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 85")]#text(" This example shows that the classical derivative ")#mi("{F^{\\prime}(x) := \\lim_{h \\rightarrow 0; h \\neq 0} \\frac{F(x+h)-F(x)}{h}}")#text(" of a function has some defects; it cannot “see” some of the variation of a continuous monotone function such as the Cantor function. ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("Much later in this series")]#text(", we will rectify this by introducing the concept of the ")#link("http://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivative")]#text(" of a function, which despite the name, is more able than the strong derivative to detect this type of singular variation behaviour. (We will also encounter the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Stieltjes_integral")[#text("Riemann-Stieltjes integral")]#text(" in later notes, which is another (closely related) way to capture all of the variation of a monotone function, and which is related to the classical derivative via the ")#link("http://en.wikipedia.org/wiki/Lebesgue's_decomposition_theorem")[#text("Lebesgue-Radon-Nikodym theorem")]#text(".)")
]

#text("In view of this counterexample, we see that we need to add an additional hypothesis to the continuous monotone non-decreasing function ")#mi("{F}")#text(" before we can recover the second fundamental theorem. One such hypothesis is ")#link("http://en.wikipedia.org/wiki/Absolute_continuity")[#text("absolute continuity")]#text(". To motivate this definition, let us recall two existing definitions:")

#list(
[#text("A function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is ")#emph[#text("continuous")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(" and ")#mi("{x_0 \\in {\\bf R}}")#text(", there exists a ")#mi("{\\delta > 0}")#text(" such that ")#tao-math("{\\left|F(b)-F(a)\\right| \\leq \\varepsilon}", block: false)#text(" whenever ")#mi("{(a,b)}")#text(" is an interval of length at most ")#mi("{\\delta}")#text(" that contains ")#mi("{x_0}")#text(".")],
[#text("A function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is ")#emph[#text("uniformly continuous")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(", there exists a ")#mi("{\\delta > 0}")#text(" such that ")#tao-math("{\\left|F(b)-F(a)\\right| \\leq \\varepsilon}", block: false)#text(" whenever ")#mi("{(a,b)}")#text(" is an interval of length at most ")#mi("{\\delta}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 86")]#text(" A function ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is said to be ")#emph[#text("absolutely continuous")]#text(" if, for every ")#mi("{\\varepsilon > 0}")#text(", there exists a ")#mi("{\\delta > 0}")#text(" such that ")#tao-math("{\\sum_{j=1}^n \\left|F(b_j)-F(a_j)\\right| \\leq \\varepsilon}", block: false)#text(" whenever ")#mi("{(a_1,b_1),\\ldots,(a_n,b_n)}")#text(" is a finite collection of disjoint intervals of total length ")#mi("{\\sum_{j=1}^n b_j - a_j}")#text(" at most ")#mi("{\\delta}")#text(".")#linebreak()#text(" We define absolute continuity for a function ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" defined on an interval ")#mi("{[a,b]}")#text(" similarly, with the only difference being that the intervals ")#mi("{[a_j,b_j]}")#text(" are of course now required to lie in the domain ")#mi("{[a,b]}")#text(" of ")#mi("{F}")#text(".")
]

#text("The following exercise places absolute continuity in relation to other regularity properties:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 87")]#text(" ")#metadata(none) <tao-c45bf610333ea3e672cb>

#enum(start: 1, 
[#text("Show that every absolutely continuous function is uniformly continuous and therefore continuous.")],
[#text("Show that every absolutely continuous function is of bounded variation on every compact interval ")#mi("{[a,b]}")#text(". (")#emph[#text("Hint:")]#text(" first show this is true for any sufficiently small interval.) In particular (by Exercise ")#link(<tao-b598eb41f0272ee62da9>)[#text("75")]#text("), absolutely continuous functions are differentiable almost everywhere.")],
[#text("Show that every Lipschitz continuous function is absolutely continuous.")],
[#text("Show that the function ")#mi("{x \\mapsto \\sqrt{x}}")#text(" is absolutely continuous, but not Lipschitz continuous, on the interval ")#mi("{[0,1]}")#text(".")],
[#text("Show that the Cantor function from Exercise ")#link(<tao-c33915525e96fcd195f6>)[#text("84")]#text(" is continuous, monotone, and uniformly continuous, but ")#emph[#text("not")]#text(" absolutely continuous, on ")#mi("{[0,1]}")#text(".")],
[#text("If ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" is absolutely integrable, show that the indefinite integral ")#mi("{F(x) := \\int_{[-\\infty,x]} f(y)\\ dy}")#text(" is absolutely continuous, and that ")#mi("{F}")#text(" is differentiable almost everywhere with ")#mi("{F^{\\prime}(x)=f(x)}")#text(" for almost every ")#mi("{x}")#text(".")],
[#text("Show that the sum or product of two absolutely continuous functions on an interval ")#mi("{[a,b]}")#text(" remains absolutely continuous. What happens if we work on ")#mi("{{\\bf R}}")#text(" instead of on ")#mi("{[a,b]}")#text("?")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 88")]

#enum(start: 1, 
[#text("Show that absolutely continuous functions map null sets to null sets, i.e. if ")#mi("{F: {\\bf R} \\rightarrow{\\bf R}}")#text(" is absolutely continuous and ")#mi("{E}")#text(" is a null set then ")#mi("{F(E) := \\{ F(x): x \\in E \\}}")#text(" is also a null set.")],
[#text("Show that the Cantor function does ")#emph[#text("not")]#text(" have this property.")]
)
]

#text("For absolutely continuous functions, we can recover the second fundamental theorem of calculus:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 89 (Second fundamental theorem for absolutely continuous functions)")]#text(" ")#metadata(none) <tao-de30ca29b1cdd27f3a3c>#text(" Let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be absolutely continuous. Then ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx = F(b)-F(a)}")#text(".")
]

#emph[#text("Proof:")]#text(" Our main tool here will be ")#link("http://en.wikipedia.org/wiki/Cousin's_theorem")[#text("Cousin’s theorem")]#text(" (Exercise ")#link(<tao-42e20cbe942249d85888>)[#text("47")]#text(").")#linebreak()#text(" By Exercise ")#link(<tao-540dc93e34853e49267b>)[#text("80")]#text(", ")#mi("{F^{\\prime}}")#text(" is absolutely integrable. By Exercise 21 of ")#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")[#text("Notes 4")]#text(", ")#mi("{F^{\\prime}}")#text(" is thus uniformly integrable. Now let ")#mi("{\\varepsilon > 0}")#text(". By Exercise 24 of ")#link("https://terrytao.wordpress.com/2010/10/02/245a-notes-4-modes-of-convergence/")[#text("Notes 4")]#text(", we can find ")#mi("{\\kappa > 0}")#text(" such that ")#mi("{\\int_U |F^{\\prime}(x)|\\ dx \\leq \\varepsilon}")#text(" whenever ")#mi("{U \\subset [a,b]}")#text(" is a measurable set of measure at most ")#mi("{\\kappa}")#text(". (Here we adopt the convention that ")#mi("{F^{\\prime}}")#text(" vanishes outside of ")#mi("{[a,b]}")#text(".) By making ")#mi("{\\kappa}")#text(" small enough, we may also assume from absolute continuity that ")#tao-math("{\\sum_{j=1}^n \\left|F(b_j)-F(a_j)\\right| \\leq \\varepsilon}", block: false)#text(" whenever ")#mi("{(a_1,b_1),\\ldots,(a_n,b_n)}")#text(" is a finite collection of disjoint intervals of total length ")#mi("{\\sum_{j=1}^n b_j - a_j}")#text(" at most ")#mi("{\\kappa}")#text(".")#linebreak()#text(" Let ")#mi("{E \\subset [a,b]}")#text(" be the set of points ")#mi("{x}")#text(" where ")#mi("{F}")#text(" is not differentiable, together with the endpoints ")#mi("{a,b}")#text(", as well as the points where ")#mi("{x}")#text(" is not a Lebesgue point of ")#mi("{F^{\\prime}}")#text(". thus ")#mi("{E}")#text(" is a null set. By outer regularity (or the definition of outer measure) we can find an open set ")#mi("{U}")#text(" containing ")#mi("{E}")#text(" of measure ")#mi("{m(U) < \\kappa}")#text(". In particular, ")#mi("{\\int_U |F^{\\prime}(x)|\\ dx \\leq \\varepsilon}")#text(".")#linebreak()#text(" Now define a gauge function ")#mi("{\\delta: [a,b] \\rightarrow (0,+\\infty)}")#text(" as follows.")

#list(
[#text("If ")#mi("{x \\in E}")#text(", we define ")#mi("{\\delta(x)>0}")#text(" to be small enough that the open interval ")#mi("{(x-\\delta(x), x+\\delta(x))}")#text(" lies in ")#mi("{U}")#text(".")],
[#text("If ")#mi("{x \\not \\in E}")#text(", then ")#mi("{F}")#text(" is differentiable at ")#mi("{x}")#text(" and ")#mi("{x}")#text(" is a Lebesgue point of ")#mi("{F^{\\prime}}")#text(". We let ")#mi("{\\delta(x)>0}")#text(" be small enough that ")#tao-math("{\\left|F(y)-F(x)-(y-x)F^{\\prime}(x)\\right| \\leq \\varepsilon \\left|y-x\\right|}", block: false)#text(" holds whenever ")#tao-math("{\\left|y-x\\right| \\leq \\delta(x)}", block: false)#text(", and such that ")#tao-math("{\\left|\\frac{1}{\\left|I\\right|} \\int_I F^{\\prime}(y)\\ dy - F^{\\prime}(x)\\right| \\leq \\varepsilon}", block: false)#text(" whenever ")#mi("{I}")#text(" is an interval containing ")#mi("{x}")#text(" of length at most ")#mi("{\\delta(x)}")#text("; such a ")#mi("{\\delta(x)}")#text(" exists by the definition of differentiability, and of Lebesgue point. We rewrite these properties using ")#link("http://en.wikipedia.org/wiki/Big_O_notation")[#text("big-O notation")]#text(" as ")#tao-math("{F(y) - F(x) = (y-x) F^{\\prime}(x) + O(\\varepsilon \\left|y-x\\right|)}", block: false)#text(" and ")#tao-math("{\\int_I F^{\\prime}(y)\\ dy = \\left|I\\right| F^{\\prime}(x) + O(\\varepsilon \\left|I\\right|)}", block: false)#text(".")]
)

#text("Applying Cousin’s theorem, we can find a partition ")#mi("{a = t_0 < t_1 < \\ldots < t_k = b}")#text(" with ")#mi("{k \\geq 1}")#text(", together with real numbers ")#mi("{t^*_j \\in [t_{j-1},t_j]}")#text(" for each ")#mi("{1 \\leq j \\leq k}")#text(" and ")#mi("{t_j - t_{j-1} \\leq \\delta(t^*_j)}")#text(".")#linebreak()#text(" We can express ")#mi("{F(b)-F(a)}")#text(" as a telescoping series")

#align(center)[#tao-fit-display[#mitex("F(b)-F(a) = \\sum_{j=1}^k F(t_j) - F(t_{j-1}).")]]

#text("To estimate the size of this sum, let us first consider those ")#mi("{j}")#text(" for which ")#mi("{t^*_j \\in E}")#text(". Then, by construction, the intervals ")#mi("{(t_{j-1},t_j)}")#text(" are disjoint in ")#mi("{U}")#text(". By construction of ")#mi("{\\kappa}")#text(", we thus have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{j: t^*_j \\in E} \\left|F(t_j) - F(t_{j-1})\\right| \\leq \\varepsilon", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\sum_{j: t^*_j \\in E} F(t_j) - F(t_{j-1}) = O(\\varepsilon).")]]

#text("Next, we consider those ")#mi("{j}")#text(" for which ")#mi("{t^*_j \\not \\in E}")#text(". By construction, for those ")#mi("{j}")#text(" we have")

#align(center)[#tao-fit-display[#tao-math("F(t_j) - F(t_{j}^*) = (t_j - t_j^*) F^{\\prime}(t^*_j) + O(\\varepsilon \\left|t_j - t^*_j\\right| )", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("F(t_j^*) - F(t_{j-1}) = (t_j^* - t_{j-1}) F^{\\prime}(t^*_j) + O(\\varepsilon \\left|t_j^* - t_{j-1}\\right| )", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("F(t_j) - F(t_{j-1}) = (t_j - t_{j-1}) F^{\\prime}(t^*_j) + O(\\varepsilon \\left|t_j - t_{j-1}\\right| ).", block: true)]]

#text("On the other hand, from construction again we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{[t_{j-1},t_j]} F^{\\prime}(y)\\ dy = (t_j -t_{j-1}) F^{\\prime}(t^*_j) + O(\\varepsilon \\left|t_j - t_{j-1}\\right| )", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#tao-math("F(t_j) - F(t_{j-1}) = \\int_{[t_{j-1},t_j]} F^{\\prime}(y)\\ dy + O(\\varepsilon \\left|t_j - t_{j-1}\\right| ).", block: true)]]

#text("Summing in ")#mi("{j}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j: t^*_j \\not \\in E} F(t_j) - F(t_{j-1}) = \\int_{S} F^{\\prime}(y)\\ dy + O(\\varepsilon (b-a) ),")]]

#text("where ")#mi("{S}")#text(" is the union of all the ")#mi("{[t_{j-1},t_j]}")#text(" with ")#mi("{t^*_j \\not \\in E}")#text(". By construction, this set is contained in ")#mi("{[a,b]}")#text(" and contains ")#mi("{[a,b] \\backslash U}")#text(". Since ")#mi("{\\int_U |F^{\\prime}(x)|\\ dx \\leq \\varepsilon}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{S} F^{\\prime}(y)\\ dy = \\int_{[a,b]} F^{\\prime}(y)\\ dy + O(\\varepsilon).")]]

#text("Putting everything together, we conclude that")

#align(center)[#tao-fit-display[#tao-math("F(b)-F(a) = \\int_{[a,b]} F^{\\prime}(y)\\ dy + O(\\varepsilon) + O( \\varepsilon \\left|b-a\\right| ).", block: true)]]

#text("Since ")#mi("{\\varepsilon > 0}")#text(" was arbitrary, the claim follows. ")#mi("\\Box")#linebreak()#text(" Combining this result with Exercise ")#link(<tao-c45bf610333ea3e672cb>)[#text("87")]#text(", we obtain a satisfactory classification of the absolutely continuous functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 90")]#text(" Show that a function ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" is absolutely continuous if and only if it takes the form ")#mi("{F(x) = \\int_{[a,x]} f(y)\\ dy + C}")#text(" for some absolutely integrable ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" and a constant ")#mi("{C}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 91 (Compatibility of the strong and weak derivatives in the absolutely continuous case)")]#text(" Let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be an absolutely continuous function, and let ")#mi("{\\phi: [a,b] \\rightarrow {\\bf R}}")#text(" be a continuously differentiable function supported in a compact subset of ")#mi("{(a,b)}")#text(". Show that ")#mi("{\\int_{[a,b]} F^{\\prime} \\phi(x) \\ dx = - \\int_{[a,b]} F \\phi^{\\prime}(x)\\ dx}")#text(".")
]

#text("Inspecting the proof of Theorem ")#link(<tao-de30ca29b1cdd27f3a3c>)[#text("89")]#text(", we see that the absolute continuity was used primarily in two ways: firstly, to ensure the almost everywhere existence, and to control an exceptional null set ")#mi("{E}")#text(". It turns out that one can achieve the latter control by making a different hypothesis, namely that the function ")#mi("{F}")#text(" is ")#emph[#text("everywhere")]#text(" differentiable rather than merely almost everywhere differentiable. More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 92 (Second fundamental theorem of calculus, again)")]#text(" ")#metadata(none) <tao-b3f4f3fca7aad0c8dcdd>#text(" Let ")#mi("{[a,b]}")#text(" be a compact interval of positive length, let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be a differentiable function, such that ")#mi("{F^{\\prime}}")#text(" is absolutely integrable. Then the Lebesgue integral ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx}")#text(" of ")#mi("{F^{\\prime}}")#text(" is equal to ")#mi("{F(b) - F(a)}")#text(".")
]

#emph[#text("Proof:")]#text(" This will be similar to the proof of Theorem ")#link(<tao-de30ca29b1cdd27f3a3c>)[#text("89")]#text(", the one main new twist being that we need several open sets ")#mi("{U}")#text(" instead of just one. Let ")#mi("{E \\subset [a,b]}")#text(" be the set of points ")#mi("{x}")#text(" which are not Lebesgue points of ")#mi("{F^{\\prime}}")#text(", together with the endpoints ")#mi("{a,b}")#text(". This is a null set. Let ")#mi("{\\varepsilon > 0}")#text(", and then let ")#mi("{\\kappa > 0}")#text(" be small enough that ")#mi("{\\int_U |F^{\\prime}(x)|\\ dx \\leq \\varepsilon}")#text(" whenever ")#mi("{U}")#text(" is measurable with ")#mi("{m(U) \\leq \\kappa}")#text(". We can also ensure that ")#mi("{\\kappa \\leq \\varepsilon}")#text(".")#linebreak()#text(" For every natural number ")#mi("{m=1,2,\\ldots}")#text(" we can find an open set ")#mi("{U_m}")#text(" containing ")#mi("{E}")#text(" of measure ")#mi("{m(U_m) \\leq \\kappa/4^m}")#text(". In particular we see that ")#mi("{m( \\bigcup_{m=1}^{\\infty} U_m ) \\leq \\kappa}")#text(" and thus ")#mi("{\\int_{\\bigcup_{m=1}^\\infty U_m} |F^{\\prime}(x)|\\ dx \\leq \\varepsilon}")#text(".")#linebreak()#text(" Now define a gauge function ")#mi("{\\delta: [a,b] \\rightarrow (0,+\\infty)}")#text(" as follows.")

#list(
[#text("If ")#mi("{x \\in E}")#text(", we define ")#mi("{\\delta(x)>0}")#text(" to be small enough that the open interval ")#mi("{(x-\\delta(x), x+\\delta(x))}")#text(" lies in ")#mi("{U_m}")#text(", where ")#mi("{m}")#text(" is the first natural number such that ")#tao-math("{\\left|F^{\\prime}(x)\\right| \\leq 2^m}", block: false)#text(", and also small enough that ")#tao-math("{\\left|F(y)-F(x)-(y-x)F^{\\prime}(x)\\right| \\leq \\varepsilon \\left|y-x\\right|}", block: false)#text(" holds whenever ")#tao-math("{\\left|y-x\\right| \\leq \\delta(x)}", block: false)#text(". (Here we crucially use the ")#emph[#text("everywhere")]#text(" differentiability to ensure that ")#mi("{f^{\\prime}(x)}")#text(" exists and is finite here.)")],
[#text("If ")#mi("{x \\not \\in E}")#text(", we let ")#mi("{\\delta(x)>0}")#text(" be small enough that ")#tao-math("{\\left|F(y)-F(x)-(y-x)F^{\\prime}(x)\\right| \\leq \\varepsilon \\left|y-x\\right|}", block: false)#text(" holds whenever ")#tao-math("{\\left|y-x\\right| \\leq \\delta(x)}", block: false)#text(", and such that ")#tao-math("{\\left|\\frac{1}{\\left|I\\right|} \\int_I F^{\\prime}(y)\\ dy - F^{\\prime}(x)\\right| \\leq \\varepsilon}", block: false)#text(" whenever ")#mi("{I}")#text(" is an interval containing ")#mi("{x}")#text(" of length at most ")#mi("{\\delta(x)}")#text(", exactly as in the proof of Theorem ")#link(<tao-de30ca29b1cdd27f3a3c>)[#text("89")]#text(".")]
)

#text("Applying Cousin’s theorem, we can find a partition ")#mi("{a = t_0 < t_1 < \\ldots < t_k = b}")#text(" with ")#mi("{k \\geq 1}")#text(", together with real numbers ")#mi("{t^*_j \\in [t_{j-1},t_j]}")#text(" for each ")#mi("{1 \\leq j \\leq k}")#text(" and ")#mi("{t_j - t_{j-1} \\leq \\delta(t^*_j)}")#text(".")#linebreak()#text(" As before, we express ")#mi("{F(b)-F(a)}")#text(" as a telescoping series")

#align(center)[#tao-fit-display[#mitex("F(b)-F(a) = \\sum_{j=1}^k F(t_j) - F(t_{j-1}).")]]

#text("For the contributions of those ")#mi("{j}")#text(" with ")#mi("{t^*_j \\not \\in E}")#text(", we argue exactly as in the proof of Theorem ")#link(<tao-de30ca29b1cdd27f3a3c>)[#text("89")]#text(" to conclude eventually that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j: t^*_j \\not \\in E} F(t_j) - F(t_{j-1}) = \\int_{S} F^{\\prime}(y)\\ dy + O(\\varepsilon (b-a) ),")]]

#text("where ")#mi("{S}")#text(" is the union of all the ")#mi("{[t_{j-1},t_j]}")#text(" with ")#mi("{t^*_j \\not \\in E}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\int_{[a,b] \\backslash S} |F^{\\prime}(x)|\\ dx \\leq \\int_{\\bigcup_{m=1}^\\infty U_m} |F^{\\prime}(x)|\\ dx \\leq \\varepsilon")]]

#text("we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{S} F^{\\prime}(y)\\ dy = \\int_{[a,b]} F^{\\prime}(y)\\ dy + O(\\varepsilon).")]]

#text("Now we turn to those ")#mi("{j}")#text(" with ")#mi("{t^*_j \\in E}")#text(". By construction, we have")

#align(center)[#tao-fit-display[#tao-math("F(t_j) - F(t_{j-1}) = (t_j - t_{j-1}) F^{\\prime}(t^*_j) + O(\\varepsilon \\left|t_j - t_{j-1}\\right| )", block: true)]]

#text("fir these intervals, and so")

#align(center)[#tao-fit-display[#mitex("\\sum_{j: t^*_j \\in E} F(t_j) - F(t_{j-1}) = (\\sum_{j: t^*_j \\in E} (t_j - t_{j-1}) F^{\\prime}(t^*_j)) + O(\\varepsilon (b-a) ).")]]

#text("Next, for each ")#mi("{j}")#text(" we have ")#mi("{F^{\\prime}(t^*_j) \\leq 2^m}")#text(" and ")#mi("{[t_{j-1},t_j] \\subset U_m}")#text(" for some natural number ")#mi("{m=1,2,\\ldots}")#text(", by construction. By countable additivity, we conclude that")

#align(center)[#tao-fit-display[#mitex("(\\sum_{j: t^*_j \\in E} (t_j - t_{j-1}) F^{\\prime}(t^*_j)) \\leq \\sum_{m=1}^\\infty 2^m m(U_m) \\leq \\sum_{m=1}^\\infty 2^m \\varepsilon/4^m = O(\\varepsilon).")]]

#text("Putting all this together, we again have")

#align(center)[#tao-fit-display[#tao-math("F(b)-F(a) = \\int_{[a,b]} F^{\\prime}(y)\\ dy + O(\\varepsilon) + O( \\varepsilon \\left|b-a\\right| ).", block: true)]]

#text("Since ")#mi("{\\varepsilon > 0}")#text(" was arbitrary, the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 93")]#text(" The above proposition is yet another illustration of how the property of everywhere differentiability is significantly better than that of almost everywhere differentiability. In practice, though, the above proposition is not as useful as one might initially think, because there are very few methods that establish the everywhere differentiability of a function that do not also establish continuous differentiability (or at least Riemann integrability of the derivative), at which point one could just use Theorem ")#link(<tao-56a426839b0d90577b49>)[#text("11")]#text(" instead.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 94")]#text(" ")#metadata(none) <tao-a5a2729ffa0eeacc1532>#text(" Let ")#mi("{F: [-1,1] \\rightarrow {\\bf R}}")#text(" be the function defined by setting ")#mi("{F(x) := x^2 \\sin(\\frac{1}{x^3})}")#text(" when ")#mi("{x}")#text(" is non-zero, and ")#mi("{F(0) := 0}")#text(". Show that ")#mi("{F}")#text(" is everywhere differentiable, but the deriative ")#mi("{F^{\\prime}}")#text(" is not absolutely integrable, and so the second fundamental theorem of calculus does not apply in this case (at least if we interpret ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx}")#text(" using the absolutely convergent Lebesgue integral). See however the next exercise.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 95 (Henstock-Kurzweil integral)")]#text(" Let ")#mi("{[a,b]}")#text(" be a compact interval of positive length. We say that a function ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Henstock%E2%80%93Kurzweil_integral")[#text("Henstock-Kurzweil integrable")]#text(" with integral ")#mi("{L \\in {\\bf R}}")#text(" if for every ")#mi("{\\varepsilon > 0}")#text(" there exists a gauge function ")#mi("{\\delta: [a,b] \\rightarrow (0,+\\infty)}")#text(" such that one has")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{j=1}^k f(t^*_j) (t_j - t_{j-1}) - L \\right| \\leq \\varepsilon", block: true)]]

#text("whenever ")#mi("{k \\geq 1}")#text(" and ")#mi("{a = t_0 < t_1 < \\ldots < t_k = b}")#text(" and ")#mi("{t^*_1,\\ldots,t^*_k}")#text(" are such that ")#mi("{t^*_j \\in [t_{j-1},t_j]}")#text(" and ")#tao-math("{\\left|t_j-t_{j-1}\\right| \\leq \\delta(t^*_j)}", block: false)#text(" for every ")#mi("{1 \\leq j \\leq k}")#text(". When this occurs, we call ")#mi("{L}")#text(" the ")#emph[#text("Henstock-Kurzweil integral")]#text(" of ")#mi("{f}")#text(" and write it as ")#mi("{\\int_{[a,b]} f(x)\\ dx}")#text(".")

#list(
[#text("Show that if a function is Henstock-Kurzweil integrable, it has a unique Henstock-Kurzweil integral. (")#emph[#text("Hint:")]#text(" use Cousin’s theorem.)")],
[#text("Show that if a function is Riemann integrable, then it is Henstock-Kurzweil integrable, and the Henstock-Kurzweil integral ")#mi("{\\int_{[a,b]} f(x)\\ dx}")#text(" is equal to the Riemann integral ")#mi("{\\int_a^b f(x)\\ dx}")#text(".")],
[#text("Show that if a function ")#mi("{f: [a,b] \\rightarrow {\\bf R}}")#text(" is everywhere defined, everywhere finite, and is absolutely integrable, then it is Henstock-Kurzweil integrable, and the Henstock-Kurzweil integral ")#mi("{\\int_{[a,b]} f(x)\\ dx}")#text(" is equal to the Lebesgue integral ")#mi("{\\int_{[a,b]} f(x)\\ dx}")#text(". (")#emph[#text("Hint:")]#text(" this is a variant of the proof of Theorem ")#link(<tao-de30ca29b1cdd27f3a3c>)[#text("89")]#text(" or Proposition ")#link(<tao-b3f4f3fca7aad0c8dcdd>)[#text("92")]#text(".)")],
[#text("Show that if ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" is everywhere differentiable, then ")#mi("{F^{\\prime}}")#text(" is Henstock-Kurzweil integrable, and the Henstock-Kurzweil integral ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx}")#text(" is equal to ")#mi("{F(b)-F(a)}")#text(". (")#emph[#text("Hint:")]#text(" this is a variant of the proof of Theorem ")#link(<tao-de30ca29b1cdd27f3a3c>)[#text("89")]#text(" or Proposition ")#link(<tao-b3f4f3fca7aad0c8dcdd>)[#text("92")]#text(".)")],
[#text("Explain why the above results give an alternate proof of Exercise ")#link(<tao-f97a403df41788c34dab>)[#text("10")]#text(" and of Proposition ")#link(<tao-b3f4f3fca7aad0c8dcdd>)[#text("92")]#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 96")]#text(" As the above exercise indicates, the Henstock-Kurzweil integral (also known as the ")#emph[#text("Denjoy integral")]#text(" or ")#emph[#text("Perron integral")]#text(") extends the Riemann integral and the absolutely convergent Lebesgue integral, at least as long as one restricts attention to functions that are defined and are finite everywhere (in contrast to the Lebesgue integral, which is willing to tolerate functions being infinite or undefined so long as this only occurs on a null set). It is the notion of integration that is most naturally associated with the fundamental theorem of calculus for everywhere differentiable functions, as seen in part 4 of the above exercise; it can also be used as a unified framework for all the proofs in this section that invoked Cousin’s theorem. The Henstock-Kurzweil integral can also integrate some (highly oscillatory) functions that the Lebesgue integral cannot, such as the derivative ")#mi("{F^{\\prime}}")#text(" of the function ")#mi("{F}")#text(" appearing in Exercise ")#link(<tao-a5a2729ffa0eeacc1532>)[#text("94")]#text(". This is analogous to how conditional summation ")#mi("{\\lim_{N \\rightarrow \\infty} \\sum_{n=1}^N a_n}")#text(" can sum conditionally convergent series ")#mi("{\\sum_{n=1}^\\infty a_n}")#text(", even if they are not absolutely integrable. However, much as conditional summation is not always well-behaved with respect to rearrangement, the Henstock-Kurzweil integral does not always react well to changes of variable; also, due to its reliance on the order structure of the real line ")#mi("{{\\bf R}}")#text(", it is difficult to extend the Henstock-Kurzweil integral to more general spaces, such as the Euclidean space ")#mi("{{\\bf R}^d}")#text(", or to abstract measure spaces.")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (255)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-692046")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2026")])]

#text("Inspired by Exercise 87 (6), does this hold:")

#text("If ")#mi("F:\\mathbf{R}\\to\\mathbf{R}")#text(" is absolutely continuous, then there exists ")#mi("f:\\mathbf{R}\\to\\mathbf{R}")#text(" being absolutely integrable so that ")#mi("F(x)=\\int_{(-\\infty,x]}f(t)\\ dt")#text("?")

#emph[#text("[As literally stated, the answer is no; take for instance ")#mi("F(x)=x")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-692631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2026")])]

#text("I’m confused by the hint for Exercise 3. Why can a function F that satisfies the Hint of Exercise 3 be used to construct an example that is everywhere differentiable but not continuously differentiable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-692643")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2026")])]

#text("If the oscillations are chosen correctly, the derivative can be made to exist both at the origin and away from the origin, but the derivative away from the origin can be made to diverge as one approaches zero, creating the desired discontinuity.")

#text("It sounds like this will be an excellent educational exercise for you to work on by yourself (without significant external assistance from either humans or AI, though some graphing or symbolic calculation tools may be helpful, as well as good old-fashioned sketching on pen and paper). The key skill needed here is to avoid ")#link("https://en.wikipedia.org/wiki/Analysis_paralysis")[#text("analysis paralysis")]#text(" – the inclination to do nothing when there are a variety of ways to proceed, and you are not sure which one to select. See also ")#link("https://terrytao.wordpress.com/books/analysis-i/comment-page-17/#comment-692097")[#text("https://terrytao.wordpress.com/books/analysis-i/comment-page-17/#comment-692097")]#text(" and ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/comment-page-1/#comment-689183")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/comment-page-1/#comment-689183")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693125")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2026")])]

#text("Thank you for your sincere advice. After repeatedly trying to sketch on paper and drawing over a dozen oscillatory functions, I believe I have constructed an example: f(x) = x²sin(1/x). However, I feel this example is artificially constructed, and I still have a question: how exactly does oscillation destroy differentiability? A function like sin(x) is also oscillatory, yet it is differentiable. At the same time, do we need to impose any restrictions on its derivative?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693151")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2026")])]

#text("Now that you have worked the answer out on pen and paper, it becomes appropriate to use AI tools to analyze it further. See ")#link("https://claude.ai/share/a7b88305-72de-4a17-9ef0-d8422eb99b77")[#text("this AI-generated response to your question")]#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-692994")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2026")])]

#text("Many of your proofs under this post involve density arguments. I’m not sure what your starting point and motivation are for using density arguments. I’d like to ask whether this is related to your observation that proofs using density arguments are connected to some type of “invariance”, so one can restrict attention to a dense subclass?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693080")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2026")])]

#text("Passing to a dense subclass is basically a “free move”: proving a given claim for all functions in a dense subclass is logically no more difficult than proving the claim for all functions in the full class, so whenever one has enough continuity (or semicontinuity, etc.) to make such a reduction, there is little downside to making the reduction. (This is not to say that one should *always* pass to a dense subclass; in some cases, such a passage does not actually simplify the proof, and simply creates some distracting and irrelevant additional steps. Also, there are some other situations where it is actually useful to work in the original space rather than a dense subclass, for instance to take advantage of some completeness, closure, or compactness properties of the original space that might be lost when passing to a subclass.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693473")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2026")])]

#text("In deriving the Lebesgue differentiation theorem, the quantitative estimate we need is the Hardy–Littlewood maximal inequality. Why is this the point where Hardy-Littlewood maximal functions come into play?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2026")])]

#text("I am ")#link("https://claude.ai/share/cf39ac78-ec91-48ea-9972-a9e45ee308e4")[#text("outsourcing this question to an AI")]#text(".")

#text("I will also note that switching from limits to maximal functions conveys the additional advantage that the maximal function is always defined (though it can be infinite), whereas limits do not always exist, which makes it easier to make arguments rigorous. Also, maximal functions tend to have decent sublinearity and semicontinuity properties which are useful for various technical steps such as interpolation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("Dear Prof. Tao,")

#text("I was astonished by (1) in Exercise 23: this seems to be called the Cauchy’s functional equation, and it’s astonishing that imposing such a weak condition, which is measurability, on its solutions can actually yield regularity (continuity). But what I want to ask is, why does Steinhaus theorem come into play here with Cauchy’s functional equation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693763")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("This is one of the simplest examples of a general phenomenon: algebraic structure (such as Cauchy’s functional equation) can combine with weak regularity structure (such as measurability) to obtain strong regularity structure (e.g., continuity or analyticity). See my book ")#link("https://terrytao.wordpress.com/books/hilberts-fifth-problem-and-related-topics/")[#text("https://terrytao.wordpress.com/books/hilberts-fifth-problem-and-related-topics/")]#text(" for an extensive exploration of this phenomenon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693780")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2026")])]

#text("Thank you for your reply. I didn’t know this question had such a deep background before. However, I’m still puzzled: Steinhaus theorem is about convolution, so why is this theorem connected to the phenomenon where the combination of algebraic structure and weak regularity can obtain strong regularity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693781")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2026")])]

#text("The definition of convolution involves both a group operation (subtraction or division) as well as measurable structure (to perform the integration).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("Is the concept of the Dini derivative a transitional notion introduced solely to lead to results like the monotone differentiation theorem? It seems that it is rarely seen elsewhere in analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-4/#comment-693874")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2026")])]

#text("I am ")#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/Is the concept of the Dini derivative a transitional notion introduced solely to lead to results like the monotone differentiation theorem? It seems that it is rarely seen elsewhere in analysis.")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Do we assume ")#mi("F")#text(" to be continuous in Exercise ")#mi("55")#text("?(showing the Dini derivatives are measurable)")

#emph[#text("[No; montonicity is sufficient here. Note that monotone functions have only countably many discontinuities in any event. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678724")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2023")])]

#text("Thank you professor, also in the proof of lemma 59, I think the statement “Thus we see that ")#mi("{E_{r,R}}")#text(" is contained inside the union of the intervals … ” should be “Thus we see that ")#mi("E_{r,R} \\cap (a,b)")#text(" is contained inside the union of the intervals … ”")

#emph[#text("[Corrected, thanks – T.]")]#emph[]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678753")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Can you elaborate a bit more on your statement in Remark 60: “Note if ")#mi("{F}")#text(" was not assumed to be continuous, then one would lose a factor of ")#mi("{C}")#text(" here from the second part of Lemma 56, and one would then be unable to prevent ")#mi("{\\overline{D^+} F}")#text(" from being up to ")#mi("{C}")#text(" times as large as ")#mi("{\\underline{D_-} F}")#text(".”? Do mean that ")#mi("{\\overline{D^+} F} \\leq C \\cdot {\\underline{D_-} F}")#text(" on a set of positive measure? What is referred to by “lose a factor of ")#mi("C")#text("“? Thank you so much.")

#emph[#text("[Yes, this is the sort of bound one would get from using the second part of Lemma 56. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678764")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" I see that the second part of Lemma 56 gives ")#mi("m( E_{r,R} \\cap (a,b) ) \\leq C\\frac{F(b)-F(a)}{R}.")#text(" How does one derive the given bound then?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678835")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" I wonder why is the bound ")#mi("{\\overline{D^+} F} \\leq C {\\underline{D^-} F}")#text(" in Remark 60 a consequence of part 2 of Lemma 56?")

#emph[#text("[Modify the proof of Lemma 59 by using the second part of Lemma 56 instead of the first part, which causes an additional loss of ")#mi("C")#text(" in the conclusion of that lemma. Then repeat the arguments preceding Lemma 59 to conclude that ")#mi("{\\overline{D^+} F} \\leq C {\\underline{D^-} F}")#text(" holds outside of a null set. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678852")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("Thank you so much professor, I cannot appreciate your warm patience more.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678886")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Following the hint of Exercise 58, I tried to find an open cover of some compact ")#mi("K \\subset \\{ x \\in (a,b): \\overline{D^+} F(x) > \\lambda \\}")#text(", of total measure at most ")#mi("\\frac{F(b)-F(a)}{\\lambda}")#text(". I feel like the fact that we can find ")#mi("y")#text(" arbitrarily close to the right of ")#mi("x")#text(" such that ")#tao-math("\\left|x - y\\right| \\leq \\frac{F(y)-F(x)}{\\lambda}", block: false)#text(" might be relevant, but I’m not sure on how to use this piece of information to construct the desired covering. Can you provide some hint on that?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of qshuyu@yahoo.com")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-678984")[#strong[#text("qshuyu@yahoo.com")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Eventually my thought on Exercise 58 lead me to obtaining a cover of the set ")#mi("A")#text(" (the set of points in ")#mi("K - \\partial K")#text(" where ")#mi("F")#text(" is continuous) for any compact subset ")#mi("K \\subset \\{ x \\in (a,b): \\overline{D^+} F(x) > \\lambda \\}")#text(". Then one can use the fact that ")#mi("F")#text(" is continuous on a sufficiently small interval containing ")#mi("x\\in A")#text(", together with the theorem that if ")#mi("f")#text(" is continuous on some bounded interval ")#mi("[c, d]")#text(", and any of the four dini derivatives is non-negative on ")#mi("[c,d]")#text(", then ")#mi("f(d) \\geq f(c)")#text(".")#linebreak()#text(" The theorem is mentioned say in Khinchin’s “Eight Lectures on Mathematical Analysis” but not in this set of note in particular. Is this idea completely off?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679207")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" In the proof of Lemma 62, Isn’t the expression ")#mi("F_{pp}(b) - F_{pp}(a) = {\\sum_{x \\in A \\cap [a,b]} c_x}")#text(" true only when ")#mi("F")#text(" is continuous both at ")#mi("a")#text(" and ")#mi("b")#text("? For if ")#mi("b \\in A")#text(", then ")#mi("F_{pp}(b) = \\sum_{x \\in A, x < b} c_x + \\theta_bc_b")#text(" instead.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679308")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" I still have some question on the end of the corrected proof of Lemma 62, where it says now that the left-hand side can be rewritten as ")#mi("{\\sum_{x \\in A \\cap [a,b]} c_x + \\theta_b c_b - \\theta_a c_a}")#text(", are we only focusing on the case where both ")#mi("a")#text(" and ")#mi("b")#text(" are jumps of ")#mi("F")#text("? If so, shouldn’t the LHS be ")#mi("{\\sum_{x \\in A \\cap (a,b)} c_x + \\theta_b c_b - \\theta_a c_a}")#text(" instead?")

#emph[#text("[Corrected, thanks (it’s simplest just to use continuity to stay away from the jumps). -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679410")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For Exercise 65, can one define the generalized jump function to be a function that can be expressed as an absolutely convergent combination of basic jump functions on any bounded interval, then translate to cover the unbounded case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679611")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" By the hint of Exercise 73, one can find a common refinement such that both ")#mi("\\sum_{i=1}^n \\max(-F(x_{i}) + F(x_{i-i}),0) > F^-(x) - \\epsilon")#text(" and ")#mi("\\sum_{i=1}^n \\max(F(x_{i}) - F(x_{i-1}),0) > F^+(x) - \\epsilon")#text(", ")#mi("\\forall \\epsilon > 0")#text(". I struggle a bit to see, however, how can we use this to prove the identity ")#mi("F(x) = F(-\\infty) + F^+(x) - F^-(x)")#text(", namely that the current height equals initial height plus the total gain in height minus the total loss in height.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679624")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" From the hint of Exercise 73, I assume we want good partitions x_0 < \\ldots < x_n \\leq x for F^- and y_0 < \\ldots < y_m \\leq x for F^+ respectively, such that F(x) < F(- \\infty) + F^+(x) – \\sum_{i=1}^n \\max(F(x_{i-1}) – F(x_i), 0) < F(x) + \\varepsilon_1 and F(x) – \\varepsilon_2 < F(- \\infty) + \\sum_{i=1}^m \\max(F(y_{i}) – F(y_{i-1}, 0) – F^-(x) < F(x). We then form the common refinement and take the sup so that ")#mi("\\varepsilon_1, \\varepsilon_2 \\rightarrow 0")#text(". Yet I’m not sure how to explicitly construct these partitions. Am I confusing what the hint is suggesting at?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679703")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" The first display following Exercise 65 should be")

#mi("\\displaystyle m(\\{ x \\in {\\mathbb R}: \\overline{D^+} (F-F_\\varepsilon)(x) \\geq \\lambda \\}) \\leq \\frac{2C\\varepsilon}{\\lambda}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679785")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" In Exercise 78, are we expected to first derive the increasing secant definition of convex function to prove both the continuity and a.e differentiability?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-679829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" The last display in the proof of proposition 79 has a ")#mi("\\leq")#text(" sign at the front which is redundant.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-680781")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("Dear Terry Tao")#linebreak()#text(" Exercise 30, You have asked to show that this exercise implies lemma 36, which I think you meant to be lemma 25 actually.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-680911")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2023")])]

#text("Dear Terry Tao")#linebreak()#text(" To prove the last part of Exercise 50, I think the following approach should work, but I’m not sure.")#linebreak()#text(" *for the beginning, note that if we let ")#tao-math("A(r) = \\frac{1}{r^d}\\int_{\\left|y\\right| \\leq r [f(x-y) - f(y)]dy}", block: false)#text(" then there exists ")#mi("M")#text(" s.t ")#mi("A(r) \\leq M")#text(" for any r > 0 and ")#mi("x")#text(" being a Lebesgue point of ")#mi("f")#text(".")#linebreak()#text(" Also ")#mi("A(r) \\to 0 as t \\to 0")#text(".")#linebreak()#text(" Also note that since ")#mi("P")#text(" is integrable there is ")#tao-math("B_R = \\{x \\in R^d : \\left|X\\right| \\geq R\\}", block: false)#text(" s.t integrating ")#mi("P")#text(" over ")#mi("B_R")#text(" is less than ")#mi("\\epsilon")#text(".")#linebreak()#text(" Now assume ")#mi("P")#text(" is bounded from above by some constant A. Hence:")#linebreak()#text(" ")#tao-math("(f*P_t)(x) - f(x) = \\int_{R^d}\\frac{1}{t^d}[f(x-y)-f(x)]P(t^{-1}y)dy \\leq \\int_{\\left|y\\right| \\leq t}|\\frac{1}{t^d}[f(x-y)-f(x)]P(t^{-1}y)|dy + \\int_{\\left|y\\right| \\leq 2t}\\frac{1}{t^d}|[f(x-y)-f(x)]P(t^{-1}y)|dy \\cdots \\int_{\\left|y\\right| \\leq Rt}\\frac{1}{t^d}|[f(x-y)-f(x)]P(t^{-1}y)|dy + \\int_{\\left|y\\right| \\geq Rt}\\frac{1}{t^d}|[f(x-y)-f(x)]P(t^{-1}y)|dy \\leq   A\\int_{\\left|y\\right| \\leq t}\\frac{1}{t^d}|[f(x-y)-f(x)]|dy + \\cdots A\\int_{\\left|y\\right| \\leq Rt}\\frac{1}{t^d}|[f(x-y)-f(x)]|dy + \\int_{\\left|y\\right| \\geq Rt}\\frac{1}{t^d}|[f(x-y)-f(x)]P(t^{-1}y)|dy", block: false)#linebreak()#text(" Now choose t small enough s.t each of the first R term be ")#mi("\\leq \\frac{\\epsilon}{2RA}")#text(".")#linebreak()#text(" Also for the last term:")#linebreak()#text(" ")#tao-math("\\int_{\\left|y\\right| \\geq Rt}|[f(x-y)-f(x)]P(t^{-1}y)|dy \\leq M\\int_{\\left|y\\right| \\geq Rt}P(t^{-1}y)|dy \\leq M\\int_{\\left|y\\right| \\geq R}P(y)|dy", block: false)#text(" and conclusion follows.")#linebreak()#text(" To complete the proof, my idea is to approximate P with bounded functions that is close enough to P in ")#mi("L^1")#text(".")#linebreak()#text(" I’m not sure this approach is correct, since there are several assumptions I didn’t use, namely being non radially decreasing.(actually the only assumption I used was integrability of P).")#linebreak()#text(" what am I missing?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-681293")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2023")])]

#text("Dear Terry Tao")#linebreak()#text(" I’m having troubles understanding proof of lemma 59.")#linebreak()#text(" actually applying rising sun lemma to ")#mi("G")#text(" gives an at most countable family of disjoint intervals ")#mi("{-I_n = (-b_n,-a_n)}")#text(" in ")#mi("{(-b,-a)}")#text(", such that ")#mi("{G(-a_n) \\geq G(-b_n)}")#text(" for all ")#mi("{n}")#text(", and such that ")#mi("{G(-x) \\geq G(-y)}")#text(" whenever ")#mi("{-x \\leq -y \\leq -a}")#text(" and ")#mi("{-x \\in (-b,-a)}")#text(" lies outside of all of the ")#mi("{-I_n}")#text(".")#linebreak()#text(" but in proof given here is said that ")#mi("{G(-x) \\leq G(-y)}")#text(" whenever ")#mi("{-x \\leq -y \\leq -a}")#text(" and ")#mi("{-x \\in (-b,-a)}")#text(" lies outside of all of the ")#mi("{-I_n}")#text(".")#linebreak()#text(" I also asked this in this ")#link("https://math.stackexchange.com/questions/4759724/proof-of-almost-everywhere-differentiability-of-monotone-functions")[#text("conversation")]#text(" but I got no answer.")#linebreak()#text(" Thanks.")

#emph[#text("[This is a typo, now fixed, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-681434")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2023")])]

#text("I think it should be a typo, isn’t it?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stein’s spherical maximal theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-686014")[#strong[#text("Stein’s spherical maximal theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2024")])]

#text("[…] for all and almost every . See for instance my lecture notes on this topic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-687494")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2025")])]

#text("[I will do one more attempt to see if I can fix that.]")

#text("In Theorem 32, Let ")#mi("A := \\{ x \\in \\mathbf{R}^d : \\lim_{r \\to 0}\\frac{1}{m(B(x,r))}\\int_{B(x,r)} f(y)\\,dy = f(x) \\}")#text(" and ")#mi("L := \\{ x \\in \\mathbf{R}^d : \\lim_{r \\to 0}\\frac{1}{m(B(x,r))}\\int_{B(x,r)} |f(y)-f(x)|\\,dy = 0 \\}")#text(".")#linebreak()#text("The Theorem asserts that ")#mi("m(\\mathbf{R}^d \\setminus A) = m(\\mathbf{R}^d \\setminus L) = 0")#text(".")#linebreak()#text("It is clear from the triangle inequality that ")#mi("L \\subset A")#text(".")#linebreak()#text("Can one find an example of a point in ")#mi("A\\setminus L")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-687499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2025")])]

#text("Sure! Hint: consider an odd function ")#mi("f")#text(" and take ")#mi("x=0")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688019")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("In proposition 79, why ")#mi("\\liminf n \\int_{b}^{b+1/n} F(x) dx = F(b)")#text("? In Stein’s book (P125), he said it is because of F is continuous, but it is not the case here…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688030")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("By the construction at the start of the proof, ")#mi("f")#text(" is constant to the right of ")#mi("b")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688240")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2025")])]

#text("Dear professor Tao:")

#text("To establish continuity of the convolution in Exercise 21, is it necessary to first get commutativity in this setting for functions defined on ")#mi("{\\bf R}^d")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688269")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2025")])]

#text("Dear professor Tao:")

#text("For the proof of the one-sided Hardy Littlewood maxima inequality, can’t we replace the subset sign with an equal sign after the statement “From the second property of that lemma, we observe that…?")

#text("[<i>This property is not stated as an if and only if statement. -T.</i>]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688271")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2025")])]

#text("Dear professor Tao:")

#text("To establish the case for ")#mi("\\lambda  = 0")#text(" in Exercise 30, the construction of ")#mi("F")#text(" in the proof of Lemma 25 does show that the integral over the union of the ")#mi("I_n")#text(" is non-negative, yet it does not seem to provide a lower bound for the integral over the smaller set where the maximal function is positive on the compact interval. Can you give a little hint on this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688272")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2025")])]

#text("My understanding of the hint for Exercise 30 is to invoke the construction ")#mi("U")#text(" in the proof of the rising sun lemma, which equals the set where the one-sided maximal function is positive, but the intervals themselves induced by the lemma are not necessarily equal to ")#mi("U")#text(" (they can be strictly larger in this case).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688285")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2025")])]

#text("Dear professor Tao:")

#text("In the hint for the Besicovitch covering lemma in one dimension, should we change “union” to “intersection”, since we can have a family of intervals with some of them contained in the union of others that still meet the requirement of the lemma.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688288")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2025")])]

#text("I got it, thank you professor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688290")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2025")])]

#text("Dear professor Tao:")

#text("Do we need to exclude the case where ")#mi("E")#text(" is a null set when talking about points of density?")

#emph[#text("[No, although in that case the concept is vacuous as no point can be a point of density – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688291")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2025")])]

#text("Dear professor Tao:")

#text("In part (2) of Exercise 49, why do we need to reduce first to the bounded case? the argument by outer regularity and decomposition of open sets seems to go through even when ")#mi("E")#text(" is not assumed to be bounded.")

#emph[#text("[That can work also. In general, there can be multiple ways to solve any given problem. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688293")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2025")])]

#text("Dear professor Tao:")

#text("For part (3) of Exercise 49, knowing that ")#mi("Q-Q")#text(" contains a neighborhood of zero, I was trying to show the same holds for ")#mi("(E \\cap Q) - (E \\cap Q)")#text(" for some properly chosen ")#mi("Q")#text(", but ran into some difficulty approaching by contradiction. Can you provide some further hint?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688298")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2025")])]

#text("Dear professor Tao:")

#text("I think I get it now. The idea is to use a sequence ")#mi("x_n")#text(" converging to the origin that lies outside of ")#mi("E-E")#text(" to “shift” most of the mass of ")#mi("Q")#text(" outside ")#mi("E")#text(", creating the desired contradiction. Apologize for the interruption.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688315")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2025")])]

#text("Dear professor Tao:")

#text("As a good kernel ")#mi("P")#text(" in Exercise 51 is taken to be only non-increasing instead of strictly decreasing, how do we achieve strict lower bound by comparing the integral of ")#mi("P")#text(" with the integral of the dilated horizontal wedding cake function you mentioned earlier?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688318")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2025")])]

#text("Dear professor Tao:")

#text("I managed to show that ")#mi("C_d^{\\prime} = 2^d C_d")#text(" in part (3) of Exercise 51, where ")#mi("C_d")#text(" is the upper bound in part (2), which can further be taken as ")#mi("1/k_d(1 - 2^{-d})")#text(", where ")#mi("k_d")#text(" is the constant in the volume of a ")#mi("d")#text("-dimensional ball. To achieve an upper bound of 1 though, may I ask which part of the bound can still be sharpened?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688330")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2025")])]

#text("Dear professor Tao:")

#text("As to the reason why we can’t simply differentiate the Weierstrass function term by term to illustrate non-differentiability, do we need to come up with an explicit example of a differentiable function with a divergent sum of derivatives?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688348")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2025")])]

#text("Dear professor Tao:")

#text("The proof of Lemma 62 contains a small typo at the end, namely, the plus sign in the sentence “while the right-hand side is ")#mi("F_{-}(b)+F_{+}(a)")#text("” should be a minus sign.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688350")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2025")])]

#text("Also, for Exercise 64, shall we add that the decomposition is unique up to a constant? If not, how to show that the only possible constant difference is zero? Thank you.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688357")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 24 June 2025")])]

#text("Dear professor Tao:")

#text("Actually I believe the original statement for Exercise 64 is correct as it was, as a shifted jump function is not a jump function by Definition 61 (it has to “jump from the ground”).")

#emph[#text("[Changes reverted – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688359")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2025")])]

#text("Dear professor Tao:")

#text("In generalizing to the unbounded case in Exercise 65, do we need to generalize the continuous monotone component to a “locally continuous monotone function” as well? If we apply lemma 62 to an extended version of ")#mi("F")#text(" restricted to ")#mi("[n,n+1]")#text(", the continuous components don’t seem to connect at the endpoints.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688362")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2025")])]

#text("Dear professor Tao:")

#text("On the generalization of Lemma 62 to the unbounded case, if one extends the restriction of ")#mi("F")#text(" to any compact interval ")#mi("[a,b]")#text(" by setting ")#mi("F(x) := F(a)")#text(" for ")#mi("x<a")#text(" and ")#mi("F(x) := b")#text(" for ")#mi("x>b")#text(", then Lemma 62 applies. For the decompositions ")#mi("F_c^n + F_{pp}^n")#text(" thus produced for the intervals ")#mi("[n-1,n]")#text(" with ")#mi("n=1,2, dots")#text(", I was trying to show that the sums ")#mi("\\sum_{n \\in {\\bf Z}} F_c^n 1_(n-1,n]")#text(" and ")#mi("\\sum_{n \\in {\\bf Z}} F_{pp}^n 1_(n-1,n]")#text(" are the desired generalization. But the continuous functions thus produced do not agree at the endpoints of the interval. Can you provide a little hint on a fix for this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688363")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2025")])]

#text("Also, since monotone functions on compact intervals are already bounded, may I ask the reason for the max and min operation to squeeze the function in the discussion below Exercise 65?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688385")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2025")])]

#text("Dear professor Tao:")

#text("In Exercise 73 should we add that ")#mi("F(\\pm \\infty)")#text(" is defined as a limit whose existence is guaranteed by Exercise 70?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688386")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2025")])]

#text("Dear professor Tao: I saw the condition in Exercise 73 now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688414")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2025")])]

#text("Dear professor Tao:")

#text("The word “non-increasing” should be “non-decreasing” in the paragraph below Remark 85.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688418")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2025")])]

#text("Dear professor Tao:")

#text("Is the second half of part (6) of Exercise 87 a restatement of the Lebesgue differentiation theorem, which is proved earlier in the notes?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688421")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2025")])]

#text("Dear professor Tao:")

#text("The proof of Theorem 89 references Exercises 8 and Exercises 11 of Notes 4, which I think should be changed to Exercise 21 and Exercise 24 respectively.")

#emph[#text("[Edited, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688431")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2025")])]

#text("Dear professor Tao: To get part (3) of Exercise 95, it suffices by the Lebesgue differentiation theorem to take ")#mi("E")#text(" to be the set of points ")#mi("x")#text(" where ")#mi("F(x) := \\int_{[a,x]} f(t) dt")#text(" is not differentiable, without including those points which are not a Lebesgue points of ")#mi("f")#text(". Is this correct? Or are we missing a subtle point here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-688432")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2025")])]

#text("Dear professor Tao: Likewise in part (4) I take ")#mi("E")#text(" to be the set of points ")#mi("x")#text(" which are not Lebesgue points of ")#mi("F")#text(", and imitate the proof of Proposition 92 to get the conclusion. Yet the resulting argument only uses the fact that ")#mi("E")#text(" is a null set (due to absolute integrability of ")#mi("F")#text(") without using the definition of Lebesgue point, can you give some clue as to what might be missing here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-689559")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2026")])]

#text("Dr Tao, I don’t know if this is a typo or just I am being stupid: In the hint of Exercise 44, you said the Exercise 8 of Note 1 use dyadic nesting properfy as well but it seems that Exercise 8 don’t need it.")

#emph[#text("[Exercise 8 corrected to Lemma 8 – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-691561")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2026")])]

#text("Dr Tao,")#linebreak()#text(" What does “maximal” means in terms of Hardy-Littlewood maximal inequality?")#linebreak()#text(" Also, Could you provide some intuitive understanding of Hardy-Littlewood maximal inequality? I think the notions are a bit hard for me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-691697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2026")])]

#text("Dear Prof. Tao,")

#text("Mathematicians would use the concept of (open) covers to define concepts like: Lebesgue measure, Heine-Borel theorem, Lebesgue’s number lemma, Vitali covering lemma, Besicovitch covering theorem — although these concepts are not directly related, they all seem to involve ")#emph[#text("covering")]#text(".")

#text("I would like to ask: Why are open covers usefuld and why do so many concepts involve open covers?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-691698")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2026")])]

#text("Open covers interact very nicely with the fundamental notion of ")#emph[#text("compactness")]#text(", as one can see from the topological definition of the term.")

#text("They also tend to capture the notion of ")#emph[#text("locality")]#text(". For instance, if a function is locally bounded, then there is an open cover of the domain such that the function is bounded for each open set in the cover.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-692080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2026")])]

#text("Lebesgue measure and Hausdorff dimension are both defined using open covers, but why do they seem unable to be connected with ")#emph[#text("compactness")]#text(" and ")#emph[#text("locality")]#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-692086")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2026")])]

#text("Many foundational results about Lebesgue measure or Hausdorff dimension do involve these concepts. For instance a fundamental property of Lebesgue measure is ")#link("https://en.wikipedia.org/wiki/Regular_measure")[#text("inner regularity")]#text(". (Hausdorff measure is also inner regular if one restricts to sufficiently nice sets, such as Borel sets.) Any measure theory text (e.g., ")#link("https://terrytao.wordpress.com/books/an-introduction-to-measure-theory/")[#text("my own")]#text(") will contain many more examples of this type.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-691991")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Dr Tao,")

#emph[#text("With a bit more effort, one can construct continuous functions that are in fact nowhere differentiable")]#text(".")

#text("Why does the first example, namely Weierstrass function ∑4^{-n}cos(16^{n}πx), in history take such a form? The expression of this construction looks a bit strange to me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-691992")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("I am ")#link("https://claude.ai/share/65b7c999-af74-443f-ae95-f0c479e4b858")[#text("outsourcing this question to an AI")]#text(". I will note however, that once one is familiar with Fourier analysis, and in particular the idea that any reasonable (periodic) function can be described by a Fourier series, and that differentiation of a Fourier series basically corresponds to multiplying each Fourier coefficient by its frequency, then the construction becomes extremely natural.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-691997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2026")])]

#text("Thank you for your reply! Your additional explanation is more to the point than the AI’s response!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-692008")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Now we can prove the Hardy-Littlewood inequality, which we will do with the constant ")#mi("{C_d := 3^d}")#text(". It suffices to verify the claim with strict inequality,")

#link("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+m%28+%5C%7B+x+%5Cin+%7B%5Cbf+R%7D%5Ed%3A+%5Csup_%7Br%3E0%7D+%5Cfrac%7B1%7D%7Bm%28B%28x%2Cr%29%29%7D+%5Cint_%7BB%28x%2Cr%29%7D+%7Cf%28y%29%7C%5C+dy+%3E+%5Clambda+%5C%7D+%29+%5Cleq+%5Cfrac%7BC_d%7D%7B%5Clambda%7D+%5Cint_%7B%7B%5Cbf+R%7D%5Ed%7D+%7Cf%28t%29%7C%5C+dt&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+m%28+%5C%7B+x+%5Cin+%7B%5Cbf+R%7D%5Ed%3A+%5Csup_%7Br%3E0%7D+%5Cfrac%7B1%7D%7Bm%28B%28x%2Cr%29%29%7D+%5Cint_%7BB%28x%2Cr%29%7D+%7Cf%28y%29%7C%5C+dy+%3E+%5Clambda+%5C%7D+%29+%5Cleq+%5Cfrac%7BC_d%7D%7B%5Clambda%7D+%5Cint_%7B%7B%5Cbf+R%7D%5Ed%7D+%7Cf%28t%29%7C%5C+dt&bg=ffffff&fg=000000&s=0&c=20201002")]
]

#text("Part of the right-hand side of the inequality is missing in the post.")

#emph[#text("[I cannot reproduce (or understand) this issue – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-692016")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2026")])]

#text("I mean that part of the expression is cut off and not displayed in the blog post:")

#link("https://i.postimg.cc/zXj1QQGV/Screenshot-2026-03-16-at-9-01-24-AM.png")[#text("https://i.postimg.cc/zXj1QQGV/Screenshot-2026-03-16-at-9-01-24-AM.png")]

#link("https://i.postimg.cc/7Pt6RbsB/Screenshot-2026-03-16-at-8-56-59-AM.png")[#text("https://i.postimg.cc/7Pt6RbsB/Screenshot-2026-03-16-at-8-56-59-AM.png")]

#emph[#text("[I am unable to reproduce this issue on my own devices; it may be some quirk of HTML rendering and the specific dimensions of your device. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-3/#comment-692017")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2026")])]

#text("Thank you. Opening the image in a new tab shows the full expression. If I move the window to another monitor and then go full screen, it also appears correctly, so it seems to be a rendering issue on my side. Interestingly, when I copy the excerpt directly from the post and paste it into the comment box (as in an earlier comment), the full expression is displayed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-466619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("In Theorem 24, do we have that the converse is actually also true, namely, if the identity")#linebreak()#text(" ")#mi("\\displaystyle \\int_{[a,b]}F^{\\prime}(x)\\ dx=F(b)-F(a)")#text(" makes sense, then ")#mi("F")#text(" must be absolutely continuous on ")#mi("[a,b]")#text("?")

#text("If ")#mi("F:[a,b]\\to\\mathbb{R}")#text(" is differentiable, can we conclude that ")#mi("F")#text(" is absolutely continuous on ")#mi("[a,b]")#text(" so that Proposition 25 is implied by Theorem 24?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-466622")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("Theorem 6 serves as a converse to Theorem 24. Note that just having ")#mi("F^{\\prime}")#text(" well-defined and absolutely integrable and ")#mi("\\int_{[a,b]} F^{\\prime}(x)\\ dx = F(b)-F(a)")#text(" for a single choice of ")#mi("a,b")#text(" is not sufficient (take for instance ")#mi("F")#text(" to be the Cantor function from Exercise 47, but with ")#mi("F(1)")#text(" set equal to 0 rather than 1).")

#text("Incidentally, all of these questions are great exercises to work out yourself; see ")#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")[#text("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-466627")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("Suppose ")#mi("F:[a,b]\\to\\mathbb{R}")#text(" is differentiable. It is true that")#linebreak()#text(" ")#mi("\\displaystyle \\int_{[a,b]}F^{\\prime}(x)\\ dx=F(b)-F(a)")#linebreak()#text(" but not necessarily true that")#linebreak()#text(" ")#mi("\\displaystyle \\int_{[a,x]}F^{\\prime}(x)\\ dx=F(x)-F(a)")#text(" for all ")#mi("x\\in[a,b]")#text(", which implies that ")#mi("F")#text(" is absolutely continuous.")#linebreak()#text(" I guess this is your point. But I don’t have a counterexample for the “not necessarily true” part. Do you have a hint how to find it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-466634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2016")])]

#text("Well, ")#mi("f(x)=\\sin(x^2)")#text(" is not even uniformly continuous on ")#mi("\\mathbb{R}")#text(". And thus it cannot be absolutely continuous. But it is ")#mi("C^\\infty(\\mathbb{R})")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-467678")[#strong[#text("Fonction maximale de Hardy-Littlewood, théorème de différentiation de Lebesgue | Matthieu Joseph")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2016")]

#text("[…] constante n’est pas optimale dans cette inégalité. Terence Tao propose un exercice (l’exercice 19) pour améliorer par , puis il discute ensuite de la […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2016")])]

#text("In Exercise 7, is ")#mi("f(x-y)g(y)")#text(" measurable on ")#mi("\\mathbb{R}^{2d}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2016")])]

#text("In Exercise 7 should ")#mi("f*g")#text(" be well defined for a.e. ")#mi("x")#text(" instead of every ")#mi("x")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468219")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2016")])]

#text("In this case ")#mi("f*g")#text(" can be shown to be well defined for all ")#mi("x")#text(" (the integrand is absolutely integrable).")

#text("Also, the measurability of ")#mi("f(x-y)")#text(" and ")#mi("g(y)")#text(" (and hence of the product) is easily deduced from observing that the composition of a measurable function and a continuous map (or more generally, a measurable map) is again measurable. Here, the maps in question are ")#mi("(x,y) \\mapsto x-y")#text(" and ")#mi("(x,y) \\mapsto y")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468221")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2016")])]

#text("If ")#mi("f")#text(" is Borel measurable, then ")#mi("f\\circ h")#text(" is Lebesgue measurable or Borel measurable whenever ")#mi("h")#text(" is. But we only know that ")#mi("f")#text(" is Lebesgue measurable. How do you conclude that ")#mi("f\\circ h")#text(" is (Lebesgue) measurable where ")#mi("h(x,y)=x-y")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468222")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2016")])]

#text("Continuity of ")#mi("h")#text(" itself is not enough in this issue I suppose? It seems that one need to show directly that ")#mi("h^{-1}(E)")#text(" is Lebesgue measurable whenever ")#mi("E")#text(" is.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468227")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2016")])]

#text("Fair enough; the map ")#mi("h: {\\bf R} \\mapsto {\\bf R}^2")#text(" defined by ")#mi("h(x) := (x,0)")#text(" is continuous but the preimage of the null set ")#mi("E \\times \\{0\\}")#text(" is nonmeasurable for any nonmeasurable ")#mi("E \\subset {\\bf R}")#text(". But in this particular case one can check that the preimage of a set of zero outer measure is again of zero outer measure, so null sets pull back to null sets. Since Lebesgue measurable sets differ by a null set from a Borel measurable set, the claim for Lebesgue sets then follows from the corresponding claim for Borel sets.")

#text("One can also use Exercise 21, 22 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468409")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2016")])]

#text("In Stein and Shakarchi, ")#mi("g")#text(" is assumed to be integrable on ")#mi("\\mathbb{R}^d")#text(" (so is ")#mi("f")#text(") and the conclusion is that ")#mi("f*g")#text(" is well defined for a.e. ")#mi("x")#text(". Do you have a hint that why one cannot have ")#mi("f*g")#text(" being well defined for all ")#mi("x")#text(" in that case? Is there a counterexample showing what could go wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2016")])]

#text("Consider for instance ")#mi("f*g(0) = \\int_{{\\bf R}^d} f(x) g(-x)\\ dx")#text(". The Cauchy-Schwarz inequality tells us that this integral is well-defined when ")#mi("f, g")#text(" are square-integrable, but when ")#mi("f,g")#text(" are merely integrable then this integral may be divergent (e.g. consider the case ")#mi("d=1")#text(" and ")#tao-math("f(x) = g(x) = \\frac{1}{\\left|x\\right|^{1/2}} 1_{\\left|x\\right| \\leq 1}", block: false)#text(").")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous2")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468426")[#strong[#text("Anonymous2")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2016")])]

#text("I read through notes 1 up to this note but I can’t find a useful statement to show that ")#mi("f*g")#text(" is well-defined for a.e. ")#mi("x")#text(" if one only assumes that ")#mi("f,g")#text(" are merely integrable… The comment above seems to suggest that this is unlikely true?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468434")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2016")])]

#text("If ")#mi("f, g: {\\bf R}^d \\to {\\bf C}")#text(" are absolutely integrable, then by the Fubini-Tonelli theorem, ")#mi("f(y) g(x-y)")#text(" is absolutely integrable on ")#mi("{\\bf R}^d \\times {\\bf R}^d")#text(", which by further application of Fubini-Tonelli shows that ")#mi("f(y) g(x-y)")#text(" is absolutely integrable in ")#mi("y")#text(" for almost every ")#mi("x")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468270")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2016")])]

#text("“But in this particular case one can check that the preimage of a set of zero outer measure is again of zero outer measure”")

#text("Would you elaborate how this is done? (What’s more, why did you use “outer measure” instead of “Lebesgue measure”?)")

#text("(Trying to prove by contradiction seems also difficult: Let ")#mi("h:\\mathbb{R}^{2}\\to\\mathbb{R}")#text(" with ")#mi("h(x,y)=x-y")#text(". Suppose ")#mi("E")#text(" is a subset of ")#mi("\\mathbb{R}^2")#text(" with positive Lebesgue measure. How can I show that ")#mi("h(E)")#text(" can not have measure zero?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2016")])]

#text("One needs to use outer measure initially because one does not know ")#emph[#text("a priori")]#text(" that the preimage is measurable.")

#text("A warmup question would be to show that if ")#mi("E \\subset {\\bf R}")#text(" has zero outer measure, then the set ")#mi("E \\times [0,1] \\subset {\\bf R}^2")#text(" has zero outer measure; using the countable subadditivity of outer measure, this implies that ")#mi("E \\times {\\bf R} \\subset {\\bf R}^2")#text(" also has outer measure. This gives the claim for ")#mi("h(x,y) = x")#text("; the case of ")#mi("h(x,y) = x-y")#text(" is similar.")

#text("As I said in my previous post, these claims are special cases of Exercises 21 and 22 of ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("Notes 1")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("Regarding the concept “good kernels” in Exercise 27, Stein and Shakarchi give two sets of conditions.")

#text("One is")#linebreak()#text(" (1) ")#mi("\\int_{\\mathbb{R}^d} K_\\delta(x)\\ dx=1")#linebreak()#text(" (2) ")#mi("\\int_{\\mathbb{R}^d} |K_\\delta(x)|\\ dx\\leq A")#linebreak()#text(" (3) For every ")#mi("\\eta>0")#text(", ")#tao-math("\\int_{\\left|x\\right|\\geq\\eta} |K_\\delta(x)|\\ dx\\to 0", block: false)#text(" as ")#mi("\\delta\\to 0")

#text("Another one is")#linebreak()#text(" (1) ")#mi("\\int_{\\mathbb{R}^d} K_\\delta(x)\\ dx=1")#linebreak()#text(" (2′) ")#tao-math("\\left|K_\\delta(x)\\right|\\leq A\\delta^{-d}", block: false)#linebreak()#text(" (3′) ")#tao-math("\\left|K_\\delta(x)\\right|\\leq A\\delta/\\left|x\\right|^{d+1}", block: false)#text(" for all ")#mi("\\delta>0")#text(" and ")#mi("x")#text(".")

#text("You also give a set of condition in Exercise 27.")

#text("(1)and has total mass ")#mi("{\\int_{{\\bf R}^d} P(x)\\ dx}")#text(" equal to ")#mi("{1}")#text(".")#linebreak()#text(" (2″)non-negative,")#linebreak()#text(" (3″) radial,")#linebreak()#text(" (4″) radially non-increasing,")

#text("Other than the “total mass equals to 1”, are other conditions in each set related to each other? In practice, how does one choose which set of conditions to use?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468550")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2016")])]

#text("Basically it depends on the application. In analysis there often is not a “one-size-fits-all” definition for a given concept (such as a “good kernel”), one often has to tailor the precise axioms for the need at hand, strengthening them if this will help prove other theorems, or weakening them if this helps find instances of the concept. For the purpose of an introductory course, one often does not strive for the most general statement one can make in these directions, but instead focuses on a simple illustrative case, even if this means that the axioms are unnecessarily strong or the conclusion unnecessarily weak.")

#text("This is in contrast with the more algebraic areas of mathematics, in which there often are natural and canonical definitions for key concepts; cf. Gowers’ ")#link("https://www.dpmms.cam.ac.uk/~wtg10/2cultures.pdf")[#text("“Two cultures of mathematics”")]#text(" essay.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47875c483f388b537f41ded3fab4d0f8be2e2ff8bbd9dcb11c6daec5b0775b6a-df50f27e9f6812ef3b868570250a9e1fbed90898122176ef0b04d0f805a32ace.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468900")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#text("Dear Terry,")

#text("in the proof of Lemma 18.2 you use this nice map. You choose for each jump at ")#mi("x")#text(" a rational number ")#mi("q_x")#text(" which lies between the left and right limit. Do you use the axiom of choice to do this?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-468908")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2016")])]

#text("One does not need the axiom of choice for this, as it is possible to place an explicit well-ordering on the rationals which can be used to create a choice function.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50e5f1f8109cc87a6a3394a68e11c763b6092dcb32a39c8ede2899c1d295ac7-43b5289b51f93c075c052b51197fc2a7f761321fdc8daaea8bbb8d7f7c9c8bdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunting")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-470790")[#strong[#text("Sunting")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("dear prof. tao. i am wondering whether the rising sun lemma could be true when it is defined on R. i.e.,")#linebreak()#text(" for any continuous F:R->R;")#linebreak()#text(" then we could find at most countable famility of disjoint non-empty open intervals.In=(an,bn);such that:")#linebreak()#text(" 1)for each n, F(an)=F(bn);")#linebreak()#text(" 2)for any x not belonging to any of In. then we have F(y)<=F(x)for any x<=y;")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c50e5f1f8109cc87a6a3394a68e11c763b6092dcb32a39c8ede2899c1d295ac7-43b5289b51f93c075c052b51197fc2a7f761321fdc8daaea8bbb8d7f7c9c8bdf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sunting")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-470791")[#strong[#text("Sunting")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("sorry , i may be wrong . it seems this lemma dont admit In=(-inf,a) or In=(a,inf);")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 246A, Notes 2: complex integration | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-472640")[#strong[#text("246A, Notes 2: complex integration | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2016")])]

#text("[…] variants of the above integrals (e.g. the Henstock-Kurzweil integral, discussed for instance in this previous post), which can handle slightly different classes of functions and have slightly different properties […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-474806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2016")])]

#text("In Theorem 6, do we have more information regarding the ")#mi("x")#text(" such that ")#mi("F^{\\prime}(x)=f(x)")#text(". For instance, do we a characterization of such ")#mi("x")#text("? Suppose ")#mi("f")#text(" is continuous at ")#mi("x=a")#text(". Can we conclude that ")#mi("F^{\\prime}(a)=f(a)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-474817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#mi("F^{\\prime}(x) = f(x)")#text(" holds whenever ")#mi("x")#text(" is a Lebesgue point of ")#mi("f")#text(" (see e.g. the Wikipedia articles on Lebesgue points and Lebesgue differentiation theorem). Note that each continuity point of ")#mi("f")#text(" is a Lebesgue point of ")#mi("f")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475181")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2016")])]

#text("Terry, in exercise 9 part 1, you say to show that ")#mi("f^{-1}(z+D)")#text(" has positive measure for some z. I get the feeling that this is supposed to be simple but I’m stuck here.")

#text("I was able to show that it this weren’t the case, then there would be a null set (in ")#mi("R^d")#text(") that maps to the entire complex plane, but I’m not sure that leads to a contradiction. Can you give a hint?")

#emph[#text("[If ")#mi("f^{-1}(z + D)")#text(" is null for every ")#mi("z")#text(", then one should be able to show that all of ")#mi("{\\bf R}^d")#text(" is null by expressing the latter set as a countable union of sets of the former type. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475206")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2016")])]

#text("That did it. Thanks T!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475240")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2016")])]

#text("There are so many inequalities you labeled as “Hardy-Littlewood”. Did they actually give all of them mentioned here?")

#text("Besides, in “Just as the integration theory of unsigned functions can be used to develop the integration theory of the absolutely ")#emph[#text("convergent ")]#text("functions”, I think you mean “absolutely integrable functions”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475261")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("Thanks for the correction. All the one-dimensional Hardy-Littlewood inequalities stated here are essentially in the original ")#link("http://kryakin.org/files/H_L_Acta_1931.pdf")[#text("1931 paper of Hardy and Littlewood")]#text(", although the notation is somewhat different. The higher-dimensional generalisations of the Hardy-Littlewood inequality first appear I believe in a ")#link("http://projecteuclid.org/euclid.dmj/1077491072")[#text("1939 paper of Wiener")]#text(", so strictly speaking it should be referred to as a maximal inequality of Hardy-Littlewood type.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475241")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2016")])]

#text("Is the converse of Corollary 21 also true so that we have a characterization of differentiable almost every where functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475263")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("No, for instance ")#mi("\\sin(\\frac{1}{x})")#text(" is differentiable almost everywhere on the real line (after assigning some arbitrary value to ")#mi("x=0")#text(") but has infinite variation; another class of examples would be functions that are locally constant outside of a Cantor set, but whose values on each connected component of the complement of the Cantor set are set to arbitrary values unrelated to each other. I would imagine that there is no particularly useful characterisation of the entire class of almost everywhere differentiable functions other than the tautological one of being differentiable outside of a set of measure zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475246")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2016")])]

#text("What is the relation between bounded variation and integrability on a compact interval?")

#emph[#text("[The fundamental theorems of calculus identify the absolutely continuous functions as the antiderivatives of the integrable functions, and the absolutely continuous functions are a subclass of the bounded variation functions. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475269")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("Sorry for the confusion. I was going to ask what is the relation between bounded variation and integrability ")#emph[#text("of a function")]#text(" on a compact interval.")

#text("Say ")#mi("f:[a,b]\\to\\mathbb{R}")#text(". Is there any relation between the integrability (being absolutely integrable or not) of ")#mi("f")#text(" on $[a,b]$ and the “bounded variationess” of ")#mi("f")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("A “d” is missing in the statement of Theorem 12.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475278")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("Functions of bounded variation are bounded and measurable, hence integrable. On the other hand, the converse statements are very far from being true; functions of bounded variation have roughly one degree of regularity, functions that are merely integrable have none.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476031")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2017")])]

#text("All the dumb questions I asked here are for doing the exercise in Stein-Shakarchi:")

#text("Let ")#mi("a,b>0")#text(" and $f:[0,1]\\to\\mathbb{R}$ be defined with ")#mi("f(x)=x^a\\sin(x^{-b})")#text(" for ")#mi("x\\in(0,1]")#text(" and ")#mi("f(0)=0")#text(". Show that ")#mi("f")#text(" is BV if and only if $a>b$.")

#text("When ")#mi("a>b>0")#text(", all I can find is")#linebreak()#text(" $f’\\in L^1([0,1])$. I really don’t know if I can conclude that ")#mi("f")#text(" is BV due to the possible bad behavior at ")#mi("x=0")#text(" since ")#mi("f")#text(" does not necessarily have a derivative there.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475984")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2017")])]

#text("This is a related “dumb question” that I don’t know how to answer. Consider ")#mi("f:[a,b]\\to\\mathbb{R}")#text(". (1)Suppose ")#mi("f")#text(" is BV on ")#mi("[a,b]")#text(". Then one has ")#mi("f")#text(" is differentiable a.e.. Can one say further that ")#mi("f^{\\prime}\\in L^1([a,b])")#text("? (2) One the other hand, if ")#mi("f^{\\prime}\\in L^1([a,b])")#text(" (assuming ")#mi("f^{\\prime}")#text(" exists a.e.), can one conclude that ")#mi("f")#text(" is BV on $[a,b]$?")

#text("I can only answer this question when ")#mi("f")#text(" is absolutely continuous, which can be done by Exercise 38.")

#emph[#text("[For (1), combine Proposition 20 with Proposition 22. for (2), see my comment from 26 Dec 10:47am. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2017")])]

#text("Thanks for the comment. For (2) I think the example ")#mi("\\sin\\left(\\frac{1}{x}\\right)")#text(" on ")#mi("[0,1]")#text(" does not work since the derivative ")#mi("\\cos\\left(\\frac{1}{x}\\right)")#text(" is not ")#mi("L^1")#text(" on ")#mi("[0,1]")#text(" and you are referring to the Cantor-function-like function actually?")

#text("One can at least now say that (i)being differentiable a.e. on ")#mi("[a,b]")#text(" and (ii)the derivative ")#mi("f^{\\prime}\\in L^1([a,b])")#text(" are ")#emph[#text("necessary")]#text(" for ")#mi("f")#text(" being BV on ")#mi("[a,b]")#text(" but far less than ")#emph[#text("sufficient")]#text(" due to the existence of counterexamples (the Cantor-function-like function?).")

#text("What if one makes the exceptional set for (i) smaller: ")#mi("f:[a,b]\\to\\mathbb{R}")#text(" is differentiable everywhere on ")#mi("[a,b]")#text(" except at one point (or finitely many points even countably many)?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2017")])]

#text("I’m trying to use Exercise 36. Does one have")

#tao-math("\\displaystyle \\left\\|F\\right\\|_{TV[a,b]}=\\lim_{\\epsilon\\to0+}\\left\\|F\\right\\|_{TV[a+\\epsilon,b]}?", block: false)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476029")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2017")])]

#text("And of course one should also assume that ")#mi("F")#text(" is continuous.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("In exercise 28, Weierstrass function is represented by a lacunary Fourier series. Is it necessary for any such example (periodic, continuous and non-differentiable everywhere) to have a lacunary Fourier series representation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475279")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("No. For instance, one can show that non-differentiable everywhere periodic functions are a comeager subset of the class of continuous periodic functions, whereas the lacunary Fourier series are a meager set.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475275")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2016")])]

#text("Due to my ignorance, I found the proof of the differentiation theorem (between Lemma 9 and Lemma10) hard to follow while the counterpart in Stein-Shakarchi (p105) seems to be very clear. (I like your comment about the “density argument” a lot. But I feel very stupid and frustrated that I didn’t figure out how the density argument is made.) Am I missing something that makes the difficulties of reading this particular proof? It seems that the style of writing here is sort of improvising, which is rather different from your advice on writing(")#link("https://terrytao.wordpress.com/advice-on-writing-papers/")[#text("https://terrytao.wordpress.com/advice-on-writing-papers/")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475598")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2016")])]

#text("I stared at the definition of Dini derivatives and wanted to try some nontrivial examples but I couldn’t figure out a way. Let ")#mi("f(x)=x\\sin\\frac{1}{x}")#text(" for ")#mi("x\\neq 0")#text(" and ")#mi("f(0)=0")#text(". Would you give an example for how to calculate one of the four Dini derivatives?")

#text("In general, is there a systematic way to calculate the Dini derivatives at the point where the given function is not differentiable?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-475599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2016")])]

#text("Would you elaborate the hint for Exercise 30? What does it mean by ")#mi("h")#text(" ranges over a countable set and how it would be useful?")

#emph[#text("[Countable unions or intersections of measurable sets stay measurable, whereas uncountable unions or intersections do not. A naive description of the level set of a Dini derivative, e.g. ")#mi("\\{ x: \\overline{{\\mathcal D}_+}F(x) > \\lambda\\}")#text(", will involve an uncountable union or intersection because ")#mi("h")#text(" ranges over the set of positive reals, which is an uncountable set. If one can somehow restrict the range of ")#mi("h")#text(" to a countable set (e.g. the set of positive rationals), then this problem goes away. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476695")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2017")])]

#text("Exercise 28 (proving the Weierstrass function is nowhere differentiable — the continuous part was easy for me) is really giving me trouble. Following your hint, I computed ")#mi("F(\\frac{j+1}{8^k})")#text(" and ")#mi("F(\\frac{j}{8^k})")#text(" (I switched to using k as an index so we’re not using n twice) and found that they can both be expressed as a sum of ")#mi("k-1")#text(" terms instead of an infinite series.")

#text("Then when I subtract them, I can use the “difference of sines” formula, but that’s where I get stuck:")

#mi("F(\\frac{j+1}{8^k}) - F(\\frac{j}{8^k}) = \\sum_{n=1}^{k-1} 4^{-n}\\cdot 2\\cdot sin(8^{n-k} \\pi /2) \\cdot cos \\left(8^{n-k} \\pi (j+\\frac{1}{2})\\right)")

#text("I don’t see any way to bound this from below (in absolute value).")

#text("I know this seems like a basic analysis problem and it wasn’t really the point of this whole chapter, but I really want to figure it out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2017")])]

#text("Hmm, actually the hint would fit the problem better if the exercise used cosines rather than sines, so that there is an ")#mi("n=k")#text(" term that easily dominates the rest of the sum. I’ll change the exercise accordingly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476718")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2017")])]

#text("Thanks, Terry! That’s better. (You swapped an m and n in part 2 though.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/876002add30560f940245cae4f30f17b114fdcdc4a38dd2376fb43fc126a5676-c0191bc3e413c578697ed69e4ce226e1554120ca9a16963771b4734a49c2bf64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of coupon_clipper")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-476719")[#strong[#text("coupon_clipper")]]#text(size: 9pt, fill: rgb("596477"), " · 12 January 2017")])]

#text("Also, it’s exercise 52 in case anyone else is reading along. I’m not sure where I got 28 from.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/804e766c0204f6282ea907613f70e43886552180d903afccd2d1ba6668d2d25a-990153b8a055dc2c9421c8de4637ff8137a0d74f63e9aef767515ae22cab422f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-480186")[#strong[#text("Pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2017")])]

#text("Thanks Tao for this lectures.")

#text("Maybe i don’t understand the formulation of the Besicovitch covering lemma :")#linebreak()#text(" If i take (0,1),(-1,2/3),(1/3,2), there is no subfamily with the same union and 1/2 will always be in 3 intervals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/804e766c0204f6282ea907613f70e43886552180d903afccd2d1ba6668d2d25a-990153b8a055dc2c9421c8de4637ff8137a0d74f63e9aef767515ae22cab422f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-480187")[#strong[#text("Pierre")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2017")])]

#text("All wrong, sorry")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-485266")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2017")])]

#text("A small typo:")

#text("In the proof of Proposition 19:")

#text("Applying (4), we conclude that")#linebreak()#text(" …")#linebreak()#text(" which we rearrange as")

#text("the next line there is an extra ")#mi("h")#text(" before the first ")#mi("(x)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-485267")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2017")])]

#text("At the end of the proof of Lebesgue differentiation theorem (just above lemma 26), is it necessary that ")#mi("\\lambda")#text(" go to zero along a COUNTABLE sequence?")

#emph[#text("[This is because there is a measure zero exceptional set of ")#mi("x")#text(" for each ")#mi("\\lambda")#text(". In order to ensure that the union of these exceptional sets remains of measure zero, one needs to use only countably many ")#mi("\\lambda")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-485310")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("Small typo in several places in section 2:")

#mi("\\int_\\mathbf{R}")#text(" should be ")#mi("\\int_{\\mathbf{R}^d}")#text(".")

#text("If I’m correct, these places are:")

#text("RHS of the line below Theorem 36 (Hardy-Littlewood maximal inequality)")#linebreak()#text(" RHS of the line below “It suffices to verify the claim with strict inequality”")#linebreak()#text(" RHS of the line below “By inner regularity, it suffices to show that”")#linebreak()#text(" RHS of he line below “establish the dyadic Hardy-Littlewood maximal inequality”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-485373")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2017")])]

#text("Small typos:")

#text("3rd lines above Remark 60:")#linebreak()#text(" ")#mi("m(E_{r,R})")#text(" should be ")#mi("m(E_{r,R} \\cap [a,b])")#text(".")

#text("In the proof of Lemma 62:")

#text("As discussed previously, ")#mi("G")#text(" is discontinuous only at ")#mi("A")

#text("should be")

#text("As discussed previously, ")#mi("F")#text(" is discontinuous only at ")#mi("A")

#text("since there is no ")#mi("G")#text(" in the context.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32065b81c16f187944d8c30e760cd8d517709c8ac8b7fd61fc96b9e15e310ac3-26bbdb9819ad9c35bc05f817557b45172536330a2f6cd94c8a4ec0de03846620.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A short proof of the Hardy-Littlewood maximal inequality | George Shakan")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-499086")[#strong[#text("A short proof of the Hardy-Littlewood maximal inequality | George Shakan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2018")])]

#text("[…] Incidentally his proof gives the better constant , though this is well known, see for instance exercise 42 in these notes of Tao. One cute related geometric question is can one improve the constant in Vitali’s covering lemma […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Local well-posedness of the Navier-Stokes equations | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-504913")[#strong[#text("254A, Notes 1: Local well-posedness of the Navier-Stokes equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2018")])]

#text("[…] Exercise 2 Relax the hypotheses of continuity on to that of being measurable and bounded on compact intervals. (You will need tools such as the fundamental theorem of calculus for absolutely continuous or Lipschitz functions, covered for instance in this previous set of notes.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/208d72953b04ee9dd0db1d2f25c79e0ffcf9dc2e90a71bf8a284c8930159f009-73f461da239b467b42738f433649f27130857ce293096d2f47b26629a59dfe62.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alan Chang")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-504971")[#strong[#text("Alan Chang")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2018")])]

#text("In Definition 66 (Bounded variation) and a few places afterwards, F(x_{i+1}) should be F(x_{i-1}).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516939")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("I don’t quite understand the conclusion of Theorem 11:")

#text("Then the Riemann integral ")#mi("{\\int_a^b F^{\\prime}(x)\\ dx} of {F^{\\prime}}")#text(" is equal to ")#mi("{F(b) - F(a)}")#text(". In particular, we have ")#mi("{\\int_a^b F^{\\prime}(x)\\ dx = F(b)-F(a)}")#text(" whenever ")#mi("{F}")#text(" is continuously differentiable.")

#text("Aren’t the following talking about the same things?")

#text("– the Riemann integral ")#mi("{\\int_a^b F^{\\prime}(x)\\ dx} of {F^{\\prime}}")#text(" is equal to ")#mi("{F(b) - F(a)}")

#text("– ")#mi("{\\int_a^b F^{\\prime}(x)\\ dx = F(b)-F(a)}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Yes, the second claim is a particular case of the first (continuously differentiable functions have a derivative that is Riemann integrable).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516940")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Is there a relation between Theorem 89 and Proposition 92? It seems that the hypothesis of Prop 92:")

#text("… let ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" be a differentiable function, such that ")#mi("{F^{\\prime}}")#text(" is absolutely integrable.")

#text("implies that of Theorem 89, namely ")#mi("F")#text(" is absolutely continuous, doesn’t it? If true, then Proposition 92 seems a bit redundant. (I may misunderstand the purpose of Theorem 89 though.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516945")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("It is true that an everywhere differentiable function with absolutely integrable derivative is absolutely continuous, but to prove this one has to ")#emph[#text("use")]#text(" Proposition 92 (together with Exercise 87.6). Note that Proposition 92 is a little subtle because it is not true if the function is merely assumed to be differentiable almost everywhere instead of differentiable everywhere, even when the function is continuous, as the example of the Devil’s staircase function illustrates.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516950")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Regarding Definition 86, is “absolute continuity” a global concept (like “uniform continuity on an interval”) or a local one (like “continuity” at a point)?")

#text("In Exercise 87:")

#text("Show that every absolutely continuous function is of bounded variation on every compact interval ")#mi("{[a,b]}")#text(".")

#text("Should one understand “absolute continuity” as on ")#mi("\\mathbf{R}")#text(" or on ")#mi("[a,b]")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516959")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("The property of being absolutely continuous is localisable, in the sense that if a function is absolutely continuous on an interval (or real line) latex I$, then its restriction to a subinterval $J$ will also be absolutely continuous, and conversely if $I$ is partitioned into subintervals and a function is absolutely continuous on each subinterval (and continuous at the endpoints of the subintervals) then it will be absolutely continuous on the entire domain. However, it is not a pointwise property: there is no meaningful notion of a function being “absolutely continuous at a point”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516952")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("Lemma 62.3 and the Lebesgue decomposition theorem in the linked notes are both a sort of “decomposition” and they both have the concept of “absolute continuity” in the statement.")

#text("But in the former decomposition ")#mi("F=F_c+F_{pp}")#text(", “absolute continuity” appears implicitly in the assumption while the later one ")#mi("\\mu = \\mu_{ac} + \\mu_s")#text(" has “absolute continuity” in the conclusion.")

#text("Would you elaborate how Lemma 62.3 fits in the Lebesgue decomposition theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-516960")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2019")])]

#text("The Lebesgue-Stieltjes measure ")#mi("dF")#text(" associated to a monotone function ")#mi("F")#text(" need not be absolutely continuous; it can have both absolutely continuous and singular components. The singular component in turn splits into a singular continuous component and a pure point component. The function ")#mi("F_c")#text(" is the cumulative distribution function of the sum of the absolutely continuous and singular continuous components, and ")#mi("F_{pp}")#text(" is the cumulative distribution function of the pure point component.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-524914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2019")])]

#text("Stein said without proofs at the beginning of his singular integral book that it is a “simple” observation that the maximal function satisfies ")#tao-math("Mf(x)\\ge c\\left|x\\right|^{-n}", block: false)#text(". I searched around the book without finding anything to prove it. I believe it relates to this set of notes. How can one do that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-524921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2019")])]

#text("If ")#mi("f(x)")#text(" is identically zero, this inequality is clearly false for any ")#mi("c > 0")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-524944")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2019")])]

#text("The assumption on ")#mi("f")#text(" is of course that ")#mi("f")#text(" is not identically zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-525091")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2019")])]

#text("For any ")#mi("R > 0")#text(" and ")#tao-math("\\left|x\\right| \\geq 1", block: false)#text(" one has")

#tao-math("\\displaystyle Mf(x) \\geq \\frac{1}{m(B(x,\\left|x\\right|+R)} \\int_{B(x,\\left|x\\right|+R)} |f(y)|\\ dy", block: false)

#tao-math("\\displaystyle\\geq \\frac{c}{(\\left|x\\right|+R)^n} \\int_{B(0,R)} |f(y)|\\ dy \\geq \\frac{c^{\\prime}}{\\left|x\\right|^n}", block: false)

#text("for some ")#mi("c^{\\prime}>0")#text(" depending on ")#mi("R, f")#text(", as long as ")#mi("R")#text(" is chosen so that ")#mi("\\int_{B(0,R)} |f(y)|\\ dy")#text(" is non-zero, which is possible to do for any non-trivial ")#mi("f")#text(" (which is part of the hypotheses in the remark in Stein’s book on pages 5-6, as is the constraint ")#tao-math("\\left|x\\right| \\geq 1", block: false)#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-525112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2019")])]

#text("It seems that it is possible to make ")#mi("c^{\\prime}")#text(" dependent only on ")#mi("f")#text(" if the inequality is required to hold only for sufficiently large ")#tao-math("\\left|x\\right|", block: false)#text(" (where the “sufficiently large” threshold is dependent only on ")#mi("f")#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-525408")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2019")])]

#text("The existence of ")#mi("R")#text(" can be derived by looking at the contrapositive of the statement: if ")#mi("\\int_{B(0,R)} |f(y)|\\ dy=0")#text(" for all ")#mi("R")#text(", then one must have ")#tao-math("\\int \\left|f\\right|=0", block: false)#text(" by the monotone convergence theorem. Is there any “constructive” proof showing what that ")#mi("R")#text(" should at least be?")

#text("If one considers the set ")#mi("E=\\{x:f(x)\\neq 0\\}")#text(", then ")#mi("B(0,R)")#text(" should contain a “large portion” of ")#mi("E")#text(". If ")#mi("E")#text(" is bounded, then this is trivial.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-525414")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2019")])]

#text("Perhaps it is clarifying to look at a simpler discrete analogue of this question. It is tautological that if a sequence ")#mi("a_1,a_2,\\dots")#text(" is not identically zero, then there exists an ")#mi("n")#text(" such that ")#mi("a_n \\neq 0")#text("; this is a discrete analogue of the assertion that if a function ")#mi("f: {\\bf R}^d \\to {\\bf R}")#text(" is not identically zero a.e., then there is an ")#mi("R")#text(" such that ")#tao-math("\\int_{B(0,R)} \\left|f\\right| \\neq 0", block: false)#text(". However, in both cases there is no bound on the quantity ")#mi("n")#text(" or ")#mi("R")#text(". One explanation for this is that the key hypothesis of being “not identically zero” is an open condition, rather than a closed condition, and in particular is certainly not a compact condition. So one does not expect to have any uniform bound on conclusions that rely on such an open condition. (Compare for instance the assertion that if a real number ")#mi("x")#text(" is non-zero, then its reciprocal ")#mi("1/x")#text(" is finite. This assertion is trivial but one has no uniform bound on the magnitude of ")#mi("1/x")#text(" because the hypothesis of being non-zero is open. If instead we replaced that hypothesis with a closed condition like ")#tao-math("\\left|x\\right| \\geq \\varepsilon", block: false)#text(" then one can now obtain a uniform bound.)")

#text("So if one somehow upgrades the hypothesis of being not identically zero to something more quantitative (and closed), then there is a chance of getting a usable bound. For instance if one has some lower bound on ")#tao-math("\\left|a_n\\right|", block: false)#text(" or ")#tao-math("\\left|f(x)\\right|", block: false)#text(" that becomes positive when ")#mi("n")#text(" or ")#mi("x")#text(" is large enough then this would bound the quantity ")#mi("n")#text(" or ")#mi("R")#text(" in the previous conclusions.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-525522")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2019")])]

#text("Is there a precise definition for the concept “open condition” ?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-526174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2019")])]

#text("In Stein-Shakarchi, the maximal function is defined as")

#mi("f^*(x)=\\sup_{x\\in B}\\frac{1}{m(B)}\\int_B|f(y)|\\,dy")

#text("I believe this is equivalent to the one given in this set of notes. Is it simply a matter of taste? Or does the flexibility of balls (not necessarily centered at ")#mi("x")#text(") in the above definition make any argument related to maximal functions easier in practice?")

#text("Stein’s book on singular integrals has the same version of maximal functions as the one here. I am wondering if there is any technical reason that he changed the definition to a different one. (Also a different version of the covering lemma was used there with the constant ")#mi("5^d")#text(" instead of ")#mi("3^d")#text(". I’m curious who in history gave this slight improvement.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-526182")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2019")])]

#text("This is the non-centered version of the maximal function. Hardy-littlewood maximal function is the centered one. The two versions are clearly equivalent since the centered maximal function is upper bounded by the non-centered one which in turn is upper bounded by ")#mi("2^d")#text(" times the centered one (by doubling the ball radius)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-559712")[#strong[#text("247B, Notes 4: almost everywhere convergence of Fourier series | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 May 2020")])]

#text("[…] established with the assistance of the Hardy-Littlewood maximal inequality; see for instance this previous blog post. A remarkable observation of Stein, known as Stein’s maximal principle, allows one to reverse […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f9f358d77988365b9375984accefe3e5ea5d8805c2ef8800ecd56582b303951-ed0504cdbde2575d6cf1058852dde69a9c06f87ae3a1185cc9fa6a060384383c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zijin Liu")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-581194")[#strong[#text("Zijin Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2020")])]

#text("In exercise 42, do you mean using sub-collection constructed in Vitali Covering lemma to cover the compact set K (with two times radius)? I have been stuck for a couple of days, could you provide some further hints?")

#text("Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-581277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2020")])]

#text("Basically yes, except that one has to use ")#mi("2+\\varepsilon")#text(" times the radius rather than twice the radius; also one has to use compactness more efficiently to make ")#mi("K")#text(" covered by the ")#mi("\\varepsilon B_j")#text(" rather than by ")#mi("B_j")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f9f358d77988365b9375984accefe3e5ea5d8805c2ef8800ecd56582b303951-ed0504cdbde2575d6cf1058852dde69a9c06f87ae3a1185cc9fa6a060384383c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zijin Liu")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-583106")[#strong[#text("Zijin Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2020")])]

#text("Dear Professor Tao,")

#text("In exercise 58, I was trying to use Vitali-type covering lemma to modify the proof of Theorem 36. But I can only get an h_x for each x, such that [F(x+h_x)-F(x)/h_x]>λ, and (x,x+h_x) may not form an open cover, since it is not centered at x. Could you provide some hint to solve this issue?")

#text("Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-583834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2020")])]

#text("One can create an epsilon of room here and enlarge each ")#mi("(x,x+h_x)")#text(" by a tiny amount to generate an open cover without degrading the lower bound on the difference quotient by too much, and then take limits at the end of the argument to remove the loss.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-622548")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2021")])]

#text("For solving Exercise 16, I think one can use Fubini’s theorem: we have ")#mi("F(x) = \\lim_{ n \\to \\infty } \\int_{-n}^{x} f(t) dt")#text(" and so taking one more limit as ")#mi("x \\to y")#text(" and then interchanging the limits (thanks to Fubini’s theorem, since both of these exists and the integrand is absolutely integrable), the claim follows.")

#text("Is there a way to avoid using Fubini’s theorem (something which is easier than proof of Fubini’s theorem for instance).")

#emph[#text("[Dominated convergence works just fine here – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1592a3aa4ba27a63c787cf6c1fe6abfb8f7cf32a2576d5d1ad38c0466bd17d81-08bc19b2e8c9530ed4158232ad053ea992c3f8534539e0ee859450484e2dd4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N is a number")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-622618")[#strong[#text("N is a number")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2021")])]

#text("It can also be proved using density argument along the lines of proof of Proposition 19.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18cefad0750f9cee30c24966f2668c3334a909ce302173e43d2aab8320c63b7f-a6e70e9d7df5095256810a0319007c30e49b320db8fadf03f753d6483ff37b52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of khaledalekasir")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-652346")[#strong[#text("khaledalekasir")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2022")])]

#text("Hi prof. Tao")#linebreak()#text(" I was trying to specify elements of “density argument” for proof given for second fundamental theorem of calculus.")#linebreak()#text(" Firs of all theorem is proven for continuous monotone case, but you`ve mentioned : “space of continuous monotone functions are not sufficiently dense in the space of all monotone functions in the relevant sense(you have mentioned this as total variation sense)”.")#linebreak()#text(" I`m still having trouble understanding meaning of “sufficiently dense” and “relevant sense”.")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-676988")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2023")])]

#text("Dear Professor Tao:")#linebreak()#text(" For Exercise ")#mi("29")#text("(Two-sided Hard-Littlewood), can we simply use the One-sided Hardy-Littlewood inequality on the reflected function ")#mi("x \\rightarrow f(-x)")

#emph[#text("[Yes, this (and the triangle inequality) will solve the problem. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677348")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2023")])]

#text("Thank you professor. Also, for Exercise ")#mi("31")#text(", in applying the rising sun lemma to the function ")#mi("F(x) = \\int_{[a, x]}f(t)\\ dt - \\lambda(x - a)")#text(", I was trying to show that the case ")#mi("a_n = a")#text(" and ")#mi("F(b_n) > F(a_n)")#text(" is impossible when ")#mi("\\lambda > 0")#text(" (so we can have ")#mi("\\int_{I_n}f(t)\\ dt = \\lambda(b_n - a_n)")#text(" for all ")#mi("n")#text("), but was was stuck in finding the contradiction. May you provide some further hint on the correct direction to proceed?")

#emph[#text("[Move the starting point ")#mi("a")#text(" to be well to the left of the support of ")#mi("f")#text(" to exclude this possibility. Drawing pictures may help. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677514")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" In Exercise 46, do we need the Besicovich covering lemma instead of the Vitaly-type covering lemma since ")#mi("x")#text(" is not assumed to be the center of the ball here, while the Vitali-type covering lemma gives the version of the maximal inequality where ")#mi("x")#text(" is the center? What underlying property of the general locally finte Borel-measure ")#mi("\\mu")#text(" that is not shared by the Lebesgue measure $m$ did we use in answering this question? Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677553")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2023")])]

#text("For general measures ")#mi("\\mu")#text(" we do not have a clean relationship between ")#mi("\\mu(3B)")#text(" and ")#mi("\\mu(B)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677558")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2023")])]

#text("Thank you professor.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" For part (2) of Exercise 49, it seems that one can reduce to ")#mi("E")#text(" being a bounded open set, and thus can be written as a countable union of almost disjoint cubes. From here, can you give some further hint as to how to construct the the cube ")#mi("Q")#text(" with the desired property? Also in part (1), do we need Exercise 48 to ensure that ")#mi("x")#text(" is a Lebesgue point (since it’s a density point), so we can safely apply Exercise 34?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677635")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" I think I got the idea of part (2) of Exercise 49, outer approximate ")#mi("E")#text(" by an open set ")#mi("U")#text(", which can be written as a countable union of almost disjoint cubes, and then one of those cubes must have the desired property.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677717")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2023")])]

#text("Dear professor Tao:")#linebreak()#text(" Following the hint in part ")#mi("(2)")#text(" of Exercise 50, for any subinterval ")#mi("I \\subset (-1, 2)")#text(", ")#mi("I \\subset (-1, 2) \\setminus K")#text(", which is a countable union of disjoint open intervals. From here, can you elaborate on the comment “fill in these open intervals and iterate”? What are we aiming at?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677757")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2023")])]

#text("My understanding is to take a compact nowhere dense subset ")#mi("E_1 \\subset I")#text(", with measure ")#tao-math("> 1/2\\left|I\\right|", block: false)#text(" (say), then take the union ")#mi("E_2")#text(" of the compact nowhere dense subsets of the open components of ")#mi("I \\setminus E_1")#text(", each with measure ")#mi("> 1/2 \\cdot")#text(" |the open component| … Then define ")#mi("E := \\bigcup_n E_n")#text(". Since ")#mi("E")#text(" is well-distributed in ")#mi("I")#text(", the translates of ")#mi("E")#text(" will be well-distributed in ")#mi("\\mathbb{R}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-677874")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2023")])]

#text("For this construction, I’m able to show that ")#mi("\\forall I^{\\prime} \\subset I")#text(", $I’$ an interval, ")#mi("m(E \\cap I^{\\prime}) > 0")#text(". Yet I’m not able to show that ")#tao-math("m(E \\cap I^{\\prime}) < \\left|I^{\\prime}\\right|", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-678096")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2023")])]

#text("The difficulty for me is to control ")#mi("m(I^{\\prime} \\cap E_n)")#text(" in terms of ")#tao-math("\\left|I^{\\prime}\\right|", block: false)#text(" for any subinterval ")#mi("I^{\\prime} \\subset I")#text(". Is this the wrong direction to consider?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-678214")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2023")])]

#text("Let ")#mi("E_n \\subset I \\setminus K \\setminus E_1 \\setminus \\ldots E_{n-1}")#text(" be the countable union of compact fillings in the ")#mi("n")#text("th stage. I get stuck as to how to control the size of the filling ")#mi("m(E_n)")#text(" to ensure ")#mi("E = \\bigcap_n E_n")#text(" has the given property. Could you please provide some further hint, professor?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-678228")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2023")])]

#text("Dear professor:")#linebreak()#text(" ")#mi("E")#text(" should be ")#mi("\\cup_n E_n")#text(" rather than ")#mi("\\cap_n E_n")#text(" in my last comment. My issue is that the holes are shrinking in size and chained together. Namely, ")#mi("I^{\\prime} \\setminus E_1 \\supset I^{\\prime} \\setminus E_1 \\setminus E_2 \\supset \\ldots")#text(". If ")#mi("n")#text(" is the first natural number such that ")#tao-math("m(I^{\\prime} \\setminus E_1 \\setminus \\ldots E_n) < \\left|I^{\\prime}\\right|", block: false)#text(", then ")#tao-math("0 < m(I^{\\prime} \\cap E_n) < \\left|I^{\\prime}\\right|", block: false)#text(". In fact, ")#mi("E_n")#text(" partially fills the hole ")#mi("I^{\\prime} \\setminus E_1 \\setminus \\ldots \\setminus E_{n-1}")#text(" by our construction of the ")#mi("E")#text("'s. But then it is unclear whether the part of ")#mi("I^{\\prime}")#text(" not filled by ")#mi("E_n")#text(", will then be filled completely in the remaining stage by ")#mi("E_{n+1}, E_{n+2}, \\ldots")#text(", etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-678471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("Dear professor Tao: For part (1) of Exercise 50. Is there any theorem/proposition in the previous notes available, other than the definition itself, for us to calculate the total mass of ")#mi("P")#text("? Also, can you elaborate further on the hint in part (2) about comparing ")#mi("P")#text(" with the “horizontal wedding cake function” you mentioned?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-678476")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2023")])]

#text("For the heat kernel, this is a gaussian integral and can be computed by a number of techniques (for instance a reduction to the famous identity ")#mi("\\int_{-\\infty}^\\infty e^{-\\pi x^2}\\ dx = 1")#text("). For the Poisson kernel, one can rescale ")#mi("t=1")#text(", and manipulate the integral by a number of techniques (e.g., polar coordinates and contour shifting, or using the identity ")#mi("\\frac{\\Gamma(s)}{a^s} = \\int_0^\\infty e^{-at} t^{s-1}\\ dt")#text(" to express the Poisson kernel in terms of gaussians); alternatively, one can simply just declare ")#mi("c_d")#text(" by fiat to normalize the mass of the Poisson kernel.")

#text("For (2), one can obtain pointwise upper and lower bounds for ")#mi("P")#text(" in terms of the horizontal wedding cake function I mentioned, as well as a dilate of this function (replacing ")#mi("x")#text(" by ")#mi("x/2")#text(" or ")#mi("2x")#text(").")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-2/#comment-678493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2023")])]

#text("Thank you so much professor.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e1ce16c2826f8d72338e52a5b4a34a3ea4b13753a02dc2122bc9850ca2b3abf-8fb19de432e8cf59e77baf25d23abd58544dce0b0985b77386838327d5f24293.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MathStudent")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47657")[#strong[#text("MathStudent")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2010")])]

#text("Dear Prof. Tao,")

#text("In a recent lecture post on generalizing Lebesgue integrals (sorry I don’t know how to link), you mention that it is usually not useful to define “improper” Lebesgue integrals or the analogs of Cauchy Principal Value type integrals. Are there other types of integrals that work in those cases? With possibly, some additional restrictions on the functions being integrated?")

#text("Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47664")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2010")])]

#text("Yes, at least in one dimension; see for instance the discussion of the Henstock-Kurzweil integral in Exercise 52 and Remark 18. This integral can handle improper integrands which are only conditionally convergent rather than absolutely convergent around a finite singularity. However, it does not cover principal value integrals around a singularity. For these, complex-analytic methods, such as analytic continuation, can sometimes be used to evaluate these integrals, although these are quite different techniques than the measure-theoretic ones presented here.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47658")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2010")])]

#text("[…] Lecture 2: Das Lebesguesche Integral Lecture 3: Maße und Maßräume Lecture 4: Konvergenzbegriffe Lecture 4: Differentiation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f396bf049db9893ab87eaf950c4afa49492aec8c24e1f88673a282448133d439-e6226ea82b2c7e83b28bbac97b55410f2c439de63cac48ee90d2c982c9743669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Xiuli")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47659")[#strong[#text("Wang Xiuli")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2010")])]

#text("It is not a comment.So long is the post,that I think it must be part of a lecture for your class.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco Angulo")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47761")[#strong[#text("Marco Angulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2010")])]

#text("There is a typo at the end of the proof for Theorem 4. The expression \\int_0^1 f(x) dx should be replaced by \\int_0^1 f(x) dt. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47794")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2010")])]

#text("The last sentence in Ex. 21 is incomplete ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("Dear Prof. Tao,")

#text("Could you please add some notes on Taylor’s expansion thms to this lecture notes?They are always used in Mathematics and it would be nice to review here.")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abd6cfa03fa35ecf1e59dc30bbd172a167f289c71edcf117eb000e881d8ee3f3-f9fd609695ceacb3fa361213040786f23bed01cb4716c971eb896e7959c1f2f3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Constantin Niculescu")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47837")[#strong[#text("Constantin Niculescu")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2010")])]

#text("In Exercise 41, the inequality defining a convex function should be reversed. ")#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47925")[#strong[#text("245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("[…] is a jump function (as defined in Definition 17 of Notes 5), show that is equal to the linear combination of delta functions (as defined in Exercise 22 of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47957")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("The dominator of \\theta_x (fraction) defined in the proof of Lemma. 18, 3. should be “F_+(x) – F_-(x)” instead of “F_+(x) – F(x)”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asymptotic decay for a one-dimensional nonlinear wave equation « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-47972")[#strong[#text("Asymptotic decay for a one-dimensional nonlinear wave equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2010")])]

#text("[…] differentiable. (By coincidence, I am teaching this theorem in my current course, both in one dimension (which is the case of interest here) and in higher dimensions.) A compactness argument allows one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/953b7bd32cf7eaa020006fc272d5a7cbc33654ae9d83278e8f02d0c21a6b5bc4-fa5c994a46b5ca481a9304fba98f508cded48261da3eed811a14fc11b6e65ebb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chandrasekhar")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48013")[#strong[#text("chandrasekhar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2010")])]

#text("Respected Sir,")

#text("There are some theorem’s measure theory which guarantee “Almost everywhere convergence” is enough for showing everywhere convergence.")

#text("Similarly are there any theorems which guarantee that almost everywhere differentiability is enough for showing everywhere differentiability.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48822")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2010")])]

#text("I have posted a theorem here below which might be relevant to your question and indeed you may be able to help me.")

#text("J.P.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f361a04950475a41037ec565251c0e2c3286072d70467ca68caf07545c2a4334-83f82a5769ac964a883555046c8486b4350c09066749cf7b896745022888e9bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cy")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48062")[#strong[#text("cy")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2010")])]

#text("Ex.47#5. uniformly continuous is repeated twice, i suppose the first should be just continuous.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1013eb9df3fb1866c715a1ceb8fa1e9ab166610a95f470d9ef576d3b9bf05b39-94fe98c03916903d8e96bf2e3d0505a842bd5be8c8a301baff405f8bea459f3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yasser")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48148")[#strong[#text("Yasser")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("Dear Prof. Tao,")

#text("In the proof of the rising sun lemma did you mean ")#mi("[t,b_n]")#text(" in the definition of the set A?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2010")])]

#text("Either definition would work in this case. (Because ")#mi("b_n")#text(" lies outside ")#mi("U")#text(", no element of ")#mi("A")#text(" can exceed ")#mi("b_n")#text(" anyway.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-485262")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2017")])]

#text("But later I don’t see why ")#mi("[t,b)\\subset I_n")#text(". However I agree that ")#mi("[t,b_n)\\subset I_n")

#emph[#text("[Explanation added as to why the elements of ")#mi("A")#text(" do not reach or exceed ")#mi("b_n")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3db66367ad1b45bfb1831368b47c739dcd4ed00c03cdadb244d504d65490cbb9-b1398d05cb97a60cacbdd94b70fba31645d2562ed3c7fbad18438143730750fe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Li")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-485311")[#strong[#text("Joe Li")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2017")])]

#text("Thank you Prof. Tao.")

#text("But what I referred to is that the line below: ")#mi("t_* \\in [t,b) \\subset I_n \\subset U")#text(". ")#mi("b")#text(" is the right end point of the whole interval, and there is no reason that ")#mi("b-\\epsilon")#text(" is covered by ")#mi("U")#text(", for example when ")#mi("F")#text(" is decreasing in ")#mi("(b-\\epsilon, b]")#text(".")

#emph[#text("[Inclusion ")#mi("t_* \\in [t,b)")#text(" corrected to ")#mi("t_* \\in [t,b_n)")#text(". -T]")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48217")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2010")])]

#text("Hi, Prof. Tao")

#text("I have two questions about exercise 26:")#linebreak()#text(" 1, why P is radially non-increasing but P~ is a non-decreasing function?")#linebreak()#text(" 2, in the question 1, what do you mean by x^2, because x is d-dimension vector. Do you mean by the inner product?")

#text("Thank you.")

#emph[#text("[Oops, these were typos. Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48237")[#strong[#text("Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")])]

#text("Several typos:")#linebreak()#text(" 1, Exercise 18: not just in 2B’_j, it should be 3B’_j")#linebreak()#text(" 2, Exercise 21: the left hand side, du(y) should be du.")#linebreak()#text(" 3, Exercise 41: f is convex, so its derivative f’ should equal a.e. to a monotone non-decreasing function, not non-increasing.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lei")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48272")[#strong[#text("Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2010")])]

#text("In question 3 of exercise 46, we can further prove that |F_{n+1}|-F_{n}|=<2^(-n-1), because it is easy to verify that |F_1-F_0|=<1/2 and we can induct on n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xtt")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48274")[#strong[#text("Xtt")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2010")])]

#text("In Exercise 26, is it that P is actually radially non-increasing? Thanks.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37cc8f233e7fa26e7317b82c1e7be5356e8ad1392c216bf8243082a453dbb1f7-3665f2532a90579e05a61967dba64bf8fe6c6ce9320539d87609987d22a8f087.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ผลบอล")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48277")[#strong[#text("ผลบอล")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2010")])]

#text("The last sentence in Ex. 21 is incomplete . Great! ")#emph[#text("[I don’t see the issue here – could you clarify? – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48281")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2010")])]

#text("Prof Tao,")

#text("Should F(x) in Exercise 47.6 be called indefinite integral or definite integral?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb18951478a79f3c665aa5abda4b96bd2df299c9dbb58bace5e3c0019c452832-08587766a77d603c794bac9941d907894c897773e7d1e4a9e2e0659ada2f18e3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dukezhang")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48325")[#strong[#text("dukezhang")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("It seems the example following Definition 17 is not non-decreasing. Since J(q_1)=1, J(q_2)=.5, but q_1<q_2. Is that the case?")

#emph[#text("[Oops, the jumps were going the wrong way; this has been fixed. Incidentally, the ")#mi("q_n")#text(" are not (and cannot) be ordered in a monotone fashion, as the rationals are not order-equivalent to the natural numbers. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d15575eccc293bf9b7ed4f969aa83d251d1be5fba27224ac9e56ac3d43af55d-ba557ae2f36f139ce88d00bc598453dd064eaa4fe6d5328f1be58a780363522f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilda")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48344")[#strong[#text("Hilda")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("In Ex.20, should it be “integration of |f|” instead of “integration of f”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d15575eccc293bf9b7ed4f969aa83d251d1be5fba27224ac9e56ac3d43af55d-ba557ae2f36f139ce88d00bc598453dd064eaa4fe6d5328f1be58a780363522f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hilda")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48345")[#strong[#text("Hilda")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("Sorry, it’s Ex. 21.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Farzin")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48383")[#strong[#text("Farzin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Dear Professor Tao,")

#text("In the 4th, 3th and 2nd to the last equation before Exercise 49, should some of the sum notations be integrals?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bunyamin Sari")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48490")[#strong[#text("Bunyamin Sari")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2010")])]

#text("In Weierstrass function, exercise 27, does the coefficient 2 in Sine function really work? If a straightforward estimate to be used, shouldn’t it be bigger than 4?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48685")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Dear Prof. Tao,")

#text("I believe the following is a counter example to 50: Take ")#mi("F \\equiv 1")#text(" and ")#mi("\\phi(x)")#text(" to be any positive, continuously differentiable bump function that is compactly supported in (a, b). Then ")#mi("\\int_{[a,b]} \\phi(x) \\neq 0")#text(".")

#emph[#text("[Yes, but in this case")]#text(" ")#mi("F^{\\prime}=0")#text(" ")#emph[#text("and so")]#text(" ")#mi("\\int_{[a,b]} F^{\\prime} \\phi(x)\\ dx = 0 = \\int_{[a,b]} F \\phi^{\\prime}(x)\\ dx")#text(". ")#emph[#text("– T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Dear Prof. Tao,")

#text("In the second paragraph of the proof of proposition 25, it states that")

#text("$\\int_{\\bigcup_{m=1}^\\infty U_m} |F'(x)|dx \\leq \\epsilon$.")

#text("I don’t believe this is true, unless the open sets $U_m$ are nested and $U_1 = U$. This wasn’t used any where else in the proof, though.")

#emph[#text("Some clarifications added – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2010")])]

#text("Thanks – got it!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48821")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2010")])]

#text("Students of Prof. Tao (or even the man himself even better!),")

#text("Could you please tell me have I made a mistake in this proof. I believe the theorem is correct but after struggling with finding a proof I think the following seems a bit too good to be true:")

#text("Theorem")

#text("Suppose that ")#mi("f")#text(" is differentiable except perhaps at ")#mi("a\\in \\mathbb{R}")#text(" and suppose that ")#mi("f")#text(" is continuous at ")#mi("a")#text(", ")#mi("\\lim_{x\\rightarrow a}f^{\\prime}(x)= L0")#text(". ")#mi("f")#text(" is continuous on ")#mi("[a,a+h]")#text(" and differentiable on ")#mi("(a,a+h)")#text(". Then, by the Mean Value Theorem, ")#mi("\\exists,c_h\\in(a,a+h)")#text(" such that")

#mi("f^{\\prime}(c_h)=\\frac{f(a+h)-f(a)}{h}")

#text("Now taking the limit as ")#mi("h\\rightarrow 0")#text(" on both sides:")

#mi("\\lim_{h\\rightarrow 0^+}f^{\\prime}(c_h)=\\lim_{h\\rightarrow 0^+}\\frac{f(a+h)-f(a)}{h}")

#text("Now ")#mi("c_h\\rightarrow a^+")#text(" as ")#mi("h\\rightarrow 0^+")#text(" hence the left hand side is equal to ")#mi("L")#text(":")

#mi("\\lim_{h\\rightarrow 0^+}\\frac{f(a+h)-f(a)}{h}=L")

#text("Similarly taking ")#mi("h<0")#text(" and ")#mi("h\\rightarrow 0^-")#text(" we can show:")

#mi("\\lim_{h\\rightarrow 0^-}\\frac{f(a+h)-f(a)}{h}=L")

#text("Hence ")#mi("f")#text(" is differentiable at ")#mi("a")#text(" with derivative ")#mi("f^{\\prime}(a)=L")#text(" ")#mi("\\Box")

#text("Full details at ")#link("http://irishjip.wordpress.com/2010/12/09/ms-2001-differentiability-question/")[#text("http://irishjip.wordpress.com/2010/12/09/ms-2001-differentiability-question/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-48824")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2010")])]

#text("ARRGGGHHHH!! Please just follow the link, the proper statement of the theorem is at the end.")

#text("Cheers,")#linebreak()#text(" J.P.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-49485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2011")])]

#text("Dear professor,")

#text("In step 1 of lemma 13’s algorithm, the expression “(which, initially, will be all the balls ")#mi("B_1, \\ldots , B_n")#text(")” is a bit ambiguous. It is not immediately clear whether these balls are the ")#mi("B_1, ... B_m^{\\prime}")#text(" or the balls ")#mi("B_j")#text(". You may want to alter that.")

#text("Thank you for the attention!")

#emph[#text("[Reworded, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-49539")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")])]

#text("Dear professor,")

#text("In lemma 16, last time you wrote ")#mi("G(-a_n) \\leq G(-b_n)")#text(", did you mean ")#mi("\\ge")#text("?")

#text("Thank you!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stein’s maximal principle « What’s new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-52633")[#strong[#text("Stein’s maximal principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2011")])]

#text("[…] to pointwise almost everywhere for all in , and not just in the dense subclass. See for instance these lecture notes of mine, in which this method is used to deduce the Lebesgue differentiation theorem from the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/686d6d93bb25b4a7e5ca0018c2229694ff9188a7b558dc64ef394a0d6e2f3053-8b71c75bc5bd875771103e0532aef19458318916c0cd01e7494372a36b3931ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-188115")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2012")])]

#text("What do the notations F’\\phi(x) and F\\phi'(x) mean in Exec 51? I cannot find the definitions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-188190")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2012")])]

#mi("F^{\\prime}\\phi")#text(" is the derivative of ")#mi("F")#text(", multiplied by ")#mi("\\phi")#text(", and similarly for ")#mi("F\\phi^{\\prime}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c856e9850f26edc137add0a41c8f97076e95fa044a8d28c3e8b6990bfca0b340-559acf0417b9f2d5a924ad53b42df5dd5689a3b65818459bc13407f7ec209427.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jdem")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-197735")[#strong[#text("jdem")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2012")])]

#text("Dear Tao, If I remember correctly, the Cantor function is differentiable almost everywhere in the Cantor set (ex 47.8), and in this kind of selfsimilar sets with Hausdorff dimension d, the points where the Devil’ staircase is not differentiable has dimension d^2 < d.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-220555")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2013")])]

#text("Prof. Tao, what’s the difference between Theorem 4 and Corollary 5? Isn’t the later one just part of Theorem 4 since ")#mi("F^{\\prime}(x)=f(x)")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-220565")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2013")])]

#text("Yes; this is why the latter result is labeled as a ")#link("http://en.wikipedia.org/wiki/Corollary")[#text("corollary")]#text(" of the former one.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ec942ae1060d42937a74c35b08d2ec7a2ef0a3833194d6f987d4c3cac41010-777c3130775f8467a4585aaa7a16722466118b96293272754ad4436a1b425267.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shubhashedthikere")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-255651")[#strong[#text("shubhashedthikere")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("Prof. Tao,")

#text("I want to know why in the definition of functions with ‘bounded variation’, the supremum is taken over “finite” increasing sequences, why “countable” increasing sequences are not allowed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-255652")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2013")])]

#text("These would give equivalent definitions (the two suprema are equal, thanks to (an easy case of) the monotone convergence theorem).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stein’s spherical maximal theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-397202")[#strong[#text("Stein’s spherical maximal theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2014")])]

#text("[…] for all and almost every . See for instance my lecture notes on this topic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-439736")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2014")])]

#text("In Exercise 1, do you actually mean “")#mi("F^{\\prime}")#text(" need not be continuous” in the last line?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-439806")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2014")])]

#text("Ah, I didn’t see Exercise 2. A simple function like ")#mi("1_A")#text(" where ")#mi("A")#text(" is a proper sub-interval is an example in this case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-439954")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2014")])]

#emph[#text("This argument requires two ingredients, which we state informally as follows:")]

#text("A verification of the convergence result for some “dense subclass” of “nice” functions {f}, such as continuous functions, smooth functions, simple functions, etc.. By “dense”, we mean that a general function {f} in the original class can be approximated to arbitrary accuracy in a suitable sense by a function in the nice subclass.")#linebreak()#text(" A quantitative estimate that upper bounds the maximal fluctuation of the linear expressions {T_h f} in terms of the “size” of the function {f} (where the precise definition of “size” depends on the nature of the approximation in the first ingredient).")

#text("I’m trying to identify the second ingredient of the density argument in the proof of Theorem 7. As I see from the proof where Lemma 9 is used, “fluctuation” ")#mi("T_hf-f")#text(" is bounded by ")#mi("\\lambda")#text(". Is this ")#mi("\\lambda")#text(" the “’size’ of the function ")#mi("{f}")#text("“? (It doesn’t make sense though, I don’t know what would be the size here.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-440135")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2014")])]

#text("Lemma 9 bounds the weak ")#mi("L^1")#text(" norm of maximal value of ")#mi("T_h f")#text(" in terms of the ")#mi("L^1")#text(" norm of ")#mi("f")#text(". So in this case, the relevant size of ")#mi("f")#text(" is the ")#mi("L^1")#text(" norm.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-440579")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2014")])]

#text("Ah, so the second step in the density argument is to bound ")#mi("T_h f")#text(" instead of ")#mi("T_hf-f")#text(" and in the example you give in the proof of Proposition 8, ")#mi("T_hf")#text(" should be understood as ")#mi("(T_hf)(x)=f_h(x)-f(x)")#text("? (Still a little bit confused about what one should bound in the “quantitative estimate” step.)")

#text("I didn’t find the definition until I skimmed through the 245C note. In Chapter 3 of Stein-Shakarchi, the inequality in Lemma 9 is called to be of “weak type.” I didn’t understand why it is called in that way. (I guess it is because the “weak ")#mi("L^1")#text(" norm” as you put is used. )")

#text("The quantity on the left hand side of the inequality looks very much like the distribution function in probability. If one replace the Lebesgue measure with some probability measure, the inequality still holds?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-440565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2014")])]

#text("I have no intuition at all why Cousin’s Theorem can be true and what might be a possible motivation for such statement. (Unlike the rising sum lemma for instance, one can vividly sense why the statement should be true). It looks like an indispensable tool for define the Henstock–Kurzweil integrals. But how should one understand the “gauge function” ")#mi("\\delta")#text(" (and the whole statement)? (It looks something like the “norm” of a partition when we define Riemann integral though.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e846bdf44d2e88129d1e0adf9379baf32f2e87c1bd1eaf9282bff1612081476-59ec8234837778f3b837232c60cf790b46f43584d8cefb362b595e5613405dbd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alperen Sirin")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-443428")[#strong[#text("Alperen Sirin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2014")])]

#text("Mathematical Proofs! Yes! I’ve been looking for this for so long now! Well, although I found a lot of interesting websites and articles about the background proof of calculus, it is quite pleasing to find it all together.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ae07f20fa1d0740cf426c5e4e6c220b34b642422afc7ad92728d2f138273344-acb1c62774d5a10fc73ccdb2560a1190526ddcc437965d18390f8ff4450bdb8c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alperen Sirin")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-443433")[#strong[#text("Alperen Sirin")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2014")])]

#text("Reblogged this on ")#link("http://alperensirin.wordpress.com/2014/12/01/245a-notes-5-differentiation-theorems/")[#text("Ideas, Thoughts, and Research")]#text(" and commented:")#linebreak()#text(" Differentiation Theorems from Terence Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-446132")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2014")])]

#text("Can one do Exercise 5 without essentially using the property that the measure defined as ")#mi("\\nu(A):=\\int_Af(t)\\ dt")#text(" is absolutely continuous w.r.t. the Lebesgue measure?")

#emph[#text("[One can also use dominated convergence – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-446141")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2014")])]

#text("Typo in the proof of Proposition 8, “to the absolutely integrable function ")#mi("{F^{\\prime}}")#text("“?")

#emph[#text("[I don’t see the issue here – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-446253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2014")])]

#text("In the proof of Proposition 8:")

#text("… Applying Littlewood’s second principle (Theorem 15 from Notes 2) to the absolutely integrable function ")#mi("{F^{\\prime}}")#text(", we can find a continuous, compactly supported function…")

#text("I think you mean “the absolutely integrable function ")#mi("f")#text("…”")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-446150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2014")])]

#text("typo right after formula (6), “whenever ")#mi("{h}")#text(" is sufficiently close to ")#mi("{x}")#text("”")

#emph[#text("[I don’t see the issue here – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-446255")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2014")])]

#text("“Now let ")#mi("{x \\in {\\bf R} \\backslash E}")#text(". From the dense subclass result (Corollary 5) applied to the continuous function ")#mi("{g}")#text(", we have")

#tao-math("\\displaystyle  \\left|\\frac{1}{h} \\int_{[x,x+h]} g(t)\\ dt - g(x)\\right| < \\lambda", block: false)

#text("whenever ")#mi("{h}")#text(" is sufficiently close to ")#mi("{x}")#text(". Combining…”")

#text("Should it be “h is sufficiently close to 0”?")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-446367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2014")])]

#text("…we conclude that")

#tao-math("\\displaystyle  \\limsup_{h \\rightarrow 0} \\left|\\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt - f(x)\\right| < 3\\lambda", block: false)

#text("for almost every ")#mi("{x \\in {\\bf R}}")#text(". If we then let ")#mi("{\\lambda}")#text(" go to zero along a countable sequence (e.g.")#mi("{\\lambda := 1/n}")#text(" for ")#mi("{n=1,2,\\ldots})")#text(", we conclude that")

#tao-math("\\displaystyle  \\limsup_{h \\rightarrow 0} \\left|\\frac{1}{h} \\int_{[x,x+h]} f(t)\\ dt - f(x)\\right| = 0", block: false)

#text("for almost every ")#mi("{x \\in {\\bf R}}")#text(", and the claim follows.")

#text("———————————————")#linebreak()#text(" Why would one need to pass the ")#mi("\\lambda")#text(" to a sequence? If one has a nonnegative quantity ")#mi("X")#text(" such that $X0$, then ")#mi("X=0")#text(". Is it just a matter of writing style or is there something wrong with my thoughts? (This might be a stupid question. I ask it just because you’ve mentioned the “")#mi("\\varepsilon")#text("-trick” over and over again in the previous notes and there seems no need to use the sequence here…)")

#emph[#text("[The need to pass to a countable sequence is to ensure that the total exceptional set of ")#mi("x")#text("‘s remains of measure zero. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-446424")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2014")])]

#text("Ah, for different ")#mi("\\lambda")#text(", the “exceptional set” of ")#mi("x")#text("‘s might be different. Fair enough. Could have been clearer if one denotes the exceptional set as ")#mi("E_{\\epsilon,\\lambda}")#text(" in the beginning of the proof(-:")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-447917")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2014")])]

#text("Is “")#mi("F")#text(" being of bounded variation on ")#mi("[a,b]")#text("” also a ")#emph[#text("necessary")]#text(" condition for the existence of ")#mi("\\int_{[a,b]}F^{\\prime}(x)\\ dx")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-448585")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("Depends on what one means by ")#mi("F^{\\prime}")#text(" here, but with the classical definition, the answer is no; consider for instance the function ")#mi("F(x) = \\sum_{n=1}^\\infty 1_{[2^{-2n-1}, 2^{-2n}]}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-448765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("Is the absolute continuity of ")#mi("F")#text(" necessary for")#linebreak()#text(" ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx = F(b)-F(a)}")#text(" to be true where ")#mi("F^{\\prime}")#text(" is with the classical definition?")

#text("Does the negative answer in your last comment suggest that we might have another class of functions so that we still have the identity ")#mi("{\\int_{[a,b]} F^{\\prime}(x)\\ dx = F(b)-F(a)}")#text(" (or the inequality in the Prop. 22) with ")#mi("F^{\\prime}")#text(" understood as in the classical sense?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-448772")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2015")])]

#text("If ")#mi("F^{\\prime}")#text(" is required to be absolutely integrable, then yes; see part 6 of Exercise 48.")

#text("If ")#mi("F^{\\prime}")#text(" is not required to be absolutely integrable, then one has to decide how one is to interpret the integral ")#mi("\\int_{[a,b]} F^{\\prime}(x)\\ dx")#text(", as one can no longer use the Lebesgue integral. There are other integration concepts for which one can broaden the range of the second fundamental theorem of calculus, such as the Henstock-Kurzweil integral; see Exercise 53.")

#text("Incidentally, these sorts of questions are excellent exercises for you to work out on your own (cf. ")#link("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")[#text("https://terrytao.wordpress.com/career-advice/ask-yourself-dumb-questions-%E2%80%93-and-answer-them/")]#text(" ).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-449175")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2015")])]

#text("What could be wrong if ")#mi("F")#text(" is unbounded in Lemma 18.3?")

#text("What I understand from the proof is that one could have ")#mi("\\sum_{x\\in A} c_x=\\infty")#text(" and thus by ")#emph[#text("definition")]#text(", ")#mi("\\sum_{x\\in A}c_xJ_x")#text(" is not a jump function. But I don’t have a concrete counterexample that Lemma 18.3 could be false if ")#mi("F")#text(" is unbounded.")

#text("What’s more, is there any significant disadvantage if we allow just the point-wise limit of ")#mi("\\sum_{n=1}^Nc_nJ_n")#text(" in the definition of jump functions?")

#emph[#text("[See Exercise 33 – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-462532")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2015")])]

#text("Professor Tao:")

#text("Could you please explain to me why, in the Rising Sun Lemma, the second condition is fulfilled even when taking x=a? It seems to me that if one takes ")#mi("F(x)=x")#text(" then ")#mi("a")#text(" is not in the union of the ")#mi("I_n")#text(" and yet ")#mi("F(y)>F(a)")#text(" for each ")#mi("y>a")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-463924")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("Professor Tao:")

#text("A proof of Cousin’s Theorem seems straightforward enough with a bisection type argument, however I haven’t been able to follow your suggestion of using the Besicovitch covering lemma together with the Heine-Borel Theorem. Could you please give some additional hint on this approach?")

#text("Thanks.")

#emph[#text("[Apply the Heine-Borel theorem to the intervals ")#mi("(t-\\delta(t), t+\\delta(t))")#text(", followed by the Besicovitch covering lemma. I’d be curious to see your bisection argument. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-463929")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("I came up with the following two arguments:")#linebreak()#text(" Proof 1. Notice that if such a tagged partition exists in the intervals ")#mi("[a,c]")#text(" and ")#mi("[c,b]")#text(" by piecing together the two partitions we may construct one that works for the entire interval ")#mi("[a,b]")#text(". The argument proceeds by contradiction; suppose the partition does not exist in ")#mi("[a,b]")#text(".Then bisect ")#mi("[a,b]")#text("; choose a half in which a suitable partition does not exist (it cannot exist in both halves). Keep doing this to find a shrinking sequence ")#mi("[a_n,b_n]")#text(" of nested closed intervals in each of which we may not find a suitable partition. Their intersection is non-empty; take ")#mi("t")#text(" in said intersection, then by taking some ")#mi("[a_n,b_n]")#text(" shorter than ")#mi("\\delta (t)")#text(" we see that the trivial partition will work in this interval, by tagging the point $t$; a contradiction.")

#text("Proof 2. Consider ")#mi("S=\\{ s \\in [a,b] : a suitable partition exists in [a,s] \\}")#text(". By the similar piecing-together arguments as in Proof 1, show that ")#mi("sup(S) \\in S")#text(" and then show that ")#mi("sup(S)=b")#text(".")

#text("Do these seem correct?")

#text("Your suggestion is precisely what I had already attempted but I don’t see how the finite covering given by the lemma may be used to obtain a suitable partition (the naive approach of simply taking the partition to be all endpoints of the intervals doesn’t seem to work).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-463930")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("These arguments look correct to me (and are closely related to either the Bolzano-Weierstrass theorem or the Heine-Borel theorem, which they should as all these results involve the compactness of ")#mi("[a,b]")#text(".)")

#text("I should have used the intervals ")#mi("(t - \\delta(t)/2,t + \\delta(t)/2)")#text(" in place of ")#mi("(t- \\delta(t),t+\\delta(t))")#text(". By Heine-Borel and Besicovitch one can find intervals ")#mi("(t^*_i- \\delta(t^*_i)/2,t^*_i+\\delta(t^*_i)/2)")#text(" covering ")#mi("[a,b]")#text(" such that any point lies in at most two of the intervals. One can delete any interval which is fully contained in any other interval. If one then lines up the ")#mi("t^*_i")#text(" in increasing order, then the intervals ")#mi("(t^*_i- \\delta(t^*_i)/2,t^*_i+\\delta(t^*_i)/2)")#text(" and ")#mi("(t^*_{i+1}- \\delta(t^*_{i+1})/2,t^*_{i+1}+\\delta(t^*_{i+1})/2)")#text(" must intersect. Now pick ")#mi("t_{i+1}")#text(" to be a common point of these intervals (with appropriate conventions at the endpoints ")#mi("a,b")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c06b5c608061b3433364d7a08c276448981d7dbe3ec5a42a3c2cf5097f6a6116-b2064c0da56b72183b36a8e311c8403011196cba9557b86b4ddceb8d838b15a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-463931")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2015")])]

#text("I see what you had in mind now, thank you very much.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-466600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2016")])]

#text("Let ")#mi("I\\subset\\mathbb{R}")#text(" and ")#mi("\\Omega\\subset\\mathbb{R}^d")#text(" be bounded open and connected. Consider a function ")#mi("u(t,x)")#text(" with ")#mi("u:I\\times\\Omega\\to\\mathbb{R}")#text(". Speaking of differentiation of ")#mi("u")#text(" with respect to the variable ")#mi("t")#text(", it seems that there are two ways to look at it: (1) the ")#emph[#text("partial")]#text(" derivative ")#mi("\\partial_t u")#text(" (2)the ")#emph[#text("derivative")]#text("of ")#mi("u")#text(", ")#mi("du/dt")#text(" where ")#mi("u")#text(" is regarded as a function from ")#mi("I")#text(" to some function space which is a subset of ")#mi("\\mathbb{R}^{\\Omega}")#text(". Are these two interpretations the same when one talks about differentiation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-466602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2016")])]

#text("Pretty much yes, assuming either that ")#mi("u")#text(" has sufficient regularity and decay, or else that the derivatives are being interpreted in an appropriately weak sense (e.g. distributional derivative, or using a weak topology for the function space).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-466613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("It is easy to state Definition 19, but I’m really wondering if one could apply it to check whether a specific function is of bounded variation or not. (Why is it a useful concept then?) It looks pretty much an “integral definition”. Does it relate to the line integrals in calculus?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-466617")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("One can use Exercise 38 or Proposition 20 as ways to verify bounded variation in practice. Bounded variation implies several additional useful properties, such as almost everywhere differentiability (Corollary 21); for functions of bounded variation on a half-line, it also implies existence of a limit at infinity, which is useful for instance in ergodic theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-466615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("For Remark 2, if ")#mi("F")#text(" is differentiable in ")#mi("(a,b)")#text(" and continuous in ")#mi("[a,b]")#text(", must it be differentiable in ")#mi("[a,b]")#text(" also?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/10/16/245a-notes-5-differentiation-theorems/comment-page-1/#comment-466616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2016")])]

#text("No; the standard counterexample is ")#mi("F(x) = x \\sin \\frac{1}{x}")#text(" on ")#mi("[0,1]")#text(" (with ")#mi("F(0)=0")#text(").")
]
]
