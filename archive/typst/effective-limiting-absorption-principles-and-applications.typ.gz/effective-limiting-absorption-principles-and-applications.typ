// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/
// Converted to Typst by tao2typ: "2026-10-14T16:36:29.050287+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Effective limiting absorption principles, and applications", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Effective limiting absorption principles, and applications")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/")[#text("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Igor Rodnianski and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1105.0873")[#text("Effective limiting absorption principles, and applications")]#text("“, submitted to ")#link("http://www.springer.com/physics/theoretical,+mathematical+%26+computational+physics/journal/220")[#text("Communications in Mathematical Physics")]#text(". In this paper we derive limiting absorption principles (of type discussed in ")#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/")[#text("this recent post")]#text(") for a general class of Schrödinger operators ")#mi("{H = -\\Delta + V}")#text(" on a wide class of manifolds, namely the ")#emph[#text("asymptotically conic")]#text(" manifolds. The precise definition of such manifolds is somewhat technical, but they include as a special case the ")#emph[#text("asymptotically flat")]#text(" manifolds, which in turn include as a further special case the smooth compact perturbations of Euclidean space ")#mi("{{\\bf R}^n}")#text(" (i.e. the smooth Riemannian manifolds that are identical to ")#mi("{{\\bf R}^n}")#text(" outside of a compact set). The potential ")#mi("{V}")#text(" is assumed to be a ")#emph[#text("short range potential")]#text(", which roughly speaking means that it decays faster than ")#tao-math("{1/\\left|x\\right|}", block: false)#text(" as ")#mi("{x \\rightarrow \\infty}")#text("; for several of the applications (particularly at very low energies) we need to in fact assume that ")#mi("{V}")#text(" is a ")#emph[#text("strongly short range potential")]#text(", which roughly speaking means that it decays faster than ")#tao-math("{1/\\left|x\\right|^2}", block: false)#text(".")

#text("To begin with, we make no hypotheses about the topology or geodesic geometry of the manifold ")#mi("{M}")#text("; in particular, we allow ")#mi("{M}")#text(" to be ")#emph[#text("trapping")]#text(" in the sense that it contains geodesic flows that do not escape to infinity, but instead remain trapped in a bounded subset of ")#mi("{M}")#text(". We also allow the potential ")#mi("{V}")#text(" to be signed, which in particular allows bound states (eigenfunctions of negative energy) to be created. For standard technical reasons we restrict attention to dimensions three and higher: ")#mi("{d \\geq 3}")#text(".")

#text("It is well known that such Schrödinger operators ")#mi("{H}")#text(" are essentially self-adjoint, and their spectrum consists of purely absolutely continuous spectrum on ")#mi("{(0,+\\infty)}")#text(", together with possibly some eigenvalues at zero and negative energy (and at zero energy and in dimensions three and four, there are also the possibility of ")#emph[#text("resonances")]#text(" which, while not strictly eigenvalues, have a somewhat analogous effect on the dynamics of the Laplacian and related objects, such as resolvents). In particular, the resolvents ")#mi("{R(\\lambda \\pm i\\epsilon) := (H - \\lambda \\mp i\\epsilon)^{-1}}")#text(" make sense as bounded operators on ")#mi("{L^2(M)}")#text(" for any ")#mi("{\\lambda \\in {\\bf R}}")#text(" and ")#mi("{\\epsilon > 0}")#text(". As discussed in the ")#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/")[#text("previous blog post")]#text(", it is of interest to obtain bounds for the behaviour of these resolvents, as this can then be used via some functional calculus manipulations to obtain control on many other operators and PDE relating to the Schrödinger operator ")#mi("{H}")#text(", such as the Helmholtz equation, the time-dependent Schrödinger equation, and the wave equation. In particular, it is of interest to obtain ")#emph[#text("limiting absorption estimates")]#text(" such as ")#metadata(none) <tao-3ff6c05723bb069d1995>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| R(\\lambda \\pm i\\epsilon) f \\right\\|_{H^{0,-1/2-\\sigma}(M)} \\leq C(M,V,\\lambda,\\sigma) \\left\\| f \\right\\|_{H^{0,1/2+\\sigma}(M)}", block: true)]]

#text("for ")#mi("{\\lambda \\in {\\bf R}}")#text(" (and particularly in the positive energy regime ")#mi("{\\lambda>0}")#text("), where ")#mi("{\\sigma,\\epsilon > 0}")#text(" and ")#mi("{f}")#text(" is an arbitrary test function. The constant ")#mi("{C(M,V,\\lambda,\\sigma)}")#text(" needs to be independent of ")#mi("{\\epsilon}")#text(" for such estimates to be truly useful, but it is also of interest to determine the extent to which these constants depend on ")#mi("{M}")#text(", ")#mi("{V}")#text(", and ")#mi("{\\lambda}")#text(". The dependence on ")#mi("{\\sigma}")#text(" is relatively uninteresting and henceforth we will suppress it. In particular, our paper focused to a large extent on ")#emph[#text("quantitative")]#text(" methods that could give ")#emph[#text("effective")]#text(" bounds on ")#mi("{C(M,V,\\lambda)}")#text(" in terms of quantities such as the magnitude ")#mi("{A}")#text(" of the potential ")#mi("{V}")#text(" in a suitable norm.")

#text("It turns out to be convenient to distinguish between three regimes:")

#list(
[#text("The ")#emph[#text("high-energy regime")]#text(" ")#mi("{\\lambda \\gg 1}")#text(";")],
[#text("The ")#emph[#text("medium-energy regime")]#text(" ")#mi("{\\lambda \\sim 1}")#text("; and")],
[#text("The ")#emph[#text("low-energy regime")]#text(" ")#mi("{0 < \\lambda \\ll 1}")#text(".")]
)

#text("Our methods actually apply more or less uniformly to all three regimes, but the nature of the conclusions is quite different in each of the three regimes.")

#text("The high-energy regime ")#mi("{\\lambda \\gg 1}")#text(" was essentially worked out ")#link("http://www.ams.org/mathscinet-getitem?mr=1618254")[#text("by Burq")]#text(", although we give an independent treatment of Burq’s results here. In this regime it turns out that we have an unconditional estimate of the form ")#link(<tao-3ff6c05723bb069d1995>)[#text("(1)")]#text(" with a constant of the shape")

#align(center)[#tao-fit-display[#mitex("C(M,V,\\lambda) = C(M,A) e^{C(M,A) \\sqrt{\\lambda}}")]]

#text("where ")#mi("{C(M,A)}")#text(" is a constant that depends only on ")#mi("{M}")#text(" and on a parameter ")#mi("{A}")#text(" that controls the size of the potential ")#mi("{V}")#text(". This constant, while exponentially growing, is still finite, which among other things is enough to rule out the possibility that ")#mi("{H}")#text(" contains eigenfunctions (i.e. point spectrum) embedded in the high-energy portion of the spectrum. As is well known, if ")#mi("{M}")#text(" contains a certain type of trapped geodesic (in particular those arising from positively curved portions of the manifold, such as the equator of a sphere), then it is possible to construct ")#emph[#text("pseudomodes")]#text(" ")#mi("{f}")#text(" that show that this sort of exponential growth is necessary. On the other hand, if we make the ")#emph[#text("non-trapping hypothesis")]#text(" that all geodesics in ")#mi("{M}")#text(" escape to infinity, then we can obtain a much stronger high-energy limiting absorption estimate, namely")

#align(center)[#tao-fit-display[#mitex("C(M,V,\\lambda,\\sigma) = C(M,A) \\lambda^{-1/2}.")]]

#text("The exponent ")#mi("{1/2}")#text(" here is closely related to the standard fact that on non-trapping manifolds, there is a local smoothing effect for the time-dependent Schrödinger equation that gains half a derivative of regularity (cf. ")#link("https://terrytao.wordpress.com/2011/04/21/the-limiting-absorption-principle/")[#text("previous blog post")]#text("). In the high-energy regime, the dynamics are well-approximated by semi-classical methods, and in particular one can use tools such as the positive commutator method and pseudo-differential calculus to obtain the desired estimates. In case of trapping one also needs the standard technique of Carleman inequalities to control the compact (and possibly trapping) core of the manifold, and in particular needing the delicate two-weight Carleman inequalities of Burq.")

#text("In the medium and low energy regimes one needs to work harder. In the medium energy regime ")#mi("{\\lambda \\sim 1}")#text(", we were able to obtain a uniform bound")

#align(center)[#tao-fit-display[#mitex("C(M,V,\\lambda) \\leq C(M,A)")]]

#text("for all asymptotically conic manifolds (trapping or not) and all short-range potentials. To establish this bound, we have to supplement the existing tools of the positive commutator method and Carleman inequalities with an additional ODE-type analysis of various energies of the solution ")#mi("{u = R(\\lambda \\pm i\\epsilon) f}")#text(" to a Helmholtz equation on large spheres, as will be discussed in more detail below the fold.")

#text("The methods also extend to the low-energy regime ")#mi("{0 < \\lambda \\ll 1}")#text(". Here, the bounds become somewhat interesting, with a subtle distinction between ")#emph[#text("effective")]#text(" estimates that are uniform over all potentials ")#mi("{V}")#text(" which are bounded in a suitable sense by a parameter ")#mi("{A}")#text(" (e.g. obeying ")#tao-math("{\\left|V(x)\\right| \\leq A \\langle x \\rangle^{-2-2\\sigma}}", block: false)#text(" for all ")#mi("{x}")#text("), and ")#emph[#text("ineffective")]#text(" estimates that exploit qualitative properties of ")#mi("{V}")#text(" (such as the absence of eigenfunctions or resonances at zero) and are thus not uniform over ")#mi("{V}")#text(". On the effective side, and for potentials that are strongly short range (at least at local scales ")#tao-math("{\\left|x\\right| = O(\\lambda^{-1/2})}", block: false)#text("; one can tolerate merely short-range behaviour at more global scales, but this is a technicality that we will not discuss further here) we were able to obtain a polynomial bound of the form")

#align(center)[#tao-fit-display[#mitex("C(M,V,\\lambda) \\leq C(M,A) \\lambda^{-C(M,A)}")]]

#text("that blew up at a large polynomial rate at the origin. Furthermore, by carefully designing a sequence of potentials ")#mi("{V}")#text(" that induce near-eigenfunctions that resemble two different Bessel functions of the radial variable glued together, we are able to show that this type of polynomial bound is sharp in the following sense: given any constant ")#mi("{C > 0}")#text(", there exists a sequence ")#mi("{V_n}")#text(" of potentials on Euclidean space ")#mi("{{\\bf R}^d}")#text(" uniformly bounded by ")#mi("{A}")#text(", and a sequence ")#mi("{\\lambda_n}")#text(" of energies going to zero, such that")

#align(center)[#tao-fit-display[#mitex("C({\\bf R}^d,V_n,\\lambda_n) \\geq \\lambda_n^{-C}.")]]

#text("This shows that if one wants bounds that are ")#emph[#text("uniform")]#text(" in the potential ")#mi("{V}")#text(", then arbitrary polynomial blowup is necessary.")

#text("Interestingly, though, if we ")#emph[#text("fix")]#text(" the potential ")#mi("{V}")#text(", and then ask for bounds that are not necessarily uniform in ")#mi("{V}")#text(", then one can do better, as was already observed in a ")#link("http://www.ams.org/mathscinet-getitem?mr=544248")[#text("classic paper of Jensen and Kato")]#text(" concerning power series expansions of the resolvent near the origin. In particular, if we make the spectral assumption that ")#mi("{V}")#text(" has no eigenfunctions or resonances at zero, then an argument (based on (a variant of) the Fredholm alternative, which as discussed in ")#link("https://terrytao.wordpress.com/2011/04/10/a-proof-of-the-fredholm-alternative/")[#text("this recent blog post")]#text(" gives ineffective bounds) gives a bound of the form")

#align(center)[#tao-fit-display[#mitex("C(M,V,\\lambda) \\leq C(M,V) \\lambda^{-1/2}")]]

#text("in the low-energy regime (but note carefully here that the constant ")#mi("{C(M,V)}")#text(" on the right-hand side depends on the potential ")#mi("{V}")#text(" itself, and not merely on the parameter ")#mi("{A}")#text(" that upper bounds it). Even if there are eigenvalues or resonances, it turns out that one can still obtain a similar bound but with an exponent of ")#mi("{\\lambda^{-3/2}}")#text(" instead of ")#mi("{\\lambda^{-1/2}}")#text(". This limited blowup at infinity is in sharp contrast to the arbitrarily large polynomial blowup rate that can occur if one demands uniform bounds. (This particular subtlety between uniform and non-uniform estimates confused us, by the way, for several weeks; for a long time we thought that we had somehow found a contradiction between our results and the results of Jensen and Kato.)")

#text("As applications of our limiting absorption estimates, we give local smoothing and dispersive estimates for solutions (as well as the closely related RAGE type theorems) to the time-dependent Schrödinger and wave equations, and also reprove standard facts about the spectrum of Schrödinger operators in this setting.")

#metadata(none) <tao-701c7a219dadea89a9ca>

#heading(level: 1)[#strong[#text(" — 1. Proof techniques — ")]]

#text("Our main new tool is an analysis of spherical energies of solutions to a Helmholtz equation such as")

#align(center)[#tao-fit-display[#mitex("-\\Delta u - \\lambda u + V u = f")]]

#text("assuming various bounds on ")#mi("{f}")#text(". On a large “sphere” ")#mi("{S_r}")#text(" of radius ")#mi("{r \\gg 1}")#text(" in ")#mi("{M}")#text(" (which, being asymptotically conic, will be equipped with a coordinate that resembles a radial variable and can thus be used to define “spheres”), one considers various “spherical energies” such as the “mass”")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal M}[r] := \\int_{S_r} \\left|v\\right|^2\\ d\\sigma", block: true)]]

#text("“radial energy”")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal R}[r] := \\int_{S_r} \\left|v_r\\right|^2\\ d\\sigma", block: true)]]

#text("or “angular energy”")

#align(center)[#tao-fit-display[#tao-math("{\\mathcal R}[r] := \\int_{S_r} \\frac{1}{r^2} ( \\left|v_{\\text{ang}}\\right|^2 + \\frac{(d-1)(d-3)}{4} \\left|v\\right|^2) \\ d\\sigma", block: true)]]

#text("and so forth. Here ")#mi("{d\\sigma}")#text(" is a suitably normalised surface measure on ")#mi("{S_r}")#text(". If one differentiates these quantities in ")#mi("{r}")#text(" using differentiation under the integral sign, and performs integration by parts, one discovers a number of ordinary differential equations and inequalities relating these energies to each other, which resemble the ")#link("http://en.wikipedia.org/wiki/Bessel_function")[#text("Bessel ordinary differential equation")]#text(" (which is not surprising, since this latter equation naturally emergies from the Helmholtz equation for the free Schrödinger operator in Euclidean space at least, after a separation of variables). Qualitative hypotheses on ")#mi("{u}")#text(" and ")#mi("{f}")#text(" (such as the “Sommerfeld radiation condition”) place certain boundary conditions on these energies at ")#mi("{r=+\\infty}")#text(". It is then possible to perform an ODE analysis to understand the behaviour of these spherical energies in the exterior region ")#mi("{r \\geq R_0}")#text(" for some large ")#mi("{R_0}")#text(", where the asymptotically conic nature of the manifold ")#mi("{M}")#text(" dominates (and in particular, effects such as trapping are not visible). In this exterior region, the ODE analysis shows (roughly speaking) that one of two things happen:")

#list(
[#text("(Bounded energy) The various spherical energies of ")#mi("{u}")#text(" are bounded in terms of ")#mi("{f}")#text(" and ")#mi("{\\lambda}")#text(" in a controlled way.")],
[#text("(Exponential growth) The spherical energies of ")#mi("{u}")#text(" near, say, ")#mi("{R_0}")#text(", are much larger than the spherical energies of ")#mi("{u}")#text(" near ")#mi("{2R_0}")#text(".")]
)

#text("This dichotomy is related to the basic fact that solutions to the eigenfunction ODE ")#mi("{u_{rr} + E u = 0}")#text(" either stay bounded (in the positive energy case) or grow exponentially (in the negative energy case). (This ignores the zero energy case, in which solutions grow linearly, so this analogy should be taken with a grain of salt; but it does already give some flavour of where the dichotomy is coming from.)")

#text("It turns out that the exponential growth portion of the dichotomy can be ruled out as being incompatible with Carleman estimates, which in contrast to the ODE analysis which only focuses on the exterior portion of the manifold ")#mi("{M}")#text(", are driven instead by the geometry of the local portion ")#mi("{r \\leq 2R_0}")#text(" of the manifold. In particular, to establish the Carleman estimate needed one needs to apply some elementary Morse theory to this local region to find suitable exponential weight functions in order to obtain the desired estimates, as was done by Burq. In the high-energy regime, the deployment of Carleman estimates costs us an exponential factor ")#mi("{e^{C(M,A)\\sqrt{\\lambda}}}")#text(", but as is well known, in the non-trapping case, one can use positive commutator methods instead to avoid this loss.")

#text("In the low energy regime ")#mi("{\\lambda \\ll 1}")#text(", one has to treat the medium-range region ")#mi("{R_0 \\leq r \\leq \\lambda^{-1/2}}")#text(" differently from the high-range region ")#mi("{r > \\lambda^{-1/2}}")#text("; in particular, some polynomial growth in the spherical energies can occur in this regime (similarly to how solutions to the Bessel equation can exhibit polynomial growth). However, apart from this detail, the methods are largely the same.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/#comment-217239")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")])]

#text("Hi Terry, a quick question about “for standard technical reasons … d >= 3”: you do not actually mean that there is an obstruction for d =2 , correct? I assume the standard technical reasons is the one giving the different form of the Newton potential in d = 2. If that is the case, do you know if the analogous analyses have been carried out in the two-dimensional case anywhere? Agmon’s paper (your citation [1]) seems to work for all dimensions, but quite often he just proves the d>=3 case while stating that d=2 can be done analogously with obvious modifications.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/#comment-217281")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")])]

#text("Well, in this specific paper, there is an additional obstruction at d=2 due to our use of the positive commutator method, which relies on the positivity (to top order, at least) of various commutators ")#mi("i[-\\Delta_M, S]")#text(" for various key operators ")#mi("S")#text(" in order to get good estimates after an integration by parts. In particular, we rely on the essential positivity of a double commutator which is basically ")#tao-math("-[-\\Delta_M,[-\\Delta_M,\\left|x\\right|]]", block: false)#text(". In order to fully exploit this positivity, one needs ")#tao-math("-\\Delta_M^2 \\left|x\\right|", block: false)#text(" to be mostly non-negative, but this only holds in dimensions three and higher.")

#text("(There is a similar technical issue with Morawetz type estimates, which also need significant modification in two dimensions.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/#comment-217283")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")])]

#text("Ah, I see. Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/#comment-451288")[#strong[#text("Carleman estimates | 逝去日子")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2015")]

#text("[…] 2. web: ")#link("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/")[#text("https://terrytao.wordpress.com/2011/05/05/effective-limiting-absorption-principles-and-applications/")]#text(" […]")
]
