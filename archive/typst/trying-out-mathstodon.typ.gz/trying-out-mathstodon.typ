// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/
// Converted to Typst by tao2typ: "2026-10-14T16:39:04.588149+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Trying out Mathstodon", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Trying out Mathstodon")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 November 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/")[#text("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("It’s been a while since I’ve actively participated in social media outside of this blog – I was active in Google Buzz/Google+ for a while, until that service closed – but I’ve decided to try out ")#link("https://mathstodon.xyz/")[#text("Mathstodon")]#text(", one of the servers of the open source social media software platform ")#link("https://joinmastodon.org/")[#text("Mastodon")]#text(". As I understand it, Mastodon functions in many ways similar to the significantly more well-known platform Twitter, but is decentralized into a ")#link("https://en.wikipedia.org/wiki/Distributed_social_network")[#text("federation of servers")]#text(" that share content with each other but can have their own moderation rules and add-ons. For instance, the Mathstodon server has the additional feature of ")#link("https://mathstodon.xyz/about")[#text("supporting LaTeX in its posts")]#text(". Another consequence of this decentralization is that if one for some reason ends up disagreeing with the administration of the server one is in, one has the option of transferring one’s account to a different server while staying on the same platform.")

#text("I just created an ")#link("https://mathstodon.xyz/@tao")[#text("account at Mathstodon")]#text(" and it currently has very little content, but I hope to add some soon (though I will probably not be as prolific as some other mathematicians already on that site, such as ")#link("https://mathstodon.xyz/@johncarlosbaez")[#text("John Baez")]#text(" or ")#link("https://mathstodon.xyz/@monsoon0")[#text("Nalini Joshi")]#text(").")

#heading(level: 1)[#text("Comments (14)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-667981")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("The supporting Latex feature is vey welcoming, wish twitter has Latex support, as many mathematicians are on twitter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/122c551f8343c80cea8ac3abeb525db10555120fabb7d1ab94994f661caf9bb1-9cec9dd4403afc0841f70ab6e1403702361dac370734f49d99390c88f5787ba0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Balhau")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-667991")[#strong[#text("Balhau")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2022")])]

#text("Following. Thanks Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668005")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("The truly wonderful feature just added in the current version is the ability to edit previous posts.")

#text("Regards,")

#text("Jon ")#link("https://mathstodon.xyz/@Inquiry")[#text("https://mathstodon.xyz/@Inquiry")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3abca4f6e4f1eca2618d75bef99f2ce19e37fc459e66444c471057e1e73e2951-b4bce1b72909577678e7f8c89c51c02a941139573f85e865c94635970890584d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan Moehler")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668031")[#strong[#text("Stefan Moehler")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("I’d like to invite you to our teaching platform (non-profit): ")#link("https://www.physicsforums.com/")[#text("https://www.physicsforums.com/")]

#text("It also supports Latex (well, MathJax to be exact) and it is targeted to help students. Tutorials (for free) on the university level combined with discussions about recently published papers in STEM fields, plus some general forums for entertainment. So, in case, you’ll find some time to either share your publications or to teach some students, you’re welcome.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668244")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2022")])]

#text("It seems that server (Mathstodon) is available for registration only with invitation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/570044150d90f16b29a8906a025b503d65d3e14a01875d7060feb010b2389eda-8889ae34c3458b08263a584cc4e3fede321bd8e83a5b6950c428b5dc9f3d5fd8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jon Awbrey")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668315")[#strong[#text("Jon Awbrey")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("Temporary condition to let the servers catch up with the mass maths influx.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Announcement")

#text("We have temporarily restricted registrations to invitation only to allow the server to stabilise again. We apologise for any inconvenience.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e33f0cf3ff2cfacb48518ae3118e0675590728de2374757a47d0cc52a725fd30-3f1634f4a267d36824da021d5f9bb65e5601398c33b794515651a5165cc4235d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Weidig")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668317")[#strong[#text("Tom Weidig")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2022")])]

#text("A network needs critical mass for it to be useful. I cannot see this happening with a Twitter clone any time soon, especially as the main motivation for people to move to Mastodon seems to be that they don’t like people having a different opinion and world view than theirs being re-instated at Twitter after having been banned.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668471")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2022")])]

#text("Pretty sure the reason people are leaving twitter is because The Biggest Twit – or whatever he calls himself – is behaving like an immature twit.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5149ed0f511d9a006f242d770ed0e6844187ffa8a653e9415588163662e5759b-60a6d379e635f9ea6bd575ebed324d6b79fcec51d542c1a85b34d1fbaaeb3cf5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MuskRat")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668765")[#strong[#text("MuskRat")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2022")])]

#text("No Tommy, it’s not “differences of opinion” – it’s being fed up with having to wade through racist, non-inclusive, anti-science drivel.")

#text("Like yours.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9accd03eae248b23accfc31fea7f425e38463ea509e81d37f7fe0efac3a4878-f846f99433bba147486e5ba36361e7790ece49e8452077944394768ca97949b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-682825")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2024")])]

#text("“Racist”, says the racist who thinks blacks can’t be racist, race isn’t real, but white people should be discriminated against.")

#text("“Anti-science”, says the gullible moron who thinks men can get pregnant.")

#text("“Non-inclusive”, says the fanatic who wants to exclude normal people from public life and the public conversation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/882b89264adca4a32ab23441a4535c76372feff1850832f90a091f6c1a7bc0b1-f7749dc6a0a8953c92d20a435c7c52de1e1cdb55198bf0071e0f2c88d7f171e4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zahmir")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-673300")[#strong[#text("Zahmir")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2023")])]

#text("Useful to whom?")#linebreak()#text(" As long as you’ve got a few colleagues and interesting people – and there are plenty of those @ Fediverse – you can have a nice experience.")#linebreak()#text(" Do you really have to keep a tab on all the people you’ve once crossed, labeling everyone as “Friends”? Does it really matter what your high-school bully has been eating, or what that dude from that one party thinks about the Senate?")

#text("There is nothing social in the way massive plataforms of personal data exploitation have been set up.")

#text("Would you rather have your family’s and loved ones’ personal lives explored by this new economy, or have them safeguarded by the Universal Human Right to Dignity?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f442e1cd836be633a263d66af8f27add361ea671db74acfb6d6300fe2286f5a8-1fd8cb264e12c4c48751b4736861568a93027509ff24201f3974df510d660950.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Certain Comments")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-668778")[#strong[#text("Certain Comments")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2022")])]

#text("I would think at this stage (regardless of what his thought process was before the buy) Musk’s plan is pretty much by the playbook if you replace Musk by any activist investor. Go into a loss making company cut the workforce. Make the company little shiny by the books and sell for a profit. In this particular case he has an additional agenda of bringing non-wanted entities back to Twitter such as the ex-president. Even his new temporary relief from suspension of all suspended users can be thought in that light – to bring more users active – so that the books look prettier. Once the lipstick has been laid on the pig (Twitter), it will be sold off.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c02e760ba824fbfb29d0705bff9f43e28147cc6166b3ffd6ee502030663db005-ca93c80df0117313fe9c395093f3a4cece1c3fd9ed78a187850cba4744bada89.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KAIN UWIZER")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-672789")[#strong[#text("KAIN UWIZER")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("Maths please.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/301943967ebcc3e6a2c22c102e3c2262e67a7907a9e7bcffbfd329bfd89001c8-b08ebc9e534ca6726a7ae191313bafb1c0942f970a4f13162ddf8b5c1d904432.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zahmir")]], [#link("https://terrytao.wordpress.com/2022/11/20/trying-out-mathstodon/#comment-673299")[#strong[#text("Zahmir")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2023")])]

#text("i believe Science should be open. Social networks relating to science should be free/libre and open as well.")#linebreak()#text(" Also, being a Science now a days means following Ethics. Its not just following the scientific method. Therefore, the new field of Data Science has to be humane and ethical to be a real science.")#linebreak()#text(" All the success to libre and decentralzied social media!")
]
