// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/
// Converted to Typst by tao2typ: "2026-10-14T11:19:40.338412+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Becoming a benchmark", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Becoming a benchmark")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/")[#text("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://dependenttyp.es/")[#text("Talia Ringer")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("When I was wrapping up graduate school in computer science in Spring 2021, I was given access to a curious little programming model on OpenAI’s “playground.” The model, called ")#link("https://en.wikipedia.org/wiki/OpenAI_Codex_(language_model)")[#text("Codex")]#text(", took in natural language text and generated programs from that text. The task of automatically generating programs given an expression of programmer intent had been one of many major questions in my field of study—programming languages—for decades. This was the first time I had seen a neural model, with little to no input from anyone in my field, actually succeed at that task to any degree. This was more than a year before ChatGPT was released, and yet I knew that everything was about to change.")

#metadata(none) <tao-6f311979098bdf9f8ed6>#text(" On one hand, I was glad that programming was becoming more accessible. My mom came to visit shortly after that, and I pulled out my laptop and told her she could now program. I had her make a little video game. It was not perfect, sure, but my mom was programming, and that was wild. I had always wanted programming to become accessible to everyone.")

#text("On the other hand, I had ")#emph[#text("so many worries")]#text(". At a technical level, would the software of the future be full of AI-introduced bugs? Would people run a bunch of unit tests on AI-produced programs and think that they are OK, but miss out on edge cases? Would AI tools overfit to the tests they are given access to? Would people sometimes ")#emph[#text("feel")]#text(" more productive using these tools, but actually get less done? (Yes, yes, yes, and yes.)")

#text("Those technical worries were overshadowed by a larger existential dread. My specific focus within programming languages research had been on using classic programming languages techniques to make it easier to write formal, machine-checkable proofs using proof assistants like Rocq and Lean. Was my entire field of research about to die? To be swallowed by AI? I was not worried about my field ")#emph[#text("actually")]#text(" being fully “solved,” but I was very worried about the prospect of AI researchers ")#emph[#text("claiming ")]#text("to fully solve my research area, and of the general public actually believing them. I had seen this play out before in linguistics and natural language processing.")

#text("Worse, if AI swallowed my field, would AI’s ")#emph[#text("culture ")]#text("leak into my field’s culture? I had known AI’s culture to involve all sorts of things I find distasteful and immoral in research, like “scooping,” competition, and secrecy. My field, by contrast, was (and thankfully still is) a lot more like mathematics in this regard. We value communication, collaboration, and openness. I was scared that AI would rot this culture from without.")

#text("I have come to understand what I went through as the AI grief cycle, the one that starts when one’s life’s work becomes a benchmark for AI companies. And as I worked through this cycle of grief, I realized that I had to communicate both to AI companies and to the general public that my work will not be replaced by these tools, but that it will change. I had to understand that myself, come to terms with it, and move with it in my own work. And above all, I had to make sure incentives stayed aligned with that reality.")

#text("This started with communicating what I ")#emph[#text("actually")]#text(" do, both to the AI community and to those outside of it who set incentives. This was the most exhausting part of it, since I was coming from a small research community, while the AI community is large and powerful. So that means I really had to immerse myself and learn to speak their language. In lieu of that, it would have been too difficult to honestly and reputably assess the limitations and impacts of what AI tools do. (In doing so, I accidentally nerd-sniped myself into actually doing AI work as part of my broader research portfolio, but it is probably possible and fine to do this in a way that still keeps one’s research far away from AI.)")

#text("On an individual level, funders and the AI community alike have since come to respect me. And also, my field of programming languages has come out pretty OK so far. I will never know how much of an impact I have had on that. But I have found that the whole community has reacted in ways that are pretty aligned with what I have done. We have engaged honestly with the changes, and we really have assessed both the capabilities and limitations of the tools that had infringed on our field so suddenly. When relevant, now, we use neural techniques to improve our own work. But we have also found ways that our techniques are strictly complementary to those techniques, and we have figured out how to communicate that. Our culture has come out intact, too.")

#text("But I think one thing we have going for ourselves in programming languages is that basically nobody has ever heard of our field, and most people do not care about what we do. People do care a lot about math. We don’t even get the “oh, I ")#emph[#text("hate")]#text(" math” response that mathematicians get; hatred means that people care.")

#text("Culturally, at least in the US, math is simultaneously revered and hated. Peak “intelligence” is often culturally associated with mathematical ability—people even bring up Terry Tao as an example of this. Poor performance at math, or anxiety around such poor performance, is often coupled with statements about not being “smart enough” to do math. Mathematicians, then, come to represent the intellectual elite, with all of the scapegoating such a label carries. And leaders of AI companies come to believe that if they can “solve math,” they can “")#link("https://www.math.inc/vision")[#text("solve everything")]#text(",” whatever that means. (Sorry, ")#link("https://jesse.so/")[#text("Jesse")]#text("; we are still friends.)")

#text("Because of this dual reverence and hatred, people are paying way more attention to AI infringing on math than they did to AI infringing on my field. This is good and bad. It does mean that mathematicians’ statements are getting lots of coverage; they have a real chance to communicate to the entire world what it is they actually do. But it also means that their legitimate sour gripes are being misread as sour grapes. There is a perception that they are gatekeeping. Just like, in 2021, if people had paid this much attention to my field, they might have wrongly concluded that I was just being bitter because I did not want my mom to be able to program. (I did!)")

#text("This makes mathematicians’ jobs harder than mine was. Their audience can at times be actively adversarial. Just learning the language of AI folks will not be enough.")

#text("Still, I think mathematicians are on the right track. The work many are already doing of addressing the public is even more important than addressing the AI industry. Yes, the AI industry’s goals are ")#link("https://mathandai.org/")[#text("misaligned")]#text(" with those of the math community. But it is actually OK if that remains true, so long as the rest of society recognizes that misalignment and continues to value and incentivize the kind of work that mathematicians value. AI companies will always want to use whatever field is hot at the time to show that their models are the “best.” There are ways to help them better understand what “best” should mean, but it’s also pretty OK if they never do understand that, as long as the general public does. So math—the process, not the benchmark—will need a PR campaign that lasts for as long as math the benchmark is relevant to AI companies. That means deliberate and consistent engagement with news outlets, social media, education systems, policymakers, and funders.")

#text("This work of engagement is exhausting and unending, but it does get easier as society and AI companies alike move on. Remember when art and writing were the main targets of these companies? Two things seem to have happened: First, society seems to have collectively developed a distaste for AI art and writing, and even for human art and writing that vaguely resembles AI art and writing. Second, AI companies seem to have reached the point at which showing off their tools’ art and writing results no longer proves them to have the “best models,” so they have largely moved on to other fields.")

#text("Have art and writing been negatively impacted? Absolutely. And the fight is still ongoing. But at least the fight is no longer all-consuming. (Collective action like unionizing, or like the Hollywood writer’s strike, might also have to do with that, though. I do think mathematicians should consider unionizing.)")

#text("And what if mathematicians actually ")#emph[#text("do")]#text(" want AI tools that help with math the process, and not just math the benchmark? (I do. I’m ")#link("https://www.ams.org/journals/notices/202409/rnoti-p1179.pdf")[#text("super excited")]#text(" about what math could be like in such a world.) In that case, I think it is probably best to look for collaborations with smaller companies and academics, especially those that have a participatory model where mathematicians get to ")#link("https://plait-lab.org/")[#text("co-design")]#text(" the tools to reflect their own values and use-cases. (I have one such collaboration with ")#link("https://emilyriehl.github.io/")[#text("Emily Riehl")]#text(" already, and I am hungry for more!) It also helps to be upfront about expectations around credit, especially where the culture might clash.")

#text("In any case, a ")#link("https://faculty.washington.edu/ebender/")[#text("friend")]#text(" who is a professor of linguistics told me in 2021 that, in ten years’ time, my research would be different in ways I could not possibly predict ahead of time. And that still, it would be OK. I took great comfort in that. It really will be OK.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I appreciate the optimism among the grief, I really do, but I find it difficult to share in that optimism right now. As an artist (and game developer) myself, I’m not sure that companies ")#emph[#text("have")]#text(" meaningfully moved on from my field. Yes, it’s no longer the headline result, but that’s mostly for sociological reasons, not because progress has stalled. Human-made art will always have value for fellow humans, but for commercial purposes, the industry is rapidly becoming a zombie of its former self. We can still find meaning in our work, that is true. But will we be okay? Both financially and existentially, that’s going to be dependent on how society chooses to react.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695533")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Pure mathematics doesn’t have the economic potential that art and game developing does. The principal economic benefit they bring to society is teaching future professionals, which for now feels safe (humans would probably prefer to be taught by humans, either because AI can’t be as good as a physical teacher or for solidarity reasons as people would not want to see other people lose their jobs).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("The purpose of professional art and game dev is not to find meaning, it is to produce art and games that people enjoy. What will happen is that professional game dev is going to get a lot more boring, people will stop going into it as much, and the salaries of game developers will stop being artificially kept low by people who go into the industry to find meaning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f02c448f4b1dbc3bd296189d04780902fa3ab2607ddf0f4f050f32a373682cfe-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Talia Lily Ringer")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695543")[#strong[#text("Talia Lily Ringer")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("Fair enough, thanks for the comment. I do think, at a much higher level, we urgently need changes to our socioeconomic system to help those who are being or will be put out of work by automation in the near future. I tried to keep this particular post fairly confined in scope, but I am writing a number of op-eds this year, and I’ll try to write at least one about that. I’m worried all of the doomer stuff is distracting from those needed socioeconomic changes. I also think it can be overwhelming for most people to think about needed changes that may be outside of one’s circle of influence.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Being worried about AI takeover scenarios and seeing the need for socioeconomic change are not at all at odds! They both cash out to not letting the AI companies do what they want as one of the most important actions.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I was not worried about my field ")#emph[#text("actually")]#text(" being fully “solved,” but I was very worried about the prospect of AI researchers ")#emph[#text("claiming ")]#text("to fully solve my research area, and of the general public actually believing them.")
]

#text("Do you worry about your field “")#emph[#text("actually")]#text(" being fully solved”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695657")[#strong[#text("Talia Lily Ringer")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")]

#text("Is this a question for me, for Terry, or for someone else? I don’t worry about that for my field these days either. I don’t even think the idea of my field being fully “solved” makes sense. I feel the same way about math.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695751")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Regarding programming becoming more accessible-")

#text("I understand the sentiment about accessibility and inclusion. However, this paragraph describes labor deskilling. Making programming accessible through technology/automation doesn’t actually help regular people. It undercuts the bargaining power of software engineers and computer professionals and transfers all the surplus to the employer. We wouldn’t say that the industrial loom made textile manufacturing accessible looking back historically, we would simply view it as deskilling.")

#text("Regarding AI companies, PR, etc.-")

#text("Sure the AI companies will move on from math eventually. But I don’t think this means that math will be fine. AI companies only need to keep generating proofs until they convince the public and the influential people that AI is as good as or exceeds the capability of the best mathematicians. Based on the Royal Fellows letter posted recently on this blog, the consensus among mathematicians is that AI models are already operating at this level. As a late stage math PhD student right now, the models are already better than I am, and I haven’t even used the most powerful ones (for whatever that is worth). It is quite surreal to see a chatbot reproduce the research I’ve spent the past few years on after typing in a few prompts and waiting a few seconds.")

#text("Anyway, then the case for funding math to the extent we do now will dry up (at least in my opinion) because it will be hard to explain to the public why we should have armies of PhD students, postdocs, etc. to read chatbot output and parrot the result back out to others. I wish this weren’t the case (I like my funding), but I haven’t heard any convincing reasons why this won’t happen. And if math becomes like art like many are saying, then certainly the funding will dry up. I mean the National Endowment for the Arts is a couple pennies relative to the national budget, and grad students in art subjects rarely if ever get funded like PhD students in math.")

#text("I don’t think unionization will really work for mathematicians either. There are no material consequences if academic mathematicians withhold labor, with the exception of teaching undergraduates. More generally, sufficiently advanced AI will decimate unionization because if one’s labor is made redundant, then withholding it does nothing. Same thing for political mobilization, because state action has historically been constrained by requiring human labor for law enforcement and administrative action.")

#text("Regarding mathematicians who want AI tools-")

#text("I mean wasn’t Lean considered a community based project that reflected the values of mathematicians, CS people, academics, etc until quite recently? Now it is being used to clobber and delegitimize the profession by the tech companies. But I don’t see how there is any way to build such a technology without decimating mathematics and related fields as a profession, regardless of ownership structure. For what it is worth, I used to be interested in such technologies along with other topics in programming language theory and formal methods. I still agree that the math is interesting, but I don’t see how the technology leads to anything other than a political disaster.")

#text("(My apologies if this comment has been submitted multiple times. It doesn’t appear immediately so I think it may be getting caught in the spam filter described in the instructions for how to comment.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c468377144f25fa6779f0067feba68c953d8b299fe553b0f836174dd933947f-69e5c9ffeca36f03ef3737cb65abb5e04ed1efe89727aea1cd203170ab5fe878.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jimmy")]], [#link("https://terrytao.wordpress.com/2026/09/17/becoming-a-benchmark/#comment-695804")[#strong[#text("Jimmy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("The benchmark discussion is a helpful reminder that measurement changes behavior once people start optimizing for it. In AI coding workflows I see a similar pattern: teams need benchmarks, but also operational notes about when tools are constrained, reset, or failing, otherwise the score and the lived reliability diverge.")
]
