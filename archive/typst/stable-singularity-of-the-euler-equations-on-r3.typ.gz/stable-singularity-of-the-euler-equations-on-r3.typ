// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/
// Converted to Typst by tao2typ: "2026-10-16T11:39:24.665500+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Stable singularity of the Euler equations on R^3", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Stable singularity of the Euler equations on R^3")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/")[#text("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-16 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://tensorlab.cms.caltech.edu/users/anima/")[#text("Anima Anandkumar")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("The last few days have been a flurry of activity. After months of sleepless nights and diving deep into different mathematical and computational tools to tackle the open problem of singularity in fluid dynamics, we were finally ready to send our work on Euler equations (without forcing) to Tom Hou and Terry Tao for feedback. Almost immediately I heard back from Terry encouraging us to release our work publicly, given that the NYU team had just released their results on forced Euler and OpenAI was rumored to release the next day.")

#text("We scrambled and put together a ")#link("https://tensorlab.cms.caltech.edu/users/anima/euler.html")[#text("blog post")]#text(" and attached our paper with code, which went live about 30 minutes after, in the evening of September 7, the day before the OpenAI’s announcement. A lot of mainstream media religiously followed their press release that fails to acknowledge our work even after we informed them. On the bright side, many researchers have reached out to me. I want to thank Terry for highlighting our work, as well as for giving me the opportunity to write this blog post.")

#text("The starting point for us is different from the route that the NYU team and OpenAI pursued. Their initial solution has a specific construction with a multi-scale structure with discrete jumps in scales. On the other hand, we consider a self-similar ansatz, and so far, no one has been able to construct a self-similar singular profile for the Euler equations in ")#mi("{{\\bf R}^3}")#text(" without forcing. Modified cases such as the Euler equation with a boundary have been successfully solved before (")#link("https://www.pnas.org/doi/10.1073/pnas.2500940122")[#text("Chen and Hou")]#text("), where the boundary helps confine the singularity, but such techniques fail in free space.")

#text("We wanted to see if AI could come up with a self-similar profile for Euler. LLMs are not suited for generating such singularity candidates without analytical closed forms. Physics informed neural networks (PINN), on the other hand, can be optimized to find such solutions. Although there have been prior attempts to use PINNs for this case, they were not successful. There are optimization and precision challenges: with standard ansatz and optimizers, a common failure mode is getting the trivial solution. The other challenge is getting precision to be high enough, so we can then attempt to convert the numerical solution into an analytical proof. This additionally requires stability at the PINN solution, which may not always occur.")

#text("When it comes to establishing singularity, we cannot directly use the Euler PDE, since that would blow up at the candidate solutions. Finding the right ansatz with enough structure is important, so it can be re-parameterized to finite solutions. Typically axisymmetric self-similar ansatz is chosen since it makes both optimization and analysis simpler.")

#text("In our PINN, we employ a traveling-wave self-similar ansatz since it allows us freedom to choose the velocity at which singularity travels along the ")#mi("{z}")#text("-axis. Although this is equivalent to a stationary ansatz for analysis, this flexibility of traveling singularity, along with removal of hard constraints such as ")#mi("{z}")#text("-parity, makes our optimization landscape more tractable. Efficient second-order optimizers such as SS-eSOAP, developed in our group, further help with convergence and are only slightly more expensive than the standard Adam optimizer. This allowed us to run an extensive set of experiments without needing massive compute. We refined our solutions only at the very end with an expensive optimizer SS-Broyden to get further increase in our accuracy. Further, methods like adaptive loss weighting, high-precision arithmetic (FP64), boosting, adaptive collocation all helped obtain high-precision solutions.")

#text("Our PINN solution aligns with prior theory and this was important for us to check constantly throughout the process. ")#link("https://arxiv.org/abs/2602.17570")[#text("Constantin et al")]#text(" predict for self-similar ansatz the scaling exponent of 0.5 as “mathematically distinguished” for the Euler equations, and essentially rule out other values of the exponent for the axisymmetric case. When we make the scaling exponent a free parameter in our PINN optimization, it still converges close to 0.5, confirming agreement with theory. Further, when we optimize the PINN over a family of ")#link("https://www.proquest.com/openview/1fb23bb74c6f902f8d6c20bfb69927be/")[#text("convection-weighted Euler")]#text(", where we can vary the contribution of the convection term, the scaling exponent decreases towards 0.5 as we increase the contribution of the convection term, again in line with theory. All these careful checks increased our confidence that we were on the right path.")

#text("The other important piece of the puzzle is checking if our PINN solution is stable. Earlier works on related blowup problems could typically prove a global outgoing property for their approximate profile, which unfortunately does not hold in our case. However, there are recent theoretical arguments by ")#link("https://arxiv.org/abs/2602.17570")[#text("Constantin et al")]#text(" that non-trivial fixed points exist where the transport term vanishes, and thus, the flow cannot be globally outgoing. Instead, we have to work with the weaker local outgoing property for stability, which is more involved. We verify that our PINN solution does indeed satisfy the local-outgoing property, allowing us to make stability arguments.")

#text("To make it a rigorous proof of stability, we need to go from discovering singularities numerically with PINNs to being able to provide tight bounds around the approximate profile. To do so, we fit the PINN solution into piecewise-polynomial splines, allowing derivatives, PDE residuals, and profile-dependent quantities to be evaluated and bounded using arbitrary-precision interval arithmetic.")

#text("We then formulate the stability problem in dynamically rescaled variables and develop weighted low- and high-order energy estimates adapted to the singular profile. Optimizing the associated singular weights reveals complementary damping mechanisms throughout the domain. In order to complete the stability proof, the non-linear contribution can be quite involved with thousands of terms. This is where LLMs play a role, and we used the OpenAI and other models extensively to simplify our bounds as well as formalize the derivations in Lean. The overall set of steps is shown in the diagram below.")

#box(width: 90%, inset: 6pt, stroke: 0.5pt + rgb("d9dfe8"))[#text(size: 9pt)[#text("Image unavailable") · #link("https://terrytao.wordpress.com/wp-content/uploads/2026/09/anandkumar-image1.png")[Original image]]]

#text("Overall, our core contribution is making PINNs work successfully to produce a self-similar singular profile for the first time in Euler equations on ")#mi("{{\\bf R}^3}")#text(" without forcing, and then certifying its bounds over an interval with high enough precision to carry out the stability analysis. We believe that these techniques will have diverse applications both in theory and practice. In the theory and analysis of PDEs where analytical constructions may be out of reach, and hence, LLMs are not that helpful, PINNs can potentially discover new solutions in high enough precision that they can be certified and converted into analysis. Additionally, in the practical realm they can be applied for simulation, design and discovery in areas involving physical systems.")

#text("This is something my group at Caltech has been working on more broadly. While PINNs aim to find the solution for a given instance of PDE, we have proposed Neural Operators that learn mappings between function spaces, and can learn the solution operators of families of parametric PDEs. We used Neural Operators to train the first high-resolution AI-weather model more than five years ago, which is tens of thousands of times faster, which allows us to support larger statistical ensembles for forecasting extreme events such as hurricanes and heat waves. We have designed a medical catheter that cuts down bacterial infection by hundred-fold using Neural Operators that learn fluid behavior, and optimized gate layouts in quantum dots. An exciting recent application of Neural Operators is solving a 60-year old problem in quantum chemistry to make density functional theory run in quasi-linear time, by skipping the auxiliary orbital calculation, and yet learning universal Kohn–Sham maps that are generalizable and transferable across molecular and material systems.")

#text("What all these cases have in common is how we are thoughtful about building AI and what purpose they serve. LLMs are trained on human text, to be good at tasks that humans are already good at, often with the explicit goal to compete with or replace human effort. Instead, our work focuses on building AI that complements human capabilities. In all the above cases, including our work on the Euler equations, we built physics-AI to propose solutions that did not compete with humans, since they are not analytical or in a structured form. This leaves room for human creativity to design the setup and the strategy for the overall proof. We want our AI to be complementary and collaborative with human creativity to enable us to push the frontiers of math and science even further.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fa776b8dd75048512ca5c43cb43f80641e99d59d459e5119374fcf6474e2a9d-d5e001d44e6e766b0e76602fc2257b912b11679f6e45b33112d236f689999959.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sukessh Velusamy")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694441")[#strong[#text("Sukessh Velusamy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("I am not a mathematician (just someone interested in math) so please indulge my ignorance, but I thought it standard mathematical practice to cite/mention prior work if and only if your work builds upon it. Considering that OpenAI’s approach was completely different than Anandkumar and her team’s, why would OpenAI be obligated to cite/mention it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694446")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("That is part of it. People often cite related work as well. Even if the work does not directly build on the cited works, another work may be cited for a few reasons:")

#enum(start: 1, 
[#strong[#text("To compare to state of the art")]#text(" Maybe the published result strengthens an existing result using an entirely new method. It would still make sense to cite the previous work so others can see what came before, even if the method was completely different.")],
[#strong[#text("To compare to related work")]#text(" Suppose a different problem is solved using similar methods. Citing the similar methods allows other researchers to build connections between the methods and to generalize.")],
[#strong[#text("To get people to see the paper")]#text(" This one is more complicated. If a paper cites others, and the citations are relevant, this helps bring attention to your paper. When reading a paper, people often want to track the references when getting more details about a particular method or step. By getting your paper in the citation network, people will see your paper listed in the “cited by” part of many other papers. Since a paper should have relevant citations and peer review should make sure the citations are appropriate, this is not the whole goal. Even so, number of citations often acts as a way of estimating the relative importance of a paper (this is by no means a perfect measurement of a paper’s importance).")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fa776b8dd75048512ca5c43cb43f80641e99d59d459e5119374fcf6474e2a9d-d5e001d44e6e766b0e76602fc2257b912b11679f6e45b33112d236f689999959.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sukessh Velusamy")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694447")[#strong[#text("Sukessh Velusamy")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("Thank you for clarifying! So, what should OpenAI do in this case? Should they modify their paper to mention Anandkumar and her team’s concurrent work?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694451")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("The author is commenting on mainstream press generally ignoring this work but highlighting competing work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694469")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("This is a good point. I can share my experience though.")

#text("when I try to solve a math problem, I rarely work in isolation. I need to read and understand prior work (just like AI). However, unlike AI this reading shapes my point of view on the material.")

#text("As a result, when I end up proving a theorem, I will naturally do so from the perspective that I’ve built internally in my mind. Thus, I will end up citing the previous work, even if for the mere purpose of comparing/explaining the differences with the existing literature.")

#text("AI is very similar in the sense that its output is shaped by the input. However, since it does not really build any ”understanding” it does not report the findings the same way I do.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694491")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("To be honest, I don’t have a coherent theory of “understanding” which would definitively exclude what the LLMs are doing as simply “understanding”.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694456")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2026")])]

#text("The author is commenting specifically on OpenAI’s press release not mentioning their related work.")

#emph[#text("“We scrambled and put together a blog post and attached our paper with code, which went live about 30 minutes after, in the evening of September 7, the day before the OpenAI’s announcement. A lot of mainstream media religiously followed their [OpenAI’s] press release that fails to acknowledge our work even after we informed them.”")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694480")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Nasa had reusable rockets ideas in 60s but am I thinking private enterprise and venture capitalism is idealized and hence EM wave?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694481")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The mainstream press, unfortunately, cares more about big headlines like ‘Navier-Stokes solved!’ than “boring” advancements like improving PINNs to better analyze blowup in the unforced Euler equations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694492")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("So press never cared about Musk stealing trillions of $s of Nasa research and convincing everyone of his genius.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fa776b8dd75048512ca5c43cb43f80641e99d59d459e5119374fcf6474e2a9d-d5e001d44e6e766b0e76602fc2257b912b11679f6e45b33112d236f689999959.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sukessh Velusamy")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-694494")[#strong[#text("Sukessh Velusamy")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("To be fair, I’m pretty sure NASA freely gave away their research, so I don’t think it is possible for anyone to ‘steal’ it.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/09/10/stable-singularity-of-the-euler-equations-on-r3/comment-page-1/#comment-698140")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2026")])]

#text("This PINN approach did not actually yield a rigorous proof, but instead only a numerical candidate and a proposed path toward a proof. Has there been any progress since this post toward completing that proof? If not, what evidence is there that the remaining steps are tractable, rather than simply another set of difficult open problems? And why would OpenAI, or anyone else with an actual rigorous proof cite this work? What specific mathematical result does it contribute that such proofs rely on?")
]
