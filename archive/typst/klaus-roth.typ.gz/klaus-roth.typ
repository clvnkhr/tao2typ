// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/11/12/klaus-roth/
// Converted to Typst by tao2typ: "2026-10-14T15:19:36.741203+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Klaus Roth", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Klaus Roth")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 November 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/")[#text("https://terrytao.wordpress.com/2015/11/12/klaus-roth/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://en.wikipedia.org/wiki/Klaus_Roth")[#text("Klaus Roth")]#text(", who made fundamental contributions to analytic number theory, died this Tuesday, aged 90.")

#text("I never met or communicated with Roth personally, but was certainly influenced by his work; he wrote relatively few papers, but they tended to have outsized impact. For instance, he was one of the key people (together with Bombieri) to work on simplifying and generalising the ")#link("https://en.wikipedia.org/wiki/Large_sieve")[#text("large sieve")]#text(", taking it from the technically formidable original formulation of Linnik and Rényi to the clean and general almost orthogonality principle that we have today (discussed for instance in ")#link("https://terrytao.wordpress.com/2015/01/10/254a-notes-3-the-large-sieve-and-the-bombieri-vinogradov-theorem/")[#text("these lecture notes of mine")]#text("). The paper of Roth that had the most impact on my own personal work was his ")#link("http://www.ams.org/mathscinet-getitem?mr=46374")[#text("three-page paper")]#text(" proving what is now known as Roth’s theorem on arithmetic progressions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Roth’s theorem on arithmetic progressions)")]#text(" Let ")#mi("{A}")#text(" be a set of natural numbers of positive upper density (thus ")#tao-math("{\\limsup_{N \\rightarrow\\infty} \\left|A \\cap \\{1,\\dots,N\\}\\right|/N > 0}", block: false)#text("). Then ")#mi("{A}")#text(" contains infinitely many arithmetic progressions ")#mi("{a,a+r,a+2r}")#text(" of length three (with ")#mi("{r}")#text(" non-zero of course).")
]

#text("At the heart of Roth’s elegant argument was the following (surprising at the time) dichotomy: if ")#mi("{A}")#text(" had some moderately large density within some arithmetic progression ")#mi("{P}")#text(", either one could use Fourier-analytic methods to detect the presence of an arithmetic progression of length three inside ")#mi("{A \\cap P}")#text(", or else one could locate a long subprogression ")#mi("{P^{\\prime}}")#text(" of ")#mi("{P}")#text(" on which ")#mi("{A}")#text(" had increased density. Iterating this dichotomy by an argument now known as the ")#emph[#text("density increment argument")]#text(", one eventually obtains Roth’s theorem, no matter which side of the dichotomy actually holds. This argument (and the many descendants of it), based on various “dichotomies between structure and randomness”, became essential in many other results of this type, most famously perhaps in ")#link("http://www.ams.org/mathscinet-getitem?mr=369312")[#text("Szemerédi’s proof")]#text(" of ")#link("https://en.wikipedia.org/wiki/Szemer%C3%A9di%27s_theorem")[#text("his celebrated theorem on arithmetic progressions that generalised Roth’s theorem to progressions of arbitrary length")]#text(". More recently, ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("my recent work on the Chowla and Elliott conjectures")]#text(" that was a crucial component of the solution of the Erdös discrepancy problem, relies on an ")#emph[#text("entropy decrement argument")]#text(" which was directly inspired by the density increment argument of Roth.")

#text("The Erdös discrepancy problem also is connected with another ")#link("http://www.ams.org/mathscinet-getitem?mr=168545")[#text("well known theorem of Roth")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Roth’s discrepancy theorem for arithmetic progressions)")]#text(" Let ")#mi("{f(1),\\dots,f(n)}")#text(" be a sequence in ")#mi("{\\{-1,+1\\}}")#text(". Then there exists an arithmetic progression ")#mi("{a+r, a+2r, \\dots, a+kr}")#text(" in ")#mi("{\\{1,\\dots,n\\}}")#text(" with ")#mi("{r}")#text(" positive such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{j=1}^k f(a+jr)\\right| \\geq c n^{1/4}", block: true)]]

#text("for an absolute constant ")#mi("{c>0}")#text(".")
]

#text("In fact, Roth proved a stronger estimate regarding mean square discrepancy, which I am not writing down here; as with the Roth theorem in arithmetic progressions, his proof was short and Fourier-analytic in nature (although non-Fourier-analytic proofs have since been found, for instance the semidefinite programming ")#link("http://www.ams.org/mathscinet-getitem?mr=1765994")[#text("proof of Lovasz")]#text("). The exponent ")#mi("{1/4}")#text(" is known to be sharp (a ")#link("http://www.ams.org/mathscinet-getitem?mr=1311824")[#text("result of Matousek and Spencer")]#text(").")

#text("As a particular corollary of the above theorem, for an infinite sequence ")#mi("{f(1), f(2), \\dots}")#text(" of signs, the sums ")#tao-math("{\\left|\\sum_{j=1}^k f(a+jr)\\right|}", block: false)#text(" are unbounded in ")#mi("{a,r,k}")#text(". The Erdös discrepancy problem asks whether the same statement holds when ")#mi("{a}")#text(" is restricted to be zero. (Roth also established discrepancy theorems for other sets, such as rectangles, which will not be discussed here.)")

#text("Finally, one has to mention ")#link("https://en.wikipedia.org/wiki/Thue%E2%80%93Siegel%E2%80%93Roth_theorem")[#text("Roth’s most famous result")]#text(", cited for instance in his Fields medal citation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Roth’s theorem on Diophantine approximation)")]#text(" Let ")#mi("{\\alpha}")#text(" be an irrational algebraic number. Then for any ")#mi("{\\varepsilon > 0}")#text(" there is a quantity ")#mi("{c_{\\alpha,\\varepsilon}}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\alpha - \\frac{a}{q}\\right| > \\frac{c_{\\alpha,\\varepsilon}}{q^{2+\\varepsilon}}.", block: true)]]
]

#text("From ")#link("https://en.wikipedia.org/wiki/Dirichlet%27s_theorem_on_diophantine_approximation")[#text("the Dirichlet approximation theorem")]#text(" (or from the theory of continued fractions) we know that the exponent ")#mi("{2+\\varepsilon}")#text(" in the denominator cannot be reduced to ")#mi("{2}")#text(" or below. A classical and easy ")#link("https://en.wikipedia.org/wiki/Liouville%27s_theorem_(transcendence_theory)")[#text("theorem of Liouville")]#text(" gives the claim with the exponent ")#mi("{2+\\varepsilon}")#text(" replaced by the degree of the algebraic number ")#mi("{\\alpha}")#text("; work of Thue and Siegel reduced this exponent, but Roth was the one who obtained the near-optimal result. An important point is that the constant ")#mi("{c_{\\alpha,\\varepsilon}}")#text(" is ")#emph[#text("ineffective")]#text(" – it is a major open problem in Diophantine approximation to produce any bound significantly stronger than Liouville’s theorem with effective constants. This is because the proof of Roth’s theorem does not exclude any ")#emph[#text("single")]#text(" rational ")#mi("{a/q}")#text(" from being close to ")#mi("{\\alpha}")#text(", but instead very ingeniously shows that one cannot have ")#emph[#text("two")]#text(" different rationals ")#mi("{a/q}")#text(", ")#mi("{a^{\\prime}/q^{\\prime}}")#text(" that are unusually close to ")#mi("{\\alpha}")#text(", even when the denominators ")#mi("{q,q^{\\prime}}")#text(" are very different in size. (I refer to this sort of argument as a “")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("dueling conspiracies")]#text("” argument; they are strangely prevalent throughout analytic number theory.)")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d85c0a27a788d1724ca0b531d5d2a337ff03f68b01b99b9e9a682ff21fa6a213-46c07a03980a31e3b80178ec8c3699aa7f77a60c9c87dd27d403be0950a8f8e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461814")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("I did meet Roth, in Inverness around 7 years ago. I asked him what his favourite proof (among his results was) and he said the lower bound for the L^2 discrepancy of point sets with respect to axis parallel boxes. It is a very elegant argument, nicely described in Bernard Chazelle’s book “Discrepancy Theory”. Later in his career he became quite interested in the “Heilbronn triangle problem”, which came up in conversation the other day: given n points in the unit square, what’s the smallest area of triangle they are guaranteed to span. I believe that ")#mi("n^{-2 + o(1)}")#text(" is conjectured, and that Roth was the first to improve on the trivial bound ")#mi("O(1/n)")#text(". Subsequently bounds of the form ")#mi("O(n^{-1 - c})")#text(" were obtained.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461823")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("I guess it should be: maximum over n points of the area of the smallest triangle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c30f6657a38720e78437620c5576c7b28925c4aa479993c91777b2dd1efccdb-6262f83afe447e6614e77c120c050017925f2e2968b63c539d513de577da4344.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aritram Dhar")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-501312")[#strong[#text("Aritram Dhar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2018")])]

#text("Terence Sir your lecture video on “Discrepancy theory” is")#linebreak()#text(" nice.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d28195df14800315168ea974f4adf888eace7d3a34fc83513af492698793a2c-e2ad3cdfa379c5dcf139408dc5d555ac7c236dfa87abd3799a789b51ef5d74f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kodlu")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461825")[#strong[#text("kodlu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("RIP. His book “Sequences” with Halberstam is very nice. My knowledge of the overall history of the field is quite limited but could onr say that, besides Erdo”s, he was the major figure who moved what is now called additive combinatorics forward in the middle years of the 20th century?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d45a7120a874d2a5488c472db240429d354e81b4a8e59ed8b63197e505dbab97-a744fd2f0fd05de31aee894d923efc3ef739d2cb8d86d4b40cc4e9a169483d11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kumaramitdavid")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461827")[#strong[#text("kumaramitdavid")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("On 8th of this month suddenly Roth’s name came to my brain as I reminded about Gelfond’s proof of Hilbert’s 7th problem – this is where I first heard about Roth, in connection with some extension (or generalisation of Gelfond’s Theorem – I just went to check if he was alive and found him so. So, when I just read this blog, I couldn’t stop saying to myself, “What? he was alive just few days ago!” though soon I realised my mistake.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d45a7120a874d2a5488c472db240429d354e81b4a8e59ed8b63197e505dbab97-a744fd2f0fd05de31aee894d923efc3ef739d2cb8d86d4b40cc4e9a169483d11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kumaramitdavid")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461828")[#strong[#text("kumaramitdavid")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("Okay, yes I remembered, it was the theorem that Prof Terry Tao has numbered as 3; it was related to Liouville’s Theorem – my mistake. Nevertheless, I read all that in the same article – Hilbert 7th problem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f09de86d71f177e40d2a573813d7807793923114f3d4d38af4e7eb591de87cb1-11ba9ceac01bcdb452452f86f1d53d15e32d792af281a262c154b50e4d180aad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AG")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461836")[#strong[#text("AG")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2015")])]

#text("I just read a very interesting “Conversation with Klaus Roth” in the “Art in the Life of Mathematicians” (AMS 2015) edited by Anna Kepes Szemeredi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94a53001d6c71abb5a3f7b8eb27944ed663d05f00188afae176627992987cbaf-6d9072119880a45eb68e82a5fe3607c6d5688874a82b8333b19723f6a468b4d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Cosgrave")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461851")[#strong[#text("John Cosgrave")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2015")])]

#text("I am saddened to hear of the passing of K.F. Roth; he wasn’t just a great mathematician, he was also a kind and gentle soul. I have the happy memory of attending his Imperial College lecture course ‘Landmarks in Number Theory’ in 1969-70 (Roger Baker also attended). I was then a graduate student at another London college (Royal Holloway), was reading the extraordinary papers of Alan Baker, and was in desperate need of someone with whom I could talk about Baker’s work. I wrote to Roth to ask if he would discuss this work with me, and he very generously did so (in so doing I learned more from him in one afternoon than from any other person I ever met) in his office at I.C.")

#text("I wrote to thank him, and he replied in a letter dated 4/11/69: “Dear Cosgrave, Thank you for your letter. It is many years since I worked in Diophantine approximations; I am at the moment engaged on problems of quite a different type. But I would be happy to meet you and discuss any specific difficulties you may have encountered. If you phone me at home (352-1363) one evening, we could arrange a time convenient for us both. Yours sincerely. K.F. Roth.”")

#text("I have that letter in front of me now (I keep it inside his Sequences book, the one he wrote with Halberstam, autographed by dear Heini himself), and I will send a photo of the letter to anyone who wishes to have it:")

#link("mailto:jbcosgrave@gmail.com")[#text("jbcosgrave@gmail.com")]

#text("Incidentally, when I was with him, I asked about the circumstances in which he found the proof of his (remarkable) theorem on rational approximations to algebraic numbers (Theorem 3 of T. Tao’s note on Roth). Many years later I wrote what he replied in the Roth section of the following student aimed lecture (never delivered!) of mine: “An introduction to the history of transcendental numbers”, availabe at")

#link("http://staff.spd.dcu.ie/johnbcos/download/Public%20and%20other%20lectures/transcendental%206thMay04/transcendentalTOC.html")[#text("http://staff.spd.dcu.ie/johnbcos/download/Public%20and%20other%20lectures/transcendental%206thMay04/transcendentalTOC.html")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94a53001d6c71abb5a3f7b8eb27944ed663d05f00188afae176627992987cbaf-6d9072119880a45eb68e82a5fe3607c6d5688874a82b8333b19723f6a468b4d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John B. Cosgrave")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-484219")[#strong[#text("John B. Cosgrave")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2017")])]

#text("It has been brought to my attention that the above link is broken (the original web site was taken down by Dublin City University). The CORRECT link is now: ")#link("http://johnbcosgrave.com/archive/transcendental_numbers.htm")[#text("http://johnbcosgrave.com/archive/transcendental_numbers.htm")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ecd3505053e823752e133e50092b53322e52a28b1566e42b351cf4683bb37b5-71206d714602e6fa76e941616865d1b5606cc72b044287d8e45e6f273d56bfc0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.P. McCarthy")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461974")[#strong[#text("J.P. McCarthy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("Hi,")

#text("“(discussed for instance in these lecture notes of mine)”… missing a link.")

#emph[#text("[Link added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/10905479e9b4f913fc4f0ad44e4ba398f7c4e8ce957f89154e9701f6274c48bf-7feed935cc53149e1eca87854c9d7339e4b41f1966ac419b1fa8e6aaada06a4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob Vaughan")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-461997")[#strong[#text("Bob Vaughan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2015")])]

#text("Hi, With William Chen, Trevor Stuart and David Larman, I am preparing an obituary to send to The (London) Times. Also we will prepare something for the London Math. Soc. and, longer term, will prepare something for the Bibliographical Memoirs of the Royal Society. Any comments and observations would be gratefully received. Bob Vaughan")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-462297")[#strong[#text("On the vanishing gradient problem | Exploratoria")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")]

#text("[…] now recently Roth passed away (a couple of weeks […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-462379")[#strong[#text("The Heilbronn Triangle Problem | Radimentary")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2015")]

#text("[…] was shocked and saddened to discover that Roth passed away that same day. Terry Tao wrote a great post about some of Roth’s most important results in analytic number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a4a2af1b7a86da80b751c353d7cec7d44393c5bf2d92c1522f3af76a36b5b4c3-e5a6fc83a720aa1956d30530bcbb169bc58d22eb517225e33d2fa01f143cd803.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Ashworth")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-462504")[#strong[#text("John Ashworth")]]#text(size: 9pt, fill: rgb("596477"), " · 27 November 2015")])]

#text("I had the pleasure of attending Roth’s lecture course on Complex Analysis whilst an undergraduate at Imperial in the early 70’s. His lectures were always clear and comprehensive: in particular, though, he communicated his enthusiasm for this particularly beautiful area of mathematics, which made a great impression on, I think, all the young students there. I have never forgotten his wonderful guttural accent stressing the opening “R” as he would say “.. but this is a RRRegular function…” (they are now more commonly referred to as holomorphic or just complex analytic functions). I consider it an honour to have been taught by him.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/12/klaus-roth/#comment-693493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("This is a comment from long time after this post, when asking AI to do math becomes prevalent. I have been curious about this following problem for a long time:")

#text("Note that ")#mi("2^6 = 64")#text(" and ")#mi("2^{10} = 1024")#text(", so the question is whether there are infinitely many integers ")#mi("k")#text(" such that ")#mi("2^k")#text("’s decimal expression start with ")#mi("k")#text(" itself?")

#text("It is equivalent to ask whether there are infinitely many ")#mi("k")#text(" such that")

#mi("\\{k \\log_{10}(2) - \\log_{10}(k)\\} < \\log_{10}(1 + 1/k)")

#text("which seems like a Ergodic theory argument, but with a moving target and a shrinking interval. Compared to the original Weyl’s equidistribution theorem, claiming that ")#mi("\\{k \\alpha\\}")#text(" is uniformly distributed for irrational ")#mi("\\alpha")#text(", this argument is stronger in terms of: 1) there is a moving target ")#mi("\\log_{10}(k)")#text(" and there is a shrinking target ")#mi("\\log_{10}(1 + 1/k) ~ 1/(\\ln(10)k)")#text(".")

#text("I have been prompting AI to figure out how to resolve this. Along one of the path, I think we are almost able to prove at least ")#mi("\\{k \\log_{10}(2)\\} < \\log_{10}(1 + 1/k)")#text(" using Diophantine approximation theory, but not sure if this is valuable; On the other hand, AI keeps frustrating me with the idea that even if we can prove some type of “almost surely” results, regarding the Lesbegue measure of ")#mi("\\alpha")#text(", we still cannot narrow it down to the specific number of ")#mi("\\log_{10}(2)")#text(", and understanding the continuous fractions of this number seems inaccessible.")

#text("I wonder if this problem seems to be reachable, given our current math achievements plus the AI tools, or completely out of reach?")
]
