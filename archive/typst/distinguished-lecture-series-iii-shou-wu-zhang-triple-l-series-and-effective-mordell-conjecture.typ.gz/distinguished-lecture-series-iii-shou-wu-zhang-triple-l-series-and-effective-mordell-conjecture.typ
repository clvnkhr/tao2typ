// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/05/04/distinguished-lecture-series-iii-shou-wu-zhang-%e2%80%9ctriple-l-series-and-effective-mordell-conjecture%e2%80%9d/
// Converted to Typst by tao2typ: "2026-10-14T15:16:22.987580+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Distinguished Lecture Series III: Shou-wu Zhang, “Triple L-series and effective Mordell conjecture”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Distinguished Lecture Series III: Shou-wu Zhang, “Triple L-series and effective Mordell conjecture”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 May 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/05/04/distinguished-lecture-series-iii-shou-wu-zhang-%e2%80%9ctriple-l-series-and-effective-mordell-conjecture%e2%80%9d/")[#text("https://terrytao.wordpress.com/2007/05/04/distinguished-lecture-series-iii-shou-wu-zhang-%e2%80%9ctriple-l-series-and-effective-mordell-conjecture%e2%80%9d/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("On Thursday Shou-wu Zhang concluded his lecture series by talking about the higher ")#link("http://en.wikipedia.org/wiki/Genus_%28mathematics%29")[#text("genus")]#text(" case ")#mi("g \\geq 2")#text(", and in particular focusing on some recent work of his which is related to the effective Mordell conjecture and the ")#link("http://en.wikipedia.org/wiki/Abc_conjecture")[#text("abc conjecture")]#text(". The higher genus case is substantially more difficult than the genus 0 or genus 1 cases, and one often needs to use techniques from many different areas of mathematics (together with one or two unproven conjectures) to get somewhere.")

#text("This is perhaps the most technical of all the talks, but also the closest to recent developments, in particular the modern attacks on the abc conjecture. (Shou-wu made the point that one sometimes needs to move away from naive formulations of problems to obtain deeper formulations which are more difficult to understand, but can be easier to prove due to the availability of tools, structures, and intuition that were difficult to access in a naive setting, as well as the ability to precisely formulate and quantify what would otherwise be very fuzzy analogies.)")

#metadata(none) <tao-c922053c8340707646cf>#text("As discussed in the ")#link("https://terrytao.wordpress.com/2007/05/02/distinguished-lecture-series-i-shou-wu-zhang-overview-of-rational-points-on-curves/")[#text("first lecture")]#text(", one of the landmark achievements in the higher genus theory is ")#link("http://en.wikipedia.org/wiki/Faltings%27_theorem")[#text("Faltings’ theorem")]#text(" (proving the Mordell conjecture), which asserts that if C is a curve of genus ")#mi("g \\geq 2")#text(" defined over the integers, then the set of rational points ")#mi("C({\\Bbb Q})")#text(" is finite; another way of saying this is that an equation of the form ")#mi("F(x,y) = 0")#text(" which is “inherently” of degree 4 or more, in that it cannot be solved via algebraic manipulations which only require solving polynomial equations of degree 3 or less, can have at most finitely many rational solutions. (For instance, this theorem already shows that for any fixed n, there are only finitely many reduced integer solutions to Fermat’s equation ")#mi("a^n + b^n = c^n")#text(".) (Indeed, the genus precisely captures the fuzzy notion of the “inherent degree” of a polynomial equation, and is a good example of the advantages of recasting problems in a deeper framework.)")

#text("There are many proofs of Faltings theorem (Mordell’s conjecture), but they are all ")#emph[#text("ineffective")]#text(" in the sense that they do not provide an upper bound for the height h(P) of the rational points P, which one can define naively as one plus the logarithm of the largest numerator or denominator of the coordinates of P (roughly speaking, this is the number of bits needed to write down P). The (naive) effective Mordell conjecture asserts that in fact ")#mi("h(P) \\ll_g h(C)")#text(", where h(C) can be defined as the largest height of any of the coefficients used to define C (roughly, the number of bits needed to write down C). This conjecture has the amusing consequence that the problem of determining whether a curve of fixed genus has a rational point would “merely” be in NP (for comparison, recall that the problem of finding a integer point on a general variety is ")#emph[#text("undecidable")]#text(", thanks to ")#link("http://en.wikipedia.org/wiki/Matiyasevich%27s_theorem")[#text("Matiyasevich’s theorem")]#text(").")

#text("The naive notion of height is somewhat artificial and extrinsic (i.e. it is affected by changes of coordinate); it would be preferable to have a more ")#emph[#text("intrinsic")]#text(", and hence more ")#emph[#text("geometric")]#text(" notion of height. (Indeed, geometry can almost be ")#emph[#text("defined")]#text(" as the study of those notions which are intrinsic; cf. Klein’s ")#link("http://en.wikipedia.org/wiki/Erlangen_program")[#text("Erlangen program")]#text(".) One reason for this is one can use the intrinsic geometry to prove deep and sharp inequalities, for instance establishing an inequality ")#mi("X \\leq Y")#text(" by establishing a geometric identity which expresses Y as the sum of X and a square, or more generally as the sum of X and an integral of something positive-definite. (One good example of this is the method of ")#emph[#text("monotonicity formulae")]#text(" from PDE, which was used for instance in the proof of the Poincare conjecture; these formulae often rely crucially on the intrinsic geometric nature of the objects being studied.)")

#text("Shou-wu made the point that Arakelov theory offers such an intrinsic notion of height. To explain this, he started with a curve C and first formed an integral model ")#mi("X = X_{/ {\\Bbb Z}}")#text(" of C (I presume this would be a scheme) by making all coefficients integer, resolving singularities, and compactifying various things. In particular, the spectrum ")#mi("\\text{Spec}({\\Bbb Z})")#text(" of the integers (i.e. the primes) is compactified by adding the Archimedean ")#link("http://en.wikipedia.org/wiki/Place_%28mathematics%29")[#text("place")]#text(" ")#mi("\\infty")#text(". There are a number of ways to see why it is natural to group the place at infinity with all the finite places p. For instance, given a rational number q, one can define the usual absolute value (or ")#emph[#text("valuation")]#text(") ")#tao-math("\\left|q\\right|_\\infty", block: false)#text(" (giving rise to the usual metric, whose completion is the field of reals ")#mi("{\\Bbb R}")#text("), or for any prime p we can define the p-adic metric ")#tao-math("\\left|q\\right|_p", block: false)#text(", defined as the reciprocal of the power of p which divides q (note this obeys the triangle inequality!), whose completion leads to the p-adic field ")#mi("{\\Bbb Q}_p")#text(". The ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(" can then be rephrased as the statement that the product ")#tao-math("\\prod_\\nu \\left|q\\right|_\\nu", block: false)#text(" of q over all places (both the finite places and the place at infinity) is always equal to 1. As an analogy, note from Cauchy’s theorem that the sum of residues of a rational function always equals zero if one compactifies the complex plane by adding the point at infinity.")

#text("[Incidentally, Shou-wu made the point that it was this compactification of the spectrum which distinguishes number theory from algebra; as he put it, “in number theory we care about the size of our solutions, and not just their number”.]")

#text("Anyway, with this integral model X (or more generally, a model over a number field k) we can use Arakelov theory to construct two invariants over k:")

#enum(start: 1, 
[#text("The ")#emph[#text("relative dualising sheaf")]#text(" ")#mi("\\omega_{X/k}")#text(", which was not defined in the talk but could be thought of as an arithmetic analogue of the canonical line bundle of a complex surface, in particular ")#mi("\\omega_{X/k}")#text(" is analogous to the first ")#link("http://en.wikipedia.org/wiki/Chern_class")[#text("Chern class")]#text(" ")#mi("c_1(X)")#text(" of X. In particular there is a self-intersection number ")#mi("\\omega_{X/k} \\cdot \\omega_{X/k}")#text(".")],
[#text("A numeric quantity ")#mi("\\hat c_2(X)")#text(", which was also not defined but was supposed to count the number of singularities in fibers of X and is analogous to the second Chern class.")]
)

#text("The intrinsic version of the effective Mordell conjecture is then the ")#emph[#text("arithmetic Bogolomov-Miyoaka-Yau inequality")]

#align(center)[#tao-fit-display[#mitex("\\omega_{X/k} \\cdot \\omega_{X/k} \\ll_{g,\\hat{c_2},d} 1 + \\log \\Delta_k")]]

#text("for all number fields k, where d is the degree of k and ")#mi("\\Delta_k")#text(" is the discriminant; this is analogous to the geometric Bogolomov-Miyoaka-Yau inequality ")#mi("c_1(X) \\cdot c_1(X) \\leq 3 c_2(X)")#text(" for complex surfaces, with the term ")#mi("\\log \\Delta_k")#text(" being somewhat analogous to a “genus” for the spectrum of the ring of integers of k. According to Shou-wu, this conjecture (which remains open, despite some announced proofs in the past) is essentially equivalent to the effective Mordell conjecture. Furthermore, through the work of Parshin and Morel-Baily, the effective Mordell conjecture essentially implies Szpiro’s conjecture ")#tao-math("\\left|\\Delta_E\\right| \\ll_\\epsilon N_E^{6+\\epsilon}", block: false)#text(" for elliptic curves, which in turn implies the abc conjecture by an observation of Frey; conversely, work of Elkies (building on earlier work of Baily) shows that the abc conjecture implies the effective Mordell conjecture, so all these conjectures are roughly equivalent. (Unfortunately I don’t have the precise details of all these equivalences.) Of course, the abc conjecture is known to have a large number of other interesting consequences.")

#text("So it is of course of interest to try to prove the arithmetic BMY inequality. In the case of the geometric BMY inequality ")#mi("c_1(X) \\cdot c_1(X) \\leq 3 c_2(X)")#text(" established ")#link("http://www.ams.org/mathscinet-getitem?mr=522939")[#text("by Bogolomov")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=460343")[#text("by Miyoaka")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=451180")[#text("by Yau")]#text(", the known proofs use one of two sources of inequality or positivity:")

#enum(start: 1, 
[#text("The ")#link("http://en.wikipedia.org/wiki/Hodge_index_theorem")[#text("Hodge index theorem")]#text(", which can establish non-negativity of self-intersections ")#mi("\\omega \\cdot \\omega")#text(" of classes under certain conditions;")],
[#text("The theory of ")#emph[#text("stable bundles")]#text(" (i.e. sheaves F which have greater slope ")#mi("\\frac{\\text{deg} F}{\\text{rank} F}")#text(" than all their sub-sheaves).")]
)

#text("Unfortunately no good arithmetic analogues of these two concepts are currently known. But Shou-wu hinted that Riemann hypothesis type assumptions can be used to establish certain non-vanishing of L-functions at various places, which can in some cases lead to some interesting strict inequalities (this was not fully elaborated in the talk).")

#text("Zhang made a substantial contribution to understanding the conjectured arithmetic BMY inequality by relating the self-intersection number ")#mi("\\omega_{X/k} \\cdot \\omega_{X/k}")#text(" to the self-intersection number ")#mi("\\Delta_\\xi \\cdot \\Delta_\\xi")#text(" of another object, the ")#emph[#text("Gross-Schoen cycle")]#text(". This in turn is conjectured (via the ")#emph[#text("Beilinson-Bloch conjecture")]#text(" – a variant of the ")#link("http://en.wikipedia.org/wiki/Birch_and_Swinnerton-Dyer_conjecture")[#text("BSD conjecture")]#text(") to be connected with the order of vanishing of a certain L-function (the ")#emph[#text("triple product L-series")]#text(" ")#mi("L(s,W)")#text("), and so information about this L-series can be used to make progress on the arithmetic BMY inequality (and thus hopefully to effective Mordell and abc – though Shou-wu cautioned that one needs to establish BMY on an entire compact family of curves before there are any applications to Mordell or abc; knowing what happens on a single curve does not directly lead to much of anything).")

#text("Shou-wu then defined the ")#emph[#text("Gross-Schoen cycle")]#text(", which he viewed as a generalisation of the concept of a ")#link("http://en.wikipedia.org/wiki/Heegner_point")[#text("Heegner point")]#text(" to the higher genus setting. Given a point p in a curve C (viewed now as a surface, e.g. by working over ")#mi("{\\Bbb C}")#text("), we can form the 2-cycle ")#mi("\\Delta_p")#text(" in the six-dimensional surface ")#mi("C^3")#text(" by taking the alternating sum of the doubly-diagonal line ")#mi("\\{ (x,x,x): x \\in C \\}")#text(" minus the three diagonal lines ")#mi("\\{ (x,x,p):x \\in C\\}, \\{ (x,p,x): x \\in C \\}, \\{ (p,x,x): x \\in C\\}")#text(", plus the coordinate lines ")#mi("\\{ (x,p,p): x \\in C\\}, \\{ (p,x,p): x \\in C\\}, \\{(p,p,x): x \\in C\\}")#text(". It is clear that ")#mi("\\int_{\\Delta_p} \\alpha = 0")#text(" for any two-form ")#mi("\\alpha")#text(" on ")#mi("C^3")#text(" which depends on only two of the three factors of C. From this it is not hard to see that ")#mi("\\Delta_p")#text(" is orthogonal to all closed two-forms and is therefore homologically trivial. As such, it is (non-uniquely) the boundary of some 3-fold Y; the map ")#mi("\\alpha \\mapsto \\int_Y \\alpha")#text(", defined on 3-forms, is then independent of Y and thus allows ")#mi("\\Delta_p")#text(" to be defined as a point in an intermediate Jacobian (")#mi("\\text{Hom}(A^3(C^3),{\\Bbb R})")#text(" quotiented out by periods – this space is a complex torus). One can also compute the self-intersection number ")#mi("\\Delta_p \\cdot \\Delta_p")#text(". It turns out that this expression is minimised if p is the ")#link("http://en.wikipedia.org/wiki/Canonical_class")[#text("canonical class")]#text(" ")#mi("\\xi = K_C/(2g-2)")#text(", which is not exactly a point but rather a divisor consisting of the equivalence class of all formal rational combinations of points whose coefficients add up to 1 (I am a bit uncertain on this point), leading to the invariant ")#mi("\\Delta_\\xi \\cdot \\Delta_\\xi")#text(", which is a “height intersection” for the curve C.")

#text("Zhang established an important formula")

#align(center)[#tao-fit-display[#mitex("\\Delta_\\xi \\cdot \\Delta_\\xi = \\frac{2g+1}{2g-2} \\omega_{X/k} \\cdot \\omega_{X/k} - \\sum_\\nu \\Phi_\\nu")]]

#text("where ")#mi("\\nu")#text(" is the sum over all “bad” places (which always includes the place at infinity), and ")#mi("\\Phi_\\nu")#text(" is an explicit non-negative quantity, essentially the negative moment of a certain Laplacian associated to the localisation of C at ")#mi("\\nu")#text(". (In the case of finite places, this is a graph Laplacian; in the case of the place at infinity, one takes the Laplace-Beltrami operator associated to the Arakelov metric on the Riemann surface.) The positive definiteness of the Laplacian (with the appropriate sign convention) is what ensures the non-negativity of ")#mi("\\Phi_\\nu")#text(".")

#text("From the above formula we see that to attack the arithmetic BMY inequality, it suffices to control the self-intersection ")#mi("\\Delta_\\xi \\cdot \\Delta_\\xi")#text(", as well as the auxiliary quantities ")#mi("\\Phi_\\nu")#text(". The latter seem to be fairly tractable, so it is the former which one now focuses on. To this end, it is convenient to introduce a cohomological object W as follows. Recall the cup product ")#mi("\\cup: H^1(C) \\otimes H^1(C) \\to H^2(C)")#text(" (where the latter space is essentially just ")#mi("{\\Bbb Q}")#text("), defined by ")#mi("\\alpha \\cup \\beta := \\int \\alpha \\vee \\beta")#text(". This in turn leads to a surjective map from ")#mi("\\bigwedge^3 H^1(C)")#text(" to ")#mi("H^1(C)")#text(" defined by")

#align(center)[#mi("\\alpha \\vee \\beta \\vee \\gamma \\mapsto \\alpha (\\beta \\cup \\gamma) + \\beta (\\gamma \\cup \\alpha) + \\gamma (\\alpha \\cup \\beta)")#text(".")]

#text("The kernel of this map is denoted W, and it is related to ")#mi("\\Delta_\\xi")#text(" in some manner which I did not understand. It can be assigned an L-function ")#mi("L(W,s)")#text(" (the ")#emph[#text("triple L-series")]#text(") in analogy with the L-function of a curve C (in both cases, the local factor is essentially the characteristic polynomial of the Frobenius automorphism restricted to the portion of an cohomological object (W, or ")#mi("H^1(C,{\\Bbb Q}_p)")#text(") which is invariant under an inertia group – again, I did not understand this part well). This L-function (related to the triple product studied by Garrett, Rallis, and Piatetski-Shapiro) is conjectured to be entire and obey a functional equation (symmetric around s=2); this is a variant of the (now-proven) Taniyama-Shimura conjecture, as it basically asserts (via the Mellin transform) that W is associated with a modular form. This conjecture is known in some genus 3 cases (and is trivial in genus 2) but is open in general.")

#text("An even stronger conjecture is the ")#emph[#text("Beilinson-Bloch conjecture")]#text(", which asserts that the order of vanishing of ")#mi("L(W,s)")#text(" at s=2 is equal to the rank of the restriction ")#mi("Ch^2(C^3)_W")#text(" of the Chow group ")#mi("Ch^2(C^3)")#text(" to W. (The Chow group here is the space of 2-cycles on ")#mi("C^3")#text(" modulo rational equivalence, while ")#mi("Ch^2(C^3)_W")#text(" can be described explicitly as the subgroup of the Chow group coming from cycles which are permutation-invariant, vanish when pushed down to ")#mi("C^2")#text(", and also vanish when restricted to a diagonal ")#mi("C^2")#text(" and then pushed down to ")#mi("C^1")#text(".) Apparently W is “cut out” by ")#mi("Ch^2(C^3)_W")#text(" in a ")#link("http://en.wikipedia.org/wiki/Motive_%28algebraic_geometry%29")[#text("motivic")]#text(" sense, but I didn’t understand this bit.")

#text("As a consequence of the Beilinson-Bloch conjecture, we see that if the L-function does not vanish at zero, then the Chow group at W is trivial, which in particular implies that the self-intersection ")#mi("\\Delta_\\xi \\cdot \\Delta_\\xi")#text(" vanishes. This particular implication is known in the function field case (which is simpler for a number of reasons – for instance, there are no bad places and so ")#mi("\\Phi_\\nu")#text(" does not appear at all), however the full Beilinson-Bloch conjecture in the function field case (known as ")#emph[#text("Tate’s conjecture")]#text(") remains partially open. As with the BSD conjecture, it is believed that the L-function L(W,s) is supposed to vanish at s=2 “50% of the time” in some sense, which morally speaking should imply that the abc conjecture is true with very good effective constants “50% of the time”.")

#text("Shou-wu mentioned some recent work of himself with Xuan and (another) Zhang, which verified a variant of the Beilinson-Bloch conjecture (linking the derivative of the L-function at s=2 with the self-intersection of the Gross-Schoen cycle as above) when W is replaced by the Rankin-Selberg convolution of three cusp forms of weight 2 with common conductor. One curious consequence of this work is that it also provides a construction to pull back a point (e.g. the origin) from one of the elliptic curves associated to a cusp form to the modular curve, and push it to another, giving a new way to build rational points on elliptic curves.")

#text("Shou-wu closed by mentioning a rather different approach to establishing these sorts of inequalities, proceeding via a Riemann hypothesis for L-functions rather than by BSD-type conjectures. In particular, the Riemann hypothesis can be used to establish a “Hodge index theorem” of sorts that gives non-negativity of ")#mi("\\Delta_\\xi \\cdot \\Delta_\\xi")#text(", which in turn can be used to give positivity of ")#mi("\\omega_{X/{\\Bbb Q}} \\cdot \\omega_{X/{\\Bbb Q}}")#text(", which in turn implies the Bogomolov conjecture (which involves heights of points on elliptic curves, but was not stated explicitly here).")

#text("Finally, when asked about the possibility of actually proving the abc conjecture, Shou-wu ventured the opinion that if one was willing to assume enough variants of both the Riemann hypothesis and the Birch and Swinnerton-Dyer conjectures (ie. assuming that all relevant L-functions behave exactly as conjectured) then it seemed likely that abc could be established in the near future by these sorts of methods. This of course is consistent with the substantial existing evidence we have that GRH and BSD are extremely powerful conjectures in number theory.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/04/distinguished-lecture-series-iii-shou-wu-zhang-%e2%80%9ctriple-l-series-and-effective-mordell-conjecture%e2%80%9d/#comment-820")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2007")]

#text("[…] Distinguished Lecture Series III: Shou-wu Zhang, “Triple L-series and effective Mordell conjecture… On Thursday Shou-wu Zhang concluded his lecture series by talking about the higher genus case [LaTeX], and in […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Distinguished Lecture Series III: Shing-Tung Yau, \"Application of the Geometric Structures to Solve Problems in Algebraic Geometry and Topology\" « What’s new")]], [#link("https://terrytao.wordpress.com/2007/05/04/distinguished-lecture-series-iii-shou-wu-zhang-%e2%80%9ctriple-l-series-and-effective-mordell-conjecture%e2%80%9d/#comment-1005")[#strong[#text("Distinguished Lecture Series III: Shing-Tung Yau, \"Application of the Geometric Structures to Solve Problems in Algebraic Geometry and Topology\" « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2007")])]

#text("[…] metrics were also used in Yau’s proof of the Bogomolov-Miyaoka-Yau inequality mentioned in Zhang’s lectures. (In fact, Yau recalled that he learnt about this problem from a colloquium of Mumford right here […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/05/04/distinguished-lecture-series-iii-shou-wu-zhang-%e2%80%9ctriple-l-series-and-effective-mordell-conjecture%e2%80%9d/#comment-1306")[#strong[#text("Not Even Wrong » Blog Archive » All Sorts of Stuff")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2007")]

#text("[…] come up with amazingly good blog entries. His latest is a series of three postings (here, here and here), reporting on my colleague Shouwu Zhang’s lectures at UCLA on the topic of rational points […]")
]
