// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/
// Converted to Typst by tao2typ: "2026-10-14T15:18:58.922619+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Conserved quantities for the surface quasi-geostrophic equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Conserved quantities for the surface quasi-geostrophic equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 March 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/")[#text("https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As in the previous post, all computations here are at the formal level only.")

#text("In the ")#link("https://terrytao.wordpress.com/2014/03/02/noethers-theorem-and-the-conservation-laws-for-the-euler-equations/")[#text("previous blog post")]#text(", the ")#link("http://en.wikipedia.org/wiki/Euler_equations_(fluid_dynamics)")[#text("Euler equations for inviscid incompressible fluid flow")]#text(" were interpreted in a Lagrangian fashion, and then ")#link("http://en.wikipedia.org/wiki/Noether's_theorem")[#text("Noether’s theorem")]#text(" invoked to derive the known conservation laws for these equations. In a bit more detail: starting with ")#emph[#text("Lagrangian space")]#text(" ")#mi("{{\\cal L} = ({\\bf R}^n, \\text{vol})}")#text(" and ")#emph[#text("Eulerian space")]#text(" ")#mi("{{\\cal E} = ({\\bf R}^n, \\eta, \\text{vol})}")#text(", we let ")#mi("{M}")#text(" be the space of volume-preserving, orientation-preserving maps ")#mi("{\\Phi: {\\cal L} \\rightarrow {\\cal E}}")#text(" from Lagrangian space to Eulerian space. Given a curve ")#mi("{\\Phi: {\\bf R} \\rightarrow M}")#text(", we can define the ")#emph[#text("Lagrangian velocity field")]#text(" ")#mi("{\\dot \\Phi: {\\bf R} \\times {\\cal L} \\rightarrow T{\\cal E}}")#text(" as the time derivative of ")#mi("{\\Phi}")#text(", and the ")#emph[#text("Eulerian velocity field")]#text(" ")#mi("{u := \\dot \\Phi \\circ \\Phi^{-1}: {\\bf R} \\times {\\cal E} \\rightarrow T{\\cal E}}")#text(". The volume-preserving nature of ")#mi("{\\Phi}")#text(" ensures that ")#mi("{u}")#text(" is a divergence-free vector field: ")#metadata(none) <tao-3784b6419c4847326e42>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\nabla \\cdot u = 0.")]]

#text("If we formally define the functional")

#align(center)[#tao-fit-display[#tao-math("J[\\Phi] := \\frac{1}{2} \\int_{\\bf R} \\int_{{\\cal E}} \\left|u(t,x)\\right|^2\\ dx dt = \\frac{1}{2} \\int_R \\int_{{\\cal L}} \\left|\\dot \\Phi(t,x)\\right|^2\\ dx dt", block: true)]]

#text("then one can show that the critical points of this functional (with appropriate boundary conditions) obey the Euler equations")

#tao-aligned(keep: true)[


#tao-math("[\\partial_t + u \\cdot \\nabla] u  & = - \\nabla p", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("for some pressure field ")#mi("{p: {\\bf R} \\times {\\cal E} \\rightarrow {\\bf R}}")#text(". As discussed in the previous post, the time translation symmetry of this functional yields conservation of the Hamiltonian")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{{\\cal E}} \\left|u(t,x)\\right|^2\\ dx = \\frac{1}{2} \\int_{{\\cal L}} \\left|\\dot \\Phi(t,x)\\right|^2\\ dx;", block: true)]]

#text("the rigid motion symmetries of Eulerian space give conservation of the total momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\cal E}} u(t,x)\\ dx")]]

#text("and total angular momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\cal E}} x \\wedge u(t,x)\\ dx;")]]

#text("and the diffeomorphism symmetries of Lagrangian space give conservation of circulation")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Phi(\\gamma)} u^*")]]

#text("for any closed loop ")#mi("{\\gamma}")#text(" in ")#mi("{{\\cal L}}")#text(", or equivalently pointwise conservation of the Lagrangian vorticity ")#mi("{\\Phi^* \\omega = \\Phi^* du^*}")#text(", where ")#mi("{u^*}")#text(" is the ")#mi("{1}")#text("-form associated with the vector field ")#mi("{u}")#text(" using the Euclidean metric ")#mi("{\\eta}")#text(" on ")#mi("{{\\cal E}}")#text(", with ")#mi("{\\Phi^*}")#text(" denoting pullback by ")#mi("{\\Phi}")#text(".")

#text("It turns out that one can generalise the above calculations. Given any self-adjoint operator ")#mi("{A}")#text(" on divergence-free vector fields ")#mi("{u: {\\cal E} \\rightarrow {\\bf R}}")#text(", we can define the functional")

#align(center)[#tao-fit-display[#mitex("J_A[\\Phi] := \\frac{1}{2} \\int_{\\bf R} \\int_{{\\cal E}} u(t,x) \\cdot A u(t,x)\\ dx dt;")]]

#text("as we shall see below the fold, critical points of this functional (with appropriate boundary conditions) obey the generalised Euler equations ")#metadata(none) <tao-309d20864f274b097f64>

#tao-aligned(keep: true)[


#tao-math("[\\partial_t + u \\cdot \\nabla] Au + (\\nabla u) \\cdot Au & = - \\nabla \\tilde p", block: true, numbering: n => [#text("(2)")])



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("for some pressure field ")#mi("{\\tilde p: {\\bf R} \\times {\\cal E} \\rightarrow {\\bf R}}")#text(", where ")#mi("{(\\nabla u) \\cdot Au}")#text(" in coordinates is ")#mi("{\\partial_i u_j Au_j}")#text(" with the usual summation conventions. (When ")#mi("{A=1}")#text(", ")#tao-math("{(\\nabla u) \\cdot Au = \\nabla(\\frac{1}{2} \\left|u\\right|^2)}", block: false)#text(", and this term can be absorbed into the pressure ")#mi("{\\tilde p}")#text(", and we recover the usual Euler equations.) Time translation symmetry then gives conservation of the Hamiltonian")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_{{\\cal E}} u(t,x) \\cdot A u(t,x)\\ dx.")]]

#text("If the operator ")#mi("{A}")#text(" commutes with rigid motions on ")#mi("{{\\cal E}}")#text(", then we have conservation of total momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\cal E}} Au(t,x)\\ dx")]]

#text("and total angular momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\cal E}} x \\wedge Au(t,x)\\ dx,")]]

#text("and the diffeomorphism symmetries of Lagrangian space give conservation of circulation")

#align(center)[#tao-fit-display[#mitex("\\int_{\\Phi(\\gamma)} (Au)^*")]]

#text("or pointwise conservation of the Lagrangian vorticity ")#mi("{\\Phi^* \\theta := \\Phi^* d(Au)^*}")#text(". These applications of Noether’s theorem proceed exactly as the previous post; we leave the details to the interested reader.")

#text("One particular special case of interest arises in two dimensions ")#mi("{n=2}")#text(", when ")#mi("{A}")#text(" is the inverse derivative ")#tao-math("{A = \\left|\\nabla\\right|^{-1} = (-\\Delta)^{-1/2}}", block: false)#text(". The vorticity ")#mi("{\\theta = d(Au)^*}")#text(" is a ")#mi("{2}")#text("-form, which in the two-dimensional setting may be identified with a scalar. In coordinates, if we write ")#mi("{u = (u_1,u_2)}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\theta = \\partial_{x_1} \\left|\\nabla\\right|^{-1} u_2 - \\partial_{x_2} \\left|\\nabla\\right|^{-1} u_1.", block: true)]]

#text("Since ")#mi("{u}")#text(" is also divergence-free, we may therefore write")

#align(center)[#tao-fit-display[#mitex("u = (- \\partial_{x_2} \\psi, \\partial_{x_1} \\psi )")]]

#text("where the ")#link("http://en.wikipedia.org/wiki/Stream_function")[#text("stream function")]#text(" ")#mi("{\\psi}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#tao-math("\\psi = \\left|\\nabla\\right|^{-1} \\theta.", block: true)]]

#text("If we take the curl of the generalised Euler equation ")#link(<tao-309d20864f274b097f64>)[#text("(2)")]#text(", we obtain (after some computation) the ")#link("https://www.ma.utexas.edu/mediawiki/index.php/Surface_quasi-geostrophic_equation")[#text("surface quasi-geostrophic equation")]#text(" ")#metadata(none) <tao-c8b93403a7a34ddcbd1a>

#tao-aligned(keep: true)[


#tao-math("[\\partial_t + u \\cdot \\nabla] \\theta  & = 0", block: true, numbering: n => [#text("(3)")])



#tao-math("u  & = (-\\partial_{x_2} \\left|\\nabla\\right|^{-1} \\theta, \\partial_{x_1} \\left|\\nabla\\right|^{-1} \\theta).", block: true)
]

#text("This equation has strong analogies with the three-dimensional incompressible Euler equations, and can be viewed as a simplified model for that system; see ")#link("http://www.ams.org/mathscinet-getitem?mr=1252829")[#text("this paper of Constantin, Majda, and Tabak")]#text(" for details.")

#text("Now we can specialise the general conservation laws derived previously to this setting. The conserved Hamiltonian is")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{{\\bf R}^2} u\\cdot \\left|\\nabla\\right|^{-1} u\\ dx = \\frac{1}{2} \\int_{{\\bf R}^2} \\theta \\psi\\ dx = \\frac{1}{2} \\int_{{\\bf R}^2} \\theta \\left|\\nabla\\right|^{-1} \\theta\\ dx", block: true)]]

#text("(a law previously observed for this equation in the abovementioned paper of Constantin, Majda, and Tabak). As ")#mi("{A}")#text(" commutes with rigid motions, we also have (formally, at least) conservation of momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} Au\\ dx")]]

#text("(which up to trivial transformations is also expressible in ")#link("http://en.wikipedia.org/wiki/Impulse_(physics)")[#text("impulse")]#text(" form as ")#mi("{\\int_{{\\bf R}^2} \\theta x\\ dx}")#text(", after integration by parts), and conservation of angular momentum")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} x \\wedge Au\\ dx")]]

#text("(which up to trivial transformations is ")#tao-math("{\\int_{{\\bf R}^2} \\theta \\left|x\\right|^2\\ dx}", block: false)#text("). Finally, diffeomorphism invariance gives pointwise conservation of Lagrangian vorticity ")#mi("{\\Phi^* \\theta}")#text(", thus ")#mi("{\\theta}")#text(" is transported by the flow (which is also evident from ")#link(<tao-c8b93403a7a34ddcbd1a>)[#text("(3)")]#text(". In particular, all integrals of the form ")#mi("{\\int F(\\theta)\\ dx}")#text(" for a fixed function ")#mi("{F}")#text(" are conserved by the flow.")

#metadata(none) <tao-14eb6bc84f392a63d186>

#heading(level: 1)[#strong[#text(" — 1. Euler-Lagrange calculations — ")]]

#text("We now justify the claim that stationary points of the functional ")#mi("{J_A[\\Phi]}")#text(" obey ")#link(<tao-309d20864f274b097f64>)[#text("(2)")]#text(". We consider continuous deformations ")#mi("{s \\mapsto \\Phi(s)}")#text(" of the critical point ")#mi("{\\Phi}")#text(", thus ")#mi("{\\Phi}")#text(" now depends on both ")#mi("{s}")#text(" and ")#mi("{t}")#text(". We already have the Eulerian velocity field ")#mi("{u}")#text(", which is related to the ")#mi("{t}")#text(" derivative of ")#mi("{\\Phi}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\Phi^i = u^i( \\Phi );")]]

#text("similarly we may introduce a deformation field ")#mi("{v}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\partial_s \\Phi^i = v^i( \\Phi ).")]]

#text("The vector field ")#mi("{v}")#text(" is divergence free and has to obey appropriate vanishing conditions at infinity, but is otherwise unconstrained. If we compute ")#mi("{\\partial_t \\partial_s \\Phi^i = \\partial_s \\partial_t \\Phi^i}")#text(" using the above two equations and the chain rule, we arrive at the “zero-curvature” condition")

#align(center)[#tao-fit-display[#mitex("\\partial_t v^i + u^j \\partial_j v^i = \\partial_s u^i + v^j \\partial_j u^i")]]

#text("so in particular ")#metadata(none) <tao-abc10f8980afb0a816ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_s u^i = \\partial_t v^i + u^j \\partial_j v^i - v^j \\partial_j u^i.")]]

#text("On the other hand, as ")#mi("{\\Phi}")#text(" is a critical point, we have")

#align(center)[#tao-fit-display[#mitex("\\partial_s J_A[\\Phi] = 0")]]

#text("when ")#mi("{s=0}")#text(". Differentiating under the integral sign and using the self-adjoint nature of ")#mi("{A}")#text(", the left-hand side is")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\cal E}} (\\partial_s u^i) A u^i\\ dx dt.")]]

#text("Inserting ")#link(<tao-abc10f8980afb0a816ed>)[#text("(4)")]#text(" and integrating by parts (and using the divergence-free nature of ")#mi("{u}")#text("), this expression can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\cal E}} v^i ( - \\partial_t A u^i - u^j \\partial_j Au^i - Au^j \\partial_i u^j)\\ dx dt.")]]

#text("Since ")#mi("{v^i}")#text(" is essentially an arbitrary divergence-free vector field, the expression inside parentheses must vanish, and the equation ")#link(<tao-309d20864f274b097f64>)[#text("(2)")]#text(" follows.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/#comment-274436")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2014")])]

#text("At the end of the second sentence, do you mean ‘these equations’ instead of ‘this equation’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/#comment-379465")[#strong[#text("Navier-Stokes Fluid Computers | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")]

#text("[…] here is a follow up post on Tao’s blog (and a few more II, III), and a post on Shtetl […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Embedding the SQG equation in a modified Euler equation | What's new")]], [#link("https://terrytao.wordpress.com/2014/03/06/conserved-quantities-for-the-surface-quasi-geostrophic-equation/#comment-454230")[#strong[#text("Embedding the SQG equation in a modified Euler equation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2015")])]

#text("[…] where is the active scalar, and is the velocity field. The SQG equations are often used as a toy model for the 3D Euler equations, as they share many of the same features (e.g. vortex stretching); see this paper of Constantin, Majda, and Tabak for more discussion (or this previous blog post). […]")
]
