// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/
// Converted to Typst by tao2typ: "2026-10-14T15:20:42.941308+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Perfectly packing a square by squares of nearly harmonic sidelength", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Perfectly packing a square by squares of nearly harmonic sidelength")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 February 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/")[#text("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my preprint “")#link("https://arxiv.org/abs/2202.03594")[#text("Perfectly packing a square by squares of nearly harmonic sidelength")]#text("“. This paper concerns a variant of an old ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=229142")[#text("problem of Meir and Moser")]#text(", who asks whether it is possible to perfectly pack squares of sidelength ")#mi("{1/n}")#text(" for ")#mi("{n \\geq 2}")#text(" into a single square or rectangle of area ")#mi("{\\sum_{n=2}^\\infty \\frac{1}{n^2} = \\frac{\\pi^2}{6} - 1}")#text(". (The following variant problem, also posed by Meir and Moser and discussed for instance in ")#link("https://mathoverflow.net/questions/34145/can-we-cover-the-unit-square-by-these-rectangles?noredirect=1&lq=1")[#text("this MathOverflow post")]#text(", is perhaps even more well known: is it possible to perfectly pack rectangles of dimensions ")#mi("{1/n \\times 1/(n+1)}")#text(" for ")#mi("{n \\geq 1}")#text(" into a single square of area ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n(n+1)} = 1}")#text("?) For the purposes of this paper, rectangles and squares are understood to have sides parallel to the axes, and a packing is perfect if it partitions the region being packed up to sets of measure zero. As one partial result towards these problems, it was shown ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1620857")[#text("by Paulhus")]#text(" that squares of sidelength ")#mi("{1/n}")#text(" for ")#mi("{n \\geq 2}")#text(" can be packed (not quite perfectly) into a single rectangle of area ")#mi("{\\frac{\\pi^2}{6} - 1 + \\frac{1}{1244918662}}")#text(", and rectangles of dimensions ")#mi("{1/n \\times 1/n+1}")#text(" for ")#mi("{n \\geq 1}")#text(" can be packed (again not quite perfectly) into a single square of area ")#mi("{1 + \\frac{1}{10^9+1}}")#text(". (Paulhus’s paper had some gaps in it, but these were subsequently ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=3873959")[#text("repaired by Grzegorek and Januszewski")]#text(".)")

#text("Another direction in which partial progress has been made is to consider instead the problem of packing squares of sidelength ")#mi("{n^{-t}}")#text(", ")#mi("{n \\geq 1}")#text(" perfectly into a square or rectangle of total area ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n^{2t}}}")#text(", for some fixed constant ")#mi("{t > 1/2}")#text(" (this lower bound is needed to make the total area ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n^{2t}}}")#text(" finite), with the aim being to get ")#mi("{t}")#text(" as close to ")#mi("{1}")#text(" as possible. Prior to this paper, the most recent advance in this direction was ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4227795")[#text("by Januszewski and Zielonka")]#text(" last year, who achieved such a packing in the range ")#mi("{1/2 < t \\leq 2/3}")#text(".")

#text("In this paper we are able to get ")#mi("{t}")#text(" arbitrarily close to ")#mi("{1}")#text(" (which turns out to be a “critical” value of this parameter), but at the expense of deleting the first few tiles:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" If ")#mi("{1/2 < t < 1}")#text(", and ")#mi("{n_0}")#text(" is sufficiently large depending on ")#mi("{t}")#text(", then one can pack squares of sidelength ")#mi("{n^{-t}}")#text(", ")#mi("{n \\geq n_0}")#text(" perfectly into a square of area ")#mi("{\\sum_{n=n_0}^\\infty \\frac{1}{n^{2t}}}")#text(".")
]

#text("As in previous works, the general strategy is to execute a greedy algorithm, which can be described somewhat incompletely as follows.")

#list(
[#text("Step 1: Suppose that one has already managed to perfectly pack a square ")#mi("{S}")#text(" of area ")#mi("{\\sum_{n=n_0}^\\infty \\frac{1}{n^{2t}}}")#text(" by squares of sidelength ")#mi("{n^{-t}}")#text(" for ")#mi("{n_0 \\leq n < n_1}")#text(", together with a further finite collection ")#mi("{{\\mathcal R}}")#text(" of rectangles with disjoint interiors. (Initially, we would have ")#mi("{n_1=n_0}")#text(" and ")#mi("{{\\mathcal R} = \\{S\\}}")#text(", but these parameter will change over the course of the algorithm.)")],
[#text("Step 2: Amongst all the rectangles in ")#mi("{{\\mathcal R}}")#text(", locate the rectangle ")#mi("{R}")#text(" of the largest width (defined as the shorter of the two sidelengths of ")#mi("{R}")#text(").")],
[#text("Step 3: Pack (as efficiently as one can) squares of sidelength ")#mi("{n^{-t}}")#text(" for ")#mi("{n_1 \\leq n < n_2}")#text(" into ")#mi("{R}")#text(" for some ")#mi("{n_2>n_1}")#text(", and decompose the portion of ")#mi("{R}")#text(" not covered by this packing into rectangles ")#mi("{{\\mathcal R}^{\\prime}}")#text(".")],
[#text("Step 4: Replace ")#mi("{n_1}")#text(" by ")#mi("{n_2}")#text(", replace ")#mi("{{\\mathcal R}}")#text(" by ")#mi("{({\\mathcal R} \\backslash \\{R\\}) \\cup {\\mathcal R}^{\\prime}}")#text(", and return to Step 1.")]
)

#text("The main innovation of this paper is to perform Step 3 somewhat more efficiently than in previous papers.")

#text("The above algorithm can get stuck if one reaches a point where one has already packed squares of sidelength ")#mi("{1/n^t}")#text(" for ")#mi("{n_0 \\leq n < n_1}")#text(", but that all remaining rectangles ")#mi("{R}")#text(" in ")#mi("{{\\mathcal R}}")#text(" have width less than ")#mi("{n_1^{-t}}")#text(", in which case there is no obvious way to fit in the next square. If we let ")#mi("{w(R)}")#text(" and ")#mi("{h(R)}")#text(" denote the width and height of these rectangles ")#mi("{R}")#text(", then the total area of the rectangles must be")

#align(center)[#tao-fit-display[#mitex("\\sum_{R \\in {\\mathcal R}} w(R) h(R) = \\sum_{n=n_0}^\\infty \\frac{1}{n^{2t}} - \\sum_{n=n_0}^{n_1-1} \\frac{1}{n^{2t}} \\asymp n_1^{1-2t}")]]

#text("and the total perimeter ")#mi("{\\mathrm{perim}({\\mathcal R})}")#text(" of these rectangles is")

#align(center)[#tao-fit-display[#mitex("\\mathrm{perim}({\\mathcal R}) = \\sum_{R \\in {\\mathcal R}} 2(w(R)+h(R)) \\asymp \\sum_{R \\in {\\mathcal R}} h(R).")]]

#text("Thus we have")

#align(center)[#tao-fit-display[#mitex("n_1^{1-2t} \\ll \\mathrm{perim}({\\mathcal R}) \\sup_{R \\in {\\mathcal R}} w(R)")]]

#text("and so to ensure that there is at least one rectangle ")#mi("{R}")#text(" with ")#mi("{w(R) \\geq n_1^{-t}}")#text(" it would be enough to have the perimeter bound")

#align(center)[#tao-fit-display[#mitex("\\mathrm{perim}({\\mathcal R}) \\leq c n_1^{1-t}")]]

#text("for a sufficiently small constant ")#mi("{c>0}")#text(". It is here that we now see the critical nature of the exponent ")#mi("{t=1}")#text(": for ")#mi("{t<1}")#text(", the amount of perimeter we are permitted to have in the remaining rectangles increases as one progresses with the packing, but for ")#mi("{t=1}")#text(" the amount of perimeter one is “budgeted” for stays constant (and for ")#mi("{t>1}")#text(" the situation is even worse, in that the remaining rectangles ")#mi("{{\\mathcal R}}")#text(" should steadily decrease in total perimeter).")

#text("In comparison, the perimeter of the squares that one has already packed is equal to")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=n_0}^{n_1-1} 4 n^{-t}")]]

#text("which is comparable to ")#mi("{n_1^{1-t}}")#text(" for ")#mi("{n_1}")#text(" large (with the constants blowing up as ")#mi("{t}")#text(" approaches the critical value of ")#mi("{1}")#text("). In previous algorithms, the total perimeter of the remainder rectangles ")#mi("{{\\mathcal R}}")#text(" was basically comparable to the perimeter of the squares already packed, and this is the main reason why the results only worked when ")#mi("{t}")#text(" was sufficiently far away from ")#mi("{1}")#text(". In my paper, I am able to get the perimeter of ")#mi("{{\\mathcal R}}")#text(" significantly smaller than the perimeter of the squares already packed, by grouping those squares into lattice-like clusters (of about ")#mi("{M^2}")#text(" squares arranged in an ")#mi("{M \\times M}")#text(" pattern), and sliding the squares in each cluster together to almost entirely eliminate the wasted space between each square, leaving only the space around the cluster as the main source of residual perimeter, which will be comparable to about ")#mi("{M n_1^{-t}}")#text(" per cluster, as compared to the total perimeter of the squares in the cluster which is comparable to ")#mi("{M^2 n_1^{-t}}")#text(". This strategy is perhaps easiest to illustrate with a picture, in which ")#mi("{3 \\times 4}")#text(" squares ")#mi("{S_{i,j}}")#text(" of slowly decreasing sidelength are packed together with relatively little wasted space:")

#image("../assets/a88478367bfd41fb977f3afdf0d7857b6fd66aaea9e5544c6f94e93a137e8bbb-60fcf678540120f0ad81be14160e18fa71163ef2e1c88b5c2b249811762b1bc6.png", width: 90%)

#text("By choosing the parameter ")#mi("{M}")#text(" suitably large (and taking ")#mi("{n_0}")#text(" sufficiently large depending on ")#mi("{M}")#text("), one can then prove the theorem. (In order to do some technical bookkeeping and to allow one to close an induction in the verification of the algorithm’s correctness, it is convenient to replace the perimeter ")#mi("{\\sum_{R \\in {\\mathcal R}} 2(w(R)+h(R))}")#text(" by a slightly weighted variant ")#mi("{\\sum_{R \\in {\\mathcal R}} w(R)^\\delta h(R)}")#text(" for a small exponent ")#mi("{\\delta}")#text(", but this is a somewhat artificial device that somewhat obscures the main ideas.)")

#heading(level: 1)[#text("Comments (41)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640238")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2022")])]

#text("I think you meant the link in the first sentence of this post to send you to arXiv. Instead it seems to just send you to the blog post itself.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640244")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2022")])]

#text("Here is the link: ")#link("https://arxiv.org/abs/2202.03594")[#text("https://arxiv.org/abs/2202.03594")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2022")])]

#text("Thank you!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c89ef3d9ab2f539d1fb9362fb1ac08aada70b0c6aac59ff83f3c0c0358dacb70-f517807a99ce6b39f54b77c56950c2a9aa2f4cd30d57eb02b2f0cedc78b2b182.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of waltonmath")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640240")[#strong[#text("waltonmath")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2022")])]

#text("I think you’re missing a set of parentheses in “is it possible to perfectly pack rectangles of dimensions {1/n \\times 1/n+1}”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f3abe7c149e5a74a76fa60c3f6ef69a7cd278150146b58fc96a44377aa5c5b8-2f4a32961f56f7be1855d6a0cbf8efaad0d72ada77b31c12771cfe1a17d47c9c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640251")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Wonderful stuff! Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640257")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("thanks for giving another possibility of square partition，more beautiful and elegant.（ and I should say “divide a square evenly”in the last situation follows the last blog～）")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/faf5907e93a0671e219db1830637fe07df16be8300106375d2579b6d55e31284-5065c5cd37c418f9be50c7cfb4d6c311e9a9b3b65f8a75ff43b5c34a3669e637.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640254")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("I like the elegance of the theorem. Of course, it would be interesting to know your personal guess whether the result holds also in the case t=1, where it is a Meir-Moser problem. Only having briefly looked at things yet, it is also not clear to me what happens for t>1. Is it an obvious case where one can pack things? In this zeta function context it would also be interesting to know whether the geometric packing problem could make any sense for s=2t complex. The “area” makes sense by analytic continuation but the packing problem might not have an analytic continuation. [Lastly as this has been mentioned in a comment, I was for a second also stuck with 1/n+1 but decided there is absolutely no way to interpret this differently than 1/(n+1). ]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640264")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("My feeling is that the greedy-type algorithms that have been used to handle the ")#mi("t<1")#text(" case will not work for the ")#mi("t \\geq 1")#text(" cases, because of the unfavorable relationship between the perimeter of the squares already used and the area of the squares remaining which suggests (unless one somehow finds an _extremely_ efficient packing algorithm) that the maximum width of the rectangles remaining will not stay above the width of the largest square that is yet to be packed, although there is perhaps some hope of clever trickery to get around this problem in the critical ")#mi("t=1")#text(" case.")

#text("(ADDED LATER): In a bit more detail: suppose one has already packed all the squares of sidelength ")#mi("1/n")#text(" for ")#mi("n_0 \\leq n < n_1")#text(" into a square of area ")#mi("\\sum_{n=n_0}^\\infty \\frac{1}{n^2}")#text(", leaving a remaining area of ")#mi("\\sum_{n=n_1}^\\infty \\frac{1}{n^2} \\asymp 1/n_1")#text(" left to pack, which we view as a union of disjoint rectangles of width ")#mi("w(R)")#text(" and height ")#mi("h(R)")#text(", thus ")#mi("\\sum_R w(R) h(R) \\asymp 1/n_1")#text(". Now if all the remaining rectangles have width less than ")#mi("1/n_1")#text(", then it is now impossible to fit in the next square into any of the remaining rectangles (though it is perhaps conceivable that one could fit it into some union of the rectangles ")#mi("R")#text(", but this would require a substantial reworking of the method in order to keep the rectangles ")#mi("R")#text(" sufficiently adjacent to each other that this becomes possible.) So we would like to ensure that ")#mi("\\max_R w(R) \\geq 1/n_1")#text(". The simplest way to ensure this, given the area bound ")#mi("\\sum_R w(R) h(R) \\asymp 1/n_1")#text(", is to obtain a bound of the form ")#mi("\\sum_R h(R) \\lll 1")#text(", that is to say we would like the total perimeter of all the rectangles in the unpacked space to be small. This looks very difficult to achieve; even the most efficient packing algorithms that I know of will keep the perimeter of the unpacked region roughly unchanged, or increase very slowly, but without a lot of algebraic miracles to ensure a \"flush fit\" of squares, I don't see how to achieve packings that _decrease_ the perimeter over time, or at least keep it smaller than a small absolute constant. In comparison, the perimeter of the squares already packed is ")#mi("\\sum_{n=n_0}^{n_1-1} 4/n \\asymp \\log n_1")#text(" for large ")#mi("n_1")#text(", which (barely) diverges to infinity as ")#mi("n_1")#text(" goes to infinity. It may still be that a perfect packing of the squares of sidelength ")#mi("1/n")#text(", ")#mi("n \\geq n_0")#text(" is possible here (at least for ")#mi("n_0")#text(" large enough), but I think it would require a much more sophisticated algorithm than the greedy type algorithms used here.")

#text("I'm not sure how to make sense of a complex-analytic packing problem, unless perhaps one wants to consider tilings where the locations of the squares depend in an analytic fashion on t. But my first reaction is that this is a primarily combinatorial problem with no complex analytic structure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("It should be remarked that the Riemann mapping theorem has a proof via circle packing – so it may indicate a similar possibility of using squares packing to approximate analytical functions (or analytical mappings).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/81ee428231e68581621b5bffa0308e45bf8ddbce95afb3ac782cfa9d47733d82-a332006b470c5b3728156802ef771b51f5392871b61627a401dac6c0d794e31a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Mastrogiacomo")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640833")[#strong[#text("Jonathan Mastrogiacomo")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2022")])]

#text("My questions are as follows:")

#text("1. How could an algorithm that is, at its core, “greedy”, as admitted, form part of the basis of a “perfect” solution?")

#text("2. What are we to do with what Christopher Langan said in his book, and theory of everything:")

#text("“Of all mathematical structures, language is the most general, powerful and necessary. Not only is every formal or working theory of science and mathematics by definition a language, but science and mathematics in whole and in sum are languages”")

#text("These questions now lead me to quote Proverbs 15:27 ESV, which says:")

#text("“Whoever is greedy for unjust gain troubles his own household”")

#text("I think what we should all do at this point is ask ourselves the following questions:")

#text("1. Which gains are just")#linebreak()#text(" 2. What is the proper affair of a household")

#text("Let me know")

#text("Anyone")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Is it possible to express RH (using these methods) in terms of a similar packing problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4b3a2f3dc5c0ab7fca91c799f1ac2f7f087ec8e497d0d7fdc89b6ed72fcb300-8c0745d13369c49e5d40f94fccf61be10e571bcf9d2ba418186bd87f408f2968.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640259")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Thanks. And managed to understand most it. Consulting job coming up for Amazon trucks and shipping containers to maximise profits!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a778b2ba58f0a83758d062a31b82125493a164e454bac4ed73a5f0b4cb8b8e89-caa1cd9f5051dd9589cb04a35a3d8e1d4fec68bd79393a9eb54194c68326ea90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("A naive question: is it known whether there exists a sequence of side-lengths ")#mi("(s_n)")#text(" such that ")#mi("\\sum s_n")#text(" diverges (but ")#mi("\\sum s_n^2")#text(" converges), yet it is not possible to find a ")#mi("n_0")#text(" and perfectly pack squares of side-lengths ")#mi("(s_n)_{n \\geq n_0}")#text(" into a square of area ")#mi("\\sum_{n\\geq n_0} s_n^2")#text("? (The truncation ")#mi("n_0")#text(" being necessary to avoid the obvious obstruction of e.g. the sequence beginning with two large squares and then all other squares being substantially smaller.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("This is a good question! If the sequence ")#mi("s_n")#text(" decays sufficiently quickly, e.g., ")#mi("s_n = 100^{-n}")#text(", then I’m pretty sure it is not possible to pack squares of sidelength ")#mi("s_n, n \\geq 0")#text(" perfectly into any square (or rectangle) just from perimeter considerations, but creating a counterexample with ")#mi("\\sum_n s_n")#text(" divergent is very close to the original Meir-Moser problem which addresses the case ")#mi("s_n = 1/n")#text(". It seems kind of hard actually to establish negative results in which one can exclude perfect packings from existing; basically the only obstruction I know of is if the first few squares leave behind a region that necessarily has larger perimeter than all the remaining squares put together, but this of course not an obstruction in the infinite perimeter case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640283")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Do you know if anyone has done work on an analogous higher-dimensional version of this problem — say, a cube-packing problem? If so, do the methods you use here generalize?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640290")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("There are some results in higher dimensions; for instance in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=4227795")[#text("this recent paper of Januszewski and Zielonka")]#text(", the cubes of sidelength ")#mi("1/n^t, n \\geq 1")#text(" were packed perfectly into a rectangular box in the range ")#mi("1/3 < t \\leq 4/11")#text(". I'm hoping to interest one of my postdocs in the question of whether the methods in this paper also apply in this three-dimensional case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Thank you for your reply. I’ll take a look at that paper.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/108ff0ed1a7fbbd0b5ef70b3ea06185c852cbf5efdcaefea60af84b13df17cf4-5a8af2149e353ce52de0578b1dde8ab499ab8a943b118623e45baa322aa299b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sandy Ganzell")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640324")[#strong[#text("Sandy Ganzell")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2022")])]

#text("Is there an obvious reason an analogous question for circles would be false? For example (though perhaps this is too naive), could a sequence of circles of harmonic (or nearly harmonic) radius be packed into a circle of radius ")#mi("\\frac{\\pi}{\\sqrt{6}}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2022")])]

#text("Nice question. I hope Dr. Tao will also compare and contrast on sphere packing vs. square packing, for those who are new to the problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2022")])]

#text("I don’t see any obstruction to this, but it is likely harder to prove than the analogous problem for squares. With squares, once one packs a finite number of squares inside a square, the remaining region can be partitioned fairly efficiently into rectangles, which allows for efficient packing algorithms. When one packs a finite number of circles into circles, the remaining regions decompose into various circular triangles of various eccentrities; it may be possible to adapt the existing packing arguments to this setting, though I don’t know if it is efficient enough to get as close to the harmonic radius case as one can in the square case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-641277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2022")])]

#text("Do you know if there has been any work done on this problem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-641285")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2022")])]

#text("Some people in my research group are looking into this question currently.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7f94bcf8ab56d1d9019d1d11a94a5c4980ad8d709e51f23ceef064514e11f7cf-bfb9bbc3ebb796a35daf223dd648e324f6deb59fff895503af67db54abe436e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640344")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2022")])]

#text("This is by far not my area of expertise, but I wonder whether almost-perfect packings could be used to obtain a perfect packing? That is, suppose that for all ")#mi("\\varepsilon > 0")#text(" we can pack the squares into a square of area ")#mi("\\frac{\\pi^2}{6} + \\varepsilon")#text(". Can we then pack the squares into a square of area ")#mi("\\frac{\\pi^2}{6}")#text("?")

#emph[#text("[Yes, this follows from a standard compactness argument, and appears to have first been observed in this context ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1883864")[#text("by Martin")]#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640453")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2022")])]

#text("Just a minor typo… In the abstract of your paper, you mention that this was “previously known for ")#mi("1/2 < t < 2/3")#text("\", while in the third paragraph of the first page of your paper, you mention that \"an affirmative answer to this question was given in the range ")#mi("1/2 < t \\leq 2/3")#text("\" (one inequality is strict, the other is not).")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2022")])]

#text("Also, there is a typo in the first sentence of Proposition 2.2 of your paper, you say, “suppose that ")#mi("R")#text(" is a rectangle of with dimensions…”")

#emph[#text("[Thanks, this will be corrected i the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640458")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2022")])]

#text("In the first (unnumbered) equation of page 5 in your paper, you bound the total weighted perimeter by ")#mi("M^{1 + \\frac{\\delta(1-\\delta)}{2}} n_0^{1-t-\\delta t}")#text(". I’m wondering if that should be ")#mi("M^{-1 + \\frac{\\delta}{2}} n_0^{1-t-\\delta t}")#text(", or am I just missing something?")

#emph[#text("[This was a typo, and will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640459")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2022")])]

#text("In page5, line 12")#linebreak()#text(" I can’t understand why the exponent of ")#mi("M")#text(" is ")#mi("1+\\delta (1-\\delta )/2")#text(".")#linebreak()#text(" It’s no problem, but I think ")#mi("M^{-1+\\delta /2}")#text(" is more natural.")

#emph[#text("[This was a typo, and will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640524")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2022")])]

#text("I guess")#linebreak()#text(" Page7, line 10. $w(R)$ should be $h(R)$")#linebreak()#text(" Page8, line -8. $y_{i,j+1}=y_{i,j}$ should be $y_{i,j+1}=y_{i,j}+n_{i,j}^{-t}$")#linebreak()#text(" Page 9, lines -5~-4. $M_{i}$, $M_{j}$ should be $M_{1}$, $M_{2}$ respectively.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2022")])]

#text("On page 7 of your paper, in the third and fourth equations, I’m thinking that the ")#mi("n")#text("‘s should probably be ")#mi("n_0")#text("‘s. In addition, in the fourth equation, I’m thinking that the ")#mi("w(R)")#text(" should be ")#mi("h(R)")#text(".")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2022")])]

#text("In the first equation of page 7 of your paper, I’m wondering if the upper bound of the sum should be ")#mi("M_1 - 1")#text(" instead of ")#mi("M_1")#text(".")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-640748")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2022")])]

#text("Same sort of thing in the second equation page 7… I think the lower bound in the sum might should be ")#mi("0")#text(" instead of ")#mi("1")#text(".")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-641269")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2022")])]

#text("On page 4, when deducing Theorem 1.1 from Proposition 2.1, you state that you use a standard compactness argument (citing Martin) to complete the proof. Why do we need Martin’s result here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-641271")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2022")])]

#text("Martin’s argument is cited just an example of the type of compactness argument used here that happens already to be in the literature on this type of problem. One can use a number of other (closely related) compactness arguments to get from a finite packing of arbitrarily many squares in a sequence to an infinite packing of all the squares in that sequence; for instance, one can use Tychonoff’s theorem, the Arzeli-Ascoli theorem, or the compactness theorem in first-order logic. (One could also use nonstandard analysis to transfer the finite packing to an infinite packing, though this is a somewhat gratuitious use of that formalism.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-641275")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2022")])]

#text("Hey Mr Tao could I have some of your time for an idea I have come up for an application of the natural numbers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-641297")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2022")])]

#text("p.8")#linebreak()#text(" In the definition of y_{i,j}, maybe j’ runs from 0 to j-1.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-641679")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2022")])]

#text("I think there are some minor mistakes in your argument on disjointness of the interiors of two different squares.")

#text("I considered the following modification.")#linebreak()#text(" 1. If i’≦i and j’>j, y_{i,j}+n_{i.j}^{-t}≦y_{i’,j’}. Hence the interior of S_{i,j} lies below of the interior of S_{i’,j’}. Similarly if i≦i’, j>j’.")#linebreak()#text(" 2. If i'<i and j'≦j, x_{i',j'}+n_{i',j'}^{-t}≦x_{i,j}. Hence the interior of S_{i',j'} lies left to the interior of S_{i,j}. Similarly if i<i', j≦j'.")

#text("(It is very possible that I'm mistaken.)")

#emph[#text("[Oops, the roles of ")#mi("i")#text(" and ")#mi("j")#text(" need to be switched in several places in this part of the argument. This will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-642548")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2022")])]

#text("Page9, (3.4)")#linebreak()#text(" The surrounded rectangle will be")#linebreak()#text(" [x_{i+1,j},x_{i+1,j+1}]×[y_{i+1,j+1},y_{i,j+1}].")

#emph[#text("[This will be corrected in the next revision of the ms, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-642575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2022")])]

#text("Are these 3D packing problems related to the Erdos-Graham problem (as a 1D packing problem for Egyptian fraction representation of 1)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-642576")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2022")])]

#text("Correction: 3D should be 2D")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/41a5a0b3b7b40f3b3a34d59c1b2741aaa5391bd73354321ca0b2271d0daf6453-3af58e866e713d8735fc731a76486fb160803aa4579677db04dca5fd4e8a96f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Keiju Sono")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-642707")[#strong[#text("Keiju Sono")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2022")])]

#text("I’m now trying to generalize your theorem to the problem of perfectly packing a square by squares of sidelength f(n)^{-t}. I’m also trying to give effective lower bounds for M and N_{0} depending on f and t.")#linebreak()#text(" In this process I thought that your lower bound for M (which is exp(C/δ), where C is an absolute constant) might be too small.")#linebreak()#text(" As far as I considered, M should be larger than (at least) (4/(1-t))^(2/(1-t)) as t→1 to justify your argument to obtain (2.7) in page 5.")#linebreak()#text(" It’s a bit difficult for me to explain this reason in this form, so I’ve made a PDF file and I’ll send you by e-mail. I hope you will read some of it, although it may contain some of my misunderstandings.")

#emph[#text("[This will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dafdf3b102cd6c00a7330fd2e4e749d63b100b002b98feb95cde361879c517f4-823915a80ba1c666a830fc14607e3852710bf2e6f76fbdeb1ed0a4c0439cc703.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/02/08/perfectly-packing-a-square-by-squares-of-nearly-harmonic-sidelength/#comment-642808")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2022")])]

#text("I’ve just uploaded a preprint of a three-dimensional analogue of this result: ")#link("https://arxiv.org/abs/2204.06038")[#text("https://arxiv.org/abs/2204.06038")]#text(".")
]
