// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/
// Converted to Typst by tao2typ: "2026-10-14T16:35:27.265413+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Concentration compactness and the profile decomposition", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Concentration compactness and the profile decomposition")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 November 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/")[#text("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the most important topological concepts in analysis is that of ")#link("http://en.wikipedia.org/wiki/Compact_space")[#emph[#text("compactness")]]#text(" (as discussed for instance in ")#link("https://terrytao.wordpress.com/2007/11/20/pcm-article-compactness-and-compactification/")[#text("my Companion article on this topic")]#text("). There are various flavours of this concept, but let us focus on ")#link("http://en.wikipedia.org/wiki/Sequentially_compact")[#text("sequential compactness")]#text(": a subset E of a ")#link("http://en.wikipedia.org/wiki/Topological_space")[#text("topological space")]#text(" X is sequentially compact if every sequence in E has a convergent subsequence whose limit is also in E. This property allows one to do many things with the set E. For instance, it allows one to maximise a functional on E:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" (Existence of extremisers) Let E be a non-empty sequentially compact subset of a topological space X, and let ")#mi("F: E \\to {\\Bbb R}")#text(" be a continuous function. Then the supremum ")#mi("\\sup_{x \\in E} f(x)")#text(" is attained at at least one point ")#mi("x_* \\in E")#text(", thus ")#mi("F(x) \\leq F(x_*)")#text(" for all ")#mi("x \\in E")#text(". (In particular, this supremum is finite.) Similarly for the infimum.")
]

#strong[#text("Proof.")]#text(" Let ")#mi("-\\infty < L \\leq +\\infty")#text(" be the supremum ")#mi("L := \\sup_{x \\in E} F(x)")#text(". By the definition of supremum (and the ")#link("http://en.wikipedia.org/wiki/Axiom_of_countable_choice")[#text("axiom of (countable) choice")]#text("), one can find a sequence ")#mi("x^{(n)}")#text(" in E such that ")#mi("F(x^{(n)}) \\to L")#text(". By compactness, we can refine this sequence to a subsequence (which, by abuse of notation, we shall continue to call ")#mi("x^{(n)}")#text(") such that ")#mi("x^{(n)}")#text(" converges to a limit x in E. Since we still have ")#mi("f(x^{(n)}) \\to L")#text(", and f is continuous at x, we conclude that f(x)=L, and the claim for the supremum follows. The claim for the infimum is similar. ")#mi("\\Box")

#strong[#text("Remark 1.")]#text(" An inspection of the argument shows that one can relax the continuity hypothesis on F somewhat: to attain the supremum, it suffices that F be upper ")#link("http://en.wikipedia.org/wiki/Semi-continuity")[#text("semicontinuous")]#text(", and to attain the infimum, it suffices that F be lower semicontinuous. ")#mi("\\diamond")

#text("We thus see that sequential compactness is useful, among other things, for ensuring the existence of extremisers. In finite-dimensional spaces (such as vector spaces), compact sets are plentiful; indeed, the ")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("Heine-Borel theorem")]#text(" asserts that every closed and bounded set is compact. However, once one moves to infinite-dimensional spaces, such as ")#link("http://en.wikipedia.org/wiki/Function_space")[#text("function spaces")]#text(", then the Heine-Borel theorem fails quite dramatically; most of the closed and bounded sets one encounters in a topological vector space are non-compact, if one insists on using a reasonably “strong” topology. This causes a difficulty in (among other things) ")#link("http://en.wikipedia.org/wiki/Calculus_of_variations")[#text("calculus of variations")]#text(", which is often concerned to finding extremisers to a functional ")#mi("F: E \\to {\\Bbb R}")#text(" on a subset E of an infinite-dimensional function space X.")

#text("In recent decades, mathematicians have found a number of ways to get around this difficulty. One of them is to weaken the topology to recover compactness, taking advantage of such results as the ")#link("http://en.wikipedia.org/wiki/Banach%E2%80%93Alaoglu_theorem")[#text("Banach-Alaoglu theorem")]#text(" (or its sequential counterpart). Of course, there is a tradeoff: weakening the topology makes compactness easier to attain, but makes the continuity of F harder to establish. Nevertheless, if F enjoys enough “smoothing” or “cancellation” properties, one can hope to obtain continuity in the weak topology, allowing one to do things such as locate extremisers. (The phenomenon that cancellation can lead to continuity in the weak topology is sometimes referred to as ")#emph[#text("compensated compactness")]#text(".)")

#text("Another option is to abandon trying to make ")#emph[#text("all")]#text(" sequences have convergent subsequences, and settle just for extremising sequences to have convergent subsequences, as this would still be enough to retain Theorem 1. Pursuing this line of thought leads to the ")#link("http://en.wikipedia.org/wiki/Palais-Smale_compactness_condition")[#text("Palais-Smale condition")]#text(", which is a substitute for compactness in some calculus of variations situations.")

#text("But in many situations, one cannot weaken the topology to the point where the domain E becomes compact, without destroying the continuity (or semi-continuity) of F, though one can often at least find an intermediate topology (or ")#link("http://en.wikipedia.org/wiki/Metric_(mathematics)")[#text("metric")]#text(") in which F is continuous, but for which E is still not quite compact. Thus one can find sequences ")#mi("x^{(n)}")#text(" in E which do not have any subsequences that converge to a constant element ")#mi("x \\in E")#text(", even in this intermediate metric. (As we shall see shortly, one major cause of this failure of compactness is the existence of a non-trivial ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("action")]#text(" of a non-compact group G on E; such a group action can cause compensated compactness or the Palais-Smale condition to fail also.) Because of this, it is ")#emph[#text("a priori")]#text(" conceivable that a continuous function F need not attain its supremum or infimum.")

#text("Nevertheless, even though a sequence ")#mi("x^{(n)}")#text(" does not have any subsequences that converge to a constant x, it may have a subsequence (which we also call ")#mi("x^{(n)}")#text(") which converges to some non-constant sequence ")#mi("y^{(n)}")#text(" (in the sense that the distance ")#mi("d(x^{(n)},y^{(n)})")#text(" between the subsequence and the new sequence in a this intermediate metric), where the approximating sequence ")#mi("y^{(n)}")#text(" is of a very structured form (e.g. “concentrating” to a point, or “travelling” off to infinity, or a superposition ")#mi("y^{(n)} = \\sum_j y^{(n)}_j")#text(" of several concentrating or travelling ")#emph[#text("profiles")]#text(" of this form). This weaker form of compactness, in which superpositions of a certain type of profile completely describe all the failures (or ")#emph[#text("defects")]#text(") of compactness, is known as ")#link("http://wiki.math.toronto.edu/DispersiveWiki/index.php/Concentration_compactness")[#emph[#text("concentration compactness")]]#text(", and the decomposition ")#mi("x^{(n)} \\approx \\sum_j y^{(n)}_j")#text(" of the subsequence is known as the ")#emph[#text("profile decomposition")]#text(". In many applications, it is a sufficiently good substitute for compactness that one can still do things like locate extremisers for functionals F – though one often has to make some additional assumptions of F to compensate for the more complicated nature of the compactness. This phenomenon was systematically studied by ")#link("http://en.wikipedia.org/wiki/Pierre-Louis_Lions")[#text("P.L. Lions")]#text(" in the 80s, and found great application in calculus of variations and nonlinear elliptic PDE. More recently, concentration compactness has been a crucial and powerful tool in the non-perturbative analysis of nonlinear ")#emph[#text("dispersive")]#text(" PDE, in particular being used to locate “minimal energy blowup solutions” or “minimal mass blowup solutions” for such a PDE (analogously to how one can use calculus of variations to find minimal energy solutions to a nonlinear elliptic equation); see for instance this ")#link("http://www.math.uchicago.edu/~mvisan/ClayLectureNotes.pdf")[#text("recent survey by Killip and Visan")]#text(".")

#text("In typical applications, the concentration compactness phenomenon is exploited in moderately sophisticated function spaces (such as ")#link("http://en.wikipedia.org/wiki/Sobolev_space")[#text("Sobolev spaces")]#text(" or ")#link("http://tosio.math.toronto.edu/wiki/index.php/Strichartz_estimates")[#text("Strichartz")]#text(" spaces), with the failure of traditional compactness being connected to a moderately complicated group G of symmetries (e.g. the group generated by translations and dilations). Because of this, concentration compactness can appear to be a rather complicated and technical concept when it is first encountered. In this note, I would like to illustrate concentration compactness in a simple toy setting, namely in the space ")#mi("X = l^1({\\Bbb Z})")#text(" of absolutely summable sequences, with the uniform (")#mi("l^\\infty")#text(") metric playing the role of the intermediate metric, and the translation group ")#mi("{\\Bbb Z}")#text(" playing the role of the symmetry group G. This toy setting is significantly simpler than any model that one would actually use in practice [for instance, in most applications X is a ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert space")]#text("], but hopefully it serves to illuminate this useful concept in a less technical fashion.")

#heading(level: 1)[#metadata(none) <tao-264f6d00b5f17a923f3b>#text("— Defects of compactness in ")#mi("l^1({\\Bbb Z})")#text(" —")]

#text("Consider the space")

#align(center)[#tao-fit-display[#tao-math("X := l^1({\\Bbb Z}) := \\{ (x_m)_{m \\in {\\Bbb Z}}: \\sum_{m \\in {\\Bbb Z}} \\left|x_m\\right| < \\infty \\}", block: true)]]

#text("of absolutely summable doubly infinite sequences ")#mi("x = (x_m)_{m \\in {\\Bbb Z}}")#text("; this is a normed vector space generated by the basis vectors ")#mi("e_n := (\\delta_{n, m})_{m \\in {\\Bbb Z}}")#text(" for ")#mi("n \\in {\\Bbb Z}")#text(" (here ")#mi("\\delta")#text(" is the Kronecker delta). We can place several topologies on this space X:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1.")]#text(" Let ")#mi("x^{(n)} = (x^{(n)}_m)_{m \\in {\\Bbb Z}}")#text(" be a sequence in X (i.e. a sequence of sequences!), and let ")#mi("x = (x_m)_{m \\in {\\Bbb Z}}")#text("be another element in X.")

#enum(start: 1, 
[#text("(")#link("http://en.wikipedia.org/wiki/Strong_topology")[#text("Strong topology")]#text(") We say that ")#mi("x^{(n)}")#text(" converges to x in the ")#emph[#text("strong topology")]#text(" (or ")#emph[#mi("l^1")#text(" topology")]#text(") if the ")#mi("l^1")#text(" distance ")#tao-math("\\left\\|x^{(n)}-x\\right\\|_{l^1({\\Bbb Z})} := \\sum_{m \\in {\\Bbb Z}} \\left|x^{(n)}_m - x_m\\right|", block: false)#text(" converges to zero.")],
[#text("(Intermediate topology) We say that ")#mi("x^{(n)}")#text(" converges in x in the ")#emph[#text("intermediate topology")]#text(" (or ")#link("http://en.wikipedia.org/wiki/Uniform_convergence")[#emph[#text("uniform topology")]]#text(") if the ")#mi("l^\\infty")#text(" distance ")#tao-math("\\left\\|x^{(n)}-x\\right\\|_{l^\\infty({\\Bbb Z})} := \\sup_{m \\in {\\Bbb Z}} \\left|x^{(n)}_m - x_m\\right|", block: false)#text(" converges to zero.")],
[#text("(")#link("http://en.wikipedia.org/wiki/Weak_topology")[#text("Weak topology")]#text(") We say that ")#mi("x^{(n)}")#text(" converges in x in the ")#emph[#text("weak topology")]#text(" (or ")#emph[#text("pointwise topology")]#text(") if ")#mi("x^{(n)}_m \\to x_m")#text(" as ")#mi("n \\to \\infty")#text(" for each m. [Strictly speaking, this only describes the weak topology for ")#emph[#text("bounded")]#text(" sequences, but these are the only sequences we will be considering here.]")]
)
]

#strong[#text("Example 1.")]#text(" The sequence ")#mi("e_n")#text(" for ")#mi("n=1,2,\\ldots")#text(" converges weakly to zero, but is not convergent in the strong or intermediate topologies. The sequence ")#mi("\\frac{1}{n} \\sum_{n^{\\prime}=1}^n e_{n^{\\prime}}")#text(" converges in the intermediate and weak topologies to zero, but is not convergent in the strong topology. ")#mi("\\diamond")

#text("It is easy to see that strong convergence implies intermediate convergence, which in turn implies weak convergence, thus justifying the names “strong”, “intermediate”, and “weak”. For bounded sequences, the intermediate topology can also be described by a number of other norms, e.g. the ")#mi("l^p({\\Bbb Z})")#text(" norm for any ")#mi("p>1")#text(" (this is an easy application of ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder%27s_inequality")[#text("Hölder’s inequality")]#text(").")

#text("The space X also has the ")#emph[#text("translation action")]#text(" of the group of integers ")#mi("G := {\\Bbb Z}")#text(", defined using the shift operators ")#mi("T^h: X \\to X")#text(" for ")#mi("h \\in G")#text(", defined by the formula")

#align(center)[#tao-fit-display[#mitex("T^h (x_m)_{m \\in {\\Bbb Z}} := (x_{m-h})_{m \\in {\\Bbb Z}}")]]

#text("(in particular, ")#mi("T^h")#text(" is linear with ")#mi("T^h e_n = e_{n+h}")#text("). This action is continuous with respect to all three of the above topologies. (We give G the discrete topology.)")

#text("Inside the infinite-dimensional space X, we let E be the “unit sphere” (though it looks more like an octahedron, actually)")

#align(center)[#tao-fit-display[#tao-math("E := \\{ (x_m)_{m \\in {\\Bbb Z}} \\in X: \\sum_{m \\in {\\Bbb Z}} \\left|x_m\\right| = 1 \\}.", block: true)]]

#text("E is clearly invariant under the translation action of G. It is easy to see that E is closed and bounded in the strong topology (or metric). However, it is not closed in the weak topology: the sequence ")#mi("e_n \\in E")#text(" of basis vectors for ")#mi("n=1,2,\\ldots")#text(" converges weakly to the origin 0, which lies outside of E. It is also not closed in the intermediate topology; the sequence ")#mi("\\frac{1}{n} \\sum_{n^{\\prime}=1}^n e_{n^{\\prime}}")#text(" lies in E but converges in the intermediate topology to 0, which lies outside of E.")

#text("The failure of closure in the weak topology causes failure of compactness in the strong or intermediate topologies. Indeed, the sequence ")#mi("e_n \\in E")#text(" cannot have any convergent subsequence in those topologies, since the limit of such a subsequence would have to equal its weak limit, which is zero; but ")#mi("e_n")#text(" clearly does not converge in either the strong or intermediate topologies to 0. (To put it another way, the embedding of ")#mi("l^1({\\Bbb Z})")#text(" into ")#mi("l^\\infty({\\Bbb Z})")#text(" is not ")#link("http://en.wikipedia.org/wiki/Compact_operator")[#text("compact")]#text(".)")

#text("More generally, for any fixed ")#emph[#text("profile")]#text(" ")#mi("x \\in E")#text(", the “travelling wave” (or “travelling profile”) ")#mi("T^n x \\in E")#text(" for ")#mi("n = 1, 2, \\ldots")#text(" converges weakly to zero, and so by the above argument has no convergent subsequence in the strong or intermediate topologies. A little more generally still, given any sequence ")#mi("h^{(n)}")#text(" of integers going off to infinity, ")#mi("T^{h^{(n)}} x \\in E")#text(" is a sequence in E which has no convergent subsequence in the strong or intermediate topologies. Thus we see that the action of the (non-compact) group G is causing a failure of compactness of E in the strong and intermediate topologies.")

#text("Because of the linear nature of the vector space X, one can also create examples of sequences in E with no convergent subsequences by taking superpositions of travelling profiles. For instance, if ")#mi("x_1, x_2 \\in X")#text(" are two non-negative sequences with ")#tao-math("\\left\\|x_1\\right\\|_{l^1({\\Bbb Z})} + \\left\\|x_2\\right\\|_{l^1({\\Bbb Z})} = 1", block: false)#text(", and ")#mi("h^{(n)}_1, h^{(n)}_2")#text(" are two sequences of integers which both go off to infinity,")

#align(center)[#tao-fit-display[#tao-math("\\left|h^{(n)}_1\\right|, \\left|h^{(n)}_2\\right| \\to \\infty", block: true)]]

#text("then the superposition")

#align(center)[#tao-fit-display[#mitex("x^{(n)} := T^{h^{(n)}_1} x_1 + T^{h^{(n)}_2} x_2")]]

#text("of the two travelling profiles ")#mi("T^{h^{(n)}_1} x_1")#text(" and ")#mi("T^{h^{(n)}_2} x_2")#text(" will be a sequence in E that continues to converge weakly to zero, and so again has no convergent subsequence in the strong or intermediate topologies.")

#text("If ")#mi("x_1")#text(" and ")#mi("x_2")#text(" are not non-negative, then there can be cancellations between ")#mi("T^{h^{(n)}_1} x_1")#text(" and ")#mi("T^{h^{(n)}_2} x_2")#text(", which could cause ")#mi("x^{(n)}")#text(" to have norm significantly less than 1 (thus straying away from E). However, if one also imposes the ")#emph[#text("asymptotic orthogonality")]#text(" condition")

#align(center)[#tao-fit-display[#tao-math("\\left|h^{(n)}_2 - h^{(n)}_1\\right| \\to \\infty", block: true)]]

#text("we see that these cancellations vanish in the limit ")#mi("n \\to \\infty")#text(", and so in this case we can build a modified superposition")

#align(center)[#tao-fit-display[#mitex("x^{(n)} := T^{h^{(n)}_1} x_1 + T^{h^{(n)}_2} x_2 + w^{(n)}")]]

#text("that lies in E, with ")#mi("w^{(n)}")#text(" converging to zero in the strong and uniform topology, and will once again be a sequence with no convergent subsequence. [If the asymptotic orthogonality condition fails, then one can collapse the superposition of two travelling profiles into a single travelling profile, after passing to a subsequence if necessary. Indeed, if ")#tao-math("\\left|h^{(n)}_2 - h^{(n)}_1\\right|", block: false)#text(" does not go to infinity, then we can find a subsequence for which ")#mi("h^{(n)}_2 - h^{(n)}_1")#text(" is equal to a constant c, in which case ")#mi("T^{h^{(n)}_1} f_1 + T^{h^{(n)}_2} f_2")#text(" is equal to a single travelling profile ")#mi("T^{h^{(n)}_1}( f_1 + T^c f_2 )")#text(".] More generally, given any collection ")#mi("x_j")#text(" of non-zero elements of X with")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\sum_j \\left\\|x_j\\right\\|_{l^1({\\Bbb Z})} \\leq 1", block: true)]]

#text("and any sequences ")#mi("h^{(n)}_j")#text(" of integers obeying the asymptotic orthogonality condition")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left|h^{(n)}_{j^{\\prime}} - h^{(n)}_j\\right| \\to \\infty \\text{ as } n \\to \\infty", block: true)]]

#text("for all ")#mi("j^{\\prime} > j")#text(", we can find a sequence in ")#mi("x^{(n)}")#text(" that takes the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("x^{(n)} = \\sum_j T^{h^{(n)}_j} x_j + w^{(n)}")]]

#text("where ")#mi("w^{(n)}")#text(" converges to zero in the intermediate topology. [If one has equality in (1), one can make ")#mi("w^{(n)}")#text(" converge in the strong topology also.] If ")#mi("h^{(n)}_j")#text(" goes off to infinity for at least one j with ")#mi("x_j")#text(" non-zero, then this sequence will have no convergent subsequence.")

#text("We have thus demonstrated a large number of ways that compactness of E fails in the strong and intermediate topologies. The concentration compactness phenomenon, in this setting, tells us that these are essentially the ")#emph[#text("only")]#text(" ways in which compactness fails in the intermediate topology. More precisely, one has")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2.")]#text(" (Profile decomposition) Let ")#mi("x^{(n)}")#text(" be a sequence in E. Then, after passing to a subsequence (which we still call ")#mi("x^{(n)}")#text("), there exist ")#mi("x_j \\in X")#text(" obeying (1), and sequences ")#mi("h^{(n)}_j")#text(" of integers obeying (2), such that we have the decomposition (3) where the error ")#mi("w^{(n)}")#text(" converges to zero in the intermediate topology. Furthermore, we can improve (1) to")

#align(center)[#tao-math("\\sum_j \\left\\|x_j\\right\\|_{l^1({\\Bbb Z})} + \\lim_{n \\to \\infty} \\left\\|w^{(n)}\\right\\|_{l^1({\\Bbb Z})} \\leq 1", block: false)#text(" (1′)")]
]

#strong[#text("Remark 2.")]#text(" The situation is vastly different in the strong topology; in this case, virtually every sequence in E fails to have a convergent subsequence (consider for instance the sequence ")#mi("\\frac{1}{n} \\sum_{n^{\\prime}=1}^n e_{n^{\\prime}}")#text(" from Example 1), and there are so many different ways a sequence can behave that there is no meaningful profile decomposition. A more quantitative way to see this is via a computation of metric entropy constants (i.e. covering numbers). Pick a small number ")#mi("\\varepsilon > 0")#text(" (e.g. ")#mi("\\varepsilon = 0.1")#text(") and a large number N, and consider how many balls of radius ")#mi("\\varepsilon")#text(" in the ")#mi("l^1(\\{1,\\ldots,N\\})")#text(" norm are needed to cover the unit sphere ")#mi("E_N")#text(" in ")#mi("l^1(\\{1,\\ldots,N\\})")#text(". A simple volume packing argument shows that this number must grow exponentially in N. On the other hand, if one wants to cover ")#mi("E_N")#text(" with the (much larger) balls of radius ")#mi("\\varepsilon")#text(" in the ")#mi("l^\\infty(\\{1,\\ldots,N\\})")#text(" topology instead, the number of balls needed grows only polynomially with N. Indeed, after rounding down each coefficient of an element of ")#mi("l^1(\\{1,\\ldots,N\\})")#text(" to a multiple of ")#mi("\\varepsilon")#text(", there are only at most ")#mi("1/\\varepsilon")#text(" non-zero coefficients, and so the total number of possibilities for this rounded down approximant is about ")#mi("(n/\\varepsilon)^{1/\\varepsilon}")#text(". Thus, the metric entropy constants for both the strong and intermediate topologies go to infinity in the infinite dimensional limit ")#mi("N \\to \\infty")#text(" (thus demonstrating the lack of compactness for both), but much more rapidly for the former than for the latter. ")#mi("\\diamond")

#heading(level: 1)[#text("— Proof sketch of Theorem 2 —")]

#text("We now sketch how one would prove Theorem 2. The idea is to hunt down and “domesticate” the large values of ")#mi("x^{(n)}")#text(", as these are the only obstructions to convergence in the intermediate topology. (I believe the use of the term “domesticate” here is due to ")#link("http://www.math.uu.se/~tintarev/")[#text("Kyril Tintarev")]#text(".) Each large piece of the ")#mi("x^{(n)}")#text(" that we capture in this manner will decrease the total “mass” in play, which guarantees that eventually one runs out of such large pieces, at which point one obtains the decomposition (3). [Curiously, the strategy here is very similar to that underlying the structural theorems that arise in additive combinatorics and ergodic theory; I touched upon these analogies before in my ")#link("https://terrytao.wordpress.com/tag/simons-lecture/")[#text("Simons lectures")]#text(".] In this process we rely heavily on the freedom to pass to a subsequence at will, which is useful to eliminate any fluctuations so long as they range over a compact space of possibilities.")

#text("Let’s see how this procedure works. We begin with our bounded sequence ")#mi("x^{(n)}")#text(", whose ")#mi("l^1")#text(" norms are all equal to 1. If this sequence already converging to zero in the intermediate topology, we are done (we let j range over the empty set, and set ")#mi("w^{(n)}")#text(" equal to all of ")#mi("x^{(n)}")#text(". So suppose that ")#mi("x^{(n)}")#text(" are not converging to zero in this topology. Passing to a subsequence if necessary, this implies the existence of an ")#mi("\\varepsilon_1 > 0")#text(" such that ")#tao-math("\\left\\|x^{(n)}\\right\\|_{l^\\infty({\\Bbb Z})} > \\varepsilon_1", block: false)#text(" for all n. Thus we can find integers ")#mi("h^{(n)}_1")#text(" such that ")#tao-math("\\left|x^{(n)}_{h^{(n)}_1}\\right| > \\varepsilon_1", block: false)#text(" for all n, or equivalently that the shifts ")#mi("T^{-h^{(n)}_1} x^{(n)}")#text(" have their zero coefficient uniformly bounded below in magnitude by ")#mi("\\varepsilon_1")#text(".")

#text("We have used the symmetry group G to move a large component of each of the ")#mi("x^{(n)}")#text(" the origin. Now we take advantage of sequential compactness of the unit ball in the ")#emph[#text("weak")]#text(" topology. This allows one (after passing to another subsequence) to assume that the shifted elements ")#mi("T^{-h^{(n)}_1} x^{(n)}")#text(" converge weakly to some limit ")#mi("x_1")#text("; since the ")#mi("T^{-h^{(n)}_1} x^{(n)}")#text(" are uniformly non-trivial at the origin, the weak limit ")#mi("x_1")#text(" is also; in particular, we have ")#tao-math("\\left\\|x_1\\right\\|_{l^1({\\Bbb Z})} \\geq \\varepsilon_1 > 0", block: false)#text(". Undoing the shift, we have obtained a decomposition")

#align(center)[#tao-fit-display[#mitex("x^{(n)} = T^{h^{(n)}_1} x_1 + w^{(n)}_1")]]

#text("where the ")#link("http://en.wikipedia.org/wiki/Residual_(numerical_analysis)")[#text("residual")]#text(" ")#mi("w^{(n)}_1")#text(" is such that ")#mi("T^{-h^{(n)}_1} w^{(n)}_1")#text(" converges weakly to zero (thus, in some sense ")#mi("w^{(n)}_1")#text(" vanishes asymptotically near ")#mi("h^{(n)}_1")#text("). It is then not difficult to show the “asymptotic orthogonality” relationship")

#align(center)[#tao-fit-display[#tao-math("\\left\\|x^{(n)}\\right\\|_{l^1({\\Bbb Z})} = \\left\\|T^{h^{(n)}_1} x_1\\right\\|_{l^1({\\Bbb Z})} + \\left\\|w^{(n)}_1\\right\\|_{l^1({\\Bbb Z})} + o(1)", block: true)]]

#text("where ")#mi("o(1)")#text(" is a quantity that goes to zero as ")#mi("n \\to \\infty")#text("; this implies, in particular, that the residual ")#mi("w^{(n)}_1")#text(" eventually has mass strictly less than that of the original sequence ")#mi("x^{(n)}_1")#text(":")

#align(center)[#tao-math("\\left\\|w^{(n)}_1\\right\\|_{l^1({\\Bbb Z})} \\leq 1 - \\varepsilon_1 + o(1)", block: false)#text(";")]

#text("in fact we have the more precise relationship")

#align(center)[#tao-math("\\left\\|x_1\\right\\|_{l^1({\\Bbb Z})} + \\lim_{n \\to \\infty} \\left\\|w^{(n)}_1\\right\\|_{l^1({\\Bbb Z})} = 1", block: false)#text(".")]

#text("Now we take this residual ")#mi("w^{(n)}_1")#text(" and repeat the whole process. Namely, if ")#mi("w^{(n)}_1")#text(" converges in the intermediate topology to zero, then we are done; otherwise, as before, we can find (after passing to a subsequence) ")#mi("\\varepsilon_2 > 0")#text(", ")#mi("h^{(n)}_2")#text(" for which ")#mi("T^{-h^{(n)}_2} w^{(n)}_1")#text(" is bounded from below by ")#mi("\\varepsilon_2")#text(" at the origin. Because ")#mi("T^{-h^{(n)}_1} w^{(n)}_1")#text(" already converged weakly to zero, one can conclude that ")#mi("h^{(n)}_2")#text(" and ")#mi("h^{(n)}_1")#text(" must be asymptotically orthogonal in the sense of (2).")

#text("Passing to a subsequence again, we can assume that ")#mi("T^{-h^{(n)}_2} w^{(n)}_2")#text(" converges weakly to a limit ")#mi("x_2")#text(" with mass at least ")#mi("\\varepsilon_2")#text(", leading to a decomposition")

#align(center)[#tao-fit-display[#mitex("x^{(n)} = T^{h^{(n)}_1} x_1 + T^{h^{(n)}_2} x_2 + w^{(n)}_2")]]

#text("where the residual ")#mi("w^{(n)}_2")#text(" is such that ")#mi("T^{-h^{(n)}_1} w^{(n)}_2")#text(" and ")#mi("T^{-h^{(n)}_2} w^{(n)}_2")#text(" both converge weakly to zero, and has norm")

#align(center)[#tao-math("\\left\\|w^{(n)}_2\\right\\|_{l^1({\\Bbb Z})} \\leq 1 - \\varepsilon_1 - \\varepsilon_2 + o(1)", block: false)#text(";")]

#text("in fact we have the more precise relationship")

#align(center)[#tao-math("\\left\\|x_1\\right\\|_{l^1({\\Bbb Z})} +  \\left\\|x_2\\right\\|_{l^1({\\Bbb Z})} + \\lim_{n \\to \\infty} \\left\\|w^{(n)}_2\\right\\|_{l^1({\\Bbb Z})} = 1", block: false)#text(".")]

#text("One can continue in this vein, extracting more and more travelling profiles ")#mi("T^{h^{(n)}_j} x_j")#text(" on finer and finer subsequences, with residuals ")#mi("w^{(n)}_j")#text(" that are getting smaller and smaller. The subsequences involved depend on j, but by the usual Cantor (or ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli")]#text(") ")#link("http://en.wikipedia.org/wiki/Cantor%27s_diagonal_argument")[#text("diagonalisation argument")]#text(", one can work with a single sequence throughout. Note that the amounts of mass ")#mi("\\varepsilon_j")#text(" that are extracted in this process cannot exceed 1 in total: ")#mi("\\sum_j \\varepsilon_j \\leq 1")#text(" (in fact we have the slightly stronger statement (2)). In particular, the ")#mi("\\varepsilon_j")#text(" must go to zero as ")#mi("j \\to \\infty")#text(" (the ")#link("https://terrytao.wordpress.com/2007/05/23/soft-analysis-hard-analysis-and-the-finite-convergence-principle/")[#text("infinite convergence principle")]#text("!). If the ")#mi("\\varepsilon_j")#text(" were selected in a “")#link("http://en.wikipedia.org/wiki/Greedy_algorithm")[#text("greedy")]#text("” manner, this shows that the asymptotic ")#mi("l^\\infty({\\Bbb Z})")#text(" norm of the residuals ")#mi("w^{(n)}_j")#text(" as ")#mi("n \\to \\infty")#text(" must decay to zero as ")#mi("j \\to \\infty")#text(". Carefully rearranging the epsilons, this gives the decomposition (3) with residual ")#mi("w^{(n)}")#text(" converging to zero in the intermediate topology, and the verification of the rest of the theorem is routine.")

#strong[#text("Remark 3.")]#text(" It is tempting to view Theorem 2 as asserting that the space E with the ")#mi("l^\\infty({\\Bbb Z})")#text(" can be “compactified” by throwing in some idealised superposition of profiles that are “infinitely far apart” from each other. ")#mi("\\diamond")

#heading(level: 1)[#text("— An application of concentration compactness —")]

#text("As mentioned in the introduction, one can use the profile decomposition of Theorem 2 as a substitute for compactness in establishing results analogous to Theorem 1. The catch is that one needs more hypotheses on the functional F in order to be able to handle the complicated profiles that come up. It is difficult to formalise the “best” set of hypotheses that would cover all conceivable situations; it seems better to just adapt the general arguments to each individual situation separately. Here is a typical (but certainly not optimal) result of this type:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Theorem 3. Let X, E be as above. Let ")#mi("F: X \\to {\\Bbb R}^+")#text(" be a non-negative function with the following properties:")

#enum(start: 1, 
[#text("(Continuity) F is continuous in the intermediate topology on E.")],
[#text("(Homogeneity) F is homogeneous of some degree ")#mi("1 < p < \\infty")#text(", thus ")#mi("F(\\lambda x) = \\lambda^p F(x)")#text(" for all ")#mi("\\lambda > 0")#text(" and ")#mi("x \\in X")#text(". (In particular, F(0)=0.)")],
[#text("(Invariance) F is G-invariant: ")#mi("F(T^h x) = F(x)")#text(" for all ")#mi("h \\in {\\Bbb Z}")#text(" and ")#mi("x \\in X")#text(".")],
[#text("(Asymptotic additivity) If ")#mi("h^{(n)}_j")#text(" are a collection of sequences obeying the asymptotic orthogonality condition (1), and ")#mi("x_j \\in X")#text(" are such that ")#tao-math("\\sum_j \\left\\|x_j\\right\\|_{l^1({\\Bbb Z})} < \\infty", block: false)#text(", then ")#mi("\\sum_j F(x_j) < \\infty")#text(" and ")#mi("F( \\sum_j T^{h^{(n)}_j} x_j ) = \\sum_j F(x_j) + o(1)")#text(". More generally, if ")#mi("w^{(n)}")#text(" is bounded in ")#mi("l^1")#text(" and converges to zero in the intermediate topology, then ")#mi("F( \\sum_j T^{h^{(n)}_j} x_j + w^{(n)} ) = \\sum_j F(x_j) + o(1)")#text(". (Note that this generalises both 1. and 3.)")]
)

#text("Then F is bounded on E, and attains its supremum.")
]

#text("A typical example of a functional F obeying the above properties is")

#align(center)[#tao-fit-display[#tao-math("F( (x_m)_{m \\in {\\Bbb Z}} ) := \\sum_{m \\in {\\Bbb Z}} \\left|x_m - x_{m+1}\\right|^p", block: true)]]

#text("for some ")#mi("1 < p < \\infty")#text(".")

#strong[#text("Proof.")]#text(" We repeat the proof of Theorem 1. Let ")#mi("L := \\sup_{x \\in E} F(x)")#text(". Clearly ")#mi("L \\geq 0")#text("; we can assume that ")#mi("L>0")#text(", since the claim is trivial when ")#mi("L=0")#text(". As before, we have an extremising sequence ")#mi("x^{(n)} \\in E")#text(" with ")#mi("F(x^{(n)}) \\to L")#text(". Applying Theorem 2, and passing to a subsequence, we obtain a decomposition (3) with the stated properties. Applying the asymptotic additivity hypothesis 4., we have")

#align(center)[#tao-fit-display[#mitex("F(x^{(n)}) = \\sum_j F( x_j ) + o(1)")]]

#text("and in particular")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("L = \\sum_j F(x_j).")]]

#text("This implies in particular that L is finite.")

#text("Now, we use the homogeneity assumption. Since ")#mi("F(x) \\leq L")#text(" when ")#tao-math("\\left\\|x\\right\\|_{l^1({\\Bbb Z})} = 1", block: false)#text(", we obtain the bound ")#tao-math("F(x) \\leq L \\left\\|x\\right\\|_{l^1({\\Bbb Z})}^p", block: false)#text(". We conclude that")

#align(center)[#tao-fit-display[#tao-math("L \\leq L \\sum_j \\left\\|x_j\\right\\|_{l^1({\\Bbb Z})}^p", block: true)]]

#text("Combining this with (1) we obtain")

#align(center)[#tao-math("L \\leq \\sum_j L \\left\\|x_j\\right\\|_{l^1({\\Bbb Z})}^p \\leq L \\sum_j \\left\\|x_j\\right\\|_{l^1({\\Bbb Z})} \\leq L", block: false)#text(".")]

#text("Thus all these inequalities must be equality. Analysing this, we see that all but one of the ")#mi("x_j")#text(" must vanish, with the remaining ")#mi("x_j")#text(" (say ")#mi("x_0")#text(") having norm 1. From (4) we thus have ")#mi("F(x_0)=L")#text(", and we have obtained the desired extremiser.")

#text("[")#emph[#text("Update")]#text(", Nov 6: some corrections, in particular with regard to the closure of E in the intermediate topology.]")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jerry Gagelman")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33417")[#strong[#text("Jerry Gagelman")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2008")])]

#text("Dear Terry,")

#text("In keeping with the standards you’ve established on this blog, another excellent post! I’ve noticed one minor correction: in Example 1, I think you meant to say that ")#mi("e_n")#text(" does not converge in the strong or _intermediate_ topologies. However the reason for my comment is the following question. In introducing travelling profiles in the sphere ")#mi("E")#text(" in ")#mi("\\ell^1")#text(", you said that it “is the action of the (non-compact) group ")#mi("G")#text(" causing the failure of compatness of ")#mi("E")#text(" in the strong and weak topologies,” which which would imply that ")#mi("G")#text(" has its own topology. Could you please expand on this briefly? E.g., is there a topology on ")#mi("G")#text(" for which the action ")#mi("G\\times \\ell^1 \\to \\ell^1")#text(" is continuous in the three topologies on ")#mi("\\ell^1")#text("?")

#text("Thanks!")#linebreak()#text(" Jerry")

#text("PS. I’ve also noticed that some formulas in the statment of Theorem 3 are not displayed correctly, but this could just be my browser.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JC")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33423")[#strong[#text("JC")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2008")])]

#text("I’ve also noticed a few typos: the word “thisbv” and “howe”, and there is a non-latexed formula in the paragraph beginning with “Now we take”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A.P.")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33424")[#strong[#text("A.P.")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2008")])]

#text("Professor Tao")

#text("I can’t give up the impression, that the statement, that unite sphere E is closed in intermediate topology is false.")#linebreak()#text(" Of course I cannot exclude (and it is actually quite probable), that I make some obvious mistake and something blinds me.")

#text("Here is a sequence that concerns me:")

#text("Let x(i) be a sequence:")#linebreak()#text(" x(i)(0) = (1/2) + (1/2)^i")#linebreak()#text(" x(i)(j) = ((1/2) – (1/2)^i)(1/2)^i for j = 1 to (2^i)")#linebreak()#text(" x(i)(j) = 0 for j > (2^i) and for j 0 x(i) belongs to E, but")#linebreak()#text(" x(i) converges to …,0, 0, 1/2, 0, 0, … in intermediate (uniform) topology.")

#text("Regards.")#linebreak()#text(" P.S. Great blog. One of the best in known universe.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33425")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2008")])]

#text("Thanks for the corrections! It is true that E is not closed in the intermediate topology; I have adjusted the discussion to reflect this.")

#text("The group G (i.e. the integers) is given the discrete topology; the non-compactness of G is in that case equivalent to the non-finiteness of G. In the situations that occur in actual applications, G is typically something like a translation group (equivalent to ")#mi("{\\Bbb R}^n")#text("), a dilation group (equivalent to ")#mi("{\\Bbb R}^+")#text("), an affine group (e.g. ")#mi("{\\Bbb R}^n \\rtimes {\\Bbb R}^+")#text("), etc., and again it is the non-compactness which causes all the trouble. (Actions of compact groups such as a rotation group O(n) do not need to be accounted for by a profile decomposition.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682fe0c13dfc3de5485dc046bf722b1bb8c3ae01e0134385c90ba77078682449-84cb11ee52d86adeb2741c0e3fcc426404df6885e7eb186e856d7c066d84adbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dylan Thurston")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33426")[#strong[#text("Dylan Thurston")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2008")])]

#text("The whole discussion reminds me of the treatment of pseudo-holomorphic curves in symplectic manifolds with cylindrical ends. There, the standard approach is to go in the direction suggested by your Remark 3: to enlarge the space to make everything honestly compact. In order to make it work, you of course need to take the quotient by the action of the group for the limiting objects, which in this case would mean you no longer have a vector space. In this and similar contexts, trying to deduce what the limits might be to prove a form of concentration compactness seems like it would be harder, as the limits can be fairly complicated.")

#text("(This is called Gromov compactness, and one standard reference is ")#link("http://www.msp.warwick.ac.uk/gt/2003/07/p025.xhtml")[#text("Bourgeoi-Eliashberg-Hofer-Wysocki-Zehnder")]#text(".)")

#text("By the way, in condition (2) you probably want to assume ")#mi("j < j^{\\prime}")#text(" rather than ")#mi("j \\ne j^{\\prime}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33445")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2008")])]

#text("I am confused by the statement “Now we take advantage of sequential compactness in the weak topology”. Is the point that, even though the unit sphere is neither closed nor compact in the weak topology, the unit ball is both?")

#text("Otherwise, a very interesting result! If I were to follow up on Dylan’s analogy, and think like an algebraic geometer, I would want to compactify E to have some extra points that correspond to the limits of these infinite sequences. My first thought is to mimic the Stone-Cech compactification but, rather than using all continuous functions from ")#mi("E \\to [0,1]")#text(", use only those satisfying the hypothesis of Theorem 3. Is there any use in this?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33452")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2008")])]

#text("Dear Dylan and David: Thanks for the corrections and comments! There certainly are close relationships between concentration compactness and, say, bubble tree decompositions, which come up in the analysis of various types of geometric singularities (or other sources of non-compactness); this comes up in harmonic maps and minimal surfaces already, so it makes sense that it would be relevant for pseudoholomorphic curves also.")

#text("It sounds plausible that some abstract procedure should be able to compactify E in such a way that concentration compactness can be interpreted as a special case of classical compactness; I would find this reassuring, though it would be more of a psychological advance than a technical one I think (unless it allows one to easily transfer a large number of additional theorems about compact sets, beyond the existence of extremisers, to the concentration-compact setting), and of course it would be nice to have a reasonably “concrete” description of the compactification (one should be adding things like formal superpositions of profiles that have been translated to be “infinitely far apart”). I played around a little with the semigroup structure of the Stone-Cech compactification ")#mi("\\beta {\\Bbb Z}")#text(" of the underlying group ")#mi("{\\Bbb Z}")#text(" for a while but wasn’t able to get a clean and satisfactory compactification of E out of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33453")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2008")])]

#text("Dear Prof. Tao,")

#text("I have a more or less complex question that may be related: as you have mentioned at the beginning of this post, the method of concentration compactness has been used in the context of dispersive PDE’s in order to exhibit solutions with a certain blow-up profile. This procedure can even be microlocalised, as shown by L. Tartar and P. Gerard, and fits well with the method of second microlocalisation, used to study the formation of caustics due to nonlinear concentration phenomena.")

#text("A curious feature of this method is that it seems to allow one to study oscillatory solutions beyond the formation of focal points and/or caustics. These are the main cause of failure of decay and Strichartz estimates for the linear wave equation with variable coefficients / curved spacetimes (as extensively discussed in recent works by Tataru, his collaborators, and many others). – after all, that’s how lensing works for _physical_ optics! On the physical side, we know from playing around with lenses and paper that the concentration is strongest when the caustic is a single, isolated point (only then can we burn the paper!), and it gets weaker and weaker as one moves away from the unfolding points of more complicated caustics. The “single point caustic” is, however, “structurally unstable”, since it gets lost when we move the lens by the slightest bit, unlike the more complicated one. Mathematically, such a procedure corresponds to perturbing the principal symbol. In curved spacetimes, isolated caustic points due to trapped geodesics (e.g. the photosphere in Schwarzschild spacetime, or the (whole) Einstein static universe) can completely kill any decay / Strichartz estimates if they occur in a more or less uniform fashion throughout spacetime, but also seem to be structurally unstable in the sense above. This leads to the following two questions:")

#text("1.) Could it be that, even for the _linear, variable-coefficient_ wave equation, one could find “intermediate” decay /Strichartz norms such that one could establish a “profile decomposition” that describes this weaker dispersion along structurally stable caustics, at least for a given normal form in Arnold’s classification?")

#text("2.) By assembling these profiles together for all normal forms, could we perhaps establish a “robust” version of decay / Strichartz estimates w.r.t. perturbations of the metric symbol that could be used for variable coefficient wave equations?")

#text("Many thanks in advance.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reader")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33463")[#strong[#text("reader")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2008")])]

#text("Dear Prof.Tao,")

#text("i wonder is this idea of profile decomposition related to fourier linear bias?")#linebreak()#text(" if so, could you say something more about it. thanks")

#text("reader")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-33477")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2008")])]

#text("Dear reader,")

#text("Well, there is a broad theme in several areas of analysis that an inverse theorem (that asserts the largeness of some norm or norm-like quantity implies the presence of a specific structure) implies a structure theorem (that asserts that arbitrary objects can be decomposed into a superposition of specific structures, plus an error of small norm). In the case of the concentration compactness result above, the inverse theorem is quite trivial: a function with large ")#mi("l^\\infty")#text(" norm contains a large component concentrated at a point. But one could similarly start with, say, the inverse theorem that says that a function with large Gowers norm ")#mi("U^2")#text(" correlates with a Fourier character, and obtain an analogous concentration compactness result that would assert that a sequence of bounded (in ")#mi("l^2")#text(") functions could be resolved into a superposition of frequency modulated profiles, plus an error with small ")#mi("U^2")#text(" norm; this is close to certain “arithmetic regularity lemmas” that are already used in the additive combinatorics literature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245B, notes 3: L^p spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-34834")[#strong[#text("245B, notes 3: L^p spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2009")])]

#text("[…] Metric structure. We also want to tell whether two functions f, g in a function space V are “near together” or “far apart”. A typical way to do this is to impose a metric on the space . If both a norm and a vector space structure are available, there is an obvious way to do this: define the distance between two functions in to be . (This will be the only type of metric on function spaces encountered in this course. But there are some nonlinear function spaces of importance in nonlinear analysis (e.g. spaces of maps from one manifold to another) which have no vector space structure or norm, but still have a metric.) It is often important to know if the vector space is complete with respect to the given metric; this allows one to take limits of Cauchy sequences, and (with a norm and vector space structure) sum absolutely convergent series, as well as use some useful results from point set topology such as the Baire category theorem. All of these operations are of course vital in analysis. [Compactness would be an even better property than completeness to have, but function spaces unfortunately tend be non-compact in various rather nasty ways, although there are useful partial substitutes for compactness that are available, see e.g. this blog post of mine.] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the bilinear L^2 Strichartz estimate for the wave equation « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-38309")[#strong[#text("An inverse theorem for the bilinear L^2 Strichartz estimate for the wave equation « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("[…] closely related to the theory of concentration compactness and profile decompositions; see this previous blog post of mine for a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Concentration compactness via nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-48327")[#strong[#text("Concentration compactness via nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("[…] property in infinite-dimensional spaces. One of these tools is concentration compactness, which was discussed previously on this blog. This can be viewed as a compromise between weak compactness (which is true in very general […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-63754")[#strong[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2011")])]

#text("[…] translation symmetry that is available for the space . (Concentration compactness is discussed in these previous blog posts.) One then has to deal with sequences of data that are not strongly convergent, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-155164")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2012")])]

#text("It appears that the link to “concentration compactness” that points to tosio.toronto… is broken. Does it point to the old dispersive wiki? the correct link probably should be wiki.math.toronto…")

#emph[#text("[Updated, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-213680")[#strong[#text("Compactness in analysis | Shrinklemma")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2013")]

#text("[…] Terence Tao talked about a toy model of concentrated compactness in one of his blogs. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/437582f5fcc47c60e8443dd7e43e82007954e55065d9ca0274c8ed6770b8a47c-ab8e61d1ee7b7041f95b5d1a6a21f59612ca92156bb4e39f550c703e6be452f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Debajyoti Choudhuri")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-507015")[#strong[#text("Debajyoti Choudhuri")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2018")])]

#text("” Analysing this, we see that all but one of the x_j must vanish, with the remaining x_j (say x_0) having norm 1″…this comment is to the end of the article. I was wondering as to why this should happen?. I presume there could several other x_j, the sum of whose norm yields 1. Can you please clear this doubt?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/11/05/concentration-compactness-and-the-profile-decomposition/#comment-507474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("If there are some ")#mi("x_j")#text(" of norm strictly between 0 and 1, then ")#tao-math("\\left\\|x_j\\right\\|_{\\ell^1}^p", block: false)#text(" would be strictly less than ")#tao-math("\\left\\|x_j\\right\\|_{\\ell^1}", block: false)#text(", and the above string of inequalities would give ")#mi("L < L")#text(", which is absurd.")
]
]
