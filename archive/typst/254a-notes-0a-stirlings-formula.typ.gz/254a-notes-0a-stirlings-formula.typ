// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/
// Converted to Typst by tao2typ: "2026-10-14T16:36:00.436681+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 0a: Stirling’s formula", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 0a: Stirling’s formula")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In this supplemental set of notes we derive some approximations for ")#mi("{n!}")#text(", when ")#mi("{n}")#text(" is large, and in particular ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(". This formula (and related formulae for binomial coefficients ")#mi("{\\binom{n}{m}}")#text(" will be useful for estimating a number of combinatorial quantities in this course, and also in allowing one to analyse discrete random walks accurately.")

#metadata(none) <tao-25c7a5ee8e6f016ec751>

#text("From Taylor expansion we have ")#mi("{x^n/n! \\leq e^x}")#text(" for any ")#mi("{x \\geq 0}")#text(". Specialising this to ")#mi("{x=n}")#text(" we obtain a crude lower bound ")#metadata(none) <tao-fbf226fc0ad3a3b0c370>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("n! \\geq n^n e^{-n}.")]]



#text(" In the other direction, we trivially have ")#metadata(none) <tao-e26bf4e241e31d2eba60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("n! \\leq n^n")]]



#text(" so we know already that ")#mi("{n!}")#text(" is within an exponential factor of ")#mi("{n^n}")#text(". (One can obtain a cruder version of this fact without Taylor expansion, by observing the trivial lower bound ")#mi("{n! \\geq (n/2)^{\\lfloor n/2\\rfloor}}")#text(" coming from considering the second half of the product ")#mi("{n! = 1 \\cdot \\ldots \\cdot n}")#text(".)")

#text("One can do better by starting with the identity")

#align(center)[#tao-fit-display[#mitex("\\log n! = \\sum_{m=1}^n \\log m")]]

#text("and viewing the right-hand side as a Riemann integral approximation to ")#mi("{\\int_1^n \\log x\\ dx}")#text(". Indeed a simple area comparison (cf. the ")#link("http://en.wikipedia.org/wiki/Integral_test_for_convergence")[#text("integral test")]#text(") yields the inequalities")

#align(center)[#tao-fit-display[#mitex("\\int_1^n \\log x\\ dx \\leq \\sum_{m=1}^n \\log m \\leq \\log n + \\int_1^n \\log x\\ dx")]]

#text("which leads to the inequalities ")#metadata(none) <tao-1d07fbbddbc10447c032>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("e n^n e^{-n} \\leq n! \\leq e n \\times n^n e^{-n}")]]



#text(" so the lower bound in ")#link(<tao-fbf226fc0ad3a3b0c370>)[#text("(1)")]#text(" was only off by a factor of ")#mi("{n}")#text(" or so. (This illustrates a general principle, namely that one can often get a non-terrible bound for a series (in this case, the Taylor series for ")#mi("{e^n}")#text(") by using the largest term in that series (which is ")#mi("{n^n/n!}")#text(").)")

#text("One can do better by using the ")#link("http://en.wikipedia.org/wiki/Trapezium_rule")[#text("trapezoid rule")]#text(". On any interval ")#mi("{[m,m+1]}")#text(", ")#mi("{\\log x}")#text(" has a second derivative of ")#mi("{O( 1 / m^2 )}")#text(", which by Taylor expansion leads to the approximation")

#align(center)[#tao-fit-display[#mitex("\\int_m^{m+1} \\log x\\ dx = \\frac{1}{2} \\log m + \\frac{1}{2} \\log(m+1) + \\epsilon_m")]]

#text("for some error ")#mi("{\\epsilon_m = O( 1/m^2 )}")#text(".")

#text("The error is absolutely convergent; by the integral test, we have ")#mi("{\\sum_{m=1}^n \\epsilon_m = C + O(1/n)}")#text(" for some absolute constant ")#mi("{C := \\sum_{m=1}^\\infty \\epsilon_m}")#text(". Performing this sum, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_1^n \\log x\\ dx = \\sum_{m=1}^{n-1} \\log m + \\frac{1}{2} \\log n + C + O(1/n)")]]

#text("which after some rearranging leads to the asymptotic ")#metadata(none) <tao-557cde45b25e35bc91ad>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("n! = (1 + O(1/n)) e^{1-C} \\sqrt{n} n^n e^{-n}")]]



#text(" so we see that ")#mi("{n!}")#text(" actually lies roughly at the geometric mean of the two bounds in ")#link(<tao-1d07fbbddbc10447c032>)[#text("(3)")]#text(".")

#text("This argument does not easily reveal what the constant ")#mi("{C}")#text(" actually is (though it can in principle be computed numerically to any specified level of accuracy by this method). To find this out, we take a different tack, interpreting the factorial via the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(". Repeated integration by parts reveals the identity ")#metadata(none) <tao-86475f5e72acb469f359>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("n! = \\int_0^\\infty t^n e^{-t}\\ dt.")]]



#text(" So to estimate ")#mi("{n!}")#text(", it suffices to estimate the integral in ")#link(<tao-86475f5e72acb469f359>)[#text("(5)")]#text(". Elementary calculus reveals that the integrand ")#mi("{t^n e^{-t}}")#text(" achieves its maximum at ")#mi("{t=n}")#text(", so it is natural to make the substitution ")#mi("{t = n+s}")#text(", obtaining")

#align(center)[#tao-fit-display[#mitex("n! = \\int_{-n}^\\infty (n+s)^n e^{-n-s}\\ ds")]]

#text("which we can simplify a little bit as")

#align(center)[#tao-fit-display[#mitex("n! = n^n e^{-n} \\int_{-n}^\\infty (1+\\frac{s}{n})^n e^{-s}\\ ds,")]]

#text("pulling out the now-familiar factors of ")#mi("{n^n e^{-n}}")#text(". We combine the integrand into a single exponential,")

#align(center)[#tao-fit-display[#mitex("n! = n^n e^{-n} \\int_{-n}^\\infty \\exp( n \\log(1+\\frac{s}{n}) - s )\\ ds.")]]

#text("From Taylor expansion we see that")

#align(center)[#tao-fit-display[#mitex("n \\log(1+\\frac{s}{n}) = s - \\frac{s^2}{2n} + \\ldots")]]

#text("so we heuristically have")

#align(center)[#tao-fit-display[#mitex("\\exp( n \\log(1+\\frac{s}{n}) - s ) \\approx \\exp( -s^2 / 2n ).")]]

#text("To achieve this approximation rigorously, we first scale ")#mi("{s}")#text(" by ")#mi("{\\sqrt{n}}")#text(" to remove the ")#mi("{n}")#text(" in the denominator. Making the substitution ")#mi("{s = \\sqrt{n} x}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("n! = \\sqrt{n} n^n e^{-n} \\int_{-\\sqrt{n}}^\\infty \\exp( n \\log(1 + \\frac{x}{\\sqrt{n}}) - \\sqrt{n} x)\\ dx,")]]

#text("thus extracting the factor of ")#mi("{\\sqrt{n}}")#text(" that we know from ")#link(<tao-557cde45b25e35bc91ad>)[#text("(4)")]#text(" has to be there.")

#text("Now, Taylor expansion tells us that for fixed ")#mi("{x}")#text(", we have the pointwise convergence ")#metadata(none) <tao-251fecd592e56e6c4a95>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\exp( n \\log(1 + \\frac{x}{\\sqrt{n}}) - \\sqrt{n} x) \\rightarrow \\exp( -x^2 / 2 )")]]



#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". To be more precise, as the function ")#mi("{n \\log(1 + \\frac{x}{\\sqrt{n}})}")#text(" equals ")#mi("{0}")#text(" with derivative ")#mi("{\\sqrt{n}}")#text(" at the origin, and has second derivative ")#mi("{\\frac{-1}{(1+x/\\sqrt{n})^2}}")#text(", we see from two applications of the fundamental theorem of calculus that")

#align(center)[#tao-fit-display[#mitex("n \\log(1 + \\frac{x}{\\sqrt{n}}) - \\sqrt{n} x = -\\int_0^x \\frac{(x-y) dy}{(1+y/\\sqrt{n})^2}.")]]

#text("This gives a uniform upper bound")

#align(center)[#tao-fit-display[#mitex("n \\log(1 + \\frac{x}{\\sqrt{n}}) - \\sqrt{n} x \\leq - c x^2")]]

#text("for some ")#mi("{c > 0}")#text(" when ")#tao-math("{\\left|x\\right| \\leq \\sqrt{n}}", block: false)#text(", and")

#align(center)[#tao-fit-display[#mitex("n \\log(1 + \\frac{x}{\\sqrt{n}}) - \\sqrt{n} x \\leq - c |x| \\sqrt{n}")]]

#text("for ")#mi("{x > \\sqrt{n}}")#text(". This is enough to keep the integrands ")#mi("{\\exp( n \\log(1 + \\frac{x}{\\sqrt{n}}) - \\sqrt{n} x)}")#text(" dominated by an absolutely integrable function. By ")#link(<tao-251fecd592e56e6c4a95>)[#text("(6)")]#text(" and the Lebesgue dominated convergence theorem, we thus have")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\sqrt{n}}^\\infty \\exp( n \\log(1 + \\frac{x}{\\sqrt{n}}) - \\sqrt{n} x)\\ dx \\rightarrow \\int_{-\\infty}^\\infty \\exp(-x^2/2)\\ dx.")]]

#text("A classical computation (based for instance on computing ")#mi("{\\int_{-\\infty}^\\infty \\int_{-\\infty}^\\infty \\exp(-(x^2+y^2)/2)\\ dx dy}")#text(" in both Cartesian and polar coordinates) shows that")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\infty}^\\infty \\exp(-x^2/2)\\ dx = \\sqrt{2\\pi}")]]

#text("and so we conclude ")#link("http://en.wikipedia.org/wiki/Stirling%27s_approximation")[#text("Stirling’s formula")]#text(" ")#metadata(none) <tao-4011393f356a69582a25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("n! = (1+o(1)) \\sqrt{2\\pi n} n^n e^{-n}.")]]





#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The dominated convergence theorem does not immediately give any effective rate on the decay ")#mi("{o(1)}")#text(" (though such a rate can eventually be extracted by a quantitative version of the above argument. But one can combine ")#link(<tao-4011393f356a69582a25>)[#text("(7)")]#text(" with ")#link(<tao-557cde45b25e35bc91ad>)[#text("(4)")]#text(" to show that the error rate is of the form ")#mi("{O(1/n)}")#text(". By using fancier versions of the trapezoid rule (e.g. ")#link("http://en.wikipedia.org/wiki/Simpson%27s_rule")[#text("Simpson’s rule")]#text(") one can obtain an asymptotic expansion of the error term in ")#mi("{1/n}")#text(", but we will not need such an expansion in this course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The derivation of ")#link(<tao-4011393f356a69582a25>)[#text("(7)")]#text(" demonstrates some general principles concerning the estimation of exponential integrals ")#mi("{\\int e^{\\phi(x)}\\ dx}")#text(" when ")#mi("{\\phi}")#text(" is large. Firstly, the integral is dominated by the local maxima of ")#mi("{\\phi}")#text(". Then, near these maxima, ")#mi("{e^{\\phi(x)}}")#text(" usually behaves like a rescaled Gaussian, as can be seen by Taylor expansion (though more complicated behaviour emerges if the second derivative of ")#mi("{\\phi}")#text(" degenerates). So one can often understand the asymptotics of such integrals by a change of variables designed to reveal the Gaussian behaviour. A similar set of principles also holds for oscillatory exponential integrals ")#mi("{\\int e^{i \\phi(x)}\\ dx}")#text("; these principles are collectively referred to as the ")#link("http://www.tricki.org/article/How_to_use_the_method_of_stationary_phase_to_control_oscillatory_integrals")[#text("method of stationary phase")]#text(".")
]

#text("One can use Stirling’s formula to estimate binomial coefficients. Here is a crude bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Entropy formula)")]#text(" Let ")#mi("{n}")#text(" be large, let ")#mi("{0 < \\gamma < 1}")#text(" be fixed, and let ")#mi("{1 \\leq m \\leq n}")#text(" be an integer of the form ")#mi("{m = (\\gamma+o(1)) n}")#text(". Show that ")#mi("{\\binom{n}{m} = \\exp( (h(\\gamma)+o(1)) n )}")#text(", where ")#mi("{h(\\gamma)}")#text(" is the ")#emph[#text("entropy function")]

#align(center)[#tao-fit-display[#mitex("h(\\gamma) := \\gamma \\log \\frac{1}{\\gamma} + (1-\\gamma) \\log \\frac{1}{1-\\gamma}.")]]
]

#text("For ")#mi("{m}")#text(" near ")#mi("{n/2}")#text(", one also has the following more precise bound:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Refined entropy formula)")]#text(" Let ")#mi("{n}")#text(" be large, and let ")#mi("{1 \\leq m \\leq n}")#text(" be an integer of the form ")#mi("{m = n/2 + k}")#text(" for some ")#mi("{k = o(n^{2/3})}")#text(". Show that ")#metadata(none) <tao-2f588afe14a613cb4499>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\binom{n}{m} = (\\sqrt{\\frac{2}{\\pi}} + o(1)) \\frac{2^n}{\\sqrt{n}} \\exp( - 2k^2/n ).")]]




]

#text("Note the gaussian-type behaviour in ")#mi("{k}")#text(". This can be viewed as an illustration of the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(" when summing iid Bernoulli variables ")#mi("{X_1,\\ldots,X_n \\in \\{0,1\\}}")#text(", where each ")#mi("{X_i}")#text(" has a ")#mi("{1/2}")#text(" probability of being either ")#mi("{0}")#text(" or ")#mi("{1}")#text(". Indeed, from ")#link(<tao-2f588afe14a613cb4499>)[#text("(8)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( X_1 +\\ldots + X_n = n/2 + k ) = (\\sqrt{\\frac{2}{\\pi}} + o(1)) \\frac{1}{\\sqrt{n}} \\exp( - 2k^2/n )")]]

#text("when ")#mi("{k = o(n^{2/3})}")#text(", which suggests that ")#mi("{X_1+\\ldots+X_n}")#text(" is distributed roughly like the gaussian ")#mi("{N( n/2, n/4 )}")#text(" with mean ")#mi("{n/2}")#text(" and variance ")#mi("{n/4}")#text(".")

#emph[#text("Update")]#text(", Jan 4: Rafe Mazzeo pointed me to this short ")#link("http://arxiv.org/abs/0711.4412")[#text("article of Joe Keller")]#text(" that gives a heuristic derivation of the full asymptotic expansion of Stirling’s formula from a Taylor expansion of the Gamma function.")

#heading(level: 1)[#text("Comments (56)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/46e7008492515e1b8ce15fdf9a6c0106597b3c68dde82725cb43e7dfaccb7d1f-3475ed09a7c092266c5dee64156b203e5ecb0cb0a30ed535463770c497429ab0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Li Jing")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43058")[#strong[#text("Li Jing")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("hi, good lecture notes. There is one typo: “so we heuristically have.. ” the formula on right hand side, you miss one negative sign.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b88d70dc194adf72f057699180f305b5075fdcc17a3847207ae2f1d091549372-21fb19c3ee7a87393199500520e1bbca17fa45453e93fa79b406b21ad7f74989.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Georges Elencwajg")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43059")[#strong[#text("Georges Elencwajg")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("Dear Terry,")#linebreak()#text(" this post of yours makes me wonder why the hundreds of books on calculus I have browsed in my life never even came close to your remark at the beginning “so we know already that n! is within an exponential factor of n^n”.")#linebreak()#text(" There is obviously something flawed in the realm of pedagogy if it takes a mathematician of your caliber to make such childish remarks.")#linebreak()#text(" I am using the word “childish” deliberately, because of the the child in Hans Christian Andersen’s tale who exclaims that the emperor has no clothes.")#linebreak()#text(" There is also the well-known Newton quotation")#linebreak()#text(" “I was like a boy playing on the sea-shore, and diverting myself now and then finding a smoother pebble or a prettier shell than ordinary, whilst the great ocean of truth lay all undiscovered before me”.")#linebreak()#text(" And Grothendieck likes to compare himself to a child in his autobiography “Récoltes et Semailles”.")#linebreak()#text(" It might seem strange to compare you to Grothendieck, who in a sense is completely antipodal to you ( I’m not sure he knows Sterling’s formula!), but your obvious common love of simplicity and hatred of showing-off might reveal some conceptual similarity, appearances to the contrary notwithstanding.")

#text("But enough ot this fuzzy philosophizing: it is high time to thank you heartily for this magnificent note : finally Sterling’s formula is not more mysterious, when explained by you , than the hypercohomology of the De Rham complex on a scheme…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/079cb57937093f8327931689e37fbb2200cfc232528e21aa0977888321d71bc7-f2117a98624bb427e54718daad39bba5d3b2ff5987d9b7ab60f6a074ea3be262.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manjil P. Saikia")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43119")[#strong[#text("Manjil P. Saikia")]]#text(size: 9pt, fill: rgb("596477"), " · 7 January 2010")])]

#text("Greatness lies in knowing its boundaries and genius is just that boundary, I guess. It takes the genius and greatness of Prof. Tao to write such nice and illuminating pots.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Concentration of measure « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43068")[#strong[#text("254A, Notes 1: Concentration of measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("[…] after using a crude form of Stirling’s formula […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43091")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("[…] after using a crude form of Stirling’s formula […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43110")[#strong[#text("254A, Notes 2: The central limit theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2010")])]

#text("[…] by those with . Now make this intuition precise.) Exercise 2 Use Stirling’s formula from Notes 0a to verify the central limit theorem in the case when is a Bernoulli distribution, taking the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: The operator norm of a random matrix « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43153")[#strong[#text("254A, Notes 3: The operator norm of a random matrix « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2010")])]

#text("[…] that the median (or mean) of is at least . On the other hand, from Stirling’s formula (Notes 0a) we see that converges to as . Taking to be a slowly growing function of , we conclude […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6acc310a3825bb7a1dd9043bc3a1a8f6db8112f4a34f6ed216855694f43647af-b50015710b481ad0b199e75dce4be03b34433a91aa63f227f48bc12c72f4a36c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Cook")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43180")[#strong[#text("Nathan Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2010")])]

#text("I think that in (3) both of the derived bounds are too small by a factor of e. Certainly the upper bound doesn’t hold, for instance if n=2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43318")[#strong[#text("Задача 565. Решение « Le blog de Nicky")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")]

#text("[…] P.S. Было вычитано у Теренса Тао. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("Dear Prof. Tao,")

#text("How do you get (3) from the inequalities just above it? I could not figure it out")

#text("thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43855")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("Compute the antiderivative of ")#mi("\\log x")#text(", use the fundamental theorem of calculus, then exponentiate all sides of the equation preceding (3).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43856")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2010")])]

#text("I see it now. Thank you. It is really a great post.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weiyu")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-43893")[#strong[#text("Weiyu")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("In the equation before “A classical computation (based for instance on computing”, maybe a “dx” is missing.")

#emph[#text("[Corrected, thanks. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Lessa")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-44139")[#strong[#text("Pablo Lessa")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2010")])]

#text("Hi everyone,")

#text("I kept wondering about the appearance of entropy in the “entropy formula” (exercise 1), and I found the following probabilistic “almost proof” which I decided to share here (I’m hoping this is considered appropriate, if not I apologize). Does anybody know other interesting explanations as to why entropy occurs in the formula?")

#text("Take ")#mi("X_1,\\ldots, X_n,\\ldots")#text(" independent random variables with ")#mi("P(X_n = 1) = \\gamma, P(X_n = 0) = 1-\\gamma")#text(". Define ")#mi("S_n = X_1 + \\cdots + X_n")#text(" and let ")#mi("p(n,k) = P(S_n = k) = \\gamma^k(1-\\gamma)^{n-k}\\left(\\begin{array}{c}n\\\\k\\end{array}\\right)")#text(" for each ")#mi("n,k")#text(".")

#text("Since ")#mi("S_n")#text(" takes only ")#mi("n")#text(" values it’s entropy is less than ")#mi("\\log(n)")#text(". From this one deduces (exchanging limit with expected value) that almost surely ")#mi("\\frac{1}{n}\\log\\left(\\frac{1}{p(n,S_n)}\\right)")#text(" goes to zero. Substituting the expresion for this and using the law of large numbers one obtains that almost surely:")

#mi("\\frac{1}{n}\\log\\left(\\begin{array}{c}n\\\\S_n\\end{array}\\right) = h(\\gamma) + o(1)")

#text("Which is to say that there are a bunch of sequences ")#mi("S_n = \\gamma n + o(1)")#text(" that satisfy the entropy formula (but sadly, it doesn’t show that they all do).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of t8m8r")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-44405")[#strong[#text("t8m8r")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2010")])]

#text("In the second paragraph, a formula appears to be missing after “we obtain a crude lower bound”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-45759")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2010")])]

#text("Dear Prof.Tao")#linebreak()#text(" I am puzzled by Exercise2. Can you give me some hints? Why k=o(n2/3)?")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-46655")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("Dear Prof. Tao")#linebreak()#text(" I have a question about Entropy Formula in Exercise 1.")#linebreak()#text(" If N is a integer which satisfied")#linebreak()#text(" ")#mi("N\\leq\\mathrm{C}_n^0+\\mathrm{C}_n^1+\\cdots+\\mathrm{C}_n^{\\lfloor\\rho n\\rfloor}")#linebreak()#text(" where 0<\\rho<1, can we arrive at the conclusion")#linebreak()#text(" ")#mi("lnN\\leq nh(\\rho)(1+o(1))")#linebreak()#text(" by Entropy Formula. If it is right, can you tell me how to get it? Some hints will be OK.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-46661")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("(Assuming ")#mi("C^k_n")#text(" means ")#mi("\\binom{n}{k}")#text(") This formula is only valid for ")#mi("\\rho \\leq 1/2")#text("; for larger values of ")#mi("\\rho")#text(", the partial sum is of size ")#mi("n (\\log 2 + O(1))")#text(".")

#text("To estimate the order of magnitude of a sum of positive terms, one can often just bound the largest term in the sum, and then multiply by the number of terms, for a crude upper bound. In this case, the largest term will be ")#mi("\\binom{n}{\\lfloor \\rho n \\rfloor}")#text(" if ")#mi("\\rho \\leq 1/2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-46674")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2010")])]

#text("Dear Prof.Tao")#linebreak()#text(" Thanks for the quick reply. I see your point. As you said, since")#linebreak()#text(" ")#mi("\\binom{n}{\\lfloor\\rho n\\rfloor}=\\exp(n(h(\\rho)+o(1)))")#text(",")#linebreak()#text(" we can get the crude estimate")#linebreak()#text(" ")#mi("N\\leq\\binom{n}{0}+\\binom{n}{1}+\\cdots+\\binom{n}{\\lfloor\\rho n\\rfloor}\\leq \\lfloor\\rho n\\rfloor\\exp(n(h(\\rho)+o(1)))")#text(",")#linebreak()#text(" when ")#mi("0<\\rho\\leq1/2")#text(",that is,")#linebreak()#text(" ")#mi("\\ln N\\leq n(h(\\rho)+\\frac{\\ln \\lfloor\\rho n\\rfloor}{n}+o(1))")#text(".")#linebreak()#text(" Since ")#mi("\\frac{\\ln \\lfloor\\rho n\\rfloor}{n}+o(1)=o(1)")#text(", then")#linebreak()#text(" ")#mi("\\ln N\\leq n(h(\\rho)+o(1))")#text(".")#linebreak()#text(" But when ")#mi("1/2<\\rho<1")#text(", we have")#linebreak()#text(" ")#mi("\\ln N\\leq n(\\log2+\\frac{\\ln \\lfloor\\rho n\\rfloor}{n}+o(1))")#text(",")#linebreak()#text(" that is, ")#mi("\\ln N\\leq n(\\log2+o(1))")#text(". Am I right? If it is so, there is a typo in the reply.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6172cb67f2866d1a9c75bcd4b937ee0f29937b1a9436b3bbd3bec3383798a71-7a7d636c9329b1dad6a7c1660f8dcf5d0a6703a4a72ee7c15f92b2ba9470b1f9.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alon")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-47376")[#strong[#text("Alon")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2010")])]

#text("Dan Romik published a short note with a slick, though perhaps less well-motivated, proof of Stirling’s formula: ")#link("http://www.stat.berkeley.edu/~romik/paperfiles/stirling.pdf")[#text("http://www.stat.berkeley.edu/~romik/paperfiles/stirling.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c9ac3ed7a9cd3238ea1ec6c879c8a180e8267ea7906e96858cc261279e0b7abe-86d182dad7a564b5e0bc4ab8f8a6c828394088f90790a319f8e50e2486c3ebd1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stirling’s formula « Mathsnail")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-47945")[#strong[#text("Stirling’s formula « Mathsnail")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2010")])]

#text("[…] formula is an approximation for large factorials, that is . A good exposition see Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-49961")[#strong[#text("Lower bounds on off-diagonal Ramsey numbers « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2011")]

#text("[…] the logarithm of both sides and bounding the corresponding Riemann sum by an integral; see also Terence Tao’s notes on Stirling’s formula) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-50731")[#strong[#text("Pi is still wrong « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2011")]

#text("[…] of in the definition of the Gaussian distribution (which is where the factor of comes from in Stirling’s formula) is that the Gaussian distribution is its own Fourier transform. This factor is commonly cited as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Erdos’ divisor bound « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-59950")[#strong[#text("Erdos’ divisor bound « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2011")])]

#text("[…] with sharper bounds available by using tools such as the Euler-Maclaurin formula (see this blog post). Exponentiating such asymptotics, incidentally, leads to one of the standard proofs of Stirling’s formula (as discussed in this blog post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3 « What’s new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-70397")[#strong[#text("The Collatz conjecture, Littlewood-Offord theory, and powers of 2 and 3 « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2011")])]

#text("[…] some absolute constant . Meanwhile, Stirling’s formula (as discussed in this previous post) combined with the approximation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0388efa73d74660f3599ac29578426a66ecb4ee43951ac21cdd0829b194e336a-0b4e9669c4d2ed25883ee72fdfc7e5f5b65ffaddd2f8e9b8acd9d34e351f3f5b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KCd")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-247577")[#strong[#text("KCd")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2013")])]

#text("This proof using the dominated convergence theorem can be found in a 1989 Monthly article: J. M. Patin, A Very Short Proof of Stirling’s Formula, Amer. Math. Monthly 96 (1989), 41–42.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-447510")[#strong[#text("Intuition for the definition of the Gamma function? | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2014")]

#text("[…] these notes by Terence Tao is a proof of Stirling’s formula. I really like most of it, but at a crucial step he uses the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 4: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-461366")[#strong[#text("275A, Notes 4: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2015")])]

#text("[…] is a function of that goes to zero as . (A proof of this formula may be found in this previous blog post.) Using this formula, and without using the central limit theorem, show […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3e92fa30f494cf13c1ec65d7827de6d9d739fb52791a8b000abfc39e757f88b-d2c1d80165bd2b164c900a7712f1ae6da8f918adab41ffbdbc0cf3edce01a0e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Herman Jaramillo")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-467755")[#strong[#text("Herman Jaramillo")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2016")])]

#text("You expanded the argument of the exponential function into a Taylor series. After the term of order $-s^2/2n$ there comes the term $s^3/3n^2$. This terms worries me. Taylor series are local. That is, it should be good for $|s|<<1$. Still the integral is between $-\\infty$ to $\\infty$. Why does not the error introduce by this next factor $exp(s^3/3n^2)$ count? The integral for that factor alone diverges.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3e92fa30f494cf13c1ec65d7827de6d9d739fb52791a8b000abfc39e757f88b-d2c1d80165bd2b164c900a7712f1ae6da8f918adab41ffbdbc0cf3edce01a0e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Herman Jaramillo")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-467763")[#strong[#text("Herman Jaramillo")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2016")])]

#text("I believe I have an answer for my own question above. As $n$ grows the “Gaussian” shape of the integrand t^n exp(-t) narrows around the “center” or peak which is at t=n. Since we are shifting the function to have the origin at t=n. The Taylor approximation makes sense around that location. Yes, the function extendes between -infty and infty, but the gross of the integral is due to the near to the maxima points since in the limit this “Gaussian” shape becomes an spike or some kind of Dirac Delta.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-467765")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2016")])]

#text("In the fifth line below (6), it should be “uniform upper bound” (instead of “uniform lower bound”). Also, in the RHS of the second estimate for this bound, “")#mi("x")#text("” should be replaced by “")#tao-math("\\left|x\\right|", block: false)#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-467782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2016")])]

#text("It is not difficult to verify (via maximization over ")#mi("n")#text("), that the integrand is dominated by ")#tao-math("(1+\\left|x\\right|) e^{-\\left|x\\right|}", block: false)#text(" – which is best possible for ")#mi("x \\geq 0")#text(" (as it attained by the integrand for ")#mi("n=1")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-468723")[#strong[#text("A symmetric formulation of the Croot-Lev-Pach-Ellenberg-Gijswijt capset bound | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 May 2016")])]

#text("[…] tool of Cramer’s theorem, but can also be derived from Stirling’s formula (discussed in this previous post). Indeed, if , , for some summing to , Stirling’s formula […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Elementary multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-472492")[#strong[#text("254A, Notes 1: Elementary multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2016")])]

#text("[…] any (a weak form of Stirling’s formula, discussed in this previous blog post), and more generally one […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: The central limit theorem | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-478164")[#strong[#text("254A, Notes 2: The central limit theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2017")])]

#text("[…] is a function of that goes to zero as . (A proof of this formula may be found in this previous blog post.) Using this formula, and without using the central limit theorem, show […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84e1d7347c0a4eaa7f1374321e168c2bde15572bef9056e95d0f627ee61a88f6-e0f64b10cbeb014f211d178e973e3982799604a142a041a41f4f2e50340b81d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bruno Bauwens")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-483683")[#strong[#text("Bruno Bauwens")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2017")])]

#text("To go from pointwise convergence to convergence of the integrals below (6), one can use Lebesgue’s monotone convergence theorem: the values ")#mi("n log (1+\\sqrt{(}n)) – \\sqrt{n} x")#text(" are increasing in n if x is negative, and are decreasing in n if x is positive. This is because for x=0 all values are 0, and the derivative of x evaluates to")#linebreak()#text(" \\[")#linebreak()#text(" \\frac{-x}{1+x/\\sqrt{n}},")#linebreak()#text(" \\]")#linebreak()#text(" which is decreasing in n both for negative and positive x.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Continuous approximations to arithmetic functions | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-488631")[#strong[#text("Continuous approximations to arithmetic functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("[…] Stirling’s formula, or the Dirichlet series […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The De Bruijn-Newman constant is non-negativ | What's new")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-491517")[#strong[#text("The De Bruijn-Newman constant is non-negativ | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2018")])]

#text("[…] and using the method of steepest descent (actually it is slightly simpler to rely instead on the Stirling approximation for the Gamma function, which can be proven in turn by steepest descent methods). Fortunately, it […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/93e96e92814988f219c345834b8f68260488ff657fe3f9cd2769dd5c3acd3bbf-211925cbb7abc01f70ce3beaacb095d6de2519fb91a58901cb536872456e1f73.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Colpitts")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-510557")[#strong[#text("George Colpitts")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2019")])]

#text("See also Gower’s blog article: ")#link("https://gowers.wordpress.com/2008/02/01/removing-the-magic-from-stirlings-formula/")[#text("https://gowers.wordpress.com/2008/02/01/removing-the-magic-from-stirlings-formula/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-671117")[#strong[#text("Stirling’s formula – On Math")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2022")]

#text("[…] [ 2 ] Terence Tao’s blog article “254A, Notes 0a: Stirling’s formula\" : ")#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")[#text("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-685521")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2024")])]

#text("Can you elaborate on this part:")

#emph[#text("One can do better by using the trapezoid rule. On any interval ")#mi("{[m,m+1]}")#text(", ")#mi("{\\log x}")#text(" has a second derivative of ")#mi("{O( 1 / m^2 )}")#text(", which by Taylor expansion leads to the approximation")]

#link("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+%5Cint_m%5E%7Bm%2B1%7D+%5Clog+x%5C+dx+%3D+%5Cfrac%7B1%7D%7B2%7D+%5Clog+m+%2B+%5Cfrac%7B1%7D%7B2%7D+%5Clog%28m%2B1%29+%2B+%5Cepsilon_m&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+%5Cint_m%5E%7Bm%2B1%7D+%5Clog+x%5C+dx+%3D+%5Cfrac%7B1%7D%7B2%7D+%5Clog+m+%2B+%5Cfrac%7B1%7D%7B2%7D+%5Clog%28m%2B1%29+%2B+%5Cepsilon_m&bg=ffffff&fg=000000&s=0&c=20201002")]

#emph[#text("for some error")]#text(" ")#mi("{\\epsilon_m = O( 1/m^2 )}")#text(".")

#text("How is Taylor expansion used to get the right-hand side? If one expands ")#mi("\\log(x)")#text(" at ")#mi("x=m")#text(", then")

#mi("\\displaystyle \\log(m+t) =\\log(m)+\\frac{t}{m}-\\frac{t^2}{2m^2}+\\cdots")

#text("gives")

#mi("\\int_m^{m+1}log(x) dx = \\int_0^1 \\log(m+t)\\ dt=\\log(m)+\\frac1{2m}+O(1/m^2)")

#text("One can then prove that this is “equivalent” to the one you wrote by looking at the expansion of ")#mi("\\log(m+1)")#text(".")

#text("But is there a more natural way to see how you get the approximation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-685530")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("Taylor approximation is often used to approximate a nonlinear function such as ")#mi("\\log(m+t)")#text(" by a tangent line such as ")#mi("\\log m + \\frac{t}{m}")#text(", but it can also be used to approximate such a function by a secant line such as ")#mi("(1-t) \\log m + t \\log(m+1)")#text(" instead, with roughly the same quadratic error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692127")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2026")])]

#text("Is it going to correspond to a convex combination of tangent line Taylor approximations, or is the secant line Taylor approximation is obtained through a different method?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-685523")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2024")])]

#text("The error is absolutely convergent; by the integral test, we have")

#link("https://s0.wp.com/latex.php?latex=%7B%5Csum_%7Bm%3D1%7D%5En+%5Cepsilon_m+%3D+C+%2B+O%281%2Fn%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7B%5Csum_%7Bm%3D1%7D%5En+%5Cepsilon_m+%3D+C+%2B+O%281%2Fn%29%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("for some absolute constant")

#link("https://s0.wp.com/latex.php?latex=%7BC+%3A%3D+%5Csum_%7Bm%3D1%7D%5E%5Cinfty+%5Cepsilon_m%7D&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%7BC+%3A%3D+%5Csum_%7Bm%3D1%7D%5E%5Cinfty+%5Cepsilon_m%7D&bg=ffffff&fg=000000&s=0&c=20201002")]

#text(".")

#text("One does not have an analytic expression for ")#mi("\\epsilon_m")#text("; how is the integral test use to get the estimate?")

#text("You once mentioned something in mathstodon approximately like “some extremely obvious folklore may be rather nontrivial to another group of people(students) depending on how calculus(or some subject) were taught to them”. Or maybe you were just mentioned the symbol conventions, I don’t remember which post exactly.")

#text("The question in this comment may be an example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-685531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("By the integral test, ")#mi("\\int_{m=M_1+1}^{M_2} 1/m^2 \\leq \\int_{M_1}^{M_2} \\frac{dt}{t^2} = O(1/M_1)")#text(", and hence also ")#mi("\\sum_{m=M_1+1}^{M_2} \\epsilon_m = O(1/M_1)")#text(". This shows that the partial sums ")#mi("\\sum_{m=1}^M \\epsilon_m")#text(" are a Cauchy sequence and thus converge to some limit ")#mi("C")#text(", and also show that the rate of convergence is ")#mi("O(1/M)")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-685525")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2024")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Elementary calculus reveals that the integrand ")#mi("{t^n e^{-t}}")#text(" achieves its maximum at ")#mi("{t=n}")#text(", so it is natural to make the substitution ")#mi("{t = n+s}")#text(", obtaining")

#link("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+n%21+%3D+%5Cint_%7B-n%7D%5E%5Cinfty+%28n%2Bs%29%5En+e%5E%7B-n-s%7D%5C+ds&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+n%21+%3D+%5Cint_%7B-n%7D%5E%5Cinfty+%28n%2Bs%29%5En+e%5E%7B-n-s%7D%5C+ds&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("which we can simplify a little bit as")

#link("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+n%21+%3D+n%5En+e%5E%7B-n%7D+%5Cint_%7B-n%7D%5E%5Cinfty+%281%2B%5Cfrac%7Bs%7D%7Bn%7D%29%5En+e%5E%7B-s%7D%5C+ds%2C&bg=ffffff&fg=000000&s=0&c=20201002")[#text("https://s0.wp.com/latex.php?latex=%5Cdisplaystyle+n%21+%3D+n%5En+e%5E%7B-n%7D+%5Cint_%7B-n%7D%5E%5Cinfty+%281%2B%5Cfrac%7Bs%7D%7Bn%7D%29%5En+e%5E%7B-s%7D%5C+ds%2C&bg=ffffff&fg=000000&s=0&c=20201002")]

#text("pulling out the now-familiar factors of ")#mi("{n^n e^{-n}}")#text(".")
]

#text("I’m wondering if you could elaborate a bit more on the idea of this mysterious part. Why the integrand ")#mi("t^ne^{-t}")#text(" achieving its maximum at ")#mi("t=n")#text(" motivate the substitution ")#mi("t=n+s")#text(" useful for the later calculation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-685532")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("This change of variables moves the maximum from ")#mi("t = n")#text(" to the origin ")#mi("s=0")#text(". In general, if one wants to study the behavior of a sum or integral near a given location, it tends to be a good idea to change coordinates to normalize that location to something simple, such as the origin, as it often makes formulae simpler, and clarifies which terms are the “main terms” and which ones are “lower order”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692121")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2026")])]

#text("Hi,")

#text("Firstly, I want to thank you for this beautifully written post. However, I wasn’t able to follow how the uniform upper bounds following (6) were derived, although I was able to follow the formula with the integral. For an example, I don’t really see how ")#mi("x=-\\sqrt{n}")#text(" is not issue in that integral, because I think explicit calculation in that case is possible and it gives a divergent integral. Moreover, I wasn’t very sure about the existence of an absolutely integrable function following from those bounds, as one of the bounds is dependent on n at its absolute value seems to be growing with n and this happens in a non-0 measure set, so I don’t see how such a function can be a uniform bound for all the functions in a sequence and still be absolutely integrable.")

#text("Thanks again.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692123")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2026")])]

#text("The divergence of the logarithm to ")#mi("-\\infty")#text(" is not an issue here, as only an upper bound is needed. The dependence on $n$ in the upper bounds works in one’s favor; one can for instance use a constant multiple of ")#tao-math("\\max(\\exp(-c\\left|x\\right|^2), \\exp(-c\\left|x\\right|))", block: false)#text(" as the dominating function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692126")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2026")])]

#text("Thanks for your reply, and sorry for the multiple copies of the sent messages, still trying to get used to WordPress.")

#text("I just wanted to ask in case I’m missing a finer detail, it seems like the second one is actually just a strengthening of the first one for the specific case of ")#mi("x\\geq \\sqrt{n}")#text(", so the first one would actually be a valid upper bound for the sequence of functions we have. We also see that it’s a type of Gaussian, which we know is integrable, so I feel like that would be enough for our purposes as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692136")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2026")])]

#mi("-c|x| \\sqrt{n}")#text(" is a weaker upper bound than ")#tao-math("-c \\left|x\\right|^2", block: false)#text(" for ")#mi("x \\geq \\sqrt{n}")#text(", not a stronger one.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692533")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2026")])]

#text("Dear Dr Tao,")

#text("If we look at the Stirling’s formula n!～sprt(2πn)n^{n}e^{-n}, there are two constants involved in it: π and e.")

#text("Since the Gamma function contains an exponential integral, and π is the only constant such that the Gaussian integral equals 1, so I think π is natural to appear (right?). But when it comes to e, I don’t know of any heuristic principle to explain why it arises here naturally- What am I missing here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692536")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2026")])]

#text("The “")#mi("e")#text("” already appears in the aforementioned exponential integral ")#mi("n! = \\int_0^\\infty t^n e^{-t}\\ dt")#text("; the ")#mi("n^n e^{-n}")#text(" factor is simply the mode (maximum value) of the integrand.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2026")])]

#text("Thanks for the reply! Now I know what am I missing here.")

#text("I would like to ask: general speaking, not just the Stirling’s formula case, is there an heuristic way to illustrate when e arises naturally?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692543")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2026")])]

#text("Euler’s constant ")#mi("e")#text(" is literally called the natural base of exponentiation; it appears in countless identities, and it would be pointless to try to design any sort of comprehensive checklist of where it appears. For instance, it is tied by various formulas to many other core special functions in mathematics, such as the trigonometric functions, the natural logarithm, the Gamma function (as discussed in this post), the gaussian distribution, etc.. One may as well ask for a heuristic as to when the constant ")#mi("2")#text(" (which, incidentally, is the second most common base of exponentiation to appear in mathematics, after ")#mi("e")#text(") is likely to arise naturally in mathematics.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/02/254a-notes-0a-stirlings-formula/#comment-692569")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2026")])]

#text("Dear Prof Tao,")

#text("Thanks for this insightful discussion of Stirling’s formula, and for linking to the short derivation by Keller and Vanden-Broeck, which is beautiful. In fact, Stirling’s formula can be derived purely from the Taylor series (TS) of ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" even more quickly – in just a few lines – as follows (in outline):")

#text("We have ")#mi("\\ln\\left(\\Gamma(z+1)\\right) = -\\gamma z + \\sum_{j=2}^{\\infty}(-1)^{j}\\frac{\\zeta(j)}{j} z^{j}")#text(" near 0 so the “coefficient function” of ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" is ")#mi("\\frac{\\zeta(s)}{s} \\cdot \\cos(\\pi s)")#text(", ")#mi("s\\in\\mathbb{C}")#text(".")

#text("Its values for ")#mi("s=j\\geq{2}")#text(" give the coefficients of ")#mi("z^{j}")#text(" (")#mi("j\\geq{2}")#text(" in the TS around 0. For ")#mi("s=j\\leq{-1}")#text(" its values give the negatives of the coefficients of ")#mi("z^{j}")#text(" in the asymptotic expansion for ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" as ")#mi("z\\rightarrow\\infty")#text(" (")#mi("\\frac{1}{12}\\frac{1}{z}-\\frac{1}{360}\\frac{1}{z^{3}}+\\ldots")#text(").")

#text("For ")#mi("s=1")#text(" its singular “value” gives rise to terms which split between the TS at 0 and the asymptotic expansion as ")#mi("z\\rightarrow\\infty")#text(". Specifically, for ")#mi("s=1+\\epsilon")#text(" we have ")#mi("\\frac{\\zeta(1+\\epsilon)}{1+\\epsilon} \\cdot \\cos(\\pi (1+\\epsilon)) \\approx \\frac{-1}{\\epsilon} + (-\\gamma + 1) + O(\\epsilon)")#text(". This gives the final ")#mi("-\\gamma z")#text(" term in the TS near 0 and, after negating signs, also gives rise to terms ")#mi("z\\ln z - z")#text(" in the asymptotic series (the ")#mi("\\frac{-1}{\\epsilon}")#text(" pole near ")#mi("s=1")#text(" generates the ")#mi("z\\ln z")#text(" term).")

#text("Likewise, for the singular “value” at ")#mi("s=0")#text(", taking ")#mi("s=\\epsilon")#text(" we have ")#mi("\\frac{\\zeta(\\epsilon)}{\\epsilon} \\cdot \\cos(\\pi \\epsilon) \\approx -\\frac{1}{2} \\frac{1}{\\epsilon} - \\frac{1}{2} \\ln(2 \\pi) + O(\\epsilon)")#text(" and, after negating signs, this contributes terms ")#mi("\\frac{1}{2} \\ln(z)+\\frac{1}{2} \\ln(2 \\pi)")#text(" to the asymptotic expansion as ")#mi("z\\rightarrow\\infty")#text(".")

#text("Combining all these contributions gives the full Stirling’s formula for the asymptotic expansion of ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" as ")#mi("z\\rightarrow\\infty")#text(".")

#text("I find this derivation striking, not just because it is so short, but because it derives the asymptotics of ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" as ")#mi("z\\rightarrow\\infty")#text(" purely from the Taylor series for ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" in an infinitesimal neighbourhood of 0 (effectively “seeing to the edge of the universe with a microscope”) – in addition to which it uses no special properties of ")#mi("\\Gamma")#text(" or advanced combinatorial identities. The method of reasoning used can thus be applied more generally to other functions ")#mi("f(z)")#text(", not just ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(".")

#text("The justification for the above reasoning requires a little bit of infrastructure, but not much and its fairly elementary. Mainly it requires ")#strong[#text("(a)")]#text(" moving from classical convergence to a generalised Cesaro convergence framework, so that the Mellin transform of ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" (and the closely-related “coefficient function” used above) are well-defined functions of ")#mi("s\\in\\mathbb{C}")#text(" (by contrast, under classical convergence, the Mellin transform of ")#mi("\\ln\\left(\\Gamma(z+1)\\right)")#text(" does not exist even for a single ")#mi("s\\in\\mathbb{C}")#text("); and ")#strong[#text("(b)")]#text(" showing that under this framework the values of the “coefficient function” ")#emph[#text("simultaneously ")]#text("connect the power and power-log behaviour of a function around 0 and as ")#mi("z\\rightarrow\\infty")#text(" (with a simple sign factor involved).")

#text("Best regards, Richard Stone")
]
