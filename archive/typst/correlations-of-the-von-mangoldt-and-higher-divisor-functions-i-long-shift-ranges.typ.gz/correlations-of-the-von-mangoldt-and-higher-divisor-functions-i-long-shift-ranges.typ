// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/
// Converted to Typst by tao2typ: "2026-10-14T16:38:08.993093+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Correlations of the von Mangoldt and higher divisor functions I.  Long shift ranges", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Correlations of the von Mangoldt and higher divisor functions I.  Long shift ranges")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 6 July 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/")[#text("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://users.utu.fi/ksmato/")[#text("Kaisa Matomaki")]#text(", ")#link("http://www.math.mcgill.ca/radziwill/")[#text("Maksym Radziwill")]#text(", and I have uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1707.01315")[#text("Correlations of the von Mangoldt and higher divisor functions I. Long shift ranges")]#text("“, submitted to ")#link("https://www.lms.ac.uk/publications/plms")[#text("Proceedings of the London Mathematical Society")]#text(". This paper is concerned with the estimation of correlations such as ")#metadata(none) <tao-eedd861ec911535e8123>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{n \\leq X} \\Lambda(n) \\Lambda(n+h)")]]

#text("for medium-sized ")#mi("{h}")#text(" and large ")#mi("{X}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text("; we also consider variants of this sum in which one of the von Mangoldt functions is replaced with a (higher order) divisor function, but for sake of discussion let us focus just on the sum ")#link(<tao-eedd861ec911535e8123>)[#text("(1)")]#text(". Understanding this sum is very closely related to the problem of finding pairs of primes that differ by ")#mi("{h}")#text("; for instance, if one could establish a lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq X} \\Lambda(n) \\Lambda(n+2) \\gg X")]]

#text("then this would easily imply the ")#link("https://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(".")

#text("The ")#link("https://en.wikipedia.org/wiki/Twin_prime#First_Hardy.E2.80.93Littlewood_conjecture")[#text("(first) Hardy-Littlewood conjecture")]#text(" asserts an asymptotic ")#metadata(none) <tao-234d8fac0818118b3bb4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{n \\leq X} \\Lambda(n) \\Lambda(n+h) = {\\mathfrak S}(h) X + o(X)")]]

#text("as ")#mi("{X \\rightarrow \\infty}")#text(" for any fixed positive ")#mi("{h}")#text(", where the ")#emph[#text("singular series")]#text(" ")#mi("{{\\mathfrak S}(h)}")#text(" is an arithmetic factor arising from the irregularity of distribution of ")#mi("{\\Lambda}")#text(" at small moduli, defined explicitly by")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak S}(h) := 2 \\Pi_2 \\prod_{p|h; p>2} \\frac{p-2}{p-1}")]]

#text("when ")#mi("{h}")#text(" is even, and ")#mi("{{\\mathfrak S}(h)=0}")#text(" when ")#mi("{h}")#text(" is odd, where")

#align(center)[#tao-fit-display[#mitex("\\Pi_2 := \\prod_{p>2} (1-\\frac{1}{(p-1)^2}) = 0.66016\\dots")]]

#text("is (half of) the ")#link("http://primes.utm.edu/glossary/xpage/TwinPrimeConstant.html")[#text("twin prime constant")]#text(". See for instance ")#link("https://terrytao.wordpress.com/2015/01/04/254a-supplement-4-probabilistic-models-and-heuristics-for-the-primes-optional/")[#text("this previous blog post")]#text(" for a a heuristic explanation of this conjecture. From the previous discussion we see that ")#link(<tao-234d8fac0818118b3bb4>)[#text("(2)")]#text(" for ")#mi("{h=2}")#text(" would imply the twin prime conjecture. Sieve theoretic methods are only able to provide an upper bound of the form ")#mi("{ \\sum_{n \\leq X} \\Lambda(n) \\Lambda(n+h) \\ll {\\mathfrak S}(h) X}")#text(".")

#text("Needless to say, apart from the trivial case of odd ")#mi("{h}")#text(", there are no values of ")#mi("{h}")#text(" for which the Hardy-Littlewood conjecture is known. However there are some results that say that this conjecture holds “on the average”: in particular, if ")#mi("{H}")#text(" is a quantity depending on ")#mi("{X}")#text(" that is somewhat large, there are results that show that ")#link(<tao-234d8fac0818118b3bb4>)[#text("(2)")]#text(" holds for most (i.e. for ")#mi("{1-o(1)}")#text(") of the ")#mi("{h}")#text(" betwen ")#mi("{0}")#text(" and ")#mi("{H}")#text(". Ideally one would like to get ")#mi("{H}")#text(" as small as possible, in particular one can view the full Hardy-Littlewood conjecture as the endpoint case when ")#mi("{H}")#text(" is bounded.")

#text("The first results in this direction were ")#link("http://www.ams.org/mathscinet-getitem?mr=1505099")[#text("by van der Corput")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=157955")[#text("by Lavrik")]#text(", who established such a result with ")#mi("{H = X}")#text(" (with a subsequent refinement ")#link("http://www.ams.org/mathscinet-getitem?mr=1084173")[#text("by Balog")]#text("); ")#link("http://www.ams.org/mathscinet-getitem?mr=990587")[#text("Wolke")]#text(" lowered ")#mi("{H}")#text(" to ")#mi("{X^{5/8+\\varepsilon}}")#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1118579")[#text("Mikawa")]#text(" lowered ")#mi("{H}")#text(" further to ")#mi("{X^{1/3+\\varepsilon}}")#text(". The main result of this paper is a further lowering of ")#mi("{H}")#text(" to ")#mi("{X^{8/33+\\varepsilon}}")#text(". In fact (as in the preceding works) we get a better error term than ")#mi("{o(X)}")#text(", namely an error of the shape ")#mi("{O_A( X \\log^{-A} X)}")#text(" for any ")#mi("{A}")#text(".")

#text("Our arguments initially proceed along standard lines. One can use the Hardy-Littlewood circle method to express the correlation in ")#link(<tao-234d8fac0818118b3bb4>)[#text("(2)")]#text(" as an integral involving exponential sums ")#mi("{S(\\alpha) := \\sum_{n \\leq X} \\Lambda(n) e(\\alpha n)}")#text(". The contribution of “major arc” ")#mi("{\\alpha}")#text(" is known by a standard computation to recover the main term ")#mi("{{\\mathfrak S}(h) X}")#text(" plus acceptable errors, so it is a matter of controlling the “minor arcs”. After averaging in ")#mi("{h}")#text(" and using the Plancherel identity, one is basically faced with establishing a bound of the form")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\beta-1/H}^{\\beta+1/H} \\left|S(\\alpha)\\right|^2\\ d\\alpha \\ll_A X \\log^{-A} X", block: true)]]

#text("for any “minor arc” ")#mi("{\\beta}")#text(". If ")#mi("{\\beta}")#text(" is somewhat close to a low height rational ")#mi("{a/q}")#text(" (specifically, if it is within ")#mi("{X^{-1/6-\\varepsilon}}")#text(" of such a rational with ")#mi("{q = O(\\log^{O(1)} X)}")#text("), then this type of estimate is roughly of comparable strength (by another application of Plancherel) to the best available prime number theorem in short intervals on the average, namely that the prime number theorem holds for most intervals of the form ")#mi("{[x, x + x^{1/6+\\varepsilon}]}")#text(", and we can handle this case using standard mean value theorems for Dirichlet series. So we can restrict attention to the “strongly minor arc” case where ")#mi("{\\beta}")#text(" is far from such rationals.")

#text("The next step (following some ideas we found in a ")#link("http://www.ams.org/mathscinet-getitem?mr=1141240")[#text("paper of Zhan")]#text(") is to rewrite this estimate not in terms of the exponential sums ")#mi("{S(\\alpha) := \\sum_{n \\leq X} \\Lambda(n) e(\\alpha n)}")#text(", but rather in terms of the Dirichlet polynomial ")#mi("{F(s) := \\sum_{n \\sim X} \\frac{\\Lambda(n)}{n^s}}")#text(". After a certain amount of computation (including some oscillatory integral estimates arising from stationary phase), one is eventually reduced to the task of establishing an estimate of the form")

#align(center)[#tao-fit-display[#mitex("\\int_{t \\sim \\lambda X} (\\sum_{t-\\lambda H}^{t+\\lambda H} |F(\\frac{1}{2}+it^{\\prime})|\\ dt^{\\prime})^2\\ dt \\ll_A \\lambda^2 H^2 X \\log^{-A} X")]]

#text("for any ")#mi("{X^{-1/6-\\varepsilon} \\ll \\lambda \\ll \\log^{-B} X}")#text(" (with ")#mi("{B}")#text(" sufficiently large depending on ")#mi("{A}")#text(").")

#text("The next step, which is again standard, is the use of the Heath-Brown identity (as discussed for instance in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous blog post")]#text(") to split up ")#mi("{\\Lambda}")#text(" into a number of components that have a Dirichlet convolution structure. Because the exponent ")#mi("{8/33}")#text(" we are shooting for is less than ")#mi("{1/4}")#text(", we end up with five types of components that arise, which we call “Type ")#mi("{d_1}")#text("“, “Type ")#mi("{d_2}")#text("“, “Type ")#mi("{d_3}")#text("“, “Type ")#mi("{d_4}")#text("“, and “Type II”. The “Type II” sums are Dirichlet convolutions involving a factor supported on a range ")#mi("{[X^\\varepsilon, X^{-\\varepsilon} H]}")#text(" and is quite easy to deal with; the “Type ")#mi("{d_j}")#text("” terms are Dirichlet convolutions that resemble (non-degenerate portions of) the ")#mi("{j^{th}}")#text(" divisor function, formed from convolving together ")#mi("{j}")#text(" portions of ")#mi("{1}")#text(". The “Type ")#mi("{d_1}")#text("” and “Type ")#mi("{d_2}")#text("” terms can be estimated satisfactorily by standard moment estimates for Dirichlet polynomials; this already recovers the result of Mikawa (and our argument is in fact slightly more elementary in that no Kloosterman sum estimates are required). It is the treatment of the “Type ")#mi("{d_3}")#text("” and “Type ")#mi("{d_4}")#text("” sums that require some new analysis, with the Type ")#mi("{d_3}")#text(" terms turning to be the most delicate. After using an ")#link("http://www.ams.org/mathscinet-getitem?mr=1092763")[#text("existing moment estimate")]#text(" of Jutila for Dirichlet L-functions, matters reduce to obtaining a family of estimates, a typical one of which (relating to the more difficult Type ")#mi("{d_3}")#text(" sums) is of the form ")#metadata(none) <tao-7afdd8504dd42b3246c6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\int_{t - H}^{t+H} \\left|M( \\frac{1}{2} + it^{\\prime})\\right|^2\\ dt^{\\prime} \\ll X^{\\varepsilon^2} H", block: true)]]

#text("for “typical” ordinates ")#mi("{t}")#text(" of size ")#mi("{X}")#text(", where ")#mi("{M}")#text(" is the Dirichlet polynomial ")#mi("{M(s) := \\sum_{n \\sim X^{1/3}} \\frac{1}{n^s}}")#text(" (a fragment of the Riemann zeta function). The precise definition of “typical” is a little technical (because of the complicated nature of Jutila’s estimate) and will not be detailed here. Such a claim would follow easily from the Lindelof hypothesis (which would imply that ")#mi("{M(1/2 + it) \\ll X^{o(1)}}")#text(") but of course we would like to have an unconditional result.")

#text("At this point, having exhausted all the Dirichlet polynomial estimates that are usefully available, we return to “physical space”. Using some further Fourier-analytic and oscillatory integral computations, we can estimate the left-hand side of ")#link(<tao-7afdd8504dd42b3246c6>)[#text("(3)")]#text(" by an expression that is roughly of the shape")

#align(center)[#tao-fit-display[#mitex("\\frac{H}{X^{1/3}} \\sum_{\\ell \\sim X^{1/3}/H} |\\sum_{m \\sim X^{1/3}} e( \\frac{t}{2\\pi} \\log \\frac{m+\\ell}{m-\\ell} )|.")]]

#text("The phase ")#mi("{\\frac{t}{2\\pi} \\log \\frac{m+\\ell}{m-\\ell}}")#text(" can be Taylor expanded as the sum of ")#mi("{\\frac{t_j \\ell}{\\pi m}}")#text(" and a lower order term ")#mi("{\\frac{t_j \\ell^3}{3\\pi m^3}}")#text(", plus negligible errors. If we could discard the lower order term then we would get quite a good bound using the ")#link("http://www.ams.org/mathscinet-getitem?mr=2212877")[#text("exponential sum estimates of Robert and Sargos")]#text(", which control averages of exponential sums with purely monomial phases, with the averaging allowing us to exploit the hypothesis that ")#mi("{t}")#text(" is “typical”. Figuring out how to get rid of this lower order term caused some inefficiency in our arguments; the best we could do (after much experimentation) was to use Fourier analysis to shorten the sums, estimate a one-parameter average exponential sum with a binomial phase by a two-parameter average with a monomial phase, and then use the van der Corput ")#mi("{B}")#text(" process followed by the estimates of Robert and Sargos. This rather complicated procedure works up to ")#mi("{H = X^{8/33+\\varepsilon}}")#text(" it may be possible that some alternate way to proceed here could improve the exponent somewhat.")

#text("In a sequel to this paper, we will use a somewhat different method to reduce ")#mi("{H}")#text(" to a much smaller value of ")#mi("{\\log^{O(1)} X}")#text(", but only if we replace the correlations ")#mi("{\\sum_{n \\leq X} \\Lambda(n) \\Lambda(n+h)}")#text(" by either ")#mi("{\\sum_{n \\leq X} \\Lambda(n) d_k(n+h)}")#text(" or ")#mi("{\\sum_{n \\leq X} d_k(n) d_l(n+h)}")#text(", and also we now only save a ")#mi("{o(1)}")#text(" in the error term rather than ")#mi("{O_A(\\log^{-A} X)}")#text(".")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-483426")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2017")])]

#text("Dear Terry,")

#text("I think there’s a typo concerning the value of the twin prime constant, which is around 0.66016.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-483429")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2017")])]

#text("Is it possible (by these methods) to improve the new exponent ")#mi("8/33")#text(" ? (i.e. is it best possible under current methods ?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-483451")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2017")])]

#text("I think there is room for further improvement, in particular new bounds on exponential sums will certainly help (e.g. finding a version of the Robert-Sargos estimates that work in the non-monomial cases). We tried a half a dozen different things while we were at MSRI together and got a whole range of exponents, of which 8/33 was the best that we could come up with, but perhaps there is some arrangement of the existing tools (or, preferably, the introduction of a new tool) that we overlooked. Conjecturally, of course, the exponent should be able to go all the way down to 0. (This is for instance the case if one assumes the exponent pairs conjecture, or even just the Lindelof hypothesis.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d187a34135d33024ccd60f2cf8f2ba799f7335215f14eafaabb7b7cabff71792-7c7c89e16274a42cc4cbdbf2e1764b959dacc78f4800a6cf730cd5956f3b4e24.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-483480")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2017")])]

#text("Good luck with your work on proving the twin prime conjecture! The conjecture is true! Why? Refer to the links below for details.")

#text("Note: Proving twin prime, or the more general Polignac conjecture, or Goldbach conjecture depends on the distribution of prime numbers along the natural number line. And if one can prove the Riemann Hypothesis, then will have enough knowledge of the prime distribution to prove those conjectures probabilistically. Prove Riemann Hypothesis and the other results will follow logically.")

#text("Reference link:")

#link("https://www.quora.com/What-great-conjectures-in-mathematics-combine-additive-theory-of-numbers-with-the-multiplicative-theory-of-numbers/answer/David-Cole-146")[#text("https://www.quora.com/What-great-conjectures-in-mathematics-combine-additive-theory-of-numbers-with-the-multiplicative-theory-of-numbers/answer/David-Cole-146")]#text(";")

#link("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")[#text("https://www.researchgate.net/post/Why_is_the_Riemann_Hypothesis_true2")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-486599")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2017")])]

#text("it is well known that in the article “A quadratic divisor problem”write by W.Duke,J.B.Friedlander and H.Iwaniec,they proof a linear estimate of this type:$")#mi("D_{f}(a,b;h)=\\sum_{am+bn=h}\\tau(m)\\tau(n)f(am,bn)=\\int_{0}^{\\infty}g(x,x+h)dx+O(P^{\\frac{5}{4}}(X+Y)^{\\frac{1}{4}}(XY)^{\\frac{1}{4}+\\epsilon})")#text("$.")#linebreak()#text(" based on A.Weil’s estimate on Ramanujan sum:")#mi("S(m,n;q)=\\sum_{d(mod\\ q)}e(\\frac{dm+\\bar dn}{q})\\leq (m,n,q)^{\\frac{1}{2}}q^{\\frac{1}{2}}\\tau(q)")#text(",and")#mi("\\delta")#text(" method.and the asymptotic formula ")#mi("\\sum_{n\\leq x}\\tau(n)\\tau(n+h)=xP_h(logx)+O(x^{\\frac{11}{12}}log^3x)")#text(".")#linebreak()#text(" is it possible to refinement the similar estimate for ")#mi("H_{f}(a,b;h)=\\sum_{am+bn=h}\\Lambda(m)\\Lambda(n)f(am,bn)")#text(" use the idea of")#mi("\\delta")#text("method and your so powerful estimate from medium term h in this blog?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f943457b36ebd91430934ad2766de6412127b5f5d02770571da86486a23ca77c-ff7f65d769d69d5b91730ce9d62f5e2b6fb6ba16b2d287e2a883f33d4b4f7926.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-486606")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2017")])]

#text("Dear hxypqr,")

#text("The short answer is no, the reason why the method of DFI works for ")#mi("\\tau(n)")#text(" is because ")#mi("\\tau(n)")#text(" has two smooth variables of size at worst ")#mi("\\sqrt{x}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1a98f3df9b6a5632a4bf0a0fd81541d05b67cf74565788c0ac7e2b54344839a8-9f492533d2b15b4f3760c8e5384c0b7fc68e7d2905a9a6ffcacc05f60becac33.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hxypqr")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-486705")[#strong[#text("hxypqr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2017")])]

#text("thank you.yeah you are right,from my calculate i understand the key point is that ")#mi("\\sum_{n\\leq x}\\Lambda(n)")#text(" does not have a good control with the error term,so because we are deal with the bilinear form,the error term is out of control.in fact if we expect to make the argument still effective.we just need a very good error term estimate of ")#mi("\\sum_{n\\leq x}\\Lambda(n)")#text(".i think it is nearly to proof RH.")#linebreak()#text(" but for the main part,the diagonal estimate and off-diagonal estimate is still effective.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]], [#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-490841")[#strong[#text("Correlations of the von Mangoldt and higher divisor functions II. Divisor correlations in short ranges | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2017")])]

#text("[…] divisor functions II. Divisor correlations in short ranges“. This is a sequel of sorts to our previous paper on divisor correlations, though the proof techniques in this paper are rather different. As with the previous paper, our […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/07/06/correlations-of-the-von-mangoldt-and-higher-divisor-functions-i-long-shift-ranges/#comment-644112")[#strong[#text("nt.number theory - Do prime gaps that are a power of \"h\" have the same density? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2022")]

#text("[…] Terence Tao’s blog post there is the […]")
]
