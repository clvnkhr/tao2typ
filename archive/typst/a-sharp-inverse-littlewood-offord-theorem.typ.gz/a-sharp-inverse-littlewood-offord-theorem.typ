// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/02/16/a-sharp-inverse-littlewood-offord-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:35:35.851578+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A sharp inverse Littlewood-Offord theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A sharp inverse Littlewood-Offord theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 February 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/02/16/a-sharp-inverse-littlewood-offord-theorem/")[#text("https://terrytao.wordpress.com/2009/02/16/a-sharp-inverse-littlewood-offord-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our preprint “")#link("http://arxiv.org/abs/0902.2357")[#text("A sharp inverse Littlewood-Offord theorem")]#text("“, which we have submitted to ")#link("http://www3.interscience.wiley.com/journal/38107/home")[#text("Random Structures and Algorithms")]#text(". This paper gives a solution to the (inverse) Littlewood-Offord problem of understanding when random walks are concentrated in the case when the concentration is of polynomial size in the length ")#mi("n")#text(" of the walk; our description is sharp up to epsilon powers of ")#mi("n")#text(". The theory of inverse Littlewood-Offord problems and related topics has been of importance in recent developments in the spectral theory of discrete random matrices (e.g. a “robust” variant of these theorems was crucial in ")#link("https://terrytao.wordpress.com/2008/08/02/random-matrices-universality-of-esds-and-the-circular-law/")[#text("our work on the circular law")]#text(").")

#text("For simplicity I will restrict attention to the Bernoulli random walk. Given ")#mi("n")#text(" real numbers ")#mi("v_1,\\ldots,v_n")#text(", one can form the random variable")

#align(center)[#tao-fit-display[#mitex("S := \\epsilon_1 v_1 + \\ldots + \\epsilon_n v_n")]]

#text("where ")#mi("\\epsilon_1,\\ldots,\\epsilon_n \\in \\{-1,+1\\}")#text(" are iid random signs (with either sign +1, -1 chosen with probability 1/2). This is a discrete random variable which typically takes ")#mi("2^n")#text(" values. However, if there are various arithmetic relations between the step sizes ")#mi("v_1,\\ldots,v_n")#text(", then many of the ")#mi("2^n")#text(" possible sums collide, and certain values may then arise with much higher probability. To measure this, define the ")#emph[#text("concentration probability")]#text(" ")#mi("p(v_1,\\ldots,v_n)")#text(" by the formula")

#align(center)[#mi("p(v_1,\\ldots,v_n) = \\sup_x {\\Bbb P}(S=x)")#text(".")]

#text("Intuitively, this probability measures the amount of additive structure present between the ")#mi("v_1,\\ldots,v_n")#text(". There are two (opposing) problems in the subject:")

#list(
[#text("(Forward Littlewood-Offord problem) Given some structural assumptions on ")#mi("v_1,\\ldots,v_n")#text(", what bounds can one place on ")#mi("p(v_1,\\ldots,v_n)")#text("?")],
[#text("(Inverse Littlewood-Offord problem) Given some bounds on ")#mi("p(v_1,\\ldots,v_n)")#text(", what structural assumptions can one then conclude about ")#mi("v_1,\\ldots,v_n")#text("?")]
)

#text("Ideally one would like answers to both of these problems which come close to inverting each other, and this is the guiding motivation for our paper.")

#metadata(none) <tao-2fa038b753ce910add29>#text("One of the first forward Littlewood-Offord theorems was ")#link("http://www.ams.org/mathscinet-getitem?mr=14608")[#text("by Erdős")]#text(", who showed")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text(" If at least k of the ")#mi("v_1,\\ldots,v_n")#text(" are non-zero, then ")#mi("p(v_1,\\ldots,v_n) \\leq O(k^{-1/2})")#text(".")
]

#text("In fact the sharp bound was computed by Erdős as $\\binom{k}{\\lfloor k/2\\rfloor}/2^k$; the proof relies, incidentally, on ")#link("http://en.wikipedia.org/wiki/Sperner%27s_theorem")[#text("Sperner’s theorem")]#text(", which is of relevance to the ongoing ")#link("http://michaelnielsen.org/polymath1/index.php?title=Main_Page")[#text("polymath1 project")]#text(". (An earlier result of Littlewood and Offord gave a weaker bound of ")#mi("O( k^{-1/2} \\log k )")#text(".) Taking contrapositives, we obtain an inverse Littlewood-Offord theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1. ")]#text(" If ")#mi("p(v_1,\\ldots,v_n) \\geq p")#text(", then at most ")#mi("O(1/p^2)")#text(" of the ")#mi("v_1,\\ldots,v_n")#text(" are non-zero.")
]

#text("The bound is sharp in the sense that it is attained in the case when all the ")#mi("v_i")#text(" are equal. However, the theorem is far from sharp in other cases; if k of the ")#mi("v_1,\\ldots,v_n")#text(" are non-zero, then ")#mi("p(v_1,\\ldots,v_n)")#text(" can be as small as ")#mi("2^{-k}")#text(".")

#text("Another forward Littlewood-Offord theorem in a similar spirit is ")#link("http://www.ams.org/mathscinet-getitem?mr=182619")[#text("by Särkőzy and Szemerédi")]#text(", who showed")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2. ")]#text(" If at least k of the ")#mi("v_1,\\ldots,v_n")#text(" are distinct, then ")#mi("p(v_1,\\ldots,v_n) \\leq O(k^{-3/2})")#text(".")
]

#text("(The slightly weaker bound of ")#mi("O( k^{-3/2} \\log k )")#text(" was obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=174539")[#text("by Erdős and Moser")]#text(".) Again, it has a contrapositive:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2. ")]#text("If ")#mi("p(v_1,\\ldots,v_n) \\geq p")#text(", then the ")#mi("v_1,\\ldots,v_n")#text(" take on at most ")#mi("O( p^{-2/3} )")#text(" distinct values.")
]

#text("Again, Theorem 2 is optimal in the sense that the bound is attained when ")#mi("v_1,\\ldots,v_n")#text(" lie in an arithmetic progression (e.g. ")#mi("v_i = i")#text("), but is not always sharp otherwise. There are many further forward and inverse Littlewood-Offord results; see our paper for a discussion of some of these.")

#text("In recent years it has become clearer that the concentration probability is connected to the extent to which the ")#mi("v_1,\\ldots,v_n")#text(" lie in a ")#emph[#text("generalised arithmetic progression")]#text(" (GAP)")

#align(center)[#mi("P = \\{ n_1 w_1 + \\ldots + n_d w_d: -N_i \\leq n_i \\leq N_i \\text{ for } i=1,\\ldots,d \\}")#text(";")]

#text("the quantity d is known as the ")#emph[#text("rank")]#text(" of the GAP. For instance, an easy computation gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3.")]#text(" (Forward Littlewood-Offord) If ")#mi("v_1,\\ldots,v_n")#text(" lie in a GAP P of rank d, then")

#align(center)[#tao-math("p(n_1,\\ldots,n_d) \\ll_d n^{-d/2} \\left|P\\right|^{-1}", block: false)#text(".")]
]

#text("Intuitively, a random sum of n vectors in P should lie in a dilate ")#mi("O(\\sqrt{n}) P")#text(" of P, which has size about ")#tao-math("n^{d/2} \\left|P\\right|", block: false)#text(", which leads to the stated concentration result.")

#text("One of our main results is a sort of converse to the above claim, in the regime where the concentration probability is of polynomial size:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4. ")]#text("(Inverse Littlewood-Offord) If ")#mi("p(v_1,\\ldots,v_n) \\geq n^{-A}")#text(", and ")#mi("\\varepsilon > 0")#text(", then there exists a GAP P of rank d at most 2A that contains all but ")#mi("O_{A,\\varepsilon}(n^{1-\\varepsilon})")#text(" of the ")#mi("v_1,\\ldots,v_n")#text(", and such that")

#align(center)[#tao-math("p(n_1,\\ldots,n_d) \\ll_{A,\\varepsilon} n^{-d/2+\\varepsilon} \\left|P\\right|^{-1}", block: false)#text(".")]
]

#text("Thus, Theorem 3 is sharp up to epsilon losses, and up to throwing away a small number of vectors. One can use this theorem to deduce several earlier theorems, such as Theorem 1 and Theorem 2, except for some epsilon losses. (It is certainly of interest to try to see how one can remove these epsilon losses; I know this problem is currently being looked at.)")

#link("http://arxiv.org/abs/math.PR/0511215")[#text("In an earlier paper")]#text(" we had proven a weaker version of Theorem 4, in which the rank d was only bounded by ")#mi("O_A(1)")#text(" instead of the optimal value of 2A, and the nearly-sharp ")#mi("n^{-d/2+\\varepsilon}")#text(" factor was replaced by ")#mi("n^{-O_A(1)}")#text(".")

#text("Our methods are purely combinatorial, based on “growing” the GAP P by a greedy algorithm. Roughly speaking, the idea is as follows:")

#enum(start: 1, 
[#text("Start with the trivial progression ")#mi("Q = \\{0\\}")#text(". Also, pick an integer k a little bit smaller than ")#mi("\\sqrt{n}")#text(".")],
[#text("Call an element x of Q “bad” if adding the progression ")#mi("\\{ -kx, \\ldots, -x,0,x,\\ldots, kx\\}")#text(" to Q significantly increases the size of Q, and “good” otherwise.")],
[#text("If only a few of the ")#mi("v_1,\\ldots,v_n")#text(" are bad, STOP.")],
[#text("Otherwise, if there are a lot of bad ")#mi("v_i")#text(", there is a way to use Hölder’s inequality to find a bad x with the property that S is much more likely to fall into a translate of ")#mi("Q + \\{-kx,\\ldots,kx\\}")#text(" than it is to Q. Replace Q with this larger GAP and return to step 2.")]
)

#text("This algorithm turns out to terminate in a bounded number of steps if the concentration probability of S was initially of polynomial size, and will trap most of the ")#mi("v_1,\\ldots,v_n")#text(" in the set of good points relating to Q, which turns out to essentially be a GAP P of size about ")#mi("n^{d/2}")#text(" times bigger than that of Q, where d is the rank of Q.")

#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/02/16/a-sharp-inverse-littlewood-offord-theorem/#comment-211774")[#strong[#text("Small ball probability and Inverse Littlewood-Offord theorems « Vuhavan's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")]

#text("[…] most elements of belong to the Minkowsky sum of few arithmetic progressions. (See this paper and this link for more details.) This result is strongly motivated by the famous Freiman Inverse theorem in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64496294e9dced8bc38362a1a7a491e8acd0e60b626eb615544667803350d3f6-ef8ada6ddac0095682ee474d452a5aa57aec035ebdf1d0a400aac63c9cd1b8cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D_809")]], [#link("https://terrytao.wordpress.com/2009/02/16/a-sharp-inverse-littlewood-offord-theorem/#comment-533406")[#strong[#text("D_809")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Dear Terry, do you have any pointers on this question: ")#link("https://mathoverflow.net/questions/348484/how-typical-are-integer-isometries-on-a-hypercube-littlewood-offord-problem-for")[#text("https://mathoverflow.net/questions/348484/how-typical-are-integer-isometries-on-a-hypercube-littlewood-offord-problem-for")]

#emph[#text("[I added a comment there – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64496294e9dced8bc38362a1a7a491e8acd0e60b626eb615544667803350d3f6-ef8ada6ddac0095682ee474d452a5aa57aec035ebdf1d0a400aac63c9cd1b8cf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D_809")]], [#link("https://terrytao.wordpress.com/2009/02/16/a-sharp-inverse-littlewood-offord-theorem/#comment-533464")[#strong[#text("D_809")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2019")])]

#text("Dear Terry, thank you very much! Since your comment answers everything I wanted to know, can you please post is as an answer so I can accept it?")
]
]
