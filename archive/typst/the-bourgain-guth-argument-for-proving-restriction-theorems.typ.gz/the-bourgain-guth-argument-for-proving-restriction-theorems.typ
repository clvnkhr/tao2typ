// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/
// Converted to Typst by tao2typ: "2026-10-14T16:36:24.685564+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Bourgain-Guth argument for proving restriction theorems", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Bourgain-Guth argument for proving restriction theorems")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 December 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/")[#text("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of my favourite unsolved problems in harmonic analysis is the ")#emph[#text("restriction problem")]#text(". This problem, first posed explicitly by Elias Stein, can take many equivalent forms, but one of them is this: one starts with a smooth compact hypersurface ")#mi("{S}")#text(" (possibly with boundary) in ")#mi("{{\\bf R}^d}")#text(", such as the unit sphere ")#mi("{S = S^2}")#text(" in ")#mi("{{\\bf R}^3}")#text(", and equips it with surface measure ")#mi("{d\\sigma}")#text(". One then takes a bounded measurable function ")#mi("{f \\in L^\\infty(S,d\\sigma)}")#text(" on this surface, and then computes the (inverse) Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\widehat{fd\\sigma}(x) = \\int_S e^{2\\pi i x \\cdot \\omega} f(\\omega) d\\sigma(\\omega)")]]

#text("of the measure ")#mi("{fd\\sigma}")#text(". As ")#mi("{f}")#text(" is bounded and ")#mi("{d\\sigma}")#text(" is a finite measure, this is a bounded function on ")#mi("{{\\bf R}^d}")#text("; from the dominated convergence theorem, it is also continuous. The restriction problem asks whether this Fourier transform also decays in space, and specifically whether ")#mi("{\\widehat{fd\\sigma}}")#text(" lies in ")#mi("{L^q({\\bf R}^d)}")#text(" for some ")#mi("{q < \\infty}")#text(". (This is a natural space to control decay because it is translation invariant, which is compatible on the frequency space side with the modulation invariance of ")#mi("{L^\\infty(S,d\\sigma)}")#text(".) By the ")#link("http://en.wikipedia.org/wiki/Closed_graph_theorem")[#text("closed graph theorem")]#text(", this is the case if and only if there is an estimate of the form ")#metadata(none) <tao-827ade3254c72ae81120>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| \\widehat{f d\\sigma} \\right\\|_{L^q({\\bf R}^d)} \\leq C_{q,d,S} \\left\\|f\\right\\|_{L^\\infty(S,d\\sigma)}", block: true)]]

#text("for some constant ")#mi("{C_{q,d,S}}")#text(" that can depend on ")#mi("{q,d,S}")#text(" but not on ")#mi("{f}")#text(". By a limiting argument, to provide such an estimate, it suffices to prove such an estimate under the additional assumption that ")#mi("{f}")#text(" is smooth.")

#text("Strictly speaking, the above problem should be called the ")#emph[#text("extension problem")]#text(", but it is dual to the original formulation of the ")#emph[#text("restriction problem")]#text(", which asks to find those exponents ")#mi("{1 \\leq q^{\\prime} \\leq \\infty}")#text(" for which the Fourier transform of an ")#mi("{L^{q^{\\prime}}({\\bf R}^d)}")#text(" function ")#mi("{g}")#text(" can be meaningfully restricted to a hypersurface ")#mi("{S}")#text(", in the sense that the map ")#mi("{g \\mapsto \\hat g|_{S}}")#text(" can be continuously defined from ")#mi("{L^{q^{\\prime}}({\\bf R}^d)}")#text(" to, say, ")#mi("{L^1(S,d\\sigma)}")#text(". A duality argument shows that the exponents ")#mi("{q^{\\prime}}")#text(" for which the restriction property holds are the dual exponents to the exponents ")#mi("{q}")#text(" for which the extension problem holds.")

#text("There are several motivations for studying the restriction problem. The problem is connected to the classical question of determining the nature of the convergence of various Fourier summation methods (and specifically, Bochner-Riesz summation); very roughly speaking, if one wishes to perform a partial Fourier transform by restricting the frequencies (possibly using a well-chosen weight) to some region ")#mi("{B}")#text(" (such as a ball), then one expects this operation to well behaved if the boundary ")#mi("{\\partial B}")#text(" of this region has good restriction (or extension) properties. More generally, the restriction problem for a surface ")#mi("{S}")#text(" is connected to the behaviour of Fourier multipliers whose symbols are singular at ")#mi("{S}")#text(". The problem is also connected to the analysis of various linear PDE such as the Helmholtz equation, Schro\\”dinger equation, wave equation, and the (linearised) Korteweg-de Vries equation, because solutions to such equations can be expressed via the Fourier transform in the form ")#mi("{fd\\sigma}")#text(" for various surfaces ")#mi("{S}")#text(" (the sphere, paraboloid, light cone, and cubic for the Helmholtz, Schrödinger, wave, and linearised Korteweg de Vries equation respectively). A particular family of restriction-type theorems for such surfaces, known as ")#emph[#text("Strichartz estimates")]#text(", play a foundational role in the nonlinear perturbations of these linear equations (e.g. the nonlinear Schrödinger equation, the nonlinear wave equation, and the Korteweg-de Vries equation). Last, but not least, there is a a fundamental connection between the restriction problem and the ")#link("http://en.wikipedia.org/wiki/Kakeya_set")[#text("Kakeya problem")]#text(", which roughly speaking concerns how tubes that point in different directions can overlap. Indeed, by superimposing special functions of the type ")#mi("{\\widehat{fd\\sigma}}")#text(", known as ")#emph[#text("wave packets")]#text(", and which are concentrated on tubes in various directions, one can “encode” the Kakeya problem inside the restriction problem; in particular, the conjectured solution to the restriction problem implies the conjectured solution to the Kakeya problem. Finally, the restriction problem serves as a simplified toy model for studying discrete exponential sums whose coefficients do not have a well controlled phase; this perspective was, for instance, used ")#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/???")[#text("by Ben Green")]#text(" when he established Roth’s theorem in the primes by Fourier-analytic methods, which was in turn one of the main inspirations for our later work establishing arbitrarily long progressions in the primes, although we ended up using ergodic-theoretic arguments instead of Fourier-analytic ones and so did not directly use restriction theory in that paper.")

#text("The estimate ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" is trivial for ")#mi("{q=\\infty}")#text(" and becomes harder for smaller ")#mi("{q}")#text(". The geometry, and more precisely the ")#emph[#text("curvature")]#text(", of the surface ")#mi("{S}")#text(", plays a key role: if ")#mi("{S}")#text(" contains a portion which is completely flat, then it is not difficult to concoct an ")#mi("{f}")#text(" for which ")#mi("{\\widehat{f d\\sigma}}")#text(" fails to decay in the normal direction to this flat portion, and so there are no restriction estimates for any finite ")#mi("{q}")#text(". Conversely, if ")#mi("{S}")#text(" is not infinitely flat at any point, then from the method of stationary phase, the Fourier transform ")#mi("{\\widehat{d\\sigma}}")#text(" can be shown to decay at a power rate at infinity, and this together with a standard method known as the ")#mi("{TT^*}")#text(" argument can be used to give non-trivial restriction estimates for finite ")#mi("{q}")#text(". However, these arguments fall somewhat short of obtaining the best possible exponents ")#mi("{q}")#text(". For instance, in the case of the sphere ")#mi("{S = S^{d-1} \\subset {\\bf R}^d}")#text(", the Fourier transform ")#mi("{\\widehat{d\\sigma}(x)}")#text(" is known to decay at the rate ")#tao-math("{O(\\left|x\\right|^{-(d-1)/2})}", block: false)#text(" and no better as ")#mi("{d \\rightarrow \\infty}")#text(", which shows that the condition ")#mi("{q > \\frac{2d}{d-1}}")#text(" is necessary in order for ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" to hold for this surface. The ")#emph[#text("restriction conjecture for ")#mi("{S^{d-1}}")]#text(" asserts that this necessary condition is also sufficient. However, the ")#mi("{TT^*}")#text("-based argument gives only the ")#link("http://www.ams.org/mathscinet-getitem?mr=358216")[#text("Tomas-Stein theorem")]#text(", which in this context gives ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" in the weaker range ")#mi("{q \\geq \\frac{2(d+1)}{d-1}}")#text(". (On the other hand, by the nature of the ")#mi("{TT^*}")#text(" method, the Tomas-Stein theorem does allow the ")#mi("{L^\\infty(S,d\\sigma)}")#text(" norm on the right-hand side to be relaxed to ")#mi("{L^2(S,d\\sigma)}")#text(", at which point the Tomas-Stein exponent ")#mi("{\\frac{2(d+1)}{d-1}}")#text(" becomes best possible. The fact that the Tomas-Stein theorem has an ")#mi("{L^2}")#text(" norm on the right-hand side is particularly valuable for applications to PDE, leading in particular to the Strichartz estimates mentioned earlier.)")

#text("Over the last two decades, there was a fair amount of work in pushing past the Tomas-Stein barrier. For sake of concreteness let us work just with the restriction problem for the unit sphere ")#mi("{S^2}")#text(" in ")#mi("{{\\bf R}^3}")#text(". Here, the restriction conjecture asserts that ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" holds for all ")#mi("{q > 3}")#text(", while the Tomas-Stein theorem gives only ")#mi("{q \\geq 4}")#text(". By combining a multiscale analysis approach with some new progress on the Kakeya conjecture, ")#link("http://www.ams.org/mathscinet-getitem?mr=1097257")[#text("Bourgain was able")]#text(" to obtain the first improvement on this range, establishing the restriction conjecture for ")#mi("{q > 4 - \\frac{2}{15}}")#text(". The methods were steadily refined over the years; until recently, the best result (")#link("http://www.ams.org/mathscinet-getitem?mr=2033842")[#text("due to myself")]#text(") was that the conjecture held for all ")#mi("{q > 3 \\frac{1}{3}}")#text(", which proceeded by analysing a “bilinear ")#mi("{L^2}")#text("” variant of the problem studied previously ")#link("http://www.ams.org/mathscinet-getitem?mr=1353448")[#text("by Bourgain")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1836285")[#text("by Wolff")]#text(". This is essentially the limit of that method; the relevant bilinear ")#mi("{L^2}")#text(" estimate fails for ")#mi("{q < 3 + \\frac{1}{3}}")#text(". (This estimate was recently established at the endpoint ")#mi("{q=3+\\frac{1}{3}}")#text(" by Jungjin Lee (personal communication), though this does not quite improve the range of exponents in ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" due to a logarithmic inefficiency in converting the bilinear estimate to a linear one.)")

#text("On the other hand, the full range ")#mi("{q>3}")#text(" of exponents in ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" was obtained by ")#link("http://www.ams.org/mathscinet-getitem?mr=2275834")[#text("Bennett, Carbery, and myself")]#text(" (with an alternate proof later ")#link("http://arxiv.org/abs/0811.2251")[#text("given by Guth")]#text("), but only under the additional assumption of ")#emph[#text("non-coplanar interactions")]#text(". In three dimensions, this assumption was enforced by replacing ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" with the weaker trilinear (and localised) variant ")#metadata(none) <tao-6cf7ea1cf658029f64c0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\widehat{f_1 d\\sigma_1} \\widehat{f_2 d\\sigma_2} \\widehat{f_3 d\\sigma_3} \\right\\|_{L^{q/3}(B(0,R))} \\leq C_{q,d,S_1,S_2,S_3,\\epsilon} R^\\epsilon", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\left\\|f_1\\right\\|_{L^\\infty(S_1,d\\sigma_1)} \\left\\|f_2\\right\\|_{L^\\infty(S_2,d\\sigma_2)} \\left\\|f_3\\right\\|_{L^\\infty(S_3,d\\sigma_3)}", block: true)]]

#text("where ")#mi("{\\epsilon>0}")#text(" and ")#mi("{R \\geq 1}")#text(" are arbitrary, ")#mi("{B(0,R)}")#text(" is the ball of radius ")#mi("{R}")#text(" in ")#mi("{{\\bf R}^3}")#text(", and ")#mi("{S_1,S_2,S_3}")#text(" are compact portions of ")#mi("{S}")#text(" whose unit normals ")#mi("{n_1(),n_2(),n_3()}")#text(" are never coplanar, thus there is a uniform lower bound")

#align(center)[#tao-fit-display[#tao-math("\\left|n_1(\\omega_1) \\wedge n_2(\\omega_2) \\wedge n_3(\\omega_3)\\right| \\geq c", block: true)]]

#text("for some ")#mi("{c>0}")#text(" and all ")#mi("{\\omega_1 \\in S_1, \\omega_2 \\in S_2, \\omega_3 \\in S_3}")#text(". If it were not for this non-coplanarity restriction, ")#link(<tao-6cf7ea1cf658029f64c0>)[#text("(2)")]#text(" would be equivalent to ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" (by setting ")#mi("{S_1=S_2=S_3}")#text(" and ")#mi("{f_1=f_2=f_3}")#text(", with the converse implication coming from Hölder’s inequality; the ")#mi("{R^\\epsilon}")#text(" loss can be removed by a lemma from ")#link("http://www.ams.org/mathscinet-getitem?mr=1666558")[#text("a paper of mine")]#text("). At the time we wrote this paper, we tried fairly hard to try to remove this non-coplanarity restriction in order to recover progress on the original restriction conjecture, but without much success.")

#text("A few weeks ago, though, ")#link("http://arxiv.org/abs/1012.3760")[#text("Bourgain and Guth")]#text(" found a new way to use multiscale analysis to “interpolate” between the result of Bennett, Carbery and myself (that has optimal exponents, but requires non-coplanar interactions), with a more classical square function estimate of Córdoba that handles the coplanar case. A direct application of this interpolation method already ties with the previous best known result in three dimensions (i.e. that ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" holds for ")#mi("{q > 3 \\frac{1}{3}}")#text("). But it also allows for the insertion of additional input, such as the best Kakeya estimate currently known in three dimensions, ")#link("http://www.ams.org/mathscinet-getitem?mr=1363209")[#text("due to Wolff")]#text(". This enlarges the range slightly to ")#mi("{q > 3.3}")#text(". The method also can extend to variable-coefficient settings, and in some of these cases (where there is so much “compression” going on that no additional Kakeya estimates are available) the estimates are best possible.")

#text("As is often the case in this field, there is a lot of technical book-keeping and juggling of parameters in the formal arguments of Bourgain and Guth, but the main ideas and “numerology” can be expressed fairly readily. (In mathematics, ")#emph[#text("numerology")]#text(" refers to the empirically observed relationships between various key exponents and other numerical parameters; in many cases, one can use shortcuts such as dimensional analysis or informal heuristic, to compute these exponents long before the formal argument is completely in place.) Below the fold, I would like to record this numerology for the simplest of the Bourgain-Guth arguments, namely a reproof of ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" for ")#mi("{p > 3 \\frac{1}{3}}")#text(". This is primarily for my own benefit, but may be of interest to other experts in this particular topic. (See also my ")#link("http://front.math.ucdavis.edu/math.CA/0311181")[#text("2003 lecture notes")]#text(" on the restriction conjecture.)")

#text("In order to focus on the ideas in the paper (rather than on the technical details), I will adopt an informal, heuristic approach, for instance by interpreting the uncertainty principle and the pigeonhole principle rather liberally, and by focusing on main terms in a decomposition and ignoring secondary terms. I will also be somewhat vague with regard to asymptotic notation such as ")#mi("{\\ll}")#text(". Making the arguments rigorous requires a certain amount of standard but tedious effort (and is one of the main reasons why the Bourgain-Guth paper is as long as it is), which I will not focus on here.")

#metadata(none) <tao-4a7dc4af041463cee958>

#heading(level: 1)[#strong[#text(" — 1. The Córdoba square function estimate — ")]]

#text("In two dimensions, the restriction theory is well understood, due to the work of Córdoba, Fefferman, and others. The situation is particularly simple when one looks at bilinear expressions such as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_1 F_2 \\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("where ")#mi("{F_1 :=\\widehat{f_1 d\\sigma_1}}")#text(", ")#mi("{F_2 := \\widehat{f_2 d\\sigma_2}}")#text(", and ")#mi("{d\\sigma_1, d\\sigma_2}")#text(" are surface measures on two smooth compact curves ")#mi("{S_1, S_2}")#text(" that are ")#emph[#text("transverse")]#text(" in the sense that the unit normals of ")#mi("{S_1}")#text(" are never oriented in the same direction as the unit normals of ")#mi("{S_2}")#text(". (A model case to consider here are two arcs of the unit circle, one near ")#mi("{(1,0)}")#text(" and one near ")#mi("{(0,1)}")#text(".) In this case, we can use Plancherel’s theorem to rewrite the above expression as a convolution")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_1 d\\sigma_1 * f_2 d\\sigma_2 \\right\\|_{L^2({\\bf R}^2)}.", block: true)]]

#text("The transversality of ")#mi("{S_1}")#text(" and ")#mi("{S_2}")#text(", combined with the inverse function theorem, shows that ")#mi("{f_1 d\\sigma_1 * f_2 d\\sigma_2}")#text(" is a non-degenerate pushforward of the tensor product ")#mi("{f_1 \\otimes f_2}")#text(", and so one obtains the basic bilinear restriction estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_1 F_2 \\right\\|_{L^2({\\bf R}^2)} \\ll \\left\\|f_1\\right\\|_{L^2(S_1,d\\sigma_1)} \\left\\|f_2\\right\\|_{L^2(S_2,d\\sigma_2)}.", block: true)]]

#text("This estimate (and higher-dimensional analogues thereof) lead to the ")#emph[#text("bilinear ")#mi("{X^{s,b}}")#text(" estimates")]#text(" which are of fundamental importance in nonlinear dispersive equations (particularly those in which the nonlinearity contains derivatives).")

#text("This bilinear estimate can be localised. Suppose one splits ")#mi("{S_1}")#text(" into arcs ")#mi("{S_{1,\\alpha}}")#text(" of diameter ")#mi("{\\sim 1/r}")#text(" for some ")#mi("{r \\gg 1}")#text(", which induces a decomposition ")#mi("{F_1 = \\sum_\\alpha F_{1,\\alpha}}")#text(" of ")#mi("{F_1}")#text(" into components ")#mi("{F_{1,\\alpha} := \\widehat{ f_1 1_{S_{1,\\alpha}} d\\sigma_1}}")#text(". Similarly decompose ")#mi("{F_2 = \\sum_\\beta F_{2,\\beta}}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("F_1 F_2 = \\sum_\\alpha \\sum_\\beta F_{1,\\alpha} F_{2,\\beta}.")]]

#text("The Fourier transform of ")#mi("{F_{1,\\alpha} F_{2,\\beta}}")#text(" is supported in the Minkowski sum ")#mi("{S_{1,\\alpha} + S_{2,\\beta}}")#text(". The transversality of ")#mi("{S_1, S_2}")#text(" ensures that these sums are basically disjoint as ")#mi("{\\alpha,\\beta}")#text(" varies, so by almost orthogonality one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_1 F_2 \\right\\|_{L^2({\\bf R}^2)} \\ll (\\sum_{\\alpha} \\sum_\\beta \\left\\| F_{1,\\alpha} F_{2,\\beta} \\right\\|_{L^2({\\bf R}^2)}^2)^{1/2}", block: true)]]

#text("or equivalently")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F_1 F_2 \\right\\|_{L^2({\\bf R}^2)} \\ll \\left\\| (\\sum_{\\alpha} \\left|F_{1,\\alpha}\\right|^2)^{1/2}) ( \\sum_\\beta \\left|F_{2,\\beta}\\right|^2)^{1/2} \\right\\|_{L^2({\\bf R}^2)}.", block: true)]]

#text("Actually, this estimate is morally localisable to balls ")#mi("{B(x,r)}")#text(" of radius ")#mi("{r}")#text("; heuristically, we have ")#metadata(none) <tao-985ad339c1fb307aba74>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| F_1 F_2 \\right\\|_{L^2(B(x,r))} \\ll \\left\\| (\\sum_{\\alpha} \\left|F_{1,\\alpha}\\right|^2)^{1/2}) ( \\sum_\\beta \\left|F_{2,\\beta}\\right|^2)^{1/2} \\right\\|_{L^2(B(x,r))}.", block: true)]]

#text("Informally, this is due to the uncertainty principle: localising in space to scale ")#mi("{r}")#text(" wouuld cause the arcs ")#mi("{S_{1,\\alpha}, S_{2,\\beta}}")#text(" in Fourier space to blur out at the scale ")#mi("{1/r}")#text(", but this will not significantly affect the almost disjointness of the Minkowski sums ")#mi("{S_{1,\\alpha} + S_{2,\\beta}}")#text(". (To make this rigorous, one would use a smoother cutoff than ")#mi("{1_{B(x,r)}}")#text(", and in particular it is convenient to use a cutoff which is compactly supported in Fourier space rather than physical space; we will not discuss these technicalities further here.)")

#text("Furthermore, the uncertainty principle suggests to us that ")#mi("{F_{1,\\alpha}}")#text(" and ")#mi("{F_{2,\\beta}}")#text(" are essentially constant on balls ")#mi("{B(x,r)}")#text(" of radius ")#mi("{r}")#text(". As such, the expression inside the norm on the right-hand side of ")#link(<tao-985ad339c1fb307aba74>)[#text("(3)")]#text(" is morally constant on such balls, which allows us to apply Hölder’s inequality and conclude that ")#metadata(none) <tao-140809994a8cfd58c684>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\| F_1 F_2 \\right\\|_{L^q(B(x,r))} \\ll \\left\\| (\\sum_{\\alpha} \\left|F_{1,\\alpha}\\right|^2)^{1/2}) ( \\sum_\\beta \\left|F_{2,\\beta}\\right|^2)^{1/2} \\right\\|_{L^q(B(x,r))}", block: true)]]

#text("for any ")#mi("{q \\leq 2}")#text(".")

#text("This is a bilinear estimate, but for heuristic purposes it is morally equivalent to the linear estimate ")#metadata(none) <tao-a5ad895656074bb12930>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| F \\right\\|_{L^q(B(x,r))} \\ll \\left\\| (\\sum_{\\alpha} \\left|F_{\\alpha}\\right|^2)^{1/2}) \\right\\|_{L^q(B(x,r))}", block: true)]]

#text("for ")#mi("{q \\leq 4}")#text(", where ")#mi("{F = \\widehat{f d\\sigma}}")#text(" and ")#mi("{d\\sigma}")#text(" is the surface measure on a curve ")#mi("{S}")#text(" which “exhibits curvature” and such that ")#mi("{F}")#text(" is “dominated by transverse interactions”, ")#mi("{F_\\alpha = \\widehat{f 1_{S_\\alpha} d\\sigma}}")#text(", and ")#mi("{S}")#text(" is partitioned into arcs ")#mi("{S_\\alpha}")#text(" of diameter ")#mi("{\\sim 1/r}")#text(". For the purposes of numerology, we will pretend that ")#link(<tao-a5ad895656074bb12930>)[#text("(5)")]#text(" is true as stated, though in practice one has to actually work with the bilinearisation ")#link(<tao-140809994a8cfd58c684>)[#text("(4)")]#text(" instead.")

#text("We remark that ")#link("http://www.ams.org/mathscinet-getitem?mr=688026")[#text("Córdoba used")]#text(" (a rigorous form of) ")#link(<tao-a5ad895656074bb12930>)[#text("(5)")]#text(" to establish the restriction conjecture ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" for curves in the plane (such as the unit circle) in the optimal range ")#mi("{q > 4}")#text(".")

#text("The estimate ")#link(<tao-a5ad895656074bb12930>)[#text("(5)")]#text(" is a two-dimensional one, but it can be stepped up to a three-dimensional estimate ")#metadata(none) <tao-11beec9fafc65d229ad8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| F \\right\\|_{L^q(B(x,r))} \\ll \\left\\| (\\sum_{\\alpha} \\left|F_{\\alpha}\\right|^2)^{1/2}) \\right\\|_{L^q(B(x,r))}", block: true)]]

#text("for ")#mi("{q \\leq 4}")#text(", where ")#mi("{F = \\widehat{f d\\sigma}}")#text(", ")#mi("{d\\sigma}")#text(" is now surface measure on the sphere ")#mi("{S^2 \\subset {\\bf R}^3}")#text(", which one decomposes into caps ")#mi("{S_\\alpha}")#text(" of diameter ")#mi("{O(1/r)}")#text(", ")#mi("{f}")#text(" is supported on the ")#mi("{O(1/r)}")#text("-neighbourhood of a great circle in ")#mi("{S^2}")#text(" with ")#mi("{F_\\alpha:= \\widehat{ f 1_{S_\\alpha} d\\sigma}}")#text(", and ")#mi("{F}")#text(" is “dominated by transverse interactions” in a sense that we will not quantify precisely here. This gives efficient control on ")#mi("{F}")#text(" in terms of square functions, but only in the “transverse coplanar case” in which the frequencies that dominate ")#mi("{F}")#text(" are both coplanar (in the sense that they all lie roughly on the same great circle) and transverse.")

#heading(level: 1)[#strong[#text(" — 2. The Bourgain-Guth argument — ")]]

#text("Now we sketch how the Bourgain-Guth argument works to establish ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(" for ")#mi("{q > \\frac{10}{3}}")#text(". Fix ")#mi("{q}")#text("; we may assume ")#mi("{q<4}")#text(". For each radius ")#mi("{R \\geq 1}")#text(", let ")#mi("{Q_R}")#text(" be the best constant in the local restriction estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F \\right\\|_{L^q(B(x,R))} \\leq Q_R \\left\\|f\\right\\|_{L^\\infty(S^2)}", block: true)]]

#text("where ")#mi("{F := \\widehat{f d\\sigma}}")#text(". To show ")#link(<tao-827ade3254c72ae81120>)[#text("(1)")]#text(", one has to show that ")#mi("{Q_R}")#text(" is bounded uniformly in ")#mi("{R}")#text(". Actually, thanks to an “epsilon removal lemma” that ")#link("http://www.ams.org/mathscinet-getitem?mr=1666558")[#text("I proved some time ago")]#text(" using a variant of the Tomas-Stein argument, it suffices to show that the logarithmic growth estimate ")#mi("{Q_R \\ll R^\\epsilon}")#text(" for any ")#mi("{\\epsilon > 0}")#text(".")

#text("An effective technique for achieving this is an ")#emph[#text("induction on scales")]#text(" argument, bounding ")#mi("{Q_R}")#text(" efficiently in terms of ")#mi("{Q_R}")#text(" for various scales ")#mi("{R^{\\prime}}")#text(" between ")#mi("{1}")#text(" and ")#mi("{R}")#text(". This technique was introduced ")#link("http://www.ams.org/mathscinet-getitem?mr=1097257")[#text("by Bourgain")]#text(", using the intermediate scale ")#mi("{R^{\\prime} := \\sqrt{R}}")#text(" (which is a natural scale for the purposes of approximating spherical caps by disks while still respecting the uncertainty principle). A subsequent ")#link("http://www.ams.org/mathscinet-getitem?mr=1836285")[#text("paper of Wolff")]#text(" adapted this argument by also relying on scales ")#mi("{R^{\\prime} = R^{1-\\epsilon}}")#text(" that were much closer to ")#mi("{R}")#text(". The Bourgain-Guth argument is closer in spirit to this latter approach.")

#text("Specifically, one sets ")#mi("{K := R^\\epsilon}")#text(" to be a small power of ")#mi("{R}")#text(", and divides the sphere ")#mi("{S^2}")#text(" into largish caps ")#mi("{S_\\alpha}")#text(" of radius ")#mi("{\\sim 1/K}")#text(", thus splitting ")#mi("{F = \\sum_\\alpha F_\\alpha}")#text(". At the same time, we cover ")#mi("{B(x,R)}")#text(" by smallish balls ")#mi("{B(y,K)}")#text(" of radius ")#mi("{K}")#text(". On each such ball ")#mi("{B(y,K)}")#text(", the functions ")#mi("{F_\\alpha}")#text(" are morally constant, as per the uncertainty principle. Of course, the amplitude of the ")#mi("{F_\\alpha}")#text(" on ")#mi("{B(y,K)}")#text(" depend on ")#mi("{\\alpha}")#text("; for each small ball ")#mi("{B(y,K)}")#text(", only a fraction of the ")#mi("{F_\\alpha}")#text(" will “dominate” the sum ")#mi("{F}")#text(". Roughly speaking, we can then sort the balls ")#mi("{B(y,K)}")#text(" into three classes:")

#enum(start: 1, 
[#text("(Non-coplanar case) There exist three dominant caps ")#mi("{S_\\alpha}")#text(" which do not lie within ")#mi("{O(1/K)}")#text(" of a great circle.")],
[#text("(Non-transverse case) All the dominant caps ")#mi("{S_\\alpha}")#text(" lie in a cap of size ")#mi("{o(1)}")#text(".")],
[#text("(Transverse coplanar case) All the dominant caps lie within ")#mi("{O(1/K)}")#text(" of a great circle, but at least two of them are at distance ")#mi("{\\sim 1}")#text(" from each other.")]
)

#text("In the first case, one can control ")#tao-math("{\\left\\| F \\right\\|_{L^q(B(y,K))}}", block: false)#text(" by ")#mi("{O(K^{O(1)})}")#text(" non-coplanar interactions of the form ")#tao-math("{\\left\\| F_1 F_2 F_3 \\right\\|_{L^{q/3}(B(y,K))}}", block: false)#text(", where ")#mi("{F_1, F_2, F_3}")#text(" are portions of ")#mi("{F}")#text(" on non-coplanar portions of the sphere ")#mi("{S^2}")#text(". In this case, one can use ")#link(<tao-6cf7ea1cf658029f64c0>)[#text("(2)")]#text(" and obtain a contribution of ")#mi("{O( K^{O(1)} ) = O(R^{O(\\epsilon)} )}")#text(" in this case.")

#text("It has been known for some time (since a ")#link("http://www.ams.org/mathscinet-getitem?mr=1625056")[#text("paper of myself, Vargas, and Vega")]#text(") that the non-transverse case can always be eliminated. Basically, if we group the caps ")#mi("{S_\\alpha}")#text(" into larger caps ")#mi("{\\tilde S_\\beta}")#text(" of radius ")#mi("{1/K^{\\prime} = o(1)}")#text(", and decompose ")#mi("{F = \\sum_\\beta \\tilde F_\\beta}")#text(" accordingly, then in the non-transverse case we can morally bound")

#align(center)[#tao-fit-display[#tao-math("\\left|F\\right| \\ll (\\sum_\\beta \\left|\\tilde F_{\\beta}\\right|^q)^{1/q}", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{L^q(B(x,R))} \\ll (\\sum_\\beta \\left\\|\\tilde F_{\\beta}\\right\\|_{L^q(B(x,R))}^q)^{1/q}.", block: true)]]

#text("However, a standard parabolic rescaling argument (which, strictly speaking, requires one to generalise the sphere to a larger family of similarly curved surfaces, but let us ignore this technical detail) shows that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\tilde F_{\\beta}\\right\\|_{L^q(B(x,R))} \\ll Q_{R/K^{\\prime}} (K^{\\prime})^{4/q-2}", block: true)]]

#text("and so (since there are ")#mi("{\\sim (K^{\\prime})^2}")#text(" large caps ")#mi("{\\tilde S_\\beta}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F\\right\\|_{L^q(B(x,R))} \\ll (K^{\\prime})^{6/q-2} Q_{R/K^{\\prime}}.", block: true)]]

#text("Since ")#mi("{q>3}")#text(", the exponent of ")#mi("{K^{\\prime}}")#text(" here is negative, and so this is a good term for the recurrence.")

#text("Finally, we deal with the transverse, coplanar case. Here, the main tool is the Córdoba-type square function estimate ")#link(<tao-11beec9fafc65d229ad8>)[#text("(6)")]#text(". Being coplanar, there are only about ")#mi("{O(K)}")#text(" caps ")#mi("{S_\\alpha}")#text(" that contribute here, so we can pay a factor of ")#mi("{O(K^{1/2 - 1/q})}")#text(" and convert the square function to a ")#mi("{\\ell^q}")#text("-function:")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F \\right\\|_{L^q(B(y,K))} \\ll K^{1/2 - 1/q} \\| (\\sum_{\\alpha} \\left|F_{\\alpha}\\right|^q)^{1/q}) \\|_{L^q(B(y,K))}.", block: true)]]

#text("Summing over all such balls, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\| F \\right\\|_{L^q(B(x,R))} \\ll K^{1/2 - 1/q} \\sum_{\\alpha} \\left\\|F_{\\alpha}\\right\\|_{L^q(B(x,R))}^q)^{1/q}).", block: true)]]

#text("Again, a parabolic rescaling gives")

#align(center)[#tao-fit-display[#tao-math("\\left\\|F_{\\alpha}\\right\\|_{L^q(B(x,R))} \\ll K^{4/q-2} Q_{R/K}", block: true)]]

#text("so the net contribution to ")#tao-math("{\\left\\|F\\right\\|_{L^q(B(x,R))}}", block: false)#text(" here is ")#mi("{O( K^{1/2 - 1/q} K^{6/q-2} Q_{R/K} )}")#text(". This leads to the recursion")

#align(center)[#tao-fit-display[#mitex("Q_R \\ll R^{O(\\epsilon)} + (K^{\\prime})^{6/q-2} Q_{R/K^{\\prime}} + K^{1/2 - 1/q} K^{6/q-2} Q_{R/K}.")]]

#text("For ")#mi("{q > 10/3}")#text(", the exponents of ")#mi("{K^{\\prime}}")#text(" and ")#mi("{K}")#text(" are negative, and this allows one to induct on scales and get the required bound ")#mi("{Q_R \\ll R^{O(\\epsilon)}}")#text(".")

#text("The argument given above is not optimal; the main inefficiency here is the factor of ")#mi("{O(K^{1/2-1/q})}")#text(" that one pays to convert the square function to the ")#mi("{\\ell^q}")#text(" function. This factor is only truly present if almost every cap ")#mi("{S_\\alpha}")#text(" along a great circle is genuinely contributing to ")#mi("{F}")#text(". However, one can use Kakeya estimates to prevent this event from happening too often. Indeed, thanks to the nature of parabolic scaling, the functions ")#mi("{F_\\alpha}")#text(" are not merely essentially constant on balls of radius ")#mi("{K}")#text(", but are in fact essentially constant on ")#mi("{K \\times K^2}")#text(" tubes oriented in the normal direction of ")#mi("{S_\\alpha}")#text(". One can use a Kakeya estimate (such as ")#link("http://www.ams.org/mathscinet-getitem?mr=1363209")[#text("Wolff’s Kakeya estimate")]#text(") to then prevent these tubes from congregating too often with too high of a multiplicity; quantifying this, Bourgain and Guth were able to relax the constraint ")#mi("{q > 10/3}")#text(" to ")#mi("{q > 3.3}")#text(". Unfortunately, there are still some residual inefficiencies, and even with the full Kakekya conjecture, the argument given in that paper only gets down to ")#mi("{3 \\frac{3}{11}}")#text(".")

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-49211")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2010")])]

#text("Dear Prof. Tao,")

#text("There is an historical question I have about the circle of ideas around the restriction problem, namely the decay estimates coming from stationary")#linebreak()#text(" phase that enter the proof of Strichartz estimates, say, for the Schrödinger and wave / Klein-Gordon operators. When were these decay estimates first proved, and by whom? The oldest reference I know of is a landmark paper on axiomatic quantum field theory due to David Ruelle:")

#text("– D. Ruelle, “On the Asymptotic Condition in Quantum Field Theory”.")#linebreak()#text(" Helvetica Physica Acta 35 (1962) 147-163.")

#text("He proves the aforementioned estimates for the wave and Klein-Gordon operators, with the purpose of constructing an axiomatic scattering theory for quantum fields following earlier ideas due to Rudolf Haag. As for the Schrödinger operator, I couldn’t track back to anything before Strichartz’s classic Duke Math. J. paper in ’75 and Hörmander’s paper on long range scattering theory (Math. Z. 146 (1976) 69-91). The first reference refers to")#linebreak()#text(" explicit formulae for Green functions in the first volume of Gel’fand-Shilov’s book on generalized functions, whereas the second seems to do everything from scratch.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-49220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2010")])]

#text("The earliest reference I know of is by Littman from 1963, ")#link("http://www.ams.org/mathscinet-getitem?mr=146521")[#text("http://www.ams.org/mathscinet-getitem?mr=146521")]#text(" , where he gives counterexamples to various L^p dispersive inequalities. Another early reference is Segal’s 1976 paper ")#link("http://www.ams.org/mathscinet-getitem?mr=492892")[#text("http://www.ams.org/mathscinet-getitem?mr=492892")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf535e2e2f8f081c7ea41f9a8d1a90fc556274255a131cf45066749d6fb24d7f-0272796322966bc66d3a685852efdadba6493a33fe71275d4d013a00f360f00b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-49238")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2010")])]

#text("Oh yes, I had forgotten Segal’s paper. I had seen Littman’s paper quoted in some lecture notes about Strichartz estimates, but only regarding some of the counterexamples you’ve mentioned – to wit, counterexamples to “energy-like” estimates in ")#mi("L^p")#text(" for ")#mi("p\\neq 2")#text(". Like Strichartz, Littman also seems to work with an explicit representation of Green’s functions for the wave operator.")

#text("Neither Segal’s paper, nor Littman’s, seem to give earlier references for the proof of ")#mi("L^1-L^\\infty")#text(" decay estimates using stationary phase, though, which form the other “interpolation tip”. It seems that Ruelle’s paper is the oldest reference with respect to this, after all – however, he was only interested in these decay estimates by themselves, and didn’t try to interpolate them with energy estimates.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaher")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-49218")[#strong[#text("Zaher")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2010")])]

#text("The left-hand side of the statement of the Bennet-Carbery-Tao result is written above as a product of norms rather than as the $L^{q/3}$ norm of the product.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyl")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-49335")[#strong[#text("Tyl")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2011")])]

#text("In the “A few weeks ago, though” paragraph, you seem to have switched to $p$ instead of $q$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b65250bb5838c66ca74ae006e465d2c97993d53ae65a1872331c95224125dbc-f63b062d12effd708db263692f4c9be00d3d9dc57248c9b85c47ece75e841b1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of science and math")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-49336")[#strong[#text("science and math")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2011")])]

#text("OOh!")#linebreak()#text(" Maths is very hard to get a grasp of!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-49338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2011")])]

#text("Minor formatting issue: The equation following “trilinear (and localised) variant” seems to get truncated (at least in firefox), so we loose the last term in the product on the right. Perhaps this could be fixed by spreading the inequality over two lines.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-50864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I’ve a question: Why in this article you don’t mention Burgain and Guth’s result for general n? I’m refering to the first theorem that appear in their preprint. I ask this question because maybe I don’t understand the right importance of their result.")#linebreak()#text(" Thank you for your attention.")#linebreak()#text(" A student")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-50875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2011")])]

#text("As I said in the blog post, I am focusing on the simplest of the Bourgain-Guth results, which is in three dimensions. The method extends to higher dimensions but is more intricate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-255982")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("I think there is a typo in the end of the Non-transverse case “the exponent of {K’} here is positive” should be negative,right?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-259687")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2013")])]

#text("Is equation (5) supposed to be exactly the same as equation (6)?")

#emph[#text("[The equations are the same, but the context is different: the various symbols in (5) are interpreted in a two-dimensional setting, while the symbols in (6) are interpreted in a three-dimensional one. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9b30b8a0ed3794bfdf0b0662e0ac485c382dc2bfb19751c61344950ec5584eb-ba38a22946d2a0d4bdbdbd10eb7d26334aae7767b9c195a45955994cf74b9fd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K Hughes")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-430613")[#strong[#text("K Hughes")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2014")])]

#text("In Bourgain–Demeter’s recent proof of the $\\ell^2$ decoupling conjecture, they make a comment, see the footnote at the bottom of page 2 in the arxiv preprint: ")#link("http://arxiv.org/abs/1403.5335")[#text("http://arxiv.org/abs/1403.5335")]#text(", that the Bennett–Carbery–Tao multilinear restriction theorem is ‘morally stronger’ than your bilinear restriction theorem. Why and how is this true?")

#text("Also, where does this sort of decoupling first appear?")

#text("Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-430696")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2014")])]

#text("The BCT estimate controls (the multilinear portion of) the quantity ")#tao-math("\\left\\| \\widehat{f d\\sigma} \\right\\|_{L^p({\\bf R}^n)}", block: false)#text(" for the optimal range of ")#mi("p")#text(" allowed by the restriction conjecture, namely ")#mi("p \\geq \\frac{2n}{n-1}")#text(" (see Theorem 6.1 of the Bourgain-Demeter paper). In contrast, my bilinear restriction estimate controls (the bilinear portion of) the same quantity, but only for exponents ")#mi("p \\geq \\frac{2(n+2)}{n}")#text(". On the other hand, the bilinear portion of ")#mi("\\widehat{f d\\sigma}")#text(" is a significantly larger chunk of that quantity than the multilinear portion; in particular, one can use rescaling arguments to directly deduce linear restriction estimates from bilinear ones, whilst the multilinear estimates are harder to use for this purpose (though it can be done, albeit usually with some loss in exponents, as discussed in this blog post). One nice feature of the Bourgain-Demeter paper is that they are able to exploit the multilinear inequality without having to lose more than an epsilon in the exponents, due to an efficient induction on scales.")

#text("As mentioned in the Bourgain-Demeter paper, decoupling estimates first appear in the work of Wolff, though not explicitly by this name.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Decoupling and the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-463393")[#strong[#text("Decoupling and the Bourgain-Demeter-Guth proof of the Vinogradov main conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2015")])]

#text("[…] We have the following nice equivalence (essentially due to Bourgain and Guth, building upon an earlier “bilinear equivalence” result of Vargas, Vega, and myself, and discussed in this previous blog post): […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-498596")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")])]

#text("I’m a bit confused with the argument at the beginning: How is the closed graph theorem used to get (1)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-498723")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 May 2018")])]

#text("The map ")#mi("f \\mapsto \\widehat{fd\\sigma}")#text(" is well defined as a continuous map from ")#mi("L^\\infty(S^d)")#text(" to (say) ")#mi("L^\\infty({\\bf R}^d)")#text(". If it in fact maps into ")#mi("L^q({\\bf R}^d)")#text(", it is easy to see that this map will be closed in the ")#mi("L^q")#text(" topology (this is basically because ")#mi("L^q")#text(" limits and ")#mi("L^\\infty")#text(" limits cannot disagree), and hence is bounded by the closed graph theorem.")

#text("I discuss the duality between restriction and extension operators in my lecture notes on the restriction problem at ")#link("https://arxiv.org/abs/math/0311181")[#text("https://arxiv.org/abs/math/0311181")]#text(" and ")#link("https://arxiv.org/abs/math/0303136")[#text("https://arxiv.org/abs/math/0303136")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-498597")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")])]

#text("I’m very interested in seeing more details of formulation of the problem: Would you elaborate what is the “duality argument” that connects the “restriction” and “extension” problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47b07b0e924fb9e38609b7487ce9b80c3720f3606af3bcabc4c590e673e13bb7-75d657cf630d92f0823177ab5f774a2ac9a2653c9d58131d469c1c29a601cb75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kathy Davis, University of Texas at Austin")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-505326")[#strong[#text("Kathy Davis, University of Texas at Austin")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2018")])]

#text("You might want to consider replaving the phrase “Tomas Stein restriction” with “L^2 restriction”, which is both more acvurate and avoids personal attributions. At the time I was working on restriction, I was reading Charles Fefferman’s Acta paper, and what I learned there had a devise impact on my proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-505522")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("My understanding is that the restriction theorems proven in the earlier Acta paper of Fefferman do not cover the full range ")#mi("q \\geq \\frac{2(d+1)}{d-1}")#text(" obtained by Tomas and Stein; I think they obtain ")#mi("q \\geq 6")#text(" in the ")#mi("d=2")#text(" case and ")#mi("q \\geq \\frac{4d}{d-1}")#text(" in the higher ")#mi("d")#text(" case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47b07b0e924fb9e38609b7487ce9b80c3720f3606af3bcabc4c590e673e13bb7-75d657cf630d92f0823177ab5f774a2ac9a2653c9d58131d469c1c29a601cb75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kathy Davis")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-506666")[#strong[#text("Kathy Davis")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2018")])]

#text("That isn”t the point; the Acta paper (as I recall it) began with a discussion of phases of the form i|x|^beta. This was on my mind when I looked at restriction. Charlie’s paper made it clear that keeping the phase as long as possible was important; I decided to do that by interchanging integrals. After that, well, the obvious thing was to complex interpolate on the index of the Bessel function. Unfortunately, I thought the function was analytic only down to J_0, and I got the wrong result. Again, reading from Charlie, I knew an alternative was to do partitions of unity.")

#text("we haven’t even begun to discuss the contributions of Herz, or Knapp (my thesis advisor).")

#text("The larger point is that results like this come from a community, not individuals. Charlie Fefferman and Eli Stein deserve more credit than I. I guess, as I get older, I prefer being part of a community than to have my name on something.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-592531")[#strong[#text("La serie que cambió el mundo – Info-spain")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")]

#text("[…] en vez de una suma y así sirve para funciones no periódicas, está bien definida cuando la restringimos a superficies como la esfera o el cono. El estudio de esta cuestión, aunque pueda parecer extremadamente específica y remota de otras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-592714")[#strong[#text("La serie que cambió el mundo » Mascarillas para protección del coronavirus")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")]

#text("[…] en vez de una suma y así sirve para funciones no periódicas, está bien definida cuando la restringimos a superficies como la esfera o el cono. El estudio de esta cuestión, aunque pueda parecer extremadamente específica y remota de otras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-592805")[#strong[#text("La serie que cambió el mundo – 24 Noticias")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2020")]

#text("[…] en vez de una suma y así sirve para funciones no periódicas, está bien definida cuando la restringimos a superficies como la esfera o el cono. El estudio de esta cuestión, aunque pueda parecer extremadamente específica y remota de otras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-594349")[#strong[#text("La serie que cambió el mundo - Noticias de Última Hora Nacionales e Internacionales Más Rápidas")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")]

#text("[…] en vez de una suma y así sirve para funciones no periódicas, está bien definida cuando la restringimos a superficies como la esfera o el cono. El estudio de esta cuestión, aunque pueda parecer extremadamente específica y remota de otras […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-594353")[#strong[#text("The series that changed the world – Pledge Times")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")]

#text("[…] integral instead of a sum and thus serves for non-periodic functions, it is well defined when the we restrict to surfaces such as the sphere or the cone. The study of this question, although it may seem extremely specific and remote from other areas, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-594379")[#strong[#text("La serie que cambió el mundo - Alicantur Noticias")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2020")]

#text("[…] en lugar de una suma y, por lo tanto, sirve funciones no periódicas, cuando está bien definido lo limitamos a superficies como esferas o conos. El estudio de este problema, aunque parece muy específico y alejado de otros campos, ha llamado […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7eeb955a96e17bf7bc3768a3f842e3f25bbeb4dd2ec8a8047af3cdf357940fd-5f5d26f7bb59cf66d7c83cc3a20c2a5601a2417d216bfb110f719cdf980c1c52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luyuf")]], [#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-608584")[#strong[#text("luyuf")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2020")])]

#text("Thanks a lot for the sharing. I have read the paper of Bougain and Guth you mentioned. And in the proof of the high dimension case(section 3 of the paper), they gave a lemma seems like the “m-linear discrete restriction estimate” to control the “coplane-transversal” case. I do not really understand what the lemma means, and the connection of the Cordoba square function estimate, and I also find when using the lemma in equation 4.20 of the paper, the integral domain miss the c over Uk, and this cannot move in the proof of lemma. So, do I misunderstand something? thanks for your time.")

#emph[#text("[Sorry, I do not understand your question (e.g., what is “c over Uk”, and what does it mean for it to “move”?). If you have a specific technical question about the Bourgain-Guth paper, you might contact Larry Guth about it. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/12/28/the-bourgain-guth-argument-for-proving-restriction-theorems/#comment-687653")[#strong[#text("Hong Wang and Joshua Zahl’s Solution for Kakeya’s Problem in Three Dimensions – Reflections and Links | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2025")]

#text("[…] The conjectural answer of the restriction problem would imply the Kakeya conjecture. Here is a blog post by Terry Tao on the restriction problem and lecture notes also by Tao, and here is a related […]")
]
