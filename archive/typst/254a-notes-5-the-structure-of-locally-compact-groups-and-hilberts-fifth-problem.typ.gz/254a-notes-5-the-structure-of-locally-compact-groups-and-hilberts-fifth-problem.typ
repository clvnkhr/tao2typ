// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:40.404759+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 5: The structure of locally compact groups, and Hilbert’s fifth problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 October 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/")[#text("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the previous notes, we established the ")#emph[#text("Gleason-Yamabe theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Gleason-Yamabe theorem)")]#text(" ")#metadata(none) <tao-e41d85d338bc53145d97>#text(" Let ")#mi("{G}")#text(" be a locally compact group. Then, for any open neighbourhood ")#mi("{U}")#text(" of the identity, there exists an open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" and a compact normal subgroup ")#mi("{K}")#text(" of ")#mi("{G^{\\prime}}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{G^{\\prime}/K}")#text(" is isomorphic to a Lie group.")
]

#text("Roughly speaking, this theorem asserts the “mesoscopic” structure of a locally compact group (after restricting to an open subgroup ")#mi("{G^{\\prime}}")#text(" to remove the macroscopic structure, and quotienting out by ")#mi("{K}")#text(" to remove the microscopic structure) is always of Lie type.")

#text("In this post, we combine the Gleason-Yamabe theorem with some additional tools from point-set topology to improve the description of locally compact groups in various situations.")

#text("We first record some easy special cases of this. If the locally compact group ")#mi("{G}")#text(" has the no small subgroups property, then one can take ")#mi("{K}")#text(" to be trivial; thus ")#mi("{G^{\\prime}}")#text(" is Lie, which implies that ")#mi("{G}")#text(" is locally Lie and thus Lie as well. Thus the assertion that all locally compact NSS groups are Lie (Theorem 10 from ")#link("https://terrytao.wordpress.com/2011/10/04/254a-notes-4-building-metrics-on-groups-and-the-gleason-yamabe-theorem/")[#text("Notes 4")]#text(") is a special case of the Gleason-Yamabe theorem.")

#text("In a similar spirit, if the locally compact group ")#mi("{G}")#text(" is connected, then the only open subgroup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" is the full group ")#mi("{G}")#text("; in particular, by arguing as in the treatment of the compact case (Exercise 19 of ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("Notes 3")]#text("), we conclude that any connected locally compact Hausdorff group is the inverse limit of Lie groups.")

#text("Now we return to the general case, in which ")#mi("{G}")#text(" need not be connected or NSS. One slight defect of Theorem ")#link(<tao-e41d85d338bc53145d97>)[#text("1")]#text(" is that the group ")#mi("{G^{\\prime}}")#text(" can depend on the open neighbourhood ")#mi("{U}")#text(". However, by using a basic result from the theory of totally disconnected groups known as ")#emph[#text("van Dantzig’s theorem")]#text(", one can make ")#mi("{G^{\\prime}}")#text(" independent of ")#mi("{U}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Gleason-Yamabe theorem, stronger version)")]#text(" ")#metadata(none) <tao-aaca07b9c4608e810616>#text(" Let ")#mi("{G}")#text(" be a locally compact group. Then there exists an open subgoup ")#mi("{G^{\\prime}}")#text(" of ")#mi("{G}")#text(" such that, for any open neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G^{\\prime}}")#text(", there exists a compact normal subgroup ")#mi("{K}")#text(" of ")#mi("{G^{\\prime}}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{G^{\\prime}/K}")#text(" is isomorphic to a Lie group.")
]

#text("We prove this theorem below the fold. As in previous notes, if ")#mi("{G}")#text(" is Hausdorff, the group ")#mi("{G^{\\prime}}")#text(" is thus an inverse limit of Lie groups (and if ")#mi("{G}")#text(" (and hence ")#mi("{G^{\\prime}}")#text(") is first countable, it is the inverse limit of a ")#emph[#text("sequence")]#text(" of Lie groups).")

#text("It remains to analyse inverse limits of Lie groups. To do this, it helps to have some control on the dimensions of the Lie groups involved. A basic tool for this purpose is the ")#link("http://en.wikipedia.org/wiki/Invariance_of_domain")[#text("invariance of domain theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Brouwer invariance of domain theorem)")]#text(" ")#metadata(none) <tao-e52da16bce3e0b1b8459>#text(" Let ")#mi("{U}")#text(" be an open subset of ")#mi("{{\\bf R}^n}")#text(", and let ")#mi("{f: U \\rightarrow {\\bf R}^n}")#text(" be a continuous injective map. Then ")#mi("{f(U)}")#text(" is also open.")
]

#text("We prove this theorem below the fold. It has an important corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (Topological invariance of dimension)")]#text(" ")#metadata(none) <tao-3f1970acc66289ecfd91>#text(" If ")#mi("{n > m}")#text(", and ")#mi("{U}")#text(" is a non-empty open subset of ")#mi("{{\\bf R}^n}")#text(", then there is no continuous injective mapping from ")#mi("{U}")#text(" to ")#mi("{{\\bf R}^m}")#text(". In particular, ")#mi("{{\\bf R}^n}")#text(" and ")#mi("{{\\bf R}^m}")#text(" are not homeomorphic.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1 (Uniqueness of dimension)")]#text(" ")#metadata(none) <tao-e5c77b7315048b259bac>#text(" Let ")#mi("{X}")#text(" be a non-empty topological space. If ")#mi("{X}")#text(" is a manifold of dimension ")#mi("{d_1}")#text(", and also a manifold of dimension ")#mi("{d_2}")#text(", show that ")#mi("{d_1=d_2}")#text(". Thus, we may define the dimension ")#mi("{\\text{dim}(X)}")#text(" of a non-empty manifold in a well-defined manner.")

#text("If ")#mi("{X, Y}")#text(" are non-empty manifolds, and there is a continuous injection from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(", show that ")#mi("{\\text{dim}(X) \\leq \\text{dim}(Y)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note that the analogue of the above exercise for surjections is false: the existence of a continuous surjection from one non-empty manifold ")#mi("{X}")#text(" to another ")#mi("{Y}")#text(" does ")#emph[#text("not")]#text(" imply that ")#mi("{\\text{dim}(X) \\geq \\text{dim}(Y)}")#text(", thanks to the existence of ")#link("http://en.wikipedia.org/wiki/Space-filling_curve")[#text("space-filling curves")]#text(". Thus we see that invariance of domain, while intuitively plausible, is not an entirely trivial observation.")
]

#text("As we shall see, we can use Corollary ")#link(<tao-3f1970acc66289ecfd91>)[#text("4")]#text(" to bound the dimension of the Lie groups ")#mi("{L_n}")#text(" in an inverse limit ")#mi("{G = \\lim_{n \\rightarrow \\infty} L_n}")#text(" by the “dimension” of the inverse limit ")#mi("{G}")#text(". Among other things, this can be used to obtain a positive resolution to Hilbert’s fifth problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Hilbert’s fifth problem)")]#text(" ")#metadata(none) <tao-1774b8eebdec58c5f119>#text(" Every locally Euclidean group is isomorphic to a Lie group.")
]

#text("Again, this will be shown below the fold.")

#text("Another application of this machinery is the following variant of Hilbert’s fifth problem, which was used in Gromov’s original proof of Gromov’s theorem on groups of polynomial growth, although we will not actually need it this course:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-496b750395e63342002c>#text(" Let ")#mi("{G}")#text(" be a locally compact ")#mi("{\\sigma}")#text("-compact group that acts transitively, faithfully, and continuously on a connected manifold ")#mi("{X}")#text(". Then ")#mi("{G}")#text(" is isomorphic to a Lie group.")
]

#text("Recall that a ")#link("http://en.wikipedia.org/wiki/Group_action")[#text("continuous action")]#text(" of a topological group ")#mi("{G}")#text(" on a topological space ")#mi("{X}")#text(" is a continuous map ")#mi("{\\cdot: G \\times X \\rightarrow X}")#text(" which obeys the associativity law ")#mi("{(gh)x = g(hx)}")#text(" for ")#mi("{g,h \\in G}")#text(" and ")#mi("{x \\in X}")#text(", and the identity law ")#mi("{1x = x}")#text(" for all ")#mi("{x \\in X}")#text(". The action is ")#emph[#text("transitive")]#text(" if, for every ")#mi("{x,y \\in X}")#text(", there is a ")#mi("{g \\in G}")#text(" with ")#mi("{gx=y}")#text(", and ")#emph[#text("faithful")]#text(" if, whenever ")#mi("{g, h \\in G}")#text(" are distinct, one has ")#mi("{gx \\neq hx}")#text(" for at least one ")#mi("{x}")#text(".")

#text("The ")#mi("{\\sigma}")#text("-compact hypothesis is a technical one, and can likely be dropped, but we retain it for this discussion (as in most applications we can reduce to this case).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that Proposition ")#link(<tao-496b750395e63342002c>)[#text("6")]#text(" implies Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("5")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" It is conjectured that the transitivity hypothesis in Proposition ")#link(<tao-496b750395e63342002c>)[#text("6")]#text(" can be dropped; this is known as the ")#link("http://en.wikipedia.org/wiki/Hilbert%E2%80%93Smith_conjecture")[#text("Hilbert-Smith conjecture")]#text(". It remains open; the key difficulty is to figure out a way to eliminate the possibility that ")#mi("{G}")#text(" is a ")#mi("{p}")#text("-adic group ")#mi("{{\\bf Z}_p}")#text(". See this ")#link("https://terrytao.wordpress.com/2011/08/13/the-hilbert-smith-conjecture/")[#text("previous blog post")]#text(" for further discussion.")
]

#metadata(none) <tao-37f9c823421805527c5f>

#heading(level: 1)[#strong[#text(" — 1. Van Dantzig’s theorem — ")]]

#text("Recall that a (non-empty) topological space ")#mi("{X}")#text(" is ")#link("http://en.wikipedia.org/wiki/Connected_space")[#text("connected")]#text(" if the only ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen")]#text(" (i.e. closed and open) subsets of ")#mi("{X}")#text(" are the whole space ")#mi("{X}")#text(" and the empty set ")#mi("{\\emptyset}")#text("; a non-empty topological space is ")#emph[#text("disconnected")]#text(" if it is not connected. (By convention, the empty set is considered to be neither connected nor disconnected, somewhat analogously to how the natural number ")#mi("{1}")#text(" is neither considered prime nor composite.)")

#text("At the opposite extreme to connectedness is the property of being a ")#link("http://en.wikipedia.org/wiki/Totally_disconnected_space")[#text("totally disconnected")]#text(" space. This is a space whose only connected subsets are the singleton sets. Typical examples of totally disconnected spaces include discrete spaces (e.g. the integers ")#mi("{{\\bf Z}}")#text(" with the discrete topology) and Cantor spaces (such as the standard Cantor set).")

#text("Most topological spaces are neither connected nor totally disconnected, but some intermediate combination of both. In the case of topological ")#emph[#text("groups")]#text(" ")#mi("{G}")#text(", this rather vague assertion can be formalised as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]

#list(
[#text("Define a ")#link("http://en.wikipedia.org/wiki/Connected_space")[#text("connected component")]#text(" of a topological space ")#mi("{X}")#text(" to be a maxmial connected set. Show that the connected components of ")#mi("{X}")#text(" form a partition of ")#mi("{X}")#text(", thus every point in ")#mi("{X}")#text(" belongs to exactly one connected component.")],
[#text("Let ")#mi("{G}")#text(" be a topological group, and let ")#mi("{G^\\circ}")#text(" be the connected component of the identity. Show that ")#mi("{G^\\circ}")#text(" is a closed normal subgroup of ")#mi("{G}")#text(", and that ")#mi("{G/G^\\circ}")#text(" is a totally disconnected subgroup of ")#mi("{G}")#text(". Thus, one has a ")#link("http://en.wikipedia.org/wiki/Short_exact_sequence")[#text("short exact sequence")]

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow G^\\circ \\rightarrow G \\rightarrow G/G^\\circ \\rightarrow 0")]]

#text("of topological groups that describes ")#mi("{G}")#text(" as an extension of a totally disconnected group by a connected group.")],
[#text("Conversely, if one has a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow H \\rightarrow G \\rightarrow K \\rightarrow 0")]]

#text("of topological groups, with ")#mi("{H}")#text(" connected and ")#mi("{K}")#text(" totally disconnected, show that ")#mi("{H}")#text(" is isomorphic to ")#mi("{G^\\circ}")#text(", and ")#mi("{K}")#text(" is isomorphic to ")#mi("{G/G^\\circ}")#text(".")],
[#text("If ")#mi("{G}")#text(" is locally compact, show that ")#mi("{G^\\circ}")#text(" and ")#mi("{G/G^\\circ}")#text(" are also locally compact.")]
)
]

#text("In principle at least, the study of locally compact groups thus splits into the study of connected locally compact groups, and the study of totally disconnected locally compact groups. (Note however that even if one has a complete understanding of the factors ")#mi("{H, K}")#text(" of a short exact sequence ")#mi("{0 \\rightarrow H \\rightarrow G \\rightarrow K \\rightarrow 0}")#text(", it may still be a non-trivial issue to fully understand the combined group ")#mi("{G}")#text(", due to the possible presence of non-trivial ")#link("http://en.wikipedia.org/wiki/Group_cohomology")[#text("group cohomology")]#text(". See for instance ")#link("https://terrytao.wordpress.com/2010/01/23/some-notes-on-group-extensions/")[#text("this previous blog post")]#text(" for more discussion.)")

#text("For totally disconnected locally compact groups, one has the following fundamental ")#link("http://www.ams.org/mathscinet-getitem?mr=1556954")[#text("theorem of van Dantzig’s")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Van Danztig’s theorem)")]#text(" ")#metadata(none) <tao-ac4df2dd11f78f0db766>#text(" Every totally disconnected locally compact group ")#mi("{G}")#text(" contains a compact open subgroup ")#mi("{H}")#text(" (which will of course still be totally disconnected).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{p}")#text(" be a prime. Then the ")#link("http://en.wikipedia.org/wiki/P-adic_number")[#mi("{p}")#text("-adic field")]#text(" ")#mi("{{\\bf Q}_p}")#text(" (with the usual ")#mi("{p}")#text("-adic valuation) is totally disconnected locally compact, and the ")#mi("{p}")#text("-adic integers ")#mi("{{\\bf Z}_p}")#text(" are a compact open subgroup.")
]

#text("Of course, this situation is the polar opposite of what occurs in the connected case, in which the only open subgroup is the whole group.")

#text("To prove van Dantzig’s theorem, we first need a lemma from point set topology, which shows that totally disconnected spaces contain enough ")#link("http://en.wikipedia.org/wiki/Clopen_set")[#text("clopen sets")]#text(" to separate points:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" ")#metadata(none) <tao-982945308d3682d16636>#text(" Let ")#mi("{X}")#text(" be a totally disconnected compact Hausdorff space, and let ")#mi("{x, y}")#text(" be distinct points in ")#mi("{X}")#text(". Then there exists a clopen set that contains ")#mi("{x}")#text(" but not ")#mi("{y}")#text(".")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{K}")#text(" be the intersection of all the clopen sets that contain ")#mi("{x}")#text(" (note that ")#mi("{X}")#text(" is obviously clopen). Clearly ")#mi("{K}")#text(" is closed and contains ")#mi("{x}")#text(". Our objective is to show that ")#mi("{K}")#text(" consists solely of ")#mi("{\\{x\\}}")#text(". As ")#mi("{X}")#text(" is totally disconnected, it will suffice to show that ")#mi("{K}")#text(" is connected.")

#text("Suppose this is not the case, then we can split ")#mi("{K = K_1 \\cup K_2}")#text(" where ")#mi("{K_1,K_2}")#text(" are disjoint non-empty closed sets; without loss of generality, we may assume that ")#mi("{x}")#text(" lies in ")#mi("{K_1}")#text(". As all compact Hausdorff spaces are ")#link("http://en.wikipedia.org/wiki/Normal_space")[#text("normal")]#text(", we can thus enclose ")#mi("{K_1, K_2}")#text(" in disjoint open subsets ")#mi("{U_1,U_2}")#text(" of ")#mi("{X}")#text(". In particular, the topological boundary ")#mi("{\\partial U_2}")#text(" is compact and lies outside of ")#mi("{K}")#text(". By definition of ")#mi("{K}")#text(", we thus see that for every ")#mi("{y \\in \\partial U_2}")#text(", we can find a clopen neighbourhood of ")#mi("{x}")#text(" that avoids ")#mi("{y}")#text("; by compactness of ")#mi("{\\partial U_2}")#text(" (and the fact that finite intersections of clopen sets are clopen), we can thus find a clopen neighbourhood ")#mi("{L}")#text(" of ")#mi("{x}")#text(" that is disjoint from ")#mi("{\\partial U_2}")#text(". One then verifies that ")#mi("{L \\backslash U_2 = L \\backslash \\overline{U_2}}")#text(" is a clopen neighbourhood of ")#mi("{x}")#text(" that is disjoint from ")#mi("{K_2}")#text(", contradicting the definition of ")#mi("{K}")#text(", and the claim follows. ")#mi("\\Box")

#text("Now we can prove van Dantzig’s theorem. We will use an argument from the ")#link("http://www.ams.org/mathscinet-getitem?mr=551496")[#text("book of Hewitt and Ross")]#text(". Let ")#mi("{G}")#text(" be totally disconnected locally compact (and thus Hausdorff). Then we can find a compact neighbourhood ")#mi("{K}")#text(" of the identity. By Lemma ")#link(<tao-982945308d3682d16636>)[#text("8")]#text(", for every ")#mi("{y \\in \\partial K}")#text(", we can find a clopen neighbourhood of the identity that avoids ")#mi("{y}")#text("; by compactness of ")#mi("{\\partial K}")#text(", we may thus find a clopen neighbourhood of the identity that avoids ")#mi("{\\partial K}")#text(". By intersecting this neighbourhood with ")#mi("{K}")#text(", we may thus find a compact clopen neighbourhood ")#mi("{F}")#text(" of the identity. As ")#mi("{F}")#text(" is both compact and open, we may then the continuity of the group operations find a symmetric neighbourhood ")#mi("{U}")#text(" of the identity such that ")#mi("{U F \\subset F}")#text(". In particular, if we let ")#mi("{G^{\\prime}}")#text(" be the group generated by ")#mi("{U}")#text(", then ")#mi("{G^{\\prime}}")#text(" is an open subgroup of ")#mi("{G}")#text(" contained in ")#mi("{F}")#text(" and is thus compact as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The same argument shows that a totally disconnected locally compact group contains arbitrarily small compact open subgroups, or in other words the compact open subgroups form a neighbourhood base for the identity.")
]

#text("In view of van Dantzig’s theorem, we see that the “local” behaviour of totally disconnected locally compact groups can be modeled by the compact totally disconnected groups, which are better understood. Thanks to the Gleason-Yamabe theorem for compact groups, such groups are the inverse limits of compact totally disconnected Lie groups. But it is easy to see that a compact totally disconnected Lie group must be finite, and so compact totally disconnected groups are necessarily ")#link("http://en.wikipedia.org/wiki/Profinite_group")[#text("profinite")]#text(". The global behaviour however remains more complicated, in part because the compact open subgroup given by van Dantzig’s theorem need not be normal, and so does not necessarily induce a splitting of ")#mi("{G}")#text(" into compact and discrete factors.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" ")#metadata(none) <tao-82e4f62b02330f8eb8a7>#text(" Let ")#mi("{p}")#text(" be a prime, and let ")#mi("{G}")#text(" be the semi-direct product ")#mi("{{\\bf Z} \\ltimes {\\bf Q}_p}")#text(", where the integers ")#mi("{{\\bf Z}}")#text(" act on ")#mi("{{\\bf Q}_p}")#text(" by the map ")#mi("{m: x \\mapsto p^m x}")#text(", and we give ")#mi("{G}")#text(" the product of the discrete topology of ")#mi("{{\\bf Z}}")#text(" and the ")#mi("{p}")#text("-adic topology on ")#mi("{{\\bf Q}_p}")#text(". One easily verifies that ")#mi("{G}")#text(" is a totally disconnected locally compact group. It certainly has compact open subgroups, such as ")#mi("{\\{0\\} \\times {\\bf Z}_p}")#text(". However, it is easy to show that ")#mi("{G}")#text(" has no non-trivial compact normal subgroups (the problem is that the conjugation action of ")#mi("{{\\bf Z}}")#text(" on ")#mi("{{\\bf Q}_p}")#text(" has all non-trivial orbits unbounded).")
]

#text("We can pull van Dantzig’s theorem back to more general locally compact groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" ")#metadata(none) <tao-c5f5571c2c9c437485d5>#text(" Let ")#mi("{G}")#text(" be a locally compact group.")

#list(
[#text("Show that ")#mi("{G}")#text(" contains an open subgroup ")#mi("{G^{\\prime}}")#text(" which is “compact-by-connected” in the sense that ")#mi("{G^{\\prime}/(G^{\\prime})^\\circ}")#text(" is compact. (")#emph[#text("Hint:")]#text(" apply van Dantzig’s theorem to ")#mi("{G/G^\\circ}")#text(".)")],
[#text("If ")#mi("{G}")#text(" is compact-by-connected, and ")#mi("{U}")#text(" is an open neighbourhood of the identity, show that there exists a compact subgroup ")#mi("{K}")#text(" of ")#mi("{G}")#text(" in ")#mi("{U}")#text(" such that ")#mi("{G/K}")#text(" is isomorphic to a Lie group. (")#emph[#text("Hint:")]#text(" use Theorem ")#link(<tao-e41d85d338bc53145d97>)[#text("1")]#text(", and observe that any open subgroup of the compact-by-connected group ")#mi("{G}")#text(" has finite index and thus has only finitely many conjugates.) Conclude Theorem ")#link(<tao-aaca07b9c4608e810616>)[#text("2")]#text(".")],
[#text("Show that any locally compact Hausdorff group ")#mi("{G}")#text(" contains an open subgroup ")#mi("{G^{\\prime}}")#text(" that is isomorphic to an inverse limit of Lie groups ")#mi("{(L_\\alpha)_{\\alpha \\in A}}")#text(", which each Lie group ")#mi("{L_\\alpha}")#text(" has at most finitely many connected components. Furthermore, each ")#mi("{L_\\alpha}")#text(" is isomorphic to ")#mi("{G^{\\prime}/K_\\alpha}")#text(" for some compact normal subgroup ")#mi("{K_\\alpha}")#text(" of ")#mi("{G^{\\prime}}")#text(", with ")#mi("{K_\\beta \\leq K_\\alpha}")#text(" for ")#mi("{\\alpha < \\beta}")#text(". If ")#mi("{G}")#text(" is first countable, show that this inverse limit can be taken to be a sequence (so that the index set ")#mi("{A}")#text(" is simply the natural numbers ")#mi("{{\\bf N}}")#text(" with the usual ordering), and the ")#mi("{K_n}")#text(" then shrink to zero in the sense that they lie inside any given open neighbourhood of the identity for ")#mi("{n}")#text(" large enough.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{G}")#text(" be a totally disconnected locally compact group. Show that every compact subgroup ")#mi("{K}")#text(" of ")#mi("{G}")#text(" is contained in a compact open subgroup. (")#emph[#text("Hint:")]#text(" van Dantzig’s theorem provides a compact open subgroup, but it need not contain ")#mi("{K}")#text(". But is there a way to modify it so that it is normalised by ")#mi("{K}")#text("? Why would being normalised by ")#mi("{K}")#text(" be useful?)")
]

#heading(level: 1)[#strong[#text(" — 2. The invariance of domain theorem — ")]]

#text("In this section we give a proof of the invariance of domain theorem. The main topological tool for this is ")#link("http://en.wikipedia.org/wiki/Brouwer_fixed_point_theorem")[#text("Brouwer’s famous fixed point theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Brouwer fixed point theorem)")]#text(" ")#metadata(none) <tao-992a93455c71fedd36ac>#text(" Let ")#mi("{f: B^n \\rightarrow B^n}")#text(" be a continuous function on the unit ball ")#tao-math("{B^n := \\{ x \\in {\\bf R}^n: \\left\\|x\\right\\| \\leq 1 \\}}", block: false)#text(" in a Euclidean space ")#mi("{{\\bf R}^n}")#text(". Then ")#mi("{f}")#text(" has at least one fixed point, thus there exists ")#mi("{x \\in B^n}")#text(" with ")#mi("{f(x)=x}")#text(".")
]

#text("This theorem has many proofs. We quickly sketch one of these proofs as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" For this exercise, suppose for sake of contradiction that Theorem ")#link(<tao-992a93455c71fedd36ac>)[#text("9")]#text(" is false, thus there is a continuous map from ")#mi("{B^n}")#text(" to ")#mi("{B^n}")#text(" with no fixed point.")

#list(
[#text("Show that there exists a ")#emph[#text("smooth")]#text(" map from ")#mi("{B^n}")#text(" to ")#mi("{B^n}")#text(" with no fixed point.")],
[#text("Show that there exists a smooth map from ")#mi("{B^n}")#text(" to the unit sphere ")#mi("{S^{n-1}}")#text(", which equals the identity function on ")#mi("{S^{n-1}}")#text(".")],
[#text("Show that there exists a smooth map ")#mi("{\\phi}")#text(" from ")#mi("{B^n}")#text(" to the unit sphere ")#mi("{S^{n-1}}")#text(", which equals the map ")#tao-math("{x \\mapsto \\frac{x}{\\left\\|x\\right\\|}}", block: false)#text(" on a neighbourhood of ")#mi("{S^{n-1}}")#text(".")],
[#text("By computing the integral ")#mi("{\\int_{B^n} \\text{det}( \\partial_1 \\phi, \\ldots, \\partial_n \\phi )}")#text(" in two different ways (one by using Stokes’ theorem, and the other by using the ")#mi("{n-1}")#text("-dimensional nature of the sphere ")#mi("{S^{n-1}}")#text("), establish a contradiction.")]
)
]

#text("Now we prove Theorem ")#link(<tao-e52da16bce3e0b1b8459>)[#text("3")]#text(". By rescaling and translation invariance, it will suffice to show the following claim:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 10 (Invariance of domain, again)")]#text(" ")#metadata(none) <tao-b4c9e14061c2fd453b36>#text(" Let ")#mi("{f: B^n \\rightarrow {\\bf R}^n}")#text(" be an continuous injective map. Then ")#mi("{f(0)}")#text(" lies in the interior of ")#mi("{f(B^n)}")#text(".")
]

#text("Let ")#mi("{f}")#text(" be as in Theorem ")#link(<tao-b4c9e14061c2fd453b36>)[#text("10")]#text(". The map ")#mi("{f: B^n \\rightarrow f(B^n)}")#text(" is a continuous bijection between compact Hausdorff spaces and is thus a homeomorphism. In particular, the inverse map ")#mi("{f^{-1}: f(B^n) \\rightarrow B^n}")#text(" is continuous. Using the ")#link("http://en.wikipedia.org/wiki/Tietze_extension_theorem")[#text("Tietze extension theorem")]#text(", we can find a continuous function ")#mi("{G: {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" that extends ")#mi("{f^{-1}}")#text(".")

#text("The function ")#mi("{G}")#text(" has a zero on ")#mi("{f(B^n)}")#text(", namely at ")#mi("{f(0)}")#text(". We can use the Brouwer fixed point theorem to show that this zero is stable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11 (Stability of zero)")]#text(" ")#metadata(none) <tao-c6508bd394398ac383f6>#text(" Let ")#mi("{\\tilde G: f(B^n) \\rightarrow {\\bf R}^n}")#text(" be a continuous function such that ")#tao-math("{\\left\\|G(y)-\\tilde G(y)\\right\\| \\leq 1}", block: false)#text(" for all ")#mi("{y \\in f(B^n)}")#text(". Then ")#mi("{\\tilde G}")#text(" has at least one zero (i.e. there is a ")#mi("{y \\in f(B^n)}")#text(" such that ")#mi("{\\tilde G(y)=0}")#text(").")
]

#emph[#text("Proof:")]#text(" Apply Theorem ")#link(<tao-992a93455c71fedd36ac>)[#text("9")]#text(" to the function")

#align(center)[#tao-fit-display[#mitex("x \\mapsto x - \\tilde G(f(x)) = G(f(x)) - \\tilde G(f(x)).")]]

#mi("\\Box")

#text("Now suppose that Theorem ")#link(<tao-b4c9e14061c2fd453b36>)[#text("10")]#text(" failed, so that ")#mi("{f(0)}")#text(" is not an interior point of ")#mi("{f(B^n)}")#text(". We will use this to locate a small perturbation of ")#mi("{G}")#text(" that no longer has a zero on ")#mi("{f(B^n)}")#text(", contradicting Lemma ")#link(<tao-c6508bd394398ac383f6>)[#text("11")]#text(".")

#text("We turn to the details. Let ")#mi("{\\epsilon > 0}")#text(" be a small number. By continuity of ")#mi("{G}")#text(", we see (if ")#mi("{\\epsilon}")#text(" is chosen small enough) that we have ")#tao-math("{\\left\\|G(y)\\right\\| \\leq 0.1}", block: false)#text(" whenever ")#mi("{y \\in {\\bf R}^n}")#text(" and ")#tao-math("{\\left\\|y-f(0)\\right\\| \\leq 2\\epsilon}", block: false)#text(".")

#text("On the other hand, since ")#mi("{f(0)}")#text(" is not an interior point of ")#mi("{f(B^n)}")#text(", there exists a point ")#mi("{c \\in {\\bf R}^n}")#text(" with ")#tao-math("{\\left\\|c-f(0)\\right\\| < \\epsilon}", block: false)#text(" that lies outside ")#mi("{f(B^n)}")#text(". By translating ")#mi("{f}")#text(" if necessary, we may take ")#mi("{c=0}")#text("; thus ")#mi("{f(B^n)}")#text(" avoids zero, ")#tao-math("{\\left\\|f(0)\\right\\| < \\epsilon}", block: false)#text(", and we have ")#metadata(none) <tao-0450a072a036895fa66a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\|G(y)\\right\\| \\leq 0.1 \\text{ whenever } \\left\\|y\\right\\| \\leq \\epsilon.", block: true)]]





#text("Let ")#mi("{\\Sigma}")#text(" denote the set ")#mi("{\\Sigma := \\Sigma_1 \\cup \\Sigma_2}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("\\Sigma_1 := \\{ y \\in f(B^n): \\left\\|y\\right\\| \\geq \\epsilon \\}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\Sigma_2 := \\{ y \\in {\\bf R}^n: \\left\\|y\\right\\| = \\epsilon \\}.", block: true)]]

#text("By construction, ")#mi("{\\Sigma}")#text(" is compact but does not contain ")#mi("{f(0)}")#text(". Crucially, there is a continuous map ")#mi("{\\Phi: f(B^n) \\rightarrow \\Sigma}")#text(" defined by setting ")#metadata(none) <tao-e46fd696bb4d24c149d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\Phi(y) := \\max( \\frac{\\epsilon}{\\left\\|y\\right\\|}, 1 ) y.", block: true)]]



#text(" Note that ")#mi("{\\Phi}")#text(" is continuous and well-defined since ")#mi("{f(B^n)}")#text(" avoids zero. Informally, ")#mi("{\\Sigma}")#text(" is a perturbation of ")#mi("{f(B^n)}")#text(" caused by pushing ")#mi("{f(B^n)}")#text(" out a small distance away from the origin ")#mi("{0}")#text(" (and hence also away from ")#mi("{f(0)}")#text("), with ")#mi("{\\Phi}")#text(" being the “pushing” map.")

#text("By construction, ")#mi("{G}")#text(" is non-zero on ")#mi("{\\Sigma_1}")#text("; since ")#mi("{\\Sigma_1}")#text(" is compact, ")#mi("{G}")#text(" is bounded from below on ")#mi("{\\Sigma_1}")#text(" by some ")#mi("{\\delta > 0}")#text(". By shrinking ")#mi("{\\delta}")#text(" if necessary we may assume that ")#mi("{\\delta < 0.1}")#text(".")

#text("By the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(", we can find a polynomial ")#mi("{P: {\\bf R}^n \\rightarrow {\\bf R}^n}")#text(" such that ")#metadata(none) <tao-f0b8c9d84dd2b877e0b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| P(y) - G(y) \\right\\| < \\delta", block: true)]]



#text(" for all ")#mi("{y \\in \\Sigma}")#text("; in particular, ")#mi("{P}")#text(" does not vanish on ")#mi("{\\Sigma_1}")#text(". At present, it is possible that ")#mi("{P}")#text(" vanishes on ")#mi("{\\Sigma_2}")#text(". But as ")#mi("{P}")#text(" is smooth and ")#mi("{\\Sigma_2}")#text(" has measure zero, ")#mi("{P(\\Sigma_2)}")#text(" also has measure zero; so by shifting ")#mi("{P}")#text(" by a small generic constant we may assume without loss of generality that ")#mi("{P}")#text(" also does not vanish on ")#mi("{\\Sigma_2}")#text(". (If one wishes, one can use an algebraic geometry argument here instead of a measure-theoretic one, noting that ")#mi("{P(\\Sigma_2)}")#text(" lies in an algebraic hypersurface and can thus be generically avoided by perturbation. A purely topological way to avoid zeroes in ")#mi("{\\Sigma_2}")#text(" is also given in ")#link("http://www.ams.org/mathscinet-getitem?mr=1696596")[#text("Kulpa’s paper")]#text(".)")

#text("Now consider the function ")#mi("{\\tilde G: f(B^n) \\rightarrow {\\bf R}^n}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("\\tilde G(y) := P( \\Phi( y ) ).")]]

#text("This is a continuous function that is never zero. From ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("(3)")]#text(", ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) - \\tilde G(y) \\right\\| < \\delta", block: true)]]

#text("whenever ")#mi("{y \\in f(B^n)}")#text(" is such that ")#tao-math("{\\left\\|y\\right\\| > \\epsilon}", block: false)#text(". On the other hand, if ")#tao-math("{\\left\\|y\\right\\| \\leq \\epsilon}", block: false)#text(", then from ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(2)")]#text(", ")#link(<tao-0450a072a036895fa66a>)[#text("(1)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) \\right\\|, \\left\\| G( \\Phi(y) ) \\right\\| \\leq 0.1", block: true)]]

#text("and hence by ")#link(<tao-f0b8c9d84dd2b877e0b9>)[#text("(3)")]#text(" and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) - \\tilde G(y) \\right\\| \\leq 0.2 + \\delta.", block: true)]]

#text("Thus in all cases we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| G(y) - \\tilde G(y) \\right\\| \\leq 0.2 + \\delta \\leq 0.3", block: true)]]

#text("for all ")#mi("{y \\in f(B^n)}")#text(". But this, combined with the non-vanishing nature of ")#mi("{\\tilde G}")#text(", contradicts Lemma ")#link(<tao-c6508bd394398ac383f6>)[#text("11")]#text(".")

#heading(level: 1)[#strong[#text(" — 3. Hilbert’s fifth problem — ")]]

#text("We now establish Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("5")]#text(". Let ")#mi("{G}")#text(" be a locally Euclidean group. By Exercise 5 of ")#link("https://terrytao.wordpress.com/2011/08/27/254a-notes-0-hilberts-fifth-problem-and-related-topics/")[#text("Notes 0")]#text(", ")#mi("{G}")#text(" is Hausdorff; it is also locally compact and first countable. Thus, by Exercise ")#link(<tao-c5f5571c2c9c437485d5>)[#text("4")]#text(", such a group contains an open subgroup ")#mi("{G^{\\prime}}")#text(" which is isomorphic to the inverse limit ")#mi("{\\lim_{n \\rightarrow \\infty} L_n}")#text(" of Lie groups ")#mi("{L_n}")#text(", each of which has only finitely many components. Clearly, ")#mi("{G^{\\prime}}")#text(" is also locally Euclidean. If it is Lie, then ")#mi("{G}")#text(" is locally Lie and thus Lie. Thus, by replacing ")#mi("{G}")#text(" with ")#mi("{G^{\\prime}}")#text(" if necessary, we may assume without loss of generality that ")#mi("{G}")#text(" is the inverse limit ")#mi("{G = \\lim_{n \\rightarrow \\infty} L_n}")#text(", each of which has only finitely many components.")

#text("By Exercise ")#link(<tao-c5f5571c2c9c437485d5>)[#text("4")]#text(", each ")#mi("{L_n}")#text(" is isomorphic to the quotient of ")#mi("{G}")#text(" by some compact normal subgroup ")#mi("{K_n}")#text(" with ")#mi("{K_{n+1} \\subset K_n}")#text(". In particular, ")#mi("{L_n}")#text(" is isomorphic to the quotient of ")#mi("{L_{n+1}}")#text(" by a compact normal subgroup ")#mi("{H_n \\equiv K_n/K_{n+1}}")#text(". By Cartan’s theorem (Theorem 2 of ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("Notes 2")]#text("), ")#mi("{H_n}")#text(" is also a Lie group. Among other things, this implies that the quotient homomorphism from the Lie algebra ")#mi("{{\\mathfrak l}_{n+1}}")#text(" of ")#mi("{L_{n+1}}")#text(" to the Lie algebra ")#mi("{{\\mathfrak l}_n}")#text(" of ")#mi("{L_n}")#text(" is surjective; indeed, it is the quotient map by the Lie algebra ")#mi("{{\\mathfrak h}_n}")#text(" of ")#mi("{H_n}")#text(". This implies that there is a continuous map from ")#mi("{{\\mathfrak l}_n}")#text(" to ")#mi("{{\\mathfrak l}_{n+1}}")#text(" that inverts the quotient map; in other words, we have a continuous map ")#mi("{\\eta_{n \\leftarrow n+1}: L(L_n) \\rightarrow L(L_{n+1})}")#text(" from the one-parameter subgroups ")#mi("{\\phi_n: {\\bf R} \\rightarrow L_n}")#text(" of ")#mi("{L_n}")#text(" to the one-parameter subgroups ")#mi("{\\phi_{n+1}: {\\bf R} \\rightarrow L_{n+1}}")#text(" of ")#mi("{L_{n+1}}")#text(", such that ")#mi("{\\eta_{n \\leftarrow n+1}(\\phi_n) \\mod H_n = \\phi_n}")#text(" for all ")#mi("{\\phi_n \\in L(L_n)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" By iterating these maps and passing to the inverse limit, conclude that for each ")#mi("{n \\in {\\bf N}}")#text(", there is a continuous map ")#mi("{\\eta_n: L(L_n) \\rightarrow L(G)}")#text(" such that ")#mi("{\\eta_n(\\phi_n) \\mod K_n = \\phi_n}")#text(" for all ")#mi("{\\phi_n \\in L(L_n)}")#text(".")
]

#text("Because ")#mi("{L_n}")#text(" is a Lie group, the exponential map ")#mi("{\\phi_n \\mapsto \\phi_n(1)}")#text(" is a homeomorphism from a neighbourhood of the origin in ")#mi("{L(L_n)}")#text(" to a neighbourhood of the identity in ")#mi("{L_n}")#text(". We can thus obtain a continuous map ")#mi("{\\phi_n(1) \\mapsto \\eta_n(\\phi_n)(1)}")#text(" from a neighbourhood of the identity in ")#mi("{L_n}")#text(" to ")#mi("{G}")#text(". Since ")#mi("{\\eta_n(\\phi_n)(1) \\mod K_n = \\phi_n(1)}")#text(", this map is injective.")

#text("Now we use the hypothesis that ")#mi("{G}")#text(" is locally Euclidean (and in particular, has a well-defined dimension ")#mi("{\\text{dim}(G)}")#text("). By Exercise ")#link(<tao-e5c77b7315048b259bac>)[#text("1")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(L_n) \\leq \\text{dim}(G)")]]

#text("for all ")#mi("{n}")#text(". On the other hand, since each ")#mi("{L_n}")#text(" is a quotient of the next Lie group ")#mi("{L_{n+1}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(L_n) \\leq \\text{dim}(L_{n+1}).")]]

#text("Since there are only finitely many possible values for the (necessarily integral) dimension ")#mi("{\\text{dim}(L_n)}")#text(" between ")#mi("{0}")#text(" and ")#mi("{\\text{dim}(G)}")#text(", we conclude that the dimension must eventually stabilise, i.e. one has")

#align(center)[#tao-fit-display[#mitex("\\text{dim}(L_n) = \\text{dim}(L_{n+1})")]]

#text("for all sufficiently large ")#mi("{n}")#text(". By discarding the first few terms in the sequence and relabeling, we may thus assume that the dimension is constant for ")#emph[#text("all")]#text(" ")#mi("{n}")#text(". Since ")#mi("{L_n \\equiv L_{n+1}/H_n}")#text(", this implies that the Lie groups ")#mi("{H_n}")#text(" have dimension zero for all ")#mi("{n}")#text(". As the ")#mi("{H_n}")#text(" are also compact, they are thus finite. Thus each ")#mi("{K_{n+1}}")#text(" is a finite extension of ")#mi("{K_n}")#text(". As ")#mi("{K_n}")#text(" is the inverse limit of the ")#mi("{K_n/K_m}")#text(" as ")#mi("{m \\rightarrow \\infty}")#text(", we conclude that ")#mi("{K_n}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Profinite_group")[#text("profinite group")]#text(", i.e. the inverse limit of finite groups. In particular, ")#mi("{K_n}")#text(" is totally disconnected.")

#text("We now study the short exact squence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow K_n \\rightarrow G \\rightarrow G_n \\rightarrow 0,")]]

#text("playing off the locally connected nature of the Lie group ")#mi("{G_n}")#text(" against the totally disconnected nature of ")#mi("{K_n}")#text(".")

#text("As discussed earlier, we have a continuous injective map ")#mi("{\\psi_n}")#text(" from a neighbourhood ")#mi("{U_n}")#text(" of the identity in ")#mi("{G_n}")#text(" to ")#mi("{G}")#text(" that partially inverts the quotient map. By translation, we may normalise ")#mi("{\\psi_n(1)=1}")#text(". As ")#mi("{G_n}")#text(" is locally connected, we can find a connected neighborhood ")#mi("{V_n}")#text(" of the identity in ")#mi("{G_n}")#text(" such that ")#mi("{(V_n \\cup V_n^{-1})^2 \\subset U_n}")#text(".")

#text("Now consider the set ")#mi("{\\{ \\psi_n(g) \\psi_n(g^{-1}): g \\in V_n \\}}")#text(". On the one hand, this set is contained in ")#mi("{K_n}")#text(" and contains ")#mi("{1}")#text("; on the other hand, it is connected. As ")#mi("{K_n}")#text(" is totally disconnected, this set must equal ")#mi("{\\{1\\}}")#text(", thus ")#mi("{\\psi_n(g^{-1}) = \\psi_n(g)^{-1}}")#text(" for all ")#mi("{g \\in V_n}")#text(". A similar argument based on consideration of the set ")#mi("{\\{ \\psi_n(g) \\psi_n(h) \\psi_n(gh)^{-1}: g,h \\in V_n \\}}")#text(" shows that ")#mi("{\\psi_n(gh) = \\psi_n(g) \\psi_n(h)}")#text(" for all ")#mi("{g \\in V_n}")#text(". Thus ")#mi("{\\psi_n}")#text(" is a homomorphism from the local group ")#mi("{V_n}")#text(" to ")#mi("{G}")#text(".")

#text("Finally, for any ")#mi("{k \\in K_n}")#text(", a consideration of the set ")#mi("{\\{ \\psi_n(g) k \\psi_n(g)^{-1}: g \\in V_n \\}}")#text(" reveals that ")#mi("{\\psi_n(g)}")#text(" commutes with ")#mi("{K_n}")#text(". As a consequence, we see that the preimage ")#mi("{\\pi_n^{-1}(V_n)}")#text(" of ")#mi("{V_n}")#text(" under the quotient map ")#mi("{\\pi_n: G \\rightarrow G_n}")#text(" is isomorphic as a local group to ")#mi("{V_n \\times K_n}")#text(", after identifying ")#mi("{\\psi_n(g) k}")#text(" with ")#mi("{(g,k)}")#text(" for any ")#mi("{g \\in V_n}")#text(" and ")#mi("{k \\in K_n}")#text(".")

#text("On the other hand, ")#mi("{G}")#text(" is locally Euclidean, and hence ")#mi("{V_n \\times K_n}")#text(" is locally Euclidean also, and in particular locally connected. This implies that ")#mi("{K_n}")#text(" is locally connected; but as ")#mi("{K_n}")#text(" is also totally disconnected, it must be discrete. This ")#mi("{G}")#text(" is now locally isomorphic to ")#mi("{V_n}")#text(" and hence to ")#mi("{G_n}")#text(", and is thus locally Lie and hence Lie as required. (Here, we say that two groups are ")#emph[#text("locally isomorphic")]#text(" if they have neighbourhoods of the identity which are isomorphic to each other as local groups.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let ")#mi("{G}")#text(" be a locally compact Hausdorff first-countable group which is “finite-dimensional” in the sense that it does not contain continuous injective images of non-trivial open sets of Euclidean spaces ")#mi("{{\\bf R}^n}")#text(" of arbitrarily large dimension. Show that ")#mi("{G}")#text(" is locally isomorphic to the direct product ")#mi("{L \\times K}")#text(" of a Lie group ")#mi("{L}")#text(" and a totally disconnected compact group ")#mi("{K}")#text(". (Note that this local isomorphism does not necessarily extend to a global isomorphism, as the example of the solenoid group ")#mi("{{\\bf R} \\times {\\bf Z}_p/{\\bf Z}^\\Delta}")#text(" shows.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Of course, it is possible for locally compact groups to be infinite-dimensional; a simple example is the infinite-dimensional torus ")#mi("{({\\bf R}/{\\bf Z})^{\\bf N}}")#text(", which is compact, abelian, metrisable, and locally connected, but infinite dimensional. (It will still be an inverse limit of Lie groups, though.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that a topological group is Lie if and only if it is locally compact, Hausdorff, first-countable, locally connected, and finite-dimensional.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" It is interesting to note that this characterisation barely uses the real numbers ")#mi("{{\\bf R}}")#text(", which are of course fundamental in defining the smooth structure of a Lie group; the only remaining reference to ")#mi("{{\\bf R}}")#text(" comes through the notion of finite dimensionality. It is also possible, using ")#link("http://en.wikipedia.org/wiki/Dimension_theory")[#text("dimension theory")]#text(", to obtain alternate characterisations of finite dimensionality (e.g. finite ")#link("http://en.wikipedia.org/wiki/Lebesgue_covering_dimension")[#text("Lebesgue covering dimension")]#text(") that avoid explicit mention of the real line, thus capturing the concept of a Lie group using only the concepts of point-set topology (and the concept of a group, of course).")
]

#heading(level: 1)[#strong[#text(" — 4. Transitive actions — ")]]

#text("We now prove Proposition ")#link(<tao-496b750395e63342002c>)[#text("6")]#text(". As this is a stronger statement than Theorem ")#link(<tao-1774b8eebdec58c5f119>)[#text("5")]#text(", it will not be surprising that we will be using a very similar argument to prove the result.")

#text("Let ")#mi("{G}")#text(" be a locally compact ")#mi("{\\sigma}")#text("-compact group that acts transitively, faithfully, and continuously on a connected manifold ")#mi("{X}")#text(". The advantage of transitivity is that one can now view ")#mi("{X}")#text(" as a homogeneous space ")#mi("{X=G/H}")#text(" of ")#mi("{G}")#text(", where ")#mi("{H = \\text{Stab}(x_0)}")#text(" is the stabiliser of a point ")#mi("{x_0}")#text(" (and is thus a closed subgroup of ")#mi("{G}")#text("). Note that ")#emph[#text("a priori")]#text(", we only know that ")#mi("{X}")#text(" and ")#mi("{G/H}")#text(" are identifiable as ")#emph[#text("sets")]#text(", with the identification map ")#mi("{\\iota: G/H \\rightarrow X}")#text(" defined by setting ")#mi("{\\iota( g H ) := g x_0}")#text(" being continuous; but thanks to the ")#mi("{\\sigma}")#text("-compact hypothesis, we can upgrade ")#mi("{\\iota}")#text(" to a homeomorphism. Indeed, as ")#mi("{G}")#text(" is ")#mi("{\\sigma}")#text("-compact, ")#mi("{G/H}")#text(" is also; and so given any compact neighbourhood of the identity ")#mi("{K}")#text(" in ")#mi("{G}")#text(", ")#mi("{G/H}")#text(" can be covered by countably many translates of ")#mi("{KH/H}")#text(". By the ")#link("http://en.wikipedia.org/wiki/Baire_category_theorem")[#text("Baire category theorem")]#text(", one of these translates ")#mi("{gK}")#text(" has an image ")#mi("{\\iota(gKH/H) = gKx_0}")#text(" in ")#mi("{X}")#text(" with non-empty interior, which implies that ")#mi("{K^{-1} K x_0}")#text(" has ")#mi("{x_0}")#text(" as an interior point. From this it is not hard to see that the map ")#mi("{\\iota}")#text(" is open; as it is also a continuous bijection, it is therefore a homeomorphism.")

#text("By the Gleason-Yamabe theorem (Theorem ")#link(<tao-aaca07b9c4608e810616>)[#text("2")]#text("), ")#mi("{G}")#text(" has an open subgroup ")#mi("{G^{\\prime}}")#text(" that is the inverse limit of Lie groups. (Note that ")#mi("{G}")#text(" is Hausdorff because it acts faithfully on the Hausdorff space ")#mi("{X}")#text(".) ")#mi("{G^{\\prime}}")#text(" acts transitively on ")#mi("{G^{\\prime}H/H}")#text(", which is an open subset of ")#mi("{G/H}")#text(" and thus also a manifold. Thus, we may assume without loss of generality that ")#mi("{G}")#text(" is itself the inverse limit of Lie groups.")

#text("As ")#mi("{G}")#text(" is ")#mi("{\\sigma}")#text("-compact, the manifold ")#mi("{X}")#text(" is also. As ")#mi("{G}")#text(" acts faithfully on ")#mi("{X}")#text(", this makes ")#mi("{G}")#text(" first countable; and so (by Exercise ")#link(<tao-c5f5571c2c9c437485d5>)[#text("4")]#text(") ")#mi("{G}")#text(" is the inverse limit of a ")#emph[#text("sequence")]#text(" of Lie groups ")#mi("{G_n = G/K_n}")#text(", with each ")#mi("{G_{n+1}}")#text(" projecting surjectively onto ")#mi("{G_n}")#text(", and with the ")#mi("{K_n}")#text(" shrinking to the identity.")

#text("Let ")#mi("{H_n}")#text(" be the projection of ")#mi("{H}")#text(" onto ")#mi("{G_n}")#text("; this is a closed subgroup of the Lie group ")#mi("{G_n}")#text(", and each ")#mi("{H_{n+1}}")#text(" projects surjectively onto ")#mi("{H_n}")#text(". Then ")#mi("{G_n/H_n}")#text(" are manifolds, and ")#mi("{G/H}")#text(" is the inverse limit of the ")#mi("{G_n/H_n = G / HK_n}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Show that the dimensions of the ")#mi("{G_n/H_n}")#text(" are be non-decreasing, and bounded above by the dimension of ")#mi("{G/H}")#text(". (")#emph[#text("Hint:")]#text(" repeat the arguments of the previous section. The ")#mi("{H_n}")#text(" need no longer be compact, but they are still closed, and this still suffices to make the preceding arguments go through.)")
]

#text("Thus, for ")#mi("{n}")#text(" large enough, the dimensions of ")#mi("{G_n/H_n}")#text(" must be constant; by renumbering, we may assume that ")#emph[#text("all")]#text(" the ")#mi("{G_n/H_n}")#text(" have the same dimension. As each ")#mi("{G_{n+1}/H_{n+1}}")#text(" is a cover of ")#mi("{G_n/H_n}")#text(" with structure group ")#mi("{K_n/K_{n+1}}")#text(", we conclude that the ")#mi("{K_n/K_{n+1}}")#text(" are zero-dimensional and compact, and thus finite. On the other hand, ")#mi("{G/H}")#text(" is locally connected, which implies that the ")#mi("{K_n/K_{n+1}}")#text(" are eventually trivial. Indeed, if we pick a simply connected neighbbourhood ")#mi("{U_1}")#text(" of the identity in ")#mi("{G_1/H_1}")#text(", then by local connectedness of ")#mi("{G/H}")#text(", there exists a connected neighbourhood ")#mi("{U}")#text(" of the identity in ")#mi("{G/H}")#text(" whose projection to ")#mi("{G_1/H_1}")#text(" is contained in ")#mi("{U_1}")#text(". Being open, ")#mi("{U}")#text(" must contain one of the ")#mi("{K_n}")#text(". If ")#mi("{K_n/K_m}")#text(" is non-trivial for any ")#mi("{m>n}")#text(", then the projection of ")#mi("{U}")#text(" to ")#mi("{G_m/H_m}")#text(" will then be disconnected (as this projection will be contained in a neighbourhood with the topological structure of ")#mi("{U \\times K_1/K_m}")#text(", and its intersection with the latter fibre is at least as large as ")#mi("{K_n/K_m}")#text(". We conclude that ")#mi("{K_n}")#text(" is trivial for ")#mi("{n}")#text(" large enough, and so ")#mi("{G = G_n}")#text(" is a Lie group as required.")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-91241")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2011")])]

#text("A comment and a questions:")

#text("1. Re Remark 5, I would say that, according to the definition of “finite dimensional” from Exercise 7, there is a lot of structure entering by the back door, namely something akin to rectifiability (statements about continuous images of euclidean spaces). Maybe related, the problem of defining rectifiability in sub-riemannian spaces (which are main examples of spaces non euclidean at any scale) is open, in the sense that there is no satisfactory definition of rectifiability for these spaces.")

#text("2. Question: In your Theorem 12 (Freiman’s type theorem) from your Notes 0, if you take ")#mi("G")#text(" to be the dyadic integers (or some noncommutative nilpotent like, but dyadic version), what could be the locally compact group generated by the said sequence of approximate groups, etc ?")

#text("Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-91259")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2011")])]

#text("I’m not sure what the “group of dyadic integers” is in Q2; also, to specify an approximate group, one needs to not just specify the ambient group G, but also a subset A of that group G obeying the approximate group axioms. So I don’t have enough information to answer your question.")

#text("If you mean G to be the additive group ")#mi("{\\bf Z}[\\frac{1}{2}]")#text(" of rationals whose denominator is a power of two, and let ")#mi("A")#text(" be the multiples of ")#mi("\\frac{1}{2^N}")#text(" between -1 and 1 for some large ")#mi("N")#text(", then this is an approximate group, and in the limit ")#mi("N \\to \\infty")#text(", the associated ultraproduct can be modeled by the interval ")#mi("[-1,1]")#text(" in the real line. But I don’t know if this is the type of example you have in mind.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marius Buliga")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-91420")[#strong[#text("Marius Buliga")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2011")])]

#text("Thank you for the reply. I don’t know your proof, but I am thinking about taking a group G which is not locally euclidean (say Q2 or nilpotent versions, easy to construct, or even some strange group a la Grigorchuk). Inside this group, maybe, you can choose a (sequence of?) approximate group(s) with two properties: first, the approximate group is big enough to feel (??) all the group G, second, you can tell exactly what is the locally euclidean group (say G’) which has inside a progression which is roughly equivalent with the approximate group.")#linebreak()#text(" The question is: is there any relation between G and G’? (like approximate morphism, or a functorial correspondence G-G’…)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4446c85e3613ea1aef783cdd2aaeed5d9f638867f5cdfb83371a8fd5eafdc802-4128d38439c3f262811511bc43edaa02d1195286a805d81c47cc20f3556adcce.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Neville")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-91250")[#strong[#text("Neville")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2011")])]

#text("“Roughly speaking, this theorem … of a locally group …”")

#text("locally compact group?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Models of ultra approximate groups « What’s new")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-97541")[#strong[#text("254A, Notes 7: Models of ultra approximate groups « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2011")])]

#text("[…] precompact neighbourhood of the identity such that . By the Gleason-Yamabe theorem (Theorem 1 of Notes 5), there is an open subgroup of , and a compact normal subgroup of contained in , such that is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-101248")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("In Exercise 8, I’m a little confused by the concept of “local isomorphism.” Do you mean that there is an open subset ")#mi("U")#text(" of ")#mi("G")#text(",a Lie Group ")#mi("L")#text(", a compact totally disconnected group ")#mi("K")#text(", and a homeomorphism ")#mi("\\phi\\colon L\\times K\\to U")#text(" such that ")#mi("\\phi(g),\\phi(h)")#text(", ")#mi("\\phi(g)^{-1}")#text(" are defined for all ")#mi("g,h\\in L\\times K")#text(" and equal ")#mi("\\phi(gh)")#text(", ")#mi("\\phi(g^{-1})")#text("? Or do you mean there are open subset ")#mi("U")#text(", ")#mi("V")#text(" of ")#mi("G")#text(", ")#mi("L\\times K")#text(" and a homeomorphism ")#mi("\\phi\\colon V\\to U")#text(" which respects multiplication and inversion (when it is defined).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-101252")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("I mean the latter; I’ll reword to clarify. (The example of the solenoid group from Notes 0 shows that the former is not true.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Hayes")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-101257")[#strong[#text("Ben Hayes")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2011")])]

#text("Okay, thanks It became clearer when I read the surrounding text.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea38b26efe23c05a469c4d4d5531d1fbf8907b6522c72cfd0beb2d22f747c950-31fe085c9d7656ecd214ac89214c70c495faf120628f35950ea22152196d6ab3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tomek Kania")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-427405")[#strong[#text("Tomek Kania")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2014")])]

#text("Let me point out a minor typo: “theorem of van Dantzig’s theorem”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf67d747b9c3fc2b143e521368ac97fc3f6460fa53a32b2efcd55480734bab72-62d5d5aa139d96892efc9188794512b28bd484142f29591f38bf0dbf1fdbcd8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeremy Brazas")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-483225")[#strong[#text("Jeremy Brazas")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2017")])]

#text("I’m glad I found this post. Thank you! Do you know of any path-connected examples of inverse limits of Lie groups that are non-trivial in the sense that they are not isomorphic to a Lie group or an infinite product of Lie groups? Connected examples like solenoids are abundant but are not path connected.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liam")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-633923")[#strong[#text("Liam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2021")])]

#text("You write “finite-dimensional in the sense that it does not contain continuous injective images of non-trivial open sets of Euclidean spaces Rn of arbitrarily large dimension.” Is it difficult to link this and the notions of dimensions of suitable topological spaces: lebesgue covering dimension, small inductive dimension or large inductive dimension ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/10/08/254a-notes-5-the-structure-of-locally-compact-groups-and-hilberts-fifth-problem/#comment-694171")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2026")])]

#text("“The map f: B^n → f(B^n) is a continuous bijection between compact Hausdorff spaces and is thus a homeomorphism”.")

#text("This proposition does not hold in general topological spaces, but when we restrict the topological spaces to a compact space and a Hausdorff space, the proposition turns out to be surprisingly true. My confusion is: why does merely imposing the compactness and Hausdorff conditions (also including the open mapping theorem) suffice to make a proposition that fails in general hold true?")
]
