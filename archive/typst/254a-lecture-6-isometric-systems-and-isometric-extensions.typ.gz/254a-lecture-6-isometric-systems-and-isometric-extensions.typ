// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/
// Converted to Typst by tao2typ: "2026-10-14T16:35:10.001657+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Lecture 6: Isometric systems and isometric extensions", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Lecture 6: Isometric systems and isometric extensions")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 January 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("In this lecture, we move away from recurrence, and instead focus on the ")#emph[#text("structure")]#text(" of topological dynamical systems. One remarkable feature of this subject is that starting from fairly “soft” notions of structure, such as topological structure, one can extract much more “hard” or “rigid” notions of structure, such as ")#emph[#text("geometric")]#text(" or ")#emph[#text("algebraic")]#text(" structure. The key concept needed to capture this structure is that of an ")#emph[#text("isometric system")]#text(", or more generally an ")#emph[#text("isometric extension")]#text(", which we shall discuss in this lecture. As an application of this theory we characterise the distribution of polynomial sequences in torii (a baby case of a variant of ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("Ratner’s theorem")]#text(" due ")#link("http://www.ams.org/mathscinet-getitem?mr=126504")[#text("to (Leon) Green")]#text(", which we will cover later in this course).")

#metadata(none) <tao-c06aacb3c63e2efad5f0>

#text("— Isometric systems —")

#text("We begin with a key definition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1")]#text(" (Equicontinuous and isometric systems). Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a topological dynamical system.")

#enum(start: 1, 
[#text("We say that the system is ")#emph[#text("isometric")]#text(" if there exists a metric d on X such that the shift maps ")#mi("T^n: X \\to X")#text(" are all ")#link("http://en.wikipedia.org/wiki/Isometry")[#text("isometries")]#text(", thus ")#mi("d(T^n x, T^n y) = d(x,y)")#text(" for all n and all x,y. (Of course, once T is an isometry, all powers ")#mi("T^n")#text(" are automatically isometries also, so it suffices to check the n=1 case.)")],
[#text("We say that the system is ")#emph[#text("equicontinuous")]#text(" if there exists a metric d on X such that the shift maps ")#mi("T^n: X \\to X")#text(" form a ")#link("http://en.wikipedia.org/wiki/Equicontinuity")[#text("uniformly equicontinuous")]#text(" family, thus for every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("\\delta > 0")#text(" such that ")#mi("d(T^n x, T^n y) \\leq \\varepsilon")#text(" whenever n, x, y are such that ")#mi("d(x,y) \\leq \\delta")#text(". (As X is compact, equicontinuity and uniform equicontinuity are equivalent concepts.)")]
)
]

#strong[#text("Example 1. ")]#text("The circle shift ")#mi("x \\mapsto x+\\alpha")#text(" on ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" is both isometric and equicontinuous. On the other hand, the Bernoulli shift on ")#mi("\\{0,1\\}^{\\Bbb Z}")#text(" is neither isometric nor equicontinuous (why?). ")#mi("\\diamond")

#strong[#text("Example 2.")]#text(" Any finite dynamical system is both isometric and equicontinuous (as one can see by using the ")#link("http://en.wikipedia.org/wiki/Discrete_metric")[#text("discrete metric")]#text("). ")#mi("\\diamond")

#text("Since all metrics are essentially equivalent, we see that the choice of metric is not actually important when checking equicontinuity, but it seems to be more important when checking for isometry. Nevertheless, there is actually no distinction between the two properties:")

#strong[#text("Exercise 1")]#text(". Show that a topological dynamical system is isometric if and only if it is equicontinuous. (Hint: one direction is obvious. For the other, if ")#mi("T^n")#text(" is a uniformly equicontinuous family with respect to a metric d, consider the modified metric ")#mi("\\tilde d(x,y) := \\sup_n d(T^n x, T^n y)")#text(".) ")#mi("\\diamond")

#strong[#text("Remark 1.")]#text(" From this exercise we see that we can upgrade ")#emph[#text("topological")]#text(" structure (equicontinuity) to ")#emph[#text("geometric")]#text(" structure (isometry). The motif of studying topology through geometry pervades modern topology; witness for instance Perelman’s proof of the Poincaré conjecture. ")#mi("\\diamond")

#strong[#text("Exercise 2")]#text(". (Ultrafilter characterisation of equicontinuity) Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a topological dynamical system. Show that X is equicontinuous if and only if the maps ")#mi("T^p: X \\to X")#text(" are homeomorphisms for every ")#mi("p \\in \\beta {\\Bbb Z}")#text(". ")#mi("\\diamond")

#text("Now we upgrade the geometric structure of isometry to the ")#emph[#text("algebraic ")]#text("structure of being a compact abelian group action.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2.")]#text(" (Kronecker system) A topological dynamical system ")#mi("(X,{\\mathcal F},T)")#text(" is said to be a ")#emph[#text("Kronecker system")]#text(" if it is isomorphic to a system of the form ")#mi("(K, {\\mathcal K}, S)")#text(", where ")#mi("(K,+,{\\mathcal K})")#text(" is a compact abelian metrisable ")#link("http://en.wikipedia.org/wiki/Topological_group")[#text("topological group")]#text(", and ")#mi("S: x \\mapsto x + \\alpha")#text(" is a group rotation for some ")#mi("\\alpha \\in K")#text(".")
]

#strong[#text("Example 3.")]#text(" The circle rotation system is a Kronecker system, as is the standard shift ")#mi("x \\mapsto x+1")#text(" on a cyclic group ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(". Any product of Kronecker systems is again a Kronecker system. ")#mi("\\diamond")

#text("Let us first observe that a Kronecker system is equicontinuous (and hence isometric). Indeed, the compactness of the topological group K (and the joint continuity of the addition law ")#mi("+: K \\times K \\to K")#text(") easily ensures that the group rotations ")#mi("g: x \\mapsto x+g")#text(" are uniformly equicontinuous as ")#mi("g \\in K")#text(" varies. Since the shifts ")#mi("T^n: x \\mapsto x+n\\alpha")#text(" are all group rotations, the claim follows.")

#text("On the other hand, not every equicontinuous or isometric system is Kronecker. Consider for instance a finite dynamical system which is the disjoint union of two cyclic shifts of distinct order; it is not hard to see that this is not a Kronecker system. Nevertheless, it clearly contains Kronecker systems within it. Indeed, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1. ")]#text("Every ")#emph[#text("minimal")]#text(" equicontinuous (or isometric) system ")#mi("(X, {\\mathcal F}, T)")#text(" is a Kronecker system, i.e. isomorphic to an abelian group rotation ")#mi("(K, {\\mathcal K}, x \\mapsto x+\\alpha)")#text(". Furthermore, the orbit ")#mi("\\{ n\\alpha: n \\in {\\Bbb Z}\\}")#text(" is dense in K.")
]

#strong[#text("Proof.")]#text(" By Exercise 1, we may assume that the system is isometric, thus we can find a metric d such that all the shift maps ")#mi("T^n")#text(" are isometries. We view the ")#mi("T^n")#text(" as lying inside the space ")#mi("C(X \\to X)")#text(" of continuous maps from X to itself, endowed with the ")#link("http://en.wikipedia.org/wiki/Uniform_convergence")[#text("uniform topology")]#text(". Let ")#mi("G \\subset C(X \\to X)")#text(" be the closure of the maps ")#mi("\\{ T^n: n \\in {\\Bbb Z} \\}")#text(". One easily verifies that G is a closed metrisable topological group of isometries in ")#mi("C(X \\to X)")#text("; from the ")#link("http://en.wikipedia.org/wiki/Arzela-Ascoli_theorem")[#text("Arzelà-Ascoli theorem")]#text(" we see that G is compact. Also, since ")#mi("T^n")#text(" and ")#mi("T^m")#text(" commute for every n and m, we see upon taking limits that G is abelian.")

#text("Now let ")#mi("x \\in X")#text(" be an arbitrary point. Then we see that the image ")#mi("\\{ f(x): f \\in G \\}")#text(" of G under the evaluation map ")#mi("f \\mapsto f(x)")#text(" is a compact non-empty invariant subset of X, and thus equal to all of X by minimality. If we then define the stabiliser ")#mi("\\Gamma := \\{ f \\in G: f(x) = x \\}")#text(", we see that ")#mi("\\Gamma")#text(" is a closed (hence compact) subgroup of the abelian group G. Since ")#mi("X = \\{ f(x): f \\in G \\}")#text(", we thus see that there is a continuous bijection ")#mi("f \\Gamma \\mapsto f(x)")#text(" from the quotient group ")#mi("K := G/\\Gamma")#text(" (with the ")#link("http://en.wikipedia.org/wiki/Quotient_topology")[#text("quotient topology")]#text(") to X. Since both spaces here are compact Hausdorff, this map is a homeomorphism. This map is thus an isomorphism of topological dynamical systems between the Kronecker system K (with the group rotation given by ")#mi("\\alpha := T \\mod \\Gamma \\in G/\\Gamma")#text(") and X. Since K is a compact metrisable (thanks to ")#link("http://en.wikipedia.org/wiki/Hausdorff_distance")[#text("Hausdorff distance")]#text(") topological group, the claim follows (relabeling the group operation as +). Note that the density of ")#mi("\\{n\\alpha: n \\in {\\Bbb Z}\\}")#text(" in K is clear from construction. ")#mi("\\Box")

#strong[#text("Remark 2. ")]#text(" Once one knows that X is homeomorphic to a Kronecker system with ")#mi("\\{ n \\alpha: n \\in {\\Bbb Z} \\}")#text(" dense, one can ")#emph[#text("a posteriori")]#text(" return to the proof and conclude that the stabiliser ")#mi("\\Gamma")#text(" is trivial. But I do not see a way to establish that fact directly. In any case, when we move to isometric extensions below, the analogue of the stabiliser ")#mi("\\Gamma")#text(" can certainly be non-trivial. ")#mi("\\diamond")

#text("To get from minimal isometric systems to non-minimal isometric systems, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" Any isometric system ")#mi("(X, {\\mathcal F}, T)")#text(" can be partitioned as the union of disjoint minimal isometric systems.")
]

#strong[#text("Proof.")]#text(" Since minimal systems are automatically disjoint, it suffices to show that every point ")#mi("x \\in X")#text(" is contained in a minimal dynamical system, or equivalently that the orbit closure ")#mi("\\overline{T^{\\Bbb Z} x}")#text(" is minimal. If this is not the case, then there exists ")#mi("y \\in \\overline{T^{\\Bbb Z} x}")#text(" such that x does not lie in the orbit closure of y. But by definition of orbit closure, we can find a sequence ")#mi("n_j")#text(" such that ")#mi("T^{n_j} x")#text(" converges to y. By the isometry property, this implies that ")#mi("T^{-n_j} y")#text(" converges to x, and so x is indeed in the orbit closure of y, a contradiction. ")#mi("\\Box")

#text("Thus every equicontinuous or isometric system can be expressed as a union of disjoint Kronecker systems.")

#text("We can use the algebraic structure of isometric systems to obtain much quicker (and slightly stronger) proofs of various recurrence theorems. For instance, we can give a short proof of (a slight strengthening of) the multiple Birkhoff recurrence theorem (Theorem 3 from ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("Lecture 4")]#text(") as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3")]#text(". (Multiple Birkhoff for isometric systems) Let ")#mi("(X, {\\mathcal F}, T)")#text(" be an isometric system. Then for every ")#mi("x \\in X")#text(" there exists a sequence ")#mi("n_j \\to \\infty")#text(" such that ")#mi("T^{kn_j} x \\to x")#text(" for every integer k.")
]

#strong[#text("Proof.")]#text(" By Proposition 2 followed by Proposition 1, it suffices to check this for Kronecker systems ")#mi("(K, {\\mathcal K}, x \\mapsto x+\\alpha)")#text(" in which ")#mi("\\{n\\alpha: n \\in {\\Bbb Z}\\}")#text(" is dense in K. But then we can find a sequence ")#mi("n_j")#text(" such that ")#mi("n_j \\alpha \\to 0")#text(" in K, and thus (since K is a topological group) ")#mi("k n_j \\alpha \\to 0")#text(" in K for all k. The claim follows. ")#mi("\\Box")

#text("The above argument illustrates one of the reasons why it is desirable to have an algebraic structural theory of various types of dynamical systems; it makes it much easier to answer many interesting questions regarding such systems, such as those involving recurrence.")

#heading(level: 1)[#text("— The Kronecker factor —")]

#text("We have seen isometric systems are basically Kronecker systems (or unions thereof). Of course, not all systems are isometric. However, it turns out that every system contains a maximal isometric ")#emph[#text("factor")]#text(". Recall that a factor of a topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(" is a surjective morphism ")#mi("\\pi: X \\to Y")#text(" from X to another topological dynamical system ")#mi("(Y, {\\mathcal G}, S)")#text(". (We shall sometimes abuse notation and refer to ")#mi("\\pi: X \\to Y")#text(" as the factor, when it is really the quadruplet ")#mi("(\\pi, Y, {\\mathcal G}, S)")#text(".) We say that one factor ")#mi("\\pi: X \\to Y")#text(" ")#emph[#text("refines")]#text(" or is ")#emph[#text("finer than")]#text(" another factor ")#mi("\\pi^{\\prime}: X \\to Y^{\\prime}")#text(" if we can factorise ")#mi("\\pi^{\\prime} = f \\circ \\pi")#text(" for some continuous map ")#mi("f: Y \\to Y^{\\prime}")#text(". (Note from surjectivity that this map, if it exists, is unique.) We say that two factors are ")#emph[#text("equivalent")]#text(" if they refine each other. Observe that modulo equivalence, refinement is a partial ordering on factors.")

#strong[#text("Example 4.")]#text(" The identity factor ")#mi("\\text{id}: X \\to X")#text(" is finer than any other factor of X, which in turn is finer than the trivial factor ")#mi("\\text{pt}: X \\to \\text{pt}")#text(" that maps to a point. ")#mi("\\diamond")

#strong[#text("Exercise 3.")]#text(" Show that any factor of a minimal topological dynamical system is again minimal. ")#mi("\\diamond")

#text("We note two useful operations on factors. Firstly, given two factors ")#mi("\\pi: X \\to Y = Y")#text(" and ")#mi("\\pi^{\\prime}: X \\to Y^{\\prime}")#text(", one can define their ")#link("http://en.wikipedia.org/wiki/Join_%28mathematics%29")[#text("join")]#text(" ")#mi("\\pi \\vee \\pi^{\\prime}: X \\to Y \\vee Y^{\\prime}")#text(", where ")#mi("Y \\vee Y^{\\prime} := \\{(\\pi(x),\\pi^{\\prime}(x)): x \\in X \\} \\subset Y \\times Y^{\\prime}")#text(" is the compact subspace of the product system ")#mi("Y \\times Y^{\\prime}")#text(", and ")#mi("\\pi \\vee \\pi^{\\prime}: X \\to Y \\vee Y^{\\prime}")#text(" is the surjective morphism ")#mi("\\pi \\vee \\pi^{\\prime}: x \\mapsto (\\pi(x), \\pi^{\\prime}(x))")#text(". One can verify that ")#mi("\\pi \\vee \\pi^{\\prime}")#text(" is the least common refinement of ")#mi("\\pi")#text(" and ")#mi("\\pi^{\\prime}")#text(", hence the name.")

#text("Secondly, given a chain ")#mi("(\\pi_\\alpha)_{\\alpha \\in A}")#text(" of factors ")#mi("\\pi_\\alpha: X \\to Y_\\alpha")#text(" (thus ")#mi("\\pi_\\alpha")#text(" refines ")#mi("\\pi_\\beta")#text(" for all ")#mi("\\alpha > \\beta")#text("), one can form their ")#link("http://en.wikipedia.org/wiki/Inverse_limit")[#text("inverse limit ")]#mi("\\pi = \\lim_{\\leftarrow} (\\pi_\\alpha)_{\\alpha \\in A}: X \\to Y = \\lim_{\\leftarrow} (Y_\\alpha)_{\\alpha \\in A}")#text(" by first letting ")#mi("f_{\\alpha \\beta}: Y_{\\alpha} \\to Y_{\\beta}")#text(" be the factoring maps for all ")#mi("\\alpha > \\beta")#text(", observing that ")#mi("f_{\\beta \\gamma} \\circ f_{\\alpha \\beta} = f_{\\alpha \\gamma}")#text(" for all ")#mi("\\alpha > \\beta > \\gamma")#text(", and then defining ")#mi("Y \\subset \\prod_\\alpha Y_\\alpha")#text(" to be the compact subspace of the product system ")#mi("\\prod_\\alpha Y_\\alpha")#text(" defined as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("Y := \\{ (y_\\alpha)_{\\alpha \\in A}: f_{\\alpha \\beta}(y_\\alpha) = y_\\beta \\text{ whenever } \\alpha > \\beta \\}")]]

#text("and then setting ")#mi("\\pi: x \\mapsto (\\pi_\\alpha(x))_{\\alpha \\in A}")#text(". One easily verifies that ")#mi("\\pi")#text(" is indeed a factor of X, and it is the ")#link("http://en.wikipedia.org/wiki/Least_upper_bound")[#text("least upper bound")]#text(" of the ")#mi("\\pi_\\alpha")#text(".")

#text("Now we observe that these operations interact well with the isometry property:")

#strong[#text("Exercise 4.")]#text(" Let ")#mi("\\pi: X \\to Y")#text(" and ")#mi("\\pi^{\\prime}: X \\to Y^{\\prime}")#text(" be two factors such that Y and Y’ are both isometric. Then ")#mi("\\pi \\vee \\pi^{\\prime}: X \\to Y \\vee Y^{\\prime}")#text(" is also isometric. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let ")#mi("(\\pi_\\alpha)_{\\alpha \\in A}")#text(" be a totally ordered set of factors ")#mi("\\pi_\\alpha: X \\to Y_\\alpha")#text(" with ")#mi("Y_\\alpha = (Y_\\alpha, {\\mathcal G}_\\alpha, S_\\alpha)")#text(" isometric. Then the inverse limit ")#mi("\\pi: X \\to Y")#text(" of the ")#mi("\\pi_\\alpha")#text(" is such that Y is also isometric.")
]

#strong[#text("Proof.")]#text(" Observe that we have factor maps ")#mi("f_\\alpha: Y \\to Y_\\alpha")#text(" which are surjective morphisms, which themselves factor as ")#mi("f_\\beta = f_{\\alpha \\beta} \\circ f_\\alpha")#text(" for ")#mi("\\alpha > \\beta")#text(" and some surjective morphisms ")#mi("f_{\\alpha \\beta}: Y_\\alpha \\to Y_\\beta")#text(". Let us fix some metric d on Y. For each ")#mi("\\alpha \\in A")#text(", consider the compact subset ")#mi("\\Delta_\\alpha := \\{ (y,y^{\\prime}) \\in Y \\times Y: f_\\alpha(y) = f_\\alpha(y^{\\prime}) \\}")#text(" of ")#mi("Y \\times Y")#text(". These sets decrease as ")#mi("\\alpha")#text(" increases, and their intersection is the diagonal ")#mi("\\{ (y,y): y \\in Y \\}")#text(" (why?). Applying the ")#link("http://en.wikipedia.org/wiki/Finite_intersection_property")[#text("finite intersection property")]#text(" in the compact sets ")#mi("\\{ (y,y^{\\prime}) \\cap \\Delta_\\alpha: d(y,y^{\\prime}) \\geq \\varepsilon \\}")#text(", we conclude that for every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("\\alpha")#text(" such that ")#mi("d(y,y^{\\prime}) < \\varepsilon")#text(" whenever ")#mi("f_\\alpha(y) = f_\\alpha(y^{\\prime})")#text(".")

#text("Now suppose for contradiction that Y is not isometric, and hence not uniformly equicontinuous. Then there exists a sequences ")#mi("y_j, y^{\\prime}_j \\in Y")#text(" with ")#mi("d(y_j,y^{\\prime}_j) \\to 0")#text(", an ")#mi("\\varepsilon > 0")#text(", and a sequence ")#mi("n_j")#text(" of integers such that ")#mi("d(S^{n_j} y_j, S^{n_j} y^{\\prime}_j) > \\varepsilon")#text(". By compactness we may assume that ")#mi("y_j, y^{\\prime}_j")#text(" both converge to the same point. But by the preceding discussion, we can find ")#mi("\\alpha \\in A")#text(" such that ")#mi("d(y,y^{\\prime}) < \\varepsilon/4")#text(" whenever ")#mi("f_\\alpha(y) = f_\\alpha(y^{\\prime})")#text(". In other words, for any z in ")#mi("Y_\\alpha")#text(", the fibre ")#mi("f_\\alpha^{-1}(\\{z\\})")#text(" has diameter at most ")#mi("\\varepsilon/4")#text(".")

#text("Now let ")#mi("z_j := f_\\alpha(y_j)")#text(" and ")#mi("z^{\\prime}_j := f_\\alpha(y^{\\prime}_j)")#text(". Then ")#mi("z_j")#text(" and ")#mi("z^{\\prime}_j")#text(" converge to the same point z in ")#mi("Y_\\alpha")#text(", and so by equicontinuity of ")#mi("Y_\\alpha")#text(", ")#mi("d_{Y_\\alpha}(S_\\alpha^{n_j} z_j, S_\\alpha^{n_j} z^{\\prime}_j)")#text(" goes to zero for some metric ")#mi("d_{Y_\\alpha}")#text(" on ")#mi("Y_\\alpha")#text(" (the exact choice of metric is not important, as remarked earlier). By compactness and passing to a subsequence we can assume that ")#mi("S_\\alpha^{n_j} z_j")#text(" and ")#mi("S_\\alpha^{n_j} z^{\\prime}_j")#text(" both converge to some point ")#mi("z_*")#text(" in ")#mi("Y_\\alpha")#text(". On the other hand, from the preceding discussion and the triangle inequality, we see that the fibres ")#mi("f_\\alpha^{-1}(\\{S_\\alpha^{n_j} z_j\\})")#text(" and ")#mi("f_\\alpha^{-1}(\\{S_\\alpha^{n_j} z^{\\prime}_j\\})")#text(" are separated by a distance at least ")#mi("\\varepsilon/2")#text(" in Y. On the other hand, the distance between ")#mi("f_\\alpha^{-1}(\\{S_\\alpha^{n_j} z_j\\})")#text(" and ")#mi("f_\\alpha^{-1}(\\{z_*\\})")#text(" must go to zero as ")#mi("j \\to \\infty")#text(" (as a simple sequential compactness argument shows), and similarly the distance between ")#mi("f_\\alpha^{-1}(\\{S_\\alpha^{n_j} z^{\\prime}_j\\})")#text(" and ")#mi("f_\\alpha^{-1}(\\{z_*\\})")#text(" goes to zero. Since ")#mi("f_\\alpha^{-1}(\\{z_*\\})")#text(" has diameter at most ")#mi("\\varepsilon/4")#text(", we obtain a contradiction. The claim follows. ")#mi("\\Box")

#text("Combining Exercise 2 and Lemma 1 with ")#link("http://en.wikipedia.org/wiki/Zorn%27s_lemma")[#text("Zorn’s lemma")]#text(" (and noting that with the trivial factor ")#mi("\\text{pt}: X \\to \\text{pt}")#text(", the image ")#mi("\\text{pt}")#text(" is clearly isometric) we obtain")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 1")]#text(". (Existence of maximal isometric factor) For every topological dynamical system ")#mi("(X,{\\mathcal F},T)")#text(" there is a factor ")#mi("\\pi: X \\to Y")#text(" with Y isometric, and which is maximal with respect to refinement among all such factors with this property. This factor is unique up to equivalence.")
]

#text("By Proposition 1 and Exercise 3, the maximal isometric factor of a minimal system is a Kronecker system, and we refer to it as the")#emph[#text(" Kronecker factor")]#text(" of that minimal system X.")

#strong[#text("Exercise 5.")]#text(" (Explicit description of Kronecker factor) Let ")#mi("(X,{\\mathcal F},T)")#text(" be a minimal topological dynamical system, and let ")#mi("Q \\subset X \\times X")#text(" be the set")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("Q := \\bigcap_V \\overline{ (T \\times T)^{\\Bbb Z}(V) }")]]

#text("where V ranges over all open neighbourhoods of the diagonal ")#mi("\\{ (x,x): x\\in X\\}")#text(" of ")#mi("X \\times X")#text(", and ")#mi("T \\times T: (x,y) \\mapsto (Tx,Ty)")#text(" is the product shift. Let ")#mi("\\sim")#text(" be the finest equivalence relation on X such that the set ")#mi("R_\\sim := \\{ (x,y) \\in X \\times X: x \\sim y \\}")#text(" is closed and contains Q. (The existence and uniqueness of ")#mi("\\sim")#text(" can be established by intersecting ")#mi("R_\\sim")#text(" over all candidates ")#mi("\\sim")#text(" together.) Show that the projection map ")#mi("\\pi: X \\to X/\\sim")#text(" to the equivalence classes of ")#mi("\\sim")#text(" (with the quotient topology) is (up to isomorphism) the Kronecker factor of X. ")#mi("\\diamond")

#text("The Kronecker factor is also closely related to the concept of an eigenfunction. We say that a continuous function ")#mi("f: X \\to {\\Bbb C}")#text(" is an ")#emph[#text("eigenfunction")]#text(" of a topological dynamical system ")#mi("(X, {\\mathcal F}, T)")#text(" if it is not identically zero and we have ")#mi("Tf = \\lambda f")#text(" for some ")#mi("\\lambda \\in {\\Bbb C}")#text(", which we refer to as an ")#emph[#text("eigenvalue")]#text(" for T.")

#strong[#text("Exercise 6")]#text(". Let ")#mi("(X,{\\mathcal F}, T)")#text(" be a minimal topological dynamical system.")

#enum(start: 1, 
[#text("Show that if ")#mi("\\lambda")#text(" is an eigenvalue for T, then ")#mi("\\lambda")#text(" lies in the unit circle ")#tao-math("S^1 := \\{ z \\in {\\Bbb C}: \\left|z\\right|=1\\}", block: false)#text(", and furthermore there exists a unimodular eigenfunction ")#mi("g: X \\to S^1")#text(" with this eigenvalue. (")#emph[#text("Hint")]#text(": the zero set of an eigenfunction is a closed shift-invariant subset of X.)")],
[#text("Show that for every eigenvalue ")#mi("\\lambda")#text(", the eigenspace ")#mi("\\{ f\\in C(X): Tf = \\lambda f \\}")#text(" is one-dimensional, i.e. all eigenvalues have geometric multiplicity 1. (")#emph[#text("Hint")]#text(": first establish this in the case ")#mi("\\lambda=1")#text(".)")],
[#text("If ")#mi("g: X \\to S^1")#text(" is a unimodular eigenfunction with non-trivial eigenvalue ")#mi("\\lambda \\neq 1")#text(", show that ")#mi("g: X \\to g(X)")#text(" is an isometric factor of X, where ")#mi("g(X) \\subset S^1")#text(" is given the shift ")#mi("z \\mapsto \\overline{\\lambda} z")#text(". Conclude in particular that ")#mi("g = c \\chi \\circ \\pi")#text(", where ")#mi("\\pi: X \\to K")#text(" is the Kronecker factor, ")#mi("\\chi: K \\to S^1")#text(" is a character of K, and c is a constant. Conversely, show that all functions of the form ")#mi("c \\chi \\circ \\pi")#text(" are eigenfunctions. (From this, it is possible to reconstruct the Kronecker factor canonically from the eigenfunctions of X; we leave the details to the reader.)")]
)

#text("We will see eigenfunctions (and various generalisations of the eigenfunction concept) playing a decisive role in the structure theory of measure-preserving systems, which we will get to in a few lectures.")

#heading(level: 1)[#text("— Isometric extensions —")]

#text("To cover more general systems than just the isometric systems, we need the more flexible concept of an ")#emph[#text("isometric extension")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3")]#text(" (Extensions). If ")#mi("\\pi: X \\to Y = (Y, {\\mathcal G}, S)")#text(" is a factor of ")#mi("(X, {\\mathcal F}, T)")#text(", we say that ")#mi("(X, {\\mathcal F}, T)")#text(" is an ")#emph[#text("extension")]#text(" of ")#mi("(Y, {\\mathcal G}, S)")#text(", and refer to ")#mi("\\pi: X \\to Y")#text(" as the ")#emph[#text("projection map")]#text(" or ")#emph[#text("factor map")]#text(". We refer to the (compact) spaces ")#mi("\\pi^{-1}(\\{y\\})")#text(" for ")#mi("y \\in Y")#text(" as the ")#emph[#text("fibres")]#text(" of this extension.")
]

#strong[#text("Example 5")]#text(". The skew shift is an extension of the circle shift, with the fibres being the “vertical” circles. All systems are extensions of a point, and (somewhat trivially) are also extensions of themselves. ")#mi("\\diamond")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 4")]#text(" (Isometric extensions). Let ")#mi("(X, {\\mathcal F}, T)")#text(" be an extension of a topological dynamical system ")#mi("(Y, {\\mathcal G}, S)")#text(" with projection map ")#mi("\\pi: X \\to Y")#text(". We say that this extension is ")#emph[#text("isometric")]#text(" if there exists a metric ")#mi("d_y: \\pi^{-1}(\\{y\\}) \\times \\pi^{-1}(\\{y\\}) \\to {\\Bbb R}^+")#text(" on each fiber ")#mi("\\pi^{-1}(\\{y\\})")#text(" with the following properties:")

#enum(start: 1, 
[#text("(Isometry) For every ")#mi("y \\in Y")#text(" and ")#mi("x, x^{\\prime} \\in \\pi^{-1}(\\{y\\})")#text(", we have ")#mi("d_{Sy}( Tx, Tx^{\\prime}) = d_y(x,x^{\\prime})")#text(".")],
[#text("(Continuity) The function ")#mi("d: \\bigcup_{y \\in Y} \\pi^{-1}(\\{y\\}) \\times \\pi^{-1}(\\{y\\}) \\to {\\Bbb R}^+")#text(" formed by gluing together all the ")#mi("d_y")#text(" is continuous (where we view the domain as a compact subspace ")#mi("\\{ (x,x^{\\prime}) \\in X \\times X: \\pi(x)=\\pi(x^{\\prime}) \\}")#text(" of ")#mi("X \\times X")#text(").")],
[#text("(Isometry, again) For any ")#mi("y, y^{\\prime} \\in Y")#text(", the metric spaces ")#mi("(\\pi^{-1}(\\{y\\}), d_y)")#text(" and ")#mi("(\\pi^{-1}(\\{y^{\\prime}\\}), d_{y^{\\prime}})")#text(" are isometric.")]
)
]

#strong[#text("Example 6")]#text(". The skew shift is an isometric extension of the circle shift, where we give each fibre the standard metric. ")#mi("\\diamond")

#strong[#text("Example 7.")]#text(" A topological dynamical system is an isometric extension of a point if and only if it is isometric. ")#mi("\\diamond")

#strong[#text("Exercise 7")]#text(". If X is minimal, show that properties 1 and 2 in the above definition automatically imply property 3. Furthermore, in this case show that the isometry group ")#mi("\\text{Isom}( \\pi^{-1}(\\{y\\}) )")#text(" of any fibre acts transitively on that fibre. Show however that property 3 can fail even when properties 1 and 2 hold if X is not assumed to be minimal. ")#mi("\\diamond")

#strong[#text("Exercise 7′. ")]#text(" (Topological characterisation of isometric extensions) Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a extension of a minimal topological dynamical system ")#mi("(Y, {\\mathcal G}, S)")#text(" with factor map ")#mi("\\pi: X \\to Y")#text(", and let d be a metric on X. Show that X is an isometric extension if and only if the shift maps ")#mi("T^n")#text(" are uniformly equicontinuous relative to ")#mi("\\pi")#text(" in the sense that for every ")#mi("\\varepsilon > 0")#text(" there exists ")#mi("\\delta > 0")#text(" such that every ")#mi("x, y \\in X")#text(" with ")#mi("\\pi(x)=\\pi(y)")#text(" and ")#mi("d(x,y) < \\delta")#text(", we have ")#mi("d(T^n x, T^n y) < \\varepsilon")#text(" for all n. ")#mi("\\diamond")

#text("An important subclass of isometric extensions are the ")#emph[#text("group extensions")]#text(". Recall that an ")#emph[#text("automorphism")]#text(" of a topological dynamical system is an isomorphism of that system to itself, i.e. a homeomorphism that commutes with the shift.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5")]#text(". (Group extensions) Let ")#mi("(X, {\\mathcal F}, T)")#text(" be a topological dynamical system. Suppose that we have a compact group G of automorphisms of X (where we endow G with the uniform topology). Then the quotient space ")#mi("Y := G\\backslash X = \\{ Gx: x \\in X \\}")#text(" is also a compact metrisable space, and one easily sees that the projection map ")#mi("\\pi: X \\mapsto Y")#text(" is a factor map. We refer to X as a ")#emph[#text("group extension")]#text(" of Y (or of any other system isomorphic to Y). We refer to G as the ")#emph[#text("structure group")]#text(" of the extension. We say that the group extension is an ")#emph[#text("abelian group extension")]#text(" if G is abelian.")
]

#strong[#text("Example 8.")]#text(" (Cocycle extensions) If G is a compact topological metrisable group, ")#mi("(Y, {\\mathcal G}, S)")#text(" is a topological dynamical system, and a continuous map ")#mi("\\sigma: Y \\to G")#text(", then we define the ")#emph[#text("cocycle extension")]#text(" ")#mi("X = Y \\times_\\sigma G")#text(" to be the product space ")#mi("Y \\times G")#text(" with the shift ")#mi("T: (y,\\zeta) \\mapsto (Sy, \\sigma(y) \\zeta)")#text(", and with the factor map ")#mi("\\pi: (y,\\zeta) \\mapsto y")#text(". One easily verifies that X is a group extension of Y with structure group G. The converse is not quite true for topological reasons; not every G-bundle can be globally trivialised, although one can still describe general group extensions by patching together cocycle extensions on local trivalisations. ")#mi("\\diamond")

#strong[#text("Example 9.")]#text(" The skew shift is a cocycle extension (and hence group extension) ")#mi("Y \\times_\\sigma ({\\Bbb R}/{\\Bbb Z})")#text(" of the circle shift ")#mi("Y")#text(", with ")#mi("\\sigma(y) := y")#text(" being the identity map. Any Kronecker system is an abelian group extension of a point. ")#mi("\\diamond")

#strong[#text("Exercise 8")]#text(". Show that every group extension is an isometric extension. (Hint: the group G acts equicontinuously on itself, and thus isometrically on itself by choosing the right metric, as in Exercise 1.) ")#mi("\\diamond")

#strong[#text("Exercise 9.")]#text(" Let ")#mi("(Y, {\\mathcal G}, S)")#text(" be a topological dynamical system, and G a compact topological metrisable group. We say that two cocycles ")#mi("\\sigma, \\sigma^{\\prime}: Y \\to G")#text(" are ")#emph[#text("cohomologous")]#text(" if we have ")#mi("\\sigma^{\\prime}(y) = \\phi(Sy) \\sigma(y) \\phi(y)^{-1}")#text(" for some continuous map ")#mi("\\phi: Y \\to G")#text(". Show that if ")#mi("\\sigma, \\sigma^{\\prime}")#text(" are cohomologous, then the cocycle extensions ")#mi("Y \\times_\\sigma G")#text(" and ")#mi("Y \\times_{\\sigma^{\\prime}} G")#text(" are isomorphic. Understanding exactly which cocycles are cohomologous to each other is a major topic of study in dynamical systems (though not one which we will pursue here). ")#mi("\\diamond")

#text("In view of Proposition 1 and Exercise 14, it is reasonable to ask whether every minimal isometric extension is a group extension. The answer is no (though actually constructing a counterexample is a little tricky). The reason is that we can form intermediate systems between a system Y=G\\X and a group extension X of that system by quotienting out a subgroup. Indeed, if H is a closed subgroup of the structure group G, then H\\X is a factor of X and an isometric extension of G\\X, but need not be a group extension of G\\X (basically because G/H need not be a group). But this is the only obstruction to obtaining an analogue of Proposition 1:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2")]#text(". Suppose that X is an isometric extension of another topological dynamical system Y with projection map ")#mi("\\pi: X \\to Y")#text(". Suppose also that X is minimal. Then there exists a group extension Z of Y with structure group G (thus ")#mi("Y \\equiv G\\backslash Z")#text(") and a closed subgroup H of G such that X is isomorphic to H\\Z, and ")#mi("\\pi")#text(" is (after applying the isomorphisms) the projection map from H\\Z to G\\Z; thus we have the ")#link("http://en.wikipedia.org/wiki/Commutative_diagram")[#text("commutative diagram")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\begin{array}{ccc} Z & \\rightarrow & X=H\\backslash Z \\\\ & \\searrow & \\downarrow \\\\ & & Y=G\\backslash Z \\end{array}.")]]
]

#strong[#text("Proof")]#text(". For each ")#mi("y \\in Y")#text(", let ")#mi("V_y")#text(" be the metric space ")#mi("\\pi^{-1}(\\{y\\})")#text(" with the metric ")#mi("d_y")#text(" given by Definition 5. Thus for any integer n and any ")#mi("y \\in Y")#text(", ")#mi("T^n")#text(" is an isometry from ")#mi("V_y")#text(" to ")#mi("V_{S^n y}")#text("; taking limits, we see for any ")#mi("p \\in \\beta {\\Bbb Z}")#text(" that ")#mi("T^p")#text(" is an isometry from ")#mi("V_y")#text(" to ")#mi("V_{S^p y}")#text(". Also, the ")#mi("T^p")#text(" clearly commute with the shift T.")

#text("Fix a point ")#mi("y_0 \\in Y")#text(", and set ")#mi("G := \\text{Isom}(V_{y_0})")#text(".")

#text("Let W be the space of all pairs ")#mi("(y,f)")#text(" where ")#mi("y \\in Y")#text(" and f is an isometry from ")#mi("V_{y_0}")#text(" to ")#mi("V_{y}")#text(". This is a compact metrisable space with a shift ")#mi("U:(y,f) \\mapsto (Sy, T \\circ f)")#text(" and an action ")#mi("g: (y,f) \\mapsto (y,f \\circ g^{-1})")#text(" of G that commutes with U. We let Z be the orbit closure in W of the G-orbit ")#mi("\\{y_0\\} \\times G")#text(" under the shift U. If we fix a point ")#mi("x_0 \\in V_{y_0}")#text(", then Z projects onto X by the map ")#mi("f \\mapsto f(y_0)")#text(", and onto Y by the map ")#mi("(y,f) \\mapsto y")#text("; these maps of course commute with the projection ")#mi("\\pi: x \\mapsto \\pi(x)")#text(" from X to Y. Because X is minimal (and thus equal to all of its orbit closures), one sees that all of these projections are surjective morphisms, thus Z extends both Y and X. Also, one verifies that Z is a group extension over Y with structure group G, and a group extension over X with structure group given by the stabiliser ")#mi("H := \\{ g \\in G: gx_0 = x_0 \\}")#text(". The claim follows. ")#mi("\\Box")

#strong[#text("Exercise 10.")]#text(" Show that if an minimal extension ")#mi("\\pi: X \\to Y")#text(" is finite, then it is automatically an abelian group extension. (")#emph[#text("Hint")]#text(": recall from ")#link("https://terrytao.wordpress.com/2008/01/10/254a-lecture-2-three-categories-of-dynamical-systems/")[#text("Lecture 2")]#text(" that minimal finite systems are equivalent to shifts on a cyclic group.) ")#mi("\\diamond")

#text("An important feature of isometric or group extensions is that they tend to preserve recurrence properties of the system. We will see this phenomenon prominently when we turn to the ergodic theory analogue of isometric extensions, but for now let us give a simple illustrative result in this direction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4.")]#text(" Let ")#mi("(X, {\\mathcal F}, T)")#text(" be an isometric extension of ")#mi("(Y, {\\mathcal G}, S)")#text(" with factor map ")#mi("\\pi: X \\to Y")#text(", and let y be a recurrent point of Y (see ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text(" for a definition). Then every point x in the fibre ")#mi("\\pi^{-1}(\\{y\\})")#text(" is a recurrent point in X.")
]

#strong[#text("Proof. ")]#text("It will be convenient to use ultrafilters. In view of Lemma 2, it suffices to prove the claim for group extensions (note that recurrence is preserved under morphisms). Since y is recurrent, there exists ")#mi("p \\in \\beta {\\Bbb Z} \\backslash {\\Bbb Z}")#text(" such that ")#mi("S^p y = y")#text(" (see Exercise 9 from ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text("). Thus ")#mi("\\pi(T^p x) = \\pi(x)")#text(". Since Y = G\\X, this implies that ")#mi("T^p x = g x")#text(" for some ")#mi("g \\in G")#text(". We can iterate this (recalling that G commutes with T) to conclude that ")#mi("T^{np} x = g^n x")#text(" for all positive integers n. But by considering the action of g on G, we know (from the Birkhoff recurrence theorem from ")#link("https://terrytao.wordpress.com/2008/01/13/254a-lecture-3-minimal-dynamical-systems-recurrence-and-the-stone-cech-compactification/")[#text("Lecture 3")]#text(") that we have ")#mi("g^{n_j} h \\to h")#text(" for some ")#mi("h \\in G")#text(" and ")#mi("n_j \\to +\\infty")#text("; canceling the h, and then applying to x, we conclude that ")#mi("g^{n_j} x \\to x")#text(", and thus ")#mi("T^{n_j p} x \\to x")#text(". If we write ")#mi("q := \\lim_{j \\to r} n_j p")#text(" for some ")#mi("r \\in \\beta {\\Bbb N} \\backslash {\\Bbb N}")#text(", we conclude that ")#mi("T^q x = x")#text(" and so x is recurrent as desired. ")#mi("\\Box")

#heading(level: 1)[#text("— Application: distribution of polynomial sequences in torii —")]

#text("Now we apply the above theory to the following specific problem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1.")]#text(" Let ")#mi("P: {\\Bbb Z} \\to ({\\Bbb R}/{\\Bbb Z})^d")#text(" be a polynomial sequence in a d-dimensional torus, thus ")#mi("P(n) = \\sum_{j=0}^k c_j n^j")#text(" for some ")#mi("c_0,\\ldots,c_k \\in ({\\Bbb R}/{\\Bbb Z})^d")#text(". Compute the orbit closure ")#mi("\\overline{P({\\Bbb Z})} = \\overline{ \\{ P(n): n \\in {\\Bbb Z} \\} }")#text(".")
]

#text("(We will be vague here about what “compute” means.)")

#strong[#text("Example 10.")]#text(" Is the orbit ")#mi("\\{ (\\sqrt{2} n \\text{ mod } 1, \\sqrt{3} n^2 \\text{ mod } 1): n \\in {\\Bbb Z} \\}")#text(" dense in the two-dimensional torus ")#mi("({\\Bbb R}/{\\Bbb Z})^2")#text("? ")#mi("\\diamond")

#text("The answer should of course depend on the polynomial P; for instance if P is constant then the orbit closure is clearly a point. Similarly, if the polynomial P has a constraint of the form ")#mi("m \\cdot P = c")#text(" for some non-zero ")#mi("m \\in {\\Bbb Z}^d")#text(" and ")#mi("c \\in {\\Bbb R}/{\\Bbb Z}")#text(", then the orbit closure is clearly going to be contained inside the proper subset ")#mi("\\{ x \\in ({\\Bbb R}/{\\Bbb Z})^d: m \\cdot x = c \\}")#text(" of the torus. For instance, ")#mi("\\{ (\\sqrt{2} n^2 \\text{ mod } 1, 2\\sqrt{2} n^2 \\text{ mod } 1 ): n \\in {\\Bbb Z} \\}")#text(" is clearly not dense in the two-dimensional torus, as it is contained in the closed one-dimensional subtorus ")#mi("\\{ (x,2x): x \\in {\\Bbb R}/{\\Bbb Z} \\}")#text(".")

#text("In the above example, it is clear that the problem of computing the orbit closure of ")#mi("(\\sqrt{2} n^2 \\text{ mod } 1, 2\\sqrt{2} n^2 \\text{ mod } 1 )")#text(" reduces to computing the orbit closure of ")#mi("(\\sqrt{2} n^2 \\text{ mod } 1)")#text(". More generally, if a polynomial ")#mi("P: {\\Bbb Z} \\to ({\\Bbb R}/{\\Bbb Z})^d")#text(" obeys a constraint ")#mi("m \\cdot P = c")#text(" for some non-zero ")#emph[#text("irreducible")]#text(" ")#mi("m \\in {\\Bbb Z}^d")#text(" (i.e. m does not factor as m = q m’ for some ")#mi("q > 1")#text(" and ")#mi("m^{\\prime} \\in {\\Bbb Z}^d")#text(", or equivalently that the greatest common divisor of the coefficients of m is 1), then some elementary number theory shows that the set ")#mi("\\{ x \\in ({\\Bbb R}/{\\Bbb Z})^d: m \\cdot x = c \\}")#text(" is isomorphic (after an invertible affine transformation with integer coefficients on the torus) to the standard subtorus ")#mi("({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(").")

#strong[#text("Exercise 11")]#text(". Prove the above claim. (Hint: the Euclidean algorithm may come in handy.) ")#mi("\\diamond")

#text("Because of this, we see that whenever we have a constraint of the form ")#mi("m \\cdot P = c")#text(" with m irreducible, we can reduce Problem 1 to an instance of Problem 1 with one lower dimension. What about if m is not irreducible? A typical example of this would be when ")#mi("P(n) := ( \\sqrt{2} n^2, 2 \\sqrt{2} n^2 + \\frac{1}{2} n )")#text(" (I’m going to drop the “mod 1” terms to remove clutter). Here, we have the constraint ")#mi("(-4, 2) \\cdot P(n) = 0")#text(", which constrains P to the union of two one-dimensional torii, rather than a single one-dimensional torus. But we can eliminate this multiplicity by the trick of working with the odd and even components ")#mi("\\{ P(2n+1): n \\in {\\Bbb Z} \\}")#text(" and ")#mi("\\{ P(2n): n \\in {\\Bbb Z} \\}")#text(" respectively. One observes that each component obeys an irreducible constraint, namely ")#mi("(-2,1) \\cdot P(2n) = 0")#text(" and ")#mi("(-2,1) \\cdot P(2n+1) = \\frac{1}{2}")#text(" respectively, and so by the preceding discussion, the problem of computing the orbit closures for each of these components reduces to that of computing an orbit closure in a torus of one lower dimension.")

#strong[#text("Exercise 12. ")]#text("More generally, show that whenever P obeys a constraint ")#mi("m \\cdot P(n) = c")#text(" with m not necessarily irreducible, then there exists an integer ")#mi("q \\geq 1")#text(" such that the orbits ")#mi("\\{ P(qn+r): n \\in {\\Bbb Z} \\}")#text(" obey a constraint ")#mi("m^{\\prime} \\cdot P(qn+r) = c_r")#text(" with m’ irreducible. ")#mi("\\diamond")

#text("From Exercises 11 and 12, we see that every time we have a constraint of the form ")#mi("m \\cdot P(n) = c")#text(" for some non-zero m, we can reduce Problem 1 to one or more copies of Problem 1 in one lower dimension. So, without loss of generality (and by inducting on dimension) we may assume that no such constraint exists. (We will see this “induction on dimension” type of argument much later in this course, when we study Ratner-type theorems in more detail.)")

#text("Now that all the “obvious” restrictions on the orbit have been removed, one might now expect P(n) to be uniformly distributed throughout the torus. Happily, this is indeed the case (at least at the topological level):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1. ")]#text("(Equidistribution theorem) Let ")#mi("P: {\\Bbb Z} \\to ({\\Bbb R}/{\\Bbb Z})^d")#text(" be a polynomial sequence which does not obey any constraint of the form ")#mi("m \\cdot P(n) = c")#text(" with ")#mi("m \\in {\\Bbb Z}^d")#text(" non-zero. Then the orbit ")#mi("P({\\Bbb Z})")#text(" is dense in ")#mi("({\\Bbb R}/{\\Bbb Z})^d")#text(" (i.e. the orbit closure is the whole torus).")
]

#strong[#text("Remark 3.")]#text(" The recurrence theorems we have already encountered (e.g. Corollary 1 from ")#link("https://terrytao.wordpress.com/2008/01/15/254a-lecture-4-multiple-recurrence/")[#text("Lecture 4")]#text(", or Theorem 1 from ")#link("https://terrytao.wordpress.com/2008/01/21/254a-lecture-5-other-topological-recurrence-results/")[#text("Lecture 5")]#text(") do not seem to directly establish this result, instead giving the weaker result that every element in ")#mi("P({\\Bbb Z})")#text(" is a limit point. ")#mi("\\diamond")

#strong[#text("Exercise 13.")]#text(" Assuming Theorem 1, show that the answer to Problem 1 is always “a finite union of subtorii”, regardless of what the coefficients of P are. ")#mi("\\diamond")

#text("Theorem 1 can be proven using Weyl’s theory of equidistribution, which is based on bounds on exponential sums; but we shall instead use a topological dynamics argument based on some ideas of Furstenberg. Amusingly, this argument will use some ")#emph[#text("global")]#text(" topology (specifically, winding numbers) and not just ")#emph[#text("local")]#text(" (point-set) topology.")

#text("To begin proving this theorem, let us first consider the linear one-dimensional case, in which one considers the orbit closure of ")#mi("\\{ n \\alpha + \\beta: n \\in {\\Bbb Z}\\}")#text(" for some ")#mi("\\alpha, \\beta \\in {\\Bbb R}/{\\Bbb Z}")#text(". The constant term ")#mi("\\beta")#text(" only affects this closure by a translation and we can ignore it. One then easily checks that the orbit closure ")#mi("\\overline{ \\{ n \\alpha: n \\in {\\Bbb Z} \\} }")#text(" is a closed subgroup of ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(". Fortunately, we have a classification of these objects:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3. ")]#text("Let H be a closed subgroup of ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(". Then either ")#mi("H = {\\Bbb R}/{\\Bbb Z}")#text(", or H is a cyclic group of the form ")#mi("H = \\{ x \\in {\\Bbb R}/{\\Bbb Z}: Nx = 0 \\}")#text(" for some ")#mi("N \\geq 1")#text(".")
]

#strong[#text("Proof.")]#text(" If H is not all of ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(", then its complement, being a non-empty open set, is the union of disjoint open intervals. Let x be the boundary of one of these intervals, then x lies in the closed set H. Translating the group H by x, we conclude that 0 is also the boundary of one of these intervals. Since H = -H, we thus see that 0 is an isolated point in H. If we then let y be the closest non-zero element of H to the origin (the case when H={0} can of course be checked separately), we check (using the Euclidean algorithm) that y generates H, and the claim easily follows. ")#mi("\\Box")

#strong[#text("Exercise 14.")]#text(" Using the above lemma, prove Theorem 1 in the case when d=1 and P is linear. ")#mi("\\diamond")

#strong[#text("Exercise 15. ")]#text("Obtain another proof of Lemma 3 using Fourier analysis and the fact that the only non-trivial subgroups of ")#mi("{\\Bbb Z}")#text(" (the Pontryagin dual of ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" are the groups ")#mi("N \\cdot {\\Bbb Z}")#text(" for ")#mi("N \\geq 1")#text(". ")#mi("\\diamond")

#text("Now we consider the linear case in higher dimensions. The key lemma is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4.")]#text(" Let H be a closed subgroup of ")#mi("({\\Bbb R}/{\\Bbb Z})^d")#text(" for some ")#mi("d \\geq 1")#text(" such that ")#mi("\\pi(H) = ({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(", where ")#mi("\\pi: ({\\Bbb R}/{\\Bbb Z})^d \\to ({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(" is the canonical projection. Then either ")#mi("H = ({\\Bbb R}/{\\Bbb Z})^d")#text(" or ")#mi("H = \\{ x \\in ({\\Bbb R}/{\\Bbb Z})^d: m \\cdot x = 0 \\}")#text(" for some ")#mi("m \\in {\\Bbb Z}^d")#text(" with final coefficient non-zero.")
]

#strong[#text("Proof. ")]#text("The fibre ")#mi("H \\cap \\pi^{-1}(\\{0\\})")#text(" is isomorphic to a closed subgroup of ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(", so we can apply Lemma 3. If this subgroup is full, then it is not hard to see that ")#mi("H = ({\\Bbb R}/{\\Bbb Z})^d")#text(", so suppose instead that ")#mi("H \\cap \\pi^{-1}(\\{0\\})")#text(" is isomorphic to the cyclic group of order N. We then apply the homomorphism ")#mi("f_N: (x_1,\\ldots,x_d) \\to (x_1,\\ldots,x_{d-1},Nx_d)")#text(", and observe that ")#mi("H_N := f_N(H)")#text(" is a closed subgroup of ")#mi("({\\Bbb R}/{\\Bbb Z})^d")#text(" whose fibres are a point, i.e. ")#mi("H_N")#text(" is a graph ")#mi("\\{ (x, \\phi(x)): x \\in ({\\Bbb R}/{\\Bbb Z})^{d-1} \\}")#text(" for some ")#mi("\\phi: ({\\Bbb R}/{\\Bbb Z})^{d-1} \\to {\\Bbb R}/{\\Bbb Z}")#text(". Observe that the projection map ")#mi("(x,\\phi(x)) \\mapsto x")#text(" is a continuous bijection from the compact Hausdorff space ")#mi("H_N")#text(" to the compact Hausdorff space ")#mi("({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(", and is thus a homeomorphism; in particular, ")#mi("\\phi")#text(" is continuous. Also, since ")#mi("H_N")#text(" is a group, ")#mi("\\phi")#text(" must be a homomorphism. It is then a standard exercise to conclude that ")#mi("\\phi")#text(" is linear, and therefore takes the form ")#mi("(x_1,\\ldots,x_{d-1}) \\mapsto m_1 x_1 + \\ldots + m_{d-1} x_{d-1}")#text(" for some integers ")#mi("m_1,\\ldots,m_{d-1}")#text(". The claim then follows by some routine algebra. ")#mi("\\Box")

#strong[#text("Exercise 16.")]#text(" Using the above lemma, prove Theorem 1 in the case when d is arbitrary and P is linear. ")#mi("\\diamond")

#text("We now turn to the polynomial case. The basic idea is to re-express P(n) in terms of the orbit ")#mi("T^n x")#text(" of some topological dynamical system on a torus. We have already seen this happen with the skew shift ")#mi("( ({\\Bbb R}/{\\Bbb Z})^2, (x,y) \\mapsto (x+\\alpha, y+x))")#text(", where the orbits ")#mi("T^n x")#text(" exhibit quadratic behaviour in n. More generally, an iterated skew shift such as")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("({\\Bbb R}/{\\Bbb Z})^d, (x_1,\\ldots,x_d) \\mapsto (x_1+\\alpha, x_2+x_1,\\ldots,x_d+x_{d-1}))")]]

#text("generates orbits ")#mi("T^n x")#text(" whose final coefficient contains degree d terms such as ")#mi("\\frac{n(n-1)\\ldots(n-d+1)}{d!} \\alpha")#text(". What we would like to do is find criteria under which we could demonstrate that systems such as (5) are ")#emph[#text("minimal")]#text("; this would mean that every orbit closure in that system is dense, which would clearly be relevant for proving results such as Theorem 1.")

#text("To do this, we will exploit the fact that systems such as (5) can be built as towers of isometric extensions; for instance, the system (5) is an isometric extension over the same system (5) associated to d-1 (which, in the case d=1, is simply a point). Now, isometric extensions don’t always preserve minimality; for instance, if one takes a trivial cocycle extension ")#mi("Y \\times_0 G")#text(" then the system is certainly non-minimal, as every horizontal slice ")#mi("Y \\times \\{g\\}")#text(" of that system is a subsystem. More generally, any cocycle extension which is cohomologous to the trivial cocycle (see Exercise 9) will not be minimal. However, it turns out that if one has a topological obstruction to triviality, then minimality is preserved. We will formulate this fact using the machinery of ")#emph[#text("winding numbers")]#text(". Recall that every continuous map ")#mi("f: {\\Bbb R}/{\\Bbb Z} \\to {\\Bbb R}/{\\Bbb Z}")#text(" has a ")#link("http://en.wikipedia.org/wiki/Winding_number")[#text("winding number")]#text(" ")#mi("{}[f] \\in {\\Bbb Z}")#text(", which can be defined as the unique integer such that f is ")#link("http://en.wikipedia.org/wiki/Homotopy")[#text("homotopic")]#text(" to the linear map ")#mi("x \\mapsto [f] x")#text(". Note that the map ")#mi("f \\mapsto [f]")#text(" is linear, and also that ")#mi("{}[f]")#text(" is unchanged if one continuously deforms f.")

#text("We now give a variant of a lemma of Furstenberg.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5.")]#text(" Let ")#mi("(Y, {\\mathcal G}, S)")#text(" be a minimal topological dynamical system. Let ")#mi("\\sigma: Y \\to ({\\Bbb R}/{\\Bbb Z})^d")#text(" be a cocycle such that for every non-zero ")#mi("m \\in {\\Bbb Z}^d")#text(" there exists a loop ")#mi("\\gamma: {\\Bbb R}/{\\Bbb Z} \\to Y")#text(" such that ")#mi("S \\circ \\gamma")#text(" is homotopic to ")#mi("\\gamma")#text(" and ")#mi("{}[m \\cdot \\sigma \\circ \\gamma] \\neq 0")#text(". Then ")#mi("Y \\times_\\sigma {\\Bbb R}/{\\Bbb Z}")#text(" is also minimal.")
]

#strong[#text("Proof. ")]#text("We induct on d. The case d=0 is trivial, so suppose ")#mi("d \\geq 1")#text(" and the claim has already been proven for d-1. Suppose for contradiction that ")#mi("Y \\times_\\sigma ({\\Bbb R}/{\\Bbb Z})^d")#text(" contains a proper minimal subsystem Z. Then ")#mi("\\pi(Z)")#text(" is a subsystem of Y, and must therefore equal all of Y, by minimality of Y. Now we use the action of ")#mi("({\\Bbb R}/{\\Bbb Z})^d")#text(" on ")#mi("Y \\times_\\sigma ({\\Bbb R}/{\\Bbb Z})^d")#text(", which commutes with the shift ")#mi("T: (y,\\zeta) \\mapsto (Sy, \\sigma(y)+\\zeta)")#text(". For every ")#mi("\\theta \\in ({\\Bbb R}/{\\Bbb Z})^d")#text(", we see that ")#mi("\\theta + Z")#text(" is also a minimal subsystem, and so is either equal to Z or disjoint from Z. If we let ")#mi("H := \\{ \\theta\\in ({\\Bbb R}/{\\Bbb Z})^d: \\theta+Z=Z\\}")#text(", we conclude that H is a closed subgroup of ")#mi("({\\Bbb R}/{\\Bbb Z})^d")#text(".")

#text("We now claim that the projection of H to ")#mi("({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(" must be all of ")#mi("({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(". For if this were not the case, we could project Z down to ")#mi("Y \\times_{\\sigma^{\\prime}} ({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(", where ")#mi("\\sigma^{\\prime}: Y \\to ({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(" is the projection of ")#mi("\\sigma")#text(", and obtain a proper subsystem of that extension. But by induction hypothesis we see that ")#mi("Y \\times_{\\sigma^{\\prime}} ({\\Bbb R}/{\\Bbb Z})^{d-1}")#text(" is minimal, a contradiction, thus proving the claim.")

#text("We can now apply Lemma 4. If H is all of ")#mi("({\\Bbb R}/{\\Bbb Z})^d")#text(" then Z is all of ")#mi("Y \\times_{\\sigma} ({\\Bbb R}/{\\Bbb Z})^d")#text(", a contradiction. Thus we have ")#mi("H  = \\{ \\zeta \\in ({\\Bbb R}/{\\Bbb Z})^d: m \\cdot \\zeta = 0 \\}")#text(" for some non-zero ")#mi("m \\in {\\Bbb Z}^d")#text(", and thus Z must take the form")

#mi("Z = \\{ (y,\\zeta) \\in  Y \\times_{\\sigma} ({\\Bbb R}/{\\Bbb Z})^d: m \\cdot \\zeta= \\phi(y) \\}")#text(" (6)")

#text("for some ")#mi("\\phi: Y \\to {\\Bbb R}/{\\Bbb Z}")#text(". Arguing as in the proof of Lemma 4 we can show that Y is homeomorphic to the image of Z under the map ")#mi("(y,\\zeta) \\mapsto (y,m \\cdot \\zeta)")#text(" and so ")#mi("\\phi")#text(" must be continuous. Since Z is shift-invariant, we must have the equation")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\phi(Sy) = \\phi(y) + m \\cdot \\sigma(y).")]]

#text("We apply this for y in the loop ")#mi("\\gamma")#text(" associated to m by hypothesis, and take degrees to conclude")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("{}[\\phi \\circ S \\circ \\gamma] = [\\phi \\circ \\gamma] + [m \\cdot \\sigma \\circ \\gamma].")]]

#text("But as ")#mi("S \\circ \\gamma")#text(" is homotopic to ")#mi("\\gamma")#text(", we have ")#mi("{}[\\phi \\circ S \\circ \\gamma] = [\\phi \\circ \\gamma]")#text(" and thus ")#mi("{}[m \\cdot \\sigma \\circ \\gamma]=0")#text(", contradicting the hypothesis. ")#mi("\\Box")

#strong[#text("Exercise 17.")]#text("Using the above lemma and an induction on d, show that the system (5) is minimal whenever ")#mi("\\alpha")#text(" is irrational. [The key, of course, is to make a good choice for the loop ")#mi("\\gamma")#text(" that makes all computations easy.] ")#mi("\\diamond")

#strong[#text("Exercise 18. ")]#text("More generally, show that the product of any finite number of systems of the form (5) remains minimal, as long as the numbers ")#mi("\\alpha")#text(" that generate each factor system are linearly independent with respect to each other and to 1 over the rationals ")#mi("{\\Bbb Q}")#text(". ")#mi("\\diamond")

#text("It is now possible to deduce Theorem 1 from Exercise 18 and a little bit of linear algebra. We sketch the ideas as follows. Firstly we take all the non-constant coefficients that appear in P and look at the space they span, together with 1, over the rationals ")#mi("{\\Bbb Q}")#text(". This is a finite-dimensional space, and so has a basis containing 1 which is linearly independent over ")#mi("{\\Bbb Q}")#text(". The non-constant coefficients of P are rational linear combinations of elements of this basis; by dividing the basis elements by some suitable integer (and using the trick of passing from P(n) to P(qn+r) if necessary) we can ensure that the coefficients of P are in fact integer linear combinations of basis elements. This allows us to write P as an affine-linear combination (with integer coefficients) of the coefficients of an orbit in the type of product system considered in Exercise 18. If this affine transformation has full rank, then we are done; otherwise, the affine transformation maps to some subspace of the torus of the form ")#mi("\\{ x: m \\cdot x = c \\}")#text(", contradicting the hypothesis on P. Theorem 1 follows.")

#text("[")#emph[#text("Update")]#text(", Feb 9: Proof of Lemma 2 corrected.]")

#text("[")#emph[#text("Update")]#text(", Feb 11: Exercise 6 corrected.]")

#text("[")#emph[#text("Update")]#text(", Feb 12: Proof of Lemma 1 corrected.]")

#text("[")#emph[#text("Update")]#text(", Feb 18: Exercise 6.3 corrected.]")

#text("[")#emph[#text("Update")]#text(", Feb 19: Exercise 6.3 corrected again.]")

#text("[")#emph[#text("Update")]#text(", Mar 24: Exercise 7′ corrected.]")

#text("[")#emph[#text("Update")]#text(", Mar 31: Some minor corrections.]")

#text("[")#emph[#text("Update")]#text(", Sep 27: More corrections.]")

#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8e3a41d2e49f99496331086313091876657e94fc1fa6eb03dd7fc7744d112706-ccb789f07279c510d7296f4fdaee60491e95a9dbe98ef733bb51533f04938f8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilay")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-24960")[#strong[#text("Nilay")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Sir")

#text("1. In the definitions of isometric and equicontinous, where does n belong to – set of integers or set of naturals?")#linebreak()#text(" 2. In example 2, I think if we use the discreet metric we will not necessarily obtain an isometric system. Consider the two point system {x,y} such that Tx = x, Ty = x. Then d(x,y) = 1 but d(Tx,Ty) = 0.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-24974")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2008")])]

#text("Dear Nilay,")

#text("In these lectures, the shift T is understood to be invertible unless otherwise specified (see Lecture 1, paragraph 5).")

#text("Cute exercise: show that a non-invertible shift cannot generate an isometric (non-invertible) topological dynamical system. (It’s clear that non-injectivity causes an obstruction; what is more tricky is to show that non-surjectivity does also.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 7: Structural theory of topological dynamical systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-25067")[#strong[#text("254A, Lecture 7: Structural theory of topological dynamical systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2008")])]

#text("[…] Exercise 3. Show that an inverse limit of a totally ordered set of distal factors is still distal. (This turns out to be slightly easier than Lemma 1 from the previous lecture.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-25991")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("In Question 6.3, I think we need to suppose that g = 1 at some point x to get the desired decomposition g = \\chi o \\phi.")

#text("Otherwise, we have the following counterexample:")

#text("X is the two-point set {a, b}, T is the shift sending a to b and vice versa, and")#linebreak()#text(" g: X –> S^1 is an eigenfunction for the eigenvalue \\lambda = -1 with g(a) = i and g(b) = -i (clearly this is unimodular).")

#text("As X is isometric, it is its own Kronecker factor (and any representation of this Kronecker factor would be as a group of order two).")

#text("However, if \\chi is a character from a group of order two to S^1, its image must be contained in the subset of S^1 consisting of order-two elements, i.e. {-1, 1}. This means that g = \\chi o \\pi is impossible as the former has range {i, -i} and the latter must have range contained in {-1, 1}.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-25995")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("Dear mmailliw/william,")

#text("Thanks for pointing that out. I’ll add a multiplicative constant to the decomposition to fix the problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 11: Compact systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26015")[#strong[#text("254A, Lecture 11: Compact systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("[…] are analogous to the equicontinuous or isometric systems in topological dynamics discussed in Lecture 6, and as with those systems, we will be able to characterise such systems (or more precisely, the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaher")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26024")[#strong[#text("Zaher")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("Dear Prof.;")

#text("In the proof of lemma 1 (last paragraph), it seems to me that we should consider the fibres ")#mi("f_{\\alpha}^{-1}(T_{\\alpha}^{n_ j}(z_ j))")#text(" and ")#mi("f_{\\alpha}^{-1}(T_{\\alpha}^{n_ j}(z^{\\prime}_ j))")#text(" and use that ")#mi("Y_{\\alpha}")#text(" is uniformly equicontinuous.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2008")])]

#text("Dear Prof Tao:")#linebreak()#text(" This is an off topic suggestion. Would it make sense to create a “graveyard” thread so that people who are not familiar with laTex/Wordpress can test their formatting before submitting the real posts?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26060")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2008")])]

#text("Dear Zaher,")

#text("Thanks for the correction!")

#text("Dear Anonymous:")

#text("What I have been doing so far is correcting any LaTeX errors I see manually. I think if someone wanted to do extensive testing of LaTeX then doing so in their own blog (where they can delete or re-edit the content at will, and also have previewing options) would make more sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaher")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26356")[#strong[#text("Zaher")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Dear Prof.;")

#text("Concerning Exercise 6.3, the unimodular eigenfunction may not be surjective and hence not a factor. mmailliw/william (above commenter) already gave an example. Yet, I think that the decomposition g= c \\pi o \\chi may still true even if g is not onto.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26361")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2008")])]

#text("Good point; I’ve amended the exercise accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 9: Ergodicity « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26498")[#strong[#text("254A, Lecture 9: Ergodicity « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2008")])]

#text("[…] Exercise 5. Show that the circle shift (with the usual Lebesgue measure) is ergodic if and only if is irrational. (Hint: analyse the equation for (say) using Fourier analysis. Added, Feb 21: As pointed out to me in class, another way to proceed is to use the Lebesgue density theorem (or Lebesgue differentiation theorem) combined with Exercise 14 from Lecture 6.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 12: Weakly mixing systems « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26557")[#strong[#text("254A, Lecture 12: Weakly mixing systems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2008")])]

#text("[…] Exercise 7. Using Exercise 6, give another proof of Theorem 1 from Lecture 6. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 13: Compact extensions « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-26825")[#strong[#text("254A, Lecture 13: Compact extensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2008")])]

#text("[…] be described as (inverse limits of) group quotient extensions, somewhat analogously to Lemma 2 from Lecture 6. Roughly speaking, the idea is to first use some spectral theory to approximate conditionally […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cfcd9364aa026da76f474a756ce5193892c32e3e204a8127500d370e29d6c3da-dbede24ff6541d7a0422ed75509acdf3df56fc821af8a5344af32bc9eb746a0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sugata")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27581")[#strong[#text("sugata")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("sir,")#linebreak()#text(" i have tried to prove the ‘topological characterisation of isometric extensions’,but could not figure it out.can i just ask you what is your definition of isometric spaces,i.e.when are two spaces called isometric.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27583")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Dear Sugata,")

#text("Oops! For exercise 7′, it’s only possible to obtain the isometry of fibres in the case when Y is minimal. I’ve added that hypothesis to the question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sugata")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27611")[#strong[#text("Sugata")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("sir,")#linebreak()#text(" i tried to solve the problem just after group extensions.does your definition of isometry imply that ‘the isometry’ is onto,then there is a problem again.")#linebreak()#text(" consider X=a discrete topological dynamical system containing n points.T=identity map on X.name the points of X 1,2,…now consider S^(n-1) acting on first (n-1) points of X.then Y=[S^(n-1).{1},{n}].then pie inverse{S^(n-1).{1}}={1,2…,n-1},pie inverse{n}={n}.then these two spaces can’t be isometric.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2008")])]

#text("Dear Sugata,")

#text("As I mentioned in my previous comment, one has to make the additional assumption that Y is minimal in order to mix the fibres together properly. With your example, Y is not minimal (the point {n}, for instance, is a proper subsystem of Y, since the shift here is just the identity).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27765")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2008")])]

#text("Dear professor 陶:")

#text("(1)The last line of definition 2 I think it should be ")#mi("\\alpha \\in K")#text(".")

#text("(2)At the end of the second paragraph of the proof of lemma 1, it is at most")#linebreak()#text(" ")#mi("\\varepsilon/4")

#text("p.s. I realized I can input Chinese characters. :-)")#linebreak()#text(" 刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27801")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2008")])]

#text("Dear 刘: Thanks for the correction!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27832")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2008")])]

#text("Dear professor 陶：")#linebreak()#text(" About the eigenfunction T. Should Tf(x) mean f(T(x)) or ")#mi("f(T^{-1}(x))")#text(" or something else?")#linebreak()#text(" 刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-27854")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear 刘: Tf is always understood to be the function ")#mi("f \\circ T^{-1}")#text(" (see equation (1) of Lecture 1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-28731")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2008")])]

#text("Dear Professor 陶:")

#text("(1)In exercise 8, should the condition “X is minimal ” be added or not? I wonder if a system is isometric extension of itself if and only if it is minimal.")

#text("(2)At the second paragraph of the proof of lemma 2, I think the definition of G should be ")#mi("\\text{Isom}(V_{y_0})")#text("; at the third paragraph, the onto X map should be ")#mi("(y,f)\\mapsto f(x_0)")

#text("(3)The proof of proposition 4, “…it suffices to prove the claim for “group” extensions”.")

#text("(4)After exercise 11, the definition of ")#mi("P(n)")#text(" should be ")#mi("P(n) := ( \\sqrt{2} n^2, 2 \\sqrt{2} n^2 + \\frac{1}{2}n )")#text(", where “n” is missing.")#linebreak()#text(" 刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-28831")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2008")])]

#text("Dear Professor 陶:")#linebreak()#text(" I don’t quite follow the last paragraph. How can one see that the system (5) could still be minimal under a affine transformation?")#linebreak()#text(" yours，")#linebreak()#text(" 刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-28839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2008")])]

#text("Dear 刘:")

#text("When applying the affine transformation, we don’t try to preserve minimality, but we can preserve the property of being dense. If for instance ")#mi("f: ({\\Bbb R}/{\\Bbb Z})^m \\to ({\\Bbb R}/{\\Bbb Z})^d")#text(" is an affine map of full rank from one torus to another (with ")#mi("m \\geq d")#text("), and E is any set which is dense in the domain of f, then f(E) will be dense in the range. In particular, given any minimal dynamical system on ")#mi("({\\Bbb R}/{\\Bbb Z})^m")#text(", the image of any dense orbit under f will be dense in ")#mi("({\\Bbb R}/{\\Bbb Z})^d")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-28855")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2008")])]

#text("Dear Professor 陶:")#linebreak()#text(" I’ve got several corrections above, although it may be my misunderstanding and they may be wrong.")#linebreak()#text(" 刘")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-32685")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2008")])]

#text("Dear 刘:")

#text("Thanks (very belatedly) for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is a gauge? « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-32692")[#strong[#text("What is a gauge? « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2008")])]

#text("[…] There was nothing terribly special about circles in this example; one can also define group extensions, or more generally homogeneous space extensions, of dynamical systems, and have a similar theory, although one has to take a little care with the order of operations when the structure group is non-abelian; see e.g. these lecture notes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the uniformity seminorms associated with the action of F^infty_p « What’s new")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-35119")[#strong[#text("An inverse theorem for the uniformity seminorms associated with the action of F^infty_p « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2009")])]

#text("[…] some standard theory of Mackey and Furstenberg on isometric extensions and group extensions (cf. my lectures on the topological dynamics counterpart to these topics), and of Furstenberg-Weiss on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-40693")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In Definition 5, why is ")#mi("Y := G\\backslash X = \\{ Gx: x \\in X \\}")#text(" a quotient space?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-40694")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In Definition 5, why is ")#mi("Y := G\\backslash X = \\{ Gx: x \\in X \\}")#text(" a quotient space?Is there any typoes there?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-40697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("If one defines the equivalence relation ")#mi("\\sim")#text(" on X by declaring ")#mi("x \\sim y")#text(" iff ")#mi("y = gx")#text(" for some ")#mi("g \\in G")#text(", then Y becomes the quotient space of that relation, see")

#link("http://en.wikipedia.org/wiki/Quotient_space")[#text("http://en.wikipedia.org/wiki/Quotient_space")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 陶哲轩遍历论习题解答：第六讲 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-40698")[#strong[#text("陶哲轩遍历论习题解答：第六讲 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("[…] (注：遍历论为陶哲轩教授于08年年初的一门课程，我尝试将所有习题做出来，这是第五讲的十八个习题。这里是这门课程的主页，这里是本讲的链接。关于拓扑动力系统两种扩张的定义，我用中文写过一个帖子。 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-41948")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Dear Professor Tao:")

#text("I am going over the proof of lemma 1 when I find a problem (I think). The metric d is only defined on The space Y. But metric d is also used on ")#mi("Y_\\alpha")#text(". The metric used there should be derived from d and thus being compatible with each other. Maybe it is worth mentioning to avoid misunderstanding.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-41959")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2009")])]

#text("Ah, yes, one needs to pick another metric ")#mi("d_{Y_\\alpha}")#text(" for ")#mi("Y_\\alpha")#text(". It doesn’t really matter which one, though; from compactness, all metrics are essentially equivalent to each other for the purposes of understanding equicontinuity. (If one wanted to fix a metric, one could use the ")#link("http://en.wikipedia.org/wiki/Hausdorff_distance")[#text("Hausdorff metric")]#text(" on the fibres with respect to d, but this is not necessary.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-45563")[#strong[#text("Solutions to Ergodic Theory：Lecture twelve « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2010")])]

#text("[…] 7. Using Exercise 6, give another proof of Theorem 1 from Lecture 6: (Equidistribution theorem) Let be a polynomial sequence which does not obey any constraint of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-45600")[#strong[#text("Solutions to Ergodic Theory：Lecture Seven « Xiaochuan Liu's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2010")])]

#text("[…] Exercise 4: Show that every topological dynamical system has a maximal distal factor. (Hint: repeat the proof of Corollary 1 from the lecture six.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-66788")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2011")])]

#text("Dear Prof. Tao,")

#text("the claim in the second paragraph of the proof of Lemma 5 should rely on the hypothesis on ")#mi("\\sigma")#text(", since for ")#mi("\\sigma=0")#text(" we obtain ")#mi("H=0")#text(". However, I think that it would be easier to use the full characterization of closed subgroups of torii, replacing the condition")

#mi("H = \\{ \\zeta : m\\cdot\\zeta=0 \\}")

#text("by ")#mi("H = \\{ \\zeta : m_i \\cdot\\zeta=0 \\}")

#text("for a finite family of ")#mi("m_i")#text(" and continuing the argument as stated.")

#text("This way the induction on ")#mi("d")#text(" is eliminated (or rather hidden). Also, there is no need to argue by a double contradiction.")

#text("Note that the same lemma and proof appear as Lemma 2.6.30 in the online preprint of your “year two…” book, which I would like to thank you for on this occasion: the introduction to the ultrafilter approach to topological dynamics has been very illuminating for me.")

#text("Finally, I have a question: how does the converse implication in Exercise 2 work? (i.e. “")#mi("T^p")#text(" are homeomorphisms” implies “")#mi("T^n")#text(" are equicontinuous”)")

#text("best regards,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-66988")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2011")])]

#text("The hypothesis on ")#mi("\\sigma")#text(" is used when the induction hypothesis is invoked (because if ")#mi("\\sigma")#text(" obeys the hypothesis in d dimensions, then the projection ")#mi("\\sigma^{\\prime}")#text(" does too). In particular, ")#mi("\\sigma=0")#text(" will not work for this step (except when d=1) because ")#mi("\\sigma^{\\prime}")#text(" will vanish also.")

#text("It is true that one can handle the full torus in one jump, but I think I preferred the inductive approach for pedagogical reasons, to illustrate the more general technique of proving things about dynamical systems by climbing up towers of extensions that are as simple as possible.")

#text("For Exercise 2: I must have had a slick ultrafilter-based proof of this at some point, but I can’t reconstruct it. Here is a rather messy (and partially ultrafilter-based) proof: put a metric on X. Suppose equicontinuity failed, then there is some ")#mi("\\varepsilon")#text(" such that one can find arbitrarily close x,y such that ")#mi("d(T^n x, T^n y) > \\varepsilon")#text(" for some n. By shifting back and forth, this implies furthermore that for any syndetic set A, one can find arbitrarily close x,y such that ")#mi("d(T^n x, T^n y) > \\varepsilon")#text(" for some n in A.")

#text("On the other hand, the ")#mi("T^p")#text(" are homeomorphisms, and are in particular injective (this is equivalent to distality). Specialising to p a minimal idempotent, we thus have ")#mi("T^p x = x")#text(" for all x. Among other things, this implies that every point in X is almost periodic, and more generally every k-tuple in ")#mi("X^k")#text(" is almost periodic.")

#text("Using these two observations, one can now recursively find a sequence of pairs ")#mi("(x_m,y_m)")#text(" of increasingly close points, such that for each M, the set of n for which ")#mi("d(T^n x_m, T^n y_m) > \\varepsilon")#text(" for all ")#mi("m = 1,\\ldots,M")#text(" is non-empty (and hence syndetic, by joint almost periodicity). One can then construct an ultrafilter p for which ")#mi("d(T^p x_m, T^p y_m) \\geq \\varepsilon")#text(" for all m, contradicting the homeomorphism property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-67361")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2011")])]

#text("Thank you for the explanations. I have now figured out what confused me in Lemma 5: it was not clear to me why the projection of ")#mi("Z")#text(" to ")#mi("Y \\times_{\\sigma^{\\prime}} (R/Z)^{d-1}")#text(" must be a proper subsystem if the projection of ")#mi("H")#text(" to ")#mi("(R/Z)^{d-1}")#text(" is not surjective.")

#text("To get it straight, here is the argument which I have filled in: by the induction hypothesis we know that the projection of ")#mi("Z")#text(" to ")#mi("Y \\times_{\\sigma^{\\prime}} (R/Z)^{d-1}")#text(" is surjective. This means that, given ")#mi("(y,a,b) \\in Z \\subset Y \\times (R/Z)^{d-1} \\times (R/Z)")#text(" fixed, for every ")#mi("a^{\\prime} \\in (R/Z)^{d-1}")#text(" there exists a ")#mi("b^{\\prime} \\in (R/Z)")#text(" such that ")#mi("(y,a+a^{\\prime},b+b^{\\prime}) \\in Z")#text(". But the orbit of the latter point under ")#mi("T")#text(" is just the orbit of the former point shifted by ")#mi("(a^{\\prime},b^{\\prime})")#text(". Since both orbits are dense in ")#mi("Z")#text(" by minimality, we see that ")#mi("Z")#text(" is invariant under translation by ")#mi("(a^{\\prime},b^{\\prime})")#text(", so that ")#mi("a^{\\prime}")#text(" is contained in the projection of ")#mi("H")#text(".")

#text("I have also found the following modification of your argument for Exercise 2:")

#text("consider ")#mi("Y = T^{\\beta Z} \\subset C(X)")#text(" with the uniform topology and the (continuous) action of ")#mi("\\beta Z")#text(" thereon via ")#mi("p T^q = T^{p+q}")#text(". For every minimal ")#mi("q \\in \\beta Z")#text(", the element ")#mi("T^q")#text(" is almost periodic in ")#mi("Y")#text(". This means that the set")

#mi("\\{ n : \\sup_{x \\in X} d(T^n T^q x, T^q x) < \\epsilon \\}")

#text("is syndetic for every positive ")#mi("\\epsilon")#text(". But since ")#mi("T^q")#text(" is surjective, the latter set is equal to")

#mi("\\{ n : \\sup_{x \\in X} d(T^n x, x) < \\epsilon \\}")#text(".")

#text("Uniform continuity of ")#mi("T^1, \\dots, T^N")#text(" for every finite ")#mi("N")#text(" concludes the argument.")

#text("best regards,")#linebreak()#text(" pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-67404")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2011")])]

#text("Dear Pavel,")

#text("This is a nice argument, although I’m a little worried about whether you are assuming implicitly that Y is compact in the uniform topology (which, by Arzela-Ascoli, is very close to the equicontinuity that one is trying to prove!). It is easy to show that Y is compact in the weak topology and closed in the uniform topology, but to get compactness requires some argument (and without compactness, one has to be careful regarding the different formulations of almost periodicity).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-67701")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2011")])]

#text("This is trickier than I believed it would be and I only have a partial result for the moment. ")#mi("Y")#text(" is compact and right topological for the pointwise topology, but also left topological since it consists of homeomorphisms. Moreover, algebraically ")#mi("Y")#text(" is a group, since whenever ")#mi("q")#text(" is a minimal idempotent and ")#mi("r+p+q=q")#text(", we have that ")#mi("T^r T^p = T^r T^p T^q = T^q = id")#text(". By Ellis’ Theorem, ")#mi("Y")#text(" is a topological group, i.e. the multiplication is jointly continuous. But ")#mi("Y")#text(" contains a dense commutative subset, hence is commutative.")

#text("Assume now that ")#mi("X")#text(" is minimal. Then the action of ")#mi("Y")#text(" is transitive and we see that ")#mi("X")#text(" is a Kronecker system (more precisely, the quotient of ")#mi("Y")#text(" by the stabilizer of any point).")

#text("I hope that the commutativity will help to show that ")#mi("Y")#text(" is compact for the uniform topology too. Unfortunately, it is no longer evident that ")#mi("T^Z")#text(" is dense, so that structure theory of monothetic groups is not immediately available.")

#text("best regards,")#linebreak()#text(" pavel")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-154625")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2012")])]

#text("For Exercise 6, what does it mean for an eigenfunction to be unimodular? I didn’t see the definition anywhere…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-154687")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2012")])]

#text("In this context, “unimodular” means that it takes values in S^1 (i.e. it has unit modulus).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-154767")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2012")])]

#text("What is an example of an isometric extension ")#mi("\\pi: X \\longrightarrow Y")#text(" where ")#mi("X")#text(" is not an isometric system?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-154807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2012")])]

#text("See Example 5.")

#text("For a less trivial example, let ")#mi("(Y,T)")#text(" be a system, let ")#mi("K")#text(" be a compact metric space, and for each ")#mi("y \\in Y")#text(", let ")#mi("\\rho_y: K \\to K")#text(" be an isometry that varies continuously in y (using the uniform topology in K). Then the skew-product system ")#mi("Y \\times K")#text(" with shift ")#mi("S: (y,k) \\mapsto (Ty, \\rho_y(k))")#text(" is an isometric extension of Y.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dbb46b0dbbba410d2963b3e2c734a16ad8289dfdd5d019cde62ae009a6eb65d-26e426597f0ddda7a2b66ae53403c5f17f21434090d3ab084d831d8740b0d42b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clemens M")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-456460")[#strong[#text("Clemens M")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2015")])]

#text("Dear Prof. Tao")

#text("I don’t see why the inverse limit factor space ")#mi("Y = \\lim_{\\leftarrow}(Y_{\\alpha})")#text(" is metrisable. Could you provide some insight on that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-456477")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2015")])]

#text("In this set of notes, topological dynamical systems are always understood to be metrisable (see Notes 1). The space Y is a factor of X, which is assumed metrisable, and thus inherits a metric (Hausdorff distance between the fibres in X).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dbb46b0dbbba410d2963b3e2c734a16ad8289dfdd5d019cde62ae009a6eb65d-26e426597f0ddda7a2b66ae53403c5f17f21434090d3ab084d831d8740b0d42b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clemens M")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-456496")[#strong[#text("Clemens M")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2015")])]

#text("More specifically, I am trying to understand why the space ")#mi("Y")#text(" as defined in equation (1) is metrisable. From your answer I understand that the Hausdorff distance could be used as a metric for the space. But I am probably still misunderstanding something, because I don’t see how this metric could generate the correct topology.")

#text("Consider for example ")#mi("X = [0,1]")#text(" with $T = id$ and $Y$ the quotient space obtained by identifying all points in the interval ")#mi("[0,1/2]")#text(" with each other. Then this quotient space is clearly metrisable, but the Hausdorff metric does not seem to be the correct choice. Each one-point set has Hausdorff distance at least ")#mi("1/2")#text(" from ")#mi("[0,1/2 ]")#text(", so with respect to the Hausdorff distance, ")#mi("\\{ [0, 1/2 ] \\}")#text(" would be an open set whereas in the quotient topology it isn’t.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-456505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2015")])]

#text("Hmm, fair enough – but one can still show that any Hausdorff quotient of a compact metric space is metrisable by appealing to Urysohn’s metrisation theorem (take a countable dense subset of the original space, and consider ")#mi("1/n")#text("-neighbourhoods of the fibres they lie in, to obtain a countable base for the quotient).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6dbb46b0dbbba410d2963b3e2c734a16ad8289dfdd5d019cde62ae009a6eb65d-26e426597f0ddda7a2b66ae53403c5f17f21434090d3ab084d831d8740b0d42b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Clemens M")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-456509")[#strong[#text("Clemens M")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2015")])]

#text("Thank you very much for answering my questions!")

#text("To be honest, this approach with the ")#mi("1/n")#text("-neighbourhoods of fibres did not work for me because I was not able to show that for any open set ")#mi("V")#text(" in the quotient space ")#mi("Y")#text(" and every ")#mi("x \\in \\pi^{-1}(V) \\subseteq X")#text(" there is a fibre ")#mi("A")#text(" from the countable collection of fibres such that ")#mi("x \\in U(A, 1/n) \\subseteq \\pi^{-1}(V)")#text(" for some ")#mi("n")#text(".")

#text("However, I found a similar proof in a book in the library yesterday (Willard – General Topology), so I see now that the space is metrisable.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maths student")]], [#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/#comment-513736")[#strong[#text("maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2019")])]

#text("It felt like compact Hausdorff uniform spaces should have been metrisable (ie. countable entourage system), but sadly ")#mi("I^I")#text(" with ")#mi("I")#text(" the unit interval seems to be a counterexample… Too bad, would’ve simplified the def. of Kronecker systems…")
]
