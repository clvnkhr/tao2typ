// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/
// Converted to Typst by tao2typ: "2026-10-14T16:37:57.062172+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on the “slice rank” of tensors", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on the “slice rank” of tensors")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 24 August 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/")[#text("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#emph[#text("[This blog post was written jointly by Terry Tao and ")#link("https://web.math.princeton.edu/~wsawin/")[#text("Will Sawin")]#text(".]")]

#text("In ")#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/")[#text("the previous blog post")]#text(", one of us (Terry) implicitly introduced a notion of rank for tensors which is a little different from the usual notion of tensor rank, and which (following ")#link("https://arxiv.org/abs/1605.06702")[#text("BCCGNSU")]#text(") we will call “slice rank”. This notion of rank could then be used to encode the Croot-Lev-Pach-Ellenberg-Gijswijt argument that uses the polynomial method to control capsets.")

#text("Afterwards, several papers have applied the slice rank method to further problems – to control tri-colored sum-free sets in abelian groups (")#link("https://arxiv.org/abs/1605.06702")[#text("BCCGNSU")]#text(", ")#link("https://arxiv.org/abs/1607.00047")[#text("KSS")]#text(") and from there to the triangle removal lemma in vector spaces over finite fields (")#link("https://arxiv.org/abs/1606.01230")[#text("FL")]#text("), to control sunflowers (")#link("https://arxiv.org/abs/1606.09575")[#text("NS")]#text("), and to bound progression-free sets in ")#mi("{p}")#text("-groups (")#link("https://arxiv.org/abs/1606.03256")[#text("P")]#text(").")

#text("In this post we investigate the notion of slice rank more systematically. In particular, we show how to give lower bounds for the slice rank. In many cases, we can show that the upper bounds on slice rank given in the aforementioned papers are sharp to within a subexponential factor. This still leaves open the possibility of getting a better bound for the original combinatorial problem using the slice rank of some other tensor, but for very long arithmetic progressions (at least eight terms), we show that the slice rank method cannot improve over the trivial bound using any tensor.")

#text("It will be convenient to work in a “basis independent” formalism, namely working in the category of abstract finite-dimensional vector spaces over a fixed field ")#mi("{{\\bf F}}")#text(". (In the applications to the capset problem one takes ")#mi("{{\\bf F}={\\bf F}_3}")#text(" to be the finite field of three elements, but most of the discussion here applies to arbitrary fields.) Given ")#mi("{k}")#text(" such vector spaces ")#mi("{V_1,\\dots,V_k}")#text(", we can form the ")#link("https://en.wikipedia.org/wiki/Tensor_product")[#text("tensor product")]#text(" ")#mi("{\\bigotimes_{i=1}^k V_i}")#text(", generated by the tensor products ")#mi("{v_1 \\otimes \\dots \\otimes v_k}")#text(" with ")#mi("{v_i \\in V_i}")#text(" for ")#mi("{i=1,\\dots,k}")#text(", subject to the constraint that the tensor product operation ")#mi("{(v_1,\\dots,v_k) \\mapsto v_1 \\otimes \\dots \\otimes v_k}")#text(" is multilinear. For each ")#mi("{1 \\leq j \\leq k}")#text(", we have the smaller tensor products ")#mi("{\\bigotimes_{1 \\leq i \\leq k: i \\neq j} V_i}")#text(", as well as the ")#mi("{j^{th}}")#text(" tensor product")

#align(center)[#tao-fit-display[#mitex("\\otimes_j: V_j \\times \\bigotimes_{1 \\leq i \\leq k: i \\neq j} V_i \\rightarrow \\bigotimes_{i=1}^k V_i")]]

#text("defined in the obvious fashion. Elements of ")#mi("{\\bigotimes_{i=1}^k V_i}")#text(" of the form ")#mi("{v_j \\otimes_j v_{\\hat j}}")#text(" for some ")#mi("{v_j \\in V_j}")#text(" and ")#mi("{v_{\\hat j} \\in \\bigotimes_{1 \\leq i \\leq k: i \\neq j} V_i}")#text(" will be called ")#emph[#text("rank one functions")]#text(", and the ")#emph[#text("slice rank")]#text(" (or ")#emph[#text("rank")]#text(" for short) ")#mi("{\\text{rank}(v)}")#text(" of an element ")#mi("{v}")#text(" of ")#mi("{\\bigotimes_{i=1}^k V_i}")#text(" is defined to be the least nonnegative integer ")#mi("{r}")#text(" such that ")#mi("{v}")#text(" is a linear combination of ")#mi("{r}")#text(" rank one functions. If ")#mi("{V_1,\\dots,V_k}")#text(" are finite-dimensional, then the rank is always well defined as a non-negative integer (in fact it cannot exceed ")#mi("{\\min( \\text{dim}(V_1), \\dots, \\text{dim}(V_k))}")#text(". It is also clearly subadditive: ")#metadata(none) <tao-a4b2c567d8a52febcc7e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\text{rank}(v+w) \\leq \\text{rank}(v) + \\text{rank}(w).")]]





#text("For ")#mi("{k=1}")#text(", ")#mi("{\\text{rank}(v)}")#text(" is ")#mi("{0}")#text(" when ")#mi("{v}")#text(" is zero, and ")#mi("{1}")#text(" otherwise. For ")#mi("{k=2}")#text(", ")#mi("{\\text{rank}(v)}")#text(" is the usual rank of the ")#mi("{2}")#text("-tensor ")#mi("{v \\in V_1 \\otimes V_2}")#text(" (which can for instance be identified with a linear map from ")#mi("{V_1}")#text(" to the dual space ")#mi("{V_2^*}")#text("). The usual notion of tensor rank for higher order tensors uses complete tensor products ")#mi("{v_1 \\otimes \\dots \\otimes v_k}")#text(", ")#mi("{v_i \\in V_i}")#text(" as the rank one objects, rather than ")#mi("{v_j \\otimes_j v_{\\hat j}}")#text(", giving a rank that is greater than or equal to the slice rank studied here.")

#text("From basic linear algebra we have the following equivalences:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" ")#metadata(none) <tao-785fda86872f7ba2ab7c>#text(" Let ")#mi("{V_1,\\dots,V_k}")#text(" be finite-dimensional vector spaces over a field ")#mi("{{\\bf F}}")#text(", let ")#mi("{v}")#text(" be an element of ")#mi("{V_1 \\otimes \\dots \\otimes V_k}")#text(", and let ")#mi("{r}")#text(" be a non-negative integer. Then the following are equivalent:")

#list(
[#text("(i) One has ")#mi("{\\text{rank}(v) \\leq r}")#text(".")],
[#text("(ii) One has a representation of the form")

#align(center)[#tao-fit-display[#mitex("v = \\sum_{j=1}^k \\sum_{s \\in S_j} v_{j,s} \\otimes_j v_{\\hat j,s}")]]

#text("where ")#mi("{S_1,\\dots,S_k}")#text(" are finite sets of total cardinality ")#tao-math("{\\left|S_1\\right|+\\dots+\\left|S_k\\right|}", block: false)#text(" at most ")#mi("{r}")#text(", and for each ")#mi("{1 \\leq j \\leq k}")#text(" and ")#mi("{s \\in S_j}")#text(", ")#mi("{v_{j,s} \\in V_j}")#text(" and ")#mi("{v_{\\hat j,s} \\in \\bigotimes_{1 \\leq i \\leq k: i \\neq j} V_i}")#text(".")],
[#text("(iii) One has")

#align(center)[#tao-fit-display[#mitex("v \\in \\sum_{j=1}^k U_j \\otimes_j \\bigotimes_{1 \\leq i \\leq k: i \\neq j} V_i")]]

#text("where for each ")#mi("{j=1,\\dots,k}")#text(", ")#mi("{U_j}")#text(" is a subspace of ")#mi("{V_j}")#text(" of total dimension ")#mi("{\\text{dim}(U_1)+\\dots+\\text{dim}(U_k)}")#text(" at most ")#mi("{r}")#text(", and we view ")#mi("{U_j \\otimes_j \\bigotimes_{1 \\leq i \\leq k: i \\neq j} V_i}")#text(" as a subspace of ")#mi("{\\bigotimes_{i=1}^k V_i}")#text(" in the obvious fashion.")],
[#text("(iv) (Dual formulation) There exist subspaces ")#mi("{W_j}")#text(" of the dual space ")#mi("{V_j^*}")#text(" for ")#mi("{j=1,\\dots,k}")#text(", of total dimension at least ")#mi("{\\text{dim}(V_1)+\\dots+\\text{dim}(V_k) - r}")#text(", such that ")#mi("{v}")#text(" is orthogonal to ")#mi("{\\bigotimes_{j=1}^k W_j}")#text(", in the sense that one has the vanishing")

#align(center)[#tao-fit-display[#mitex("\\langle \\bigotimes_{j=1}^k w_j, v \\rangle = 0")]]

#text("for all ")#mi("{w_j \\in W_j}")#text(", where ")#mi("{\\langle, \\rangle: \\bigotimes_{j=1}^k V_j^* \\times \\bigotimes_{j=1}^k V_j \\rightarrow {\\bf F}}")#text(" is the obvious pairing.")]
)
]

#emph[#text("Proof:")]#text(" The equivalence of (i) and (ii) is clear from definition. To get from (ii) to (iii) one simply takes ")#mi("{U_j}")#text(" to be the span of the ")#mi("{v_{j,s}}")#text(", and conversely to get from (iii) to (ii) one takes the ")#mi("{v_{j,s}}")#text(" to be a basis of the ")#mi("{U_j}")#text(" and computes ")#mi("{v_{\\hat j,s}}")#text(" by using a basis for the tensor product ")#mi("{\\bigotimes_{j=1}^k U_j \\otimes_j \\bigotimes_{1 \\leq i \\leq k: i \\neq j} V_i}")#text(" consisting entirely of functions of the form ")#mi("{v_{j,s} \\otimes_j e}")#text(" for various ")#mi("{e}")#text(". To pass from (iii) to (iv) one takes ")#mi("{W_j}")#text(" to be the annihilator ")#mi("{\\{ w_j \\in V_j: \\langle w_j, v_j \\rangle = 0 \\forall v_j \\in U_j \\}}")#text(" of ")#mi("{U_j}")#text(", and conversely to pass from (iv) to (iii). ")#mi("\\Box")

#text("One corollary of the formulation (iv), is that the set of tensors of slice rank at most ")#mi("{r}")#text(" is Zariski closed (if the field ")#mi("{{\\mathbf F}}")#text(" is algebraically closed), and so the slice rank itself is a lower semi-continuous function. This is in contrast to the usual tensor rank, which is not necessarily semicontinuous.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" Let ")#mi("{V_1,\\dots, V_k}")#text(" be finite-dimensional vector spaces over an algebraically closed field ")#mi("{{\\bf F}}")#text(". Let ")#mi("{r}")#text(" be a nonnegative integer. The set of elements of ")#mi("{V_1 \\otimes \\dots \\otimes V_k}")#text(" of slice rank at most ")#mi("{r}")#text(" is closed in the ")#link("https://en.wikipedia.org/wiki/Zariski_topology")[#text("Zariski topology")]#text(".")
]

#emph[#text("Proof:")]#text(" In view of Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text("(i and iv), this set is the union over tuples of integers ")#mi("{d_1,\\dots,d_k}")#text(" with ")#mi("{d_1 + \\dots + d_k \\geq \\text{dim}(V_1)+\\dots+\\text{dim}(V_k) - r}")#text(" of the projection from ")#mi("{\\text{Gr}(d_1, V_1) \\times \\dots \\times \\text{Gr}(d_k, V_k) \\times ( V_1 \\otimes \\dots \\otimes V_k)}")#text(" of the set of tuples ")#mi("{(W_1,\\dots,W_k, v)}")#text(" with ")#mi("{ v}")#text(" orthogonal to ")#mi("{W_1 \\times \\dots \\times W_k}")#text(", where ")#mi("{\\text{Gr}(d,V)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Grassmannian")[#text("Grassmanian")]#text(" parameterizing ")#mi("{d}")#text("-dimensional subspaces of ")#mi("{V}")#text(".")

#text("One can check directly that the set of tuples ")#mi("{(W_1,\\dots,W_k, v)}")#text(" with ")#mi("{ v}")#text(" orthogonal to ")#mi("{W_1 \\times \\dots \\times W_k}")#text(" is Zariski closed in ")#mi("{\\text{Gr}(d_1, V_1) \\times \\dots \\times \\text{Gr}(d_k, V_k) \\times V_1 \\otimes \\dots \\otimes V_k}")#text(" using a set of equations of the form ")#mi("{\\langle \\bigotimes_{j=1}^k w_j, v \\rangle = 0}")#text(" locally on ")#mi("{\\text{Gr}(d_1, V_1) \\times \\dots \\times \\text{Gr}(d_k, V_k) }")#text(". Hence because the Grassmanian is a ")#link("https://en.wikipedia.org/wiki/Complete_variety")[#text("complete variety")]#text(", the projection of this set to ")#mi("{V_1 \\otimes \\dots \\otimes V_k}")#text(" is also Zariski closed. So the finite union over tuples ")#mi("{d_1,\\dots,d_k}")#text(" of these projections is also Zariski closed.")

#mi("\\Box")

#text("We also have good behaviour with respect to linear transformations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" ")#metadata(none) <tao-e7502c799b8f76fbed07>#text(" Let ")#mi("{V_1,\\dots,V_k, W_1,\\dots,W_k}")#text(" be finite-dimensional vector spaces over a field ")#mi("{{\\bf F}}")#text(", let ")#mi("{v}")#text(" be an element of ")#mi("{V_1 \\otimes \\dots \\otimes V_k}")#text(", and for each ")#mi("{1 \\leq j \\leq k}")#text(", let ")#mi("{\\phi_j: V_j \\rightarrow W_j}")#text(" be a linear transformation, with ")#mi("{\\bigotimes_{j=1}^k \\phi_j: \\bigotimes_{j=1}^k V_k \\rightarrow \\bigotimes_{j=1}^k W_k}")#text(" the tensor product of these maps. Then ")#metadata(none) <tao-7a1b1850245e45c50d0a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\text{rank}( (\\bigotimes_{j=1}^k \\phi_j)(v) ) \\leq \\text{rank}(v).")]]



#text(" Furthermore, if the ")#mi("{\\phi_j}")#text(" are all injective, then one has equality in ")#link(<tao-7a1b1850245e45c50d0a>)[#text("(2)")]#text(".")
]

#text("Thus, for instance, the rank of a tensor ")#mi("{v \\in \\bigotimes_{j=1}^k V_k}")#text(" is intrinsic in the sense that it is unaffected by any enlargements of the spaces ")#mi("{V_1,\\dots,V_k}")#text(".")

#emph[#text("Proof:")]#text(" The bound ")#link(<tao-7a1b1850245e45c50d0a>)[#text("(2)")]#text(" is clear from the formulation (ii) of rank in Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text(". For equality, apply ")#link(<tao-7a1b1850245e45c50d0a>)[#text("(2)")]#text(" to the injective ")#mi("{\\phi_j}")#text(", as well as to some arbitrarily chosen left inverses ")#mi("{\\phi_j^{-1}: W_j \\rightarrow V_j}")#text(" of the ")#mi("{\\phi_j}")#text(". ")#mi("\\Box")

#text("Computing the rank of a tensor is difficult in general; however, the problem becomes a combinatorial one if one has a suitably sparse representation of that tensor in some basis, where we will measure sparsity by the property of being an ")#link("https://en.wikipedia.org/wiki/Antichain")[#text("antichain")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 4")]#text(" ")#metadata(none) <tao-617dab84791917e3fe34>#text(" Let ")#mi("{V_1,\\dots,V_k}")#text(" be finite-dimensional vector spaces over a field ")#mi("{{\\bf F}}")#text(". For each ")#mi("{1 \\leq j \\leq k}")#text(", let ")#mi("{(v_{j,s})_{s \\in S_j}}")#text(" be a linearly independent set in ")#mi("{V_j}")#text(" indexed by some finite set ")#mi("{S_j}")#text(". Let ")#mi("{\\Gamma}")#text(" be a subset of ")#mi("{S_1 \\times \\dots \\times S_k}")#text(".")

#text("Let ")#mi("{v \\in \\bigotimes_{j=1}^k V_j}")#text(" be a tensor of the form ")#metadata(none) <tao-89b73d84ce1d89e5039d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("v = \\sum_{(s_1,\\dots,s_k) \\in \\Gamma} c_{s_1,\\dots,s_k} v_{1,s_1} \\otimes \\dots \\otimes v_{k,s_k}")]]



#text(" where for each ")#mi("{(s_1,\\dots,s_k)}")#text(", ")#mi("{c_{s_1,\\dots,s_k}}")#text(" is a coefficient in ")#mi("{{\\bf F}}")#text(". Then one has ")#metadata(none) <tao-942121ae9b804b44c657>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\text{rank}(v) \\leq \\min_{\\Gamma = \\Gamma_1 \\cup \\dots \\cup \\Gamma_k} \\left|\\pi_1(\\Gamma_1)\\right| + \\dots + \\left|\\pi_k(\\Gamma_k)\\right|", block: true)]]



#text(" where the minimum ranges over all coverings of ")#mi("{\\Gamma}")#text(" by sets ")#mi("{\\Gamma_1,\\dots,\\Gamma_k}")#text(", and ")#mi("{\\pi_j: S_1 \\times \\dots \\times S_k \\rightarrow S_j}")#text(" for ")#mi("{j=1,\\dots,k}")#text(" are the projection maps.")

#text("Now suppose that the coefficients ")#mi("{c_{s_1,\\dots,s_k}}")#text(" are all non-zero, that each of the ")#mi("{S_j}")#text(" are equipped with a total ordering ")#mi("{\\leq_j}")#text(", and ")#mi("{\\Gamma^{\\prime}}")#text(" is the set of maximal elements of ")#mi("{\\Gamma}")#text(", thus there do not exist distinct ")#mi("{(s_1,\\dots,s_k) \\in \\Gamma^{\\prime}}")#text(", ")#mi("{(t_1,\\dots,t_k) \\in \\Gamma}")#text(" such that ")#mi("{s_j \\leq t_j}")#text(" for all ")#mi("{j=1,\\dots,k}")#text(". Then one has ")#metadata(none) <tao-7ec1587736e091bafc3e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\text{rank}(v) \\geq \\min_{\\Gamma^{\\prime} = \\Gamma_1 \\cup \\dots \\cup \\Gamma_k} \\left|\\pi_1(\\Gamma_1)\\right| + \\dots + \\left|\\pi_k(\\Gamma_k)\\right|.", block: true)]]



#text(" In particular, if ")#mi("{\\Gamma}")#text(" is an antichain (i.e. every element is maximal), then equality holds in ")#link(<tao-942121ae9b804b44c657>)[#text("(4)")]#text(".")
]

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-e7502c799b8f76fbed07>)[#text("3")]#text(" (or by enlarging the bases ")#mi("{v_{j,s_j}}")#text("), we may assume without loss of generality that each of the ")#mi("{V_j}")#text(" is spanned by the ")#mi("{v_{j,s_j}}")#text(". By relabeling, we can also assume that each ")#mi("{S_j}")#text(" is of the form")

#align(center)[#tao-fit-display[#tao-math("S_j = \\{1,\\dots,\\left|S_j\\right|\\}", block: true)]]

#text("with the usual ordering, and by Lemma ")#link(<tao-e7502c799b8f76fbed07>)[#text("3")]#text(" we may take each ")#mi("{V_j}")#text(" to be ")#tao-math("{{\\bf F}^{\\left|S_j\\right|}}", block: false)#text(", with ")#mi("{v_{j,s_j} = e_{s_j}}")#text(" the standard basis.")

#text("Let ")#mi("{r}")#text(" denote the rank of ")#mi("{v}")#text(". To show ")#link(<tao-942121ae9b804b44c657>)[#text("(4)")]#text(", it suffices to show the inequality ")#metadata(none) <tao-ac0b52a2ae6ef99999bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("r \\leq \\left|\\pi_1(\\Gamma_1)\\right| + \\dots + \\left|\\pi_k(\\Gamma_k)\\right|", block: true)]]



#text(" for any covering of ")#mi("{\\Gamma}")#text(" by ")#mi("{\\Gamma_1,\\dots,\\Gamma_k}")#text(". By removing repeated elements we may assume that the ")#mi("{\\Gamma_i}")#text(" are disjoint. For each ")#mi("{1 \\leq j \\leq k}")#text(", the tensor")

#align(center)[#tao-fit-display[#mitex("\\sum_{(s_1,\\dots,s_k) \\in \\Gamma_j} c_{s_1,\\dots,s_k} e_{s_1} \\otimes \\dots \\otimes e_{s_k}")]]

#text("can (after collecting terms) be written as")

#align(center)[#tao-fit-display[#mitex("\\sum_{s_j \\in \\pi_j(\\Gamma_j)} e_{s_j} \\otimes_j v_{\\hat j,s_j}")]]

#text("for some ")#tao-math("{v_{\\hat j, s_j} \\in \\bigotimes_{1 \\leq i \\leq k: i \\neq j} {\\bf F}^{\\left|S_i\\right|}}", block: false)#text(". Summing and using ")#link(<tao-a4b2c567d8a52febcc7e>)[#text("(1)")]#text(", we conclude the inequality ")#link(<tao-ac0b52a2ae6ef99999bc>)[#text("(6)")]#text(".")

#text("Now assume that the ")#mi("{c_{s_1,\\dots,s_k}}")#text(" are all non-zero and that ")#mi("{\\Gamma^{\\prime}}")#text(" is the set of maximal elements of ")#mi("{\\Gamma}")#text(". To conclude the proposition, it suffices to show that the reverse inequality ")#metadata(none) <tao-d5be8fe5a2433605843d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("r \\geq \\left|\\pi_1(\\Gamma_1)\\right| + \\dots + \\left|\\pi_k(\\Gamma_k)\\right|", block: true)]]



#text(" holds for some ")#mi("{\\Gamma_1,\\dots,\\Gamma_k}")#text(" covering ")#mi("{\\Gamma^{\\prime}}")#text(". By Lemma ")#link(<tao-785fda86872f7ba2ab7c>)[#text("1")]#text("(iv), there exist subspaces ")#mi("{W_j}")#text(" of ")#tao-math("{({\\bf F}^{\\left|S_j\\right|})^*}", block: false)#text(" whose dimension ")#mi("{d_j := \\text{dim}(W_j)}")#text(" sums to ")#metadata(none) <tao-8808396d9ff626b4d7b1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_{j=1}^k d_j = \\sum_{j=1}^k \\left|S_j\\right| - r", block: true)]]



#text(" such that ")#mi("{v}")#text(" is orthogonal to ")#mi("{\\bigotimes_{j=1}^k W_j}")#text(".")

#text("Let ")#mi("{1 \\leq j \\leq k}")#text(". Using Gaussian elimination, one can find a basis ")#mi("{w_{j,1},\\dots,w_{j,d_j}}")#text(" of ")#mi("{W_j}")#text(" whose representation in the standard dual basis ")#tao-math("{e^*_{1},\\dots,e^*_{\\left|S_j\\right|}}", block: false)#text(" of ")#tao-math("{({\\bf F}^{\\left|S_j\\right|})^*}", block: false)#text(" is in row-echelon form. That is to say, there exist natural numbers")

#align(center)[#tao-fit-display[#tao-math("1 \\leq s_{j,1} < \\dots < s_{j,d_j} \\leq \\left|S_j\\right|", block: true)]]

#text("such that for all ")#mi("{1 \\leq t \\leq d_j}")#text(", ")#mi("{w_{j,t}}")#text(" is a linear combination of the dual vectors ")#tao-math("{e^*_{s_{j,t}},\\dots,e^*_{\\left|S_j\\right|}}", block: false)#text(", with the ")#mi("{e^*_{s_{j,t}}}")#text(" coefficient equal to one.")

#text("We now claim that ")#mi("{\\prod_{j=1}^k \\{ s_{j,t}: 1 \\leq t \\leq d_j \\}}")#text(" is disjoint from ")#mi("{\\Gamma^{\\prime}}")#text(". Suppose for contradiction that this were not the case, thus there exists ")#mi("{1 \\leq t_j \\leq d_j}")#text(" for each ")#mi("{1 \\leq j \\leq k}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("(s_{1,t_1}, \\dots, s_{k,t_k}) \\in \\Gamma^{\\prime}.")]]

#text("As ")#mi("{\\Gamma^{\\prime}}")#text(" is the set of maximal elements of ")#mi("{\\Gamma}")#text(", this implies that")

#align(center)[#tao-fit-display[#mitex("(s^{\\prime}_1,\\dots,s^{\\prime}_k) \\not \\in \\Gamma")]]

#text("for any tuple ")#tao-math("{(s^{\\prime}_1,\\dots,s^{\\prime}_k) \\in \\prod_{j=1}^k \\{ s_{j,t_j}, \\dots, \\left|S_j\\right|\\}}", block: false)#text(" other than ")#mi("{(s_{1,t_1}, \\dots, s_{k,t_k})}")#text(". On the other hand, we know that ")#mi("{w_{j,t_j}}")#text(" is a linear combination of ")#tao-math("{e^*_{s_{j,t_j}},\\dots,e^*_{\\left|S_j\\right|}}", block: false)#text(", with the ")#mi("{e^*_{s_{j,t_j}}}")#text(" coefficient one. We conclude that the tensor product ")#mi("{\\bigotimes_{j=1}^k w_{j,t_j}}")#text(" is equal to")

#align(center)[#tao-fit-display[#mitex("\\bigotimes_{j=1}^k e^*_{s_{j,t_j}}")]]

#text("plus a linear combination of other tensor products ")#mi("{\\bigotimes_{j=1}^k e^*_{s^{\\prime}_j}}")#text(" with ")#mi("{(s^{\\prime}_1,\\dots,s^{\\prime}_k)}")#text(" not in ")#mi("{\\Gamma}")#text(". Taking inner products with ")#link(<tao-89b73d84ce1d89e5039d>)[#text("(3)")]#text(", we conclude that ")#mi("{\\langle v, \\bigotimes_{j=1}^k w_{j,t_j}\\rangle = c_{s_{1,t_1},\\dots,s_{k,t_k}} \\neq 0}")#text(", contradicting the fact that ")#mi("{v}")#text(" is orthogonal to ")#mi("{\\prod_{j=1}^k W_j}")#text(". Thus we have ")#mi("{\\prod_{j=1}^k \\{ s_{j,t}: 1 \\leq t \\leq d_j \\}}")#text(" disjoint from ")#mi("{\\Gamma^{\\prime}}")#text(".")

#text("For each ")#mi("{1 \\leq j \\leq k}")#text(", let ")#mi("{\\Gamma_j}")#text(" denote the set of tuples ")#mi("{(s_1,\\dots,s_k)}")#text(" in ")#mi("{\\Gamma^{\\prime}}")#text(" with ")#mi("{s_j}")#text(" not of the form ")#mi("{\\{ s_{j,t}: 1 \\leq t \\leq d_j \\}}")#text(". From the previous discussion we see that the ")#mi("{\\Gamma_j}")#text(" cover ")#mi("{\\Gamma^{\\prime}}")#text(", and we clearly have ")#tao-math("{\\pi_j(\\Gamma_j) \\leq \\left|S_j\\right| - d_j}", block: false)#text(", and hence from ")#link(<tao-8808396d9ff626b4d7b1>)[#text("(8)")]#text(" we have ")#link(<tao-d5be8fe5a2433605843d>)[#text("(7)")]#text(" as claimed. ")#mi("\\Box")

#text("As an instance of this proposition, we recover the computation of diagonal rank from the ")#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/")[#text("previous blog post")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 5")]#text(" Let ")#mi("{V_1,\\dots,V_k}")#text(" be finite-dimensional vector spaces over a field ")#mi("{{\\bf F}}")#text(" for some ")#mi("{k \\geq 2}")#text(". Let ")#mi("{d}")#text(" be a natural number, and for ")#mi("{1 \\leq j \\leq k}")#text(", let ")#mi("{e_{j,1},\\dots,e_{j,d}}")#text(" be a linearly independent set in ")#mi("{V_j}")#text(". Let ")#mi("{c_1,\\dots,c_d}")#text(" be non-zero coefficients in ")#mi("{{\\bf F}}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{t=1}^d c_t e_{1,t} \\otimes \\dots \\otimes e_{k,t}")]]

#text("has rank ")#mi("{d}")#text(". Indeed, one applies the proposition with ")#mi("{S_1,\\dots,S_k}")#text(" all equal to ")#mi("{\\{1,\\dots,d\\}}")#text(", with ")#mi("{\\Gamma}")#text(" the diagonal in ")#mi("{S_1 \\times \\dots \\times S_k}")#text("; this is an antichain if we give one of the ")#mi("{S_i}")#text(" the standard ordering, and another of the ")#mi("{S_i}")#text(" the opposite ordering (and ordering the remaining ")#mi("{S_i}")#text(" arbitrarily). In this case, the ")#mi("{\\pi_j}")#text(" are all bijective, and so it is clear that the minimum in ")#link(<tao-942121ae9b804b44c657>)[#text("(4)")]#text(" is simply ")#mi("{d}")#text(".")
]

#text("The combinatorial minimisation problem in the above proposition can be solved asymptotically when working with tensor powers, using the notion of the ")#link("https://en.wikipedia.org/wiki/Shannon_entropy")[#text("Shannon entropy")]#text(" ")#mi("{h(X)}")#text(" of a discrete random variable ")#mi("{X}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" ")#metadata(none) <tao-48b676e2b107da679512>#text(" Let ")#mi("{V_1,\\dots,V_k}")#text(" be finite-dimensional vector spaces over a field ")#mi("{{\\bf F}}")#text(". For each ")#mi("{1 \\leq j \\leq k}")#text(", let ")#mi("{(v_{j,s})_{s \\in S_j}}")#text(" be a linearly independent set in ")#mi("{V_j}")#text(" indexed by some finite set ")#mi("{S_j}")#text(". Let ")#mi("{\\Gamma}")#text(" be a non-empty subset of ")#mi("{S_1 \\times \\dots \\times S_k}")#text(".")

#text("Let ")#mi("{v \\in \\bigotimes_{j=1}^k V_j}")#text(" be a tensor of the form ")#link(<tao-89b73d84ce1d89e5039d>)[#text("(3)")]#text(" for some coefficients ")#mi("{c_{s_1,\\dots,s_k}}")#text(". For each natural number ")#mi("{n}")#text(", let ")#mi("{v^{\\otimes n}}")#text(" be the tensor power of ")#mi("{n}")#text(" copies of ")#mi("{v}")#text(", viewed as an element of ")#mi("{\\bigotimes_{j=1}^k V_j^{\\otimes n}}")#text(". Then ")#metadata(none) <tao-aaf68ada0efca2fabd36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\text{rank}(v^{\\otimes n}) \\leq \\exp( (H + o(1)) n )")]]



#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", where ")#mi("{H}")#text(" is the quantity ")#metadata(none) <tao-62846fbd68c1b929cce1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("H = \\text{sup}_{(X_1,\\dots,X_k)} \\text{min}( h(X_1), \\dots, h(X_k) )")]]



#text(" and ")#mi("{(X_1,\\dots,X_k)}")#text(" range over the random variables taking values in ")#mi("{\\Gamma}")#text(".")

#text("Now suppose that the coefficients ")#mi("{c_{s_1,\\dots,s_k}}")#text(" are all non-zero and that each of the ")#mi("{S_j}")#text(" are equipped with a total ordering ")#mi("{\\leq_j}")#text(". Let ")#mi("{\\Gamma^{\\prime}}")#text(" be the set of maximal elements of ")#mi("{\\Gamma}")#text(" in the product ordering, and let ")#mi("{H^{\\prime} = \\text{sup}_{(X_1,\\dots,X_k)} \\text{min}( h(X_1), \\dots, h(X_k) ) }")#text(" where ")#mi("{(X_1,\\dots,X_k)}")#text(" range over random variables taking values in ")#mi("{\\Gamma^{\\prime}}")#text(". Then ")#metadata(none) <tao-8e2d10f02742e6b70e53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\text{rank}(v^{\\otimes n}) \\geq \\exp( (H^{\\prime} + o(1)) n )")]]



#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". In particular, if the maximizer in ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(" is supported on the maximal elements of ")#mi("{\\Gamma}")#text(" (which always holds if ")#mi("{\\Gamma}")#text(" is an antichain in the product ordering), then equality holds in ")#link(<tao-aaf68ada0efca2fabd36>)[#text("(9)")]#text(".")
]

#emph[#text("Proof:")]

#text("It will suffice to show that ")#metadata(none) <tao-34c4ba8f5ba5f40e56e4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\min_{\\Gamma^n = \\Gamma_{n,1} \\cup \\dots \\cup \\Gamma_{n,k}} \\left|\\pi_{n,1}(\\Gamma_{n,1})\\right| + \\dots + \\left|\\pi_{n,k}(\\Gamma_{n,k})\\right| = \\exp( (H + o(1)) n )", block: true)]]



#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", where ")#mi("{\\pi_{n,j}: \\prod_{i=1}^k S_i^n \\rightarrow S_j^n}")#text(" is the projection map. Then the same thing will apply to ")#mi("{\\Gamma^{\\prime}}")#text(" and ")#mi("{H^{\\prime}}")#text(". Then applying Proposition ")#link(<tao-617dab84791917e3fe34>)[#text("4")]#text(", using the lexicographical ordering on ")#mi("{S_j^n}")#text(" and noting that, if ")#mi("{\\Gamma^{\\prime}}")#text(" are the maximal elements of ")#mi("{\\Gamma}")#text(", then ")#mi("{\\Gamma^{\\prime n}}")#text(" are the maximal elements of ")#mi("{\\Gamma^n}")#text(", we obtain both ")#link(<tao-aaf68ada0efca2fabd36>)[#text("(9)")]#text(" and ")#link(<tao-8e2d10f02742e6b70e53>)[#text("(11)")]#text(".")

#text("We first prove the lower bound. By compactness (and the continuity properties of entropy), we can find a random variable ")#mi("{(X_1,\\dots,X_k)}")#text(" taking values in ")#mi("{\\Gamma}")#text(" such that ")#metadata(none) <tao-ff94fe54203a912ee5ed>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("H = \\text{min}( h(X_1), \\dots, h(X_k) ).")]]



#text(" Let ")#mi("{\\varepsilon = o(1)}")#text(" be a small positive quantity that goes to zero sufficiently slowly with ")#mi("{n}")#text(". Let ")#mi("{\\Sigma = \\Sigma_{X_1,\\dots,X_k} \\subset \\Gamma^n}")#text(" denote the set of all tuples ")#mi("{(a_1, \\dots, \\vec a_n)}")#text(" in ")#mi("{\\Gamma^n}")#text(" that are within ")#mi("{\\varepsilon}")#text(" of being distributed according to the law of ")#mi("{(X_1,\\dots,X_k)}")#text(", in the sense that for all ")#mi("{a \\in \\Gamma}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\frac{\\left|\\{ 1 \\leq l \\leq n: a_l = a \\}\\right|}{n} - {\\bf P}( (X_1,\\dots,X_k) = a )\\right| \\leq \\varepsilon.", block: true)]]

#text("By the ")#link("https://en.wikipedia.org/wiki/Asymptotic_equipartition_property")[#text("asymptotic equipartition property")]#text(", the cardinality of ")#mi("{\\Sigma}")#text(" can be computed to be ")#metadata(none) <tao-a2f005a07e20c66a1995>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left|\\Sigma\\right| = \\exp( (h( X_1,\\dots,X_k)+o(1)) n )", block: true)]]



#text(" if ")#mi("{\\varepsilon}")#text(" goes to zero slowly enough. Similarly one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\pi_{n,j}(\\Sigma)\\right| = \\exp( (h( X_j)+o(1)) n ),", block: true)]]

#text("and for each ")#mi("{s_{n,j} \\in \\pi_{n,j}(\\Sigma)}")#text(", one has ")#metadata(none) <tao-ff7006235a21f3fe3ffd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\{ \\sigma \\in \\Sigma: \\pi_{n,j}(\\sigma) = s_{n,j} \\}\\right| \\leq \\exp( (h( X_1,\\dots,X_k)-h(X_j)+o(1)) n ).", block: true)]]



#text(" Now let ")#mi("{\\Gamma^n = \\Gamma_{n,1} \\cup \\dots \\cup \\Gamma_{n,k}}")#text(" be an arbitrary covering of ")#mi("{\\Gamma^n}")#text(". By the pigeonhole principle, there exists ")#mi("{1 \\leq j \\leq k}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Gamma_{n,j} \\cap \\Sigma\\right| \\geq \\frac{1}{k} \\left|\\Sigma\\right|", block: true)]]

#text("and hence by ")#link(<tao-a2f005a07e20c66a1995>)[#text("(14)")]#text(", ")#link(<tao-ff7006235a21f3fe3ffd>)[#text("(15)")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\pi_{n,j}( \\Gamma_{n,j} \\cap \\Sigma)\\right| \\geq \\frac{1}{k} \\exp( (h( X_j)+o(1)) n )", block: true)]]

#text("which by ")#link(<tao-ff94fe54203a912ee5ed>)[#text("(13)")]#text(" implies that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\pi_{n,1}(\\Gamma_{n,1})\\right| + \\dots + \\left|\\pi_{n,k}(\\Gamma_{n,k})\\right| \\geq \\exp( (H + o(1)) n )", block: true)]]

#text("noting that the ")#mi("{\\frac{1}{k}}")#text(" factor can be absorbed into the ")#mi("{o(1)}")#text(" error). This gives the lower bound in ")#link(<tao-34c4ba8f5ba5f40e56e4>)[#text("(12)")]#text(".")

#text("Now we prove the upper bound. We can cover ")#mi("{\\Gamma^n}")#text(" by ")#mi("{O(\\exp(o(n))}")#text(" sets of the form ")#mi("{\\Sigma_{X_1,\\dots,X_k}}")#text(" for various choices of random variables ")#mi("{(X_1,\\dots,X_k)}")#text(" taking values in ")#mi("{\\Gamma}")#text(". For each such random variable ")#mi("{(X_1,\\dots,X_k)}")#text(", we can find ")#mi("{1 \\leq j \\leq k}")#text(" such that ")#mi("{h(X_j) \\leq H}")#text("; we then place all of ")#mi("{\\Sigma_{X_1,\\dots,X_k}}")#text(" in ")#mi("{\\Gamma_j}")#text(". It is then clear that the ")#mi("{\\Gamma_j}")#text(" cover ")#mi("{\\Gamma}")#text(" and that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Gamma_j\\right| \\leq \\exp( (H+o(1)) n )", block: true)]]

#text("for all ")#mi("{j=1,\\dots,n}")#text(", giving the required upper bound. ")#mi("\\Box")

#text("It is of interest to compute the quantity ")#mi("{H}")#text(" in ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(". We have the following criterion for when a maximiser occurs:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7")]#text(" ")#metadata(none) <tao-0177048f8ab1f013f4c5>#text(" Let ")#mi("{S_1,\\dots,S_k}")#text(" be finite sets, and ")#mi("{\\Gamma \\subset S_1 \\times \\dots \\times S_k}")#text(" be non-empty. Let ")#mi("{H}")#text(" be the quantity in ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(". Let ")#mi("{(X_1,\\dots,X_k)}")#text(" be a random variable taking values in ")#mi("{\\Gamma}")#text(", and let ")#mi("{\\Gamma^* \\subset \\Gamma}")#text(" denote the essential range of ")#mi("{(X_1,\\dots,X_k)}")#text(", that is to say the set of tuples ")#mi("{(t_1,\\dots,t_k)\\in \\Gamma}")#text(" such that ")#mi("{{\\bf P}( X_1=t_1, \\dots, X_k = t_k)}")#text(" is non-zero. Then the following are equivalent:")

#list(
[#text("(i) ")#mi("{(X_1,\\dots,X_k)}")#text(" attains the maximum in ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(".")],
[#text("(ii) There exist weights ")#mi("{w_1,\\dots,w_k \\geq 0}")#text(" and a finite quantity ")#mi("{D \\geq 0}")#text(", such that ")#mi("{w_j=0}")#text(" whenever ")#mi("{h(X_j) > \\min(h(X_1),\\dots,h(X_k))}")#text(", and such that ")#metadata(none) <tao-f9d0d9b18ae9033a5ea3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sum_{j=1}^k w_j \\log \\frac{1}{{\\bf P}(X_j = t_j)} \\leq D")]]

#text("for all ")#mi("{(t_1,\\dots,t_k) \\in \\Gamma}")#text(", with equality if ")#mi("{(t_1,\\dots,t_k) \\in \\Gamma^*}")#text(". (In particular, ")#mi("{w_j}")#text(" must vanish if there exists a ")#mi("{t_j \\in \\pi_i(\\Gamma)}")#text(" with ")#mi("{{\\bf P}(X_j=t_j)=0}")#text(".)")]
)

#text("Furthermore, when (i) and (ii) holds, one has ")#metadata(none) <tao-4a1f4e350903ffa6faa3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("D = H \\sum_{j=1}^k w_j.")]]




]

#emph[#text("Proof:")]#text(" We first show that (i) implies (ii). The function ")#mi("{p \\mapsto p \\log \\frac{1}{p}}")#text(" is concave on ")#mi("{[0,1]}")#text(". As a consequence, if we define ")#mi("{C}")#text(" to be the set of tuples ")#mi("{(h_1,\\dots,h_k) \\in [0,+\\infty)^k}")#text(" such that there exists a random variable ")#mi("{(Y_1,\\dots,Y_k)}")#text(" taking values in ")#mi("{\\Gamma}")#text(" with ")#mi("{h(Y_j) \\geq h_j}")#text(", then ")#mi("{C}")#text(" is convex. On the other hand, by ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(", ")#mi("{C}")#text(" is disjoint from the orthant ")#mi("{(H,+\\infty)^k}")#text(". Thus, by the ")#link("https://en.wikipedia.org/wiki/Hyperplane_separation_theorem")[#text("hyperplane separation theorem")]#text(", we conclude that there exists a half-space")

#align(center)[#tao-fit-display[#mitex("\\{ (h_1,\\dots,h_k) \\in {\\bf R}^k: w_1 h_1 + \\dots + w_k h_k \\geq c \\},")]]

#text("where ")#mi("{w_1,\\dots,w_k}")#text(" are reals that are not all zero, and ")#mi("{c}")#text(" is another real, which contains ")#mi("{(h(X_1),\\dots,h(X_k))}")#text(" on its boundary and ")#mi("{(H,+\\infty)^k}")#text(" in its interior, such that ")#mi("{C}")#text(" avoids the interior of the half-space. Since ")#mi("{(h(X_1),\\dots,h(X_k))}")#text(" is also on the boundary of ")#mi("{(H,+\\infty)^k}")#text(", we see that the ")#mi("{w_j}")#text(" are non-negative, and that ")#mi("{w_j = 0}")#text(" whenever ")#mi("{h(X_j) \\neq H}")#text(".")

#text("By construction, the quantity")

#align(center)[#tao-fit-display[#mitex("w_1 h(Y_1) + \\dots + w_k h(Y_k)")]]

#text("is maximised when ")#mi("{(Y_1,\\dots,Y_k) = (X_1,\\dots,X_k)}")#text(". At this point we could use the method of Lagrange multipliers to obtain the required constraints, but because we have some boundary conditions on the ")#mi("{(Y_1,\\dots,Y_k)}")#text(" (namely, that the probability that they attain a given element of ")#mi("{\\Gamma}")#text(" has to be non-negative) we will work things out by hand. Let ")#mi("{t = (t_1,\\dots,t_k)}")#text(" be an element of ")#mi("{\\Gamma}")#text(", and ")#mi("{s = (s_1,\\dots,s_k)}")#text(" an element of ")#mi("{\\Gamma^*}")#text(". For ")#mi("{\\varepsilon>0}")#text(" small enough, we can form a random variable ")#mi("{(Y_1,\\dots,Y_k)}")#text(" taking values in ")#mi("{\\Gamma}")#text(", whose probability distribution is the same as that for ")#mi("{(X_1,\\dots,X_k)}")#text(" except that the probability of attaining ")#mi("{(t_1,\\dots,t_k)}")#text(" is increased by ")#mi("{\\varepsilon}")#text(", and the probability of attaining ")#mi("{(s_1,\\dots,s_k)}")#text(" is decreased by ")#mi("{\\varepsilon}")#text(". If there is any ")#mi("{j}")#text(" for which ")#mi("{{\\bf P}(X_j = t_j)=0}")#text(" and ")#mi("{w_j \\neq 0}")#text(", then one can check that")

#align(center)[#tao-fit-display[#mitex("w_1 h(Y_1) + \\dots + w_k h(Y_k) - (w_1 h(X_1) + \\dots + w_k h(X_k)) \\gg \\varepsilon \\log \\frac{1}{\\varepsilon}")]]

#text("for sufficiently small ")#mi("{\\varepsilon}")#text(", contradicting the maximality of ")#mi("{(X_1,\\dots,X_k)}")#text("; thus we have ")#mi("{{\\bf P}(X_j = t_j) > 0}")#text(" whenever ")#mi("{w_j \\neq 0}")#text(". Taylor expansion then gives")

#align(center)[#tao-fit-display[#mitex("w_1 h(Y_1) + \\dots + w_k h(Y_k) - (w_1 h(X_1) + \\dots + w_k h(X_k)) = (A_t - A_s) \\varepsilon + O(\\varepsilon^2)")]]

#text("for small ")#mi("{\\varepsilon}")#text(", where")

#align(center)[#tao-fit-display[#mitex("A_t := \\sum_{j=1}^k w_j \\log \\frac{1}{{\\bf P}(X_j = t_j)}")]]

#text("and similarly for ")#mi("{A_s}")#text(". We conclude that ")#mi("{A_t \\leq A_s}")#text(" for all ")#mi("{s \\in \\Gamma^*}")#text(" and ")#mi("{t \\in \\Gamma}")#text(", thus there exists a quantity ")#mi("{D}")#text(" such that ")#mi("{A_s = D}")#text(" for all ")#mi("{s \\in \\Gamma^*}")#text(", and ")#mi("{A_t \\leq D}")#text(" for all ")#mi("{t \\in \\Gamma}")#text(". By construction ")#mi("{D}")#text(" must be nonnegative. Sampling ")#mi("{(t_1,\\dots,t_k)}")#text(" using the distribution of ")#mi("{(X_1,\\dots,X_k)}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k w_j \\log \\frac{1}{{\\bf P}(X_j = t_j)} = D")]]

#text("almost surely; taking expectations we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k w_j \\sum_{t_j \\in S_j} {\\bf P}( X_j = t_j) \\log \\frac{1}{{\\bf P}(X_j = t_j)} = D.")]]

#text("The inner sum is ")#mi("{h(X_j)}")#text(", which equals ")#mi("{H}")#text(" when ")#mi("{w_j}")#text(" is non-zero, giving ")#link(<tao-4a1f4e350903ffa6faa3>)[#text("(17)")]#text(".")

#text("Now we show conversely that (ii) implies (i). As noted previously, the function ")#mi("{p \\mapsto p \\log \\frac{1}{p}}")#text(" is concave on ")#mi("{[0,1]}")#text(", with derivative ")#mi("{\\log \\frac{1}{p} - 1}")#text(". This gives the inequality ")#metadata(none) <tao-dd1ae5d54c48b730d473>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("q \\log \\frac{1}{q} \\leq p \\log \\frac{1}{p} + (q-p) ( \\log \\frac{1}{p} - 1 )")]]



#text(" for any ")#mi("{0 \\leq p,q \\leq 1}")#text(" (note the right-hand side may be infinite when ")#mi("{p=0}")#text(" and ")#mi("{q>0}")#text("). Let ")#mi("{(Y_1,\\dots,Y_k)}")#text(" be any random variable taking values in ")#mi("{\\Gamma}")#text(", then on applying the above inequality with ")#mi("{p = {\\bf P}(X_j = t_j)}")#text(" and ")#mi("{q = {\\bf P}( Y_j = t_j )}")#text(", multiplying by ")#mi("{w_j}")#text(", and summing over ")#mi("{j=1,\\dots,k}")#text(" and ")#mi("{t_j \\in S_j}")#text(" gives")

#tao-aligned(keep: true)[


#tao-math("\\sum_{j=1}^k w_j h(Y_j)  & \\leq \\sum_{j=1}^k w_j h(X_j)", block: true)



#tao-math(" & + \\sum_{j=1}^k \\sum_{t_j \\in S_j} w_j ({\\bf P}(Y_j = t_j) - {\\bf P}(X_j = t_j)) ( \\log \\frac{1}{{\\bf P}(X_j=t_j)} - 1 ).", block: true)
]

#text("By construction, one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k w_j h(X_j) = \\min(h(X_1),\\dots,h(X_k)) \\sum_{j=1}^k w_j")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k w_j h(Y_j) \\geq \\min(h(Y_1),\\dots,h(Y_k)) \\sum_{j=1}^k w_j")]]

#text("so to prove that ")#mi("{\\min(h(Y_1),\\dots,h(Y_k)) \\leq \\min(h(X_1),\\dots,h(X_k))}")#text(" (which would give (i)), it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k \\sum_{t_j \\in S_j} w_j ({\\bf P}(Y_j = t_j) - {\\bf P}(X_j = t_j)) ( \\log \\frac{1}{{\\bf P}(X_j=t_j)} - 1 ) \\leq 0,")]]

#text("or equivalently that the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k \\sum_{t_j \\in S_j} w_j {\\bf P}(Y_j = t_j) ( \\log \\frac{1}{{\\bf P}(X_j=t_j)} - 1 )")]]

#text("is maximised when ")#mi("{(Y_1,\\dots,Y_k) = (X_1,\\dots,X_k)}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k \\sum_{t_j \\in S_j} w_j {\\bf P}(Y_j = t_j) = \\sum_{j=1}^k w_j")]]

#text("it suffices to show this claim for the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^k \\sum_{t_j \\in S_j} w_j {\\bf P}(Y_j = t_j) \\log \\frac{1}{{\\bf P}(X_j=t_j)}.")]]

#text("One can view this quantity as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{(Y_1,\\dots,Y_k)} \\sum_{j=1}^k w_j \\log \\frac{1}{{\\bf P}_{X_j}(X_j=Y_j)}.")]]

#text("By (ii), this quantity is bounded by ")#mi("{D}")#text(", with equality if ")#mi("{(Y_1,\\dots,Y_k)}")#text(" is equal to ")#mi("{(X_1,\\dots,X_k)}")#text(" (and is in particular ranging in ")#mi("{\\Gamma^*}")#text("), giving the claim. ")#mi("\\Box")

#text("The second half of the proof of Proposition ")#link(<tao-0177048f8ab1f013f4c5>)[#text("7")]#text(" only uses the marginal distributions ")#mi("{{{\\bf P}(X_j=t_j)}}")#text(" and the equation")#link(<tao-f9d0d9b18ae9033a5ea3>)[#text("(16)")]#text(", not the actual distribution of ")#mi("{(X_1,\\dots,X_k)}")#text(", so it can also be used to prove an upper bound on ")#mi("{H}")#text(" when the exact maximizing distribution is not known, given suitable probability distributions in each variable. The logarithm of the probability distribution here plays the role that the weight functions do in ")#link("https://arxiv.org/abs/1605.06702")[#text("BCCGNSU")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" Suppose one is in the situation of (i) and (ii) above; assume the nondegeneracy condition that ")#mi("{H}")#text(" is positive (or equivalently that ")#mi("{D}")#text(" is positive). We can assign a “degree” ")#mi("{d_j(t_j)}")#text(" to each element ")#mi("{t_j \\in S_j}")#text(" by the formula ")#metadata(none) <tao-aa58b21b01d6b8a99c1a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("d_j(t_j) := w_j \\log \\frac{1}{{\\bf P}(X_j = t_j)},")]]



#text(" then every tuple ")#mi("{(t_1,\\dots,t_k)}")#text(" in ")#mi("{\\Gamma}")#text(" has total degree at most ")#mi("{D}")#text(", and those tuples in ")#mi("{\\Gamma^*}")#text(" have degree exactly ")#mi("{D}")#text(". In particular, every tuple in ")#mi("{\\Gamma^n}")#text(" has degree at most ")#mi("{nD}")#text(", and hence by ")#link(<tao-4a1f4e350903ffa6faa3>)[#text("(17)")]#text(", each such tuple has a ")#mi("{j}")#text("-component of degree less than or equal to ")#mi("{nHw_j}")#text(" for some ")#mi("{j}")#text(" with ")#mi("{w_j>0}")#text(". On the other hand, we can compute from ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(19)")]#text(" and the fact that ")#mi("{h(X_j) = H}")#text(" for ")#mi("{w_j > 0}")#text(" that ")#mi("{Hw_j = {\\bf E} d_j(X_j)}")#text(". Thus, by asymptotic equipartition, and assuming ")#mi("{w_j \\neq 0}")#text(", the number of “monomials” in ")#mi("{S_j^n}")#text(" of total degree at most ")#mi("{nHw_j}")#text(" is at most ")#mi("{\\exp( (h(X_j)+o(1)) n )}")#text("; one can in fact use ")#link(<tao-aa58b21b01d6b8a99c1a>)[#text("(19)")]#text(" and ")#link(<tao-dd1ae5d54c48b730d473>)[#text("(18)")]#text(" to show that this is in fact an equality. This gives a direct way to cover ")#mi("{\\Gamma^n}")#text(" by sets ")#mi("{\\Gamma_{n,1},\\dots,\\Gamma_{n,k}}")#text(" with ")#tao-math("{\\left|\\pi_j(\\Gamma_{n,j})\\right| \\leq \\exp( (H+o(1)) n)}", block: false)#text(", which is in the spirit of the Croot-Lev-Pach-Ellenberg-Gijswijt arguments from ")#link("https://terrytao.wordpress.com/2016/05/18/a-symmetric-formulation-of-the-croot-lev-pach-ellenberg-gijswijt-capset-bound/")[#text("the previous post")]#text(".")
]

#text("We can now show that the rank computation for the capset problem is sharp:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Let ")#mi("{V_1^{\\otimes n} = V_2^{\\otimes n} = V_3^{\\otimes n}}")#text(" denote the space of functions from ")#mi("{{\\bf F}_3^n}")#text(" to ")#mi("{{\\bf F}_3}")#text(". Then the function ")#mi("{(x,y,z) \\mapsto \\delta_{0^n}(x+y+z)}")#text(" from ")#mi("{{\\bf F}_3^n \\times {\\bf F}_3^n \\times {\\bf F}_3^n}")#text(" to ")#mi("{{\\bf F}}")#text(", viewed as an element of ")#mi("{V_1^{\\otimes n} \\otimes V_2^{\\otimes n} \\otimes V_3^{\\otimes n}}")#text(", has rank ")#mi("{\\exp( (H^*+o(1)) n )}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(", where ")#mi("{H^* \\approx 1.013445}")#text(" is given by the formula ")#metadata(none) <tao-21abd0c5031e1bfab637>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("H^* = \\alpha \\log \\frac{1}{\\alpha} + \\beta \\log \\frac{1}{\\beta} + \\gamma \\log \\frac{1}{\\gamma}")]]



#text(" with")

#tao-aligned(keep: true)[


#tao-math("\\alpha  & = \\frac{32}{3(15 + \\sqrt{33})} \\approx 0.51419", block: true)



#tao-math("\\beta  & = \\frac{4(\\sqrt{33}-1)}{3(15+\\sqrt{33})} \\approx 0.30495", block: true)



#tao-math("\\gamma  & = \\frac{(\\sqrt{33}-1)^2}{6(15+\\sqrt{33})} \\approx 0.18086.", block: true)
]
]

#emph[#text("Proof:")]#text(" In ")#mi("{{\\bf F}_3 \\times {\\bf F}_3 \\times {\\bf F}_3}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\delta_0(x+y+z)  & = 1 - (x+y+z)^2", block: true)



#tao-math(" & = (1-x^2) - y^2 - z^2 + xy + yz + zx.", block: true)
]

#text("Thus, if we let ")#mi("{V_1=V_2=V_3}")#text(" be the space of functions from ")#mi("{{\\bf F}_3}")#text(" to ")#mi("{{\\bf F}_3}")#text(" (with domain variable denoted ")#mi("{x,y,z}")#text(" respectively), and define the basis functions")

#tao-aligned(keep: true)[


#tao-math("v_{1,0}  & := 1; v_{1,1} := x; v_{1,2} := x^2", block: true)



#tao-math("v_{2,0}  & := 1; v_{2,1} := y; v_{2,2} := y^2", block: true)



#tao-math("v_{3,0}  & := 1; v_{3,1} := z; v_{3,2} := z^2", block: true)
]

#text("of ")#mi("{V_1,V_2,V_3}")#text(" indexed by ")#mi("{S_1=S_2=S_3 := \\{ 0,1,2\\}}")#text(" (with the usual ordering), respectively, and set ")#mi("{\\Gamma \\subset S_1 \\times S_2 \\times S_3}")#text(" to be the set")

#align(center)[#tao-fit-display[#mitex("\\{ (2,0,0), (0,2,0), (0,0,2), (1,1,0), (0,1,1), (1,0,1),(0,0,0) \\}")]]

#text("then ")#mi("{\\delta_0(x+y+z)}")#text(" is a linear combination of the ")#mi("{v_{1,t_1} \\otimes v_{1,t_2} \\otimes v_{1,t_3}}")#text(" with ")#mi("{(t_1,t_2,t_3) \\in \\Gamma}")#text(", and all coefficients non-zero. Then we have ")#mi("{\\Gamma^{\\prime}= \\{ (2,0,0), (0,2,0), (0,0,2), (1,1,0), (0,1,1), (1,0,1) \\}}")#text(". We will show that the quantity ")#mi("{H}")#text(" of ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(" agrees with the quantity ")#mi("{H^*}")#text(" of ")#link(<tao-21abd0c5031e1bfab637>)[#text("(20)")]#text(", and that the optimizing distribution is supported on ")#mi("{\\Gamma^{\\prime}}")#text(", so that by Proposition ")#link(<tao-48b676e2b107da679512>)[#text("6")]#text(" the rank of ")#mi("{\\delta_{0^n}(x+y+z)}")#text(" is ")#mi("{\\exp( (H+o(1)) n)}")#text(".")

#text("To compute the quantity at ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(", we use the criterion in Proposition ")#link(<tao-0177048f8ab1f013f4c5>)[#text("7")]#text(". We take ")#mi("{(X_1,X_2,X_3)}")#text(" to be the random variable taking values in ")#mi("{\\Gamma}")#text(" that attains each of the values ")#mi("{(2,0,0), (0,2,0), (0,0,2)}")#text(" with a probability of ")#mi("{\\gamma \\approx 0.18086}")#text(", and each of ")#mi("{(1,1,0), (0,1,1), (1,0,1)}")#text(" with a probability of ")#mi("{\\alpha - 2\\gamma = \\beta/2 \\approx 0.15247}")#text("; then each of the ")#mi("{X_j}")#text(" attains the values of ")#mi("{0,1,2}")#text(" with probabilities ")#mi("{\\alpha,\\beta,\\gamma}")#text(" respectively, so in particular ")#mi("{h(X_1)=h(X_2)=h(X_3)}")#text(" is equal to the quantity ")#mi("{H^{\\prime}}")#text(" in ")#link(<tao-21abd0c5031e1bfab637>)[#text("(20)")]#text(". If we now set ")#mi("{w_1 = w_2 = w_3 := 1}")#text(" and")

#align(center)[#tao-fit-display[#mitex("D := 2\\log \\frac{1}{\\alpha} + \\log \\frac{1}{\\gamma} = \\log \\frac{1}{\\alpha} + 2 \\log \\frac{1}{\\beta} = 3H^* \\approx 3.04036")]]

#text("we can verify the condition ")#link(<tao-f9d0d9b18ae9033a5ea3>)[#text("(16)")]#text(" with equality for all ")#mi("{(t_1,t_2,t_3) \\in \\Gamma^{\\prime}}")#text(", which from ")#link(<tao-4a1f4e350903ffa6faa3>)[#text("(17)")]#text(" gives ")#mi("{H=H^{\\prime}=H^*}")#text(" as desired. ")#mi("\\Box")

#text("This statement already follows from the result of ")#link("https://arxiv.org/abs/1607.00047")[#text("Kleinberg-Sawin-Speyer")]#text(", which gives a “tri-colored sum-free set” in ")#mi("{\\mathbb F_3^n}")#text(" of size ")#mi("{\\exp((H^{\\prime}+o(1))n)}")#text(", as the slice rank of this tensor is an upper bound for the size of a tri-colored sum-free set. If one were to go over the proofs more carefully to evaluate the subexponential factors, this argument would give a stronger lower bound than ")#link("https://arxiv.org/abs/1607.00047")[#text("KSS")]#text(", as it does not deal with the substantial loss that comes from Behrend’s construction. However, because it actually constructs a set, the ")#link("https://arxiv.org/abs/1607.00047")[#text("KSS")]#text(" result rules out more possible approaches to give an exponential improvement of the upper bound for capsets. The lower bound on slice rank shows that the bound cannot be improved using only the slice rank of this particular tensor, whereas ")#link("https://arxiv.org/abs/1607.00047")[#text("KSS")]#text(" shows that the bound cannot be improved using any method that does not take advantage of the “single-colored” nature of the problem.")

#text("We can also show that the slice rank upper bound in a result of ")#link("https://arxiv.org/abs/1606.09575")[#text("Naslund-Sawin")]#text(" is similarly sharp:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" Let ")#mi("{V_1^{\\otimes n} = V_2^{\\otimes n} = V_3^{\\otimes n}}")#text(" denote the space of functions from ")#mi("{\\{0,1\\}^n}")#text(" to ")#mi("{\\mathbb C}")#text(". Then the function ")#mi("{(x,y,z) \\mapsto \\prod_{i=1}^n (x_i+y_i+z_i)-1}")#text(" from ")#mi("{\\{0,1\\}^n \\times \\{0,1\\}^n \\times \\{0,1\\}^n \\rightarrow \\mathbb C}")#text(", viewed as an element of ")#mi("{V_1^{\\otimes n} \\otimes V_2^{\\otimes n} \\otimes V_3^{\\otimes n}}")#text(", has slice rank ")#mi("{(3/2^{2/3})^n e^{o(n)}}")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{v_{1,0}=1}")#text(" and ")#mi("{v_{1,1}=x}")#text(" be a basis for the space ")#mi("{V_1}")#text(" of functions on ")#mi("{\\{0,1\\}}")#text(", itself indexed by ")#mi("{S_1=\\{0,1\\}}")#text(". Choose similar bases for ")#mi("{V_2}")#text(" and ")#mi("{V_3}")#text(", with ")#mi("{v_{2,0}=1, v_{2,1}=y}")#text(" and ")#mi("{v_{3,0}=1,v_{3,1}=z-1}")#text(".")

#text("Set ")#mi("{\\Gamma = \\{(1,0,0),(0,1,0),(0,0,1)\\}}")#text(". Then ")#mi("{x+y+z-1}")#text(" is a linear combination of the ")#mi("{v_{1,t_1} \\otimes v_{1,t_2} \\otimes v_{1,t_3}}")#text(" with ")#mi("{(t_1,t_2,t_3) \\in \\Gamma}")#text(", and all coefficients non-zero. Order ")#mi("{S_1,S_2,S_3}")#text(" the usual way so that ")#mi("{\\Gamma}")#text(" is an antichain. We will show that the quantity ")#mi("{H}")#text(" of ")#link(<tao-62846fbd68c1b929cce1>)[#text("(10)")]#text(" is ")#mi("{\\log(3/2^{2/3})}")#text(", so that applying the last statement of Proposition ")#link(<tao-48b676e2b107da679512>)[#text("6")]#text(", we conclude that the rank of ")#mi("{\\delta_{0^n}(x+y+z)}")#text(" is ")#mi("{\\exp( (\\log(3/2^{2/3})+o(1)) n)= (3/2^{2/3})^n e^{o(n)}}")#text(" ,")

#text("Let ")#mi("{(X_1,X_2,X_3)}")#text(" be the random variable taking values in ")#mi("{\\Gamma}")#text(" that attains each of the values ")#mi("{(1,0,0),(0,1,0),(0,0,1)}")#text(" with a probability of ")#mi("{1/3}")#text(". Then each of the ")#mi("{X_i}")#text(" attains the value ")#mi("{1}")#text(" with probability ")#mi("{1/3}")#text(" and ")#mi("{0}")#text(" with probability ")#mi("{2/3}")#text(", so")

#align(center)[#tao-fit-display[#mitex("h(X_1)=h(X_2)=h(X_3) = (1/3) \\log (3) + (2/3) \\log(3/2) = \\log 3 - (2/3) \\log 2= \\log (3/2^{2/3})")]]

#text("Setting ")#mi("{w_1=w_2=w_3=1}")#text(" and ")#mi("{D=3 \\log(3/2^{2/3})=3 \\log 3 - 2 \\log 2}")#text(", we can verify the condition ")#link(<tao-f9d0d9b18ae9033a5ea3>)[#text("(16)")]#text(" with equality for all ")#mi("{(t_1,t_2,t_3) \\in \\Gamma^{\\prime}}")#text(", which from ")#link(<tao-4a1f4e350903ffa6faa3>)[#text("(17)")]#text(" gives ")#mi("{H=\\log (3/2^{2/3})}")#text(" as desired. ")#mi("\\Box")

#text("We used a slightly different method in each of the last two results. In the first one, we use the most natural bases for all three vector spaces, and distinguish ")#mi("{\\Gamma}")#text(" from its set of maximal elements ")#mi("{\\Gamma^{\\prime}}")#text(". In the second one we modify one basis element slightly, with ")#mi("{v_{3,1}=z-1}")#text(" instead of the more obvious choice ")#mi("{z}")#text(", which allows us to work with ")#mi("{\\Gamma = \\{(1,0,0),(0,1,0),(0,0,1)\\}}")#text(" instead of ")#mi("{\\Gamma=\\{(1,0,0),(0,1,0),(0,0,1),(0,0,0)\\}}")#text(". Because ")#mi("{\\Gamma}")#text(" is an antichain, we do not need to distinguish ")#mi("{\\Gamma}")#text(" and ")#mi("{\\Gamma^{\\prime}}")#text(". Both methods in fact work with either problem, and they are both about equally difficult, but we include both as either might turn out to be substantially more convenient in future work.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11")]#text(" Let ")#mi("{k \\geq 8}")#text(" be a natural number and let ")#mi("{G}")#text(" be a finite abelian group. Let ")#mi("{{\\bf F}}")#text(" be any field. Let ")#mi("{V_1 = \\dots = V_k}")#text(" denote the space of functions from ")#mi("{G}")#text(" to ")#mi("{{\\bf F}}")#text(".")

#text("Let ")#mi("{F}")#text(" be any ")#mi("{{\\bf F}}")#text("-valued function on ")#mi("{G^k}")#text(" that is nonzero only when the ")#mi("{k}")#text(" elements of ")#mi("{G^n}")#text(" form a ")#mi("{k}")#text("-term arithmetic progression, and is nonzero on every ")#mi("{k}")#text("-term constant progression.")

#text("Then the slice rank of ")#mi("{F}")#text(" is ")#tao-math("{\\left|G\\right|}", block: false)#text(".")
]

#emph[#text("Proof:")]#text(" We apply Proposition ")#link(<tao-617dab84791917e3fe34>)[#text("4")]#text(", using the standard bases of ")#mi("{V_1,\\dots,V_k}")#text(". Let ")#mi("{\\Gamma}")#text(" be the support of ")#mi("{F}")#text(". Suppose that we have ")#mi("{k}")#text(" orderings on ")#mi("{H}")#text(" such that the constant progressions are maximal elements of ")#mi("{\\Gamma}")#text(" and thus all constant progressions lie in ")#mi("{\\Gamma^{\\prime}}")#text(". Then for any partition ")#mi("{\\Gamma_1,\\dots, \\Gamma_k}")#text(" of ")#mi("{\\Gamma^{\\prime}}")#text(", ")#mi("{\\Gamma_j}")#text(" can contain at most ")#tao-math("{\\left|\\pi_j(\\Gamma_j)\\right|}", block: false)#text(" constant progressions, and as all ")#tao-math("{\\left|G\\right|}", block: false)#text(" constant progressions must lie in one of the ")#mi("{\\Gamma_j}")#text(", we must have ")#tao-math("{\\sum_{j=1}^k \\left|\\pi_j(\\Gamma_j)\\right| \\geq \\left|G\\right|}", block: false)#text(". By Proposition ")#link(<tao-617dab84791917e3fe34>)[#text("4")]#text(", this implies that the slice rank of ")#mi("{F}")#text(" is at least ")#tao-math("{\\left|G\\right|}", block: false)#text(". Since ")#mi("{F}")#text(" is a ")#tao-math("{\\left|G\\right| \\times \\dots \\times \\left|G\\right|}", block: false)#text(" tensor, the slice rank is at most ")#tao-math("{\\left|G\\right|}", block: false)#text(", hence exactly ")#tao-math("{\\left|G\\right|}", block: false)#text(".")

#text("So it is sufficient to find ")#mi("{k}")#text(" orderings on ")#mi("{G}")#text(" such that the constant progressions are maximal element of ")#mi("{\\Gamma}")#text(". We make several simplifying reductions: We may as well assume that ")#mi("{\\Gamma}")#text(" consists of all the ")#mi("{k}")#text("-term arithmetic progressions, because if the constant progressions are maximal among the set of all progressions then they are maximal among its subset ")#mi("{\\Gamma}")#text(". So we are looking for an ordering in which the constant progressions are maximal among all ")#mi("{k}")#text("-term arithmetic progressions. We may as well assume that ")#mi("{G}")#text(" is cyclic, because if for each cyclic group we have an ordering where constant progressions are maximal, on an arbitrary finite abelian group the lexicographic product of these orderings is an ordering for which the constant progressions are maximal. We may assume ")#mi("{k=8}")#text(", as if we have an ")#mi("{8}")#text("-tuple of orderings where constant progressions are maximal, we may add arbitrary orderings and the constant progressions will remain maximal.")

#text("So it is sufficient to find ")#mi("{8}")#text(" orderings on the cyclic group ")#mi("{\\mathbb Z/n}")#text(" such that the constant progressions are maximal elements of the set of ")#mi("{8}")#text("-term progressions in ")#mi("{\\mathbb Z/n}")#text(" in the ")#mi("{8}")#text("-fold product ordering. To do that, let the first, second, third, and fifth orderings be the usual order on ")#mi("{\\{0,\\dots,n-1\\}}")#text(" and let the fourth, sixth, seventh, and eighth orderings be the reverse of the usual order on ")#mi("{\\{0,\\dots,n-1\\}}")#text(".")

#text("Then let ")#mi("{(c,c,c,c,c,c,c,c)}")#text(" be a constant progression and for contradiction assume that ")#mi("{(a,a+b,a+2b,a+3b,a+4b,a+5b,a+6b,a+7b)}")#text(" is a progression greater than ")#mi("{(c,c,c,c,c,c,c,c)}")#text(" in this ordering. We may assume that ")#mi("{c \\in [0, (n-1)/2]}")#text(", because otherwise we may reverse the order of the progression, which has the effect of reversing all eight orderings, and then apply the transformation ")#mi("{x \\rightarrow n-1-x}")#text(", which again reverses the eight orderings, bringing us back to the original problem but with ")#mi("{c \\in [0,(n-1)/2]}")#text(".")

#text("Take a representative of the residue class ")#mi("{b}")#text(" in the interval ")#mi("{[-n/2,n/2]}")#text(". We will abuse notation and call this ")#mi("{b}")#text(". Observe that ")#mi("{a+b, a+2b,}")#text(" ")#mi("{a+3b}")#text(", and ")#mi("{a+5b}")#text(" are all contained in the interval ")#mi("{[0,c]}")#text(" modulo ")#mi("{n}")#text(". Take a representative of the residue class ")#mi("{a}")#text(" in the interval ")#mi("{[0,c]}")#text(". Then ")#mi("{a+b}")#text(" is in the interval ")#mi("{[mn,mn+c]}")#text(" for some ")#mi("{m}")#text(". The distance between any distinct pair of intervals of this type is greater than ")#mi("{n/2}")#text(", but the distance between ")#mi("{a}")#text(" and ")#mi("{a+b}")#text(" is at most ")#mi("{n/2}")#text(", so ")#mi("{a+b}")#text(" is in the interval ")#mi("{[0,c]}")#text(". By the same reasoning, ")#mi("{a+2b}")#text(" is in the interval ")#mi("{[0,c]}")#text(". Therefore ")#tao-math("{\\left|b\\right| \\leq c/2< n/4}", block: false)#text(". But then the distance between ")#mi("{a+2b}")#text(" and ")#mi("{a+4b}")#text(" is at most ")#mi("{n/2}")#text(", so by the same reasoning ")#mi("{a+4b}")#text(" is in the interval ")#mi("{[0,c]}")#text(". Because ")#mi("{a+3b}")#text(" is between ")#mi("{a+2b}")#text(" and ")#mi("{a+4b}")#text(", it also lies in the interval ")#mi("{[0,c]}")#text(". Because ")#mi("{a+3b}")#text(" is in the interval ")#mi("{[0,c]}")#text(", and by assumption it is congruent mod ")#mi("{n}")#text(" to a number in the set ")#mi("{\\{0,\\dots,n-1\\}}")#text(" greater than or equal to ")#mi("{c}")#text(", it must be exactly ")#mi("{c}")#text(". Then, remembering that ")#mi("{a+2b}")#text(" and ")#mi("{a+4b}")#text(" lie in ")#mi("{[0,c]}")#text(", we have ")#mi("{c-b \\leq b}")#text(" and ")#mi("{c+b \\leq b}")#text(", so ")#mi("{b=0}")#text(", hence ")#mi("{a=c}")#text(", thus ")#mi("{(a,\\dots,a+7b)=(c,\\dots,c)}")#text(", which contradicts the assumption that ")#mi("{(a,\\dots,a+7b)>(c,\\dots,c)}")#text(". ")#mi("\\Box")

#text("In fact, given a ")#mi("{k}")#text("-term progressions mod ")#mi("{n}")#text(" and a constant, we can form a ")#mi("{k}")#text("-term binary sequence with a ")#mi("{1}")#text(" for each step of the progression that is greater than the constant and a ")#mi("{0}")#text(" for each step that is less. Because a rotation map, viewed as a dynamical system, has zero ")#link("https://en.wikipedia.org/wiki/Topological_entropy")[#text("topological entropy")]#text(", the number of ")#mi("{k}")#text("-term binary sequences that appear grows subexponentially in ")#mi("{k}")#text(". Hence there must be, for large enough ")#mi("{k}")#text(", at least one sequence that does not appear. In this proof we exploit a sequence that does not appear for ")#mi("{k=8}")#text(".")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471778")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2016")])]

#text("In Lemma 1(iii), the first $\\latex \\oplus$ should be a ")#mi("\\sum")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2016")])]

#text("Is it possible to formulate (at least part of) these result in terms of some appropriate notions of entropy and information ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471898")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("i.e. is there an “information theoretic” approach to the notion of “slice rank” and to these results?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471900")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("I don’t think there is a direct information-theoretic interpretation of slice rank for any fixed dimension, but when considering the slice rank of a tensor power ")#mi("v^{\\otimes n}")#text(" in the limit ")#mi("n \\to \\infty")#text(" it seems that the asymptotic (normalised) slice rank has an information-theoretic interpretation. Right now we can only formalise this in the case that ")#mi("v")#text(" has a representation in terms of suitable basis vectors in which the nonzero coefficients are restricted to an antichain (see Proposition 6), but this connection may well hold in greater generality (maybe involving some “noncommutative” version of entropy?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37432c98750e4022b84c1e02476ca47a145927ff594ef0eb39e820fe7e06b425-ce55d07280b037e17918e2e1908cc9c00ecabf3d55d9d47936fe5043346ccd52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471908")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("You can interpret the combinatorial problem appearing in Proposition 4 as a particular kind of information problem, where Alice knows a k-tuple of solutions to a problem and must send a message to Bob in the minimum amount of space, and then Bob must give one of the k possible solutions (and Alice and Bob both know the set of possible problems and agree on a communication protocol beforehand). Here S_1,…,S_k are sets of possible solutions and Gamma is the set of possible problems. I don’t know much about this kind of information problem, other than the asymptotic formula in Proposition 6.")

#text("Surely something more can be said about this combinatorial problem. But, as Terry says, it’s hard to connect it to slice rank, outside this very special antichain case.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/813e3f3f5dc5d157c901cced4067cdb6b1792c95ba86917d3bd544576d90f749-97041097062c863ae6fd8b56fd19ea753a6719f822660d60d5aba199892c4fed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jhon Manugal")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471793")[#strong[#text("Jhon Manugal")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2016")])]

#text("tensor products of vector spaces can describe entangled quantum states, as in these notes of Barton Zweibach ")#link("http://ocw.mit.edu/courses/physics/8-05-quantum-physics-ii-fall-2013/lecture-notes/MIT8_05F13_Chap_08.pdf")[#text("http://ocw.mit.edu/courses/physics/8-05-quantum-physics-ii-fall-2013/lecture-notes/MIT8_05F13_Chap_08.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae170f7dfc9cd32e181772f5ed4b3546e67ef6408020e5e45aa57f41e79b25fb-223c790ed4b2b6544b755cb6ac59795f87b2de69f9550f9017c1042afb6ac4dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hai Le")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471794")[#strong[#text("Hai Le")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2016")])]

#text("In the Proposition 9, there seems to be a typo at 1-(x+y+z)^2 = (1-x^2)-y^2-z^2+xy+yz+zx.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae170f7dfc9cd32e181772f5ed4b3546e67ef6408020e5e45aa57f41e79b25fb-223c790ed4b2b6544b755cb6ac59795f87b2de69f9550f9017c1042afb6ac4dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hai Le")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471795")[#strong[#text("Hai Le")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2016")])]

#text("I was wrong, forgot that it is in F_3")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a05ed57d8ab8413ba442e5f1620067dd039e80c878ac6718553566be4fbcef0-9c3888ebd42c24fd0a2a2c6508f3131b5f495461adebead4fa02f1972266e45d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matjaž Gomilšek")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471817")[#strong[#text("Matjaž Gomilšek")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2016")])]

#text("There is a ")#mi("\\in")#text(" missing just before “will be called rank one functions,”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c078f33b6fb7acab0dd6a3ff37c1a965423e168caeaf3d955d68a6fdd0c7371-01ef04b5ef1b58a71fbe0cc8f3b459639a6650f6e3bd441f92d2281551b7dd30.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Parminder Singh")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-471884")[#strong[#text("Parminder Singh")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2016")])]

#text("Do you ever get bored doing mathematics? If no, Why not? If yes, What pushes you again to do it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e154415b436e9bc8285736de147cd4f38daaec928c63342d457acc7a7cada98e-573c071666a829883ed2a9bbe3426924bc1ddb72b98f5d279797def52ba8e56c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuval Filmus")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-472018")[#strong[#text("Yuval Filmus")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2016")])]

#text("In (7), the direction of the inequality seems wrong. Also, the word “holds” is missing right after (7).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f9a4c102874ab40f69cf58b8f9e6d2e7805aa739dae9adf00fd761cb7f87ef-453100bda411909e1d60891c35f7390f392cd2b172086612881038bcec6ca3f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Gustafson")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-472199")[#strong[#text("Paul Gustafson")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2016")])]

#text("I think there’s a typo in your comparison with the usual notion of tensor rank, “giving a rank that is greater than or equal to the slice rank studied here”")

#text("That should be a “less than or equal,” since there are more rank 1 functions for the usual tensor rank than for the slice rank.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8119d9fc276b780d97d3f6f156c7a9da50962420966a10aea3c41230e4f967-fc350d449d4da6aa900eae30a9512458446b47a9f4eb944ecf588db9c5df17a6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-472201")[#strong[#text("Will")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2016")])]

#text("It is correct. There are actually fewer rank-one functions for the usual tensor rank than for the slice rank, not more as you say. Rank-one functions for the usual tensor rank must split into independent functions of each factor, whereas for slice rank they must only split into a function of one factor times a function of all the other factors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f9a4c102874ab40f69cf58b8f9e6d2e7805aa739dae9adf00fd761cb7f87ef-453100bda411909e1d60891c35f7390f392cd2b172086612881038bcec6ca3f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Gustafson")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-472210")[#strong[#text("Paul Gustafson")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2016")])]

#text("Oh, that makes sense. My mistake!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-472233")[#strong[#text("Introduction to the polynomial method (and other similar things) | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2016")]

#text("[…] polynomial method has made some waves recently (see this and that, for instance), and last week, Boris Alexeev gave a very nice talk on various applications of this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2458e475e6f1148b05ec79641cbe69615406e3b104fd0369525672c124916351-2f100601fea7030612c824651b06a80a5aeab80e695076e6b900a1bc71cebb04.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dion Gijswijt")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-479140")[#strong[#text("Dion Gijswijt")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2017")])]

#text("The set ")#mi("C")#text(" in the proof of Proposition 7 is not convex in general. I think what you need is that ")#mi("C+\\mathbb{R}_{\\leq 0}^k")#text(" is convex.")#linebreak()#text(" Nice proof!")

#emph[#text("[Corrected, thanks – WS.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca1b86a8af9c99d875999f4948ee99b054181f00e4246d3ce2c116c7fc91c8db-c1fc8940af2cb8e68eee194775cc7f18c82f561b83b76be2181aa3c577e7e710.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes of the seminar ‘On the slice rank of functions’ | Points And Lines")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-480731")[#strong[#text("Notes of the seminar ‘On the slice rank of functions’ | Points And Lines")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2017")])]

#text("[…] of geometrical way. Most, if not all, of the theory can be developed for general tensors (see again Terry’s blog), but we will restrict ourselves to to a special case, which we will explain in the next paragraph. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-623086")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2021")])]

#text("A bit late to the party here, but in the statement and proof of Proposition 9, is ")#mi("\\delta_{0^n}(x,y,z)")#text(" a typo for ")#mi("\\delta_{0^n}(x+y+z)")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a01f264f48f5e05d5d685b9021d8eabe021cba75bb29f31f0c2c489198037bd-3a332be6c68a6a6e665ca9294ad450f10654091c15e3a2b8f42c50a2c9b259ff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sets of points meeting each subspace in a few points | Anurag's Math Blog")]], [#link("https://terrytao.wordpress.com/2016/08/24/notes-on-the-slice-rank-of-tensors/#comment-676179")[#strong[#text("Sets of points meeting each subspace in a few points | Anurag's Math Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2023")])]

#text("[…] of just an affine subspace and many new results have been obtained using the various notions of ranks of a tensor (see this and the references […]")
]
