// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/
// Converted to Typst by tao2typ: "2026-10-31T12:50:46.358818+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Will it be a golden age or a dark age for mathematics (and science)?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Will it be a golden age or a dark age for mathematics (and science)?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/")[#text("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-31 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://web.ma.utexas.edu/users/maggi/")[#text("Francesco Maggi")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("Large language models (LLMs) and the research systems built around them (and commonly known as “artificial intelligence”) have demonstrated remarkable abilities in generating mathematical proofs. While the quality and limits of these tools remain incompletely understood, their potential for accelerating discovery and enabling extraordinary advances in mathematics and, more broadly, across science and technology seems clear.")

#text("Seizing on that potential will require the careful integration of LLMs into the various STEM ecosystems, with the priorities of empowering a new generation of scientists, developing new STEM expertise, and preserving an open, collaborative, and intellectually independent scientific enterprise: that is the “golden age” scenario in the title. In the “dark age” scenario, scientific and technological output would still increase spectacularly in the short term, but, at the same time, independent human scientific activity would progressively weaken, the production of new knowledge becoming increasingly concentrated in a small number of hands, who become increasingly incapable of understanding the knowledge produced. The real darkness here would be knowledge becoming alien to human understanding.")

#text("Reality will likely combine these scenarios. In eight points, I will examine the choices shaping that outcome, moving from mathematics to science more broadly, and closing with actionable proposals.")

#strong[#text("(1) The technological breakthrough is real! But…")]

#text("To state the obvious, LLMs have become powerful research tools. Recent LLM-generated proofs, like the construction of a finite-time blow-up solution to the Navier–Stokes equations with a forcing term, or the proposed proof of the quasi-Riemann Hypothesis, deserve the utmost attention from mathematicians. Assessing their significance will require continuous independent scrutiny, interpretation, and assimilation by the mathematical community.")

#text("LLMs seem most at home when writing proofs in Lean. (Lean is a proof assistant that allows computers to check whether a formal argument establishes a stated claim under specified definitions and axioms.) For those hard theorems where we really want LLMs to help us, these Lean proofs are extremely long, like hundreds of thousands of lines of code long. A seemingly emergent trend is that the longer the Lean version of a proof, the messier and less faithful its machine-generated “natural language” translation seems to be. We don’t understand why LLMs seem so bad at doing this kind of translation, but, as of today, they seem to really struggle with that task. So, for the really important problems, LLMs can give us correct Lean proofs that we cannot directly read, and messy natural language translations that are so complex as to require intensive study by mathematicians before they can lead to human understanding. Although this specific problem translation problem may change in the future, it leads us directly to the fundamental question:")

#emph[#text("Without human understanding, why do we care about studying mathematics, or even obtaining proofs, beyond benchmarking LLMs?")]

#text("Mathematics is a very peculiar human artifact. It seems to have deep biological roots in how humans cognize. We identify (people, animals, objects); therefore, we count, we have numbers. We seem to have innate concepts of space and time, and we quantify and measure them with numbers. Some basic forms of arithmetic and geometry seem to almost be innate to humans. Different civilizations have built different kinds of mathematics, and even during the most recent history of mathematics, the very notion of the domain of mathematical inquiry has expanded drastically, sometimes even accidentally.")

#text("(We may even be in a situation where there is a mathematics of humans and a mathematics of LLMs. This is maybe true not only at a linguistic level, but also in a deeper sense, although it is just too early to say.)")

#text("I therefore disagree with claims that mathematics is over because machines can prove theorems. Without humans who understand mathematics, there is, quite literally, no human mathematics—a fundamental part of human culture. If we agree that we should not abandon mathematics because poorly understood machines bruise our anthropocentric vision of it, then society will need more mathematicians, not fewer. Like… a lot more.")

#strong[#text("(2) Healthy scientific skepticism and the limits of LLMs’ creativity.")]

#text("Given the extraordinary results obtained by LLMs in mathematics, there is now considerable excitement concerning future capabilities and, at times, I think a lack of cool-headedness that does not do justice to the scientific method. Extraordinary performance should be received as a phenomenon to study, not as evidence for speculative conclusions about intelligence, creativity, or even consciousness. The latter are among the hardest legitimate subjects of scientific inquiry. They should be approached with explicit definitions, testable hypotheses, and empirical evidence. The same goes for the sweeping predictions about inevitable social transformations that inevitably follow the amazement generated by observed capabilities. We seem to forget too easily that the social consequences of these technologies will not be solely determined by their capabilities, but, most importantly, by the choices we will make on how these capabilities are developed and integrated into existing institutions. There are no inevitable outcomes, but there is a sore need for scientific and political leadership.")

#text("What do we know today about the mathematical abilities of LLMs? Theoretical and empirical insights both support the conclusion that LLMs are extraordinary at recombining existing intellectual structures and discovering unobserved connections among distant parts of the scientific literature. What is more, LLMs do this at a scale that is inaccessible to individual researchers. Whether their uncanny effectiveness at proving theorems can be entirely explained as hyper-sophisticated linguistic recombination, or whether it involves other forms of synthetic reasoning that are yet to be described and understood, is today an open scientific question.")

#text("One point that seems particularly hard to decide, given that commercial developers are not (cannot be) transparent on the working of their models is the relation between LLMs’ performance on a problem and the richness of the related mathematical literature. For example, both the Navier-Stokes equations and the Riemann Hypothesis are the subject of a vast literature created by hundreds of the most brilliant mathematicians. There may be something here. After all, when OpenAI published their “Tuesday October 6, 2026, Drop”, they mentioned having tried 4000 problems, reporting success for some hundreds of them (as counted after “aggregation” and “selection”). The language used there is a bit vague, but it still seems to imply the existence of a potentially large group of problems on which the frontier LLM failed to find solutions: from a scientific viewpoint, it would be very interesting to know what these problems were. Maybe those problems are more interesting than NS and RH? Or is the ground around them less fertile for LLMs to come help? These are important questions for humans who want to advance mathematical progress: how do we put LLMs in the best position to help?")

#strong[#text("(3) Mathematization.")]

#text("Mathematicians seem substantially agreed that some human mathematical functions are not reducible to theorem proving. A particularly important one is ")#strong[#text("mathematization:")]

#emph[#text("The act of inventing the very mathematical language through which reality (including mathematical structures themselves) becomes quantitatively and rationally intelligible.")]

#text("Newton, Fourier, Riemann, Einstein, Shannon, Grothendieck: their greatest mathematical contributions could be described as the highest examples of mathematization, as they included the invention of mathematical languages and conceptual frameworks that transformed entire areas of knowledge.")

#text("We do not know if LLMs can perform mathematization — my guess would be that they should be (or eventually become) capable of mathematization of mathematical structures, so, of a very specific part of reality, but it is much less clear if they can go beyond that, at least in ways that they can then translate efficiently into natural language — I am going back to human understanding here.")

#text("In my opinion, the most exciting opportunity created by making proofs a more accessible commodity is that, in the near future, we may be able to do much more mathematization than ever. There are vast swaths of the natural and social sciences where our ability to mathematize has been largely dampened by the difficulty of obtaining proofs — indeed, without proofs, it can be difficult to establish a theory’s consequences and compare them with observed phenomena. But, as often observed in science, we may have just climbed the peak of the mountain only to find more land to explore.")

#text("I think there should be considerable excitement around this idea. Indeed, whenever a system of phenomena, experiments, and data is successfully mathematized, we vastly increase the sophistication and depth of the accessible insights into that system.")

#text("The most spectacular example of this assertion is probably the success of quantum mechanics, where the mathematical formalization of an original set of experimental data has famously produced many physically counterintuitive but testable predictions confirmed by experiments that would have otherwise been unthinkable — who would have proposed entanglement as a property of nature if not forced to do so by theoretical prediction?")

#strong[#text("(4) Mathematical progress cannot be measured by checking off boxes on a problem list.")]

#text("Mathematics is not a finite system of questions. Hilbert proposed his famous list of problems at the dawn of the previous century (which inspired the list of Millennium Prize Problems) with the intent of guiding and channeling a “Cambrian explosion” of mathematical activity. But many fundamental mathematical contributions of the past century happened without any connection to any list of problems.")

#text("For example, the mathematical foundations of general relativity emerged from geometric ideas developed over multiple generations of mathematicians, starting with Gauss and Riemann, and continuing with Ricci-Curbastro and Levi-Civita. The synthesis of physical insight, special relativity, and Riemannian geometry into general relativity has no connection with any list of difficult problems or their intricately complex proofs (and is a textbook example of mathematization in action!)")

#text("A second example is provided by a broad historical trajectory connecting the study of Fourier series, the development of measure theory, modern probability, and information theory. Shannon’s insight that the statistical structure of a source determines fundamental limits on the transmission and compression of information is an extraordinary example of how mathematization can open an entirely new field. Similarly, some of the mathematical foundations of modern computing and machine learning are arguably rooted in a series of mathematical advancements that were not immediately inspired by attempts at proving big conjectures or by increasingly complex proofs.")

#text("It is undeniable that working on problems from Hilbert’s and other lists has proven extremely fruitful for the development of mathematics. What is interesting in that regard is that the usefulness of these efforts has often gone well beyond the solution of the specific problems: these problems have served as lighthouses in the navigation of unknown mathematical waters, as already noted in other comments. But reducing mathematics to solving hard problems from a list provides a simplistic and incomplete understanding of the field and of what constitutes progress in it.")

#strong[#text("(5) Authorship, credit, and peer review still matter!")]

#text("LLM-generated work draws on a vast body of human mathematical literature, but how the extracted information is used remains unclear. There are several issues related to this basic obscurity: Which mathematical ideas contributed to a specific proof? Who is responsible for asserting the proof’s correctness and for implementing revisions? In the case of an LLM rediscovering arguments already present in the literature, how do we ensure appropriate citations? We need sensible answers to all these questions, and we need to discuss how the existing publication system should correspondingly change and adapt.")

#text("Proofs are not the end of the mathematical discovery process. To become a fruitful intellectual artifact, a proof needs to be understood, interpreted, related to previous work. Key ideas must be identified and processed to become part of a shared mathematical culture. Peer review matters. The use of LLMs and of Lean formalization can support the effectiveness of peer review (formal correctness becoming potentially easier to ascertain), but human intervention remains necessary to establish meaning, relevance, and context, and to preserve a creative mathematical environment that favors mathematization and is compatible with the training of future mathematicians.")

#text("A particularly challenging issue related to the obscurity of how human-generated data is made accessible to LLMs is of course the current transition from a very open system of doing mathematics (with people routinely proposing open problems and conjectures), to a closely guarded one (where people have already become very cautious about sharing ideas).")

#text("For example, given OpenAI’s interest in the Riemann Hypothesis, who would light-heartedly think of prompting a potentially original idea about it into ChatGPT? After all, that same idea could become accessible to another mathematician or OpenAI employee working with a more advanced LLM, that could turn that idea into a proof without even realizing its origin and having the opportunity of acknowledging it. So, another side of obscurity and uncertainty is that people may end up using LLMs much less than they would like to do. My concern extends beyond published policies on training data to the security of stored research material. Indeed, there are documented cases of agents gaining unauthorized access to third-party systems. Those incidents make the independent assessment of confidentiality protections particularly important.")

#text("Similarly, it seems that mathematicians are already concerned and guarded about what they write in research statements and research proposals. After all, an administrator or a reviewer may upload those documents into an LLM to get help in writing a report, thus potentially compromising the confidentiality of unpublished research.")

#strong[#text("(6) The training of future mathematicians has already become an existential challenge.")]

#text("Training future mathematicians is closely related to authorship and credit. I will discuss a few representative challenges.")

#text("One remarkable feature of mathematics has traditionally been the possibility of establishing intellectual merit very directly through mathematical achievement. A strong result addressing a well-known question could allow a researcher to gain recognition and opportunities, no matter how institutionally marginalized and independently of established academic hierarchies.")

#text("Among the mathematicians I have spoken with, the prevailing sentiment is that this traditional mechanism of recognition has effectively collapsed in a matter of weeks. A strong mathematical result, by itself, can no longer be taken as convincing evidence of a student’s independent mathematical abilities. I do not know whether this sentiment is overblown, but the uncertainty is real, and we have yet to develop satisfactory standards for assessing individual intellectual contributions to mathematical research in the age of LLMs.")

#text("Without substantial transparency on how LLMs are prompted and by which mechanisms prompts influence their effectiveness, the assessment of mathematical capabilities of individuals will rest almost exclusively on individual judgements, which will have to be based, arguably, on more substantial human-to-human interactions.")

#text("This is, by far, not the only problem. The effects of intensive LLM use on human creativity are largely unknown. Anecdotal accounts from experienced mathematicians who have used LLMs extensively over the past year suggest subtle, and sometimes not-so-subtle, shifts in attention, motivation, and depth of understanding.")

#text("How do we learn to use LLMs in ways that amplify our intellectual abilities without increasingly delegating the very cognitive activities through which mathematical expertise is learned and acquired?")

#text("Finding plausible answers to this question is one of the main issues to address if we want the golden age scenario to materialize.")

#strong[#text("(7) Private control of frontier LLMs is potentially dangerous.")]

#text("Academic and corporate research have collaborated fruitfully for decades. LLMs themselves combine theoretical and technological insights developed in academia with concentrated capital and investment.")

#text("The danger here rather lies in the growing asymmetry between the scientific capabilities available to a small number of frontier companies and those accessible to universities and public institutions.")

#text("This asymmetry can be very consequential when those companies use proprietary systems to pursue scientific and technological discoveries in competition with academic research, in a setting where academic researchers will come to depend on the use of those same proprietary systems to be able to contribute.")

#text("Mathematics may offer an early, visible example of an asymmetry that could become increasingly consequential across science. Allowing private interests to determine which questions receive the best tools, who can use them, how capabilities are evaluated, and when discoveries are released would concentrate scientific influence to an unprecedented degree. A balance in capabilities seems necessary for stable cooperation and harmonization of interests. Giving a few companies increasing—and potentially total—control over what seems bound to become a basic infrastructure for frontier mathematics and science seems ill-advised.")

#text("This conclusion does not require assuming bad intentions on the part of corporate leadership. Simply put, commercial incentives, scientific priorities, and the public interest do not always necessarily align. A healthy scientific ecosystem requires a dialog between institutions with different objectives and different sources of authority, subject to transparency and forms of public accountability.")

#text("Coming back to mathematics, OpenAI has been engaging in various forms of dialogue with the mathematical community. This dialogue has led to some improvements with respect to the situation at the time of the Navier–Stokes problem, both in the presentation and dissemination of LLM-generated results. I think these efforts should be received constructively and deserve recognition, also because there are objective and legitimate difficulties for OpenAI in increasing transparency and access, like the pressure to generate returns on enormous investments, and the need to assess safety before deploying systems.")

#text("These interactions show clearly the inherent difficulties in harmonizing corporate and academic interests, even assuming perfect goodwill on everyone’s part. More importantly, these initiatives do not address the structural issue of unequal access to frontier LLM capabilities. Leaving the solution of this point to the goodwill and voluntary initiatives of individual companies seems insufficient.")

#strong[#text("(8) Building scientific LLM infrastructure within the broader research community.")]

#text("Universities, professional societies, funding agencies, and scientific foundations should coordinate the development and governance of competitive LLMs. Scientists will need access to frontier capabilities, transparency about their operation and use of research data, strong confidentiality protections, and the ability to test and reproduce research claims independently.")

#text("The massive computing resources, specialized personnel, data infrastructure, and ongoing investments needed to support this kind of initiative are not within the reach of a single institution, and a huge leadership effort will be necessary to conjure the combination of independent model development, guaranteed access to commercial systems, public computing infrastructure, and open research resources that could do the job.")

#text("The key goal here is not necessarily to achieve total technological independence from private companies, but to preserve the capacity for independent scientific research and to create LLMs that are calibrated for supporting research communities, rather than bound to cause their gradual weakening and, possibly, their eventual disappearance.")

#text("Preserving an intellectually independent, open, and creative scientific culture while skillfully integrating increasingly powerful machines is bound to become the defining cultural challenge of our times. Mathematics offers an early opportunity to confront a challenge likely soon to extend across science, with increasingly complex and potentially dangerous consequences for knowledge, intellectual power, and society. Scientific skepticism and fairness to everyone involved should guide us.")

#strong[#text("The golden age scenario is achievable.")]#text(" Access to frontier LLMs for researchers, reproducibility and disclosure standards for LLM-generated scholarship, resources for understanding and disseminating LLM-generated results, resources for studying the effects of LLMs on scientific education and research training, and sustained investments in publicly governed LLM infrastructure are concrete steps that we can take today to make the golden age scenario the most likely outcome.")

#text("In the specific case of mathematics, my hope and wish for a solidly independent LLM infrastructure would be the empowerment of mathematicians to systematically pursue opportunities for theory-building, or mathematization, both inside mathematics and across the spectrum of natural and social sciences. That, I think, would be a truly revolutionary achievement.")

#text("In the meantime")#strong[#text(", I think mathematicians have the huge responsibility of preserving mathematics as a lively part of human culture")]#text(" . Right now, there are far too many interests and far too many emotional reactions pulling towards absolute, negative conclusions of little constructive content. We must just accept that these are uncertain times and that we are not in full control of the situation. We must engage with every tool that can help us discover new mathematics. We must keep writing, publishing, reviewing, writing proposals. We must become more ambitious and curious than ever in doing all these things. And we must make sure to create the best professional standards for the next generations of mathematicians to keep mathematics a central node of human culture.")

#heading(level: 1)[#text("Comments (31)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84fb9722bc5268a1067a3d0f6b53ec321f24c56b68bd4da731757814bf0d59f8-7261b19ed0a94b10a3be2c858eb2fffc295cdfd1d9edc0c47abfcf9ae49ebd4c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nilima Nigam")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698312")[#strong[#text("Nilima Nigam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Thank you for this! Your 8 points are excellent.")

#text("Item 6 on your list is occupying much of my thinking time. The issue is entirely pressing: I venture this academic year most math departments are having town halls to discuss this, but still running qualifying examinations. Will demonstrated skill in formalization be part of next year’s exams?")

#text("MathJobs lists open positions, and in most applicants are asked for ‘(1) A cover letter; (2) A CV; (3) A detailed publication list; (4) Research proposals about current and future work; (5) N Representative publications and preprints and (6) letters. These requirements look identical to last year. But if you’re an applicant, what does a ‘research proposal about current and future work’ even look like? Is it reasonable to reveal the problems you mean to think about?")

#text("What plan can you write down today, that a hiring committee will believe as reasonably ambitious given AI tools? If you said ‘I’ve worked on this line of thought, and plan next to extend these ideas to the 3D Kakeya conjecture’ 5 years ago, that would be deemed wonderful, and ambitious. After Open AI’s drive-by spraying of results, should a hiring committee view ‘future work’ about the 4D Kakeya sets as incremental? Or this Fall are hiring committees looking for colleagues excellent at exposition and who plan to extend human understanding of AI-generated proofs?")

#text("Speaking strictly for myself, I think it would be helpful know learn what other departments are doing. A very large-scale (and inadvertant) experiment with no ethics approval is being run on human mathematicians. The exploratory research question is ‘how does AI impact young mathematicians?’")

#text("Students and postdocs did not provide informed consent to the experiment, the protocols are unclear, and actual human participants are involved. At the least we need to understand the local outcomes.")

#text("– Nilima Nigam.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698314")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("You are saying mathematics is about human understanding i.e. whatever we do, we must understand what we did. This is not only true for mathematics, this is true for all the branches of knowledge industry or academia. For example, AI companies are creating AI which they don’t understand fully. That is the reason of all the problems AI is creating in the whole world and that’s why humans are worried. There is no second reason. Whatever technology or knowledge till now we have built is completely understood by humans. That’s why we can switch it off when not required, we ca switch it on when required and also we can do maintenance. But in case of AI which is a technology obviously created by humans, but humans are not able to understand how it works. If you are not understanding how it works, then you should stop there and understand it. Until you understand it, you should not make progress on it. Like you are saying, if AI has generated Navier-Stokes solution, that’s not a problem for you, but hold next generation of a mathematical proof till Navier-Stokes is fully understood. That’s what I said in my comment that if humans don’t understand anything in the knowledge industry, then it means that technology is running the economy where all humans stay and we are giving our independence to that machine. And thus we will be servant of that machine. And as AI companies are creating powerful AIs without understanding the before release completely, it means we are giving our independence to AIs and thus AI will run our economy and we will just watch it being able to do nothing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698315")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Newton, Fourier, Riemann, Einstein, Shannon, Grothendieck: their greatest mathematical contributions could be described as the highest examples of mathematization")
]

#text("Strange to include Einstein and Shannon. They applied existing mathematical language. They didn’t create new mathematical language.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b91f703faf3ae458db99e0adf550e4d1569a8a7972d16c3ce13e2a388d8f84fd-b3b108c4135270dbdf3f572505fdd416dce3f18b92be25ebd8d3888b3a044ee1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francesco Maggi")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698349")[#strong[#text("Francesco Maggi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("By mathematization I mean creating a conceptual framework through which phenomena become mathematically intelligible. That can involve existing mathematical tools: Einstein used Riemannian geometry, but identifying gravitation with the dynamical geometry of spacetime was a creative act of extraordinary mathematical significance. A similar analysis applies to Shannon’s contributions: he drew on existing mathematical theories to develop a general framework in which information, noise, and communication received precise mathematical formulations and became subject to fundamental mathematical relationships. The invention lies in identifying the right objects, quantities, and relationships through which a set of phenomena can be described with mathematical precision.")

#text("In my understanding of mathematics, these are among the highest examples of mathematization, and considering them helps isolate the concept. But acts of mathematization are relatively common in the unfolding of mathematical progress, especially when they concern that part of reality consisting of mathematical structures themselves.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bf478ef32b7ef8e3a865e27208b659237f47b7b4430b234954e99a5066823870-826610670736ea3f7be1f9cd80dbf4b9d95ea4893aae0c3393fe65338df1757b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698360")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Ok, on that definition, some create the mathematical tools, while other use them. From that list, Newton, Riemann and Fourier did both. Grothendieck was a tool creator. Einstein was definitely a tool user.")#linebreak()#text("(Maybe Shannon belongs with the “both” — it’s a bit of a matter of opinion).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b52796f5953bd198c7a8f665c49d979b54adbb7be9b9502491f6ae6a1e29267-b798674221bbe8c8b7d6e6e7fbd9dfb3eaa8304bd696584e006950d38098d2e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Twinhomodox")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698420")[#strong[#text("Twinhomodox")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Bro you gotta get a life")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698316")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("One can generate a proof using a powerful AI and submit it to a journal saying that this proof is correct and the journal verifies that it is correct. Then can he be an author of the paper? No. He can only be an author of the paper if he understands the paper completely. It doesn’t matter whether he generated the proof using AI or himself. What matters is does he understand the proof? Because in knowledge industry nothing can be done without understanding. So, the definition of authorship goes in this way : The one who understands completely a thing or paper is an author of the paper or thing. And according to that definition, how can OpenAI say that we are the author or owner of GPT 5 or GPT 6? Because they don’t understand their released model. And thus they are violating the definition of authorship and thus they are held criminal legally. If these laws are implemented properly and strictly, then how can OpenAI or any AI company can progress without understanding their released system? And if they understand their released system, then there will be no worry from anybody in this world about AI will kill all of us. For example, you can see this blog post of Timothy Gowers : ")#link("https://gowers.wordpress.com/2026/10/16/how-worried-should-we-be-about-extinction-risk-from-ai/")[#text("https://gowers.wordpress.com/2026/10/16/how-worried-should-we-be-about-extinction-risk-from-ai/")]#text(" . The problem is we always think non-mathematically and go on debating forever rather than solving problems because e are prone to stupidity from our birth. We don’t say our birth right is human rights, rather we say stupidity is our birth right.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698324")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I find this definition strange. If your parents write your homework but you understand it, does that make you the author?")

#text("LLM output cannot even be copyrighted. It will be disastrous if mathematicians agree that a human can claim authorship of LLM output just by understanding it.")

#text("It is the thin end of the wedge and just what BigAI wants. It will be transferred to lawyers, artists, software engineers and everyone else.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698329")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I just forgot to write the word FIRST. The human who understands it first, is the author. For example, before publishing a paper, the author, the editor, the referee all understand the paper. But the author gets the authorship because he is the first to understand. And according to that definition, if my parents who are humans, do my homework, then my parents are the author because they understood it first.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698344")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("It first is to be asked “What is ‘understanding’?”")

#strong[#text("John von Neumann")]#emph[#text("“Young man, in mathematics you don’t understand things. You just get used to them.”")]#strong[#text("Richard Feynman")]#emph[#text("“I think I can safely say that nobody understands quantum mechanics.”")]#strong[#text("Carl Sagan")]#emph[#text("“Science is a way to call the bluff of those who only pretend to knowledge.”")]#strong[#text("E.M. Forster")]#emph[#text("“In daily life we never understand each other… We know each other approximately, by external signs…")]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698359")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Your question is absolutely valid and also John von Neumann, Richard Feynman, Carl Sagan, E. M. Forster all said it correctly the truth. You can take the definition of understanding how each of the 4 author you mentioned, mentioned the word understanding. I am sure you will not understand “understanding” from this. I think Terence Tao is at better place to define “understanding” than me. So, I outsource this question to Terence Tao if he wants to answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698362")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("The dictionary meaning of understanding is realization. So how “well” you realize. Realization never ends i.e. questions on a topic never ends. So, when you read a piece, then you realize something. When you read the piece again, then you realize something more i.e. you can answer more questions related to a that topic i.e. the meaning of “well”. So, as “well” never ends, so I define understanding using the word perfection which I define using the phrase “as far as you can go” i.e. for example, a student stood first in a class exam with 95% marks. He is not perfect but he has gone the farthest among others i.e. he is the perfect among all boys in the class. So, the measure of perfection is percentile not percentage. The perfect person’s percentile is always 100 and then goes on. So, say for example, you are defending your PhD thesis, you can defend only if you understand it. But the actual thing is don’t understand it totally but you understand it at least better than who are attacking you with questions i.e. according to the definition of perfection, your understanding is perfect among the people who are involved in your PhD defending. So, I define understanding using two words only : “Perfect realization”. Which means you realize a thing most among humans. But actually realization never ends.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698363")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Similarly, like your PhD defending tests your understanding according to the definition of understanding that I gave, when OpenAI is about to release a model of AI, then they need to defend it also in front of live audience. And according to the definition of understanding and authorship, then they will get the authorship or ownership of that model if they can defend it and thus they can release it. Otherwise they can’t release it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698366")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Now, you can counter me with the following example. Say, Person 1 gets authorship of a paper Paper 1. Now, it is published with author as Person 1. Because he has defended the paper in front of reviewer and editor. Now, after publication Person 2 reads it 10 times and Person 2 now understands more than Person 1, the author i.e. Person 2 can realize more things than Person 1 about Paper 1. Does that mean authorship should be transferred to Person 2 from Person 1? The answer is no. Because for example, Person 1 has introduced a proof or new theory in Paper 1. And he understands the paper. Now, if Person 2 understands it more, which means Person 2 derives a theorem or some deduction from it i.e. Person 2 understands it more, then Person 2 can publish his more understanding i.e. the theorem or some deduction in another paper Paper 2 citing Paper 1. Because Person 2 could not contribute anything in Paper 1, rather Person 2 extends it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698665")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("Is it true the LLM output cannot be copyrighted? I haven’t heard this before.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2919a2bd6f23d40609e215496608f5bd4261d04e6eca9a5351d85150b239f117-cd24097b516a9fabc44eb06bc0f5e8d5a73a83fe9b7a29b9bc268594a7da7ab0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of generouslydff7bc0de8")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698331")[#strong[#text("generouslydff7bc0de8")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("On point 6: In a single generation, we may reach point where we have no human trained sufficiently well to understand the output of LLMs; yet, use or direct LLMs efficiently to extend the knowledge borders. Golden age of LLMs in maths can be very brief.")

#text("I am not sure anyone can today suggest a maths career to a young kid, however talented he/she can be. Maths is central to all sciences, it should not be dehumanized.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698334")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("“LLMs seem most at home when writing proofs in Lean.” I would assume that actually is not the case. In OpenAI case only about half of the claimed proofs are for formalized in Lean.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel M Gessel")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698667")[#strong[#text("Daniel M Gessel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("Mechanically generated proofs that are not mechanically verifiable? Do the abstracts start with “Abandon all hope, ye who enter here?”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef8cfa9ed941f30bc24ab67ab86acd879ac779284f210ee3e3a15ae54eb1f676-c37304b74373dd967c4e8c8d91170a8eb86fe792ccd8be566e229dbf764add84.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Burt Totaro")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698340")[#strong[#text("Burt Totaro")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I like your description of what we can aim for in the new world. What we want to preserve is people giving insight to each other. You effectively describe the complexity of the ecosystem that allowed that to happen in the past. Like many people, I’ve been reflecting on this kind of thing. One small observation is that Covid forced math departments away from in-person activities in 2020, and it has taken a long time to recover from that, since people established different habits. The need to respond to AI is actually forcing mathematicians to come together in person more.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698346")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("I think the light in the ages depends on how far is Godel singularity or a fully capable system to proofs on finite length. It seems a little ironic mathematicians on one end are pushing for P vs NP which states nothing about proof clarity and distribution to humanity if P is NP but on other end now pushing against being bombarded by computer verified proofs which morally seems to go against Godel singularity since it appears computer proofs could be undigestible to humans. The accepted answer in ")#link("https://mathoverflow.net/a/48081/10035")[#text("https://mathoverflow.net/a/48081/10035")]#text(" comes consequential since it appears at one point mathematicians would have been ok to being bombarded by computer generated proofs and would still continue to be mathematicians for the glory of it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c444a848a8495e95d351f13559266fe8adcc121d3f7201306c7460a495c0933e-3365f5dfa24141ba2151c926ee663dd6a34f890061a120ece14ba8db40f4a070.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hume")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698354")[#strong[#text("Hume")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Despite people’s criticism of AI limitations")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c444a848a8495e95d351f13559266fe8adcc121d3f7201306c7460a495c0933e-3365f5dfa24141ba2151c926ee663dd6a34f890061a120ece14ba8db40f4a070.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hume")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698364")[#strong[#text("Hume")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("it would be more spooky if AI develops curiosity and begins to explore math on its own without human prompts. It will be a bigger hugging face incident.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698365")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Dear Francesco,")

#text("Thank you for this interesting post. I have a question about a small part of it, the role of Lean. You write that “LLMs seem most at home when writing proofs in Lean.” Perhaps I misunderstand, but you seem to suggest that LLMs tend to come up with a Lean proof, and then translate it into natural language. That is not my impression of what is happening with most of the recent advances (it is hard to know, because of the opaqueness of the companies, and perhaps fundamentally of the models themselves). It seems to me that the AI is finding the proofs via “natural language reasoning”; Lean proofs serve primarily to convince the humans. I don’t have strong evidence for this, but have heard things about the high cost of formalization that are consistent with this. Do you have a different understanding?")

#text("There was a narrative that I started hearing 4-5 years ago about how AI would get good at math. Autoformalization was supposed to play a key part — it would be used to, say, check intermediate results before building off them, and maybe also to evaluate the reward for reinforcement learning. That narrative seemed somewhat plausible, but it does not seem to be how things played out. Maybe, at least in retrospect, it’s not so surprising. For humans, formalization is very costly. Informal, but “pretty rigorous” reasoning that mathematicians engage in when they’re being careful is cheaper, and still fairly reliable, especially if the results go through various other types of checks. For AI, the ratio of the costs of the two types of reasoning might be roughly similar to the ratio for human. And it seems that the AI systems also perform various other checks (e.g. by calling up a fresh agent to critique the proof), which give a good level of confidence even without formalization.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae925ac28eadfe565c3de0f0c069a1e4c1caf124c42a78e812e03d58cd36a6a9-bfc5f271dcc4181b5a3e2ff355816133a60cfc08f8d722a9283dcc97591dbd6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leigh Stephenson")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698368")[#strong[#text("Leigh Stephenson")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2026")])]

#text("Thank you for taking the time to consider what things must be done to achieve an ideal outcome in the maths world, though I doubt it is a unique solution. Unfortunately, whether or not a dark age sets upon mathematics may have reasons outside whatever strategies are concocted within the community, as LLM as unproved educational products are foisted upon schools and universities. The crisis to maths I would also say takes a back seat to environmental concerns and demographic change which hopefully will be addressed but will like be the source of much upheaval for many centuries.")

#text("So when you say dark age for maths, I imagine a dark age more universally, perhaps resembling the situation in A Canticle for Leibowitz, though maybe with less fallout.")

#text("To be somewhat constructive, I do believe that mathematicians owe it to themselves and to their society to take responsibility and do what they can to affirm a place within human culture, so I’ll take that as a guiding principle.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698396")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2026")])]

#text("Imagine math as the Book that Erdős described, but with some of its pages lost, incomplete, or erased. Is it possible for LLMs to reconstruct the missing parts just by looking at the pages we have?")

#text("LLMs compress humanity’s mathematical knowledge and then try to complete whatever they are given using that knowledge. Can they generalize? If so, how much? If not, can the Book be reconstructed at all?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c362f3735b211c22413bc8c3ad496aeba4d5f0261acab76e3f1522ab660816f3-1176ea5ca7062b5905272d590bbc6941a0f42c89c5d8f0843babd657e962b537.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of turtleluminousa613153523")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698441")[#strong[#text("turtleluminousa613153523")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("Claims AI’s creativity is limited is, perhaps, a red herring. The inflection point is accepting a given formalization of mathematics and it’s mechanical verifier – search can, in principle, find any proof our creativity could lead us to. A description of “A (not so beautiful) Book” that, somewhere in it’s infinite pages has every valid formal proof (according to the verifier), can be given by considering all strings up to some length which are syntactically valid as proofs, and giving the verifier a fixed amount of time, for each string, to prove, reject by counterexample, or fail to decide. Increase the upper limit of the length of the strings and the time limit, and repeat. We know neither proofs nor counterexamples for some correctly constructed hypotheses will be in the book, but reading up to any given page, we can’t be sure exactly which strings that have failed to be decided so far will be resolved later in the book.")

#text("The question of which proofs are most beautiful, and would appear in Erdős Book, is still undefinable (arguably none, if you find formalism ugly).")

#text("However compelling “chats” with LLMs might be, given a formal hypothesis. their role in finding a formal proof can be framed as a search heuristic, even if it’s a one shot. Your question is whether or not the LLM heuristic prunes some pathways to definitive answers. Transforming what LLMs do into comprehensible heuristics for “old-school symbolic AI” (aka search) would bring us closer to understanding what’s happening and moving away from mistaking LLMs for collaborators.")

#text("Does including the works of Shakespeare, or descriptions of what a “red herring” is, in the LLMs training set improve it’s Mathematical ability? Wouldn’t we like to know?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f66292a8fb23260a0486cc611887e1b89edcc0fe568c0d0d6244a61ef2d8114d-31f3192b982901d1d91200619d27abe93284136e9f1f77804143b0f8c98364c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jeanamella")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698504")[#strong[#text("jeanamella")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("We do not need mathematical heroes, because mathematics is a natural science and should neither be owned nor capitalized on by anyone, whether through prestige or money. In reality, we need 29–50 years to achieve a blockbuster breakthrough in mathematics. Another reality is that mathematics is gradually approaching the limits of the classical framework. It is facing numerous historically significant challenges that are delaying the progress of human science, leaving human civilization and scientific understanding primitive and obscure for a prolonged period, until we realize whether it is too late for new breakthroughs. Therefore, we need AI and the creative freedom that AI can provide.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a117bd7be6f6e0b99a5e1eb6f5b1bcc527a01f5abc19780336d2d6c27129008-df2a072102977d04297c6fc1fb9cd4864cf3f6eb170bda71a3967cbd2a9df1f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leo")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698506")[#strong[#text("Leo")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2026")])]

#text("The distinction drawn here between output rising and independent human understanding weakening is the part that stays with me. Output is easy to count; whether a new generation still builds intuition by struggling with problems is much harder to see until it is gone. One concrete lever seems to be what departments and journals give credit for. If verifying, explaining, and turning machine-generated arguments into something people genuinely understand counted as real contributions, the golden-age scenario would have institutional support instead of relying on individual goodwill.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea44efbf41418c72dc466b09998fdcb4b0abc0c094c698f07828aca69a377358-6c3f593f6a9db5d47fcce38bf651ad5b65e734a6a8dd56f58bdd0962e3818c24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of admin")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698756")[#strong[#text("admin")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("The main issue is that the addiction to ready-made science has spread everywhere, starting with experienced scientists!")

#text("We should all start caring more about the next generation and try to preserve the fundamental principles of research.")

#text("We all know that one day it will happen:")

#link("https://doi.org/10.2139/ssrn.6223538")[#text("https://doi.org/10.2139/ssrn.6223538")]

#text("AI has exposed this weakness of ours, yet we continue to slide further in the wrong direction!")

#text("But, to prevent this and anything new coming, then we all must first solve and teach:")

#link("https://doi.org/10.2139/ssrn.6290658")[#text("https://doi.org/10.2139/ssrn.6290658")]

#text("[We will all be happy if everyone chooses what purpose they are intended for in the era of AI]")

#text("Some recent examples:")

#text("[1] ")#link("https://www.linkedin.com/posts/panagiotis-gioannis-3b8605186_we-all-know-that-one-day-it-will-happen-share-7510036290709626880-hUjn/")[#text("https://www.linkedin.com/posts/panagiotis-gioannis-3b8605186_we-all-know-that-one-day-it-will-happen-share-7510036290709626880-hUjn/")]

#text("[Using AI, a professor wrote 200 papers this year. Researchers are alarmed]")

#text("[2] ")#link("https://www.linkedin.com/posts/panagiotis-gioannis-3b8605186_in-doing-so-dr-mestre-said-he-and-colleagues-share-7510420411776663553-UgAe/")[#text("https://www.linkedin.com/posts/panagiotis-gioannis-3b8605186_in-doing-so-dr-mestre-said-he-and-colleagues-share-7510420411776663553-UgAe/")]

#text("[Did Anthropic’s A.I. Really Make a Scientific Discovery on Its Own?]")

#text("[3] ")#link("https://www.linkedin.com/posts/panagiotis-gioannis-3b8605186_we-all-know-that-someday-it-will-happen-share-7506754918565904384-1a8_/")[#text("https://www.linkedin.com/posts/panagiotis-gioannis-3b8605186_we-all-know-that-someday-it-will-happen-share-7506754918565904384-1a8_/")]

#text("[OpenAI … math]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4e4e26441e70f3294e1b416f1197daa85464c77b5c1e63e7714d0f909c35e80-b6874de23959d332ec7a366bacaf13a45a02615f72f691ed2f545c69486f49e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ken ken")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698883")[#strong[#text("ken ken")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2026")])]

#text("Navigating the profound shifts brought by AI in mathematics and scientific research offers a critical lens on balancing technological capability with human comprehension. Ensuring that science remains grounded in human understanding is such a vital dialogue for the future of research. I was actually reading a discussion on artificial intelligence in academic research and the future of scientific methodology over on ")#link("https://yonoreview.com/apps/ever-777/")[#text("ever 777")]#text(" recently, and it highlights just how important it is to preserve independent inquiry. Thanks for sharing this thought-provoking perspective!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebfd1e9ea71b5b2ff4845cf6e4521eaa5116b72f0577f74e2d01047b13fa3c6f-3868187fd3f303a7ff8f9fbe15737780d7a3c0cce1762096ac17d51fb8c76ba9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lawrence Paulson")]], [#link("https://terrytao.wordpress.com/2026/10/18/will-it-be-a-golden-age-or-a-dark-age-for-mathematics-and-science/comment-page-1/#comment-698961")[#strong[#text("Lawrence Paulson")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2026")])]

#text("Interesting article, but with the usual monomania for Lean. In fact, Josef Urban’s ")#link("https://arxiv.org/abs/2601.03298")[#text("big autoformalisation experiment")]#text(" last year used a wholly unknown and very simple prover called Megalodon. Then he repeated his experiment with HOL Light. Then with Isabelle/HOL. It’s a big world; take time to look around it.")
]
