// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/
// Converted to Typst by tao2typ: "2026-10-14T09:31:08.366488+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Suppose one is given a ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H} = (h_1,\\ldots,h_{k_0})}")#text(" of ")#mi("{k_0}")#text(" distinct integers for some ")#mi("{k_0 \\geq 1}")#text(", arranged in increasing order. When is it possible to find infinitely many translates ")#mi("{n + {\\mathcal H} =(n+h_1,\\ldots,n+h_{k_0})}")#text(" of ")#mi("{{\\mathcal H}}")#text(" which consists entirely of primes? The case ")#mi("{k_0=1}")#text(" is just ")#link("http://en.wikipedia.org/wiki/Euclid%27s_theorem")[#text("Euclid’s theorem")]#text(" on the infinitude of primes, but the case ")#mi("{k_0=2}")#text(" is already open in general, with the ")#mi("{{\\mathcal H} = (0,2)}")#text(" case being the notorious ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(".")

#text("On the other hand, there are some tuples ")#mi("{{\\mathcal H}}")#text(" for which one can easily answer the above question in the negative. For instance, the only translate of ")#mi("{(0,1)}")#text(" that consists entirely of primes is ")#mi("{(2,3)}")#text(", basically because each translate of ")#mi("{(0,1)}")#text(" must contain an even number, and the only even prime is ")#mi("{2}")#text(". More generally, if there is a prime ")#mi("{p}")#text(" such that ")#mi("{{\\mathcal H}}")#text(" meets each of the ")#mi("{p}")#text(" residue classes ")#mi("{0 \\text{ mod } p, 1 \\text{ mod } p, \\ldots, p-1 \\text{ mod } p}")#text(", then every translate of ")#mi("{{\\mathcal H}}")#text(" contains at least one multiple of ")#mi("{p}")#text("; since ")#mi("{p}")#text(" is the only multiple of ")#mi("{p}")#text(" that is prime, this shows that there are only finitely many translates of ")#mi("{{\\mathcal H}}")#text(" that consist entirely of primes.")

#text("To avoid this obstruction, let us call a ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(" ")#emph[#text("admissible")]#text(" if it avoids at least one residue class ")#mi("{\\text{ mod } p}")#text(" for each prime ")#mi("{p}")#text(". It is easy to check for admissibility in practice, since a ")#mi("{k_0}")#text("-tuple is automatically admissible in every prime ")#mi("{p}")#text(" larger than ")#mi("{k_0}")#text(", so one only needs to check a finite number of primes in order to decide on the admissibility of a given tuple. For instance, ")#mi("{(0,2)}")#text(" or ")#mi("{(0,2,6)}")#text(" are admissible, but ")#mi("{(0,2,4)}")#text(" is not (because it covers all the residue classes modulo ")#mi("{3}")#text("). We then have the famous ")#link("http://en.wikipedia.org/wiki/Prime_k-tuple")[#text("Hardy-Littlewood prime tuples conjecture")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Prime tuples conjecture, qualitative form)")]#text(" ")#metadata(none) <tao-d9e826e427a4a24d7daa>#text(" If ")#mi("{{\\mathcal H}}")#text(" is an admissible ")#mi("{k_0}")#text("-tuple, then there exists infinitely many translates of ")#mi("{{\\mathcal H}}")#text(" that consist entirely of primes.")
]

#text("This conjecture is extremely difficult (containing the twin prime conjecture, for instance, as a special case), and in fact there is ")#emph[#text("no")]#text(" explicitly known example of an admissible ")#mi("{k_0}")#text("-tuple with ")#mi("{k_0 \\geq 2}")#text(" for which we can verify this conjecture (although, thanks to the ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("recent work of Zhang")]#text(", we know that ")#mi("{(0,d)}")#text(" satisfies the conclusion of the prime tuples conjecture for some ")#mi("{0 < d < 70,000,000}")#text(", even if we can’t yet say what the precise value of ")#mi("{d}")#text(" is).")

#text("Actually, Hardy and Littlewood conjectured a more precise version of Conjecture ")#link(<tao-d9e826e427a4a24d7daa>)[#text("1")]#text(". Given an admissible ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H} = (h_1,\\ldots,h_{k_0})}")#text(", and for each prime ")#mi("{p}")#text(", let ")#tao-math("{\\nu_p = \\nu_p({\\mathcal H}) := \\left|{\\mathcal H} \\text{ mod } p\\right|}", block: false)#text(" denote the number of residue classes modulo ")#mi("{p}")#text(" that ")#mi("{{\\mathcal H}}")#text(" meets; thus we have ")#mi("{1 \\leq \\nu_p \\leq p-1}")#text(" for all ")#mi("{p}")#text(" by admissibility, and also ")#mi("{\\nu_p = k_0}")#text(" for all ")#mi("{p>h_{k_0}-h_1}")#text(". We then define the ")#emph[#text("singular series")]#text(" ")#mi("{{\\mathfrak G} = {\\mathfrak G}({\\mathcal H})}")#text(" associated to ")#mi("{{\\mathcal H}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathfrak G} := \\prod_{p \\in {\\mathcal P}} \\frac{1-\\frac{\\nu_p}{p}}{(1-\\frac{1}{p})^{k_0}}")]]

#text("where ")#mi("{{\\mathcal P} = \\{2,3,5,\\ldots\\}}")#text(" is the set of primes; by the previous discussion we see that the infinite product in ")#mi("{{\\mathfrak G}}")#text(" converges to a finite non-zero number.")

#text("We will also need some asymptotic notation (in the spirit of “")#link("https://terrytao.wordpress.com/2012/04/02/a-cheap-version-of-nonstandard-analysis/")[#text("cheap nonstandard analysis")]#text("“). We will need a parameter ")#mi("{x}")#text(" that one should think of going to infinity. Some mathematical objects (such as ")#mi("{{\\mathcal H}}")#text(" and ")#mi("{k_0}")#text(") will be independent of ")#mi("{x}")#text(" and referred to as ")#emph[#text("fixed")]#text("; but unless otherwise specified we allow all mathematical objects under consideration to depend on ")#mi("{x}")#text(". If ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are two such quantities, we say that ")#mi("{X = O(Y)}")#text(" if one has ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some fixed ")#mi("{C}")#text(", and ")#mi("{X = o(Y)}")#text(" if one has ")#tao-math("{\\left|X\\right| \\leq c(x) Y}", block: false)#text(" for some function ")#mi("{c(x)}")#text(" of ")#mi("{x}")#text(" (and of any fixed parameters present) that goes to zero as ")#mi("{x \\rightarrow \\infty}")#text(" (for each choice of fixed parameters).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (Prime tuples conjecture, quantitative form)")]#text(" ")#metadata(none) <tao-0a1013386dd38ca8fcc4>#text(" Let ")#mi("{k_0 \\geq 1}")#text(" be a fixed natural number, and let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple. Then the number of natural numbers ")#mi("{n < x}")#text(" such that ")#mi("{n+{\\mathcal H}}")#text(" consists entirely of primes is ")#mi("{({\\mathfrak G} + o(1)) \\frac{x}{\\log^{k_0} x}}")#text(".")
]

#text("Thus, for instance, if Conjecture ")#link(<tao-0a1013386dd38ca8fcc4>)[#text("2")]#text(" holds, then the number of twin primes less than ")#mi("{x}")#text(" should equal ")#mi("{(2 \\Pi_2 + o(1)) \\frac{x}{\\log^2 x}}")#text(", where ")#mi("{\\Pi_2}")#text(" is the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin prime constant")]

#align(center)[#tao-fit-display[#mitex("\\Pi_2 := \\prod_{p \\in {\\mathcal P}: p>2} (1 - \\frac{1}{(p-1)^2}) = 0.6601618\\ldots.")]]

#text("As this conjecture is stronger than Conjecture ")#link(<tao-d9e826e427a4a24d7daa>)[#text("1")]#text(", it is of course open. However there are a number of partial results on this conjecture. For instance, this conjecture is known to be true if one introduces some additional averaging in ")#mi("{{\\mathcal H}}")#text("; see for instance ")#link("https://terrytao.wordpress.com/2008/11/18/marker-lectures-ii-linear-equations-in-primes/")[#text("this previous post")]#text(". From the methods of ")#link("http://en.wikipedia.org/wiki/Sieve_theory")[#text("sieve theory")]#text(", one can obtain an ")#emph[#text("upper bound")]#text(" of ")#mi("{(C_{k_0} {\\mathfrak G} + o(1)) \\frac{x}{\\log^{k_0} x}}")#text(" for the number of ")#mi("{n < x}")#text(" with ")#mi("{n + {\\mathcal H}}")#text(" all prime, where ")#mi("{C_{k_0}}")#text(" depends only on ")#mi("{k_0}")#text(". Sieve theory can also give analogues of Conjecture ")#link(<tao-0a1013386dd38ca8fcc4>)[#text("2")]#text(" if the primes are replaced by a suitable notion of ")#link("http://en.wikipedia.org/wiki/Almost_prime")[#text("almost prime")]#text(" (or more precisely, by a weight function concentrated on almost primes).")

#text("Another type of partial result towards Conjectures ")#link(<tao-d9e826e427a4a24d7daa>)[#text("1")]#text(", ")#link(<tao-0a1013386dd38ca8fcc4>)[#text("2")]#text(" come from the results ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("of Goldston-Pintz-Yildirim")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("Motohashi-Pintz")]#text(", and ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("of Zhang")]#text(". Following the notation of ")#link("http://arxiv.org/abs/1305.6289")[#text("this recent paper of Pintz")]#text(", for each ")#mi("{k_0>2}")#text(", let ")#mi("{DHL[k_0,2]}")#text(" denote the following assertion (DHL stands for “Dickson-Hardy-Littlewood”):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 3")]#text(" (")#mi("{DHL[k_0,2]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple. Then there are infinitely many translates ")#mi("{n+{\\mathcal H}}")#text(" of ")#mi("{{\\mathcal H}}")#text(" which contain ")#emph[#text("at least two")]#text(" primes.")
]

#text("This conjecture gets harder as ")#mi("{k_0}")#text(" gets smaller. Note for instance that ")#mi("{DHL[2,2]}")#text(" would imply all the ")#mi("{k_0=2}")#text(" cases of Conjecture ")#link(<tao-d9e826e427a4a24d7daa>)[#text("1")]#text(", including the twin prime conjecture. More generally, if one knew ")#mi("{DHL[k_0,2]}")#text(" for some ")#mi("{k_0}")#text(", then one would immediately conclude that there are an infinite number of pairs of consecutive primes of separation at most ")#mi("{H(k_0)}")#text(", where ")#mi("{H(k_0)}")#text(" is the minimal diameter ")#mi("{h_{k_0}-h_1}")#text(" amongst all admissible ")#mi("{k_0}")#text("-tuples ")#mi("{{\\mathcal H}}")#text(". Values of ")#mi("{H(k_0)}")#text(" for small ")#mi("{k_0}")#text(" can be found at ")#link("http://www.opertech.com/primes/k-tuples.html")[#text("this link")]#text(" (with ")#mi("{H(k_0)}")#text(" denoted ")#mi("{w}")#text(" in that page). For large ")#mi("{k_0}")#text(", the best upper bounds on ")#mi("{H(k_0)}")#text(" have been found by using admissible ")#mi("{k_0}")#text("-tuples ")#mi("{{\\mathcal H}}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("{\\mathcal H} = ( - p_{m+\\lfloor k_0/2\\rfloor - 1}, \\ldots, - p_{m+1}, -1, +1, p_{m+1}, \\ldots, p_{m+\\lfloor (k_0+1)/2\\rfloor - 1} )")]]

#text("where ")#mi("{p_n}")#text(" denotes the ")#mi("{n^{th}}")#text(" prime and ")#mi("{m}")#text(" is a parameter to be optimised over (in practice it is an order of magnitude or two smaller than ")#mi("{k_0}")#text("); see ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart/")[#text("this blog post for details")]#text(". The upshot is that one can bound ")#mi("{H(k_0)}")#text(" for large ")#mi("{k_0}")#text(" by a quantity slightly smaller than ")#mi("{k_0 \\log k_0}")#text(" (and the large sieve inequality shows that this is sharp up to a factor of two, see e.g. ")#link("https://terrytao.wordpress.com/2011/12/31/montgomerys-uncertainty-principle/")[#text("this previous post")]#text(" for more discussion).")

#text("In a key breakthrough, ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("Goldston, Pintz, and Yildirim")]#text(" were able to establish the following conditional result a few years ago:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Goldston-Pintz-Yildirim)")]#text(" ")#metadata(none) <tao-017477be6610750917d7>#text(" Suppose that the ")#link("http://en.wikipedia.org/wiki/Elliott-Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(" ")#mi("{EH[\\theta]}")#text(" is true for some ")#mi("{1/2 < \\theta < 1}")#text(". Then ")#mi("{DHL[k_0,2]}")#text(" is true for some finite ")#mi("{k_0}")#text(". In particular, this establishes an infinite number of pairs of consecutive primes of separation ")#mi("{O(1)}")#text(".")
]

#text("The dependence of constants between ")#mi("{k_0}")#text(" and ")#mi("{\\theta}")#text(" given by the Goldston-Pintz-Yildirim argument is basically of the form ")#mi("{k_0 \\sim (\\theta-1/2)^{-2}}")#text(". (UPDATE: as recently ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("observed by Farkas, Pintz, and Revesz")]#text(", this relationship can be improved to ")#mi("{k_0 \\sim (\\theta-1/2)^{-3/2}}")#text(".)")

#text("Unfortunately, the Elliott-Halberstam conjecture (which we will state properly below) is only known for ")#mi("{\\theta<1/2}")#text(", an important result known as the ")#link("http://en.wikipedia.org/wiki/Bombieri%E2%80%93Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(". If one uses the Bombieri-Vinogradov theorem instead of the Elliott-Halberstam conjecture, Goldston, Pintz, and Yildirim were still able to show the highly non-trivial result that there were infinitely many pairs ")#mi("{p_{n+1},p_n}")#text(" of consecutive primes with ")#mi("{(p_{n+1}-p_n) / \\log p_n \\rightarrow 0}")#text(" (actually they showed more than this; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2265008")[#text("this survey of Soundararajan")]#text(" for details).")

#text("Actually, the full strength of the Elliott-Halberstam conjecture is not needed for these results. There is a technical specialisation of the Elliott-Halberstam conjecture which does not presently have a commonly accepted name; I will call it the ")#emph[#text("Motohashi-Pintz-Zhang conjecture")]#text(" ")#mi("{MPZ[\\varpi]}")#text(" in this post, where ")#mi("{0 < \\varpi < 1/4}")#text(" is a parameter. We will define this conjecture more precisely later, but let us remark for now that ")#mi("{MPZ[\\varpi]}")#text(" is a consequence of ")#mi("{EH[\\frac{1}{2}+2\\varpi]}")#text(".")

#text("We then have the following two theorems. Firstly, we have the following strengthening of Theorem ")#link(<tao-017477be6610750917d7>)[#text("4")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (Motohashi-Pintz-Zhang)")]#text(" ")#metadata(none) <tao-20854963535d2fa25505>#text(" Suppose that ")#mi("{MPZ[\\varpi]}")#text(" is true for some ")#mi("{0 < \\varpi < 1/4}")#text(". Then ")#mi("{DHL[k_0,2]}")#text(" is true for some ")#mi("{k_0}")#text(".")
]

#text("A version of this result (with a slightly different formulation of ")#mi("{MPZ[\\varpi]}")#text(") appears in ")#link("http://www.ams.org/mathscinet-getitem?mr=2414788")[#text("this paper of Motohashi and Pintz")]#text(", and in ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("the paper of Zhang")]#text(", Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(" is proven for the concrete values ")#mi("{\\varpi = 1/1168}")#text(" and ")#mi("{k_0 = 3,500,000}")#text(". We will supply a self-contained proof of Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(" below the fold, the constants upon those in Zhang’s paper (in particular, for ")#mi("{\\varpi = 1/1168}")#text(", we can take ")#mi("{k_0}")#text(" as low as ")#mi("{341,640}")#text(", with further improvements on the way). As with Theorem ")#link(<tao-017477be6610750917d7>)[#text("4")]#text(", we have an inverse quadratic relationship ")#mi("{k_0 \\sim \\varpi^{-2}}")#text(".")

#text("In his paper, Zhang obtained for the first time an unconditional advance on ")#mi("{MPZ[\\varpi]}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Zhang)")]#text(" ")#metadata(none) <tao-01aae5bc4882bc2e94f1>#text(" ")#mi("{MPZ[\\varpi]}")#text(" is true for all ")#mi("{0 < \\varpi \\leq 1/1168}")#text(".")
]

#text("This is a deep result, building upon the work of ")#link("http://www.ams.org/mathscinet-getitem?mr=610700")[#text("Fouvry-Iwaniec")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=786351")[#text("Friedlander-Iwaniec")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=834613")[#text("Bombieri")]#text("–")#link("http://www.ams.org/mathscinet-getitem?mr=891581")[#text("Friedlander")]#text("–")#link("http://www.ams.org/mathscinet-getitem?mr=976723")[#text("Iwaniec")]#text(" which established results of a similar nature to ")#mi("{MPZ[\\varpi]}")#text(" but simpler in some key respects. We will not discuss this result further here, except to say that they rely on the (higher-dimensional case of the) ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(", which were famously proven by Deligne using methods from ")#link("http://en.wikipedia.org/wiki/L-adic_cohomology")[#text("l-adic cohomology")]#text(". Also, it was believed among at least some experts that the methods of Bombieri, Fouvry, Friedlander, and Iwaniec were not quite strong enough to obtain results of the form ")#mi("{MPZ[\\varpi]}")#text(", making Theorem ")#link(<tao-01aae5bc4882bc2e94f1>)[#text("6")]#text(" a particularly impressive achievement.")

#text("Combining Theorem ")#link(<tao-01aae5bc4882bc2e94f1>)[#text("6")]#text(" with Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(" we obtain ")#mi("{DHL[k_0,2]}")#text(" for some finite ")#mi("{k_0}")#text("; Zhang obtains this for ")#mi("{k_0 = 3,500,000}")#text(" but as detailed below, this can be lowered to ")#mi("{k_0 = 341,640}")#text(". This in turn gives infinitely many pairs of consecutive primes of separation at most ")#mi("{H(k_0)}")#text(". Zhang gives a simple argument that bounds ")#mi("{H(3,500,000)}")#text(" by ")#mi("{70,000,000}")#text(", giving his famous result that there are infinitely many pairs of primes of separation at most ")#mi("{70,000,000}")#text("; by being a bit more careful (as discussed in ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart/")[#text("this post")]#text(") one can lower the upper bound on ")#mi("{H(3,500,000)}")#text(" to ")#mi("{57,554,086}")#text(", and if one instead uses the newer value ")#mi("{k_0 = 341,640}")#text(" for ")#mi("{k_0}")#text(" one can instead use the bound ")#mi("{H(341,640) \\leq 4,982,086}")#text(". (Many thanks to Scott Morrison for these numerics.) UPDATE: These values are now obsolete; see ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes#World_records")[#text("this web page")]#text(" for the latest bounds.")

#text("In this post we would like to give a self-contained proof of both Theorem ")#link(<tao-017477be6610750917d7>)[#text("4")]#text(" and Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(", which are both sieve-theoretic results that are mainly elementary in nature. (But, as stated earlier, we will not discuss the deepest new result in Zhang’s paper, namely Theorem ")#link(<tao-01aae5bc4882bc2e94f1>)[#text("6")]#text(".) Our presentation will deviate a little bit from the traditional sieve-theoretic approach in a few places. Firstly, there is a portion of the argument that is traditionally handled using contour integration and properties of the Riemann zeta function; we will present a “cheaper” approach (which Ben Green and I used in our papers, e.g. in ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("this one")]#text(") using Fourier analysis, with the only property used about the zeta function ")#mi("{\\zeta(s)}")#text(" being the elementary fact that blows up like ")#mi("{\\frac{1}{s-1}}")#text(" as one approaches ")#mi("{1}")#text(" from the right. To deal with the contribution of small primes (which is the source of the singular series ")#mi("{{\\mathfrak G}}")#text("), it will be convenient to use the “")#mi("{W}")#text("-trick” (introduced in ")#link("http://www.ams.org/mathscinet-getitem?mr=2415379")[#text("this paper of mine with Ben")]#text("), passing to a single residue class mod ")#mi("{W}")#text(" (where ")#mi("{W}")#text(" is the product of all the small primes) to end up in a situation in which all small primes have been “turned off” which leads to better pseudorandomness properties (for instance, once one eliminates all multiples of small primes, almost all pairs of remaining numbers will be coprime).")

#metadata(none) <tao-1c1a6eebb79640bb9dc0>

#heading(level: 1)[#strong[#text(" — 1. The ")#mi("{W}")#text("-trick — ")]]

#text("In this section we introduce the “")#mi("{W}")#text("-trick”, which is a simple but useful device that automatically takes care of local factors arising from small primes, such as the singular series ")#mi("{{\\mathfrak G}}")#text(". The price one pays for this trick is that the explicit decay rates in various ")#mi("{o(1)}")#text(" terms can be rather poor, but for the applications here, we will not need to know any information on these decay rates and so the ")#mi("{W}")#text("-trick may be freely applied.")

#text("Let ")#mi("{w}")#text(" be a natural number, which should be thought of as either fixed and large, or as a very slowly growing function of ")#mi("{x}")#text(". Actually, the two viewpoints are basically equivalent for the purposes of asymptotic analysis (at least at the qualitative level of ")#mi("{o(1)}")#text(" decay rates), thanks to the following basic principle:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Overspill principle)")]#text(" ")#metadata(none) <tao-4356298b9e1872371c48>#text(" Let ")#mi("{F(w,x)}")#text(" be a quantity depending on ")#mi("{w}")#text(" and ")#mi("{x}")#text(". Then the following are equivalent:")

#list(
[#text("(i) For every fixed ")#mi("{\\epsilon>0}")#text(" there exists a fixed ")#mi("{w_\\epsilon > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|F(w,x)\\right| \\leq \\epsilon + o(1)", block: true)]]

#text("for all fixed ")#mi("{w \\geq w_\\epsilon}")#text(".")],
[#text("(ii) We have")

#align(center)[#tao-fit-display[#mitex("F(w,x) = o(1)")]]

#text("whenever ")#mi("{w = w(x)}")#text(" is a function of ")#mi("{x}")#text(" going to infinity that is sufficiently slowly growing. (In other words, there exists a function ")#mi("{w_0: {\\bf R}^+ \\rightarrow {\\bf N}}")#text(" going to infinity with the property that ")#mi("{F(w,x)=o(1)}")#text(" whenever ")#mi("{w = w(x)}")#text(" is a natural number-valued function of ")#mi("{x}")#text(" is such that ")#mi("{w(x) \\rightarrow \\infty}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(" and ")#mi("{w(x) \\leq w_0(x)}")#text(" for all sufficiently large ")#mi("{x}")#text(".)")]
)
]

#text("This principle is closely related to the ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill principle")]#text(" from nonstandard analysis, though we will not explicitly adopt a nonstandard perspective here. It is also similar in spirit to the diagonalisation trick used to prove the Arzela-Ascoli theorem.")

#emph[#text("Proof:")]#text(" We first show that (i) implies (ii). By (i), we see that for every natural number ")#mi("{n}")#text(", we can find a real number ")#mi("{x_n}")#text(" with the property that")

#align(center)[#tao-fit-display[#tao-math("\\left|F(w,x)\\right| \\leq \\frac{2}{m}", block: true)]]

#text("whenever ")#mi("{1 \\leq m \\leq n}")#text(", ")#mi("{1 \\leq w \\leq n}")#text(", and ")#mi("{x \\geq x_n}")#text(" are such that ")#mi("{w \\geq w_{1/m}}")#text(". By increasing the ")#mi("{x_n}")#text(" as necessary we may assume that they are increasing and go to infinity as ")#mi("{n \\rightarrow \\infty}")#text(". If we then define ")#mi("{w_0(x)}")#text(" to equal the largest natural number ")#mi("{n}")#text(" for which ")#mi("{x \\geq x_n}")#text(", or equal to ")#mi("{1}")#text(" if no such number exists, then one easily verifies that ")#mi("{F(w,x)=o(1)}")#text(" whenever ")#mi("{w= w(x)}")#text(" goes to infinity and is bounded by ")#mi("{w_0}")#text(" for sufficiently large ")#mi("{x}")#text(".")

#text("Now we show that (ii) implies (i). Suppose for contradiction that (i) failed, then we can find a fixed ")#mi("{\\epsilon>0}")#text(" with the property that for any natural number ")#mi("{n}")#text(", there exist ")#mi("{w_n \\geq n}")#text(" such that ")#tao-math("{\\left|F(w_n,x_n)\\right| \\geq \\epsilon}", block: false)#text(" for arbitrarily large ")#mi("{x_n}")#text(". We can select the ")#mi("{w_n}")#text(" to be increasing to infinity, and then we can find a sequence ")#mi("{x_n}")#text(" increasing to infinity such that ")#tao-math("{\\left|F(w_n,x_n)\\right| \\geq \\epsilon}", block: false)#text(" for all ")#mi("{n}")#text("; by increasing ")#mi("{x_n}")#text(" as necessary, we can also ensure that ")#mi("{w_0(x) \\geq w_n}")#text(" for all ")#mi("{x \\geq x_n}")#text(" and ")#mi("{n}")#text(". If we then define ")#mi("{w(x)}")#text(" to be ")#mi("{w_n}")#text(" when ")#mi("{x_n \\leq x < x_{n+1}}")#text(", and ")#mi("{w(x)=1}")#text(" for ")#mi("{x < x_1}")#text(", we see that ")#tao-math("{\\left|F(w,x)\\right| \\geq \\epsilon}", block: false)#text(" whenever ")#mi("{x=x_n}")#text(", contradicting (ii). ")#mi("\\Box")

#text("Henceforth we will usually think of ")#mi("{w}")#text(" as a sufficiently slowly growing function of ")#mi("{x}")#text(", although we will on occasion take advantage of Lemma ")#link(<tao-4356298b9e1872371c48>)[#text("7")]#text(" to switch to thinking of ")#mi("{w}")#text(" as a large fixed quantity instead. In either case, we should think of ")#mi("{w}")#text(" as exceeding the size of fixed quantities such as ")#mi("{k}")#text(" or ")#mi("{h_k-h_1}")#text(", at least in the limit where ")#mi("{x}")#text(" is large; in particular, for a fixed ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(", we will have ")#metadata(none) <tao-5ff943050a79b0e6f3f6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\nu_p = k_0 \\text{ for all } p > w")]]



#text(" if ")#mi("{x}")#text(" is large enough. A particular consequence of the growing nature of ")#mi("{w}")#text(" is that ")#metadata(none) <tao-30c952fab122c3f9759f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{p > w} \\frac{1}{p^2} = o(1)")]]



#text(" as this follows from the absolutely convergent nature of the sum ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{n^2}}")#text(" and hence also ")#mi("{\\sum_p \\frac{1}{p^2}}")#text(". As a consequence of this, once we “turn off” all the primes less than ")#mi("{w}")#text(", any errors in our sieve-theoretic analysis which are quadratic or higher in ")#mi("{1/p}")#text(" can be essentially ignored, which will be very convenient for us. In a similar vein, for any fixed ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(", one has ")#metadata(none) <tao-f173a1438b19a61083aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\prod_{p>w} \\frac{1-\\frac{\\nu_p}{p}}{(1-\\frac{1}{p})^{k_0}} = 1+o(1)")]]



#text(" which allows one to truncate the singular series: ")#metadata(none) <tao-a04cdf8493f8abae7d90>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("{\\mathfrak G} = \\prod_{p \\leq w} \\frac{1-\\frac{\\nu_p}{p}}{(1-\\frac{1}{p})^{k_0}} + o(1).")]]





#text("In order to “turn off” all the small primes, we introduce the quantity ")#mi("{W}")#text(", defined as the product of all the primes up to ")#mi("{w}")#text(" (i.e. the ")#link("http://en.wikipedia.org/wiki/Primorial")[#text("primorial")]#text(" of ")#mi("{w}")#text("):")

#align(center)[#tao-fit-display[#mitex("W := \\prod_{p \\leq w} p.")]]

#text("As ")#mi("{w}")#text(" is going to infinity, ")#mi("{W}")#text(" is going to infinity also (but as slowly as we please). The idea of the ")#mi("{W}")#text("-trick is to search for prime patterns in a single residue class ")#mi("{b \\text{ mod } W}")#text(", which as mentioned earlier will “turn off” all the primes less than ")#mi("{w}")#text(" in the sieve-theoretic analysis.")

#text("Using ")#link(<tao-a04cdf8493f8abae7d90>)[#text("(4)")]#text(" and the Chinese remainder theorem, we may thus approximate the singular series as ")#metadata(none) <tao-f963de8a0491982412cc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("{\\mathfrak G} = \\frac{\\left|C(W)\\right|}{W} (\\frac{\\phi(W)}{W})^{-k_0} + o(1)", block: true)]]



#text(" where ")#mi("{\\phi(W)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Euler_totient_function")[#text("Euler totient function")]#text(" of ")#mi("{W}")#text(", and ")#mi("{C(W) \\subset {\\bf Z}/W{\\bf Z}}")#text(" is the set of residue classes ")#mi("{b \\text{ mod } W}")#text(" such that all of the shifts ")#mi("{b+h_1,\\ldots,b+h_{k_0}}")#text(" are coprime to ")#mi("{W}")#text(". Note that if ")#mi("{n+{\\mathcal H}}")#text(" consists purely of primes and ")#mi("{n}")#text(" is sufficiently large, then ")#mi("{n}")#text(" must lie in one of the residue classes in ")#mi("{C(W)}")#text(". Thus we can count tuples with ")#mi("{n+{\\mathcal H}}")#text(" all prime by working in each residue class in ")#mi("{C(W)}")#text(" separately. We conclude that Conjecture ")#link(<tao-0a1013386dd38ca8fcc4>)[#text("2")]#text(" is equivalent to the following “")#mi("{W}")#text("-tricked version” in which the singular series is no longer present (or, more precisely, has been replaced by some natural normalisation factors depending on ")#mi("{W}")#text(", such as ")#mi("{(\\phi(W)/W)^{-k_0}}")#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 8 (Prime tuples conjecture, W-tricked quantitative form)")]#text(" ")#metadata(none) <tao-991efd7994dd30f626fd>#text(" Let ")#mi("{k_0 \\geq 1}")#text(" be a fixed natural number, and let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple. Assume ")#mi("{w}")#text(" is a sufficiently slowly growing function of ")#mi("{x}")#text(". Then for any residue class ")#mi("{b \\text{ mod } W}")#text(" in ")#mi("{C(W)}")#text(", the number of natural numbers ")#mi("{n < x}")#text(" with ")#mi("{n=b \\text{ mod } W}")#text(" such that ")#mi("{n+{\\mathcal H}}")#text(" consists entirely of primes is ")#mi("{(\\frac{1}{W} (\\frac{W}{\\phi(W)})^{k_0} + o(1)) \\frac{x}{\\log^{k_0} x}}")#text(".")
]

#text("We will work with similarly ")#mi("{W}")#text("-tricked asymptotics in the analysis below.")

#heading(level: 1)[#strong[#text(" — 2. Sums of multiplicative functions — ")]]

#text("As a result of the sieve-theoretic computations to follow, we will frequently need to estimate sums of the form")

#align(center)[#tao-fit-display[#mitex("S_{0,R,I}( f, g ) := \\sum_{d \\in {\\mathcal S}_I} \\frac{f(d)}{d} g( \\frac{\\log d}{\\log R} )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{1,R,I}( f, g ) := \\sum_{d \\in {\\mathcal S}_I} \\mu(d) \\frac{f(d)}{d} g( \\frac{\\log d}{\\log R} )")]]

#text("where ")#mi("{f: {\\bf N} \\rightarrow {\\bf C}}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Multiplicative_function")[#text("multiplicative function")]#text(", the ")#emph[#text("sieve level")]#text(" ")#mi("{R>0}")#text(" (also denoted ")#mi("{D}")#text(" in some literature) is a fixed power of ")#mi("{x}")#text(" (such as ")#mi("{x^{1/4}}")#text(" or ")#mi("{x^{1/4+\\varpi}}")#text("), ")#mi("{\\mu}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Möbius_function")[#text("Möbius function")]#text(", ")#mi("{g: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a fixed smooth compactly supported function, ")#mi("{I}")#text(" is a (possibly half-infinite) interval in ")#mi("{(w,+\\infty)}")#text(", and ")#mi("{{\\mathcal S}_I}")#text(" is the set of square-free numbers that are products ")#mi("{p_1 \\ldots p_j}")#text(" of distinct primes ")#mi("{p_1,\\ldots,p_j}")#text(" in ")#mi("{I}")#text(". (Actually, in applications ")#mi("{g}")#text(" won’t ")#emph[#text("quite")]#text(" be smooth, but instead have some high order of differentiability (e.g. ")#mi("{k_0+l_0-1}")#text(" times continuously differentiable for some ")#mi("{l_0>0}")#text("), but we can extend the analysis of smooth ")#mi("{g}")#text(" to sufficiently differentiable ")#mi("{g}")#text(" by various standard limiting or approximation arguments which we will not dwell on here.) We will also need to control the more complicated variant")

#align(center)[#tao-fit-display[#mitex("S_{2,R,I}(f,g_1,g_2) := \\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\frac{\\mu(d_1) \\mu(d_2) f([d_1,d_2])}{[d_1,d_2]} g_1( \\frac{\\log d_1}{\\log R} ) g_2( \\frac{\\log d_2}{\\log R} )")]]

#text("where ")#mi("{g_1,g_2:{\\bf R} \\rightarrow {\\bf C}}")#text(" are also smooth compactly supported functions. In practice, the interval ")#mi("{I}")#text(" will be something like ")#mi("{(w, x^{1/4+\\varpi})}")#text(", ")#mi("{(w, x^\\varpi)}")#text(", ")#mi("{[x^\\varpi,x^{1/4+\\varpi}]}")#text(". In particular, thanks to the ")#mi("{W}")#text("-trick we will be able to turn off all the primes up to ")#mi("{w}")#text(", so that ")#mi("{I}")#text(" only contains primes larger than ")#mi("{w}")#text(", allowing us to take advantage of bounds such as ")#link(<tao-30c952fab122c3f9759f>)[#text("(2)")]#text(".")

#text("Once ")#mi("{d}")#text(" is restricted to ")#mi("{{\\mathcal S}_I}")#text(", the quantity ")#mi("{f(d)}")#text(" is determined entirely by the values of the multiplicative function ")#mi("{f}")#text(" at primes in ")#mi("{I}")#text(":")

#align(center)[#tao-fit-display[#mitex("f(d) = \\prod_{p \\in {\\mathcal P} \\cap I: p | d} f(p).")]]

#text("In applications, ")#mi("{f}")#text(" will have the size bound ")#metadata(none) <tao-1835e4c4552915e3a325>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("f(p) = k + O( \\frac{1}{p} )")]]



#text(" for all ")#mi("{p \\in I}")#text(" and some fixed positive ")#mi("{k}")#text(" (note that we allow the implied constants in the ")#mi("{O()}")#text(" notation to depend on quantities such as ")#mi("{k}")#text("); we refer to ")#mi("{k}")#text(" as the ")#emph[#text("dimension")]#text(" of the multiplicative function ")#mi("{f}")#text(". Henceforth we assume that ")#mi("{f}")#text(" has a fixed dimension ")#mi("{k}")#text(". We remark that we could unify the treatment of ")#mi("{S_{0,R,I}}")#text(" and ")#mi("{S_{1,R,I}}")#text(" in what follows by allowing multiplicative functions of negative dimension, but we will avoid doing so here. In our applications ")#mi("{k}")#text(" will be an integer; one could also generalise much of the discussion below to the fractional dimension case, but we will not need to do so here.")

#text("Traditionally the above expressions are handled by complex analysis, starting with ")#link("http://en.wikipedia.org/wiki/Perron%27s_formula")[#text("Perron’s formula")]#text(". We will instead take a slightly different Fourier-analytic approach. We perform a Fourier expansion of the smooth compactly supported function ")#mi("{e^x g(x)}")#text(" to obtain a representation ")#metadata(none) <tao-5312fb609f60384731fc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("e^x g(x) = \\int_{\\bf R} e^{-itx} \\hat g(t)\\ dt")]]



#text(" for some Schwartz function ")#mi("{\\hat g}")#text("; in particular, ")#mi("{\\hat g}")#text(" is rapidly decreasing. (Strictly speaking, ")#mi("{\\hat g}")#text(" is the Fourier transform of ")#mi("{g}")#text(" shifted in the complex domain by ")#mi("{i}")#text(", rather than the true Fourier transform of ")#mi("{g}")#text(", but we will ignore this distinction for the purposes of this discussion.) In particular we have")

#align(center)[#tao-fit-display[#mitex("g(\\frac{\\log d}{\\log R}) = \\int_{\\bf R} \\frac{1}{d^{\\frac{1+it}{\\log R}}} \\hat g(t)\\ dt")]]

#text("for any ")#mi("{d}")#text(". By Fubini’s theorem, we can thus write ")#mi("{S_{0,R,I}}")#text(" as")

#align(center)[#tao-fit-display[#mitex("S_{0,R,I}(f,g) = \\int_{\\bf R} \\sum_{d \\in {\\mathcal S}_I} \\frac{f(d)}{d^{1+\\frac{1+it}{\\log R}}} \\hat g(t)\\ dt,")]]

#text("which factorises as")

#align(center)[#tao-fit-display[#mitex("S_{0,R,I}(f,g) = \\int_{\\bf R} (\\prod_{p \\in I} (1 + \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}})) \\hat g(t)\\ dt.")]]

#text("Similarly one has")

#align(center)[#tao-fit-display[#mitex("S_{1,R,I}(f,g) = \\int_{\\bf R} (\\prod_{p \\in I} (1 - \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}})) \\hat g(t)\\ dt.")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{2,R,I}(f,g_1,g_2) = \\int_{\\bf R} \\int_{\\bf R} (\\prod_{p \\in I} (1 - \\frac{f(p)}{p^{1+\\frac{1+it_1}{\\log R}}} - \\frac{f(p)}{p^{1+\\frac{1+it_2}{\\log R}}} + \\frac{f(p)}{p^{1+\\frac{1+it_1+1+it_2}{\\log R}}} ))")]]

#align(center)[#tao-fit-display[#mitex("\\hat g_1(t_1) \\hat g_2(t_2)\\ dt_1 dt_2.")]]

#text("In order to use asymptotics of the Riemann zeta function near the pole ")#mi("{s=1}")#text(", it is convenient to temporarily truncate the above integrals to the region ")#tao-math("{\\left|t\\right| \\leq \\sqrt{\\log R}}", block: false)#text(" or ")#tao-math("{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log R}}", block: false)#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" For any fixed ")#mi("{A>0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("S_{0,R,I}(f,g) = \\int_{\\left|t\\right| \\leq \\sqrt{\\log R}} (\\prod_{p \\in I} (1 + \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}})) \\hat g(t)\\ dt + O( \\log^{-A} R)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("S_{1,R,I}(f,g) = \\int_{\\left|t\\right| \\leq \\sqrt{\\log R}} (\\prod_{p \\in I} (1 - \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}})) \\hat g(t)\\ dt + O( \\log^{-A} R)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("S_{2,R,I}(f,g) = \\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log R}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("(\\prod_{p \\in I} (1 - \\frac{f(p)}{p^{1+\\frac{1+it_1}{\\log R}}} - \\frac{f(p)}{p^{1+\\frac{1+it_2}{\\log R}}} + \\frac{f(p)}{p^{1+\\frac{1+it_1+1+it_2}{\\log R}}} ))")]]

#align(center)[#tao-fit-display[#mitex("\\hat g_1(t_1) \\hat g_2(t_2)\\ dt_1 dt_2 + O(\\log^{-A} R).")]]

#text("Also we have the crude bound")

#align(center)[#tao-fit-display[#mitex("S_{0,R,I}(f,g) = O( \\log^k R ).")]]
]

#emph[#text("Proof:")]#text(" We begin with the bounds on ")#mi("{S_{0,R,I}}")#text(". From ")#link(<tao-1835e4c4552915e3a325>)[#text("(6)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|1 + \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}})\\right| \\leq k p^{-1-\\frac{1}{\\log R}} + O( p^{-2} )", block: true)]]

#text("for ")#mi("{p \\in I}")#text(" (which forces ")#mi("{p>w}")#text(", so there is no issue with the singularity of the logarithm) and thus")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\in I} (1 + \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}}) = O( \\exp( k \\sum_p p^{-1-\\frac{1}{\\log R}} ) ).")]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\prod_p (1-\\frac{1}{p^{1+1/\\log R}}) = \\frac{1}{\\zeta(1+1/\\log R)} = \\frac{1}{\\log R + O(1)}")]]

#text("we see on taking logarithms that")

#align(center)[#tao-fit-display[#mitex("\\sum_p p^{-1-\\frac{1}{\\log R}} = \\log\\log R + O(1)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\in I} (1 + \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}}) = O( \\log^k R ).")]]

#text("The bounds on ")#mi("{S_{0,R,I}(f,g)}")#text(" then follow from the rapid decrease of ")#mi("{\\hat g}")#text(". The bounds for ")#mi("{S_{1,R,I}}")#text(" and ")#mi("{S_{2,R,I}}")#text(" are proven similarly. ")#mi("\\Box")

#text("From ")#link(<tao-1835e4c4552915e3a325>)[#text("(6)")]#text(" and the restriction of ")#mi("{I}")#text(" to quantities larger than ")#mi("{w}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("(\\prod_{p \\in I} (1 + \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}})) = (1+o(1)) \\zeta_I(1+\\frac{1+it}{\\log R})^k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(\\prod_{p \\in I} (1 - \\frac{f(p)}{p^{1+\\frac{1+it}{\\log R}}})) = (1+o(1)) \\zeta_I(1+\\frac{1+it}{\\log R})^{-k}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(\\prod_{p \\in I} (1 - \\frac{f(p)}{p^{1+\\frac{1+it_1}{\\log R}}} - \\frac{f(p)}{p^{1+\\frac{1+it_2}{\\log R}}} + \\frac{f(p)}{p^{1+\\frac{1+it_1+1+it_2}{\\log R}}} ))")]]

#align(center)[#tao-fit-display[#mitex("= (1+o(1)) \\zeta_I(1+\\frac{1+it_1}{\\log R})^{-k} \\zeta_I(1+\\frac{1+it_2}{\\log R})^{-k}")]]

#align(center)[#tao-fit-display[#mitex("\\zeta_I(1-\\frac{1+it_1+1+it_2}{\\log R})^{k}")]]

#text("where ")#mi("{\\zeta_I}")#text(" is the restricted Euler product")

#align(center)[#tao-fit-display[#mitex("\\zeta_I(s) := \\prod_{p \\in I} (1-\\frac{1}{p^s})^{-1},")]]

#text("which is well-defined for ")#mi("{\\text{Re}(s)>1}")#text(" at least (and this is the only region of ")#mi("{s}")#text(" for which we will need ")#mi("{\\zeta_I}")#text(").")

#text("We now specialise to the model case ")#mi("{I = (w,+\\infty)}")#text(", in which case")

#align(center)[#tao-fit-display[#mitex("\\zeta_I(s) = \\zeta(s) \\prod_{p \\leq w} (1 - \\frac{1}{p^s})")]]

#text("where ")#mi("{\\zeta(s) = \\sum_{n=1}^\\infty \\frac{1}{n^s}}")#text(" is the Riemann zeta function. Using the basic (and easily proven) asymptotic ")#mi("{\\zeta(s) = \\frac{1}{s-1} + O(1)}")#text(" for ")#mi("{s}")#text(" near ")#mi("{1}")

#align(center)[#tao-fit-display[#mitex("\\zeta_I(s) = (1+o(1)) \\frac{\\phi(W)}{W} \\frac{1}{s-1}")]]

#text("for ")#mi("{s = 1+O(1/\\sqrt{\\log R})}")#text(", if ")#mi("{w}")#text(" is sufficiently slowly growing (this can be seen by first working with a fixed large ")#mi("{W}")#text(" and then using Lemma ")#link(<tao-4356298b9e1872371c48>)[#text("7")]#text("). Note that because of the above truncation, we do not need any deeper bounds on ")#mi("{\\zeta}")#text(" than what one can obtain from the simple pole at ")#mi("{s=1}")#text("; in particular no zero-free regions near the line ")#mi("{\\{ 1+it: t \\in {\\bf R} \\}}")#text(" are needed here. (This is ultimately because of the smooth nature of ")#mi("{g}")#text(", which is sufficient for the applications in this post; if one wanted rougher cutoff functions here then the situation is closer to that of the prime number theorem, and non-trivial zero-free regions would be required.)")

#text("We conclude in the case ")#mi("{I = (w,+\\infty)}")#text(" that")

#tao-aligned(keep: true)[


#tao-math("S_{0,R,I}(f,g)  & = (\\frac{\\phi(W)}{W} \\log R)^k \\int_{\\left|t\\right| \\leq \\sqrt{\\log R}} (1+o(1)) (1+it)^{-k} \\hat g(t)\\ dt", block: true)



#tao-math(" & + O( \\log^{-A} R)", block: true)
]

#text("and")

#tao-aligned(keep: true)[


#tao-math("S_{1,R,I}(f,g)  & = (\\frac{\\phi(W)}{W} \\log R)^{-k} \\int_{\\left|t\\right| \\leq \\sqrt{\\log R}} (1+o(1)) (1+it)^k \\hat g(t)\\ dt", block: true)



#tao-math(" & + O( \\log^{-A} R)", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#tao-math("S_{2,R,I}(f,g_1,g_2) = (\\frac{\\phi(W)}{W} \\log R)^{-k} \\int_{\\left|t_1\\right|, \\left|t_2\\right| \\leq \\sqrt{\\log R}}", block: true)]]

#align(center)[#tao-fit-display[#mitex("(1+o(1)) (1+it_1)^k (1+it_2)^k (1+it_1+1+it_2)^{-k} \\hat g_1(t_1) \\hat g_2(t_2)\\ dt_1 dt_2")]]

#align(center)[#tao-fit-display[#mitex("+ O(\\log^{-A} R);")]]

#text("using the rapid decrease of ")#mi("{\\hat g, \\hat g_1, \\hat g_2}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("S_{0,R,I}(f,g) = (\\frac{\\phi(W)}{W} \\log R)^k (\\int_{\\bf R} (1+it)^{-k} \\hat g(t)\\ dt + o(1))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{1,R,I}(f,g) = (\\frac{\\phi(W)}{W} \\log R)^{-k} (\\int_{\\bf R} (1+it)^k \\hat g(t)\\ dt + o(1))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{2,R,I}(f,g_1,g_2) = (\\frac{\\phi(W)}{W} \\log R)^{-k} (\\int_{\\bf R} \\int_{\\bf R}")]]

#align(center)[#tao-fit-display[#mitex("(1+it_1)^k (1+it_2)^k (1+it_1+1+it_2)^{-k}")]]

#align(center)[#tao-fit-display[#mitex("\\hat g_1(t_1) \\hat g_2(t_2)\\ dt_1 dt_2 + o(1)).")]]

#text("We can rewrite these expressions in terms of ")#mi("{g}")#text(" instead of ")#mi("{\\hat g}")#text(". Using the Gamma function identity")

#align(center)[#tao-fit-display[#mitex("(1+it)^{-k} = \\int_0^\\infty e^{-x(1+it)} \\frac{x^{k-1}}{(k-1)!}\\ dx")]]

#text("and ")#link(<tao-5312fb609f60384731fc>)[#text("(7)")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (1+it)^{-k} \\hat g(t)\\ dt = \\int_0^\\infty g(x) \\frac{x^{k-1}}{(k-1)!}\\ dx")]]

#text("whilst from differentiating ")#link(<tao-5312fb609f60384731fc>)[#text("(7)")]#text(" ")#mi("{k}")#text(" times at the origin (after first dividing by ")#mi("{e^x}")#text(") we see that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} (1+it)^k \\hat g(t)\\ dt = (-1)^k g^{(k)}(0).")]]

#text("Combining these two methods, we also see that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{\\bf R} (1+it_1)^k (1+it_2)^k (1+it_1+1+it_2)^{-k} \\hat g_1(t_1) \\hat g_1(t_2)\\ dt_1 dt_2")]]

#align(center)[#tao-fit-display[#mitex("= \\int_0^\\infty g^{(k)}_1(x) g^{(k)}_2(x) \\frac{x^{k-1}}{(k-1)!}\\ dx.")]]

#text("We have thus obtained the following asymptotics:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10 (Asymptotics without prime truncation)")]#text(" ")#metadata(none) <tao-5009a047a11fbd680bb4>#text(" Suppose that ")#mi("{I = (w,+\\infty)}")#text(", and that ")#mi("{f}")#text(" has dimension ")#mi("{k}")#text(" for some fixed natural number ")#mi("{k}")#text(". Then we have")

#align(center)[#tao-fit-display[#mitex("S_{0,R,I}(f,g) = (\\frac{\\phi(W)}{W} \\log R)^k (\\int_0^\\infty g(x) \\frac{x^{k-1}}{(k-1)!}\\ dx + o(1))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{1,R,I}(f,g) = (\\frac{\\phi(W)}{W} \\log R)^{-k} ((-1)^k g^{(k)}(0) + o(1))")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("S_{2,R,I}(f,g) = (\\frac{\\phi(W)}{W} \\log R)^{-k}")]]

#align(center)[#tao-fit-display[#mitex("(\\int_0^\\infty g^{(k)}_1(x) g^{(k)}_2(x) \\frac{x^{k-1}}{(k-1)!}\\ dx + o(1)).")]]
]

#text("These asymptotics will suffice for the treatment of the Goldston-Pintz-Yildirim theorem (Theorem ")#link(<tao-017477be6610750917d7>)[#text("4")]#text("). For the Motohashi-Pintz-Zhang theorem (Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(") we will also need to deal with truncated intervals ")#mi("{I}")#text(", such as ")#mi("{(w,x^{1/\\varpi})}")#text("; we will discuss how to deal with these truncations later.")

#heading(level: 1)[#strong[#text(" — 3. The Goldston-Yildirim-Pintz theorem — ")]]

#text("We are now ready to state and prove the Goldston-Yildirim-Pintz theorem. We first need to state the Elliott-Halberstam conjecture properly.")

#text("Let ")#mi("{\\Lambda: {\\bf N} \\rightarrow {\\bf R}}")#text(" be the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", thus ")#mi("{\\Lambda(n)}")#text(" equals ")#mi("{\\log p}")#text(" when ")#mi("{n}")#text(" is equal to a prime ")#mi("{p}")#text(" or a power of that prime, and equal to zero otherwise. The prime number theorem in arithmetic progressions tells us that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n < x: n = a \\text{ mod } q} \\Lambda(n) = (1 + o(1)) \\frac{x}{\\phi(q)}")]]

#text("for any fixed arithmetic progression ")#mi("{a \\text{ mod } q}")#text(" with ")#mi("{a}")#text(" coprime to ")#mi("{q}")#text(". In particular,")

#align(center)[#tao-fit-display[#tao-math("\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{n < x: n = a \\text{ mod } q} \\Lambda(n) - \\frac{1}{\\phi(q)} \\sum_{n < x} \\Lambda(n)\\right| = o( \\frac{x}{\\phi(q)} )", block: true)]]

#text("where ")#mi("{({\\bf Z}/q{\\bf Z})^\\times}")#text(" are the residue classes mod ")#mi("{q}")#text(" that are coprime to ")#mi("{q}")#text(". By invoking the ")#link("http://en.wikipedia.org/wiki/Siegel–Walfisz_theorem")[#text("Siegel-Walfisz theorem")]#text(" one can obtain the improvement")

#align(center)[#tao-fit-display[#tao-math("\\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{n < x: n = a \\text{ mod } q} \\Lambda(n) - \\frac{1}{\\phi(q)} \\sum_{n < x} \\Lambda(n)\\right| = O( \\frac{x}{\\phi(q) \\log^A x} )", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(" (though, annoyingly, the implied constant here is only ineffectively bounded with current methods; see ")#link("https://terrytao.wordpress.com/2009/09/24/the-prime-number-theorem-in-arithmetic-progressions-and-dueling-conspiracies/")[#text("this previous post")]#text(" for further discussion).")

#text("The above error term is only useful when ")#mi("{q}")#text(" is fixed (or is of logarithmic size in ")#mi("{x}")#text("). For larger values of ")#mi("{q}")#text(", it is very difficult to get good error terms for each ")#mi("{q}")#text(" separately, unless one assumes powerful hypotheses such as the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("generalised Riemann hypothesis")]#text(". However, it is possible to obtain good control on the error term if one ")#emph[#text("averages")]#text(" in ")#mi("{q}")#text(". More precisely, for any ")#mi("{0 < \\theta < 1}")#text(", let ")#mi("{EH[\\theta]}")#text(" denote the following assertion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 11")]#text(" (")#mi("{EH[\\theta]}")#text(") One has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{1 \\leq q \\leq x^\\theta} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{n < x: n = a \\text{ mod } q} \\Lambda(n) - \\frac{1}{\\phi(q)} \\sum_{n < x} \\Lambda(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("= O( \\frac{x}{\\log^A x} )")]]

#text("for all fixed ")#mi("{A>0}")#text(".")
]

#text("This should be compared with the asymptotic ")#mi("{\\sum_{1 \\leq q \\leq x^\\theta} \\frac{x}{\\phi(q)} = (C+o(1)) x \\log x^\\theta}")#text(" for some absolute constant ")#mi("{C>0}")#text(", as can be deduced for instance from Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(". The ")#link("http://en.wikipedia.org/wiki/Elliott-Halberstam_conjecture")[#text("Elliott-Halberstam conjecture")]#text(" is the assertion that ")#mi("{EH[\\theta]}")#text(" holds for all ")#mi("{0 < \\theta < 1}")#text(". This remains open, but the important ")#link("http://en.wikipedia.org/wiki/Bombieri–Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(" establishes ")#mi("{EH[\\theta]}")#text(" for all ")#mi("{0 < \\theta < 1/2}")#text(". Remarkably, the threshold ")#mi("{1/2}")#text(" is also the limit of what one can establish if one directly invokes the generalised Riemann hypothesis, so the Bombieri-Vinogradov theorem is often referred to as an assertion that the generalised Riemann hypothesis (or at least the Siegel-Walfisz theorem) holds “on the average”, which is often good enough for sieve-theoretic purposes.")

#text("We may replace the von Mangoldt function ")#mi("{\\Lambda(n)}")#text(" with the slight variant ")#mi("{\\theta(n)}")#text(", defined to equal ")#mi("{\\log p}")#text(" when ")#mi("{n}")#text(" is a prime ")#mi("{p}")#text(" and zero otherwise. Using this replacement, as well as the prime number theorem (with")#mi("{O(x / \\log^A x)}")#text(" error term), it is not difficult to show that ")#mi("{EH[\\theta]}")#text(" is equivalent to the estimate ")#metadata(none) <tao-7d7e0862cc44a052ac56>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\sum_{1 \\leq q \\leq x^\\theta} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{n < x: n = a \\text{ mod } q} \\theta(n) - \\frac{x}{\\phi(q)}\\right| = O( \\frac{x}{\\log^A x} ).", block: true)]]





#text("Now we establish Theorem ")#link(<tao-017477be6610750917d7>)[#text("4")]#text(". Suppose that ")#mi("{EH[\\theta]}")#text(" holds for some fixed ")#mi("{1/2 <\\theta < 1}")#text(", let ")#mi("{k_0}")#text(" be sufficiently large depending on ")#mi("{\\theta}")#text(" but otherwise fixed, and let ")#mi("{{\\mathcal H}}")#text(" be a fixed admissible ")#mi("{k_0}")#text("-tuple. We would like to show that there are infinitely many ")#mi("{n}")#text(" such that ")#mi("{n + {\\mathcal H}}")#text(" contains at least two primes. We will begin with the ")#mi("{W}")#text("-trick, restricting ")#mi("{n}")#text(" to a residue class ")#mi("{b \\text{ mod } W}")#text(" with ")#mi("{b \\in C(W)}")#text(" (note that ")#mi("{C(W)}")#text(" is non-empty because ")#mi("{{\\mathcal H}}")#text(" is admissible).")

#text("The general strategy will be as follows. We will introduce a ")#emph[#text("weight function")]#text(" ")#mi("{\\nu: {\\bf Z} \\rightarrow {\\bf R}^+}")#text(" that obeys the upper bound ")#metadata(none) <tao-e8bc163c82eee1873328>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W} \\nu(n) \\leq (\\alpha+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{x}{W \\log^{k_0} R}")]]



#text(" and lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W} \\theta(n+h) \\nu(n)")]]

#metadata(none) <tao-ad328846aa18b32a3358>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\geq (\\beta-o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{x}{W \\log^{k_0-1} R}")]]



#text(" for all ")#mi("{h \\in {\\mathcal H}}")#text(" and some fixed ")#mi("{\\alpha,\\beta > 0}")#text(", where ")#mi("{R}")#text(" is a fixed power of ")#mi("{x}")#text(" (we will eventually take ")#mi("{R = x^{\\theta/2}}")#text("). (The factors of ")#mi("{W, \\phi(W)}")#text(", ")#mi("{x}")#text(", and ")#mi("{\\log R}")#text(" on the right-hand side are natural normalisations coming from sieve theory and the reader should not pay too much attention to them.) Informally, ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(" says that ")#mi("{\\nu}")#text(" has some normalised density at most ")#mi("{\\alpha}")#text(", and then ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" roughly speaking asserts that relative to the weight ")#mi("{\\nu}")#text(", ")#mi("{n+h}")#text(" has a probability of at least ")#mi("{\\beta/\\alpha -o(1)}")#text(" of being prime. If we sum ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" for all ")#mi("{h \\in H}")#text(" and then subtract off ")#mi("{\\log 3x}")#text(" copies of ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W} (\\sum_{h \\in {\\mathcal H}} \\theta(n+h) - \\log 3x) \\nu(n)")]]

#align(center)[#tao-fit-display[#mitex("\\geq (k_0\\beta - \\alpha \\frac{\\log x}{\\log R}-o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\frac{x}{W \\log^{k_0-1} R}.")]]

#text("In particular, if we have the crucial inequality ")#metadata(none) <tao-6e226a9abab47f9e81f8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("k_0 \\beta > \\alpha \\frac{\\log x}{\\log R}")]]



#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W} (\\sum_{h \\in {\\mathcal H}} \\theta(n+h) - \\log 3x) \\nu(n) \\gg \\frac{x}{W \\log^{k_0-1} x}")]]

#text("and so ")#mi("{\\sum_{h \\in {\\mathcal H}} \\theta(n+h) - \\log 3x}")#text(" is positive for at least one value of ")#mi("{n}")#text(" between ")#mi("{x}")#text(" and ")#mi("{2x}")#text(". This can only occur if ")#mi("{n+{\\mathcal H}}")#text(" contains two or more primes. Thus we must have ")#mi("{n+{\\mathcal H}}")#text(" containing at least two primes for some ")#mi("{n}")#text(" between ")#mi("{x}")#text(" and ")#mi("{2x}")#text("; sending ")#mi("{x}")#text(" off to infinity then gives ")#mi("{DHL[k_0,2]}")#text(" as desired.")

#text("It thus suffices to find a weight function ")#mi("{\\nu}")#text(" obeying the required properties ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" with parameters ")#mi("{\\alpha,\\beta,R}")#text(" obeying the key inequality ")#link(<tao-6e226a9abab47f9e81f8>)[#text("(11)")]#text(". It is thus of interest to make ")#mi("{R}")#text(" as large a power of ")#mi("{x}")#text(" as possible, and to minimise the ratio between ")#mi("{\\alpha}")#text(" and ")#mi("{\\beta}")#text(". It is in the former task that the Elliott-Halberstam hypothesis will be crucial.")

#text("The key is to find a good choice of ")#mi("{\\nu}")#text(", and the selection of this weight is arguably the main contribution of Goldston, Pintz, and Yildirim, who use a carefully modified version of the ")#link("http://en.wikipedia.org/wiki/Selberg_sieve")[#text("Selberg sieve")]#text(". Following (a slight modification of) the Goldston-Pintz-Yildirim argument, we will take a weight of the form ")#mi("{\\nu(n) = \\lambda(n)^2}")#text(", where ")#metadata(none) <tao-7f1b55b860590406f84f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\lambda(n) := \\sum_{d \\in {\\mathcal S}_I: d|P(n)} \\mu(d) g( \\frac{\\log d}{\\log R} )")]]



#text(" where ")#mi("{g: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a fixed smooth non-negative function supported on ")#mi("{[-1,1]}")#text(" to be chosen later, ")#mi("{I := (w,+\\infty)}")#text(", and ")#mi("{P(n)}")#text(" is the polynomial")

#align(center)[#tao-fit-display[#mitex("P(n) := \\prod_{h \\in {\\mathcal H}} (n+h).")]]

#text("The intuition here is that ")#mi("{\\lambda}")#text(" is a truncated approximation to a function of the form")

#align(center)[#tao-fit-display[#mitex("\\lambda_a(n) := \\sum_{d \\in {\\mathcal S}_I: d|P(n)} \\mu(d) \\log^a \\frac{P(n)}{d}")]]

#text("for some natural number ")#mi("{a}")#text(", which one can check is only non-vanishing when ")#mi("{P(n)}")#text(" has at most ")#mi("{a}")#text(" distinct prime factors in ")#mi("{I}")#text(". So ")#mi("{\\nu(n)}")#text(" is concentrated on those numbers ")#mi("{n}")#text(" for which ")#mi("{n+h}")#text(" already has few prime factors for ")#mi("{h \\in {\\mathcal H}}")#text(", which will assist in making the ratio ")#mi("{\\alpha/\\beta}")#text(" as small as possible.")

#text("Clearly ")#mi("{\\nu}")#text(" is non-negative. Now we consider the task of estimating the left-hand side of ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(". Expanding out ")#mi("{\\nu = \\lambda^2}")#text(" using ")#link(<tao-7f1b55b860590406f84f>)[#text("(12)")]#text(" and interchanging summations, we can expand this expression as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) \\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W: d_1,d_2 | P(n)} 1.")]]

#text("The constraint ")#mi("{d_1,d_2 | P(n)}")#text(" is equivalent to requiring that for each prime ")#mi("{p}")#text(" dividing ")#mi("{[d_1,d_2]}")#text(", ")#mi("{n}")#text(" lies in one of the residue classes ")#mi("{-h_i \\text{ mod } p}")#text(" for ")#mi("{i=1,\\ldots,k_0}")#text(". By choice of ")#mi("{I}")#text(", ")#mi("{p > w}")#text(", so all the ")#mi("{h_i}")#text(" are distinct, and so we are constraining ")#mi("{n}")#text(" to lie in one of ")#mi("{k_0}")#text(" residue classes modulo ")#mi("{p}")#text(" for each ")#mi("{p|[d_1,d_2]}")#text("; together with the constraint ")#mi("{n = b \\text{ mod } W}")#text(" and the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese remainder theorem")]#text(", we are thus constraining ")#mi("{n}")#text(" to ")#mi("{k_0^{\\Omega([d_1,d_2])}}")#text(" residue classes modulo ")#mi("{W [d_1,d_2]}")#text(", where ")#mi("{\\Omega([d_1,d_2])}")#text(" is the number of prime factors of ")#mi("{[d_1,d_2]}")#text(". We thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W: d_1,d_2 | P(n)} 1 = k_0^{\\Omega([d_1,d_2])} \\frac{x}{W[d_1,d_2]} + O( k_0^{\\Omega([d_1,d_2])} ).")]]

#text("Note from the support of ")#mi("{g}")#text(" that ")#mi("{d_1,d_2}")#text(" may be constrained to be at most ")#mi("{R}")#text(", so that ")#mi("{d_1d_2}")#text(" is at most ")#mi("{R^2}")#text(". We can thus express the left-hand side of ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(" as the main term")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) k_0^{\\Omega([d_1,d_2])} \\frac{x}{W[d_1,d_2]}")]]

#text("plus an error")

#align(center)[#tao-fit-display[#mitex("O( R^2 \\sum_{d_1,d_2 \\in {\\mathcal S}_I} g(\\frac{\\log d_1}{\\log R}) g(\\frac{\\log d_2}{\\log R}) \\frac{k_0^{\\Omega(d_1)} k_0^{\\Omega(d_2)} }{d_1 d_2} ).")]]

#text("By Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(", the error term is ")#mi("{O( R^2 \\log^{2k_0} R )}")#text(". So if we set")

#align(center)[#tao-fit-display[#mitex("R := x^{\\theta/2}")]]

#text("then the error term will certainly give a negligible contribution to ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(" with plenty of room to spare. (But when we come to the more difficult sum ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(", we will have much less room – only a superlogarithmic amount of room, in fact.) To show ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1,d_2]}")]]

#align(center)[#tao-fit-display[#mitex("\\leq (\\alpha+o(1)) (\\frac{W}{\\phi(W)})^{k_0} \\log^{-k_0} R.")]]

#text("But by Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(" (applied to the ")#mi("{k_0}")#text("-dimensional multiplicative function ")#mi("{k_0^{\\Omega([d_1,d_2])}}")#text(") and the support of ")#mi("{g}")#text(", this bound holds with ")#mi("{\\alpha}")#text(" equal to the quantity")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\int_0^1 g^{(k_0)}(x)^2 \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx.")]]

#text("Now we turn to ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(". Fix ")#mi("{h \\in {\\mathcal H}}")#text(". Repeating the arguments for ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(", we may expand the left-hand side of ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R})")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W: d_1,d_2 | P(n)} \\theta(n+h).")]]

#text("Now we consider the inner sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W: d_1,d_2 | P(n)} \\theta(n+h).")]]

#text("As discussed earlier, the conditions ")#mi("{n=b \\text{ mod } W}")#text(" and ")#mi("{d_1,d_2 | P(n)}")#text(" split into ")#mi("{k_0^{\\Omega([d_1,d_2])}}")#text(" residue classes ")#mi("{n = a \\text{ mod } W [d_1,d_2]}")#text(". However, if ")#mi("{n = -h \\text{ mod } p}")#text(" for one of the primes ")#mi("{p}")#text(" dividing ")#mi("{[d_1,d_2]}")#text(", then ")#mi("{\\theta(n+h)}")#text(" must vanish (since ")#mi("{R = x^\\theta}")#text(" is much less than ")#mi("{n+h}")#text("). So there are actually only ")#mi("{(k_0-1)^{\\Omega([d_1,d_2])}}")#text(" residue classes ")#mi("{a \\text{ mod } W[d_1,d_2]}")#text(" for which ")#mi("{a+h}")#text(" is coprime to ")#mi("{W[d_1,d_2]}")#text(". We thus have")

#tao-aligned(keep: true)[


#tao-math("\\sum_{x \\leq n \\leq 2x: n = a \\text{ mod } W[d_1,d_2]} \\theta(n+h)  & = (k_0-1)^{\\Omega([d_1,d_2])} \\frac{x}{\\phi(W[d_1,d_2])}", block: true)



#tao-math(" & + O( (k_0-1)^{\\Omega([d_1,d_2])} E(x; W[d_1,d_2]) )", block: true)
]

#text("where ")#mi("{E(x;q)}")#text(" denotes the quantity ")#metadata(none) <tao-d711ad6b6f95b90b5220>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("E(x;q) := \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\sum_{x \\leq n \\leq 2x: n = a \\text{ mod } q} \\theta(n) - \\frac{x}{\\phi(q)}\\right|.", block: true)]]





#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" There is an inefficiency here; the supremum in ")#link(<tao-d711ad6b6f95b90b5220>)[#text("(13)")]#text(" is over ")#emph[#text("all")]#text(" primitive residue classes ")#mi("{a \\text{ mod } q}")#text(", but actually one only needs to take the supremum over the ")#mi("{(k_0-1)^{\\Omega(q)}}")#text(" residue classes ")#mi("{a \\text{ mod } q}")#text(" for which ")#mi("{P_h(a) = 0 \\text{ mod } q}")#text(", where ")#mi("{P_h(a) := \\prod_{h^{\\prime} \\in {\\mathcal H}:h^{\\prime} \\neq h} (a+h^{\\prime}-h)}")#text(". This inefficiency is not exploitable if we insist on using the Elliott-Halberstam conjecture as the starting hypothesis, but will be used in the arguments of the next section in which a more lightweight hypothesis is utilised.")
]

#text("The left-hand side of ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" is thus equal to the main term")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) (k_0-1)^{\\Omega([d_1,d_2])} \\frac{x}{\\phi(W[d_1,d_2])}")]]

#text("plus an error term")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{d_1,d_2 \\in {\\mathcal S}_I} g(\\frac{\\log d_1}{\\log R}) g(\\frac{\\log d_2}{\\log R}) (k_0-1)^{\\Omega([d_1,d_2])} E(x; W[d_1,d_2]) ).")]]

#text("We first deal with the error term. Since ")#mi("{[d_1,d_2]}")#text(" is in ")#mi("{{\\mathcal S}_I}")#text(" and is bounded by ")#mi("{R^2}")#text(" on the support of this function, and each ")#mi("{d \\in {\\mathcal S}_I}")#text(" has ")#mi("{3^{\\Omega(d)}}")#text(" representations of the form ")#mi("{d = [d_1,d_2]}")#text(", we can bound this expression by")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{d \\in {\\mathcal S}_I: d \\leq R^2} 3^{\\Omega(d)} (k_0-1)^{\\Omega(d)} E(x;Wd) ).")]]

#text("Note that we are assuming ")#mi("{g}")#text(" to be a fixed smooth compactly supported function and so it has magnitude ")#mi("{O(1)}")#text(". On the other hand, from Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(" and the trivial bound ")#mi("{E(x;Wd) = O( \\frac{x \\log x}{Wd} + \\frac{x}{\\phi(W) \\phi(d)} )}")#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I: d \\leq R^2} 3^{2\\Omega(d)} (k_0-1)^{2\\Omega(d)} E(x;Wd) = O( x \\log^{O(1)} x )")]]

#text("while from ")#link(<tao-7d7e0862cc44a052ac56>)[#text("(8)")]#text(" (and here we crucially use the choice ")#mi("{R = x^{\\theta/2}}")#text(" of ")#mi("{R}")#text(") one easily verifies that")

#align(center)[#tao-fit-display[#mitex("\\sum_{d \\in {\\mathcal S}_I: d \\leq R^2} E(x;Wd) = O( x \\log^{-A} x )")]]

#text("for any fixed ")#mi("{A}")#text(". By the Cauchy-Schwarz inequality we see that the error term to ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" is negligible (assuming ")#mi("{w}")#text(" sufficiently slowly growing of course). Meanwhile, the main term can be rewritten as")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{\\phi(W)} \\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) \\frac{f([d_1,d_2])}{[d_1,d_2]}")]]

#text("where ")#mi("{f}")#text(" is the ")#mi("{k_0-1}")#text("-dimensional multiplicative function")

#align(center)[#tao-fit-display[#mitex("f(d) := \\prod_{p|d} (k_0-1) \\frac{p}{p-1}.")]]

#text("Applying Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(", we obtain ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("\\beta = \\int_0^1 g^{(k_0-1)}(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt.")]]

#text("To obtain the crucial inequality ")#link(<tao-6e226a9abab47f9e81f8>)[#text("(11)")]#text(", we thus need to locate a fixed smooth non-negative function supported on ")#mi("{[-1,1]}")#text(" obeying the inequality ")#metadata(none) <tao-2ad81149147ce72b6732>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("k_0 \\int_0^1 g^{(k_0-1)}(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt > \\frac{2}{\\theta} \\int_0^1 g^{(k_0)}(t)^2 \\frac{t^{k_0-1}}{(k_0-1)!}\\ dt .")]]



#text(" In principle one can use calculus of variations to optimise the choice of ")#mi("{g}")#text(" here (it will be the ground state of a certain one-dimensional Schrödinger operator), but one can already get a fairly good result here by a specific choice of ")#mi("{g}")#text(" that is amenable for computations, namely a polynomial of the form ")#mi("{g(t) := \\frac{1}{(k_0+l_0)!} (1-t)^{k_0+l_0}}")#text(" for ")#mi("{t \\in [0,1]}")#text(" and some integer ")#mi("{l_0>0}")#text(", with ")#mi("{g}")#text(" vanishing for ")#mi("{t>1}")#text(" and smoothly truncated to ")#mi("{[-1,1]}")#text(" somehow at negative values of ")#mi("{t}")#text(". Strictly speaking, this ")#mi("{g}")#text(" is not admissible here because it is not infinitely smooth at ")#mi("{1}")#text(", being only ")#mi("{k_0+l_0-1}")#text(" times continuously differentiable instead, but one can regularise this function to be smooth without significantly affecting either side of ")#link(<tao-2ad81149147ce72b6732>)[#text("(14)")]#text(", so we will go ahead and test ")#link(<tao-2ad81149147ce72b6732>)[#text("(14)")]#text(" with this function and leave the regularisation details to the reader. The inequality then becomes (after cancelling some factors)")

#align(center)[#tao-fit-display[#mitex("k_0 \\int_0^1 (1-t)^{2l_0+2} \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt > \\frac{2}{\\theta} \\int_0^1 (l_0+1)^2 (1-t)^{2l_0} \\frac{t^{k_0-1}}{(k_0-1)!}\\ dt .")]]

#text("Using the ")#link("https://en.wikipedia.org/wiki/Beta_function")[#text("Beta function")]#text(" identity")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 (1-t)^a t^b\\ dt = \\frac{a! b!}{(a+b+1)!}")]]

#text("we have ")#metadata(none) <tao-658e28f06315a42fc360>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\alpha = \\frac{(2l_0)!}{(l_0!)^2 (k_0+2l_0)!}")]]



#text(" and ")#metadata(none) <tao-6aea43f12a7bea73486f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\beta = \\frac{(2l_0+2)!}{((l_0+1)!)^2 (k_0+2l_0+1)!}")]]



#text(" and the preceding equation now becomes")

#align(center)[#tao-fit-display[#mitex("k_0 \\frac{(2l_0+2)!}{(2l_0+k_0+1)!} > \\frac{2}{\\theta} (l_0+1)^2 \\frac{(2l_0)!}{(2l_0+k_0)!}")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("2\\theta > (1 + \\frac{1}{2l_0+1}) (1 + \\frac{2l_0+1}{k_0}).")]]

#text("Actually, the same inequality is also applicable when ")#mi("{l_0}")#text(" is real instead of integer, using ")#link("https://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma functions")]#text(" in place of factorials; we leave the details to the interested reader. We can then optimise in ")#mi("{l_0}")#text(" by setting ")#mi("{2l_0+1 = \\sqrt{k_0}}")#text(", arriving at the inequality")

#align(center)[#tao-fit-display[#mitex("2\\theta > (1 + \\frac{1}{\\sqrt{k_0}})^2.")]]

#text("But as long as ")#mi("{\\theta > 1/2}")#text(", this inequality is satisfiable for any ")#mi("{k_0}")#text(" larger than ")#mi("{(\\sqrt{2\\theta}-1)^{-2}}")#text(". This concludes the proof of Theorem ")#link(<tao-017477be6610750917d7>)[#text("4")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" One can obtain slightly better dependencies of ")#mi("{k_0}")#text(" in terms of ")#mi("{\\theta}")#text(" by using more general functions for ")#mi("{g}")#text(" than the monomials ")#mi("{\\frac{1}{(k_0+l_0)!} (1-x)^{k_0+l_0}}")#text(", for instance one can take linear combinations of such functions. See the ")#link("http://www.ams.org/mathscinet-getitem?mr=2552109")[#text("paper of Goldston, Pintz, and Yildirim")]#text(" for details. Unfortunately, as noted in ")#link("http://arxiv.org/abs/math/0605696")[#text("this survey of Soundararajan")]#text(", one has the general inequality ")#metadata(none) <tao-63f75c890b05405e6e1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("k_0 \\int_0^1 g^{(k_0-1)}(t)^2 \\frac{t^{k_0-2}}{(k_0-2)!}\\ dt \\leq 4 \\int_0^1 g^{(k_0)}(t)^2 \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx")]]



#text(" which defeats any attempt to directly use this method using only the Bombieri-Vinogradov result that ")#mi("{EH[\\theta]}")#text(" holds for all ")#mi("{\\theta < 1/2}")#text(". We show ")#link(<tao-63f75c890b05405e6e1f>)[#text("(17)")]#text(" in the case when ")#mi("{k_0}")#text(" is large. Write ")#mi("{f(t) := g^{(k_0-1)}(t) t^{k_0/2-1}}")#text(", then ")#link(<tao-63f75c890b05405e6e1f>)[#text("(17)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("\\frac{k_0 (k_0-1)}{4} \\int_0^1 f(t)^2\\ dt \\leq \\int_0^1 (f^{\\prime}(t) - (k_0/2-1) t^{-1} f(t))^2 t\\ dt.")]]

#text("The right-hand side simplifies after some integration by parts to")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 f^{\\prime}(t)^2 t + \\frac{(k_0-2)^2}{4} f(t)^2 t^{-1}\\ dt.")]]

#text("Subtracting off ")#mi("{\\int_0^1 \\frac{(k_0-2)^2}{4} f(t)^2\\ dt}")#text(" from both sides, one is left with")

#align(center)[#tao-fit-display[#mitex("\\frac{3k_0-4}{4} \\int_0^1 f(t)^2 \\leq \\int_0^1 f^{\\prime}(t)^2 t + \\frac{(k_0-2)^2}{4} f(t)^2 (t^{-1} - 1)\\ dx.")]]

#text("From the fundamental theorem of calculus and Cauchy-Schwarz, one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(y)\\right|^2 \\leq (\\int_0^1 f^{\\prime}(y)^2 y\\ dy) (\\log(1/y)).", block: true)]]

#text("Using this bound for ")#mi("{y}")#text(" close to ")#mi("{1}")#text(" and dominating ")#mi("{\\frac{3k_0-4}{4}}")#text(" by ")#mi("{\\frac{(k_0-2)^2}{4} (y^{-1} - 1)}")#text(" for ")#mi("{y}")#text(" far from ")#mi("{1}")#text(", we obtain the claim (at least if ")#mi("{k_0}")#text(" is large enough). There is some slack in this argument; it would be of interest to calculate exactly what the best constants are in ")#link(<tao-63f75c890b05405e6e1f>)[#text("(17)")]#text(", so that one can obtain the optimal relationship between ")#mi("{\\theta}")#text(" and ")#mi("{k_0}")#text(".")

#text("To get around this obstruction ")#link(<tao-63f75c890b05405e6e1f>)[#text("(17)")]#text(" in the unconditional setting when one only has ")#mi("{EH[\\theta]}")#text(" for ")#mi("{\\theta<1/2}")#text(", Goldston, Pintz, and Yildirim also considered sums of the form ")#mi("{\\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W} \\theta(n+h) \\nu(n)}")#text(" in which ")#mi("{h}")#text(" was now outside (but close to) ")#mi("{{\\mathcal H}}")#text(". While the bounds here were significantly inferior to those in ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(", they were still sufficient to prove a variant of the inequality ")#link(<tao-6e226a9abab47f9e81f8>)[#text("(11)")]#text(" to get reasonably small gaps between primes.")
]

#heading(level: 1)[#strong[#text(" — 4. The Motohashi-Pintz-Zhang theorem — ")]]

#text("We now modify the above argument to give Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(". Our treatment here is different from that of Zhang in that it employs the method of Buchstab iteration; a related argument also appears in the paper of Motohashi and Pintz. This arrangement of the argument leads to a more efficient dependence of ")#mi("{k_0}")#text(" on ")#mi("{\\varpi}")#text(" than in the paper of Zhang. (The argument of Motohashi and Pintz is a bit more complicated and uses a slightly different formulation of the base conjecture ")#mi("{MPZ[\\varpi]}")#text(", but the final bounds are similar to those given here, albeit with non-explicit constants in the ")#mi("{O()}")#text(" notation.)")

#text("The main idea here is to truncate the interval ")#mi("{I}")#text(" of relevant primes from ")#mi("{(w,\\infty)}")#text(" to ")#mi("{(w,x^\\varpi)}")#text(" for some small ")#mi("{\\varpi}")#text(". Somewhat remarkably, it turns out that this apparently severe truncation does not affect the sums ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" here as long as ")#mi("{k_0 \\varpi}")#text(" is large (which is going to be the case in practice, with ")#mi("{k_0}")#text(" being comparable to ")#mi("{\\varpi^{-2}}")#text("). The intuition is that ")#mi("{\\nu}")#text(" was already concentrated on those ")#mi("{n}")#text(" for which ")#mi("{P(n)}")#text(" had about ")#mi("{O(k_0)}")#text(" factors, and it is too “expensive” for one of these factors to as large as ")#mi("{x^\\varpi}")#text(" or more, as it forces many of the other factors to be smaller than they “want” to be. The advantage of truncating the set of primes this way is that the version of the Elliott-Halberstam conjecture needed also acquires the same truncation, which gives that version a certain “well-factored” form (in the spirit of the work of Bombieri, Fouvry, Friedlander, and Iwaniec) which is essential in being able to establish that conjecture unconditionally for some suitably small ")#mi("{\\varpi}")#text(".")

#text("To make this more precise, we first formalise the conjecture ")#mi("{MPZ[\\varpi]}")#text(" for ")#mi("{0 < \\varpi < 1/4}")#text(" mentioned earlier.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 12")]#text(" (")#mi("{MPZ[\\varpi]}")#text(") Let ")#mi("{{\\mathcal H}}")#text(" be a fixed ")#mi("{k}")#text("-tuple (not necessarily admissible) for some fixed ")#mi("{k \\geq 2}")#text(", and let ")#mi("{b \\text{ mod } W}")#text(" be a primitive residue class. Then")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times: P(a) = 0 \\text{ mod } q} \\left|\\Delta_{b,W}(\\theta; q,a)\\right| = O( x \\log^{-A} x)", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{I = (w,x^{\\varpi})}")#text(" and ")#mi("{\\Delta_{b,W}(\\theta;q,a)}")#text(" is the quantity ")#metadata(none) <tao-c1a421182e1fb908168f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\Delta_{b,W}(\\theta;q,a) := | \\sum_{x \\leq n \\leq 2x: n=b \\text{ mod } W; n = a \\text{ mod } q} \\theta(n)")]]





#align(center)[#tao-fit-display[#mitex("- \\frac{1}{\\phi(q)} \\sum_{x \\leq n \\leq 2x: n = b \\text{ mod } W} \\theta(n)|.")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("P(a) := \\prod_{h \\in {\\mathcal H}} (a+h).")]]
]

#text("This is the ")#mi("{W}")#text("-tricked formulation of the conjecture as (implicitly) stated in Zhang’s paper, which did not have the restriction ")#mi("{n = b \\text{ mod } W}")#text(" present (and with the interval ")#mi("{I}")#text(" enlarged from ")#mi("{(w,x^\\varpi)}")#text(" to ")#mi("{(1,x^\\varpi)}")#text(", and ")#mi("{{\\mathcal H} \\cup \\{0\\}}")#text(" was required to be admissible). However the two formulations are morally equivalent (and Zhang’s arguments establish Theorem ")#link(<tao-01aae5bc4882bc2e94f1>)[#text("6")]#text(" with ")#mi("{MPZ[\\varpi]}")#text(" as stated). From the prime number theorem in arithmetic progressions (with ")#mi("{O( x \\log^{-A} x)}")#text(" error term) together with Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(" we observe that we may replace ")#link(<tao-c1a421182e1fb908168f>)[#text("(18)")]#text(" here by the slight variant ")#metadata(none) <tao-9294ab38039f60d2ec53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\Delta^{\\prime}_{b,W}(\\theta;q,a) := | \\sum_{x \\leq n \\leq 2x: n=b \\text{ mod } W; n = a \\text{ mod } q} \\theta(n)")]]





#align(center)[#tao-fit-display[#mitex("- \\frac{1}{\\phi(Wq)} x|")]]

#text("without affecting the truth of ")#mi("{MPZ[\\varpi]}")#text(".")

#text("It is also not difficult to deduce ")#mi("{MPZ[\\varpi]}")#text(" from ")#mi("{EH[1/2 + 2 \\varpi]}")#text(" after using a Cauchy-Schwarz argument to dispose of the ")#mi("{k^{\\Omega(d)}}")#text(" residue classes ")#mi("{a}")#text(" in the above sum (cf. the treatment of the error term in ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" in the previous section); we leave the details to the interested reader. Note however that whilst ")#mi("{EH[1/2+2\\varpi]}")#text(" demands control over ")#emph[#text("all")]#text(" primitive residue classes ")#mi("{a}")#text(" in a given modulus ")#mi("{q}")#text(", the conjecture ")#mi("{MPZ[\\varpi]}")#text(" only requires control of a much smaller number of residue classes (roughly polylogarithmic in number, on average). Thus ")#mi("{MPZ[\\varpi]}")#text(" is simpler than ")#mi("{EH[1/2+2\\varpi]}")#text(", though it is still far from trivial.")

#text("We now begin the proof of Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(". Let ")#mi("{0 < \\varpi < 1/4}")#text(" be such that ")#mi("{MPZ[\\varpi]}")#text(" holds, and let ")#mi("{k_0}")#text(" be a sufficiently large quantity depending on ")#mi("{\\varpi}")#text(" but which is otherwise fixed. As before, it suffices to locate a non-negative sieve weight ")#mi("{\\nu}")#text(" that obeys the estimates ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(", ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" for parameters ")#mi("{\\alpha,\\beta,R}")#text(" that obey the key inequality ")#link(<tao-6e226a9abab47f9e81f8>)[#text("(11)")]#text(", and with ")#mi("{g}")#text(" smooth and supported on ")#mi("{[-1,1]}")#text(". The choice of weight ")#mi("{\\nu}")#text(" is almost the same as before; it is also given as a square ")#mi("{\\nu(n) = \\lambda(n)^2}")#text(" with ")#mi("{\\lambda}")#text(" given by ")#link(<tao-7f1b55b860590406f84f>)[#text("(12)")]#text(", but now the interval ")#mi("{I}")#text(" is truncated to ")#mi("{(w,x^\\varpi)}")#text(" instead of ")#mi("{(x,\\infty)}")#text(". Also, in this argument we take")

#align(center)[#tao-fit-display[#mitex("R = x^{1/4 + \\varpi}")]]

#text("We now establish ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(". By repeating the previous arguments, the left-hand side of ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(" is equal to a main term ")#metadata(none) <tao-9a370ebd95136e8b2036>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) k_0^{\\Omega([d_1,d_2])} \\frac{x}{W[d_1,d_2]}")]]



#text(" plus an error term which continues to be acceptable (indeed, the error term is slightly smaller than in the previous case due to the truncated nature of ")#mi("{I}")#text("). At this point in the previous section we applied Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(", but that proposition was only available for the untruncated interval ")#mi("{[w,+\\infty)}")#text(" instead of the truncated interval ")#mi("{[w,x^\\varpi)}")#text(". One could try to adapt the proof of that proposition to the truncated case, but then one is faced with the problem of controlling the truncated zeta function ")#mi("{\\zeta_I}")#text(". While one can eventually get some reasonable asymptotics for this function, it seems to be more efficient to eschew Fourier analysis and work entirely in “physical space” by the following partial ")#link("http://en.wikipedia.org/wiki/M%C3%B6bius_inversion_formula")[#text("Möbius inversion argument")]#text(". Write ")#mi("{J := [x^\\varpi,\\infty)}")#text(", thus ")#mi("{I \\cup J = [w,+\\infty)}")#text(". Observe that for any ")#mi("{d \\in {\\mathcal S}_{I \\cup J}}")#text(", the quantity ")#mi("{\\sum_{a \\in {\\mathcal S}_J: a|d} \\mu(a)}")#text(" equals ")#mi("{1}")#text(" when ")#mi("{d}")#text(" lies in ")#mi("{{\\mathcal S}_I}")#text(" and vanishes otherwise. Hence, for any function ")#mi("{F(d_1,d_2)}")#text(" of ")#mi("{d_1}")#text(" and ")#mi("{d_2}")#text(" supported on squarefree numbers we have the partial Mobius inversion formula")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} F(d_1,d_2) = \\sum_{a_1, a_2 \\in {\\mathcal S}_J} \\mu(a_1) \\mu(a_2) \\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}} F(a_1 d_1, a_2 d_2)")]]

#text("and so the main term ")#link(<tao-9a370ebd95136e8b2036>)[#text("(20)")]#text(" can be expressed as ")#metadata(none) <tao-b3deb173436f3977aca4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sum_{a_1, a_2 \\in {\\mathcal S}_J} \\mu(a_1) \\mu(a_2) \\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}} \\mu(a_1 d_1) g(\\frac{\\log a_1d_1}{\\log R}) \\mu(a_2 d_2) g(\\frac{\\log a_2 d_2}{\\log R})")]]





#align(center)[#tao-fit-display[#mitex("k_0^{\\Omega([a_1d_1,a_2d_2])} \\frac{x}{W [a_1d_1,a_2d_2]}.")]]

#text("We first dispose of the contribution to ")#link(<tao-b3deb173436f3977aca4>)[#text("(21)")]#text(" when ")#mi("{a_i,d_j}")#text(" share a common prime factor ")#mi("{p_* \\in J}")#text(" for some ")#mi("{i,j=1,2}")#text(". For any fixed ")#mi("{i,j}")#text(", we can bound this contribution by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{x}{W} \\sum_{p_* \\in J} \\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}} 1_{p^2_*|a_id_j} (a_1 d_1 a_2 d_2)^{-1/\\log R} \\frac{k_0^{\\Omega([a_1d_1,a_2d_2])}}{[a_1d_1,a_2d_2]}.")]]

#text("Factorising the inner two sums as an Euler product, this becomes")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{x}{W} \\sum_{p_* \\in J} \\frac{1}{p_*^2} ( \\prod_{p \\in I \\cup J} 1 + O(\\frac{1}{p^{1+1/\\log R}}) ).")]]

#text("[UPDATE: The above argument is not quite correct; a corrected (and improved) version is given at ")#link("https://terrytao.wordpress.com/2013/06/11/further-analysis-of-the-truncated-gpy-sieve/")[#text("this newer post")]#text(".] The product is ")#mi("{O(\\log^{O(1)} R)}")#text(" by e.g. Mertens’ theorem, while ")#mi("{\\sum_{p_* \\in J} \\frac{1}{p_*^2} \\ll x^{-\\varpi}}")#text(". So the contribution of this case is negligible.")

#text("If ")#mi("{a_i,d_j}")#text(" do not share a common factor ")#mi("{p_* \\in J}")#text(" for any ")#mi("{i,j=1,2}")#text(", then we can factor ")#mi("{[a_1d_1,a_2d_2]}")#text(" as ")#mi("{[a_1,a_2][d_1,d_2]}")#text(". Rearranging this portion of ")#link(<tao-b3deb173436f3977aca4>)[#text("(21)")]#text(" and then reinserting the case when ")#mi("{a_i,d_j}")#text(" have a common factor ")#mi("{p_* \\in J}")#text(" for some ")#mi("{i,j}")#text(", we may write ")#link(<tao-b3deb173436f3977aca4>)[#text("(21)")]#text(" up to negligible errors as")

#align(center)[#tao-fit-display[#mitex("\\frac{x}{W} \\sum_{a_1, a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}} \\mu(d_1) g(\\frac{\\log d_1}{\\log R} + \\frac{\\log a_1}{\\log R})")]]

#align(center)[#tao-fit-display[#mitex("\\mu(d_2) g(\\frac{\\log d_2}{\\log R} + \\frac{\\log a_2}{\\log R}) \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1,d_2]}.")]]

#text("Note that we can restrict ")#mi("{a_1,a_2}")#text(" to be at most ")#mi("{R}")#text(" as otherwise the ")#mi("{g}")#text(" factors vanish. The inner sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_{I \\cup J}} \\mu(d_1) g(\\frac{\\log d_1}{\\log R} + \\frac{\\log a_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R} + \\frac{\\log a_2}{\\log R}) \\frac{k_0^{\\Omega([d_1,d_2])}}{[d_1,d_2]}")]]

#text("is now of the form that can be treated by Proposition ")#link(<tao-5009a047a11fbd680bb4>)[#text("10")]#text(", and takes the form")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\phi(W)}{W} \\log R)^{-k_0} (\\int_0^\\infty g^{(k_0)}(x + \\frac{\\log a_1}{R}) g^{(k_0)}(x + \\frac{\\log a_2}{R}) \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("+ o(1)).")]]

#text("Here we make the technical remark that the translates of ")#mi("{g}")#text(" by shifts between ")#mi("{0}")#text(" and ")#mi("{1}")#text(" are uniformly controlled in smooth norms, which means that the ")#mi("{o(1)}")#text(" error here is uniform in the choices of ")#mi("{a_1, a_2}")#text(".")

#text("Let us first deal with the contribution of the ")#mi("{o(1)}")#text(" error term. This is bounded by")

#align(center)[#tao-fit-display[#mitex("o( \\frac{x}{W} (\\frac{\\phi(W)}{W} \\log R)^{-k_0} \\sum_{a_1,a_2 \\in {\\mathcal S}_{(x^\\varpi, R]}} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} ).")]]

#text("The inner sum factorises as")

#align(center)[#tao-fit-display[#mitex("\\prod_{x^\\varpi < p \\leq R} (1 + \\frac{3 k_0}{p})")]]

#text("which by ")#link("http://en.wikipedia.org/wiki/Mertens'_theorems")[#text("Mertens’ theorem")]#text(" is ")#mi("{O(1)}")#text(" (albeit with a rather large implied constant!), so this error is negligible for the purposes of ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(". Indeed, ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(" is now reduced to the inequality")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]}")]]

#metadata(none) <tao-5e8c9902207afaeb7120>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\int_0^\\infty g^{(k_0)}(x + \\frac{\\log a_1}{\\log R}) g^{(k_0)}(x + \\frac{\\log a_2}{\\log R}) \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx")]]





#align(center)[#tao-fit-display[#mitex("\\leq \\alpha+o(1).")]]

#text("Note that the factor ")#mi("{\\frac{x^{k_0-1}}{(k_0-1)!}}")#text(" increases very rapidly with ")#mi("{x}")#text(" when ")#mi("{k}")#text(" is large, which basically means that any non-trivial shift of the ")#mi("{g^{(k_0)}}")#text(" factors to the left by ")#mi("{\\frac{\\log a_1}{\\log R}}")#text(" or ")#mi("{\\frac{\\log a_2}{\\log R}}")#text(" will cause the integral in ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" to decrease dramatically. Since all the ")#mi("{a_1,a_2}")#text(" in ")#mi("{{\\mathcal J}}")#text(" are either equal to ")#mi("{1}")#text(" or bounded below by ")#mi("{x^\\varpi}")#text(", this will cause the ")#mi("{a_1=a_2=1}")#text(" term to dominate in the regime when ")#mi("{k_0 \\varpi}")#text(" is large (or more precisely ")#mi("{k_0 \\varpi \\gg \\log k_0}")#text("), which is the case in applications.")

#text("At this point, in order to perform the computations cleanly, we will mimic the arguments from the previous section and take the explicit choice")

#align(center)[#tao-fit-display[#mitex("g(x) := \\frac{1}{(k_0+l_0)!} (1-x)_+^{k_0+l_0}")]]

#text("for some integer ")#mi("{l_0>0}")#text(" and ")#mi("{x>0}")#text(" (and some smooth continuation to ")#mi("{[-1,1]}")#text(" for negative ")#mi("{x}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("g^{(k_0)}(x) = (-1)^{k_0} \\frac{1}{l_0!} (1-x)^{l_0}_+")]]

#text("for positive ")#mi("{x}")#text(". (Again, this function is not quite smooth at ")#mi("{1}")#text(", but this issue can be dealt with by an infinitesimal regularisation argument which we omit here.) The left-hand side of ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" now becomes")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(l_0!)^2} \\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\int_0^\\infty (1-x-\\frac{\\log a_1}{\\log R})_+^{l_0} (1-x-\\frac{\\log a_2}{\\log R})_+^{l_0}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{x^{k_0-1}}{(k_0-1)!}\\ dx.")]]

#text("The integral here is a little bit more complicated than a beta integral. To estimate it, we use the beta function identity to observe that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty (1-x-\\frac{\\log a_1}{\\log R})_+^{2l_0} \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx = (1 - \\frac{\\log a_1}{\\log R})_+^{k_0+2l_0} \\frac{(2l_0)!}{(k_0+2l_0)!}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty (1-x-\\frac{\\log a_2}{\\log R})_+^{2l_0} \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx = (1 - \\frac{\\log a_2}{\\log R})_+^{k_0+2l_0} \\frac{(2l_0)!}{(k_0+2l_0)!}")]]

#text("and hence by Cauchy-Schwarz")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty (1-x-\\frac{\\log a_1}{\\log R})_+^{l_0} (1-x-\\frac{\\log a_2}{\\log R})_+^{l_0} \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("\\leq (1 - \\frac{\\log a_1}{\\log R})_+^{k_0/2+l_0} (1 - \\frac{\\log a_2}{\\log R})_+^{k_0/2+l_0} \\frac{(2l_0)!}{(k_0+2l_0)!}.")]]

#text("This Cauchy-Schwarz step is a bit wasteful when ")#mi("{a_1,a_2}")#text(" are far apart, but this does seems to only lead to a minor loss of efficiency in the estimates. We have thus bounded the left-hand side of ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\frac{(2l_0)!}{(l_0!)^2 (k_0+2l_0)!} \\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]}")]]

#align(center)[#tao-fit-display[#mitex("(1 - \\frac{\\log a_1}{\\log R})_+^{k_0/2+l_0} (1 - \\frac{\\log a_2}{\\log R})_+^{k_0/2+l_0}.")]]

#text("It is now convenient to collapse the double summation to a single summation. We may bound")

#align(center)[#tao-fit-display[#mitex("(1 - \\frac{\\log a_1}{\\log R})_+^{k_0/2+l_0} (1 - \\frac{\\log a_2}{\\log R})_+^{k_0/2+l_0} \\leq (1 - \\frac{\\log [a_1,a_2]}{\\log R^2})_+^{k_0/2+l_0}")]]

#text("(since ")#mi("{\\frac{\\log [a_1,a_2]}{\\log R^2}}")#text(" is less than the greater of ")#mi("{\\frac{\\log a_1}{\\log R}}")#text(" and ")#mi("{\\frac{\\log a_2}{\\log R}}")#text(") and observe that each ")#mi("{a \\in {\\mathcal S}_J}")#text(" has ")#mi("{3^{\\Omega(a)}}")#text(" representations of the form ")#mi("{a = [a_1,a_2]}")#text(", so we may now bound the left-hand side of ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\frac{(2l_0)!}{(l_0!)^2 (k_0+2l_0)!} \\sum_{a \\in {\\mathcal S}_J} \\frac{(3k_0)^{\\Omega(a)}}{a} (1 - \\frac{\\log a}{\\log R^2})_+^{k_0/2+l_0}.")]]

#text("Note that an element ")#mi("{a}")#text(" of ")#mi("{{\\mathcal S}_J}")#text(" is either equal to ")#mi("{1}")#text(", or lies in the interval ")#mi("{[x^{n\\varpi}, x^{(n+1)\\varpi})}")#text(" for some natural number ")#mi("{n \\geq 1}")#text(". In the latter case, we have")

#align(center)[#tao-fit-display[#mitex("(1 - \\frac{\\log a}{\\log R^2})_+ \\leq (1 - \\frac{2n \\varpi}{1 + 4\\varpi})_+.")]]

#text("In particular, this expression vanishes if ")#mi("{n \\geq 2 + \\frac{1}{2\\varpi}}")#text(". We can thus bound the left-hand side of ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\frac{(2l_0)!}{(l_0!)^2 (k_0+2l_0)!} (1 + \\sum_{1 \\leq n < 2 + \\frac{1}{2\\varpi}} (1 - \\frac{2n \\varpi}{1 + 4\\varpi})^{k_0/2 + l_0}")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\in {\\mathcal S}_J: a < x^{(n+1)\\varpi}} \\frac{(3k_0)^{\\Omega(a)}}{a} ).")]]

#text("If we introduce the quantity ")#metadata(none) <tao-6d993237dbb77056871b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\Phi_{3k_0}(z,y) := \\sum_{j=0}^\\infty (3k_0)^j \\sum_{y \\leq p_1 < \\ldots < p_j: p_1 \\ldots p_j < z} \\frac{1}{p_1 \\ldots p_j}")]]



#text(" then we have thus bounded the left-hand side of ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\frac{(2l_0)!}{(l_0!)^2 (k_0+2l_0)!} (1 + \\sum_{j=1}^\\infty (1 - \\frac{2j \\varpi}{1 + 4\\varpi})_+^{k_0/2 + l_0} \\Phi_{3k_0}( x^{(j+1)\\varpi}, x^\\varpi )).")]]

#text("We observe that ")#metadata(none) <tao-71cac9f6e54fb6722ca8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("\\Phi_{3k_0}(z,y) = 1")]]



#text(" when ")#mi("{y \\geq z}")#text(", while in general we have the ")#emph[#text("Buchstab identity")]#text(" ")#metadata(none) <tao-e77c4b3f81059b97c4d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\Phi_{3k_0}(z,y) \\leq 1 + 3k_0 \\sum_{y \\leq p < z} \\frac{1}{p} \\Phi(\\frac{z}{p}, p)")]]



#text(" as can be seen by isolating the smallest prime ")#mi("{p_1}")#text(" in all the terms in ")#link(<tao-6d993237dbb77056871b>)[#text("(23)")]#text(" with ")#mi("{j \\geq 1}")#text(". (This inequality is very close to being an identity, the only loss coming from the possibility of the prime factor ")#mi("{p}")#text(" being repeated in a term associated to ")#mi("{\\frac{1}{p} \\Phi(\\frac{z}{p},p)}")#text(".) We can iterate this identity to obtain the following conclusion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 13")]#text(" ")#metadata(none) <tao-94c2821958d4fa785bad>#text(" For any ")#mi("{n \\geq 1}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\Phi_{3k_0}(z,y) \\leq \\prod_{j=1}^{n-1} (1 + 3k_0 \\log(1+\\frac{1}{j})) + o(1)")]]

#text("whenever ")#mi("{z \\leq y^n}")#text(" and ")#mi("{y \\geq x^\\varpi}")#text(" for some fixed ")#mi("{\\varpi > 0}")#text(", with the error term being uniform in the choice of ")#mi("{z,y}")#text(".")
]

#emph[#text("Proof:")]#text(" Write ")#mi("{A_n := \\prod_{j=1}^{n-1} (1 + 3k_0 \\log(1+\\frac{1}{j}))}")#text(". We prove the bound ")#mi("{\\Phi_{3k_0}(z,y) \\leq A_n + o(1)}")#text(" by strong induction on ")#mi("{n}")#text(". The case ")#mi("{n=1}")#text(" follows from ")#link(<tao-71cac9f6e54fb6722ca8>)[#text("(24)")]#text(". Now suppose that ")#mi("{n>1}")#text(" and that the claim has already been proven for smaller ")#mi("{n}")#text(". Let ")#mi("{z \\leq y^n}")#text(" and ")#mi("{y > x^\\varpi}")#text(". Note that ")#mi("{\\frac{z}{p} \\leq p^j}")#text(" whenever ")#mi("{p \\geq z^{\\frac{1}{j+1}}}")#text(". We thus have from ")#link(<tao-e77c4b3f81059b97c4d2>)[#text("(25)")]#text(" and the induction hypothesis that")

#align(center)[#tao-fit-display[#mitex("\\Phi_{3k_0}(z,y) \\leq 1 + 3k_0 \\sum_{j=1}^{n-1} \\sum_{z^{\\frac{1}{j+1}} \\leq p < z^{\\frac{1}{j}}} \\frac{1}{p} (A_j + o(1) );")]]

#text("applying Mertens’ theorem (or the prime number theorem) we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{z^{\\frac{1}{j+1}} \\leq p < z^{\\frac{1}{j}}} \\frac{1}{p} ( A_j + o(1) ) = A_j \\log(1 + \\frac{1}{j}) + o(1)")]]

#text("and the claim follows from the telescoping identity")

#align(center)[#tao-fit-display[#mitex("A_n = 1 + 3k_0 \\sum_{j=1}^{n-1} A_j \\log(1+\\frac{1}{j}).")]]

#mi("\\Box")

#text("Applying this inequality, we have established ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" with ")#metadata(none) <tao-f81ab872625c131d92e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\alpha := \\frac{(2l_0)!}{(l_0!)^2 (k_0+2l_0)!} (1 + \\kappa)")]]



#text(" where ")#metadata(none) <tao-73a429df77c02fe87680>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\kappa := \\sum_{1 \\leq n < 2 + \\frac{1}{2\\varpi}} (1 - \\frac{2n \\varpi}{1 + 4\\varpi})^{k_0/2 + l_0} \\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j})) ).")]]



#text(" We remark that as a first approximation we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j})) ) \\approx \\frac{(3k_0)^{n}}{n!}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(1 - \\frac{2n \\varpi}{1 + 4\\varpi})^{k_0/2 + l_0} \\approx \\exp( - n k_0 \\varpi )")]]

#text("so in the regime ")#mi("{k_0 \\varpi \\gg \\log k_0}")#text(", ")#mi("{\\kappa}")#text(" is roughly ")#mi("{3k_0 \\exp( - k_0 \\varpi )}")#text(", which will be negligible for the parameter ranges of ")#mi("{k_0,\\varpi}")#text(" of interest. Thus the ")#mi("{\\alpha}")#text(" in this argument is quite close to the ")#mi("{\\alpha}")#text(" from ")#link(<tao-658e28f06315a42fc360>)[#text("(15)")]#text(" in practice.")

#text("Now we turn to ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(". Fix ")#mi("{h \\in {\\mathcal H}}")#text(". As in the previous section, we can bound the left-hand side of ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" as the sum of the main term")

#align(center)[#tao-fit-display[#mitex("\\sum_{d_1,d_2 \\in {\\mathcal S}_I} \\mu(d_1) g(\\frac{\\log d_1}{\\log R}) \\mu(d_2) g(\\frac{\\log d_2}{\\log R}) (k_0-1)^{\\Omega([d_1,d_2])} \\frac{x}{\\phi(W[d_1,d_2])}")]]

#text("plus an error term")

#align(center)[#tao-fit-display[#mitex("O( \\sum_{d_1,d_2 \\in {\\mathcal S}_I} g(\\frac{\\log d_1}{\\log R}) g(\\frac{\\log d_2}{\\log R}) (k_0-1)^{\\Omega([d_1,d_2])} E^{\\prime}(x; [d_1,d_2]) )")]]

#text("where ")#mi("{E^{\\prime}(x;q)}")#text(" is the quantity")

#align(center)[#tao-fit-display[#tao-math("E^{\\prime}(x;q) := \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times: P_h(a) = 0 \\text{ mod } q} \\left|\\Delta^{\\prime}_{b,W}(\\theta; q,a)\\right|,", block: true)]]

#mi("{P_h}")#text(" is the polynomial ")#mi("{P_h(a) := \\prod_{h^{\\prime} \\in {\\mathcal H} \\backslash \\{h\\}} (n+h^{\\prime}-h)}")#text(", and ")#mi("{\\Delta^{\\prime}_{b,W}}")#text(" was defined in ")#link(<tao-9294ab38039f60d2ec53>)[#text("(19)")]#text(". Using the hypothesis ")#mi("{MPZ[\\varpi]}")#text(" and Cauchy-Schwarz as in the previous section we see that the error term is negligible for the purposes of establishing ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(". As for the main term, the same argument used to reduce ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(" to ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" shows that ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" reduces to")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{(k_0-1)^{\\Omega([a_1,a_2])}}{\\phi([a_1,a_2])} \\int_0^\\infty g^{(k_0-1)}(x + \\frac{\\log a_1}{\\log R}) g^{(k_0-1)}(x + \\frac{\\log a_2}{\\log R}) \\frac{x^{k_0-2}}{(k_0-2)!}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("\\geq \\beta-o(1).")]]

#text("Here, we can do something a bit crude; with our choice of ")#mi("{g}")#text(", the integrand is non-negative, so we can simply discard all but the ")#mi("{a_1=a_2=1}")#text(" term and reduce to")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty g^{(k_0-1)}(x) g^{(k_0-1)}(x) \\frac{x^{k_0-2}}{(k_0-2)!}\\ dx \\geq \\beta")]]

#text("(The intuition here is that by refusing to sieve using primes larger than ")#mi("{x^\\varpi}")#text(", we have enlarged the sieve ")#mi("{\\nu}")#text(", which makes the upper bound ")#link(<tao-e8bc163c82eee1873328>)[#text("(9)")]#text(" more difficult but the lower bound ")#link(<tao-ad328846aa18b32a3358>)[#text("(10)")]#text(" actually becomes easier.) So we can take the same choice ")#link(<tao-6aea43f12a7bea73486f>)[#text("(16)")]#text(" of ")#mi("{\\beta}")#text(" as in the previous section:")

#align(center)[#tao-fit-display[#mitex("\\beta := \\frac{(2l_0+2)!}{((l_0+1)!)^2 (k_0+2l_0+1)!}.")]]

#text("Inserting this and ")#link(<tao-f81ab872625c131d92e7>)[#text("(26)")]#text(" into ")#link(<tao-6e226a9abab47f9e81f8>)[#text("(11)")]#text(" and simplifying, we see that we can obtain ")#mi("{DHL[k_0,2]}")#text(" once we can verify the inequality")

#align(center)[#tao-fit-display[#mitex("1+4\\varpi > (1 + \\frac{1}{2l_0+1}) (1 + \\frac{2l_0+1}{k_0}) (1+\\kappa).")]]

#text("As before, ")#mi("{l_0}")#text(" can be taken to be non-integer if desired. Setting ")#mi("{k_0}")#text(" to be slightly larger than ")#mi("{(\\sqrt{1+4\\varpi}-1)^{-2} \\approx (2\\varpi)^{-2}}")#text(" we obtain Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(".")

#heading(level: 1)[#strong[#text(" — 5. Using optimal values of ")#mi("{g}")#text(" (NEW, June 5, 2013) — ")]]

#text("We can do better than given above by using an optimal value of ")#mi("{g}")#text(". The following result was ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("obtained recently by Farkas, Pintz, and Revesz")]#text(", and independently worked out by commenters on this blog:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Optimal GPY weight)")]#text(" ")#metadata(none) <tao-fed6bed78dd6917874a2>#text(" Let ")#mi("{k_0 > 2}")#text(" be an integer. Then the ratio")

#align(center)[#tao-fit-display[#mitex("\\frac{\\int_0^1 f^{\\prime}(x)^2 x^{k_0-1}\\ dx}{\\int_0^1 f(x)^2 x^{k_0-2}\\ dx}")]]

#text("where ")#mi("{f: [0,1] \\rightarrow {\\bf R}}")#text(" is a smooth function with ")#mi("{f(1)=0}")#text(" that is not identically vanishing, has a minimal value of")

#align(center)[#tao-fit-display[#mitex("\\lambda := \\frac{j_{k_0-2}^2}{4}")]]

#text("where ")#mi("{j_{k_0-2}}")#text(" is the first zero of the ")#link("http://en.wikipedia.org/wiki/Bessel_function")[#text("Bessel function")]#text(" ")#mi("{J_{k_0-2}}")#text(". Furthermore, this minimum is attained if (and only if) ")#mi("{f}")#text(" is a scalar multiple of the function")

#align(center)[#tao-fit-display[#mitex("f_0(x) = x^{1-k_0/2} J_{k_0-2}(2\\sqrt{x\\lambda}).")]]
]

#emph[#text("Proof:")]#text(" The function ")#mi("{J_{k_0-2}}")#text(", by definition, obeys the Bessel differential equation")

#align(center)[#tao-fit-display[#mitex("x^2 \\frac{d}{dx^2} J_{k_0-2} + x \\frac{d}{dx} J_{k_0-2} + (x^2 - (k_0-2)^2) J_{k_0-2} = 0")]]

#text("and also vanishes to order ")#mi("{k_0-2}")#text(" at the origin. From this and routine computations it is easy to see that ")#mi("{f_0}")#text(" is smooth, strictly positive on ")#mi("{[0,1)}")#text(", and obeys the differential equation ")#metadata(none) <tao-df087996d45b03e7eb8c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\frac{d}{dx} (x^{k_0-1} \\frac{d}{dx} f_0(x)) + \\lambda x_0^{k-2} f_0(x) = 0.")]]



#text(" If we write ")#mi("{g_0(x) := \\frac{f^{\\prime}_0}{f_0}(x)}")#text(", which is well-defined away from ")#mi("{1}")#text(" since ")#mi("{f_0}")#text(" is non-vanishing on ")#mi("{[0,1)}")#text(", then ")#mi("{g_0}")#text(" obeys the Ricatti-type equation ")#metadata(none) <tao-9326851980ccb5437d1c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("(k_0-1) g_0(x) + x g^{\\prime}_0(x) + x g_0(x)^2 + \\lambda = 0.")]]



#text(" Now consider the quadratic form")

#align(center)[#tao-fit-display[#mitex("Q( f ) := \\int_0^1 f^{\\prime}(x)^2 x^{k_0-1}\\ dx - \\lambda \\int_0^1 f(x)^2 x^{k_0-2}\\ dx")]]

#text("for smooth functions ")#mi("{f: [0,1] \\rightarrow {\\bf R}}")#text(" with ")#mi("{f(1)=0}")#text(". A calculation using ")#link(<tao-9326851980ccb5437d1c>)[#text("(29)")]#text(" and integration by parts shows that")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 (f^{\\prime}(x)-g_0(x)f(x))^2 x^{k_0-1}\\ dx = Q(f)")]]

#text("and so ")#mi("{Q(f) \\geq 0}")#text(", giving the first claim; the second claim follows by noting that ")#mi("{f^{\\prime}-g_0 f}")#text(" vanishes if and only if ")#mi("{f}")#text(" is a scalar multiple of ")#mi("{f_0}")#text(". (Note that the integration by parts is a little subtle, because ")#mi("{f_0}")#text(" vanishes to first order at ")#mi("{x=1}")#text(" and so ")#mi("{g_0}")#text(" blows up to first order; but ")#mi("{g_0 f^2}")#text(" still vanishes to first order at ")#mi("{x=1}")#text(", allowing one to justify the integration by parts by a standard limiting argument.) ")#mi("\\Box")

#text("If we now test ")#link(<tao-2ad81149147ce72b6732>)[#text("(14)")]#text(" with a function ")#mi("{g: [0,1] \\rightarrow {\\bf R}}")#text(" which is smooth, vanishes to order ")#mi("{k_0}")#text(" at ")#mi("{x=1}")#text(", and has a ")#mi("{(k_0-1)^{th}}")#text(" derivative equal to ")#mi("{f_0}")#text(", we see that we can deduce ")#mi("{DHL[k_0,2]}")#text(" from ")#mi("{EH[\\theta]}")#text(" whenever")

#align(center)[#tao-fit-display[#mitex("2\\theta > \\frac{j_{k_0-2}^2}{k_0(k_0-1)}.")]]

#text("Using the known asymptotic")

#align(center)[#tao-fit-display[#mitex("j_n = n + c n^{1/3} + O( n^{-1/3} )")]]

#text("for ")#mi("{c := 1.8557571\\ldots}")#text(" and large ")#mi("{n}")#text(" (see e.g. ")#link("http://en.wikipedia.org/wiki/Abramowitz_and_Stegun")[#text("Abramowitz and Stegun")]#text("), this is asymptotically of the form")

#align(center)[#tao-fit-display[#mitex("2 \\theta > 1 + 2c k_0^{-2/3} + O( k_0^{-1} )")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("k_0 > (2c (2\\theta-1))^{-3/2},")]]

#text("thus giving a relationship of the form ")#mi("{k_0 \\sim (\\theta-1/2)^{-3/2}}")#text(" that is superior to the previous relationship ")#mi("{k_0 \\sim (\\theta-1/2)^{-2}}")#text(".")

#text("A similar argument can be given for Theorem ")#link(<tao-20854963535d2fa25505>)[#text("5")]#text(", using ")#mi("{g}")#text(" of the form above rather than a monomial ")#mi("{\\frac{(1-x)^{k_0+l_0}}{(k_0+l_0)!}}")#text(" (and extended by zero to ")#mi("{[1,+\\infty)}")#text("). For future optimisation we consider a generalisation ")#mi("{MPZ[\\varpi,\\delta]}")#text(" of ")#mi("{MPZ[\\varpi]}")#text(" in which the interval ")#mi("{I}")#text(" is of the form ")#mi("{[w,x^\\delta)}")#text(" rather than ")#mi("{[w,x^\\varpi)}")#text(", so that ")#mi("{J}")#text(" is now ")#mi("{[x^\\delta,\\infty)}")#text(" rather than ")#mi("{[x^\\varpi,\\infty)}")#text(". As before, the key point is the estimation of ")#mi("{\\alpha}")#text(". The arguments leading to ")#link(<tao-5e8c9902207afaeb7120>)[#text("(22)")]#text(" go through for any test function ")#mi("{g}")#text(", so we have to show")

#align(center)[#tao-fit-display[#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\int_0^\\infty g^{(k_0)}(x + \\frac{\\log a_1}{\\log R}) g^{(k_0)}(x + \\frac{\\log a_2}{\\log R}) \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx \\leq \\alpha+o(1).")]]

#text("As ")#mi("{g}")#text(" has ")#mi("{(k_0-1)^{th}}")#text(" derivative equal to ")#mi("{f_0}")#text(", this is ")#metadata(none) <tao-0e753487879fb8a9bb8a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} \\int_0^{1-\\frac{\\log \\max(a_1,a_2)}{\\log R}} f^{\\prime}_0(x + \\frac{\\log a_1}{\\log R}) f^{\\prime}_0(x + \\frac{\\log a_2}{\\log R})")]]





#align(center)[#tao-fit-display[#mitex("\\frac{x^{k_0-1}}{(k_0-1)!}\\ dx \\leq \\alpha+o(1).")]]

#text("We need some sign information on ")#mi("{f^{\\prime}_0}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 15")]#text(" On ")#mi("{[0,1)}")#text(", ")#mi("{f_0}")#text(" is positive, ")#mi("{f^{\\prime}_0}")#text(" is negative and ")#mi("{f^{\\prime\\prime}_0}")#text(" is positive.")
]

#emph[#text("Proof:")]#text(" From ")#link(<tao-df087996d45b03e7eb8c>)[#text("(28)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("x f^{\\prime\\prime}_0(x) + (k_0-1) f^{\\prime}_0(x) + \\lambda f_0(x) = 0.")]]

#text("From construction we already know that ")#mi("{f_0}")#text(" is positive on ")#mi("{[0,1)}")#text(". The above equation then shows that ")#mi("{f^{\\prime}_0}")#text(" is negative at ")#mi("{x=0}")#text(", and that ")#mi("{f_0}")#text(" cannot have any local minimum in ")#mi("{(0,1)}")#text(", so ")#mi("{f^{\\prime}_0}")#text(" is negative throughout. To obtain the final claim ")#mi("{f^{\\prime\\prime}_0>0}")#text(" we use an argument provided by Gergely Harcos in the comments: from the recursive relations for Bessel functions we can check that ")#mi("{f^{\\prime\\prime}_0}")#text(" is a positive multiple of ")#mi("{x^{-k_0/2} J_{k_0}(2 \\sqrt{x\\lambda})}")#text(", and the claim then follows from the interlacing properties of the zeroes of Bessel functions. ")#mi("\\Box")

#text("Write ")#mi("{A := \\int_0^1 f_0(x)^2 \\frac{x^{k_0-2}}{(k_0-2)!}}")#text(", so ")#mi("{A}")#text(" is positive and by Theorem ")#link(<tao-fed6bed78dd6917874a2>)[#text("14")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 f^{\\prime}_0(x)^2 \\frac{x^{k_0-1}}{(k_0-1)!} = \\frac{j_{k_0-2}^2}{4(k_0-1)} A.")]]

#text("If ")#mi("{a_1 < R}")#text(", then as ")#mi("{f^{\\prime}_0}")#text(" is negative and increasing we have")

#align(center)[#tao-fit-display[#mitex("-f^{\\prime}_0(x + \\frac{\\log a_1}{\\log R}) \\leq -f^{\\prime}_0( x / (1-\\frac{\\log a_1}{\\log R}) )")]]

#text("for ")#mi("{0 \\leq x \\leq 1 - \\frac{\\log a_1}{\\log R}}")#text(", and thus by change of variable")

#align(center)[#tao-fit-display[#mitex("\\int_0^{1-\\frac{\\log a_1}{\\log R}} f^{\\prime}_0(x + \\frac{\\log a_1}{\\log R})^2 \\frac{x^{k_0-1}}{(k_0-1)!} \\leq (1-\\frac{\\log a_1}{\\log R})^{k_0} \\frac{j_{k_0-2}^2}{4(k_0-1)} A")]]

#text("for ")#mi("{a_1 < R}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\int_0^{1-\\frac{\\log a_1}{\\log R}} f^{\\prime}_0(x + \\frac{\\log a_1}{\\log R})^2 \\frac{x^{k_0-1}}{(k_0-1)!} \\leq (1-\\frac{\\log a_1}{\\log R})_+^{k_0} \\frac{j_{k_0-2}^2}{4(k_0-1)} A")]]

#text("for all ")#mi("{a_1}")#text(". Similarly")

#align(center)[#tao-fit-display[#mitex("\\int_0^{1-\\frac{\\log a_2}{\\log R}} f^{\\prime}_0(x + \\frac{\\log a_2}{\\log R})^2 \\frac{x^{k_0-1}}{(k_0-1)!} \\leq (1-\\frac{\\log a_2}{\\log R})^{k_0}_+ \\frac{j_{k_0-2}^2}{4(k_0-1)} A")]]

#text("for all ")#mi("{a_2}")#text(". By Cauchy-Schwarz we can thus bound the integral in ")#link(<tao-0e753487879fb8a9bb8a>)[#text("(30)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("(1-\\frac{\\log a_1}{\\log R})_+^{k_0/2} (1-\\frac{\\log a_2}{\\log R})_+^{k_0/2} \\frac{j_{k_0-2}^2}{4(k_0-1)} A")]]

#text("and so ")#link(<tao-0e753487879fb8a9bb8a>)[#text("(30)")]#text(" reduces to")

#align(center)[#tao-fit-display[#mitex("\\frac{j_{k_0-2}^2}{4(k_0-1)} A \\sum_{a_1,a_2 \\in {\\mathcal S}_J} \\frac{k_0^{\\Omega([a_1,a_2])}}{[a_1,a_2]} (1-\\frac{\\log a_1}{\\log R})_+^{k_0/2} (1-\\frac{\\log a_2}{\\log R})_+^{k_0/2} \\leq \\alpha + o(1).")]]

#text("Repeating the arguments of the previous section, we can reduce this to")

#align(center)[#tao-fit-display[#mitex("\\frac{j_{k_0-2}^2}{4(k_0-1)} A \\sum_{a \\in {\\mathcal S}_J} \\frac{(3k_0)^{\\Omega(a)}}{a} (1-\\frac{\\log a}{\\log R})_+^{k_0/2} \\leq \\alpha + o(1)")]]

#text("and by further continuing the arguments of the previous section we end up being able to take")

#align(center)[#tao-fit-display[#mitex("\\alpha = \\frac{j_{k_0-2}^2}{4(k_0-1)} A (1 + \\kappa)")]]

#text("where ")#metadata(none) <tao-acaddd6a84db73536f42>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0/2} \\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j})) ).")]]





#text("Also, the previous arguments allow us to take")

#align(center)[#tao-fit-display[#mitex("\\beta = A.")]]

#text("The key inequality ")#link(<tao-6e226a9abab47f9e81f8>)[#text("(11)")]#text(" now becomes ")#metadata(none) <tao-4d02adeedded9f185762>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("1 + 4\\varpi > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa),")]]



#text(" thus ")#mi("{MPZ[\\varpi,\\delta]}")#text(" implies ")#mi("{DHL[k_0,2]}")#text(" whenever ")#link(<tao-4d02adeedded9f185762>)[#text("(32)")]#text(" is obeyed with the value ")#link(<tao-acaddd6a84db73536f42>)[#text("(31)")]#text(" of ")#mi("{\\kappa}")#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (144)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-244903")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2013")])]

#text("In the second display below (12), ")#mi("\\frac{n}{d}")#text(" should be ")#mi("\\frac{P(n)}{d}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffe89443b5bd903c46f0e36ab16b745fe9977f85cacf9fec586271c4ed2cea0b-ac4fdc455655250683cd6bc175d5a2b4626c30d38b6f18e26772587f5e3831e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-247234")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("My apologies for all the help I’m requiring but a lot of these proof techniques are new to me in style. I’m looking at your proof of the overspill principle (Lemma 7). In the ")#mi("(i) \\Longrightarrow (ii)")#text(" part you create your ")#mi("w_0")#text(" function to be some specific function tending to infinity with x. Thus, given any ")#mi("w_{1/m}")#text(", the function ")#mi("w_0 (x)")#text(" will surpass it at some point. Thus:")

#tao-math("\\left|F(w_0 (x), x)\\right| \\leq \\frac{2}{m}", block: false)

#text("where ")#mi("1 \\leq m \\leq w_0 (x)")#text(". Upon letting x tend to infinity ")#mi("w_0 (x)")#text(" tends to infinity and we can let m tend to infinity and we have ")#tao-math("\\left|F(w_0 (x), x)\\right| = o(1)", block: false)#text(" and this seems clear to me.")#linebreak()#text(" The issue for me is the ‘sufficiently slowly’ part of the statement. Suppose that ")#mi("w(x)")#text(" is a function tending to infinity with x. Then, for all natural numbers m there is some real ")#mi("y_m")#text(" such that ")#mi("x \\geq y_m \\Longrightarrow w(x) \\geq w_{1/m}")#text(". If we define ")#mi("X = max( y_m, x_n )")#text(" then, surely, we must have ")#tao-math("\\left|F(w(x), x)\\right| \\leq \\frac{2}{m}", block: false)#text(" whenever ")#mi("x \\geq X")#text(" and ")#mi("1 \\leq m \\leq n")

#text("The one thing this argument avoids is your condition of ")#mi("1 \\leq w \\leq n")#text(" but I didn’t understand where that came from in the first place.")

#text("I’m sure I’ve missed something obvious (as I have before) but I can’t see it.")

#text("P.S. there is a slight typo in the proof in that it says “veifies” instead of “verifies”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-247235")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("One cannot conclude ")#tao-math("\\left|F(w(x),x)\\right| \\leq \\frac{2}{m}", block: false)#text(" for ")#mi("x \\geq X")#text(" unless one already knows that ")#mi("w(x) \\leq n")#text(" (note that ")#mi("w(x)")#text(" is not fixed, whereas (i) is only available for fixed w); this is why one needs ")#mi("w")#text(" to grow more slowly than ")#mi("w_0")#text(".")

#text("Incidentally, in the polymath8 writeup (see ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")]#text(" ) the overspill principle is no longer needed, because it turns out one can take ")#mi("w=  \\log\\log\\log x")#text(" rather than have ")#mi("w")#text(" be a sufficiently slowly growing function of x.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ffe89443b5bd903c46f0e36ab16b745fe9977f85cacf9fec586271c4ed2cea0b-ac4fdc455655250683cd6bc175d5a2b4626c30d38b6f18e26772587f5e3831e4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-247237")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2013")])]

#text("I assumed it had something to do with that w restriction but I don’t see where ")#mi("w(x) \\leq n")#text(" comes from. The way I understand it we’re setting ")#mi("\\epsilon = \\frac{1}{m}")#text(" and then ")#mi("x_n")#text(" is some real number such that the ")#mi("o(1)")#text(" term dips below ")#mi("\\frac{1}{n}")#text(" whenever ")#mi("x \\geq x_n")#text(" but, obviously, I must be missing something.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8b: Bounded intervals with many primes, after Maynard | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-251694")[#strong[#text("Polymath8b: Bounded intervals with many primes, after Maynard | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("[…] this claim was already essentially established back in this Polymath8a post (or see Proposition 4.1 and Lemma 4.7 of the Polymath8a paper for essentially these bounds). In […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-401506")[#strong[#text("Together and Alone, Closing the Prime Gap | For a better Vietnam")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2014")]

#text("[…] work. At the time, though, this advance was one of the most fruitful ones. When the team filled in this piece of the puzzle on June 5, the bound on prime gaps dropped from about 4.6 million to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1190ae941d18fd5ab544b9f83352ec3e8e36834c2fae49829d07ca88013292db-27836c2c00cd34a940bde5132a234613db5b2ed01732de0dc215774213cb3183.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wanglaoxinr")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-455907")[#strong[#text("wanglaoxinr")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2015")])]

#text("for Cramér Conjecture ，change Pn to x, will that hold?")#linebreak()#text(" Pn means n th prime, Pn<Pn+1<=x, Max(Pn+1-Pn) means the maximum gap between two neighboring primes in (0,x], when x tending to infinity, Max(Pn+1-Pn)/(lnx)^2 tending to 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-456596")[#strong[#text("The prime tuples conjecture, sieve theory, and the work of Goldston-Pintz-Yildirim, Motohashi-Pintz, and Zhang | fragments")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2015")]

#text("[…] for instance, if Conjecture 2 holds, then the number of twin primes less than should equal , where is the twin prime […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b654cd917c5d07dddb68a4811da76b8320f71702b9cc6888bcda22eba54b374d-8ff54ab0904fe0982bff74b8c46eb4a636a417d3b1b69fa2ddea539e0d23d279.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alexey")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-461113")[#strong[#text("Alexey")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2015")])]

#text("I have a question about an upper bound of conjecture 2 (about k-tuple of primes). Where can I find a proof of this upper bound? How C_{k_0} depends from k_0?")

#text("Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-461131")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2015")])]

#text("This can be found for instance in the texts of Montgomery-Vaughan or Iwaniec-Kowalski, or any book on sieve theory (e.g. Friedlander-Iwaniec). I also have it as an application of the Selberg sieve in Exercise 34 of ")#link("https://terrytao.wordpress.com/2015/01/21/254a-notes-4-some-sieve-theory/")[#text("these notes")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-467574")[#strong[#text("Where has the Time Gone? | Sublime Illusions")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2016")]

#text("[…] Tao explains concepts wonderfully, especially if you want a summary of a long and intricate paper (like the explanation of Zhang Yitang’s work on the Twin Prime Conjecture and related backgroun…). Beware, not for the faint of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-470788")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("Why is obvious that the Hardy-Littlewood infinite product does not converge to 0?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-2/#comment-470793")[#strong[#text("John")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("Oh I guess it’s a simple consequence of the Prime Number Theorem and the discrete integration by part, i.e., let ")#mi("f(p) = log[(1 - k/p) / (1 - 1/p)^k]")#text(", then one gets that the log of the HL-constant is equal to ")#mi("\\sum_n f(n) (\\pi(n) -\\pi(n-1)) = \\sum_n (f(n) - f(n-1)) \\pi(n) + C")#text(". The latter is finite since ")#mi("\\pi(n)")#text(" is bounded above and below eventually by $0.2 n / \\log n$ and $5 n / \\log n$.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6746c6eea9519df5df1c8c933282a784e55691fb468022b69d34ef606331ff85-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shun-Xiang Ouyang")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232408")[#strong[#text("Shun-Xiang Ouyang")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("Dear Terry, in the tags, “Yitong Zhang” should be “Yitang Zhang”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232410")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("Terry, amazing post. Near the start (it would take me a few hours to scroll back to exactly the right point) you say that ")#mi("k_0 \\sim (\\theta - 1/2)^2")#text(", where of course you mean ")#mi("(\\theta - 1/2)^{-2}")#text(". In the formulation of MPZ, you have ")#mi("S(q)")#text(", the residue classes ")#mi("a")#text(" for which ")#mi("P(a) = 0 mod(q)")#text(". It looks to me to be possible, from what I have read of Zhang’s paper so far, that all you need about these ")#mi("S(q)")#text(" is that ")#mi("S(q) \\times S(r) = S(qr)")#text(" under the isomorphism of ")#mi("Z/qZ \\times Z/rZ")#text(" and ")#mi("Z/qrZ")#text(", rather than that they come from the polynomial ")#mi("P")#text(". I’m not too sure about that at this stage, though.")

#emph[#text("[Thanks for the correction! My feeling is that there are some Kloosterman sum estimates (using the Weil conjectures) which rely on some of the structure coming from the polynomial P, otherwise Zhang would be proving something close to the full Elliott-Halberstam conjecture which I don’t think he is. But I haven’t checked this in detail yet – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232473")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("I withdraw my earlier comment: on closer inspection (and consultation with Ben Green) it appears that indeed the fine structure of S(q) is not needed beyond the multiplicative property ")#mi("S(q) \\times S(r) = S(qr)")#text(", the point being that ")#mi("q")#text(" is restricted to be smooth (only having prime factors less than ")#mi("x^\\varpi")#text(") and the effect of each small prime ")#mi("p < x^\\varpi")#text(" \"disperses\" itself across many moduli q, and so there is an opportunity to use the dispersion method (or Cauchy-Schwarz).")

#text("I am thinking of setting up an online reading seminar on the second half of Zhang's paper on this blog (perhaps as part of a broader Polymath project to improve the bounds). It looks like there are a lot of technical details here to discuss…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin O'Bryant")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232411")[#strong[#text("Kevin O'Bryant")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("Terry, You misspelled Sound’s name.")

#emph[#text("[Gah, that’s embarrassing – I’ve known Sound for 24 years! Fixed now – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a34de3cadf72ccac6610285e12c3bcebfccb65bbfbc1dbf4a0a4e1418f0dfae9-ff08d1e6595501802fa250f8098ab7d7e733ad521cc83d71559bc3462cc6ab4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vít Tuček")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232412")[#strong[#text("Vít Tuček")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("“In this post we would like to give a self-contained proof of both Theorem 4 and Theorem 6, … ”")

#text("I believe you meant to say Theorem 4 and Theorem 5.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232446")[#strong[#text("Why is mathematics possible? | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")]

#text("[…] Update: A description of Zhang’s work and a link to the paper can be found on Emmanuel Kowalski’s bloog Further update: A description of Zhang’s work and related questions and results can be found now in Terry Tao’s blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5650c915e01b3f2f0896d679b5113249b30eb7842aa9825e700a1707b19212e7-ed8d81786d8f1d2d8c99e19bc29e7de67ad3de72bcc79202285cd9bdefe55988.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232461")[#strong[#text("Anthony")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("Dear Terry,")#linebreak()#text(" Thanks a lot for the post.")#linebreak()#text(" Right after Conjecture 1, you say that Zhang’s result implies that there exists some ")#mi("d")#text(" such that ")#mi("(0,d)")#text(" is admissible. You probably meant to say that there is such an admissible set with infinitely many translates that consist entirely of primes.")#linebreak()#text(" And a couple of lines later, it should be ")#mi("\\nu_p = k_0")#text(" for all ")#mi("p>k_0")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c18b01ce7045b846d4b345c7e6a1f00fc78b7920dad1c72e409ae7ea7096c624-59149e3910509c0e2baab70107bfb50470121150beec3e39523e9f8ae21d2669.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of castover")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232479")[#strong[#text("castover")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("Terry,")

#text("Right before you make the definition of the singular series, you say “We then define the singular series ")#mi("{{\\mathfrak H} = {\\mathfrak G}({\\mathcal H})}")#text(" associated to ")#mi("{{\\mathfrak H}}")#text(" by the formula…” Do you mean to say “…associated to ")#mi("{{\\mathcal H}}")#text("…?”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D.Smith")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232498")[#strong[#text("Warren D.Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("See this for a (probably easy) suggestion:")#linebreak()#text(" ")#link("http://tech.groups.yahoo.com/group/primenumbers/message/25125")[#text("http://tech.groups.yahoo.com/group/primenumbers/message/25125")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4ad6c18186ffa1aab4aadbb6437ddfdfd03ffdb28fa7b75fb5a4b74dadd060d-b17876bb6ed44b4eb4e6f409d6e9c2e04bf2fd6789fad7fda897a642de72445e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath proposal: bounded gaps between primes | The polymath blog")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232499")[#strong[#text("Polymath proposal: bounded gaps between primes | The polymath blog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("[…] the explicit upper bound of 70,000,000 given for this gap. Since then there has been a flurry of activity in reducing this bound, with the current record being 4,802,222 (but likely to improve at least by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232501")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2013")])]

#text("As the above link indicates, I’ve posted a proposal for a Polymath project to systematically optimise the bound on prime gaps and to improve the understanding of the mathematics behind these results. Please feel free to contribute your opinion on that post!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232572")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("This comment is implicit in the above post, but I thought I would highlight it again. Morally speaking, the above analysis shows that the conjecture ")#mi("DHL[k_0,2]")#text(" will hold for any natural number ")#mi("k_0")#text(" for which one can find a smooth function ")#mi("g: [0,1] \\to {\\bf R}")#text(" vanishing to order at least ")#mi("k_0")#text(" at ")#mi("1")#text(" for which the inequality")

#mi("k_0 \\int_0^1 g^{(k_0-1)}(x)^2 \\frac{x^{k_0-2}}{(k_0-2)!}\\ dx > \\frac{2}{1/2 + 2\\varpi} \\int_0^1 g^{(k_0)}(x)^2 \\frac{x^{k_0-1}}{(k_0-1)!}\\ dx")#text("\\")

#text("holds ")#strike[#text("(with ")#mi("\\varpi = 1/1158")#text(")")]#text(" (with ")#mi("\\varpi = 1/1168")#text("), or equivalently if there exists a smooth function ")#mi("f: [0,1] \\to {\\bf R}")#text(" with ")#mi("f(1)=0")#text(" such that the inequality")

#mi("(1+4\\varpi) \\frac{k_0(k_0-1)}{4} \\int_0^1 f(x)^2 x^{k_0-2}\\ dx > \\int_0^1 f^{\\prime}(x)^2 x^{k_0-1}\\ dx.  (*)")

#text("(This is cheating a little bit because there is also an error term ")#mi("\\kappa")#text(" in the analysis, but this term is exponentially small and is basically negligible for the purposes of optimising ")#mi("k_0")#text(".)")

#text("Finding the optimal value of ")#mi("k_0")#text(" for which this inequality (*) holds is a calculus of variations / numerical spectral theory / ODE problem which appears to be quite computationally tractable. Right now we can obtain the value ")#mi("k_0 = 341,640")#text(" just by substituting in monomials ")#mi("f(x) = \\frac{1}{l_0} (1-x)^{l_0}")#text(", but these are not the optimal solutions and one should be able to do better, thus improving ")#mi("k_0")#text(" and hence the bound ")#mi("H")#text(" on the gap between primes.")

#emph[#text("[Edited to remove some sign conditions on g and f as they are unlikely to be essential. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232590")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Perhaps f(x) may have also negative values? (because the functional is independent of its sign)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Ah, you’re right, the condition that f be positive should not be relevant, since if f changed sign then one can replace f with its absolute value (and smooth out f a little bit where it crosses 0 to keep it smooth). So one can think of this as a pure quadratic program.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232721")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("The condition (*) above is equivalent to saying that (for given ")#mi("k_0")#text(" ) the infimum of the ratio of the right integral over the left integral in (*) is less than the factor of the left integral. Denote the above infimum by ")#mi("\\lambda")#text(" (which of course depends on ")#mi("k_0")#text("). So we need only to find this dependence which can be found as follows:")#linebreak()#text(" 1. The Euler-Lagrange equation is the following Sturm-Liouville equation")

#mi("(ay^{\\prime})^{\\prime} + \\lambda by = 0")#text(" on (0, 1)")

#text("Where ")#mi("a(x) = x^{k_0 -1}")#text(" and ")#mi("b(x) = x^{k_0 -2}")

#text("2. Note that integration by parts (using vanishing of ")#mi("ayy^{\\prime}")#text(" at 0 and 1) shows that the Lagrange multiplier ")#mi("\\lambda")#text(" is the desired infimum!")

#text("3. In order to solve the equation I used the paper “A cataloge of Sturm-Liouville differential equation” by W.N. Everitt . In page16 (Bessel equation: form 2) the solution is given (up to a multiplicative constant) by")

#mi("y(x) = x^{1- k_0 / 2} J_{k_0 - 2}(2x\\sqrt\\lambda)")

#text("Where ")#mi("J_n")#text(" are Bessel functions of the first kind (")#mi("Y_n")#text(" of the second kind also solve the equation but are avoided – to keep integrability near 0)")

#text("4. The boundary condition y(1) = 0 implies that")

#mi("J_{k_0 -2}(2\\sqrt \\lambda) = 0")

#text("This is the desired dependence of ")#mi("\\lambda")#text(" on ")#mi("k_0")#text("!")

#text("5. Since we need the least possible ")#mi("\\lambda")#text(", we denote by j_n the first positive zero of ")#mi("J_n(x)")#text(", and get")

#mi("\\lambda(k_0) = (j_{k_0 - 2})^2 / 4")

#text("Remark: In the handbook of mathematical functions (Abramowitz and Stegun) there is an asymptotic expansion of j_n (for large n)")

#mi("j_n \\sim n + 1.88557571*n^{1/3} + 1.03315*n^{-1/3} - 0.00397*n^{-1} + \\ldots")

#text("which may be useful to approximate ")#mi("\\lambda(k_0)")#text(".")

#text("6. The optimal ")#mi("k_0")#text(" is therefore the minimal ")#mi("k_0")#text(" for which ")#mi("\\lambda(k_0)")#text(" (as given above) is less than the factor of the left integral.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232727")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Great, thanks for the calculations! I think there is a very minor typo: the formula for y should actually be")

#mi("y(x) = x^{1-k_0/2} J_{k_0-2}( 2 \\sqrt{x \\lambda})")#text(".")

#text("Otherwise it seem to check out. So, inserting this optimal value into (*), and ignoring the kappa issue, we can morally get ")#mi("DHL[k_0,2]")#text(" from ")#mi("MPZ[\\varpi]")#text(" whenever")

#mi("j_{k_0-2}^2 < k_0 (k_0-1) (1+4\\varpi)")#text(". (**)")

#text("Asymptotically this gives ")#mi("k_0 \\approx \\varpi^{-3/2}")#text(", which is significantly better than the ")#mi("k_0 \\approx \\varpi^{-2}")#text(" asymptotics we currently have. I don't have easy access to software that can compute zeroes of Bessel functions here, but it should not be difficult to optimise (**) for ")#mi("\\varpi = 1/1168")#text(" and get the value of ")#mi("k_0")#text(" which should be between one and two orders of magnitude better than it is currently. (Then we have to put back in the ")#mi("\\kappa")#text(" term, but this should be fairly straightforward.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232731")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("I’m glad to see such improvement! please note also that the last correction gives the solution a definite positive limit at zero (moreover, it is positive and even analytic on the interval !)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232732")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("I get the above (**) is true for ")#mi("k_0=34429")#text(", using BesselJZeros in Maple(tm). The zero is at ")#mi("34487.401713")#text(". For ")#mi("\\omega\\sim 1/320")#text(", I get ")#mi("k_0=4790")#text(" is optimal.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232807")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Very good news! It is not yet a confirmed demonstration of ")#mi("DHL[k_0,2]")#text(" for this choice of ")#mi("k_0")#text(" because the presence of the cutoff in ")#mi("MPZ[\\varpi,\\delta]")#text(" to primes up to ")#mi("x^\\delta")#text(" introduces a small error term ")#mi("\\kappa")#text(" to the basic inequality which should be so small as to be negligible, but this needs to be checked. I will start doing so. One fact which will come in handy is that the extremiser ")#mi("y(x) = x^{1-k_0/2} J_{k_0-2}(2 \\sqrt{x\\lambda})")#text(" should be decreasing (or at least non-increasing) in x on [0,1]. I think this should be clear from variational reasons: if y is increasing and then decreasing in some region then one could reflect the portion of the graph of y above some threshold across the horizontal line associated to that threshold and obtain a superior ratio for the variational problem. It should presumably be deducible from the properties of Bessel functions or the differential equation obeyed by y as well.")

#text("While I can confirm the Bessel function computations, it would be nice to also have a way to explain the relationship ")#mi("k_0 \\sim \\varpi^{-3/2}")#text(" through some simplified asymptotic approximation to the Bessel function. Does anyone know a good asymptotic approximation to a high order Bessel function ")#mi("J_{k_0-2}")#text(" in the interval from 0 to the first zero, which has size roughly ")#mi("k_0")#text("? The asymptotics I know about work for very small arguments or very large arguments but not for arguments of the order of the first zero.")

#text("ADDED LATER: I see now that the Pintz-Revesz-Farkas paper has such an approximation, by a polynomial which (in our notation) of the form ")#mi("y(x) \\sim \\sum_{l_0} g( \\frac{l_0}{L} ) (\\frac{k_0}{2})^{l_0} \\frac{(1-x)^{k_0+l_0}}{(k_0+l_0)!}")#text(" for some cutoff function ")#mi("g")#text(" that localises ")#mi("l_0")#text(" to be comparable to some parameter ")#mi("L")#text(" which ends up being of order ")#mi("k_0^{1/3}")#text(". The verification of the asymptotics are a bit messy though, actually they end up being longer than the verification for the Bessel function!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232728")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("A small correction: in step 3 above, the solution should be")

#mi("y(x) = x^{1-k_0 / 2} J_{k_0 - 2} (2*\\sqrt{x\\lambda})")

#text("Fortunately, it has no influence on the next steps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232734")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("You have a typo, it is ")#mi("1.8557571")#text(", not ")#mi("1.88557571")#text(".")

#link("http://people.math.sfu.ca/~cbm/aands/page_371.htm")[#text("http://people.math.sfu.ca/~cbm/aands/page_371.htm")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232740")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Thanks for the correction!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232744")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Your finding is in complete agreement with a recent paper of Farkas-Pintz-Révész. See Theorem 16 in ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232757")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Thank for the information! (it gives more confidence on the result)")#linebreak()#text(" BTW, this optimization problem is somewhat unusual in the sense that it has only ONE endpoint constraint, the second constraint (necessary to make a discrete spectrum for $lambda$) is the integrability condition near 0 (which enforces the coefficient of the independent singular solution Y_{k_0 – 2} to vanish.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87b9c73bde5b0aaf898dcb44dfd94cda8891ee9da095a40da63a779c83b7e8ea-3841db76a0c5d1981882970b6dd393579be341ce5df3a8562da8db1dcf7a9dee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Commelin")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232742")[#strong[#text("Johan Commelin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Dear Terrence, that ")#mi("\\varpi")#text(" should be 1/1168, right? Instead of 1/1158.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232588")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Dear Terry, please fix the link here: “which Ben Green and I used in our papers, e.g. in this one”.")

#emph[#text("[Corrected, thanks -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D.Smith")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232596")[#strong[#text("Warren D.Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Hi Terry, the question you just asked of whether such a function f(x) exists on [0,1], is if we make f(x) be a fixed-finite-degree polynomial with")#linebreak()#text(" undetermined coefficients, a QUADRATIC PROGRAMMING problem, which")#linebreak()#text(" available software will solve.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b0bc4ff58e9f725174d6883325394b25e77602bbe15bf5b0163662478631940-f56b943efc2c39cd8c3be04dbf21fde6993535ed9ed28bcbb4b779f016bca753.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Warren D.Smith")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232598")[#strong[#text("Warren D.Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Well actually your demand f(x)>0 for every x with 0<x<=1 is an infinite")#linebreak()#text(" number of constraints (one for each x) and further if I did not restrict the polynomial degree it would be an infinite dimensional quadratic program. However, adaptive finite sets of constraints should approximate it fine (kind of like Remez algorithm in approximation theory…) so this should be no problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232599")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Small corrections to the proof of Lemma 7, namely that (ii) implies (i). We need to choose ")#mi("x_n")#text(" so large")#linebreak()#text(" that ")#mi("w_0(x)\\geq w_n")#text(" for ")#mi("x\\geq x_n")#text(", otherwise (ii) cannot be invoked.")#linebreak()#text(" In addition, ")#mi("w(x)")#text(" should be ")#mi("1")#text(" not for ")#mi("x<x_n")#text(" but for ")#mi("x<x_1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232600")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("When you defined the singular series, you wrote ")#mi("{{\\mathcal H} = {\\mathfrak G}({\\mathcal H})}")#text(" instead of ")#mi("{{\\mathfrak G} = {\\mathfrak G}({\\mathcal H})}")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232603")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Sorry, how do you include latex in these comments (for the future?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232605")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Read “For commenters” on the bottom left corner of this page. I missed that, too!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232612")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("A technical comment: The parameter ")#mi("\\varpi")#text(" appears in two separate places in the conjecture ")#mi("MPZ[\\varpi]")#text(" (Conjecture 12 above); firstly (and most importantly) in the threshold ")#mi("x^{1/2+2\\varpi}")#text(" for ")#mi("q")#text(", and secondly as the upper bound for the interval ")#mi("I=(w, x^\\varpi)")#text(" of primes involved. For the purpose of optimising bounds, it may make sense to split this parameter into two, thus let ")#mi("MPZ[\\varpi,\\delta]")#text(" be as in Conjecture 12 but with the interval ")#mi("I=(w,x^\\varpi)")#text(" replaced by ")#mi("I=(w,x^\\delta)")#text(". The analysis in the above post continues to then give ")#mi("DHL[k_0,2]")#text(" assuming the same condition")

#mi("1+4\\varpi > (1 + \\frac{1}{2l_0+1}) (1 + \\frac{2l_0+1}{k_0}) (1+\\kappa)")

#text("as before, but the quantity ")#mi("\\kappa")#text(" should now be replaced by")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0/2 + l_0} \\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j})) ).")

#text("This quantity is still exponentially small for ")#mi("\\delta")#text(" as small as ")#mi("O(1/k_0)")#text(". So rather than prove ")#mi("MPZ[1/1168,1/1168]")#text(" as Zhang does, it may be numerically more advantageous to prove ")#mi("MPZ[\\varpi,\\delta]")#text(" with ")#mi("\\delta")#text(" very close to zero in order to raise the value of ")#mi("\\varpi")#text(". Currently, Zhang proves ")#mi("MPZ[\\varpi,\\varpi]")#text(" whenever ")#mi("31/32 + 36 \\varpi < 1 - \\varpi/2")#text("; it seems like a good idea to trace through his argument for ")#mi("MPZ[\\varpi,\\delta]")#text(" instead and see how many of the ")#mi("\\varpi")#text("'s in the above expression are actually ")#mi("\\delta")#text("'s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232613")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("In Section 3, in the first two displays there should be no ")#mi("\\log x")#text(" on the right hand side, because ")#mi("\\Lambda(n)")#text(" is included on the left hand side.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232615")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("In the display before (11), ")#mi("D")#text(" should be ")#mi("R")#text(" on the right hand side.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Online reading seminar for Zhang’s “bounded gaps between primes” | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232620")[#strong[#text("Online reading seminar for Zhang’s “bounded gaps between primes” | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("[…] obtained for . The current best value of is , as discussed in this previous blog post. To get from to Theorem 1, one has to exhibit an admissible -tuple of diameter at most . For […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232625")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("Also, ")#mi("D")#text(" should be ")#mi("R")#text(" in the first two displays of Section 2.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232738")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2013")])]

#text("In Remark 1, ")#mi("[d_1,d_2]")#text(" should be ")#mi("q")#text(". In Remark 2, ")#mi("\\frac{(k_0-2)^2}{2}")#text(" should be ")#mi("\\frac{(k_0-2)^2}{4}")#text(". In (19), there should be no ")#mi("\\log x")#text(" in the denominator. Finally, to also add some content, the finding of Eytan Paldi above is in complete agreement with a recent paper of Farkas-Pintz-Révész. The best constant in (17) is given by Theorem 16 in ")#link("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")[#text("http://www.renyi.hu/~revesz/ThreeCorr0grey.pdf")]

#emph[#text("[Corrected, thanks! – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232833")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Dear Terry, somehow my last corrections did not materialize (Remark 1, Remark 2, and (19)) although you said you made the corrections.")

#emph[#text("[Sorry, they should appear now. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232840")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("OK, I have now updated the main text to add a criterion for deducing ")#mi("DHL[k_0,2]")#text(" from ")#mi("MPZ[\\varpi,\\delta]")#text(" which should get very close to v08ltu’s value of ")#mi("k_0 = 34,429")#text(". Unfortunately it is conditional on the following conjecture:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("CONJECTURE")]#text(": the function ")#mi("f(x) := x^{1-k_0/2} J_{k_0-2}(\\sqrt{x})")#text(" is convex on ")#mi("[0,j_{k_0-2}^2]")#text(", i.e. ")#mi("f^{\\prime\\prime}(x) \\geq 0")#text(" on this interval.")
]

#text("I can confirm this conjecture numerically for small ")#mi("k_0")#text(" but do not yet have a rigorous proof of it for large ")#mi("k_0")#text(" (e.g. ")#mi("k_0 = 34,429")#text("). It is not absolutely essential to have this conjecture in order to get a criterion, but it would be a much messier criterion if this were not the case.")

#text("Anyway, assuming this conjecture, we get ")#mi("DHL[k_0,2]")#text(" whenever")

#mi("1+4\\varpi > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")

#text("where ")#mi("\\kappa")#text(" is the quantity")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0/2} \\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j})) )")#text(".")

#text("In the past, ")#mi("\\kappa")#text(" has been exponentially small; now that ")#mi("k_0")#text(" is a fair bit smaller than it was before, it may not be quite as small as it was before, but it should still have a fairly miniscule impact on the final value of ")#mi("k_0")#text(". (There is a bit of slack in the estimation of ")#mi("\\kappa")#text(" in any case; it was not important to optimise it previously since it was already so tiny, but maybe we will have to do so soon.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232843")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("For ")#mi("\\omega=\\delta=1/1168")#text(" and ")#mi("k_0=34429")#text(", I get that ")#mi("\\kappa\\sim 1.21\\cdot 10^{-8}")#text(". Yet I agree that soon improvements will hit a barrier here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232844")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Incidentally if you take ")#mi("\\delta=1/2\\omega")#text(", then the above ")#mi("\\kappa")#text(" increases to ")#mi("0.03")#text(", and by the time ")#mi("\\delta=1/3\\omega=1/3504")#text(", it is about ")#mi("\\kappa\\approx 114")#text(". So I think one cannot ")#mi("\\delta")#text(" too small.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232848")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("On the other hand, my current best practice in estimation is that we will need essentially ")#mi("40\\omega+\\delta\\le 1/8")#text(", which is not attenuated much on ")#mi("\\delta")#text(". Say ")#mi("\\omega\\sim 1/336")#text(" and ")#mi("\\delta=1/168")#text(" for effect (the ratio of 2 here is highly accidental). Then you win at at 5165. Taking ")#mi("\\omega\\sim 1/330")#text(" and ")#mi("\\delta=1/264")#text(" I think you win at ")#mi("k_0\\sim5070")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232855")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I checked the constraint ")#mi("1 + 4\\varpi > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")#text(" for ")#mi("k_0 = 34429")#text(" and v08ltu’s value of ")#mi("\\kappa")#text(", and confirmed that ")#mi("k_0=34,429")#text(" obeys the criterion (barely!). So as long as we have the conjectued convexity of ")#mi("x^{1-k_0/2} J_{k_0-2}(\\sqrt{x})")#text(" for this value of ")#mi("k_0")#text(", we have confirmed ")#mi("DHL[34429,2]")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232872")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Sounds great. Out of curiosity: what is the smallest ")#mi("k_0")#text(" we obtain with this ")#mi("g")#text(" under Elliott-Halberstam? The original construction of GPY gave ")#mi("k_0=6")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232917")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Unfortunately ")#mi("k_0=5")#text(" still seems out of reach: we need ")#mi("j_{k_0-2}^2 / (k_0(k_0-1))")#text(" to be less than 2 for the method to work on Elliott-Halberstam, and for ")#mi("k_0=5")#text(" this is 2.03532… – a touch too big.")#linebreak()#text(" (For ")#mi("k_0=6")#text(", this quantity is 1.9194… instead.) Some really clever new idea is probably needed to get further here even on EH; I’m sure GPY and the other people in the area have tried all the obvious things here by this point.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232846")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("A very minor remark: there seem to be a small typo in line 4 (34.429 instead of 34,429)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232888")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("The Conjecture is now proved, see my response below.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232850")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("In one of the comments above (form 4 June, 2013 at 8:13 am) it was written that an error term ")#mi("k")#text(" should appear but it should be exponentially small. Something similar was written in a comment (June 5, 2013)")#linebreak()#text(" in the relevant post of Scott Morrison (from May 30, 2013) mentioned above. Is it possible to give more details on this issue? In particular, to explain why and where this error term appears? And is there any argument or proof showing that this error term must be exponentially small or at least sufficiently small so it will not affect the final value of ")#mi("k_0")#text("?")

#text("Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232851")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("The error term (which, incidentally is denoted ")#mi("\\kappa")#text(" (kappa) rather than ")#mi("k")#text(") is not present in the original work of Goldston-Pintz-Yildirim (Section 3 in the blog post) but arises in the modification of the Goldston-Pintz-Yildirim argument due to Motohashi-Pintz and Zhang (Section 4, see also the updated version at Section 5). Motohashi, Pintz, and Zhang modify the Goldston-Pintz-Yildirim sieve by throwing out all numbers that are divisible by large primes (primes larger than a certain threshold ")#mi("\\delta")#text("). It is necessary to discard these primes in order to have a chance of proving the input conjecture ")#mi("MPZ[\\varpi,\\delta]")#text(" (otherwise one has to prove the much more difficult conjecture ")#mi("EH[\\theta]")#text(", which remains open). But by throwing out these numbers one enlarges the sieve by a small factor ")#mi("\\kappa")#text(" (a precise formula for this quantity is now given in my previous comment at 9:53 am). In practice this quantity ")#mi("\\kappa")#text(" is very small (it is about ")#mi("k_0 \\exp( - k_0 \\delta )")#text(") although, ironically, because we have been making so many improvements in the ")#mi("k_0")#text(" factor, the error ")#mi("\\kappa")#text(" is not as small as it used to be, and we may soon have to take a look at optimising ")#mi("\\kappa")#text(" further in order to get the best results.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232856")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Thanks for the information. I have missed some details in previous readings. By the way: does the derivation of ")#mi("\\kappa")#text(" from equation (30) depend on the partly conjectured Lemma 15? And is the value ")#mi("\\alpha")#text(" which is mentioned above equation (30) optimal or perhaps better values can be obtained? And is there any estimation on the ")#mi("o(1)")#text(" term in the inequality above ")#mi("\\alpha")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232867")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Yes, at present the value of ")#mi("\\kappa")#text(" in (30) presumes Lemma 15; without it one would get a messier expression for ")#mi("\\kappa")#text(". There is certainly scope for improvement in the bound for ")#mi("\\kappa")#text(" (in particular, the factors of 2 and 3 appearing there might be removable with a finer analysis), though we are not yet at the regime where this leads to decisive improvements in the final bounds.")

#text("The o(1) term goes to zero as x goes to infinity; since the conjecture ")#mi("DHL[k_0,2]")#text(" is only an asymptotic assertion (as is the assertion that there are infinitely many prime gaps of size at most H), the o(1) term can be utterly neglected for the purposes of optimising k_0 or H. (It would however be important for the question of obtaining quantitative estimates on how often these prime gaps occur.) The way the argument in this blog post is set up, particularly with its reliance on the W-trick, the decay rates on the o(1) factor will be terrible. (There is some discussion on quantitative bounds at the end of this recent paper of Pintz: ")#link("http://arxiv.org/abs/1305.6289")[#text("http://arxiv.org/abs/1305.6289")]#text(" .)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232871")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("**(It would however be important for the question of obtaining quantitative estimates on how often these prime gaps occur.)**")

#text("As it currently stands pedantically, Zhang uses ineffective Bombieri-Vinogradov. As noted in Section 12 of GPY Primes in Tuples II, one can circumvent Siegel zeros, due to the result of Heath-Brown that they (in in a suitable sense) imply infinitely many prime twins.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abc530355ca859abdf45e1983c5d0aa71a49963c398110ff56153a766213e9a-9562b5bf2e84d8146d1785c2938ab925d2df24c41f84c2d978f6cd4abda9612a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Reem")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232881")[#strong[#text("Daniel Reem")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Thanks again. Here is a minor question before l will probably take a break (I apologize in advance if I miss something trivial here!):")#linebreak()#text(" Are there any assumption or known estimates on ")#mi("\\delta")#text(" which ensure, in particular, that the number of terms ")#mi("n")#text(" in (30) is at least 1?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4c0ce8b668c58de579ed07eee7de917198e3e98ba28bcd5a6da914b9e4fa577-af89841539159a61bffcba5ec713db3bb63dff5680102a6f50a30e53587496e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JamesM")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232873")[#strong[#text("JamesM")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("A couple of quick comments:")

#text("If instead of taking ")#mi("\\lambda(n)=\\sum\\mu(d)g(\\log{d}/\\log{R})")#text(" as above (which one typically estimates with complex integrals), you can diagonalise the sum using the `elementary method’ which goes back to Selberg. This produces the same asymptotic expressions, but at least in the case ")#mi("g(x)=x^{k_0+l_0}/(k_0+l_0)!")#text(" it allows for a slightly simpler argument to bound the error term ")#mi("\\kappa")#text(", which might be useful if ")#mi("\\kappa")#text(" is no longer trivially small.")#linebreak()#text(" (I got something like ")#mi("\\kappa\\le (1+4\\varpi)^{-(k_0+2l_0)/2}\\log{1/(4\\varpi)}+k(1+4\\varpi)^{-(k_0+2l_0)}\\log{1/(4\\varpi)}")#text(" for ")#mi("g(x)=x^{k_0+l_0}/(k_0+l_0)!")#text(")")

#text("I think, however, that ")#mi("k_0\\exp(-k_0\\delta)")#text(" is roughly the right order of magnitude of ")#mi("\\kappa")#text(", and beyond this one would want to use approximate asymptotic formulae. Instead of obtaining ")#mi("\\int_0^1 g^{(k_0)}(x)^2 x^{k_0-1}dx")#text(" with the error ")#mi("\\kappa")#text(", one would obtain ")#mi("\\delta^{k-1}\\int_0^1 g^{(k_0)}(x)^2 f^{\\prime}_{k_0}(x/\\delta) dx/k")#text(", where ")#mi("f_k")#text(" is defined by the delay-differential equation")#linebreak()#text(" ")#mi("f_k(x)=x^{k},\\qquad\\text{if }0\\le x\\le 1,")#linebreak()#text(" ")#mi("x f_k^{\\prime}(x)=k f_k(x)-k f_k(x-1),\\qquad\\text{if }1\\le x.")#linebreak()#text(" This might be useful in dealing with the terms if ")#mi("k_0")#text(" becomes small.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232877")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("I believe the conjecture ")#mi("x^{1-k_0/2}J_{k_0-2}(\\sqrt{x})")#text(" follows from the fact that its second derivative equals ")#mi("\\frac{1}{4}x^{-k_0/2}J_{k_0}(\\sqrt{x})")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232884")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Some details on this claim: by the usual Taylor series expansion of the ")#mi("J")#text("-Bessel function, ")#mi("x^{-k/2}J_k(\\sqrt{x})=\\sum_{m=0}^\\infty\\frac{(-1)^mx^m}{2^{2m+k}m!(m+k)!}")#text(", hence differentiating twice yields the same expression times ")#mi("\\frac{1}{4}")#text(", with ")#mi("k")#text(" replaced by ")#mi("k+2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232887")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Great! That was easier than I expected. So it looks like ")#mi("k_0 = 34,429")#text(" is now confirmed! I will pass this on to the “H” team. :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232886")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("To finish the proof of the Conjecture (in order to take ")#mi("k_0=34,429")#text("), it suffices to show that the first zero of ")#mi("J_{k_0-2}")#text(" precedes the first zero of ")#mi("J_{k_0}")#text(". This follows from the more general fact that the zeros of the ")#mi("J")#text("-Bessel functions are interlaced, see Section 15.22 in Watson: A treatise on the theory of Bessel functions (2nd ed., Cambridge University Press, 1944).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232889")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("In the proof of theorem 14, the definition of g_0 after (27) applies only for the interval [0, 1) – so the integration by parts is somewhat more delicate (exploiting the fact that g_0 as a logaritmic derivative of the entire function f_0 has a SIMPLE pole at 1, so the result follows from the fact that a*g_0*f^2")#linebreak()#text(" tend to zero at the endpoints.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232891")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Ah, that’s a good point; I’ve updated the blog post to reflect this subtlety (and also to incorporate Gergely’s nice proof of the convexity).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233003")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("A minor correction: After (27), f_0 is non-vanishing over [0, 1) (not [0, 1]) – so g_0 is well defined only over [0, 1).")#linebreak()#text(" (BTW, the identity about Q(f) is of “Wirtinger type” – see e.g. the remarks about Wirtinger’s inequality in section 7.7 of “inequalities” by Hardy, Littlewood and Polya)")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232899")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("Actually the interlacing of zeroes argument yields a generalization of Lemma 15 (with a simpler proof): on ")#mi("[0,1)")#text(", the ")#mi("n")#text("-th derivative of ")#mi("f_0")#text(" has sign ")#mi("(-1)^n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233187")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("In fact, using your idea of differentiating the Taylor series of f_0 (x), it is easy to verify that its n-th derivative is")

#mi("(-2)^{-n} x^{1 - (k_0 n) / 2} J_{k_0 n - 2} (\\sqrt{\\lambda  x})")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233246")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("You probably meant ")#mi("k_0+n")#text(" in place of ")#mi("k_0n")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233248")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Somehow it was printed with that typo, as you see I just sent a correction.")#linebreak()#text(" (Thanks for seeing that!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233247")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("A minor typo: Instead of k_0*n (both in the exponent of x and the order of J) it should be k_0 + n.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232902")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")])]

#text("A small remark regarding the ")#mi("\\kappa")#text(" issue: the Motohashi-Pintz-Zhang restriction of the GPY sieve to smooth numbers enlarges the sieve, and thus increases the quantity ")#mi("\\alpha")#text(" (roughly speaking this measures the density of the sieve) by the factor ")#mi("1+\\kappa")#text(". But it also increases the quantity ")#mi("\\beta")#text(" (roughly speaking the normalised density of primes shifted by h in the sieve) by more or less the same factor ")#mi("1+\\kappa")#text(". This increase is simply discarded in the current analysis, but if we really had to we could compute very precisely the kappa-factor on both the alpha and beta sides of the key inequality (11), and so it is conceivable that in the final analysis kappa more or less cancels itself out and is thus much less of a problem than feared.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-232963")[#strong[#text("More narrow admissible sets | Secret Blogging Seminar")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2013")]

#text("[…] A reading seminar on Zhang’s Theorem 2. 2) A discussion on sieve theory, bridging the gap begin Zhang’s Theorem 2 and the parameter k_0. 3) Efforts to find narrow […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233136")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("I just noticed this new preprint by János Pintz, ")#link("http://arxiv.org/abs/1306.1497")[#text("http://arxiv.org/abs/1306.1497")]#text(", where he proves that ")#mi("\\varpi=\\frac{1}{488}")#text(" is admissible in place of Zhang’s ")#mi("\\varpi=\\frac{1}{1168}")#text(". This allows him to take ")#mi("k_0=60000")#text(". What value for ")#mi("k_0")#text(" do we get by using the optimized GPY weights of Theorem 14?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233145")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("In our notation, Pintz proves ")#mi("MPZ[ \\varpi, \\delta]")#text(" with ")#mi("\\varpi = \\frac{1}{488}")#text(" and ")#mi("\\delta = \\frac{3}{19} \\varpi = \\frac{3}{9272}")#text(". So we have to minimise ")#mi("k_0")#text(" such that")

#mi("1+4\\varpi > \\frac{j_{k_0-2}^2}{k_0(k_0-1)} (1+\\kappa)")

#text("where ")#mi("\\kappa")#text(" is the quantity")

#mi("\\kappa := \\sum_{1 \\leq n < \\frac{1+4\\varpi}{2\\delta}} (1 - \\frac{2n \\delta}{1 + 4\\varpi})^{k_0/2} \\prod_{j=1}^{n} (1 + 3k_0 \\log(1+\\frac{1}{j})) )")#text(".")

#text("I’ll fire up Maple and try to figure this out (starting by solving the easier ")#mi("\\kappa=0")#text(" problem and then increasing ")#mi("k_0")#text(" if necessary), but perhaps some independent confirmation would be good to have as well. Certainly we can already do better than Pintz’s k_0=60,000, being currently at 34,429 (Pintz uses the older style monomials instead of the Bessel function).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233147")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Well, unfortunately ")#mi("\\kappa")#text(" is now big enough to cause a problem again, in large part because Pintz took ")#mi("\\delta")#text(" to be so small; without ")#mi("\\kappa")#text(" we could take ")#mi("k_0")#text(" as low as 9128, but ")#mi("\\kappa")#text(" is huge then. In fact even with our current value of ")#mi("k_0=34,429")#text(", ")#mi("\\kappa")#text(" is roughly of order 1, so in fact we get no gain at all! But this is an artificial problem for two reasons; firstly we can do better with kappa; and secondly it should be possible to analyse Pintz’s preprint (only 9 pages) to extract exactly what is required on ")#mi("\\varpi,\\delta")#text(" and we can do a multivariable optimisation in ")#mi("\\varpi, \\delta, k_0")#text(" to proceed. I’ll go through Pintz’s paper now and see what we get…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233149")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("OK, so Pintz’s conditions on ")#mi("\\varpi")#text(" and ")#mi("\\delta")#text(" (the latter he calls ")#mi("\\eta")#text(") are")

#mi("\\delta \\leq \\varpi \\leq 1/200")

#text("and")

#mi("\\frac{119}{4} \\varpi + \\frac{19}{4} \\delta < \\frac{1}{16}")#text(".")

#text("If we set ")#mi("\\delta=\\varpi")#text(", we can get ")#mi("\\varpi=\\delta=\\frac{1}{552}-")#text("; this makes ")#mi("\\varpi")#text(" a little worse than Pintz's value of ")#mi("1/488")#text(", but ")#mi("\\delta")#text(" is six times better which will help substantially with our current setup. Back to Maple…")

#text("Incidentally, the last section of Pintz suggests that one should be able to take ")#mi("\\kappa = \\frac{1}{\\delta} \\exp( - k_0 \\delta )")#text(", which is a little bit better than our current value (which is more like ")#mi("3 \\ln(2) k_0 \\exp( - k_0 \\delta )")#text("), but I don't know how much this will help us.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233151")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("OK, I computed that ")#mi("k_0=11123")#text(" works with this choice, but it would be good to get some confirmation. ")#mi("\\kappa")#text(" is relatively small here (about ")#mi("4 \\times 10^{-5}")#text(") but this is still enough to have some impact; without ")#mi("\\kappa")#text(" one could lower ")#mi("k_0")#text(" to ")#mi("11015")#text(". So it looks like it is time to work on bounding ")#mi("\\kappa")#text(" again!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233167")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("I worked through the details of the Motohashi-Pintz sieve as used in Pintz’s most recent paper (it’s similar to what JamesM described in a previous comment). It seems to work fine if we replace the monomial weights by Bessel weights. it appears that the key inequality now becomes")

#mi("(1+4\\varpi) (1-\\kappa) > \\frac{j_{k_0-2}^2}{k_0(k_0-1)}")

#text("with")

#mi("\\kappa = \\frac{1}{\\delta} \\exp(-k_0 \\delta)")#text(".")

#text("With this, ")#mi("\\kappa")#text(" becomes smaller again and one should be able to reach ")#mi("k_0 = 11015")#text(" with ")#mi("\\varpi=\\delta=1/552")#text(" [EDIT: not quite; Maple reports one gets down to 11018 instead]; and by optimising subject to the constraints ")#mi("\\delta \\leq \\varpi \\leq 1/200")#text(" and ")#mi("\\frac{119}{4} \\varpi + \\frac{19}{4} \\delta < 1/16")#text(" one should be able to get a little better still.")

#text("I'll try to write up the details of the Motohashi-Pintz sieve in a separate blog post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233172")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("As far as I can tell, there is no real reason to take ")#mi("\\delta")#text(" less than ")#mi("\\omega")#text(". In the 1/200 part, Pintz is just writing down something that works. In fact, in 2.8 and 2.13 he copies what I think is an error in Zhang, namely ")#mi("Q^6")#text(" when I get ")#mi("Q^7")#text(". This leads into the right half of the max in 2.18, but I don’t think it matters as one wins easily enough in this comparison of the 2.18 components to the ")#mi("1/2-7\\omega-\\eta")#text(" of 2.19. You should really compare the 2.18 exponents to those in 2.19, rather than use the convenient 1/200 and ")#mi("\\delta\\le\\omega")#text(" statements.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233174")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("For that matter, although I would trust Pintz over myself at this point, I am not sure why he merely imports Zhang’s (7.2) ")#mi("R\\sim N/x^{3\\omega+\\eta}")#text(" in this 2.19 statement (maybe “3” can be 2+epsilon by choosing ")#mi("R^\\star")#text(" more subtly?), other than that this is the Type II border, and earlier he indicated that only Type I was critical. Maybe even the ")#mi("N\\ge x^{1/2-4\\omega}")#text(" as the Type I/II frontier as used in 2.19 could be changed if needed. But since he expects to win here by a margin, there is no need to optimize, is my conclusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233178")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("If I understand the game correctly, I can take ")#mi("(\\omega,\\delta,k_0)=(1/538,1/660,10721)")#text(" and win. Note that taking ")#mi("\\delta\\ge \\omega")#text(" is not going to help anyways.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233182")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Slight improvement, ")#mi("(\\omega,\\delta,k_0)=(1/538,31/20444,10719)")#text(". From what I can tell, this ")#mi("\\omega")#text(" is at least a local optimum, and ")#mi("k_0=10718")#text(" cannot be had.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233237")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Great! Are you using the Motohashi-Pintz sieve formulation (with ")#mi("\\kappa = \\delta \\exp(-k_0 \\delta)")#text(" instead of the clunkier value I had in my blog post?). Also, if you could make explicit precisely the linear constraints on ")#mi("\\omega,\\delta")#text(" that you have extracted from Pintz’s paper that would be useful for future optimisation (I take it that you have deleted the constraint ")#mi("\\delta \\leq \\varpi \\leq 1/200")#text(", but kept the main constraint ")#mi("\\frac{119}{4} \\varpi + \\frac{19}{4} \\delta < \\frac{1}{16}")#text("? Since you mentioned a possible correction to Zhang/Pintz, it would be good to update what the constraints are here.")

#text("Basically, it looks like Pintz has done our near-term work for us in that he has optimised Zhang's argument in the parameters ")#mi("\\varpi,\\delta")#text(" that we were beginning to optimise in. It seems the next major improvement will have to come from somehow reducing the number of Cauchy-Schwarz steps in the analysis (which is something Ben and I are looking forward to, having some experience in that area…).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233266")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Yes, I just plugged into exactly the formula you listed at 11:35pm, eventually figured out that one simply sets ")#mi("\\delta=(1/19)(1/4-119\\omega)")#text(" and then just minimized ")#mi("k_0")#text(" wrt ")#mi("\\omega")#text(". I think Pintz is probably correct. He gets the 1/16 that I now determine shows up (which Zhang also has, though he writes the argument after Cauchy and has 31/32) from the “critical” case that Ben Green and Kowalski have both mentioned, and I don’t doubt that he counted the multiples of ")#mi("\\omega")#text(" correctly given the efforts he made. He seems to have solved for the Type I/III barrier (which is the crucial one, as he says) based on the last line of 2.6 (spilling to the top of page 4) and 2.40 just setting the inequalities to be equalities and solving ")#mi("a")#text(". I strongly suspect that any glitches elsewhere are irrelevant (for instance, 9.9 in Zhang I get ")#mi("N^{-3\\omega}")#text(" not ")#mi("x^{-3\\omega}")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e579fa60f06b2b355ef3edabbae6dec6d9e7a0eed71c6645929e8f327d820eed-ba4a4594e7b47094d4631d6c89616486cc2038fed96e37cd81c7d89edceb3a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233150")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2013")])]

#text("Maple tells me that ")#mi("\\kappa=0.005584095042")#text(", so the inequality is only true for ")#mi("k_0\\geq 52295")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233241")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("You probably miscalculated. For ")#mi("k_0=11015")#text(" and ")#mi("\\delta=\\frac{1}{552}")#text(" we get ")#mi("\\kappa=\\frac{1}{\\delta}\\exp(-k_0\\delta)=1.19047\\times 10^{-6}")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233242")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("I think Michael was using the older formula for ")#mi("\\kappa")#text(" which was somewhat less efficient than the new formula ")#mi("\\kappa = 1/\\delta \\exp(-k_0\\delta)")#text(", being about one to two orders of magnitude times bigger it seems in current ranges of ")#mi("k_0,\\varpi,\\delta")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233310")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Pintz from 2.35 to 2.39 (the key part) is a bit hard to parse. What he wants to say in 2.39 is that 2.35 is satisfied if ")#mi("R= x^{1/16+3a/2-6\\omega}\\ll N_1J/L")#text(" but it comes out garbled IMO.")

#text("Also, it is wrong. He should have ")#mi("5a/2")#text(" in 2.39, not ")#mi("3a/2")#text(" (compare, one subtracts the exponents in 2.37 and 2.38, getting ")#mi("4-(-2)=6")#text(" for ")#mi("\\omega")#text(", so should be ")#mi("2-(-1/2)=5/2")#text(" for ")#mi("a")#text(", not 3/2 as asserted).")

#text("So I only get ")#mi("1/4\\ge 141\\omega+25\\delta")#text(" as the critical inequality now (I think his choice of ")#mi("a")#text(" is already optimal, but am not sure). Back to the optimization technique…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233311")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Actually, I got subtraction mixed up. It should even be ")#mi("-5a/2")#text(" not ")#mi("3a/2")#text(" (Pintz gets the sign wrong too), so now I have ")#mi("1/4\\ge 207\\omega+43\\delta")#text(". So Pintz is really not gaining that much over Zhang in the end (if I am correct). In short, he should be subtracting exponents (2.38) minus (2.37), but he adds the ")#mi("a")#text("-parts (and it seems that 2.38 is correct as written, though its input 2.20 has an obvious typo, not putting the RHS in an exponent).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233314")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("PS, this latter statement matches what I got from a rudimentary (ignore ")#mi("\\delta")#text(") plugging in of the “critical” case into Ben Green’s analysis on the Reading seminar page, which I also determined was equivalent to what Pintz had written before his error (in fact, I ran across the Pintz problem trying to reconcile).")

#text("There one gets (after multiplying BG’s ")#mi("\\omega")#text(" by 2) that ")#mi("16\\omega\\ge 4\\nu_1+4\\nu_2+5\\nu_3-4-\\delta")#text(", and with ")#mi("\\nu_i\\sim 5/16-11\\omega/4")#text(" from Type I/III Pintz optimization (w/o ")#mi("\\delta")#text("‘s), you do indeed (w/o ")#mi("\\delta")#text("‘s) get ")#mi("16\\omega\\ge 13(5/16-11\\omega/4)-4=1/16-143\\omega/4")#text(", or ")#mi("207/4\\omega\\ge 1/16")#text(" as my re-do of Pintz derived.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233245")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Since the exponents ")#mi("\\omega")#text(" and ")#mi("\\delta")#text(" obey linear inequality constraints, it seems that the minimization of ")#mi("k_0")#text(" (with respect to these two exponents or “control parameters”) is at an edge of the “admissible polygon” for them – which may explain their rational values?")#linebreak()#text(" (this happens if the minimal k_0 as a function of (")#mi("\\omega")#text(",")#mi("\\delta")#text(") is CONCAVE, otherwise the optimal exponents can be in the interior of the polygon – and even may be irrational!)")#linebreak()#text(" In any case, I suggest to first try the exponent pairs on the edges of the admissible polygon, and later try to see if ")#mi("k_0")#text(" may be improved inside the polygon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233251")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Perhaps, it is better to first try as exponent pairs the vertices of the admissible polygon for them")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233257")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Just checking if I understand the optimal ")#mi("g:[0,1]\\to\\mathbf{R}")#text(" right. It should vanish to order ")#mi("k_0")#text(" at ")#mi("x=1")#text(", and its ")#mi("(k_0-1)")#text("th derivative should be ")#mi("f_0")#text(". The second condition implies that ")#mi("g(x)=p(x)+c\\sqrt{x}J_1(j_{k_0-2}\\sqrt{x})")#text(", where ")#mi("p")#text(" is a polynomial of degree at most ")#mi("k_0-2")#text(". We can choose ")#mi("p")#text(" so that ")#mi("g")#text(" vanishes to order ")#mi("k_0-1")#text(" at ")#mi("x=1")#text(", and then ")#mi("g^{(k_0-1)}=f_0")#text(" implies that in fact ")#mi("g")#text(" vanishes to order ")#mi("k_0")#text(" at ")#mi("x=1")#text(". Am I right? Also, do we really need ")#mi("p")#text(" for ")#mi("g")#text(" to work?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233297")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Yes, this should be the right choice for ")#mi("g")#text(", with ")#mi("p")#text(" being the Taylor polynomial at ")#mi("x=1")#text(" needed to enforce the vanishing. It makes for a rather strange formula for ")#mi("g")#text(" but I think this is an artefact of the choice of sieve; the elementary Selberg sieve works directly with ")#mi("f_0")#text(" rather than ")#mi("g")#text(" (I’m in the process of writing up the details).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233302")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Thank you! Writing up means the new blog entry that will also incorporate/describe Pintz’s improvement? At any rate, I look forward to it!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233321")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("If my statements about the error in Pintz are correct, then under the constraint ")#mi("207\\omega+43\\delta\\le 1/4")#text(", the best I find is ")#mi("\\omega=1/942")#text(" and ")#mi("k_0=25111")#text(". Of course ")#mi("\\delta=19/27004")#text(" here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233323")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("I think there is little choice here but to work through the Type I and II analyses in the same way as for the Type III – hopefully the dependence of these parameters will then become crystal clear. It will happen in time….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233338")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("I noticed that for your optimal ")#mi("\\omega")#text(" and ")#mi("\\delta")#text(" the inequality constraint becomes equality. Is there any reason for that? (Perhaps k_0 as a function of these two parameters is concave?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233346")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("I think someone familiar with the details could/should simply ask Pintz.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233419")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("By the way, do you know if there are still any further constraints on ")#mi("\\varpi, \\delta")#text(" beyond the condition ")#mi("207 \\varpi + 43 \\delta \\leq 1/4")#text(" and ")#mi("\\varpi, \\delta > 0")#text("? I know that the condition ")#mi("\\delta \\leq \\varpi \\leq 1/200")#text(" has been deleted but I wanted to confirm that there are no other conditions which are not already implied by the ones above.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233459")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("There is some upper bound on ")#mi("\\omega,\\delta")#text(", for else Type I/III would not be the important barrier (rather Type II would invade), but I think it is so large (like 1/200) that it makes no difference. The quirky ")#mi("\\delta\\le\\omega")#text(" is convenient but not needed, and is satisfied anyway for optimal parameters.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233469")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Terry, it seems as though ")#mi("207 \\varpi + 43 \\delta \\leq \\frac{1}{4}")#text(" is by far the strongest condition these parameters need to satisfy. It comes from the boundary between the Type I and III conditions. I’ve put details of all these computations over at the other blog.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("I’m encountering some difficulty verifying a claim in the most recent paper of Pintz ")#link("http://arxiv.org/pdf/1306.1497v1.pdf")[#text("http://arxiv.org/pdf/1306.1497v1.pdf")]#text(" , as well as a related claim in an earlier paper of Motahashi and Pintz ")#link("http://arxiv.org/pdf/math/0602599v1.pdf")[#text("http://arxiv.org/pdf/math/0602599v1.pdf")]#text(" , regarding the value of kappa. (This is unrelated to the issues that v08ltu has raised recently in the Pintz paper). In particular, in (3.1) the most recent Pintz paper it is claimed that kappa is as small as")

#mi("k \\sum_{R^\\eta < p < R} \\frac{1}{p} (1 - \\frac{\\log p}{\\log R})^{k+2\\ell}")

#text("which can be bounded above by ")#mi("\\frac{1}{\\eta} e^{-(k+2\\ell)\\eta}")#text("; there is also a closely related claim in (5.14)-(5.15) of Motohashi-Pintz, in which it is claimed that the quantity ")#mi("{\\mathcal T}^{**}")#text(" given by (5.14) can be estimated by the quantity in (5.15) (and the latter Pintz paper refers to this step of the Motohashi-Pintz paper to justify the claim (3.1) of the Pintz paper).")

#text("However, I can't figure out how Motohashi and Pintz get from (5.14) to (5.15), because (5.14) contains a difference of two summations, and the main terms from both terms (after applying arguments analogous to (4.12)-(4.15) as suggested in the text) largely cancel each other out, leading to an expression that is smaller than claimed in (5.15), in which (after ignoring terms of size ")#mi("O(e^{-k\\omega/3})")#text(" of the main terms) the factor")

#mi("\\frac{(2(\\ell+1))!}{(k+2\\ell+1)!} = \\int_0^1 (1-x)^{2(\\ell+1)} \\frac{x^{k-2}}{(k-2)!}\\ dx \\quad (*)")

#text("is instead replaced by")

#mi("\\int_0^1 (1-x)^{2(\\ell+1)} \\frac{x^{k-2}}{(k-2)!}\\ dx - \\int_0^{1-\\omega} (1-x)^{2(\\ell+1)} \\frac{x^{k-2}}{(k-2)!}\\ dx")#linebreak()#text(" ")#mi("= \\int_{1-\\omega}^1 (1-x)^{2(\\ell+1)} \\frac{x^{k-2}}{(k-2)!}\\ dx.")

#text("Unfortunately this expression can be significantly less than (*) in the regime ")#mi("\\omega \\ll \\ell/k")#text(", which seems to be the region that Pintz has (with ")#mi("k = 60,000")#text(", ")#mi("\\ell = 245")#text(", ")#mi("\\omega \\approx \\frac{3}{19 \\times 488}")#text(").")

#text("In Motohashi-Pintz they suggest trying to adapt (4.15) to deal with the second of the two summations to try to capture an exponential decay, but (4.15) involves a factor like ")#tao-math("(\\log (R/w)/\\left|D\\right|)^{2l+1}", block: false)#text(" rather than ")#tao-math("(\\log (R)/\\left|D\\right|)^{2l+1}", block: false)#text(" and so is not directly applicable for the purposes of estimating (5.14).")

#text("I'm planning to contact Pintz about this issue; I may be missing something obvious, but at present I can't reconstruct enough of Pintz's argument to make any of our claims that require the value ")#mi("\\frac{1}{\\delta} \\exp(-k_0 \\delta)")#text(" for ")#mi("\\kappa")#text(" to work, and will have to be regarded as provisional (particularly given the issues that v08ltu is raising). So any confirmed value of ")#mi("k_0")#text(" will, for now, have to come using the older value of ")#mi("\\kappa")#text(" given in ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/#comment-232840")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/#comment-232840")]#text(" rather than the Pintz value of ")#mi("\\kappa")#text(".")

#text("Hopefully all this confusion will be cleared up soon, but until then a lot of the most recent world records will unfortunately have to have a question mark attached to them on the wiki… (in particular, even v08ltu’s most recent value 25,111 for k_0 may need to be recalculated.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233358")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("I think he is already violating 4.2 if I understand correctly, where ")#mi("3\\log k\\le k\\omega")#text(" is demanded, but when ")#mi("\\omega=3/19/488")#text(" this says ")#mi("33.00\\le 19.4")#text(". This feeds into 4.15.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233359")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("From what I can tell, the passage for the last two lines of 4.15, the meat is ")#mi("k|\\log\\omega|(1-\\omega)^{k+2l}\\le e^{-k\\omega/3}")#text(". Taking logs and ")#mi("k\\rightarrow\\infty")#text(" shows this to work asymptotically, but it is less apparent in the desired range of ")#mi("k")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233407")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I think the issue is estimates for the form (4.15) are not actually applicable in the context required, namely for estimating the second sum in (5.14). The difference looks tiny but is significant: in (5.14) there is a factor of ")#tao-math("\\log (\\frac{R}{\\left|D\\right|})^{2(\\ell+1)}", block: false)#text(", whereas in (4.15) there is the smaller factor of ")#tao-math("\\log (\\frac{R/w}{\\left|K\\right|})^{2(\\ell+1)}", block: false)#text(" (with ")#mi("K")#text(" in the latter sum playing basically the same role that ")#mi("D")#text(" plays in the former sum, in particular both expressions are to sum up to ")#mi("R/w")#text("). In both cases the dominant contribution comes when the summation variable (")#mi("D")#text(" or ")#mi("K")#text(") is close to its upper limit of ")#mi("R/w")#text(", so one sees that the type of sums in (4.15) are actually a lot smaller than those in (5.14). One can get the ")#mi("\\exp(-k\\omega)")#text(" type decay for the former but I don’t think one can for the latter.")

#text("I am going to write up an erratum page recording all issues reported so far in relevant papers on the wiki, and also I am going to have a blog post on the sieve theory surrounding this particular issue (I had planned to have it ready yesterday, but then I ran into the above mathematical issue and this complicated things).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233364")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("If I did everything correctly, with the verified ")#mi("\\kappa")#text(" expression (30) and ")#mi("1/4= 207\\omega+43\\delta")#text(", I get ")#mi("\\omega=1/964")#text(" and ")#mi("k_0=26024")#text(" is best. Here ")#mi("\\delta=17/20726")#text(" and ")#mi("\\kappa\\approx0.000031177")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I have verified that the above choices of ")#mi("\\varpi, k_0, \\delta")#text(" do indeed give the claimed value of ")#mi("\\kappa")#text(" and that (30) is satisfied. Given that Ben and v08ltu have independently found ")#mi("207\\omega + 43 \\delta = 1/4")#text(" as the optimised criterion coming out of Zhang’s paper, I think we can now report the ")#mi("k_0=26024")#text(" value as confirmed.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233403")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("Just to say that v08ltu and I seem to have independently arrived at the constraint ")#mi("207 \\varpi + 43 \\delta \\leq \\frac{1}{4}")#text(" as being the optimal thing coming from Zhang’s argument in its present form. This (for me at least) is based on the assumption that the worst part of his argument is where the so-called Type I and Type III estimates meet. Details on the other blog.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233474")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("I think it is really that you agree with my correction of Pintz. I trusted his value of ")#mi("a")#text(" in the Type I/III border, and it seems you rederived it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233416")[#strong[#text("Weekend Reading | A Flustered Monkey Writes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-go&#8230")[#text("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-go&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The elementary Selberg sieve and bounded prime gaps | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233460")[#strong[#text("The elementary Selberg sieve and bounded prime gaps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("[…] post is a continuation of the previous post on sieve theory, which is an ongoing part of the Polymath8 project to improve the various parameters in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233462")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2013")])]

#text("It’s time to close this thread and roll over to the new thread at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("The elementary Selberg sieve and bounded prime gaps")]
]

#text("to continue the discussion of how to optimise ")#mi("k_0")#text(" from a given range of ")#mi("\\varpi,\\delta")#text(", and how to deal with the ")#mi("\\kappa")#text(" error term. We now have two slightly different approaches, based on what I call the “analytic Selberg sieve” and the “elementary Selberg sieve”, both truncated to smooth moduli; there is certainly scope for optimisation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A combinatorial subset sum problem associated with bounded prime gaps | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-233834")[#strong[#text("A combinatorial subset sum problem associated with bounded prime gaps | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2013")])]

#text("[…] , which in turn control the best bound on asymptotic gaps between consecutive primes. See this previous post for more discussion of this. At present, the best value of is applied by taking sufficiently […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Further analysis of the truncated GPY sieve | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-234104")[#strong[#text("Further analysis of the truncated GPY sieve | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2013")])]

#text("[…] This post is a continuation of the previous post on sieve theory, which is an ongoing part of the Polymath8 project. As the previous post was getting somewhat full, we are rolling the thread over to the current post. We also take the opportunity to correct some errors in the treatment of the truncated GPY sieve from this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type I and Type II sums | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-234213")[#strong[#text("Estimation of the Type I and Type II sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("[…] we prove part (i) of Theorem 4. By an overspill argument (cf. Lemma 7 of this previous post) it suffices to show […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e18fc670ce8373ad813ce52fe449dccef3601a486a3a1cba3908ad64086d4bb-59b218de9324f4d0409874676640f8edc386cf876c8e6d516e0d605f805f478f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anant1964")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-234331")[#strong[#text("anant1964")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("A question from a complete outside: if eventually the twin-prime conjecture in its original form is proved, then would it also imply that there would be an infinite number of primes that differ not just by 2, but there would also be an infinite number of primes that differ by 4, by 6, by 8,…? In other words, some kind of an analog of your celebrated theorem with Green? Would the present approach allow one to infer such a result, constructive or not?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69328ca38020bfdb13e572a59ca53eaf4bd575cc30bf6a9da7fcbe218b11e62b-35ac0fb53b4d8dfdaafdeca5cc6d4320e35ac400b23bc0818982f7d91f3d6ea8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-234378")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Zhang’s proof works by proving first that there at least 2 primes in an infinite number of a certain “admissible tuple” with k_0 elements (see the introduction of the article). The difference result is a consequence of picking “narrow” tuples with that number of elements. One could conceive that by pushing k_0 to be 2 we get all admissible 2 tuples (0, 2m) for any m and the twin prime conjecture (m=1) together with any even difference would immediately follow. But unfortunately the present methods are based in a weaker version of the Elliott-Halberstam conjecture that even in its strongest version could only get k_0=6 with the narrowest tuple (0,4,6,10,12,16) and maximum difference 16.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-234379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Not directly, but I would be extremely surprised if any future proof of the twin prime conjecture could not be easily modified to also prove an infinitude of prime pairs p, p+k for any even k. (Numbers k for which this statement holds are known as Polignac numbers; this recent paper by Pintz ")#link("http://arxiv.org/abs/1305.6289")[#text("http://arxiv.org/abs/1305.6289")]#text(" gives a quite comprehensive discussion of what exactly we can know or hope to know about such numbers with current methods.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A truncated elementary Selberg sieve of Pintz | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-235108")[#strong[#text("A truncated elementary Selberg sieve of Pintz | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("[…] this new truncation we need to review some notation. As in all previous posts (in particular, the first post in this series), we have an asymptotic parameter going off to infinity, and all quantities here are implicitly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-235320")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("I’m finally taking the time to read through these arguments thoroughly, and am enjoying it immensely. Here are some minor corrections I found.")

#text("In the second offset equation after ")#mi("\\zeta_{I}")#text(" is defined, there is a right parenthesis missing after ")#mi("o(1)")#text(".")

#text("In Proposition 10, I believe you want the dimension ")#mi("k")#text(" to be fixed. (At least, that was the assumption stated for (6).)")

#text("In the second line of the offset equation following (10), I believe the two ")#mi("k")#text("‘s should be ")#mi("k_0")#text("‘s.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-235414")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("A few more minor corrections, and some questions.")

#text("1. In the two offset equations above where ")#mi("\\zeta_I")#text(" is defined, there are four instances where ")#mi("\\zeta_I(1-\\ast)")#text(" should be ")#mi("\\zeta_I(1+\\ast)")#text(".")

#text("2. When describing the constraint ")#mi("d_1,d_2|P(n)")#text(", instead of ")#mi("n")#text(" lying in one of the residue classes ")#mi("h_i \\pmod{p}")#text(", I believe you want it in ")#mi("-h_i \\pmod{p}")#text(".")

#text("3. You write “Repeating the arguments for (9), we may expand the left-hand side of (9) as…”. The second (9) should be a (10).")

#text("4. After remark 1, when dealing with the error term for (10), it appears that you are assuming ")#mi("g")#text(" is bounded by a fixed constant. (Or perhaps I’m not seeing the reason that the two ")#mi("g")#text(" terms can be incorporated into the big-O.)")

#text("5. In the last paragraph of Remark 2, “unconditional” is misspelled.")

#text("—")

#text("Question 1: I’ve now read through Section 3. Would you advise me to skip Section 4, and move on to the “The elementary Selberg sieve and bounded prime gaps” post?")

#text("Question 2: Chen Jingrun’s theorem on twin primes also had a counter-part for Goldbach’s conjecture. Is there something similar here? Can these sieve methods be modified to show that there is a fixed number ")#mi("k")#text(" for which two of ")#mi("p, 2p+1, 4p+3,\\ldots, 2^k p+(2^k-1)")#text(" are simultaneously prime?")

#text("Question 3: Is there a way to modify the sieve to take into account non-admissible tuples? In other words, suppose we want to consider something stronger than the prime tuples conjecture, such as the claim that the set ")#mi("\\{n,n+1,n+2\\}")#text(" is “as prime as possible infinitely often.” (One meaning could be that (simultaneously) ")#mi("n")#text(" and ")#mi("n+2")#text(" are prime and ")#mi("n+2")#text(" is 6 times a prime, infinitely often.) In this way, one might be able to generalize the result a bit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-235422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Thanks for the corrections! I had neglected to specify that the function ")#mi("g")#text(" was fixed, which was why it could bounded by O(1).")

#text("Section 3 is more or less obsolete, but I think some later posts refer to some of the calculations in this section, so one may still have to jump back to this section for later reading.")

#text("Yes, the methods here should extend to other patterns ")#mi("a_1 n + b_1,\\ldots,a_k n+b_k")#text(" of linear forms than just shifts ")#mi("n + h_1,\\ldots,n+h_k")#text(" of a single tuple. Unfortunately these more general patterns don’t seem to easily imply a result as clean as “bounded prime gaps” though; for instance, it doesn’t look like one can show that every positive integer is O(1) away from being the sum of two primes by this method.")

#text("For non-admissible tuples, I think basically things just fragment into non-interacting admissible tuples and one doesn’t really gain anything. For instance, with ")#mi("\\{n,n+1,n+2\\}")#text(", one should think of this set as really being ")#mi("\\{n,n+2\\}")#text(" when n is odd and ")#mi("\\{n+1\\}")#text(" when n is even for the purposes of trying to capture primes. Intuitively there should be no gain on the odd side that comes from fancy sieving on the even side or vice versa. (The W-trick automatically reduces to a single residue class to get rid of all of these local phenomena in any event.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-235438")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("On the non-admissible tuple ")#mi("\\{n, n+1, n+2\\}")#text(" I realized that another way of dealing with it (and keeping both the 2-adic and 3-adic information) would instead be to work with the tuple ")#mi("\\{m, 6m-1, 6m+1\\}")#text(" (where we think of ")#mi("6m=n+1")#text("). So nothing new here.")

#text("On the Sophie Germain-type sequence, if I’m understanding your claim correctly (and after modifying the sequence slightly), that may give another proof for infinitely many exponents of FLT (in case 1).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounded gaps between primes (Polymath8) – a progress report | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-236879")[#strong[#text("Bounded gaps between primes (Polymath8) – a progress report | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("[…] out to be given in terms of a certain Bessel function, and improves the relationship to ; see this post for details. Also, a modification of the truncated Selberg sieve due to Pintz allows one to take […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fc15347dcea2a7a737be91183f43a08f24ea2da4a25cc1e7f06012dd9aac0b0-138c4d6c35c03139a8225dbb7ca0f67c8ee3ce59adc8b70f2aeb33a55bdbe052.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-238823")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("I think I’m missing something in the proof of Lemma 9. In this it is stated:")#linebreak()#text(" ")#mi("\\frac{1}{\\zeta (1 + \\frac{1}{\\log R}} ) = \\log R + O(1)")#linebreak()#text(" and while I certainly get that it seems to be a very weak bound as I’m getting:")#linebreak()#text(" ")#mi("\\frac{1}{\\zeta (1 + \\frac{1}{\\log R} ) } = \\frac{1}{\\frac{1}{1 + \\frac{1}{\\log R} - 1} + O(1)} = \\frac{1}{\\log R + O(1)}")#linebreak()#text(" which seems about right as ")#mi("\\zeta")#text(" tends to infinity as it approaches 1 from the right. It just seems like such a wasteful bound that I fear I’m misunderstanding something.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0fc15347dcea2a7a737be91183f43a08f24ea2da4a25cc1e7f06012dd9aac0b0-138c4d6c35c03139a8225dbb7ca0f67c8ee3ce59adc8b70f2aeb33a55bdbe052.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-238827")[#strong[#text("Stijn Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("EDIT: Nope, I got confused between << and O. I really can't see how that equality is arrived at")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-238831")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2013")])]

#text("Ah, that was a typo, the estimate should indeed be ")#mi("\\frac{1}{\\log R + O(1)}")#text(" (which also fixes the next step of the argument). It’s corrected now.")

#text("[Incidentally, it can be helpful for things like this to develop some mathematical reading strategies that are robust with respect to typos and do not cause mental “compilation errors”, as I discuss ")#link("https://profiles.google.com/114134834346472219368/buzz/GPQDR3gHsYr")[#text("here")]#text(".]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0f7aba6dff110725c648a0c757b8edacc96b47d94c3c37f4612eb6b8cf62734-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Stefan Campbell Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-240571")[#strong[#text("Stijn Stefan Campbell Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2013")])]

#text("I think my problem is that I can’t actually see how the next line follows anyway. It says to take logs which would give something along the lines of:")#linebreak()#text(" ")#mi("\\displaystyle \\sum_p log(1-\\frac{1}{p^{1+\\frac{1}{log R}}}) = log(log R + O(1))")#linebreak()#text(" and I can quite easily see how the R.H.S. becomes ")#mi("log log R + O(1)")#text(" but that would then require:")#linebreak()#text(" ")#mi("\\displaystyle \\sum_p log(1-\\frac{1}{p^{1+\\frac{1}{log R}}}) = \\sum_p p^{-1-\\frac{1}{log R}}")#linebreak()#text(" or at least some asymptotic relationship.")

#text("Trying to take your advice it’s clear how ")#mi("\\sum_p p^{-1-\\frac{1}{log R}} = log log R + O(1)")#text(" is necessary but I just have no earthly idea how it’s derived. My apologies if these questions are stupid.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-240605")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2013")])]

#text("By Taylor expansion, ")#mi("\\log(1-x) = -x + O(x^2)")#text(" when ")#mi("x")#text(" is small.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12d404f409cfa929ed29832da558e59e322a910f2349ed86fa2a0156ac3d68b3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Stefan Campbell Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-240606")[#strong[#text("Stijn Stefan Campbell Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2013")])]

#text("Of course, I was trying to use the full Taylor expansion. Sorry, I’m still not used to what I can throw away and what I can’t in these sorts of calculations.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c0f7aba6dff110725c648a0c757b8edacc96b47d94c3c37f4612eb6b8cf62734-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Stefan Campbell Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-242117")[#strong[#text("Stijn Stefan Campbell Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")])]

#text("I’ve been working through at a rather pedestrian pace and have (finally) gotten to the end of Proposition 10 but I seem to have some extra factors of ")#mi("\\frac{1}{2 \\pi}")#text(" kicking around. Even though you haven’t explicitly said so it seems like you’ve defined:")

#mi("\\displaystyle \\hat{g}(t) := \\int_\\mathbb{R} g(x) e^{-ix(t+i)} dx")

#text("which would seem to imply")

#mi("\\displaystyle e^x g(x) = \\frac{1}{2 \\pi} \\int_\\mathbb{R} \\hat{g}(t) e^{-itx}")

#text("and throws those ")#mi("\\frac{1}{2 \\pi}")#text(" coefficients in later, particularly in the expressions for ")#mi("S_{1,R,I} (f,g)")#text(" and ")#mi("S_{2,R,I} (f,g)")#text(" both of which I derive with an extra factor of ")#mi("(2 \\pi)^{-k}")

#text("These don’t seem to be particularly important but I’m worried I might have done something wrong, especially as I followed the other convention for the Fourier transform and was kinda expecting all those factors to cancel out at some point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-242157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")])]

#text("The precise definition of ")#mi("\\hat g")#text(" is not important for this argument, but one can multiply the expression for ")#mi("\\hat g")#text(" you have by ")#mi("2\\pi")#text(" to resolve this issue.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/comment-page-1/#comment-242073")[#strong[#text("Euclid Strikes Back | Gödel's Lost Letter and P=NP")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")]

#text("[…] are other uses of this simple trick. I note that it is quite close to the “W-trick” described by Terence Tao in relation to Yitang Zhang’s advance on the twin-prime conjecture, and […]")
]
