// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/
// Converted to Typst by tao2typ: "2026-10-14T16:35:48.518830+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Selberg’s limit theorem for the Riemann zeta function on the critical line", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Selberg’s limit theorem for the Riemann zeta function on the critical line")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/")[#text("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Riemann_zeta_function")[#text("Riemann zeta function")]#text(" ")#mi("{\\zeta(s)}")#text(", defined for ")#mi("{\\text{Re}(s)>1}")#text(" by ")#metadata(none) <tao-2a935c3c55a46458ae02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\zeta(s) := \\sum_{n=1}^\\infty \\frac{1}{n^s}")]]

#text("and then continued ")#link("http://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphically")]#text(" to other values of ")#mi("{s}")#text(" by ")#link("http://en.wikipedia.org/wiki/Analytic_continuation")[#text("analytic continuation")]#text(", is a fundamentally important function in analytic number theory, as it is connected to the primes ")#mi("{p=2,3,5,\\ldots}")#text(" via the ")#link("http://en.wikipedia.org/wiki/Analytic_continuation")[#text("Euler product formula")]#text(" ")#metadata(none) <tao-561f156bb5b88037becd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\zeta(s) = \\prod_p (1 - \\frac{1}{p^s})^{-1}")]]

#text("(for ")#mi("{\\text{Re}(s) > 1}")#text(", at least), where ")#mi("{p}")#text(" ranges over primes. (The equivalence between ")#link(<tao-2a935c3c55a46458ae02>)[#text("(1)")]#text(" and ")#link(<tao-561f156bb5b88037becd>)[#text("(2)")]#text(" is essentially the ")#link("http://en.wikipedia.org/wiki/Generating_function")[#text("generating function")]#text(" version of the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(".) The function ")#mi("{\\zeta}")#text(" has a pole at ")#mi("{1}")#text(" and a number of zeroes ")#mi("{\\rho}")#text(". A formal application of the ")#link("http://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(" gives ")#metadata(none) <tao-1cc70ab75ecefa36cf3a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\zeta(s) = \\frac{1}{s-1} \\prod_\\rho (s-\\rho) \\times \\ldots")]]

#text("where ")#mi("{\\rho}")#text(" ranges over zeroes of ")#mi("{\\zeta}")#text(", and we will be vague about what the ")#mi("{\\ldots}")#text(" factor is, how to make sense of the infinite product, and exactly which zeroes of ")#mi("{\\zeta}")#text(" are involved in the product. Equating ")#link(<tao-561f156bb5b88037becd>)[#text("(2)")]#text(" and ")#link(<tao-1cc70ab75ecefa36cf3a>)[#text("(3)")]#text(" and taking logarithms gives the formal identity ")#metadata(none) <tao-8847bf53d6c151d876b9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("- \\log \\zeta(s) = \\sum_p \\log(1 - \\frac{1}{p^s}) = \\log(s-1) - \\sum_\\rho \\log(s-\\rho) + \\ldots;")]]

#text("using the Taylor expansion ")#metadata(none) <tao-78675cc176081372c43a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\log(1 - \\frac{1}{p^s}) = - \\frac{1}{p^s} - \\frac{1}{2 p^{2s}} - \\frac{1}{3p^{3s}} - \\ldots")]]

#text("and differentiating the above identity in ")#mi("{s}")#text(" yields the formal identity ")#metadata(none) <tao-e9e3c879b071067298b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("- \\frac{\\zeta^{\\prime}(s)}{\\zeta(s)} = \\sum_n \\frac{\\Lambda(n)}{n^s} = \\frac{1}{s-1} - \\sum_\\rho \\frac{1}{s-\\rho} + \\ldots")]]

#text("where ")#mi("{\\Lambda(n)}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(", defined to be ")#mi("{\\log p}")#text(" when ")#mi("{n}")#text(" is a power of a prime ")#mi("{p}")#text(", and zero otherwise. Thus we see that the behaviour of the primes (as encoded by the von Mangoldt function) is intimately tied to the distribution of the zeroes ")#mi("{\\rho}")#text(". For instance, if we knew that the zeroes were far away from the axis ")#mi("{\\text{Re}(s)=1}")#text(", then we would heuristically have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^{1+it}} \\approx \\frac{1}{it}")]]

#text("for real ")#mi("{t}")#text(". On the other hand, the integral test suggests that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{1}{n^{1+it}} \\approx \\frac{1}{it}")]]

#text("and thus we see that ")#mi("{\\frac{\\Lambda(n)}{n}}")#text(" and ")#mi("{\\frac{1}{n}}")#text(" have essentially the same (multiplicative) ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(":")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\frac{\\Lambda(n)}{n^{1+it}} \\approx \\sum_n \\frac{1}{n^{1+it}}.")]]

#text("Inverting the Fourier transform (or performing a contour integral closely related to the inverse Fourier transform), one is led to the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\leq x} \\Lambda(n) \\approx \\sum_{n \\leq x} 1.")]]

#text("In fact, the standard proof of the prime number theorem basically proceeds by making all of the above formal arguments precise and rigorous.")

#text("Unfortunately, we don’t know as much about the zeroes ")#mi("{\\rho}")#text(" of the zeta function (and hence, about the ")#mi("{\\zeta}")#text(" function itself) as we would like. The ")#link("http://en.wikipedia.org/wiki/Riemann_hypothesis")[#text("Riemann hypothesis")]#text(" (RH) asserts that all the zeroes (except for the “trivial” zeroes at the negative even numbers) lie on the ")#emph[#text("critical line")]#text(" ")#mi("{\\text{Re}(s)=1/2}")#text("; this hypothesis would make the error terms in the above proof of the prime number theorem significantly more accurate. Furthermore, the stronger ")#emph[#text("GUE hypothesis")]#text(" asserts in addition to RH that the local distribution of these zeroes on the critical line should behave like the local distribution of the eigenvalues of a random matrix drawn from the ")#link("http://en.wikipedia.org/wiki/Gaussian_Unitary_Ensemble")[#text("gaussian unitary ensemble")]#text(" (GUE). I will not give a precise formulation of this hypothesis here, except to say that the adjective “local” in the context of distribution of zeroes ")#mi("{\\rho}")#text(" means something like “at scale ")#mi("{O(1/\\log T)}")#text(" when ")#mi("{\\text{Im}(s) = O(T)}")#text("“.")

#text("Nevertheless, we do know some reasonably non-trivial facts about the zeroes ")#mi("{\\rho}")#text(" and the zeta function ")#mi("{\\zeta}")#text(", either unconditionally, or assuming RH (or GUE). Firstly, there are no zeroes for ")#mi("{\\text{Re}(s)>1}")#text(" (as one can already see from the convergence of the Euler product ")#link(<tao-561f156bb5b88037becd>)[#text("(2)")]#text(" in this case) or for ")#mi("{\\text{Re}(s)=1}")#text(" (this is trickier, relying on ")#link(<tao-e9e3c879b071067298b6>)[#text("(6)")]#text(" and the elementary observation that")

#align(center)[#tao-fit-display[#mitex("\\text{Re}( 3\\frac{\\Lambda(n)}{n^{\\sigma}} + 4\\frac{\\Lambda(n)}{n^{\\sigma+it}} + \\frac{\\Lambda(n)}{n^{\\sigma+2it}} ) = 2\\frac{\\Lambda(n)}{n^\\sigma} (1+\\cos(t \\log n))^2")]]

#text("is non-negative for ")#mi("{\\sigma > 1}")#text(" and ")#mi("{t \\in {\\mathbb R}}")#text("); from the ")#link("http://en.wikipedia.org/wiki/Functional_equation")[#text("functional equation")]

#align(center)[#tao-fit-display[#mitex("\\pi^{-s/2} \\Gamma(s/2) \\zeta(s) = \\pi^{-(1-s)/2} \\Gamma((1-s)/2) \\zeta(1-s)")]]

#text("(which can be viewed as a consequence of the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(", see e.g. ")#link("https://terrytao.wordpress.com/2008/07/27/tates-proof-of-the-functional-equation/")[#text("my blog post on this topic")]#text(") we know that there are no zeroes for ")#mi("{\\text{Re}(s) \\leq 0}")#text(" either (except for the trivial zeroes at negative even integers, corresponding to the poles of the Gamma function). Thus all the non-trivial zeroes lie in the ")#emph[#text("critical strip")]#text(" ")#mi("{0 < \\text{Re}(s) < 1}")#text(".")

#text("We also know that there are infinitely many non-trivial zeroes, and can approximately count how many zeroes there are in any large bounded region of the critical strip. For instance, for large ")#mi("{T}")#text(", the number of zeroes ")#mi("{\\rho}")#text(" in this strip with ")#mi("{\\text{Im}(\\rho) = T+O(1)}")#text(" is ")#mi("{O(\\log T)}")#text(". This can be seen by applying ")#link(<tao-e9e3c879b071067298b6>)[#text("(6)")]#text(" to ")#mi("{s = 2+iT}")#text(" (say); the trivial zeroes at the negative integers end up giving a contribution of ")#mi("{O(\\log T)}")#text(" to this sum (this is a heavily disguised variant of ")#link("http://en.wikipedia.org/wiki/Stirling%27s_formula")[#text("Stirling’s formula")]#text(", as one can view the trivial zeroes as essentially being poles of the Gamma function), while the ")#mi("{\\frac{1}{s-1}}")#text(" and ")#mi("{\\ldots}")#text(" terms end up being negligible (of size ")#mi("{O(1)}")#text("), while each non-trivial zero ")#mi("{\\rho}")#text(" contributes a term which has a non-negative real part, and furthermore has size comparable to ")#mi("{1}")#text(" if ")#mi("{\\text{Im}(\\rho) = T+O(1)}")#text(". (Here I am glossing over a technical renormalisation needed to make the infinite series in ")#link(<tao-e9e3c879b071067298b6>)[#text("(6)")]#text(" converge properly.) Meanwhile, the left-hand side of ")#link(<tao-e9e3c879b071067298b6>)[#text("(6)")]#text(" is absolutely convergent for ")#mi("{s=2+iT}")#text(" and of size ")#mi("{O(1)}")#text(", and the claim follows. A more refined version of this argument shows that the number of non-trivial zeroes with ")#mi("{0 \\leq \\text{Im}(\\rho) \\leq T}")#text(" is ")#mi("{\\frac{T}{2\\pi} \\log \\frac{T}{2\\pi} - \\frac{T}{2\\pi} + O(\\log T)}")#text(", but we will not need this more precise formula here. (A fair fraction – at least 40%, in fact – of these zeroes are known to lie on the critical line; see this ")#link("https://terrytao.wordpress.com/2007/08/12/atle-selberg/")[#text("earlier blog post")]#text(" of mine for more discussion.)")

#text("Another thing that we happen to know is how the ")#emph[#text("magnitude")]#text(" ")#tao-math("{\\left|\\zeta(1/2+it)\\right|}", block: false)#text(" of the zeta function is distributed as ")#mi("{t \\rightarrow \\infty}")#text("; it turns out to be ")#link("http://en.wikipedia.org/wiki/Log-normal_distribution")[#text("log-normally")]#text(" distributed with log-variance about ")#mi("{\\frac{1}{2} \\log \\log t}")#text(". More precisely, we have the following result of Selberg:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1")]#text(" Let ")#mi("{T}")#text(" be a large number, and let ")#mi("{t}")#text(" be chosen uniformly at random from between ")#mi("{T}")#text(" and ")#mi("{2T}")#text(" (say). Then the distribution of ")#tao-math("{\\frac{1}{\\sqrt{\\frac{1}{2} \\log \\log T}} \\log \\left|\\zeta(1/2+it)\\right|}", block: false)#text(" converges (")#link("http://en.wikipedia.org/wiki/Convergence_of_random_variables")[#text("in distribution")]#text(") to the normal distribution ")#mi("{N(0,1)}")#text(".")
]

#text("To put it more informally, ")#tao-math("{\\log \\left|\\zeta(1/2+it)\\right|}", block: false)#text(" behaves like ")#mi("{\\sqrt{\\frac{1}{2} \\log \\log t} \\times N(0,1)}")#text(" plus lower order terms for “typical” large values of ")#mi("{t}")#text(". (Zeroes ")#mi("{\\rho}")#text(" of ")#mi("{\\zeta}")#text(" are, of course, certainly not typical, but one can show that one can usually stay away from these zeroes.) In fact, Selberg showed a slightly more precise result, namely that for any fixed ")#mi("{k \\geq 1}")#text(", the ")#mi("{k^{th}}")#text(" moment of ")#tao-math("{\\frac{1}{\\sqrt{\\frac{1}{2} \\log \\log T}} \\log \\left|\\zeta(1/2+it)\\right|}", block: false)#text(" converges to the ")#mi("{k^{th}}")#text(" moment of ")#mi("{N(0,1)}")#text(".")

#text("Remarkably, Selberg’s result does not need RH or GUE, though it is certainly consistent with such hypotheses. (For instance, the determinant of a GUE matrix asymptotically obeys a remarkably similar log-normal law to that given by Selberg’s theorem.) Indeed, the net effect of these hypotheses only affects some error terms in ")#tao-math("{\\log \\left|\\zeta(1/2+it)\\right|}", block: false)#text(" of magnitude ")#mi("{O(1)}")#text(", and are thus asymptotically negligible compared to the main term, which has magnitude about ")#mi("{O(\\sqrt{\\log \\log T})}")#text(". So Selberg’s result, while very pretty, manages to finesse the question of what the zeroes ")#mi("{\\rho}")#text(" of ")#mi("{\\zeta}")#text(" are actually doing – he makes the primes do most of the work, rather than the zeroes.")

#text("Selberg never actually published the above result, but it is reproduced in a number of places (e.g. in ")#link("http://www.ams.org/mathscinet-getitem?mr=865983")[#text("this book by Joyner")]#text(", or ")#link("http://www.ams.org/mathscinet-getitem?mr=1376140")[#text("this book by Laurincikas")]#text("). As with many other results in analytic number theory, the actual details of the proof can get somewhat technical; but I would like to record here (partly for my own benefit) an informal sketch of some of the main ideas in the argument.")

#metadata(none) <tao-43373a8e2285caca685a>

#heading(level: 1)[#strong[#text(" — 1. Informal overview of argument — ")]]

#text("The first step is to get a usable (approximate) formula for ")#tao-math("{\\log\\left|\\zeta(s)\\right|}", block: false)#text(". On the one hand, from the second part of ")#link(<tao-8847bf53d6c151d876b9>)[#text("(4)")]#text(" one has ")#metadata(none) <tao-5667ef73dac709effcfd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("-\\log\\left|\\zeta(s)\\right| = \\log\\left|s-1\\right| - \\sum_\\rho \\log\\left|s-\\rho\\right| + \\ldots.", block: true)]]

#text("This formula turns out not to be directly useful because it requires one to know much more about the distribution of the zeroes ")#mi("{\\rho}")#text(" than we currently possess. On the other hand, from the first part of ")#link(<tao-8847bf53d6c151d876b9>)[#text("(4)")]#text(" and ")#link(<tao-78675cc176081372c43a>)[#text("(5)")]#text(" one also has the formula ")#metadata(none) <tao-2e16b4ca8367812b8427>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\log\\left|\\zeta(s)\\right| = \\sum_p \\text{Re} \\frac{1}{p^s} + \\ldots.", block: true)]]

#text("This formula also turns out not to be directly useful, because it requires one to know much more about the distribution of the primes ")#mi("{p}")#text(" than we currently possess.")

#text("However, it turns out that we can “split the difference” between ")#link(<tao-5667ef73dac709effcfd>)[#text("(7)")]#text(", ")#link(<tao-2e16b4ca8367812b8427>)[#text("(8)")]#text(", and get a formula for ")#tao-math("{\\log \\left|\\zeta(s)\\right|}", block: false)#text(" which involves some zeroes ")#mi("{\\rho}")#text(" and some primes ")#mi("{p}")#text(", in a manner that one can control them both. Roughly speaking, the formula looks like this: ")#metadata(none) <tao-f9919d2c8e76efd79ab4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\log\\left|\\zeta(s)\\right| = \\sum_{p \\leq T^\\epsilon} \\text{Re} \\frac{1}{p^s} + O( \\sum_{\\rho = s + O(1/\\log T)} 1 + \\left|\\log\\frac{\\left|s-\\rho\\right|}{1/\\log T}\\right| ) + \\ldots", block: true)]]

#text("for ")#mi("{s = 1/2 + it}")#text(" and ")#mi("{t = O(T)}")#text(", where ")#mi("{\\epsilon}")#text(" is a small parameter that we can choose (e.g. ")#mi("{\\epsilon = 0.01}")#text("); thus we have localised the prime sum to the primes ")#mi("{p}")#text(" of size ")#mi("{O(T^{O(1)})}")#text(", and the zero sum to those zeroes at a distance ")#mi("{O(1/\\log T)}")#text(" from ")#mi("{s}")#text(". (This is an oversimplification; there is a “tail” coming from those zeroes that are more distant from ")#mi("{s}")#text(" than ")#mi("{O(1/\\log T)}")#text(", and also one has to smooth out the sum in ")#mi("{p}")#text(" a little bit, and allow the implied constants in the ")#mi("{O()}")#text(" notation to depend on ")#mi("{\\epsilon}")#text(", but let us ignore these technical issues here, as well as the issue of what exactly is hiding in the ")#mi("{\\ldots}")#text(" error.)")

#text("It turns out that all of these expressions can be controlled. The error term coming from the zeroes (as well as the ")#mi("{\\ldots}")#text(" error term) turn out to be of size ")#mi("{O(1)}")#text(" for most values of ")#mi("{t}")#text(", so are a lower order term. (As mentioned before, it is this error term that would be better controlled if one had RH or GUE, but this is not necessary to establish Selberg’s result.) The main term is the one coming from the primes.")

#text("We can heuristically argue as follows. The expression ")#mi("{X_p := \\text{Re} \\frac{1}{p^s} = \\frac{1}{\\sqrt{p}} \\cos( t \\log p )}")#text(", for ")#mi("{t}")#text(" ranging between ")#mi("{T}")#text(" and ")#mi("{2T}")#text(", is a random variable of mean zero and variance approximately ")#mi("{\\frac{1}{2p}}")#text(" (if ")#mi("{p \\leq T^\\epsilon}")#text(" and ")#mi("{\\epsilon}")#text(" is small). Making the heuristic assumption that the ")#mi("{X_p}")#text(" behave as if they were independent, the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(" then suggests that the sum ")#mi("{\\sum_{p \\leq T^\\epsilon} X_p}")#text(" should behave like a normal distribution of mean zero and variance ")#mi("{\\sum_{p \\leq T^\\epsilon} \\frac{1}{2p}}")#text(". But the claim now follows from the classical estimate")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq x}\\frac{1}{p} = \\log \\log x + O(1)")]]

#text("(which follows from the prime number theorem, but can also be deduced from the formula ")#link(<tao-2e16b4ca8367812b8427>)[#text("(8)")]#text(" for ")#mi("{s = 1 + O(1/\\log x)}")#text(", using the fact that ")#mi("{\\zeta}")#text(" has a simple pole at ")#mi("{1}")#text(").")

#text("To summarise, there are three main tasks to establish Selberg’s theorem:")

#enum(start: 1, 
[#text("Establish a formula along the lines of ")#link(<tao-f9919d2c8e76efd79ab4>)[#text("(9)")]#text(";")],
[#text("Show that the error terms arising from zeroes are ")#mi("{O(1)}")#text(" on the average;")],
[#text("Justify the central limit calculation for ")#mi("{\\sum_p X_p}")#text(".")]
)

#text("I’ll now briefly talk (informally) about each of the three steps in turn.")

#heading(level: 1)[#strong[#text(" — 2. The explicit formula — ")]]

#text("To get a formula such as ")#link(<tao-f9919d2c8e76efd79ab4>)[#text("(9)")]#text(", the basic strategy is to take a suitable average of the formula ")#link(<tao-5667ef73dac709effcfd>)[#text("(7)")]#text(" and the formula ")#link(<tao-2e16b4ca8367812b8427>)[#text("(8)")]#text(". Traditionally, this is done by contour integration; however, I prefer (perhaps idiosyncratically) to take a more Fourier-analytic perspective, using convolutions rather than contour integrals. (The two approaches are largely equivalent, though.) The basic point is that the imaginary part ")#mi("{\\text{Im}(\\rho)}")#text(" of the zeroes inhabits the same space as the imaginary part ")#mi("{t = \\text{Im}(s)}")#text(" of the ")#mi("{s}")#text(" variable, which in turn is the Fourier analytic dual of the variable that the logarithm ")#mi("{\\log p}")#text(" of the primes ")#mi("{p}")#text(" live in; this can be seen by writing ")#link(<tao-5667ef73dac709effcfd>)[#text("(7)")]#text(", ")#link(<tao-2e16b4ca8367812b8427>)[#text("(8)")]#text(" in a more Fourier-like manner as")

#align(center)[#tao-fit-display[#tao-math("\\sum_\\rho \\log\\left|1/2+it-\\rho\\right| + \\ldots = \\text{Re} \\sum_p \\frac{1}{\\sqrt{p}} e^{-i t \\log p} + \\ldots.", block: true)]]

#text("(These sorts of Fourier-analytic connections are often summarised by the slogan “the zeroes of the zeta function are the music of the primes”.) The uncertainty principle then predicts that localising ")#mi("{\\log p}")#text(" to the scale ")#mi("{O(\\log T^\\epsilon)}")#text(" should result in blurring out the zeroes ")#mi("{\\rho}")#text(" at scale ")#mi("{O(1/\\log T^\\epsilon)}")#text(", which is where ")#link(<tao-f9919d2c8e76efd79ab4>)[#text("(9)")]#text(" is going to come from.")

#text("Let’s see how this idea works in practice. We consider a convolution of the form ")#metadata(none) <tao-e88b7f5b5d68912f4353>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\int_{\\mathbb R} \\log\\left|\\zeta(s + \\frac{iy}{\\log T^\\epsilon})\\right| \\psi(y)\\ dy", block: true)]]

#text("where ")#mi("{\\psi}")#text(" is some bump function with total mass ")#mi("{1}")#text("; informally, this is ")#tao-math("{\\log\\left|\\zeta(s)\\right|}", block: false)#text(" averaged out in the vertical direction at scale ")#mi("{O(1/\\log T^\\epsilon) = O(1/\\log T)}")#text(" (we allow implied constants to depend on ")#mi("{\\epsilon}")#text(").")

#text("We can express ")#link(<tao-e88b7f5b5d68912f4353>)[#text("(10)")]#text(" in two different ways, one using ")#link(<tao-5667ef73dac709effcfd>)[#text("(7)")]#text(", and one using ")#link(<tao-2e16b4ca8367812b8427>)[#text("(8)")]#text(". Let’s look at ")#link(<tao-5667ef73dac709effcfd>)[#text("(7)")]#text(" first. If one modifies ")#mi("{s}")#text(" by ")#mi("{O(1/\\log T)}")#text(", then the quantity ")#tao-math("{\\log\\left|s-\\rho\\right|}", block: false)#text(" doesn’t fluctuate very much, unless ")#mi("{\\rho}")#text(" is within ")#mi("{O(1/\\log T)}")#text(" of ")#mi("{s}")#text(", in which case it can move by about ")#tao-math("{O( 1 + \\log \\frac{\\left|s-\\rho\\right|}{1/\\log T} )}", block: false)#text(". As a consequence, we see that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\mathbb R} \\log\\left|s + \\frac{iy}{\\log T^\\epsilon}-\\rho\\right| \\psi(y)\\ dy \\approx \\log \\left|s-\\rho\\right|", block: true)]]

#text("when ")#tao-math("{\\left|\\rho-s\\right| \\gg 1/\\log T}", block: false)#text(", and")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\mathbb R} \\log\\left|s + \\frac{iy}{\\log T^\\epsilon}-\\rho\\right| \\psi(y)\\ dy = \\log \\left|s-\\rho\\right| + O( 1 + \\log \\frac{\\left|s-\\rho\\right|}{1/\\log T} ).", block: true)]]

#text("The quantity ")#tao-math("{\\log\\left|s-1\\right|}", block: false)#text(" also doesn’t move very much by this shift (we are assuming the imaginary part of ")#mi("{s}")#text(" to be large). Inserting these facts into ")#link(<tao-5667ef73dac709effcfd>)[#text("(7)")]#text(", we thus see that ")#link(<tao-e88b7f5b5d68912f4353>)[#text("(10)")]#text(" is (heuristically) equal to ")#metadata(none) <tao-9a9bb24870c32535a3f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\log\\left|\\zeta(s)\\right| + \\sum_{\\rho = s + O(1/\\log T)} O( 1 + \\log \\frac{\\left|s-\\rho\\right|}{1/\\log T} ) + \\ldots.", block: true)]]

#text("Now let’s compute ")#link(<tao-e88b7f5b5d68912f4353>)[#text("(10)")]#text(" using ")#link(<tao-2e16b4ca8367812b8427>)[#text("(8)")]#text(" instead. Writing ")#mi("{s = 1/2+it}")#text(", we express ")#link(<tao-e88b7f5b5d68912f4353>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\text{Re} \\frac{1}{p^s} \\int_{\\mathbb R} e^{-i y \\log p / \\log T^\\epsilon} \\psi(y)\\ dy + \\ldots.")]]

#text("Introducing the Fourier transform ")#mi("{\\hat \\psi(\\xi) := \\int_{\\mathbb R} e^{-iy\\xi} \\psi(y)\\ dy}")#text(" of ")#mi("{\\psi}")#text(", one can write this as")

#align(center)[#tao-fit-display[#mitex("\\sum_p \\text{Re} \\frac{1}{p^s} \\hat \\psi(\\log p / \\log T^\\epsilon) + \\ldots.")]]

#text("Now we took ")#mi("{\\psi}")#text(" to be a bump function, so its Fourier transform should also be like a bump function (or perhaps a Schwartz function). As a first approximation, one can thus think of ")#mi("{\\hat \\psi}")#text(" as a smoothed truncation to the region ")#mi("{\\{ \\xi: \\xi = O(1)\\}}")#text(", thus the ")#mi("{\\hat \\psi(\\log p / \\log T^\\epsilon)}")#text(" weight is morally restricting ")#mi("{p}")#text(" to the region ")#mi("{p \\leq T^\\epsilon}")#text(". Thus we (morally) can express ")#link(<tao-e88b7f5b5d68912f4353>)[#text("(10)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_{p \\leq T^\\epsilon} \\text{Re} \\frac{1}{p^s} + \\ldots.")]]

#text("Comparing this with the other formula ")#link(<tao-9a9bb24870c32535a3f9>)[#text("(11)")]#text(" we have for ")#link(<tao-e88b7f5b5d68912f4353>)[#text("(10)")]#text(", we obtain ")#link(<tao-f9919d2c8e76efd79ab4>)[#text("(9)")]#text(" as required (formally, at least).")

#heading(level: 1)[#strong[#text(" — 3. Controlling the zeroes — ")]]

#text("Next, we want to show that the quantity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\rho = s + O(1/\\log T)} 1 + \\left|\\log\\frac{\\left|s-\\rho\\right|}{1/\\log T}\\right|", block: true)]]

#text("is ")#mi("{O(1)}")#text(" on the average, when ")#mi("{s=1/2+it}")#text(" and ")#mi("{t}")#text(" is chosen uniformly at random from ")#mi("{T}")#text(" to ")#mi("{2T}")#text(".")

#text("For this, we can use the ")#emph[#text("first moment method")]#text(". For each zero ")#mi("{\\rho}")#text(", let ")#mi("{I_\\rho}")#text(" be the random variable which equals ")#tao-math("{1 + \\left|\\log\\frac{\\left|s-\\rho\\right|}{1/\\log T}\\right|}", block: false)#text(" when ")#mi("{\\rho = s + O(1/\\log T)}")#text(" and zero otherwise, thus we are trying to control the expectation of ")#mi("{\\sum_\\rho I_\\rho}")#text(". The only zeroes which are relevant are those which are of size ")#mi("{O(T)}")#text(", and we know that there are ")#mi("{O(T \\log T)}")#text(" of these (indeed, we have an even more precise formula, as remarked earlier). On the other hand, a randomly chosen ")#mi("{s}")#text(" has a probability of ")#mi("{O( 1 / T \\log T )}")#text(" of falling within ")#mi("{O(1/\\log T)}")#text(" of ")#mi("{\\rho}")#text(", and so we expect each ")#mi("{I_\\rho}")#text(" to have an expected value of ")#mi("{O(1/T \\log T)}")#text(". (The logarithmic factor in the definition of ")#mi("{I_\\rho}")#text(" turns out not to be an issue, basically because ")#mi("{\\log x}")#text(" is locally integrable.) By linearity of expectation, we conclude that ")#mi("{\\sum_\\rho I_\\rho}")#text(" has expectation ")#mi("{O(T \\log T) \\times O( 1/T \\log T) = O(1)}")#text(", and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can actually do a bit better than this, showing that higher order moments of ")#mi("{\\sum_\\rho I_\\rho}")#text(" are also ")#mi("{O(1)}")#text(", by using a variant of ")#link(<tao-f9919d2c8e76efd79ab4>)[#text("(9)")]#text(" together with the moment bounds in the next section; but we will not need that refinement here.")
]

#heading(level: 1)[#strong[#text(" — 4. The central limit theorem — ")]]

#text("Finally, we have to show that ")#mi("{\\sum_{p \\leq T^\\epsilon} X_p}")#text(" behaves like a normal distribution, as predicted by the central limit theorem heuristic. The key is to show that the ")#mi("{X_p}")#text(" behave “as if” they were jointly independent. In particular, as the ")#mi("{X_p}")#text(" all have mean zero, one would like to show that products such as ")#metadata(none) <tao-2ee620ed2bce873b7e6d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("X_{p_1} \\ldots X_{p_k}")]]

#text("have a negligible expectation as long as at least one of the primes in ")#mi("{p_1,\\ldots,p_k}")#text(" occurs at most once. Once one has this (as well as a similar formula for the case when all primes appear at least twice), one can then do a standard moment computation of the ")#mi("{k^{th}}")#text(" moment ")#mi("{(\\sum_{p \\leq T^\\epsilon} X_p)^k}")#text(" and verify that this moment then matches the answer predicted by the central limit theorem, which by standard arguments (involving the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(") is enough to establish the distributional law. Note that to get close to the normal distribution by a fixed amount of accuracy, it suffices to control a bounded number of moments, which ultimately means that we can treat ")#mi("{k}")#text(" as being bounded, ")#mi("{k=O(1)}")#text(".")

#text("If we expand out the product ")#link(<tao-2ee620ed2bce873b7e6d>)[#text("(12)")]#text(", we get")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\sqrt{p_1} \\ldots \\sqrt{p_k}} \\cos( t \\log p_1 ) \\ldots \\cos( t \\log p_k ).")]]

#text("Using the product formula for cosines (or ")#link("http://en.wikipedia.org/wiki/Euler%27s_formula")[#text("Euler’s formula")]#text("), the product of cosines here can be expressed as a linear combination of cosines ")#mi("{\\cos(t\\xi)}")#text(", where the frequency ")#mi("{\\xi}")#text(" takes the form")

#align(center)[#tao-fit-display[#mitex("\\xi = \\pm \\log p_1 \\pm \\log p_2 \\ldots \\pm \\log p_k.")]]

#text("Thus, ")#mi("{\\xi}")#text(" is the logarithm of a rational number, whose numerator and denominator are the product of some of the ")#mi("{p_1,\\ldots,p_k}")#text(". Since all the ")#mi("{p_j}")#text(" are at most ")#mi("{T^\\epsilon}")#text(", we see that the numerator and denominator here are at most ")#mi("{T^{k\\epsilon}}")#text(".")

#text("Now for the punchline. If there is a prime in ")#mi("{p_1,\\ldots,p_k}")#text(" that appears only once, then the numerator and denominator cannot fully cancel, by the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_arithmetic")[#text("fundamental theorem of arithmetic")]#text(". Thus ")#mi("{\\xi}")#text(" cannot be ")#mi("{0}")#text(". Furthermore, since the denominator is at most ")#mi("{T^{k\\epsilon}}")#text(", we see that ")#mi("{\\xi}")#text(" must stay away from ")#mi("{0}")#text(" by a distance of about ")#mi("{1/T^{k\\epsilon}}")#text(" or more, and so ")#mi("{\\cos(t\\xi)}")#text(" has a wavelength of at most ")#mi("{O(T^{k\\epsilon})}")#text(". On the other hand, ")#mi("{t}")#text(" ranges between ")#mi("{T}")#text(" and ")#mi("{2T}")#text(". If ")#mi("{k}")#text(" is fixed and ")#mi("{\\epsilon}")#text(" is small enough (much smaller than ")#mi("{1/k}")#text("), we thus see that the average value of ")#mi("{\\cos(t\\xi)}")#text(" between ")#mi("{T}")#text(" and ")#mi("{2T}")#text(" is close to zero, and so ")#link(<tao-2ee620ed2bce873b7e6d>)[#text("(12)")]#text(" does indeed have negligible expectation as claimed. (A similar argument lets one compute the expectation of ")#link(<tao-2ee620ed2bce873b7e6d>)[#text("(12)")]#text(" when all primes appear at least twice.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" A famous ")#link("http://en.wikipedia.org/wiki/Erd%C5%91s%E2%80%93Kac_theorem")[#text("theorem of Erdös and Kac")]#text(" gives a normal distribution for the number of prime factors of a large number ")#mi("{n}")#text(", with mean ")#mi("{\\log \\log n}")#text(" and variance ")#mi("{\\log \\log n}")#text(". One can view Selberg’s theorem as a sort of Fourier-analytic variant of the Erdös-Kac theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The Fourier-like correspondence between zeroes of the zeta function and primes can be used to convert statements about zeroes, such as the Riemann hypothesis and the GUE hypothesis, into equivalent statements about primes. For instance, the Riemann hypothesis is equivalent to having the square root error term")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq x+y} \\Lambda(n) = y + O_\\varepsilon( y^{1/2+\\varepsilon} )")]]

#text("in the prime number theorem holding asymptotically as ")#mi("{x \\rightarrow \\infty}")#text(" for all ")#mi("{\\epsilon > 0}")#text(" and all intervals ")#mi("{[x,x+y]}")#text(" which are ")#emph[#text("large")]#text(" in the sense that ")#mi("{y}")#text(" is comparable to ")#mi("{x}")#text(". Meanwhile, the pair correlation conjecture (the simplest component of the GUE hypothesis) is equivalent (on RH) to the square root error term holding (with the expected variance) for all ")#mi("{\\epsilon > 0}")#text(" and ")#emph[#text("almost")]#text(" all intervals ")#mi("{[x,x+y]}")#text(" which are ")#emph[#text("short")]#text(" in the sense that ")#mi("{y=x^\\theta}")#text(" for some small (fixed) ")#mi("{\\theta > 0}")#text(". (This is a rough statement; a more precise formulation can be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=1018376")[#text("this paper of Goldston and Montgomery")]#text(".) It seems to me that reformulation of the full GUE hypothesis in terms of primes should be similar, but would assert that the error term in the prime number theorem (as well as variants of this theorem for almost primes) in short intervals enjoys the expected normal distribution; I don’t know of a precise formulation of this assertion, but calculations in this direction lie in ")#link("http://www.ams.org/mathscinet-getitem?mr=1363402")[#text("this paper of Bogomolny and Keating")]#text(".)")
]

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40018")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2009")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for the post.")

#text("Could you please recommend an introductory level analytic number theory book?")

#text("thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40021")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2009")])]

#text("The connection between Selberg’s central limit theorem for zeta(s) and the Erdös-Kác theorem is quite interesting; as ")#link("http://blogs.ethz.ch/kowalski/2009/02/28/a-beautiful-analogy-2/")[#text("I’ve discussed recently")]#text(" (based on joint work with A. Nikgehbali and J. Jacod), they can both be interpreted as renormalized consequences of un-normalized limiting behavior of the relevant characteristic functions/Fourier transforms (although for zeta(s), this is only conditional, depending on a suitable form of the Random Matrix correspondance).")#linebreak()#text(" One difference is that the case of zeta(s) involves unitary matrices and gaussian variables, while the Erdös-Kác theorem involves permutations and Poisson variables. (See ")#link("http://front.math.ucdavis.edu/0905.0318")[#text("this preprint")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2009")])]

#text("There’s a small typo in ” that does appears only once”. ")#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40035")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2009")])]

#text("I have a question about the truncation in (9). Isn’t it sub-optimal? We are truncating in physical space at ")#mi("T^{\\epsilon}")#text(" while in frequency space at ")#mi("1/ \\log (T)")#text(". But ")#mi("T^{\\epsilon}")#text(" is, at least in most results regarding the zeta function, far away from ")#mi("\\log(T)")#text(". By the uncertainty principle shouldn’t we be able to truncate at ")#mi("\\log(T)")#text(" without much (any?) impact on the tail terms in frequency space? Of course, you could argue that we aren’t going to improve the conclusion of the theorem so why does it matter, but it struck me as odd.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40037")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2009")])]

#text("Oh, i think i see, we are realy localizing at ")#mi("\\log(p) < log(T^{\\epsilon})")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40042")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("This question my be sightly off comment but out of curiosity…")

#text("A question regarding the Zeros of the Riemann’s Zeta.")

#text("I believe that Hardy proved the Riemann’s conjecture for an countable number of zeros.")

#text("I have been told that this has been improved so that the number of zeros is commensurate with the continuum!")

#text("Is this correct!??? If so please can you give any references!")

#text("Thanks in advance")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hezhigang")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40861")[#strong[#text("hezhigang")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2009")])]

#text("to infinite set, same cardinality can not imply equivalent.")#linebreak()#text(" card{n^2|n∈N}=card{n|n∈N}, but their elements are different in much detail.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb907bd6e02ba0882a72505fc0f0d6798d8a9a42a3aa267f2b05fb7663a880ac-63d101255ea20a2c5585bcc97c132cd5aa008a34363479e36a7c531a0b99bad1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex Kontorovich")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40044")[#strong[#text("Alex Kontorovich")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("Dear Terry,")

#text("Thanks for the interesting post. Since you also recently posted about Benford’s law, I wanted to mention a paper with Steve (J.) Miller:")

#link("http://arxiv.org/abs/math.NT/0412003")[#text("http://arxiv.org/abs/math.NT/0412003")]

#text("in which we show that the values of $L$-functions near the critical line exhibit Benford behavior, using generalizations of Selberg’s theorem. In the same paper we show that iterates in the 3x+1 problem are also Benford; there is also a subsequent paper of Lagarias and Sound on the matter:")

#link("http://arxiv.org/abs/math/0509175")[#text("http://arxiv.org/abs/math/0509175")]

#text("Best, Alex")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7b3e5d904932dcca1708db23de32f91876c5d738e9e38a82a3c4b079977be62-3c9b7fbd63c57ffdda02f638e1891c854749eed000a4484c3f40eb7843c3c9db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Emerton")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40050")[#strong[#text("Matthew Emerton")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("Dear Anonymous (at 4:51 am, July 14),")

#text("Any non-zero meromorphic function has only countably many zeroes, since the zeroes are a discrete set. In particular, the zeta function has only countably")#linebreak()#text(" many zeroes on the critical line.")

#text("Hardy proved that an infinite number of zeroes lie on the critical line, and this")#linebreak()#text(" result was later improved (by Selberg) to show that a positive proportion of zeroes lies on the line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80ccb94c50c8e6d0a52921d2fefac582aa1d3ebac54448350302574ce8356ca8-24efd013ca99410abff9c9208b75ce99123eaf724ac054de73c9e60339a01b2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2009")])]

#text("Hi everyone!")

#text("Slightly off topic…")

#text("There appears to be a revised version of some papers on the Archive")#linebreak()#text(" A Proof of the Density Hypothesis")#linebreak()#text(" ")#link("http://arxiv.org/abs/0810.2103")[#text("http://arxiv.org/abs/0810.2103")]#linebreak()#text(" Yuan-You Fu-Rui Cheng")

#text("Anything to this")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-43736")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2010")])]

#text("The revised version has been posted on Feb. 26, 2010.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-205027")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2012")])]

#link("http://arxiv.org/abs/0810.2103")[#text("http://arxiv.org/abs/0810.2103")]

#text("Yuanyou Cheng and Sergio Albeverio")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d132c66d23606535c4b4e8d713c86209508b72752f28a35baf38443bd0725f4-51166bded42be6a43b36baf9dde4f8351b2c435986218fcc64bbed81dbb70253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of zhiganghe")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40084")[#strong[#text("zhiganghe")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("some naive question:")#linebreak()#text(" in formula (3), is {\\rho} contains both trivial zeroes and complex zeroes?")#linebreak()#text(" why 1/(s-1)?")#linebreak()#text(" I understand it as s=1 is pole of zeta.")

#text("Lars V. Ahlfors said in Complex Analysis’ preface that ues of words ‘clearly’, ‘obviously’, ‘evidently’ to test the reader’s understanding.")

#text("as a layman to math, I can understand few lines of such professional blog")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40116")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2009")])]

#text("Thank you for presenting this.")

#text("Minor detail:")

#text("Are there a few missing minus signs? For example, it’s minus the logarithmic derivative of zeta which gives the von Mangoldt function. I think this applies to the left hand sides of equations (4), (5) and (7) — maybe more?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sika")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40344")[#strong[#text("Sika")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Dear professor, I believe that you have error/typo in remark 2.")

#text("sqrt(log log (n)) is standard deviation, not variance, for the number of prime factors of a large number n. ")#emph[#text("[Corrected, thanks – T.]")]

#text("Regards, sika")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40643")[#strong[#text("Michael Nielsen » Biweekly links for 07/24/2009")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")]

#text("[…] Selberg’s limit theorem for the Riemann zeta function on the critical line « What’s new […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fcb1ad3a5c5b7d36a8ac735026e985158ffb089118a652d71a9bbafbc70a6fb4-a1e38006801f1e16ecaf0152ddaad43c83c62861cb3f15b405806d07437c9347.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Valentina")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-40888")[#strong[#text("Valentina")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Dear Prof. Tao,")

#text("Thank you very much for the notes!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrea Alu")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-43431")[#strong[#text("Andrea Alu")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2010")])]

#text("Terry: congratulations on the King Faisal award. Will you be picking it up?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-43525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2010")])]

#text("You wrote: ‘(this is a heavily disguised variant of Stirling’s formula, as one can view the trivial zeroes as essentially being zeroes of the Gamma function)’")

#text("Did you mean ‘poles of the Gamma function’? (since the Gamma function doesn’t have zeros)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uncertainty principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-45696")[#strong[#text("The uncertainty principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2010")])]

#text("[…] e.g. this blog post of mine for more discussion). Using such formulae, one can relate the zeroes of the zeta function in the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a6f2f466b42ba9bce44eda3afa691b80b6254f8a0885b1b206ffa321718e3793-d98f9bf14638c90d14ed7177e3e926aea34c7c629aa1b35d6f367423692798f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duy")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-49091")[#strong[#text("Duy")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2010")])]

#text("Dear Prof. Tao,")

#text("I tried to find the proof of Selberg’s CLT and I found your interesting discussion here. Thank you very much. Actually, I have the book of Laurincikas but it is not so clear for me. Could you tell me where I can find the complete argument as you post here?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4e9eb08a589bd925e57bef55c4d1377bbe561374ca6317239a52adc348948c85-52a5a24c4e04374e3b1eb50774434695241e93efa7058ff018789dc5042f2da0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of polishchuk")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-434154")[#strong[#text("polishchuk")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("Reading the work of “N. Levinson, More than one third of the zeros of Riemann’s zeta-function are on a=1/2 (1974)” I thought that for molifier Selberg can apply the Riemann hypothesis and later use this new molifier. Terence Tao as you think it may affect the number of zeros or not? Thank you..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d187a34135d33024ccd60f2cf8f2ba799f7335215f14eafaabb7b7cabff71792-7c7c89e16274a42cc4cbdbf2e1764b959dacc78f4800a6cf730cd5956f3b4e24.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-481825")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2017")])]

#text("FYI: ")#link("https://www.researchgate.net/post/Does_the_nth_nontrivial_simple_zero_of_the_Riemann_zeta_function_indicate_the_nth_prime_p_n_occurs_as_a_prime_factor_in_all_multiples_of_p_n")[#text("https://www.researchgate.net/post/Does_the_nth_nontrivial_simple_zero_of_the_Riemann_zeta_function_indicate_the_nth_prime_p_n_occurs_as_a_prime_factor_in_all_multiples_of_p_n")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b31f1481b00bf8fcc2d94300c4160eb617a48f71b7fa87bf045d7a7cdbe6cbb6-082e0c6173edfc684f3271ff6dc0b0cb5a5ca86ee24a9ecaa73f72586e343a8f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2009/07/12/selbergs-limit-theorem-for-the-riemann-zeta-function-on-the-critical-line/#comment-523582")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2019")])]

#text("Dear Professor Tao,")#linebreak()#text(" Do we have any existing results in literature in which the Martingale Central Limit Theorem has the limit as a stable distribution instead of Normal distribution ?")
]
