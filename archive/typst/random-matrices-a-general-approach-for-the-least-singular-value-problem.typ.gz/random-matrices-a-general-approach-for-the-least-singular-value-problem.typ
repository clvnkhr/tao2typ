// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/
// Converted to Typst by tao2typ: "2026-10-14T15:16:47.365168+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: A general approach for the least singular value problem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: A general approach for the least singular value problem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 May 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/")[#text("https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/%7Evanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/0805.3167")[#text("Random matrices: A general approach for the least singular value problem")]#text("“, submitted to ")#link("http://www.ma.huji.ac.il/~ijmath/")[#text("Israel J. Math.")]#text(". This paper continues a recent series of papers ")#link("http://arxiv.org/abs/math.PR/0511215")[#text("by")]#text(" ")#link("http://arxiv.org/abs/math.PR/0703307")[#text("ourselves")]#text(" ")#link("http://arxiv.org/abs/0708.2895")[#text("and")]#text(" also ")#link("http://www.math.missouri.edu/~rudelson/papers/square-matrix.pdf")[#text("by")]#text(" ")#link("http://www.math.missouri.edu/~rudelson/papers/rectangular_matrix_CRAS.pdf")[#text("Rudelson")]#text(" and by ")#link("http://www.math.missouri.edu/~rudelson/papers/rv-invertibility.pdf")[#text("Rudelson")]#text("–")#link("http://www.math.missouri.edu/~rudelson/papers/rv-rectangular-matrices.pdf")[#text("Vershynin")]#text(" on understanding the least ")#link("http://en.wikipedia.org/wiki/Singular_value")[#text("singular value")]#text(" ")#tao-math("\\sigma_n(A) := \\inf_{\\left\\|v\\right\\|=1} \\left\\|Av\\right\\|", block: false)#text(" of a large random ")#mi("n \\times n")#text(" random complex matrix A. There are many random matrix models that one can consider, but here we consider models of the form ")#mi("A = M_n + N_n")#text(", where ")#mi("M_n = {\\Bbb E}(A)")#text(" is a deterministic matrix depending on n, and ")#mi("N_n")#text(" is a random matrix whose entries are ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("iid")]#text(" with some complex distribution x of mean zero and unit variance. (In particular, this model is useful for studying the normalised resolvents ")#mi("(\\frac{1}{\\sqrt{n}} N_n - zI)^{-1}")#text(" of random iid matrices ")#mi("N_n")#text(", which are of importance in the spectral theory of these matrices; understanding the least singular value of random perturbations of deterministic matrices is also important in numerical analysis, and particularly in ")#link("http://www.cs.yale.edu/homes/spielman/PAPERS/icm.pdf")[#text("smoothed analysis")]#text(" of algorithms such as the ")#link("http://en.wikipedia.org/wiki/Simplex_algorithm")[#text("simplex method")]#text(".)")

#text("In the model mean zero case ")#mi("M_n = 0")#text(", the normalised singular values ")#mi("\\frac{1}{\\sqrt{n}} \\sigma_1(A) \\geq \\ldots \\geq \\frac{1}{\\sqrt{n}} \\sigma_n(A) \\geq 0")#text(" of ")#mi("A = N_n")#text(" are known to be asymptotically distributed according to the Marchenko-Pastur distribution ")#mi("\\frac{1}{\\pi} (4-x^2)_+^{1/2} dx")#text(", which in particular implies that most of the singular values are continuously distributed (via a semicircular distribution) in the interval ")#mi("{}[0, 2\\sqrt{n}]")#text(". (Assuming only second moment hypotheses on the underlying distribution x, this result is due ")#link("http://www.ams.org/mathscinet-getitem?mr=862241")[#text("to Yin")]#text("; there are many earlier results assuming stronger hypotheses on x.) This strongly suggests, but does not formally prove, that the least singular value ")#mi("\\sigma_n(A)")#text(" should be of size ")#mi("\\sim 1/\\sqrt{n}")#text(" on the average. (To get such a sharp bound on the least singular value via the Marchenko-Pastur law would require an incredibly strong bound on the convergence rate to this law, which seems out of reach at present, especially when one does not assume strong moment conditions on x; current results such as those of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061442")[#text("Götze-Tikhomirov")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=2105745")[#text("Chatterjee-Bose")]#text(" give some upper bound on ")#mi("\\sigma_n(A)")#text(" which improves upon the trivial bound of ")#mi("O(n^{1/2})")#text(" by a polynomial factor assuming certain moment conditions on x, but as far as I am aware these bounds do not get close to the optimal value of ")#mi("O(n^{-1/2})")#text(", except perhaps in the special case when x is Gaussian.) The statement that ")#mi("\\sigma_n(A) \\sim 1/\\sqrt{n}")#text(" with high probability has been conjectured (in various forms) in a number of places, for instance by von Neumann, ")#link("http://www.ams.org/mathscinet-getitem?mr=799791")[#text("by Smale")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1989210")[#text("by Spielman-Teng")]#text(".")

#metadata(none) <tao-b89be0761062372b9c3a>

#text("There have been several papers establishing lower tail bounds on the least singular value consistent with the above conjecture of varying degrees of strength, under various hypotheses on the matrix ")#mi("M_n")#text(" and distribution x. For instance:")

#enum(start: 1, 
[#text("In 1988, ")#link("http://www.ams.org/mathscinet-getitem?mr=964668")[#text("Edelman showed")]#text(" that ")#mi("{\\Bbb P}( \\sigma_n(A) \\leq \\varepsilon/\\sqrt{n}) = O( \\varepsilon )")#text(" for any ")#mi("\\varepsilon > 0")#text(" when ")#mi("M_n=0")#text(" and x is Gaussian (there is also a matching lower bound when ")#mi("\\varepsilon = O(1)")#text(").")],
[#text("Some non-trivial bounds on ")#mi("{\\Bbb P}( \\sigma_n(A) \\leq \\varepsilon/\\sqrt{n})")#text(" for very small ")#mi("\\varepsilon")#text(" (polynomially small in size) are established implicitly in the case when ")#mi("M_n")#text(" is a multiple of the identity in the papers ")#link("http://www.ams.org/mathscinet-getitem?mr=2046403")[#text("of Girko")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=1428519")[#text("of Bai")]#text(" assuming some moment and continuity assumptions on x, although these bounds are not specified explicitly.")],
[#text("In 2005, ")#link("http://arxiv.org/abs/math/0507024")[#text("Rudelson showed")]#text(" that ")#mi("{\\Bbb P}( \\sigma_n(A) \\leq \\varepsilon/\\sqrt{n}) = O( n \\varepsilon + n^{-1/2})")#text(" when ")#mi("M_n=0")#text(" and x is subgaussian.")],
[#text("In 2005, ")#link("http://arxiv.org/abs/math/0511215")[#text("Van Vu and I showed")]#text(" that for every ")#mi("C_1 > 0")#text(" there existed ")#mi("C_2 > 0")#text(" such that ")#mi("{\\Bbb P}( \\sigma_n(A) \\leq n^{-C_2}) = O( n^{-C_1} )")#text(", when ")#mi("M_n=0")#text(" and x is the Bernoulli distribution (equal to +1 or -1 with a equal probability of each).")],
[#text("In 2006, ")#link("http://www.ams.org/mathscinet-getitem?mr=2255338")[#text("Senkar, Teng, and Spielman extended")]#text(" Edelman’s result to the case when ")#mi("M_n")#text(" is nonzero (but x is still Gaussian).")],
[#text("In 2007, ")#link("http://arxiv.org/abs/math/0703503")[#text("Rudelson-Vershynin showed")]#text(" that ")#mi("{\\Bbb P}( \\sigma_n(A) \\leq \\varepsilon/\\sqrt{n})")#text(" is bounded by ")#mi("O( \\varepsilon^c )")#text(" for ")#mi("\\varepsilon")#text(" independent of n when ")#mi("M_n=0")#text(" and x has bounded fourth moment, and is bounded by ")#mi("O( \\varepsilon + c^n)")#text(" for all ")#mi("\\varepsilon > 0")#text(" if x is subgaussian.")],
[#text("In 2007, ")#link("http://arxiv.org/abs/math/0703307")[#text("Van Vu and I showed")]#text(" that our earlier result extends to the case when ")#mi("M_n")#text(" is non-zero, as long as it has polynomial size in n and is also integer-valued; we also allow x to be more general than the Bernoulli distribution, but still integer-valued. (Our restriction to the integer case was due to a certain rounding trick that converted finite precision arithmetic to exact arithmetic, but only when the expressions involved ultimately come from integers.)")],
[#text("In 2007, ")#link("http://arxiv.org/abs/0708.2895")[#text("Van Vu and I removed")]#text(" the integrality assumptions on our previous results, thus establishing the bound ")#mi("{\\Bbb P}( \\sigma_n(A) \\leq n^{-C_2}) = O( n^{-C_1} )")#text(" whenever M has polynomial size and with no assumptions on x other than zero mean and unit variance. (See also my earlier ")#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")[#text("blog post")]#text(" on this paper.)")],
[#text("In 2008, ")#link("http://arxiv.org/abs/0802.3956")[#text("Rudelson and Vershynin")]#text(" obtained generalisations of their previous results to rectangular matrices (thus also generalising some previous work of ")#link("http://www.ams.org/mathscinet-getitem?mr=2146352")[#text("Litvak, Pajor, Rudelson, and Tomczak-Jaegermann")]#text("), but still for the case ")#mi("M_n=0")#text(" and with subgaussian hypotheses on x.")]
)

#text("These recent results are largely based on entropy (or “epsilon-net”) arguments, combined with conditioning arguments, with the entropy bounds in turn originating from inverse Littlewood-Offord theorems; see my ")#link("https://terrytao.wordpress.com/2008/03/18/lewis-lectures/")[#text("Lewis lectures")]#text(" for further discussion.")

#text("The current paper is a partial unification of the results of Rudelson and Vershynin (which give very sharp tail estimates, but under strong hypotheses on M and x) and ourselves (which have very general assumptions on M and x, but a weak tail estimate). A little more precisely, we obtain an estimate of the form")

#align(center)[#tao-fit-display[#tao-math("{\\Bbb P}( \\sigma_n(A) \\leq \\varepsilon/\\sqrt{n}) \\leq O( n^{o(1)} \\varepsilon + n^{-C} + {\\Bbb P}( \\left\\|N_n\\right\\| \\geq C \\sqrt{n} ) )", block: true)]]

#text("for any fixed ")#mi("C > 0")#text(", assuming that ")#tao-math("\\left\\|M\\right\\| = O(\\sqrt{n})", block: false)#text(". This result almost recovers those of Rudelson and Vershynin under subgaussian hypotheses on x (which are known to imply exponentially good bounds on ")#tao-math("{\\Bbb P}( \\left\\|N_n\\right\\| \\geq C \\sqrt{n} )", block: false)#text(") in the case when ")#mi("\\varepsilon")#text(" has polynomial size, except that we lose a factor of ")#mi("n^{o(1)}")#text(". One has analogous results here in which ")#tao-math("\\left\\|M\\right\\|", block: false)#text(" and ")#tao-math("\\left\\|N_n\\right\\|", block: false)#text(" are bounded by some weaker power of n than ")#mi("n^{1/2}")#text("; roughly speaking, if ")#tao-math("\\left\\|M\\right\\|", block: false)#text(" and ")#tao-math("\\left\\|N_n\\right\\|", block: false)#text(" have size ")#mi("O(n^\\gamma)")#text(", then we can show that ")#mi("\\sigma_n(A)")#text(" is at least ")#mi("n^{-(2C+1) \\gamma}")#text(" with probability ")#mi("1 - O(n^{-C+o(1)})")#text(" for any given C.")

#text("We also give a simple example that show that the deterioration of these bounds when ")#tao-math("\\left\\|M\\right\\|", block: false)#text(" gets large is necessary; in particular, we show that the universality of the bounds of Edelman type can break down once ")#tao-math("\\left\\|M\\right\\|", block: false)#text(" exceeds ")#mi("n^2")#text(", because one can design M to force the existence of an unusually small value of ")#mi("Av = (M +N_n)v")#text(" for a certain type of unit vector v.")

#text("Our methods here are based on those of earlier papers, particularly our ")#link("https://terrytao.wordpress.com/2007/08/23/random-matrices-the-circular-law/")[#text("circular law paper")]#text("; the key innovation is to run a certain scale pigeonholing argument as efficiently as possible, so that one only loses factors of ")#mi("n^{o(1)}")#text(" in the final bound.")

#text("[")#emph[#text("Update")]#text(", May 22: some typos corrected.]")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f427b2adbbafe637bc7ad05749cf67514f71ab6967eabb4a8f3796a19a52261-f6a680c04c34d61a608dd62a36e4ec4eb26fe2f1a6051efa9aa4bbde812b6ec4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/#comment-29996")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2008")])]

#text("I know this is quite a different question but maybe you know the answer: What happens over a finite field F, with N elements, say. If I pick the matrix elements independently with a flat distribution, what is the probability that the matrix A is not invertible? My guess would be 1/N, since one could imagine all elements but the last (a11 say) have been drawn already and det(A)= c1 + c2 a11 with some constants c1 and c2. If c2 does not vanish the determinant takes all N different values when a11 is varied but the case of c2=0 (some minor) it depends on the distribution of c1’s…")

#text("This problem came up in an encoding problem: There (imagine for example a RAID system) you want to spread information between a number of different people. For example the data are many (say L) vectors in F^k and everybody in a room has access to those vectors. However they cannot remember kL numbers. But if everybody picks one random vector and projects all the L vectors on that random vector and just remebers the random vector and the L scalar products. Then the full information can likely be reconstructed by any choice of k people (namely if their random vectors are linearly independent). So I am asking what is the probability that this fails?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of enric")]], [#link("https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/#comment-29998")[#strong[#text("enric")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2008")])]

#text("wow, you can also prove theorems in the future!")

#text("(e.g., item 9)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/#comment-30002")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2008")])]

#text("For the question in Comment 1 (if I understand it right) for matrrices of size ")#mi("n")#text(", the probability you want seems to be simply one minus the ratio of the order of the group of invertible matrices divided by ")#mi("N^{n^2}")#text(". The order of the group of invertible matrices is well-known, and one finds this probability is")

#mi("1-\\prod_{k=1}^n{(1-N^{-k})}")

#text("which has a limit (for fixed ")#mi("N")#text(") as ")#mi("n")#text(" goes to infinity (one minus the inverse of the generating series of the partition function, evaluated at ")#mi("z=1/N")#text("). This is indeed asymptotic to ")#mi("1/N")#text(" by Taylor expansion, when ")#mi("N")#text(" is large.")

#text("Because the answer is explicit, one can also understand the behavior in many mixed situations when both ")#mi("N")#text(" and the size ")#mi("n")#text(" of the matrices are fixed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/#comment-30006")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2008")])]

#text("Dear Enric: Oops, thanks for the correction!")

#text("Dear Robert: Emmanuel is correct. One way to see the fact that the probability of being invertible is ")#mi("\\prod_{k=1}^n (1 - N^{-k})")#text(" is to expose one row at a time. After k-1 rows have been exposed, and conditioning on the event that they are already linearly independent, the probability that the k^th row is going to be linearly independent of all previous rows is ")#mi("(1 - N^{-k})")#text(". Multiplying all these conditional probabilities together gives the claim.")

#text("There is also a paper of Kahn and Komlos that investigates this problem for slightly different matrix models (e.g. random +1/-1 matrices over finite fields):")

#link("http://www.ams.org/mathscinet-getitem?mr=1833067")[#text("http://www.ams.org/mathscinet-getitem?mr=1833067")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f427b2adbbafe637bc7ad05749cf67514f71ab6967eabb4a8f3796a19a52261-f6a680c04c34d61a608dd62a36e4ec4eb26fe2f1a6051efa9aa4bbde812b6ec4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert")]], [#link("https://terrytao.wordpress.com/2008/05/22/random-matrices-a-general-approach-for-the-least-singular-value-problem/#comment-30047")[#strong[#text("Robert")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2008")])]

#text("Thanks for the help!")

#text("I guess, the question I really wanted to ask is: What is the best strategy to come up with many vectors in F^k such that the the probability that a random selection of k of those is linearly independent? Again my guess would be that you cannot do better than picking (non-zero) random vectors and then the probability is what you write.")
]
