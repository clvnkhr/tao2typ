// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/
// Converted to Typst by tao2typ: "2026-10-14T16:37:12.864149+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Notes on simple groups of Lie type", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Notes on simple groups of Lie type")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 September 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/")[#text("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("this previous post")]#text(" I recorded some (very standard) material on the structural theory of finite-dimensional complex ")#link("http://en.wikipedia.org/wiki/Lie_algebra")[#text("Lie algebras")]#text(" (or ")#emph[#text("Lie algebras")]#text(" for short), with a particular focus on those Lie algebras which were ")#link("http://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple")]#text(" or ")#link("http://en.wikipedia.org/wiki/Simple_Lie_algebra")[#text("simple")]#text(". Among other things, these notes discussed the Weyl complete reducibility theorem (asserting that semisimple Lie algebras are the direct sum of simple Lie algebras) and the classification of simple Lie algebras (with all such Lie algebras being (up to isomorphism) of the form ")#mi("{A_n}")#text(", ")#mi("{B_n}")#text(", ")#mi("{C_n}")#text(", ")#mi("{D_n}")#text(", ")#mi("{E_6}")#text(", ")#mi("{E_7}")#text(", ")#mi("{E_8}")#text(", ")#mi("{F_4}")#text(", or ")#mi("{G_2}")#text(").")

#text("Among other things, the structural theory of Lie algebras can then be used to build analogous structures in nearby areas of mathematics, such as ")#link("http://en.wikipedia.org/wiki/Lie_group")[#text("Lie groups")]#text(" and Lie algebras over more general fields than the complex field ")#mi("{{\\bf C}}")#text(" (leading in particular to the notion of a ")#link("http://en.wikipedia.org/wiki/Group_of_Lie_type")[#text("Chevalley group")]#text("), as well as ")#link("http://en.wikipedia.org/wiki/Group_of_Lie_type")[#text("finite simple groups of Lie type")]#text(", which form the bulk of the ")#link("http://en.wikipedia.org/wiki/Classification_of_finite_simple_groups")[#text("classification of finite simple groups")]#text(" (with the exception of the ")#link("http://en.wikipedia.org/wiki/Alternating_group")[#text("alternating groups")]#text(" and a finite number of ")#link("http://en.wikipedia.org/wiki/Sporadic_groups")[#text("sporadic groups")]#text(").")

#text("In the case of complex Lie groups, it turns out that every simple Lie algebra ")#mi("{\\mathfrak{g}}")#text(" is associated with a finite number of connected complex Lie groups, ranging from a “minimal” Lie group ")#mi("{G_{ad}}")#text(" (the ")#emph[#text("adjoint form")]#text(" of the Lie group) to a “maximal” Lie group ")#mi("{\\tilde G}")#text(" (the ")#emph[#text("simply connected form")]#text(" of the Lie group) that finitely covers ")#mi("{G_{ad}}")#text(", and occasionally also a number of intermediate forms which finitely cover ")#mi("{G_{ad}}")#text(", but are in turn finitely covered by ")#mi("{\\tilde G}")#text(". For instance, ")#mi("{\\mathfrak{sl}_n({\\bf C})}")#text(" is associated with the projective special linear group ")#mi("{\\text{PSL}_n({\\bf C}) = \\text{PGL}_n({\\bf C})}")#text(" as its adjoint form and the special linear group ")#mi("{\\text{SL}_n({\\bf C})}")#text(" as its simply connected form, and intermediate groups can be created by quotienting out ")#mi("{\\text{SL}_n({\\bf C})}")#text(" by some subgroup of its centre (which is isomorphic to the ")#mi("{n^{th}}")#text(" roots of unity). The minimal form ")#mi("{G_{ad}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Simple_group")[#text("simple")]#text(" in the group-theoretic sense of having no normal subgroups, but the other forms of the Lie group are merely ")#link("http://en.wikipedia.org/wiki/Quasisimple_group")[#text("quasisimple")]#text(", although traditionally all of the forms of a Lie group associated to a simple Lie algebra are known as ")#emph[#text("simple Lie groups")]#text(".")

#text("Thanks to the work of Chevalley, a very similar story holds for algebraic groups over arbitrary fields ")#mi("{k}")#text("; given any Dynkin diagram, one can define a simple Lie algebra with that diagram over that field, and also one can find a finite number of connected algebraic groups over ")#mi("{k}")#text(" (known as ")#emph[#text("Chevalley groups")]#text(") with that Lie algebra, ranging from an adjoint form ")#mi("{G_{ad}}")#text(" to a universal form ")#mi("{G_u}")#text(", with every form having an ")#link("http://en.wikipedia.org/wiki/Isogeny")[#text("isogeny")]#text(" (the analogue of a finite cover for algebraic groups) to the adjoint form, and in turn receiving an isogeny from the universal form. Thus, for instance, one could construct the universal form ")#mi("{E_7(q)_u}")#text(" of the ")#mi("{E_7}")#text(" algebraic group over a finite field ")#mi("{{\\bf F}_q}")#text(" of finite order.")

#text("When one restricts the Chevalley group construction to adjoint forms over a finite field (e.g. ")#mi("{\\text{PSL}_n({\\bf F}_q)}")#text("), one usually obtains a finite simple group (with a finite number of exceptions when the rank and the field are very small, and in some cases one also has to pass to a bounded index subgroup, such as the derived group, first). One could also use other forms than the adjoint form, but one then recovers the same finite simple group as before if one quotients out by the centre. This construction was then extended by Steinberg, Suzuki, and Ree by taking a Chevalley group over a finite field and then restricting to the fixed points of a certain automorphism of that group; after some additional minor modifications such as passing to a bounded index subgroup or quotienting out a bounded centre, this gives some additional finite simple groups of Lie type, including classical examples such as the projective special unitary groups ")#mi("{\\text{PSU}_n({\\bf F}_{q^2})}")#text(", as well as some more exotic examples such as the ")#link("http://en.wikipedia.org/wiki/Suzuki_groups")[#text("Suzuki groups")]#text(" or the ")#link("http://en.wikipedia.org/wiki/Ree_group")[#text("Ree groups")]#text(".")

#text("While I learned most of the classical structural theory of Lie algebras back when I was an undergraduate, and have interacted with Lie groups in many ways in the past (most recently in connection with ")#link("http://en.wikipedia.org/wiki/Hilbert%27s_fifth_problem")[#text("Hilbert’s fifth problem")]#text(", as discussed in ")#link("https://terrytao.wordpress.com/category/teaching/254a-hilberts-fifth-problem/")[#text("this previous series of lectures")]#text("), I have only recently had the need to understand more precisely the concepts of a Chevalley group and of a finite simple group of Lie type, as well as better understand the structural theory of simple complex Lie groups. As such, I am recording some notes here regarding these concepts, mainly for my own benefit, but perhaps they will also be of use to some other readers. The material here is standard, and was drawn from a number of sources, but primarily from ")#link("http://www.ams.org/mathscinet-getitem?mr=794307")[#text("Carter")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=1490581")[#text("Gorenstein-Lyons-Solomon")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1153249")[#text("Fulton-Harris")]#text(", as well as ")#link("http://www.math.ucla.edu/~rst/YaleNotes.pdf")[#text("the lecture notes on Chevalley groups")]#text(" by my colleague Robert Steinberg. The arrangement of material also reflects my own personal preferences; in particular, I tend to favour complex-variable or Riemannian geometry methods over algebraic ones, and this influenced a number of choices I had to make regarding how to prove certain key facts. The notes below are far from a comprehensive or fully detailed discussion of these topics, and I would refer interested readers to the references above for a properly thorough treatment.")

#metadata(none) <tao-604841805e1bc19cf761>

#heading(level: 1)[#strong[#text(" — 1. Simple Lie groups over ")#mi("{{\\bf C}}")#text(" — ")]]

#text("We begin with some discussion of Lie groups ")#mi("{G}")#text(" over the complex numbers ")#mi("{{\\bf C}}")#text(". We will restrict attention to the connected Lie groups, since more general Lie groups can be factored")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow G^\\circ \\rightarrow G \\rightarrow G/G^\\circ \\rightarrow 0")]]

#text("into an extension of an (essentially arbitrary) discrete group ")#mi("{G/G^\\circ}")#text(" by the connected component ")#mi("{G^\\circ}")#text(" (or, in the ")#link("http://en.wikipedia.org/wiki/ATLAS_of_Finite_Groups")[#text("ATLAS")]#text(" notation of ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("the previous post")]#text(", ")#mi("{G = G^\\circ . (G/G^\\circ)}")#text("). One can interpret ")#mi("{G^\\circ}")#text(" as the minimal open subgroup of ")#mi("{G}")#text(", thus a Lie group is connected if and only if there are no proper open subgroups.")

#text("To each Lie group ")#mi("{G}")#text(" over ")#mi("{{\\bf C}}")#text(" one can associate a complex Lie algebra ")#mi("{{\\mathfrak g}}")#text(", which one can identify with the tangent space of ")#mi("{G}")#text(" at the identity. This identification is however not injective; one can have non-isomorphic Lie groups with the same Lie algebra. For instance, the special linear group ")#mi("{\\text{SL}_2({\\bf C})}")#text(" and the projective special linear group ")#mi("{\\text{PSL}_2({\\bf C}) = \\text{SL}_2({\\bf C}) / \\{+1,-1\\}}")#text(" have the same Lie algebra ")#mi("{\\mathfrak{sl}_2({\\bf C})}")#text("; intuitively, the Lie algebra captures all the “local” information of the Lie group but not the “global” or “topological” information. (This statement can be made more precise using the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdorff formula")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("this previous post")]#text(".) On the other hand, every connected Lie group ")#mi("{G}")#text(" has a ")#link("http://en.wikipedia.org/wiki/Covering_space")[#text("universal cover")]#text(" ")#mi("{\\tilde G}")#text(" with the same Lie algebra (up to isomorphism) as ")#mi("{G}")#text(", which is a simply connected Lie group which projects onto ")#mi("{G}")#text(" by a short exact sequence")

#align(center)[#tao-fit-display[#mitex("0 \\rightarrow \\pi_1(G) \\rightarrow \\tilde G \\rightarrow G \\rightarrow 0")]]

#text("with ")#mi("{\\pi_1(G)}")#text(" being (an isomorphic copy of) the (topological) ")#link("http://en.wikipedia.org/wiki/Fundamental_group")[#text("fundamental group")]#text(" of ")#mi("{G}")#text(". Furthermore, two Lie groups have the same Lie algebra (up to isomorphism) if and only if their universal covers agree (up to isomorphism); this is essentially ")#emph[#text("Lie’s second theorem")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("this previous blog post")]#text(" (in the context of Lie groups and Lie algebras over the reals rather than the complex numbers, but the result holds over both fields). Conversely, every Lie algebra is the Lie algebra of some Lie group, and thus of some simply connected Lie group; this is essentially ")#link("http://en.wikipedia.org/wiki/Lie%27s_third_theorem")[#text("Lie’s third theorem")]#text(", also discussed at the above post. Thus, the Lie groups associated to a given Lie algebra ")#mi("{{\\mathfrak g}}")#text(" can all be viewed as quotients of a universal cover ")#mi("{\\tilde G}")#text(" by a discrete normal subgroup ")#mi("{\\Gamma}")#text(".")

#text("We can say a little more about the fundamental group ")#mi("{\\pi_1(G)}")#text(". Observe that ")#mi("{\\tilde G}")#text(" acts by conjugation on ")#mi("{\\pi_1(G)}")#text("; however, ")#mi("{\\pi_1(G)}")#text(" is discrete, and so the automorphism group of ")#mi("{\\pi_1(G)}")#text(" is discrete also. Since ")#mi("{\\tilde G}")#text(" is connected, we conclude that the action of ")#mi("{\\tilde G}")#text(" on ")#mi("{\\pi_1(G)}")#text(" is trivial; in other words, ")#mi("{\\pi_1(G)}")#text(" is a ")#emph[#text("central")]#text(" subgroup of ")#mi("{G}")#text(" (and so ")#mi("{\\tilde G}")#text(" is a central extension of ")#mi("{G}")#text("). In particular, the fundamental group ")#mi("{\\pi_1(G)}")#text(" of a connected Lie group ")#mi("{G}")#text(" is always abelian. (Of course, fundamental groups can be non-abelian for more general topological spaces; the key property of Lie groups that are being used here is that they are ")#link("http://en.wikipedia.org/wiki/H-space")[#text("H-spaces")]#text(".)")

#text("Not every subgroup of a Lie group is again a Lie group; for instance, the rational numbers ")#mi("{{\\bf Q}}")#text(" are a subgroup of the one-dimensional complex Lie group ")#mi("{{\\bf C}}")#text(" but are clearly not a Lie group. However, a basic theorem of Cartan (proven in ")#link("https://terrytao.wordpress.com/2011/09/08/254a-notes-2-building-lie-structure-from-representations-and-metrics/")[#text("this previous post")]#text(") says that any subgroup of a ")#emph[#text("real")]#text(" Lie group which is ")#emph[#text("topologically")]#text(" closed, is also a real Lie group. This theorem doesn’t directly apply in the complex case (for instance ")#mi("{{\\bf R}}")#text(" is a subgroup of the complex Lie group ")#mi("{{\\bf C}}")#text(" but is only a real Lie group rather than a complex one), but it does say that a closed subgroup of a complex Lie group is a real Lie group, and if in addition one knows that the real tangent space of the subgroup at the origin is closed under complex multiplication then it becomes a complex Lie group again.")

#text("We expect properties about the Lie algebra ")#mi("{{\\mathfrak g}}")#text(" to translate to analogous properties about the Lie group ")#mi("{G}")#text(". In the case of simple Lie algebras, we have the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" Let ")#mi("{G}")#text(" be a connected complex Lie group with Lie algebra ")#mi("{{\\mathfrak g}}")#text(". Then the following are equivalent:")

#list(
[#mi("{{\\mathfrak g}}")#text(" is a simple Lie algebra.")],
[#mi("{G}")#text(" is non-abelian, and the only closed normal subgroups of ")#mi("{G}")#text(" are discrete or all of ")#mi("{G}")#text(".")],
[#mi("{G}")#text(" is non-abelian, and the only normal subgroups of ")#mi("{G}")#text(" are discrete or all of ")#mi("{G}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{{\\mathfrak g}}")#text(" is simple (which implies that ")#mi("{{\\mathfrak g}}")#text(", and hence ")#mi("{G}")#text(", is non-abelian), but ")#mi("{G}")#text(" has a closed normal subgroup ")#mi("{H}")#text(" which is not discrete or all of ")#mi("{G}")#text(", then by Cartan’s theorem it is a real Lie group with positive dimension. Then the Lie algebra ")#mi("{{\\mathfrak h}}")#text(" of ")#mi("{H}")#text(" is a non-trivial real Lie algebra which is preserved by the adjoint action of ")#mi("{{\\mathfrak g}}")#text(". If ")#mi("{{\\mathfrak h}={\\mathfrak g}}")#text(" then ")#mi("{H}")#text(" contains a neighbourhood of the identity in ")#mi("{G}")#text(" and is thus all of ")#mi("{G}")#text(" as ")#mi("{G}")#text(" is connected, so ")#mi("{{\\mathfrak h}}")#text(" is a proper subalgebra of ")#mi("{{\\mathfrak g}}")#text(". Note that ")#mi("{[{\\mathfrak h}, {\\mathfrak g}]}")#text(" is a complex Lie algebra ideal of ")#mi("{{\\mathfrak g}}")#text(", so by simplicity this ideal is trivial, thus ")#mi("{{\\mathfrak h}}")#text(" lies in the centre of ")#mi("{{\\mathfrak g}}")#text(", which is again trivial by simplicity, a contradiction.")

#text("If ")#mi("{H}")#text(" is normal but not closed, one can adapt the above argument as follows. If ")#mi("{H}")#text(" is central then it is discrete (because ")#mi("{{\\mathfrak g}}")#text(" is centreless) so assume that ")#mi("{H}")#text(" is not central, then it contains a non-trivial conjugacy class; after translation this means that ")#mi("{H}")#text(" contains a curve through the identity whose derivative at the identity is a non-zero vector ")#mi("{v}")#text(" in ")#mi("{{\\mathfrak g}}")#text(". As ")#mi("{{\\mathfrak g}}")#text(" is simple, ")#mi("{{\\mathfrak g}}")#text(" is the minimal ideal generated by ")#mi("{v}")#text(", which implies that the orbit of ")#mi("{v}")#text(" under the adjoint action of ")#mi("{G}")#text(" spans ")#mi("{{\\mathfrak g}}")#text(" as a linear space, thus there are a finite number of ")#mi("{G}")#text("-conjugates of ")#mi("{v}")#text(" that form a basis for ")#mi("{{\\mathfrak g}}")#text(". Lifting back up to ")#mi("{G}")#text(" and using the inverse function theorem, we conclude that ")#mi("{H}")#text(" contains an open neighbourhood of the identity and is thus all of ")#mi("{G}")#text(".")

#text("Now suppose that ")#mi("{{\\mathfrak g}}")#text(" is not simple. If it has a non-trivial abelian ideal, then one can exponentiate this ideal and take closures to obtain a closed normal abelian subgroup of ")#mi("{G}")#text(", which is not all of ")#mi("{G}")#text(" as ")#mi("{G}")#text(" is non-abelian, and which is complex because the ideal is a complex vector space. So we may assume that no such ideal exists, which means (see Theorem 1 from ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("the previous set of notes")]#text(") that ")#mi("{{\\mathfrak g}}")#text(" is semisimple and thus the direct sum ")#mi("{{\\mathfrak g}_1 \\oplus \\ldots \\oplus {\\mathfrak g}_k}")#text(" of simple algebras for some ")#mi("{k \\geq 2}")#text(". If we then take ")#mi("{H}")#text(" to be the subgroup of ")#mi("{G}")#text(" whose adjoint action on ")#mi("{{\\mathfrak g}}")#text(" is the identity on ")#mi("{{\\mathfrak g}_1}")#text(", then ")#mi("{H}")#text(" is a closed subgroup of ")#mi("{G}")#text(", thus a real Lie group, and also a complex Lie group as the tangent space is ")#mi("{{\\mathfrak g}_2 \\oplus \\ldots \\oplus {\\mathfrak g}_k}")#text(", giving a closed normal subgroup of intermediate dimension. ")#mi("\\Box")

#text("In view of this lemma, we call a connected complex Lie group ")#emph[#text("simple")]#text(" if it is non-abelian and the only closed normal subgroups of ")#mi("{G}")#text(" are discrete or all of ")#mi("{G}")#text(". This differs slightly from the group-theoretic notion of simplicity, which asserts instead that the only normal subgroups of ")#mi("{G}")#text(" (including the non-closed normal subgroups) are ")#emph[#text("trivial")]#text(" or all of ")#mi("{G}")#text(". However, these two notions are actually not that far apart from each other. Firstly, given a simple Lie algebra ")#mi("{{\\mathfrak g}}")#text(", one can form the ")#emph[#text("adjoint form")]#text(" ")#mi("{G_{ad}}")#text(" of the associated Lie group, defined as the closed subgroup of the general linear group ")#mi("{GL({\\mathfrak g})}")#text(" on ")#mi("{{\\mathfrak g}}")#text(" generated by the transformations ")#mi("{\\text{Ad}_x := \\exp( \\text{ad} x)}")#text(" for ")#mi("{x \\in {\\mathfrak g}}")#text(". This is group is clearly connected. Because all such transformations are ")#link("http://en.wikipedia.org/wiki/Derivation_(abstract_algebra)")[#text("derivations")]#text(" on ")#mi("{{\\mathfrak g}}")#text(", and derivations on a simple Lie algebra are inner (see Lemma 8 from ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("previous notes")]#text("), we see that the tangent space of this group is ")#mi("{\\text{ad} {\\mathfrak g}}")#text(", which is isomorphic to ")#mi("{{\\mathfrak g}}")#text(" as ")#mi("{{\\mathfrak g}}")#text(" is simple (and thus centerless). In particular, ")#mi("{G_{ad}}")#text(" is a complex Lie group whose Lie algebra is ")#mi("{{\\mathfrak g}}")#text(". Furthermore, any other connected complex Lie group ")#mi("{G}")#text(" with Lie algebra ")#mi("{{\\mathfrak g}}")#text(" will map by a continuous homomorphism to ")#mi("{G_{ad}}")#text(" by the conjugation action of ")#mi("{G}")#text(" on ")#mi("{{\\mathfrak g}}")#text("; this map is open near the origin, and so this homomorphism is surjective. Thus, ")#mi("{G}")#text(" is a discrete cover of ")#mi("{G_{ad}}")#text(", much as ")#mi("{\\tilde G}")#text(" is a discrete cover of ")#mi("{G}")#text(", and so all the Lie groups ")#mi("{G}")#text(" with Lie algebra ")#mi("{{\\mathfrak g}}")#text(" are sandwiched between the universal cover ")#mi("{\\tilde G}")#text(" and the adjoint form ")#mi("{G_{ad}}")#text(". The same argument shows that ")#mi("{G_{ad}}")#text(" itself has no non-trivial discrete normal subgroups, as one could then have non-trivial quotients of ")#mi("{G_{ad}}")#text(" which still somehow cover ")#mi("{G_{ad}}")#text(" by an inverse of the quotient map, which is absurd. Thus the adjoint form ")#mi("{G_{ad}}")#text(" of the Lie group is simple in the group-theoretic sense, but none of the other forms are (since they can be quotiented down to ")#mi("{G_{ad}}")#text("). In particular, ")#mi("{G_{ad}}")#text(" is centerless, so given any of the other covers ")#mi("{G}")#text(" of ")#mi("{G_{ad}}")#text(", the kernel of the projection of ")#mi("{G}")#text(" to ")#mi("{G_{ad}}")#text(" is precisely ")#mi("{Z(G)}")#text(", thus ")#mi("{G_{ad} \\equiv G/Z(G)}")#text(" for any of the Lie group forms ")#mi("{G}")#text(".")

#text("Note that for any form ")#mi("{G}")#text(" of the Lie group associated to the simple Lie algebra ")#mi("{{\\mathfrak g}}")#text(", the commutator group ")#mi("{[G,G]}")#text(" contains a neighbourhood of the origin (as ")#mi("{{\\mathfrak g}}")#text(" is ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect")]#text(") and so is all of ")#mi("{G}")#text(". Thus we see that while any given form ")#mi("{G}")#text(" of the Lie group is not necessarily simple in the group-theoretic sense, it is ")#link("http://en.wikipedia.org/wiki/Quasisimple_group")[#text("quasisimple")]#text(", that is to say it is a perfect central extension of a simple group.")

#text("It is now of interest to understand the fundamental group ")#mi("{\\pi(G_{ad})}")#text(" of the adjoint form ")#mi("{G_{ad}}")#text(", as this measures the gap between ")#mi("{\\tilde G}")#text(" and ")#mi("{G_{ad}}")#text(" and will classify all the intermediate forms ")#mi("{G}")#text(" of the Lie group associated to ")#mi("{{\\mathfrak g}}")#text(" (as these all arise from quotienting ")#mi("{\\tilde G}")#text(" by some subgroup of ")#mi("{\\pi(G_{ad})}")#text("). For this we have the following very useful tool:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Existence of compact form)")]#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a simple complex Lie algebra, and let ")#mi("{G_{ad} \\subset GL({\\mathfrak g})}")#text(" be its adjoint form. Then there exists a compact subgroup ")#mi("{G_c}")#text(" of ")#mi("{G_{ad}}")#text(" with Lie algebra ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(", where ")#mi("{{\\mathfrak g}_{\\bf R}}")#text(" is a real Lie algebra that complexifies to ")#mi("{{\\mathfrak g}}")#text(", thus ")#mi("{{\\mathfrak g} = {\\mathfrak g}_{\\bf R} \\oplus i{\\mathfrak g}_{\\bf R}}")#text(". Furthermore, every element ")#mi("{A}")#text(" in ")#mi("{G_{ad}}")#text(" has a unique ")#link("http://en.wikipedia.org/wiki/Polar_decomposition")[#text("polar decomposition")]#text(" ")#mi("{A = DU}")#text(", where ")#mi("{U \\in G_c}")#text(" and ")#mi("{D \\in \\text{exp}({\\mathfrak g}_{\\bf R})}")#text(".")
]

#emph[#text("Proof:")]#text(" Before we begin the proof, we give a (morally correct) example of the lemma: take ")#mi("{{\\mathfrak g} = {\\mathfrak sl}_n({\\bf C})}")#text(", and replace ")#mi("{G_{ad}}")#text(" by ")#mi("{\\text{SL}_n({\\bf C})}")#text(" (this is not the adjoint form of ")#mi("{{\\mathfrak g}}")#text(", but never mind this). Then the obvious choice of compact form is the special unitary group ")#mi("{G_c = SU_n({\\bf C})}")#text(", which has as Lie algebra the real algebra ")#mi("{i{\\mathfrak su}_n({\\bf C})}")#text(" of skew-adjoint transformations of trace zero. This suggests that we need a notion of “adjoint” ")#mi("{*: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" for more general Lie algebras ")#mi("{{\\mathfrak g}}")#text(" in order to extract the skew-adjoint ones.")

#text("We now perform this construction. As discussed in ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("the previous set of notes")]#text(", ")#mi("{{\\mathfrak g}}")#text(" has a ")#link("http://www.encyclopediaofmath.org/index.php/Cartan-Weyl_basis")[#text("Cartan-Weyl basis")]#text(" consisting of vectors ")#mi("{E_\\alpha}")#text(" for roots ")#mi("{\\alpha \\in \\Phi}")#text(" as well as co-roots ")#mi("{H_\\alpha}")#text(" for simple roots ")#mi("{\\alpha}")#text(" (with the ")#mi("{H_\\beta}")#text(" for other roots ")#mi("{\\beta}")#text(" then expressed as linear combinations of the simple co-roots ")#mi("{H_\\alpha}")#text(", and where we have fixed some direction ")#mi("{h}")#text(" in which to define the notions of positive and simple roots), obeying the relations")

#align(center)[#tao-fit-display[#mitex("[H_\\alpha,H_\\beta] = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("[H_\\alpha,E_\\beta] = A_{\\alpha,\\beta} E_\\beta")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("[E_\\alpha,E_{-\\alpha}] = H_\\alpha")]]

#text("as well as the relation")

#align(center)[#tao-fit-display[#mitex("[E_\\alpha,E_\\beta] = N_{\\alpha,\\beta} E_{\\alpha+\\beta}")]]

#text("when ")#mi("{\\alpha \\neq -\\beta}")#text(" and some integers ")#mi("{A_{\\alpha,\\beta}, N_{\\alpha,\\beta}}")#text(", with the convention that ")#mi("{E_\\alpha}")#text(" vanishes when ")#mi("{\\alpha}")#text(" is not a root. We can also arrange matters so that ")#mi("{N_{\\alpha,\\beta} = N_{-\\alpha,-\\beta}}")#text("; see Lemma 31 of ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("the previous notes")]#text(". If we then define the adjoint map ")#mi("{*: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" to be the antilinear map that preserves all the co-roots ")#mi("{H_\\alpha}")#text(", but maps ")#mi("{E_\\alpha}")#text(" to ")#mi("{E_{-\\alpha}}")#text(" for all ")#mi("{\\alpha}")#text(", one easily verifies that ")#mi("{*}")#text(" is an anti-homomorphism, so that ")#mi("{[X^*,Y^*] = -[X,Y]^*}")#text(" for all ")#mi("{X,Y \\in {\\mathfrak g}}")#text(". Furthermore, one can now make ")#mi("{{\\mathfrak g}}")#text(" into a complex Hilbert space with the Hermitian form ")#mi("{\\langle X, Y\\rangle := K(X,Y^*)}")#text(" (with ")#mi("{K}")#text(" being the ")#link("http://en.wikipedia.org/wiki/Killing_form")[#text("Killing form")]#text("), which one can verify using the Cartan-Weyl basis to be positive definite (indeed the Cartan-Weyl basis becomes an orthogonal basis with this Hermitian form). For any ")#mi("{X \\in {\\mathfrak g}}")#text(", one can also verify that the maps ")#mi("{\\text{ad} X: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" and ")#mi("{\\text{ad} X^*: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" are adjoints with respect to this Hermitian form.")

#text("If we now set ")#mi("{{\\mathfrak g}_{\\bf R} := \\{ X \\in {\\mathfrak g}: X^* = X \\}}")#text(" to be the self-adjoint elements of ")#mi("{{\\mathfrak g}}")#text(", and ")#mi("{G_c}")#text(" to be those elements of ")#mi("{G_{ad}}")#text(" that are unitary with respect to the Hermitian form, we see that ")#mi("{{\\mathfrak g}_{\\bf R}}")#text(" complexifies to ")#mi("{{\\mathfrak g}}")#text(" and ")#mi("{G_c}")#text(" is a compact group with real Lie algebra ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(". Also, since ")#mi("{\\text{ad} X}")#text(" is the adjoint of ")#mi("{\\text{ad} X^*}")#text(", we see that ")#mi("{G_{ad}}")#text(" is closed under the operation of taking adjoints.")

#text("Now we obtain the polar decomposition. If ")#mi("{A \\in G_{ad}}")#text(", then ")#mi("{AA^*}")#text(" is a self-adjoint positive definite map on the Hilbert space ")#mi("{{\\mathfrak g}}")#text(", which also lies in ")#mi("{G_{ad}}")#text(" and thus respects the Lie bracket: ")#mi("{AA^*[X,Y] = [AA^* X, AA^* Y]}")#text(". By diagonalising ")#mi("{AA^*}")#text(" and working with the structure constants of the Lie bracket in the eigenbasis of ")#mi("{AA^*}")#text(" we conclude that all powers ")#mi("{(AA^*)^t}")#text(" for ")#mi("{t>0}")#text(" also respect the Lie bracket; sending ")#mi("{t \\rightarrow 0}")#text(" we conclude that ")#mi("{\\log AA^*}")#text(" is a derivation of ")#mi("{{\\mathfrak g}}")#text(", and thus inner, which implies that ")#mi("{(AA^*)^t \\in G_{ad}}")#text(" for all ")#mi("{t>0}")#text(". In particular the square root ")#mi("{D := (AA^*)^{1/2}}")#text(" lies in ")#mi("{G_{ad}}")#text(". Setting ")#mi("{U := D^{-1} A}")#text(" we obtain the required polar decomposition; the uniqueness can be obtained by observing that ")#mi("{DU = A}")#text(" implies ")#mi("{D = (AA^*)^{1/2}}")#text(". ")#mi("\\Box")

#text("From the polar decomposition we see that ")#mi("{G_{ad}}")#text(" can be contracted onto ")#mi("{G_c}")#text(" (by deforming ")#mi("{DU}")#text(" as ")#mi("{D^t U}")#text(" as ")#mi("{t}")#text(" goes from ")#mi("{1}")#text(" to ")#mi("{0}")#text("). In particular, ")#mi("{G_c}")#text(" is connected and has the same fundamental group as ")#mi("{G_{ad}}")#text(". On the other hand, the Hermitian form ")#mi("{\\langle,\\rangle}")#text(" restricts to a real positive definite form on the tangent space of ")#mi("{G_c}")#text(" that is invariant with respect to the conjugation action of ")#mi("{G_c}")#text(", and thus defines a ")#link("http://en.wikipedia.org/wiki/Riemannian_metric#Riemannian_metrics")[#text("Riemannian metric")]#text(" on ")#mi("{G_c}")#text(". The definiteness of the Killing form then impolies (after some computation) that this metric has strictly positive ")#link("http://en.wikipedia.org/wiki/Sectional_curvature")[#text("sectional curvature")]#text(" (and hence also strictly positive ")#link("http://en.wikipedia.org/wiki/Ricci_curvature")[#text("Ricci curvature")]#text("), and so any cover of ")#mi("{G_c}")#text(" also has a metric with Ricci and sectional curvatures uniformly bounded from below. Applying ")#link("http://en.wikipedia.org/wiki/Myers%27_theorem")[#text("Myers’ theorem")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2008/04/27/285g-lecture-9-comparison-geometry-the-high-dimensional-limit-and-perelman-reduced-volume/")[#text("this previous blog post")]#text("), we conclude that any cover of ")#mi("{G_c}")#text(" is necessarily compact also; this implies that the fundamental group of ")#mi("{G_c}")#text(", and hence of ")#mi("{G_{ad}}")#text(", is finite. Thus there are only finitely many different forms of ")#mi("{G}")#text(" between ")#mi("{G_{ad}}")#text(" and ")#mi("{\\tilde G}")#text(", with the latter being a finite cover of the former. For instance, in the case of ")#mi("{{\\mathfrak g} = \\mathfrak{sl}_n({\\bf C})}")#text(" (i.e. the type ")#mi("{A_{n-1}}")#text(" case), one can show that the adjoint form ")#mi("{G_{ad}}")#text(" is isomorphic to ")#mi("{\\text{PSL}_n({\\bf C}) = \\text{PGL}_n({\\bf C})}")#text(" and the universal cover ")#mi("{\\tilde G}")#text(" is isomorphic to ")#mi("{\\text{SL}_n({\\bf C})}")#text(", so that")

#align(center)[#tao-fit-display[#mitex("\\pi(G_{ad}) \\equiv Z(\\tilde G) \\equiv {\\bf Z}/n{\\bf Z}")]]

#text("(since the central elements of ")#mi("{\\text{SL}_n({\\bf C})}")#text(" come from the ")#mi("{n^{th}}")#text(" roots of unity), and all the intermediate forms of ")#mi("{G}")#text(" then come from quotienting out ")#mi("{\\text{SL}_n({\\bf C})}")#text(" by some subgroup of the ")#mi("{n^{th}}")#text(" roots of unity. Actually, as it turns out, for all Lie algebras other than the ")#mi("{A_n}")#text(" family, the fundamental group ")#mi("{\\pi(G_{ad}) \\equiv Z(\\tilde G)}")#text(" is very small, having order at most ")#mi("{4}")#text("; see below. For instance, in the orthogonal algebras ")#mi("{\\mathfrak{so}_n({\\bf C})}")#text(" (coming from the ")#mi("{B_r}")#text(" and ")#mi("{D_r}")#text(" families) the adjoint form is ")#mi("{SO_n({\\bf C})}")#text(" and the universal cover is the ")#link("http://en.wikipedia.org/wiki/Spin_group")[#text("spin group")]#text(" ")#mi("{Spin_n({\\bf C})}")#text(", which is a double cover of ")#mi("{SO_n({\\bf C})}")#text("; in particular, there are no other models of the Lie groups associated to the ")#mi("{B_r}")#text(" and ")#mi("{D_r}")#text(" diagrams. This is in marked contrast with the case of abelian Lie groups, in which there is an infinity of Lie groups associated to a given abelian Lie algebra. For instance, with the one-dimensional Lie algebra ")#mi("{{\\bf C}}")#text(", every lattice ")#mi("{\\Gamma}")#text(" in ")#mi("{{\\bf C}}")#text(" gives a different Lie group ")#mi("{{\\bf C}/\\Gamma}")#text(" with the specified Lie algebra.")

#text("The compact form of the adjoint form ")#mi("{G_{ad}}")#text(" of course lifts to compact forms for all other Lie groups with the given Lie algebra. Among other things, it demonstrates (by the ")#link("http://en.wikipedia.org/wiki/Unitary_trick")[#text("Weyl unitary trick")]#text(") the representation version of Weyl’s complete reducibility theorem: every finite-dimensional representation ")#mi("{\\rho: {\\mathfrak g} \\rightarrow \\mathfrak{gl}(V)}")#text(" of ")#mi("{{\\mathfrak g}}")#text(" splits as the direct sum of a finite number of irreducible representations. Indeed, one can lift this representation to a representation ")#mi("{\\rho: \\tilde G \\rightarrow GL(V)}")#text(" of the universal cover ")#mi("{\\tilde G}")#text(", which then restricts to a representation of the compact form ")#mi("{\\tilde G_c}")#text(" of ")#mi("{\\tilde G}")#text(". But then by averaging some Hermitian form on ")#mi("{V}")#text(" with respect to the Haar measure on ")#mi("{\\tilde G_c}")#text(" one can then construct a Hermitian form with respect to which ")#mi("{\\tilde G_c}")#text(" acts in a unitary fashion, at which point it is easy to take orthogonal complements and decompose ")#mi("{V}")#text(" into ")#mi("{\\tilde G_c}")#text("-irreducible components, which on returning to the infinitesimal action establishes a decomposition into complex vector spaces that are irreducible with respect to the action of ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(" and hence (on complexifying) ")#mi("{{\\mathfrak g}}")#text(". A similar theorem applies for actions of simple (or semisimple) Lie groups, showing that such groups are ")#link("http://en.wikipedia.org/wiki/Reductive_group")[#text("reductive")]#text(".")

#text("Another application of the unitary trick reveals that every simple complex Lie group ")#mi("{G}")#text(" is linear, that is to say it is isomorphic to a Lie subgroup of ")#mi("{GL_n({\\bf C})}")#text(" for some ")#mi("{n}")#text(" (this is in contrast to real Lie groups, which can be non-linear even when simple; the canonical example here is the ")#link("http://en.wikipedia.org/wiki/Metaplectic_group")[#text("metaplectic group")]#text(" ")#mi("{Mp_n({\\bf R})}")#text(" that forms the double cover of the symplectic group ")#mi("{\\text{Sp}_n({\\bf R})}")#text(" for any ")#mi("{n \\geq 2}")#text("). Indeed, letting ")#mi("{G^{\\prime}_c}")#text(" be the compact form of ")#mi("{G^{\\prime}_c}")#text(", the ")#link("http://en.wikipedia.org/wiki/Peter%E2%80%93Weyl_theorem")[#text("Peter-Weyl theorem")]#text(" (as discussed in ")#link("https://terrytao.wordpress.com/2011/09/27/254a-notes-3-haar-measure-and-the-peter-weyl-theorem/")[#text("this previous blog post")]#text(") we see that ")#mi("{G^{\\prime}_c}")#text(" can be identified with a unitary Lie group (i.e. a real Lie subgroup of ")#mi("{U_n({\\bf C})}")#text(" for some ")#mi("{n}")#text("); in particular, its real Lie algebra can be identified with a Lie algebra ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(" of skew-Hermitian matrices. Note that ")#mi("{{\\mathfrak g}}")#text(" can be identified with the complexification ")#mi("{{\\mathfrak g}_{\\bf R} \\oplus i {\\mathfrak g}_{\\bf R}}")#text(". The set ")#mi("{\\{ g \\exp( x ): g \\in G^{\\prime}_c, x \\in {\\mathfrak g}_{\\bf R} \\}}")#text(" can then be seen to be a connected smooth manifold which locally is a Lie group with Lie algebra ")#mi("{{\\mathfrak g}}")#text(", and by a continuity argument contains the group generated by a sufficiently small neighbourhood of the identity, and is therefore a Lie group with the same compact form as ")#mi("{G}")#text(", and thus descends from quotienting the universal cover ")#mi("{\\tilde G}")#text(" by the same central subgroup, and so is isomorphic to ")#mi("{G}")#text(". This argument also shows that the compact form of a connected simple complex Lie group is always connected, and that every complex form of a Lie group is associated to some linear representation of the underlying Lie algebra ")#mi("{{\\mathfrak g}}")#text(". (For instance, the universal form is associated to the sum of the representations having the fundamental weights (the dual basis to the simple coroots) as highest weights, although we will not show this here.)")

#text("If one intersects a Cartan subalgebra ")#mi("{{\\mathfrak h}}")#text(" with ")#mi("{i {\\mathfrak g}_{\\bf R}}")#text(" and then exponentiates and takes closures, one obtains a compact abelian connected subgroup of ")#mi("{G_c}")#text(" whose Lie algebra is again ")#mi("{{\\mathfrak h} \\cap i {\\mathfrak g}_{\\bf R}}")#text(" (from the self-normalising property of Cartan algebras); these groups are known as (real) ")#emph[#text("maximal tori")]#text(". As all Cartan subalgebras are conjugate to each other, all maximal tori are conjugate to each other also. On a compact Lie group, the exponential map is surjective (as discussed in ")#link("https://terrytao.wordpress.com/2011/06/25/two-small-facts-about-lie-groups/")[#text("this previous blog post")]#text("); as every element in ")#mi("{{\\mathfrak g}}")#text(" lies in a Cartan algebra, we obtain the useful fact that every element of ")#mi("{G_c}")#text(" lies in a maximal torus. The same statement lifts to other models ")#mi("{G}")#text(" of the Lie group, and among other things implies that the centre ")#mi("{Z(G)}")#text(" of such a model is equal to the intersection of all the maximal tori in that model.")

#text("We can push the above analysis a bit further to give a more explicit description of the fundamental group of ")#mi("{G_{ad}}")#text(" in terms of the root structure. We will be a bit sketchy in our presentation; details may be found for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=2279709")[#text("the text of Sepanski")]#text(".")

#text("We first need a basic lemma. Let ")#mi("{G_c}")#text(" be the compact form of a simple Lie group, and let ")#mi("{T}")#text(" be a maximal torus in ")#mi("{G_c}")#text(". Let ")#mi("{N(T)}")#text(" be the normaliser of ")#mi("{T}")#text(" in ")#mi("{G_c}")#text("; as Cartan algebras are self-normalising, we see that ")#mi("{N(T)}")#text(" has the same Lie algebra as ")#mi("{T}")#text(", and so ")#mi("{N(T)/T}")#text(" is a finite group, which acts on the Lie algebra ")#mi("{{\\mathfrak t}}")#text(" of ")#mi("{T}")#text(" by conjugation, and similarly acts on the dual ")#mi("{{\\mathfrak t}^*}")#text(". It is easy to see that this action preserves the roots of ")#mi("{{\\mathfrak t}^*}")#text(". Note that the Weyl group ")#mi("{W}")#text(" of the root system, defined in the previous set of notes, also acts (faithfully) on ")#mi("{{\\mathfrak t}^*}")#text(". It turns out that the two groups coincide:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3 (Equivalence of Weyl groups)")]#text(" ")#metadata(none) <tao-6c08aca2d4eff12811d8>#text(" We have ")#mi("{N(T)/T \\equiv W}")#text(", with the actions on ")#mi("{{\\mathfrak t}^*}")#text(" (or equivalently, ")#mi("{{\\mathfrak t}}")#text(") being compatible.")
]

#emph[#text("Proof:")]#text(" It will suffice to show that")

#list(
[#text("(a) the action of ")#mi("{N(T)/T}")#text(" on ")#mi("{{\\mathfrak t}^*}")#text(" is faithful;")],
[#text("(b) to every element of ")#mi("{W}")#text(" one can find an element of ")#mi("{N(T)/T}")#text(" that acts the same way on ")#mi("{{\\mathfrak t}^*}")#text("; and")],
[#text("(c) for every element of ")#mi("{N(T)/T}")#text(" there is an element of ")#mi("{W}")#text(" that acts the same way on ")#mi("{{\\mathfrak t}^*}")#text(".")]
)

#text("To prove (a), we establish the stronger statement that any element ")#mi("{w}")#text(" of ")#mi("{N(T)}")#text(" that preserves a given Weyl chamber ")#mi("{C_h}")#text(" of ")#mi("{{\\mathfrak t}^*}")#text(" (for some regular ")#mi("{h \\in {\\mathfrak t}}")#text(") is necessarily in ")#mi("{T}")#text(". If ")#mi("{w}")#text(" preserves the ")#mi("{h}")#text("-Weyl chamber ")#mi("{C_h}")#text(", then it permutes the ")#mi("{h}")#text("-simple roots, and thus fixes the sum ")#mi("{\\rho = \\rho_h}")#text(" of these ")#mi("{h}")#text("-simple roots. Thus, the one-parameter group ")#mi("{\\{ \\exp( t \\rho ): t \\in {\\bf R} \\}}")#text(" lies in the connected component ")#mi("{Z(w)^0}")#text(" of the centraliser ")#mi("{Z(w) := \\{ g \\in G_c: gw=wg\\}}")#text(" of ")#mi("{w}")#text(". Of course, ")#mi("{w}")#text(" also lies in ")#mi("{Z(w)^0}")#text(", as does any maximal torus of ")#mi("{G_c}")#text(" that contains ")#mi("{w}")#text(". In particular, any maximal torus of ")#mi("{G_c}")#text(" containing ")#mi("{w}")#text(" is also a maximal torus in ")#mi("{Z(w)^0}")#text("; since all maximal tori in ")#mi("{Z(w)^0}")#text(" are conjugate, we conclude that all maximal tori in ")#mi("{Z(w)^0}")#text(" are also maximal tori in ")#mi("{G_c}")#text("; they also all contain ")#mi("{w}")#text(" since ")#mi("{w}")#text(" is central in ")#mi("{Z(w)^0}")#text(". In particular, ")#mi("{\\{\\exp(t\\rho): t \\in {\\bf R}\\}}")#text(" lies in a maximal torus ")#mi("{T^{\\prime}}")#text(" of ")#mi("{Z(w)^0}")#text(" (and hence in ")#mi("{G_c}")#text(") that contains ")#mi("{w}")#text(". In particular, the adjoint action of ")#mi("{\\rho}")#text(" fixes the Lie algebra ")#mi("{{\\mathfrak t}^{\\prime}}")#text(" of ")#mi("{T^{\\prime}}")#text(". But ")#mi("{\\rho}")#text(" is regular in ")#mi("{{\\mathfrak t}}")#text(", so its centraliser in ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(" is ")#mi("{{\\mathfrak t}}")#text(". Thus ")#mi("{T = T^{\\prime}}")#text("; since ")#mi("{w \\in T^{\\prime}}")#text(", we have ")#mi("{w \\in T}")#text(" as required.")

#text("The proof of (c) is similar. Here, ")#mi("{w}")#text(" need not preserve ")#mi("{\\rho}")#text(", but one can select an element ")#mi("{w^{\\prime}}")#text(" of ")#mi("{W}")#text(" to maximise ")#mi("{\\langle w^{\\prime}(h), w(\\rho)\\rangle}")#text("; arguing as in the proof of Lemma 28 of ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("these previous notes")]#text(", we see that ")#mi("{(w^{\\prime})^{-1} w}")#text(" maps the ")#mi("{h}")#text("-Weyl chamber to itself, and the claim follows from the previous discussion.")

#text("To prove (b), it suffices to show that every reflection ")#mi("{s_\\alpha}")#text(" comes from an element of ")#mi("{N(T)/T}")#text(". But in the rank one case (when ")#mi("{G}")#text(" is isomorphic ")#mi("{SU_2({\\bf C})}")#text(") this can be done by direct computation, and the general rank case can then be obtained by looking at the embedded copy of the rank one Lie group associated to the pair of roots ")#mi("{\\{-\\alpha,\\alpha\\}}")#text(". ")#mi("\\Box")

#text("Call an element of ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(" ")#emph[#text("regular")]#text(" if it is conjugate (under the adjoint action of ")#mi("{G_c}")#text(") to a regular element of ")#mi("{{\\mathfrak t}}")#text(" (and hence, by the Weyl group action, to an element in the interior ")#mi("{{\\mathfrak c}}")#text(" of the (adjoint of the) Weyl chamber); this conjugation element can be viewed as an element of ")#mi("{G/T}")#text(", which is unique by the discussion in the previous section. This gives a bijection ")#mi("{G_c/T \\times {\\mathfrak c} \\rightarrow i{\\mathfrak g}^{reg}_{\\bf R}}")#text(" to the regular elements of ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(", which can be seen to be a homeomorphism. The non-regular elements can be computed to have codimension at least three in ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(" (because the centraliser of non-regular elements have at least two more dimensions than in the regular case), so ")#mi("{i{\\mathfrak g}^{reg}_{\\bf R}}")#text(" is simply connected; as this space retracts onto ")#mi("{G_c/T}")#text(", we conclude that ")#mi("{G_c/T}")#text(" is simply connected.")

#text("From this we may now compute the fundamental group of ")#mi("{G_c}")#text(" (or equivalently, of ")#mi("{G_{ad}}")#text("). By inspecting the adjoint action of ")#mi("{T}")#text(" on ")#mi("{{\\mathfrak g}}")#text(", we see that for ")#mi("{t \\in {\\mathfrak h}_{\\bf R}}")#text(", ")#mi("{\\exp(t)}")#text(" is trivial in ")#mi("{T}")#text(" if and only if ")#mi("{t}")#text(" lies in the ")#emph[#text("coweight lattice")]#text(" ")#mi("{P := \\{ t \\in {\\mathfrak h}: \\langle t, \\alpha \\rangle \\in {\\bf Z} \\}}")#text(", so the torus ")#mi("{T}")#text(" may be identified with the quotient ")#mi("{{\\mathfrak h}_{\\bf R}/P}")#text(". Inside ")#mi("{P}")#text(" we have the ")#emph[#text("coroot lattice")]#text(" ")#mi("{Q}")#text(" generated by the coroots ")#mi("{\\{ h_\\alpha: \\alpha \\in \\Phi \\}}")#text("; these are both full rank in ")#mi("{{\\mathfrak h}_{\\bf R}}")#text(" and so the quotient ")#mi("{P/Q}")#text(" is finite.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" In the ")#mi("{A_{n-1}}")#text(" example, ")#mi("{{\\mathfrak h}_{\\bf R}}")#text(" is the space ")#mi("{{\\bf R}^n_0}")#text(" of vectors ")#mi("{(x_1,\\ldots,x_n) \\in {\\bf R}^n}")#text(" with ")#mi("{x_1+\\ldots+x_n = 0}")#text("; the coweight lattice ")#mi("{P}")#text(" is then generated by ")#mi("{e_i - \\frac{1}{n} \\sum_{j=1}^n}")#text(" for ")#mi("{i=1,\\ldots,n}")#text(", and the root lattice ")#mi("{Q}")#text(" is spanned by ")#mi("{e_i - e_j}")#text(" for ")#mi("{1 \\leq i < j \\leq n}")#text(" and has index ")#mi("{n}")#text(" in ")#mi("{P}")#text(".")
]

#text("Call an element ")#mi("{x}")#text(" of ")#mi("{{\\mathfrak h}}")#text(" ")#emph[#text("non-integral")]#text(" if one has ")#mi("{\\langle x, \\alpha \\rangle \\not \\in {\\bf Z}}")#text(" for all ")#mi("{\\alpha \\in \\Phi}")#text("; this is a stronger condition than being regular, which corresponds to ")#mi("{\\langle x,\\alpha\\rangle}")#text(" being non-zero for all ")#mi("{\\alpha}")#text(". The set of non-integral elements of ")#mi("{{\\mathfrak h}}")#text(" is a collection of open polytopes, and is acted upon by the group ")#mi("{A_Q}")#text(" of affine transformations generated by the Weyl group and translations by elements of the coroot lattice ")#mi("{Q}")#text(". A fundamental domain of this space is the ")#emph[#text("Weyl alcove")]#text(" ")#mi("{{\\mathcal A}}")#text(", in which ")#mi("{\\langle x, \\alpha \\rangle > 0}")#text(" for positive roots and ")#mi("{\\langle x, \\beta \\rangle < 1}")#text(" for the maximal root ")#mi("{\\beta}")#text("; this is a simplex in the Weyl chamber consisting entirely of non-integral elements, such that the reflection along any of the faces of the alcove lies in ")#mi("{A}")#text(", which shows that it is indeed a fundamental domain. (In the ")#mi("{A_{n-1}}")#text(" case, the alcove consists of tuples ")#mi("{\\theta_1,\\ldots,\\theta_n}")#text(" with ")#mi("{\\theta_1 > \\ldots > \\theta_n > \\theta_1-1}")#text(".)")

#text("Call an element of ")#mi("{G_c}")#text(" ")#emph[#text("regular")]#text(" if it is conjugate to ")#mi("{\\exp(x)}")#text(" for some non-integral ")#mi("{x \\in {\\mathfrak h}}")#text("; as before, the regular elements have codimension at least three in ")#mi("{G_c}")#text(", and so the fundamental group of ")#mi("{G_c}")#text(" is the same as the fundamental group of the non-integral elements of ")#mi("{G_c}")#text(". (In the case of ")#mi("{A_{n-1}}")#text(", ")#mi("{G_c}")#text(" is the projective special unitary group ")#mi("{\\text{PSU}_n({\\bf C})}")#text(", and the equivalence class of an unitary matrix is regular if its eigenvalues are all distinct.) Observe that ")#mi("{\\exp(ax)}")#text(" and ")#mi("{\\exp(x)}")#text(" are conjugate whenever ")#mi("{a \\in A_Q}")#text("; in fact the same is true for all ")#mi("{a}")#text(" in ")#mi("{A_P}")#text(", the group of affine transformations on ")#mi("{{\\mathfrak h}}")#text(" generated by the Weyl group and translations by elements of the coweight lattice ")#mi("{P}")#text(". Because of this, we see that every element of ")#mi("{G_c}")#text(" can be expressed in the form ")#mi("{\\exp(x)^a}")#text(" where ")#mi("{x}")#text(" lies in the Weyl alcove ")#mi("{{\\mathcal A}}")#text(", ")#mi("{g}")#text(" lies in ")#mi("{G/T}")#text(", and ")#mi("{\\exp(x)^g}")#text(" is the conjugate of ")#mi("{\\exp(x)}")#text(" by (any representative of) ")#mi("{g}")#text(". By lifting, we can then write any loop ")#mi("{\\gamma: [0,1] \\rightarrow G_c}")#text(" in ")#mi("{G_c}")#text(" in the form")

#align(center)[#tao-fit-display[#mitex("\\gamma(t) = \\exp(x(t))^{g(t)}")]]

#text("for some continuous ")#mi("{x: [0,1] \\rightarrow {\\mathcal A}}")#text(" and ")#mi("{g: [0,1] \\rightarrow G/T}")#text(". If we fix the base point ")#mi("{\\gamma(0)=\\gamma(1)=p_0}")#text(" of ")#mi("{\\gamma}")#text(", then we can fix the initial point ")#mi("{x(0) = x_0}")#text(" of ")#mi("{x}")#text(", and normalise ")#mi("{g(0)}")#text(" to be the identity; we then have")

#align(center)[#tao-fit-display[#mitex("\\exp(x(1))^{g(1)} = \\exp(x_0),")]]

#text("which places ")#mi("{g(1)}")#text(" in ")#mi("{N(T)/T}")#text(" (since ")#mi("{\\exp(x_0)}")#text(" and ")#mi("{\\exp(x_1)}")#text(", being non-integral, do not lie in any maximal torus other than ")#mi("{T}")#text(", as can be seen by inspecting its adjoint action on ")#mi("{{\\mathfrak g}}")#text("). Thus there is an element ")#mi("{w}")#text(" of ")#mi("{W}")#text(" and ")#mi("{k \\in P}")#text(" such that ")#mi("{x(1) = w x_0 + k}")#text(" and ")#mi("{g(1) = w^{-1}}")#text("; this assigns an element ")#mi("{a}")#text(" of ")#mi("{A_P}")#text(" to ")#mi("{\\gamma}")#text(" with the property that ")#mi("{a x_0 \\in {\\mathcal A}}")#text("; one can check that this assignment is preserved under homotopy of ")#mi("{\\gamma}")#text(". From the simply connected nature of both ")#mi("{G/T}")#text(" and ")#mi("{{\\mathcal A}}")#text(" one can check that this assignment is injective; and by the connected nature of ")#mi("{G/T}")#text(" and ")#mi("{{\\mathcal A}}")#text(" the assignment is surjective. On the other hand, as ")#mi("{{\\mathcal A}}")#text(" is a fundamental domain for ")#mi("{A_Q}")#text(", we see that each (right) coset of ")#mi("{A_P}")#text(" in ")#mi("{A_Q}")#text(" has exactly one representative ")#mi("{a}")#text(" for which ")#mi("{ax_0 \\in {\\mathcal A}}")#text(", so we have obtained a bijective correspondence between ")#mi("{\\pi_1(G_c)}")#text(" and ")#mi("{A_Q/A_P \\equiv Q/P}")#text(". In fact it is not difficult to show that this bijection is a group isomorphism, thus ")#metadata(none) <tao-cb96897bd0f82fd54c24>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("Z(\\tilde G) \\equiv \\pi_1(G_{ad}) \\equiv \\pi_1(G_c) \\equiv Q/P.")]]

#text("With this formula one can now compute the fundamental group or centre ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(1)")]#text(" associated to any Dynkin diagram group quite easily, and it usually ends up being very small:")

#list(
[#text("For ")#mi("{G_2}")#text(", ")#mi("{F_4}")#text(", or ")#mi("{E_8}")#text(", the group ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(1)")]#text(" is trivial.")],
[#text("For ")#mi("{B_n}")#text(", ")#mi("{C_n}")#text(", or ")#mi("{E_7}")#text(", the group ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(1)")]#text(" has order two.")],
[#text("For ")#mi("{E_6}")#text(", the group ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(1)")]#text(" has order three.")],
[#text("For ")#mi("{D_n}")#text(", the group ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(1)")]#text(" has order four, and is cyclic for odd ")#mi("{n}")#text(" and the Klein group for even ")#mi("{n}")#text(".")],
[#text("As mentioned previously, for ")#mi("{A_n}")#text(", the group ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(1)")]#text(" is cyclic of order ")#mi("{n+1}")#text(".")]
)

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above theory for simple Lie algebras extends without difficulty to the semisimple case, with a connected Lie group defined to be semisimple if its Lie algebra is semisimple. If one restricts to the simply connected models ")#mi("{\\tilde G}")#text(", then every simply connected semisimple Lie group is expressible as the direct sum of simply connected simple Lie groups. A general semisimple Lie groups might not be a direct product of simple Lie groups, but will always be a ")#link("http://en.wikipedia.org/wiki/Central_product")[#text("central product")]#text(" (a direct product quotiented out by some subgroup of the center).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The compact form ")#mi("{G_c}")#text(" (and its lifts) are usually not the only real Lie groups associated to ")#mi("{{\\mathfrak g}}")#text(", as there may be other ")#link("http://en.wikipedia.org/wiki/Real_form")[#text("real forms")]#text(" of ")#mi("{{\\mathfrak g}}")#text(" than ")#mi("{i{\\mathfrak g}_{\\bf R}}")#text(". These can be classified by a somewhat messier version of the arguments given previously, but we will not pursue this matter here; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1920389")[#text("Knapp’s book")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 2. Chevalley groups — ")]]

#text("The theory of connected Lie groups works well over the reals ")#mi("{{\\bf R}}")#text(" or complexes ")#mi("{{\\bf C}}")#text(", as these fields are themselves connected in the topological sense, but becomes more problematic when one works with disconnected fields, such as finite fields or the ")#mi("{p}")#text("-adics. However, there is a good substitute for the notion of a Lie group in these settings (particularly when working with algebraically complete fields ")#mi("{k}")#text("), namely the notion of an ")#link("http://en.wikipedia.org/wiki/Algebraic_group")[#text("algebraic group")]#text(". Actually, in analogy to how complex Lie groups are automatically linear groups (up to isomorphism), we will be able to restrict attention to (classical) ")#link("http://en.wikipedia.org/wiki/Linear_algebraic_group")[#text("linear algebraic groups")]#text(", that is to say Zariski-closed subgroups of a general linear group ")#mi("{GL_n(k)}")#text(" over an algebraically closed field ")#mi("{k}")#text(". (Remarkably, it turns out that all affine algebraic groups are isomorphic to a linear algebraic group, though we will not prove this fact here.)")

#text("The following result allows one to easily generate linear algebraic groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4")]#text(" ")#metadata(none) <tao-2d0042b2b8a5540b4313>#text(" Let ")#mi("{k}")#text(" be algebraically closed. All topological notions are with respect to the Zariski topology, and notions of constructibility and irreducibility are in the algebraic geometry sense. If ")#mi("{V}")#text(" is a connected constructible subset of ")#mi("{GL_n(k)}")#text(" containing the identity, then the group ")#mi("{\\langle V \\rangle}")#text(" generated by ")#mi("{V}")#text(" is closed (and is thus a linear algebraic group) and also irreducible.")
]

#text("In particular, this theorem implies that linear algebraic groups are connected if and only if they are irreducible.")

#emph[#text("Proof:")]#text(" By combining ")#mi("{V}")#text(" with its reflection ")#mi("{V^{-1}}")#text(" we may assume that ")#mi("{V}")#text(" is symmetric: ")#mi("{V = V^{-1}}")#text(". The product sets ")#mi("{V, V^2, V^3, \\ldots}")#text(" are all constructible and increasing, so at some point the dimension must stabilise, thus we can find ")#mi("{k}")#text(" such that ")#mi("{V^k}")#text(" and ")#mi("{V^{2k}}")#text(" both have dimension ")#mi("{d}")#text(". Let ")#mi("{A_1,\\ldots,A_m}")#text(" be the ")#mi("{d}")#text("-dimensional irreducible components of ")#mi("{V^k}")#text(", and ")#mi("{A^{\\prime}_1,\\ldots,A^{\\prime}_{m^{\\prime}}}")#text(" be the ")#mi("{d}")#text("-dimensional irreducible components of ")#mi("{V^{2k}}")#text(", thus every element of ")#mi("{V^k}")#text(" lies in one of the sets ")#mi("{B_{i^{\\prime}} := \\{ g \\in GL_n(k): g \\overline{A_1} = \\overline{A^{\\prime}_{i^{\\prime}}} \\}}")#text(" for some ")#mi("{i^{\\prime}=1,\\ldots,k^{\\prime}}")#text(". As these sets are closed and disjoint and ")#mi("{V^k}")#text(" is connected, only one of the ")#mi("{B_{i^{\\prime}}}")#text(", say ")#mi("{B_1}")#text(", is non-empty; as ")#mi("{V^k}")#text(" contains the identity, we conclude that ")#mi("{\\overline{A_1} = \\overline{A^{\\prime}_1}}")#text(" and ")#mi("{V^k \\subset B_1 \\subset \\overline{A^{\\prime}_1}}")#text(", thus ")#mi("{V^k}")#text(" is an open dense subset of ")#mi("{\\overline{A_1}}")#text(", which is symmetric, contains the identity, is Zariski closed, and closed under multiplication and is thus an algebraic group. This implies that ")#mi("{V^{2k}}")#text(" is all of ")#mi("{\\overline{A_1}}")#text(" (because ")#mi("{V^k}")#text(" and ")#mi("{(V^k)^{-1} g}")#text(" intersect for all ")#mi("{g \\in \\overline{A_1}}")#text(" as they are both open dense subsets of ")#mi("{\\overline{A_1}}")#text(") and the claim follows. ")#mi("\\Box")

#text("This already gives a basic link between the category of complex Lie groups and the category of algebraic groups:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5")]#text(" Every complex simple Lie group ")#mi("{G_{ad}}")#text(" in adjoint form is an linear algebraic group over ")#mi("{{\\bf C}}")#text(".")
]

#text("The same statement is in fact true (up to isomorphism) for the other forms of a complex simple Lie group (by essentially the same argument, and using the fact that the Jordan decomposition for a simple Lie algebra is universal across all representations), though we will focus here on the adjoint form for simplicity. Note though that not every real simple Lie group is algebraic; for instance, the universal cover of ")#mi("{\\text{SL}_2({\\bf R})}")#text(" has an infinite discrete centre (the fundamental group of ")#mi("{\\text{SL}_2({\\bf R})}")#text(" is isomorphic to ")#mi("{{\\bf Z}}")#text(") and is therefore non-algebraic. To emphasise the algebraicity of the complex simple Lie group ")#mi("{G_{ad}}")#text(" (and in order to distinguish it from the more general Chevalley groups ")#mi("{G_{ad}(k)}")#text(" which we will introduce shortly) we will now write it as ")#mi("{G_{ad}({\\bf C})}")#text(".")

#emph[#text("Proof:")]#text(" Recall (see ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("this previous post")]#text(") that the complex Lie algebra ")#mi("{{\\mathfrak g}}")#text(" has a ")#link("http://www.encyclopediaofmath.org/index.php/Cartan-Weyl_basis")[#text("Cartan-Weyl basis")]#text(" – a ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("complex-linear basis")]#text(" ")#mi("{(E_\\alpha)_{\\alpha \\in \\Phi}, (H_\\alpha)_{\\alpha \\in \\Pi}}")#text(" indexed by the roots ")#mi("{\\Phi}")#text(" and the simple roots ")#mi("{\\Pi}")#text(" respectively, obeying the Cartan-Weyl relations")

#tao-aligned(keep: true)[


#tao-math("[H_\\alpha, E_\\beta]  & = A_{\\alpha,\\beta}", block: true)



#tao-math("[E_\\alpha, E_{-\\alpha}]  & = H_\\alpha", block: true)



#tao-math("[E_\\alpha, E_\\beta]  & = N_{\\alpha,\\beta} E_{\\alpha+\\beta}", block: true)



#tao-math("[H_\\alpha,H_\\beta]  & = 0", block: true)
]

#text("where we extend ")#mi("{H_\\alpha}")#text(" to all roots ")#mi("{\\alpha \\in \\Phi}")#text(" by making ")#mi("{H_\\alpha}")#text(" linear in the coroot of ")#mi("{\\alpha}")#text(", ")#mi("{A_{\\alpha,\\beta}}")#text(" are integers, and ")#mi("{N_{\\alpha,\\beta}}")#text(" are structure constants. Among other things, this shows that ")#mi("{G_{ad}({\\bf C})}")#text(" is generated by the one-parameter unipotent subgroups ")#mi("{U_\\alpha({\\bf C}) := \\{ \\exp( t \\text{ad} E_\\alpha ): t \\in {\\bf C} \\}}")#text(" and toral subgroups ")#mi("{T_\\alpha({\\bf C}) := \\{ \\exp( t \\text{ad} H_\\alpha ): t \\in {\\bf C} \\}}")#text(" for various ")#mi("{\\alpha}")#text(". The unipotent groups ")#mi("{U_\\alpha}")#text(" are algebraic because ")#mi("{\\text{ad} E_\\alpha}")#text(" is nilpotent. The toral groups ")#mi("{T_\\alpha}")#text(" are not quite algebraic (they aren’t closed), but they are constructible, because the Cartan-Weyl relations show that ")#mi("{\\exp( t \\text{ad} H_\\alpha )}")#text(" is given by a diagonal matrix whose entries are monomials in ")#mi("{\\exp(t)}")#text(", so by reparameterising in terms of ")#mi("{z := \\exp(t) \\in {\\bf C}^\\times}")#text(" we obtain the desired constructibility. The claim then follows from Theorem ")#link(<tao-2d0042b2b8a5540b4313>)[#text("4")]#text(". ")#mi("\\Box")

#text("Somewhat miraculously, the same construction works for any other algebraically closed fields ")#mi("{k}")#text(" (and even to non-algebraically closed fields, as discussed below), to construct an algebraic group ")#mi("{G_{ad}(k)}")#text(" that is the analogue over ")#mi("{k}")#text(" of the adjoint form of the complex Lie group ")#mi("{G_{ad}({\\bf C})}")#text(". Whereas ")#mi("{G_{ad}({\\bf C})}")#text(" consisted of linear transformations from the complex vector space ")#mi("{{\\mathfrak g}}")#text(" to itself, ")#mi("{G_{ad}(k)}")#text(" consists of linear transformations on the ")#mi("{k}")#text("-vector space ")#mi("{{\\mathfrak g}(k)}")#text(", which has the same Cartan-Weyl basis ")#mi("{(E_\\alpha)_{\\alpha \\in \\Phi}, (H_\\alpha)_{\\alpha \\in \\Pi}}")#text(" but now viewed as a basis over ")#mi("{k}")#text(" rather than ")#mi("{{\\bf C}}")#text(". The analogue ")#mi("{T_\\alpha(k)}")#text(" of the toral subgroups ")#mi("{T_\\alpha({\\bf C}) = \\{ \\exp( t \\text{ad} H_\\alpha ): t \\in {\\bf C} \\}}")#text(" are then the group of linear transformations ")#mi("{h_\\alpha(z)}")#text(" on ")#mi("{{\\mathfrak g}(k)}")#text(" that map ")#mi("{E_\\beta}")#text(" to ")#mi("{z^{A_{\\alpha,\\beta}} E_\\beta}")#text(" for all roots ")#mi("{\\beta}")#text(" and annihilate all the ")#mi("{H_\\gamma}")#text(", for some ")#mi("{z \\in k^\\times}")#text("; this is a connected constructible subgroup of ")#mi("{GL({\\mathfrak g}(k))}")#text(". As for the ")#mi("{k}")#text("-analogue ")#mi("{U_\\alpha(k)}")#text(" of the unipotent subgroups ")#mi("{U_\\alpha({\\bf C}) = \\{ \\exp( t \\text{ad} E_\\alpha ): t \\in {\\bf C} \\}}")#text(", we use crucially the fact (established in ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("this previous post")]#text(") that one can ensure that ")#mi("{N_{\\alpha,\\beta} = \\pm (r+1)}")#text(", where ")#mi("{r}")#text(" is the largest integer such that ")#mi("{\\beta-r\\alpha}")#text(" is a root. This implies in the complex setting that")

#align(center)[#tao-fit-display[#mitex("\\exp( t \\text{ad} E_\\alpha ) E_\\beta = E_\\beta \\pm t (r+1) E_{\\beta+\\alpha} \\pm t^2 \\frac{(r+1)(r+2)}{2} E_{\\beta+2\\alpha} \\pm \\ldots")]]

#text("where the series terminates once ")#mi("{\\beta+s\\alpha}")#text(" stops being a root. The point here is that the coefficients ")#mi("{\\pm (r+1), \\pm \\frac{(r+1)(r+2)}{2}}")#text(", etc. are all integers, and so one can take this as a definition for ")#mi("{u_\\alpha(t) = \\exp(t \\text{ad} E_\\alpha )}")#text(" for ")#mi("{{\\mathfrak g}(k)}")#text(" and any ")#mi("{t \\in k}")#text(" regardless of what characteristic ")#mi("{k}")#text(" is, and one still obtains a connected unipotent group in this way. If we then let ")#mi("{G_{ad}(k)}")#text(" be the group generated by these one-parameter subgroups ")#mi("{T_\\alpha(k)}")#text(", ")#mi("{U_\\alpha(k)}")#text(", we see that this is a connected linear algebraic group defined over ")#mi("{k}")#text(", known as the (adjoint form) ")#emph[#text("Chevalley group")]#text(" over ")#mi("{k}")#text(" associated to the given root system (or Dynkin diagram).")

#text("The same construction works over fields ")#mi("{k}")#text(" that are not algebraically closed, giving groups ")#mi("{G_{ad}(k)}")#text(" that are also denoted ")#mi("{D(k)}")#text(" where ")#mi("{D}")#text(" is the Dynkin diagram associated to ")#mi("{k}")#text("; for instance ")#mi("{A_n(k)}")#text(" is the projective special linear group ")#mi("{\\text{PSL}_{n+1}(k)}")#text(". The resulting groups ")#mi("{G_{ad}(k)}")#text(" are then not algebraic groups, since we only define the notion of a (classical) algebraic variety over algebraically closed fields. Nevertheless, these groups still retain a great deal of the other structure of the complex Lie group ")#mi("{G_{ad}({\\bf C})}")#text(", and in particular inherit the ")#link("http://en.wikipedia.org/wiki/Bruhat_decomposition")[#text("Bruhat decomposition")]#text(" which we now pause to recall. We first identify some key subgroups of ")#mi("{G_{ad}(k)}")#text(". We first locate the ")#link("http://en.wikipedia.org/wiki/Maximal_torus")[#text("maximal torus")]#text(" ")#mi("{T(k)}")#text(", defined as the group generated by the one-parameter toral subgroups ")#mi("{T_\\alpha(k)}")#text(" for ")#mi("{\\alpha \\in \\Pi}")#text("; this is an abelian subgroup of ")#mi("{G_{ad}(k)}")#text(". Next, we locate the ")#link("http://en.wikipedia.org/wiki/Borel_subgroup")[#text("Borel subgroup")]#text(" ")#mi("{B(k)}")#text(", defined as the group generated by ")#mi("{T}")#text(" and the unipotent groups ")#mi("{U_\\alpha(k)}")#text(" for ")#emph[#text("positive")]#text(" roots ")#mi("{\\alpha}")#text("; this can be seen to be a solvable subgroup of ")#mi("{G_{ad}(k)}")#text(". Then, for each reflection ")#mi("{s_\\alpha \\in W}")#text(" in the Weyl group ")#mi("{W}")#text(" associated to a simple root ")#mi("{\\alpha \\in \\Pi}")#text(", we define the elements")

#align(center)[#tao-fit-display[#mitex("n_\\alpha(t) := u_\\alpha(t) u_{-\\alpha}(-t^{-1}) u_\\alpha(t)")]]

#text("for ")#mi("{t \\in k^\\times}")#text(", one can check using the Cartan-Weyl relations that ")#mi("{n_\\alpha(t)}")#text(" determines an element in a coset of ")#mi("{T}")#text(" in its normaliser ")#mi("{N(T)}")#text(" which is independent of the choice of ")#mi("{t}")#text(". Letting ")#mi("{N(k)}")#text(" be the group generated by the ")#mi("{n_\\alpha(t)}")#text(" and ")#mi("{T(k)}")#text(", we thus see that ")#mi("{N(k)}")#text(" normalises ")#mi("{T(k)}")#text(", and with some further application of the Cartan-Weyl relations one sees that ")#mi("{N(k)/T(k)}")#text(" is isomorphic to ")#mi("{W}")#text(" (with each ")#mi("{n_\\alpha(t)}")#text(" projecting down to ")#mi("{s_\\alpha}")#text("); cf. Lemma ")#link(<tao-6c08aca2d4eff12811d8>)[#text("3")]#text(". Indeed, if ")#mi("{n_w \\in N(k)}")#text(" is a representative of ")#mi("{w \\in W}")#text(", one sees that the operation of conjugation ")#mi("{g \\mapsto n_w g n_w^{-1}}")#text(" maps ")#mi("{U_\\alpha(k)}")#text(" to ")#mi("{U_{w(\\alpha)}(k)}")#text(" for any root ")#mi("{\\alpha}")#text(".")

#text("For notational reasons we now fix an assignment ")#mi("{n_w}")#text(" of a representative in ")#mi("{N(k)}")#text(" to each element ")#mi("{w \\in W}")#text(", although all of the objects we will actually study will not be dependent on this choice of assignment.")

#text("The following axioms can then be verified from further use of the Cartan-Weyl relations:")

#enum(start: 1, 
[#mi("{G_{ad}(k)}")#text(" is generated by ")#mi("{B(k)}")#text(" and ")#mi("{N(k)}")#text(".")],
[#mi("{T(k)}")#text(" is the intersection of ")#mi("{B(k)}")#text(" and ")#mi("{N(k)}")#text(", and is normalised by ")#mi("{N(k)}")#text(".")],
[#mi("{W = N(k)/T(k)}")#text(" is generated by the reflections ")#mi("{s_\\alpha, \\alpha \\in \\Pi}")#text(", which are of order two.")],
[#text("No reflection ")#mi("{s_\\alpha}")#text(" (or more precisely, no representative in ")#mi("{N(k)}")#text(" of that reflection) normalises ")#mi("{B(k)}")#text(".")]
)

#text("For each element ")#mi("{w \\in W}")#text(" of the Weyl group, we can form the double coset ")#mi("{C(w) := B(k) n_w B(k)}")#text("; this is easily seen to be independent of the choice of representative ")#mi("{n_w}")#text(". Thus for instance ")#mi("{C(1)=B(k)}")#text(". It is also clear that any two double cosets ")#mi("{C(w), C(w^{\\prime})}")#text(" are either equal or disjoint, and one has the inclusion ")#metadata(none) <tao-beb134754910a4b4790c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("C(ww^{\\prime}) \\subset C(w) C(w^{\\prime}).")]]

#text("for any ")#mi("{w,w^{\\prime} \\in W}")#text(", as well as the symmetry ")#mi("{C(w)^{-1} = C(w^{-1})}")#text(". We also have the important further inclusion relation:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6")]#text(" ")#metadata(none) <tao-c81b021331344adcdd57>#text(" For any ")#mi("{\\alpha \\in \\Pi}")#text(" and ")#mi("{w \\in W}")#text(", we have ")#mi("{C(w) C(s_\\alpha) \\subset C(w) \\cup C(w s_\\alpha)}")#text(".")
]

#emph[#text("Proof:")]#text(" First suppose that ")#mi("{w(\\alpha)}")#text(" is a positive root. Then we observe the factorisation")

#align(center)[#tao-fit-display[#mitex("B(k) = U_\\alpha(k) T(k) U_{\\overline{\\alpha}}(k)")]]

#text("where ")#mi("{U_{\\overline{\\alpha}}(k)}")#text(" is the group generated by all the ")#mi("{U_\\beta}")#text(" for positive ")#mi("{\\beta \\neq \\alpha}")#text(". From the positivity of ")#mi("{w(\\alpha)}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("n_w U_\\alpha(k) n_w^{-1} = U_{w(\\alpha)}(k) \\subset B(k)")]]

#text("and from the simplicity of ")#mi("{\\alpha}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("n_{s_\\alpha} (T(k) U_{\\overline{\\alpha}}(k)) n_{s_\\alpha}^{-1} \\subset B(k)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("B(k) \\subset (n_w^{-1} B(k) n_w) (n_{s_\\alpha} B(k) n_{s_\\alpha}^{-1});")]]

#text("multiplying on the left by ")#mi("{n_w}")#text(" and on the right by ")#mi("{s_\\alpha}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("C(w) C(s_\\alpha) \\subset C(w s_\\alpha);")]]

#text("as the left-hand side is a non-empty union of double cosets, we in fact have equality")

#align(center)[#tao-fit-display[#mitex("C(w) C(s_\\alpha) = C(w s_\\alpha).")]]

#text("Now suppose instead that ")#mi("{w(\\alpha)}")#text(" is a negative root. Applying the previous equality with ")#mi("{w}")#text(" replaed by ")#mi("{w s_\\alpha}")#text(" we conclude that ")#metadata(none) <tao-0fc1806534e7eb831d53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("C(w s_\\alpha) C(s_\\alpha) = C(w)")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("C(w) C(s_\\alpha) = C(w s_\\alpha) C(s_\\alpha) C(s_\\alpha).")]]

#text("On the other hand, direct calculation with the Cartan-Weyl relations reveals that")

#align(center)[#tao-fit-display[#mitex("C(s_\\alpha) C(s_\\alpha) \\subset C(1) \\cup C(s_\\alpha)")]]

#text("and the claim then follows from ")#link(<tao-0fc1806534e7eb831d53>)[#text("(3)")]#text(". ")#mi("\\Box")

#text("Lemma ")#link(<tao-c81b021331344adcdd57>)[#text("6")]#text(" and the preceding four axioms form the axiom system, introduced by Tits, for a ")#link("http://en.wikipedia.org/wiki/(B,_N)_pair")[#mi("{(B,N)}")#text("-pair")]#text(". This axiom system is convenient for abstractly achieving a number of useful facts, such as the ")#link("http://en.wikipedia.org/wiki/Bruhat_decomposition")[#text("Bruhat decomposition")]#text(", and the simplicity of ")#mi("{G_{ad}(k)}")#text(" (in most cases). We begin with the Bruhat decomposition:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Bruhat decomposition)")]#text(" ")#mi("{G_{ad}(k)}")#text(" is the disjoint union of ")#mi("{C(w)}")#text(" as ")#mi("{w}")#text(" ranges over ")#mi("{W}")#text(". (Thus there is a canonical bijection between ")#mi("{B(k)G_{ad}(k)/B(k)}")#text(" and ")#mi("{W = N(k)/T(k)}")#text(", which by slight abuse of notation can be written as ")#mi("{G_{ad}(k) = B(k) W B(k)}")#text(".)")
]

#emph[#text("Proof:")]#text(" We first show that the ")#mi("{C(w)}")#text(" cover ")#mi("{G_{ad}(k)}")#text(". As the ")#mi("{C(w)}")#text(" cover both ")#mi("{B(k)}")#text(" and ")#mi("{N(k)}")#text(" (which together generate ")#mi("{G_{ad}(k)}")#text(") and their union is symmetric, it suffices to show that ")#mi("{\\bigcup_w C(w)}")#text(" is closed under multiplication, thus ")#mi("{C(w_1) C(w_2) \\subset \\bigcup_w C(w)}")#text(". But this is easily achieved by iterating Lemma ")#link(<tao-c81b021331344adcdd57>)[#text("6")]#text(" (inducting on the length of ")#mi("{w_2}")#text(", that is to say the minimal number of reflections ")#mi("{s_\\alpha}")#text(" needed to generate ")#mi("{C(w_2)}")#text(", noting that the case ")#mi("{w_2=1}")#text(" is trivial).")

#text("Now we show that the ")#mi("{C(w)}")#text(" are disjoint. Since double cosets are either equal or disjoint, it suffices to show that ")#mi("{C(w_1)=C(w_2)}")#text(" implies ")#mi("{w_1=w_2}")#text(" for all ")#mi("{w_1,w_2 \\in W}")#text(". We induct on the length of ")#mi("{w_2}")#text(". The case when ")#mi("{w_2=1}")#text(" is trivial, so suppose that ")#mi("{w_2 \\neq 1}")#text(" and that the claim has already been proven for all shorter ")#mi("{w_2}")#text(". We write ")#mi("{w_2 = w^{\\prime}_2 s_\\alpha}")#text(" for some shorter ")#mi("{w^{\\prime}_2}")#text(". Then")

#tao-aligned(keep: true)[


#tao-math("w^{\\prime}_2  & = w_2 s_\\alpha \\subset C(w_2) C(s_\\alpha)", block: true)



#tao-math(" & = C(w_1) C(s_\\alpha) \\subset C(w_1) \\cup C(w_1 s_\\alpha)", block: true)



#tao-math(" & = C(w_2) \\cup C(w_1 s_\\alpha)", block: true)
]

#text("and hence ")#mi("{C(w^{\\prime}_2)}")#text(" is either equal to ")#mi("{C(w_2)}")#text(" or ")#mi("{C(w_1 s_\\alpha)}")#text(". By induction we then either have ")#mi("{w^{\\prime}_2=w_2}")#text(" or ")#mi("{w^{\\prime}_2 = w_1 s_\\alpha}")#text(". The former is absurd, thus ")#mi("{w^{\\prime}_2 = w_1 s_\\alpha}")#text(" and thus ")#mi("{w_1=w_2}")#text(" as required. ")#mi("\\Box")

#text("By further exploitation of the ")#mi("{(B,N)}")#text("-pair axioms and some other properties of ")#mi("{G_{ad}(k)}")#text(", we can show that this group is simple in the group-theoretic sense in almost all cases (there are a few exceptions in very low characteristic). This generalises the discussion of complex Lie groups in the previous section, except now we do not need to pass through the simplicity of the associated Lie algebra (and instead work with the irreducibility of the root system).")

#text("We use an argument of Iwasawa and Tits. We first need some structural results about ")#link("http://en.wikipedia.org/wiki/Parabolic_subgroup")[#text("parabolic subgroups")]#text(" of ")#mi("{G_{ad}(k)}")#text(" – subgroups that contain the Borel subgroup ")#mi("{B}")#text(" (or a conjugate thereof).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" ")#metadata(none) <tao-15f3b852d2465ae56ff5>#text(" Let ")#mi("{w \\in W}")#text(" be an element of the Weyl group, with a minimal-length representation ")#mi("{w = s_{\\alpha_1} \\ldots s_{\\alpha_l}}")#text(" in terms of representations. Then ")#mi("{n_{s_{\\alpha_1}},\\ldots,n_{s_{\\alpha_l}}}")#text(" lie in the group generated by ")#mi("{B(k)}")#text(" and ")#mi("{n_w B(k) n_w^{-1}}")#text(".")
]

#emph[#text("Proof:")]#text(" We may assume inductively that ")#mi("{l>0}")#text(" and that the claim has been proven for smaller values of ")#mi("{l}")#text(". From minimality we know that ")#mi("{w^{-1}(\\alpha_1)}")#text(" is a negative root, and so")

#align(center)[#tao-fit-display[#mitex("U_{-\\alpha}(k) = n_w U_{-w^{-1}(\\alpha)}(k) n_w^{-1} \\subset n_w B(k) n_w^{-1}")]]

#text("and ")#mi("{U_\\alpha(k) \\subset B(k)}")#text(", hence ")#mi("{n_\\alpha}")#text(", being in the group generated by ")#mi("{U_\\alpha(k)}")#text(" and ")#mi("{U_{-\\alpha}(k)}")#text(", is contained in the group generated by ")#mi("{B(k)}")#text(" and ")#mi("{n_w B(k) n_w^{-1}}")#text(". Writing ")#mi("{w = s_\\alpha w^{\\prime}}")#text(", this implies that this group contains the group generated by ")#mi("{B(k)}")#text(" and ")#mi("{n_{w^{\\prime}} B(k) n_{w^{\\prime}}^{-1}}")#text(", and the claim then follows from induction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 9 (Classification of parabolic groups)")]#text(" ")#metadata(none) <tao-e2b69d98193f4e08e070>#text(" Every parabolic group ")#mi("{B(k) \\subset P \\subset G_{ad}(k)}")#text(" containing ")#mi("{B(k)}")#text(" takes the form ")#mi("{\\bigcup_{w \\in W_\\pi} C(w)}")#text(" for some ")#mi("{\\pi \\subset \\Pi}")#text(", where ")#mi("{W_\\pi}")#text(" is the subgroup of ")#mi("{W}")#text(" generated by the ")#mi("{s_\\alpha}")#text(" for ")#mi("{\\alpha \\in \\Pi}")#text(", and conversely each of the ")#mi("{\\bigcup_{w \\in W_\\pi} C(w)}")#text(" is a parabolic subgroup of ")#mi("{G_{ad}(k)}")#text(". Furthermore all of these ")#tao-math("{2^{\\left|\\Pi\\right|}}", block: false)#text(" parabolic groups are distinct.")
]

#emph[#text("Proof:")]#text(" The fact that ")#mi("{\\bigcup_{w \\in W_\\pi} C(w)}")#text(" is a group follows from Lemma ")#link(<tao-c81b021331344adcdd57>)[#text("6")]#text(". To show distinctness, it suffices by the Bruhat decomposition to show that the ")#mi("{W_\\pi}")#text(" are all distinct, but this follows from the linear independence of the simple roots. Finally, if ")#mi("{P}")#text(" is a parabolic subgroup containing ")#mi("{B(k)}")#text(", we can set ")#mi("{\\pi := \\{ \\alpha \\in \\Pi: n_\\alpha \\in P \\}}")#text(", then clearly ")#mi("{P}")#text(" contains ")#mi("{\\bigcup_{w \\in W_\\pi} C(w)}")#text(". On the other hand, as ")#mi("{P = B(k) P B(k)}")#text(", ")#mi("{P}")#text(" is the union of double cosets ")#mi("{C(w)}")#text(", and from Lemma ")#link(<tao-15f3b852d2465ae56ff5>)[#text("8")]#text(" if ")#mi("{P}")#text(" contains ")#mi("{C(w)}")#text(", then ")#mi("{w}")#text(" is generated by reflections from ")#mi("{\\pi}")#text(". The claim follows. ")#mi("\\Box")

#text("This, together with the previously noted solvability of ")#mi("{B}")#text(" and the irreducibility of the root system, gives a useful criterion for simplicity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Criterion for simplicity)")]#text(" ")#metadata(none) <tao-6d8ab6a74666f61de3cb>#text(" Suppose that ")#mi("{G_{ad}(k)}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Perfect_group")[#text("perfect group")]#text(" and that ")#mi("{B(k)}")#text(" does not contain any non-trivial normal subgroup of ")#mi("{G_{ad}(k)}")#text(" (i.e. ")#mi("{\\bigcap_{g \\in G_{ad}(k)} g B(k) g^{-1} = \\{1\\}}")#text("). Then ")#mi("{G_{ad}(k)}")#text(" is simple.")
]

#emph[#text("Proof:")]#text(" Let ")#mi("{H}")#text(" be a non-trivial normal subgroup of ")#mi("{G_{ad}(k)}")#text(". Then by hypothesis ")#mi("{H}")#text(" is not contained in ")#mi("{B(k)}")#text(", so the group ")#mi("{HB(k)}")#text(" is a parabolic subgroup of ")#mi("{G_{ad}(k)}")#text(" that is strictly larger than ")#mi("{B(k)}")#text(", thus ")#mi("{HB(k) =\\bigcup_{w \\in W_\\pi} C(w)}")#text(" for some non-empty ")#mi("{\\pi \\subset \\Pi}")#text(". If ")#mi("{\\alpha \\in \\pi}")#text(" and ")#mi("{\\beta \\in \\Pi \\backslash \\pi}")#text(", then ")#mi("{H}")#text(" intersects ")#mi("{C(s_\\alpha)}")#text(", and thus (by the normality of ")#mi("{H}")#text(") also intersects ")#mi("{n_{s_\\beta} C(s_\\alpha) n_{s_\\beta}^{-1}}")#text(". By Lemma ")#link(<tao-c81b021331344adcdd57>)[#text("6")]#text(" (and ")#link(<tao-0fc1806534e7eb831d53>)[#text("(3)")]#text("), we have")

#tao-aligned(keep: true)[


#tao-math("n_{s_\\beta} C(s_\\alpha) n_{s_\\beta}^{-1}  & \\subset C(s_\\beta) C(s_\\alpha) C(s_\\beta) = C(s_\\beta) C(s_\\alpha s_\\beta)", block: true)



#tao-math(" & \\subset C(s_\\beta s_\\alpha s_\\beta) \\cup C(s_\\alpha s_\\beta)", block: true)
]

#text("and so at least one of ")#mi("{s_\\beta s_\\alpha s_\\beta}")#text(" and ")#mi("{s_\\alpha s_\\beta}")#text(" lies in ")#mi("{W_\\pi}")#text(". But as ")#mi("{s_\\alpha \\in W_\\pi}")#text(" and ")#mi("{s_\\beta \\not \\in W_\\pi}")#text(", we conclude that ")#mi("{s_\\beta s_\\alpha s_\\beta \\in W_\\pi}")#text(". From this and Lemma ")#link(<tao-15f3b852d2465ae56ff5>)[#text("8")]#text(" we see that any minimal representation of ")#mi("{s_\\beta s_\\alpha s_\\beta}")#text(" has generators both in ")#mi("{\\{\\alpha,\\beta\\}}")#text(" and ")#mi("{\\pi}")#text(", which forces ")#mi("{s_\\beta s_\\alpha s_\\beta = s_\\alpha}")#text(" (note that ")#mi("{s_\\beta s_\\alpha s_\\beta}")#text(" cannot vanish). Thus we see that ")#mi("{s_\\alpha}")#text(" commutes with ")#mi("{s_\\beta}")#text(", contradicting the irreducibility of the root system unless ")#mi("{\\pi = \\Pi}")#text(". We thus have ")#mi("{HB(k) = G_{ad}(k)}")#text(". As ")#mi("{G_{ad}(k)}")#text(" is perfect, this implies that ")#mi("{G_{ad}(k)/H}")#text(" is also perfect; but this is a quotient of the solvable group ")#mi("{B(k)}")#text(" and is thus solvable also. As only the trivial group is both perfect and solvable, we conclude that ")#mi("{H = G_{ad}(k)}")#text(", and the claim follows. ")#mi("\\Box")

#text("In the specific case of the adjoint form, the second hypothesis in Lemma ")#link(<tao-6d8ab6a74666f61de3cb>)[#text("10")]#text(" can be verified:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#mi("{B(k)}")#text(" does not contain any non-trivial normal subgroup of ")#mi("{G_{ad}(k)}")#text(".")
]

#text("As in the complex case, it turns out that non-adjoint forms of a Chevalley group have non-trivial centre that lies in every maximal torus and hence in every Borel group, so this lemma is specific to the adjoint form.")

#emph[#text("Proof:")]#text(" Let ")#mi("{H}")#text(" be a normal subgroup of ")#mi("{G_{ad}(k)}")#text(" that lies in ")#mi("{B(k)}")#text(". Conjugating by the long word in ")#mi("{W}")#text(" (that maps all positive roots to negative roots) we see that ")#mi("{H}")#text(" actually lies in the torus ")#mi("{T(k)}")#text(". In particular, for any root ")#mi("{\\alpha}")#text(", ")#mi("{[H, U_\\alpha(k)]}")#text(" lies in both ")#mi("{H \\subset T(k)}")#text(" and ")#mi("{U_\\alpha(k)}")#text(" and is thus trivial; this shows that ")#mi("{H}")#text(" is central. But by the Cartan-Weyl relations we see that there are no elements of ")#mi("{T(k)}")#text(" that commute with all the ")#mi("{U_\\alpha(k)}")#text(", and the claim follows. ")#mi("\\Box")

#text("We remark that the above arguments can also be adapted to show that ")#mi("{G_{ad}(k)}")#text(" always has trivial centre ")#mi("{Z(G_{ad}(k))}")#text(" (because the above lemma and the proof of Lemma ")#link(<tao-6d8ab6a74666f61de3cb>)[#text("10")]#text(" then shows that ")#mi("{Z(G_{ad}(k)) B(k) = G_{ad}(k)}")#text(", making ")#mi("{B(k)}")#text(" normal in ")#mi("{G(k)}")#text(", which can be shown to lead to a contradiction).")

#text("From the above discussion we see that ")#mi("{G_{ad}(k)}")#text(" will be simple whenever it is perfect. Establishing perfection is relatively easy in most cases, as it only requires enough explicit examples of commutators to encompass a generating subset of ")#mi("{G_{ad}(k)}")#text(". It is only when the field ")#mi("{k}")#text(" and the Dynkin diagram are extremely small that one has too few commutators to make a generating subset, and ")#mi("{G_{ad}(k)}")#text(" fails to be perfect (and thus also fails to be simple); the specific failures turn out to be ")#mi("{A_1({\\bf F}_2)}")#text(", ")#mi("{A_1({\\bf F}_3)}")#text(", ")#mi("{B_2({\\bf F}_2)}")#text(", and ")#mi("{G_2({\\bf F}_2)}")#text(". See the ")#link("http://www.ams.org/mathscinet-getitem?mr=794307")[#text("text of Carter")]#text(" for details.")

#text("We have focused primarily on the adjoint form ")#mi("{G_{ad}(k)}")#text(" of the Chevalley groups, but much as in the complex Lie group case, to each Dynkin diagram and field ")#mi("{k}")#text(" one can associate a finite number of forms of the Chevalley group, ranging from the minimal example of the adjoint form ")#mi("{G_{ad}(k)}")#text(" to the maximal example ")#mi("{G_u(k)}")#text(" of the universal form. When ")#mi("{k}")#text(" is algebraically closed, these are all linear algebraic groups, and every form of the Chevalley group has an ")#link("http://en.wikipedia.org/wiki/Isogeny")[#text("isogeny")]#text(" (the algebraic group analogue of a finite cover) to the adjoint form (arising from quotienting out by the centre) and receives an isogeny from the universal form, much as in the complex case. We still have the basic identity ")#link(<tao-cb96897bd0f82fd54c24>)[#text("(1)")]#text(", but the lattices ")#mi("{P,Q}")#text(" now lie over ")#mi("{k}")#text(" rather than ")#mi("{{\\bf R}}")#text(" or ")#mi("{{\\bf C}}")#text(" (which can make the order of ")#mi("{Q/P}")#text(" smaller than in the complex case if ")#mi("{k}")#text(" has small positive characteristic ")#mi("{p}")#text(" by quotienting out the elements of order a prime power of ")#mi("{p}")#text(", thus collapsing the number of distinct forms of the Chevalley group in some characteristics), and the fundamental group ")#mi("{\\pi_1(G_{ad}(k))}")#text(" has to be interpreted as an ")#link("http://en.wikipedia.org/wiki/%C3%89tale_fundamental_group")[#text("étale fundamental group")]#text(" rather than a topological fundamental group. See for instance the ")#link("http://www.math.ucla.edu/~rst/YaleNotes.pdf")[#text("notes of Steinberg")]#text(" or the ")#link("http://www.math.ucla.edu/~rst/YaleNotes.pdf")[#text("text of Gorenstein-Lyons-Solomon")]#text(" for details. As an example of the collapse phenomenon mentioned earlier, ")#mi("{\\text{SL}_2(k)}")#text(" (the universal form for ")#mi("{A_1(k)}")#text(") and ")#mi("{\\text{PSL}_2(k)}")#text(" (the adjoint form for ")#mi("{A_1(k)}")#text(") are distinct for most fields ")#mi("{k}")#text(", but coincide when ")#mi("{k}")#text(" has characteristic two.")

#text("We also caution that a Chevalley group ")#mi("{G(k)}")#text(" over a non-algebraically closed field is not necessarily the same as the set of ")#mi("{k}")#text("-points of the Chevalley group ")#mi("{G(\\overline{k})}")#text(" of the algebraic closure ")#mi("{\\overline{k}}")#text(", as the latter may be strictly larger. For instance, the real elements of ")#mi("{\\text{PSL}_2({\\bf C}) = \\text{PGL}_2({\\bf C})}")#text(" are the elements of ")#mi("{\\text{PGL}_2({\\bf R})}")#text(", which a larger group than ")#mi("{\\text{PSL}_2({\\bf R})}")#text(" (it also contains the projectivisation of matrices with negative determinant). Thus Chevalley groups and algebraic groups are slightly different concepts when specialised to non-algebraically closed fields.")

#text("The Chevalley construction gives some specific families of algebraic groups over algebraically closed fields that are either simple (in the adjoint form) or almost simple (which means that the only normal groups are zero-dimensional); in the latter case they are also quasisimple as in the complex case. It is natural to ask whether there are any other (non-abelian) simple algebraic groups over an algebraically closed field. It turns out (quite remarkably) that one can perform the entirety of the classification of complex Lie algebras in the category of algebraic groups over a given algebraically closed field (regardless of its characteristic!), to arrive at the conclusion that the Chevalley groups are (up to isomorphism) the ")#emph[#text("only")]#text(" non-abelian simple or almost simple connected linear algebraic groups. This is despite the lack of any reasonable analogue of the compact form ")#mi("{G_c}")#text(" over arbitrary fields, and also despite the additional subtleties present in the structural theory of Lie algebras when the characteristic is positive and small. Instead, one has to avoid use of Lie algebras or compact forms, and try to build the basic ingredients of the ")#mi("{(B,N)}")#text("-pair structure mentioned above (e.g. maximal tori, Borel subgroups, roots, etc.) directly. This result however requires a serious amount of algebraic geometry machinery and will not be discussed here; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=396773")[#text("this text of Humphreys")]#text(" for details.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" ")#metadata(none) <tao-3f524cdc07a11d7c6220>#text(" The Bruhat decomposition gives a parameterisation of ")#mi("{G_{ad}(k)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("G_{ad}(k) = \\bigcup_{w \\in W} U(k) T(k) n_w U_w^-(k)")]]

#text("where ")#mi("{U(k)}")#text(" is the group generated by the ")#mi("{U_\\alpha(k)}")#text(" for all positive roots ")#mi("{\\alpha}")#text(", and ")#mi("{U_w^-(k)}")#text(" is the subgroup generated by the ")#mi("{U_\\alpha}")#text(" for those positive roots ")#mi("{\\alpha}")#text(" for which ")#mi("{w(\\alpha)}")#text(" is negative; every element ")#mi("{g}")#text(" of ")#mi("{G(k)}")#text(" then has a unique representation of the form")

#align(center)[#tao-fit-display[#mitex("g = u t n_w u^{\\prime}")]]

#text("for some ")#mi("{w \\in W}")#text(", ")#mi("{u \\in U(k)}")#text(", ")#mi("{t \\in T(k)}")#text(", and ")#mi("{u^{\\prime} \\in U_w^-(k)}")#text(". Among other things, this allows for a computation of the order of the Chevalley group ")#mi("{G_{ad}({\\bf F}_q)}")#text(" over a finite field of ")#mi("{q}")#text(" elements:")

#align(center)[#tao-fit-display[#tao-math("\\left|G_{ad}({\\bf F}_q)\\right| = \\sum_{w \\in W} q^N (q-1)^r q^{N_w}", block: true)]]

#text("where ")#mi("{N}")#text(" is the number of positive roots, ")#mi("{r}")#text(" is the rank (the dimension of the maximal torus), and ")#mi("{N_w}")#text(" is the number of positive roots ")#mi("{\\alpha}")#text(" with ")#mi("{w(\\alpha)}")#text(" negative. If suggestively writes ")#mi("{q=1+\\epsilon}")#text(", this becomes")

#align(center)[#tao-fit-display[#tao-math("\\left|G_{ad}({\\bf F}_{1+\\epsilon})\\right| = \\epsilon^r ( \\left|W\\right| + O(\\epsilon) )", block: true)]]

#text("suggesting that in the limit ")#mi("{\\epsilon \\rightarrow 0}")#text(", the Chevalley group ")#mi("{G_{ad}({\\bf F}_1)}")#text(" over the “")#link("http://en.wikipedia.org/wiki/Field_with_one_element")[#text("field with one element")]#text("” should degenerate to something like ")#mi("{N({\\bf F}_1) = T({\\bf F}_1) . W}")#text(", an extension of the Weyl group by some sort of torus over the field with one element. Now, this calculation does not make actual rigorous sense – the currently accepted definition of a field does not allow the possibility of fields of order equal to one (or arbitrarily close to one) – but there are tantalising hints in various areas of mathematics that these sorts of formal computations can sometimes to tied to interesting rigorous mathematical statements. However, it appears that we are still some ways off from a completely satisfactory understanding of the extent to which the “field with one element” actually exists, and what its nature is.")
]

#heading(level: 1)[#strong[#text(" — 3. Finite simple groups of Lie type — ")]]

#text("As discussed above, the (adjoint form of the) Chevalley group construction ")#mi("{G_{ad}(k)}")#text(", when applied to a finite field, usually gives a finite simple group. However, this construction does not give all of the finite simple groups that are associated to Lie groups. A basic example is the ")#emph[#text("projective special unitary group")]#text(" ")#mi("{\\text{PSU}_n({\\bf F}_{q})}")#text(" over a finite field whose order ")#mi("{q}")#text(" is a perfect square: ")#mi("{q= \\tilde q^2}")#text(". This field supports a Frobenius automorphism ")#mi("{\\tau: x \\mapsto x^{\\tilde q}}")#text(" which behaves much like complex conjugation ")#mi("{z \\mapsto \\overline{z}}")#text(" does on the complex field (for instance, ")#mi("{\\tau}")#text(" fixes the index two subfield ")#mi("{{\\bf F}_{\\tilde q}}")#text(", much as complex conjugation fixes the index two subfield ")#mi("{{\\bf R}}")#text("). We can then define ")#mi("{\\text{PSU}_n({\\bf F}_{q^2})}")#text(" as the quotient of the matrix group ")#metadata(none) <tao-27756f050e14a1cb1c1e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("SU_n({\\bf F}_{q}) := \\{ U \\in \\text{SL}_n({\\bf F}_{q}): U \\tau(U^T) = 1 \\}")]]

#text("by its centre, where ")#mi("{\\tau(U^T)}")#text(" is the matrix formed by applying the Frobenius automorphism ")#mi("{\\tau}")#text(" to each entry of the transpose ")#mi("{U^T}")#text(" of ")#mi("{TU}")#text(". This resembles Chevalley groups such as ")#mi("{\\text{PSL}_n(k)}")#text(", but the group ")#mi("{\\text{PSU}_n(k)}")#text(" requires the additional input of the Frobenius automorphism, which is available for some fields ")#mi("{k}")#text(" but not for others, and destroys the algebraic nature of the group. For instance, ")#mi("{\\text{PSU}_n({\\bf C})}")#text(" is not a complex algebraic group, because complex conjugation ")#mi("{z \\mapsto \\overline{z}}")#text(" is not a complex algebraic operation; it is similarly not a complex Lie group because complex conjugation is not a complex analytic operation. One can view this groups as algebraic (or analytic) over an index two subgroup – for instance, ")#mi("{\\text{PSU}_n({\\bf C})}")#text(" is a ")#emph[#text("real")]#text(" Lie group, and can also be (carefully) viewed as a real algebraic group, as long as one bears in mind that the reals are not algebraically closed. While this can certainly be a profitable way to view group of this type (known as ")#link("http://en.wikipedia.org/wiki/Steinberg_group_(Lie_theory)#Steinberg_groups")[#text("Steinberg groups")]#text("), there is another perspective on such groups which extends to the most general class of finite simple groups of Lie types, which contains not only the Chevalley groups and the Steinberg groups but an additional third class, namely the ")#emph[#text("Suzuki-Ree groups")]#text(". To motivate this different viewpoint, observe that the definition ")#link(<tao-27756f050e14a1cb1c1e>)[#text("(4)")]#text(" of the special unitary group ")#mi("{SU_n({\\bf F}_{q})}")#text(" can be rewritten as")

#align(center)[#tao-fit-display[#mitex("SU_n({\\bf F}_{q}) = \\{ U \\in \\text{SL}_n({\\bf F}_{q}): \\sigma(U) = U \\}")]]

#text("where ")#mi("{\\sigma = \\rho \\circ \\tau = \\tau \\circ \\rho}")#text(", ")#mi("{\\tau}")#text(" is the Frobenius map defined earlier (acting componentwise on each matrix entry), and ")#mi("{\\tau}")#text(" is the transpose inverse map ")#metadata(none) <tao-0b9da5e5b61c22045eb6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\rho(U) := (U^T)^{-1}.")]]

#text("Observe that ")#mi("{\\tau}")#text(" and ")#mi("{\\rho}")#text(" are commuting automorphisms on ")#mi("{\\text{SL}_n({\\bf F}_{q^2})}")#text(" of order two, and so ")#mi("{\\sigma}")#text(" is also an automorphism of order two (i.e. it is an ")#link("http://en.wikipedia.org/wiki/Involution_(mathematics)")[#text("involution")]#text("). Thus we see that the special unitary group is the subgroup of the Chevalley group ")#mi("{\\text{SL}_n({\\bf F}_{q^2})}")#text(" which is fixed by the involution ")#mi("{\\sigma}")#text(".")

#text("This suggests that we can locate other finite simple (or at least finite quasisimple) groups of Lie type by looking at the fixed points")

#align(center)[#tao-fit-display[#mitex("G({\\bf F}_q)^\\sigma = \\{ g \\in G({\\bf F}_q): \\sigma(g) = g \\}")]]

#text("of automorphisms ")#mi("{\\sigma}")#text(" in a Chevalley group ")#mi("{G({\\bf F}_{q})}")#text(". One should look for automorphisms with a fairly small order (such as two or three), as otherwise the fixed point set might be so small as to generate a trivial group.")

#text("As the example of the special unitary group suggests, one can obtain such automorphisms ")#mi("{\\sigma}")#text(" by composing two types ")#mi("{\\rho,\\tau}")#text(" of automorphisms. On the one hand, we have the ")#emph[#text("field automorphisms")]#text(" ")#mi("{\\tau: x \\mapsto x^{\\tilde q}}")#text(", where ")#mi("{\\tilde q}")#text(" is some power of the characteristic ")#mi("{p}")#text(" of the field ")#mi("{{\\bf F}_q}")#text(", applied to each matrix entry of Chevalley group elements. On the other hand, we have ")#emph[#text("graph automorphisms")]#text(" ")#mi("{\\rho: G(k) \\rightarrow G(k)}")#text(", arising from automorphisms of the Dynkin diagram (which, as noted in ")#link("https://terrytao.wordpress.com/2013/04/27/notes-on-the-classification-of-complex-lie-algebras/")[#text("Theorem 29 of this previous post")]#text(", induces an automorphism of Lie algebras, and can also be used to induce an automorphism of Chevalley groups), which commute with field automorphisms. The transpose inverse map ")#mi("{\\rho}")#text(" defined in ")#link(<tao-0b9da5e5b61c22045eb6>)[#text("(5)")]#text(" is, strictly speaking, not of this form: it is associated to the Lie algebra involution ")#mi("{x \\mapsto -x^T}")#text(", which maps each root ")#mi("{e_i - e_j}")#text(" to its negation ")#mi("{e_j-e_i}")#text(", so in particular does not map simple roots to simple roots. However, if one composes ")#mi("{\\rho}")#text(" with the conjugation action of the ")#emph[#text("long word")]#text(" in the Weyl group (an example of an inner automorphism), which in the case of ")#mi("{\\text{SL}_n}")#text(" is represented by an antidiagonal matrix, the associated Lie algebra involution now maps each root ")#mi("{e_i-e_j}")#text(" to its reflection ")#mi("{e_{n+1-j} - e_{n+1-i}}")#text(", and corresponds to the Dynkin diagram automorphism of ")#mi("{A_n}")#text(" formed by reflection. With this conjugation by the long word, the fixed points of the resulting automorphism ")#mi("{\\sigma}")#text(" is still a special unitary group ")#mi("{SU_n({\\bf F}_q)}")#text(", but the sesquilinear form that defines unitarity is not the familiar form")

#align(center)[#tao-fit-display[#mitex("\\langle (x_1,\\ldots,x_n), (y_1,\\ldots,y_n) \\rangle := x_1 \\tau(y_1) + \\ldots + x_n \\tau(y_n)")]]

#text("but rather an antidiagonal version")

#align(center)[#tao-fit-display[#mitex("\\langle (x_1,\\ldots,x_n), (y_1,\\ldots,y_n) \\rangle := x_1 \\tau(y_n) + \\ldots + x_n \\tau(y_1).")]]

#text("It turns out that up to group isomorphism, we still obtain the same projective special unitary group ")#mi("{\\text{PSU}_n({\\bf F}_q)}")#text(" regardless of choice of sesquilinear form, so this reversal in the definition of the form is ultimately not a difficulty.")

#text("If the graph automorphism ")#mi("{\\rho}")#text(" has order ")#mi("{d}")#text(", and one takes the field automorphism ")#mi("{\\tau}")#text(" to also have order ")#mi("{d}")#text(" by requiring that ")#mi("{q = \\tilde q^d}")#text(", take the fixed points ")#mi("{G(q)^\\sigma}")#text(" of the resulting order ")#mi("{d}")#text(" automorphism ")#mi("{\\sigma = \\rho \\tau}")#text(", we (essentially) obtain the standard form of a ")#link("http://en.wikipedia.org/wiki/Steinberg_group_(Lie_theory)#Steinberg_groups")[#text("Steinberg group")]#text(" ")#mi("{{}^d {\\bf D}(q)}")#text(", where ")#mi("{{\\bf D}}")#text(" is the Dynkin diagram. By “essentially”, we mean that we may first have to pass to a bounded index subgroup, and then quotient out by the centre, before one gets a finite simple group; this is a technical issue which be will briefly discuss later. Thus for instance ")#mi("{\\text{PSU}_n({\\bf F}_q)}")#text(" is denoted ")#mi("{{}^2 A_{n-1}(q)}")#text(". (In some texts such a group would be denoted ")#mi("{{}^2 A_{n-1}(\\tilde q)}")#text(" instead.) In a similar vein, the Dynkin diagrams ")#mi("{D_n}")#text(" and ")#mi("{E_6}")#text(" also obviously support order two automorphisms, leading to additional Steinberg groups ")#mi("{{}^2 D_n(q), {}^2 E_6(q)}")#text(" when ")#mi("{q = \\tilde q^2}")#text(" is a perfect square. The ")#mi("{{}^2 D_n(q)}")#text(" class can be interpreted as a class of projective special orthogonal groups, but ")#link("http://en.wikipedia.org/wiki/2E6_(mathematics)")[#text("the ")#mi("{{}^2 E_6(q)}")#text(" family")]#text(" does not have a classical interpretation. A noteworthy special case is ")#mi("{D_4}")#text(", which is the unique Dynkin diagram that also supports an automorphism of order three, leading to the final class of Steinberg groups, the ")#link("http://en.wikipedia.org/wiki/%C2%B3D%E2%82%84")[#text("triality groups")]#text(" ")#mi("{{}^3 D_4(q)}")#text(" when ")#mi("{q = \\tilde q^3}")#text(" is a perfect cube.")

#text("In large characteristic (five and higher), the Chevalley and Steinberg groups are (up to isomorphism) turn out to be the only way to generate finite simple groups of Lie type; one can experiment with other cocmbinations of automorphisms on Chevalley groups but they end up either giving the same groups up to isomorphism as the preceding constructions, or groups that are not simple (they do not obey the ")#mi("{(B,N)}")#text(" axioms that one can use to easily test for simplicity). But in small characteristic, where the distinction between short and long roots can become blurred, there are additional Dynkin diagram automorphisms. Specifically, for the Dynkin diagrams ")#mi("{B_2=C_2}")#text(" and ")#mi("{F_4}")#text(" in ")#link("http://en.wikipedia.org/wiki/Perfect_field")[#text("perfect fields")]#text(" of characteristic two, there is a ")#emph[#text("projective")]#text(" Dynkin diagram automorphism of order two that swaps the long and short roots, which induces a automorphism ")#mi("{\\rho}")#text(" of the Chevalley group which is order two modulo a Frobenius map (in that ")#mi("{\\rho^2}")#text(" is given by the Frobenius map ")#mi("{x \\mapsto x^2}")#text("); see the ")#link("http://www.ams.org/mathscinet-getitem?mr=794307")[#text("text of Carter")]#text(" for the construction. If one combines this automorphism with a field automorphism ")#mi("{\\tau: x \\mapsto x^{\\tilde q}}")#text(" with ")#mi("{q}")#text(" equal to ")#mi("{2\\tilde q^2}")#text(", we obtain an order two automorphism ")#mi("{\\sigma}")#text(" that generates the families of ")#link("http://en.wikipedia.org/wiki/Suzuki_groups")[#text("Suzuki groups")]#text(" ")#mi("{{}^2 B_2(2^{2n+1})}")#text(" and ")#link("http://en.wikipedia.org/wiki/Ree_group")[#text("Ree groups")]#text(" ")#mi("{{}^2 F_4(2^{2n+1})}")#text(". Similarly, the Dynkin diagram ")#mi("{G_2}")#text(" in perfect fields of characteristic three has an automorphism that swaps the short and long root, and if ")#mi("{q = 3 \\tilde q^2}")#text(" leads to the final class of Ree groups, ")#mi("{{}^3 G_2(3^{2n+1})}")#text(". In contrast to the Steinberg groups, the Suzuki-Ree groups cannot be easily viewed as algebraic groups over a suitable subfield; morally, one “wants” to view ")#mi("{{}^2 B_2(2^{2n+1})}")#text(" and ")#mi("{{}^2 F_4(2^{2n+1})}")#text(" as being algebraic over the field of ")#mi("{2^{n+1/2}}")#text(" elements (and similarly view ")#mi("{{}^3 G_2(3^{2n+1})}")#text(" as algebraic over the field of ")#mi("{3^{n+1/2}}")#text(" elements), but such fields of course do not exist. (Despite superficial similarity, this issue appears unrelated to the “field with one element” discussed in Remark ")#link(<tao-3f524cdc07a11d7c6220>)[#text("3")]#text(", although both phenomena do suggest that there is perhaps a useful generalisation of the concept of a field that is currently missing from modern mathematics.) One can also view the Steinberg and Suzuki-Ree groups ")#mi("{{}^d {\\bf D}(q)}")#text(" (collectively referred to as ")#emph[#text("twisted")]#text(" groups of Lie type) as being “fractal” subgroups (modulo quotienting by the centre) of the associated Chevalley group ")#mi("{{\\bf D}(q)}")#text(", of relative “fractal dimension” about ")#mi("{1/d}")#text(", with the former group lying in “general position” with respect to the latter in some algebraic geometry sense; for instance one could view ")#mi("{\\text{PSU}_n({\\bf F}_{q})}")#text(" as a subgroup of ")#mi("{\\text{PSL}_n({\\bf F}_q)}")#text(" of approximately “half the dimension”, and in general position in the sense that it does not lie in any (bounded complexity) algberaic subgroup of ")#mi("{\\text{PSL}_n({\\bf F}_q)}")#text(". This type of viewpoint was formalised quite profitably in ")#link("http://www.ams.org/mathscinet-getitem?mr=2813339")[#text("this paper of Larsen and Pink")]#text(" (and is also used in a forthcoming paper of Breuillard, Green, Guralnick, and myself).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" We have oversimplified slightly the definition of a twisted finite simple group of Lie type: in some cases the group ")#mi("{G({\\bf F}_q)^\\sigma}")#text(" is not quite a simple group. As in the previous section, this can happen for very small groups (the Chevalley group examples ")#mi("{A_1(2), A_1(3)}")#text(", ")#mi("{B_2(2)}")#text(", ")#mi("{G_2(2)}")#text(" mentioned earlier, but also ")#mi("{{}^2 A_2(4)}")#text(", ")#mi("{{}^2 B_2(2)}")#text(", ")#mi("{{}^2 G_2(3)}")#text(", and ")#mi("{{}^2 F_4(2)}")#text("). Another issue (which already arises in the Chevalley group case if one does not use the adjoint form) is that the fixed points ")#mi("{G({\\bf F}_q)^\\sigma}")#text(" contain a non-trivial centre and are only a quasisimple group rather than a simple group. Usually one can quotient out by the centre (which will always be quite small) to recover the finite simple group, or work exclusively with adjoint forms which are automatically centreless. But there is one additional technicality that arises even in the adjoint form, which is that sometimes there are some extraneous fixed points of ")#mi("{\\sigma}")#text(" of ")#mi("{G({\\bf F}_q)}")#text(" that one does not actually want (for instance, they do not lie in the group generated by the natural analogues of the ")#mi("{B}")#text(" and ")#mi("{N}")#text(" groups in this setting, thus violating the ")#mi("{(B,N)}")#text("-axioms). So one sometimes has to restrict attention to a bounded index subgroup of ")#mi("{G({\\bf F}_q)^\\sigma}")#text(", such as the group ")#mi("{O^{p^{\\prime}}(G({\\bf F}_q)^\\sigma)}")#text(" generated by those “unipotent” elements whose order is a power of the characteristic ")#mi("{p}")#text("; an alternative (and equivalent, except in very small cases) approach is to work with the derived group ")#mi("{[G({\\bf F}_q)^\\sigma,G({\\bf F}_q)^\\sigma]}")#text(" of ")#mi("{G({\\bf F}_q)^\\sigma}")#text(", which turns out to kill off the extraneous elements (which are associated to another type of automorphism we did not previously discussed, namely the ")#emph[#text("diagonal")]#text(" automorphisms). See ")#link("http://www.ams.org/mathscinet-getitem?mr=1490581")[#text("the text of Gorenstein-Lyons-Solomon")]#text(" for a detailed treatment of these issues.")
]

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/353141aae94df7fa820777cb2404306103c8b4d2cb07198e646dd27cd03b4fd8-ae54acbeb25fd6976c81a2bd90e2755b6b6bf11acb02b45569f51a48e53cc15f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amarashiki")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-243984")[#strong[#text("amarashiki")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2013")])]

#text("Tao, this was a really amazing post!!!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-243996")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2013")])]

#text("At this point all discussions of Lie Algebras / Groups and Root Systems give me deja-vu.")

#text("Don’t get me wrong, I love groups and wish there were more of them!!")

#text("I didn’t know the “lie groups” over Finite Fields were simple.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244014")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2013")])]

#text("I was hoping to find out why _you_ now want to know this stuff well…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94e21653b7b79d97b506b801e8ba3da3c5e88db6699fb66c69bc693c2c43e4fd-9f150060fde18bc1fe5c3756171f085b194ea71b0afb5f0dceb65b332118656b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alireza")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244059")[#strong[#text("Alireza")]]#text(size: 9pt, fill: rgb("596477"), " · 6 September 2013")])]

#text("I’d rather view PGL_n as the adjoint form of SL_n. In some sense PSL_n is not a representable functor. Of course, over an algebraically closed field K we have PGL_n(K)=PSL_n(K), but not over other fields (e.g. finite fields).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244109")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")])]

#text("Hmm, there seems to be a tradeoff here between “functoriality” across different fields, and “connectedness” for a single choice of field. PGL_n may be a representable functor, but PGL_n(k) need not be simple or even quasisimple, and does not play the role of the “minimal” model of a group of Lie type the same way that PSL_n does. I could see it going both ways: PSL_n is the image of the adjoint representation of SL_n, but then again PGL_n is the image of the adjoint representation of GL_n. I believe my use of the term “adjoint form” is consistent with that in Gorenstein, Lyons, and Solomon, but I’d have to double-check that (my copy of GLS is at work).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bab7934735d2ba2b4e3716159b0cb5e2d1c5b4c6ea38ae916111e32485bef59-ec1f53e9079361e2247bfad065127558d7d4afc6d32de474c4fad1ff961e902c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alireza")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244184")[#strong[#text("Alireza")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")])]

#text("In some sense, PSL_n is NOT an algebraic group. As you said, for any (commutative) ring R, PSL_n(R)=Ad(SL_n(R)), but Ad(SL_n) as an algebraic group is PGL_n. So the adjoint form of SL_n is PGL_n.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bab7934735d2ba2b4e3716159b0cb5e2d1c5b4c6ea38ae916111e32485bef59-ec1f53e9079361e2247bfad065127558d7d4afc6d32de474c4fad1ff961e902c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alireza")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244186")[#strong[#text("Alireza")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2013")])]

#text("Just adding to the previous comment, in general I prefer to work with simply connected forms. Then I can view the adjoint form as a subgroup of the group of automorphisms of G(F) (for instance, one does the same for the construction and the study of Bruhat-Tits buildings).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2013")])]

#text("I think what is going on here is that the “correct” notion of an “adjoint form” (or “universal form”, etc.) depends on the precise category of groups (or group-like objects) one is working in. If one is working as an algebraic group theorist, then presumably one wants to work in the category of algebraic groups (with the underlying field ")#mi("k")#text(" or ring ")#mi("R")#text(" viewed as a parameter rather than being fixed, or equivalently one can take a scheme-theoretic point of view), in which case I agree that ")#mi("PSL_n")#text(" is not an algebraic group, and that ")#mi("PGL_n")#text(" is then the more natural choice for the adjoint form of ")#mi("SL_n")#text(". But the category of algebraic groups is not perfectly well-behaved with respect to quotients which leads to some complications (e.g. the adjoint form ")#mi("PGL_n")#text(" is not a quotient of the universal form ")#mi("SL_n")#text(" in this category).")

#text("But there are other categories one could work in instead. For instance, if one wants to work in the category of real Lie groups, then ")#mi("PSL_n({\\bf R})")#text(" is a real Lie group, and is the connected Lie group associated to the adjoint action of ")#mi("SL_n({\\bf R})")#text(" (or of the Lie algebra ")#mi("{\\mathfrak sl}_n({\\bf R})")#text("). The group ")#mi("PGL_n({\\bf R})")#text(" is also a real Lie group, with ")#mi("PSL_n({\\bf R})")#text(" as its connected component, but (when ")#mi("n")#text(" is even) it has an additional component which one cannot “reach” if one works purely over the reals, but one can see if one allows the underlying field to change temporarily to be complex (or if one works in the category of algebraic groups).")

#text("If one is thinking as a finite group theorist, and then works in the category of finite groups (which may, but do not necessarily have to, be the ")#mi("k")#text("-points of an algebraic group for a finite field ")#mi("k")#text(", or more generally the fixed points of some automorphism on such a group), then again ")#mi("PSL_n(k)")#text(" is the more natural candidate for the adjoint form for ")#mi("SL_n(k)")#text(" than ")#mi("PGL_n(k)")#text("; for instance, on page 68 of Gorenstein-Lyons-Solomon’s “The classification of finite simple groups, Number 3” ")#mi("PSL_{m+1}({\\bf F}_q)")#text(" is identified as the adjoint form of ")#mi("A_m(q)")#text(" (with ")#mi("PGL_{m+1}({\\bf F}_q)")#text(" being the associated inner diagonal group).")

#text("[This seems to be related to a technical issue when constructing finite simple groups of Lie type, in that one does not just take the fixed points ")#mi("C_{\\overline{K}}(\\sigma)")#text(" of some Steinberg endomorphism ")#mi("\\sigma")#text(" on an algebraic group, but rather just the subgroup ")#mi("O^{r^{\\prime}}(C_{\\overline{K}}(\\sigma))")#text(" of those fixed points generated by the ")#mi("r")#text("-elements.]")

#text("In the category of Chevalley groups over a given field ")#mi("k")#text(", it again seems that ")#mi("PSL_n(k)")#text(" is the better candidate for the adjoint form than ")#mi("PGL_n(k)")#text(" (see e.g. the table on page 45 of ")#link("http://www.math.ucla.edu/~rst/YaleNotes.pdf")[#text("these notes of Steinberg")]#text("). For instance, ")#mi("PSL_n(k)")#text(" is generated by the one-parameter unipotent subgroups coming from the Chevalley basis, whereas ")#mi("PGL_n(k)")#text(" is not.")

#text("[Again, this seems to relate to a divergence between a Chevalley group ")#mi("k \\mapsto G(k)")#text(" and an algebraic group ")#mi("k \\mapsto G(k)")#text(", when the underlying field ")#mi("k")#text(" is viewed as a parameter; a Chevalley group and an algebraic group may agree for algebraically closed fields ")#mi("k")#text(" but be slightly different for non-algebraically closed fields ")#mi("k")#text(", and in particular they have different functorial properties. For the Dynkin diagram ")#mi("A_m")#text(", it appears that ")#mi("PGL_{m+1}: k \\mapsto PGL_{m+1}(k)")#text(" is the adjoint form algebraic group, and ")#mi("PSL_{m+1}: k \\mapsto PSL_{m+1}(k)")#text(" is the adjoint form Chevalley group.]")

#text("I’m not 100% sure on this, but I believe that if one enlarges the category of algebraic groups to the category of ")#link("http://en.wikipedia.org/wiki/Group_scheme")[#text("group schemes")]#text(" (which is better behaved with respect to quotients than the category of algebraic groups), then ")#mi("PSL_n")#text(" becomes a valid object in the category, and I think one could make the case that this then becomes the natural adjoint form for ")#mi("SL_n")#text(" in this category.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244304")[#strong[#text("Rtistry & Rbominations :: linklist, sunday 2013-09-08")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2013")]

#text("[…] Notes on simple groups of Lie type […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94e21653b7b79d97b506b801e8ba3da3c5e88db6699fb66c69bc693c2c43e4fd-9f150060fde18bc1fe5c3756171f085b194ea71b0afb5f0dceb65b332118656b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alireza")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244339")[#strong[#text("Alireza")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2013")])]

#text("I do not know what you mean that “PGL_n is not the quotient of SL_n in the category of k-algebraic groups”. PGL_n is the quotient of SL_n as k-algebraic groups for any field k. We have the following short exact sequence")

#text("1–> \\mu_n –> SL_n –> PGL_n –>1")

#text("where \\mu_n is a k-group of n-th roots of unity. When it comes to looking at the l-rational points of these groups for a field extension l (or an k-algebra), one has to use either Galois or flat cohomology to get the needed information about the the image of the adjoint map. For instance in the case of a field extension using flat cohomology we have the following long exact sequence")

#text("1–> \\mu_n(l) –> SL_n(l) –> PGL_n(l) –> H^1_f(l,\\mu_n) –> H^1_f(l,SL_n)=1,")

#text("and so")

#text("1–> \\mu_n(l) –> SL_n(l) –> PGL_n(l) –> l^*/(l^*)^n — > 1.")

#text("This exact sequence shows what you described in the real case. One uses the same line of argument for any other group as well. In the other cases, one needs to use extra information about the cohomology of simply connected cases. For instance when l is finite, Lang’s theorem give us the needed information. Or when l is a local field Kneser-Bruhat-Tits theorem is needed and when l is global, local-global theorems give us the needed information and so on.")

#text("It is true that PSL_n(k) is generated by its (good) unipotent elements, but it is due to the fact that SL_n(k) has this property. As I said it in my previous comment, it is better to work on the simply connected case and using that one can get the desired result on the image of the k-points. It is worth pointing out the Kneser-Tits conjecture in connection to this point:")

#text("The conjecture essentially says if this fact is true for any other semisimple simply connected K-isotropic group or not; namely is G(K) generated by its (good) unipotent elements? [the quotient group is called the Whitehead group of (G,K)] And the answer is NO in general. However it is true for local and global fields. And of course it is true for the K-split groups a.k.a. Chevalley groups. Moral of the story, working with simply connected groups is much better ;)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244349")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2013")])]

#text("Ah, sorry about that; I had forgotten about the role of cohomology and was thinking (somewhat carelessly) that if H was a quotient of G as an algebraic group, then H(k) was a quotient of G(k) for any k; the fact I had in mind was that PGL_n(k) was not always a quotient of SL_n(k), but as you say this does not prohibit PGL_n from being a quotient of SL_n. (I’m much more used to working over a fixed field than over all fields simultaneously.)")

#text("In any event, I agree that simply connected forms are often easier to work with than adjoint forms; I certainly prefer working with SL_n than either PSL_n or PGL_n, for instance :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Expansion in finite simple groups of Lie type | What's new")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244501")[#strong[#text("Expansion in finite simple groups of Lie type | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2013")])]

#text("[…] this paper is to establish the analogous result for finite simple groups of Lie type (as defined in the previous blog post) and bounded rank, namely that almost all pairs of elements of such a group generate a Cayley […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd664bb5f6e554703ab5ba4d7623a284ef2d24f87435df545eaab3dabefa5065-3e8c8198b6f875b4fa8945bd1e6bc379cc63489321fa6ea9fb987f6777fc0115.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesper Grodal")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-244937")[#strong[#text("Jesper Grodal")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2013")])]

#text("Thanks for the post! Apart from the references you give (Carter, GLS,..), I’ve also found the recent book Linear Algebraic Groups and Finite Groups of Lie Type by Malle and Testerman a nice reference.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a34de3cadf72ccac6610285e12c3bcebfccb65bbfbc1dbf4a0a4e1418f0dfae9-ff08d1e6595501802fa250f8098ab7d7e733ad521cc83d71559bc3462cc6ab4f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vít Tuček")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-247093")[#strong[#text("Vít Tuček")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2013")])]

#text("Nitpick: The metaplectic group is not a double cover of the special linear group but of the symplectic group.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc678a306e0fcede9e7a4278338a87e2196f2a96421894c0f85be4d7be3d4572-64e06157cf51471c485ae2338e039f0e1225b8db9c473c9b5813a7239da992cb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hassan")]], [#link("https://terrytao.wordpress.com/2013/09/05/notes-on-simple-groups-of-lie-type/#comment-248476")[#strong[#text("hassan")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2013")])]

#text("What is the para-complexification of $U(n)$")
]
