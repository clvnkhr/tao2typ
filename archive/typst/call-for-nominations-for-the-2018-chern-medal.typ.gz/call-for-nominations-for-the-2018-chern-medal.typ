// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/11/29/call-for-nominations-for-the-2018-chern-medal/
// Converted to Typst by tao2typ: "2026-10-14T10:38:25.724725+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Call for nominations for the 2018 Chern Medal", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Call for nominations for the 2018 Chern Medal")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 November 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/11/29/call-for-nominations-for-the-2018-chern-medal/")[#text("https://terrytao.wordpress.com/2016/11/29/call-for-nominations-for-the-2018-chern-medal/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("[This guest post is authored by ")#link("https://homepages.warwick.ac.uk/~masbb/")[#text("Caroline Series")]#text(".]")

#text("The ")#link("http://www.mathunion.org/general/prizes/chern/details/")[#text("Chern Medal")]#text(" is a relatively new prize, awarded once every four years jointly by the IMU")#linebreak()#text(" and the Chern Medal Foundation (CMF) to an individual whose accomplishments warrant")#linebreak()#text(" the highest level of recognition for outstanding achievements in the field of mathematics.")#linebreak()#text(" Funded by the CMF, the Medalist receives a cash prize of US$ 250,000. In addition, each")#linebreak()#text(" Medalist may nominate one or more organizations to receive funding totalling US$ 250,000, for the support of research, education, or other outreach programs in the field of mathematics.")

#text("Professor Chern devoted his life to mathematics, both in active research and education, and in nurturing the field whenever the opportunity arose. He obtained fundamental results in all the major aspects of modern geometry and founded the area of global differential geometry. Chern exhibited keen aesthetic tastes in his selection of problems, and the breadth of his work deepened the connections of geometry with different areas of mathematics. He was also generous during his lifetime in his personal support of the field.")

#text("Nominations should be sent to the Prize Committee Chair: Caroline Series, email: ")#link("mailto:chair@chern18.mathunion.org")[#text("chair@chern18.mathunion.org")]#text(" by ")#text("31st December 2016")#text(". Further details and nomination guidelines for this and the other IMU prizes can be found at ")#link("http://www.mathunion.org/general/prizes/")[#text("http://www.mathunion.org/general/prizes/")]
