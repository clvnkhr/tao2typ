// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/
// Converted to Typst by tao2typ: "2026-10-14T16:34:59.068598+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Darwin’s finches and introgressive hybridisation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Darwin’s finches and introgressive hybridisation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 July 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")[#text("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Last week, ")#link("https://terrytao.wordpress.com/2007/07/13/a-visit-to-the-royal-society/")[#text("as mentioned previously")]#text(", I attended a very inspiring interdisciplinary meeting at the Royal Society. It would be impossible for me to describe all 47 talks in detail; but I thought that I would take the time to discuss one representative talk, presented by ")#link("http://en.wikipedia.org/wiki/Peter_and_Rosemary_Grant")[#text("Rosemary Grant")]#text(" ")#link("http://en.wikipedia.org/wiki/Fellow_of_the_Royal_Society")[#text("FRS")]#text(", on her research (together with several collaborators, including ")#link("http://www.eeb.princeton.edu/FACULTY/Grant_P/grantPeter.html")[#text("her husband")]#text("), on the ongoing evolution (and ")#link("http://en.wikipedia.org/wiki/Speciation")[#text("speciation")]#text(") of ")#link("http://en.wikipedia.org/wiki/Darwin%27s_Finches")[#text("Darwin’s finches")]#text(" in the ")#link("http://en.wikipedia.org/wiki/Gal%C3%A1pagos_Islands")[#text("Galápagos islands")]#text("; this was a particularly striking talk for me, as I had not been aware that such dramatic ")#link("http://en.wikipedia.org/wiki/Microevolution")[#text("microevolutionary")]#text(" changes could be seen in real-time (Grant and her co-authors have tracked multiple generations of these finches for 35 years!). They have several interesting results; the talk that I am reproducing here is largely based on ")#link("http://www.eeb.princeton.edu/FACULTY/Grant_P/Evolution_2004.pdf")[#text("this article in Evolution")]#text(".")

#metadata(none) <tao-7932b3bf46e3a73d1eda>#text("Darwin’s finches are of course famous for being studied by Charles Darwin during ")#link("http://en.wikipedia.org/wiki/Second_voyage_of_HMS_Beagle")[#text("his voyage on the Beagle")]#text("; their remarkable biodiversity, for instance in their beak shapes, being one of the major pieces of evidence leading him to formulate the theory of evolution and natural selection. (The beaks of these finches, incidentally, formed the topic of a ")#link("http://en.wikipedia.org/wiki/The_Beak_of_the_Finch")[#text("Pulitzer Prize-winning book")]#text(", based in large part on the Grants’ research.) They consist of 14 different species, which are distributed separately and together in different combinations of islands in the Galápagos archipelago, which has the fortune to be a relatively pristine environment (it is part of Ecuador’s national park system). Their importance to evolutionary biology is due in part to the fact that their ")#link("http://en.wikipedia.org/wiki/Evolutionary_radiation")[#text("evolutionary radiation")]#text(" is very recent by evolutionary standards; indeed, data from their ")#link("http://en.wikipedia.org/wiki/Mitochondrial_DNA")[#text("mitochondrial DNA")]#text(" and ")#link("http://en.wikipedia.org/wiki/Microsatellite")[#text("microsatellites")]#text(", combined with an ")#link("http://en.wikipedia.org/wiki/Allozyme")[#text("allozyme")]#text(" ")#link("http://en.wikipedia.org/wiki/Molecular_clock")[#text("molecular clock")]#text(", ")#link("http://www.pnas.org/cgi/content/full/96/9/5101")[#text("have")]#text(" ")#link("http://www.pubmedcentral.nih.gov/articlerender.fcgi?artid=1689686")[#text("shown")]#text(" ")#link("http://www.springerlink.com/content/r667636728557n25/")[#text("that")]#text(" these species all evolved from a common ancestor about 2 or 3 million years ago. (For comparison, ")#link("http://www.nature.com/nature/journal/v355/n6357/abs/355246a0.html")[#text("geological data shows")]#text(" that each of the islands of the archipelago emerged above sea level between 5 to 9 million years ago.)")

#text("Grant and her fellow researchers have tracked the finches on the island of ")#link("http://en.wikipedia.org/wiki/Daphne_Major")[#text("Daphne Major ")]#text("in the Galápagos for the past 35 years – ")#link("http://en.wikipedia.org/wiki/Bird_ringing")[#text("banding")]#text(" them, measuring them, and taking blood samples for DNA analysis. There are two major species of finches on this island: ")#emph[#text("Geospiza scandens")]#text(" (common cactus-finch), which is a larger finch with a more pointed beak that feeds primarily on cactus seeds, and ")#emph[#text("Geospiza fortis")]#text(" (medium ground-finch), which is a smaller finch with a stronger, blunter beak and a more varied diet, feeding on pollen and nectar as well as the smaller of the cactus seeds. Both finches have a fairly rapid life cycle, being fully grown after about two months, breeding every year, and living up to 16 years. They are genetically very similar, and in fact interbreed very occasionally (about 1% of the time), but are distinct enough to be considered different species. Here is a picture of the ancestry of these and other finches from the ")#link("http://www.britannica.com/ebc/art/print?id=74641&articleTypeId=1")[#text("Encyclopedia Britannica")]#text(":")

#image("../assets/667209a6d7463bad66fab21915baa1d4117e25e899db0e64b6cd3456d3ebb61c-e203a983372b525ce0024ac768b3a66b26ed2f8dd22a06f3e237a10a2d66cd58.jpg", width: 90%)

#align(center)[#image("../assets/667209a6d7463bad66fab21915baa1d4117e25e899db0e64b6cd3456d3ebb61c-e203a983372b525ce0024ac768b3a66b26ed2f8dd22a06f3e237a10a2d66cd58.jpg", width: 90%)]

#text("The climate on Daphne Major oscillates every decade or so between heavy rainfall and drought, thanks to ")#link("http://en.wikipedia.org/wiki/El_Ni%C3%B1o-Southern_Oscillation")[#text("El Niño")]#text(". As a consequence, the number of cactus seeds available for the finches varies dramatically from year to year. During El Niño years, there is such an abundance of food supply that the population of the finches explodes, for instance it doubled during the El Niño year of 1982. Conversely, during drought years, when there are only a few seeds, the population of the finches collapses, although ")#emph[#text("Geospiza fortis")]#text(", having a more varied diet, is not as vulnerable to this effect. This (rather low-resolution) picture from the textbook ")#link("http://www.blackwellpublishing.com/ridley/")[#text("Evolution")]#text(" shows the contrast in vegetation during a drought year (left) and a El Niño year (right):")

#align(center)[#image("../assets/951ba284b92b85a0b4505791f6c98bc1cdd8ed7f1625e2dfce908d4cf1bcd9e1-14665df4922fd1118a9d015593d6894729d5191bd1501889c634e676b17ee59b.jpg", width: 90%)]

#text("There are several types of cactus seeds on Daphne major, ranging from smaller seeds that can be eaten by all the finches (particularly those with smaller beaks), and the larger, harder seeds which are only edible to the ")#emph[#text("Geospiza scandens")]#text(" finches with larger and stronger beaks. The relative proportion of these seeds varies from year to year, and thus exerts a strong selective pressure on these finches, particularly in drought years and El Niño years; the beak size and strength is determined by only a handful of genes and so is quite susceptible to evolutionary forces. For instance, during the 1976-1977 drought, large hard seeds were the primary seeds remaining, and in the next year the surviving ")#emph[#text("Geospiza scandens ")]#text("finches and their progeny had significantly stronger and larger beaks; conversely, during the 1984-1985 drought, in which most of the remaining seeds were of the smaller variety, the population in the following year had significantly smaller beaks. (The beaks of ")#emph[#text("Geospiza fortis")]#text(" fluctuated also, but to a lesser extent.) Graphs for all these changes can be ")#link("http://www.sciencemag.org/content/vol296/issue5568/images/large/se1620406001.jpeg")[#text("found here")]#text(".")

#text("This was all very reasonable and predictable, but it led to an interesting puzzle – given the modest genetic pool of the ")#emph[#text("Geospiza scandens ")]#text("population, how was it that ")#emph[#text("both")]#text(" the small-beak genes and large-beak genes survived for millions of years, given that selective pressures tended to strongly favour one over the other every decade or so?")

#text("The answer, hypothesised and then confirmed by Grant and her collaborators, was ")#link("http://en.wikipedia.org/wiki/Introgression")[#text("introgressive hybridisation")]#text(" – the occasional sharing of genes between ")#emph[#text("Geospiza scandens")]#text(" and ")#emph[#text("Geospiza fortis")]#text(" due to interbreeding. This interbreeding is usually prevented by ")#link("http://en.wikipedia.org/wiki/Bird_song")[#text("bird song")]#text(" – a finch learns the bird song of its species from its parents (via ")#link("http://en.wikipedia.org/wiki/Imprinting_%28psychology%29")[#text("imprinting")]#text("), and only mates with other finches with the same song, this being the primary way for the finches to recognise members of the same species. However, occasionally a young finch is imprinted with the wrong song due to the parents having died, or the nest taken over by a different finch species, and this can cause some interbreeding. This event was rare enough that it was not observed directly, but was first hypothesised due to the detection of a slight drift in beak shape and size of the ")#emph[#text("Geospiza scandens ")]#text("finches towards that of the ")#emph[#text("Geospiza fortis")]#text(" finches over the 35 year observation period, and then confirmed using DNA measurements of ")#link("http://en.wikipedia.org/wiki/Genetic_distance")[#text("genetic distance")]#text(", as well as the migration of certain ")#link("http://en.wikipedia.org/wiki/Microsatellite")[#text("microsatellite markers")]#text(" from one species to the other over time. The hybridisation (together with occasional mutation) allowed enough genetic variation to flow from ")#emph[#text("Geospiza fortis")]#text(" to ")#emph[#text("Geospiza scandens")]#text(" to prevent the genes for either large beaks or small beaks from becoming completely extinguished. On the other hand, the hybridisation was rare enough that the two species did not converge back to a single species – the convergence effect of hybridisation was not as strong as the divergence caused by the selective pressures, which affected the two species in different ways.")

#text("This research sheds some interesting light on the early stages of ")#link("http://en.wikipedia.org/wiki/Speciation")[#text("speciation")]#text(" – the divergence of one species into two. At these stages, the species are mostly separate from each other, but a limited amount of interbreeding, and thus gene transfer, still takes place; not necessarily enough to make the two species converge back into one (especially if they are specialised towards different ecological niches), but enough to have a non-trivial impact on the genetic diversity of both species. Whether the speciation continues to the point hybridisation incurs too much of a fitness cost and the species diverge to become irreversibly distinct, or whether they converge back into a single species, seems to depend very strongly on environmental factors; this process is apparently rather fluid.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9422163fcf6925a87d2584372ada82e01d628ee7c1a21042c1246320ddbd8465-2ed5c14ec66d72520ddd407ad92527f833215b370aafb06b62f66538de883354.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of p-ter")]], [#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-4711")[#strong[#text("p-ter")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")])]

#text("fyi, introgression from archaic hominids (likely Neandertals), has possibly played a role in the human adaptive radiation (neandertals adapted to the european climate long before modern humans arrived). Some evidence points towards a gene involved in brain development having introgressed into the human lineage:")#linebreak()#text(" ")#link("http://www.pnas.org/cgi/content/abstract/0606966103v1")[#text("http://www.pnas.org/cgi/content/abstract/0606966103v1")]

#text("and the evolutionary dynamics of introgression are pretty well-characterized:")#linebreak()#text(" ")#link("http://johnhawks.net/weblog/reviews/evolution/introgression/hawks_cochran_introgression_2006.html")[#text("http://johnhawks.net/weblog/reviews/evolution/introgression/hawks_cochran_introgression_2006.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-4718")[#strong[#text("Thursday late night links « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2007")]

#text("[…] Terence Tao attends a talk on introgressive hybridisation, and tells us what it is all about; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-4795")[#strong[#text("Top Posts « WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2007")]

#text("[…] Darwin’s finches and introgressive hybridisation Last week, as mentioned previously, I attended a very inspiring interdisciplinary meeting at the Royal Society. It […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd4f0496ffde7f87fc1f0ff5785c58a4f056979b9955af4c4033485b46f50d84-d974e7e0a391c069c51435392dec31c016dc83cc3350edbb8070438bf16c0db2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of muzhiqingfeng")]], [#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-4909")[#strong[#text("muzhiqingfeng")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2007")])]

#text("I like it ,I’ll work hard to learn English and mathmatics well and to understand all Terrence Tao’ blog. Now I am at the age of 18 with a poor English level. Happy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-41116")[#strong[#text("Fringuelli e Tortelli")]]#text(size: 9pt, fill: rgb("596477"), " · 23 August 2009")]

#text("[…] becchi differenti. Non sta a me spiegarvi tutta la storia, se volete leggetevi qualcosa qua, qua o qua, o cercate su […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-168634")[#strong[#text("matapon")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2012")]

#text("[…] กาลาปากอสกับวิวัฒนาการ หลังจากที่Darwinเดินทางกลับไปยังประเทศอังกฤษ ในปี ค.ศ. 1836 Darwinได้ส่งตัวอย่างสิ่งมีชีวิตชนิดต่างๆ ไปให้นักวิทยาศาสตร์หลายๆคนช่วยศึกษา ซึ่งจากการศึกษาตัวอย่างนกจำนวน 26 ชนิด พบว่า 25 ชนิดเป็นนกชนิดใหม่ และในจำนวนนั้นมี 3 ตัวอย่างที่พบว่ามีลักษณะแตกต่างกันแต่เมื่อทำการศึกษาแล้วกลับพบว่าเป็นนกชนิดเดียวกัน จากข้อมูลต่างๆที่ได้จากการเดินทางไปสำรวจกับเรือ Beagle ทำให้ Darwinได้นำเสนอทฤษฏีวิวัฒนาการ ซึ่งเชื่อว่าสิ่งมีชีวิตชนิดต่างๆ มีการเปลี่ยนแปลงไปตามกาลเวลาเพื่อให้เหมาะสมกับสภาพแวดล้อมที่สิ่งมีชีวิตนั้นๆ อาศัยอยู่ ตัวอย่างสัตว์ที่แสดงถึงการมีวิวัฒนาการ คือ นกฟินช์ที่อาศัยอยู่ที่หมู่เกาะกาลาปากอส ซึ่งแต่เดิมมีนกฟินซ์อาศัยอยู่บนหมู่เกาะเพียงชนิดเดียวโดยกินเมล็ดพืชตามพื้นดินเป็นอาหาร ต่อมาได้มีวิวัฒนาการกลายเป็นนกฟินซ์ชนิดต่างๆ ประมาณ 14 ชนิด ซึ่งแต่ละชนิดจะมีลักษณะของจงอยปากที่แตกต่างกันออกไปตามอาหารที่กิน เช่น large ground finch เป็นนกฟินซ์ที่กินเมล็ดพืชเป็นอาหารจะมีจงอยปากที่กว้างและใหญ่ ส่วน cactus finch เป็นนกฟินช์ที่กินนำหวานจากต้นกระบองเพชรจะมีจงอยปากที่ยาวและโค้งลง เป็นต้น ที่มา : ")#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")[#text("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-332678")[#strong[#text("Jinglebelltour.com | กาลาปากอส กับสัตว์ในวรรณคดีของไทย")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2014")]

#text("[…] ที่มาภาพ:")#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")[#text("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-521294")[#strong[#text("การคัดเลือกโดยธรรมชาติของอูฐ – สังคมแห่งการเรียนรู้โพธาวัฒนาเสนี")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")]

#text("[…] ลักษณะจงอยในแบบต่างๆของนกฟินช์ที่มา : ")#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")[#text("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/#comment-523249")[#strong[#text("หมู่เกาะกาลาปากอส – สาขาวิชาวิทยาศาสตร์มัธยมศึกษาตอนปลาย – Biology")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2019")]

#text("[…] ที่มา : https://terrytao.wordpress.com/2007/07/19/darwins-finches-and-introgressive-hybridisation/ […]")
]
