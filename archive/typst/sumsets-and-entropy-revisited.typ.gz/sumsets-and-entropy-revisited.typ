// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/
// Converted to Typst by tao2typ: "2026-10-14T16:39:08.182815+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Sumsets and entropy revisited", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Sumsets and entropy revisited")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 June 2023")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/")[#text("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://people.maths.ox.ac.uk/greenbj/")[#text("Ben Green")]#text(", ")#link("https://mathweb.ucsd.edu/~fmanners/")[#text("Freddie Manners")]#text(" and I have just uploaded to the arXiv our preprint “")#link("https://arxiv.org/abs/2306.13403")[#text("Sumsets and entropy revisited")]#text("“. This paper uses entropy methods to attack the ")#link("https://terrytao.wordpress.com/2007/03/11/ben-green-the-polynomial-freiman-ruzsa-conjecture/")[#text("Polynomial Freiman-Ruzsa (PFR) conjecture")]#text(", which we study in the following two forms:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Weak PFR over ")#mi("{Z}")#text(")")]#text(" ")#metadata(none) <tao-8718818e4d635289b13b>#text(" Let ")#mi("{A \\subset {\\bf Z}^D}")#text(" be a finite non-empty set whose doubling constant ")#tao-math("{\\sigma[A] := \\left|A+A\\right|/\\left|A\\right|}", block: false)#text(" is at most ")#mi("{K}")#text(". Then there is a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" of density ")#mi("{\\gg K^{-O(1)}}")#text(" that has affine dimension ")#mi("{O(\\log K)}")#text(" (i.e., it is contained in an affine space of dimension ")#mi("{O(\\log K)}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 2 (PFR over ")#mi("{{\\bf F}_2}")#text(")")]#text(" ")#metadata(none) <tao-49634c226e0f323317d7>#text(" Let ")#mi("{A \\subset {\\bf F}_2^D}")#text(" be a non-empty set whose doubling constant ")#mi("{\\sigma[A]}")#text(" is at most ")#mi("{K}")#text(". Then ")#mi("{A}")#text(" can be covered by ")#mi("{O(K^{O(1)})}")#text(" cosets of a subspace of cardinality at most ")#tao-math("{\\left|A\\right|}", block: false)#text(".")
]

#text("Our main results are then as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3")]#text(" If ")#mi("{A \\subset {\\bf Z}^D}")#text(" with ")#mi("{\\sigma[A] \\leq K}")#text(", then")

#list(
[#text("(i) There is a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" of density ")#mi("{\\gg K^{-O(1)}}")#text(" of “skew-dimension” (or “query complexity”) ")#mi("{O(\\log K)}")#text(".")],
[#text("(ii) There is a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" of density ")#mi("{\\gg \\exp( -O(\\log^{5/3+o(1)} K) )}")#text(" of affine dimension ")#mi("{O(\\log K)}")#text(" (where ")#mi("{o(1)}")#text(" goes to zero as ")#mi("{K \\rightarrow \\infty}")#text(").")],
[#text("(iii) If Conjecture ")#link(<tao-49634c226e0f323317d7>)[#text("2")]#text(" holds, then there is a subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(" of density ")#mi("{\\gg K^{-O(1)}}")#text(" of affine dimension ")#mi("{O(\\log K)}")#text(". In other words, Conjecture ")#link(<tao-49634c226e0f323317d7>)[#text("2")]#text(" implies Conjecture ")#link(<tao-8718818e4d635289b13b>)[#text("1")]#text(".")]
)
]

#text("The skew-dimension of a set is a quantity smaller than the affine dimension which is defined recursively; the precise definition is given in the paper, but suffice to say that singleton sets have dimension ")#mi("{0}")#text(", and a set ")#mi("{A \\subset {\\bf Z}^{D_1} \\times {\\bf Z}^{D_2}}")#text(" whose projection to ")#mi("{{\\bf Z}^{D_1}}")#text(" has skew-dimension at most ")#mi("{d_1}")#text(", and whose fibers in ")#mi("{\\{x\\} \\times {\\bf Z}^{D_2}}")#text(" have skew-dimension at most ")#mi("{d_2}")#text(" for any ")#mi("{x}")#text(", will have skew-dimension at most ")#mi("{d_1+d_2}")#text(". (In fact, the skew-dimension is basically the largest quantity which obeys all of these properties.)")

#text("Part (i) of this theorem was implicitly proven ")#link("https://mathscinet.ams.org/mathscinet/article?mr=4319771")[#text("by Pálvölgi and Zhelezov")]#text(" by a different method. Part (ii) with ")#mi("{5/3+o(1)}")#text(" replaced by ")#mi("{2}")#text(" was established ")#link("https://mathscinet.ams.org/mathscinet/article?mr=3685112")[#text("by Manners")]#text(". To our knowledge, part (iii) is completely new.")

#text("Our proof strategy is to establish these combinatorial additive combinatorics results by using entropic additive combinatorics, in which we replace sets ")#mi("{A}")#text(" with random variables ")#mi("{X}")#text(", and cardinality with (the exponential of) ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(". This is in order to take advantage of some superior features of entropic additive combinatorics, most notably good behavior with respect to homomorphisms.")

#text("For instance, the analogue of the combinatorial doubling constant ")#tao-math("{\\sigma[A] := \\left|A+A\\right|/\\left|A\\right|}", block: false)#text(" of a finite non-empty subset ")#mi("{A}")#text(" of an abelian group ")#mi("{G}")#text(", is the entropy doubling constant")

#align(center)[#tao-fit-display[#mitex("\\sigma_{\\mathrm{ent}}[X] := {\\exp( \\bf H}(X_1+X_2) - {\\bf H}(X) )")]]

#text("of a finitely-valued random variable ")#mi("{X}")#text(" in ")#mi("{G}")#text(", where ")#mi("{X_1,X_2}")#text(" are independent copies of ")#mi("{X}")#text(" and ")#mi("{{\\bf H}}")#text(" denotes ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(". There is also an analogue of the Ruzsa distance")

#align(center)[#tao-fit-display[#tao-math("d(A,B) := \\log \\frac{\\left|A-B\\right|}{\\left|A\\right|^{1/2} \\left|B\\right|^{1/2}}", block: true)]]

#text("between two finite non-empty subsets ")#mi("{A,B}")#text(" of ")#mi("{G}")#text(", namely the entropic Ruzsa distance")

#align(center)[#tao-fit-display[#mitex("d_{\\mathrm{ent}}(X,Y) := {\\bf H}(X^{\\prime}+Y^{\\prime}) - \\frac{1}{2} {\\bf H}(X) - \\frac{1}{2} {\\bf H}(Y)")]]

#text("where ")#mi("{X^{\\prime},Y^{\\prime}}")#text(" are independent copies of ")#mi("{X,Y}")#text(" respectively. (Actually, one thing we show in our paper is that the independence hypothesis can be dropped, and this only affects the entropic Ruzsa distance by a factor of three at worst.) Many of the results about sumsets and Ruzsa distance have entropic analogues, but the entropic versions are slightly better behaved; for instance, we have a contraction property")

#align(center)[#tao-fit-display[#mitex("d_{\\mathrm{ent}}(\\phi(X),\\phi(Y)) \\leq d_{\\mathrm{ent}}(X,Y)")]]

#text("whenever ")#mi("{\\phi: G \\rightarrow H}")#text(" is a homomorphism. In fact we have a refinement of this inequality in which the gap between these two quantities can be used to control the entropic distance between “fibers” of ")#mi("{X,Y}")#text(" (in which one conditions ")#mi("{\\phi(X)}")#text(" and ")#mi("{\\phi(Y)}")#text(" to be fixed). On the other hand, there are direct connections between the combinatorial and entropic sumset quantities. For instance, if ")#mi("{U_A}")#text(" is a random variable drawn uniformly from ")#mi("{A}")#text(", then")

#align(center)[#tao-fit-display[#mitex("\\sigma_{\\mathrm{ent}}[U_A] \\leq \\sigma[A].")]]

#text("Thus if ")#mi("{A}")#text(" has small doubling, then ")#mi("{U_A}")#text(" has small entropic doubling. In the converse direction, if ")#mi("{X}")#text(" has small entropic doubling, then ")#mi("{X}")#text(" is close (in entropic Ruzsa distance) to a uniform random variable ")#mi("{U_S}")#text(" drawn from a set ")#mi("{S}")#text(" of small doubling; a version of this statement was proven in an ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2647496")[#text("old paper of myself")]#text(", but we establish here a quantitatively efficient version, established by rewriting the entropic Ruzsa distance in terms of certain ")#link("https://en.wikipedia.org/wiki/Kullback%E2%80%93Leibler_divergence")[#text("Kullback-Liebler divergences")]#text(".")

#text("Our first main result is a “99% inverse theorem” for entropic Ruzsa distance: if ")#mi("{d_{\\mathrm{ent}}(X,Y)}")#text(" is sufficiently small, then there exists a finite subgroup ")#mi("{H}")#text(" of ")#mi("{G}")#text(" such that ")#metadata(none) <tao-769a4e6d0003189c7e96>#mi("\\displaystyle  d_{\\mathrm{ent}}(X,U_H), d_{\\mathrm{ent}}(Y,U_H) \\leq 12 d_{\\mathrm{ent}}(X,Y). \\ \\ \\ \\ \\ (1)")#text(" ")#text(" This result uses the results just mentioned to relate ")#mi("{X,Y}")#text(" to a set ")#mi("{S}")#text(" of small doubling, which can then be related to a subgroup ")#mi("{H}")#text(" by standard inverse theorems; this gives a weak version of ")#link(<tao-769a4e6d0003189c7e96>)[#text("(1)")]#text(" (roughly speaking losing a square root in the bound), and some additional analysis is needed to bootstrap this initial estimate back to ")#link(<tao-769a4e6d0003189c7e96>)[#text("(1)")]#text(".")

#text("We now sketch how these tools are used to prove our main theorem. For (i), we reduce matters to establishing the following bilinear entropic analogue: given two non-empty finite subsets ")#mi("{A,B}")#text(" of ")#mi("{{\\bf Z}^D}")#text(", one can find subsets ")#mi("{A^{\\prime} \\subset A}")#text(", ")#mi("{B^{\\prime} \\subset B}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left|A^{\\prime}\\right| \\left|B^{\\prime}\\right| \\geq e^{-C d_{\\mathrm{ent}}(U_A, U_B)} \\left|A\\right| \\left|B\\right|", block: true)]]

#text("such that ")#mi("{A^{\\prime}, B^{\\prime}}")#text(" have skew-dimension at most ")#mi("{C d_{\\mathrm{ent}}(U_A, U_B)}")#text(", for some absolute constant ")#mi("{C}")#text(". This can be shown by an induction on ")#tao-math("{\\left|A\\right|\\left|B\\right|}", block: false)#text(" (say). One applies a non-trivial coordinate projection ")#mi("{\\pi: {\\bf Z}^D \\rightarrow {\\bf Z}}")#text(" to ")#mi("{A,B}")#text(". If ")#mi("{\\pi(U_A)}")#text(" and ")#mi("{\\pi(U_B)}")#text(" are very close in entropic Ruzsa distance, then the 99% inverse theorem shows that these random variables must each concentrate at a point (because ")#mi("{{\\bf Z}}")#text(" has no non-trivial finite subgroups), and can pass to a fiber of these points and use the induction hypothesis. If instead ")#mi("{\\pi(U_A)}")#text(" and ")#mi("{\\pi(U_B)}")#text(" are far apart, then by the behavior of entropy under projections one can show that the fibers of ")#mi("{A}")#text(" and ")#mi("{B}")#text(" under ")#mi("{\\pi}")#text(" are closer on average in entropic Ruzsa distance of ")#mi("{A}")#text(" and ")#mi("{B}")#text(" themselves, and one can again proceed using the induction hypothesis.")

#text("For parts (ii) and (iii), we first use an entropic version of an observation ")#link("https://mathscinet.ams.org/mathscinet/article?mr=3685112")[#text("of Manners")]#text(" that sets of small doubling in ")#mi("{{\\bf Z}^D}")#text(" must be irregularly distributed modulo ")#mi("{2}")#text(". A clean formulation of this in entropic language is the inequality")

#align(center)[#tao-fit-display[#mitex("d_{\\mathrm{ent}}(X, 2Y) \\leq 5 d_{\\mathrm{ent}}(X,Y)")]]

#text("whenever ")#mi("{X,Y}")#text(" take values in a torsion-free abelian group such as ")#mi("{{\\bf Z}^D}")#text("; this turns out to follow from two applications of the entropy submodularity inequality. One corollary of this (and the behavior of entropy under projections) is that")

#align(center)[#tao-fit-display[#mitex("{\\bf H}( X \\text{ mod } 2 ), {\\bf H}( Y \\text{ mod } 2 ) \\leq 10 d_{\\mathrm{ent}}(X,Y).")]]

#text("This is the key link between the ")#mi("{{\\bf Z}^D}")#text(" and ")#mi("{{\\bf F}_2^D}")#text(" worlds that is used to prove (ii), (iii): while (iii) relies on the still unproven PFR conjecture over ")#mi("{{\\bf F}_2}")#text(", (ii) uses the unconditional progress on PFR by Konyagin, as detailed in ")#link("https://mathscinet.ams.org/mathscinet/article?mr=2994996")[#text("this survey of Sanders")]#text(". The argument has a similar inductive structure to that used to establish (i) (and if one is willing to replace ")#mi("{5/3+o(1)}")#text(" by ")#mi("{2}")#text(" then the argument is in fact relatively straightforward and does not need any deep partial results on the PFR).")

#text("As one byproduct of our analysis we also obtain an appealing entropic reformulation of Conjecture ")#link(<tao-49634c226e0f323317d7>)[#text("2")]#text(", namely that if ")#mi("{X}")#text(" is an ")#mi("{{\\bf F}_2^D}")#text("-valued random variable then there exists a subspace ")#mi("{H}")#text(" of ")#mi("{{\\bf F}_2^D}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("d_{\\mathrm{ent}}(X, U_H) \\ll \\sigma_{\\mathrm{ent}}[X].")]]

#text("Right now the best result in this direction is")

#align(center)[#tao-fit-display[#mitex("d_{\\mathrm{ent}}(X, U_H) \\ll_\\varepsilon \\sigma_{\\mathrm{ent}}[X] + \\sigma_{\\mathrm{ent}}^{3+\\varepsilon}[X]")]]

#text("for any ")#mi("{\\varepsilon > 0}")#text(", by using Konyagin’s partial result towards the PFR.")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-679117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2023")])]

#text("Is there a conjectured value for the best exponent in theorem 3(ii) (instead of 5/3)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-679148")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2023")])]

#text("The conjectured exponent is 1 (this is Conjecture 1).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4c9b301cd1a9e8f3f50a2da225c95aeb109bbfe2e1525e967925fdffc4717b7-fb316f7fc5c88f5da7b88287e0c50ce2d26b006f9516b10b5ffca5df8dfa4f69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-679143")[#strong[#text("Joe")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2023")])]

#text("In Theorem 3 (iii),’There’ should be typed in lowercase.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-679241")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2023")])]

#text("I find it surprising and remarkable that a result over Z can be derived from a similar result over Z/2Z. Terry, can you elaborate more on how it works?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-679255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2023")])]

#text("For simplicity I will describe the argument in combinatorial language rather than entropic language, although the combinatorial argument doesn’t quite work as stated and one has to move to the entropy formulation to make everything go through. (Also to make the inductive argument close properly one has to work with a “bilinear” formulation in which one has two sets ")#mi("A,B")#text(" to induct on rather than a single set ")#mi("A")#text(", but I will ignore this complication.)")

#text("The first key observation is a remarkable observation of Manners that says, roughly speaking, that if a subset ")#mi("A \\subset {\\bf Z}^d")#text(" has small doubling, then ")#mi("A")#text(" is also close (in Ruzsa distance) to the dilate ")#mi("2 \\cdot A = \\{ 2a: a \\in A \\}")#text(" (which already strongly hints at the low dimensionality of a large portion of ")#mi("A")#text(", but does not yet establish it). This comes from the inequality ")#tao-math("\\left|A\\right| \\left|A-2\\cdot A\\right| \\leq \\left|A-A-A\\right| \\left|A-A\\right|", block: false)#text(" which is proven by a double counting argument similar to the one used to prove the Ruzsa triangle inequality ")#tao-math("\\left|B\\right| \\left|A-C\\right| \\leq \\left|A-B\\right| \\left|B-C\\right|", block: false)#text(" (the point being that because of the identity ")#mi("x-2y_1 = (x-y_1-y_2) - (y_1-y_2)")#text(", every element of ")#mi("A - 2 \\cdot A")#text(" generates ")#tao-math("\\left|A\\right|", block: false)#text(" distinct pairs in ")#mi("(A-A-A) \\times (A-A)")#text(").")

#text("If we project the integer lattice ")#mi("{\\bf Z}^D")#text(" down to the finite field vector space ")#mi("({\\bf Z}/2{\\bf Z})^D")#text(", then the dilate ")#mi("2 \\cdot A")#text(" gets sent to 0. As a consequence, we see that the projection of ")#mi("A")#text(" to ")#mi("({\\bf Z}/2{\\bf Z})^D")#text(" has to be quite small; also, since ")#mi("A")#text(" has small doubling, the projection has small doubling also. From this and the known progress on PFR, one can relate the projection of ")#mi("A")#text(" efficiently to a low dimensional subspace of ")#mi("({\\bf Z}/2{\\bf Z})^D")#text(", whose inverse images are sublattices of ")#mi("{\\bf Z}^D")#text(". If ")#mi("D")#text(" is much larger than the dimension of this subspace, one can (in the entropic setting) use this to locate a coset of this sublattice inside of which ")#mi("A")#text(" is still quite large, and has better doubling properties than the original set ")#mi("A")#text(". An induction on the dimension ")#mi("D")#text(" then lets one close the argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c166534073097167e4c59f89ecea19beebabb41cd1334904afe092a9c40d87f6-38cb325bcf5a422aa37019e772380661db0cb8be99098b0137259a10d63c1733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CSperson")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-680094")[#strong[#text("CSperson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 July 2023")])]

#text("Why do you use the phrase “query complexity”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-680168")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2023")])]

#text("The terminology was first introduced to this context ")#link("https://arxiv.org/abs/2003.04648")[#text("by Zhelezov and Pálvölgyi")]#text(" (see page 3 for the explanation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c166534073097167e4c59f89ecea19beebabb41cd1334904afe092a9c40d87f6-38cb325bcf5a422aa37019e772380661db0cb8be99098b0137259a10d63c1733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CSperson")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-680236")[#strong[#text("CSperson")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2023")])]

#text("May be should be called ‘generalized decision tree complexity’ or something along those lines. Someone might know better on the analogy here.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-681972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")])]

#text("It would be interesting to have an analog for Theorem 3 (i) for $F_2^n$. Possibly it may have some connections to the log rank conjecture in computer science?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-681975")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2023")])]

#text("We were actually able to get some sort of analogue in finite fields using these entropic methods, but it was really weird and we didn’t find a good use for it (or a clean statement). Roughly speaking, it is similar to 3(i) except that ")#mi("A^{\\prime}")#text(", instead of having query complexity ")#mi("O(\\log K)")#text(", is instead generated from a point via ")#mi("O(\\log K)")#text(" “extension” operations, where an extension from one set ")#mi("A \\in {\\bf F}_2^n")#text(" to another ")#mi("B \\in {\\bf F}_2^{n+m}")#text(" is one of the following three things:")

#text("1. Short extension ")#mi("m=1")#text(", and ")#mi("B")#text(" is a subset of ")#mi("A \\times {\\bf F}_2")#text(" of relative density ")#mi("\\sim 1")#text(".")

#text("2. Dense extension. ")#mi("B")#text(" is a subset of ")#mi("A \\times {\\bf F}_2^m")#text(" of relative density ")#mi("0.99")#text(" (say).")

#text("3. Freiman extension. ")#mi("B")#text(" is a graph ")#mi("\\{ (a,\\phi(a)): a \\in A \\}")#text(" where ")#mi("\\phi: A \\to {\\bf F}_2^m")#text(" is a “99% Freiman homomorphism”.")

#text("Of course, we believe the “correct” statement in ")#mi("{\\bf F}_2^n")#text(" to be the polynomial Freiman-Ruzsa conjecture (Conjecture 2). We have some thoughts on how to improve the current state of the art towards this conjecture, but we don’t see a way to resolve it completely at this point.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c3710593c93f9aa4ffe104075f0c874e61d665b7cfc69d8e4a50f7711084a401-549d31e224a297daa4d41ecfdf7f6ba7176804ba5ce73a18c0c471db9354fe65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kaiyi Huang")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-682085")[#strong[#text("Kaiyi Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2023")])]

#text("Hello Terence,")

#text("Thanks for your blog post and paper. I am a graduate student recently reading this paper in order to present in a fall school. I find it very accessible and inspiring. However, there are a few questions listed below.")

#text("1. In proving the small Ruzsa distance results, the construction of ")#mi("S")#text(" on which the uniform distribution is close to ")#mi("X,Y")#text(" induces a Bernoulli random variable ")#mi("A")#text(". Is it a common trick to introduce this ")#mi("A")#text("? Can we improve the results in Proposition 1.2 by reducing/removing the ")#mi("h(1-\\frac{2}{C})")#text(" term?")

#text("2. The bilinear forms you use in Theorems 7.3 and 9.3 are very different from that of 1.6. How did you come up with the inequality and specifically the functions ")#mi("f")#text("?")

#text("3. Do you have any conjecture on how to further improve Theorem 1.11? Do you think this is the best the entropic method can achieve with a function similar to ")#mi("f")#text(" Theorem 9.3?")

#text("4. What are some future directions? Do we have to come up with some statement different from Theorem 1.11 to attack the conjectures?")

#text("4. In the proof of 1.4 in Section 4, I think all the ")#mi("X_1+X_2, Y_1+Y_2")#text(" should be replaced by ")#mi("X_1-X_2, Y_1-Y_2")#text(", respectively. Of course, this typo does not affect the results.")

#text("Thanks for reading the questions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-682139")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2023")])]

#text("We did not try too strenuously to optimize the arguments, and it is very plausible that by applying entropy inequalities in a slightly different way one could get superior results. Introducing a boolean variable such as ")#mi("A")#text(" to restrict to a “good” event (or to the complementary “exceptional” event) in order to access facts that are available conditioning to that event, is a common trick in this subject.")

#text("In these sorts of iterative arguments, the bounding functions ")#mi("f")#text(" is usually not known in advance – one first works out what the inductive step gives, which in this case is some assertion of the form “if ")#mi("A, B")#text(" have a certain entropy distance ")#mi("d_{ent}(U_A, U_B)")#text(", then I can find some better pair ")#mi("A^{\\prime},B^{\\prime}")#text(" obeying one of several possible improved bounds”, and then one has to hunt for a clean choice of function ")#mi("f")#text(" for which the inductive step will close properly. This often takes some trial and error, especially if the inductive step does not produce a single bound, but rather a disjunction of several possible bounds. Usually one has to explore a few iterations of the inductive step to get a feel of how the bounds might grow in order to propose a guess for ")#mi("f")#text(", try to close the induction for that ")#mi("f")#text(", and tweak the choice if it didn’t quite work.")

#text("We have a forthcoming paper (with Timothy Gowers) with some significant improvements to the results. Will hopefully be able to report more on this soon. (We will also correct the typos in Section 4 in the next revision of the ms.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On a conjecture of Marton | What's new")]], [#link("https://terrytao.wordpress.com/2023/06/27/sumsets-and-entropy-revisited/#comment-682242")[#strong[#text("On a conjecture of Marton | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2023")])]

#text("[…] constant at most is unclear (and perhaps even false). However, it turns out (as discussed in this recent paper of myself with Green and Manners) that things are much better. Here, the analogue of a subset in is a random variable taking […]")
]
