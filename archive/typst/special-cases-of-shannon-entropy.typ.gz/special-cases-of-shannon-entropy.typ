// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/
// Converted to Typst by tao2typ: "2026-10-14T10:40:00.466566+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Special cases of Shannon entropy", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Special cases of Shannon entropy")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 March 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")[#text("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Given a random variable ")#mi("{X}")#text(" that takes on only finitely many values, we can define its ")#link("https://en.wikipedia.org/wiki/Entropy_(information_theory)")[#text("Shannon entropy")]#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("H(X) := \\sum_x \\mathbf{P}(X=x) \\log \\frac{1}{\\mathbf{P}(X=x)}")]]

#text("with the convention that ")#mi("{0 \\log \\frac{1}{0} = 0}")#text(". (In some texts, one uses the logarithm to base ")#mi("{2}")#text(" rather than the natural logarithm, but the choice of base will not be relevant for this discussion.) This is clearly a nonnegative quantity. Given two random variables ")#mi("{X,Y}")#text(" taking on finitely many values, the joint variable ")#mi("{(X,Y)}")#text(" is also a random variable taking on finitely many values, and also has an entropy ")#mi("{H(X,Y)}")#text(". It obeys the ")#emph[#text("Shannon inequalities")]

#align(center)[#tao-fit-display[#mitex("H(X), H(Y) \\leq H(X,Y) \\leq H(X) + H(Y)")]]

#text("so we can define some further nonnegative quantities, the ")#link("https://en.wikipedia.org/wiki/Mutual_information")[#text("mutual information")]

#align(center)[#tao-fit-display[#mitex("I(X:Y) := H(X) + H(Y) - H(X,Y)")]]

#text("and the ")#link("https://en.wikipedia.org/wiki/Conditional_entropy")[#text("conditional entropies")]

#align(center)[#tao-fit-display[#mitex("H(X|Y) := H(X,Y) - H(Y); \\quad H(Y|X) := H(X,Y) - H(X).")]]

#text("More generally, given three random variables ")#mi("{X,Y,Z}")#text(", one can define the ")#link("https://en.wikipedia.org/wiki/Conditional_mutual_information")[#text("conditional mutual information")]

#align(center)[#tao-fit-display[#mitex("I(X:Y|Z) := H(X|Z) + H(Y|Z) - H(X,Y|Z)")]]

#text("and the final of the Shannon entropy inequalities asserts that this quantity is also non-negative.")

#text("The mutual information ")#mi("{I(X:Y)}")#text(" is a measure of the extent to which ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" fail to be independent; indeed, it is not difficult to show that ")#mi("{I(X:Y)}")#text(" vanishes if and only if ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are independent. Similarly, ")#mi("{I(X:Y|Z)}")#text(" vanishes if and only if ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are ")#emph[#text("conditionally")]#text(" independent relative to ")#mi("{Z}")#text(". At the other extreme, ")#mi("{H(X|Y)}")#text(" is a measure of the extent to which ")#mi("{X}")#text(" fails to depend on ")#mi("{Y}")#text("; indeed, it is not difficult to show that ")#mi("{H(X|Y)=0}")#text(" if and only if ")#mi("{X}")#text(" is determined by ")#mi("{Y}")#text(" in the sense that there is a deterministic function ")#mi("{f}")#text(" such that ")#mi("{X = f(Y)}")#text(". In a related vein, if ")#mi("{X}")#text(" and ")#mi("{X^{\\prime}}")#text(" are equivalent in the sense that there are deterministic functional relationships ")#mi("{X = f(X^{\\prime})}")#text(", ")#mi("{X^{\\prime} = g(X)}")#text(" between the two variables, then ")#mi("{X}")#text(" is interchangeable with ")#mi("{X^{\\prime}}")#text(" for the purposes of computing the above quantities, thus for instance ")#mi("{H(X) = H(X^{\\prime})}")#text(", ")#mi("{H(X,Y) = H(X^{\\prime},Y)}")#text(", ")#mi("{I(X:Y) = I(X^{\\prime}:Y)}")#text(", ")#mi("{I(X:Y|Z) = I(X^{\\prime}:Y|Z)}")#text(", etc..")

#text("One can get some initial intuition for these information-theoretic quantities by specialising to a simple situation in which all the random variables ")#mi("{X}")#text(" being considered come from restricting a single random (and uniformly distributed) boolean function ")#mi("{F: \\Omega \\rightarrow \\{0,1\\}}")#text(" on a given finite domain ")#mi("{\\Omega}")#text(" to some subset ")#mi("{A}")#text(" of ")#mi("{\\Omega}")#text(":")

#align(center)[#tao-fit-display[#mitex("X = F \\downharpoonright_A.")]]

#text("In this case, ")#mi("{X}")#text(" has the law of a random uniformly distributed boolean function from ")#mi("{A}")#text(" to ")#mi("{\\{0,1\\}}")#text(", and the entropy here can be easily computed to be ")#tao-math("{\\left|A\\right| \\log 2}", block: false)#text(", where ")#tao-math("{\\left|A\\right|}", block: false)#text(" denotes the cardinality of ")#mi("{A}")#text(". If ")#mi("{X}")#text(" is the restriction of ")#mi("{F}")#text(" to ")#mi("{A}")#text(", and ")#mi("{Y}")#text(" is the restriction of ")#mi("{F}")#text(" to ")#mi("{B}")#text(", then the joint variable ")#mi("{(X,Y)}")#text(" is equivalent to the restriction of ")#mi("{F}")#text(" to ")#mi("{A \\cup B}")#text(". If one discards the normalisation factor ")#mi("{\\log 2}")#text(", one then obtains the following dictionary between entropy and the combinatorics of finite sets:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Random variables ")#mi("{X,Y,Z}")],
table.cell(colspan: 1, rowspan: 1)[#text("Finite sets ")#mi("{A,B,C}")],
table.cell(colspan: 1, rowspan: 1)[#text("Entropy ")#mi("{H(X)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Cardinality ")#tao-math("{\\left|A\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#text("Joint variable ")#mi("{(X,Y)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Union ")#mi("{A \\cup B}")],
table.cell(colspan: 1, rowspan: 1)[#text("Mutual information ")#mi("{I(X:Y)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Intersection cardinality ")#tao-math("{\\left|A \\cap B\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#text("Conditional entropy ")#mi("{H(X|Y)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Set difference cardinality ")#tao-math("{\\left|A \\backslash B\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#text("Conditional mutual information ")#mi("{I(X:Y|Z)}")],
table.cell(colspan: 1, rowspan: 1)[#tao-math("{\\left|(A \\cap B) \\backslash C\\right|}", block: false)],
table.cell(colspan: 1, rowspan: 1)[#mi("{X, Y}")#text(" independent")],
table.cell(colspan: 1, rowspan: 1)[#mi("{A, B}")#text(" disjoint")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X}")#text(" determined by ")#mi("{Y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{A}")#text(" a subset of ")#mi("{B}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X,Y}")#text(" conditionally independent relative to ")#mi("{Z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{A \\cap B \\subset C}")]
)

#text("Every (linear) inequality or identity about entropy (and related quantities, such as mutual information) then specialises to a combinatorial inequality or identity about finite sets that is easily verified. For instance, the Shannon inequality ")#mi("{H(X,Y) \\leq H(X)+H(Y)}")#text(" becomes the union bound ")#tao-math("{\\left|A \\cup B\\right| \\leq \\left|A\\right| + \\left|B\\right|}", block: false)#text(", and the definition of mutual information becomes the inclusion-exclusion formula")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap B\\right| = \\left|A\\right| + \\left|B\\right| - \\left|A \\cup B\\right|.", block: true)]]

#text("For a more advanced example, consider the ")#link("https://en.wikipedia.org/wiki/Data_processing_inequality")[#text("data processing inequality")]#text(" that asserts that if ")#mi("{X, Z}")#text(" are conditionally independent relative to ")#mi("{Y}")#text(", then ")#mi("{I(X:Z) \\leq I(X:Y)}")#text(". Specialising to sets, this now says that if ")#mi("{A, C}")#text(" are disjoint outside of ")#mi("{B}")#text(", then ")#tao-math("{\\left|A \\cap C\\right| \\leq \\left|A \\cap B\\right|}", block: false)#text("; this can be made apparent by considering the corresponding Venn diagram. This dictionary also suggests how to ")#emph[#text("prove")]#text(" the data processing inequality using the existing Shannon inequalities. Firstly, if ")#mi("{A}")#text(" and ")#mi("{C}")#text(" are not necessarily disjoint outside of ")#mi("{B}")#text(", then a consideration of Venn diagrams gives the more general inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap C\\right| \\leq \\left|A \\cap B\\right| + \\left|(A \\cap C) \\backslash B\\right|", block: true)]]

#text("and a further inspection of the diagram then reveals the more precise identity")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cap C\\right| + \\left|(A \\cap B) \\backslash C\\right| = \\left|A \\cap B\\right| + \\left|(A \\cap C) \\backslash B\\right|.", block: true)]]

#text("Using the dictionary in the reverse direction, one is then led to conjecture the identity")

#align(center)[#tao-fit-display[#mitex("I( X : Z ) + I( X : Y | Z ) = I( X : Y ) + I( X : Z | Y )")]]

#text("which (together with non-negativity of conditional mutual information) implies the data processing inequality, and this identity is in turn easily established from the definition of mutual information.")

#text("On the other hand, not every assertion about cardinalities of sets generalises to entropies of random variables that are not arising from restricting random boolean functions to sets. For instance, a basic property of sets is that disjointness from a given set ")#mi("{C}")#text(" is preserved by unions:")

#align(center)[#tao-fit-display[#mitex("A \\cap C = B \\cap C = \\emptyset \\implies (A \\cup B) \\cap C = \\emptyset.")]]

#text("Indeed, one has the union bound ")#metadata(none) <tao-ef3ff703d7565ab5215c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|(A \\cup B) \\cap C\\right| \\leq \\left|A \\cap C\\right| + \\left|B \\cap C\\right|.", block: true)]]

#text(" Applying the dictionary in the reverse direction, one might now conjecture that if ")#mi("{X}")#text(" was independent of ")#mi("{Z}")#text(" and ")#mi("{Y}")#text(" was independent of ")#mi("{Z}")#text(", then ")#mi("{(X,Y)}")#text(" should also be independent of ")#mi("{Z}")#text(", and furthermore that")

#align(center)[#tao-fit-display[#mitex("I(X,Y:Z) \\leq I(X:Z) + I(Y:Z)")]]

#text("but these statements are well known to be false (for reasons related to pairwise independence of random variables being strictly weaker than joint independence). For a concrete counterexample, one can take ")#mi("{X, Y \\in {\\bf F}_2}")#text(" to be independent, uniformly distributed random elements of the finite field ")#mi("{{\\bf F}_2}")#text(" of two elements, and take ")#mi("{Z := X+Y}")#text(" to be the sum of these two field elements. One can easily check that each of ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" is separately independent of ")#mi("{Z}")#text(", but the joint variable ")#mi("{(X,Y)}")#text(" determines ")#mi("{Z}")#text(" and thus is not independent of ")#mi("{Z}")#text(".")

#text("From the inclusion-exclusion identities")

#tao-aligned(keep: true)[


#tao-math("\\left|A \\cap C\\right|  & = \\left|A\\right| + \\left|C\\right| - \\left|A \\cup C\\right|", block: true)



#tao-math("\\left|B \\cap C\\right|  & = \\left|B\\right| + \\left|C\\right| - \\left|B \\cup C\\right|", block: true)



#tao-math("\\left|(A \\cup B) \\cap C\\right|  & = \\left|A \\cup B\\right| + \\left|C\\right| - \\left|A \\cup B \\cup C\\right|", block: true)



#tao-math("\\left|A \\cap B \\cap C\\right|  & = \\left|A\\right| + \\left|B\\right| + \\left|C\\right| - \\left|A \\cup B\\right| - \\left|B \\cup C\\right| - \\left|A \\cup C\\right|", block: true)



#tao-math(" & + \\left|A \\cup B \\cup C\\right|", block: true)
]

#text("one can check that ")#link(<tao-ef3ff703d7565ab5215c>)[#text("(1)")]#text(" is equivalent to the trivial lower bound ")#tao-math("{\\left|A \\cap B \\cap C\\right| \\geq 0}", block: false)#text(". The basic issue here is that in the dictionary between entropy and combinatorics, there is no satisfactory entropy analogue of the notion of a triple intersection ")#mi("{A \\cap B \\cap C}")#text(". (Even the double intersection ")#mi("{A \\cap B}")#text(" only exists information theoretically in a “virtual” sense; the mutual information ")#mi("{I(X:Y)}")#text(" allows one to “compute the entropy” of this “intersection”, but does not actually describe this intersection itself as a random variable.)")

#text("However, this issue only arises with three or more variables; it is not too difficult to show that the only linear equalities and inequalities that are necessarily obeyed by the information-theoretic quantities ")#mi("{H(X), H(Y), H(X,Y), I(X:Y), H(X|Y), H(Y|X)}")#text(" associated to just two variables ")#mi("{X,Y}")#text(" are those that are also necessarily obeyed by their combinatorial analogues ")#tao-math("{\\left|A\\right|, \\left|B\\right|, \\left|A \\cup B\\right|, \\left|A \\cap B\\right|, \\left|A \\backslash B\\right|, \\left|B \\backslash A\\right|}", block: false)#text(". (See for instance the Venn diagram at ")#link("https://en.wikipedia.org/wiki/Mutual_information")[#text("the Wikipedia page for mutual information")]#text(" for a pictorial summation of this statement.)")

#text("One can work with a larger class of special cases of Shannon entropy by working with random ")#emph[#text("linear")]#text(" functions rather than random ")#emph[#text("boolean")]#text(" functions. Namely, let ")#mi("{S}")#text(" be some finite-dimensional vector space over a finite field ")#mi("{{\\mathbf F}}")#text(", and let ")#mi("{f: S \\rightarrow {\\mathbf F}}")#text(" be a random linear functional on ")#mi("{S}")#text(", selected uniformly among all such functions. Every subspace ")#mi("{U}")#text(" of ")#mi("{S}")#text(" then gives rise to a random variable ")#mi("{X = X_U: U \\rightarrow {\\mathbf F}}")#text(" formed by restricting ")#mi("{f}")#text(" to ")#mi("{U}")#text(". This random variable is also distributed uniformly amongst all linear functions on ")#mi("{U}")#text(", and its entropy can be easily computed to be ")#tao-math("{\\mathrm{dim}(U) \\log \\left|\\mathbf{F}\\right|}", block: false)#text(". Given two random variables ")#mi("{X, Y}")#text(" formed by restricting ")#mi("{f}")#text(" to ")#mi("{U, V}")#text(" respectively, the joint random variable ")#mi("{(X,Y)}")#text(" determines the random linear function ")#mi("{f}")#text(" on the union ")#mi("{U \\cup V}")#text(" on the two spaces, and thus by linearity on the ")#link("https://en.wikipedia.org/wiki/Minkowski_addition")[#text("Minkowski sum")]#text(" ")#mi("{U+V}")#text(" as well; thus ")#mi("{(X,Y)}")#text(" is equivalent to the restriction of ")#mi("{f}")#text(" to ")#mi("{U+V}")#text(". In particular, ")#tao-math("{H(X,Y) = \\mathrm{dim}(U+V) \\log \\left|\\mathbf{F}\\right|}", block: false)#text(". This implies that ")#tao-math("{I(X:Y) = \\mathrm{dim}(U \\cap V) \\log \\left|\\mathbf{F}\\right|}", block: false)#text(" and also ")#tao-math("{H(X|Y) = \\mathrm{dim}(\\pi_V(U)) \\log \\left|\\mathbf{F}\\right|}", block: false)#text(", where ")#mi("{\\pi_V: S \\rightarrow S/V}")#text(" is the quotient map. After discarding the normalising constant ")#tao-math("{\\log \\left|\\mathbf{F}\\right|}", block: false)#text(", this leads to the following dictionary between information theoretic quantities and linear algebra quantities, analogous to the previous dictionary:")

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Random variables ")#mi("{X,Y,Z}")],
table.cell(colspan: 1, rowspan: 1)[#text("Subspaces ")#mi("{U,V,W}")],
table.cell(colspan: 1, rowspan: 1)[#text("Entropy ")#mi("{H(X)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Dimension ")#mi("{\\mathrm{dim}(U)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Joint variable ")#mi("{(X,Y)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Sum ")#mi("{U+V}")],
table.cell(colspan: 1, rowspan: 1)[#text("Mutual information ")#mi("{I(X:Y)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Dimension of intersection ")#mi("{\\mathrm{dim}(U \\cap V)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Conditional entropy ")#mi("{H(X|Y)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Dimension of projection ")#mi("{\\mathrm{dim}(\\pi_V(U))}")],
table.cell(colspan: 1, rowspan: 1)[#text("Conditional mutual information ")#mi("{I(X:Y|Z)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\mathrm{dim}(\\pi_W(U) \\cap \\pi_W(V))}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X, Y}")#text(" independent")],
table.cell(colspan: 1, rowspan: 1)[#mi("{U, V}")#text(" transverse (")#mi("{U \\cap V = \\{0\\}}")#text(")")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X}")#text(" determined by ")#mi("{Y}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{U}")#text(" a subspace of ")#mi("{V}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{X,Y}")#text(" conditionally independent relative to ")#mi("{Z}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\pi_W(U)}")#text(", ")#mi("{\\pi_W(V)}")#text(" transverse.")]
)

#text("The combinatorial dictionary can be regarded as a specialisation of the linear algebra dictionary, by taking ")#mi("{S}")#text(" to be the vector space ")#mi("{\\mathbf{F}_2^\\Omega}")#text(" over the finite field ")#mi("{\\mathbf{F}_2}")#text(" of two elements, and only considering those subspaces ")#mi("{U}")#text(" that are coordinate subspaces ")#mi("{U = {\\bf F}_2^A}")#text(" associated to various subsets ")#mi("{A}")#text(" of ")#mi("{\\Omega}")#text(".")

#text("As before, every linear inequality or equality that is valid for the information-theoretic quantities discussed above, is automatically valid for the linear algebra counterparts for subspaces of a vector space over a finite field by applying the above specialisation (and dividing out by the normalising factor of ")#tao-math("{\\log \\left|\\mathbf{F}\\right|}", block: false)#text("). In fact, the requirement that the field be finite can be removed by applying the ")#link("https://en.wikipedia.org/wiki/Compactness_theorem")[#text("compactness theorem")]#text(" from logic (or one of its relatives, such as ")#link("https://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem on ultraproducts")]#text(", as done in ")#link("https://terrytao.wordpress.com/2013/12/07/ultraproducts-as-a-bridge-between-discrete-and-continuous-analysis/")[#text("this previous blog post")]#text(").")

#text("The linear algebra model captures more of the features of Shannon entropy than the combinatorial model. For instance, in contrast to the combinatorial case, it is possible in the linear algebra setting to have subspaces ")#mi("{U,V,W}")#text(" such that ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are separately transverse to ")#mi("{W}")#text(", but their sum ")#mi("{U+V}")#text(" is not; for instance, in a two-dimensional vector space ")#mi("{{\\bf F}^2}")#text(", one can take ")#mi("{U,V,W}")#text(" to be the one-dimensional subspaces spanned by ")#mi("{(0,1)}")#text(", ")#mi("{(1,0)}")#text(", and ")#mi("{(1,1)}")#text(" respectively. Note that this is essentially the same counterexample from before (which took ")#mi("{{\\bf F}}")#text(" to be the field of two elements). Indeed, one can show that any necessarily true linear inequality or equality involving the dimensions of three subspaces ")#mi("{U,V,W}")#text(" (as well as the various other quantities on the above table) will also be necessarily true when applied to the entropies of three discrete random variables ")#mi("{X,Y,Z}")#text(" (as well as the corresponding quantities on the above table).")

#text("However, the linear algebra model does not completely capture the subtleties of Shannon entropy once one works with ")#emph[#text("four")]#text(" or more variables (or subspaces). This was first observed by Ingleton, ")#link("https://en.wikipedia.org/wiki/Ingleton's_inequality")[#text("who established the dimensional inequality")]#text(" ")#metadata(none) <tao-28080005a0fe03ba7172>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\mathrm{dim}(U \\cap V) \\leq \\mathrm{dim}(\\pi_W(U) \\cap \\pi_W(V)) + \\mathrm{dim}(\\pi_X(U) \\cap \\pi_X(V)) + \\mathrm{dim}(W \\cap X)")]]

#text(" for any subspaces ")#mi("{U,V,W,X}")#text(". This is easiest to see when the three terms on the right-hand side vanish; then ")#mi("{\\pi_W(U), \\pi_W(V)}")#text(" are transverse, which implies that ")#mi("{U\\cap V \\subset W}")#text("; similarly ")#mi("{U \\cap V \\subset X}")#text(". But ")#mi("{W}")#text(" and ")#mi("{X}")#text(" are transverse, and this clearly implies that ")#mi("{U}")#text(" and ")#mi("{V}")#text(" are themselves transverse. To prove the general case of Ingleton’s inequality, one can define ")#mi("{Y := U \\cap V}")#text(" and use ")#mi("{\\mathrm{dim}(\\pi_W(Y)) \\leq \\mathrm{dim}(\\pi_W(U) \\cap \\pi_W(V))}")#text(" (and similarly for ")#mi("{X}")#text(" instead of ")#mi("{W}")#text(") to reduce to establishing the inequality ")#metadata(none) <tao-adc5877fb1da7d50eec1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\mathrm{dim}(Y) \\leq \\mathrm{dim}(\\pi_W(Y)) + \\mathrm{dim}(\\pi_X(Y)) + \\mathrm{dim}(W \\cap X)")]]

#text(" which can be rearranged using ")#mi("{\\mathrm{dim}(\\pi_W(Y)) = \\mathrm{dim}(Y) - \\mathrm{dim}(W) + \\mathrm{dim}(\\pi_Y(W))}")#text(" (and similarly for ")#mi("{X}")#text(" instead of ")#mi("{W}")#text(") and ")#mi("{\\mathrm{dim}(W \\cap X) = \\mathrm{dim}(W) + \\mathrm{dim}(X) - \\mathrm{dim}(W + X)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim}(W + X ) \\leq \\mathrm{dim}(\\pi_Y(W)) + \\mathrm{dim}(\\pi_Y(X)) + \\mathrm{dim}(Y)")]]

#text("but this is clear since ")#mi("{\\mathrm{dim}(W + X ) \\leq \\mathrm{dim}(\\pi_Y(W) + \\pi_Y(X)) + \\mathrm{dim}(Y)}")#text(".")

#text("Returning to the entropy setting, the analogue")

#align(center)[#tao-fit-display[#mitex("H( V ) \\leq H( V | Z ) + H(V | W ) + I(Z:W)")]]

#text("of ")#link(<tao-adc5877fb1da7d50eec1>)[#text("(3)")]#text(" is true (exercise!), but the analogue ")#metadata(none) <tao-2d3a8c1fe4700b4d31e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("I(X:Y) \\leq I(X:Y|Z) + I(X:Y|W) + I(Z:W)")]]

#text(" of Ingleton’s inequality is false in general. Again, this is easiest to see when all the terms on the right-hand side vanish; then ")#mi("{X,Y}")#text(" are conditionally independent relative to ")#mi("{Z}")#text(", and relative to ")#mi("{W}")#text(", and ")#mi("{Z}")#text(" and ")#mi("{W}")#text(" are independent, and the claim ")#link(<tao-2d3a8c1fe4700b4d31e9>)[#text("(4)")]#text(" would then be asserting that ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are independent. While there is no linear counterexample to this statement, there are simple non-linear ones: for instance, one can take ")#mi("{Z,W}")#text(" to be independent uniform variables from ")#mi("{\\mathbf{F}_2}")#text(", and take ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" to be (say) ")#mi("{ZW}")#text(" and ")#mi("{(1-Z)(1-W)}")#text(" respectively (thus ")#mi("{X, Y}")#text(" are the indicators of the events ")#mi("{Z=W=1}")#text(" and ")#mi("{Z=W=0}")#text(" respectively). Once one conditions on either ")#mi("{Z}")#text(" or ")#mi("{W}")#text(", one of ")#mi("{X,Y}")#text(" has positive conditional entropy and the other has zero entropy, and so ")#mi("{X, Y}")#text(" are conditionally independent relative to either ")#mi("{Z}")#text(" or ")#mi("{W}")#text("; also, ")#mi("{Z}")#text(" or ")#mi("{W}")#text(" are independent of each other. But ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are not independent of each other (they cannot be simultaneously equal to ")#mi("{1}")#text("). Somehow, the feature of the linear algebra model that is not present in general is that in the linear algebra setting, every pair of subspaces ")#mi("{U, V}")#text(" has a well-defined intersection ")#mi("{U \\cap V}")#text(" that is also a subspace, whereas for arbitrary random variables ")#mi("{X, Y}")#text(", there does not necessarily exist the analogue of an intersection, namely a “common information” random variable ")#mi("{V}")#text(" that has the entropy of ")#mi("{I(X:Y)}")#text(" and is determined either by ")#mi("{X}")#text(" or by ")#mi("{Y}")#text(".")

#text("I do not know if there is any simpler model of Shannon entropy that captures all the inequalities available for four variables. One significant complication is that there exist some information inequalities in this setting that are not of Shannon type, such as the ")#link("http://www.ams.org/mathscinet-getitem?mr=1481054")[#text("Zhang-Yeung inequality")]

#tao-aligned(keep: true)[


#tao-math("I(X:Y)  & \\leq 2 I(X:Y|Z) + I(X:Z|Y) + I(Y:Z|X)", block: true)



#tao-math(" & + I(X:Y|W) + I(Z:W).", block: true)
]

#text("One can however still use these simpler models of Shannon entropy to be able to guess arguments that would work for general random variables. An example of this comes from ")#link("https://terrytao.wordpress.com/2015/09/18/the-logarithmically-averaged-chowla-and-elliott-conjectures-for-two-point-correlations-the-erdos-discrepancy-problem/")[#text("my paper on the logarithmically averaged Chowla conjecture")]#text(", in which I showed among other things that ")#metadata(none) <tao-50b8d2c3973594d74271>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left|\\sum_{n \\leq x} \\frac{\\lambda(n) \\lambda(n+1)}{n}\\right| \\leq \\varepsilon \\log x", block: true)]]

#text(" whenever ")#mi("{x}")#text(" was sufficiently large depending on ")#mi("{\\varepsilon>0}")#text(", where ")#mi("{\\lambda}")#text(" is the Liouville function. The information-theoretic part of the proof was as follows. Given some intermediate scale ")#mi("{H}")#text(" between ")#mi("{1}")#text(" and ")#mi("{x}")#text(", one can form certain random variables ")#mi("{X_H, Y_H}")#text(". The random variable ")#mi("{X_H}")#text(" is a sign pattern of the form ")#mi("{(\\lambda(n+1),\\dots,\\lambda(n+H))}")#text(" where ")#mi("{n}")#text(" is a random number chosen from ")#mi("{1}")#text(" to ")#mi("{x}")#text(" (with logarithmic weighting). The random variable ")#mi("{Y_H}")#text(" was a tuple ")#mi("{(n \\text{ mod } p)_{p \\sim \\varepsilon^2 H}}")#text(" of reductions of ")#mi("{n}")#text(" to primes ")#mi("{p}")#text(" comparable to ")#mi("{\\varepsilon^2 H}")#text(". Roughly speaking, what was implicitly shown in the paper (after using the multiplicativity of ")#mi("{\\lambda}")#text(", the circle method, and the Matomaki-Radziwill theorem on short averages of multiplicative functions) is that if the inequality ")#link(<tao-50b8d2c3973594d74271>)[#text("(5)")]#text(" fails, then there was a lower bound")

#align(center)[#tao-fit-display[#mitex("I( X_H : Y_H ) \\gg \\varepsilon^7 \\frac{H}{\\log H}")]]

#text("on the mutual information between ")#mi("{X_H}")#text(" and ")#mi("{Y_H}")#text(". From translation invariance, this also gives the more general lower bound ")#metadata(none) <tao-f1c5e050ad6e41beada8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("I( X_{H_0,H} : Y_H ) \\gg \\varepsilon^7 \\frac{H}{\\log H}")]]

#text(" for any ")#mi("{H_0}")#text(", where ")#mi("{X_{H_0,H}}")#text(" denotes the shifted sign pattern ")#mi("{(\\lambda(n+H_0+1),\\dots,\\lambda(n+H_0+H))}")#text(". On the other hand, one had the entropy bounds")

#align(center)[#tao-fit-display[#mitex("H( X_{H_0,H} ), H(Y_H) \\ll H")]]

#text("and from concatenating sign patterns one could see that ")#mi("{X_{H_0,H+H^{\\prime}}}")#text(" is equivalent to the joint random variable ")#mi("{(X_{H_0,H}, X_{H_0+H,H^{\\prime}})}")#text(" for any ")#mi("{H_0,H,H^{\\prime}}")#text(". Applying these facts and using an “entropy decrement” argument, I was able to obtain a contradiction once ")#mi("{H}")#text(" was allowed to become sufficiently large compared to ")#mi("{\\varepsilon}")#text(", but the bound was quite weak (coming ultimately from the unboundedness of ")#mi("{\\sum_{\\log H_- \\leq j \\leq \\log H_+} \\frac{1}{j \\log j}}")#text(" as the interval ")#mi("{[H_-,H_+]}")#text(" of values of ")#mi("{H}")#text(" under consideration becomes large), something of the order of ")#mi("{H \\sim \\exp\\exp\\exp(\\varepsilon^{-7})}")#text("; the quantity ")#mi("{H}")#text(" needs at various junctures to be less than a small power of ")#mi("{\\log x}")#text(", so the relationship between ")#mi("{x}")#text(" and ")#mi("{\\varepsilon}")#text(" becomes essentially quadruple exponential in nature, ")#mi("{x \\sim \\exp\\exp\\exp\\exp(\\varepsilon^{-7})}")#text(". The basic strategy was to observe that the lower bound ")#link(<tao-f1c5e050ad6e41beada8>)[#text("(6)")]#text(" causes some slowdown in the growth rate ")#mi("{H(X_{kH})/kH}")#text(" of the mean entropy, in that this quantity decreased by ")#mi("{\\gg \\frac{\\varepsilon^7}{\\log H}}")#text(" as ")#mi("{k}")#text(" increased from ")#mi("{1}")#text(" to ")#mi("{\\log H}")#text(", basically by dividing ")#mi("{X_{kH}}")#text(" into ")#mi("{k}")#text(" components ")#mi("{X_{jH, H}}")#text(", ")#mi("{j=0,\\dots,k-1}")#text(" and observing from ")#link(<tao-f1c5e050ad6e41beada8>)[#text("(6)")]#text(" each of these shares a bit of common information with the same variable ")#mi("{Y_H}")#text(". This is relatively clear when one works in a set model, in which ")#mi("{Y_H}")#text(" is modeled by a set ")#mi("{B_H}")#text(" of size ")#mi("{O(H)}")#text(", and ")#mi("{X_{H_0,H}}")#text(" is modeled by a set of the form")

#align(center)[#tao-fit-display[#mitex("X_{H_0,H} = \\bigcup_{H_0 < h \\leq H_0+H} A_h")]]

#text("for various sets ")#mi("{A_h}")#text(" of size ")#mi("{O(1)}")#text(" (also there is some translation symmetry that maps ")#mi("{A_h}")#text(" to a shift ")#mi("{A_{h+1}}")#text(" while preserving all of the ")#mi("{B_H}")#text(").")

#text("However, on considering the set model recently, I realised that one can be a little more efficient by exploiting the fact (basically the Chinese remainder theorem) that the random variables ")#mi("{Y_H}")#text(" are basically jointly independent as ")#mi("{H}")#text(" ranges over dyadic values that are much smaller than ")#mi("{\\log x}")#text(", which in the set model corresponds to the ")#mi("{B_H}")#text(" all being disjoint. One can then establish a variant ")#metadata(none) <tao-c740dcae3b016289c8c7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("I( X_{H_0,H} : Y_H | (Y_{H^{\\prime}})_{H^{\\prime} < H}) \\gg \\varepsilon^7 \\frac{H}{\\log H}")]]

#text(" of ")#link(<tao-f1c5e050ad6e41beada8>)[#text("(6)")]#text(", which in the set model roughly speaking asserts that each ")#mi("{B_H}")#text(" claims a portion of the ")#mi("{\\bigcup_{H_0 < h \\leq H_0+H} A_h}")#text(" of cardinality ")#mi("{\\gg \\varepsilon^7 \\frac{H}{\\log H}}")#text(" that is not claimed by previous choices of ")#mi("{B_H}")#text(". This leads to a more efficient contradiction (relying on the unboundedness of ")#mi("{\\sum_{\\log H_- \\leq j \\leq \\log H_+} \\frac{1}{j}}")#text(" rather than ")#mi("{\\sum_{\\log H_- \\leq j \\leq \\log H_+} \\frac{1}{j \\log j}}")#text(") that looks like it removes one order of exponential growth, thus the relationship between ")#mi("{x}")#text(" and ")#mi("{\\varepsilon}")#text(" is now ")#mi("{x \\sim \\exp\\exp\\exp(\\varepsilon^{-7})}")#text(". Returning to the entropy model, one can use ")#link(<tao-c740dcae3b016289c8c7>)[#text("(7)")]#text(" and Shannon inequalities to establish an inequality of the form")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2H} H(X_{2H} | (Y_{H^{\\prime}})_{H^{\\prime} \\leq 2H}) \\leq \\frac{1}{H} H(X_{H} | (Y_{H^{\\prime}})_{H^{\\prime} \\leq H}) - \\frac{c \\varepsilon^7}{\\log H}")]]

#text("for a small constant ")#mi("{c>0}")#text(", which on iterating and using the boundedness of ")#mi("{\\frac{1}{H} H(X_{H} | (Y_{H^{\\prime}})_{H^{\\prime} \\leq H})}")#text(" gives the claim. (A modification of this analysis, at least on the level of the back of the envelope calculation, suggests that the Matomaki-Radziwill theorem is needed only for ranges ")#mi("{H}")#text(" greater than ")#mi("{\\exp( (\\log\\log x)^{\\varepsilon^{7}} )}")#text(" or so, although at this range the theorem is not significantly simpler than the general case).")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (33)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Manny")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478568")[#strong[#text("Manny")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("I think the equation in first sentence is missing a minus.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7dc3a833553751c0dc9571dd4e984cf43dd81b1e9c95966a9eaf61a3a9102c54-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478569")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("In the first formula the minus is missing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa57950b9986d0d0324a804ca71fd32b0d9229d6d6d351a8935c4aa75945ff12-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nikita Sidorov")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478570")[#strong[#text("Nikita Sidorov")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("Sorry, didn’t notice 1/… It’s all good, then.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/010df765105ce34e909d32e048742a010efe062bbd36c2f8dd19b0f5d8696624-674c360e65f00aef448537ac10f62e98585537d42a371884d863a417fe6f0980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ravi Andrew Bajaj")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478572")[#strong[#text("Ravi Andrew Bajaj")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("Dear Professor Tao,")

#text("Are there applications of this result to random matrix theory?")

#text("–RAB")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478573")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("Nice post! Just to note a couple of typos: In the third line of the dictionary for subspaces, either change the random variable to its entropy or the dimension to a subspace. In the paragraph below (5) I think you mean “if the inequality (5) fails…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of .")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478576")[#strong[#text(".")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("Your dictionary as in other dictionaries misses the non-trivial $X,Y,Z$ are correlated case. How would you give a dictionary between information theory and set theory/subspace for the cases $X,Y,Z$ are correlated?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4dc01391ad8b1febd0cd5d437051dc69ac7d492df96b4b30641b613558b2447b-a405f2809a5b03cfedc1efa0b62ea6cb9899b5a3053d16bae6cab1acad7ea18f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of domotorp")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478583")[#strong[#text("domotorp")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("What happens if we swap union and intersection in the set dictionary, or we project ONTO the subspaces in the subspace dictionary? Is it only that some inequalities and signs turn?")

#text("Also, I think there are a few more typos:")#linebreak()#text(" 1, if and if -> if and only if")#linebreak()#text(" 2, equivalent to the restriction to f -> of f")#linebreak()#text(" 3, S/U is the quotient map -> S/V")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478601")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2017")])]

#text("Thanks for the corrections!")

#text("In the set dictionary, one can replace all the sets ")#mi("A")#text(" with their complements ")#mi("\\Omega \\backslash A")#text(" in the ambient space ")#mi("\\Omega")#text(". This interchanges unions and intersections by de Morgan’s laws, but also cardinality ")#tao-math("\\left|A\\right|", block: false)#text(" must now be replaced by cocardinality ")#tao-math("\\left|\\Omega\\right| - \\left|A\\right|", block: false)#text(". The analogue of conditional entropy ")#tao-math("\\left|A \\backslash B\\right|", block: false)#text(" is now the cocardinality of ")#mi("A \\cap B")#text(" inside ")#mi("B")#text(" (viewing the latter as the new ambient space, thus conditioning corresponds to restricting the ambient space and all the sets inside it to ")#mi("B")#text(").")

#text("Similarly, in the linear algebra dictionary, by replacing all the vector spaces with their complements (viewed as subspaces of the dual space ")#mi("S^*")#text(", or if one has a nondegenerate bilinear form on ")#mi("S")#text(" one can take orthogonal complements with respect to that form and stay inside ")#mi("S")#text("), one can interchange sums and intersections, replacing dimensions with codimensions throughout. Again, the analogue of projection is now restriction (restricting the ambient space ")#mi("S^*")#text(" and all of its subspaces to a smaller space ")#mi("V")#text("). For instance, the analogue of conditional entropy ")#mi("\\mathrm{dim}(\\pi_V(U))")#text(" is now the codimension of ")#mi("U \\cap V")#text(" inside ")#mi("V")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/774ef0809a7b7d309616326a909a6efbd859843695bb51e000365ddd3f62ae28-e6843b3960b3f1b1f932032eeb8fb80d08c9ab51dfbef1b83c961b039d99bfee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djdkd")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478584")[#strong[#text("Djdkd")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2017")])]

#text("Dear Terry, I think you proved something considerably stronger than (5)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478592")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2017")])]

#text("In the second paragraph, the word only is missing in “…vanishes if and if …”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc5a1646939215ff9ff5807f586af966fa8275e95ed3c9ffe8ac15aca667ba1a-eadd8138fdf71b0abb06a7bc84c9206c203fb6cd63d1d44a144284d532b35905.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Fries")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478595")[#strong[#text("John Fries")]]#text(size: 9pt, fill: rgb("596477"), " · 2 March 2017")])]

#text("Professor Tao,")

#text("Have you read Amari’s paper “Information Geometry on Hierarchy of Probability Distributions”? Instead of mapping information theory to set theory or linear algebra, he maps it to differential geometry. Of particular note is that he is able to discuss triplewise and higher interactions between random variables.")

#text("Here is a link: ")#link("https://pdfs.semanticscholar.org/aa12/aee8cb3fb5ef2c545c0a9efa383326270340.pdf")[#text("https://pdfs.semanticscholar.org/aa12/aee8cb3fb5ef2c545c0a9efa383326270340.pdf")]

#text("Sincerely,")#linebreak()#text(" John Fries")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9217dfee37edacba8605f63635202db16bad895ad09c9f5041ebf4f19dc33134-679b57d05c41ad2f2dea954bab8cd9a3e02a1b7582cc13eac5b70b837c3f0f6d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478693")[#strong[#text("Jeff")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2017")])]

#text("most readers of this blog probably won’t get confused by this, but it’s slightly confusing to call conditional entropy “relative entropy”, which many take as synonymous with the fairly unrelated concept of KL divergence.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb04e98f5fa36224822bb2c7b89ae1a754cfdd2f1dbc98068837bfc36239922-c8100cb1df9c86941161db08630ee720a10be4def2c2abb193dd0bc5e3df7ec2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Oliver Knill")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478838")[#strong[#text("Oliver Knill")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2017")])]

#text("Nice analogies. Since cardinality is generalized by Euler characteristic for finite abstract simplicial complexes, one could push the analogy even further. The inclusion-exclusion formula becomes the property of a “valuation” on complexes which is the defining relation. Valuation is understood in the sense of Klain and Rota, who developed the discrete analogue of continuum geometric probability theory. Zero dimensional complexes are sets so that this extends the finite set analogy.")

#text("Entropy, an important functional (maybe the most important one) in a probabilistic set-up when dealing with random variables X is then linked to Euler characteristic an important quantity (maybe the most important one) in topology, when dealing with simplicial complexes X.")

#text("Euler characteristic has long known to be the only valuation which is invariant under Barycentric refinement of the complex G, the complex, in which the sets of G are the points of the new base and the new sets are the subsets. The reason is that there is a universal linear map A which maps the f-vector of G to the f-vector of the refinement of G. This matrix A has a unique eigenvalue 1 which is (1,-1,1,-1,…) leading to the Euler characteristic. Euler characteristic is then a Perron-Frobenius eigenvector of the inverse of the Barycentric refinement operator. It is unique if one normalizes it so that its value on a 1-point complex 1 is 1.")

#text("There is a similar defining renormalization picture for entropy: Shannon in his 1948 article already established such a condition which defines entropy uniquely (Theorem 2 in his paper). Much earlier, Boltzmann saw entropy as a functional on measures as he defined it as the expectation of -log(P) (famously displayed on his tomb stone) and already on physical grounds wanted entropy to be additive for physical systems which do not interact Taking about random variables X means the entropy of its law (which essentially corresponds to the Shannon condition). Obviously, entropy H satisfies H(X+X’)/2=H(X) if X,X’ are IID and H(X)=0 if X is a constant random variable. This renormalisation operator X -> X+X’ is the analogue of Barycentric refinement and the requirement H(X+X’)/2=H(X) defines the entropy functional uniquely if normalized for the constant random variable. (Shannon seems to have a stronger assumptions I(X:Y)=0 for independent X,Y but this could be bootstrapped from H(X+X’)/2=H(X) for IID X,X’ using polarization from H(X+Y + X’+Y’)). The value H=-log(X) for Euler characteristic X is an analogue of entropy as it is additive with respect to Cartesian products of complexes but topologists refrain from taking the log as we also want to deal with spaces of Euler characteristic 0 like the circle. A special case is the product G x 1 with one-point complex 1 which is the Barycentric refinement of G. The analogue of H(A + B)=H(A) + H(B) for IID random variables A,B is H(A x B) = H(A) + H(B) for simplicial complexes. The analogue of H(1)=0 (H=entropy, 1=constant random variable) is H(1)=0 (H=-log(Euler characteristic, 1=1 point complex)).")

#text("There is also an analogue central limit theorem: the operator X -> X+X’ for random variables (X’ is just an IID copy of X and X+X’ is normalized to have variance 1 obviously leads to the classical central limit theorem and entropy is a Lyapunov function under the operation and iterating the map is a discrete time gradient type flow leading to a Gaussian distribution, the maximum. Similarly as a random variable X defines a law P, any simplicial complex X has a “law” P: it is the density of states of its Laplacian, a discrete point measure P on the real line. What happens during Barycentric refinement is that one is close to adding up independent complexes (there is a boundary part which becomes negligible and controlling this needs a Lidskii-Last inequality). The story is even more intriguing as in probability theory because so far, we only know the limiting measure for one-dimensional complexes. It is the potential theoretical equilibrium measure on an interval, the arcsine law. The limiting universal measures for higher dimensional complexes depends only on the maximal dimension of the complex and are unidentified so far. Its integrated density of states (= CDF) appears discontinuous in dimensions larger than 1.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478864")[#strong[#text("Shannon Entropy and Euler Characteristic - Quantum Calculus")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2017")]

#text("[…] A blog entry mentions some analogies between entropy and other combinatorial notions. One can push the analogy in an other direction and compare random variables with simplicial complexes, Shannon entropy with Euler characteristic. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Furstenberg limits of the Liouville function | What's new")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478891")[#strong[#text("Furstenberg limits of the Liouville function | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("[…] of ) shows that eventually becomes negative for sufficiently large , which is absurd. (See also this previous blog post for a sketch of a slightly different way to conclude the argument from entropy […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-478974")[#strong[#text("Machine Learning Notes/Pointers | SChaiken's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2017")]

#text("[…] Terry Tao on Shannon Entropy and its analogies to set functions […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a19e1527a5a5e5ce6cc69e0ee5e0af051d83cf8781a0459eb871c19697de474-14785f94a667cea5537939b4c41d289fd45219cf34cffb52ca2c456c929e062b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Triscari")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479198")[#strong[#text("Joe Triscari")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2017")])]

#text("Interesting article.")

#text("It makes me wonder if there are category theoretic ideas to be milked out of these analogies.")

#text("The free vector space on a set preserves entropy. Maybe there’s some entropy concept lurking under other categories and there are functors that preserve the entropy…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80855259868f882fa9bf4ab7a0f4c4c90f77b9708807d56d25944e886a95b17c-a94222ac58ef0bf5a103dce3f406b2c8db1d7214dcb0fac61f2ab006fe641a05.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Tse")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479252")[#strong[#text("David Tse")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("Nice post. A pedagogical comment. Instead of defining the set theoretic model in terms of a random mapping F, wouldn’t it be more straightforward to define it in terms of a set of i.i.d. Bern(0.5) random variables ")#mi("X_1, X_2, \\ldots X_n")#text(", where $n = |\\Omega|$? Then for every subset ")#mi("A \\subset \\Omega")#text(", one can define a random vector ")#mi("X_A = (X_i)_{i \\in A}")#text(".")

#emph[#text("[One could indeed do this, but I preferred to use the random function model as it made the similarity between the set theoretic dictionary and the linear algebra dictionary more apparent. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80855259868f882fa9bf4ab7a0f4c4c90f77b9708807d56d25944e886a95b17c-a94222ac58ef0bf5a103dce3f406b2c8db1d7214dcb0fac61f2ab006fe641a05.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Tse")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479312")[#strong[#text("David Tse")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2017")])]

#text("Continuing on my previous comment and in response to Terry’s note, I believe the representation of the set theoretic model in terms of basic random variables ")#mi("X_1, \\ldots, X_n")#text(" can be generalized to the linear algebra model by starting again with ")#mi("X_1, \\ldots, X_n")#text(" but now thinking it as a random vector X. For each linear transformation T, we can define ")#mi("X_T = TX")#text(". The set theoretic model corresponds to the random vectors obtained by restricting T to be diagonal with only 1’s and 0’s.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1e6898aa39df44ff5a295073c7b2889b77b9a4a7d7b88358130004b9b1a6424-7c24dfa436fc50168ed0cfc79cbd3b16d9453ba8a26e8994011fa92d9ef1a3ab.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raymond Yeung")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479297")[#strong[#text("Raymond Yeung")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2017")])]

#text("Nice post by Terry and others. Here are some supplementary comments.")

#text("1. The first rigorous proof of the set-entropy dictionary, to my knowledge, is the 1962 paper by Hu (originally in Russian):")

#link("http://epubs.siam.org/doi/pdf/10.1137/1107041")[#text("http://epubs.siam.org/doi/pdf/10.1137/1107041")]

#text("2. The analogy between sets and entropy was enhanced into an equivalence in my 1991 paper. For a fixed finite set of discrete random variables, we have for example")

#text("$I(X:Y|Z) = \\mu^*(A \\cap B – C)$ ,")

#text("where $\\mu^*$, called the I-Measure, is a unique signed measure defined on a suitably constructed $\\sigma$-field. $\\mu^*$ is unique in the sense that")#linebreak()#text(" it is determined by the joint entropies of all the random variables involved. With this equivalence, one can formally apply all the tools in set theory to information theory. In short, in the information theory domain, every identity (not inequality) that one can read off from the Venn diagram is valid and one does not have to go back to prove it in information theory.")

#text("3. As pointed out in Terry’s post, the quantity")

#text("$I(X:Y:Z) = I(X:Y) – I(X:Y|Z)$")

#text("can be negative. Though without an operational meaning, quantities such as $I(X:Y:Z)$ have a clear measure-theoretic meaning and are very handy for manipulating terms.")

#text("The I-Measure $\\mu^*$ is a signed measure in general. However, when the random variables form a Markov chain, $\\mu^*$ is always nonnegative and hence a measure. There also exists a very simple form of Venn diagram for Markov chains, allowing one to read off simple identities/ inequalities like the data processing inequality and even elaborate identities like")

#text("$H(Y) + H(T) = I(Z: X, Y, T, U) + I(X, Y : T, U) + H(Y|Z) + H(T|Z)$")

#text("when $X – Y – Z – T – U$ form a Markov chain.")

#text("Terry pointed out correctly that one cannot read off entropy inequalities from Venn diagrams for 3 or more random variables. This is precisely because $\\mu^*$ is not necessarily a measure. Nevertheless, for identities this is not a problem. For Markov chains, $\\mu^*$ is always a measure and so one can read off inequalities from the Venn diagram.")

#text("4. Shannon’s information measures exhibit a very beautiful set-theoretic structure for a certain class of conditional independencies called full conditional independencies (FCMI), including Markov random field as a special case. Markov random field in turn includes Markov chain as a special case.")

#text("*****")

#text("The above can be found in Ch. 3 and Ch. 12 of my 2008 book (soft copy should be available at most university libraries). There are also historical notes at the end of the chapter which may be of interest to some.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f82aecd5694c460d0c0a0a739657f992bc0a02908916d524bf68514135a6671a-fc3af49e19abffc81aab72e5d8d581f18466fa4457d57646898d06cd37cd3eaf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Szymon Toruńczyk")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479632")[#strong[#text("Szymon Toruńczyk")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2017")])]

#text("About the model for four or more variables – below is a proposal, originating from “On a relation between information inequalities and group theory” by Terence H. Chan and Raymond W. Yeung.")#linebreak()#text(" Consider a finite group ")#mi("G")#text(" and a random variable ")#mi("g")#text(" taking as values elements of ")#mi("G")#text(", with uniform distribution. For a subgroup ")#mi("H")#text(" of ")#mi("G")#text(", define the random variable ")#mi("g\\cdot H")#text(". This random variable is uniformly distributed on the set of cosets ")#mi("G/H")#text(", so its entropy is equal to ")#tao-math("\\log \\left|G/H\\right|", block: false)#text(". For a subset ")#mi("X")#text(" of a group ")#mi("G")#text(", denote ")#tao-math("\\log \\frac{\\left|G\\right|}{\\left|X\\right|}", block: false)#text(" by ")#mi("\\textrm{codim}^G(X)")#text(".")#linebreak()#text(" Below is a dictionary between information theoretic quantities and group theoretic quantities:")#linebreak()#text(" Random variables ")#mi("X,Y,Z")#text(" – subgroups ")#mi("K,H,S")#linebreak()#text(" Entropy ")#mi("H(X)")#text(" – codimension ")#tao-math("\\textrm{codim}^G(K)=\\log \\frac{\\left|G\\right|}{\\left|K\\right|}", block: false)#linebreak()#text(" Joint variable ")#mi("(X,Y)")#text(" – subgroup intersection ")#mi("K\\cap H")#linebreak()#text(" Mutual information ")#mi("I(X:Y)")#text(" – codimension of product set ")#mi("\\textrm{codim}^G(K\\cdot H)")#linebreak()#text(" Conditional entropy ")#mi("H(X|Y)")#text(" – relative codimension ")#mi("\\textrm{codim}^H(K\\cap H)")#linebreak()#text(" Conditional mutual information ")#mi("I(X:Y|Z)")#text(" – ")#mi("\\textrm{codim}^S((K\\cap S)\\cdot (H\\cap S))")#linebreak()#text(" ")#mi("X,Y")#text(" independent – ")#mi("K\\cdot H=G")#linebreak()#text(" ")#mi("X")#text(" determined by ")#mi("Y")#text(" – ")#mi("H\\subset K")#linebreak()#text(" ")#mi("X,Y")#text(" conditionally independent relative to ")#mi("Z")#text(" – ")#mi("(K\\cap S)\\cdot (H\\cap S)=S")#linebreak()#text(" ")#linebreak()#text(" The linear algebra dictionary can be regarded as a special case of the group dictionary, by taking ")#mi("G")#text(" to be the additive group ")#mi("S^*")#text(" of all linear functions from ")#mi("S")#text(" to the field ")#mi("\\mathbf F")#text(".")#linebreak()#text(" Every linear inequality which holds for an expression involving joint entropies of several random variables,such as the inequality ")#mi("H(X,Z)+H(Y,Z)\\ge H(X,Y,Z)+H(Z)")#text(" (equivalent to ")#mi("I(X:Y|Z)\\ge 0")#text("), automatically yields a valid inequality concerning sizes of intersections of subgroups of ")#mi("G")#text(", obtained")#linebreak()#text(" by replacing each entropy of a joint random variable ")#mi("H(X_1,X_2,\\ldots, X_k)")#text(" by ")#mi("\\textrm{codim}^G(S_1\\cap S_2\\cap \\ldots \\cap S_k)")#text(".")#linebreak()#text(" In the particular example above we obtain, after exponentiation and canceling out the ")#tao-math("\\left|G\\right|", block: false)#text(" terms, the inequality ")#tao-math("\\left|K\\cap S\\right|\\cdot \\left|H\\cap S\\right|\\le \\left|K\\cap H\\cap S\\right|\\cdot \\left|S\\right|", block: false)#text(", which can be also proved directly as follows ")#tao-math("\\left|S\\right|\\ge \\left|(K\\cap S)\\cdot (H\\cap S)\\right|=(\\left|K\\cap S\\right|\\cdot \\left|H\\cap S\\right|)/\\left|(K\\cap H\\cap S)\\right|", block: false)#text(".")

#text("Surprisingly, the group theoretic model captures ")#emph[#text("all")]#text(" non-strict linear inequalities among joint entropies of several random variables; this was proved by Chan and Yeung. The proof is actually very simple, and goes roughly as follows.")#linebreak()#text(" Suppose that there is a tuple of random variables ")#mi("X_1,\\ldots,X_n")#text(" such that some linear combination ")#mi("\\ell")#text(" of some of their joint entropies is strictly negative. By approximating, we can assume that the joint random variable ")#mi("X=(X_1,\\ldots,X_n)")#text(" has a distribution with rational coefficients. We view ")#mi("X")#text(" as a table with ")#mi("n")#text(" columns and in which each row ")#mi("r")#text(" has a rational weight ")#mi("p_r")#text(" assigned to it; the weights of all the rows add up to ")#mi("1")#text(" and we assume they have a common denominator ")#mi("q")#text(". For a large number ")#mi("k")#text(" which is a multiple of ")#mi("q")#text(", let")#linebreak()#text(" ")#mi("T")#text(" be a table with ")#mi("k")#text(" rows obtained from ")#mi("X")#text(" by replicating each row ")#mi("r")#text(" in ")#mi("k\\cdot p_r")#text(" many copies.")#linebreak()#text(" Let ")#mi("G")#text(" be the group of all permutations of the rows of the table ")#mi("T")#text(", and for ")#mi("i=1,\\ldots,n")#text(", let ")#mi("G_i\\subset G")#text(" be the subgroup consisting of those permutations ")#mi("\\pi")#text(" which preserve the value in the ")#mi("i")#text("th column, i.e., ")#mi("\\pi(r)[i]=r[i]")#text(", for each row ")#mi("r")#text(" of ")#mi("T")#text(". The group ")#mi("G")#text(" is the symmetric group on ")#mi("k")#text(" elements, and ")#mi("G_i")#text(" is a product of symmetric groups, whose size can be easily described by the distribution of the variable ")#mi("X_i")#text(". Applying Stirling’s formula we get that as ")#mi("k")#text(" goes to ")#mi("\\infty")#text(",")#linebreak()#text(" the value ")#tao-math("\\log\\left|G\\right|/\\log\\left|G_i\\right|", block: false)#text(" is asymptotically")#linebreak()#text(" equivalent to ")#mi("k\\cdot H(X_i)")#text(" and, similarly, ")#tao-math("\\log\\left|G\\right|/\\log\\left|G_{i_1}\\cap\\cdots\\cap G_{i_k}\\right|", block: false)#text(" is asymptotically equivalent to ")#mi("k\\cdot H(X_{i_1},\\ldots,X_{i_k})")#text(". In particular, for sufficiently large ")#mi("k")#text(", we obtain a group ")#mi("G")#text(" and its subgroups ")#mi("G_1,\\ldots,G_n")#text(" such that the linear combination of codimensions of group intersections")#linebreak()#text(" corresponding to ")#mi("\\ell")#text(" is strictly negative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8044d7b7e5e5b768237929bb78165d7707b8eca297f6625025d63249a68fc76-d820674b5dafb128fd0ba3c61c1938959fe0b4d3a74f009fbbe4de608ad256d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shang Shan")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479799")[#strong[#text("Shang Shan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2017")])]

#text("Prof Tao, Have you ever heard arguments that the entropy should actually have been defined as $- \\sum p ( \\ln p – 1 )$ ? I have read Shannon’s original paper, and he speaks generally, that it should be a logarithmic function. So there is no reason why he would not have defined it this way, by shifting the zero. In this way, one could accomodate the additional constraint that $\\sum p = 1$ with a Lagrange multiplier of -1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479817")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2017")])]

#text("Of course, one is free to define one’s terms however one pleases, however if one shifts the entropy, then the Shannon entropy axioms (listed on pages 392-393 of ")#link("http://ieeexplore.ieee.org/document/6773024/")[#text("Shannon’s original paper")]#text(") will be violated (in particular, axiom 3 will fail). Also, the form of many basic propeties of Shannon entropy, e.g. the entropy inequalities such as ")#mi("H(X,Y) \\leq H(X) + H(Y)")#text(", will become a bit more complicated, and the intuitive interpretation of entropy as a measure of information becomes less clear (since now an empty piece of information will have positive entropy rather than zero entropy). Also, all the dictionaries mentioned in this post become a little bit more complicated also. So there does not seem to be much to gain by shifting the entropy in this fashion.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8044d7b7e5e5b768237929bb78165d7707b8eca297f6625025d63249a68fc76-d820674b5dafb128fd0ba3c61c1938959fe0b4d3a74f009fbbe4de608ad256d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Shang Shan")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-479895")[#strong[#text("Shang Shan")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2017")])]

#text("Thank you Prof Tao.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The sunflower lemma via Shannon entropy | What's new")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-575967")[#strong[#text("The sunflower lemma via Shannon entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2020")])]

#text("[…] this previous blog post for some intuitive analogies to understand Shannon […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed997b15b527ebc749c2dd61cbc5fc4270180701e6820eb06c5786ee7fb78d2e-84d34cd3b1f6f2f63a89081b843f472f6b21cf3c533f21760864b8ecd90abe44.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Entropy Estimation via Two Chains: Streamlining the Proof of the Sunflower Lemma – Theory Dish")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-626392")[#strong[#text("Entropy Estimation via Two Chains: Streamlining the Proof of the Sunflower Lemma – Theory Dish")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2021")])]

#text("[…] of Shannon entropy are also discussed. (We also highly recommend Tao’s other blog posts about Shannon entropy and the entropy compression […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Venn and Euler type diagrams for vector spaces and abelian groups | What's new")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-636830")[#strong[#text("Venn and Euler type diagrams for vector spaces and abelian groups | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2021")])]

#text("[…] of a dimension in a vector space is analogous in many ways to that of cardinality of a set; see this previous post for an instance of this analogy (in the context of Shannon […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-657173")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2022")])]

#text("In the RHS of (5), I think you want ")#mi("\\epsilon \\log(x)")#text(" instead of ")#mi("\\epsilon x")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-684616")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2024")])]

#text("Does quantum entropy have a place in these discusssions?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-687858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2025")])]

#text("Shouldn’t the analogue of “X,Y conditionally independent relative to Z” be")

#mi("A \\cap B \\cap C = \\emptyset")#text(", or equivalently")

#mi("A \\cap B \\subseteq C^c")#text("?")

#text("We want A and B to be disjoint after restricting to C.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-687861")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2025")])]

#text("Actually, we want ")#mi("A")#text(" and ")#mi("B")#text(" to be disjoint after _deleting_ ")#mi("C")#text(" (which represents all the information that ")#mi("Z")#text(" knows about). For instance, ")#mi("X")#text(" is always conditionally independent of itself relative to ")#mi("X")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-687867")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2025")])]

#text("Ha! Oops, sorry. Maybe the fact that conditioning has the same symbol as restricting prevented me from thinking clearly…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/#comment-689274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Dr Tao,")

#text("There is one typo: “was tuple” should be “was a tuple” or “was the tuple”.")

#text("I have a question: the term “mutual information” and other terms like “information theory” include a concept that I am confused——What does “information” mean?")

#text("Also, in other fields like linear algebra, one may say words like : the nullity of T measures how much “information” is lost when applying T. But people didn’t specify what “information” means.")

#emph[#text("[Thanks for the typo. For linguistic questions of this nature, I suggest directing your query to web search engines or AI chatbots. -T]")]
]
