// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/
// Converted to Typst by tao2typ: "2026-10-14T15:21:00.137859+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A computation-outsourced discussion of zero density theorems for the Riemann zeta function", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A computation-outsourced discussion of zero density theorems for the Riemann zeta function")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 July 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/")[#text("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Many modern mathematical proofs are a combination of conceptual arguments and technical calculations. There is something of a tradeoff between the two: one can add more conceptual arguments to try to reduce the technical computations, or vice versa. (Among other things, this leads to a ")#link("https://en.wikipedia.org/wiki/Berkson%27s_paradox")[#text("Berkson paradox-like phenomenon")]#text(" in which a negative correlation can be observed between the two aspects of a proof; see ")#link("https://mathstodon.xyz/@tao/112525669406416314")[#text("this recent Mastodon post of mine")]#text(" for more discussion.)")

#text("In a ")#link("https://arxiv.org/abs/2405.04699")[#text("recent article")]#text(", Heather Macbeth argues that the preferred balance between conceptual and computational arguments is quite different for a computer-assisted proof than it is for a purely human-readable proof. In the latter, there is a strong incentive to minimize the amount of calculation to the point where it can be checked by hand, even if this requires a certain amount of ")#emph[#text("ad hoc")]#text(" rearrangement of cases, unmotivated parameter selection, or otherwise non-conceptual additions to the arguments in order to reduce the calculation. But in the former, once one is willing to outsource any tedious verification or optimization task to a computer, the incentives are reversed: freed from the need to arrange the argument to reduce the amount of calculation, one can now describe an argument by listing the main ingredients and then letting the computer figure out a suitable way to combine them to give the stated result. The two approaches can thus be viewed as complementary ways to describe a result, with neither necessarily being superior to the other.")

#text("In this post, I would like to illustrate this computation-outsourced approach with the topic of ")#emph[#text("zero-density theorems")]#text(" for the Riemann zeta function, in which all computer verifiable calculations (as well as other routine but tedious arguments) are performed “off-stage”, with the intent of focusing only on the conceptual inputs to these theorems.")

#text("Zero-density theorems concern upper bounds for the quantity ")#mi("{N(\\sigma,T)}")#text(" for a given ")#mi("{1/2 \\leq \\sigma \\leq 1}")#text(" and large ")#mi("{T}")#text(", which is defined as the number of zeroes of the Riemann zeta function in the rectangle ")#mi("{\\{ \\beta+i\\gamma: \\sigma \\leq \\beta \\leq 1; 0 \\leq \\gamma \\leq T \\}}")#text(". (There is also an important generalization of this quantity to ")#mi("{L}")#text("-functions, but for simplicity we will focus on the classical zeta function case here). Such quantities are important in analytic number theory for many reasons, one of which is through ")#link("https://en.wikipedia.org/wiki/Explicit_formulae_for_L-functions")[#text("explicit formulae")]#text(" such as the Riemann-von Mangoldt explicit formula ")#metadata(none) <tao-3b283e93debf035e990d>#mi("\\displaystyle  \\sum_{n \\leq x}^{\\prime} \\Lambda(n) = x - \\sum_{\\rho:\\zeta(\\rho)=0} \\frac{x^\\rho}{\\rho} - \\log(2\\pi) - \\frac{1}{2} \\log(1-x^{-2}) \\ \\ \\ \\ \\ (1)")#text(" ")#text(" relating the prime numbers to the zeroes of the zeta function (the “music of the primes”). The better bounds one has on ")#mi("{N(\\sigma,T)}")#text(", the more control one has on the complicated term ")#mi("{\\sum_{\\rho:\\zeta(\\rho)=0} \\frac{x^\\rho}{\\rho}}")#text(" on the right-hand side.")

#text("Clearly ")#mi("{N(\\sigma,T)}")#text(" is non-increasing in ")#mi("{\\sigma}")#text(". The ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93von_Mangoldt_formula")[#text("Riemann-von Mangoldt formula")]#text(", together with the functional equation, gives us the asymptotic")

#align(center)[#tao-fit-display[#mitex("N(1/2,T) \\asymp T \\log T")]]

#text("in the ")#mi("{\\sigma=1/2}")#text(" case, while the prime number theorem tells us that")

#metadata(none) <tao-58925ceba237648814f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("N(1,T) = 0.")]]

#text("The various zero free regions for the zeta function can be viewed as slight improvements to ")#link(<tao-58925ceba237648814f1>)[#text("(2)")]#text("; for instance, the classical zero-free region is equivalent to the assertion that ")#mi("{N(\\sigma,T)}")#text(" vanishes if ")#mi("{\\sigma > 1 - c/\\log T}")#text(" for some small absolute constant ")#mi("{c>0}")#text(", and the Riemann hypothesis is equivalent to the assertion that ")#mi("{N(\\sigma,T)=0}")#text(" for all ")#mi("{\\sigma>1/2}")#text(".")

#text("Experience has shown that the most important quantity to control here is the exponent ")#mi("{A(\\sigma)}")#text(", defined as the least constant for which one has an asymptotic")

#align(center)[#tao-fit-display[#mitex("N(\\sigma,T) = T^{A(\\sigma)(1-\\sigma)+o(1)}")]]

#text("as ")#mi("{T \\rightarrow \\infty}")#text(". Thus, for instance,")

#metadata(none) <tao-f37508d21e9ebda7c2eb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("A(1/2) = 2,")]]

#mi("{A(1) = 0}")#text(", and ")#mi("{A(\\sigma)(1-\\sigma)}")#text(" is a non-increasing function of ")#mi("{\\sigma}")#text(", so we obtain the trivial “von Mangoldt” zero density theorem")

#align(center)[#tao-fit-display[#mitex("A(\\sigma) \\leq \\frac{1}{1-\\sigma}.")]]

#text("Of particular interest is the supremal value ")#tao-math("{\\left\\|A\\right\\|_\\infty := \\sup_{1/2 \\leq \\sigma \\leq 1} A(\\sigma)}", block: false)#text(" of ")#mi("{A}")#text(", which has to be at least ")#mi("{2}")#text(" thanks to ")#link(<tao-f37508d21e9ebda7c2eb>)[#text("(3)")]#text(". The ")#emph[#text("density hypothesis")]#text(" asserts that the maximum is in fact exactly ")#mi("{2}")#text(", or equivalently that")

#metadata(none) <tao-3944783bc199f6d26205>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("A(\\sigma) \\leq 2,")]]

#text("for all ")#mi("{1/2 \\leq \\sigma \\leq 1}")#text(". This is of course implied by the Riemann hypothesis (which clearly implies that ")#mi("{A(\\sigma)=0}")#text(" for all ")#mi("{\\sigma>1/2}")#text("), but is a more tractable hypothesis to work with; for instance, the hypothesis is already known to hold for ")#mi("{\\sigma \\geq 25/32 = 0.78125}")#text(" by the ")#link("https://zbmath.org/1099.11511")[#text("work of Bourgain")]#text(" (building upon many previous authors). The quantity ")#tao-math("{\\left\\|A\\right\\|_\\infty}", block: false)#text(" directly impacts our understanding of the prime number theorem in short intervals; indeed, it is not difficult using ")#link(<tao-3b283e93debf035e990d>)[#text("(1)")]#text(" (as well as the Vinogradov-Korobov zero-free region) to establish a short interval prime number theorem")

#align(center)[#tao-fit-display[#mitex("\\sum_{x \\leq n \\leq x + x^\\theta} \\Lambda(n) = (1+o(1)) x^\\theta")]]

#text("for all ")#mi("{x \\rightarrow \\infty}")#text(" if ")#tao-math("{1 - \\frac{1}{\\left\\|A\\right\\|_\\infty} < \\theta < 1}", block: false)#text(" is a fixed exponent, or for ")#emph[#text("almost")]#text(" all ")#mi("{x \\rightarrow \\infty}")#text(" if ")#tao-math("{1 - \\frac{2}{\\left\\|A\\right\\|_\\infty} < \\theta < 1}", block: false)#text(" is a fixed exponent. Until recently, the best upper bound for ")#tao-math("{\\left\\|A\\right\\|_\\infty}", block: false)#text(" was ")#mi("{12/5 = 2.4}")#text(", thanks to a 1972 ")#link("https://zbmath.org/0268.10030")[#text("result of Huxley")]#text("; but this was recently lowered to ")#mi("{30/13=2.307\\ldots}")#text(" in a breakthrough work of ")#link("https://arxiv.org/abs/2405.20552")[#text("Guth and Maynard")]#text(".")

#text("In between the papers of Huxley and Guth-Maynard are dozens of additional improvements on ")#mi("{A(\\sigma)}")#text(", though it is only the Guth-Maynard paper that actually lowered the supremum norm ")#tao-math("{\\left\\|A\\right\\|_\\infty}", block: false)#text(". A summary of most of the state of the art before Guth-Maynard may be found in Table 2 of this recent paper of ")#link("https://arxiv.org/abs/2306.05599")[#text("Trudgian and Yang")]#text("; it is complicated, but it is easy enough to get a computer to illustrate it with a plot:")

#image("../assets/cf4502997fe6ab1a27708a0417eb0428ba56b7a9e955440d8be21fc137cf8661-6ebfc417ff7d5e1767879d6f026f00c1281cb0d3d22bc371e6dcc8f77a84231b.png", width: 90%)

#text("(For an explanation of what is going on under the assumption of the Lindelöf hypothesis, see below the fold.) This plot represents the combined effort of nearly a dozen papers, each one of which claims one or more components of the depicted piecewise smooth curve, and is written in the “human-readable” style mentioned above, where the argument is arranged to reduce the amount of tedious computation to human-verifiable levels, even if this comes the cost of obscuring the conceptual ideas. (For an animation of how this bound improved over time, see ")#link("https://mathstodon.xyz/@tao/112715720761286847")[#text("here")]#text(".) Below the fold, I will try to describe (in sketch form) some of the standard ingredients that go into these papers, in particular the routine reduction of deriving zero density estimates from large value theorems for Dirichlet series. We will not attempt to rewrite the entire literature of zero-density estimates in this fashion, but focus on some illustrative special cases.")

#metadata(none) <tao-a82735ce41f07451e4b7>

#heading(level: 1)[#strong[#text(" — 1. Zero detecting polynomials — ")]]

#text("As we are willing to lose powers of ")#mi("{T^{o(1)}}")#text(" here, it is convenient to adopt the asymptotic notation ")#mi("{X \\lessapprox Y}")#text(" (or ")#mi("{Y \\gtrapprox X}")#text(") for ")#mi("{X \\leq T^{o(1)} Y}")#text(", and similarly ")#mi("{X \\approx Y}")#text(" for ")#mi("{X \\lessapprox Y \\gtrapprox X}")#text(".")

#text("The Riemann-von Mangoldt formula implies that any unit square in the critical strip only contains ")#mi("{\\lessapprox 1}")#text(" zeroes, so for the purposes of counting ")#mi("{N(\\sigma,T)}")#text(" up to ")#mi("{T^{o(1)}}")#text(" errors, one can restrict attention to counting sets of zeroes ")#mi("{\\beta+i\\gamma}")#text(" whose imaginary parts ")#mi("{\\gamma}")#text(" are ")#mi("{1}")#text("-separated, and we will do so henceforth. By dyadic decomposition, we can also restrict attention to zeroes with imaginary part ")#mi("{\\gamma}")#text(" comparable to ")#mi("{T}")#text(" (rather than lying between ")#mi("{0}")#text(" and ")#mi("{T}")#text(".)")

#text("The ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Siegel_formula")[#text("Riemann-Siegel formula")]#text(", roughly speaking, tells us that for a zero ")#mi("{\\beta+i\\gamma}")#text(" as above, we have ")#metadata(none) <tao-e01d787649e8436c9583>#mi("\\displaystyle  \\zeta(\\beta + i \\gamma) = \\sum_{n \\leq T^{1/2}} \\frac{1}{n^{\\beta+i\\gamma}} + \\dots \\ \\ \\ \\ \\ (5)")#text(" ")#text(" plus terms which are of lower order when ")#mi("{\\beta > 1/2}")#text(". One can decompose the sum here dyadically into ")#mi("{\\approx 1}")#text(" pieces that look like")

#align(center)[#tao-fit-display[#mitex("N^{-\\beta} \\sum_{n \\sim N} \\frac{1}{n^{i\\gamma}}")]]

#text("for ")#mi("{1 \\leq N \\ll T^{1/2}}")#text(". The ")#mi("{N=1}")#text(" component of this sum is basically ")#mi("{1}")#text("; so if there is to be a zero at ")#mi("{\\beta+i\\gamma}")#text(", we expect one of the other terms to balance it out, and so we should have")

#metadata(none) <tao-fab66aa01347d3f11a16>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\sum_{n \\sim N} \\frac{1}{n^{i\\gamma}}\\right| \\gtrapprox N^\\beta \\geq N^\\sigma", block: true)]]

#text("for at least one value of ")#mi("{1 < N \\ll T^{1/2}}")#text(". In the notation of this subject, the expressions ")#mi("{\\sum_{n \\sim N} \\frac{1}{n^{it}}}")#text(" are known as ")#emph[#text("zero detecting (Dirichlet) polynomials")]#text("; the large values of such polynomials provide a set of candidates where zeroes can occur, and so upper bounding the large values of such polynomials will lead to zero density estimates.")

#text("Unfortunately, the particular choice of zero detecting polynomials described above, while simple, is not useful for applications, because the polynomials with very small values of ")#mi("{N}")#text(", say ")#mi("{N=2}")#text(", will basically obey the largeness condition ")#link(<tao-fab66aa01347d3f11a16>)[#text("(6)")]#text(" a positive fraction of the time, leading to no useful estimates. (Note that standard “square root ” heuristics suggest that the left-hand side of ")#link(<tao-fab66aa01347d3f11a16>)[#text("(6)")]#text(" should typically be of size about ")#mi("{N^{1/2}}")#text(".) However, this can be fixed by the standard device of introducing a “mollifier” to eliminate the role of small primes. There is some flexibility in what mollifier to introduce here, but a simple choice is to multiply ")#link(<tao-e01d787649e8436c9583>)[#text("(5)")]#text(" by ")#mi("{\\sum_{n \\leq T^\\varepsilon} \\frac{\\mu(n)}{n^{\\beta+i\\gamma}}}")#text(" for a small ")#mi("{\\varepsilon}")#text(", which morally speaking has the effect of eliminating the contribution of those terms ")#mi("{n}")#text(" with ")#mi("{1 < n \\leq T^\\varepsilon}")#text(", at the cost of extending the range of ")#mi("{N}")#text(" slightly from ")#mi("{T^{1/2}}")#text(" to ")#mi("{T^{1/2+\\varepsilon}}")#text(", and also introducing some error terms at scales between ")#mi("{T^\\varepsilon}")#text(" and ")#mi("{T^{2\\varepsilon}}")#text(". The upshot is that one then gets a slightly different set of zero-detecting polynomials: one family (often called “Type I”) is basically of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\sim N} \\frac{1}{n^{i\\gamma}}")]]

#text("for ")#mi("{T^\\varepsilon \\ll N \\ll T^{1/2+\\varepsilon}}")#text(", and another family (“Type II”) is of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\sim N} \\frac{a_n}{n^{i\\gamma}}")]]

#text("for ")#mi("{T^\\varepsilon \\ll N \\ll T^{2\\varepsilon}}")#text(" and some coefficients ")#mi("{a_n}")#text(" of size ")#mi("{\\lessapprox 1}")#text("; see Section 10.2 of ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" or ")#link("https://terrytao.wordpress.com/2015/02/13/254a-notes-6-large-values-of-dirichlet-polynomials-zero-density-estimates-and-primes-in-short-intervals/")[#text("these lecture notes of mine")]#text(", or Appendix 3 of ")#link("https://arxiv.org/abs/2206.11729")[#text("this recent paper of Maynard and Pratt")]#text(" for more details. It is also possible to reverse these implications and efficiently derive large values estimates from zero density theorems; see ")#link("https://arxiv.org/abs/2403.13157")[#text("this recent paper of Matomäki and Teräväinen")]#text(".")

#text("One can sometimes squeeze a small amount of mileage out of optimizing the ")#mi("{\\varepsilon}")#text(" parameter, but for the purpose of this blog post we shall just send ")#mi("{\\varepsilon}")#text(" to zero. One can then reformulate the above observations as follows. For given parameters ")#mi("{\\sigma \\geq 1/2}")#text(" and ")#mi("{\\alpha > 0}")#text(", let ")#mi("{C(\\sigma,\\alpha)}")#text(" denote the best non-negative exponent for which the following ")#emph[#text("large values estimate")]#text(" holds: given any sequence ")#mi("{a_n}")#text(" of size ")#mi("{\\lessapprox 1}")#text(", and any ")#mi("{1}")#text("-separated set of frequencies ")#mi("{t \\sim T}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\sim N} \\frac{a_n}{n^{it}}\\right| \\gtrapprox N^\\sigma", block: true)]]

#text("for some ")#mi("{N \\approx T^\\alpha}")#text(", the number of such frquencies ")#mi("{t}")#text(" does not exceed ")#mi("{T^{C(\\sigma,\\alpha)+o(1)}}")#text(". We define ")#mi("{C_1(\\sigma,\\alpha)}")#text(" similarly, but where the coefficients ")#mi("{a_n}")#text(" are also assumed to be identically ")#mi("{1}")#text(". Then clearly")

#metadata(none) <tao-93da5ae354cfd4b36b11>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("C_1(\\sigma,\\alpha) \\leq C(\\sigma,\\alpha),")]]

#text("and the above zero-detecting formalism is (morally, at least) asserting an inequality of the form")

#metadata(none) <tao-97005ed2f09d5f0e992c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("A(\\sigma)(1-\\sigma) \\leq \\max( \\sup_{0 < \\alpha \\leq 1/2} C_1(\\sigma,\\alpha), \\limsup_{\\alpha \\rightarrow 0} C(\\sigma,\\alpha) ).")]]

#text("The converse results of Matomäki and Teräväinen morally assert that this inequality is essentially an equality (there are some asterisks to this assertion which I will gloss over here). Thus, for instance, verifying the density hypothesis ")#link(<tao-3944783bc199f6d26205>)[#text("(4)")]#text(" for a given ")#mi("{\\sigma}")#text(" is now basically reduced to establishing the “Type I” bound")

#metadata(none) <tao-d4332469d7342f3df939>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("C_1(\\sigma,\\alpha) \\leq 2 (1-\\sigma)")]]

#text("for all ")#mi("{0 < \\alpha \\leq 1/2}")#text(", as well as the “Type II” variant")

#metadata(none) <tao-170e20133e2249637090>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("C(\\sigma,\\alpha) \\leq 2 (1-\\sigma) + o(1)")]]

#text("as ")#mi("{\\alpha \\rightarrow 0^+}")#text(".")

#text("As we shall see, the Type II task of controlling ")#mi("{C(\\sigma,\\alpha)}")#text(" for small ")#mi("{\\alpha}")#text(" is relatively well understood (in particular, ")#link(<tao-170e20133e2249637090>)[#text("(10)")]#text(" is already known to hold for all ")#mi("{1/2 \\leq \\sigma \\leq 1}")#text(", so in some sense the “Type II” half of the density hypothesis is already established); the main difficulty is with the Type I task, with the main difficulty being that the parameter ")#mi("{\\alpha}")#text(" (representing the length of the Dirichlet series) is often in an unfavorable location.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The approximate functional equation for the Riemann zeta function morally tells us that ")#mi("{C_1(\\sigma,\\alpha) = C_1(1/2 + \\frac{\\alpha}{1-\\alpha}(\\sigma-1/2),1-\\alpha)}")#text(", but we will not have much use for this symmetry since we have in some sense already incorporated it (via the Riemann-Siegel formula) into the condition ")#mi("{\\alpha \\leq 1/2}")#text(".")
]

#text("The standard ")#emph[#mi("{L^2}")#text(" mean value theorem")]#text(" for Dirichlet series tells us that a Dirichlet polynomial ")#mi("{\\sum_{n \\sim N} \\frac{a_n}{n^{it}}}")#text(" with ")#mi("{a_n \\lessapprox 1}")#text(" has an ")#mi("{L^2}")#text(" mean value of ")#mi("{\\lessapprox N^{1/2}}")#text(" on any interval of length ")#mi("{N}")#text(", and similarly if we discretize ")#mi("{t}")#text(" to a ")#mi("{1}")#text("-separated subset of that interval; this is easily established by using the approximate orthogonality properties of the function ")#mi("{t \\mapsto \\frac{1}{n^{it}}}")#text(" on such an interval. Since an interval of length ")#mi("{T}")#text(" can be subdivided into ")#mi("{O( (N+T)/N )}")#text(" intervals of length ")#mi("{N}")#text(", we see from the Chebyshev inequality that such a polynomial can only exceed ")#mi("{\\gtrapprox N^\\sigma}")#text(" on a ")#mi("{1}")#text("-separated subset of a length ")#mi("{T}")#text(" interval of size ")#mi("{\\lessapprox (N+T)/N \\times N \\times N^{1-2\\sigma}}")#text(", which we can formalize in terms of the ")#mi("{C(\\sigma,\\alpha)}")#text(" notation as ")#metadata(none) <tao-8a1cee436cbac1489a18>#mi("\\displaystyle  C(\\sigma,\\alpha) \\leq \\min((2-2\\sigma)\\alpha, 1 + (1-2\\sigma)\\alpha). \\ \\ \\ \\ \\ (11)")#text(" ")#text(" For instance, this (and ")#link(<tao-93da5ae354cfd4b36b11>)[#text("(7)")]#text(") already give the density hypothesis-strength bound ")#link(<tao-d4332469d7342f3df939>)[#text("(9)")]#text(" – but only at ")#mi("{\\alpha = 1}")#text(". This initially looks useless, since we are restricting ")#mi("{\\alpha}")#text(" to the range ")#mi("{0 \\leq \\alpha \\leq 1}")#text("; but there is a simple trick that allows one to greatly amplify this bound (as well as many other large values bounds). Namely, if one raises a Dirichlet series ")#mi("{\\sum_{n \\sim N} \\frac{a_n}{n^{it}}}")#text(" with ")#mi("{a_n \\lessapprox 1}")#text(" to some natural number power ")#mi("{k}")#text(", then one obtains another Dirichlet series ")#mi("{\\sum_{n \\sim N^k} \\frac{b_n}{n^{it}}}")#text(" with ")#mi("{b_n \\lessapprox 1}")#text(", but now at length ")#mi("{N^k}")#text(" instead of ")#mi("{N}")#text(". This can be encoded in terms of the ")#mi("{C(\\sigma,\\alpha)}")#text(" notation as the inequality ")#metadata(none) <tao-07d715edb696fb5f628f>#mi("\\displaystyle  C(\\sigma,\\alpha) \\leq C(\\sigma,k\\alpha) \\ \\ \\ \\ \\ (12)")#text(" ")#text(" for any natural number ")#mi("{k \\geq 1}")#text(". It would be very convenient if we could remove the restriction that ")#mi("{k}")#text(" be a natural number here; there is a conjecture of Montgomery in this regard, but it is out of reach of current methods (it was observed by in ")#link("https://zbmath.org/0776.30003")[#text("this paper of Bourgain")]#text(" that it would imply the Kakeya conjecture!). Nevertheless, the relation ")#link(<tao-07d715edb696fb5f628f>)[#text("(12)")]#text(" is already quite useful. Firstly, it can easily be used to imply the Type II case ")#link(<tao-170e20133e2249637090>)[#text("(10)")]#text(" of the density hypothesis, and also implies the Type I case ")#link(<tao-d4332469d7342f3df939>)[#text("(9)")]#text(" as long as ")#mi("{\\alpha}")#text(" is of the special form ")#mi("{\\alpha = 1/k}")#text(" for some natural number ")#mi("{k}")#text(". Rather than give a human-readable proof of this routine implication, let me illustrate it instead with a graph of what the best bound one can obtain for ")#mi("{C(\\sigma,\\alpha)}")#text(" becomes for ")#mi("{\\sigma=3/4}")#text(", just using ")#link(<tao-8a1cee436cbac1489a18>)[#text("(11)")]#text(" and ")#link(<tao-07d715edb696fb5f628f>)[#text("(12)")]#text(":")

#image("../assets/ad1e400e5c18350290f1495595ca91ebc2836108110d07a2c408880724ff3a66-33c97adc9a68b7548ab7c9a34c1fec58c7a819cb7a8228390ace5edbccf89b0f.png", width: 90%)

#text("Here we see that the bound for ")#mi("{C(\\sigma,\\alpha)}")#text(" oscillates between the density hypothesis prediction of ")#mi("{2(1-\\sigma)=1/2}")#text(" (which is attained when ")#mi("{\\alpha=1/k}")#text("), and a weaker upper bound of ")#mi("{\\frac{12}{5}(1-\\sigma) = 0.6}")#text(", which thanks to ")#link(<tao-93da5ae354cfd4b36b11>)[#text("(7)")]#text(", ")#link(<tao-97005ed2f09d5f0e992c>)[#text("(8)")]#text(" gives the upper bound ")#mi("{A(3/4) \\leq \\frac{12}{5}}")#text(" that was first established in 1937 ")#link("https://zbmath.org/66.0341.02")[#text("by Ingham")]#text(" (in the style of a human-readable proof without computer assistance, of course). The same argument applies for all ")#mi("{1/2 \\leq \\sigma \\leq 1}")#text(", and gives rise to the bound ")#mi("{A(\\sigma) \\leq \\frac{3}{2-\\sigma}}")#text(" in this interval, beating the trivial von Mangoldt bound of ")#mi("{A(\\sigma) \\leq \\frac{1}{1-\\sigma}}")#text(":")

#image("../assets/018054b8c48da3f1c6cb0a192ce6025942c2192ff02626165bb30feaa14eea7a-474cb220383b04802092629b234a0166a2f794c481fdc61593fcb26b6374f0e2.png", width: 90%)

#text("The method is flexible, and one can insert further bounds or hypotheses to improve the situation. For instance, the ")#link("https://en.wikipedia.org/wiki/Lindel%C3%B6f_hypothesis")[#text("Lindelöf hypothesis")]#text(" asserts that ")#mi("{\\zeta(1/2+it) \\lessapprox 1}")#text(" for all ")#mi("{0 \\leq t \\leq T}")#text(", which on dyadic decomposition can be shown to give the bound ")#metadata(none) <tao-c28f28a284eadc147f0a>#mi("\\displaystyle  \\sum_{n \\sim N} \\frac{1}{n^{it}} \\lessapprox N^{1/2} \\ \\ \\ \\ \\ (13)")#text(" ")#text(" for all ")#mi("{N \\approx T^\\alpha}")#text(" and all fixed ")#mi("{0 < \\alpha < 1}")#text(" (in fact this hypothesis is basically equivalent to this estimate). In particular, one has ")#metadata(none) <tao-a9f615c4e7d33cf9a6a2>#mi("\\displaystyle  C_1(\\sigma,\\alpha)=0 \\ \\ \\ \\ \\ (14)")#text(" ")#text(" for any ")#mi("{\\sigma > 1/2}")#text(" and ")#mi("{\\alpha > 0}")#text(". In particular, the Type I estimate ")#link(<tao-d4332469d7342f3df939>)[#text("(9)")]#text(" now holds for all ")#mi("{\\sigma>1/2}")#text(", and so the Lindeöf hypothesis implies the Density hypothesis.")

#text("In fact, as observed ")#link("https://zbmath.org/0174.08101")[#text("by Hálasz and Turán in 1969")]#text(", the Lindelöf hypothesis also gives good Type II control in the regime ")#mi("{\\sigma > 3/4}")#text(". The key point here is that the bound ")#link(<tao-c28f28a284eadc147f0a>)[#text("(13)")]#text(" basically asserts that the functions ")#mi("{n \\mapsto \\frac{1}{n^{it}}}")#text(" behave like orthogonal functions on the range ")#mi("{n \\sim N}")#text(", and this together with a standard duality argument (related to the Bessel inequality, the large sieve, or the ")#mi("{TT^*}")#text(" method in harmonic analysis) lets one control the large values of Dirichlet series, with the upshot here being that")

#align(center)[#tao-fit-display[#mitex("C(\\sigma,\\alpha)=0")]]

#text("for all ")#mi("{\\sigma > 3/4}")#text(" and ")#mi("{\\alpha > 0}")#text(". This lets one go beyond the density hypothesis for ")#mi("{\\sigma>3/4}")#text(" and in fact obtain ")#mi("{A(\\sigma)=0}")#text(" in this case.")

#text("While we are not close to proving the full strength of ")#link(<tao-c28f28a284eadc147f0a>)[#text("(13)")]#text(", the theory of exponential sums gives us some relatively good control on the left-hand side in some cases. For instance, by using van der Corput estimates on ")#link(<tao-c28f28a284eadc147f0a>)[#text("(13)")]#text(", ")#link("https://zbmath.org/0204.37401")[#text("Montgomery in 1969")]#text(" was able to obtain an unconditional estimate which in our notation would be ")#metadata(none) <tao-8eec61de8302ca2ca160>#mi("\\displaystyle  C(\\sigma,\\alpha) \\leq (2 - 2 \\sigma) \\alpha \\ \\ \\ \\ \\ (15)")#text(" ")#text(" whenever ")#mi("{\\sigma > \\frac{1}{2} + \\frac{1}{4\\alpha}}")#text(". This is already enough to give some improvements to Ingham’s bound for very large ")#mi("{\\sigma}")#text(". But one can do better by a simple subdivision observation of Huxley (which was already implicitly used to prove ")#link(<tao-8a1cee436cbac1489a18>)[#text("(11)")]#text("): a large values estimate on an interval of size ")#mi("{T}")#text(" automatically implies a large values estimate on a longer interval of size ")#mi("{T^{\\prime}}")#text(", simply by covering the latter interval by ")#mi("{O(T^{\\prime}/T)}")#text(" intervals. This observation can be formalized as a general inequality ")#metadata(none) <tao-9a80b44788374fb621b4>#mi("\\displaystyle  C(\\sigma,\\alpha^{\\prime}) \\leq 1 - \\frac{\\alpha^{\\prime}}{\\alpha} + \\frac{\\alpha^{\\prime}}{\\alpha} C(\\sigma,\\alpha) \\ \\ \\ \\ \\ (16)")#text(" ")#text(" whenever ")#mi("{1/2 \\leq \\sigma \\leq 1}")#text(" and ")#mi("{0 < \\alpha^{\\prime} \\leq \\alpha \\leq 1}")#text("; that is to say, the quantity ")#mi("{(1-C(\\sigma\\alpha))/\\alpha}")#text(" is non-decreasing in ")#mi("{\\alpha}")#text(". This leads to the ")#emph[#text("Huxley large values inequality")]#text(", which in our notation asserts that ")#metadata(none) <tao-db3bed3d1ea3c3cbece3>#mi("\\displaystyle  C(\\sigma,\\alpha) \\leq \\min((2-2\\sigma)\\alpha, 1 + (4-6\\sigma)\\alpha) \\ \\ \\ \\ \\ (17)")#text(" ")#text(" for all ")#mi("{1/2 \\leq \\sigma \\leq 1}")#text(" and ")#mi("{\\alpha>0}")#text(", which is superior to ")#link(<tao-8a1cee436cbac1489a18>)[#text("(11)")]#text(" when ")#mi("{\\sigma > 3/4}")#text(". If one simply adds either Montgomery’s inequality ")#link(<tao-8eec61de8302ca2ca160>)[#text("(15)")]#text(", or Huxley’s extension inequality ")#link(<tao-db3bed3d1ea3c3cbece3>)[#text("(17)")]#text(", into the previous pool and asks the computer to optimize the bounds on ")#mi("{A(\\sigma)}")#text(" as a consequence, one obtains the following graph:")

#image("../assets/06c53bc51cf5fb1a67ca4081dc88b53a91f2718177dfc402795a904743d725d9-da9afbe170caf16e6246e826807a13cbfda164867f11a317d5187d6b629a20ba.png", width: 90%)

#text("In particular, the density hypothesis is now established for all ")#mi("{\\sigma > 5/6 = 0.833\\dots}")#text(". But one can do better. Consider for instance the case of ")#mi("{\\sigma=0.9}")#text(". Let us inspect the current best bounds on ")#mi("{C_1(\\sigma,\\alpha)}")#text(" from the current tools:")

#image("../assets/b607f85b9fd6fc1c17662f7eb3a2417d3932bf49b4a14d06e1f956d608f59b27-f5ecd156bb3ab0f03591c5e6baa8d0862df518df6ee400aa3c0a632880fd838f.png", width: 90%)

#text("Here we immediately see that it is only the ")#mi("{\\alpha=0.5}")#text(" case that is preventing us from improving the bound on ")#mi("{A(0.9)}")#text(" to below the density hypothesis prediction of ")#mi("{2(1-\\sigma) = 0.2}")#text(". However, it is possible to exclude this case through exponential sum estimates. In particular, the van der Corput inequality can be used to establish the bound ")#mi("{\\zeta(1/2+it) \\lessapprox T^{1/6}}")#text(" for ")#mi("{t \\lessapprox T}")#text(", or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\sim N} \\frac{1}{n^{it}} \\lessapprox N^{1/2} T^{1/6}")]]

#text("for ")#mi("{N \\lessapprox T}")#text("; this already shows that ")#mi("{C_1(\\sigma,\\alpha)}")#text(" vanishes unless")

#metadata(none) <tao-863066fb08f926d3e39a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\alpha \\leq \\frac{1}{6(\\sigma-1/2)},")]]

#text("which improves upon the existing restriction ")#mi("{\\alpha \\leq 1/2}")#text(" when ")#mi("{\\sigma > 5/6}")#text(". If one inserts this new constraint into the pool, we recover the full strength of the Huxley bound")

#metadata(none) <tao-2dfc18f170434d8a6189>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("A(\\sigma) \\leq \\frac{3}{3\\sigma-1},")]]

#text("valid for all ")#mi("{1/2 \\leq \\sigma \\leq 1}")#text(", and which improves upon the Ingham bound for ")#mi("{3/4 \\leq \\sigma \\leq 1}")#text(":")

#image("../assets/0c0e3ce339b1a7ae55dfc7877a6f4ec2aeb9d7bca9039ef4432e0cc56e10b779-041086e8c83b91091d550b4dd5d13e63cd8fbc5bfb75822030116b4636e2fe5c.png", width: 90%)

#text("One can continue importing in additional large values estimates into this framework to obtain new zero density theorems. For instance, one could insert the twelfth moment estimate ")#link("https://zbmath.org/0394.10020")[#text("of Heath-Brown")]#text(", which in our language asserts that ")#mi("{C_1(\\sigma,\\alpha) \\leq 2 + (6-12\\sigma) \\alpha}")#text("; one could also insert variants of the van der Corput estimate, such as bounds coming from other exponent pairs, the Vinogradov mean value theorem or (more recently) the resolution of the Vinogradov main conjecture ")#link("https://zbmath.org/1408.11083")[#text("by Bourgain-Demeter-Guth")]#text(" using decoupling methods, or ")#link("https://zbmath.org/1456.11149")[#text("by Wooley")]#text(" using efficient congruencing methods. We close with an example from the Guth-Maynard paper. Their main technical estimate is to establish a new large values theorem (Proposition 3.1 from ")#link("https://arxiv.org/abs/2405.20552")[#text("their paper")]#text("), which in our notation asserts that ")#metadata(none) <tao-55fafa646c7783954981>#mi("\\displaystyle  C(\\sigma,\\alpha) \\leq 1 + (\\frac{12}{5}-4\\sigma)\\alpha \\ \\ \\ \\ \\ (20)")#text(" ")#text(" whenever ")#mi("{0.7 \\leq \\sigma \\leq 0.8}")#text(" and ")#mi("{\\alpha = \\frac{5}{6}}")#text(". By subdivision ")#link(<tao-9a80b44788374fb621b4>)[#text("(16)")]#text(", one also automatically obtains the same bound for ")#mi("{0 < \\alpha \\leq \\frac{5}{6}}")#text(" as well. If one drops this estimate into the mix, one obtains the Guth-Maynard addition ")#metadata(none) <tao-473fd7f90806306ee092>#mi("\\displaystyle  A(\\sigma) \\leq \\frac{15}{3+5\\sigma} \\ \\ \\ \\ \\ (21)")#text(" ")#text(" to the Ingham and Huxley bounds (which are in fact valid for all ")#mi("{1/2 \\leq \\sigma \\leq 3/4}")#text(", but only novel in the interval ")#mi("{0.7 \\leq \\sigma \\leq 0.8}")#text("):")

#image("../assets/14f23d809acdc60ea18bbbfb4145fd3bc49122df90f04c38d7fecb6ee361b9cc-d2b37409c820565345a3aaa7bb03d9c1bd654bf7ffbb13da1200a6b06b7b984d.png", width: 90%)

#text("This is not the most difficult (or novel) part of the Guth-Maynard paper – the proof of ")#link(<tao-55fafa646c7783954981>)[#text("(20)")]#text(" occupies about 34 of the 48 pages of the paper – but it hopefully illustrates how some of the more routine portions of this type of work can be outsourced to a computer, at least if one is willing to be convinced purely by numerically produced graphs. Also, it is possible to transfer even more of the Guth-Maynard paper to this format, if one introduces an additional quantity ")#mi("{C^*(\\sigma,\\alpha)}")#text(" that tracks not the number of large values of a Dirichlet series, but rather its energy, and interpreting several of the key sub-propositions of that paper as providing inequalities relating ")#mi("{C(\\sigma,\\alpha)}")#text(" and ")#mi("{C^*(\\sigma,\\alpha)}")#text(" (this builds upon an ")#link("https://zbmath.org/0393.10043")[#text("earlier paper of Heath-Brown")]#text(" that was the first to introduce non-trivial inequalities of this type).")

#text("The above graphs were produced by myself using some quite crude Python code (with a small amount of AI assistance, for instance via Github Copilot); the code does not actually “prove” estimates such as ")#link(<tao-2dfc18f170434d8a6189>)[#text("(19)")]#text(" or ")#link(<tao-473fd7f90806306ee092>)[#text("(21)")]#text(" to infinite accuracy, but rather to any specified finite accuracy, although one can at least make the bounds completely rigorous by discretizing using a mesh of rational numbers (which can be manipulated to infinite precision) and using the monotonicity properties of the various functions involved to control errors. In principle, it should be possible to create software that would work “symbolically” rather than “numerically”, and output (human-readable) proof certificates of bounds such as ")#link(<tao-473fd7f90806306ee092>)[#text("(21)")]#text(" from prior estimates such as ")#link(<tao-55fafa646c7783954981>)[#text("(20)")]#text(" to infinite accuracy, in some formal proof verification language (e.g., Lean). Such a tool could potentially shorten the primary component of papers of this type, which would then focus on the main inputs to a standard inequality-chasing framework, rather than the routine execution of that framework which could then be deferred to an appendix or some computer-produced file. It seems that such a tool is now feasible (particularly with the potential of deploying AI tools to locate proof certificates in some tricky cases), and would be useful for many other analysis arguments involving explicit exponents than the zero-density example presented here (e.g., a version of this could have been useful to optimize constants in the recent resolution of the PFR conjecture), though perhaps the more practical workflow case for now is to use the finite-precision numerics approach to locate the correct conclusions and intermediate inequalities, and then prove those claims rigorously by hand.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-685295")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2024")])]

#text("Regarding the last paragraph, if two numbers a, b to be compared can be expressed as the solution of a system of polynomials on real variables, then a real algebraic number arithmetic package can be used to decide whether a < b in an exact way (no approximation). For example see ")#link("https://www-sop.inria.fr/galaad/logiciels/synaps/Algebraic.html")[#text("https://www-sop.inria.fr/galaad/logiciels/synaps/Algebraic.html")]#text(" and ")#link("https://mathoverflow.net/questions/116069/exact-arithmetic-for-real-algebraic-numbers")[#text("https://mathoverflow.net/questions/116069/exact-arithmetic-for-real-algebraic-numbers")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-685301")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("and {A(sigma)(1-sigma)} is a non-decreasing function of {sigma}")
]

#text("Perhaps non-increasing?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-685304")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2024")])]

#text("…Appendix 3 of this recent paper of Maynard and *Pratt*")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/299cf347497591e2825a98fe3ed4bfd64279952115afbb4130aa0182d43874c0-8464bd819c940e65b941c9e38aecf394aba5dbab4b860bb4703a6f35032fa8ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Một bước tiến trong chứng minh giả thuyết Riemann của Maynard và Guth | Blog Toán Học")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-685341")[#strong[#text("Một bước tiến trong chứng minh giả thuyết Riemann của Maynard và Guth | Blog Toán Học")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2024")])]

#text("[…] 09/07/2024: Tao vừa có một bài chi tiết hơn trên blog của anh […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-685343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2024")])]

#text("i have interest of prime fractions and prime decimals as where I’m finishing up prep for final exams on corseras Exploring Quantum Physics so adequate understanding is above par to say on also a reddit rant post an then seeing moderators erase and destroy innovation in actions just mostly good to see the tasks of rieman solutions are of interests to others")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-685360")[#strong[#text("Few disjoint thoughts collating number theory – SMCL")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")]

#text("[…] estimates for Dirichlet polynomials (talks here and here). More recently, an expository article by Terry on using graphs to collate improved bounds across the literature, by taking a specific […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-685441")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2024")])]

#text("Again regarding last paragraph, the work of Chee Yap’s Exact Geometric Computation group may be relevant: ")#link("https://cs.nyu.edu/~exact/")[#text("https://cs.nyu.edu/~exact/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of New exponent pairs, zero density estimates, and zero additive energy estimates: a systematic approach | What's new")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-687130")[#strong[#text("New exponent pairs, zero density estimates, and zero additive energy estimates: a systematic approach | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2025")])]

#text("[…] energy estimates: a systematic approach“. This paper launches a project envisioned in this previous blog post, in which the (widely dispersed) literature on various exponents in classical analytic number […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f41ce141635328694bcab5ca037c55a5527e176372e014af91c93f4299e2bf16-caa3b021bd49ec87699f797be038e6a10f47387f23e1eb9488ece74075bd2fc1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dependablemaker62b1f1de42")]], [#link("https://terrytao.wordpress.com/2024/07/07/a-computation-outsourced-discussion-of-zero-density-theorems-for-the-riemann-zeta-function/#comment-688708")[#strong[#text("dependablemaker62b1f1de42")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2025")])]

#text("Dear Prof. Tao,")#linebreak()#text("I have been testing a drift/coverage framework for ζ(s). For truncated Euler products I consistently observe that")#linebreak()#text("|ζ(σ+it)| ≤ q · |ζ(1/2+it)| with q<1,")#linebreak()#text("uniformly when σ≠1/2 above some height. This looks like a potential-type inequality that forces all nontrivial zeros onto the critical line. Do you think such a lemma could be phrased in the classical analytic number theory language (explicit formulas, mollifiers), or connected to your work on pair correlations?")#linebreak()#text("Best regards,")#linebreak()#text("Volkan TÜRKBAY – Eskişehir / TÜRKİYE")
]
