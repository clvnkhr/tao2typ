// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/
// Converted to Typst by tao2typ: "2026-10-14T15:20:48.435369+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Bayesian probability worksheet", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Bayesian probability worksheet")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 October 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/")[#text("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is a spinoff from ")#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/")[#text("the previous post")]#text(". In that post, we remarked that whenever one receives a new piece of information ")#mi("{E}")#text(", the prior ")#link("https://en.wikipedia.org/wiki/Odds")[#text("odds")]#text(" ")#mi("{\\mathop{\\bf P}( H_1 ) / \\mathop{\\bf P}( H_0 )}")#text(" between an ")#link("https://en.wikipedia.org/wiki/Null_hypothesis")[#text("alternative hypothesis")]#text(" ")#mi("{H_1}")#text(" and a ")#link("https://en.wikipedia.org/wiki/Null_hypothesis")[#text("null hypothesis")]#text(" ")#mi("{H_0}")#text(" is updated to a posterior odds ")#mi("{\\mathop{\\bf P}( H_1|E ) / \\mathop{\\bf P}( H_0|E )}")#text(", which can be computed via Bayes’ theorem by the formula")

#align(center)[#tao-fit-display[#mitex("\\frac{\\mathop{\\bf P}( H_1|E )}{\\mathop{\\bf P}(H_0|E)} = \\frac{\\mathop{\\bf P}(H_1)}{\\mathop{\\bf P}(H_0)} \\times \\frac{\\mathop{\\bf P}(E|H_1)}{\\mathop{\\bf P}(E|H_0)}")]]

#text("where ")#mi("{\\mathop{\\bf P}(E|H_1)}")#text(" is the likelihood of this information ")#mi("{E}")#text(" under the alternative hypothesis ")#mi("{H_1}")#text(", and ")#mi("{\\mathop{\\bf P}(E|H_0)}")#text(" is the likelihood of this information ")#mi("{E}")#text(" under the null hypothesis ")#mi("{H_0}")#text(". If there are no other hypotheses under consideration, then the two posterior probabilities ")#mi("{\\mathop{\\bf P}( H_1|E )}")#text(", ")#mi("{\\mathop{\\bf P}( H_0|E )}")#text(" must add up to one, and so can be recovered from the posterior odds ")#mi("{o := \\frac{\\mathop{\\bf P}( H_1|E )}{\\mathop{\\bf P}(H_0|E)}}")#text(" by the formulae")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf P}(H_1|E) = \\frac{o}{1+o}; \\quad \\mathop{\\bf P}(H_0|E) = \\frac{1}{1+o}.")]]

#text("This gives a straightforward way to update one’s prior probabilities, and I thought I would present it in the form of a worksheet for ease of calculation:")

#image("../assets/2c420d61866a4b9c9eb3781fa333d6f71befb217929f308550769bcd99c2336b-d077a29a52d4ae302065fcf04f4452bfd683276402d6cb37970b15e0227db5b8.png", width: 90%)

#text("A PDF version of the worksheet and instructions ")#link("https://terrytao.wordpress.com/wp-content/uploads/2022/10/worksheet.pdf")[#text("can be found here")]#text(". One can fill in this worksheet in the following order:")

#enum(start: 1, 
[#text("In Box 1, one enters in the precise statement of the null hypothesis ")#mi("{H_0}")#text(".")],
[#text("In Box 2, one enters in the precise statement of the alternative hypothesis ")#mi("{H_1}")#text(". (This step is ")#emph[#text("very important")]#text("! As discussed in the previous post, Bayesian calculations can become extremely inaccurate if the alternative hypothesis is vague.)")],
[#text("In Box 3, one enters in the prior probability ")#mi("{\\mathop{\\bf P}(H_0)}")#text(" (or the best estimate thereof) of the null hypothesis ")#mi("{H_0}")#text(".")],
[#text("In Box 4, one enters in the prior probability ")#mi("{\\mathop{\\bf P}(H_1)}")#text(" (or the best estimate thereof) of the alternative hypothesis ")#mi("{H_1}")#text(". If only two hypotheses are being considered, we of course have ")#mi("{\\mathop{\\bf P}(H_1) = 1 - \\mathop{\\bf P}(H_0)}")#text(".")],
[#text("In Box 5, one enters in the ratio ")#mi("{\\mathop{\\bf P}(H_1)/\\mathop{\\bf P}(H_0)}")#text(" between Box 4 and Box 3.")],
[#text("In Box 6, one enters in the precise new information ")#mi("{E}")#text(" that one has acquired since the prior state. (As discussed in the previous post, it is important that all relevant information ")#mi("{E}")#text(" – both supporting and invalidating the alternative hypothesis – are reported accurately. If one cannot be certain that key information has not been withheld to you, then Bayesian calculations become highly unreliable.)")],
[#text("In Box 7, one enters in the likelihood ")#mi("{\\mathop{\\bf P}(E|H_0)}")#text(" (or the best estimate thereof) of the new information ")#mi("{E}")#text(" under the null hypothesis ")#mi("{H_0}")#text(".")],
[#text("In Box 8, one enters in the likelihood ")#mi("{\\mathop{\\bf P}(E|H_1)}")#text(" (or the best estimate thereof) of the new information ")#mi("{E}")#text(" under the alternative hypothesis ")#mi("{H_1}")#text(". (This can be difficult to compute, particularly if ")#mi("{H_1}")#text(" is not specified precisely.)")],
[#text("In Box 9, one enters in the ratio ")#mi("{\\mathop{\\bf P}(E|H_1)/\\mathop{\\bf P}(E|H_0)}")#text(" between Box 8 and Box 7.")],
[#text("In Box 10, one enters in the product of Box 5 and Box 9.")],
[#text("(Assuming there are no other hypotheses than ")#mi("{H_0}")#text(" and ")#mi("{H_1}")#text(") In Box 11, enter in ")#mi("{1}")#text(" divided by ")#mi("{1}")#text(" plus Box 10.")],
[#text("(Assuming there are no other hypotheses than ")#mi("{H_0}")#text(" and ")#mi("{H_1}")#text(") In Box 12, enter in Box 10 divided by ")#mi("{1}")#text(" plus Box 10. (Alternatively, one can enter in ")#mi("{1}")#text(" minus Box 11.)")]
)

#text("To illustrate this procedure, let us consider a standard Bayesian update problem. Suppose that a given point in time, ")#mi("{2\\%}")#text(" of the population is infected with COVID-19. In response to this, a company mandates COVID-19 testing of its workforce, using a cheap COVID-19 test. This test has a ")#mi("{20\\%}")#text(" chance of a false negative (testing negative when one has COVID) and a ")#mi("{5\\%}")#text(" chance of a false positive (testing positive when one does not have COVID). An employee ")#mi("{X}")#text(" takes the mandatory test, which turns out to be positive. What is the probability that ")#mi("{X}")#text(" actually has COVID?")

#text("We can fill out the entries in the worksheet one at a time:")

#list(
[#text("Box 1: The null hypothesis ")#mi("{H_0}")#text(" is that ")#mi("{X}")#text(" does not have COVID.")],
[#text("Box 2: The alternative hypothesis ")#mi("{H_1}")#text(" is that ")#mi("{X}")#text(" does have COVID.")],
[#text("Box 3: In the absence of any better information, the prior probability ")#mi("{\\mathop{\\bf P}(H_0)}")#text(" of the null hypothesis is ")#mi("{98\\%}")#text(", or ")#mi("{0.98}")#text(".")],
[#text("Box 4: Similarly, the prior probability ")#mi("{\\mathop{\\bf P}(H_1)}")#text(" of the alternative hypothesis is ")#mi("{2\\%}")#text(", or ")#mi("{0.02}")#text(".")],
[#text("Box 5: The prior odds ")#mi("{\\mathop{\\bf P}(H_1)/\\mathop{\\bf P}(H_0)}")#text(" are ")#mi("{0.02/0.98 \\approx 0.02}")#text(".")],
[#text("Box 6: The new information ")#mi("{E}")#text(" is that ")#mi("{X}")#text(" has tested positive for COVID.")],
[#text("Box 7: The likelihood ")#mi("{\\mathop{\\bf P}(E|H_0)}")#text(" of ")#mi("{E}")#text(" under the null hypothesis is ")#mi("{5\\%}")#text(", or ")#mi("{0.05}")#text(" (the false positive rate).")],
[#text("Box 8: The likelihood ")#mi("{\\mathop{\\bf P}(E|H_1)}")#text(" of ")#mi("{E}")#text(" under the alternative is ")#mi("{80\\%}")#text(", or ")#mi("{0.8}")#text(" (one minus the false negative rate).")],
[#text("Box 9: The likelihood ratio ")#mi("{\\mathop{\\bf P}(E|H_1)/\\mathop{\\bf P}(E|H_0)}")#text(" is ")#mi("{0.8 / 0.05 = 16}")#text(".")],
[#text("Box 10: The product of Box 5 and Box 9 is approximately ")#mi("{0.32}")#text(".")],
[#text("Box 11: The posterior probability ")#mi("{\\mathop{\\bf P}(H_0|E)}")#text(" is approximately ")#mi("{1/(1+0.32) \\approx 75\\%}")#text(".")],
[#text("Box 12: The posterior probability ")#mi("{\\mathop{\\bf P}(H_1|E)}")#text(" is approximately ")#mi("{0.32/(1+0.32) \\approx 25\\%}")#text(".")]
)

#text("The filled worksheet looks like this:")

#image("../assets/9fdc3dd7d2227e3a3e8018aaf355fc033a02f319c551b2b77db48943e897d6f3-2e27630cc62dceadbef8478413c681fd5b1f4eb90cd6ee712863f7fdb4e35a74.png", width: 90%)

#text("Perhaps surprisingly, despite the positive COVID test, the employee ")#mi("{X}")#text(" only has a ")#mi("{25\\%}")#text(" chance of actually having COVID! This is due to the relatively large false positive rate of this cheap test, and is an illustration of the ")#link("https://en.wikipedia.org/wiki/Base_rate_fallacy")[#text("base rate fallacy")]#text(" in statistics.")

#text("We remark that if we switch the roles of the null hypothesis and alternative hypothesis, then some of the odds in the worksheet change, but the ultimate conclusions remain unchanged:")

#image("../assets/f41449899ee25aed88bbbc3fde9524ef95b8249746f2a25644dca8c84eba91e7-ff7187cbab272a8bbf45276fc52072fd076bbbd6015671f37b42be16054cf0fc.png", width: 90%)

#text("So the question of which hypothesis to designate as the null hypothesis and which one to designate as the alternative hypothesis is largely a matter of convention.")

#text("Now let us take a superficially similar situation in which a mother observers her daughter exhibiting COVID-like symptoms, to the point where she estimates the probability of her daughter having COVID at ")#mi("{50\\%}")#text(". She then administers the same cheap COVID-19 test as before, which returns positive. What is the posterior probability of her daughter having COVID?")

#text("One can fill out the worksheet much as before, but now with the prior probability of the alternative hypothesis raised from ")#mi("{2\\%}")#text(" to ")#mi("{50\\%}")#text(" (and the prior probablity of the null hypothesis dropping from ")#mi("{98\\%}")#text(" to ")#mi("{50\\%}")#text("). One now gets that the probability that the daughter has COVID has increased all the way to ")#mi("{94\\%}")#text(":")

#image("../assets/03da00937be76d7997b5ccf4f6d58a3130db24bfff4134238316586644a47442-292bfc877692d57b8696f6d8746dea0b2b7fd47b944f7f9af564365c698686eb.png", width: 90%)

#text("Thus we see that prior probabilities can make a significant impact on the posterior probabilities.")

#text("Now we use the worksheet to analyze an infamous probability puzzle, the ")#link("https://en.wikipedia.org/wiki/Monty_Hall_problem")[#text("Monty Hall problem")]#text(". Let us use the formulation given in that Wikipedia page:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Suppose you’re on a game show, and you’re given the choice of three doors: Behind one door is a car; behind the others, goats. You pick a door, say No. 1, and the host, who knows what’s behind the doors, opens another door, say No. 3, which has a goat. He then says to you, “Do you want to pick door No. 2?” Is it to your advantage to switch your choice?")
]

#text("For this problem, the precise formulation of the null hypothesis and the alternative hypothesis become rather important. Suppose we take the following two hypotheses:")

#list(
[#text("Null hypothesis ")#mi("{H_0}")#text(": The car is behind door number 1, and no matter what door you pick, the host will randomly reveal another door that contains a goat.")],
[#text("Alternative hypothesis ")#mi("{H_1}")#text(": The car is behind door number 2 or 3, and no matter what door you pick, the host will randomly reveal another door that contains a goat.")]
)

#text("Assuming the prizes are distributed randomly, we have ")#mi("{\\mathop{\\bf P}(H_0)=1/3}")#text(" and ")#mi("{\\mathop{\\bf P}(H_1)=2/3}")#text(". The new information ")#mi("{E}")#text(" is that, after door 1 is selected, door 3 is revealed and shown to be a goat. After some thought, we conclude that ")#mi("{\\mathop{\\bf P}(E|H_0)}")#text(" is equal to ")#mi("{1/2}")#text(" (the host has a fifty-fifty chance of revealing door 3 instead of door 2) but that ")#mi("{\\mathop{\\bf P}(E|H_1)}")#text(" is also equal to ")#mi("{1/2}")#text(" (if the car is behind door 2, the host must reveal door 3, whereas if the car is behind door 3, the host cannot reveal door 3). Filling in the worksheet, we see that the new information does not in fact alter the odds, and the probability that the car is not behind door 1 remains at 2/3, so it is advantageous to switch.")

#image("../assets/b73c99bd1451746d67abbc5cbd9610acce26fc064a10b5512ca98440135b96de-2a82a7cdffd3f484b50b9f4b3bad4db165ce8aed5f1beb1123e2c9e7b6914ab1.png", width: 90%)

#text("However, consider the following different set of hypotheses:")

#list(
[#text("Null hypothesis ")#mi("{H^{\\prime}_0}")#text(": The car is behind door number 1, and if you pick the door with the car, the host will reveal another door to entice you to switch. Otherwise, the host will not reveal a door.")],
[#text("Alternative hypothesis ")#mi("{H^{\\prime}_1}")#text(": The car is behind door number 2 or 3, and if you pick the door with the car, the host will reveal another door to entice you to switch. Otherwise, the host will not reveal a door.")]
)

#text("Here we still have ")#mi("{\\mathop{\\bf P}(H^{\\prime}_0)=1/3}")#text(" and ")#mi("{\\mathop{\\bf P}(H^{\\prime}_1)=2/3}")#text(", but while ")#mi("{\\mathop{\\bf P}(E|H^{\\prime}_0)}")#text(" remains equal to ")#mi("{1/2}")#text(", ")#mi("{\\mathop{\\bf P}(E|H^{\\prime}_1)}")#text(" has dropped to zero (since if the car is not behind door 1, the host will not reveal a door). So now ")#mi("{\\mathop{\\bf P}(H^{\\prime}_0|E)}")#text(" has increased all the way to ")#mi("{1}")#text(", and it is not advantageous to switch! This dramatically illustrates the importance of specifying the hypotheses precisely. The worksheet is now filled out as follows:")

#image("../assets/2c0860294e9099ff1c22952c36b337af87a3ea48a8c84710ea5273b8f0f51991-c387438e97979eae0709096843d05c41f55377988b09694a05ee30c4215def75.png", width: 90%)

#text("Finally, we consider another famous probability puzzle, the ")#link("https://en.wikipedia.org/wiki/Sleeping_Beauty_problem")[#text("Sleeping Beauty problem")]#text(". Again we quote the problem as formulated on the Wikipedia page:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 2")]#text(" Sleeping Beauty volunteers to undergo the following experiment and is told all of the following details: On Sunday she will be put to sleep. Once or twice, during the experiment, Sleeping Beauty will be awakened, interviewed, and put back to sleep with an amnesia-inducing drug that makes her forget that awakening. A fair coin will be tossed to determine which experimental procedure to undertake:")

#list(
[#text("If the coin comes up heads, Sleeping Beauty will be awakened and interviewed on Monday only.")],
[#text("If the coin comes up tails, she will be awakened and interviewed on Monday and Tuesday.")],
[#text("In either case, she will be awakened on Wednesday without interview and the experiment ends.")]
)

#text("Any time Sleeping Beauty is awakened and interviewed she will not be able to tell which day it is or whether she has been awakened before. During the interview Sleeping Beauty is asked: “What is your credence now for the proposition that the coin landed heads?”‘")
]

#text("Here the situation can be confusing because there are key portions of this experiment in which the observer is unconscious, but nevertheless Bayesian probability continues to operate regardless of whether the observer is conscious. To make this issue more precise, let us assume that the awakenings mentioned in the problem always occur at 8am, so in particular at 7am, Sleeping beauty will always be unconscious.")

#text("Here, the null and alternative hypotheses are easy to state precisely:")

#list(
[#text("Null hypothesis ")#mi("{H_0}")#text(": The coin landed tails.")],
[#text("Alternative hypothesis ")#mi("{H_1}")#text(": The coin landed heads.")]
)

#text("The subtle thing here is to work out what the correct ")#emph[#text("prior state")]#text(" is (in most other applications of Bayesian probability, this state is obvious from the problem). It turns out that the most reasonable choice of prior state is “unconscious at 7am, on either Monday or Tuesday, with an equal chance of each”. (Note that whatever the outcome of the coin flip is, Sleeping Beauty will be unconscious at 7am Monday and unconscious again at 7am Tuesday, so it makes sense to give each of these two states an equal probability.) The new information is then")

#list(
[#text("New information ")#mi("{E}")#text(": One hour after the prior state, Sleeping Beauty is awakened.")]
)

#text("With this formulation, we see that ")#mi("{\\mathop{\\bf P}(H_0)=\\mathop{\\bf P}(H_1)=1/2}")#text(", ")#mi("{\\mathop{\\bf P}(E|H_0)=1}")#text(", and ")#mi("{\\mathop{\\bf P}(E|H_1)=1/2}")#text(", so on working through the worksheet one eventually arrives at ")#mi("{\\mathop{\\bf P}(H_1|E)=1/3}")#text(", so that Sleeping Beauty should only assign a probability of ")#mi("{1/3}")#text(" to the event that the coin landed as heads.")

#image("../assets/f75b56ec5007369206eaa50d768846597356fa1c866f6358856fa55d78cc9b1e-9b29aa2c42e655e68d9c60eeda175f178a177a5847e89737859b237e6a391964.png", width: 90%)

#text("There are arguments advanced in the literature to adopt the position that ")#mi("{\\mathop{\\bf P}(H_1|E)}")#text(" should instead be equal to ")#mi("{1/2}")#text(", but I do not see a way to interpret them in this Bayesian framework without a substantial alteration to either the notion of the prior state, or by not presenting the new information ")#mi("{E}")#text(" properly.")

#text("If one has multiple pieces of information ")#mi("{E_1, E_2, \\dots}")#text(" that one wishes to use to update one’s priors, one can do so by filling out one copy of the worksheet for each new piece of information, or by using a multi-row version of the worksheet using such identities as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\mathop{\\bf P}( H_1|E_1,E_2 )}{\\mathop{\\bf P}(H_0|E_1,E_2)} = \\frac{\\mathop{\\bf P}(H_1)}{\\mathop{\\bf P}(H_0)} \\times \\frac{\\mathop{\\bf P}(E_1|H_1)}{\\mathop{\\bf P}(E_1|H_0)} \\times \\frac{\\mathop{\\bf P}(E_2|H_1,E_1)}{\\mathop{\\bf P}(E_2|H_0,E_1)}.")]]

#text("We leave the details of these variants of the Bayesian update problem to the interested reader. The only thing I will note though is that if a key piece of information ")#mi("{E}")#text(" is withheld from the person filling out the worksheet, for instance if that person relies exclusively on a news source that only reports information that supports the alternative hypothesis ")#mi("{H_1}")#text(" and omits information that debunks it, then the outcome of the worksheet is likely to be highly inaccurate, and one should only perform a Bayesian analysis when one has a high confidence that all relevant information (both favorable and unfavorable to the alternative hypothesis) is being reported to the user.")

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658597")[#strong[#text("A Bayesian probability worksheet – Marxist Statistics")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2022")]

#text("[…] A Bayesian probability worksheet […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mgflax")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658599")[#strong[#text("mgflax")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2022")])]

#text("Starting in elementary school, we teach children to think of likelihood in terms of a probability lying in [0,1] — and then later Bayesists tell them to exclude 0 and 1 as not actually possible. But I’m wondering if it wouldn’t be more natural to have students *start* with an odds formulation of likelihood, with values lying in (0,\\infty). If it’s the natural way gamblers think, perhaps it’s more fundamental in general?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658713")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2022")])]

#text("In this specific problem of updating Bayesian priors, the prior odds ")#mi("{\\bf P}(H_1)/{\\bf P}(H_0)")#text(" and the posterior odds ")#mi("{\\bf P}(H_1|E)/{\\bf P}(H_0|E)")#text(" are indeed convenient quantities to use. However for the likelihoods ")#mi("{\\bf P}(E|H_0)")#text(", ")#mi("{\\bf P}(E|H_1)")#text(" it is still convenient to use the actual probabilities rather than their associated odds ")#mi("{\\bf P}(E|H_0)/(1-{\\bf P}(E|H_0))")#text(", ")#mi("{\\bf P}(E|H_1)/(1-{\\bf P}(E|H_1))")#text(". Furthermore, many of the laws of probability are easier to state using probabilities than odds. For instance, the union bound")

#text("* If ")#mi("E")#text(", ")#mi("F")#text(" are two events, then ")#mi("{\\bf P}(E \\vee F)")#text(" is at most ")#mi("{\\bf P}(E)+{\\bf P}(F)")#text(", with equality when ")#mi("E, F")#text(" are disjoint")

#text("or the independence rule")

#text("* If ")#mi("E")#text(", ")#mi("F")#text(" are two independent events, then ")#mi("{\\bf P}(E \\wedge F) = {\\bf P}(E) {\\bf P}(F)")

#text("become more unwieldy when phrased in terms of odds. So I think one has to teach both probabilities and odds, and how to convert between each other (much like how one teaches real arithmetic with both decimals and fractions simultaneously); there isn’t a “one-size-fits-all” convention that simplifies all calculations simultaneously.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2022")])]

#text("In the wikipedia article on the Monty Hall problem (problem 1 above) it is stated that even Erdos had difficulty to accept the correct solution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcc8dd35fd3341bd1f47d9472063440b46e7b5f3ab73ea865fb54e45ee88722f-bb4be7f57e927f772a1e062ffc44ee78703e605f4e8c811c8e97971d91ad5d36.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Smith")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658631")[#strong[#text("James Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2022")])]

#text("Good to see you linking to the Monty Hall problem on Wikipedia. I remember trying to explain the result to my student a few years back. I had several stabs at it but in the end had to admit to myself, and to my student, that I really didn’t know what I was talking about! The proof that was there didn’t help, it was clearly bogus, so in the end we decided that we should just figure it out from first principles ourselves. Since neither of us were experts, it took several hours!")

#text("Here is link to that proof:")

#link("https://en.wikipedia.org/w/index.php?title=Monty_Hall_problem&oldid=818327855#Direct_calculation")[#text("https://en.wikipedia.org/w/index.php?title=Monty_Hall_problem&oldid=818327855#Direct_calculation")]

#text("I give it here because it has since been rewritten again and the current rewrite is perhaps a little less expansive. For this reason, I keep the above link on my home page. Anyway, perhaps the proof will help someone gain some insight.")

#text("I still cannot quite believe the end result myself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5dcc500d5f05dd2cd9dc63e2fb064696e337b2e2910d944b977a3afeb6bfebba-93066f9f9b261e0b43f33aeb66a0064e32f4e6c27ff3397620779f9dcb70d238.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Des Smith")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658690")[#strong[#text("Des Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2022")])]

#text("Please help!")

#text("Consider the first example, where 2\\% of the population is infected with COVID-19, the COVID-19 test has a 20\\% chance of a false negative, and a 5\\% chance of a false positive. My na\\”ive calculation is that a positive test implies a probability of the test subject actually having the disease of")

#mi("\\displaystyle P = TP / ( TP + FP)")

#mi("TP =")#text(" true positive, ")#mi("FP =")#text(" false positive. The computed probability, ")#mi("P")#text(", is called the positive predictive value, or PPV.")

#text("Using the concrete numbers provided:")

#mi("P = (0.02 \\times 0.95) / ( 0.02 \\times 0.95 + 0.98 \\times 0.05) = 0.2794")

#text("This result is somewhat different from the worked example value and, further, does not require the false negative rate which the worked example employs.")

#text("What am I doing wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658712")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2022")])]

#text("The true positive rate is ")#mi("0.02 \\times 0.8")#text(", not ")#mi("0.02 \\times 0.95")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5dcc500d5f05dd2cd9dc63e2fb064696e337b2e2910d944b977a3afeb6bfebba-93066f9f9b261e0b43f33aeb66a0064e32f4e6c27ff3397620779f9dcb70d238.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Des Smith")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658714")[#strong[#text("Des Smith")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2022")])]

#text("Oh yes, I see now, thank you so much. Your comment prompted me to draw out a forking diagram of possibilities and I now understand much better. Thanks so much again!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e56585db621b41a08296d5c75274bec46a17836a6830fb83773a5f2164759dd7-e8e57b7792a08c4612542db934f36f2ef1215b4825ead7345e8179acf0255d7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-658979")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2022")])]

#text("Can I make a request concerning notation? Would you please not refer to ratios of probabilities (such as $P(H_1)/P(H_0)$) as ‘odds ratios’ but reserve the term ‘odds ratio’ for a number that is actually the ratio between two odds? Odds ratios in the sense of ratios between odds are ubiquitous in medical and epidemilogical research as they are the thing that logistic models output. But in media representations of the same research these odds ratios are often misrepresented as ratios of probabilities (e.g. risk ratios) which can be seriously misleading (unless the probabilities in question are close to zero, in which case the difference is also small).")

#text("Of course this particular misunderstanding will not be gone from the world anytime soon, especially since in everyday use ‘odds’ and ‘probability’ are used interchangeably. But still I think it is useful if in more technical publications we try not to further the confusion between odds ratios, odds and (other) ratios of probability and stick to the established terminology.")

#text("So my request is: please call $P(H_1)/P(H_0)$ simply ‘the odds of $H_1$’, or if you want to stress that (like any odds) it is also a ratio , maybe you can write something like ‘The ratio $P(H_1)/P(H_0)$, known as the odds’ or similar.")

#text("Thanks in advance!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659026")[#strong[#text("Weekly Non-Covid News #1 (10/13/22) | Don't Worry About the Vase")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2022")]

#text("[…] Terrance Tao offers worksheet on Bayesian probability. No idea if this would be helpful to someone who didn’t already ‘get it.’ […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42750c69d4b8fe69ffeb7fe7a4bd9569a10cd883924727a4bc6e5fe80ee10c91-585182e8ca38669d31b82923ecdf7af70675d3e5c1787c5ea412492cd627823c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Skylar English")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659061")[#strong[#text("Skylar English")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2022")])]

#text("Shouldn’t box 8 in the “switched” worksheet be 0.05 instead of 0.5? The chance of a false positive is still 0.05. I felt something must be wrong because the outcome of the probabilities should not have stayed the same when we inverted our definition of the null, they should have swapped places. Our definition of the null vs alternative for the same events wouldn’t change the probability mass of those events.")

#emph[#text("[Typo corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Payor")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659196")[#strong[#text("James Payor")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2022")])]

#text("Regarding Sleeping Beauty, I think there’s structure not captured by simply P(Heads) = 1/3. I’m not sure what the fuller story is.")

#text("Let’s imagine Beauty has a trust fund for her daughter, and that I will visit her on both Monday and Tuesday offering her an investment she can make (if she’s awake).")

#text("Suppose the investment loses $60 if the coin landed heads, but pays out $40 on tails. Beauty should take it when she wakes up. (This is because she buys it twice when the coin is tails, earning $80.)")

#text("Suppose instead that Beauty can make the investment at most once – if she asks for it on Monday and Tuesday she only gets one copy. Now it’s a bad idea, losing $10 on average.")

#text("The first case is kinda consistent with “P(heads) = 1/3“, but this would give you the wrong answer in the second case.")

#text("I think it matters then what you’re aiming for in your probability estimates. Do you care about the log probability that Beauty assigns to the true outcome, summed across all times she wakes up? Or do you only care about what she says on Monday, or perhaps her average answer across wakings?")

#text("These probably correspond to different methods of obtaining the prior. I remain pretty confused about the right way to think about all this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe1bd133cb09a72871b11fd70fd85c5a0fac84a33785de370decd9496cdaa991-bd47997ee0af534961cd0ee01488d2717737f6065aaaf30fa38d1a763d33190f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radford Neal")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659220")[#strong[#text("Radford Neal")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2022")])]

#text("“The first case is kinda consistent with P(heads) = 1/3, but this would give you the wrong answer in the second case.”")

#text("Actually, P(Heads) = 1/3 is consistent with the right answer in the second case as well.")

#text("First, to find the optimal strategy in this situation where investing when Heads yields -60 for Beauty, and investing when Tails yields +40 for Beauty, but only once if Beauty decides to invest on both wakenings, we need to consider random strategies in which with probability q, Beauty does not invest, and with probability (1-q) she does invest.")

#text("Beauty’s expected gain if she follows such a strategy is (1/2)40(1-q^2)-(1/2)60(1-q). Taking the derivative, we get -40q+30, and solving for this being zero gives q=3/4 as the optimal value. So Beauty should invest with probability 1/4, which works out to giving her an average return of (1/2)40(7/16)-(1/2)60(1/4)=5/4.")

#text("That’s all when working out the strategy beforehand. But what if Beauty re-thinks her strategy when she is woken? Will she change her mind, making this strategy inconsistent?")

#text("Well, she will think that with probability 1/3, the coin landed Heads, and the investment will lose 60, and with probability 2/3, the coin landed Tails, in which case the investment will gain 40, but only if she didn’t/doesn’t invest in her other wakening. If she follows the strategy worked out above, in her other wakening, she doesn’t invest with probability 3/4, and if Beauty thinks things over with that assumption, she will see her expected gain as (2/3)(3/4)40-(1/3)60=0. With a zero expected gain, Beauty would seem indifferent to investing or not investing, and so has no reason to depart from the randomized strategy worked out beforehand. We might hope that this reasoning would lead to a positive recommendation to randomize, not just acquiescence to doing that, but in Bayesian decision theory randomization is never required, so if there’s a problem here it’s with Bayesian decision theory, not with the Sleeping Beauty problem in particular.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Payor")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659237")[#strong[#text("James Payor")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2022")])]

#text("Okay yeah randomized strategies are a good way to still exploit the difference between one and two awakenings! That’s awesome.")

#text("But also, there should be no difference in the calculation for what policy to follow before and after observing an awakening. Beauty should not acquire incorrect beliefs about the state of the trust fund just because she awakened and thereby acquired more information! This indicates an error in the reasoning (that I would confidently bet is not some core issue with Bayesianism but rather confusions in the application here).")

#text("To be clear, if you calculate “what conditional policy should I follow to maximize trust fund money when I observe I have awakened”, you simply get the right answers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Payor")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659238")[#strong[#text("James Payor")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2022")])]

#text("I guess you have spent a bunch of time thinking about this :)")

#text("My main trailhead for all this is trying to better track the difference between “what do I expect to see next, given my uncertainty over which observer I am” and “what policy do I think best achieves my goals in the world I’m in when instantiated across my copies”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe1bd133cb09a72871b11fd70fd85c5a0fac84a33785de370decd9496cdaa991-bd47997ee0af534961cd0ee01488d2717737f6065aaaf30fa38d1a763d33190f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radford Neal")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659240")[#strong[#text("Radford Neal")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2022")])]

#text("I’m not sure what you’re saying here. Do you think there is something wrong with the analysis I present above?")

#text("In my analysis, I assumed that after deciding beforehand to invest with probability (1-q), Beauty assumes that she did/will invest with that probability on any other awakening. I then show that her reasoning after awakening does not contradict this – though it doesn’t exactly recommend that strategy either, being instead indeterminate about with what probability Beauty should invest.")

#text("So I don’t see how Beauty acquires any incorrect beliefs after awakening.")

#text("I’m also not sure how you “simply” get the right answers. Are you referring to my analysis (which I’d say is a bit subtle, though of course not really complex), or do you think there is a simpler way?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/791c213002f597b0a4b2733a662a94b6da8fd1b8ebbb6f549e62a178b9c6125b-71bb7c050b50d5af6903a8376a1d5f8eb0bbcc354235782f23123ea0e8e60a35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Ngo")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-660296")[#strong[#text("Richard Ngo")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2022")])]

#text("This comment makes an excellent point, which is fleshed out in the more general case in Armstrong’s paper on anthropic decision theory: ")#link("https://www.fhi.ox.ac.uk/wp-content/uploads/Anthropic_Decision_Theory_Tech_Report.pdf")[#text("https://www.fhi.ox.ac.uk/wp-content/uploads/Anthropic_Decision_Theory_Tech_Report.pdf")]#text(" (which itself is a special case of functional decision theory: ")#link("https://arxiv.org/abs/1710.05060")[#text("https://arxiv.org/abs/1710.05060")]#text(").")

#text("Based on this I no longer believe that there are well-defined answers to problems like Sleeping Beauty unless utilities are also specified.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe1bd133cb09a72871b11fd70fd85c5a0fac84a33785de370decd9496cdaa991-bd47997ee0af534961cd0ee01488d2717737f6065aaaf30fa38d1a763d33190f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Radford Neal")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659221")[#strong[#text("Radford Neal")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2022")])]

#text("In your analysis of the Sleeping Beauty problem, I think you miss the point, as far as the discussion by philosophers is concerned. In particular, it’s crucial to pay careful attention to whom the probabilities are supposed to be for, and everything that that person knows.")

#text("Clearly, for the experimenter who flipped the coin, the probability of Heads is either 0 or 1. We’re instead supposed to be figuring out the probabilities that Beauty should have when she is awakened. But it’s arguable that you are not doing that.")

#text("The probabilities that you figure out would be appropriate for some third party, if they happened on the experiment after spending many days away from civilization, and having therefore forgotten what day of the week it is. They are informed of the experimental setup, see Beauty asleep at 7am, and then see that the experimenter wakes her up at 8am. Their probability that the coin landed Heads should indeed be 1/3, as you calculate.")

#text("But to conclude similarly that, when woken, Beauty should also assign a probability of 1/3 to Heads, it is necessary that Beauty have no additional relevant information. This is the crux of the debate. Some people think that Beauty has “indexical” information, of the form “I am now awake”. Note the presence of “I”, meaning “me, right now, not somebody else”. One might argue that this is information not accounted for in your analysis. And in Bayesian reasoning, one must always use all the information you have, not just some subset.")

#text("Now, I do in fact think that 1/3 is the correct answer for Beauty’s probability of Heads when woken. My reasoning is based on rigorously applying the principle that one must use all information when forming probabilities – information such as that when woken, Beauty sees a particular changing pattern of sunlight from the window as the shade trees outside blow with the wind, and many other details of perception that will be different on Monday or (if she’s woken then) on Tuesday. The probability of Beauty, when woken, having the particular perceptions that she knows she has is a factor of two greater if she is woken twice than if she is woken once (assuming that any particular perceptions have very low probability). This leads to a probability of 1/3 for Heads.")

#text("You can read the argument in more detail in my paper at ")#link("https://arxiv.org/abs/math/0608592")[#text("https://arxiv.org/abs/math/0608592")]#text(" (see Section 3).")

#text("There are other arguments for 1/3 as well. I think that those advocating that Beauty’s probability of Heads should be 1/2 only manage to maintain this conclusion by contending that different people with exactly the same information can rationally have different probabilities for the same event, depending on their perspective (or some such), a view that seems rather contrived to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659232")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2022")])]

#text("Is there a quantum mechanical formulation of this problem (with “quantum observer” and quantum information) instead of this classical formulation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9e8ba354408860d8a4ca0ae8876cbc0985f27eaf398d29c43e21204e683a22e1-d4977aa11be9be9ab76c3109a2bdaa15515638b9b0c6337e424a5e50fe638f0c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Aspegren")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659235")[#strong[#text("Johan Aspegren")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2022")])]

#text("I can think of one. The sleeping beaty really does not know what the day is it when she is awakened. But she knows that there are two different events to consider: 1) This is the first and only time during the experiment that she is awake, so heads. 2) This is the second time during the experiment that she is awake *or* this is the first time during the experiment but there will be a second time, so tails. In 2) she cannot really use *exclusive or* so she is kind of in a superposition with her beliefs :) So her being her, she gives 1/3 probability to heads and 2/3 probability to tails.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659587")[#strong[#text("Reckoning with Bayes – Epicycloid of Cremona")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2022")]

#text("[…] theorem. As always, his exposition was clear and thorough, and he even followed up with a worksheet designed to help apply the theorem in real-world situations, with warnings about the various […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e810aa7a56b85d7d9444714ed2025f589da57bad99d6ac1533ac3a24f17a843e-93ebb5376e768d162c5a4578220768eb84334d4982f2d3a3ccc5526f8de8496e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Probability")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659640")[#strong[#text("Probability")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2022")])]

#text("We 💜 u Terrence thanks for the statostasketidos. U r the best math Dude evr!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/945d2db15ad4b10608aabc63bf54c5a66a7939bd8b17686a2844f2e5579ef72b-d2f59d7291f6d0f1c27e0171329a11a7aeedbeeb7ad3023170a7bcaf7ff7d94c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Heiko242")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-659991")[#strong[#text("Heiko242")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2022")])]

#text("SB: Of course the double halfer position is the right solution “duck away”. :-)")

#text("There seems to be another problem of decision theory , the Judy Benjamin Problem, which regards the correct Bayes updating when the new information consist of a conditional information. Dr. Tao could you please elaborate a little in it?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c02e760ba824fbfb29d0705bff9f43e28147cc6166b3ffd6ee502030663db005-ca93c80df0117313fe9c395093f3a4cece1c3fd9ed78a187850cba4744bada89.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KAIN UWIZER")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-672790")[#strong[#text("KAIN UWIZER")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("Is it true that you failed to prove the collatz conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2e32cd77f397765bcbe73da63649f1d42dbbe4f6b0f0436c0a91995fb1c01851-15cc2654c75fd56073fa2267b2b0f1831eadeaf62e4db3684583d89fe28765bf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of KAIN UWIZER")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-672791")[#strong[#text("KAIN UWIZER")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("If you pick a door, you haven’t not picked a door. In otherwords, if you pick a door, you have picked a door. All results of (picking(in your mind))(not picking a door) are a convoluted TURD PUZZLE. Is that so hard with all that IQ?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-672792")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2023")])]

#text("Hello, hopefully you’re doing well my friend")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71f2f5bc61eeadb5272a6575a581a4a94073d55c29b9d04aa0af465f95ecc782-ed74ed3d9fee69ee518c2301b2c9d1145a5a717d0fd1a778b2a30e5943cb74bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ivan")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-680180")[#strong[#text("Ivan")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2023")])]

#text("Surely you must realize something is off with this argument – they don’t even have to flip the coin until Tuesday, since they wake her up on Monday regardless – so on Monday Sleeping Beauty wakes up and has an updated posterior belief on the outcome of something that hasn’t happened yet? What’s the causal relationship? What’s the new information?")

#text("I disagree with the choice of prior. We know the exact distribution in advance – that my current waking up moment is 1/2 Monday heads, 1/4 Monday tails and 1/4 Tuesday tails. A uniform prior on today being Monday/Tuesday makes absolutely no sense in this scenario. The argument from Wikipedia about expressing it as a bet actually makes things very clear – the 1/3 doesn’t come from a Bayesian update, it’s because you get asked twice on one of the branches and only once on the other – so if you are optimizing on the total number of wrong guesses, then yeah, of course you want to guess tails 2/3 of the time. But it has nothing to do with your posterior belief about the result of a fair coin flip (that hasn’t happened yet), just risk-neutral betting.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-680778")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2023")])]

#text("The mathematics of Bayesian probability works regardless of whether the posterior information is causally dependent, or occurs in the future of, prior information, even if this is the case in many of the use cases of Bayesian probability. Indeed, there is no mention at all of causality in the mathematical foundations of this theory.")

#text("The uniform prior is prior to the information that one is actually conscious at the given time. If one only assumes that one *exists*, but is not necessarily *conscious*, the prior is 1/4 Monday heads, 1/4 Tuesday heads, 1/4 Monday tails, and 1/4 Tuesday tails. Again, the mathematics of Bayesian probability continues to apply even when the person to which the calculation would apply to is unconscious.")

#text("A human needs to be conscious and operate casually in order to perform Bayesian probability calculations, but the underlying mathematics of these calculations does not actually require either consciousness or causality in order to be valid. [Perhaps it will help if you view these calculations as not being performed by Sleeping Beauty herself, but by some dispassionate AI who, on the Wednesday after the experiment is concluded, is given the information that Sleeping Beauty has achieved consciousness at some unknown time, and is asked to make conclusions based on this information.]")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-685827")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Dear professor Tao:")

#text("A small typo in step 8, “null hypothesis” ")#mi("H_1")#text(" should be “alternative hypothesis” ")#mi("H_1")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-685829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Also, in the first Bayesian update problem with COVID-19, I think the posterior hypotheses probabilities in the worksheet where the original null and alternative hypothesis is switched should flipped to show the fact that the ultimate conclusions remain unchanged.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-689070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2025")])]

#text("Prof. Tao, I would like to ask what Bayesian probabilistic thinking is. The reason I ask this question is because I don’t know what distinguishes conventional probabilistic thinking (e.g., avoiding looking at the details of the sample space) from Bayesian probabilistic thinking. Also, what are the applications of this way of thinking in statistics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-689466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("Dear Dr Tao,")

#text("A small typo here: “betwen” should be “between”.")

#text("I am confused about a term you use a lot in this blog: …P(E | H_1) is the “")#strong[#text("likelihood")]#text("” of this information…")

#text("Why would you call this probability “likelihood”?")

#text("( I checked the wiki but I can’t see the connections under the wiki’s definition: ")#link("https://en.wikipedia.org/wiki/Likelihood_function")[#text("https://en.wikipedia.org/wiki/Likelihood_function")]#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-689468")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("In general, I would recommend not fixating on the specific definitions of informally introduced terms, as this is a rather fragile reading comprehension strategy that can lead to “")#link("https://terrytao.wordpress.com/advice-on-writing-papers/on-compilation-errors-in-mathematical-reading-and-how-to-resolve-them/")[#text("compilation errors")]#text("” when reading mathematical texts. A more robust reading strategy is to continue reading even when the meaning of some terms used in the text is unclear, and infer them from context afterwards, when one has managed to deduce the general thrust of what the author is saying.")

#text("As I suggested in a previous response, linguistic questions are well suited for posing to an LLM, especially if one provides ample context, including the text one is trying to understand, your background knowledge about the topic, and the specific types of confusion one is having with the text.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-689477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("Actually this is the belief I hold too. But what I am really like to ask is that what is the connection between this informal saying and formal definition of likelihood.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-692542")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2026")])]

#text("Dr Tao:")

#text("In this blog post you have used Bayesian probability to solve the puzzle of the Monty Hall problem with 3 doors. However, I failed when I try to solve the the extreme case (say 1,000,000 doors). Could you specify is it possible to solve the extreme case using Bayesian probability?")

#emph[#text("[If you have conceptually difficulty working with the case of 1,000,000 doors, I suggest first starting with 4 doors, and gradually increasing from there. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1316b80df5a677c3c7168727f112a826d87fe696da27bc180a673a7268be70c-12f1707b7f63c3bd137d51884b92c3e88f27aa0bccdaf43bd988212355f59f65.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JEFF GARZA")]], [#link("https://terrytao.wordpress.com/2022/10/07/a-bayesian-probability-worksheet/#comment-693269")[#strong[#text("JEFF GARZA")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("Your analysis of Problem 2 (Sleeping Beauty) closes with the remark that you do not see a way to interpret the arguments for 1/2 in this framework without “a substantial alteration to either the notion of the prior state” or an improper presentation of the new information E. Suppose one makes exactly that alteration. Replace the day-partitioned prior state with a prior over the outcome of the experiment as a whole, retaining P(H_0) = P(H_1) = 1/2, and let E be the event that an awakening occurs at some point during the experiment. Then P(E|H_0) = P(E|H_1) = 1, and the worksheet returns P(H_1|E) = 1/2. Do you regard this model as incoherent, or as coherent but answering a different question from yours? If the latter, is it the wording of the interview question that selects the day-partitioned prior state, or considerations external to it?")

#text("Let me put the same question more narrowly. The coin is the only chance device in the experiment, and the equal weighting of the Monday and Tuesday states at 7am is an indifference assignment over days rather than an output of that device. Your Monty Hall discussion shows how strongly the conclusion depends on the precise specification of the protocol. Is the day-uniform assignment forced, or one admissible convention among others, with the model above as another?")
]
