// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/
// Converted to Typst by tao2typ: "2026-10-14T16:38:26.071694+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 2: Weak solutions of the Navier-Stokes equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 2: Weak solutions of the Navier-Stokes equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("previous set of notes")]#text(" we developed a theory of “strong” solutions to the Navier-Stokes equations. This theory, based around viewing the Navier-Stokes equations as a perturbation of the linear heat equation, has many attractive features: solutions exist locally, are unique, depend continuously on the initial data, have a high degree of regularity, can be continued in time as long as a sufficiently high regularity norm is under control, and tend to enjoy the same sort of conservation laws that classical solutions do. However, it is a major open problem as to whether these solutions can be extended to be (forward) global in time, because the norms that we know how to control globally in time do not have high enough regularity to be useful for continuing the solution. Also, the theory becomes degenerate in the inviscid limit ")#mi("{\\nu \\rightarrow 0}")#text(".")

#text("However, it is possible to construct “weak” solutions which lack many of the desirable features of strong solutions (notably, uniqueness, propagation of regularity, and conservation laws) but can often be constructed globally in time even when one us unable to do so for strong solutions. Broadly speaking, one usually constructs weak solutions by some sort of “compactness method”, which can generally be described as follows.")

#enum(start: 1, 
[#text("Construct a sequence of “approximate solutions” to the desired equation, for instance by developing a well-posedness theory for some “regularised” approximation to the original equation. (This theory often follows similar lines to those in the previous set of notes, for instance using such tools as the contraction mapping theorem to construct the approximate solutions.)")],
[#text("Establish some ")#emph[#text("uniform")]#text(" bounds (over appropriate time intervals) on these approximate solutions, even in the limit as an approximation parameter is sent to zero. (Uniformity is key; ")#emph[#text("non-uniform")]#text(" bounds are often easy to obtain if one puts enough “mollification”, “hyper-dissipation”, or “discretisation” in the approximating equation.)")],
[#text("Use some sort of “weak compactness” (e.g., the Banach-Alaoglu theorem, the Arzela-Ascoli theorem, or the Rellich compactness theorem) to extract a subsequence of approximate solutions that converge (in a topology weaker than that associated to the available uniform bounds) to a limit. (Note that there is no reason ")#emph[#text("a priori")]#text(" to expect such limit points to be unique, or to have any regularity properties beyond that implied by the available uniform bounds..)")],
[#text("Show that this limit solves the original equation in a suitable weak sense.")]
)

#text("The quality of these weak solutions is very much determined by the type of uniform bounds one can obtain on the approximate solution; the stronger these bounds are, the more properties one can obtain on these weak solutions. For instance, if the approximate solutions enjoy an energy identity leading to uniform energy bounds, then (by using tools such as Fatou’s lemma) one tends to obtain energy ")#emph[#text("inequalities")]#text(" for the resulting weak solution; but if one somehow is able to obtain uniform bounds in a higher regularity norm than the energy then one can often recover the full energy ")#emph[#text("identity")]#text(". If the uniform bounds are at the regularity level needed to obtain well-posedness, then one generally expects to upgrade the weak solution to a strong solution. (This phenomenon is often formalised through ")#emph[#text("weak-strong uniqueness")]#text(" theorems, which we will discuss later in these notes.) Thus we see that as far as attacking global regularity is concerned, both the theory of strong solutions and the theory of weak solutions encounter essentially the same obstacle, namely the inability to obtain uniform bounds on (exact or approximate) solutions at high regularities (and at arbitrary times).")

#text("For simplicity, we will focus our discussion in this notes on finite energy weak solutions on ")#mi("{{\\bf R}^d}")#text(". There is a completely analogous theory for periodic weak solutions on ")#mi("{{\\bf R}^d}")#text(" (or equivalently, weak solutions on the torus ")#mi("{({\\bf R}^d/{\\bf Z}^d)}")#text(" which we will leave to the interested reader.")

#text("In recent years, a completely different way to construct weak solutions to the Navier-Stokes or Euler equations has been developed that are not based on the above compactness methods, but instead based on techniques of convex integration. These will be discussed in a later set of notes.")

#metadata(none) <tao-ed6c765a7a84f3958f5c>

#heading(level: 1)[#strong[#text(" — 1. A brief review of some aspects of distribution theory — ")]]

#text("We have already been using the concept of a distribution in previous notes, but we will rely more heavily on this theory in this set of notes, so we pause to review some key aspects of the theory. A more comprehensive discussion of distributions may be found in ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("this previous blog post")]#text(". To avoid some minor subtleties involving complex conjugation that are not relevant for this post, we will restrict attention to real-valued (scalar) distributions here. (One can then define vector-valued distributions (taking values in a finite-dimensional vector space) as a vector of scalar-valued distributions.)")

#text("Let us work in some non-empty open subset ")#mi("{U}")#text(" of a Euclidean space ")#mi("{{\\bf R}^d}")#text(" (which may eventually correspond to space, time, or spacetime). We recall that ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" is the space of (real-valued) test functions ")#mi("{\\phi: U \\rightarrow {\\bf R}}")#text(". It has a rather subtle topological structure (see ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("previous notes")]#text(") which we will not detail here. A (real-valued) distribution ")#mi("{\\lambda}")#text(" on ")#mi("{U}")#text(" is a continuous linear functional ")#mi("{\\phi \\mapsto \\langle \\lambda, \\phi \\rangle}")#text(" from test functions ")#mi("{\\phi \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" to the reals ")#mi("{{\\bf R}}")#text(". (This pairing ")#mi("{\\langle \\lambda, \\phi \\rangle}")#text(" may also be denoted ")#mi("{\\langle \\phi,\\lambda \\rangle}")#text(" or ")#mi("{\\lambda(\\phi)}")#text(" in other texts.) There are two basic examples of distributions to keep in mind:")

#list(
[#text("Any locally integrable function ")#mi("{f \\in L^1_{loc}(U \\rightarrow {\\bf R})}")#text(" gives rise to a distribution (which by abuse of notation we also call ")#mi("{f}")#text(") by the formula ")#mi("{\\langle f, \\phi \\rangle := \\int_{U} f(x) \\phi(x)\\ dx}")#text(".")],
[#text("Any Radon measure ")#mi("{\\mu \\in M(U)}")#text(" gives rise to a distribution (which we will again call ")#mi("{\\mu}")#text(") by the formula ")#mi("{\\langle \\mu, \\phi \\rangle = \\int_{U} \\phi(x)\\ d\\mu(x)}")#text(". For instance, if ")#mi("{x_0 \\in U}")#text(", the Dirac mass ")#mi("{\\delta_{x_0}}")#text(" at ")#mi("{x_0}")#text(" is a distribution with ")#mi("{\\langle \\delta_{x_0}, \\phi \\rangle = \\phi(x_0)}")#text(".")]
)

#text("Two distributions ")#mi("{\\lambda, \\eta}")#text(" are equal in the sense of distributions of ")#mi("{\\langle \\lambda, \\phi \\rangle = \\langle \\eta, \\phi \\rangle}")#text(" for all ")#mi("{\\phi \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(". For instance, it is not difficult to show that two locally integrable functions are equal in the sense of distributions if and only if they agree almost everywhere, and two Radon measures are equal in the sense of distributions if and only if they are identical.")

#text("As a general principle, any “linear” operation that makes sense for “nice” functions (such as test functions) can also be defined for distributions, but any “nonlinear” operation is unlikely to be usefully defined for arbitrary distributions (though it may still be a good concept to use for distributions with additional regularity). For instance, one can take a partial derivative ")#mi("{\\partial_i \\lambda}")#text(" (known as the ")#link("https://en.wikipedia.org/wiki/Weak_derivative")[#text("weak derivative")]#text(") of any distribution ")#mi("{\\lambda}")#text(" by the definition")

#align(center)[#tao-fit-display[#mitex("\\langle \\partial_i \\lambda, \\phi \\rangle := - \\langle \\lambda, \\partial_i \\phi \\rangle")]]

#text("for all ")#mi("{\\phi \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(". Note that this definition agrees with the “strong” or “classical” notion of a derivative when ")#mi("{\\lambda}")#text(" is a smooth function, thanks to integration by parts. Similarly, if ")#mi("{f \\in C^\\infty(U \\rightarrow {\\bf R})}")#text(" is smooth, one can define the product distribution ")#mi("{f\\lambda = \\lambda f}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle f \\lambda, \\phi \\rangle := \\langle \\lambda, f \\phi \\rangle")]]

#text("for all ")#mi("{\\phi \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(". One can also take linear combinations of two distributions ")#mi("{\\lambda, \\eta}")#text(" in the usual fashion, thus")

#align(center)[#tao-fit-display[#mitex("\\langle a \\lambda + b \\nu, \\phi \\rangle = a \\langle \\lambda, \\phi \\rangle + b \\langle \\nu, \\phi \\rangle")]]

#text("for all ")#mi("{a,b \\in {\\bf R}}")#text(" and ")#mi("{\\phi \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Let ")#mi("{U}")#text(" be a connected open subset of ")#mi("{{\\bf R}^d}")#text(". Let ")#mi("{\\lambda}")#text(" be a distribution on ")#mi("{U}")#text(" such that ")#mi("{\\partial_i \\lambda = 0}")#text(" in the sense of distributions for all ")#mi("{i=1,\\dots,d}")#text(". Show that ")#mi("{\\lambda}")#text(" is a constant, that is to say there exists ")#mi("{c \\in {\\bf R}}")#text(" such that ")#mi("{\\lambda = c}")#text(" in the sense of distributions.")
]

#text("A sequence of distributions ")#mi("{\\lambda_n}")#text(" is said to ")#link("https://en.wikipedia.org/wiki/Weak_topology")[#text("converge in the weak-* sense")]#text(" or ")#emph[#text("converge in the sense of distributions")]#text(" to another distribution ")#mi("{\\lambda}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\langle \\lambda_n, \\phi \\rangle \\rightarrow \\langle \\lambda, \\phi \\rangle")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for every test function ")#mi("{\\phi}")#text("; in this case we write ")#mi("{\\lambda_n \\rightharpoonup^* \\lambda}")#text(". This notion of convergence is sometimes referred to also as weak convergence (and one writes ")#mi("{\\lambda_n \\rightharpoonup \\lambda}")#text(" instead of ")#mi("{\\lambda_n \\rightharpoonup^* \\lambda}")#text("), although there is a subtle distinction between weak and weak-* convergence in non-")#link("https://en.wikipedia.org/wiki/Reflexive_space")[#text("reflexive")]#text(" spaces and so I will try to avoid this terminology (though in many cases one will be working in a reflexive space in which there is no distinction).")

#text("The linear operations alluded to above tend to be continuous in the distributional sense. For instance, it is easy to see that if ")#mi("{\\lambda_n \\rightharpoonup^* \\lambda}")#text(", then ")#mi("{\\partial_i \\lambda_n \\rightharpoonup^* \\partial_i \\lambda}")#text(" for all ")#mi("{i=1,\\dots,d}")#text(", and ")#mi("{f \\lambda_n \\rightharpoonup^* f \\lambda}")#text(" for any smooth ")#mi("{f}")#text("; similarly, if ")#mi("{\\lambda_n \\rightharpoonup^* \\lambda}")#text(", ")#mi("{\\mu_n \\rightharpoonup^* \\mu}")#text(", and ")#mi("{a_n \\rightarrow a}")#text(", ")#mi("{b_n \\rightarrow b}")#text(" are sequences of real numbers, then ")#mi("{a_n \\lambda_n + b_n \\mu_n \\rightharpoonup^* a \\lambda + b \\mu}")#text(".")

#text("Suppose that one places a norm or seminorm ")#mi("{\\| \\|_X}")#text(" on ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(". Then one can define a subspace ")#mi("{X^*}")#text(" of the space of distributions, defined to be the space of all distributions ")#mi("{\\lambda}")#text(" for which the norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\lambda \\right\\|_{X^*} := \\sup_{\\phi \\in C^\\infty_c(U \\rightarrow {\\bf R}): \\left\\|\\phi \\right\\|_X \\leq 1} \\left|\\langle \\lambda, \\phi \\rangle\\right|", block: true)]]

#text("is finite. For instance, if ")#mi("{X}")#text(" is the ")#mi("{L^p}")#text(" norm for some ")#mi("{1 \\leq p < \\infty}")#text(", then ")#mi("{X^*}")#text(" is just the dual space ")#mi("{L^{p^{\\prime}}(U \\rightarrow {\\bf R})}")#text(" (with the (equivalence classes of) locally integrable functions in ")#mi("{L^{p^{\\prime}}(U \\rightarrow {\\bf R})}")#text(" identified with distributions as above).")

#text("We have the following version of the Banach-Alaoglu theorem which allows us to easily create sequences that converge in the sense of distributions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Variant of Banach-Alaoglu)")]#text(" ")#metadata(none) <tao-970f519c2cadbcefb1e8>#text(" Suppose that ")#mi("{\\| \\|_X}")#text(" is a norm or seminorm on ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" which makes the space ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" separable. Let ")#mi("{\\lambda_n}")#text(" be a bounded sequence in ")#mi("{X^*}")#text(". Then there is a subsequence of the ")#mi("{\\lambda_n}")#text(" which converges in the sense of distributions to a limit ")#mi("{\\lambda \\in X^*}")#text(".")
]

#emph[#text("Proof:")]#text(" By hypothesis, there is a constant ")#mi("{C}")#text(" such that ")#metadata(none) <tao-da3274a0f3c936fdbb17>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\langle \\lambda_n, \\phi \\rangle\\right| \\leq C \\left\\|\\phi \\right\\|_X", block: true)]]

#text(" ")#text(" for all ")#mi("{\\phi \\in C^\\infty_c(U \\rightarrow {\\bf R})}")#text(". For each given ")#mi("{\\phi}")#text(", we may thus pass to a subsequence of ")#mi("{\\lambda_n}")#text(" such that ")#mi("{\\langle \\lambda_n, \\phi \\rangle}")#text(" converges to a limit. Passing to a subsequence a countably infinite number of times and using the Arzelá-Ascoli diagonalisation trick, we can thus find a dense subset ")#mi("{{\\mathcal D}}")#text(" of ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(" (using the ")#mi("{\\| \\|_X}")#text(" metric) and a subsequence ")#mi("{\\lambda_{n_j}}")#text(" of the ")#mi("{\\lambda_n}")#text(" such that the limit ")#mi("{\\lim_{j \\rightarrow \\infty} \\langle \\lambda_{n_j}, \\phi \\rangle}")#text(" exists for every ")#mi("{\\phi \\in {\\mathcal D}}")#text(", and hence for every ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d)}")#text(" by a limiting argument and ")#link(<tao-da3274a0f3c936fdbb17>)[#text("(1)")]#text(". If one then defines ")#mi("{\\lambda}")#text(" to be the function")

#align(center)[#tao-fit-display[#mitex("\\langle \\lambda,\\phi \\rangle := \\lim_{j \\rightarrow \\infty} \\langle \\lambda_{n_j}, \\phi \\rangle,")]]

#text("then one can verify that ")#mi("{\\lambda}")#text(" is a distribution, and by ")#link(<tao-da3274a0f3c936fdbb17>)[#text("(1)")]#text(" we will have ")#mi("{\\lambda \\in X^*}")#text(". By construction, ")#mi("{\\lambda_{n_j}}")#text(" converges in the sense of distributions to ")#mi("{\\lambda}")#text(", and we are done. ")#mi("\\Box")

#text("It is important to note that there is no uniqueness claimed for ")#mi("{\\lambda}")#text("; while any given subsequence of the ")#mi("{\\lambda_n}")#text(" can have at most one limit ")#mi("{\\lambda}")#text(", it is certainly possible for different subsequences to converge to different limits. Also, the proposition only applies for spaces ")#mi("{X^*}")#text(" that have preduals ")#mi("{X}")#text("; this covers many popular function spaces, such as ")#mi("{L^p({\\bf R}^d \\rightarrow {\\bf R})}")#text(" spaces for ")#mi("{1 < p \\leq \\infty}")#text(", but omits endpoint spaces such as ")#mi("{L^1({\\bf R}^d \\rightarrow {\\bf R})}")#text(" or ")#mi("{C_0({\\bf R}^d \\rightarrow {\\bf R})}")#text(". (For instance, approximations to the identity are uniformly bounded in ")#mi("{L^1}")#text(", but converge weakly to a Dirac mass, which lies outside of ")#mi("{L^1}")#text(".)")

#text("From definition we see that if ")#mi("{\\lambda_n \\rightharpoonup^* \\lambda}")#text(", then we have the Fatou-type lemma ")#metadata(none) <tao-fee9c0a0cd6b109ede4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| \\lambda \\right\\|_{X^*} \\leq \\liminf_{n \\rightarrow \\infty} \\left\\| \\lambda_n \\right\\|_{X^*}.", block: true)]]

#text(" ")#text(" Thus, upper bounds on the approximating distributions ")#mi("{\\lambda_n}")#text(" are usually inherited by their limit ")#mi("{\\lambda}")#text(". However, it is essential to be aware that the same is not true for lower bounds; there can be “loss of mass” in the limit. The following four examples illustrate some key ways in which this can occur:")

#list(
[#text("(Escape to spatial infinity) If ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d \\rightarrow {\\bf R})}")#text(" is a non-zero test function, and ")#mi("{x_n}")#text(" is a sequence in ")#mi("{{\\bf R}^d}")#text(" going to infinity, then the translations ")#mi("{x \\mapsto \\phi(x-x_n)}")#text(" of ")#mi("{\\phi}")#text(" converge in the sense of distributions to zero, even though they will not go to zero in many function space norms (such as ")#mi("{L^p}")#text(").")],
[#text("(Escape to frequency infinity) If ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d \\rightarrow {\\bf R})}")#text(" is a non-zero test function, and ")#mi("{\\xi_n}")#text(" is a sequence in ")#mi("{{\\bf R}^d}")#text(" going to infinity, then the modulations ")#mi("{x \\mapsto \\cos(2\\pi \\xi_n \\cdot x) \\phi(x)}")#text(" of ")#mi("{\\phi}")#text(" converge in the sense of distributions to zero (cf. the ")#link("https://en.wikipedia.org/wiki/Riemann%E2%80%93Lebesgue_lemma")[#text("Riemann-Lebesgue lemma")]#text("), even though they will not go to zero in many function space norms (such as ")#mi("{L^p}")#text(").")],
[#text("(Escape to infinitely fine scales) If ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d \\rightarrow {\\bf R})}")#text(", ")#mi("{\\lambda_n}")#text(" is a sequence of positive reals going to infinity, and ")#mi("{\\alpha < d}")#text(", then the sequence ")#mi("{x \\mapsto \\lambda_n^\\alpha \\phi(\\lambda_n x)}")#text(" converges in the sense of distributions to zero, but will not go to zero in several function space norms (e.g. ")#mi("{L^p}")#text(" with ")#mi("{p \\geq d/\\alpha}")#text(").")],
[#text("(Escape to infinitely coarse scales) If ")#mi("{\\phi \\in C^\\infty_c({\\bf R}^d \\rightarrow {\\bf R})}")#text(", ")#mi("{\\lambda_n}")#text(" is a sequence of positive reals going to zero, and ")#mi("{\\alpha > 0}")#text(", then the sequence ")#mi("{x \\mapsto \\lambda_n^\\alpha \\phi(\\lambda_n x)}")#text(" converges in the sense of distributions to zero, but will not go to zero in several function space norms (e.g. ")#mi("{L^p}")#text(" with ")#mi("{p \\leq d/\\alpha}")#text(").")]
)

#text("Related to this loss of mass phenomenon is the important fact that the operation of pointwise multiplication is generally ")#emph[#text("not")]#text(" continuous in the distributional topology: ")#mi("{\\lambda_n \\rightharpoonup^* \\lambda}")#text(" and ")#mi("{\\eta_n \\rightharpoonup^* \\eta}")#text(" does ")#emph[#text("not")]#text(" necessarily imply ")#mi("{\\lambda_n \\eta_n \\rightharpoonup^* \\lambda \\eta}")#text(" in general (in fact in many cases the products ")#mi("{\\lambda_n \\eta_n}")#text(" or ")#mi("{\\lambda \\eta}")#text(" might not even be well-defined). For instance:")

#list(
[#text("Using the escape to frequency infinity example, the functions ")#mi("{x \\mapsto \\cos(\\xi_n \\cdot x) \\phi(x)}")#text(" converge in the sense of distributions to zero, but their squares ")#mi("{x \\mapsto (\\cos(\\xi_n \\cdot x) \\phi(x))^2}")#text(" instead converge in the sense of distributions to ")#mi("{x \\mapsto \\frac{1}{2} \\phi^2(x)}")#text(", as can be seen from the double angle formula ")#mi("{\\cos(\\theta)^2 = \\frac{1}{2} + \\frac{1}{2} \\cos(2\\theta)}")#text(".")],
[#text("Using the escape to infinitely fine scales example, the functions ")#mi("{x \\mapsto \\lambda_n^\\alpha \\phi(\\lambda_n x)}")#text(" converge in the sense of distributions to zero, but their squares ")#mi("{x \\mapsto (\\lambda_n^\\alpha \\phi(\\lambda_n x))^2}")#text(" will not if ")#mi("{\\alpha > d/2}")#text(".")]
)

#text("This lack of continuity of multiplication means that one has to take a non-trivial amount of care when applying the theory of distributions to nonlinear PDE; a sufficiently careless regard for this issue (or more generally, treating distribution theory as some sort of “")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/???")[#text("magic wand")]#text("“) is likely to lead to serious errors in one’s arguments.")

#text("One way to recover continuity of pointwise multiplication is to somehow upgrade distributional convergence to stronger notions of convergence. For instance, from Hölder’s inequality one sees that if ")#mi("{\\lambda_n}")#text(" converges strongly to ")#mi("{\\lambda}")#text(" in ")#mi("{L^p(U \\rightarrow {\\bf R})}")#text(" (thus ")#mi("{\\lambda_n}")#text(" and ")#mi("{\\lambda}")#text(" both lie in ")#mi("{L^p}")#text(", and ")#tao-math("{\\left\\| \\lambda_n - \\lambda \\right\\|_{L^p}}", block: false)#text(" goes to zero), and ")#mi("{\\eta_n}")#text(" converges strongly to ")#mi("{\\eta}")#text(" in ")#mi("{L^q(U \\rightarrow {\\bf R})}")#text(", then ")#mi("{\\lambda_n \\eta_n}")#text(" will converge strongly in ")#mi("{L^r(U \\rightarrow {\\bf R})}")#text(" to ")#mi("{\\lambda \\eta}")#text(", where ")#mi("{\\frac{1}{r} = \\frac{1}{p} + \\frac{1}{q}}")#text(".")

#text("One key way to obtain strong convergence in some norm is to obtain uniform bounds in an even stronger norm – so strong that the associated space embeds ")#link("https://en.wikipedia.org/wiki/Compact_operator")[#text("compactly")]#text(" in the space associated to the original norm. More precisely")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Upgrading to strong convergence)")]#text(" ")#metadata(none) <tao-7fef9479c8bc5a3c8689>#text(" Let ")#mi("{\\| \\|_X, \\| \\|_Y}")#text(" be two norms on ")#mi("{C^\\infty_c(U \\rightarrow {\\bf R})}")#text(", with associated spaces ")#mi("{X^*, Y^*}")#text(" of distributions. Suppose that ")#mi("{X^*}")#text(" embeds compactly into ")#mi("{Y^*}")#text(", that is to say the closed unit ball in ")#mi("{X^*}")#text(" is a compact subset of ")#mi("{Y^*}")#text(". If ")#mi("{\\lambda_n}")#text(" is a bounded sequence in ")#mi("{X^*}")#text(" that converges in the sense of distributions to a limit ")#mi("{\\lambda}")#text(", then ")#mi("{\\lambda_n}")#text(" converges strongly in ")#mi("{Y^*}")#text(" to ")#mi("{\\lambda}")#text(" as well.")
]

#emph[#text("Proof:")]#text(" By the Urysohn subsequence principle, it suffices to show that every subsequence of ")#mi("{\\lambda_n}")#text(" has a further subsequence that converges strongly in ")#mi("{Y^*}")#text(" to ")#mi("{\\lambda}")#text(". But by the compact embedding of ")#mi("{X^*}")#text(" into ")#mi("{Y^*}")#text(", every subsequence of ")#mi("{\\lambda_n}")#text(" has a further subsequence that converges strongly in ")#mi("{Y^*}")#text(" to some limit ")#mi("{\\lambda^{\\prime}}")#text(", and hence also in the sense of distributions to ")#mi("{\\lambda^{\\prime}}")#text(" by definition of the ")#mi("{Y^*}")#text(" norm. But thus subsequence also converges in the sense of distributions to ")#mi("{\\lambda}")#text(", and hence ")#mi("{\\lambda = \\lambda^{\\prime}}")#text(", and the claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 2. Simple examples of weak solutions — ")]]

#text("We now study weak solutions for some very simple equations, as a warmup for discussing weak solutions for Navier-Stokes.")

#text("We begin with an extremely simple initial value problem, the ODE")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = f")]]

#text("on a half-open time interval ")#mi("{[0,T)}")#text(" with ")#mi("{0 < T \\leq \\infty}")#text(", with initial condition ")#mi("{u_0 = u(0)}")#text(", where ")#mi("{f: [0,T) \\rightarrow {\\bf R}}")#text(" and ")#mi("{u_0 \\in {\\bf R}}")#text(" given and ")#mi("{u: [0,T) \\rightarrow {\\bf R}}")#text(" is the unknown. Of course, when ")#mi("{f,u}")#text(" are smooth, then the fundamental theorem of calculus gives the unique solution")

#metadata(none) <tao-469cc643a19fb75901e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("u(t) = u_0 + \\int_0^t f(s)\\ ds")]]

#text("for ")#mi("{t \\in [0,T)}")#text(". If one integrates the identity ")#mi("{\\partial_t u - f = 0}")#text(" against a test function ")#mi("{\\phi \\in C^\\infty_c((-\\infty,T))}")#text(" (that is to say, one multiplies both sides of this identity by ")#mi("{\\phi}")#text(" and then integrates) on ")#mi("{[0,T)}")#text(", one obtains")

#align(center)[#tao-fit-display[#mitex("\\int_0^T (\\partial_t u - f)(s) \\phi(s)\\ ds = 0")]]

#text("which upon integration by parts and rearranging gives")

#align(center)[#tao-fit-display[#mitex("- \\langle u, \\partial_t \\phi \\rangle = \\langle u_0 \\delta_0, \\phi \\rangle + \\langle f, \\phi \\rangle")]]

#text("where we extend ")#mi("{u, f}")#text(" by zero to the open set ")#mi("{(-\\infty,T)}")#text(". Thus, we have")

#metadata(none) <tao-999e3bbc8148d63317b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_t u = u_0 \\delta_0 + f")]]

#text("in the sense of distributions (on ")#mi("{(-\\infty,T)}")#text("). More generally, if ")#mi("{u,f}")#text(" are locally integrable functions on ")#mi("{[0,T)}")#text(", we say that ")#mi("{u}")#text(" is a ")#emph[#text("weak solution")]#text(" to the initial value problem ")#mi("{\\partial_t u = f, u(0) =u_0}")#text(" if ")#link(<tao-999e3bbc8148d63317b8>)[#text("(4)")]#text(" holds in the sense of distributions on ")#mi("{(-\\infty,T)}")#text(". Thanks to the fundamental theorem of calculus for locally integrable functions, we still recover the unique solution ")#link(<tao-469cc643a19fb75901e5>)[#text("(3)")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{u,f: [0,T) \\rightarrow {\\bf R}}")#text(" be locally integrable functions (extended by zero to all of ")#mi("{{\\bf R}}")#text("), and let ")#mi("{u_0 \\in {\\bf R}}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{u}")#text(" is a weak solution to the initial value problem ")#mi("{\\partial_t u = f, u(0) = u_0}")#text(" in the sense that ")#link(<tao-999e3bbc8148d63317b8>)[#text("(4)")]#text(" holds in the sense of distributions on ")#mi("{(-\\infty,T)}")#text(".")],
[#text("(ii) One has ")#link(<tao-469cc643a19fb75901e5>)[#text("(3)")]#text(" for almost all ")#mi("{t \\in [0,T)}")#text(".")]
)
]

#text("Now let ")#mi("{V}")#text(" be a finite dimensional vector space, let ")#mi("{F: V \\rightarrow V}")#text(" be a continuous function, let ")#mi("{u_0 \\in V}")#text(", and consider the initial value problem ")#metadata(none) <tao-ca063aca8f620b1f1b1c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\partial_t u = F(u); \\quad u(0) = u_0")]]

#text(" ")#text(" on some forward time interval ")#mi("{[0,T)}")#text(". The Picard existence theorem lets us construct such solutions when ")#mi("{F}")#text(" is Lipschitz continuous and ")#mi("{T}")#text(" is small enough, but now we are merely requiring ")#mi("{F}")#text(" to be continuous and not necessarily Lipschitz. As in the preceding case, we introduce the notion of a weak solution. If ")#mi("{u}")#text(" is locally bounded (and measurable) on ")#mi("{[0,T)}")#text(", then ")#mi("{F(u)}")#text(" will be locally integrable on ")#mi("{[0,T)}")#text("; we then extend ")#mi("{u, F(u)}")#text(" by zero to be distributions on ")#mi("{(-\\infty,T)}")#text(", and we say that ")#mi("{u}")#text(" is a ")#emph[#text("weak solution")]#text(" to ")#link(<tao-ca063aca8f620b1f1b1c>)[#text("(5)")]#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = u_0 \\delta_0 + F(u)")]]

#text("in the sense of distributions on ")#mi("{(-\\infty,T)}")#text(", or equivalently that one has the identity")

#align(center)[#tao-fit-display[#mitex("- \\int_0^T u(s) \\partial_t \\phi(s)\\ ds = u_0 \\phi(0) + \\int_0^T F(u(s)) \\phi(s)\\ ds")]]

#text("for all test functions ")#mi("{\\phi}")#text(" compactly supported in ")#mi("{(-\\infty,T)}")#text(". In this simple ODE setting, the notion of a weak solution coincides with stronger notions of solutions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-fd6c6fd81e04b6632785>#text(" Let ")#mi("{V}")#text(" be finite dimensional, let ")#mi("{F: V \\rightarrow V}")#text(" be continuous, let ")#mi("{u_0 \\in V}")#text(", and let ")#mi("{u: [0,T) \\rightarrow V}")#text(" be locally bounded and measurable. Show that the following are equivalent:")

#list(
[#text("(i) (Weak solution) ")#mi("{u}")#text(" is a weak solution to ")#link(<tao-ca063aca8f620b1f1b1c>)[#text("(5)")]#text(" on ")#mi("{[0,T)}")#text(".")],
[#text("(ii) (Mild solution) After modification on a set of measure zero, ")#mi("{u}")#text(" is continuous and ")#mi("{u(t) = u_0 + \\int_0^t F(u(s))\\ ds}")#text(" for all ")#mi("{t \\in [0,T)}")#text(".")],
[#text("(iii) (Classical solution) After modification on a set of measure zero, ")#mi("{u}")#text(" is continuously differentiable and obeys ")#link(<tao-ca063aca8f620b1f1b1c>)[#text("(5)")]#text(" for all ")#mi("{t \\in [0,T)}")#text(".")]
)
]

#text("In particular, if the ODE initial value problem ")#link(<tao-ca063aca8f620b1f1b1c>)[#text("(5)")]#text(" exhibits finite time blowup for its (unique) classical solution, then it will also do so for weak solutions (with exactly the same blouwp time). This will be in contrast with the situation for PDE, in which it is possible for weak solutions to persist beyond the time in which classical solutions exist.")

#text("Now we give a compactness argument to produce weak solutions (which will then be classical solutions, by the above exercise):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6 (Weak existence)")]#text(" ")#metadata(none) <tao-3fa36bd90d08ff11cb1b>#text(" Let ")#mi("{V}")#text(" be a finite dimensional vector space, let ")#mi("{R>0}")#text(", let ")#mi("{u_0 \\in \\overline{B(0,R)}}")#text(", and let ")#mi("{F: V \\rightarrow V}")#text(" be a continuous function. Let ")#mi("{T>0}")#text(" be the time")

#align(center)[#tao-fit-display[#tao-math("T := \\frac{R}{\\sup_{u \\in \\overline{B(0,2R)}} \\left\\|F(u)\\right\\|_V}.", block: true)]]

#text("Then there exists a continuously differentiable solution ")#mi("{u: [0,T) \\rightarrow \\overline{B(0,2R)}}")#text(" to the initial value problem ")#link(<tao-ca063aca8f620b1f1b1c>)[#text("(5)")]#text(" on ")#mi("{[0,T)}")#text(".")
]

#emph[#text("Proof:")]#text(" By construction, we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{u \\in \\overline{B(0,2R)}} \\left\\|F(u)\\right\\|_V = \\frac{R}{T}.", block: true)]]

#text("Using the Weierstrass approximation theorem (or Stone-Weierstrass theorem), we can express ")#mi("{F}")#text(" on ")#mi("{\\overline{B(0,2R)}}")#text(" as the uniform limit of Lipschitz continuous functions ")#mi("{F_n: \\overline{B(0,2R)} \\rightarrow V}")#text(", such that")

#metadata(none) <tao-c4fc623057c6521b2fcc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\sup_{u \\in \\overline{B(0,2R)}} \\left\\|F_n(u)\\right\\|_V \\leq \\frac{R}{T}.", block: true)]]

#text("for all ")#mi("{n}")#text("; we can then extend ")#mi("{F_n}")#text(" in a Lipschitz continuous fashion to all of ")#mi("{V}")#text(". (The Lipschitz constant of ")#mi("{F_n}")#text(" is permitted to diverge to infinity as ")#mi("{n \\rightarrow \\infty}")#text("). We can then apply the Picard existence theorem (Theorem 8 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text("), for each ")#mi("{n}")#text(" we have a (continuously differentiable) maximal Cauchy development ")#mi("{u_n: [0,T_n) \\rightarrow V}")#text(" of the initial value problem")

#metadata(none) <tao-81bd5f38081ad07262ff>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\partial_t u_n = F_n(u_n); \\quad u_n(0) = u_0")]]

#text("with ")#tao-math("{\\left\\|u_n(t)\\right\\|_V \\rightarrow \\infty}", block: false)#text(" as ")#mi("{t \\rightarrow T_n^-}")#text(" if ")#mi("{T_n}")#text(" is finite. (We could also solve the ODE backwards in time, but will not need to do so here.) We now claim that ")#mi("{T_n \\geq T}")#text(", and furthermore that one has the uniform bound")

#metadata(none) <tao-bb61cfb3ba1059ecb596>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|u_n(t)\\right\\|_V \\leq 2R", block: true)]]

#text("for all ")#mi("{n}")#text(" and all ")#mi("{0 \\leq t \\leq T}")#text(". Indeed, if this were not the case then by continuity (and the fact that ")#tao-math("{\\left\\|u_n(0)\\right\\|_V = \\left\\|u_0\\right\\|_V \\leq R < 2R}", block: false)#text(") there would be some ")#mi("{n}")#text(" and some ")#mi("{0 < t_n < \\min(T,T_n)}")#text(" such that ")#tao-math("{\\left\\|u_n(t_n)\\right\\|_V = 2R}", block: false)#text(", and ")#tao-math("{\\left\\| u_n(t)\\right\\|_V < 2R}", block: false)#text(" for all ")#mi("{0 \\leq t < t_n}")#text(". But then by the fundamental theorem of calculus and the triangle inequality (and ")#link(<tao-c4fc623057c6521b2fcc>)[#text("(6)")]#text(") we have")

#tao-aligned(keep: true)[


#tao-math("2R  & = \\left\\| u_n(t_n) \\right\\|_V \\leq \\left\\|u_0\\right\\|_V + \\int_0^{t_n} \\left\\| F(u_n(s))\\right\\|_V\\ ds", block: true)



#tao-math(" & \\leq R + t_n \\sup_{u \\in \\overline{B(0,2R)}} \\left\\|F_n(u)\\right\\|_V", block: true)



#tao-math(" & < 2R,", block: true)
]

#text("a contradiction. Thus we have ")#link(<tao-bb61cfb3ba1059ecb596>)[#text("(8)")]#text(" for all ")#mi("{n}")#text(" and ")#mi("{0 \\leq t \\leq T}")#text(", so ")#mi("{u_n}")#text(" takes values in ")#mi("{\\overline{B(0,2R)}}")#text(" on ")#mi("{[0,T]}")#text(". Applying ")#link(<tao-81bd5f38081ad07262ff>)[#text("(7)")]#text(", ")#link(<tao-c4fc623057c6521b2fcc>)[#text("(6)")]#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\partial_t u_n(t) \\right\\|_V \\leq \\frac{R}{T}", block: true)]]

#text("for all ")#mi("{n}")#text(" and all ")#mi("{0 \\leq t \\leq T}")#text("; in particular, the ")#mi("{u_n}")#text(" are uniformly Lipschitz continuous and uniformly bounded on ")#mi("{[0,T]}")#text(". Applying the Arzelá-Ascoli theorem, we can then pass to a subsequence in which the ")#mi("{u_n}")#text(" converge uniformly on ")#mi("{[0,T)}")#text(" to a limit ")#mi("{u}")#text(", which then also takes values in ")#mi("{\\overline{B(0,2R)}}")#text(". (Alternatively, one could use Proposition ")#link(<tao-970f519c2cadbcefb1e8>)[#text("2")]#text(" to have ")#mi("{u_n}")#text(" converge in the sense of distributions, followed by Proposition ")#link(<tao-7fef9479c8bc5a3c8689>)[#text("3")]#text(" to upgrade to uniform convergence.) As ")#mi("{F_n}")#text(" converges uniformly to ")#mi("{F}")#text(" on ")#mi("{\\overline{B(0,2R)}}")#text(", we conclude that ")#mi("{F_n(u_n)}")#text(" converges uniformly to ")#mi("{F(u)}")#text(" on ")#mi("{[0,T)}")#text(". Since we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t u_n = u_0 \\delta_0 + F_n(u_n)")]]

#text("in the sense of distributions (extending ")#mi("{u_n}")#text(", ")#mi("{F_n(u_n)}")#text(" by zero to ")#mi("{(-\\infty,T)}")#text("), we can take distributional limits and conclude that")

#align(center)[#tao-fit-display[#mitex("\\partial_t u = u_0 \\delta_0 + F(u)")]]

#text("in the sense of distributions, which by Exercise ")#link(<tao-fd6c6fd81e04b6632785>)[#text("5")]#text(" shows that ")#mi("{u: [0,T) \\rightarrow \\overline{B(0,2R)}}")#text(" is a continuously differentiable solution to the initial value problem ")#link(<tao-ca063aca8f620b1f1b1c>)[#text("(5)")]#text(" as required. ")#mi("\\Box")

#text("In contrast to the Picard theory when ")#mi("{F}")#text(" is Lipschitz, Proposition ")#link(<tao-3fa36bd90d08ff11cb1b>)[#text("6")]#text(" does not assert any uniqueness of the solution ")#mi("{u}")#text(" to the initial value problem ")#link(<tao-ca063aca8f620b1f1b1c>)[#text("(5)")]#text(". And in fact uniqueness often fails once the Lipschitz hypothesis is dropped! Consider the simple example of the scalar initial value problem")

#align(center)[#tao-fit-display[#tao-math("\\partial_t u = \\left|u\\right|^{1/2}; \\quad u(0) = 0", block: true)]]

#text("on ")#mi("{[0,+\\infty)}")#text(", so the nonlinearity here is the continuous, but not Lipschitz continuous, function ")#tao-math("{u \\mapsto \\left|u\\right|^{1/2}}", block: false)#text(". Clearly the zero function ")#mi("{u(0) = 0}")#text(" is a solution to this ODE. But so is the function ")#mi("{u(t) := t^2/4}")#text(". In fact there are a continuum of solutions: for any ")#mi("{t_0 \\geq 0}")#text(", the function ")#mi("{u(t) := \\max(t-t_0,0)^2/4}")#text(" is a solution. Proposition ")#link(<tao-3fa36bd90d08ff11cb1b>)[#text("6")]#text(" will select one of these solutions, but the precise solution selected will depend on the choice of approximating functions ")#mi("{F_n}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Let ")#mi("{t_0>0}")#text(". For each ")#mi("{n}")#text(", let ")#mi("{F_n: {\\bf R} \\rightarrow {\\bf R}}")#text(" denote the function")

#align(center)[#tao-fit-display[#tao-math("F_n(u) := \\left( \\max( \\left|u\\right|-\\frac{1}{n}, 0 ) + \\frac{1}{n^2 t_0^2} \\right)^{1/2}.", block: true)]]

#list(
[#text("(i) Show that each ")#mi("{F_n}")#text(" is Lipschitz continuous, and the ")#mi("{F_n}")#text(" converge uniformly to the function ")#tao-math("{F(u) := \\left|u\\right|^{1/2}}", block: false)#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#text("(ii) Show that the solution ")#mi("{u_n: [0,+\\infty) \\rightarrow {\\bf R}}")#text(" to the initial value problem ")#mi("{\\partial_t u_n = F_n(u_n), u_n(0) = 0}")#text(" is given by")

#align(center)[#tao-fit-display[#mitex("u_n(t) = \\frac{t}{nt_0}")]]

#text("for ")#mi("{0 \\leq t \\leq t_0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("u_n(t) = \\frac{1}{n} - \\frac{1}{n^2 t_0^2} + \\frac{ \\left( t - t_0 + \\frac{2}{nt_0} \\right)^2}{4}")]]

#text("for ")#mi("{t \\geq t_0}")#text(".")],
[#text("(iii) Show that as ")#mi("{n \\rightarrow \\infty}")#text(", ")#mi("{u_n}")#text(" converges locally uniformly to the function ")#mi("{t \\mapsto \\max(t-t_0,0)^2/4}")#text(".")]
)
]

#text("Now we give a simple example of a weak solution construction for a PDE, namely the linear transport equation ")#metadata(none) <tao-411b0496da5eeced5314>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\partial_t u(t,x) + v(x) \\partial_x u(t,x) = 0; \\quad u(0,x) = u_0(x)")]]

#text(" ")#text(" where the initial data ")#mi("{u_0: {\\bf R} \\rightarrow {\\bf R}}")#text(" and a position-dependent velocity field ")#mi("{v: {\\bf R} \\rightarrow {\\bf R}}")#text(" is given, and ")#mi("{u: [0,+\\infty) \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" is the unknown field.")

#text("Suppose for the moment that ")#mi("{u_0, v, u}")#text(" are smooth, with ")#mi("{v}")#text(" bounded. Then one can solve this problem using the ")#link("https://en.wikipedia.org/wiki/Method_of_characteristics")[#text("method of characteristics")]#text(". For any ")#mi("{x_0 \\in {\\bf R}}")#text(", let ")#mi("{\\Phi(t)(x_0)}")#text(" denote the solution to the initial value problem ")#metadata(none) <tao-90c12db963cc6c880aa8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\partial_t \\Phi(t)(x_0) = v(\\Phi(t)(x_0)); \\quad \\Phi(0)(x_0) = x_0.")]]

#text(" ")#text(" The Picard existence theorem gives us a smooth maximal Cauchy development ")#mi("{t \\mapsto \\Phi(t)(x_0)}")#text(" for this problem; as ")#mi("{v}")#text(" is bounded, this development cannot go to infinity in finite time (either forward or backwards in time), and so the solution is global. Thus we have a well-defined map ")#mi("{\\Phi(t): {\\bf R} \\rightarrow {\\bf R}}")#text(" for each time ")#mi("{t \\in {\\bf R}}")#text(". In fact we can say more:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Let the assumptions be as above.")

#list(
[#text("(i) Show the semigroup property ")#mi("{\\Phi(t_1 + t_2) = \\Phi(t_1) \\circ \\Phi(t_2)}")#text(" for all ")#mi("{t_1,t_2 \\in {\\bf R}}")#text(".")],
[#text("(ii) Show that ")#mi("{\\Phi(t)}")#text(" is a homeomorphism for each ")#mi("{t \\in {\\bf R}}")#text(".")],
[#text("(iii) Show that for every ")#mi("{t}")#text(", ")#mi("{\\Phi(t)}")#text(" is differentiable, and the derivative ")#mi("{\\partial_x \\Phi(t)}")#text(" obeys the linear initial value problem")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\partial_x \\Phi(t)(x) = v^{\\prime}(\\Phi(t)(x)) \\partial_x \\Phi(t)(x); \\quad \\partial_x \\Phi(0)(x) = 1.")]]

#text("(Hint: while this system formally can be obtained by differentiating ")#link(<tao-90c12db963cc6c880aa8>)[#text("(10)")]#text(" in ")#mi("{x_0}")#text(", this formal differentiation requires rigorous justification. One can for instance proceed by first principles, showing that the Newton quotients ")#mi("{\\frac{\\Phi(t)(x+h)-\\Phi(t)(x)}{h}}")#text(" approximately obey this equation, and then using a Gronwall inequality argument to compare this approximate solution to an exact solution.)")],
[#text("(iv) Show that ")#mi("{\\Phi(t)}")#text(" is a ")#mi("{C^1}")#text(" ")#link("https://en.wikipedia.org/wiki/Diffeomorphism")[#text("diffeomorphism")]#text(" for each ")#mi("{t}")#text("; that is to say, ")#mi("{\\Phi(t)}")#text(" and its inverse are both continuously differentiable.")],
[#text("(v) Show that ")#mi("{\\Phi(t)}")#text(" is a smooth diffeomorphism (that is to say ")#mi("{\\Phi(t)}")#text(" and its inverse are both smooth). (Caution: one may require a bit of planning to avoid the proof becoming extremely long and tedious.)")]
)
]

#text("From ")#link(<tao-90c12db963cc6c880aa8>)[#text("(10)")]#text(" and the chain rule we have the identity")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} u( t, \\Phi(t)(x) ) = (\\partial_t u + v \\partial_x u)( t, \\Phi(t)(x) )")]]

#text("for any smooth function ")#mi("{u}")#text(" (cf. the material derivative used in ")#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/")[#text("Notes 0")]#text("). Thus, one can rewrite the initial value problem ")#link(<tao-411b0496da5eeced5314>)[#text("(9)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} u( t, \\Phi(t)(x) ) = 0; \\quad u( 0, \\Phi(0)(x) ) = x")]]

#text("at which point it is clear that the unique smooth solution to the initial value problem ")#link(<tao-90c12db963cc6c880aa8>)[#text("(10)")]#text(" is given by")

#align(center)[#tao-fit-display[#mitex("u(t, x) := u_0( \\Phi(t)^{-1}(x) ) = u_0( \\Phi(-t)(x) ).")]]

#text("Among other things, this shows that the sup norm ")#tao-math("{\\left\\| u(t) \\right\\|_{L^\\infty({\\bf R} \\rightarrow {\\bf R})}}", block: false)#text(" is a conserved quantity:")

#metadata(none) <tao-36c4e2966694bae93561>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\| u(t) \\right\\|_{L^\\infty({\\bf R} \\rightarrow {\\bf R})} = \\left\\| u_0 \\right\\|_{L^\\infty({\\bf R} \\rightarrow {\\bf R})}.", block: true)]]

#text("Now we drop the hypothesis that ")#mi("{v}")#text(" is bounded. One can no longer assume that the trajectories ")#mi("{\\Phi(t)(x_0)}")#text(" are globally defined, or even that they are defined for a positive time independent of the starting point ")#mi("{x_0}")#text(". Nevertheless, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Weak existence)")]#text(" ")#metadata(none) <tao-8bac25169314c9760521>#text(" Let ")#mi("{v: {\\bf R} \\rightarrow {\\bf R}}")#text(" be smooth, and let ")#mi("{u_0: {\\bf R} \\rightarrow {\\bf R}}")#text(" be smooth and bounded. Then there exists a bounded measurable function ")#mi("{u: [0,+\\infty) \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" which weakly solves ")#link(<tao-90c12db963cc6c880aa8>)[#text("(10)")]#text(" in the sense that")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t,x) + v(x) \\partial_x u(t,x) = u_0(x) \\delta_0(t)")]]

#text("in the sense of distributions on ")#mi("{{\\bf R} \\times {\\bf R}}")#text(") (extending ")#mi("{u}")#text(" by zero outside of ")#mi("{[0,+\\infty) \\times {\\bf R}}")#text("), or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\int_0^\\infty \\int_{\\bf R} u(t,x) (- \\partial_t \\phi(t,x) - \\partial_x (v(x) \\phi(t,x)) )\\ dx dt")]]

#align(center)[#tao-fit-display[#mitex("= \\int_{\\bf R} u_0(x) \\phi(0,x)\\ dx")]]

#text("for any ")#mi("{\\phi \\in C^\\infty_c({\\bf R} \\times {\\bf R} \\rightarrow {\\bf R})}")#text(". Furthermore we have")

#metadata(none) <tao-9dc02223da426384268a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\| u\\right\\|_{L^\\infty([0,+\\infty) \\times {\\bf R})} \\leq \\left\\| u_0 \\right\\|_{L^\\infty({\\bf R} \\rightarrow {\\bf R})}.", block: true)]]
]

#emph[#text("Proof:")]#text(" By multiplying ")#mi("{v}")#text(" by appropriate smooth cutoff functions, we can express ")#mi("{v}")#text(" as the locally uniform limit of smooth bounded functions ")#mi("{v_n}")#text(" with ")#mi("{v_n}")#text(" equal to ")#mi("{v}")#text(" on (say) ")#mi("{[-n,n]}")#text(". By the preceding discussion, for each ")#mi("{n}")#text(" we have a smooth global solution ")#mi("{u_n: [0,+\\infty) \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" to the initial value problem")

#align(center)[#tao-fit-display[#mitex("\\partial_t u_n + v_n u_n = 0; \\quad u_n(0,x) = u_0(x)")]]

#text("on ")#mi("{[0,+\\infty) \\times {\\bf R}}")#text(", and thus")

#metadata(none) <tao-68bca10eea2ba33f6f15>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\partial_t u_n(t,x) + v_n(x) \\partial_x u_n(t,x) = u_0(x) \\delta_0(t)")]]

#text("in the sense of distributions on ")#mi("{{\\bf R} \\times {\\bf R}}")#text(". By ")#link(<tao-36c4e2966694bae93561>)[#text("(11)")]#text(", the ")#mi("{u_n}")#text(" are uniformly bounded with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u_n\\right\\|_{L^\\infty([0,+\\infty) \\times {\\bf R})} = \\left\\| u_0 \\right\\|_{L^\\infty({\\bf R} \\rightarrow {\\bf R})}.", block: true)]]

#text("Thus, by Proposition ")#link(<tao-970f519c2cadbcefb1e8>)[#text("2")]#text(", we can pass to a subsequence and assume that ")#mi("{u_n}")#text(" converges in the sense of distributions to an element ")#mi("{u}")#text(" on ")#mi("{L^\\infty({\\bf R} \\times {\\bf R})}")#text("; by ")#link(<tao-fee9c0a0cd6b109ede4b>)[#text("(2)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u_n\\right\\|_{L^\\infty([0,+\\infty) \\times {\\bf R})} \\leq \\left\\| u_0 \\right\\|_{L^\\infty({\\bf R} \\rightarrow {\\bf R})}.", block: true)]]

#text("Since the ")#mi("{u_n}")#text(" are all supported on ")#mi("{[0,+\\infty) \\times {\\bf R}}")#text(", ")#mi("{u}")#text(" is also. Taking weak limits in ")#link(<tao-68bca10eea2ba33f6f15>)[#text("(13)")]#text(" (multiplying first by a cutoff function to localise to a compact set) we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t u(t,x) + v_n(x) \\partial_x u(t,x) = u_0(x) \\delta_0(t).")]]

#text("This gives the required weak solution. ")#mi("\\Box")

#text("The following exercise shows that while one can construct global weak solutions, there is significant failure of uniqueness and persistence of regularity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Set ")#mi("{v(x) = x^2}")#text(", thus we are solving the ODE")

#metadata(none) <tao-f1ca692c1a7a49de4744>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\partial_t u(t,x) + x^2 \\partial_x u(t,x) = 0")]]

#list(
[#text("(i) If ")#mi("{f, g: {\\bf R} \\rightarrow {\\bf R}}")#text(" are bounded measurable functions, show that the function ")#mi("{u: [0,+\\infty) \\times {\\bf R} \\rightarrow {\\bf R}}")#text(" defined by")

#align(center)[#tao-fit-display[#mitex("u(t,x) := f(\\frac{1}{x} + t)")]]

#text("for ")#mi("{x>0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("u(t,x) := g(\\frac{1}{x} + t)")]]

#text("for ")#mi("{x<0}")#text(" is a weak solution to ")#link(<tao-f1ca692c1a7a49de4744>)[#text("(14)")]#text(" with initial data")

#align(center)[#tao-fit-display[#mitex("u_0(x) := f(\\frac{1}{x})")]]

#text("for ")#mi("{x>0}")#text(" and")

#align(center)[#tao-fit-display[#mitex("u_0(x) := g(\\frac{1}{x})")]]

#text("for ")#mi("{x<0}")#text(". (Note that one does not need to specify these functions at ")#mi("{x=0}")#text(", since this describes a measure zero set.)")],
[#text("(ii) Suppose further that ")#mi("{g=0}")#text(", and that ")#mi("{f}")#text(" is smooth and compactly supported in ")#mi("{(0,+\\infty)}")#text(". Show that the weak solution described in (i) is the solution constructed by Proposition ")#link(<tao-8bac25169314c9760521>)[#text("9")]#text(".")],
[#text("(iii) Show that there exist at least two bounded measurable weak solutions to ")#link(<tao-f1ca692c1a7a49de4744>)[#text("(14)")]#text(" with initial data ")#mi("{u_0=0}")#text(", thus showing that weak solutions are not unique. (Of course, at most one of these solutions could obey the inequality ")#link(<tao-9dc02223da426384268a>)[#text("(12)")]#text(", so there are some weak solutions that are not constructible using Proposition ")#link(<tao-8bac25169314c9760521>)[#text("9")]#text(".) Show that this lack of uniqueness persists even if one also demands that the weak solutions be smooth; conversely, show that there exist weak solutions with initial data ")#mi("{u_0=0}")#text(" that are discontinuous.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" As the above example illustrates, the loss of mass phenomenon for weak solutions arises because the approximants to those weak solutions “escape to infinity”in the limit, similarly, the loss of uniqueness phenomenon for weak solutions arises because the approximants “come from infinity” in the limit. In this particular case of a transport equation, the infinity is spatial infinity, but for other types of PDE it can be possible for approximate solutions to escape from, or come from, other types of infinity, such as frequency infinity, fine scale infinity, or coarse scale infinity. (In the former two cases, the loss of mass phenomenon will also be closely related to a loss of regularity in the weak solution.) Eliminating these types of “bad behaviour” for weak solutions is morally equivalent to obtaining uniform bounds for the approximating solutions that are strong enough to prevent such solutions from having a significant presence near infinity; in the case of Navier-Stokes, this basically corresponds to controlling such solutions uniformly in subcritical or critical norms.")
]

#heading(level: 1)[#strong[#text(" — 3. Leray-Hopf weak solutions — ")]]

#text("We now adapt the above formalism to construct weak solutions to the Navier-Stokes equations, following the fundamental work of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1555394")[#text("Leray")]#text(", who constructed such solutions on ")#mi("{{\\bf R}^d}")#text(", ")#mi("{d \\geq 2}")#text(" (as before, we discard the ")#mi("{d=1}")#text(" case as being degenerate). The later ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=50423")[#text("work of Hopf")]#text(" extended this construction to other domains, but we will work solely with ")#mi("{{\\bf R}^d}")#text(" here for simplicity.")

#text("In the ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("previous set of notes")]#text(", several formulations of the Navier-Stokes equations were considered. For smooth solutions (with suitable decay at infinity, and in some cases a normalisation hypothesis on the pressure also), these formulations were shown to be essentially equivalent to each other. But at the very low level of regularity that weak solutions are known to have, these different formulations of Navier-Stokes are no longer obviously equivalent. As such, there is not a single notion of a “weak solution to the Navier-Stokes equations”; the notion depends on which formulation of these equations one chooses to work with. This leads to a number of rather technical subtleties when developing a theory of weak solutions. We will largely avoid these issues here, focusing on a specific type of weak solution that arises from our version of Leray’s construction.")

#text("It will be convenient to work with the formulation")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + \\mathbb{P}( \\nabla \\cdot (u \\otimes u) ) = \\nu \\Delta u; \\quad u(0) = u_0")]]

#text("of the initial value problem for the Navier-Stokes equations. Writing out the divergence ")#mi("{\\nabla \\cdot (u \\otimes u)}")#text(" as ")#mi("{\\partial_j (u_j u)}")#text(" and interchanging ")#mi("{\\partial_j}")#text(" with ")#mi("{\\mathbb{P}}")#text(", we can rewrite this as")

#metadata(none) <tao-83e1afedfca86f152655>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\partial_t u + \\partial_j \\mathbb{P}( u_j u ) = \\nu \\Delta u; \\quad u(0) = u_0.")]]

#text("The point of this formulation is that it can be interpreted distributionally with fairly weak regularity hypotheses on ")#mi("{u}")#text(". For Leray’s construction, it turns out that a natural regularity class is")

#metadata(none) <tao-e9d00c39afc8fc0d6139>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("u \\in L^\\infty_t L^2_x( [0,\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d ); \\quad \\nabla u \\in L^2_t L^2_x([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2}),")]]

#text("basically because the norms associated to these function spaces are precisely the quantities that will be controlled by the important ")#emph[#text("energy identity")]#text(" that we will discuss later. With this regularity, we have in particular that")

#align(center)[#tao-fit-display[#mitex("u \\in L^2_{t,loc} H^1_x( [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("by which we mean that")

#align(center)[#tao-fit-display[#mitex("u \\in L^2_{t} H^1_x( [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("for all ")#mi("{T>0}")#text(". Next, we need a special case of the Sobolev embedding theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Non-endpoint Sobolev embedding theorem)")]#text(" Let ")#mi("{2 \\leq p \\leq \\infty}")#text(" be such that ")#mi("{\\frac{1}{p} > \\frac{1}{2} - \\frac{1}{d}}")#text(". Show that for any ")#mi("{u \\in H^1({\\bf R}^d \\rightarrow {\\bf R})}")#text(", one has ")#mi("{u \\in L^p({\\bf R}^d \\rightarrow {\\bf R})}")#text(" with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^p({\\bf R}^d \\rightarrow {\\bf R})} \\lesssim_{d,p} \\left\\| u \\right\\|_{H^1({\\bf R}^d \\rightarrow {\\bf R})}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" this non-endpoint case can be proven using the Littlewood-Paley projections from the ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("previous set of notes")]#text(".) The endpoint case ")#mi("{\\frac{1}{p} = \\frac{1}{2} - \\frac{1}{d}}")#text(" of the Sobolev embedding theorem is also true (as long as ")#mi("{p < \\infty}")#text("), but the proof requires the Hardy-Littlewood-Sobolev fractional integration inequality, which we will not cover here; see for instance ")#link("https://terrytao.wordpress.com/2009/04/30/245c-notes-4-sobolev-spaces/")[#text("these previous lecture notes")]#text(".")
]

#text("We conclude that there is some ")#mi("{p>2}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("u \\in L^2_{t,loc} L^p_x( [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("and hence by Hölder’s inequality")

#align(center)[#tao-fit-display[#mitex("u_j u \\in L^1_{t,loc} L^{p/2}_x( [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("for all ")#mi("{j=1,\\dots,d}")#text(". (The precise value of ")#mi("{p}")#text(" is not terribly important for our arguments.)")

#text("Next, we invoke the following result from harmonic analysis:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13 (Boundedness of the Leray projection)")]#text(" ")#metadata(none) <tao-12c38af71f5c716a31b0>#text(" For any ")#mi("{1 < p < \\infty}")#text(", one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathbb{P} f \\right\\|_{L^p({\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_p \\left\\| f\\right\\|_{L^p({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{f \\in C^\\infty_c({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(". In particular, ")#mi("{\\mathbb{P}}")#text(" has a unique continuous extension to a linear map from ")#mi("{L^p({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" to itself.")
]

#text("For ")#mi("{p=2}")#text(", this proposition follows easily from Plancherel’s theorem. For ")#mi("{p \\neq 2}")#text(", the proposition is more non-trivial, and is usually proven using the ")#link("https://en.wikipedia.org/wiki/Singular_integral_operators_of_convolution_type")[#text("Calderón-Zygmund theory of singular integrals")]#text(". A proof can be found for instance in Stein’s “")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=290095")[#text("Singular integrals")]#text("“; we shall simply assume it as a black box here. We conclude that for ")#mi("{u}")#text(" in the regularity class ")#link(<tao-e9d00c39afc8fc0d6139>)[#text("(16)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\mathbb{P}( u_j u ) \\in L^1_{t,loc} L^{p/2}_x( [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d).")]]

#text("In particular, ")#mi("{\\mathbb{P}( u_j u )}")#text(" is locally integrable in spacetime and thus can be interpreted as a distribution on ")#mi("{{\\bf R} \\times {\\bf R}^d}")#text(" (after extending by zero outside of ")#mi("{[0,+\\infty) \\times {\\bf R}^d}")#text(". Thus ")#mi("{\\partial_j \\mathbb{P}( u_j u )}")#text(" also can be interpreted as a distribution. Similarly for the other two terms ")#mi("{\\partial_t u, \\nu \\Delta u}")#text(" in ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(". We then say that a function ")#mi("{u}")#text(" in the regularity class ")#link(<tao-e9d00c39afc8fc0d6139>)[#text("(16)")]#text(" is a ")#emph[#text("weak solution")]#text(" to the initial value problem ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(" for some distribution ")#mi("{u_0}")#text(" if one has")

#metadata(none) <tao-b3b1b8da8347e7b1153e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("\\partial_t u(t,x) + \\partial_j \\mathbb{P}( u_j u )(t,x) = \\nu \\Delta u(t,x) + u_0(x) \\delta_0(t)")]]

#text("in the sense of spacetime distributions on ")#mi("{{\\bf R} \\times {\\bf R}^d}")#text(" (after extending ")#mi("{u}")#text(" by zero outside of ")#mi("{[0,+\\infty) \\times {\\bf R}^d}")#text(". Unpacking the definitions of distributional derivative, this is equivalent to requiring that")

#align(center)[#tao-fit-display[#mitex("\\int_{[0,\\infty)} \\int_{{\\bf R}^d} - u \\partial_t \\psi - \\mathbb{P}(u_j u) \\partial_j \\psi - \\nu u \\Delta \\psi\\ dx dt = \\int_{{\\bf R}^d} u_0(x) \\psi(0,x)\\ dx")]]

#text("for all spacetime test functions ")#mi("{\\psi \\in C^\\infty_c({\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(".")

#text("We can now state a form of Leray’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Leray’s weak solutions)")]#text(" ")#metadata(none) <tao-8907fd712c5bd01e5f48>#text(" Let ")#mi("{u_0 \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence free (in the sense of distributions), and let ")#mi("{\\nu>0}")#text(". Then there exists a weak solution ")#mi("{u}")#text(" to the initial value problem ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(". Furthermore, ")#mi("{u}")#text(" obeys the energy inequality")

#metadata(none) <tao-6cb3f51eed90e7dbe08c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\int_{{\\bf R}^d} u(T,x)^2\\ dx + 2\\nu \\int_0^T \\int_{{\\bf R}^d} \\left|\\nabla u(t,x)\\right|^2\\ dx dt", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq \\int_{{\\bf R}^d} u_0(x)^2\\ dx")]]

#text("for almost every ")#mi("{T>0}")#text(".")
]

#text("We now prove this theorem using the same sort of scheme that was used previously to construct weak solutions to other equations. We first need to set up some approximate solutions to ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(". There are many ways to do this – the traditional way being to use some variant of the ")#link("https://en.wikipedia.org/wiki/Galerkin_method")[#text("Galerkin method")]#text(" – but we will proceed using the Littlewood-Paley projections that were already introduced in the ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("previous set of notes")]#text(". Let ")#mi("{N^{(n)}}")#text(" be a sequence of dyadic integers going to infinity. We consider solutions ")#mi("{u^{(n)}: [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" to the initial value problem ")#metadata(none) <tao-60539cc918e124a98a4a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\partial_t u^{(n)} + \\partial_j P_{\\leq N^{(n)}} \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) ) = \\nu \\Delta u^{(n)}; \\quad u^{(n)}(0) = P_{\\leq N^{(n)}} u_0;")]]

#text(" ")#text(" this is ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(" except with some additional factors of ")#mi("{P_{\\leq N^{(n)}}}")#text(" inserted in the initial data and in the nonlinear term. Formally, in the limit ")#mi("{n \\rightarrow \\infty}")#text(", the factors ")#mi("{P_{\\leq N^{(n)}}}")#text(" should converge to the identity and one should recover ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text("; but this requires rigorous justification. The number of factors of ")#mi("{P_{\\leq N^{(n)}}}")#text(" in the nonlinear term may seem excessive, but as we shall see, this turns out to be a convenient choice as it will lead to a favourable energy inequality for these solutions.")

#text("The Fujita-Kato theory of mild solutions for ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(" from the ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("previous set of notes")]#text(" can be easily adapted to the initial value problem ")#link(<tao-60539cc918e124a98a4a>)[#text("(19)")]#text(", because the projections ")#mi("{P_{\\leq N^{(n)}}}")#text(" are bounded on all the function spaces of interest. Thus, for any ")#mi("{s \\geq 0}")#text(", and any divergence-free ")#mi("{u_0 \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", we can define an ")#mi("{H^s}")#text("-mild solution to ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(" on a time interval ")#mi("{[0,T]}")#text(" to be a function ")#mi("{u^{(n)}: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" in the function space")

#align(center)[#tao-fit-display[#mitex("u^{(n)} \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d) \\cap L^2_t H^{s+1}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)")]]

#text("such that")

#align(center)[#tao-fit-display[#mitex("u^{(n)}(t) = e^{\\nu t \\Delta} P_{\\leq N^{(n)}} u_0 + \\int_0^t e^{\\nu (t-t^{\\prime})\\Delta}\\partial_j P_{\\leq N^{(n)}} \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j(t^{\\prime})) (P_{\\leq N^{(n)}} u^{(n)}(t^{\\prime})) )\\ dt^{\\prime}")]]

#text("(in the sense of distributions) for all ")#mi("{t \\in [0,T]}")#text("; a ")#mi("{H^s}")#text(" mild solution on ")#mi("{[0,T_*) \\times {\\bf R}^d}")#text(" is a solution that is an ")#mi("{H^s}")#text(" mild solution when restricted to every compact subinterval ")#mi("{[0,T] \\times {\\bf R}^d}")#text(". Note that the frequency-localised initial data ")#mi("{P_{\\leq N^{(n)}} u_0}")#text(" lies in every ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R})}")#text(" space. By a modification of the theory of the previous set of notes, we thus see that there is a maximal Cauchy development ")#mi("{u^{(n)}: [0,T_*^{(n)}) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" that is a smooth solution to ")#link(<tao-60539cc918e124a98a4a>)[#text("(19)")]#text(" (and an ")#mi("{H^s}")#text(" mild solution for every ")#mi("{s \\geq 0}")#text("), with ")#tao-math("{\\left\\|u^{(n)} \\right\\|_{L^\\infty_t L^\\infty_x([0,T_*^{(n)}))} = \\infty}", block: false)#text(" if ")#mi("{T_*^{(n)} < \\infty}")#text(". Note that as ")#mi("{u_0}")#text(" is divergence-free, ")#mi("{e^{\\nu t \\Delta}}")#text(", ")#mi("{\\partial_j}")#text(" and ")#mi("{P_{\\leq N^{(n)}}}")#text(" preserves the divergence-free property, and ")#mi("{\\mathbb{P}}")#text(" projects to divergence-free functions, ")#mi("{u^{(n)}(t)}")#text(" is divergence-free for all ")#mi("{t}")#text(". Similarly, as ")#mi("{P_{\\leq N^{(n)}}}")#text(" projects to functions with Fourier transform supported on the ball ")#mi("{\\overline{B(0, N^{(n)})}}")#text(" in ")#mi("{{\\bf R}^d}")#text(", and this property is preserved by ")#mi("{\\partial_j}")#text(", ")#mi("{\\mathbb{P}}")#text(", and ")#mi("{e^{\\nu t \\Delta}}")#text(" we see that ")#mi("{u^{(n)}(t)}")#text(" also has Fourier transform supported on the ball ")#mi("{\\overline{B(0, N^{(n)})}}")#text(". This (non-uniformly) bounded frequency support is the key additional feature enjoyed by our approximate solutions that has no analogue for the actual solution ")#mi("{u}")#text(", and effectively serves as a sort of “discretisation” of the problem (as per the uncertainty principle).")

#text("The next step is to ensure that the approximate solutions ")#mi("{u^{(n)}}")#text(" exist globally in time, that is to say that ")#mi("{T^{(n)}_* = \\infty}")#text(". We can do this by exploiting the energy conservation law for this equation. Indeed for any time ")#mi("{t \\in [0,T_*^{(n)})}")#text(", define the energy")

#align(center)[#tao-fit-display[#tao-math("E^{(n)}(t) := \\frac{1}{2} \\int_{{\\bf R}^d} \\left|u^{(n)}(t,x)\\right|^2\\ dx", block: true)]]

#text("(compare with Exercise 4 from Notes 0). From ")#link(<tao-60539cc918e124a98a4a>)[#text("(19)")]#text(" we know that ")#mi("{u^{(n)}}")#text(" and ")#mi("{\\partial_t u^{(n)}}")#text(" lie in ")#mi("{C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" for any ")#mi("{s \\geq 0}")#text(" and any ")#mi("{0 < T < T_*}")#text(". This very high regularity allows us to easily justify operations such as integration by parts or differentiation under the integral sign in what follows. In particular, it is easy to establish the identity")

#align(center)[#tao-fit-display[#mitex("\\partial_t E^{(n)}(t) = \\int_{{\\bf R}^d} u^{(n)}(t,x) \\cdot \\partial_t u^{(n)}(t,x)\\ dx")]]

#text("for any ")#mi("{0 \\leq t < T_*}")#text(". Inserting ")#link(<tao-60539cc918e124a98a4a>)[#text("(19)")]#text(" (and suppressing explicit dependence on ")#mi("{t,x}")#text(" for brevity), we obtain")

#tao-aligned(keep: true)[


#tao-math("\\partial_t E^{(n)}  & = - \\int_{{\\bf R}^d} u^{(n)} \\cdot \\partial_j P_{\\leq N^{(n)}} \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) ) \\ dx", block: true)



#tao-math(" & + \\nu \\int_{{\\bf R}^d} u^{(n)}\\cdot \\Delta u^{(n)}\\ dx.", block: true)
]

#text("For the second term, we integrate by parts to obtain")

#align(center)[#tao-fit-display[#tao-math("\\nu \\int_{{\\bf R}^d} u^{(n)} \\cdot \\Delta u^{(n)}\\ dx = - \\nu \\int_{{\\bf R}^d} \\left|\\nabla u^{(n)}\\right|^2\\ dx.", block: true)]]

#text("For the first term")

#align(center)[#tao-fit-display[#mitex("- \\int_{{\\bf R}^d} u^{(n)} \\cdot \\partial_j P_{\\leq N^{(n)}} \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) )\\ dx,")]]

#text("we use the self-adjointness of ")#mi("{\\mathbb{P}}")#text(" and ")#mi("{P_{\\leq N^{(n)}}}")#text(", the skew-adjointness of ")#mi("{\\partial_j}")#text(", the fact that all three of these operators (being Fourier multipliers) commute with each other to write it as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} (\\partial_j P_{\\leq N^{(n)}} \\mathbb{P} u^{(n)}) \\cdot (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)})\\ dx.")]]

#text("Since ")#mi("{u^{(n)}}")#text(" is divergence-free, the Leray projection ")#mi("{\\mathbb{P}}")#text(" acts as the identity on it, so we may write the above expression as")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^d} (\\partial_j P_{\\leq N^{(n)}} u^{(n)}) \\cdot (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)})\\ dx.")]]

#text("Recalling the rules of thumb for the energy method from the previous set of notes, we locate a total derivative to rewrite the preceding expression as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{{\\bf R}^d} P_{\\leq N^{(n)}} u^{(n)}_j \\partial_j \\left|P_{\\leq N^{(n)}} u^{(n)}\\right|^2\\ dx.", block: true)]]

#text("(It is here that we begin to see how important it was to have so many factors of ")#mi("{P_{\\leq N^{(n)}}}")#text(" in our approximating equation.) We may now integrate by parts (easily justified using the high regularity of ")#mi("{u^{(n)}}")#text(") to obtain")

#align(center)[#tao-fit-display[#tao-math("- \\frac{1}{2} \\int_{{\\bf R}^d} P_{\\leq N^{(n)}} (\\partial_j u^{(n)}_j) \\left|P_{\\leq N^{(n)}} u^{(n)}\\right|^2\\ dx.", block: true)]]

#text("But ")#mi("{u^{(n)}}")#text(" is divergence-free, so ")#mi("{\\partial_j u^{(n)}_j}")#text(" vanishes. To summarise, we conclude the (differential form of) the ")#emph[#text("energy identity")]

#align(center)[#tao-fit-display[#tao-math("\\partial_t E^{(n)}(t) = - \\nu \\int_{{\\bf R}^d} \\left|\\nabla u^{(n)}\\right|^2\\ dx;", block: true)]]

#text("by the fundamental theorem of calculus, we conclude in particular that")

#metadata(none) <tao-81485e82c7ecb013479f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("E^{(n)}(T) + \\nu \\int_0^T \\int_{{\\bf R}^d} \\left|\\nabla u^{(n)}(t,x)\\right|^2\\ dx dt = E^{(n)}(0)", block: true)]]

#text("for all ")#mi("{0 \\leq T < T_*^{(n)}}")#text(". Among other things, this gives a uniform bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u^{(n)} \\right\\|_{L^\\infty_t L^2_x([0,T_*^{(n)}) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} \\leq \\left\\| u_0 \\right\\|_{L^2_x({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("Ordinarily, this ")#mi("{L^2_x}")#text(" type bound would be too weak to combine with the ")#mi("{L^\\infty_x}")#text(" blowup criterion mentioned earlier. But we know that ")#mi("{u^{(n)}}")#text(" has Fourier transform supported in ")#mi("{\\overline{B(0,N^{(n)})}}")#text(", so in particular we have the reproducing formula ")#mi("{u^{(n)} = P_{\\leq 2 N^{(n)}} u^{(n)}}")#text(". We may thus use the Bernstein inequality (Exercise 52 from ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text(") and conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u^{(n)} \\right\\|_{L^\\infty_t L^\\infty_x([0,T_*^{(n)}) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_d (N^{(n)})^{d/2} \\left\\| u_0 \\right\\|_{L^2_x({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("This bound is not uniform in ")#mi("{n}")#text(", but it is still finite, and so by combining with the blowup criterion we conclude that ")#mi("{T_*^{(n)} = \\infty}")#text(".")

#text("Now we need to start taking limits as ")#mi("{n \\rightarrow \\infty}")#text(". For this we need uniform bounds. Returning to the energy identity ")#link(<tao-81485e82c7ecb013479f>)[#text("(20)")]#text(", we have the uniform bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u^{(n)} \\right\\|_{L^\\infty_t L^2_x([0,\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}, \\left\\| \\nabla u^{(n)} \\right\\|_{L^2_t L^2_x([0,\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2})} \\lesssim_{\\nu,u_0} 1", block: true)]]

#text("so in particular for any finite ")#mi("{T>0}")#text(" one has")

#metadata(none) <tao-dd877258cfbc14ca9c54>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\left\\| u^{(n)} \\right\\|_{L^2_t H^1_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{\\nu,u_0,T} 1.", block: true)]]

#text("This is enough regularity for Proposition ")#link(<tao-970f519c2cadbcefb1e8>)[#text("2")]#text(" to apply, and we can pass to a subsequence of ")#mi("{u^{(n)}}")#text(" which converges in the sense of spacetime distributions in ")#mi("{{\\bf R} \\times{\\bf R}^d}")#text(" (after extending by zero outside of ")#mi("{[0,+\\infty) \\times {\\bf R}^d}")#text(") to a limit ")#mi("{u}")#text(", which is in ")#mi("{L^2_t H^1_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" for every ")#mi("{T}")#text(".")

#text("Now we work on verifying the energy inequality ")#link(<tao-6cb3f51eed90e7dbe08c>)[#text("(18)")]#text(". Let ")#mi("{\\eta \\in C^\\infty_c({\\bf R} \\rightarrow {\\bf R})}")#text(" be a test function with ")#mi("{\\eta(0)=1}")#text(" which is non-increasing on ")#mi("{[0,+\\infty)}")#text(". From ")#link(<tao-81485e82c7ecb013479f>)[#text("(20)")]#text(" and integration by parts we have")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty (-\\eta^{\\prime}(t)) \\int_{{\\bf R}^d} \\left|u^{(n)}(t,x)\\right|^2\\ dx dt + 2 \\nu \\int_0^\\infty \\eta(t) \\int_{{\\bf R}^d} \\left|\\nabla u^{(n)}(t,x)\\right|^2\\ dx dt = \\int_{{\\bf R}^d} \\left|P_{\\leq N_n} u_0(x)\\right|^2\\ dx.", block: true)]]

#text("Taking limit inferior and using the Fatou-type lemma ")#link(<tao-fee9c0a0cd6b109ede4b>)[#text("(2)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty (-\\eta^{\\prime}(t)) \\int_{{\\bf R}^d} \\left|u(t,x)\\right|^2\\ dx dt + 2 \\nu \\int_0^\\infty \\eta(t) \\int_{{\\bf R}^d} \\left|\\nabla u(t,x)\\right|^2\\ dx dt", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\int_{{\\bf R}^d} \\left|u_0(x)\\right|^2\\ dx.", block: true)]]

#text("Now let ")#mi("{T>0}")#text(", take ")#mi("{\\eta = \\eta_\\varepsilon}")#text(" to equal ")#mi("{1}")#text(" on ")#mi("{[0,T]}")#text(" and zero outside of ")#mi("{[0,T+\\varepsilon]}")#text(" for some small ")#mi("{\\varepsilon}")#text(". Then we have")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty (-\\eta^{\\prime}_\\varepsilon(t)) \\int_{{\\bf R}^d} \\left|u(t,x)\\right|^2\\ dx dt + 2 \\nu \\int_0^T \\int_{{\\bf R}^d} \\left|\\nabla u(t,x)\\right|^2\\ dx dt", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\leq \\int_{{\\bf R}^d} \\left|u_0(x)\\right|^2\\ dx.", block: true)]]

#text("The function ")#mi("{-\\eta^{\\prime}_\\varepsilon}")#text(" is supported on ")#mi("{[T,T+\\varepsilon]}")#text(", is non-negative, and has total mass one. By the ")#link("https://en.wikipedia.org/wiki/Lebesgue_differentiation_theorem")[#text("Lebesgue differentiation theorem")]#text(" applied to the bounded measurable function ")#tao-math("{t \\mapsto \\int_{{\\bf R}^d} \\left|u(t,x)\\right|^2\\ dx}", block: false)#text(", we conclude that for almost every ")#mi("{T \\in [0,+\\infty)}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty (-\\eta^{\\prime}_\\varepsilon(t)) \\int_{{\\bf R}^d} \\left|u(t,x)\\right|^2\\ dx dt \\rightarrow \\int_{{\\bf R}^d} \\left|u(T,x)\\right|^2\\ dx", block: true)]]

#text("as ")#mi("{\\varepsilon \\rightarrow 0}")#text(". The claim ")#link(<tao-6cb3f51eed90e7dbe08c>)[#text("(18)")]#text(" follows.")

#text("It remains to show that ")#mi("{u}")#text(" is a weak solution of ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(", that is to say that ")#link(<tao-b3b1b8da8347e7b1153e>)[#text("(17)")]#text(" holds in the sense of spacetime distributions. Certainly the smooth solution ")#mi("{u^{(n)}}")#text(" of ")#link(<tao-60539cc918e124a98a4a>)[#text("(19)")]#text(" will also be a weak solution, thus ")#metadata(none) <tao-730f5f0254a024550c2a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\partial_t u^{(n)}(t,x) + \\partial_j P_{\\leq N^{(n)}} \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) )(t,x)")]]



#align(center)[#tao-fit-display[#mitex("= \\nu \\Delta u^{(n)}(t,x) + P_{\\leq N^{(n)}} u_0(x) \\delta_0(t)")]]

#text("in the sense of spacetime distributions on ")#mi("{{\\bf R} \\times {\\bf R}^d}")#text(", where we extend ")#mi("{u^{(n)}}")#text(" by zero outside of ")#mi("{[0,+\\infty) \\times {\\bf R}^d}")#text(".")

#text("At this point it is tempting to just take distributional limits of both sides of ")#link(<tao-730f5f0254a024550c2a>)[#text("(22)")]#text(" to obtain ")#link(<tao-b3b1b8da8347e7b1153e>)[#text("(17)")]#text(". Certainly we have the expected convergence for the linear components of the equation:")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^{(n)}  & \\rightharpoonup^* \\partial_t u", block: true)



#tao-math("\\nu \\Delta u^{(n)}  & \\rightharpoonup^* \\nu \\Delta u", block: true)



#tao-math("P_{\\leq N^{(n)}} u_0(x) \\delta_0(t)  & \\rightharpoonup^* u_0(x) \\delta_0(t).", block: true)
]

#text("However, it is not immediately clear that")

#metadata(none) <tao-0cdcc60fc20886d88a80>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\partial_j P_{\\leq N^{(n)}} \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) ) \\rightharpoonup^* \\partial_j \\mathbb{P}( u_j u ),")]]

#text("mainly because of the previously mentioned problem that multiplication is not continuous with respect to weak notions of convergence. But if we can show ")#link(<tao-0cdcc60fc20886d88a80>)[#text("(23)")]#text(", then we do indeed recover ")#link(<tao-b3b1b8da8347e7b1153e>)[#text("(17)")]#text(" as the limit of ")#link(<tao-730f5f0254a024550c2a>)[#text("(22)")]#text(", which will complete the proof of Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(".")

#text("Let’s try to simplify the task of proving ")#link(<tao-0cdcc60fc20886d88a80>)[#text("(23)")]#text(". The partial derivative operator ")#mi("{\\partial_j}")#text(" is continuous with respect to convergence in distributions, so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N^{(n)}} F^{(n)}_j \\rightharpoonup^* \\mathbb{P}( u_j u ),")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("F^{(n)}_j := \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) ).")]]

#text("We now try to get rid of the outer Littlewood-Paley projection. We claim that")

#metadata(none) <tao-1197b203eea750ff88aa>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("(1 - P_{\\leq N^{(n)}}) F^{(n)}_j \\rightharpoonup^* 0.")]]

#text("Let ")#mi("{T>0}")#text(" be a fixed time. By Sobolev embedding and ")#link(<tao-dd877258cfbc14ca9c54>)[#text("(21)")]#text(", ")#mi("{u^{(n)}}")#text(" is bounded in ")#mi("{L^2_t L^p_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", uniformly in ")#mi("{n}")#text(", for some ")#mi("{2 < p < \\infty}")#text(". The same is then true for ")#mi("{P_{\\leq N^{(n)}} u^{(n)}}")#text(", hence by Hölder’s inequality and Proposition ")#link(<tao-12c38af71f5c716a31b0>)[#text("13")]#text(", ")#mi("{F^{(n)}}")#text(" is uniformly bounded in ")#mi("{L^1_t L^{p/2}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(". On the other hand, for any spacetime test function ")#mi("{\\psi \\in C^\\infty_c({\\bf R} \\times {\\bf R}^d)}")#text(", it is not difficult (using the rapid decrease of the Fourier transform of ")#mi("{\\psi}")#text(") to show that ")#mi("{(1 - P_{\\leq N^{(n)}}) \\psi}")#text(" goes to zero in the dual space ")#mi("{L^\\infty_t L^{(p/2)^{\\prime}}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(". This gives ")#link(<tao-1197b203eea750ff88aa>)[#text("(24)")]#text(".")

#text("It thus suffices to show that ")#mi("{F^{(n)}_j}")#text(" converges in the sense of distributions to ")#mi("{\\mathbb{P}( u_j u )}")#text(", thus one wants")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R} \\times {\\bf R}^d} (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) \\mathbb{P} \\phi\\ dx dt \\rightarrow \\int_{{\\bf R} \\times {\\bf R}^d} u_j u \\mathbb{P} \\phi\\ dx dt")]]

#text("for any spacetime test function ")#mi("{\\phi}")#text(". One can easily calculate that ")#mi("{\\mathbb{P} \\phi}")#text(" lies in the dual space ")#mi("{L^\\infty_t L^{(p/2)^{\\prime}}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(" to the space ")#mi("{L^1_t L^{p/2}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" that ")#mi("{(P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)})}")#text(" and ")#mi("{u_j u}")#text(" are bounded in, so it will suffices to show that ")#mi("{P_{\\leq N^{(n)}} u^{(n)}}")#text(" converges strongly in ")#mi("{L^2_t L^p_x(K \\rightarrow {\\bf R}^d)}")#text(" to ")#mi("{u}")#text(" for ")#mi("{p>2}")#text(" sufficiently close to ")#mi("{2}")#text(". and any compact subset ")#mi("{K}")#text(" of spacetime (since the ")#mi("{L^\\infty_t L^{(p/2)^{\\prime}}_x}")#text(" norm of ")#mi("{\\mathbb{P} \\phi}")#text(" outside of ")#mi("{K}")#text(" can be made arbitrarily small by making ")#mi("{K}")#text(" large enough.)")

#text("Let ")#mi("{N}")#text(" be a dyadic integer, then we can split")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N^{(n)}} u^{(n)} - u = P_{\\leq N}( u^{(n)}-u) + (P_{\\leq N^{(n)}}-P_{\\leq N}) u^{(n)} - (1-P_{\\leq N}) u.")]]

#text("The functions ")#mi("{u^{(n)}, u}")#text(" are uniformly bounded in ")#mi("{L^2_t H^1_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" by some bound ")#mi("{A}")#text(", hence by Plancherel’s theorem the functions ")#mi("{(P_{\\leq N^{(n)}}-P_{\\leq N}) u^{(n)}}")#text(", ")#mi("{(1-P_{\\leq N}) u}")#text(" have an ")#mi("{L^2_t L^2_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" norm of ")#mi("{O(A N^{-1})}")#text(" (assuming ")#mi("{n}")#text(" is large enough so that ")#mi("{N^{(n)} > N}")#text("). Indeed, by Littlewood-Paley decomposition and Bernstein’s inequality we also see that these functions have an ")#mi("{L^2_t L^p_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" norm of ")#mi("{O( A N^{-1 + \\frac{d}{2}-\\frac{d}{p}})}")#text(" if ")#mi("{p>2}")#text(" is close enough to ")#mi("{2}")#text(" that the exponent of ")#mi("{N}")#text(" is negative. It will therefore suffice to show that")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N}( u^{(n)} - u ) \\rightarrow 0")]]

#text("strongly in ")#mi("{L^2_t L^p_x(K \\rightarrow {\\bf R}^d)}")#text(" for every fixed ")#mi("{N}")#text(" and ")#mi("{K}")#text(".")

#text("We already know that ")#mi("{u^{(n)}-u}")#text(" goes to zero in the sense of distributions, so (as Proposition ")#link(<tao-7fef9479c8bc5a3c8689>)[#text("3")]#text(" indicates) the main difficulty is to obtain compactness of the sequence. The ")#mi("{P_{\\leq N}}")#text(" operator localises in spatial frequency, and the restriction to ")#mi("{K}")#text(" localises in both space and time, however there is still the possibility of escaping to temporal frequency. To prevent this, we need some sort of equicontinuity in time. For this, we may turn to the equation ")#link(<tao-60539cc918e124a98a4a>)[#text("(19)")]#text(" obeyed by ")#mi("{u^{(n)}}")#text(". Applying ")#mi("{P_{\\leq N}}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_t P_{\\leq N} u^{(n)} + \\partial_j P_{\\leq N} F^{(n)}_j = \\nu \\Delta P_{\\leq N} u^{(n)}")]]

#text("when ")#mi("{n}")#text(" is large enough. Since ")#mi("{P_{\\leq N} u^{(n)}}")#text(" is uniformly bounded in ")#mi("{L^\\infty_t L^2_x}")#text(" and ")#mi("{L^2_{t,loc} L^p_x}")#text(", we see from Hölder (and Proposition ")#link(<tao-12c38af71f5c716a31b0>)[#text("13")]#text(" that ")#mi("{F^{(n)}_j}")#text(" is bounded in ")#mi("{L^\\infty_t L^{q}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" uniformly in ")#mi("{n}")#text(" for some ")#mi("{q>1}")#text(", so by the Bernstein inequality ")#mi("{\\partial_j P_{\\leq N} F^{(n)}_j}")#text(" is bounded in ")#mi("{L^2_t L^{\\infty}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" (we allow the bound to depend on ")#mi("{N}")#text("). Similarly for ")#mi("{\\nu \\Delta P_{\\leq N} u^{(n)}}")#text(". We conclude that ")#mi("{\\partial_t P_{\\leq N} u^{(n)}}")#text(" is bounded in ")#mi("{L^2_t L^{\\infty}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" uniformly in ")#mi("{n}")#text("; taking weak limits using ")#link(<tao-fee9c0a0cd6b109ede4b>)[#text("(2)")]#text(", the same is true for ")#mi("{u}")#text(", and hence ")#mi("{\\partial_t P_{\\leq N}( u^{(n)} - u )}")#text(" is bounded in ")#mi("{L^2_t L^{\\infty}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(". By the fundamental theorem of calculus and Cauchy-Schwarz, this gives Hölder continuity in time (of order ")#mi("{1/2}")#text("). Also, ")#mi("{\\nabla P_{\\leq N}( u^{(n)} - u)}")#text(" is bounded in ")#mi("{L^\\infty_t L^{\\infty}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" by Bernstein’s inequality; thus ")#mi("{P_{\\leq N}( u^{(n)} - u )}")#text(" is equicontinuous in ")#mi("{K}")#text(". By the Arzelá-Ascoli theorem and Proposition ")#link(<tao-7fef9479c8bc5a3c8689>)[#text("3")]#text(", ")#mi("{P_{\\leq N}(u^{(n)} - u)}")#text(" must therefore go to zero uniformly on ")#mi("{K}")#text(", and the claim follows. This completes the proof of Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Rellich compactness theorem)")]#text(" Let ")#mi("{2 \\leq p < \\infty}")#text(" be such that ")#mi("{\\frac{1}{p} > \\frac{1}{2} - \\frac{1}{d}}")#text(".")

#list(
[#text("(i) Show that if ")#mi("{u_n}")#text(" is a bounded sequence in ")#mi("{H^1({\\bf R}^d \\rightarrow {\\bf R})}")#text(" that converges in the sense of distributions to a limit ")#mi("{u}")#text(", then there is a subsequence ")#mi("{u_{n_j}}")#text(" which converges strongly in ")#mi("{L^p_{loc}({\\bf R}^d \\rightarrow {\\bf R})}")#text(" to ")#mi("{u}")#text(" (thus, for any compact set ")#mi("{K \\subset {\\bf R}^d}")#text(", the restrictions of ")#mi("{u_{n_j}}")#text(" to ")#mi("{K}")#text(" converge strongly in ")#mi("{L^p(K \\rightarrow {\\bf R})}")#text(" to the restriction of ")#mi("{u}")#text(" to ")#mi("{K}")#text(").")],
[#text("(ii) Show that for any compact set ")#mi("{K \\subset {\\bf R}^d}")#text(", the linear map ")#mi("{\\iota_K: H^1({\\bf R}^d \\rightarrow {\\bf R}) \\rightarrow L^p(K \\rightarrow {\\bf R})}")#text(" defined by setting ")#mi("{\\iota_K u: K \\rightarrow {\\bf R}}")#text(" to be the restriction of ")#mi("{u: {\\bf R}^d \\rightarrow {\\bf R}}")#text(" to ")#mi("{K}")#text(" is a compact linear map.")],
[#text("(iii) Show that the above two claims fail at the endpoint ")#mi("{\\frac{1}{p} = \\frac{1}{2} - \\frac{1}{d}}")#text(" (which of course only occurs when ")#mi("{d>3}")#text(").")]
)
]

#text("The weak solutions constructed by Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(" have additional properties beyond the ones listed in the above theorem. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" ")#metadata(none) <tao-592a05acd0f3079f91e9>#text(" Let ")#mi("{u_0}")#text(" be as in Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(", and let ")#mi("{u}")#text(" be a weak solution constructed using the proof of Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(".")

#list(
[#text("(i) Show that ")#mi("{u}")#text(" is divergence-free in the sense of spacetime distributions.")],
[#text("(ii) (Note: this exercise is tricky.) Assume ")#mi("{d=3}")#text(". Show that the weak solution ")#mi("{u}")#text(" obeys a local energy inequality")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|x\\right| \\geq 2R} \\left|u(T,x)\\right|^2\\ dx \\leq \\int_{\\left|x\\right| \\geq R} \\left|u_0(x)\\right|^2 + O_{T,u_0}( \\frac{1}{R} )", block: true)]]

#text("for all ")#mi("{T, R > 0}")#text(". (")#emph[#text("Hint:")]#text(" compute the time derivative of ")#tao-math("{\\int_{{\\bf R}^3} \\left|u^{(n)}(t,x)\\right|^2 \\psi(x/R)\\ dx}", block: false)#text(", where ")#mi("{\\psi}")#text(" is a smooth cutoff supported on ")#mi("{B(0,2)}")#text(" that equals one in ")#mi("{B(0,1)}")#text(", and use Sobolev inequalities and Hölder to control the various terms that arise from integration by parts; one will need to expand out the Leray projection and use the fact that ")#mi("{\\partial_i \\partial_j \\Delta^{-1}}")#text(" is bounded on every ")#mi("{L^p({\\bf R}^3)}")#text(" space for ")#mi("{1 < p < \\infty}")#text(".) Using this inequality, show that there is a measure zero subset ")#mi("{E}")#text(" of ")#mi("{[0,+\\infty)}")#text(" such that one has the energy inequality")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} u(T_2,x)^2\\ dx + 2\\nu \\int_{T_1}^{T_2} \\int_{{\\bf R}^d} \\left|\\nabla u(t,x)\\right|^2\\ dx dt", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\leq \\int_{{\\bf R}^d} u(T_1,x)^2\\ dx")]]

#text("for all ")#mi("{T_1, T_2 \\in [0,+\\infty) \\backslash E}")#text(" with ")#mi("{T_1 < T_2}")#text(". Furthermore, show that for all ")#mi("{T \\in [0,+\\infty) \\backslash E}")#text(", the time-shifted function ")#mi("{u_T: [0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" defined by ")#mi("{u_T(t,x) := u(t+T, x)}")#text(" is a weak solution to the initial value problem ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(" with initial data ")#mi("{u(T)}")#text(". (The arguments here can be extended to dimensions ")#mi("{d \\leq 4}")#text(", but it is open for ")#mi("{d>4}")#text(" whether one can construct Leray-Hopf solutions obeying the strong energy inequality.)")],
[#text("(iii) Show that after modifying ")#mi("{u}")#text(" on a set of measure zero, the function ")#mi("{t \\mapsto \\int_{{\\bf R}^d} u(t,x) \\cdot v(x)\\ dx}")#text(" is continuous for any ")#mi("{v \\in L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(". (")#emph[#text("Hint:")]#text(" first establish this when ")#mi("{v}")#text(" is a test function.)")]
)
]

#text("We will discuss some further properties of the Leray weak solutions in later notes.")

#heading(level: 1)[#strong[#text(" — 4. Weak-strong uniqueness — ")]]

#text("If ")#mi("{u}")#text(" is a (non-zero) element in a Hilbert space ")#mi("{H}")#text(", and ")#mi("{v}")#text(" is another element obeying the inequality ")#metadata(none) <tao-e6184ce10e266134fdcf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\left\\|v\\right\\| \\leq \\left\\|u\\right\\|,", block: true)]]

#text(" ")#text(" then this is very far from the assertion that ")#mi("{v}")#text(" is equal to ")#mi("{u}")#text(", since the ball ")#tao-math("{\\overline{B(0,\\left\\|u\\right\\|)}}", block: false)#text(" of elements of ")#mi("{H}")#text(" obeying ")#link(<tao-e6184ce10e266134fdcf>)[#text("(25)")]#text(" is far larger than the single point ")#mi("{\\{u\\}}")#text(". However, if one also posseses the information that ")#mi("{v}")#text(" agrees with ")#mi("{u}")#text(" when tested against ")#mi("{u}")#text(", in the sense that")

#metadata(none) <tao-28d46654d81889701f71>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\langle v,u \\rangle = \\langle u, u \\rangle,")]]

#text("then ")#link(<tao-e6184ce10e266134fdcf>)[#text("(25)")]#text(" and ")#link(<tao-28d46654d81889701f71>)[#text("(26)")]#text(" combine to indeed be able to conclude that ")#mi("{u=v}")#text(". Geometrically, this is because the above-mentioned ball is tangent to the hyperplane described by ")#link(<tao-28d46654d81889701f71>)[#text("(26)")]#text(" at the point ")#mi("{u}")#text(". Algebraically, one can establish this claim by the cosine rule computation")

#tao-aligned(keep: true)[


#tao-math("\\left\\| v-u\\right\\|^2  & = \\langle u,u \\rangle - 2 \\langle v,u \\rangle + \\langle v,v \\rangle", block: true)



#tao-math(" & = \\langle v,v \\rangle - \\langle u, u \\rangle", block: true)



#tao-math(" & = \\left\\|v\\right\\|^2 - \\left\\|u\\right\\|^2", block: true)



#tao-math(" & \\leq 0", block: true)
]

#text("giving the claim.")

#text("This basic argument has many variants. Here are two of them:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Weak convergence plus norm bound equals strong convergence (Hilbert spaces))")]#text(" ")#metadata(none) <tao-ccf3aac864e8767e23e5>#text(" Let ")#mi("{u}")#text(" be an element of a Hilbert space ")#mi("{H}")#text(", and let ")#mi("{u_n}")#text(" be a sequence in ")#mi("{H}")#text(" which weakly converges to ")#mi("{u}")#text(", that is to say that ")#mi("{\\langle u_n, w \\rangle \\rightarrow \\langle u, w \\rangle}")#text(" for all ")#mi("{w \\in H}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#tao-math("{\\limsup_{n \\rightarrow \\infty} \\left\\|u_n \\right\\| \\leq \\left\\|u\\right\\|}", block: false)#text(".")],
[#text("(ii) ")#tao-math("{\\lim_{n \\rightarrow \\infty} \\left\\|u_n \\right\\| = \\left\\|u\\right\\|}", block: false)#text(".")],
[#text("(iii) ")#mi("{u_n}")#text(" converges ")#emph[#text("strongly")]#text(" to ")#mi("{u}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Weak convergence plus norm bound equals strong convergence (")#mi("{L^1}")#text(" norms))")]#text(" Let ")#mi("{(X,\\mu)}")#text(" be a measure space, let ")#mi("{f: X \\rightarrow [0,+\\infty)}")#text(" be an absolutely integrable non-negative function, and let ")#mi("{f_n: X \\rightarrow [0,+\\infty)}")#text(" be a sequence of absolutely integrable non-negative functions that converge pointwise to ")#mi("{f}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{\\limsup_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu \\leq \\int_X f\\ d\\mu}")#text(".")],
[#text("(ii) ")#mi("{\\lim_{n \\rightarrow \\infty} \\int_X f_n\\ d\\mu = \\int_X f\\ d\\mu}")#text(".")],
[#text("(iii) ")#mi("{f_n}")#text(" converges strongly in ")#mi("{L^1(X,\\mu)}")#text(" to ")#mi("{f}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" express ")#mi("{\\int_X |f_n-f|\\ d\\mu}")#text(" and ")#mi("{\\int_X f_n-f\\ d\\mu}")#text(" in terms of the positive and negative parts of ")#mi("{f_n-f}")#text(". The latter can be controlled using the dominated convergence theorem.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{u_0}")#text(" be as in Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(", and let ")#mi("{u}")#text(" be a weak solution constructed using the proof of Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(". Show that (after modifying ")#mi("{u}")#text(" on a set of measure zero if necessary), ")#mi("{u(t)}")#text(" converges strongly in ")#mi("{L^2({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" to ")#mi("{u_0}")#text(" as ")#mi("{t \\rightarrow 0^+}")#text(". (")#emph[#text("Hint:")]#text(" use Exercise ")#link(<tao-592a05acd0f3079f91e9>)[#text("16")]#text("(iii) and Exercise ")#link(<tao-ccf3aac864e8767e23e5>)[#text("17")]#text(".)")
]

#text("Now we give a variant relating to weak and strong solutions of the Navier-Stokes equations.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 20 (Weak-strong uniqueness)")]#text(" Let ")#mi("{u: [0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be an ")#mi("{H^s}")#text(" mild solution to the Navier-Stokes equations ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(" for some ")#mi("{u_0 \\in H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", ")#mi("{0 < T_* \\leq +\\infty}")#text(", and ")#mi("{s > \\frac{d}{2}-1}")#text(" with ")#mi("{s \\geq 1}")#text(". Let ")#mi("{v: [0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be a weak solution to the Navier-Stokes equation with ")#mi("{v \\in L^\\infty_t L^2_x}")#text(" and ")#mi("{\\nabla v \\in L^2_t L^2_x}")#text(" which obeys the energy inequality ")#link(<tao-6cb3f51eed90e7dbe08c>)[#text("(18)")]#text(" for almost all ")#mi("{0 \\leq T < T_*}")#text(". Then ")#mi("{u}")#text(" and ")#mi("{v}")#text(" agree almost everywhere on ")#mi("{[0,T_*) \\times {\\bf R}^d}")#text(".")
]

#text("Roughly speaking, this proposition asserts that weak solutions obeying the energy inequality stay unique as long as a strong solution exists (in particular, it is unique whenever it is regular enough to be a strong solution). However, once a strong solution reaches the end of its maximal Cauchy development, there is no further guarantee of uniqueness for the rest of the weak solution. Also, there is no guarantee of uniqueness of weak solutions if the energy inequality is dropped, and indeed there is now increasing evidence that uniqueness is simply false in this case; see for instance ")#link("https://arxiv.org/abs/1709.10033")[#text("this paper of Buckmaster and Vicol")]#text(" for recent work in this direction. The conditions on ")#mi("{u}")#text(" can be relaxed somewhat (in particular, it is possible to drop the condition ")#mi("{s \\geq 1}")#text("), though they still need to be “subcritical” or “critical” in nature; see for instance the classic papers ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=126088")[#text("of Prodi")]#text(", ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=150444")[#text("of Serrin")]#text(", and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=236541")[#text("of Ladyzhenskaya")]#text(", which show that weak solutions on ")#mi("{[0,+\\infty) \\times {\\bf R}^3}")#text(" obeying the energy inequality are necessarily unique and smooth (after time ")#mi("{t=0}")#text(") if they lie in the space ")#mi("{L^p_t L^q_r([0,+\\infty) \\times {\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" for some exponents ")#mi("{p,q}")#text(" with ")#mi("{\\frac{2}{p} + \\frac{3}{q} = 1}")#text(" and ")#mi("{2 \\leq p < \\infty}")#text("; the endpoint case ")#mi("{p=\\infty}")#text(" was worked out more recently ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1992563")[#text("by Escauriaza, Seregin, and Sverak")]#text(". For a recent survey of weak-strong uniqueness results for fluid equations, see ")#link("https://arxiv.org/abs/1705.04220")[#text("this paper of Wiedemann")]#text(".")

#emph[#text("Proof:")]#text(" Before we give the formal proof, let us first give a non-rigorous proof in which we pretend that the weak solution ")#mi("{v}")#text(" can be manipulated like a strong solution. Then we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t v + \\partial_j \\mathbb{P}( v_j v ) = \\nu \\Delta v; \\quad v(0) = u_0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + \\partial_j \\mathbb{P}( u_j u ) = \\nu \\Delta u; \\quad u(0) = u_0.")]]

#text("As in the beginning of the section, the idea is to analyse the ")#mi("{L^2}")#text(" norm of the difference ")#mi("{w := v-u}")#text(". Writing ")#mi("{v=u+w}")#text(" in the first equation and subtracting from the second equation, we obtain the ")#emph[#text("difference equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t w + \\partial_j \\mathbb{P}( w_j u + u_j w + w_j w ) = \\nu \\Delta w; \\quad w(0) = 0.")]]

#text("If we formally differentiate the energy ")#tao-math("{E(t) := \\frac{1}{2} \\int_{{\\bf R}^d} \\left|w(t,x)\\right|^2\\ dx}", block: false)#text(" using this equation, we obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t) = \\int_{{\\bf R}^d} - w \\cdot \\partial_j \\mathbb{P}( w_j u + u_j w + w_j w ) + \\nu w \\cdot \\Delta w\\ dx")]]

#text("(omitting the explicit dependence of the integrand on ")#mi("{t}")#text(" and ")#mi("{x}")#text(") which after some integration by parts (noting that ")#mi("{\\partial_j w}")#text(" is divergence-free and thus is the identity on ")#mi("{\\mathbb{P}}")#text(") formally becomes")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E(t) = \\int_{{\\bf R}^d} \\partial_j w \\cdot ( w_j u + u_j w + w_j w ) - \\nu \\left|\\nabla w\\right|^2.", block: true)]]

#text("The ")#mi("{\\partial_j w \\cdot(u_j w)}")#text(" and ")#mi("{\\partial_j w \\cdot(w_j w)}")#text(" terms formally cancel out by the usual trick of writing ")#mi("{\\partial_j w \\cdot w}")#text(" as a total derivative ")#tao-math("{\\frac{1}{2} \\partial_j \\left|w\\right|^2}", block: false)#text(" and integrating by parts, using the divergence-free nature ")#mi("{\\partial_j u_j= \\partial_j w_j = 0}")#text(" of both ")#mi("{u}")#text(" and ")#mi("{w}")#text(". For the term ")#mi("{\\partial_j w \\cdot(w_j u)}")#text(", we can cancel it against the ")#tao-math("{\\nu \\left|\\nabla w\\right|^2}", block: false)#text(" term by the arithmetic mean-geometric mean inequality")

#align(center)[#tao-fit-display[#tao-math("\\partial_j w \\cdot(w_j u) \\leq \\nu \\left|\\nabla w\\right|^2 + \\frac{1}{4\\nu} \\left|w\\right|^2 \\left|u\\right|^2", block: true)]]

#text("to obtain")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E(t) \\leq \\frac{1}{4\\nu} \\int_{{\\bf R}^d} \\left|w\\right|^2 \\left|u\\right|^2 \\leq \\frac{1}{2\\nu} E(t) \\left\\|u(t) \\right\\|_{L^\\infty_x({\\bf R}^d \\rightarrow {\\bf R}^d)}^2", block: true)]]

#text("thanks to Hölder’s inequality. As ")#mi("{u}")#text(" is an ")#mi("{H^s}")#text(" mild solution, it lies in ")#mi("{L^2_{t,loc} H^{s+1}_x}")#text(", which by Sobolev embedding and Hölder means that it is also in ")#mi("{L^2_{t,loc} L^\\infty_x}")#text(". Since ")#mi("{E(0)=0}")#text(", Gronwall’s inequality then should give ")#mi("{E(t)=0}")#text(" for all ")#mi("{t \\geq 0}")#text(", giving the claim.")

#text("Now we begin the rigorous proof, in which ")#mi("{v}")#text(" is only known to be a weak solution. Here, we do not directly manipulate the difference equation, but instead carefully use the equations for ")#mi("{u}")#text(" and ")#mi("{v}")#text(" as a substitute. Define ")#mi("{w}")#text(" and ")#mi("{E(t)}")#text(" as before. From the cosine rule we have")

#align(center)[#tao-fit-display[#tao-math("E(T) = \\frac{1}{2} \\int_{{\\bf R}^d} \\left|u(T)\\right|^2\\ dx + \\frac{1}{2} \\int_{{\\bf R}^d} \\left|v(T)\\right|^2\\ dx - \\int_{{\\bf R}^d} u(T) \\cdot v(T)\\ dx,", block: true)]]

#text("where we drop the explicit dependence on ")#mi("{x}")#text(" in the integrand. From the energy inequality hypothesis ")#link(<tao-6cb3f51eed90e7dbe08c>)[#text("(18)")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{{\\bf R}^d} \\left|v(T)\\right|^2\\ dx \\leq \\frac{1}{2} \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx - \\nu \\int_0^T \\int_{{\\bf R}^d} \\left|\\nabla v\\right|^2\\ dx dt", block: true)]]

#text("for almost all ")#mi("{T}")#text(", where we also drop explicit dependence on ")#mi("{t}")#text(" in the integrand. The strong solution ")#mi("{u}")#text(" also obeys the energy inequality; in fact we have the energy equality")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{{\\bf R}^d} \\left|u(T)\\right|^2\\ dx = \\frac{1}{2} \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx - \\nu \\int_0^T \\int_{{\\bf R}^d} \\left|\\nabla u\\right|^2\\ dx dt", block: true)]]

#text("as can be seen by first working with smooth solutions and taking limits using the local well-posedness theory. We conclude that")

#metadata(none) <tao-5dcf449f49d5c8247116>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("E(T) \\leq \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx - \\nu \\int_0^T \\int_{{\\bf R}^d} \\left|\\nabla u\\right|^2 + \\left|\\nabla v\\right|^2\\ dx dt - \\int_{{\\bf R}^d} u(T) \\cdot v(T)\\ dx", block: true)]]

#text("for almost all ")#mi("{T}")#text(".")

#text("Now we work on the integral ")#mi("{\\int_{{\\bf R}^d} u(T) \\cdot v(T)\\ dx}")#text(". Because we only know ")#mi("{v}")#text(" to solve the equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t v(t,x) + \\partial_j \\mathbb{P}( v_j v )(t,x) = \\nu \\Delta v(t,x) + u_0(x) \\delta_0(t)")]]

#text("in the sense of spacetime distributions, it is difficult to directly treat this spatial integral. Instead (similarly to the proof of the energy inequality for Leray solutions), we will first work with a proxy")

#metadata(none) <tao-1241936d4dd3aad68fe7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} -\\eta^{\\prime}(t) u \\cdot v\\ dx dt")]]

#text("where ")#mi("{\\eta \\in C^\\infty_c({\\bf R} \\rightarrow {\\bf R})}")#text(" is a test function in time, which we normalise with ")#mi("{\\eta(0)=1}")#text("; eventually we will make ")#mi("{\\eta}")#text(" an approximation to the indicator function of ")#mi("{[-T,T]}")#text(" and apply the Lebesgue differentiation theorem to recover information about ")#mi("{\\int_{{\\bf R}^d} u(T) \\cdot v(T)\\ dx}")#text(" for almost every ")#mi("{T}")#text(".")

#text("By hypothesis, we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} - v \\cdot \\partial_t \\psi + \\partial_j (v_j v) \\cdot \\mathbb{P} \\psi + \\nu \\partial_j v \\cdot \\partial_j \\psi\\ dx dt = \\int_{{\\bf R}^d} u_0 \\cdot \\psi(0)\\ dx")]]

#text("for any spacetime test function ")#mi("{\\psi \\in C^\\infty_c({\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(". We would like to apply this identity with ")#mi("{\\psi}")#text(" replaced by ")#mi("{\\eta(t) u}")#text(" (in order to obtain an identity involving the expression ")#link(<tao-1241936d4dd3aad68fe7>)[#text("(28)")]#text("). Now ")#mi("{\\eta(t) u}")#text(" is not a test function; however, as ")#mi("{u}")#text(" is an ")#mi("{H^s}")#text(" mild solution, it has the regularity")

#align(center)[#tao-fit-display[#mitex("\\eta(t) u \\in C^0_t H^s_x({\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^d) \\cap L^2_t H^{s+1}_x({\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^d);")]]

#text("also, using the equation ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(", Sobolev embedding, Hölder’s inequality, and the hypotheses ")#mi("{s > \\frac{d}{2}-1}")#text(" and ")#mi("{s \\geq 1}")#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_t (\\eta(t) u) \\in L^2_t H^{-1}_x({\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}^d).")]]

#text("(If one wishes, one can first obtain this bound for smooth solutions, and take limits using the local well-posedness theory.) As a consequence, one can find (for instance by using a combination of Littlewood-Paley projections and spatial cutoffs) a sequence of test functions ")#mi("{\\psi_n}")#text(", such that ")#mi("{\\psi_n}")#text(" converges to ")#mi("{\\eta(t) u}")#text(" in ")#mi("{C^0_t H^s_x}")#text(" and ")#mi("{L^2_t H^{s+1}_x}")#text(" norm (so ")#mi("{\\partial_j \\psi_n}")#text(" converges to ")#mi("{\\partial_j (\\eta(t) u)}")#text(" in ")#mi("{L^2_t H^s_x}")#text(" norm), and ")#mi("{\\partial_t \\psi_n}")#text(" converges to ")#mi("{\\partial_t (\\eta(t) u)}")#text(" in ")#mi("{L^2_t H^{-1}_x}")#text(" norm. Since ")#mi("{v}")#text(" lies in ")#mi("{L^2_t H^1_x}")#text(", ")#mi("{\\partial_j v}")#text(" lies in ")#mi("{L^2_t L^2_x}")#text(", and ")#mi("{\\partial_j (v_j v)}")#text(" lies in ")#mi("{L^2_t L^1_x}")#text(" by Hölder and Sobolev, we can take limits and conclude that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} - v \\cdot \\partial_t (\\eta(t) u)+ \\partial_j (v_j v) \\cdot \\mathbb{P} (\\eta(t) u) + \\nu \\partial_j v \\cdot \\partial_j (\\eta(t) u)\\ dx dt")]]

#align(center)[#tao-fit-display[#tao-math("= \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx.", block: true)]]

#text("Since ")#mi("{u}")#text(" is divergence-free, and ")#mi("{\\eta(t)}")#text(" does not depend on the spatial variables, we can simplify this slightly as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\int_{{\\bf R}^d} - \\eta^{\\prime}(t) u \\cdot v - \\eta(t) v \\cdot \\partial_t u + \\eta(t) \\partial_j (v_j v) \\cdot u + \\eta(t) \\nu \\partial_j v \\cdot \\partial_j u\\ dx dt")]]

#align(center)[#tao-fit-display[#tao-math("= \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx", block: true)]]

#text("and so we can write ")#link(<tao-1241936d4dd3aad68fe7>)[#text("(28)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} \\eta(t) \\int_{{\\bf R}^d} [v \\cdot \\partial_t u - \\partial_j (v_j v) \\cdot u - \\nu \\partial_j v \\cdot \\partial_j u]\\ dx dt")]]

#align(center)[#tao-fit-display[#tao-math("+ \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx.", block: true)]]

#text("Using the Lebesgue differentiation theorem as in the proof of Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(", we conclude that for almost every ")#mi("{T}")#text(", one has the identity")

#tao-aligned(keep: true)[


#tao-math("\\int_{{\\bf R}^d} u(T) \\cdot v(T)\\ dx  & = \\int_0^T \\int_{{\\bf R}^d} [v \\cdot \\partial_t u - \\partial_j (v_j v) \\cdot u - \\nu \\partial_j v \\cdot \\partial_j u]\\ dx dt", block: true)



#tao-math(" & + \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx.", block: true)
]

#text("Applying ")#link(<tao-83e1afedfca86f152655>)[#text("(15)")]#text(", the right-hand side is")

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\int_{{\\bf R}^d} -v \\cdot \\mathbb{P} \\partial_j(u_j u) - \\partial_j (v_j v) \\cdot u + \\nu v \\cdot \\Delta u - \\nu \\partial_j v \\cdot \\partial_j u\\ dx dt + \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx.", block: true)]]

#text("(Note that expressions such as ")#mi("{\\int_0^T \\int_{{\\bf R}^d} v \\cdot \\Delta u\\ dx dt}")#text(" are well defined because ")#mi("{u, v}")#text(" lie in ")#mi("{L^2_t H^1_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(".) We can integrate by parts (justified using the usual limiting argument and the bounds on ")#mi("{u,v}")#text(") and use the divergence-free nature of ")#mi("{v}")#text(" to write this as")

#align(center)[#tao-fit-display[#tao-math("\\int_0^T \\int_{{\\bf R}^d} -v \\cdot \\partial_j(u_j u) - u \\cdot \\partial_j (v_j v) - 2\\nu \\partial_j v \\cdot \\partial_j u\\ dx dt + \\int_{{\\bf R}^d} \\left|u_0\\right|^2\\ dx.", block: true)]]

#text("Inserting this into ")#link(<tao-5dcf449f49d5c8247116>)[#text("(27)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("E(T) \\leq \\int_0^T \\int_{{\\bf R}^d} - u \\cdot \\partial_j (v_j v) - v \\cdot \\partial_j(u_j u) - \\nu \\left|\\nabla v - \\nabla u\\right|^2\\ dx dt.", block: true)]]

#text("We write ")#mi("{v = u + w}")#text(" and write this as")

#tao-aligned(keep: true)[


#tao-math("E(T)  & \\leq \\int_0^T \\int_{{\\bf R}^d} - u \\cdot \\partial_j (2 u_j u + w_j u + w u_j + w_j w) - w \\cdot \\partial_j(u_j u)", block: true)



#tao-math(" & - \\nu \\left|\\nabla w\\right|^2\\ dx dt,", block: true)
]

#text("noting from the regularity ")#mi("{w \\in C^0_t L^2_x \\cap L^2_t H^1_x}")#text(", ")#mi("{u \\in C^0_t H^s_x \\cap L^2_t H^{s+1}_x}")#text(" on ")#mi("{[0,T] \\times {\\bf R}^d}")#text(" and Sobolev embedding that one can ensure that all integrals here are absolutely convergent.")

#text("The integral ")#mi("{\\int_0^T \\int_{{\\bf R}^d} u \\cdot \\partial_j (2 u_j u)\\ dx dt}")#text(" can be rewritten using integration by parts as ")#mi("{-2\\int_0^T \\int_{{\\bf R}^d} u_j (\\partial_j u) \\cdot u\\ dx dt}")#text(" (noting that there is enough regularity to justify the integration by parts by the usual limiting argument); expressing ")#mi("{\\partial_j u \\cdot u}")#text(" as a total derivative ")#tao-math("{\\frac{1}{2} \\partial_j \\left|u\\right|^2}", block: false)#text(" and integrating by parts again using the divergence-free nature of ")#mi("{u}")#text(", we see that this expression vanishes. Similarly for the ")#mi("{u \\cdot \\partial_j (w_j u)}")#text(" term. Now we eliminate the remaining terms which are linear in ")#mi("{w}")#text(":")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{{\\bf R}^d} -u \\cdot \\partial_j (w u_j) - w \\cdot \\partial_j(u_j u).")]]

#text("We may integrate by parts, and write the dot product in coordinates, to write this as")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{{\\bf R}^d} (\\partial_j u_k) w_k u_j - w_k \\cdot \\partial_j(u_j u_k).")]]

#text("Applying the Leibniz rule and the divergence-free nature of ")#mi("{u}")#text(", we see that this expression vanishes. We conclude that")

#align(center)[#tao-fit-display[#tao-math("E(T) \\leq \\int_0^T \\int_{{\\bf R}^d} - u \\cdot \\partial_j (w_j w) - \\nu \\left|\\nabla w\\right|^2\\ dx dt.", block: true)]]

#text("Now we use the Leibniz rule, the divergence-free nature of ")#mi("{w}")#text(", and the arithmetic mean-geometric mean inequality to write")

#align(center)[#tao-fit-display[#tao-math("\\left|u \\cdot \\partial_j(w_j w)\\right| \\leq \\left|u\\right| \\left|w\\right| \\left|\\nabla w\\right| \\leq \\nu \\left|\\nabla w\\right|^2 + \\frac{1}{4 \\nu} \\left|u\\right|^2 \\left|w\\right|^2", block: true)]]

#text("to obtain")

#align(center)[#tao-fit-display[#tao-math("E(T) \\leq \\frac{1}{4\\nu} \\int_0^T \\int_{{\\bf R}^d} \\left|u\\right|^2 \\left|w\\right|^2", block: true)]]

#text("and hence by Sobolev embedding we have")

#align(center)[#tao-fit-display[#tao-math("E(T) \\lesssim_{d,s,\\nu} \\left\\| u \\right\\|_{L^2_t H^{s+1}_x([0,T] \\times {\\bf R}^d)} \\int_0^T E(t)\\ dt", block: true)]]

#text("for almost all ")#mi("{T \\in [0,T_*)}")#text(". Applying Gronwall’s inequality (modifying ")#mi("{E}")#text(" on a set of measure zero) we conclude that ")#mi("{E(T) = 0}")#text(" for almost all ")#mi("{T}")#text(", giving the claim. ")#mi("\\Box")

#text("One application of weak-strong uniqueness results is to give (in the ")#mi("{d=3}")#text(" case at least) ")#emph[#text("partial regularity")]#text(" on the weak solutions constructed by Leray, in that the solutions ")#mi("{u}")#text(" agree with smooth solutions on large regions of spacetime – large enough, in fact, to cover all but a measure zero set of times ")#mi("{t}")#text(". Unfortunately, the complement of this measure zero set could be disconnected, and so one could have different smooth solutions agreeing with ")#mi("{u}")#text(" at different epochs, so this is still quite far from an assertion of global regularity of the solution. Nevertheless it is still a non-trivial and interesting result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Partial regularity)")]#text(" Let ")#mi("{d=3}")#text(". Let ")#mi("{u_0}")#text(" be as in Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(", and let ")#mi("{u}")#text(" be a weak solution constructed using the proof of Theorem ")#link(<tao-8907fd712c5bd01e5f48>)[#text("14")]#text(".")

#list(
[#text("(i) (Eventual regularity) There exists a time ")#mi("{0 < T_0 < +\\infty}")#text(" such that (after modification on a set of measure zero), the weak solution ")#mi("{u}")#text(" on ")#mi("{[T_0,+\\infty) \\times {\\bf R}^3}")#text(" agrees with an ")#mi("{H^1}")#text(" mild solution on ")#mi("{[T_0,+\\infty) \\times {\\bf R}^3}")#text(" with initial data ")#mi("{u(T_0) \\in H^1_x({\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" (where we time shift the notion of a mild solution to start at ")#mi("{T_0}")#text(" instead of ")#mi("{0}")#text(").")],
[#text("(ii) (Epochs of regularity) There exists a compact exceptional set ")#mi("{E \\subset [0,+\\infty)}")#text(" of measure zero, such that for any time ")#mi("{t \\in [0,+\\infty) \\backslash E}")#text(", there is a time interval ")#mi("{[T_1,T_2]}")#text(" containing ")#mi("{t}")#text(" in its interior such that ")#mi("{u}")#text(" on ")#mi("{[T_1,T_2] \\times {\\bf R}^3}")#text(" agrees almost everywhere whtn an ")#mi("{H^1}")#text(" mild solution on ")#mi("{[T_1,T_2] \\times {\\bf R}^3}")#text(" with initial data ")#mi("{u(T_1) \\in H^1_x({\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" (Sketch) We begin with (i). From ")#link(<tao-6cb3f51eed90e7dbe08c>)[#text("(18)")]#text(", the ")#mi("{L^2_t L^2_x([0,+\\infty) \\times {\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" norm of ")#mi("{\\nabla u}")#text(" and the ")#mi("{L^\\infty_t L^2_x([0,+\\infty) \\times {\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" norm of ")#mi("{u}")#text(" are finite. Thus, for any ")#mi("{\\varepsilon>0}")#text(", one can find a positive measure set of times ")#mi("{T}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla u(T) \\right\\|_{L^2_x({\\bf R}^3 \\rightarrow {\\bf R}^9)} \\left\\| u(T) \\right\\|_{L^2_x({\\bf R}^3 \\rightarrow {\\bf R}^3)} \\leq \\varepsilon", block: true)]]

#text("which by Plancherel and Cauchy-Schwarz implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(T) \\right\\|_{\\dot H^{1/2}_x({\\bf R}^3 \\rightarrow {\\bf R}^3)} \\lesssim \\varepsilon^{1/2}.", block: true)]]

#text("In particular, by Exercise ")#link(<tao-592a05acd0f3079f91e9>)[#text("16")]#text(", one can find a time ")#mi("{T_0}")#text(" such that ")#mi("{u}")#text(" is a weak solution on ")#mi("{[T_0,+\\infty)}")#text(" with initial data ")#mi("{u(T_0) \\in H^1_x({\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(" obeying the energy inequality, with")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(T_0) \\right\\|_{\\dot H^{1/2}_x({\\bf R}^3 \\rightarrow {\\bf R}^3)} \\lesssim \\varepsilon^{1/2}.", block: true)]]

#text("By the small data global existence theory (Theorem 45 from ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations")[#text("Notes 1")]#text("), if ")#mi("{\\varepsilon>0}")#text(" is chosen small enough, then there is then a global ")#mi("{H^1}")#text(" mild solution on ")#mi("{[T_0,+\\infty) \\times {\\bf R}^3}")#text(" to the Navier-Stokes equations with initial data ")#mi("{u(T_0)}")#text(", which must then agree with ")#mi("{u}")#text(" by weak-strong uniqueness. This proves (i).")

#text("Now we look at (ii). In view of (i) we can work in a fixed compact interval ")#mi("{[0,T_0]}")#text(". Let ")#mi("{0 < t \\leq T_0}")#text(" be a time, and let ")#mi("{\\varepsilon>0}")#text(" be a sufficiently small constant. If there is a positive measure set of times ")#mi("{0 < T_1 < t}")#text(" for which")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(T_1) \\right\\|_{H^1_x({\\bf R}^3)} \\leq \\varepsilon / (T_1-t)^{1/4},", block: true)]]

#text("then by the same argument as above (but now using ")#mi("{H^1}")#text(" well-posedness theory instead of ")#mi("{\\dot H^{1/2}}")#text(" well-posedness theory, which was not explicitly covered in previous notes but can be handled by variants of the techniques there), we will be able to equate ")#mi("{u}")#text(" (almost everywhere) with an ")#mi("{H^1}")#text(" mild solution on ")#mi("{[T_1,T_2] \\times {\\bf R}^3}")#text(" for some neighbourhood ")#mi("{[T_1,T_2]}")#text(" of ")#mi("{t}")#text(". Thus the only times ")#mi("{t}")#text(" for which we cannot do this are those for which one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(T_1) \\right\\|_{H^1_x({\\bf R}^3)} \\geq \\varepsilon / (T_1-t)^{1/4}", block: true)]]

#text("for almost all ")#mi("{0 < T_1 < t}")#text(". In particular, using Vitali-type covering lemmas, for any ")#mi("{\\delta>0}")#text(", one can cover such times by the doubles of a finite collection of intervals of length ")#mi("{\\delta}")#text(", such that ")#tao-math("{\\left\\| u(T)\\right\\|_{H^1_x({\\bf R}^3)} \\gtrsim \\delta^{-1/4}}", block: false)#text(" for almost every ")#mi("{T}")#text(" in that interval. On the other hand, as ")#mi("{u}")#text(" is bounded in ")#mi("{L^2_t H^1_x([0,T_0] \\times {\\bf R}^3 \\rightarrow {\\bf R}^3)}")#text(", the number of disjoint time intervals of this form is at most ")#mi("{O( \\delta^{-1/2} )}")#text(" (where we allow the implied constant to depend on ")#mi("{u}")#text(" and ")#mi("{T_0}")#text("). Thus the set of exceptional times can be covered by ")#mi("{O(\\delta^{-1/2})}")#text(" intervals of length ")#mi("{\\delta}")#text(", and thus its closure has Lebesgue measure ")#mi("{O(\\delta^{1/2})}")#text(". Sending ")#mi("{\\delta \\rightarrow 0}")#text(" we see that the exceptional times are contained in a closed measure zero subset of ")#mi("{[0,T_0]}")#text(", and the claim follows. ")#mi("\\Box")

#text("The above argument in fact shows that the exceptional set ")#mi("{E}")#text(" in part (ii) of the above theorem will have upper Minkowski dimension at most ")#mi("{1/2}")#text(" (and hence also Hausdorff dimension at most ")#mi("{1/2}")#text("). There is a significant strengthening of this partial regularity result ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=673830")[#text("due to Caffarelli, Kohn, and Nirenberg")]#text(", which we will discuss in later notes.")

#heading(level: 1)[#text("Comments (48)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a25625bbd643889041c7bea26afdb6aa7c5d1bd5fb04522502cf5efdc4027ad7-1cb970cce66496034f68df26f20d5016599886da9d4a63bcbad695dbecccc9bb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quanling Deng")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505556")[#strong[#text("Quanling Deng")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2018")])]

#text("Reblogged this on ")#link("https://gonewithmath.wordpress.com/2018/10/03/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("gonewithmath")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/113036bc3b7e217fa340ded7e1a8379cbb6a7b2a723bac79a39df2b1aeea4eb0-00cb93e2823945dbaa2a98b8ab022e559af925dc015a2b12de5474eb7058aeb2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gabriel Apolinario")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505569")[#strong[#text("Gabriel Apolinario")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2018")])]

#text("These notes are a great resource.")#linebreak()#text(" Terry, there’s a missing word in the first paragraph: “are not high enough regularity”")

#emph[#text("[Reworded – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/288aec238adc0b32df98cab5af571a2dc982a5d0fb6cd488400a0a0187fdaf2e-0328b77df668c75b3b45e609ea18039dc2c8be1cd32cbe278508cceed3ee2b83.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Anil Pedgaonkar")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505575")[#strong[#text("Dr. Anil Pedgaonkar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2018")])]

#text("Why maths people are left with old topics like fluid mechanics while topics like relativity theory string theory quantum theory are with physics")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505577")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2018")])]

#text("Turbulence is still not well understood and since we live in turbulent times it may become a contemporary subject.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505604")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2018")])]

#text("No doubt you are aware of ")#link("https://en.wikipedia.org/wiki/Straw_man")[#text("https://en.wikipedia.org/wiki/Straw_man")]#text(" in your post, but let us overlook that. The reason why fluid mechanics, in particular Navier-Stokes equations, is mathematically interesting is that its behavior is not well-understood, even though its formulation is extremely simple. Anyone with modest math education can “understand” the governing equations, but no-one knows whether they are well-posed for arbitrarily long time intervals. Certainly there are open problems and plenty of theory building to be done in string theory and other fields practiced by “big bad physicists” where the problem setting itself is more complicated, but one is simply less surprised to encounter unsolved problems in more complicated settings. Moreover, all the fields you mentioned belong to mathematical physics and are under active research by quite a few well-trained people who consider themselves primarily as mathematicians.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0c66ead9d57be1b9fb7c592d26498fb6199c971c567dc67ba8ee06bc82148674-581fe2315e6309a341cd26d11f68809d4c26c86e03c878e710d821f1ed6602fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juha-Matti Perkkiö")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505605")[#strong[#text("Juha-Matti Perkkiö")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2018")])]

#text("Prof. Tao,")

#text("the recent polymath-projects discussed in this blog have been very inspiring and seem to be rather efficient when their goals are set properly. Could there be a case for some kind of mixed analysis/numerical analysis/computational project to gain some insight on Navier-Stokes? What comes to mind is for example to generate solutions with H^2- or H^1-norm growing as fast as possible/decaying as slow as possible or perhaps to generate solutions decaying as fast as possible in some relevant weaker norm like L^2. I am aware that even the existence of suitable quantitative criteria for the reliability of such numerical experiments is not self-evident, but perhaps there are some.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f74fdb0dcaa0cd19704c7a2ecd5ca1ce3c536fc69389e58e0904d9077155ca68-40bd8040410cbdbc5674a935f2b8c93254533911e7f6b0f0fe68b5f8871a1b42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505614")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("Apologies, I must be missing something basic, but why do the bounds on the ")#mi("L^\\infty_t L^2_x")#text(" norm of ")#mi("u^{(n)}")#text(" and ")#mi("L^2_tL^2_x")#text("-norm of ")#mi("\\nabla u^{(n)}")#text(" imply an ")#mi("L^\\infty_t H^1")#text(" bound on ")#mi("u")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f74fdb0dcaa0cd19704c7a2ecd5ca1ce3c536fc69389e58e0904d9077155ca68-40bd8040410cbdbc5674a935f2b8c93254533911e7f6b0f0fe68b5f8871a1b42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505615")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("Sorry, I should specify that I’m talking about estimate (21).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2018")])]

#text("This was a typo: it has been corrected to ")#mi("L^2_t H^1_x")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f74fdb0dcaa0cd19704c7a2ecd5ca1ce3c536fc69389e58e0904d9077155ca68-40bd8040410cbdbc5674a935f2b8c93254533911e7f6b0f0fe68b5f8871a1b42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505731")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("Ah, yes, that makes sense. Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/802228f63be3c0010639008d2564eb0250f2141168464cd4255f8eb5486ad7c1-f3fe7a52a65cbcd5d2c04786aad240aed2fb8d7d2fea316d1b8b792cf395ead1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huang")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505735")[#strong[#text("Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2018")])]

#text("Terry，I am Chinese. I have a new opinion about Callatz Conjecture. How can I send it to you?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2018")])]

#text("Are you Huang Deren mathematician?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/802228f63be3c0010639008d2564eb0250f2141168464cd4255f8eb5486ad7c1-f3fe7a52a65cbcd5d2c04786aad240aed2fb8d7d2fea316d1b8b792cf395ead1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Huang")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505771")[#strong[#text("Huang")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2018")])]

#text("No")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Local well-posedness for the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-505786")[#strong[#text("254A, Notes 3: Local well-posedness for the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("[…] weak compactness (Proposition 2 of Notes 2), one can pass to a subsequence such that converge weakly to some limits , such that and all […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3689e0d6a9fec56942fa60464bf07751c27cd5544336804003cbf9dba71609ae-0d5e08416596109ba9142a3c4e88e91ab82c3daf8ee32bc07240118771435eff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stefan")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-507000")[#strong[#text("Stefan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2018")])]

#text("As a double major in theoretical physics/theoretical computer science, I’m very intersted in this.")

#text("Does anybody know if this is related to “Homotopy Analysis Method in Nonlinear Differential Equations” and “Liao’s Method of Directly Defining the Inverse Mapping (MDDiM).”?")

#link("https://www.researchgate.net/publication/266832165_Homotopy_Analysis_Method_in_Nonlinear_Differential_Equations")[#text("https://www.researchgate.net/publication/266832165_Homotopy_Analysis_Method_in_Nonlinear_Differential_Equations")]

#link("https://link.springer.com/article/10.1007/s11075-015-0077-4")[#text("https://link.springer.com/article/10.1007/s11075-015-0077-4")]

#text("Anyway, since reading the post about ultrafilters and hierarchical infinitesimals, I feel that more boundries between physics and computer science could be broken and new solutions be found.")

#text("I think it is about time to solve the crisis in physics")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-507025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2018")])]

#text("In physics, the subjective(!) description “more beautiful” for a desired feature of a better new theory should be replaced (or interpreted) by the objective(!) description “more symmetrical”. It is interesting to observe that each new physical theory is indeed “more symmetrical” (i.e. invariant under a larger group of transformations) – leading to (the already observed) microscopic “fearfull symmetry” for all known elementary particles interactions, and also macroscopically for gravitation.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-508596")[#strong[#text("254A, Supplemental: Weak solutions from the perspective of nonstandard analysis (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2018")])]

#text("[…] a Notes 2, we reviewed the classical construction of Leray of global weak solutions to the Navier-Stokes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 255B, Notes 1: The Lagrangian formulation of the Euler equations | What's new")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-508850")[#strong[#text("255B, Notes 1: The Lagrangian formulation of the Euler equations | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2018")])]

#text("[…] Despite the popularity of the initial condition (4), we will try to keep conceptually separate the Eulerian space from the Lagrangian space , as they play different physical roles in the interpretation of the fluid; for instance, while the Euclidean metric is an important feature of Eulerian space , it is not a geometrically natural structure to use in Lagrangian space . We have the following more general version of Exercise 8 from 254A Notes 2: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45a5be4295cafec35e3c7fe6ba826a3711bdd7d1deb23dac47a438025de2b08f-b139d299a820f33231f451488b7494f1c4e826ac17f66148ebe55f6794f62e44.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guilherme Rezende")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-513068")[#strong[#text("Guilherme Rezende")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2019")])]

#text("You have tried solutions in the form: ")#mi("u_{i}(x,t)=u_{i}^{0}+\\frac{c_{i}te^{-t}}{cosh(k_{1}x_{1}+k_{2}x_{2}+k_{3}x_{3})}")#text(" with ")#mi("c_{2}+c_{3}+c_{4}=0")#text(" and ")#mi("k_{1}c_{1}+k_{2}c_{2}+k_{3}c_{3}=0")#text(" ? they work")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9b379798ea85a002113647888af66caf93519cbf5b2b392692d1dcf422c1b01-273710622e39a4de9c08f95361181aeae85806e1619fe90321c7b8363ca9d148.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaher")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-514537")[#strong[#text("Zaher")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2019")])]

#text("In the discussion following (24), it is said that {u^{(n)}} is bounded in {L^\\infty_t L^p_x}, uniformly in {n}, for some {2 < p < \\infty}. But we only have uniform {L_2 H^1} control which would give {L_t^2 L_x^p}. As a consequence, {F_j^N} is uniformly bounded in {L_t^1 L_x^{p/2}}. This does not affect the argument, apart from some apparent typos.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-514914")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("If one considers the Dirichlet boundary conditions on a bounded domain, does the Leray projection preserve the boundary condition?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8543bdb72931a4f8507babe0a0589bfa4d5704b53903a36f25b9afbfa912c5c4-399f1e2f700a4a9ea7bb3f257babcb53e8b730b6b53916f56d54ec113b9fe29e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-519278")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2019")])]

#text("Hello, I am interested in the solutions of the Navier-Stokes equations.")#linebreak()#text(" Is a weak solution for the 3D Navier-Stokes equations locally unique?")#linebreak()#text(" If ")#mi("u")#text(", ")#mi("v")#text(" are two weak Leray solutions for the 3D Navier-Stokes equations with")#linebreak()#text(" ")#mi("u(0)=v(0)")#text(" (1)")#linebreak()#text(" Then there is a small ")#mi("\\delta > 0")#text(" ,")#linebreak()#text(" such that ")#mi("u(t)=v(t)")#text(" for all ")#mi("t\\in[0,\\delta]")#text(" (2).")#linebreak()#text(" Is it true that (1) implies (2) using weak continuity, energy inequality?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-519282")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2019")])]

#text("I am not aware of such a result (and this would likely be of comparable difficulty as establishing global uniqueness for Leray-Hopf solutions, which is not universally believed to be true). It is true however that ")#mi("u(t)-v(t)")#text(" will converge strongly to zero in ")#mi("L^2")#text(" as ")#mi("t \\to 0")#text(" (possibly after modifying the weak solution on a measure zero set of times), thanks to Exercise 19. And weak-strong uniqueness will kick in if one of the weak solutions ")#mi("u,v")#text(" is strong.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8543bdb72931a4f8507babe0a0589bfa4d5704b53903a36f25b9afbfa912c5c4-399f1e2f700a4a9ea7bb3f257babcb53e8b730b6b53916f56d54ec113b9fe29e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-519294")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2019")])]

#text("We assume that the following assertion is true:")#linebreak()#text(" Let u, v two weak Leray solutions of the 3D Navier-Stokes equations on ")#mi("[a,T]")#text(", with ")#mi("a>0")#text(" corresponding to the same data ")#mi("u(a)")#text(".")#linebreak()#text(" Then ")#mi("u(t)=v(t)")#text(" almost everywhere on ")#mi("[a,T]")#text(".")#linebreak()#text(" Is this an uniqueness result for weak Leray solutions of the 3D Navier-Stokes equations ?")#linebreak()#text(" Or, It must to extend this to ")#mi("a=0")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-519337")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2019")])]

#text("This would depend rather sensitively on how one actually defines the notion of a “weak Leray solution on ")#mi("[a,T]")#text("“. For instance, would one require the energy inequality (18) to hold starting from time ")#mi("t=a")#text(", or from time ")#mi("t=0")#text("? Similarly for the distributional initial value condition (17). With weak solutions one has to be very careful with the precise definitions and hypotheses, as it is very easy to make subtle errors in one’s reasoning otherwise by blindly applying a fact that is true for classical solutions to one or more weak solutions. For instance, depending on how precisely one defines a “Leray weak solution”, the time translation ")#mi("(t,x) \\mapsto u(t+a,x)")#text(" of a Leray weak solution ")#mi("u")#text(" may not itself be a Leray weak solution, even though the corresponding fact for classical solutions is trivially true.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b552293faf977d93ae5ed706a9249ad5e789f8d9bff93f89da10b0f1472e70d8-d81138d2501078e642a558e2c947a61e332a701320f1ed496d0a515b0ccdfc7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Antoine")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-564525")[#strong[#text("Antoine")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2020")])]

#text("At the end of the lecture, you said that you would cover the Caffarelli-Kohn-Nirenberg theorem, which I would like to read about. However, the later notes only cover Euler equations related topics. Do you stil plan on writing notes on this matter?")

#emph[#text("[No – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-596451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2020")])]

#text("Before Exercise 4:")

#emph[#text("Thanks to the fundamental theorem of calculus for locally integrable functions, we still recover the unique solution (16):")#linebreak()#text(" ")]

#text("and also in Exercise 4(ii):")

#emph[#text("One has (16) for almost all ")#mi("{t \\in [0,T)}")#text(".")]

#text("“(16)” is linked to equation (3).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597258")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2020")])]

#text("At the level of set function, a function ")#mi("u:[0,T]\\times \\mathbf{R}^d\\to\\mathbf{R}")#text(" can be always interpreted as")#linebreak()#text(" ")#mi("u:[0,T]\\to X")#text(" where ")#mi("X")#text(" is the set of functions from ")#mi("\\mathbf{R}^d")#text(" to ")#mi("\\mathbf{R}")#text(" and ")#mi("(u(t))(x)=u(t,x)")#text(".")

#text("If one puts extra assumptions on ")#mi("u")#text(" so that ")#mi("u(t)\\in X")#text(" for all ")#mi("t")#text(" and ")#mi("X")#text(" is some nice (separable, self-reflexive, …) Banach space, then there are two ways to define the weak partial derivative ")#mi("\\partial_tu")#text(".")

#text("One way is to define it as a distribution on ")#mi("\\mathbf{R}\\times\\mathbf{R}^d")#text(", as in this set of notes, which is a continuous linear functional on ")#mi("C_c^\\infty(\\mathbf{R}\\times\\mathbf{R}^d\\to\\mathbf{R})")#text(" (with the smooth topology). This notion does not depend on the structure of ")#mi("X")#text(" mentioned above.")

#text("Another way is that if one knows in addition, ")#mi("u\\in L^1((0,T);X)")#text(", i.e., ")#mi("u")#text(" is strongly measurable such that ")#tao-math("\\int_{[0,T]}\\left\\|u(t)\\right\\|_{X}dt<\\infty", block: false)#text(", one can define ")#mi("u^{\\prime}=v\\in L^1((0,T);X)")#text(" be the \"weak derivative of ")#mi("u")#text(" where")#linebreak()#text(" ")#mi("\\displaystyle \\int_0^T\\phi^{\\prime}(t)u(t)dt=-\\int_0^T\\phi(t)v(t)dt")#linebreak()#text(" for all ")#mi("\\phi\\in C_c^\\infty((0,T)\\to\\mathbf{R})")#text(". Here ")#mi("u^{\\prime}")#text(" is a continuous functional on ")#mi("C_c^\\infty((0,T))")#text(".")

#text("Are these two notions of \"weak derivative\" somehow equivalent to each other so that one can always write one in terms of another and safely use them interchangeably?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597445")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("As a general rule, any two “good” notions of weak or strong derivative (or integral, or other standard linear operation) would be expected to coincide on their common domain of definition. One reason for this is that (i) almost all the usual domains of definition admit some nice class of test functions which are dense these domains in suitable topologies; (ii) a “good” interpretation of the operation in question tends to be weakly continuous with respect to these topologies (e.g., as measured in the distributional topology), and (iii) weak limits are unique. It would be a good exercise for you to work out this scheme for the two notions of derivative you describe here to show that they are compatible on the common domain of definition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597518")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#emph[#linebreak()#text(" … by the definition")#linebreak()#text(" ")#mi("\\displaystyle  \\langle \\partial_i \\lambda, \\phi \\rangle := - \\langle \\lambda, -\\partial_i \\phi \\rangle")#linebreak()#text(" ")]

#text("There is a redundant negative sign.")

#emph[#linebreak()#text(" … Two distributions ")#mi("{\\lambda, \\eta}")#text(" are equal in the sense of distributions of ")#mi("{\\langle \\lambda, \\phi \\rangle = \\langle \\eta, \\phi \\rangle}")#text(" for all ")#mi("{\\phi \\in C^\\infty(U \\rightarrow {\\bf R})}")#text("…")#linebreak()#text(" ")]

#text("I think the subscript ")#mi("c")#text(" is missing in ")#mi("C^\\infty(U \\rightarrow {\\bf R})")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("Could you elaborate on how Exercise 4 is done by the fundamental theorem of calculus for locally integrable functions?")

#text("By definition, (i) is the same as")

#mi("\\displaystyle -\\int_0^Tu\\partial_t\\phi(s)\\,ds = u_0\\phi(0)+\\int_0^Tf(s)\\phi(s)\\,ds\\ \\ \\ \\ \\ \\ (*)")

#text("for every ")#mi("\\phi\\in C_c^{\\infty}((-\\infty,T))")#text(". How does this lead to (3) almost everywhere?")

#text("On the other hand, if one assumes (3) almost everywhere, then (*) is true for some special test function ")#mi("\\phi")#text(". How does it generalize to every ")#mi("\\phi\\in C_c^{\\infty}((-\\infty,T))")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597914")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("For the first implication, it suffices by the second implication and linearity to verify the case ")#mi("u_0=f=0")#text(". By the fundamental theorem of calculus, any function in ")#mi("C^\\infty_c((-\\infty,T))")#text(" is equal on ")#mi("[0,T]")#text(" to the derivative of another function on ")#mi("C^\\infty_c((-\\infty,T))")#text(".")

#text("For the second implication, insert (3) into the left-hand side of (*), then apply Fubini’s theorem and then the fundamental theorem of calculus (the regularity hypotheses on ")#mi("u,f,\\phi")#text(" are more than sufficient to justify the formal manipulations).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2020")])]

#text("In section 2, when defining the weak solution using (4), ")#mi("u")#text(" is required to be “locally integrable”. In the more general setting of (5), ")#mi("u")#text(" is said to be “locally bounded”. Are these two notions equivalent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597915")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("No. For instance if ")#mi("q_n")#text(" is an enumeration of the rationals then ")#mi("\\sum_{n=1}^\\infty 2^{n} 1_{[q_n,q_n+4^{-n}]}")#text(" is locally integrable (in fact globally integrable) but not locally bounded. On the other hand all locally bounded functions are locally integrable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597684")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2020")])]

#text("In the proof of Theorem 14,")#linebreak()#text(" ")#emph[#linebreak()#text(" … This is enough regularity for Proposition 2 to apply, and we can pass to a subsequence of ")#mi("{u^{(n)}}")#text(" which converges in the sense of spacetime distributions in ")#mi("{{\\bf R} \\times{\\bf R}^d}")#text(" (after extending by zero outside of ")#mi("{[0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" to a limit ")#mi("{u}")#text(", which is in ")#mi("{L^\\infty_t H^1_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" for every ")#mi("{T}")#text(".")#linebreak()#text(" ")]

#text("(A piece of parenthesis is missing and I guess you mean extending by zero outside of ")#mi("[0,+\\infty) \\times {\\bf R}^d")#text(".)")

#emph[#text("[Typos corrected, also ")#mi("L^\\infty_t H^1_x")#text(" should be ")#mi("L^2_t H^1_x")#text(" -T.]")]

#text("I try to understand how Banach-Alaoglu (Prop 2) is used here. In particular, what is ")#mi("\\|\\|_X")#text(" and what is ")#mi("\\|\\|_{X^*}")#text(" in the argument above?")

#emph[#text("[Here ")#mi("X^* = L^2_t H^1_x")#text(" and ")#mi("X")#text(" is the predual space ")#mi("L^2_t H^{-1}_x")#text(" (or one can use the Riesz representation theorem for Hilbert spaces and take ")#mi("X=X^*")#text(" with the usual Riesz identification). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2020")])]

#text("I’m confused with the topologies on the linear space ")#mi("C_c^{\\infty}(U\\to\\mathbf{R})")#text(".")

#text("In the definition of distributions on ")#mi("U")#text(", there is a “standard” topology ")#mi("\\tau")#text(" on ")#mi("C_c^{\\infty}(U\\to\\mathbf{R})")#text(" that one defines the continuous linear functionals on ")#mi("C_c^{\\infty}(U\\to\\mathbf{R})")#text(" as distributions on ")#mi("U")#text(".")

#text("On the other hand, with a different norm/seminorm ")#mi("\\|\\|_X")#text(" on ")#mi("C_c^{\\infty}(U\\to\\mathbf{R})")#text(" in the hypothesis of Proposition 2, one has different topology ")#mi("\\tau_X")#text(". How does ")#mi("\\tau_X")#text(" compare to ")#mi("\\tau")#text("? How does one know that element in ")#mi("X^*")#text(" is a “distribution” so that one can talk about “converges in the sense of distributions” in Proposition 2?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-597993")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("Virtually every function space norm one works with in analysis, when restricted to test functions, gives a topology that is weaker than the test function topology, hence every linear functional that is continuous with respect to the norm topology will also be continuous with respect to the test function topology, and is hence a distribution.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-598038")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("(I tried to post the following comment previously. But I don’t know why it was classified as spam by WordPress…)")

#text("In the “approximate solutions” stage of the proof of Theorem 14, what is the purpose of introducing the notion of ")#mi("H^s")#text("-mild solution to (15) on a time interval ")#mi("[0,T]")#text("?")

#text("It is said after the ")#mi("H^s")#text("-mild solution definition that")

#emph[#linebreak()#text(" … By a modification of the theory of the previous set of notes, we thus see that there is a maximal Cauchy development ")#mi("{u^{(n)}: [0,T_*^{(n)}) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" that is a *smooth* solution to (19) (and an ")#mi("{H^s}")#text("-mild solution for every ")#mi("{s \\geq 0})")#text(", with ")#tao-math("{\\left\\|u^{(n)} \\right\\|_{L^\\infty_t L^\\infty_x([0,T_*^{(n)}))} = \\infty}", block: false)#text(" if ")#mi("{T_*^{(n)} < \\infty}")#text(".")#linebreak()#text(" ")]

#text("Isn’t being smooth better than being ")#mi("H^s")#text("-mild?")

#text("Later,")

#emph[#linebreak()#text(" … From (19) we know that ")#mi("{u^{(n)}}")#text(" and ")#mi("{\\partial_t u^{(n)}}")#text(" lie in ")#mi("{C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" for any ")#mi("{s \\geq 0}")#text(" and any ")#mi("{0 < T < T_*}")#text(".")#linebreak()#text(" ")]

#text("why the *smooth* ")#mi("u^{(n)}")#text(" now only lie in ")#mi("{C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-598052")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2020")])]

#text("Smoothness does not imply decay in space, so a smooth function does not automatically lie in ")#mi("H^s_x")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-598183")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2020")])]

#text("In the last big step of the proof of Theorem 14, the problem is reduced to showing (23):")

#mi("\\displaystyle  \\partial_j P_{\\leq N^{(n)}} \\mathbb{P}( (P_{\\leq N^{(n)}} u^{(n)}_j) (P_{\\leq N^{(n)}} u^{(n)}) ) \\rightharpoonup^* \\partial_j \\mathbb{P}( u_j u ), \\ \\ \\ \\ \\ (23)")

#text("which, by several intermediate steps, is reduced to showing that")#linebreak()#text(" ")#mi("\\displaystyle  P_{\\leq N}( u^{(n)} - u ) \\rightarrow 0")#linebreak()#text(" strongly in ")#mi("{L^2_t L^p_x(K \\rightarrow {\\bf R}^d)}")#text(" for every fixed ")#mi("{N}")#text(" and ")#mi("{K}")#text(".")

#text("If one wants to apply Proposition 3 (with some appropriate ")#mi("X^*")#text(" and ")#mi("Y^*")#text(") at some point, then it should be that ")#mi("Y^*=L^2_t L^p_x(K \\rightarrow {\\bf R}^d)")#text(" (right?). The sequence itself is not a space, what should ")#mi("X^*")#text(" be?")

#text("By showing that")

#mi("{\\partial_t P_{\\leq N}( u^{(n)} - u )}")#text(" is bounded in ")#mi("{L^2_t L^{\\infty}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")

#text("and")

#mi("{\\nabla P_{\\leq N}( u^{(n)} - u)}")#text(" is bounded in ")#mi("{L^\\infty_t L^{\\infty}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")

#text("the later paragraph shows that ")#mi("{P_{\\leq N}( u^{(n)} - u )}")#text(" is equicontinuous in ")#mi("{K}")#text(". In order to apply Arzela-Ascoli theorem, a pointwise bound for ")#mi("{P_{\\leq N}( u^{(n)} - u )}")#text(" is also needed (isn’t it?), is it alluded somewhere?")

#text("Also, when the Arzela-Ascoli theorem is applied, does one only have a uniformly convergent subsequence of ")#mi("{P_{\\leq N}( u^{(n)} - u )}")#text(" instead of the sequence itself as stated in the penultimate sentence of the proof? Would you elaborate how Proposition 3 is used there?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-598629")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2020")])]

#text("Proposition 3 can applied with ")#tao-math("\\left\\| u \\right\\|_{Y^*}", block: false)#text(" being the sum of the ")#mi("L^2_t L^\\infty_x(K \\times [0,T])")#text(" norm of ")#mi("\\partial_t u")#text(", the ")#mi("L^\\infty_t L^\\infty_x(K \\times [0,T])")#text(" norm of ")#mi("\\nabla u")#text(", and the ")#mi("L^\\infty_x(K)")#text(" norm of ")#mi("u(0)")#text(" (to get the lower order term, which in this case vanishes for ")#mi("n")#text(" large enough), and ")#mi("X^* = L^\\infty_t L^\\infty_x(K \\times [0,T])")#text(", with the Arzela-Ascoli theorem giving the required compact embedding. (One can check that these spaces have appropriate preduals ")#mi("X,Y")#text("; one can also use the proof of Proposition 3 directly rather than using it as a black box to obtain a similar conclusion, for instance the Urysohn subsequence principle can be used to deal with the subsequence problem you mentioned.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-600293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("In the definition (17) of the “weak solution” right before Theorem 14, is the divergence-free condition for ")#mi("u")#text(" hiding somewhere so that one does not need to incorporate it into the definition?")

#text("Does the mentioned definition (17) remain the same if one only considers the spacetime test functions that are (space) divergence-free?.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-600298")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2020")])]

#text("1. If the data is div-free then solutions to this equation are always div-free.")#linebreak()#text(" 2. The test function here is scalar-valued so this doesn’t make sense. If instead you dot it with a vector-valued test function, the answer is yes because of the Hodge decomposition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-600499")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2020")])]

#text("In the case when ")#mi("V")#text(" is a finite-dimensional vector space, particularly in the definition of “weak solutions” after Exercise 4, the notion of “distributions” seems to be no longer a continuous linear ")#emph[#text("functional")]#text(" on the space ")#mi("C_c^\\infty({\\bf R}^n)")#text(" but a map from ")#mi("C_c^\\infty({\\bf R}^n)")#text(" to ")#mi("V")#text(".")

#text("On the other hand, one can consider the vector-valued test functions ")#mi("{\\boldsymbol \\phi}\\in [C_c^\\infty((-\\infty, T))^n]^n")#text(" in the definition of weak solution:")#linebreak()#text(" ")#mi("\\displaystyle   - \\int_0^T u(s) \\cdot\\partial_t {\\boldsymbol \\phi}(s)\\ ds = u_0 \\cdot{\\boldsymbol \\phi}(0) + \\int_0^T F(u(s))\\cdot  {\\boldsymbol \\phi}(s)\\ ds")#linebreak()#text(" where ")#mi("V")#text(" is endowed with an inner product structure. In this case, one has linear ")#emph[#text("functionals")]#text(" on ")#mi("[C_c^\\infty((-\\infty, T))^n)]^n")#text(".")

#text("Are these two notions of weak solutions equivalent? (What if ")#mi("V")#text(" is of infinite-dimensional?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-600531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2020")])]

#text("For finite dimensions the two notions are equivalent, as can be easily be seen by selecting a basis for ")#mi("V")#text(" (e.g., by applying Gram-Schmidt to the inner product) and writing everything in coordinates. For infinite dimensional ranges, different notions of weak solution can in principle differ from each other, though many times in practice one has enough additional bounds on the specific weak solutions one constructs (e.g., by the Leray-Hopf method) that one can establish the weak solvability of the solution in any of the possible senses. Conversely, without such additional bounds the mere property of being weakly solvable is virtually useless, regardless of which specific notion of weak solution one prefers. So in practice the precise definition of weak solution is not of critical importance.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b71c6c27a04c4d12bc89b901df1cb462c2b93f9d6b8c3fb8b64f86f2395c639-fc8dd64ad38539c5e0d295b5f46db0b9ba664f3c8e813e2099a2f95b37f719dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jakob Moeller")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-602286")[#strong[#text("Jakob Moeller")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2020")])]

#text("A question about the spaces we need to show convergence of ")#mi("F_j^{(n)} \\rightharpoonup^{\\ast} \\mathbb{P}(u_ju)")#text(". We know by ")#mi("u^{(n)} \\in L^2_tH^1_x")#text(" and Sobolev as well as Hölder that ")#mi("F^{(n)}_j \\in L^1_tL^{p/2}_x")#text(" (all on ")#mi("[0,T]")#text("). It is later stated that ")#mi("(P_{\\geq N^{(n)}} u_j^{(n)})(P_{\\geq N^{(n)}} u^{(n)})")#text(" is in ")#mi("L^{\\infty}_t L_x^{(p/2)}")#text(". This is a little confusing to me. Shouldn’t it be in ")#mi("L^{1}_t L_x^{(p/2)}")#text(" as before? Especially because we reduce the claim to showing that ")#mi("P_{\\geq N^{(n)}} u^{(n)}")#text(" converges strongly in ")#mi("L^2_t L^p_x")#text(" to ")#mi("u")#text("?")

#emph[#text("[This was a typo, now corrected. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-682686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2023")])]

#text("Hello. I have a question about weak-strong uniqueness.")

#text("Most textbooks as well as your statement deal with the decaying turbulence only. That is, the external forcing term “f” is set to be zero.")

#text("However, it seems to me that your proof of weak-strong uniqueness actually works for any “f” belonging to L^2_t L^2_x.")

#text("Could you please tell me your opinion? I also would deeply appreciate if you recommend me any reference.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/#comment-682690")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2023")])]

#text("This seems plausible to me, although there are often subtleties with manipulating weak solutions and one would have to go through the proof carefully. I’m afraid I don’t know of a canonical reference for treating weak-strong uniqueness for the inhomogeneous problem, but I would imagine that this problem has been considered by multiple authors in the literature.")
]
]
