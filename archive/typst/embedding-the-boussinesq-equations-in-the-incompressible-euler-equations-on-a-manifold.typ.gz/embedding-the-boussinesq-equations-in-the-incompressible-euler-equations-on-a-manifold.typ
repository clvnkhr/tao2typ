// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/
// Converted to Typst by tao2typ: "2026-10-14T15:19:57.686009+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Embedding the Boussinesq equations in the incompressible Euler equations on a manifold", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Embedding the Boussinesq equations in the incompressible Euler equations on a manifold")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 14 December 2017")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/")[#text("https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("https://en.wikipedia.org/wiki/Boussinesq_approximation_(buoyancy)")[#text("Boussinesq equations")]#text(" for inviscid, incompressible two-dimensional fluid flow in the presence of gravity are given by ")#metadata(none) <tao-4d2d1dfcb8d03bc60bce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("(\\partial_t + u_x \\partial_x+ u_y \\partial_y) u_x = -\\partial_x p")]]

#metadata(none) <tao-bafd07bd8cf993dba8fd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("(\\partial_t + u_x \\partial_x+ u_y \\partial_y) u_y = \\rho - \\partial_y p")]]

#metadata(none) <tao-4438ca09da7d7bb2704d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("(\\partial_t + u_x \\partial_x+ u_y \\partial_y) \\rho = 0")]]

#metadata(none) <tao-2c56740841699f248ce2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\partial_x u_x + \\partial_y u_y = 0")]]

#text("where ")#mi("{u: {\\bf R} \\times {\\bf R}^2 \\rightarrow {\\bf R}^2}")#text(" is the velocity field, ")#mi("{p: {\\bf R} \\times {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" is the pressure field, and ")#mi("{\\rho: {\\bf R} \\times {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" is the density field (or, in some physical interpretations, the temperature field). In this post we shall restrict ourselves to formal manipulations, assuming implicitly that all fields are regular enough (or sufficiently decaying at spatial infinity) that the manipulations are justified. Using the ")#link("https://en.wikipedia.org/wiki/Material_derivative")[#text("material derivative")]#text(" ")#mi("{D_t := \\partial_t + u_x \\partial_x + u_y \\partial_y}")#text(", one can abbreviate these equations as")

#tao-aligned(keep: true)[


#tao-math("D_t u_x  & = -\\partial_x p", block: true)



#tao-math("D_t u_y  & = \\rho - \\partial_y p", block: true)



#tao-math("D_t \\rho  & = 0", block: true)



#tao-math("\\partial_x u_x + \\partial_y u_y  & = 0.", block: true)
]

#text("One can eliminate the role of the pressure ")#mi("{p}")#text(" by working with the ")#emph[#text("vorticity")]#text(" ")#mi("{\\omega := \\partial_x u_y - \\partial_y u_x}")#text(". A standard calculation then leads us to the equivalent “vorticity-stream” formulation")

#tao-aligned(keep: true)[


#tao-math("D_t \\omega  & = \\partial_x \\rho", block: true)



#tao-math("D_t \\rho  & = 0", block: true)



#tao-math("\\omega  & = \\partial_x u_y - \\partial_y u_x", block: true)



#tao-math("\\partial_x u_y + \\partial_y u_y  & = 0", block: true)
]

#text("of the Boussinesq equations. The latter two equations can be used to recover the velocity field ")#mi("{u}")#text(" from the vorticity ")#mi("{\\omega}")#text(" by the Biot-Savart law")

#align(center)[#tao-fit-display[#mitex("u_x := -\\partial_y \\Delta^{-1} \\omega; \\quad u_y = \\partial_x \\Delta^{-1} \\omega.")]]

#text("It has long been observed (see e.g. Section 5.4.1 of ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1867882")[#text("Bertozzi-Majda")]#text(") that the Boussinesq equations are very similar, though not quite identical, to the three-dimensional inviscid incompressible Euler equations under the hypothesis of axial symmetry (with swirl). The Euler equations are")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\nabla p", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("where now the velocity field ")#mi("{u: {\\bf R} \\times {\\bf R}^3 \\rightarrow {\\bf R}^3}")#text(" and pressure field ")#mi("{p: {\\bf R} \\times {\\bf R}^3 \\rightarrow {\\bf R}}")#text(" are over the three-dimensional domain ")#mi("{{\\bf R}^3}")#text(". If one expresses ")#mi("{{\\bf R}^3}")#text(" in polar coordinates ")#mi("{(z,r,\\theta)}")#text(" then one can write the velocity vector field ")#mi("{u}")#text(" in these coordinates as")

#align(center)[#tao-fit-display[#mitex("u = u^z \\frac{d}{dz} + u^r \\frac{d}{dr} + u^\\theta \\frac{d}{d\\theta}.")]]

#text("If we make the axial symmetry assumption that these components, as well as ")#mi("{p}")#text(", do not depend on the ")#mi("{\\theta}")#text(" variable, thus")

#align(center)[#tao-fit-display[#mitex("\\partial_\\theta u^z, \\partial_\\theta u^r, \\partial_\\theta u^\\theta, \\partial_\\theta p = 0,")]]

#text("then after some calculation (which we give below the fold) one can eventually reduce the Euler equations to the system ")#metadata(none) <tao-ca0417d59595abfa7a19>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\tilde D_t \\omega = \\frac{1}{r^4} \\partial_z \\rho")]]

#metadata(none) <tao-c3bb54755e09b7dd1c30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\tilde D_t \\rho = 0")]]

#metadata(none) <tao-b67c2a054d5bbe5c7c5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\omega = \\frac{1}{r} (\\partial_z u^r - \\partial_r u^z)")]]

#metadata(none) <tao-bf6fff9974460c845262>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\partial_z(ru^z) + \\partial_r(ru^r) = 0")]]

#text("where ")#mi("{\\tilde D_t := \\partial_t + u^z \\partial_z + u^r \\partial_r}")#text(" is the modified material derivative, and ")#mi("{\\rho}")#text(" is the field ")#mi("{\\rho := (r u^\\theta)^2}")#text(". This is almost identical with the Boussinesq equations except for some additional powers of ")#mi("{r}")#text("; thus, the intuition is that the Boussinesq equations are a simplified model for axially symmetric Euler flows when one stays away from the axis ")#mi("{r=0}")#text(" and also does not wander off to ")#mi("{r=\\infty}")#text(".")

#text("However, this heuristic is not rigorous; the above calculations do not actually give an embedding of the Boussinesq equations into Euler. (The equations do match on the cylinder ")#mi("{r=1}")#text(", but this is a measure zero subset of the domain, and so is not enough to give an embedding on any non-trivial region of space.) Recently, while playing around with trying to embed other equations into the Euler equations, I discovered that it is possible to make such an embedding into a ")#emph[#text("four")]#text("-dimensional Euler equation, albeit on a slightly curved manifold rather than in Euclidean space. More precisely, we use the ")#link("http://www.ams.org/mathscinet-getitem?mr=246328")[#text("Ebin-Marsden")]#text(" generalisation")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + \\nabla_u u  & = - \\mathrm{grad}_g p", block: true)



#tao-math("\\mathrm{div}_g u  & = 0", block: true)
]

#text("of the Euler equations to an arbitrary Riemannian manifold ")#mi("{(M,g)}")#text(" (ignoring any issues of boundary conditions for this discussion), where ")#mi("{u: {\\bf R} \\rightarrow \\Gamma(TM)}")#text(" is a time-dependent vector field, ")#mi("{p: {\\bf R} \\rightarrow C^\\infty(M)}")#text(" is a time-dependent scalar field, and ")#mi("{\\nabla_u}")#text(" is the covariant derivative along ")#mi("{u}")#text(" using the ")#link("https://en.wikipedia.org/wiki/Levi-Civita_connection")[#text("Levi-Civita connection")]#text(" ")#mi("{\\nabla}")#text(". In ")#link("https://en.wikipedia.org/wiki/Abstract_index_notation")[#text("Penrose abstract index notation")]#text(" (using the Levi-Civita connection ")#mi("{\\nabla}")#text(", and raising and lowering indices using the metric ")#mi("{g = g_{ij}}")#text("), the equations of motion become ")#metadata(none) <tao-167020255b8ecbb788c7>

#tao-aligned(keep: true)[


#tao-math("\\partial_t u^i + u^j \\nabla_j u^i  & = - \\nabla^i p", block: true, numbering: n => [#text("(9)")])



#tao-math("\\nabla_i u^i  & = 0;", block: true)
]

#text("in coordinates, this becomes")

#align(center)[#tao-fit-display[#mitex("\\partial_t u^i + u^j (\\partial_j u^i + \\Gamma^i_{jk} u^k) = - g^{ij} \\partial_j p")]]

#metadata(none) <tao-37edf9404d8649f6a673>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\partial_i u^i + \\Gamma^i_{ik} u^k = 0")]]

#text("where the ")#link("https://en.wikipedia.org/wiki/Christoffel_symbols")[#text("Christoffel symbols")]#text(" ")#mi("{\\Gamma^i_{jk}}")#text(" are given by the formula")

#align(center)[#tao-fit-display[#mitex("\\Gamma^i_{jk} := \\frac{1}{2} g^{il} (\\partial_j g_{lk} + \\partial_k g_{lj} - \\partial_l g_{jk}),")]]

#text("where ")#mi("{g^{il}}")#text(" is the inverse to the metric tensor ")#mi("{g_{il}}")#text(". If the coordinates are chosen so that the volume form ")#mi("{dg}")#text(" is the Euclidean volume form ")#mi("{dx}")#text(", thus ")#mi("{\\mathrm{det}(g)=1}")#text(", then on differentiating we have ")#mi("{g^{ij} \\partial_k g_{ij} = 0}")#text(", and hence ")#mi("{\\Gamma^i_{ik} = 0}")#text(", and so the divergence-free equation ")#link(<tao-37edf9404d8649f6a673>)[#text("(10)")]#text(" simplifies in this case to ")#mi("{\\partial_i u^i = 0}")#text(". The Ebin-Marsden Euler equations are the natural generalisation of the Euler equations to arbitrary manifolds; for instance, they (formally) conserve the kinetic energy")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_M \\left|u\\right|_g^2\\ dg = \\frac{1}{2} \\int_M g_{ij} u^i u^j\\ dg", block: true)]]

#text("and can be viewed as the formal geodesic flow equation on the infinite-dimensional manifold of volume-preserving diffeomorphisms on ")#mi("{M}")#text(" (see ")#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("this previous post")]#text(" for a discussion of this in the flat space case).")

#text("The specific four-dimensional manifold in question is the space ")#mi("{{\\bf R} \\times {\\bf R}^+ \\times {\\bf R}/{\\bf Z} \\times {\\bf R}/{\\bf Z}}")#text(" with metric")

#align(center)[#tao-fit-display[#mitex("dx^2 + dy^2 + y^{-1} dz^2 + y dw^2")]]

#text("and solutions to the Boussinesq equation on ")#mi("{{\\bf R} \\times {\\bf R}^+}")#text(" can be transformed into solutions to the Euler equations on this manifold. This is part of a more general family of embeddings into the Euler equations in which passive scalar fields (such as the field ")#mi("{\\rho}")#text(" appearing in the Boussinesq equations) can be incorporated into the dynamics via fluctuations in the Riemannian metric ")#mi("{g}")#text("). I am writing the details below the fold (partly for my own benefit).")

#metadata(none) <tao-fa9f8fb85613df80050b>

#text("Firstly, it is convenient to transform the Euler equations on an arbitrary Riemannian manifold to a ")#emph[#text("covelocity")]#text(" formulation, by introducing the covelocity ")#mi("{1}")#text("-form ")#mi("{v_i := g_{ij} u^j}")#text(", as this formulation allows one to largely avoid having to work with covariant derivatives or Christoffel symbols. Lowering indices in the Euler equation ")#link(<tao-167020255b8ecbb788c7>)[#text("(9)")]#text(" then gives the system")

#tao-aligned(keep: true)[


#tao-math("\\partial_t v_i + u^j \\nabla_j v_i  & = - \\partial_i p", block: true)



#tao-math("u^j  & = g^{ij} v_i", block: true)



#tao-math("\\nabla_i u^i  & = 0.", block: true)
]

#text("Noting that ")#mi("{u^j \\nabla_i v_j = \\frac{1}{2} \\partial_i ( u^j v_j)}")#text(", and introducing the modified pressure ")#mi("{p^{\\prime} := p + \\frac{1}{2} u^j v_j}")#text(", we arrive at the system")

#tao-aligned(keep: true)[


#tao-math("\\partial_t v_i + u^j (\\nabla_j v_i - \\nabla_i v_j)  & = - \\partial_i p^{\\prime}", block: true)



#tao-math("u^j  & = g^{ij} v_i", block: true)



#tao-math("\\nabla_i u^i  & = 0.", block: true)
]

#text("As the Levi-Civita connection is torsion-free (or equivalently, one has the symmetry ")#mi("{\\Gamma^i_{jk} = \\Gamma^i_{kj})}")#text(", we have ")#mi("{\\nabla_j v_i - \\nabla_i v_j = \\partial_j v_i - \\partial_i v_j}")#text(", thus we arrive at the system ")#metadata(none) <tao-e6184ce10e266134fdcf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\partial_t v_i + u^j (\\partial_j v_i - \\partial_i v_j) = - \\partial_i p^{\\prime}")]]

#metadata(none) <tao-94582e5e0efa969706ef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("u^j = g^{ij} v_i")]]

#metadata(none) <tao-61737afbdcf655054550>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\nabla_i u^i = 0")]]

#text("which is equivalent to (and thus embeddable in) the Euler equations. The advantage of this formulation is that the metric ")#mi("{g}")#text(" now plays no role whatsoever in the main equation ")#link(<tao-e6184ce10e266134fdcf>)[#text("(11)")]#text(", and only appears in ")#link(<tao-94582e5e0efa969706ef>)[#text("(12)")]#text(" and ")#link(<tao-61737afbdcf655054550>)[#text("(13)")]#text(". One can also interpret the expression ")#mi("{u^j (\\partial_j v_i - \\partial_i v_j)}")#text(" as the Lie derivative of the covelocity ")#mi("{v}")#text(" along the velocity ")#mi("{u}")#text(".")

#text("If one works in a coordinate system in which the volume form ")#mi("{dg}")#text(" is Euclidean (that is to say, ")#mi("{\\mathrm{det} g = 1}")#text("), then the Riemannian divergence ")#mi("{\\nabla_i u^i}")#text(" is the same as the ordinary divergence ")#mi("{\\partial_i u^i}")#text("; this can be seen either by viewing the divergence as the adjoint of the gradient operator with respect to the volume form, or else by differentiating the condition ")#mi("{\\mathrm{det} g = 1}")#text(" to conclude that ")#mi("{g^{ij} \\partial_k g_{ij} = 0}")#text(", which implies that ")#mi("{\\Gamma^i_{ik}=0}")#text(" and hence ")#mi("{\\nabla_i u^i = \\partial_i u^i}")#text(". But actually, as already observed in ")#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/")[#text("my previous paper")]#text(", one can replace ")#mi("{\\nabla_i u^i}")#text(" with ")#mi("{\\partial_i u^i}")#text(" “for free”, even if one does not have the Euclidean volume form condition ")#mi("{\\mathrm{det} g = 1}")#text(", if one is prepared to add an additional “dummy” dimension to the manifold ")#mi("{M}")#text(". More precisely, if ")#mi("{u, v, g, p^{\\prime}}")#text(" solves the system ")#metadata(none) <tao-3c44c3e1b8b784478672>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\partial_t v_i + u^j (\\partial_j v_i - \\partial_i v_j) = - \\partial_i p^{\\prime}")]]

#metadata(none) <tao-e7f045719968d9c05896>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("u^j = g^{ij} v_i")]]

#metadata(none) <tao-27278643264601c818c2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\partial_i u^i = 0")]]

#text("on some ")#mi("{d}")#text("-dimensional Riemannian manifold ")#mi("{(M,g)}")#text(", then one can introduce modified fields ")#mi("{\\tilde u, \\tilde v, \\tilde g, \\tilde p^{\\prime}}")#text(" on a ")#mi("{d+1}")#text("-dimensional manifold ")#mi("{(M^{\\prime},g^{\\prime})}")#text(" by defining")

#tao-aligned(keep: false)[


#tao-math("\\tilde M  & := M \\times {\\bf R}/{\\bf Z}", block: true)



#tao-math("d\\tilde g^2  & := dg^2 + \\mathrm{det}(g)^{-1} ds^2", block: true)



#tao-math("\\tilde u^i(x,s)  & := u^i(x)", block: true)



#tao-math("\\tilde u^s(x,s)  & := 0", block: true)



#tao-math("\\tilde v_i(x,s)  & := v_i(x)", block: true)



#tao-math("\\tilde v_s(x,s)  & := 0", block: true)



#tao-math("\\tilde p^{\\prime}(x,s)  & := p^{\\prime}(x)", block: true)
]

#text("then these fields obey the same system, and hence (since ")#mi("{\\mathrm{det}(\\tilde g)=1}")#text(") solve ")#link(<tao-e6184ce10e266134fdcf>)[#text("(11)")]#text(", ")#link(<tao-94582e5e0efa969706ef>)[#text("(12)")]#text(", ")#link(<tao-61737afbdcf655054550>)[#text("(13)")]#text(". Thus the above system is embeddable into the Euler equations in one higher dimension. To embed the Boussinesq equations into the four-dimensional Euler equations mentioned previously, it thus suffices to embed these equations into the system ")#link(<tao-3c44c3e1b8b784478672>)[#text("(14)")]#text("–")#link(<tao-27278643264601c818c2>)[#text("(16)")]#text(" for the three-dimensional manifold ")#mi("{{\\bf R} \\times {\\bf R}^+ \\times {\\bf R}/{\\bf Z}}")#text(" with metric ")#metadata(none) <tao-5b82f0ed7ad205f5b574>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("dx^2 + dy^2 + y^{-1} dz^2.")]]

#text("Let us more generally consider the system ")#link(<tao-3c44c3e1b8b784478672>)[#text("(14)")]#text("–")#link(<tao-27278643264601c818c2>)[#text("(16)")]#text(" under the assumption that ")#mi("{M}")#text(" splits as a product ")#mi("{M_1 \\times M_2}")#text(" of two manifolds ")#mi("{M_1,M_2}")#text(", with all data independent of the ")#mi("{M_2}")#text(" coordinates (but, for added flexibility, we do ")#emph[#text("not")]#text(" assume that the metric on ")#mi("{M}")#text(" splits as the direct sum of metrics on ")#mi("{M_1}")#text(" and ")#mi("{M_2}")#text(", allowing for twists and shears). This, if we use Roman indices to denote the ")#mi("{M_1}")#text(" coordinates and Greek indices to denote the ")#mi("{M_2}")#text(" coordinates (with summation only being restricted to these coordinates), and denote the inverse metric by the tensor with components ")#mi("{g^{ij}, g^{i\\beta}, g^{\\beta \\gamma}}")#text(", then we have ")#metadata(none) <tao-339efeab70b4cc6e2755>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("\\partial_\\alpha g^{ij}, \\partial_\\alpha g^{i\\beta}, \\partial_\\alpha g^{\\beta \\gamma} = 0")]]

#metadata(none) <tao-7e78e25d816a159e2c18>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\partial_\\alpha v_i, \\partial_\\alpha v_\\beta = 0")]]

#metadata(none) <tao-1b5fa29b7a43be5b0cba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\partial_\\alpha u^i, \\partial_\\alpha u^\\beta = 0")]]

#metadata(none) <tao-519a87309f69dd643823>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\partial_\\alpha p^{\\prime} = 0,")]]

#text("and then the system ")#link(<tao-3c44c3e1b8b784478672>)[#text("(14)")]#text("–")#link(<tao-27278643264601c818c2>)[#text("(16)")]#text(" in these split coordinates become")

#tao-aligned(keep: true)[


#tao-math("\\partial_t v_i + u^j (\\partial_j v_i - \\partial_i v_j) - u^\\alpha \\partial_i v_\\alpha  & = - \\partial_i p^{\\prime}", block: true)



#tao-math("\\partial_t v_\\beta + u^j \\partial_j v_\\beta  & = 0", block: true)



#tao-math("u^j  & = g^{ij} v_i + g^{\\alpha j} v_\\alpha", block: true)



#tao-math("u^\\alpha  & = g^{\\alpha \\beta} v_\\beta + g^{\\alpha j} v_j", block: true)



#tao-math("\\partial_i u^i  & = 0.", block: true)
]

#text("We can view this as a system of PDE on the smaller manifold ")#mi("{M_1}")#text(", which is then embedded into the Euler equations. Introducing the material derivative ")#mi("{D_t := \\partial_t + u^j \\partial_j}")#text(", this simplifies slightly to")

#tao-aligned(keep: true)[


#tao-math("D_t v_i - u^j \\partial_i v_j - u^\\alpha \\partial_i v_\\alpha  & = - \\partial_i p^{\\prime}", block: true)



#tao-math("D_t v_\\beta  & = 0", block: true)



#tao-math("u^j  & = g^{ij} v_i + g^{\\alpha j} v_\\alpha", block: true)



#tao-math("u^\\alpha  & = g^{\\alpha \\beta} v_\\beta + g^{\\alpha j} v_j", block: true)



#tao-math("\\partial_i u^i  & = 0.", block: true)
]

#text("We substitute the third and fourth equations into the first, then drop the fourth (as it can be viewed as a definition of the field ")#mi("{u^\\alpha}")#text(", which no longer plays any further role), to obtain")

#tao-aligned(keep: true)[


#tao-math("D_t v_i - g^{jk} v_k \\partial_i v_j - g^{\\alpha j} v_\\alpha \\partial_i v_j - g^{\\alpha \\beta} v_\\beta \\partial_i v_\\alpha - g^{\\alpha j} v_j \\partial_i v_\\alpha  & = - \\partial_i p^{\\prime}", block: true)



#tao-math("D_t v_\\beta  & = 0", block: true)



#tao-math("u^j  & = g^{ij} v_i + g^{\\alpha j} v_\\alpha", block: true)



#tao-math("\\partial_i u^i  & = 0.", block: true)
]

#text("We can reverse the pressure modification by writing")

#align(center)[#tao-fit-display[#mitex("p := p^{\\prime} - \\frac{1}{2} g^{jk} v_j v_k - g^{\\alpha j} v_j v_\\alpha - \\frac{1}{2} g^{\\alpha \\beta} v_\\alpha v_\\beta,")]]

#text("to move some derivatives off of the covelocity fields and onto the metric, so that the system now becomes ")#metadata(none) <tao-7b02047a7e8380830bee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("D_t v_i + \\frac{1}{2} v_k v_j \\partial_i g^{jk} + v_j v_\\alpha \\partial_i g^{j\\alpha} + \\frac{1}{2} v_\\alpha v_\\beta \\partial_i g^{\\alpha \\beta} = - \\partial_i p")]]

#metadata(none) <tao-93acb0bde1db3c5483e5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("D_t v_\\beta = 0")]]

#metadata(none) <tao-07e0eeedc75c851a6ee4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("u^j = g^{ij} v_i + g^{\\alpha j} v_\\alpha")]]

#metadata(none) <tao-a3817fabb5b840b8d997>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("\\partial_i u^i = 0.")]]

#text("At this point one can specialise to various special cases to obtain some possibly simpler dynamics. For instance, one could set ")#mi("{M_2}")#text(" to be flat (so that ")#mi("{g^{\\alpha \\beta}}")#text(" is constant), and set ")#mi("{v_i}")#text(" and ")#mi("{p}")#text(" to both vanish, then we obtain the simple-looking (but somewhat overdetermined) system")

#tao-aligned(keep: true)[


#tao-math("D_t v_\\beta  & = 0", block: true)



#tao-math("u^j  & = g^{\\alpha j} v_\\alpha", block: true)



#tao-math("\\partial_i u^i  & = 0.", block: true)
]

#text("This is basically the system I worked with in ")#link("https://terrytao.wordpress.com/2017/07/25/on-the-universality-of-the-incompressible-euler-equation-on-compact-manifolds/")[#text("my previous paper")]#text(". For instance, one could set one of the components of ")#mi("{v_\\alpha}")#text(", say ")#mi("{v_\\zeta}")#text(" to be identically ")#mi("{1}")#text(", and ")#mi("{g^{\\zeta j}}")#text(" to be an arbitrary divergence-free vector field for that component, then ")#mi("{u^j = g^{\\zeta j}}")#text(", and all the other components ")#mi("{v_\\beta}")#text(" of ")#mi("{v}")#text(" are transported by this static velocity field, leading for instance to exponential growth of vorticity if ")#mi("{g^{\\zeta j}}")#text(" has a hyperbolic fixed point and the initial data of the components of ")#mi("{v}")#text(" other than ")#mi("{v_\\alpha}")#text(" are generic. (Alas, I was not able to modify this example to obtain something more dramatic than exponential growth, such as finite time blowup.)")

#text("Alternatively, one can set ")#mi("{g^{j\\alpha}}")#text(" to vanish, leaving one with ")#metadata(none) <tao-21cc7f7d455c69650143>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("D_t v_i + \\frac{1}{2} v_k v_j \\partial_i g^{jk} + \\frac{1}{2} v_\\alpha v_\\beta \\partial_i g^{\\alpha \\beta} = - \\partial_i p.")]]

#metadata(none) <tao-0e6d468aabbb60e643d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("D_t v_\\beta = 0")]]

#metadata(none) <tao-b26277df51b7eb02d407>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("u^j = g^{ij} v_i")]]

#metadata(none) <tao-717e78dabbe4172410bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("\\partial_i u^i = 0.")]]

#text("If ")#mi("{M_2}")#text(" consists of a single coordinate ")#mi("{\\zeta}")#text(", then on setting ")#mi("{\\rho := \\frac{1}{2} v_\\zeta^2}")#text(", this simplifies to")

#tao-aligned(keep: true)[


#tao-math("D_t v_i + \\frac{1}{2} v_k v_j \\partial_i g^{jk}  & = - \\partial_i p - \\rho \\partial_i g^{\\zeta\\zeta}", block: true)



#tao-math("D_t \\rho  & = 0", block: true)



#tao-math("u^j  & = g^{ij} v_i", block: true)



#tao-math("\\partial_i u^i  & = 0.", block: true)
]

#text("If we take ")#mi("{M_1}")#text(" to be ")#mi("{{\\bf R} \\times {\\bf R}^+}")#text(" with the Euclidean metric ")#mi("{g^{ij}}")#text(", and set ")#mi("{g^{\\zeta\\zeta} = y}")#text(" (so that ")#mi("{M}")#text(" has the metric ")#link(<tao-5b82f0ed7ad205f5b574>)[#text("(17)")]#text("), then one obtains the Boussinesq system ")#link(<tao-4d2d1dfcb8d03bc60bce>)[#text("(1)")]#text("–")#link(<tao-4438ca09da7d7bb2704d>)[#text("(3)")]#text(", giving the claimed embedding.")

#text("Now we perform a similar analysis for the axially symmetric Euler equations. The cylindrical coordinate system ")#mi("{(z,r,\\theta)}")#text(" is slightly inconvenient to work with because the volume form ")#mi("{r\\ dz dr d\\theta}")#text(" is not Euclidean. We therefore introduce ")#link("http://www.ams.org/mathscinet-getitem?mr=977488")[#text("Turkington coordinates")]

#align(center)[#tao-fit-display[#mitex("(x,y,\\zeta) := (z,r^2/2,\\theta)")]]

#text("to rewrite the metric ")#mi("{dz^2 + dr^2 + r^2 d\\theta^2}")#text(" as")

#align(center)[#tao-fit-display[#mitex("dx^2 + \\frac{1}{2y} dy^2 + 2y d\\zeta^2")]]

#text("so that the volume form ")#mi("{dx dy d\\zeta}")#text(" is now Euclidean, and the Euler equations become ")#link(<tao-3c44c3e1b8b784478672>)[#text("(14)")]#text("–")#link(<tao-27278643264601c818c2>)[#text("(16)")]#text(". Splitting as before, with ")#mi("{M_1}")#text(" being the two-dimensional manifold parameterised by ")#mi("{x,y}")#text(", and ")#mi("{M_2}")#text(" the one-dimensional manifold parameterised by ")#mi("{\\zeta}")#text(", the symmetry reduction ")#link(<tao-339efeab70b4cc6e2755>)[#text("(18)")]#text("–")#link(<tao-519a87309f69dd643823>)[#text("(21)")]#text(" gives us ")#link(<tao-21cc7f7d455c69650143>)[#text("(26)")]#text("–")#link(<tao-717e78dabbe4172410bc>)[#text("(29)")]#text(" as before. Explicitly, one has")

#tao-aligned(keep: true)[


#tao-math("D_t v_x  & = - \\partial_x p", block: true)



#tao-math("D_t v_y + v_y^2 - \\frac{1}{4y^2} v_\\zeta^2  & = - \\partial_y p", block: true)



#tao-math("D_t v_\\zeta  & = 0", block: true)



#tao-math("u^x  & = v_x; u^y = 2y v_y", block: true)



#tao-math("\\partial_x u^x + \\partial_y u^y  & = 0.", block: true)
]

#text("Setting ")#mi("{\\omega := \\partial_x v_y - \\partial_y v_x}")#text(" to eliminate the pressure ")#mi("{p}")#text(", we obtain")

#tao-aligned(keep: true)[


#tao-math("D_t \\omega  & = \\frac{1}{4y^2} \\partial_x (v_\\zeta^2)", block: true)



#tao-math("D_t v_\\zeta  & = 0", block: true)



#tao-math("\\omega  & := \\partial_x(\\frac{1}{2y} u^y) - \\partial_y u^x", block: true)



#tao-math("\\partial_x u^x + \\partial_y u^y  & = 0.", block: true)
]

#text("Since ")#mi("{u^y = r u^r}")#text(", ")#mi("{u^x = u^z}")#text(", ")#mi("{\\partial_x = \\partial_z}")#text(", ")#mi("{\\partial_y = \\frac{1}{r} \\partial_r}")#text(", and ")#mi("{\\rho = v_\\zeta^2}")#text(", we obtain the system ")#link(<tao-ca0417d59595abfa7a19>)[#text("(5)")]#text("–")#link(<tao-bf6fff9974460c845262>)[#text("(8)")]#text(".")

#text("Returning to the general form of ")#link(<tao-7b02047a7e8380830bee>)[#text("(22)")]#text("–")#link(<tao-a3817fabb5b840b8d997>)[#text("(25)")]#text(", one can obtain an interesting transformation of this system by writing ")#mi("{g_{ij}}")#text(" for the inverse of ")#mi("{g^{ij}}")#text(" (caution: in general, this is ")#emph[#text("not")]#text(" the restriction of the original metric on ")#mi("{M}")#text(" to ")#mi("{M_1}")#text("), and define the modified covelocity")

#align(center)[#tao-fit-display[#mitex("\\tilde v_i := g_{ij} u^j = v_i + g_{ij} g^{j\\alpha} v_\\alpha,")]]

#text("then by the Leibniz rule")

#tao-aligned(keep: true)[


#tao-math("D_t \\tilde v_i  & = D_t v_i + v_\\alpha D_t (g_{ij} g^{j\\alpha})", block: true)



#tao-math(" & = - \\frac{1}{2} v_k v_j \\partial_i g^{jk} - v_j v_\\alpha \\partial_i g^{j\\alpha} - v_\\alpha v_\\beta \\frac{1}{2} \\partial_i g^{\\alpha \\beta} - \\partial_i p^{\\prime}", block: true)



#tao-math(" & + v_\\alpha u^k \\partial_k( g_{ij} g^{j\\alpha} )", block: true)
]

#text("Replacing the covelocity with the modified covelocity, this becomes")

#tao-aligned(keep: true)[


#tao-math(" & = - \\frac{1}{2} \\tilde v_k \\tilde v_j \\partial_i g^{jk} + \\tilde v_k g_{jl} g^{l\\alpha} v_\\alpha \\partial_i g^{jk} - \\frac{1}{2} g_{km} g^{m\\beta} v_\\beta g_{jl} g^{l\\alpha} v_\\alpha \\partial_i g^{jk}", block: true)



#tao-math(" & - \\tilde v_j v_\\alpha \\partial_i g^{j\\alpha} + g_{jl} g^{l \\beta} v_\\alpha v_\\beta \\partial_i g^{j\\alpha} - v_\\alpha v_\\beta \\frac{1}{2} \\partial_i g^{\\alpha \\beta} - \\partial_i p", block: true)



#tao-math(" & + v_\\alpha u^k \\partial_k( g_{ij} g^{j\\alpha} ).", block: true)
]

#text("We thus have the system")

#tao-aligned(keep: true)[


#tao-math("D_t \\tilde v_i + \\frac{1}{2} \\tilde v_k \\tilde v_j \\partial_i g^{jk}  & = - \\partial_i p^{\\prime} + R_i^{j\\alpha} \\tilde v_j v_\\alpha + S_i^{\\alpha \\beta} v_\\alpha v_\\beta", block: true)



#tao-math("D_t v_\\alpha  & = 0", block: true)



#tao-math("u^i  & = g^{ij} \\tilde v_j", block: true)



#tao-math("\\partial_i u^i  & = 0", block: true)
]

#text("where")

#tao-aligned(keep: true)[


#tao-math("R_i^{j\\alpha}  & := g_{kl} g^{l\\alpha} \\partial_i g^{jk} - \\partial_i g^{j\\alpha} + g^{jk} \\partial_k( g_{il} g^{l\\alpha} )", block: true)



#tao-math(" & = g^{jk} (\\partial_k (g^{l\\alpha} g_{il}) - \\partial_i(g^{l\\alpha} g_{kl}))", block: true)



#tao-math("S_i^{\\alpha \\beta}  & := -\\frac{1}{2} g_{km} g^{m\\beta} g_{jl} g^{l\\alpha} \\partial_i g^{jk} + g_{jl} g^{l\\beta} \\partial_i g^{j\\alpha} - \\frac{1}{2} \\partial_i g^{\\alpha\\beta} = \\frac{1}{2} \\partial_i (g^{m\\beta} g^{l\\alpha} g_{ml} - g^{\\alpha \\beta})", block: true)
]

#text("and so if one writes")

#tao-aligned(keep: true)[


#tao-math("p^{\\prime}  & := p + \\frac{1}{2} \\tilde v_k \\tilde v_j g^{jk}", block: true)



#tao-math("\\theta^\\alpha_i  & := g^{l\\alpha} g_{il}", block: true)



#tao-math("\\omega^\\alpha_{ki}  & := \\partial_k \\theta^\\alpha_i - \\partial_i \\theta^\\alpha_k", block: true)



#tao-math("F^{\\alpha \\beta}  & := \\frac{1}{2} (g^{\\alpha \\beta} - g^{m\\beta} g^{l\\alpha} g_{ml})", block: true)
]

#text("we obtain")

#tao-aligned(keep: true)[


#tao-math("D_t \\tilde v_i - u^j \\partial_i \\tilde v_j  & = - \\partial_i p^{\\prime} + u^k v_\\alpha \\omega^\\alpha_{ki} - v_\\alpha v_\\beta \\partial_i F^{\\alpha \\beta}", block: true)



#tao-math("D_t v_\\alpha  & = 0", block: true)



#tao-math("u^i  & = g^{ij} \\tilde v_j", block: true)



#tao-math("\\partial_i u^i  & = 0.", block: true)
]

#text("For each ")#mi("{\\alpha,\\beta}")#text(", we can specify ")#mi("{F^{\\alpha\\beta}}")#text(" as an arbitrary smooth function of space (it has to be positive definite to keep the manifold ")#mi("{M}")#text(" Riemannian, but one can add an arbitrary constant to delete this constraint), and ")#mi("{\\omega^\\alpha_{ki}}")#text(" as an arbitrary time-independent exact ")#mi("{2}")#text("-form. Thus we obtain an incompressible Euler system with two new forcing terms, one term ")#mi("{v_\\alpha v_\\beta \\partial_i F^{\\alpha \\beta}}")#text(" coming from passive scalars ")#mi("{v_\\alpha, v_\\beta}")#text(", and another term ")#mi("{u^k v_\\alpha \\omega^\\alpha_{ki}}")#text(" that sets up some rotation between the components ")#mi("{\\tilde v_i}")#text(", with the rotation speed determined by a passive scalar ")#mi("{v_\\alpha}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" As a sanity check, one can observe that one still has conservation of the kinetic energy, which is equal to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int g^{jk} v_j v_k + 2 g^{j\\alpha} v_j v_\\alpha + g^{\\alpha \\beta} v_\\alpha v_\\beta")]]

#text("and can be expressed in terms of ")#mi("{u^j}")#text(" and ")#mi("{v_\\alpha}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int g_{jk} u^j u^k + v_\\alpha v_\\beta (g^{\\alpha \\beta} - g^{j\\alpha} g^{k\\beta} g_{jk})")]]

#align(center)[#tao-fit-display[#mitex("= \\int u^j \\tilde v_j + 2 v_\\alpha v_\\beta F^{\\alpha \\beta}.")]]

#text("One can check this is conserved by the above system (mainly due to the antisymmetry of ")#mi("{\\omega}")#text(").")
]

#text("As one special case of this system, one can work with a one-dimensional fibre manifold ")#mi("{M_2}")#text(", and set ")#mi("{v_\\zeta=1}")#text(" and ")#mi("{F^{\\zeta\\zeta}=0}")#text(" for the single coordinate ")#mi("{\\zeta}")#text(" of this manifold. This leads to the system")

#tao-aligned(keep: true)[


#tao-math("D_t \\tilde v_i - u^j \\partial_i \\tilde v_j  & = - \\partial_i p^{\\prime} + u^k \\omega_{ki}", block: true)



#tao-math("u^i  & = g^{ij} \\tilde v_j", block: true)



#tao-math("\\partial_i u^i  & = 0.", block: true)
]

#text("where ")#mi("{\\omega_{ki}}")#text(" is some smooth time-independent exact ")#mi("{2}")#text("-form that one is free to specify. This resembles an Euler equation in the presence of a “magnetic field” that rotates the velocity of the fluid. I am currently experimenting with trying to use this to force some sort of blowup, though I have not succeeded so far (one would obviously have to use the pressure term at some point, for if the pressure vanished then one could keep things bounded using the method of characteristics).")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13e01e67b31aae381cb174b5d546557a8b0c532fd10df9d5ed4bf78719a6625f-e781006f11f27399154967ee6bed59c50636dd4054f10d8c03ddfc1e45471767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aula")]], [#link("https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/#comment-489941")[#strong[#text("Aula")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2017")])]

#text("On the third line above Remark 1, “conming from” should probably be “coming from”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/#comment-489942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2017")])]

#text("There are several systematic methods to check for equivalence (under suitable coordinate transformation) between two given systems of nonlinear PDE’s (using e.g. Cartan’s equivalence method or differential algebra methods) which were already implemented (since the 90′) by some symbolic software programs (e.g. MAPLE or MATHEMATICA).")#linebreak()#text(" Moreover, such systems can be reduced (automatically) to standard form with determination of the dimension of their solution space and the Taylor series solution – see e.g. Reid’s paper in Euro J. Appl. Math. 2(1991), 293-318.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/#comment-489972")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2017")])]

#text("It seems that if the solution space of the PDE system turns out to be (locally) real analytic with finite dimension, it should restrict (by analytic continuation) the initial data to be finite dimensional as well (i.e. to be described by finitely many parameters!)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0548ef592392a7f99d29599825e59cc44bd25a3b9f057e56f2de89ffc14c655f-37362dec2d60d3ea30ebd58c32fe6872603491a279e76af5dfa835f5231e0f41.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/#comment-490017")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("The covelocity formulation is very interesting because the Christoffel symbols does not appear explicitely. From an engineer perspective, this is a very interesting property. I would be interested to learn more about this formulation and its applications. Any reference would be greatly appreciated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d124007d2de6148d14903db2bb99935bead41cf80c8cc96b55fc4552f34831c-5eeb3eab01bf20cbdfe67ed70c194fe87536a9fd478b9308b79bb68243654663.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2017/12/14/embedding-the-boussinesq-equations-in-the-incompressible-euler-equations-on-a-manifold/#comment-491846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")])]

#text("The Wikipedia link at the beginning of the article goes to the water wave Boussinesq equations, rather than the buoyancy Boussinesq equations, which are ")#link("https://en.wikipedia.org/wiki/Boussinesq_approximation_(buoyancy)")[#text("here")]#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
