// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/
// Converted to Typst by tao2typ: "2026-10-14T15:21:09.089690+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Equational Theories Project: Advancing Collaborative Mathematical Research at Scale", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Equational Theories Project: Advancing Collaborative Mathematical Research at Scale")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 December 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/")[#text("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Matthew Bolan, Joachim Breitner, Jose Brox, Nicholas Carlini, Mario Carneiro, Floris van Doorn, Martin Dvorak, Andrés Goens, Aaron Hill, Harald Husum, Hernán Ibarra Mejia, Zoltan Kocsis, Bruno Le Floch, Amir Livne Bar-on, Lorenzo Luccioli, Douglas McNeil, Alex Meiburg, Pietro Monticone, Pace P. Nielsen, Emmanuel Osalotioman Osazuwa, Giovanni Paolini, Marco Petracci, Bernhard Reinke, David Renshaw, Marcus Rossel, Cody Roux, Jérémy Scanvic, Shreyas Srinivas, Anand Rao Tadipatri, Vlad Tsyrklevich, Fernando Vaquerizo-Villar, Daniel Weber, Fan Zheng, and I have just uploaded to the arXiv our preprint ")#link("https://arxiv.org/abs/2512.07087")[#text("The Equational Theories Project: Advancing Collaborative Mathematical Research at Scale")]#text(". This is the final report for the ")#link("https://github.com/teorth/equational_theories")[#text("Equational Theories Project")]#text(", which was proposed in ")#link("https://terrytao.wordpress.com/2024/09/25/a-pilot-project-in-universal-algebra-to-explore-new-ways-to-collaborate-and-use-machine-assistance/")[#text("this blog post")]#text(" and also showcased in ")#link("https://terrytao.wordpress.com/2024/10/12/the-equational-theories-project-a-brief-tour/")[#text("this subsequent blog post")]#text(". The aim of this project was to see whether one could collaboratively achieve a large-scale systematic exploration of a mathematical space, which in this case was the implication graph between 4694 equational laws of magmas. A ")#link("https://en.wikipedia.org/wiki/Magma_(algebra)")[#text("magma")]#text(" is a set ")#mi("{G}")#text(" equipped with a binary operation ")#mi("{\\diamond: G \\times G \\rightarrow G}")#text(" (or, equivalently, a ")#mi("{G \\times G}")#text(" multiplication table). An equational law is an equation involving this operation and a number of indeterminate variables. Some examples of equational laws, together with the number that we assigned to that law, include")

#list(
[#mi("{E1}")#text(" (Trivial law): ")#mi("{x = x}")],
[#mi("{E2}")#text(" (Singleton law): ")#mi("{x = y}")],
[#mi("{E43}")#text(" (Commutative law): ")#mi("{x \\diamond y = y \\diamond x}")],
[#mi("{E168}")#text(" (")#link("https://en.wikipedia.org/wiki/Central_groupoid")[#text("Central groupoid law")]#text("): ")#mi("{x = (y \\diamond x) \\diamond (x \\diamond z)}")],
[#mi("{E4512}")#text(" (Associative law): ")#mi("{x \\diamond (y \\diamond z) = (x \\diamond y) \\diamond z}")]
)

#text("Up to relabeling and symmetry, there turn out to be 4694 equational laws that involve at most four invocations of the magma operation ")#mi("{\\diamond}")#text("; one can explore them in our “")#link("https://teorth.github.io/equational_theories/implications/")[#text("Equation Explorer")]#text("” tool.")

#text("The aim of the project was to work out which of these laws imply which others. For instance, all laws imply the trivial law ")#mi("{E1}")#text(", and conversely the singleton law ")#mi("{E2}")#text(" implies all the others. On the other hand, the commutative law ")#mi("{E43}")#text(" does not imply the associative law ")#mi("{E4512}")#text(" (because there exist magmas that are commutative but not associative), nor is the converse true. All in all, there are ")#mi("{22,028,942}")#text(" implications of this type to settle; most of these are relatively easy and could be resolved in a matter of minutes by an expert in college-level algebra, but prior to this project, it was impractical to actually do so in a manner that could be feasibly verified. Also, this problem is known to become undecidable for sufficiently long equational laws. Nevertheless, we were able to resolve all the implications informally after two months, and have them completely formalized in Lean after a further five months.")

#text("After a rather hectic setup process (documented in ")#link("https://github.com/teorth/equational_theories/wiki/Terence-Tao's-personal-log")[#text("this personal log")]#text("), progress came in various waves. Initially, huge swathes of implications could be resolved first by very simple-minded techniques, such as brute-force searching all small finite magmas to refute implications; then, automated theorem provers such as Vampire or Mace4 / Prover9 were deployed to handle a large fraction of the remainder. A few equations had existing literature that allowed for many implications involving them to be determined. This left a core of just under a thousand implications that did not fall to any of the “cheap” methods, and which occupied the bulk of the efforts of the project. As it turns out, all of the remaining implications were negative; the difficulty was to construct explicit magmas that obeyed one law but not another. To do this, we discovered a number of general constructions of magmas that were effective at this task. For instance:")

#list(
[#text("Linear models, in which the carrier ")#mi("{G}")#text(" was a (commutative or noncommutative) ring and the magma operation took the form ")#mi("{x \\diamond y = ax + by}")#text(" for some coefficients ")#mi("{a,b}")#text(", turned out to resolve many cases.")],
[#text("We discovered a new invariant of an equational law, which we call the “")#link("https://teorth.github.io/equational_theories/blueprint/weak-central-groupoids-chapter.html#twist-sec")[#text("twisting semigroup")]#text("” of that law, which also allowed us to construct further examples of magmas that obeyed one law ")#mi("{E}")#text(" but not another ")#mi("{E^{\\prime}}")#text(", by starting with a base magma ")#mi("{M}")#text(" that obeyed both laws, taking a Cartesian power ")#mi("{M^n}")#text(" of that magma, and then “twisting” the magma operation by certain permutations of ")#mi("{\\{1,\\dots,n\\}}")#text(" designed to preserve ")#mi("{E}")#text(" but not ")#mi("{E^{\\prime}}")#text(".")],
[#text("We developed a theory of “abelian magma extensions”, similar to the notion of an abelian extension of a group, which allowed us to flexibly build new magmas out of old ones in a manner controlled by a certain “")#link("https://teorth.github.io/equational_theories/blueprint/cohomology-chapter.html")[#text("magma cohomology group")]#text(" ")#mi("{H^1_E(G,M)}")#text("” which were tractable to compute, and again gave ways to construct magmas that obeyed one law ")#mi("{E}")#text(" but not another ")#mi("{E^{\\prime}}")#text(".")],
[#link("https://teorth.github.io/equational_theories/blueprint/infinite-magma-constructions-chapter.html#greedy-section")[#text("Greedy methods")]#text(", in which one fills out an infinite multiplication table in a greedy manner (somewhat akin to naively solving a Sudoku puzzle), subject to some rules designed to avoid collisions and maintain a law ")#mi("{E}")#text(", as well as some seed entries designed to enforce a counterexample to a separate law ")#mi("{E^{\\prime}}")#text(". Despite the apparent complexity of this method, it can be automated in a manner that allowed for many outstanding implications to be refuted.")],
[#text("Smarter ways to utilize automated theorem provers, such as strategically adding in additional axioms to the magma to help narrow the search space, were developed over the course of the project.")]
)

#text("Even after applying all these general techniques, though, there were about a dozen particularly difficult implications that resisted even these more powerful methods. Several ad hoc constructions were needed in order to understand the behavior of magmas obeying such equations as ")#link("https://teorth.github.io/equational_theories/blueprint/854-chapter.html")[#text("E854")]#text(", ")#link("https://teorth.github.io/equational_theories/blueprint/906-chapter.html")[#text("E906")]#text(", ")#link("https://teorth.github.io/equational_theories/blueprint/1323-chapter.html")[#text("E1323")]#text(", ")#link("https://teorth.github.io/equational_theories/blueprint/1516-chapter.html")[#text("E1516")]#text(", and ")#link("https://teorth.github.io/equational_theories/blueprint/1729-chapter.html")[#text("E1729")]#text(", with the latter taking months of effort to finally solve and then formalize.")

#text("A variety of GUI interfaces were also developed to facilitate the collaboration (most notably the Equation Explorer tool mentioned above), and several side projects were also created within the project, such as the exploration of the implication graph when the magma was also restricted to be finite. In this case, we resolved all of the ")#mi("{22,028,942}")#text(" implications except for one (and its dual):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 1")]#text(" Does the law ")#mi("{x = y \\diamond (x \\diamond ((y \\diamond x) \\diamond y))}")#text(" (E677) imply the law ")#mi("{x = ((x \\diamond x) \\diamond x) \\diamond x}")#text(" (E255) for finite magmas?")
]

#text("See ")#link("https://teorth.github.io/equational_theories/blueprint/677-chapter.html")[#text("this blueprint page")]#text(" for some partial results on this problem, which we were unable to resolve even after months of effort.")

#text("Interestingly, modern AI tools did not play a major role in this project (but it was largely completed in 2024, before the most recent advanced models became available); while they could resolve many implications, the older “good old-fashioned AI” of automated theorem provers were far cheaper to run and already handled the overwhelming majority of the implications that the advanced AI tools could. But I could imagine that such tools would play a more prominent role in future similar projects.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70d68edaf1b08f310886b89f27f77459c80d00e7e66f95d1d949724f6aed20f4-169737cd43f66f0dc8e17d4cc5f25a93edc6616f77e278f9a1f0943afd7ac9ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Dietz")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689292")[#strong[#text("Paul Dietz")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Do you mean Mace4 or Prover9? I can’t find a Mace9.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("such equations as […], and E1729, with the latter taking months of effort to finally solve and then formalize.")
]

#text("That number seems to be rather a dull one; apparently it was an unfavourable omen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689299")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Typo in the “basic theory” of the blueprint, Definition 1.7 and Theorem 1.8: syntactic implication is usually denoted ")#mi("vdash")#text(", to distinguish it from the semantic implication ")#mi("models")#text(" of Definition 1.6. As written Theorem 1.8 is a tautology.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3529ef3432f19f545244ebd5f1dcf2e0c12c9d7a202f84575075a8a6a8f28b46-4e0415730b98015d10729ff930abd4ed7e2d3b9eb85d1d109c12918dde1913bc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JoseBrox")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689302")[#strong[#text("JoseBrox")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Two typos: There are not 4684, but 4694 laws. Also, Conjecture 1 is actually formulated as an open question.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689306")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Wait, did you resolve all or all except for one? The blog post says the latter but the arxiv abstract says the former.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689307")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Without the restriction that magmas are finite, we resolved all implications. When restricting attention to finite magmas only, we resolved all but one (and its dual).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689309")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#text("Excellent! For the greedy method intercept.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Such a nice project, congratulations to all of you, and thanks.")

#text("Last year a ")#link("https://www.quantamagazine.org/amateur-mathematicians-find-fifth-busy-beaver-turing-machine-20240702")[#text("collaborative effort")]#text(" could prove the exact value for BusyBeaver(5), and I wonder what would it take to have more projects like this. It seems that only a very specific type of propositions could be crowd-researched, but what is your feeling? Are there other natural places to define projects like this?")

#text("The Erdos open problems also come to my mind, in the sense that the listing of the problems and space for comments for people to communicate is what made the problem be solved quickly (as you said in previous post). Is there a low hanging fruit here by trying to list conjectures and open problems? Is the “gamification” of completing a list something that can be used for making more people collaborating?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("In Section 14 of our report we identify some factors which we believe were key to allowing our project to be successful. I do believe that there will be other projects that fulfil these criteria, but some trial and error will need to be done to work out some further models of this type, since until recently the technology did not permit this type of collaboration at scale and so we have very few working models. But there are some: I recently started an effort to collect examples at ")#link("https://mathoverflow.net/questions/500720/list-of-crowdsourced-math-projects-actively-seeking-participants")[#text("https://mathoverflow.net/questions/500720/list-of-crowdsourced-math-projects-actively-seeking-participants")]#linebreak()#text(" At IPAM I am in the beginning phases of launching another crowdsourced project (see ")#link("https://www.ipam.ucla.edu/news-research/special-projects/integrated-explicit-analytic-number-theory-network/")[#text("https://www.ipam.ucla.edu/news-research/special-projects/integrated-explicit-analytic-number-theory-network/")]#text(" ): stay tuned!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2012b6135b45cac63d35b9bd8c81bf95cb591596b76c826fa2a4adf0049718d2-3b843ddfe0611b39de10e584527432998e3ef7958bfbccc9faa356ef89b70d42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Pezzi")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689314")[#strong[#text("Daniel Pezzi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Is this article submitted for publication? I am not sure what the standards are for review of 1) a large scale collaborative project and 2) something formalized so heavily. Are there journals that specifically handle papers like this, or is the scale collaboration itself a type of review?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("We are just ")#link("https://leanprover.zulipchat.com/#narrow/channel/458659-Equational/topic/Submitting.20the.20paper/with/562714994")[#text("restarting a discussion")]#text(" on this on our project channel. (We had ")#link("https://leanprover.zulipchat.com/#narrow/channel/458659-Equational/topic/Writing.20the.20paper/near/533228561")[#text("some earlier discussion and a straw poll")]#text(" a few months ago on this topic, but it was inconclusive.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Webspinner")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689326")[#strong[#text("Webspinner")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("While I do not have significant hopes of this comment not getting redacted, I would like to mention that while I do think the collaborative approach is all well and good if you feel well doing this sort of thing, it is no sense to persecute those who would solve problems on their own.")

#text("True inclusivity would imply that EVERY style of doing mathematics (and EVERY person doing so) is accepted.")

#text("All of this is particularly painful for those who do NOT hold a far-right opinion and find themselves in opposition both to the far-right and to people who falsely assume they belong to the far-right.")

#text("If anything has come out of the recent surge of far-right barbarism, it is though that I’m far less shy now voicing my opinion, because it does seem exceedingly moderate when compared to some positions that now enjoy the support of huge swaths of the population.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689332")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("What does this mean?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689335")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("Some problems lend themselves to large collaborations, and others do not. These large Polymath-esque collaborations do not make traditional math research obsolete. Mathematicians who do not join large collaborations are not persecuted.")

#text("As for your other comments, they do not seem relevant to the blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689331")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("Is it possible that problem 1 is undecidable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689337")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2025")])]

#text("Theoretically, yes; it is known that there exist implications between equational laws (either with or without the finiteness hypothesis) which are undecidable. I would be extremely surprised however if this particular problem was undecidable.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2025")])]

#text("If by “undecidable” you mean unprovable from the usual axioms of mathematics (like ZFC), then yes it is possible as Terry confirms.")

#text("If by “undecidable” you mean there is no computer program that will output the correct answer, then no. There is a trivial computer program that can output the correct answer; either the “print Yes” or “print No” algorithm.")

#text("Mathematicians usually refer to the first type of undecidability as “independent from X” where X is the given set of axioms. Undecidability of the second type is usually only discussed in contexts where some data is provided to a computer, and the answer can change depending on the data. So, for instance, the problem of giving to a computer two magma laws, and asking if the first implies the second for finite magmas, is undecidable in the second sense; there is NO single algorithm that will always give the correct answer when provided with the two laws.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-689397")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2025")])]

#text("One thing that struck me in the Equational Theories Project is how uneven implication feels in practice: some identities rigidify most models almost immediately, while others only weakly constrain behavior unless combined with additional laws.")

#text("I don’t have a universal notion in mind, but in settings with natural symmetry it seems plausible to normalize a measure of “alignment” between equational schemas: one that collapses to 1 in the implication case, but otherwise interpolates continuously rather than remaining binary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematics Distillation Challenge – Equational Theories | What's new")]], [#link("https://terrytao.wordpress.com/2025/12/09/the-equational-theories-project-advancing-collaborative-mathematical-research-at-scale/#comment-691981")[#strong[#text("Mathematics Distillation Challenge – Equational Theories | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2026")])]

#text("[…] either of these, but this sort of problem is difficult, and even undecidable in some cases; see this paper of the ETP collaborators for more discussion. Nevertheless, many of these problems can be settled with some effort by […]")
]
