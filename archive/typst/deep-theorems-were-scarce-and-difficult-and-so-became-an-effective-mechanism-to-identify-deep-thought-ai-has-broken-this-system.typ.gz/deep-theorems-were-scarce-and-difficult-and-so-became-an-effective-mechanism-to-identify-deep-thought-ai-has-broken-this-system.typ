// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/
// Converted to Typst by tao2typ: "2026-10-14T15:21:19.271165+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“Deep theorems were scarce and difficult and so became an effective mechanism to identify deep thought. AI has broken this system.”", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“Deep theorems were scarce and difficult and so became an effective mechanism to identify deep thought. AI has broken this system.”")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")[#text("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://sites.math.northwestern.edu/~kra/")[#text("Bryna Kra")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("For generations, mathematicians have treated the production of theorems as a clear measure of success. The stronger the theorem, the deeper the proof, the more surprising the connections, the greater the achievement. Positions and prizes are based on these theorems and the mathematicians making the breakthroughs set the directions for future research.")

#text("But theorem production was only part of what we cared about. It was a proxy for something harder to measure: understanding. A major breakthrough meant that years were invested in learning a subject and uncovering hidden aspects, accompanied by work to make the answer apparent to the community. Deep theorems were scarce and difficult and so became an effective mechanism to identify deep thought.")

#text("AI has broken this system.")

#text("Artificial intelligence has lowered the cost of producing sophisticated proofs. As the models improve, the list of deep conjectures that fall will grow. Someone with little knowledge in a field can now generate a manuscript that reads like a polished article, cites the literature, and combines techniques that would have taken years to master. The machines are producing solutions faster than the mathematical community can read them, much less digest them.")

#metadata(none) <tao-241e9838f9fd7dc9f903>

#text("This week the changes arrived in my field. The Nivat conjecture is a beautiful problem at the intersection of combinatorics and dynamical systems. Imagine an infinite grid of square tiles, with each tile colored either red or blue. Look at every rectangular window of a fixed size, say ")#mi("{n}")#text(" tiles wide and ")#mi("{m}")#text(" tiles high, and count how many different color patterns show up in that window. The conjecture says that if there are at most ")#mi("{nm}")#text(" such patterns, then the entire coloring repeats under some fixed, nonzero shift of the grid. In other words, some precise limit on local behavior gives rise to simple global behavior, periodicity.")

#text("Though this statement can be explained without formulas or higher mathematics, the conjecture resisted our efforts for nearly three decades.")

#text("In work that we first circulated in 2012, ")#link("https://arxiv.org/pdf/1208.4090")[#text("Van Cyr and I")]#text(" proved a partial result, showing that periodicity holds when the number of patterns is at most half the area of the window. We translated the combinatorial question into one about the geometry of dynamical systems, studying ways in which information in the system does (or does not) propagate. Progress on challenging problems does not happen in a vacuum, and our work began by studying and building on earlier results in the literature [")#link("https://www.sciencedirect.com/science/article/pii/S0304397501003863")[#text("1")]#text(", ")#link("https://www.sciencedirect.com/science/article/pii/S030439750100281X")[#text("2")]#text(", ")#link("https://www.sciencedirect.com/science/article/pii/S0304397504001033")[#text("3")]#text("]. Soon after, ")#link("https://arxiv.org/pdf/1605.05929")[#text("Jarkko Kari and Michal Szabados")]#text(" developed a different approach, viewing the combinatorial question as an algebraic object, using certain types of polynomials to find the infinite patterns.")

#text("To those of us who worked in the area, this was a tantalizing situation. Two different methods to approach the same problem seemed to shout to us: find the conceptual bridge between them. We tried, without success, and moved on to other problems. Colleagues continued pushing the boundaries of what we knew, combining the varied techniques in increasingly powerful ways [")#link("https://arxiv.org/pdf/1710.05360")[#text("1")]#text(", ")#link("https://arxiv.org/pdf/1904.01267")[#text("2")]#text(", ")#link("https://arxiv.org/pdf/2606.10193")[#text("3")]#text("].")

#text("But synthesizing different approaches is one of the ways in which frontier models excel. A machine does not need years to absorb distinct areas of mathematics before it can find the connections. It can translate notation, compare partial results, and try thousands of combinations without being discouraged. ")#link("https://github.com/google-deepmind/formal-conjectures/issues/3907")[#text("The Nivat conjecture")]#text(" has been proposed for inclusion in Google DeepMind’s Formal Conjectures project, turning the problem into a target for automated reasoning and making more people aware of the question.")

#text("The manuscripts have started to arrive. This week I received several purported proofs of the full conjecture from researchers making their first foray into the subject. Some acknowledged using AI, but only for polishing the English or checking the proof. When I asked if the authors would meet over Zoom to explain their arguments, none accepted the invite.")

#text("Silence does not mean that the authors used AI and a proposed proof is not a theorem. But merely disclosing AI use and checking correctness of the proof, both of which are essential, miss the point. Suppose these results are correct. That is a mathematical contribution. Yet it opens more questions. What did we learn? What did the authors contribute? What impact will this result have?")

#text("A proof is more than a certificate that something is true. Instead, it is a story, a picture, an insight, an explanation. A proof highlights novel ideas and opens new directions for what we should ask next. It becomes part of the toolkit of the community. A deep theorem changes how we think, not because of its statement, but because of what it teaches us. As Bill Thurston wrote ")#link("https://mathoverflow.net/a/44213")[#text("on MathOverflow")]#text(" in a 2010 response to a question about what mathematicians do: “The product of mathematics is clarity and understanding. Not theorems, by themselves.”")

#text("These new texts certainly contain knowledge, just as a data file of bits of 0’s and 1’s contains information. But human authorship is more than the string of words that prove something. It is intellectual responsibility, understanding of a new concept, the ability to respond to questions, the sorting of new ideas from existing scaffolding. And perhaps most importantly, it is incorporating the result into the corpus of our understanding.")

#text("I welcome AI-generated proofs and believe that human-only proofs will become rare. This is a profound change of perspective, but mathematicians have always used external tools and machines. AI is already a powerful mathematical instrument and we, as a community, need to incorporate it responsibly into our practice of mathematics. The question is not if machines should participate in discovery. They already do. The question our community needs to address is what we value in our mathematics now that certain kinds of discovery are no longer a scarce resource.")

#text("The tradition of journals publishing novel results, hiring committees rewarding those publications, and prize committees recognizing the person who completed the result do not suffice. Peer review is a slow process that relies on the unpaid expertise of a small group of overworked researchers. Any single submission can be handled, but the current volume is drowning the reviewers. The careers of young researchers depend on producing theorems, with incentive to produce as much as possible as quickly as possible. The time for deep reflection, necessary for deep understanding, does not happen when someone types the question into a model and quickly produces a manuscript.")

#text("All of these issues existed before AI entered our field. Unfortunately, we no longer have the luxury of addressing them in a leisurely manner.")

#text("Mathematics is at a watershed moment. Our incentive structures are misaligned with the prolific output of highly accessible AI models. Careful verification and stellar exposition will not happen when there is no reward for those tasks. Producing a paper is no longer enough: authors must be able to explain the proof’s mechanism and how they arrived at this point. Journals need to distinguish and credit the roles of discovery, proof, formalization and explanation. Exposition must become an important component of any major intellectual achievement. We advance mathematics not by what we write, but by what we learn, check, apply, and teach others.")

#text("Finding the right concept, crafting the right definition, and formulating new questions have always been part of our intellectual work. The creation of collective understanding, the ability to communicate ideas in a lecture, and the sharing of ideas informally that spark research have always been admired. Such achievements are harder to quantify than theorem production, and so have been treated as by-products. But these are the key aspects shaping the future of our field and their value is at least as important as knocking down the next conjecture. Our incentive system needs to be realigned to reflect what we truly value, and not just what we can easily measure.")

#text("Mathematics is the canary in a coal mine for all parts of intellectual life. Its claims can be carefully checked and so we are witnessing the disruption in real time. But when AI disrupts the tried and tested standards in a field like mathematics, what will it do to fields where evidence and interpretation are more contested? Science, law, public policy, and art will all have to find ways to assess what is valuable amidst the abundant output.")

#text("The arrival of machine generated mathematics does not replace the role of human expertise. Instead it reveals why we valued that expertise. The goal of our discipline is not simply to resolve conjectures, but to enlarge our capacity to reason and open our minds to new ways of understanding. It will take our entire community to create new standards, discover new ways of creating mathematics, work with AI models to open new horizons of knowledge, and develop the tools to approach them. It’s truly an exciting time to be a mathematician.")

#heading(level: 1)[#text("Comments (36)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695165")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Moving from discussions to decisions, I think top journals need to come out uniformly and set a new expositional and conceptual standard for submissions. The truth is, mathematical exposition has never been particularly valued, and there have been many Fields medalists with a reputation for writing unintelligible papers. But there was always enough mathematicians who did the (often unthanked, uncompensated, and not considered for tenure) work of writing exposition articles, rewriting the literature in their own words for the sake of completeness, and general synthesizing material. But, if you solved Named Conjecture, you could submit a manuscript of subpar quality to a top journal and it would be readily accepted.")

#text("Most journals have a policy against fully AI generated manuscripts, but talk about valuing digestion and synthesis needs to be backed up by a change in the reward system which, at this point, is expressed primarily through journal publication. Papers with clearly AI generated text, even if the proofs are human in nature, or with confusing or unclear exposition should be rejected categorically. Referees should feel empowered to make decisions like this. In response, the quality of paper writing will increase. An Annals papers should communicate Annals level understanding, not just the proof of an Annals level result.")

#text("Before AI, the papers submitted to papers digested ratio was already off. We need to move to a model of less papers of higher quality, but this will only happen if the reward structures are changed. Quality of writing is not considered by hiring or promotion committees. This needs to change, and this change needs to happen quickly and loudly, or else we will drown in blog posts and open letters without anything of substance changing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695177")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Agree. Recently, I took the liberty of major-correcting a clearly AI generated paper because it was very hard to read. Correct result? maybe, but at some point I was fed up with it, why do I have to make effort on reading and understanding if the authors didn’t? No feedback to authors more than something like “rewrite the whole paper in a way that can be read by relatively competent human mathematicians”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("The journal system is one that I really think needs a massive change, and is one of the most unpleasant aspects of our current system. I would prefer to simply let the broken institution such as “top journals” die out rather than trying to salvage them.")

#text("Here is a thought experiment. Suppose an author rushes out AI generated slop (with a ton of mathematical insight) in order to claim their territory to write-up a more digested paper. Suppose another author sees this and quickly write up their own digestion, which is now human readable and has a lot of mathematical insight. The first author seeing this, also decides to rush out this digestion. Suppose further that a third author sees what’s going on and writes up a digestion quickly; all three have written up digestions within a few days and submit to a “top journal.” Which paper does the top journal publish?")

#text("Suppose now a fourth author takes much more time and writes up a digestion that is much better written and contains a bit more insight. Which one of these four papers do we decide to publish in the annals?")

#text("Oh, and what if one was submitted to Inventiones with an irresponsible editor and another submitted to the Annals with a more responsible editor? What if they were held to different standards among quick opinions? What if one editor cares about their article more than another theirs?")

#text("This all seems incredibly toxic, and I’d rather have the current journal system which is a relic of a time where we cared about obtaining a proof first die out.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695206")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I agree that “digestion” publishing system may not be easy to implement: if a problem on a topic is relatively well-known and expected, then any researcher in that area will want to try it on AI, resulting in many preprints solving the same problem. It is very likely that the obtained solutions will be very similar and “digestion” will not differ much from one researcher to another. Thus a journal may get many submissions with no significant difference in their content. How would they decide?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Similar feelings here: the new era (with digestive publishing) could be more toxic with many “rushed” papers appearing in bundles on the arxiv (or on the webpages) to claim “territory”. Then there may not be anything left to work on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695261")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Maybe we need a parallel system for AI-generated preprints called AIrchiv which can be a repository for AI generated papers, but which allows them to be in a silo separate from “professionally produced” work. Of course a vast quantity of the AI submissions will likely be worthless restatings of previously treated material, but it would allow for authors without credentials to contribute without mucking up the more “filtered” works in standard archiv. Then a deep well of AI data will be allowed to exist and this will create a competitive landscape between AI driven noob submissions and those of the professional mathematician class. Everything from a “history of science” perspective will then be transparent. Think of it as a Deep Blue vs. Kasparov situation, just between Polymaths and Autodidacts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32ef2758e4d90937522172f5870525f3f75e8e3f8f32c7282534c1a42abc6453-c45b953fe831d879029937f42d7fa559229430ef3e22ccc479011ff2b261dbb5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele Caselli")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695224")[#strong[#text("Michele Caselli")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I agree so much with this comment that I could have been the one writing it line for line, especially the last paragraph.")

#text("The system can change only after the incentives do, and this needs to happen at a very tangible/practical level. This summer we have seen a lot of talking and blog posts in our community, rightfully so, and I agree with a large percentage of them. But I hope this is backed by a yet-to-be-seen movement from people in positions of power in our community, aimed at changing the incentives at a tangible level.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695307")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Yikes. If we implemented this, then Bourgain would have left math and joined an AI company. His writing was absolutely terrible!")

#text("We need to reward asking interesting questions. Rewarding exposition so much would totally destroy the careers of great mathematicians who are terrible writers. Bourgain, Shelah, you name it. Do you really want that? I understand that no one wants to have to read badly AI-generated solutions, and I don’t, but this isn’t the solution.")

#text("I also don’t see any reason why AIs can’t improve in exposition in the future. I think they will.")

#text("What I really think we should be rewarding more is asking interesting questions. I want to see nice tantalizing conjectures at the end of Annals papers. Make some nice conjectures that current AI models cannot do.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695323")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("The writing appears to be on the wall for nice things we used to have like arxiv as well…")

#text("I would however somewhat disagree that if exposition was totally disvalued text like EGA wouldn’t be so legendary, perhaps thats a good segway into Emily Riehl’s take on this matter")

#text("The last controversy about a Clay Problem didn’t leave the community looking very good, hopefully it goes differently this time and voices like yours are listened too")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695169")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Although the title seems in the same vein as the defensive stance of the math community, the text itself isn’t and I think that’s good. AI solving problems isn’t bad as long as we continue asking more and more questions and seeking true understanding. It might actually help with that eg by producing counterexamples to overly naive conjectures. And the idea that good problems are scarce is just the admission that we are stuck or uninspired. Not a good thing to say. I would think there’s tons of great mathematics waiting to be discovered, and possibly getting rid of these “lighthouse” problems by solving them with AI will bring us faster to focus on these new mathematics. The letter by the 25 fields medallist is such a turn off!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695209")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("”And the idea that good problems are scarce is just the admission that we are stuck or uninspired. Not a good thing to say.”")

#list(
[#text("Idk if I’d agree in terms of talking about the collective “we”. I can go say far as saying that the incentive/power structure makes it hard to feel inspired for many. I feel more good can be done here (if still possible) by dissociating from the “we” that repeated in popular science articles, and start relearning it to mean “we” as in the community, our colleagues, friends, educators, online creators, organizers, math enthusiasts, etc.. people who have a relationship with math outside the “big problems” talked about in those articles.")]
)

#text("“I would think there’s tons of great mathematics waiting to be discovered, and possibly getting rid of these “lighthouse” problems by solving them with AI will bring us faster to focus on these new mathematics.”")

#list(
[#text("_Completely_ (to a painful degree) agree with the first part. However, I assume you meant that “AI will bring us faster to these new mathematics” in the sense of “getting rid of things we were stuck at so we can move on”. Here’s where I disagree. I would argue “MATHEMATICIANS will bring us faster to these new mathematics.” Just from….idk I guess from how much effort I (and others I know in the community) am going to put in this AI-filed world. So it’s possible I might end up looking like a _complete_ fool, but…I guess I wouldn’t know unless it was something huge that makes me take notice?")],
[#text("I would agree with this statement in terms of “AI being a tool for exposition of very technical topics from groups of a different cultures/lineages”. This is a great tool for tuning learning curves to your liking, and explore more math.")]
)

#text("I guess my goal with this reply (you use the word “we”, so I assume you’re a mathematician or at least a math enthusiast) is to shift the conversation from what “they” think is “good math” to what “we” think is the math we love. I understand the sentiment behind the comment, I would have left feeling the same if you hadn’t commented this. This is some kind of effort (with fleeting hope, I confess) to connect the community of people around the world whose relationship with math extends beyond awards and adulations. These things just don’t seem that fun anymore. Luckily math is _SO_ much more, and we get to explore _ANYTHING_ in the activity of “doing math” without tying it to (really questionable?) economic/financial/*marketing* strategies of a handful of people. Take care, and don’t let anyone make you forget why you fell in love with (or were at least drawn to) math.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695171")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("AI will force mathematics to move away from the overly formal proofs of the French Bourbaki style and instead focus on the ideas. For instance, with respect to the Navier-Stokes proof.")

#text("The proof has time running in reverse but keeps the idea of time moving forward from an initial condition to a final condition. The Millennium problem requires the initial velocity to be well-defined, smooth, and divergence-free. By reversing time, the singularity matches the final condition instead of the initial condition, and this is also forbidden if time is reversed.")

#text("Velocity is distance over time, x/t. At t = 0, velocity has a singularity with x/0 and is not defined. We cannot use this initial condition because it does not satisfy a smooth, well-defined initial velocity.")

#text("The AI uses the definition tau = (1-t) and describes it as a countdown to a singularity. Jean Leray first did this ‘trick’ in his foundational 1934 paper on fluid dynamics.")

#text("The infinitesimal dtau is the mirror opposite of regular time, dt. The infinitesimal dtau = -dt. As t increases, tau decreases. You can prove this by taking the time derivative of tau.")

#text("dTau/dt = (d/dt)(1-t) = -1")

#text("dtau/dt = -1")

#text("dtau = -dt")

#text("The Euler equations are time reversible. They are identical to the Navier-Stokes equations but have zero viscosity. Using dtau in Euler and ending with a blowup is identical to starting with a forbidden blowup as an initial condition, due to time symmetry. No proof of this type can ever prove that the velocity in Euler’s equations diverges.")

#text("Navier-Stokes has viscosity, so it is not time reversible. Energy dissipates; this is like entropy defining the arrow of time. The AI proof going backward in time does not equal a proof going forward in time. The two cannot be equal. If they were equal, we would be working with Euler’s equations, not Navier-Stokes.")

#text("The AI proof setting dtau = -dt over the chosen interval invalidates the proof of finite time blowup for both the Euler and Navier-Stokes equations.")

#text("Navier-Stokes has a symmetry due to Gauss, what goes in must come out and a conservation law due to Noether’s theorem.")

#text("Saying an area of infinitely small volume goes to infinite velocity as energy goes to zero is literally a proof that nothing travels at infinite speed. Similarly, L = I × ω, and I = mR^2; at zero radius, the angular momentum is zero. No mass density is traveling at an infinite speed. The ideas are still defined. There is no contradiction. Zero multiplied by infinity is zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695182")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("What makes you think that the AI’s won’t get better at exposition?")

#text("What has broken the system is not the AI’s. It is our inability to keep up with them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695204")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I could not understand (or rather recall) the concept of zero knowledge proofs reading a textbook, which otherwise looked quite interesting, just unpolished. A short session with LLM, which also allowed ne to ask focused questions, and to get immediately the answers, soon clarified the concept.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695216")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("We have structures to improve AI proofs a abilities (LEAN, for instance). In the current paradigm, what would infuse AI to improve its expository capacities? I don’t know.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c88719e1427244bb8b43e87a938060d45d5e169e2f5bf6749329dd661a56c6a1-5ae8301510366208050e9e7fa1442b13f6dbdb9acec30ca8dc16c1cafa3fa9e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thái Võ")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695184")[#strong[#text("Thái Võ")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("From a practical tool perspective, AI helps us immensely in solving technical problems and optimizing time. However, relying on AI to crack open-ended questions and profound mysteries of the world is deeply concerning.")

#text("​When humans use raw thought and inner struggle to decode reality, the solution possesses a pure, intrinsic beauty of true understanding. In contrast, the essence of AI is merely data aggregation, regurgitation, and pattern-matching. Depending on AI for fundamental breakthroughs is not just a technological over-reliance; it risks dragging science and mathematics into serious decline. When machines take the crown, humanity’s capacity for independent cognition will plummet")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/be3fc8a1bb9516778d62edaac093b8f6633f9bce4f896aac8e80c07249354be1-17eb75813185f6e088980e54589bc20369df7b46363a66653c6c15ec91f233e7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fabien Besnard")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695200")[#strong[#text("Fabien Besnard")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I very much agree with Bryna that the problems we’re facing with AI are not new, only more intense. For instance, in the past, the tools people used to do the hard technical stuff in their stead were called Ph. D. students.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695211")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("“")#linebreak()#text("I welcome AI-generated proofs and believe that human-only proofs will become rare.”")

#text("Rest in peace those of us who cannot afford those tools. It was a good run, I guess.")

#text("Sincerely,")

#text("a fallen postdoc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("(Just discovered Professor Kra’s post today, very nice, and since I was writing a similar piece with the next generation of mathematicians in mind, I thought I would just copy my draft here, it might add some elements to the discussion).")

#text("—-")

#text("There has been significant discussion recently regarding announced breakthroughs on the Navier-Stokes equation using artificial intelligence (AI) assisted methods; a collection of thoughts has been collected/linked on this blog, where most likely you are also going to find more relevant links in the future.")

#text("The rather heated debate in many posts is relatively unusual for mathematics and has led to uncertainty and even some fear in the younger generation whether this will be detrimental for the subject of mathematics and their careers. Let me first address all the students and let me ensure you: if you have decided to study mathematics, it is still one of the best available options, one of the most relevant and broadly applicable subjects, one of the most beautiful and rewarding subjects, and no one with a successful mathematics degree and dedication is going to have any worries regarding their careers. Don’t listen to unfounded fear-mongering, the situation is much more pleasant, I would even say especially bright, if you are in mathematics today.")

#text("But mathematics will change fundamentally, you may object. And you would be right! It will likely change for the better with the existence of AI in my opinion, as I shall explain below. Importantly, this does not exclude that there will the those who might try to generate commerical success and funnel it into their pockets in this change process. If there is money to be made from marketing stunts, the stunts will be made. If there is money to be made from generating headlines, it will be attempted. To the (hopefully) small minority who still feel that being a mathematician should be disconnected from the world beyond the discipline, you should have lately woken up already on many occasions. Science is not disconnected from the world around it, neither should it be, it should be an integral part. And within recent years, AI has undoutedly become part of our everyday lives already in many respects.")

#text("So what will change, and why seem parts of the mathematical community so surprised, or even deeply worried by recent events surrounding the announced Navier-Stokes solution? There could be many reasons but in my opinion, one primary reason could be the fear of loss of intellectual superiority in their field. And yes, the skill set will undoutedly change. Previous announcements that AI can solve international mathematical olympiad (IMO) problems to a top-level should have signalled this already clearly. In fact, once AI was strong enough to master the games of Chess, Go, Starcraft, and beyond, it should have been evident to every mathematician that the skill set will change.")

#text("Let us take chess as an example as it might be familiar to most of us. To become a master of chess and play at the absolute international world-leading level, just pure brilliance was never enough. You always had to practice hard, learn a lot of very repetitive openings at amazing depth, and be willing to train your brain on the specific pattern formation challenges that are presented in chess in different phases of the game. Today, top-level classical chess is completely different. You almost exclusively prepare with a computer running, and with the main intention to find interesting sidelines that are easy to play for a computer but quickly become difficult to judge for one of the human players. These are then the lines you play in tournaments. Fisher-random chess has gained popularity, so have shorter time control tournments. I would argue, this has changed chess for the better, it is more exciting, more interesting, more anchored in society, and more vibrant than ever.")

#text("In top-level mathematics, we will definitely see a very similar movement. So far, aiming for technical prowess learned by repetition of one or two particular techniques at remarkable depth basically led many researchers in pure mathematics to success, and out of this group, the ones with additional creative ideas have become leaders in their field. In the future, you will still need to be proficient at techniques, but the balance will significantly shift. Instead of absolutely mastering a technical tool in its full depth, you will rather have to learn how to creatively find new developments from it, or even better invent new tools and techniques altogether that are not present in any AI training data set. You will have to branch out into areas, where AI will not be of much help, e.g., in the communication and connection of mathematical ideas to scientists of other disciplines, in teaching and understanding the mathematics of AI itself, and in creating unknown fields far out of the available task of interpolation and completing current data. Even if your interests are in the latter, it is an interesting and challenging job to guide agents to complete interpolation processes. In fact, AI will free many areas of mathematics from sometimes quite ancient constraints and beliefs. This could well be interpreted as refreshing and rejuvenating. Scientists should embrace and shape the creative process involved in change in the world surrounding them, rather than condemn it.")

#text("In fact, similar situations have historically arisen many times, and the exaggerated often polemic and fearful end-of-the-world predictions have never manifested. Being able to use computers for simulation was seen as a desaster by many in the 1960s. Personally, I would rather say, at least for my main field of mathematics being applied nonlinear dynamics, it was the biggest driver of the field in the twentieth century that we can finally visualize and explore nonlinear systems beyond using formulas. We would have never understood the mathematics of bifurcations, chaos, patterns, and beyond at the marvelous depth we understand it now without numerical simulation. We would have never discovered the joyful applications of nonlinear systems that have changed many disciplines beyond mathematics into a new golden age. Instead, several fields were even generated in addition. Think historically: trains, cars, and planes were not the end of the horse. Originally, horses were just used as means of transport, and they were treated actually horribly in many cases. By now, horses are well-treated, respected, and admired animals in many cultures. Of course, if you wanted to go still everywhere by horse, you should be free to do so, you just have to accept the fact that others might want to go faster and by different means.")

#text("But then you may ask, why didn’t AI companies act more responsibly in the correspondence and conection to the mathematical community in certain, at least perceived, instances? A relevant case study might be recent nobel laureate Demis Hassabis of Deepmind. He has long promised artificial general intelligence (AGI) while pointing out at the same time that AI is particularly made for problems with large data, a large search space, and repetitive tasks. Whether one should take these aspects as the heart of AGI is at least questionable. So why does he proceed trying to get to, and heavily advertise, a goal that even he seems intrinsically sceptical whether it is fully achievable? The reasons might be hidden in his biography, which you can find even with classical search methods and in film format as an ad movie on your favourite video platform.")

#text("In his younger years, Hassabis was viewed as a chess prodigy and tried to get to the international top-level but for whatever reason this dream did never manifest. He was studying at Cambridge learning about the protein folding problem from fellow students finding fascination for it but also having to learn that others had currently better tools to study it, and he would have to potentially learn for decades to make a contribution to the area. Not reaching the pinnacle of a discipline or technique is a strong driver, it drives humans to find ingenious ways around the obstacle to avoid climbing large mountains.")

#text("In fact, drilling through the mountain leads to big celebrations in engineering circles but might not make expert mountain climbers particularly happy. Hassabis could be a case in point. He eventually participated in the development of a big machine instead of trying to climb the mountains. It is likely that many OpenAI developers driving projects to solve old mathematical conjectures act because of similar understandable and deeply human motives. They certainly know how the mountains look like as they would have to at least be able to communicate the Navier-Stokes equation in some form to an AI and guide how it attacks the problem. Yet, they might have realized they just won’t make it as mountain climbers themselves and it is evidently very tempting to use that shiny tunnel boring machine instead. And to no surprise, there are mountain climbers that don’t really like the overly joyful celebrations when engineers finish their brute-forced dark tunnel.")

#text("However, what many mathematicians apparently overlook in this allegory, is that mountain climbing still exists. Humans also still ride horses. Just the purpose has changed. We do it for the beauty, for re-creation, for enriching our abilities, to train our skills for other tasks, we do it for purely sporting competitions, whereas in daily real-world life, we just use the most efficient ways we have available to us from get from A to B.")

#text("AI will have the same impact. The field of mathematics will change, certain sub-disciplines will definitely shrink, particularly those where large existing data, available understanding of the most important techniques, tedious trial-and-error counter-examples, calculations, estimates, or finite classification problems have driven the field in the past. Yet, it is very likely that several existing disciplines will be much more relevant.")

#text("The most exciting aspect is that I would predict that entirely new mathematical disciplines will emerge. For example, it should be clear to anyone with a background in nonlinear science that the existence of AGI would entail the coexistence of a high degree of multistability in the AI model. But one could conjecture that controlling this high degree of multistability is extremely expensive and the propensity to find complex chaotic attractors will increase, potentially increasing faulty behaviour such as confabulations. Therefore, why not try to prove that there exists a certain balance between available energy/data input, achievable multistability and simultaneous fault tolerance? Or even more ambitious, which mathematical techniques fields that don’t exist yet would benefit particulary from having very sparse data and a very limited availability of repetitive tasks to push the field forward? With the help of AI we are now to free to think about questions and challenges that were simply out of reach for any previous generation.")

#text("Yes, we have to use technology responsibly, we have to be extremely careful to put results into context, to make science reproducible, to make it accessible. But to be fair, these are challenges we have faced and actually mastered quite remarkably well in similar forms historically. So if you are young, it is actually a golden opportunity to discover a new world, and I would encourage you to shape it actively with a positive spirit.")

#text("(no AI was used in writing this post)")

#text("Christian Kuehn, Garching b. München")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695310")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Beautiful comment! I really liked the story about computer simulations leading to new fields of math being invented.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695226")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I read this and it’s not too far from what we do in programming now. Coding agents generate a massive amount of changes, how do you review and understand it?")

#text("Just as you expect an author to be able to answer questions about their mathematics, I expect the agent to be able to answer those same questions.")

#text("If a colleague drops a 60k line change on me at the end of the day, I’ll skim what it’s doing and then have questions about it at a high level and I’ll as an agent to investigate and report. The AI is making the proof, it’s the right “person” to ask about it and guide understanding.")

#text("In my field the understanding is not super high value to an employer, but back in my days in abstract algebra trying to prove a group is or isn’t Abelian the entire point was the understanding. I think AI is good for this as well, if you’re smart enough to understand the concepts it is extremely patient in trying to guide you through it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ed7378ff13f5dfac4a4ce07ac96fd65de4fed9c358e4432a89468adecf76c6f-7fe31ea03be325bd18751a4995f0ff94d15e89ddec748cca62664c60c2945c53.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gleamingspeedilybb59fcc54d")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695230")[#strong[#text("gleamingspeedilybb59fcc54d")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Excellent article. One of the very best I’ve read on this subject.")

#text("As some others have already done, I’ll pick up on the points about exposition. Human expository work is needed for now because AI writing of math is currently still horrific. However, I would not be surprised if, in 6 months, it was producing the most beautiful and insightful articles we have ever seen. It would be a mistake to tie our value to a task that can clearly be automated.")

#text("As far as I can tell, the only value that we can guarantee that we will be able to provide in the future is in a task that is historically even more overlooked than exposition: reading. Reading cutting edge math takes years of training, and this will increase rapidly as AI finds new connections between different fields. Moreover, if we do not continue to train new mathematicians, then the ability to read mathematics will die when we die.")

#text("There is one more thing that we can still provide, but it is more fragile. Current AI seems to be filling up the convex hull of mathematical knowledge. It is making connections between different ideas that no human has had a wide enough scope and enough time and energy to find. However, it is not yet clear that it is able to discover new points outside the convex hull. Of course, it is also rare for humans to do this, but we can do it. If a large amount of human effort is redirected from filling the convex hull to trying to find points outside it, then maybe we will get better and faster at it than we are right now. And, at the moment, LLMs are probably unable to do it. That being said, I am aware that AlphaZero found new Go strategies that no human has found before. Therefore, it may be possible that a more advanced AI in the future will be great at this job as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#strong[#text("Right")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bb59e0a8353ef50c4fa01fca09e0afc26abe865572c899f7afb646046fee258-58022e796e82df0a245199d944dabdb763afe041c4093e84a6b0d8008cdbe1ac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.W. Helkenberg")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695240")[#strong[#text("J.W. Helkenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("AI is truly the exemplar of the slogan, “The whole is greater than the sum of its parts.” Take the totality of human thought and tokenize it. Next, look for distances between tokens across the vast corpus to estimate relationships. A formal reduction of language into meaning by removing meaning as an obfuscatory distraction.")

#text("Mathematicians have a certain wizard-like aesthetic that comes from the incomprehensibility of most formal math to average humans. Of course at the end of the day a mathematician is similar to an automotive technician in the sense they can understand systems most people avoid. Math is the purview of mathematicians and cars are understood by mechanics. Each is a master of their domain and this mastery is a result of exposure and practice.")

#text("AI has fundamentally altered this landscape. I study prime number distribution because it represents an invariant property of reality, one where a final answer can (in theory) be resolved. I have an algorithmic understanding of prime numbers but I have never once studied the tools used by mechanics (Lemma, theorem, etc) so I have no idea how to explain my approach in a language that can be understood by anyone familiar with the subject. I think it was Goedel who said no private language can exist, but AI is challenging that insofar as AI can generate proofs that cannot be expounded by the user generating the prompts. AI is racing far afield while us mere humans now work diligently to comprehend and refactor it’s outputs.")

#text("I have been excited to work in mathematics precisely because I view it as the intellectuals version of the “Thunderdome” where conjectures may enter but only proofs can leave. It matters not your educational attainment or professional accolades; anyone can pull the tools off the wall and produce a victory. AI is like walking into the Thunderdome wearing an exoskeleton armor and so the victories against outstanding problems are coming faster and faster.")

#text("“I have a proof of the twin prime conjecture,” he says as he weakly slashes his sword against the impervious mass of the TPC. I have been banging my sword against this demon for twenty years. I have published dozens of sequences in OEIS related to my efforts. I saw the path to success in a vision while spending time with native americans on a reservation outside Taos, NM. It was a vision granted by the heavens. A blessing and a curse as once you start you can’t stop. The mathematicians equivalent of “chasing the dragon.”")

#text("AI can now take my strange and un-mathematical ramblings (and extensive code and OEIS sequences) and help me forge a new weapon against TPC. Now my primary concern is that those of you with the supreme learning will be hit with a tsunami of AI generated proofs before I am done and so how do I become a signal that can be discerned above the noise.")

#text("Of course I will pay for that. Mathematicians now have a new and lucrative business model in front of them: offer to review AI generated proofs for $$$$. A bunch of amateurs generating proofs they can’t comprehend want an interpreter. Your new mission is to get paid interpreting AI for novice mathematicians.")

#text("Let me know your prices. Maybe we can get famous together?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695245")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I agree with everything, but suppose we do all this and next year AI is also great at exposition and can write beautifully and make great expository videos. What do we do then?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("People now writing paper with acknowledgements like: This paper was written by the authors with the assistance of large language models, which included suggesting arguments, … and writing code for computational checks.")

#text("lol, if llm’s were suggesting arguments and writing code, what did you do exactly, especially when you were not known as an expert in the field?")

#text("I also noticed people not mentioning ai on arxiv but acknowledging it in the journal submissions. Once you lose respect, how can people trust you in the future?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695303")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I cannot even solve my own problems, even with AI’s logorrhic pedantic advice. What does respect have to do with solving a problem or proving a theorem? I wanted Navier-Stokes to have a proof as beautiful as its derivation. I was robbed. We all were. I felt that disrespect.")

#text("AI is not profitable. Burning 12 million dollars on a fallacious proof was a PR stunt to make it appear as if AI has literally reached a singularity. I care deeply about Navier-Stokes but would never post my thoughts on the problem until it was declared solved on a whim.")

#text("The math says the price to earnings ratio is above 30, the price to book ratio is Abi e 6, and the dividend yield is 1%. The stocks are overpriced. When people say buy low, sell high, they mean sell now, or at least use a higher percentage of bonds to decrease portfolio volatility. AI companies are engaged in circular lending and are financing the buildout with their free cash flow and debt. This is why bond interest rates refuse to come down.")

#text("Claude has mathematicians on staff automating proofs. Then OpenAI scooped the proofs. What you are seeing is the value of problems increasing as a proxy for AGI to investors. Math proofs are a commodity. The free ride will end. They do not care about math. They care about a cultish sci-fi AI singularity as fuel for a financial bubble.")

#text("If you prove the Riemann hypothesis, maybe someone will acknowledge your efforts long after you’re gone. More than likely, AI will scoop whatever value you contributed. AI is a tragedy of the commons. A privatized tool built from shared public resources.")

#text("How many mathematicians can spend 12 million dollars in two weeks? But OpenAI is done with Navier-Stokes. Why would Anthropic or anyone else work on it now? Whatever they missed is fair game to anyone.")

#text("AI will not replace mathematicians because mathematics isn’t profitable except as a proxy for AGI. A bubble bursting, or the fulfillment of the goal of eliminating workers, will destroy the tax base and reduce funding for math. That will end mathematicians and their gaming of papers and citations that nobody but AI was reading.")

#text("Then again, the lump of labor fallacy says mathematicians will find work elsewhere.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695281")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I’m just deeply worried about the more correct things the mathematicians do, to understand how to best collaborate with ai models, more expositions was written down, it will become close source AI models’s source of intelligence and amplify the concentration of power. I think mathematicians should also rethink about credit assignment being part of the new economics model and making sure your output benefits all humanity not just specific models you choose.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695284")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("“Artificial intelligence has lowered the cost of producing sophisticated proofs.” This has, by and large, been the framing of this issue in the discussions I’ve seen so far. But it ignores the economic and environmental costs associated with AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695319")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Many years ago I said to this issue what I have to say:")

#text("An efficient proof machine, on which formal systems are implemented, would be a useful tool, as it is often time-consuming and nerve-wracking to track down a proof for a mathematical conjecture. Even if such a machine is built, the task of defining useful or beautiful mathematical objects and formulating conjectures about their properties would still remain for a researching mathematician. The pure mathematician is concerned with the beauty of mathematical objects and the applied mathematician in interdisciplinary collaboration about their usefulness. The learning and teaching mathematician would still have the task of understanding proofs, preparing them in a pleasing way and conveying his understanding to students. We are convinced that no machine can take over these tasks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Mathematicians need to rethink what it means to do mathematics. It can’t just be about proving things any more and the focus has to go firmly back on the ideas. It can no longer just be ”mathematicians prove things”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/560f4a91a5cd50f865eb38fc8a2e6908c92821fafdf3146d7b460db7e1fdbada-91bce0fdcb860de8cfba0d1ae6258a996852c82272810f0864cfa0a031eeeaf9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Billy Le Blanc")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695505")[#strong[#text("Billy Le Blanc")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("We need to start from a sociological lens. What you are proposing is to create new incentives for people. But we have to curate it based on what people are going to want to chase.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfcd6acb67cc0c9664613d3c57310908379b0a5b76439ffd8f27e637af53805f-2b4e509c975cb9e71bf571293c740f185dac12e7b75484e344d2569a1efec112.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of History and Future of Fluid Dynamics – Proofs and Prompts")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-695860")[#strong[#text("History and Future of Fluid Dynamics – Proofs and Prompts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("[…] not caring much about the machine solution and doing mathematics at one’s own pace like before, adjusting the economy of doing mathematics, the issues that lie ahead in the context of Navier-Stokes to resolve are, how the new proof – […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-696267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("I genuinely wonder how we are going to produce new PhDs in mathematics.")

#text("Right now, at the most basic level, a math PhD means proving some genuinely new results yourself. I am not sure that model can remain unchanged in the AI era.")

#text("Imagine a PhD student decides not to use AI. They spend two or three months on a problem, get stuck, and meanwhile someone somewhere else in the world uses AI and solves the same problem. Sure, the student learned a lot during those months, but that does not help much if they still need original results for a thesis.")

#text("And the problems that AI itself cannot solve may eventually be extremely difficult, possibly too difficult to expect a PhD student to solve from scratch.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1644c7ada1fe9126712ff045feaa8f551fb55d85d7023f53c7d53b48d0c268d6-8bcc80eff677b687935f6f20ed89884887470a9adbe385af8acab1d6a2aee536.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of phenomenal18e147ff2c")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-696272")[#strong[#text("phenomenal18e147ff2c")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2026")])]

#text("Many in this blog may not be old enough understand the joy of writing letters; more so about the joy of writing “love letters”. I enjoyed writing long letters (and occasionally love letters). I tried to resist the idea of writing emails, because of my love of writing letters (inclusive of love letters). In 1987, I had to jump in and had to start sending emails, across the continents. Letters and love letters had served their time. Same may happen to proving theorem and writing papers. ")#strong[#text("If writing papers had any remaining intrinsic value")]#text(", it will continue. If not, writing papers also had served their purpose and time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1b7c05932689f69d87ba60010636a4b6a97e8df362f9a3a5e506811f22f36aad-0a7db1aa99e210a55e4260a1bbd681468016793d285f9b3a6b1bcd9691c0a89b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bhaweshmishraa")]], [#link("https://terrytao.wordpress.com/2026/09/13/deep-theorems-were-scarce-and-difficult-and-so-became-an-effective-mechanism-to-identify-deep-thought-ai-has-broken-this-system/#comment-697215")[#strong[#text("bhaweshmishraa")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Certainly, something needs to be thought to reorganize mathematics and its pursuit for human-beings. I agree with Dr. Kra that the pursuit has human value.")

#text("I wouldn’t go to gym and move weights using a forklift. True that forklift does the same job, and it is easy on me to do so – but kind of defeats the value of gym altogether.")

#text("If the entire incentive at the gym (think of social hierarchy, gold/platinum membership, free massage, perks and privileges) only depended on how much weight one moved, then it is only a matter of time before almost everyone used a forklift.")

#text("Of course, analogy is extremely loose. For instance, weights can be measured uniformly, perhaps muscle size could be too – beauty, importance, impact etc. of a mathematical result : not that easy.")

#text("HOWEVER, moving the goal-post from “theorems” to “exposition” to “doing a handstand while reciting Socrates on a rocking boat” etc. is hardly more than a knee-jerk reaction that almost certainly another technological advancement will overcome, if that is not the case already.")

#text("Why do we go to gym? It helps us improve our overall physical, mental, emotional health, longevity, avoid disease etc. Then, we can design incentives around this and almost noone will use forklifts to move weights. So:")

#strong[#text("Why do we human-beings do mathematics, care about it, value it in the first place?")]

#text("Building incentive structure around “exposition” and “communication” is also weird in another sense. Imagine that we start considering only those painters who can explain composition, color, expression, presentation etc. properly. Then, any sort of genuine spark would get dwarfed by those incentives again.. We will be crowded by overlearned experts who don’t know how to paint but can explain the painting in a very sophisticated manner… We need these experts, make no mistake about that, but whole painters guild cannot be made up of just these experts.")

#text("We need great mathematical “expositors, communicators etc. “. We have not paid enough attention to developing those kind of skills as a community, and only recently started paying attention to it systematically. But again, the whole mathematical community cannot be just made up of great communicators and expositors and so on.. We need a great variety of all of them – theorem provers, expositors, communicators, collaborators, solo-working mathematician, perhaps a few rascals that shake and embarass the system every once in a while and so on.")
]
