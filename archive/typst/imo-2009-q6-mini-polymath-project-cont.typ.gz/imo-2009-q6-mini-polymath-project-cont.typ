// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/
// Converted to Typst by tao2typ: "2026-10-14T16:35:49.745711+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "IMO 2009 Q6 mini-polymath project cont.", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("IMO 2009 Q6 mini-polymath project cont.")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 July 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/")[#text("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Well, participation in the ")#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/")[#text("IMO 2009 Q6 polymath project")]#text(" has exceeded my expectations; it appears that the collaborative effort has scored some partial successes toward a solution in the first 24 hours of its existence, but is not quite there yet.")

#text("As the thread has become overly long, I am following established polymath practice and starting a new thread here, hopefully to try to impose more order onto the chaos. In order to assist this effort, some of the participants may wish to summarise some of the “state of play” so far. (I am unable to do this due to being biased by the knowledge of a solution.)")

#text("The comment numbering system has not worked as smoothly as I had hoped, but it is still better than nothing. I propose that comments in this thread start at 200, so as not to collide with the ")#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/")[#text("previous thread")]#text(".")

#text("Of course, all the rules of the polymath exercise (as discussed in the previous thread) continue to apply. I am pleased to see that virtually everyone participating has adhered to the collaborative spirit of the exercise, for instance in keeping criticism constructive and technical rather than pejorative and personal.")

#text("As an experiment, I have enabled one level of comment threading; thus one can reply to a specific comment in the thread below. If one does so, I would request that you number the comment by subsection, for instance the first response to comment 234 would be numbered 234.1, the next one 234.2, and so forth. There is a tradeoff here; the threading adds more structure to the comments, but the flip side of this is that it makes it harder to read off at a glance all the comments made since the last time one checks the thread. Hopefully participants will be able to use their discretion when to reply and when not to. [")#emph[#text("Update")]#text(", Jul 21: Threading should work properly now, I didn’t set it properly before.]")

#heading(level: 1)[#text("Comments (172)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40679")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("I wonder if there are equivalent formulations. Here is one which is not so general as the original, but might be more confusing to solve.")

#text("A round table has n(n+1)/2 seats. n boys come in and discover that there are already (n-1) girls sitting at the table. Show that the boys can always arrange to sit down at vacant seats so that the distances between consecutive boys are all different.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40692")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("Actually there may be proof strategies which are easier in the circular case (identifying the beginning and end of the path) if the grasshopper can start at any vacant space.")

#text("For example, the ‘mod n’ kind of proof – there is a residue class completely unused – promises to work quite straightforwardly with this set up.")

#text("And there may be counting approaches which benefit from the extra symmetry of the circle.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wenwen")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40680")[#strong[#text("wenwen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("I’ve a proof which seems to be correct. I don’t know if it appeared in the above discussions.")#linebreak()#text(" Let ")#mi("a_1 < a_2 < \\cdots < a_n")#text(" be the ")#mi("n")#text(" given positive integers.")#linebreak()#text(" Denote ")#mi("A = \\{a_1, a_2, \\cdots, a_n\\}")#text(" and ")#mi("s = a_1 + \\cdots + a_n")#text(".")#linebreak()#text(" Let ")#mi("x_1 < x_2 < \\cdots < x_{n-1}")#text(" be ")#mi("n-1")#text(" numbers the the grasshopper wants to avoid.")#linebreak()#text(" Denote ")#mi("X = \\{x_1, \\cdots x_{n-1}\\}")#text(".")

#text("Induction on ")#mi("n")#text(". When n = 1,2,3, it's easy to check.")#linebreak()#text(" Assume now for ")#mi("n^{\\prime} < n")#text(", it's true. We want to show that for ")#mi("n")#text(", it's true.")

#text("Case I. ")#mi("x_{n-1} \\geq a_2 + \\cdots + a_n  = s- a_1")

#text("There exists a ")#mi("k \\neq 1")#text(", such that ")#mi("s-a_k \\notin M-\\{x_{n-1}\\}")#text(". So for the pair ")#mi("(A-\\{a_k\\}, M-\\{x_{n-1}\\})")#text(" we can use the induction hypothesis to get permutation of ")#mi("A-\\{a_k\\}")#text(", say ")#mi("(b_1, b_2, \\cdots, b_{n-1})")#text(" to avoid the set ")#mi("M-\\{x_{n-1}\\}")#text(". Since ")#mi("b_1 + b_2 + \\cdots + b_{n-1} = s-a_k < s-{a_1} = x_{n-1}")#text(", so the permutation ")#mi("(b_1, b_2, \\cdots, b_{n-1}, a_k)")#text(" of ")#mi("A")#text(" is good.")

#text("Case II. ")#mi("x_{n-1} \\leq a_1 + \\cdots + a_{n-1}  = s- a_n")

#text("Consider the pair ")#mi("(A-\\{a_n\\}, M-{x_\\{n-1}\\})")#text(", by the condition, we know that we can use the induction hypothesis to have one permutation of ")#mi("A-\\{a_n\\}")#text(", say ")#mi("(b_1, b_2, \\cdots, b_{n-1})")#text(" to avoid the set ")#mi("M-\\{x_{n-1}\\}")#text(". If for any partial sum ")#mi("b_1 + \\cdots + b_k")#text(", it's NOT equal to ")#mi("x_{n-1}")#text(", the permutation ")#mi("(b_1, b_2, \\cdots, b_{n-1},a_n)")#text(" is what we want; if there is a $k$, such that ")#mi("b_1 + \\cdots + b_k = x_{n-1}")#text(", we switch ")#mi("a_n")#text(" and ")#mi("b_k")#text(" to get the following permutation ")#mi("(b_1, b_2, \\cdots,b_{k-1}, a_n, b_{k+1},\\cdots b_{n-1},b_k)")#text(", it works since this switch provides a big jump to avoid every thing at the ")#mi("k^{th}")#text(" step.")

#text("CaseIII. ")#mi("s- a_n < x_{n-1}<s- a_1")

#text("In this case there must be a $1<k<n$, such that")#linebreak()#text(" ")#mi("s-a_n < s-a_{n-1} < \\cdots < s-a_{k+1} \\leq x_{n-1} < s-a_k < \\cdots < s-a_1")

#text("We first claim that we can require for ")#mi("i = n, n-1, \\cdots, k+1")#text(", we have ")#mi("s-a_i \\in M")#text(".(otherwise, if ")#mi("s-a_i \\notin M")#text(", we consider the pair ")#mi("(A-\\{a_i\\}, M-\\{x_{n-1}\\})")#text(" to get a permutation ")#mi("(b_1, b_2, \\cdots, b_{n-1})")#text(" of ")#mi("A-\\{a_i\\}")#text(", and take ")#mi("(b_1, b_2, \\cdots, b_{n-1}, a_i)")#text(" as the permutation we need.)")

#text("Now consider the set ")#mi("M^{\\prime} = M-\\{s-a_n, \\cdots, s-a_{k+1}\\}")#text(" and it has exactly ")#mi("k-1")#text(" elements, so there is a ")#mi("l \\in \\{1, \\cdots, k\\}")#text(", such that ")#mi("s-a_l-a_n \\notin M^{\\prime}")#text(". We consider the pair ")#mi("(A-\\{a_l, a_n\\}, M-\\{s-a_n, x_{n-1}\\})")#text(", it easy to see that we can use the induction hypothesis on this set to get a permutation ")#mi("(b_1,\\cdots, b_{n-2})")#text(" of ")#mi("A-\\{a_l, a_n\\}")#text(", then we can take the permutation ")#mi("(b_1,\\cdots, b_{n-2}, a_n, a_l)")#text(" for ")#mi("A")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe84d8480ff4dcc22b8daf0b230056880d4e9296b6a8a3382024cb745c76862b-6e79261126b30f79d32a26471d281e4c4a134347d547b595ce714c280bf0381e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luka Lasic")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40686")[#strong[#text("Luka Lasic")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("@wenwen Case I. wonderful, Case II. wonderful,")

#text("Case III. wonderful long jump.")

#text("Change cases (1,2,3) -> (3,1,2), and X -> M.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe84d8480ff4dcc22b8daf0b230056880d4e9296b6a8a3382024cb745c76862b-6e79261126b30f79d32a26471d281e4c4a134347d547b595ce714c280bf0381e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luka Lasic")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40696")[#strong[#text("Luka Lasic")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("PROBLEM {0,1,2} :")

#text("O:={0} and splits are: 0 -> (1,2) and 0->(2,1) and 1->(0,2) and 1->(2,0) and 2->(0,1) and 2->(1,0). Now:")

#text("A={(1,2),(2,1)}, and splits on first coordinates leads to:")

#text("1[A]={(0,2,2),(2,0,2),(0,1,1),(1,0,1)}, and splits on second coordinates leads to:")#linebreak()#text(" 2[A]={(1,0,1),(1,1,0),(2,0,2),(2,2,0)}. Clearly, intersection of 1[A] and 2[A] are non-empty.")

#text("Recursively, 1[1[A]], 2[1[A]], 3[1[A]], 1[2[A]], 2[2[A]], 3[2[A]],")#linebreak()#text(" are pairwise with non-empty intersection, and analogous to infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40743")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("As some sort of control experiment I asked A. Nili and got this reply (I am not sure if it is identical to argument that was already presented):")

#text("Problem:")#linebreak()#text(" let a_1,a_2,…,a_n be n distinct positive real numbers,")#linebreak()#text(" and let b_1,b_2,…,b_{n-1} be n-1 distinct positive reals.")#linebreak()#text(" Prove that there is a permutation a_{i1},a_{i2},…,a_{in} of the")#linebreak()#text(" numbers a_i so that all initial sums a_{i1}+a_{i2}+…+a_{ij}")#linebreak()#text(" differ from all b_k’s.")

#text("Solution:")#linebreak()#text(" Proof by induction on n. Trivial for n=1, assuming for n-1, omit")#linebreak()#text(" the largest a and the largest b. By induction the remaining a’s can")#linebreak()#text(" be arranged so that their initial sums avoid all b’s but possibly")#linebreak()#text(" the largest. If the largest is obtained as")#linebreak()#text(" a_{i1}+a_{i2}+…+a_{ij}, replace a_{ij} by a_max and put a_{ij}")#linebreak()#text(" last (or anywhere after a_max), noting that all initial sums of")#linebreak()#text(" at least j a’s are now larger than the largest b.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40746")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("“Proof by induction on n. Trivial for n=1, assuming for n-1, omit")#linebreak()#text(" the largest a and the largest b. By induction the remaining a’s can")#linebreak()#text(" be arranged so that their initial sums avoid all b’s but possibly")#linebreak()#text(" the largest. If the largest is obtained as”")

#text("the sum of the n-1 elements could also be a landmine in the n-1 case we don’t prove it we have it by hypothesis here we have the sum of n elements cannot be a mine by hypothesis.")

#text("In my")#linebreak()#text(" 24 July, 2009 8:10 am proof I go along those lines and then I have to deal with the n-1 elements issue mentioned above. It can be dealt with. I think it is the fifth proof on the wiki.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac50f5bbbd50c08dbc00e806b3035c082de46665d8d9431664a171971baeb15f-fdc2a50d536e6684604b70d17622611c33032d8a1fc3fbcd47c03ad51f3f1f66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex and Ecki")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40748")[#strong[#text("Alex and Ecki")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2009")])]

#text("This is the easier part 1 of the proof 5 already in the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6#Proof_.235")[#text("wiki")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40756")[#strong[#text("Gil")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2009")])]

#text("Hmm, right. I overlooked that…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40794")[#strong[#text("A mini-polymath project « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2009")]

#text("[…] ")#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/")[#text("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40894")[#strong[#text("E")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Sadly I only got to see this problem today and it is seems hopeless to follow the discussion.")#linebreak()#text(" I was following a first lead on the problem sitting on my coach which seemed to me like a good one.")#linebreak()#text(" I would be happy to hear if this direction was discussed and what you guys think.")

#text("Let us first notice that since all the jumps are of distinct size we have n! different ways in which our grasshopper can take his course.")#linebreak()#text(" Secondly, a simple observation is that we must have at least two completely distinct paths since if we don’t then we can take an arbitrary path and choose our mines to match it exactly, by the assumption we’ve just made, any other path has at least one step that matches the first path and the theorem is disproven(sorry for my shaky English).")#linebreak()#text(" So we now know that we must have atleast two completely distinct possible paths. Obviously showing that we actually got two such paths proves the theorem.")#linebreak()#text(" Again, if we assume that we do not have such two paths, than every two paths have atleast one point in common, and with some simple combinatorics it is eazy to see that we get less than the N! possible different paths that we know exist.")

#text("My bet is that i’m missing something here. It took me less than an hour to come up with this “solution” while many people whos math talent and experience are superior to mine seem to have struggled with the problem.")

#text("BTW, did the discussion move somewhere else or something like that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40895")[#strong[#text("E")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2009")])]

#text("Okay, I was too hasty")#linebreak()#text(" “Obviously showing that we actually got two such paths proves the theorem.”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JM")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40955")[#strong[#text("JM")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Another solution, I think.")

#text("Let’s suppose ")#mi("a_1 < \\ldots a_n, m_1 m_{k+1}.")

#text("We make an observation: If we get up to or past ")#mi("m_{k+1}")#text(" with ")#mi("k+1")#text(" steps, then the")#linebreak()#text(" ")#mi("k+1")#text("-th step lands on a mine. (To see this, let ")#mi("b_1,\\ldots b_{k+1}")#text(" be the steps")#linebreak()#text(" with ")#mi("m_{k+1}\\leq b_1+\\ldots +b_{k+1}\\notin M.")#text(" We can find a jump sequence clearing ")#mi("m_1,\\ldots m_k.")#text(" This jump sequence in fact avoids all mines: With ")#mi("j\\leq k")#text(" steps we can")#linebreak()#text(" only trip up on one of the mines ")#mi("m_1, \\ldots m_k")#text("; the ")#mi("k")#text("-th step doesnt land on a")#linebreak()#text(" mine and goes past ")#mi("m_{k+1}.")#text(" This allows us to construct a mine free trip for the original")#linebreak()#text(" ")#mi("n")#text(", which we aren’t supposed to be able to.)")

#text("Set ")#mi("A:=a_n+\\ldots +a_{n-k+}.")#text(" By considering ")#mi("n-k")#text(" numbers ")#mi("A+a_i")#text(" with ")#mi("1\\leq i\\leq n-k")#text(", the observation above tells us that there exists ")#mi("1\\leq r\\leq n-(k+1)")#linebreak()#text(" with ")#mi("A+a_r<m_{k+1}\\leq A+a_{r+1}.")#text(" Of course, we also have those ")#mi("A+a_i\\geq m_{k+1}")#text(" are in ")#mi("M.")

#text("Now consider the following ")#mi("k+1")#text(" numbers all ")#mi("\\geq m_{k+1}")#text(": ")#mi("A+a_{r+1},\\ldots , A+a_{n-k}")#text(" and ")#mi("A+a_{n-k}+a_1,\\ldots , A+a_{n-k}+a_r.")#text(" We can conclude that ")#mi("A+a_{n-k}+a_t\\notin M")#text(" for some ")#mi("1\\leq t\\leq r.")

#text("We now use ")#mi("a_n,\\ldots ,a_{n-k}")#text(" and ")#mi("a_t")#text(" to jump ")#mi("k+2")#text(" steps clearing ")#mi("m_1, \\ldots m_k")#text(" and ")#mi("A+a_{n-k}.")#text(" This trip doesn't land on any mine: if it did, it can")#linebreak()#text(" only be on the ")#mi("k+1")#text("-th step (anything before, distance covered is ")#mi("leq m_k")#text("). On the")#linebreak()#text(" ")#mi("k+1")#text("-th step it must land on ")#mi("A+a_{n-k}+a_t-a_j")#text(" for some ")#mi("n\\geq j\\geq n-k.")#linebreak()#text(" But then ")#mi("A+a_{n-k}+a_t-a_j\\leq A+a_tk+1.")#linebreak()#text(" So we have in fact a mine free trip of ")#mi("k+2")#text(" steps going safely beyond ")#mi("m_{k+2}")#text(",")#linebreak()#text(" which allows us to construct a solution for the original problem.")

#text("That proves the claim.")

#text("To finish off, by the claim ")#mi("s-a_1,\\ldots s-a_n")#text(" are all ")#mi("\\leq m_{n-1}.")#text(" So we must")#linebreak()#text(" have ")#mi("m_k<s-a_i<m_{k+1}.")#text(" We use jumps apart from ")#mi("a_i")#text(" to go clear mines upto ")#mi("m_k")#text(" and round off with ")#mi("a_i.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JM")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40991")[#strong[#text("JM")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("Apart from the formatting problems, couple of paragraphs seem to have disappeared since my writing and it appearing. The solution should begin with:")

#text("Let’s suppose ")#mi("a_1 < \\ldots a_n, \\ m_1 m_{k+1}.")

#text("The soln still doesnt read well, but hopefully there is enough explanation for one to work through.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JM")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40992")[#strong[#text("JM")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("Still doesnt work; last try before I give up :)")

#text("Let’s suppose a_1 < \\ldots a_n, m_1 < … m_{k+1}.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-40999")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2009")])]

#text("I think what is happening is that the parser is interpreting your < and > signs as HTML. One can fix this by using &lt; and &gt; instead. Alternatively, you can place your solution on the wiki at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")[#text("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6526aafba50fac8f08483d48e266a7581602235c24e0b08faddb3375da70310-efeb9228c243067198b3f473823ee0c04c9e87d550512128b63c04e598b05987.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajen Shah")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-41864")[#strong[#text("Rajen Shah")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("I’m not sure if I’m missing something here:")

#text("There are n! different paths that could be taken (if we forget the restriction imposed by the set M).")#linebreak()#text(" Each element of M which is a sum of k numbers from a_1 up to a_n blocks out k!(n-k)! of these paths.")#linebreak()#text(" Now if we count up the maximum possible number of paths blocked, it is easy to see we can never block more than n! paths.")

#text("Does this not work?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-41865")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2009")])]

#text("Hi Rajen,")

#text("I haven’t thought about the problem seriously myself but I don’t think that your observation provides a solution unless the sums formed from the a_i’s happen to all be distinct.")

#text("‘Coincidences’ between the sums will make it harder. For example, if the first few of the a_i are 3,4,6 and 7, then a mine at 10 = 3 + 7 = 4 + 6, blocks more paths than you have accounted for.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/06849e100bf734f45a9dfcc89e627e06270752e577170400c3c3c79ac803d436-f05557b1f5289465627804446ee4710396b835bff4d71dbafcae2d3135a1b52b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bài toán số 6 trong IMO 2009 « Sharing")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-43691")[#strong[#text("Bài toán số 6 trong IMO 2009 « Sharing")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2010")])]

#text("[…] link 3 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-45556")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 17 June 2010")])]

#text("Here is a non-technical version of an early solution, developed for use with a school group.")

#text("If n=1 there is one jump and no mines. Easy.")#linebreak()#text(" Assume cases up to n-1 are done.")

#text("Try to make the longest jump from the left hand side.")

#text("Case A: this jump clears at least one mine and lands on an unmined place. Thene the remainder is case n-1 and we are done.")

#text("Case B: the longest jump clears no mines, though it may land on one. Remove the leftmost mine, and take out the longest jump. Working from the right, now, we have a case of (n-1) and can make all the leaps in some order, clearing all the remaining mines.")

#text("Put back the leftmost mine.")

#text("If no jump lands on it, then we can add the longest jump at the left hand end, and we are done.")

#text("If a jump does land on it, then working from the right, replace that jump with the longest jump. Now up to the longest jump we have cleared all the mines and the remaining jumps can be added at the left hand end in any order to complete the task.")

#text("Case C: the longest jump clears at least one mine, but lands on a mine – so there is a mine at distance equal to the longest jump from the left hand end, with at least one mine to the left of this. Then any combination of two jumps from the left hand end and including the longest will clear at least two mines.")

#text("Consider the n-1 possibilities (from the left) of {short jump followed by longest jump}. None of these lands on the mine whose fixed position is known – so there are just n-2 more mines to avoid. Because the short jumps are all different lengths, all the positions landed on by this set of n-1 pairs are distinct. n-2 mines can only block n-2 of these possibilities, so there is at least one pair {short jump followed by longest jump} which does not land on a mine and which clears at least two mines. The rest is case n-2 and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d25caf1f7fb440ffa6be5dc6603c502ef59967980980d0fe7f70d5b8973bdde-3d659c86b528d06e719a7be27a2cc1876606120d81dc420154dd193139259d81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of noname")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-3/#comment-46507")[#strong[#text("noname")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2010")])]

#text("I found a solution but it seems too much simple compared to other solutions so please let me know if I made a mistake.")

#text("Let S={A_1,…,A_n+1} and T={B_1,…,B_n}")#linebreak()#text(" Suppose the statement is true for n. We will prove it for n+1.")

#text("Let a k-sum to be sum of k elements of S. Now there are n+1 n-sums and each one is different from one other because elements of S assumed to be distinct. So at least one of the n-sums is not an element of T. Let A_k is not in this n-sum. Apply the statement for S/A_k and T/B_n . Grasshopper doesn’t land on any mine including B_n. By adding this order A_k we prove the statement.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("234. SPOILER warning inherited from brumm’s comment.")

#text("Re 225: You’re wondering about the case where max A is a mine and f = 0. I will try to rephrase brumm’s comment in this case more precisely but perhaps less clearly.")

#text("In this case max A = min M. Get A’ and M’ for induction by subtracting max A (=min M) from each element of A and M, then removing the resulting 0 element from each set. Use induction to get a path through A’ avoiding mines in M’. Call P’ the permutation of elements of A’ that define this path. Let x be min A. Then you can get P as (P'(1), x, P'(2)+x, … P'(N)+x). This cleverness avoids the pesky first mine, while allowing induction to avoid the rest of them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of d")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40487")[#strong[#text("d")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("234. I’m a bit late to the party, but what about this idea:")

#text("(*) if there are ever k (some 1 <= k = 1 element of M that is greater than s – max(a_j) so reversing (making that the “last” jump”) we would still be done by induction (apply (*) where we have reversed M and the a_j).")

#text("maybe i’m missing something, i’ve only just thought about this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of d")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40490")[#strong[#text("d")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("234.1 (Your blog munged my comment so I’ll try again)")

#text("234. I’m a bit late to the party, but what about this idea:")

#text("(*) if there are ever k (some 1 <= k = 1 element of M that is greater than s – max(a_j) so reversing (making that the “last” jump”) we would still be done by induction (apply (*) where we have reversed M and the a_j).")

#text("maybe i’m missing something, i’ve only just thought about this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40488")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Mark (223)… You start assuming there is a solution, and then use your relation to show that the solution is in the class of solutions. How would you use your equivalence relations to show there is not a solution to the problem when M=A.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40491")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("David")

#text("I’m not assuming what you suggest. In the spirit of polymath, I’m proposing a path to solution different from that suggested so far.")

#text("I’m not quite sure of the definition of A.")

#text("I think that my most useful point is that a hypothetical minimal counterexample (eg to induction) can be more tightly drawn than most ofthe suggestions proposed elsewhere.")

#text("I can choose the lowest possible n. I can choose the first mine as close to zero as possible given n. Or I can choose the largest mine to have the smallest index possible. Or I can choose the set M to have the lowest possible index sum (all attempts to get the mines as far left as possible so that initial jums have a better chance of k jumps covering k mines and induction following).")

#text("Or I can choose the hypothetical counterexample which has the minimum number of landings on mines.")

#text("In each case I want to show that this is not a counterexample, or it is not minimal.")

#text("Then my question is “what tools do I have to do this?” The standard set is the permutations of the Ai. Are there other options?")

#text("Equivalence is a possible set of options – are they useful, do they work, are they necessary? I haven’t sat down to check.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("235. SPOILER")

#text("Sorry I botched that a bit. I’ll try again.")

#text("In this case max A = min M. Get A’ by removing max A. Get M’ for induction by subtracting min M from each element of M and removing the resulting 0. Use induction to get a path through A’ avoiding mines in M’. Call P’ the permutation of elements of A’ that defines this path. Then you can get P as (P’(1), min A, P’(2), … P’(N)). P is the path through A that avoids mines in M.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of carmen")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40494")[#strong[#text("carmen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("237. Lets consider again the sets")#linebreak()#text(" A0={0}")#linebreak()#text(" A1={a1, a2, …, an} (the initial set)")#linebreak()#text(" A2={a1+a2, a1+a3, a1+a4, …, a1+an, a2+a3, ..,a2+an, …, an-1+an}")#linebreak()#text(" A3={a1+a2+a3, a1+a2+a4, …}")#linebreak()#text(" …")#linebreak()#text(" An={a1+a2+…+an}")#linebreak()#text(" We know that |Ak|=|A_{n-k}|, k=0,1,…,n")

#text("Using induction, we will be done if any element from A1 or A_{n-1} would belong to M. So we may suppose that this two set do not intersect M.")#linebreak()#text(" We also know that")#linebreak()#text(" |A1|=|An-1|=n")#linebreak()#text(" |A2|=|An-2|>=n-1+n-2=2n-3>n, n>1")#linebreak()#text(" |A3|=|An-3|>=n-2+n-3+n-4=3n-7>n, n>1")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40493")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("236. I’ve worked through brumm’s proof. It seems to me that it works fine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40495")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("237 I also believe Brumm’s proof. Nice work!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40498")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("238. Continuing post 218.")

#text("Applying the induction hypothesis on M’ and A’ we find that there is a permutation t in S_{n-1} so that the partial sums S_j:=a_{t(1)},….,a_{t(j)} do not lie in M’.")

#text("We first get rid of 2 easy cases. First, if m’>a_1+…+a_{n-1}, we are done (just choose a_n as the last jump). Second, if m’")#text("1 by the induction hypothesis.")

#text("So now assume that a_{t(1)}<m'<a_1+…+a_{n-1}. Then there exists a unique k in {1,….,n-2} so that S_k<m'<S_{k+1}. If k+1=n-1, then we are done because m is different from S_{k+1}=a_1+….+a_{n-1} by our assumption. Hence we may assume that k+12 jumps are chosen in order to avoid the points m’ and m, which is possible by the induction hypothesis. This completes the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5fb9bb82f073d3c7fca108fd2dddea730ba270ea88dbe057d000ca525e7ef093-e1ff3d3a9120fbba8ff67a25002897ccb6550f762e3816ccb01ac69fc4cc7afa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zach")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40501")[#strong[#text("Zach")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Comment 239.")

#text("First, I apologize as I haven’t read all the posts here. I thought I might throw in a little idea I have, though.")

#text("I think all we need is induction. The base case n = 1 is easy, and if we suppose it’s true for $n = k$ and we’ve got a sequence $(a_i)$ of $k + 1$ distinct positive integers and a set $M$ of $(k+1) – 1 = k$ positive integers, then to apply the induction hypothesis just remove an element of $M$ (any element will do), calling the result, say, $M’$, and then find an element of the sequence to remove such that the sum of the smaller sequence isn’t a member of $M’$. Once this is done, the induction hypothesis will apply to the smaller sequence and $M’$, and I think the problem can be solved from there.")

#text("Showing this latter (that a suitable element of the sequence can be removed) I suspect is just a counting argument.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40502")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("239.")

#text("Brumm’s proof case 4(There is a spoiler warning):")

#text("“max a is not a mine and f=0. As in case 3, construct M’, jump max a first and solve for the remaining a_i and M’. If this solution hits min M in step k, construct a new solution by exchanging step k+1 and step 1 (i.e. max a). There are no mines before min M, thus the mine is avoided and no new mines are hit. We have completed solution for n+1")

#text("I hope that’s it and it’s shut tight. This problem is just evil”")

#text("What if solution jumps over min M and hits a larger element of M then couldn’t the exchange hit the the original element min M or for that matter any smaller elements of M it has jumped over before hitting the mine?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jc")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40505")[#strong[#text("jc")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("239.1")#linebreak()#text(" The solution for the {a_i}\\max a with mines at M’=M\\min M is guaranteed to exist (and hence not hit any element of M except possibly min M) by the induction step for grasshopper problems of size n.")

#text("Forgive me if I misinterpreted your comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brumm")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40506")[#strong[#text("brumm")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Not sure I understand you. The solution (solves for M’) hits by definition no other mines in M, because the induction assumes all problems of size n are solved successfully.")

#text("A technicality: When solving the smaller problem from some starting point like max a, of course the numeric values of the mines in M’ have to be reduced by starting point, I.e. A=(1,5,10,11), M=(12,13,14), max A=11, A’=(1,5,10), M’=(1,2,3)")

#text("Thanks for the kind words. Actually I saw the key idea (isolating max a and min M then solving by recursion) in a faulty proof which only considered cases 3, 4 and which seemed to assume that you can “extend” M_n to M_n+1. I wrote it up mainly to have a full documented proof with URL. Acquaintance got faulty proof from mathlinks.ro dicussion I believe. Have to admit I didn’t get that all of that idea on my own. I tried induction over the hopper jumps and exchanging with earlier jumps if a mine is hit – this turned out to melt my brain but got no results. Considered combinatorics, the n! hopper jumps are all different from each other in at least one jump position, but this went nowhere either. Then the idea of finding the “biggest clump” of mines and bridging it first with max a was considered, this doesn’t work either. It’s surprising how easy it looks in the full proof, especially case 4 (mines cluster in the middle) which had been a nightmare in previous attempts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40504")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("240.")

#text("from 239.(There was a spoiler warning from the original)")

#text("“What if solution jumps over min M and hits a larger element of M then couldn’t the exchange hit the the original element min M or for that matter any smaller elements of M it has jumped over before hitting the mine?”")

#text("No it can’t do that because we have solved for the remianing a_i and M")#linebreak()#text(" so it looks like it works.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40510")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("241. I have an alternative step for use in induction on the number of intervals.")

#text("Assume a sequence of n intervals cannot be blocked by any set of n-1 mines.")#linebreak()#text(" Construct a set of n mines that will block this sequence of intervals.")#linebreak()#text(" Then the longest path that is blocked must terminate on the last mine, because we know that we can cross any sequence of n-1 mines by assumption.")

#text("Next step would be to show that we can unblock by adding another interval to the sequence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40511")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("242")

#text("I was not quite sure about the fourth of Brumm’s points. If I put all the mines near the end, I can force the last jump to be any particular one of the Ai. Does the induction pick out the right one?")

#text("But thinking about it, it seems to be delicate enough to do it rather nicely.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40512")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("242. I think I finally figured out what is going on with my posts (after reading the “about” page of the blog). Whenever I used two signs of strict inequalities (one less than and one greater than) the text that lied between them disappeared because the site interpreted them as html code.")

#text("Rewriting post 238:")

#text("Applying the induction hypothesis on ")#mi("M^\\prime")#text(" and ")#mi("A^\\prime")#text(" we find that there is a permutation ")#mi("t\\in S_{n-1}")#text(" so that the partial sums ")#mi("A_j:=a_{t(1)}+\\cdots+a_{t(j)}")#text(" do not lie in ")#mi("M^\\prime")#text(".")

#text("We get rid of two easy cases. First, if ")#mi("m^\\prime > a_1+ \\ldots +a_{n-1}")#text(", we are done (just choose $a_n$ as the last jump). Second, if ")#mi("m^\\prime < a_{t(1)}")#text(", then pick ")#mi("a_{t(1)}")#text(" as the first step and then choose the next ")#mi("n-1")#text(" steps by possible rearranging ")#mi("a_{t(2)},\\dots,a_{t(n-1)}")#text(" and ")#mi("a_n")#text(" in order to avoid the point ")#mi("m")#text(". This can be done by the induction hypothesis.")

#text("So now assume that ")#mi("a_{t(1)} < m^\\prime < a_1+\\ldots+a_{n-1}")#text(". Then there exists a unique ")#mi("k\\in\\{1,\\dots,n-2\\}")#text(" so that ")#mi("A_k < m^\\prime < A_{k+1}")#text(". If ")#mi("k+1=n-1")#text(", then we are done because ")#mi("m\\neq A_{k+1}=a_1+\\cdots+a_{n-1}")#text(" by our assumption (choose ")#mi("a_n")#text(" as the last jump). Hence we may assume that ")#mi("k+1  2")#text(" jumps by possibly rearranging ")#mi("a_{t(k+1)},\\ldots,a_{t(n-1)}")#text(" and ")#mi("a_n")#text(" in order to avoid the points ")#mi("m^\\prime")#text(" and ")#mi("m")#text(", which is possible by the induction hypothesis. This completes the proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40515")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("245. Alternative complete proof")

#text("We restrict ourselves to to sequences of intervals in ascending order; this is without loss of generality.")

#text("Assume a sequence of n intervals cannot be blocked by any set of n-1 mines.")#linebreak()#text(" Pick any sequence of n intervals and add a new interval greater than all the others.")#linebreak()#text(" Any set of n mines that blocks this new sequence, must also block the original sequence of n intervals; otherwise we could just take an unblocked path from the original sequence and append the new interval, contradicting that this set blocks the new sequence.")#linebreak()#text(" The longest path blocked in the original sequence must terminate in the last mine (by 241). Exchange the last interval in this path with the new interval that has been added (which must be greater and just jumps over the mine), and we have unblocked the path. remaining intervals can just be appended to reach the target, because we have passed the last mine.")

#text("So any sequence of n+1 intervals cannot be blocked by n mines assuming we cannot block a sequence of n intervals with n-1 mines. We cannot block a sequence of 2 intervals with 1 mine, so by induction we have proven al cases.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40525")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("“The longest path blocked in the original sequence must terminate in the last mine (by 241).”")

#text("Let the intervals be ")#mi("a_1 < a_2 < \\ldots < a_n")#text(".")

#text("What if there is a mine at ")#mi("t:=a_1 + a_2 + \\ldots + a_{n-1}")#text(", and also a mine at some value ")#mi("u")#text(" greater than this? Then your original sequence will terminate at ")#mi("t")#text(", which is not the last mine. The reason the induction does not apply is that the inductive set up has an assumption that there is no mine at the sum of the intervals.")

#text("This is why Brumm's argument needs cases 1 and 2. Your argument is the reflection of Brumm's cases 3 and 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40526")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("I don’t think this works… You have correctly proved that if M is a minimal blocker of A (meaning you cannot remove any mine and still block), then M does not block A’=A union a_max. If you want to have a set of mines that blocks A’ with M as a subset then you would have to add at least one mine, but I don’t think that shows that a rearrangement of M would not block A’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40527")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("My previous message was eaten by the spam filter. My current theory is that it has a very bad method of counting links and eats any comment with too many less than or greater than signs. So I’ll try again without them:")

#text("Let the lengths of the intervals, written in increasing order, be a_1, a_2, …, a_n. Suppose that there is a mine at t=a_1+a_2+…+a_{n-1} and also a mine at u, for some u greater than t.")

#text("Then your inductively constructed sequence of jumps will be blocked at t, which is not the largest mine.")

#text("This is why Brumm’s argument needs cases 1 and 2. Your argument is basically the mirror image of cases 3 and 4.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40528")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("I take back my previous… I think this can work.")

#text("Assume A not blocked by M when |A|>|M| proved for |A|a_i in A.")#linebreak()#text(" If M’ blocks A’ then M’ blocks A, otherwise a_1…a_n,a_{n+1} reaches the end.")#linebreak()#text(" Since M’ blocks A there exists an M subset of M’ where M is a minimal blocker of A.")#linebreak()#text(" Therefore a path in A reaches the last mine im M.")#linebreak()#text(" Exchange a_{n+1} with the a_k which hits this mine to avoid it.")#linebreak()#text(" Therefore M cannot block A’.")#linebreak()#text(" But M’ does block A’, so M’ must be strictly greater than M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40529")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Typo..")#linebreak()#text(" A not blocked by M when |A|>|M| proved when |A|a_i in A.")#linebreak()#text(" If M’ blocks A’ then M’ blocks A, otherwise a_1…a_n,a_{n+1} reaches the end.")#linebreak()#text(" Since M’ blocks A there exists an M subset of M’ where M is a minimal blocker of A.")#linebreak()#text(" Therefore a path in A reaches the last mine im M.")#linebreak()#text(" Exchange a_{n+1} with the a_k which hits this mine to avoid it.")#linebreak()#text(" Therefore M cannot block A’.")#linebreak()#text(" But M’ does block A’, so M’ must be strictly greater than M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40530")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Terry…. please get a wiki this is annoying!!!")

#text("A not blocked by M when |A|>|M| proved when |A| less than or equal to n")

#text("Take WLOG A’=A union a_{n+1} where a_{n+1}>a_i in A.")#linebreak()#text(" If M’ blocks A’ then M’ blocks A, otherwise a_1…a_n,a_{n+1} reaches the end.")#linebreak()#text(" Since M’ blocks A there exists an M subset of M’ where M is a minimal blocker of A.")#linebreak()#text(" Therefore a path in A reaches the last mine im M.")#linebreak()#text(" Exchange a_{n+1} with the a_k which hits this mine to avoid it.")#linebreak()#text(" Therefore M cannot block A’.")#linebreak()#text(" But M’ does block A’, so M’ must be strictly greater than M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40532")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("@David Escott: I say that if a set of mines blocks A’, then it must also block A. If it does not, I take an unbocked path of A and append a_max, which wuld also be unblocked, contradicting the assumption that tis set of mines blocks A’.")

#text("@David Speyer: If there is mine at u greater than t, then u cannot be reached in the original sequence, and n-1 mines cannot block the original sequence by the induction assumption.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40534")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("I think this nearly works. Assume that I can do the case with n (M, s etc). I therefore can jump any set of n-1 mines with a set of n distinct jumps.")

#text("I want to do the case for n+1. I remove the longest jump, leaving me with a distance s’ I can jump with the remaining ones.")

#text("Curioso’s point is that, because I can make sure I jump n-1 mines with at most n jumps, the only way of blocking my n jumps with n mines is for me to land on the last one.")

#text("But I’ve taken out the longest jump, so I replace the jump which landed on the last mine, with the longest jump, which definitely clears it, and there are no mines left to obstruct the rest of the path.")

#text("It looks nice and nearly works, but doesn’t take account of the fact that a mine at s’ acts as a blocker, and there may be other mines beyond it – ie the cases with a mine at distance max a from the far end.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40535")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("David Speyer,")#linebreak()#text(" I am convinced this works… when restricting from A’ to A, you also need to restrict your blocking set. If M’ blocks A’ then M’ blocks A, therefore you can find a subset M of M’ which blocks A which is minimal (nothing can be removed). Curioso then shows that this M doesn’t block A’, but that implies that M is not equal to M’, so M is a strict subset of M’, and |M’| is strictly greater than |M|, which completes the induction hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40536")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Take A = (1,2,3,4) and M = (6,7,8). The induction, as proposed, is to consider A’ = (1,2,3). No matter how we order A’, this jump sequence is blocked at 6, which is not the largest mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40537")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("In terms of Brumm’s solution, the case this doesn’t deal with is the first case.")

#text("If the longest leap doesn’t hit a mine, this is simple and elegant.")

#text("If the longest leap first or last jumps no mines but hits one, solve the remaining part as if this mine is not there, replace the end leap which hits the mine with the longest one to clear it and we’re done – this idea is in Brumm and Curioso.")

#text("It is if the longest leap jumps at least one mine and lands on a mine there is a problem (at either end of course, and don’t forget that the longest leap can be greater than the sum of all the others, or equal to the sum of all the others, in which case this is the same mine both times). If a shorter leap jumps a mine and lands clear the induction follows.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40539")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("@Mark Bennet: You are right. It is not a problem if the blocking set has a mine at s’ and no mines beyond that, the reasoning still works then, but I overlooked the case where there are mines beyond s’.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40516")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("246")

#text("Ref 245 – it is possible to begin the induction with the trivial observation that you can’t block one interval with no mines.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40517")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("True")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40519")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("But I should have added – it looks very neat.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40533")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Curioso’s proof got me thinking along a line that might provide some kind of classification of the structure of the mines.")

#text("M minimal blocking for A")#linebreak()#text(" |M|=m |A|=n")#linebreak()#text(" m_m last mine in M")#linebreak()#text(" Exists path a_1,…a_k that hits m_m and no other mine.")#linebreak()#text(" a_k gt a_{k+i} for i gt 0. Otherwise swap a_k and a_{k+i} to escape.")#linebreak()#text(" Each of a_1+…+a_{k-1}+a_i is mined. Otherwise swap would escape.")

#text("That accounts for k mines related to the tail, that all must occur within a_k of the last mine. Can these be separated from the head in some way? Can we prove that all mines must occur within a_k of the last mine, or is there a ready counter example.")

#text("Among the truths to work with:")#linebreak()#text(" a_1+…+a_{k-1} is not mined.")#linebreak()#text(" Each path a_1…a_{i-1},a_k,a_{i+1},…a_{k-1},a_i hits a mine, at some point.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40540")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("David")

#text("If you are using the Ai equal (1,2,3,4 … n), then you can hit the last mine of a block of n-1 near the end by using the jump (n-1), but you need to use jump (n) to clear it. You have to deal with the case where you’ve used (n) near the beginning.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40541")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("The a_i are ordered by how they appear in the sequence, not by magnitude. In the case you describe a_1=a_k=n, and the statement that “Each of a_1+…+a_{k-1}+a_i is mined. Otherwise swap would escape.” means that 1…n are all mined.")

#text("I know its not helpful to be this terse, but the spam blocker keeps causing problems.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f4a3d12d7dd8396e2e24ca4a348a8719fa8b8dd6dd66f1e759f56bbd500149f-7a9f909d0347c714a63dc084b1ca768a3700e11ce70c7d02d2034787a9a322c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of robert")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40538")[#strong[#text("robert")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Not easy to follow this series of comments; not helpful for someone like me with lesser math ability though i am very keen to know. Has anyone among those commenting solved it? and if so, can someone please post in one entry the complete “user friendly” proof? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40543")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("WARNING")#linebreak()#text(" This is a version of Brumm’s proof with inspiration from Curioso.")#linebreak()#text(" We are trying to find a path for a grasshopper through a minefield. The grasshopper has n distinct leaps of length ai (i = 1,2 .. n). The minefield contains n-1 mines, has length s (the sum of the ai), and no mine in the last place.")#linebreak()#text(" We can trivially negotiate zero mines with one leap (the case n=1).")#linebreak()#text(" We assume that, provided the last place is clear, that we can deal with (n-1) or fewer mines in n leaps, and we want to show that we can deal with n mines in (n+1) leaps.")#linebreak()#text(" We try to make the largest leap.")#linebreak()#text(" Case 1: If the largest leap carries us to a clear space (no mine) and jumps at least one mine, we are left with n leaps and at most (n-1) mines, which we can do by hypothesis.")#linebreak()#text(" Case 2: If the largest leap carries us to a clear space, but doesn’t jump a mine, we work from the other end of the minefield. If we remove the mine closest to the beginning we have (n-1) mines left, and we know that we can negotiate all of these with the n leaps other than the largest (we ignore the blank spaces covered by the largest leap at the beginning).")#linebreak()#text(" If this arrangement also avoids the mine we removed, we are done. If it doesn’t – working from the far end – take the leap which lands on this mine, and replace it by the longest leap, which is longer, and therefore jumps us clear of the mine. There are no mines closer to the beginning than this, so we use any remaining leaps to take us to the beginning and we have a path through.")#linebreak()#text(" Case 3: If the largest leap lands on a mine but doesn’t jump any mines, this is similar to case 2 – this mine is the closest one to the beginning. We can find a path from the far end which lands only on this mine. We look at the leap which takes us there, and swap it with the longest leap to jump clear of it, while the swapped leap takes us to the beginning, and we have our path.")#linebreak()#text(" Case 4: the longest leap lands on a mine and jumps one or more mines. Following brumm’s notation, assume the longest leap jumps f of the mines, with f at least 1.")#linebreak()#text(" We have accounted for f+1 mines (including the one we landed on). So there are (n-f-1) mines out of range of the longest leap.")#linebreak()#text(" Observe there are n other possible leaps from the beginning, all different and shorter than the longest leap, and there are at most f mines in this range to hit, so there are at least (n-f) possible initial leaps which don’t hit a mine.")#linebreak()#text(" For each of those (n-f) possible first leaps, try following with the longest leap, which definitely takes us beyond the first f+1 mines. This gives us (n-f) double jumps of different lengths, but there are just (n-f-1) mines we might hit, so one of these double jumps lands clear.")#linebreak()#text(" This double jump passes at least two mines. So the remaining (n-1) jumps are available to negotiate at most (n-2) mines, and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40544")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("I should also say that the ai are all greater than zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40545")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Observations on solution")

#text("Note that this solution uses two main techniques.")

#text("If we jump a mine using the longest leap, we use the inductive hypothesis for one fewer or two fewer mines, depending on the case.")

#text("If we don’t jump a mine using the longest leap, then we use the inductive hypothesis differently, from the other end of the minefield, and when we reach a block we use the fact that we have the longest leap spare to clear it.")

#text("It is not always true that the longest leap jumps a mine (the easy part of case 2), and it isn’t true that this solution puts the longest leap as close to the beginning as possible. The more difficult part of case 2 requires a short leap to be replaced by the longest leap. If there happened to be another long enough leap available, this could be used instead. The proof could be tidied up to force the longest leap closest to the beginning, by applying the harder part of case 2 only when there is no path for the easier part.")

#text("Only the hard part of case 2 can force the longest leap out of the first two places, so this is unavoidable since I can force the longest leap to be anywhere I choose for the jump set (1,2 …n) by putting all the (n-1) mines together.")

#text("Cases 2 and 3 require the longest leap to be different from another leap so they can be exchanged, and case 4 requires shorter leaps to be distinct for the counting to work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40547")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Some questions")

#text("1 Whether it is possible to classify the cases in which the longest leap cannot be one of the first two in some simple way.")

#text("2 Whether it is possible to reduce the number of cases which have to be considered. Cases 2 and 3 are very similar, for example.")

#text("3 Whether the counting argument in case 4 can be eliminated, or alternatively extended to cover other cases. It seems that case 4 – strangely, since it is the one which engages with most mines most quickly – is the part of the argument which is hardest to see.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40548")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("The above solution was lots of fun to read!")

#text("It suggests the following (stronger) conjecture—a conjecture that might perhaps lead to alternative proof.")

#text("We are given a grasshopper jump-set and a mine-set. We know that there is a least one path-ordering of the grasshopper jump-set that misses all the mines. So if we consider the set of all path-orderings, we know that the fraction ")#emph[#text("f")]#text(" of paths that hit at least one mine is strictly less than unity.")

#text("We conjecture that if we add one more jump to the jump-set, and one more mine to the mine-set, then ")#emph[#text("f")]#text(" decreases.")

#text("Is this (stronger) conjecture true? If so, can it be proved by (perhaps non-constructive) combinatoric arguments? This might lead to a more Tao-esque proof of the original theorem.")

#text("The point is, that oft-times when a proof is achieved, the fun is just beginning! :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40549")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("A similar conjecture might suggest that f decreases as s (the length of the minefield) increases, keeping n the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/914c459b8303f733c97b8f66e20143119e90f2997df4fece3560d18191db8f9d-9f9352973d40fb7977c9ca267e25b7e5047d2278800b2a73809480cc7c7b0609.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a.s.")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40550")[#strong[#text("a.s.")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("The conjecture seems to be false. Take A={1..n}, M={2..n}. Clearly, there are (n-2)! paths that miss all the mines. This appears to be “most efficient” minefield (can be easily checked for small n). In this case, f=1-1/(n(n-1)) and it increases to 1 as n goes to infinity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40553")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("If you have a a set of jumps such that all jumps and sums of jumps miss all mines and then add a mine that hits one of the initial jumps and an arbitrary jump then the f will not decrease and in fact it will increase.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40556")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("253")

#text("I still haven’t quite worked out what partalopoulo has been trying to post as a solution, and how it relates to brumm’s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40558")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("sorry 253 was in the wrong place – my browser is playing up.")

#text("What I wanted to say here to Kristal is that it is trivially possible to do such a thing eg if all our jumps are even, and the mines are all in odd places.")

#text("However there may be some more sophisticated version of measure taking n and s as parameters. eg for a particular minefield of length s with n-1 mines take the fraction of (paths through the minefield)/(all possible paths ignoring mines) over all possible jump sets with n jumps. Or do the same over all minefields of length s with n-1 mines. These average out the special cases.")

#text("The question is whether this is at all useful – and whether the special cases create the conditions for density increment/decrement as in the original polymath, and whether this goes anywhere, and whether there is an interesting two- (r-) dimensional generalisation.")

#text("As s increases, the density of the mines decreases, and intuitively there ought to be, on average, more flexibility about getting through. Indeed there are only a maximum 2^n possible places which can be hit by any subset of the jumps, so as s increases above 2^n there is more chance of mines being in places which can never be hit by the grasshopper.")

#text("But i would be interested in generalisations to more than one dimension.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40551")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("250. (skipping some unnumbered comments)")

#text("I wonder if the complement of this theorem is also true, i.e. can any sequence of n leaps be blocked by n mines.")#linebreak()#text(" Insight in this may give insight in the proof we have here, and may give opportunity to simplify it still a bit (I think the counting for case 4 is central to the proof).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40552")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("251.")

#text("in regards to 250 couldn’t you use the n initial jumps as blocking mines and block any sequence by blocking the first step?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b2998bcffc8177489c8ec6d6a7626fb64df094597326e49411769be46619937c-4efccc0eb0bcc79e40a4daa24a2011b51de3cdabf7598e0fec0d7b5ca610596d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jc")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40555")[#strong[#text("jc")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("252. I’ve written up a quick and dirty implementation of Brumm’s algorithm in Mathematica. A “pastebin” of the code is in my website link.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40559")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("253.")

#text("There is a dual form of Bramm’s proof. it based on the fact that we can subtract everything from the sum of the a_i’s and get a copy of the same problem with roughly what happens is that you can replace max a with")#linebreak()#text(" target-max a and let f be the number of mines targe-max a and target.")#linebreak()#text(" I have just lost my write up of the complete proof in the one of the filters I suspect the spam filter perhaps.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40560")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("here is my second attempt at case one of the dual of Bramm’s proof mentioned above")

#text("max a is a mine and f is greater 0. In that case, out of the target-a_i that are not max a (n numbers), at least n-f are not mined (when taken as a first jump). Consider the n double jumps (target–max aa_i != max a, target-max a target). At least n-f of those are not mined on first jump. The number of mines in (0 target -max a) is the number of mines (n) less f less the one for target -max a, yielding n-f-1 which is less than n-f. Thus by counting argument, at least one of the double jumps does not hit a mine on both jumps. This double jump takes two jumps and jumps over f+1 >=2 mines, yielding a problem with n-2 mines and n-1 remaining jumps, which is solved by induction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40561")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("255. second step of dual of Bramm’s proof")

#text("target-max a is not a mine and f>0. Take max a as last jump, yielding problem with n remaining jumps and n-f<n mines, which is solved by induction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40562")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Third step of dual proof:")

#text("target- max a is a mine and f=0. Let max M be the largest mine in M. Construct M’=M\\{max M}. Jump target-max a to target as the last jump and solve the n-problem with the remaining a_i and M’ Let a_x be the last jump of this solution. Exchange max a and a_x (i.e. jump a_x last and max a before that). target -(max a+a_x) is no mine (guaranteed by solution), target-a_x is no mine (because target-a_x is greater than target-max a == max M as above). There are no mines in the rest. We have completed solution for n+1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40563")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("256, Final case of dual proof")

#text("target-max a is not a mine and f=0. As in case 3, construct M’, jump max a last and solve for the remaining a_i and M’. If this solution hits max M in step k, construct a new solution by exchanging step k-1 and the last step (i.e. target-max a). There are no mines after max M, thus the mine is avoided and no new mines are hit. We have completed solution for n+1")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40564")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("257. I should have done this earlier, but I have opened up a wiki page for this project (borrowing space from the polymath1 wiki) at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")[#text("http://michaelnielsen.org/polymath1/index.php?title=Imo_2009_q6")]

#text("In it I have recorded my own proof of the problem (as Proof #1); it would be good to have the other complete proofs up there as well.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ef7eabe5492dd842c1cf5b3fc57c264c1639a092ff614cdf4add46e4ffb5956-c46d08644476dd721e2ce21cc952851f493341f295367ed0d3485e05b18ec822.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro Poggi-Corradini")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40566")[#strong[#text("Pietro Poggi-Corradini")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("Line 10 of Proof 1 in the wiki: “and suppose that the grasshopper is already known to be immune to order 1” should that be j? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40568")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("258.")

#text("I looked at proof #1 in the wiki I think I might be able to find a dual for it the same way in posts 253 to 256 I found a dual for Bramm’s proof. I think mosts proofs would have duals.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21f981115eac23de64b0e57c9b310ac1a594a81242e2a7e7141f394cac10458f-62196923690a4a2e62fd0b0bbed8d60ae479c394bd19e7c6bea25a289fcbc9c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Moskovich")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40578")[#strong[#text("Daniel Moskovich")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("I just saw the thread… beautiful proof, actually- like any good proof, it looks obvious after you’ve seen it (although not before).")#linebreak()#text(" I wonder what the generalization would be to other lattices. So you would be allowed to move ")#mi("a_1,\\ldots, a_n")#text(" units along the lattice, and the goal would be to hit any point at distance $\\latex a_1+a_2+\\cdots+a_n$ from where you started. How many mines would it take to block you?")#linebreak()#text(" Of course there are many other generalizations possible… one might wonder what happens if one restricts to lattices consisting of integer points in ")#mi("\\mathbb{R}^n")#text(", or allow only certain moves (only in straight lines, or something).")#linebreak()#text(" I also wonder whether there is a continuous version of the problem, although I have no idea what it might look like.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21f981115eac23de64b0e57c9b310ac1a594a81242e2a7e7141f394cac10458f-62196923690a4a2e62fd0b0bbed8d60ae479c394bd19e7c6bea25a289fcbc9c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Moskovich")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40586")[#strong[#text("Daniel Moskovich")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Maybe in fact the natural generalization is to consider graphs, and one is allowed to jump ")#mi("a_1,\\ldots,a_n")#text(" units along the graph. The objective is to reach any vertex at distance $a_1+\\cdots+a_n$ from the initial point (Q6 corresponds to the graph with ")#mi("a_1+\\cdots+a_n")#text(" vertices with 2 vertices of valence 1 and all other vertices of valence 2). This encapsulates all generalizations considered so far (I think, unless somebody has mentioned this already).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40613")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("If there were a single objective vertex and a transformation T interchanging the starting vertex and the objective vertex while preserving the structure needed for the problem then the transformed problem would be the dual problem and each step of the proof S would have a dual step")#linebreak()#text(" TST^-1 thus giving a dual proof.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/21f981115eac23de64b0e57c9b310ac1a594a81242e2a7e7141f394cac10458f-62196923690a4a2e62fd0b0bbed8d60ae479c394bd19e7c6bea25a289fcbc9c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Moskovich")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40676")[#strong[#text("Daniel Moskovich")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("Kristal Cantwell:")

#text("I can always assume that the number of terminal vertices is 1 by identifying them. For a graph which admits an involution which exchanges the initial and terminal vertex, you and invert the solution… perhaps these are the only graphs for which the problem is interesting.")#linebreak()#text(" The 2-dimensional case seems the first to tackle- get to distance ")#mi("a_1+\\cdots+a_n")#text(" from (0,0), where you can move $a_1,\\ldots,a_n$ units along the lattice. There are some silly trivial upper bounds on the number of mines which would block the grasshopper, but I don’t know the actual number, much less how to prove it…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40592")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("259. I am still trying to simplify the proof.")

#text("We have a set of n jumps a_i and a set of n-1 mines m_j.")#linebreak()#text(" Let s be the sum of the a_i.")

#text("Assume we have a blocking set of n-1 mines m_j.")#linebreak()#text(" Then we can take out an a_i such hat there is no mine at s-a_i (because there are more a_i than mines), and take out the last mine. Now these reduced sets must still be blocking, otherwise we could just take an unblocked path, add back the mine (which is not at the final point of the path), and add the jump we have removed.")#linebreak()#text(" So by induction the blocking set of n-1 mines cannot exist.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brumm")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40594")[#strong[#text("brumm")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("I think you keep slipping into the same hole again and again. There’s no need for the mines to behave nicely, they can cluster as they want.")

#text("In your case consider A=(5,6,7), s=18, M=(16,17). You take out the mine at 17 but the mine at 16 does not block A=(5,6).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40599")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("@Brumm: But mines 16,17 are not blocking the jumps 5,6,7.")

#text("But I see the problem, you cannot just put back the mine, it might be somewhere else on the path..")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8a3013f4429139a123a3bec6970d804cd2804710e3ca5db26b43e1fa703bd46-36c5da777bb851e4b79cc21d9381f2ed464040c237c5a6e2e64fa4782c4175d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aj")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40593")[#strong[#text("aj")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Since I lost out on coming up with a proof, I thought it’d be fun to redo Bramm’s proof as a program, which I wrote up on ")#link("http://www.erisian.com.au/wordpress/2009/07/23/solving-hard-maths-olympiad-problems")[#text("my blog")]#text(". While I was writing the code, a few of the cases collapsed, making, I think, for a potentially nicer proof.")

#text("I think it should be plausible to do just two cases: where min(m)<max(a) and max(a) is mined; and where you can rearrange the path for the smaller problem (a-max(a),m-min(m)) (label that path as p), as x,max(a),y, where p=y+x and x is the first step in the path after min(m).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40601")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("aj")

#text("You might want to add this comment to the wiki, with the link – I put in a link to your program.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77f7946f9ae888012c14e790fd0140ae8ccfe256f8a4dc7b5a9d51e0200c8c83-9c4ba5b6f9bcebb67c07e29f9252696b1e5d4ffe6cd502a005228c0eee83e099.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Hartley")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40598")[#strong[#text("Ralph Hartley")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("OK what happens if we remove the constraint that the a_i (and M) all be positive?")#linebreak()#text(" Under what condition is there a solution with m mines?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40600")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("262 Reply to Ralph Hartley")

#text("Are you allowed to step outside the minefield on your path? Can you go beyond the end and come back, or jump onto negative integers.")#linebreak()#text(" Query where are you placing your mines – can they go on negative integers or beyond point s?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe84d8480ff4dcc22b8daf0b230056880d4e9296b6a8a3382024cb745c76862b-6e79261126b30f79d32a26471d281e4c4a134347d547b595ce714c280bf0381e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luka Lasic")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40602")[#strong[#text("Luka Lasic")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("ind. proof of question 6. IMO")

#text("def. S_{k} = Sum of every a_{i } excluding only one a_{k}")

#text("Clearly, exists S_{k} which is not in M.")

#text("Induction step on A’ := A \\ { a_{k} } and M’ := M \\ { m_ {i} }")

#text("leads to solution with a_{k} on the last place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8a3013f4429139a123a3bec6970d804cd2804710e3ca5db26b43e1fa703bd46-36c5da777bb851e4b79cc21d9381f2ed464040c237c5a6e2e64fa4782c4175d7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of aj")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40604")[#strong[#text("aj")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("@Mark Bennet 6:13am; written up and added to proof page! What fun!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40607")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("This sounds the same as what I tried in 259. This fails because you cannot put back m_{i} with the guarantee that the sequence of jumps for A’ does not land on it, at least I do not see that guarantee.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40611")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("264.")

#text("I have added the dual of Bramm’s proof to the wiki. I think most proofs will have an associated dual.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe84d8480ff4dcc22b8daf0b230056880d4e9296b6a8a3382024cb745c76862b-6e79261126b30f79d32a26471d281e4c4a134347d547b595ce714c280bf0381e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luka Lasic")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40612")[#strong[#text("Luka Lasic")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("@Curioso In induction step A’ is fixed, but M’ has free choise of")

#text("on the term m_{i} ( excluded from M ).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40615")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("You have a solution for A if m_{i} > S_{k}. But what do you do if m_{i} < S_{k}, i.e. how do you make sure it is not on one of the jumping pints of the solution for A'?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ef7eabe5492dd842c1cf5b3fc57c264c1639a092ff614cdf4add46e4ffb5956-c46d08644476dd721e2ce21cc952851f493341f295367ed0d3485e05b18ec822.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pietro Poggi-Corradini")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40618")[#strong[#text("Pietro Poggi-Corradini")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Possible variant to proof 1: redefine “immune of order j” to mean that there exists a given subset of the a’s with j elements that can be re-odered so as to avoid the n-1 mines. Now assume that no subsets with j+1 elements is immune. By induction hypothesis there is one subset with j elements that is immune (and ends say at s_j). Extend it using one of the remaining n-j jumps. They all land on mines, meaning that there are n-j mines to the left of s_j, but doesn’t this contradict assumption A in reverse. I might be doing something wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40630")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Dear Pietro,")

#text("The n-j mines are to the right of s_j, rather than to the left. But the more serious issue, I think, is that we don’t know that the grasshopper can safely reach s_j in n-j steps from the right, rather than from j steps on the left, so the dual of Assumption A does not seem to apply here.")

#text("It is instructive to see what happens when ")#mi("a_i = i")#text(" and the blocking set M takes the form ")#mi("\\{ r+1,\\ldots,r+n-1\\}")#text(" for some medium-sized r. Then it’s quite possible to reach r in a manner that uses up the n jump, and then get stuck, without any obvious violation of Assumption A or its dual at this point. One has to take a more “global” view and look at all the possible places the grasshopper can reach in j steps at once in order to see the Assumption A violation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e942430ff1257ac41f2cb8b03de7d52203ef174c36ddbff15f615d8ab4914902-8ddc25447f5bfeef892b40ed87c269f9cb4ec46df0a94ba282313a4ca3c594ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pietropc")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40636")[#strong[#text("pietropc")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("Thanks and sorry for the typos in my previous comment. I finally understand Proof 1, I think. You might want to state explicitly that ")#mi("a_1<a_2\\cdots<a_n")#text(": this seems to be crucial to keep ")#mi("M\\cap S_j")#text(" disjoint from ")#mi("\\{a_i+a_{n-j+1}+\\cdots+a_n\\}")#text(". Finally a small quibble, in line -3, \"by Assumption A\" should this be \"by induction hypothesis\"?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of IMO 2009 Q6 mini-polymath project: impressions, reflections, analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40620")[#strong[#text("IMO 2009 Q6 mini-polymath project: impressions, reflections, analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("[…] | by Terence Tao The mini-polymath project to find solutions to Problem 6 of the 2009 IMO is still ongoing, but I thought that, while the memories of the experience are still fresh, it would be a good time […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f29ba14cd1d7683a36e37de6d86d09fcfdf6c43bfa90131458f5c3be9bd5a8b-f17dc65da42ab0516f162831003a0ddf149c52737db601c34f181aea64bf96d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Ghose")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40633")[#strong[#text("Abhishek Ghose")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("267.")

#text("Unfortunately, I am seeing this problem very late (I stumbled across this blog only yesterday). I had a quick thought regarding this, and I could only give a cursory glance over at the comments (given their now huge number – things probably work out better if you’re involved from the start :) ). The post by Richard(117) seems to be quite close to what I have in mind.")

#text("For every possible permutation of {a0,…,an}, we define a conflict set as one containing all the numbers in the number line the grasshopper steps on when following this particular stepping order/permutation. Clearly, if M contains at least one element from some conflict set, the corresponding permutation is unusable. For all possible permutations to be unusable M must contain at least one element from the conflict sets of each of these permutations. If we can prove that the minimum possible size of such an ideal M (that renders every permutation unusable) is greater than n-1, we are done.")

#text("The tricky part, of course, is to find the minimum sized M. Especially, since some ‘conflict elements’ might be common across different permutations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f29ba14cd1d7683a36e37de6d86d09fcfdf6c43bfa90131458f5c3be9bd5a8b-f17dc65da42ab0516f162831003a0ddf149c52737db601c34f181aea64bf96d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abhishek Ghose")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40634")[#strong[#text("Abhishek Ghose")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")])]

#text("(Missed copying the last sentence from my text editor :) )")

#text("Pigeonhole or Induction for finding the minimum size may be viable approaches?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40635")[#strong[#text("Terence Tao’s polymath experiment « Mathematical Remarks")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2009")]

#text("[…] Terence Tao’s polymath experiment Published July 24, 2009 Uncategorized Leave a Comment I’m having fun following this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40640")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("I’ve put some comments on the proofs in the discussion part of the Wiki – do add comments and correct errors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9db5d6d53a26b6c7978772ca37c13f3d152b1f143f85a85a3ec3457e3a8df300-d43fc4b9a9142e08f6f9b3f175dc37ffaf12375609327954d1e998ec6d85cfb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40647")[#strong[#text("Juan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Hi!")#linebreak()#text(" I don’t understand Tao’s proof. More specifically, I don’t get the last sentence “But this forces M to contain n distinct elements, a contradiction.”")

#text("Can anyone elaborate the point a little further for me, please?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac50f5bbbd50c08dbc00e806b3035c082de46665d8d9431664a171971baeb15f-fdc2a50d536e6684604b70d17622611c33032d8a1fc3fbcd47c03ad51f3f1f66.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex and Ecki")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40648")[#strong[#text("Alex and Ecki")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("We looked at proof #1 and have an additional suggestion to pietropc’s suggestions in his post: in the last paragraph one should chose i as the greatest element rather than smallest (or change ")#mi("a_i+a_{n-j+1}+\\ldots+a_{n-1}")#text(" to ")#mi("a_i+a_{n-j+2}+\\ldots+a_{n}")#text(") to ensure that all the following numbers are distinct from each other.")

#text("It might be nice to make the three groups of numbers that lie in M which are n numbers in total more explicit: 1. ")#mi("a_i+a_{n-j+1}+\\ldots+a_{n}")#text(" for ")#mi("i \\notin I")#text(", 2. ")#mi("a_i+a_{n-j+1}+\\ldots+a_{n-1}")#text(" for ")#mi("i \\in I")#text(" and 3. for the biggest ")#mi("i \\in I")#text(" the numbers ")#mi("a_i+a_{n-j+1}+\\ldots+a_n - a_m")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40658")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Thanks for all the corrections and suggestions! I’ve updated the proof accordingly (but of course you are welcome to make future corrections directly, if you wish).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40649")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Here is another proof. We remove the largest mine and the largest step a_max. We apply induction. Two things can happen we hit the largest mine or we reach the sum of all the a_i’s(target) minus the largest step a_max. If we hit the largest mine we swap the last step for the largest step and we skip over the largest mine then we just continue till we are done. If we go to the the sum of all the a_i’s except the largest step and it is not a mine we add one more step and we are done. If it is a mine and we replace the last step with a_max and we don’t land on a mine then we take one more step then we are done.")

#text("We have one case left where target – a_max is a mine and there is one or more mines greater than target – a_max call the number of these mines f.")#linebreak()#text(" Then what remains is case one of the dual proof which we solve as follows:")

#text("max a is a mine and f is greater 0. In that case, out of the target-a_i that are not max a (n numbers), at least n-f are not mined (when taken as a first jump). Consider the n double jumps (target–max aa_i != max a, target-max a target). At least n-f of those are not mined on first jump. The number of mines in (0 target -max a) is the number of mines (n) less f less the one for target -max a, yielding n-f-1 which is less than n-f. Thus by counting argument, at least one of the double jumps does not hit a mine on both jumps. This double jump takes two jumps and jumps over f+1 >=2 mines, yielding a problem with n-2 mines and n-1 remaining jumps, which is solved by induction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40678")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("I just added this to the wiki.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9db5d6d53a26b6c7978772ca37c13f3d152b1f143f85a85a3ec3457e3a8df300-d43fc4b9a9142e08f6f9b3f175dc37ffaf12375609327954d1e998ec6d85cfb0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Juan")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40650")[#strong[#text("Juan")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Thanks, Alex & Ecki! Now I get it. It’s a beautiful proof!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40655")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("If I have a set of positive integers {A1 … Am} sum Sa and another {B1 … Bn} sum Sb (Ai distinct, Bj distinct), a jump in a two dimensional space involves moving (Ai,Bj), I start at (0,0) and there is no mine at (Sa,Sb) – what is the minimum number of mines I need to block.")

#text("(maxA x maxB) can block by putting a rectangle starting at (1,1). Can I always dodge (MaxA x MaxB)-1?")

#text("This looks rather easy, for example, I can avoid some rectangles of size (MaxA x MaxB) entirely.")

#text("Further dimensions diminish the density of the mines. So is there an interesting generalisation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40707")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("If the sums are distinct then it looks like you need all nxn mines or in k dimensions n^k so if you don’t need nxn points in all cases the number you need will depend on whether the sums are distinct. I don’t know of a counterexample requiring less then nxn mines. The problem looks interesting.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Lessa")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40665")[#strong[#text("Pablo Lessa")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("In the end I couldn’t help myself and had to follow through on the study of the special case $A = \\{1,2,\\ldots,n\\}$.")

#text("In the case $n$ odd, the pigeonhole principle provides at least one residue class modulo ")#mi("n")#text(" without landmines. I was able to prove that there is a path that steps on each point of one of these “safe” residue classes (in the interval $0,n(n+1)/2$ of course) while avoiding all landmines.")

#text("In the case $n$ I use instead a “safe” residue class modulo $n+1$ and obtain the same result.")

#text("The proof was based on dividing the jumps into pairs adding up to the same number, and asigning a different pair of jumps to each of the intervals between the elements of the safe residue class. There is a simple counting argument that shows that this can be done.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40668")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2009")])]

#text("Pablo")

#text("I think you may be assuming that the jumps are {1,2 … n-1}, which seems to be the toughest case.")#linebreak()#text(" If the jumps are {1,2,4 …. 2^(n-1)} there are no two pairs with the same sum.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pablo Lessa")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40709")[#strong[#text("Pablo Lessa")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2009")])]

#text("I’m assuming exactly that.")

#text("The point is that in that case there is a different proof that exploits the fact that there are many ways of obtaining the same sum.")

#text("In fact, one may view the argument as being based on ")#mi("1+2+3+4+5+6 = (1+6) + (2+5) + (3+4)")#text(" (in the even case… in the odd case it would be ")#mi("1+2+3+4+5 = (0+5) + (1+4) + (2+3)")#text(").")

#text("The result seems to show that an apparent disadvantage (i.e. a single mine can block many paths) may actually be an advantage (i.e. we can find a solution that fulfills the aditional restriction of touching all points in a certain residue class).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40670")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("Are there any thoughts on the best approach for a grasshopper who can detect whether the next jump will land on a mine, and can count the number of mines passed – are there efficient algorithms for getting through the minefield?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57cca5c5678d9bac1049bd1d93337ac3afa45251ae5858ba29ac53e17826cb0f-e636e956d73d039200705d08ad7aadab49e2acbfe85907e40b57c7fe4f8c68a9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Curioso")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40675")[#strong[#text("Curioso")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("You cannot determine a safe path for the grasshopper based on local information only, you need to take a global view. Let s be the sum of the a_i, put the mines on s-a_1, s-a_2 … s-a_n, except for one place s-a_i that you leave empty. The grasshopper does not know which a_i until it makes the jump into the minefield, but then it is not certain that it still has a_i available to jump over the rest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40677")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("So the grasshopper is allowed to backtrack.")

#text("The answer will depend on what the grasshopper is allowed to remember.")

#text("A brute force search (try everything until something succeeds) will always find any path which exists.")

#text("How do these two strategies work out:")

#text("1. If I have a choice, always use the longest leap I can")#linebreak()#text(" 2. If I have a choice, always use the shortest leap I can")

#text("In each case, when blocked, backtrack as little as possible for an option, and use the next leap in the list.")

#text("In longest leap first, if I encounter a block of r mines, and I am allowed to remember it is there, I can add ‘if I have not passed the block, make sure I have a leap of length at least r+1 in hand.’")

#text("In shortest leap first, I keep the long leaps in hand.")

#text("There are always ‘bad’ configurations, like the one which forces the last leap by blocking all other possibilities with mines near the end.")

#text("Is there a good measure of the effectiveness of a strategy?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-2/#comment-40671")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 25 July 2009")])]

#text("Does the problem make sense over a finite field rather than the integers? It looks that the arguments use the order structur of integers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SW")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40415")[#strong[#text("SW")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("201. A few comments (2, 141b etc) have suggested taking a topological approach, viewing partial sums of the ")#mi("a_i")#text(" as subsets of ")#mi("\\{1...n\\}")#text(" and thus as vertices on the n-cube. Each vertex/subset gets mapped to the integers by the sum function, and one can therefore take a quotient of the graph by identifying vertices with the same sum. The problem then would seem to deal with the number of vertices one might remove in order to disconnect the empty set vertex with the opposite corner.")

#text("My comment is that the grasshopper cannot move backward, whereas one might do so on the n-cube. Thus showing that removing n-1 vertices from the quotient cannot disconnect is not sufficient. You could change it to a directed graph, but then Menger’s theorem on graph connectivity does not seem to apply and the topology becomes more complicated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SW")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40417")[#strong[#text("SW")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("202. Another line of thought has focused on figuring out how to place ")#mi("a_n")#text(" (or some other big jump) so that it can jump the maximum number of mines.")

#text("If we can use the first or last jump to jump a mine we are done by induction, so we may as well assume that we cannot (in particular, both ")#mi("a_n")#text(" and ")#mi("s-a_n")#text(" are henceforth assumed to be in ")#mi("M")#text("). That means we have ")#mi("n-2")#text(" jumps in the middle to hop over ")#mi("n-1")#text(" mines; at least one jump must go over 2 mines. A few comments have asked if we can prove that there must be two mines close enough to be jumped simultaneously (answer: yes) and also whether it must be the case that we can choose ")#mi("a_n")#text(" to be one of the jumps that does so (answer: no; see comment 150, but note that this example is one in which the easy induction argument applies, so perhaps if we avoid these cases…?).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40418")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("201. Status")

#text("It appears that there are two (related) proposed solutions standing at this time.")

#text("(1) The first is contained in posts 125 and 129, with follow up threads at 130, 131, 132, 136, 137, 138, 141, 149, 151.")

#text("(2) The second is contained in the posts “Raghu 7:37 am” and 141 (8:06 am).")

#text("Can I suggest that we take a look at these and either turn them into clean proofs or identify any issues? Of course, this should not discourage other approaches/discusion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0c473d67cde178c94599095e3a8c54e04bd59b868d9c6521df465ab302d3122-c12b256352bd50a2926a14a1d7011017d09092221e86f204cf38a758857e2844.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raghu")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40419")[#strong[#text("Raghu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("202. I posted an argument in comment 144 (")#link("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/#comment-40403")[#text("https://terrytao.wordpress.com/2009/07/20/imo-2009-q6-as-a-mini-polymath-project/#comment-40403")]#text(") but there is a mistake in it. There’s perhaps something to salvage. Here’s a summary of the approach suggested by Gowers and others.")

#text("Approach: Show that for 0 < k < n we can take k steps without hitting a mine.")

#text("For induction suppose we can take k-1 steps ")#mi("a_1, ...,a_{k-1}")#text(" and ")#mi("s = a_1 + a_2 + ... + a_{k-1}")#text(". The point now is that if we can't take one more step then ")#mi("s+a_k, s+a_{k+1},...,s+a_n")#text(" must all be mines so that many mines are within one 'interval'. Perhaps there's a way of exploiting it ….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40421")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("204 – ref 202")

#text("An and s-An could be empty, rather than in M, and it would still prevent the induction going through. This bunches things up in the middle, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b888be0be275de5b3877f2e54e8a21aa0f26ea8eaf6930d9e9785ec9273e89fe-94ad56e80e6f291631307c33b1a9f07dbcd8e93d22127df52e56af95222fbec0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Louigi")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40422")[#strong[#text("Louigi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("205. A small observation, not terribly linked to either of the approaches described above. Suppose that ")#mi("a_1 < a_2 < \\ldots < a_n")#text(" and that the landmines are at ")#mi("m_1 < m_2 < \\ldots < m_{n-1}")#text(". Choose a sequence of steps that avoids as many land mines as possible, and suppose it lands on some mine ")#mi("m_i")#text(". If the last step (the one that leads the walk to land on ")#mi("m_i")#text(" is ")#mi("a_j")#text(" then the walk must also have used ")#mi("a_{j+1},\\ldots,a_n")#text(". Otherwise, we could replace that last step by a large last step and avoid an additional mine (")#mi("m_i")#text("). I don't know exactly what to do with this. Maybe let ")#mi("a_k")#text(" be the largest unused step and replace one of the used steps with ")#mi("a_k")#text(" to avoid ")#mi("m_i")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40423")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("If you are looking at the problem for n and your are looking at the sums of n-1 elements then the sum of the largest n-1 elements cannot be in M. If it is any of the other sums of n-1 elements is missing from M then it will take n elements to block the set of n-1 elements making up the sum by induction so all such numbers must be in M but that gives a total of n elements and M has n-1. So the sum of the largest n-1 elements is not in M and further by induction that means that it will take n elements to block the set of the n-1 elements making up the sum by induction so what we have is that every element of M is the sum of n-2 or less elements of the set of the n-1 largest elements of the n set a_n. I am not sure useful this is though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40428")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("206. Another attempt at a summary, I’ll go ahead and say that I’m biased to try to find a solution for ")#mi("A = \\{1,\\ldots,n\\}")#text(":")#linebreak()#text(" ———")

#text("One of the main obstacles in this problem is that diferent subsets of the set ")#mi("A")#text(" may have the same sum, and therefore a single landmine may block several paths.")

#text("In accordance with this, the case ")#mi("A = \\{1,2,4,\\ldots, 2^{n-1}\\}")#text(" (in which all subsets have different sums) has been solved by a simple counting argument (see 27).")

#text("Also, numerical experiments have shown that, in general, landmines can block a substantial number of paths and this has casted a lot of doubt on the possible success of counting arguments (e.g. 71,72,73).")

#text("All this experience seems to indicate that the worst possible case is ")#mi("A=\\{1,\\ldots, n\\}")#text(".")

#text("— Progress for ")#mi("A = \\{1,\\ldots, n\\}")#text(" —")

#text("This case has been solved in self contained manner for ")#mi("n \\le 4")#text(" but the arguments don’t seem to generalize (18,60).")

#text("For larger ")#mi("n")#text(" it was pointed out that there exists a residue class modulo ")#mi("n")#text(" without landmines. Also an argument was given for ")#mi("n = 5")#text(" but it’s not self contained and seems to rely on the inductive argument explained below (124).")

#text("None of the arguments given seem to generalize easily for larger ")#mi("n")#text(" although they haven’t been explored in depth.")

#text("The special case in which there are ")#mi("n-1")#text(" consecutive landmines has been singled out a couple of times (e.g. 51). It shows that one cannot choose the first (or last) step arbitrarily among the available options, and therefore proposed solutions that do so, must be examined carefully.")

#text("— Induction —")

#text("Let’s return to general ")#mi("A")#text(".")

#text("In the attempt to find a way to use induction, the following lemma was identified several times (e.g. 112):")

#text("“If we can jump over ")#mi("k")#text(" or more landmines with ")#mi("k")#text(" jumps then induction can be used to complete the solution”")

#text("Also there is an obvious “forward-backward” symmetry that can be exploited in certain cases.")

#text("— Reformulations —")

#text("A number of abstract formulations of the problem have appeared. The most discussed deals with the cube ")#mi("\\{0,1\\}^n")#text(" or quotients of it. Out of this a subdiscussion involving Mengers theorem grew, but I am not qualified to comment on it (see 201).")

#text("— Proposed proofs —")

#text("There are a couple of proposed proofs:")

#text("One of the comments numbered 140. (the one by liuxiaochuan) seems to me to give a clear argument that we can jump at least twice, but I couldn’t quite get the following inductive step.")

#text("Another proposed proof starts off by removing ")#mi("a_i")#text(" from ")#mi("A")#text(" and the largest landmine ")#mi("m_{n-1}")#text(" from ")#mi("M")#text(". The number ")#mi("a_i")#text(" is choosen so that ")#mi("a_1+\\ldots + a_n - a_i \\notin M")#text(".")

#text("The next step in this proposed proof is to use induction to find a path avoiding ")#mi("M \\setminus \\{m_{n-1}\\}")#text(" and ending at ")#mi("a_1+\\ldots+a_{n} - a_i")#text(".")

#text("The final step in the argument is to modify this path (half of it actually) in order to avoid the remaining landmine.")

#text("The implicit concensus seems to be that the proposed proofs aren’t quite correct yet, but might be fixable. Both of them (but especially the first one) seem to run in to the problem of choosing the first or last step arbitrarily based on local infomatin (see above, and also 51.).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liu xiaochuan")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40429")[#strong[#text("liu xiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("206 I just can’t leave any comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liu xiaochuan")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40431")[#strong[#text("liu xiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("207 I have tried at least twenty times to leave a comment and still can’t see them, though it always tell me that I duplicated the same comment.I guess the same situation happens to David,too. Maybe it is because our comments are too lengthy,since the last one is ok.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40432")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("207. Logistical Question: How does the (one level of) comment threading work?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liu xiaochuan")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40440")[#strong[#text("liu xiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Let ")#mi("a_1<a_2<\\cdots<a_n")#text(".")#linebreak()#text(" 1,")#mi("a_1")#text("can't be blocked, otherwise we can choose our first step to left a landmine behind, finish the inductive step.")

#text("2, Two sets ")#mi("A=\\{a_2,\\cdots,a_n\\}")#text(" and ")#mi("B=a_1+a_2,\\cdots,a_1+a_n")#text(" contains at least n different values. we claim that the elements in B should not be all blocked. otherwise we can choose the first step with ")#mi("a_i")#text(" and then ")#mi("a_i+a_n")#text(" leaving all landmines behind.")

#text("3,so, we can at least get to the second group withour being killed. then we claim that ")#mi("a_1+a_2")#text(" and ")#mi("a_1+a_3")#text(" can't be all blocked. otherwise we can take two steps and leave two landmines behind and finish the inductive step.")

#text("4, through ")#mi("a_1+a_2")#text(" or ")#mi("a_1+a_3")#text(", we can get to")#linebreak()#text(" ")#mi("a_1+a_2+a_3,a_1+a_2+a_4,a_1+a_2+a_n")#text(",")#linebreak()#text(" ")#mi("\\cdots,a_1+a_3+a_4,\\cdots,a_1+a_3+a_n")#text(" which contains at least n-1 different values. Similarly, if all of these are blocked, then we can construct a way to avoid all of the landmines. So, we can get to one of these by the third step.")

#text("5, then we analyze ")#mi("a_1+a_2+a_3,a_1+a_2+a_4,and a_1+a_3+a_4")#text(" in the similar fasion and continue in the road.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40441")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("208.")

#text("I think there is a length based filter. I have problems with longer posts being held up. I now try to break them up. I am not sure what length triggers the filter.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40442")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("208")

#text("Can I put in a word for creating an equivalence relation between solutions, which allows any solution to be reduced to something trivial. [A solution is a configuration Ai, n, s, M; together with a specific path through the minefield] (see 143, 144-148) and some machinery to order configurations so we can prove the non-existence of a minimal counterexample.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca116084471cf4cfe891c1e62a2641c04658f6bdc15b508384b665576a566745-6b81ac9a31e72c42c95cc6a8c1abfbe5da141e0c999c1c22d952da7c5e991814.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristina")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40443")[#strong[#text("Cristina")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("I was not able to leave a comment, either — curious if this is going through.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40445")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("209")

#text("In fact, does ordering solutions to find a minimal counterexample help anyway.")

#text("Look at this possibility:")

#text("First we choose the minimum value of n for a counterexample.")#linebreak()#text(" Amongst such values of n we choose the Ai and M so that we can choose a permutation of the Ai which minimises the number of hits on mines over all counterexamples for such n.")#linebreak()#text(" Then “all” we need to achieve is a rearrangement which avoids one hit, and we’re done.")

#text("Or maybe minimising n is irrelevant, and a counterexample with the minimum number of hits is the thing. Then there might be some flexibility to jiggle the proposed counterexample in a reversible manner to prove that it was not minimal.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca116084471cf4cfe891c1e62a2641c04658f6bdc15b508384b665576a566745-6b81ac9a31e72c42c95cc6a8c1abfbe5da141e0c999c1c22d952da7c5e991814.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristina")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40446")[#strong[#text("Cristina")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("209.Bit of a tangential idea to some posts (eg.Raghu, Gowers) based on the fact that the elements in A are distinct-maybe can be used to fix some things.")#linebreak()#text(" If no permutations exist, then k<n exists for which all arrangements of k elements from A lead to an impasse: a1+a2+…+ak=mi, where mi is one of the elements in M (we'll have n!/(n-k)! such sums/equalities)")#linebreak()#text(" Maybe these partial sums being simultaneously equal to elements from M leads to an equality of the form ai=aj, which is contrary to the original hypothesis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40447")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("210. It looks like the server was holding back some posts (because of length?). I apologize for the repetition, but there were constantly problems with my posts (missing text, latex code not appearing etc.).")

#text("I will attempt to post the suggestive the suggested proof as a whole again. I’ll avoid using latex so that there will be no missing text. I also rewrote the last part of it to make it clearer.")

#text("This will be done in 2-3 posts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40448")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Induct on n. For n=2 see post 4@Lugo and for n=3 see post 18@gowers. Assume it holds for 2,3,…,n-1. Let M and A={a_1,…,a_n} be as in the statement. Set m=max(M). WLOG assume that m<s. We have that at least one of the numbers S-a_i is NOT contained in M, since card(M)<n. WLOG assume that S-a_n is the one not contained in M.")

#text("Set M'=M-{m} and A'=A-{a_n}. Apply the induction hypothesis on A' and M'. So there exists some permutation t in S_{n-1} so that the numbers S_j:=a_{t(1)}+…+a_{t(j)} do not belong to M'.")

#text("If S_{n-1}=a_1+\\cdots a_{n-1}<max(M'), we are done (choose a_n as the last step), so assume this is not the case. Also, if max(M')")#text("1).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40449")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Mark (208),")

#text("Isn’t your equivalence relation going to reduce all paths to one big jump. Doesn’t it just say that all successful solutions are equivalent in that they are successful. Did I miss something?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40451")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Let me try to address proposed solution (2) listed in the summary post 201. The original posts are “Raghu 7:37 am” and 141 (8:06 am).")

#text("The author writes: Suppose that you can take ")#mi("k-1")#text(" steps ")#mi("a_1, a_2, \\ldots, a_{k-1}")#text(" (in that order) without hitting a mine. Let ")#mi("a_k < a_{k+1} ... < a_n")#text(" be the remaining possible steps and let ")#mi("s = a_1 +a_2 + \\ldots + a_n")#text(". Now a strong observation is that if any of the ")#mi("s+a_k, s+ a_{k+1}, \\ldots, s+ a_{n}")#text(" is not a mine we are done.")

#text("I think this last assertion is false. In order to perform the induction we need to remove an element from ")#mi("A")#text(" (this element is ")#mi("a_n")#text(" above) AND a mine. The problem (which has come up before) is that when we include this mine back in it may destroy the path of elements ")#mi("a_1, \\ldots, a_{n-1}")#text(" we obtain from the previous case of the induction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64647729883096ef829622aa41070800a42c787cf0ee79b1d3b7c2331dba4e23-1ba7fa063a00390f9bcecc416d9bbb128795b7dfef5e6d61451667326512707d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PhilG")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40453")[#strong[#text("PhilG")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("213. “half-dozen or so managed to solve this problem completely”")#linebreak()#text(" There could be a non-obvious observation that resolves this quickly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ca116084471cf4cfe891c1e62a2641c04658f6bdc15b508384b665576a566745-6b81ac9a31e72c42c95cc6a8c1abfbe5da141e0c999c1c22d952da7c5e991814.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Cristina")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40454")[#strong[#text("Cristina")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("What if the fact that all the possible partial sums at a step k (for any initial a1) take to a mine leads to an equality between two of elements in A, which is contrary to the hypothesis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40456")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("215 partalopoulo 210– Thanks for offering to repose your idea. I was having some trouble following it towards the end (particularly, I assume the 12 was a typo?) — maybe you could reword the last paragraph?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40457")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("216 I believe there should be a correspondence of minimal blocking sets constructed as follows:")#linebreak()#text(" Let M={m_1<m_2…<m_n} be minimal blocking set. Let F=sum(a_i). Then if we remove m_k from M we allow at least one path. Furthermore all these paths must pass through m_k, just as all paths must pass through start=0 and finish=F. Therefore, I think we can shuffle these minimal blocking sets")

#text("Construct M'={F-m_i|ik} union {F-m_k}. I believe it should still block.")

#text("Can this symmetry perhaps be used to get the minimal blocking set into a nice form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brumm")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40458")[#strong[#text("brumm")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("SPOILER Complete proof")

#text("Induction: Case n is already proved -> Case n+1")#linebreak()#text(" (Induction start is trivial)")

#text("We make no further assumptions about M and a_i (i.e. we do NOT generate M_n+1 from M_n as some faulty proofs do).")

#text("Let’s call the largest of the a_i “max a” (there’s a single max a since they are all distinct). Let’s call the sum of the a_i “target”.")

#text("Let f be the number of mines in the interval (0,max a).")

#text("Now we have the following cases:")

#text("* max a is a mine and f>0. In that case, out of the a_i that are not max a (n numbers), at least n-f are not mined (when taken as a first jump). Consider the n double jumps (a_i != max a, max a). At least n-f of those are not mined on first jump. The number of mines in (max a, target) is the number of mines (n) less f less the one for max a, yielding n-f-1 which is less than n-f. Thus by counting argument, at least one of the double jumps does not hit a mine on both jumps. This double jump takes two jumps and jumps over f+1 >=2 mines, yielding a problem with n-2 mines and n-1 remaining jumps, which is solved by induction.")

#text("* max a is not a mine and f>0. Take max a as first jump, yielding problem with n remaining jumps and n-f<n mines, which is solved by induction.")

#text("* max a is a mine and f=0. Let min M be the smallest mine in M. Construct M'=M\\{min M}. Jump max a as the first jump and solve the n-problem with the remaining a_i and M' by recursion, I mean induction. Let a_x be the first jump of this solution. Exchange max a and a_x (i.e. jump a_x first then max a). max a+a_x is no mine (guaranteed by solution), a_x is no mine (because a_x < max a == min M as above). There are no mines in the rest. We have completed solution for n+1.")

#text("* max a is not a mine and f=0. As in case 3, construct M', jump max a first and solve for the remaining a_i and M'. If this solution hits min M in step k, construct a new solution by exchanging step k+1 and step 1 (i.e. max a). There are no mines before min M, thus the mine is avoided and no new mines are hit. We have completed solution for n+1")

#text("I hope that's it and it's shut tight. This problem is just evil")#linebreak()#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40492")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Well done… did any part of the thread help you?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benoit")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40524")[#strong[#text("Benoit")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2009")])]

#text("It seems right to me, but may be to complicated formulated this way.")

#text("First, if there is a mine at all in (0,max a) then the induction works as has been noticed. Otherwise, use the induction to solve the problem of going from max a to s using the n-1 smallest a_i and avoiding the n-2 largest mines. If, when adding the first mine it blows up the grasshopper, then you can switch the a_i that was used to from this first mine with max a to avoid it. You won’t encounter any other mine this way because there is none before the one you just add.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b11b8be2e336eaf6d0bea6b8fc68cdc6779233d102663c5a29c6f33e44388206-a396da3374a882d11fc2fd48e721431037b4bca78c4bd308197e6cb1a4d23bc3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Escott")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40459")[#strong[#text("David Escott")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("216 This spam filter is annoying. If you have a minimal blocking set, I think you can pivot it around any point in the minimal set, by removing that point, swapping the front and back, and adding the point corresponding to the original endpoint. Might this be used to normalize the form of the minimal blocking sets, and thus prove their size is at least n.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87d371ed5b16ea55f490d194f87ea4e959a08f20d7ad7aa247b06166f57c2da4-578db053ee374a5e0cc24cf86804aa3af53ffbb818f2e59a45dea00966c34631.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Logistics: Having trouble posting comments. Checking if problem is the length of comment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0c473d67cde178c94599095e3a8c54e04bd59b868d9c6521df465ab302d3122-c12b256352bd50a2926a14a1d7011017d09092221e86f204cf38a758857e2844.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raghu")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40461")[#strong[#text("Raghu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("217. @Anonymous 21 July, 2009 at 11:04 am – You are right in that there’s a mistake in the argument, but it is not the one you mention: the induction is over k (n is fixed). The observation that ")#mi("s + a_k, ..., s+a_n")#text(" should all be mines could still be useful though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Vieira consegue um feito histórico: a primeira medalha de prata portuguesa nas Olimpíadas Internacionais de Matemática « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40463")[#strong[#text("Pedro Vieira consegue um feito histórico: a primeira medalha de prata portuguesa nas Olimpíadas Internacionais de Matemática « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("[…] Adenda de 21.07.09: outro problema, do mesmo dia, considerado particularmente difícil por Terence Tao é o n.º 6. Sobre ele o Professor propôs, ontem, no seu blogue, que os seus leitores o tentassem resolver de forma colaborativa, havendo já mais de centena e meia de comentários, no post respectivo, pelo que decidiu abrir um segundo post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40464")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("218. To Anonymous at 215. I have a very hard time posting my comments. I will try again.")

#text("Continuing post 210:")

#text("We perform induction on n. For n=2 it is true. Assume it is true for 2,…,n-1. Let A={a_1,…,a_n} and M as in the statement. For one of the a_i we have that s-a_i is not in M because card(M)<n. WLOG assume this is a_n. Set m=max(M), M'=M-{m}, A'=A-{a_n} and m'=max(M').")

#text("To be continued….")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/192353d80dc19af0715968dbb0e57e705f4cef4bb496aa42e3fc3f5c2d7816bc-54dd0f60b137745080490dfc27251d5499fc7f33ba25a3c3bd1ff7fb6e4e60aa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of partalopoulo")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40467")[#strong[#text("partalopoulo")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("218. To Anonymous at 215. It’s impossible for me to post anything. The server is not accepting it. I’ll try again later.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40468")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("219. I just saw this post. I think they way to go is extend the idea in n=2 and use induction. Since there are n-1 numbers in the set, at least one of s-a_i s is not in it. Use a_i as the last jump.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40469")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("219. I just saw this post. I think the way to go is extend the idea in n=2 and use induction. Since there are n-1 numbers in the set, at least one of s-a_i s is not in it. Use a_i as the last jump.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of K")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40470")[#strong[#text("K")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("220. Adding to 219: To reduce the set, there should be at least one possible a_i such that one of the members of the set is above s-a_i.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/914c459b8303f733c97b8f66e20143119e90f2997df4fece3560d18191db8f9d-9f9352973d40fb7977c9ca267e25b7e5047d2278800b2a73809480cc7c7b0609.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of a.s.")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40471")[#strong[#text("a.s.")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("In the case of A={1…n}, the “worst” cases seem to be blocks of landmines M={2,3,…,n} or M={3,4,…,n+1}, and two “symmetric” sets ending at N-3 and N-2 (with N=n(n+1)/2). Obviously, in this four cases we are left with (n-2)! paths, other sets M leaving many more possibilities. Tested experimentally for n=2..7; can it be of any help for counting or an induction hypothesis?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/881129b35acf6b9a3253370c1ec853c923ad4973a05c0709e9f5e82ac2307faa-5f5e2be7d616d800aab509e0afa54c55c512397bf3203f4820d49af68e6ef5ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pablolessa")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40472")[#strong[#text("pablolessa")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("222. I’d like to discuss an idea for a very special case, which I think might be of some general value.")

#text("Take ")#mi("A = \\{1,2,3,4,5,6,7\\}")#text(" and suppose that there are no mines in the set ")#mi("\\{7,14,21\\}")#text(".")

#text("This set divides ")#mi("0,1,\\ldots, 27,28")#text(" into four equal intervals of length ")#mi("7")#text(". The idea is to jump over each of them by using either ")#mi("7")#text(", or one of the pairs ")#mi("1+6, 2+5,3+4")#text(".")

#text("In order to simplify the discussion I will include a jump of length zero, so that we have four pairs of jumps available ")#mi("0+7,1+6,2+5,3+4")#text(" (note that most pairs can be used in two different ways).")

#text("——-")#linebreak()#text(" The following observations are the key to the argument:")#linebreak()#text(" *Any given pair of jumps will be able to pass over an interval with zero or one mines, without hitting a landmine.")

#text("*Given two pairs of jumps, it is garanteed one of them will be able to pass an interval with two or three mines.")

#text("*Given any three pairs, one of them will be able to jump over an interval with four or five mines.")#linebreak()#text(" ——-")

#text("Order the four intervals by decreasing number of landmines.")

#text("The first interval has at most ")#mi("6")#text(" mines.")#linebreak()#text(" The second interval has at most ")#mi("3")#text(" mines.")#linebreak()#text(" The third interval has at most ")#mi("2")#text(" mines.")#linebreak()#text(" The fourth interval has at most ")#mi("1")#text(" mine.")

#text("Therefore we can pass the first one with a pair. Pass the second one with one of the remaining three pairs. Pass the third one with one of the remaining two pairs. And the last one is garanteed to be passed safely by the only remaining pair of jumps.")

#text("I think this argument might generalize to ")#mi("A = \\{1,\\ldots, n\\}")#text(" with odd ")#mi("n")#text(", when there are no landmines on multiples of ")#mi("n")#text(".")

#text("But I also think that if ")#mi("n")#text(" is arbitrary and another residue class modulo ")#mi("n")#text(" has no landmines, we might be able to adapt the argument to deal with the two smaller intervals at ")#mi("{}0")#text(" and ")#mi("n(n+1)/2")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40473")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("223. brumm 11:16am.")

#text("I haven’t fully digested your argument, but I have a question on the following line.")

#text("You write:")#linebreak()#text(" max a is a mine and f=0. Let min M be the smallest mine in M. Construct M’=M\\{min M}. Jump max a as the first jump and solve the n-problem with the remaining a_i and M’ by recursion, I mean induction.")

#text("Since max a is a mine (by assumption) aren’t we going to run into trouble if we take max a as the first jump?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40474")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("224. @223 No that mine has been temporarily from M to construct M’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("Oh I accidentally the whole mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("225 @ 224. But isn’t is the min M that we remove to construct M, not max M.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/441fda2323a8a25f72dba1eca93d0d2ab7007e1da5561ce1610adaf0aea05f84-66d89e932870e2b814c75ce81d75e047b30161cd0b4eab5f4c70b52d59bad083.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gbaloglou")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40477")[#strong[#text("gbaloglou")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("224. Let Nk be the number of obstacles at the k-node level, k = 1, …, n-1. Each obstacle at that level kills (n-k)! paths from A1+…+An to 0 *and* it appears k! times at that level. There is a total of n! such paths, while SUM[Nk] = n-1. It looks at first that this does it because of SUM[Nk] = n-1 —-> SUM[Nk(n-k)!k!] < n! … BUT the same obstacle may appear at two distinct levels!")

#text("Let me illustrate this by reference to my ")#link("http://www.oswego.edu/~baloglou/gr-q6-tree.html")[#text("example")]#text(" (that I linked here yesterday). Given obstacles {3, 8, 20} we get N1 = N2 = N3 = 1; we also see that 3 appears 3! times at level-3, 8 appears 2! times at level-2, and 20 appears 1! times at level-1. The formula SUM[Nk(n-k)!k!] yields 1*3!*1! + 1*2!*2! + 1*1!*3! = 6 + 4 + 6 = 14 24 … but there is double counting, too!)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/441fda2323a8a25f72dba1eca93d0d2ab7007e1da5561ce1610adaf0aea05f84-66d89e932870e2b814c75ce81d75e047b30161cd0b4eab5f4c70b52d59bad083.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gbaloglou")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40478")[#strong[#text("gbaloglou")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("227. My comment (224, should be 226) has been truncated — I forgot that business about inequality signs :-(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/373599b5c94464690b689f1bb1b063a92a622e8b246e4d8244f22cd741e2abe2-8f643e9e0747242d847da971d7d6a4c5557fd0795c19dcf0d348bac02bc2a6cc.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Henry")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40479")[#strong[#text("Henry")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("228. Here’s a way of proving that there is a path of length 3 which has a more inductive character. As in 107, choose b_1,b_2 from among the a_i such that b_1+b_2 is the largest possible value after a path of length 2, and b_1 is the largest first value which begins a path of length 2 with this sum. Suppose there is no path of length 3 extending this path; that is, b_1+b_2+a_i is in M whenever a_i is neither b_1 nor b_2. Note that this accounts for all but one element of M.")

#text("Let c_1,c_2 be the smallest a_i other than b_1 and b_2. Suppose we could show that c_1<b_1 and c_1+b_2+c_2 not in M; then there would be at most two smaller elements of M smaller, and so by induction, a path of length 3 leading to c_1+b_2+c_2. Similarly if we could show c_1<b_2 and b_1+c_1+c_2 not in M.")

#text("First, observe that at most one of b_1+c_1 and b_2+c_2 belong to M, and by the maximality of b_1+b_2, it follows that either c_1<b_1 or c_1<b_2. Suppose it is not the case that c_1<b_2; then b_2+c_1 is in M and c_1<b_1, so in particular b_2+c_1<c_1+b_2+c_2<b_1+b_2+c_2 and c_1+b_2+c_2 is not b_1+b_2+c_2, and therefore c_1+b_2+c_2 is not in M.")

#text("Similarly, if it is not the case that c_1<b_1 then b_1+c_1 is in M and c_1<b_2, so it follows that b_1+c_1<b_1+c_1+c_2<b_1+b_2+c_2 and b_1+c_1+c_2!=b_1+b_2+c_1, so b_1+c_1+c_2 is not in M.")

#text("If both c_1<b_1 and c_1<b_2, it follows that both b_1+c_1+c_2 and c_1+b_2+c_2 are less than b_1+b_2+c_2 and distinct from b_1+b_2+c_1; therefore at most one is in M, and we are done.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Hofmann")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40480")[#strong[#text("Kyle Hofmann")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("223. It seems to me that most of the comments so far have focused on trying to pass a group of land mines with a single jump. A problem with this “one jump at a time” approach is that you may need to set yourself up for that jump.")

#text("For example, consider the set ")#mi("A = \\{1, 2, 3, 4, 5\\}")#text(". Here ")#mi("s = 15")#text(". Take ")#mi("M = \\{6, 7, 8, 9\\}")#text(". Suppose that we choose our first jump to be of length five. Then for a jump of length ")#mi("i")#text(", where ")#mi("i")#text(" is any number between one and four, we get blown up. But we can do nothing else, because we have already used our jump of length five.")

#text("Instead, we must make two jumps before jumping any mines at all: We may make the jumps 1 + 4, 4 + 1, 2 + 3, or 3 + 2, and then we must make the jump of length five. The numerics on this strategy look bad, actually: We use up two jumps and pass zero mines, so we are left with three jumps to cross four mines! Somehow it works anyway because the same bad distribution that forces us to make two jumps at the start also forces us to jump four mines at once.")

#text("If we’re going to use some sort of induction (which feels like the way to go to me), then my best guess is that we should set it up like this: Assume that the statement is true if A has less than n elements; now prove that there is always a way to reduce to the same statement with less than n elements (not necessarily n-1 elements, which won’t work as above). This is of course hard, but the other inductive strategy we seem to have is to include some information about the distribution of the elements of M; and that strikes me as harder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ar")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40481")[#strong[#text("ar")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("230. @sw (201). Regarding the graph approach, it’s true that Menger’s theorem does not seem to apply because you need to take the graph directed. But in fact we don’t need Menger’s theorem at all. If there are n vertex independent paths between the “0 vertex” and the “total sum vertex”, obviously there is no way to disconnect them taking out n-1 vertices (each vertex you take out will belong to at most one path).")

#text("What Menger’s theorem would say (if applicable) is that the “n disconnecting vertices” statement and the “n vertex independent paths” statement are equivalent. Without Menger’s theorem, the “n vertex independent paths” statement could happen to be wrong… Anyway, this still seems worth thinking to me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40482")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("223")

#text("David – my equivalence relation can reduce every solution to the trivial case where n=1,s=1,A1=1 and there are no mines.")

#text("The point is that every step is reversible, so:")

#text("(a) can a sequence of ‘going up’ steps be used to construct a solution by brute force? [difficult, but there is a richer set of options, it seems to me, than simply permutations of the Ai]")

#text("(b) by studying the space of solutions through equivalence, can we prove that every configuration is solvable: eg by proving that a hypothetical minimal counterexample can’t exist? [again the richer set of options might help here]")

#text("I think it is possible to put quite severe conditions on a hypothetical minimal counterexample by defining the order well. Then it is necessary to have sufficient flexibility to show that a smaller counterexample must exist. [I’m reminded of Kempe chains to prove the five colour theorem]")

#text("It seems indicated to me that such factors as the Ai being distinct are crucial to the proof, because there are counterexamples otherwise. So any proof which does not, in some way, use this fact, cannot succeed.")

#text("The problem has various local obstructions to a route through, which may require global solutions – in that a route which seems “to nearly work” may be quite distant (in some intuitive sense) from any actual solution.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ar")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40483")[#strong[#text("ar")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("232. Let me write the graph restatment again. Construct an n-cube putting a subset of {1,…n} at each vertex and a directed edge from A to ")#mi("A \\cup \\lbrace k \\rbrace")#text(" for any ")#mi("A \\subset \\lbrace 1,\\ldots,n\\rbrace")#text(" and ")#mi("k \\not \\in A")#text(". Every vertex is labelled by the integer ")#mi("\\sum_{i \\in A} a_i")#text(", and every edge by the ")#mi("a_k")#text(" corresponding to the index that the edge adds to the set at the source.")

#text("Now take the quotient of this graph G identifying vertices with the same label and edges with the same edge label and vertex label at both, source and target. If we prove that there are at least n vertex-independent paths (i.e. without vertices in common except from the endpoints) joining the empty set to {1,…n} in the graph G we are done !")

#text("An other way to say the same is as follows: Find n vertex-independent paths from the empty set to {1,…n} in the n-cube but now the paths may be discontinuous, allowing a teletransportation from one vertex to another with the same label (ah, and the independence condition also knows about teletransportation … otherwise it would be easy).")

#text("By the way, the graph G is a piece of the Cayley Graph of the group of the integers with respect to the set of generators {a_1/d,…,a_n/d} and d = gcd(a_1,…a_n).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a80887302c847c64d480720a81a699d383aef441f57a5ba3f73db51d20dbaa-5781e5654aa85037d7b2da00b4db75e4fed3c3352c957e1c22c0ed77ef4483d1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40484")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("233 ar: If I understand you correctly, what you want is impossible. Take A = (1,2,3). Then there are not three independent paths from 0 to 6. Proof: The paths are p=(0,1,4,6), q=(0,2,5,6) and four others, each of which contain 3. So precisely one of the paths containing 3 must be used. But each of these is either incompatible with p or with q.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jens")]], [#link("https://terrytao.wordpress.com/2009/07/21/imo-2009-q6-mini-polymath-project-cont/comment-page-1/#comment-40485")[#strong[#text("jens")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2009")])]

#text("233. Just a general thought on “almost complete” proofs by induction (as 129. and follow-ups), i.e. where the reduction of the problem to smaller problems works except in seemingly rather special cases:")#linebreak()#text(" I think that those proofs might still be far from completion, because I have the feeling that the “input data” for the induction hypothesis might typically be of that very special form. (It slightly reminds me of complexity theory…)")
]
