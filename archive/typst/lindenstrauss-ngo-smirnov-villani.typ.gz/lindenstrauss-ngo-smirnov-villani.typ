// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/
// Converted to Typst by tao2typ: "2026-10-14T16:36:15.777772+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Lindenstrauss, Ngo, Smirnov, Villani", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Lindenstrauss, Ngo, Smirnov, Villani")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 August 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/")[#text("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As is now widely reported, the ")#link("http://en.wikipedia.org/wiki/Fields_Medal")[#text("Fields medals")]#text(" for 2010 ")#link("http://www.icm2010.in/imu-prizes/prize-winners-2010")[#text("have been awarded")]#text(" to ")#link("http://en.wikipedia.org/wiki/Elon_Lindenstrauss")[#text("Elon Lindenstrauss")]#text(", ")#link("http://en.wikipedia.org/wiki/Ng%C3%B4_B%E1%BA%A3o_Ch%C3%A2u")[#text("Ngo Bao Chau")]#text(", ")#link("http://en.wikipedia.org/wiki/Stanislav_Smirnov")[#text("Stas Smirnov")]#text(", and ")#link("http://en.wikipedia.org/wiki/C%C3%A9dric_Villani")[#text("Cedric Villani")]#text(". Concurrently, the ")#link("http://en.wikipedia.org/wiki/Nevanlinna_prize")[#text("Nevanlinna prize")]#text(" (for outstanding contributions to mathematical aspects of information science) was awarded to ")#link("http://en.wikipedia.org/wiki/Daniel_Spielman")[#text("Dan Spielman")]#text(", the ")#link("http://en.wikipedia.org/wiki/Carl_Friedrich_Gauss_Prize")[#text("Gauss prize")]#text(" (for outstanding mathematical contributions that have found significant applications outside of mathematics) to ")#link("http://en.wikipedia.org/wiki/Yves_Meyer")[#text("Yves Meyer")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Chern_Medal_Award")[#text("Chern medal")]#text(" (for lifelong achievement in mathematics) to ")#link("http://en.wikipedia.org/wiki/Louis_Nirenberg")[#text("Louis Nirenberg")]#text(". All of the recipients are of course exceptionally qualified and deserving for these awards; congratulations to all of them. (I should mention that I myself was only very tangentially involved in the awards selection process, and like everyone else, had to wait until the ceremony to find out the winners. I imagine that the work of the prize committees must have been extremely difficult.)")

#text("Today, I thought I would mention one result of each of the Fields medalists; by chance, three of the four medalists work in areas reasonably close to my own. (Ngo is rather more distant from my areas of expertise, but I will give it a shot anyway.) This will of course only be a tiny sample of each of their work, and I do not claim to be necessarily describing their “best” achievement, as I only know a portion of the research of each of them, and my selection choice may be somewhat idiosyncratic. (I may discuss the work of Spielman, Meyer, and Nirenberg in a later post.)")

#metadata(none) <tao-457d75e7363651206a75>

#heading(level: 1)[#strong[#text(" — 1. Elon Lindenstrauss — ")]]

#text("Elon Lindenstrauss works primarily in ergodic theory and dynamical systems, particularly with regard to the ")#emph[#text("homogeneous dynamics")]#text(" of the action of some subgroup ")#mi("{H}")#text(" of a Lie group ")#mi("{G}")#text(" on a quotient ")#mi("{G/\\Gamma}")#text(", and on the applications of this theory to questions in analytic number theory.")

#text("One of the themes of modern mathematics is that within any field of mathematics, there is some sort of underlying action by a group (or group-like object) which endows certain key objects of study in that field with a rich, symmetric structure (both algebraic and geometric). Analytic number theory is no exception to this; many classical questions, for instance, about Minkowski’s geometry of numbers, Diophantine approximation, or quadratic forms can be interpreted through this modern perspective as questions about the actions of groups such as ")#mi("{SL_2({\\bf R})}")#text(" on spaces such as the homogeneous space ")#mi("{SL_2({\\bf R})/SL_2({\\bf Z})}")#text(". In particular, the ")#emph[#text("dynamical")]#text(" properties of such actions (e.g. the behaviour of orbits, the classification of invariant measures, the mixing properties of the action, or averages of the action) often have direct bearing on the number-theoretic properties of these objects. A typical example of this is the resolution of the ")#link("http://en.wikipedia.org/wiki/Oppenheim_conjecture")[#text("Oppenheim conjecture")]#text(" on quadratic forms by Margulis, using a classification of orbit closures in the homogeneous space ")#mi("{SL_3({\\bf R})/SL_3({\\bf Z})}")#text(" of a certain subgroup ")#mi("{U}")#text(" of ")#mi("{SL_3({\\bf R})}")#text(", which is also a special case of ")#link("http://en.wikipedia.org/wiki/Ratner%27s_theorems")[#text("Ratner’s theorems")]#text("; this was discussed earlier on this blog at ")#link("https://terrytao.wordpress.com/2009/01/13/distinguished-lecture-series-i-gregory-margulis-homogeneous-dynamics-and-number-theory-i/")[#text("this writeup of a lecture of Margulis")]#text(", or at ")#link("https://terrytao.wordpress.com/2007/09/29/ratners-theorems/")[#text("this discussion of Ratner’s theorems")]#text(". Indeed, even though the Oppenheim conjecture is a purely number-theoretic statement, the only known proofs of this conjecture in full generality proceed via homogeneous dynamics. (There are however more number-theoretic proofs of partial cases of this conjecture.)")

#text("Another demonstration of this principle is ")#link("http://www.ams.org/mathscinet-getitem?mr=2247967")[#text("the remarkable 2006 paper of Einsiedler, Katok, and Lindenstrauss")]#text(" that gives the best partial result known to date on the notorious ")#link("http://en.wikipedia.org/wiki/Littlewood_conjecture")[#text("Littlewood conjecture")]#text(", which asserts that for any real numbers ")#mi("{\\alpha, \\beta}")#text(", and any ")#mi("{\\varepsilon > 0}")#text(", one can find a positive integer ")#mi("{n}")#text(" such that ")#tao-math("{\\left\\| n \\alpha \\right\\| \\left\\| n \\beta \\right\\| \\leq \\varepsilon/n}", block: false)#text(", where ")#tao-math("{\\left\\|x\\right\\|}", block: false)#text(" is the distance from ")#mi("{x}")#text(" to the nearest integer. Note that the ")#link("http://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(" already gives ")#tao-math("{\\left\\|n\\alpha\\right\\| = O(1/n)}", block: false)#text(" for infinitely many ")#mi("{n}")#text(", and ")#tao-math("{\\left\\|n\\beta\\right\\|}", block: false)#text(" is clearly bounded, so the conjecture is tantalisingly close to being “easy”; nevertheless, it has defied proof for about eight decades now.")

#text("Einsiedler, Katok, and Lindenstrauss establish the partial result that the Littlewood conjecture is true for “most” ")#mi("{\\alpha,\\beta}")#text(", in the sense that the set of pairs ")#mi("{(\\alpha,\\beta)}")#text(" for which the conjecture fails is a subset of ")#mi("{{\\bf R}^2}")#text(" of Hausdorff dimension zero. This is a much stronger statement than the fact that the Littlewood conjecture holds for ")#emph[#text("almost every")]#text(" ")#mi("{(\\alpha,\\beta)}")#text(", which is fairly easy to prove; being dimension zero is much stronger than having measure zero.")

#text("How is this connected with homogeneous dynamics? Fix ")#mi("{\\alpha,\\beta}")#text(", and let us consider the orbit ")#mi("{A^+x}")#text(" of a point ")#mi("{x}")#text(" in the homogeneous space")

#align(center)[#tao-fit-display[#mitex("G/\\Gamma := SL_3({\\bf R}) / SL_3({\\bf Z}),")]]

#text("where ")#mi("{x}")#text(" is given as")

#align(center)[#tao-fit-display[#mitex("x := \\begin{pmatrix} 1 & 0 & 0 \\\\ \\alpha & 1 & 0 \\\\ \\beta & 0 & 1 \\end{pmatrix} SL_3({\\bf Z})")]]

#text("and ")#mi("{A^+}")#text(" is the semigroup")

#align(center)[#tao-fit-display[#mitex("A^+ := \\left\\{ \\begin{pmatrix} e^{-r-s} & 0 & 0 \\\\ 0 & e^r & 0 \\\\ 0 & 0 & e^s \\end{pmatrix}: r, s \\geq 0 \\right\\}.")]]

#text("The space ")#mi("{G/\\Gamma}")#text(" has finite volume, but is non-compact, having a “cusp” at infinity. Thus, the orbit ")#mi("{A^+x}")#text(" need not be bounded, but could wander arbitrarily close to the cusp. The connection with the Littlewood conjecture (first observed, I believe, by Margulis) is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" The Littlewood conjecture is true for ")#mi("{(\\alpha,\\beta)}")#text(" if and only if ")#mi("{A^+x}")#text(" is unbounded.")
]

#emph[#text("Proof:")]#text(" We’ll just prove the “if” part; the “only if” part is proven by a slightly more sophisticated version of the arguments below. One can identify ")#mi("{G/\\Gamma}")#text(" with the space of all ")#link("http://en.wikipedia.org/wiki/Unimodular_lattice")[#text("unimodular lattices")]#text(" in ")#mi("{{\\bf R}^3}")#text(", by identifying each point ")#mi("{T SL_3({\\bf Z})}")#text(" of ")#mi("{G/\\Gamma}")#text(" with the lattice ")#mi("{T{\\bf Z}^3}")#text(". The non-compactness of this space arises from the fact that the shortest non-zero vector in such lattices can become arbitrarily small (or to put it contrapositively, as long as one keeps the non-zero vectors of a unimodular lattice away from zero, the space of such lattices becomes (pre)compact). In particular, ")#mi("{A^+x}")#text(" is unbounded if and only if the vector")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} e^{-r-s} & 0 & 0 \\\\ 0 & e^r & 0 \\\\ 0 & 0 & e^s \\end{pmatrix} \\begin{pmatrix} 1 & 0 & 0 \\\\ \\alpha & 1 & 0 \\\\ \\beta & 0 & 1 \\end{pmatrix} \\begin{pmatrix} n \\\\ m_1 \\\\ m_2 \\end{pmatrix}")]]

#text("where ")#mi("{r,s \\geq 0}")#text(" and ")#mi("{n,m_1,m_2}")#text(" are integers not all zero, can become arbitrarily small. We can multiply out this vector as")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} ne^{-r-s} \\\\ e^r(m_1+n\\alpha) \\\\ e^s(m_2+n\\beta) \\end{pmatrix}.")]]

#text("We conclude that if ")#mi("{A^+x}")#text(" is unbounded, then for any ")#mi("{\\varepsilon > 0}")#text(", we can find ")#mi("{r,s \\geq 0}")#text(" and ")#mi("{n,m_1,m_2}")#text(" (not all zero) such that")

#align(center)[#tao-fit-display[#tao-math("\\left|ne^{-r-s}\\right|, \\left|e^r(m_1+n\\alpha)\\right|, \\left|e^s(m_2+n\\beta)\\right| \\leq \\varepsilon^{1/3}.", block: true)]]

#text("Since ")#mi("{r,s \\geq 0}")#text(" and ")#mi("{n,m_1,m_2}")#text(" are not all zero, we easily verify that this forces ")#mi("{n}")#text(" to be non-zero if ")#mi("{\\varepsilon}")#text(" is small enough. Multiplying all three terms together, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left|ne^{-r-s}\\right| \\times \\left|e^r(m_1+n\\alpha)\\right| \\times \\left|e^s(m_2+n\\beta)\\right| \\leq \\varepsilon", block: true)]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#tao-math("\\left|m_1 + n \\alpha\\right| \\left|m_2 + n \\beta\\right| \\leq \\varepsilon/n.", block: true)]]

#text("But the left-hand side is at least ")#tao-math("{\\left\\|n\\alpha\\right\\| \\left\\|n\\beta\\right\\|}", block: false)#text(", we conclude that Littlewood’s conjecture is true for ")#mi("{(\\alpha,\\beta)}")#text(" as required. ")#mi("\\Box")

#text("The orbits of semigroups such as ")#mi("{A^+}")#text(" are still not well understood, in contrast to the orbits of unipotently generated groups ")#mi("{U}")#text(" for which we have the powerful theorems of Ratner. Nevertheless, by a remarkable analysis of the effects of hyperbolicity on the entropy of an invariant measure, Einsiedler, Katok, and Lindenstrauss are able to obtain some general theorems concerning invariant measures of such semigroups which gives the above consequence to Littlewood’s conjecture, as well as many other applications.")

#heading(level: 1)[#strong[#text(" — 2. Ngo Bao Chau — ")]]

#text("(Caveat: my understanding of the subject matter here is rather superficial, and so what I write below may be somewhat inaccurate in places. Corrections and clarifications would, of course, be greatly appreciated!)")

#text("Ngo Bao Chau has made major contributions to the ")#link("http://en.wikipedia.org/wiki/Langlands_program")[#text("Langlands programme")]#text(", which among other things seeks to control the automorphic representations of a (connected, reductive) algebraic group ")#mi("{G}")#text(" by the Langlands dual group ")#mi("{{}^L G}")#text(", in a way which is analogous to how the representation theory of a (locally compact) ")#emph[#text("abelian")]#text(" group ")#mi("{G}")#text(" is controlled by the Pontryagin dual group ")#mi("{\\hat G}")#text(". Thus, the Langlands programme can be viewed in some sense as a generalisation of Fourier analysis to non-abelian groups ")#mi("{G}")#text(". For instance, the classical ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(", that relates summations in an abelian group ")#mi("{G}")#text(" to summations in its Pontryagin dual ")#mi("{\\hat G}")#text(", has a vast generalisation in the ")#link("http://en.wikipedia.org/wiki/Selberg_trace_formula")[#text("Selberg trace formula")]#text(" and its generalisations (in particular, the ")#link("http://en.wikipedia.org/wiki/Arthur-Selberg_trace_formula")[#text("Arthur-Selberg trace formula")]#text("), which very roughly speaking relates summations (of orbital integrals) over conjugacy classes in ")#mi("{G}")#text(" with sums over the automorphic representations of ")#mi("{G}")#text(" (which, by Langlands duality, should be in turn controlled somehow by ")#mi("{{}^L G}")#text(").")

#text("The Poisson summation formula is closely related to the “functorial” properties of the Fourier transform ")#mi("{f \\mapsto \\hat f}")#text(": every homomorphism ")#mi("{\\phi: G \\rightarrow H}")#text(" of locally compact abelian groups induces a corresponding adjoint homomorphism ")#mi("{\\phi^*: \\hat H \\rightarrow \\hat G}")#text(" on the Pontryagin dual groups, and one can interpret Poisson summation as being a consequence of the claim that pullback by the homomorphism ")#mi("{\\phi}")#text(" becomes pushforward by the adjoint homomorphism ")#mi("{\\phi^*}")#text(" after taking Fourier transforms. As I understand it (which is, admittedly, not very well), ")#emph[#text("Langlands functoriality")]#text(" is a nonabelian generalisation of this Fourier functoriality. However, the notions of pushforward and pullback become much more complicated in the nonabelian world, as one is working on things such as conjugacy classes and representations, rather than individual elements of the groups involved. One can define these notions relatively easily in a “local” fashion, working one place at a time, but to glue everything together properly into a “global” setting (in which one is working over an adele ring) in such a way that the relevant trace formulae remain compatible requires the ")#link("http://en.wikipedia.org/wiki/Fundamental_lemma_(automorphic_forms)")[#text("fundamental lemma")]#text(", the establishment of which was then a major goal of the Langlands programme (as it makes the trace formula significantly more useful, particularly for applications to number theory). In 2008, ")#link("http://arxiv.org/abs/0801.0446")[#text("Ngo established")]#text(" this lemma in full generality, building upon several special cases and previous reductions by other mathematicians (including an earlier breakthrough paper of Laumon and Ngo), and also importing a major new tool from geometry and mathematical physics, namely that of a ")#emph[#text("Hitchin fibration")]#text(". Apparently, a key observation of Ngo is that the sums over conjugacy classes that appear in the trace formula can be naturally interpreted in terms of some geometric data associated to such fibrations. This is a deep connection which not only gives the fundamental lemma (after a lot of difficult work), but gives a better understanding as to the Langlands programme as a whole.")

#heading(level: 1)[#strong[#text(" — 3. Stas Smirnov — ")]]

#text("Stas Smirnov works in a number of related fields, and in particular in complex dynamics and in statistical physics. One of his celebrated results in the latter area is the ")#link("http://www.ams.org/mathscinet-getitem?mr=1851632")[#text("first rigorous demonstration")]#text(" of ")#emph[#text("conformal invariance")]#text(" for a scaling limit percolation model, namely that of percolation on the triangular lattice; this invariance was conjectured for physicists for some time (being part of a larger philosophy of ")#link("http://en.wikipedia.org/wiki/Universality_(dynamical_systems)#Universality_in_statistical_mechanics")[#text("universality")]#text(", that asserts that the large-scale behaviour of a statistical system should be largely insensitive to the precise small-scale geometry of that system, after normalising some key parameters). Smirnov’s result, especially when combined with the theory of the Schramm-Loewner equation (SLE) developed by Lawler, Schramm, and Werner which classifies conformally invariant processes, allows for a rigorous analysis of many random processes in statistical physics, confirming the general intuition of universality, although the underlying explanation for the universality phenomenon is still lacking. (For instance, we still do not have an analogue of Stas’s result for any lattice other than the triangular one.) Note that this universality phenomenon is not directly related to the universality phenomenon observed in random matrix theory (which has guided much of my own recent research with Van Vu), though there are certainly some superficial similarities between the two.")

#text("Smirnov’s full result of conformal invariance for the triangular lattice is a bit tricky to state, but it is a bit easier to state a simpler but still highly non-trivial consequence of that result, namely ")#emph[#text("Cardy’s formula")]#text(" for crossing probabilities in the scaling limit. As observed by Carleson, this formula is easiest to state when the domain is a unit equilateral triangle ")#mi("{ABC}")#text(", though it is an important consequence of Stas’s conformal invariance result (first conjectured by Aizenman) that it can in fact be phrased for any simply connected domain in the plane.")

#text("Pick a large natural number ")#mi("{n}")#text(", and subdivide the original unit equilateral triangle into ")#mi("{n^2}")#text(" subtriangles of sidelength ")#mi("{1/n}")#text(". This creates a triangular lattice on ")#mi("{\\frac{(n+1)(n+2)}{2}}")#text(" (the ")#mi("{(n+1)^{th}}")#text(" triangular number, naturally) vertices or ")#emph[#text("sites")]#text(". Now randomly colour each site blue and yellow (say), with an independent ")#mi("{1/2}")#text(" probability of each; this is the ")#emph[#text("critical")]#text(" probability for this lattice, in which neither colour dominates, and thus gives the most interesting behaviour. The site colouring then separates the ")#mi("{\\frac{(n+1)(n+2)}{2}}")#text(" vertices into blue and yellow ")#emph[#text("clusters")]#text(", with two vertices of the same colour belonging to the same cluster if they are connected by a path in the lattice that only goes through vertices of that colour.")

#text("The size, shape, and other geometrical properties of clusters in such lattice models, especially in the scaling limit ")#mi("{n \\rightarrow \\infty}")#text(", is the main subject of study of ")#link("http://en.wikipedia.org/wiki/Percolation_theory")[#text("percolation theory")]#text(". There are many such aspects to this theory, but let us focus on a relatively simple aspect, namely the ")#emph[#text("crossing probability")]#text(" between two line segments on the boundary of the triangle ")#mi("{ABC}")#text(", say ")#mi("{AB}")#text(" and ")#mi("{CD}")#text(", where ")#mi("{D}")#text(" is a site on the line segment ")#mi("{CB}")#text(". This crossing probability is defined to be the probability that there is a blue (say) cluster connecting ")#mi("{AB}")#text(" with ")#mi("{CD}")#text(", or equivalently that there is a blue path that starts at ")#mi("{AB}")#text(" and ends at ")#mi("{CD}")#text(". Clearly, for fixed ")#mi("{n}")#text(", this probability is an increasing function of the length ")#tao-math("{\\left|CD\\right|}", block: false)#text(" of the line segment ")#mi("{CD}")#text(", which equals ")#mi("{1}")#text(" when ")#mi("{D}")#text(" is equal to ")#mi("{B}")#text(", and which we expect to be close to zero at the other extreme when ")#mi("{D}")#text(" is equal to ")#mi("{C}")#text(". Cardy’s formula is the assertion that in the limit ")#mi("{n \\rightarrow\\infty}")#text(", the crossing probability is asymptotically equal to the length ")#tao-math("{\\left|CD\\right|}", block: false)#text(" of the interval. (There is a similar formula when one replaces the triangle ")#mi("{ABC}")#text(" by a more general simply connected domain (while still keeping the small-scale triangular lattice structure), and replaces ")#mi("{AB}")#text(" and ")#mi("{CD}")#text(" by two arcs on the boundary of that domain, but then one has to apply the ")#link("http://en.wikipedia.org/wiki/Riemann_mapping_theorem")[#text("Riemann mapping theorem")]#text(" to convert that domain back into the equilateral triangle.)")

#text("The first step in Smirnov’s proof of Cardy’s formula is to consider a two-dimensional extension of the crossing probability, namely the function ")#mi("{h(z)}")#text(" defined for ")#mi("{z}")#text(" in the ")#emph[#text("solid")]#text(" triangle ")#mi("{ABC}")#text(", defined as the probability that there is a blue path from ")#mi("{AB}")#text(" to ")#mi("{CB}")#text(" that separates ")#mi("{z}")#text(" from ")#mi("{AC}")#text(". Note that when ")#mi("{z}")#text(" is a boundary point ")#mi("{D}")#text(" on the edge ")#mi("{CB}")#text(", then ")#mi("{h(z)}")#text(" is basically the crossing probability from ")#mi("{AB}")#text(" to ")#mi("{CD}")#text(" (ignoring some boundary effects which are negligible in the asymptotic limit ")#mi("{n \\rightarrow \\infty}")#text("); thus the crossing probability arises as the boundary values of ")#mi("{h}")#text(". Smirnov was able to show that the function ")#mi("{h}")#text(" is asymptotically harmonic and obeys some natural Dirichlet-Neumann boundary conditions, which ultimately gives Cardy’s formula. By pushing this analysis much further, these methods also eventually give the conformal invariance of the entire triangular lattice percolation process.")

#heading(level: 1)[#strong[#text(" — 4. Cedric Villani — ")]]

#text("Cedric Villani works in several areas of mathematical physics, and particularly in the rigorous theory of continuum mechanics equations such as the Boltzmann equation.")

#text("Imagine a gas consisting of a large number of particles traveling at various velocities. To begin with, let us take a ridiculously oversimplified discrete model and suppose that there are only four distinct velocities that the particles can be in, namely ")#mi("{v_1, v_2, v_3}")#text(", and ")#mi("{v_4}")#text(". Let us also make the homogeneity assumption that the distribution of velocities of the gas is independent of the position; then the distribution of the gas at any given time ")#mi("{t}")#text(" can then be described by four densities ")#mi("{f(t,v_1), f(t,v_2), f(t,v_3), f(t,v_4)}")#text(" adding up to ")#mi("{1}")#text(", which describe the proportion of the gas that is currently traveling at velocities ")#mi("{v_1}")#text(", etc..")

#text("If there were no collisions between the particles that could transfer velocity from one particle to another, then all the quantities ")#mi("{f(t,v_i)}")#text(" would be constant in time: ")#mi("{\\frac{\\partial}{\\partial t} f(t,v_i) = 0}")#text(". But suppose that there is a collision reaction that can take two particles traveling at velocities ")#mi("{v_1, v_2}")#text(" and change their velocities to ")#mi("{v_3, v_4}")#text(", or vice versa, and that no other collision reactions are possible. Making the key heuristic assumption that different particles are distributed more or less independently in space for the purposes of computing the rate of collision (this hypothesis is also known as the ")#link("http://en.wikipedia.org/wiki/Molecular_chaos")[#text("molecular chaos")]#text(" or ")#emph[#text("Stosszahlansatz")]#text(" hypothesis), the rate at which the former type of collision occurs will be proportional to ")#mi("{f(t,v_1) f(t,v_2)}")#text(", while the rate at which the latter type of collision occurs is proportional to ")#mi("{f(t,v_3) f(t,v_4)}")#text(". This leads to equations of motion such as")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial t} f(t,v_1) = \\kappa ( f(t,v_3) f(t,v_4) - f(t,v_1) f(t,v_2) )")]]

#text("for some rate constant ")#mi("{\\kappa > 0}")#text(", and similarly for ")#mi("{f(t,v_2)}")#text(", ")#mi("{f(t,v_3)}")#text(", and ")#mi("{f(t,v_4)}")#text(". It is interesting to note that even in this simplified model, we see the emergence of an “arrow of time”: the rate of a collision is determined by the density of the ")#emph[#text("initial")]#text(" velocities rather than the ")#emph[#text("final")]#text(" ones, and so the system is not time reversible, despite being a statistical limit of a time-reversible collision from the velocities ")#mi("{v_1,v_2}")#text(" to ")#mi("{v_3,v_4}")#text(" and vice versa.")

#text("To take a less ridiculously oversimplified model, now suppose that particles can take a continuum of velocities, but we still make the homogeneity assumption the velocity distribution is still independent of position, so that the state is now described by a density function ")#mi("{f(t,v)}")#text(", with ")#mi("{v}")#text(" now ranging continuously over ")#mi("{{\\bf R}^3}")#text(". There are now a continuum of possible collisions, in which two particles of initial velocity ")#mi("{v^{\\prime}, v^{\\prime}_*}")#text(" (say) collide and emerge with velocities ")#mi("{v, v_*}")#text(". If we assume purely elastic collisions between particles of identical mass ")#mi("{m}")#text(", then we have the law of conservation of momentum")

#align(center)[#tao-fit-display[#mitex("mv^{\\prime} + mv^{\\prime}_* = mv + mv_*")]]

#text("and conservation of energy")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} m \\left|v^{\\prime}\\right|^2 + \\frac{1}{2} m \\left|v^{\\prime}_*\\right|^2 = \\frac{1}{2} m \\left|v\\right|^2 + \\frac{1}{2} m \\left|v^{\\prime}\\right|^2", block: true)]]

#text("some simple Euclidean geometry shows that the pre-collision velocities ")#mi("{v^{\\prime}, v^{\\prime}_*}")#text(" must be related to the post-collision velocities ")#mi("{v, v_*}")#text(" by the formulae ")#metadata(none) <tao-87cfd62083178f54058c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("v^{\\prime} = \\frac{v+v_*}{2} + \\frac{\\left|v-v_*\\right|}{2} \\sigma; \\quad v^{\\prime}_* = \\frac{v+v_*}{2} - \\frac{\\left|v-v_*\\right|}{2} \\sigma", block: true)]]

#text("for some unit vector ")#mi("{\\sigma \\in S^2}")#text(". Thus a collision can be completely described by the post-collision velocities ")#mi("{v,v_* \\in {\\bf R}^3}")#text(" and the pre-collision direction vector ")#mi("{\\sigma \\in S^2}")#text("; assuming Galilean invariance, the physical features of this collision can in fact be described just using the relative post-collision velocity ")#mi("{v-v_*}")#text(" and the pre-collision direction vector ")#mi("{\\sigma}")#text(". Using the same independence heuristics used in the four velocities model, we are then led to the equation of motion")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial t} f(t,v) = Q(f,f)(t,v)")]]

#text("where ")#mi("{Q(f,f)}")#text(" is the quadratic expression")

#align(center)[#tao-fit-display[#mitex("Q(f,f)(t,v) := \\int_{{\\bf R}^3} \\int_{S^2} (f(t,v^{\\prime}) f(t,v^{\\prime}_*) - f(t,v) f(t,v_*)) B(v-v_*,\\sigma) dv_* d\\sigma")]]

#text("for some ")#emph[#text("Boltzmann collision kernel")]#text(" ")#mi("{B(v-v_*,\\sigma) > 0}")#text(", which depends on the physical nature of the hard spheres, and needs to be specified as part of the dynamics. Here of course ")#mi("{v^{\\prime}, v^{\\prime}_*}")#text(" are given by ")#link(<tao-87cfd62083178f54058c>)[#text("(1)")]#text(".")

#text("If one now allows the velocity distribution to depend on position ")#mi("{x \\in \\Omega}")#text(" in a domain ")#mi("{\\Omega \\subset {\\bf R}^3}")#text(", so that the density function is now ")#mi("{f(t,x,v)}")#text(", then one has to combine the above equation with a transport equation, leading to the ")#link("http://en.wikipedia.org/wiki/Boltzmann_equation")[#text("Boltzmann equation")]

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial t} f + v \\cdot \\nabla_x f = Q(f,f),")]]

#text("together with some boundary conditions on the spatial boundary ")#mi("{\\partial \\Omega}")#text(" that will not be discussed here.")

#text("One of the most fundamental facts about this equation is the ")#link("http://en.wikipedia.org/wiki/H-theorem")[#text("Boltzmann H theorem")]#text(", which asserts that (given sufficient regularity and integrability hypotheses on ")#mi("{f}")#text(", and reasonable boundary conditions), the ")#mi("{H}")#text("-functional")

#align(center)[#tao-fit-display[#mitex("H(f)(t) := \\int_{{\\bf R}^3} \\int_\\Omega f(t,x,v) \\log f(t,x,v)\\ dx dv")]]

#text("is non-increasing in time, with equality if and only if the density function ")#mi("{f}")#text(" is Gaussian in ")#mi("{v}")#text(" at each position ")#mi("{x}")#text(" (but where the mass, mean and variance of the Gaussian distribution being allowed to vary in ")#mi("{x}")#text("). Such distributions are known as ")#emph[#text("Maxwellian distributions")]#text(".")

#text("From a physical perspective, ")#mi("{H}")#text(" is the negative of the entropy of the system, so the H theorem is a manifestation of the second law of thermodynamics, which asserts that the entropy of a system is non-decreasing in time, thus clearly demonstrating the “arrow of time” mentioned earlier.")

#text("There are considerable technical issues in ensuring that the derivation of the H theorem is actually rigorous for reasonable regularity hypotheses on ")#mi("{f}")#text(" (and on ")#mi("{B}")#text("), in large part due to the delicate and somewhat singular nature of “grazing collisions” when the pre-collision and post-collision velocities are very close to each other. Important work ")#link("http://www.umpa.ens-lyon.fr/~cvillani/research.html#grazing")[#text("was done by Villani and his co-authors")]#text(" on resolving this issue, but this is not the result I want to focus on here. Instead, I want to discuss the long-time behaviour of the Boltzmann equation.")

#text("As the ")#mi("{H}")#text(" functional always decreases until a Maxwellian distribution is attained, it is then reasonable to conjecture that the density function ")#mi("{f}")#text(" must converge (in some suitable topology) to a Maxwellian distribution. Furthermore, even though the ")#mi("{H}")#text(" theorem allows the Maxwellian distribution to be non-homogeneous in space, the transportation aspects of the Boltzmann equation should serve to homogenise the spatial behaviour, so that the limiting distribution should in fact be a homogeneous Maxwellian. In a remarkable 72-page ")#emph[#text("tour de force")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2116276")[#text("Desvilletes and Villani")]#text(" showed that (under some strong regularity assumptions), this was indeed the case, and furthermore the convergence to the Maxwellian distribution was quite fast, faster than any polynomial rate of decay in fact. Remarkably, this was a ")#emph[#text("large data")]#text(" result, requiring no perturbative hypotheses on the initial distribution (although a fair amount of regularity was needed). As is usual in PDE, large data results are considerably more difficult due to the lack of perturbative techniques that are initially available; instead, one has to primarily rely on such tools as conservation laws and monotonicity formulae. One of the main tools used here is a quantitative version of the H theorem (also obtained by Villani), but this is not enough; the quantitative bounds on entropy production given by the H theorem involve quantities other than the entropy, for which further equations of motion (or more precisely, differential inequalities on their rate of change) must be found, by means of various inequalities from harmonic analysis and information theory. This ultimately leads to a finite-dimensional system of ordinary differential inequalities that control all the key quantities of interest, which must then be solved to obtain the required convergence.")

#heading(level: 1)[#text("Comments (67)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-2/#comment-488293")[#strong[#text("Laudationes de las medallas Fields 2010 | Ciencia | La Ciencia de la Mula Francis")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2017")]

#text("[…] técnico de los 4 nuevos Medalla Fields recomiendo la entrada del genial Terence Tao, “Lindenstrauss, Ngo, Smirnov, Villani,” What’s New, 19 August, 2010, que como siempre, lo […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Birkar, Figalli, Scholze, Venkatesh | What's new")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-2/#comment-503569")[#strong[#text("Birkar, Figalli, Scholze, Venkatesh | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("[…] the two previous congresses in 2010 and 2014, I wrote blog posts describing some of the work of each of the winners. This time, though, I happened to be a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ICM 2010 Índia 17-27 Agosto – Congresso Internacional de Matemáticos « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46558")[#strong[#text("ICM 2010 Índia 17-27 Agosto – Congresso Internacional de Matemáticos « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("[…] poderá ficar a saber as áreas em que se destacaram pelas suas contribuições; ou então no post Lindenstrauss, Ngo, Smirnov, Villani do Professor Terry Tao, no seu blog, que dá exemplos do trabalho de cada um dos premiados com a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2a0ddac0f8c671da2ba7fdb3b4846f38a51bfcbbf7ee2fd51c4f6eb91fd0c119-edb178af56f9ae87010efb533f43e1eae702ec47d73f77ab424b8b0b063bb849.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Lin")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46560")[#strong[#text("Kevin Lin")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("Thanks for writing this! Minor correction: Hitchin, not Hitchen.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cad542da5efa7e581bbbd0c55341fcb569176c1eb6cf2c3de30cbad82365565a-d2ccb5246660e13ebdcaece28deb6796063f097cf9e8287a3788ceef7901f51c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jailton Viana")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46750")[#strong[#text("Jailton Viana")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("Mister Terence ,very good your texts about the international congress of mathematics.It was only by your blog that I knew of the awards on this event .Congratulations for your work.But where do you find time to prepare this amounts of mathematical news?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42b855f49d776a562d6da8385077f8f9f83039ef67f24522585bdeca76d18fdf-32b61eaa93c2ea19d88f1aba1438cd4a412e852cf74ed8503fd77574c43cfcd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felipe Zaldivar")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46561")[#strong[#text("Felipe Zaldivar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("Re: Ngo Bao Chau’ work, I guess you mean “Hitchin fibration”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b12fff728949bd163d993f0e9c1ef0ab688e75246d6fa169143cd939530872c6-e598a8ceeabbf4e151ed32ea6674b619019fa085be299dbcd892176ee8c943b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rod")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46562")[#strong[#text("Rod")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("terry you are much more bad ass then these people. your name is catchy and more recognizable. When I think of the fields medal, I think of you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("In the part for Lindenstrauss, the links for both Littlewood conjecture and almost every are not right. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46567")[#strong[#text("Medalla Fields 2010 « Series Divergentes")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")]

#text("[…] Lindestrauss, Ngo, Smirnov, Villani (What’s new). Terry Tao discute detalles sobre el trabajo de cada uno de los medallistas. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46574")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("I don’t know if he is a stickler about this, but it seems every non-French website forgets the accent on his first name: it is Cédric Villani…")

#text("More interestingly, he gave a colloquium lecture two years ago in Zürich on entropy and the Boltzmann equation which was taped and can be found ")#link("http://www.multimedia.ethz.ch/speakers/zurich_physics_colloquium/?doi=10.3930/ETHZ/AV-7d60c880-f6b0-4b65-9ddc-d8197372afb9")[#text("here")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9adc4a944494870794b36e81325f4f42ab601a227ae5cedcbf8f5b1c0b0a114d-53ba2eb0eb9f0d6bb5a48549fba4328c98ad698dfb6a2d9848d83b99ecebf493.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Willie Wong")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46584")[#strong[#text("Willie Wong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("Thanks for the link to the video.")

#text("p.s. While one instance does not make sufficient evidence, his own website (in the title bar) also forgets the accent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4b48b712fd5757288d408d356f12dec9e0fccde6e90cc397f0e94e649c5dc89-a1b40d7783295271178c53ac89a80a891448e409c5f68333f4991a15e695264e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Norailyain")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46587")[#strong[#text("Norailyain")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("Vietnamese accents on *Ngô Bảo Châu*’s correctly-spelled full name are also often forgotten, for they are not easy to be typed on an usual Western keyboard.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46575")[#strong[#text("AMS Graduate Student Blog » Blog Archive » Discussion of Fields Medalists")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")]

#text("[…] is an interesting post by Terry Tao on some of the work of this years Fields Medal Winners. Category: General, Math […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46576")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 19 August 2010")])]

#text("Another short comment concerning Ngo’s work (about which I am also far from expert): the Langlands program concerns both number fields (e.g., the rationals) and function fields over finite fields (e.g., one-variable polynomials over a fixed finite field); those two type of base fields are quite different. In particular, geometric interpretations and arguments are usually much more natural and easier over function fields (for instance, Lafforgue’s work, which led him to received a Fields medal in 2002, was over function fields). Part of the reason Ngo’s work is certain to be exceptionally useful is that it concerns both number fields and function fields. If I understand things right, he works mostly in the function field setting, and appeals to results of Waldspurger to transfer the (or some of the) results to number fields. (This transfer also has a recent different proof, I think, due to Cluckers and Denef).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a6d7bfaab15d364e5b49865f28111b03bffa68435b4bdfcda74c51b42070a12-acae0d9c2b0ceb8fc191ea449781973da58d9d8338a5b301c554d0aca602f46e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46581")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("You might want to look at ")#link("http://sbseminar.wordpress.com/2009/09/24/a-partial-explanation-of-the-fundamental-lemma-and-ngos-proof/")[#text("Joel’s post")]#text(" on Ngo’s work over at our blog. Now to digest the other three…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46586")[#strong[#text("What does Green Mean? » (Bringing) Order to Disorder")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] Take this winner, for instance, Cedric Villani of France, who calculated the rate at which entropy is increasing – there seems to be some sort of throttle on the rate at which the world is falling apart. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46588")[#strong[#text("Hiện tượng Ngô Bảo Châu và bài học cho chúng ta! « Thích toán học")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] Châu đã giải quyết được, nhưng qua bài điểm qua các giải fields năm nay của Terry Tao thì thấy 3 người trong 4 người giải quyết các bài toán liên quan tới Vật lý: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46592")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("To my surprise, when I went to the Caltech Math Department yesterday morning (my B.S. in Math was there, 1973, and I have formally applied to be in their Grad program recently, though I’ve been an Adjunct Professor of Math some years ago). To my shock, nobody there seemed to have heard about Smirnov. 17 hours after I’d posted a write-up on Facebook, I emailed the Caltech PR department. They have, this morning, emailed back to say that they’ll soon be posting a story, using not only my notes, but my link to your thread. Thank you for the umpteenth time, Terry Tao!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46602")[#strong[#text("Top Posts — WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] Lindenstrauss, Ngo, Smirnov, Villani As is now widely reported, the Fields medals for 2010 have been awarded to Elon Lindenstrauss, Ngo Bao Chau, Stas […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46603")[#strong[#text("Fields Medalists « Tsourolampis Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] were announce in IMU. Their names: Lindenstrauss, Ngo, Smirnov and Villani. Terence Tao has a post in his blog where he highlights certain achievements of the Medalists. I was also very pleased to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46608")[#strong[#text("ICM2010 — Ngo laudatio « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] has written descriptions of their work for a general audience and Terence Tao has now posted about the work of the Fields medallists and the other prizewinners. And as I have already said, the ICM website has links to the full texts […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ef267ee10255c7aa9b8c5a4407ef538c8c4127c84beb45c59228e7cbe9033c0-eddb9040c87b17f43d78b50096ad241d5d19c7b3c09452667878b675adf574c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Ben-Zvi")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46614")[#strong[#text("David Ben-Zvi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("Dear Terry, thanks for the wonderful explanations!")#linebreak()#text(" Regarding Ngo, It seems to me the beauty and fundamental nature of the subject and his work is made inaccessible to most by the technical nature of official accounts. I gave what I hope was an accessible – and certainly very informal, to the point of inaccuracy – talk on the fundamental lemma – notes and video at ")#link("http://media.cit.utexas.edu/math-grasp/David_Ben-Zvi_lecture.html")[#text("http://media.cit.utexas.edu/math-grasp/David_Ben-Zvi_lecture.html")]#linebreak()#text(" (a much better attempt by David Nadler will appear in the Bulletin of AMS I")#linebreak()#text(" believe)… In any case, to summarize, in my outsider view Ngo has made a great breakthrough in")#linebreak()#text(" our understanding of the relation between eigenvalues, characteristic")#linebreak()#text(" polynomials and conjugacy classes of matrices, in a form suited to deepen the")#linebreak()#text(" ancient theme of the relation between conjugacy classes and representations in")#linebreak()#text(" groups…")#linebreak()#text(" David")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46615")[#strong[#text("Watch the Math! | Sun Ju's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")]

#text("[…] Terence Tao also gave his personal exposition (here and here) on the remarkable work of Prize winners in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2d5d5d1954b727612fa7bf67cac84de167cb7ac22b6081a606b82453bc222e21-2a1c1164307a180bc4b93133204e5a901df020a286a7bc2d4814dd072a2f9253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Asaf")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46621")[#strong[#text("Asaf")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("Dear Terry, thanks for the explanation.")

#text("About the work of Lindenstrauss (and Margulis), it seems that the first paper which related problems in the geometry of numbers to the area of homogeneous spaces was a 1950s paper by J. Cassels and H. Swinnerton-Dyer called “On the Product of Three Homogeneous Linear Forms and Indefinite Ternary Quadratic Forms”, although the connection was implicit.")#linebreak()#text(" It’s unclear (at least to me) if Margulis knew about that paper in the time (it seems that the paper was forgotten during the years).")

#text("Nowdays, it’s very common to referring to this paper as the starting point, at least this is how Elon considers the histroy.")#linebreak()#text(" See for example Margulis’ lecture about the Oppenheim conjecture in “Fields Medallists’ Lectures” and the wikipedia entry “Oppenheim Conjecture”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("Thanks for the reference! Now that you mention it, I dimly recall this paper being cited (perhaps in one of Margulis’s lectures).")

#text("I also was told once that Serre was able to interpret Ramanujan’s famous congruences for the partition function in terms of the dynamics of SL_2 on the modular curve (possibly over the p-adics; I vaguely recall that Hecke operators were involved somehow). This isn’t exactly geometry of numbers, but it might be in a similar spirit nevertheless.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46626")[#strong[#text("ICM2010 — Smirnov laudatio « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")]

#text("[…] (which then has amazing consequences thanks to the work of Lawler, Werner and Schramm). See Tao’s blog post for more on this. And more recently Smirnov has proved conformal invariance for the Ising model in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46627")[#strong[#text("ICM2010 — Villani laudatio « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")]

#text("[…] just looked at Tao’s post on the Fields medallists and my understanding is such that I’m not even quite certain which of the above three […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46629")[#strong[#text("P נגד NP ומדליות פילד. שתי הערות לסדר היום | ניימן 3.0")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")]

#text("[…] חשבתי לכתוב פוסט קצר בעברית שמסביר דוגמא, ברורה יחסית, שקשורה לעבודתו של אלון. אבל זו הרבה עבודה יחסית, והעצלנות פה גוברת על התמורה. כך שבמקום זאת, אשלח אתכם לשני מאמרים נהדרים, באנגלית, שמסבירים פחות או יותר מדוע הבחור זכה לכבוד. הראשון מהאתר הרשמי של הקונגרס המתמטיקה בהודו (פה. pdf). השני הוא של טרנס טאו הבלתי נלאה. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5d06a1da18a50ebc7a9bfb52c1488f8b1a998309feb22dce5101294227f315c7-850f082c8d3a111855639dec6fb204547f5e05cffd889ab402a4d777c019ede9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2010")])]

#text("Why we have not a field medalist in “pure” mathematics?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36e1a62ff4ff0d2f998a9e4819e737e30bc142e1a6d855e656b6b3dde78953e8-65575f2bfa69f1773a4a52b6030504ac425e27b21b45897c6a13c0434352f784.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lindenstrauss, Ngo, Smirnov, Villani (via What’s new) « Math Society the club")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46634")[#strong[#text("Lindenstrauss, Ngo, Smirnov, Villani (via What’s new) « Math Society the club")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2010")])]

#text("[…] As is now widely reported, the Fields medals for 2010 have been awarded to Elon Lindenstrauss, Ngo Bao Chau, Stas Smirnov, and Cedric Villani. Concurrently, the Nevanlinna prize (for outstanding contributions to mathematical aspects of information science) was awared to Dan Spielman, the Gauss prize (for outstanding mathematical contributions that have found significant applications outside of mathematics) to Yves Meyer, and the Chern medal (for … Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46637")[#strong[#text("Terrence Tao on 2010 Fields medalists « The Other Side of Moon")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2010")]

#text("[…] Terrence Tao on 2010 Fields medalists 2010年08月23日 dualm 留下评论 Go to comments Lindenstrauss, Ngo, Smirnov, Villani […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46644")[#strong[#text("Terence Tao viết về huy chương Fields năm 2010 « Lenhoty's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2010")]

#text("[…] về bốn huy chương Fields năm 2010. Sau đây là toàn văn diễn giải của giáo sư Lindenstrauss, Ngo, Smirnov, Villani Còn bạn muốn dành sự quan tâm nhiều hơn một chút tới Chương trình Langlands và […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd453f44ac4b5697b65734773476abb8478f4868f119b6d7436092ed6347e59f-895fdcc0c9d8159482a31c2a3bfa2d9c92f2022a87c043251159deb11ae6bb40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dominiczypen")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46647")[#strong[#text("dominiczypen")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2010")])]

#text("Re: Elon Lindenstrauss and the Littlewood conjecture, for what ")#mi("\\alpha")#text(" do we have ")#tao-math("\\lim \\inf_{n\\to\\infty} n\\left\\|n\\alpha\\right\\| > 0", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46649")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2010")])]

#text("Quadratic numbers such as the golden ratio ")#mi("\\phi = \\frac{1+\\sqrt{5}}{2}")#text(" are an example, as one can see from the classical properties of Fibonacci numbers. I think there is a way to characterise these numbers in terms of the continued fraction expansion; a quick back-of-the-envelope calculation suggests that what one needs is that the terms in this expansion stay bounded. (Quadratic numbers have an eventually periodic continued fraction expansion and so are definitely of this form.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a718fe0ae1ce222ea33275174bc93b6011081a9ba6d690bd7cf9c39f0317e62a-6170224188d25c8da1133b3e3d9c851d6c93c48eb9e4532aaaf759d38dceb8b4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mfrasca")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46658")[#strong[#text("mfrasca")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("Hi Terry,")

#text("About the work of Villani I would like to comment that, while this gives deep foundations to all the area of kinetic equations and statistical mechanics, yet we miss here an important point, based on the Loschmidt paradox (see ")#link("http://en.wikipedia.org/wiki/Loschmidt%27s_paradox")[#text("http://en.wikipedia.org/wiki/Loschmidt%27s_paradox")]#text(" ). Boltzmann equation rather implies irreversibility from the start and does not give a proof of it. Indeed, following Loschmidt criticism, Boltzmann was forced to introduce a hypothesis in his proof (molecular chaos or Stosszahlansatz, see ")#link("http://en.wikipedia.org/wiki/Molecular_chaos")[#text("http://en.wikipedia.org/wiki/Molecular_chaos")]#text(" ) implying that we need a proof of it to have a final demonstration of irreversibility. This is an open question in physics yet and could require an analysis starting from many-body quantum mechanics and quantum master equations.")

#text("Regards,")

#text("Marco")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46664")[#strong[#text("Giải Nevalina 2010 « Vuhavan's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")]

#text("[…] đề này rất gần với Universality (hay Invariance) principle trong toán vật lý (xem bài của Tào về Smirnov). Nôm na mà nói, thường ta tin rằng một định lý đúng với một mô hình (hay […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46667")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("One little typo: “awared”. ")#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/294c4ff35da05f0523e6354b8c143920c93d6331e23d9039d8d8cd8bab78fb05-75f6be02c0c1a1dcbaa913aebf37087cab5731b7d02cda1715f8d5ec4dbbfcca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of inkspot")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46673")[#strong[#text("inkspot")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2010")])]

#text("“… modular curve $SL_2(R)/SL_2(Z)$…” A merely terminological point: this is a $3$-manifold, the unit tangent bundle (in a stacky sense) over [what is usually called] the modular curve $SO_2(R)\\backslash SL_2(R)/SL_2(Z)$. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46683")[#strong[#text("Videos of Fields medalists 2010 lectures at ICM in Hyderabad « Successful Researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")]

#text("[…] a discussion of their work see e.g. this post of Terence Tao and the official […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f1cfbb41d667f80dfaf38542b1fba2dec62a8042655e70bf952a655afd164482-c2dd9ec48770d31caa38e2d0809f16d189f790bf890a34e5839b41b42733ba0d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miscellanées « Hady Ba’s weblog")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46688")[#strong[#text("Miscellanées « Hady Ba’s weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("[…] où l’auteur demande qu’on lui explique le programme de Langlands puis dériver vers ce post de Terry Tao où il explique les travaux de chacun des médaillés de cette année. Si vous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46691")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("You are still the coolest Field Medallist for having this awsome blog…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russell Lyons")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46697")[#strong[#text("Russell Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2010")])]

#text("Hi, Terry.")

#text("Re Stas’s work:")

#text("I think it is worth pointing out that it was Carleson who noted the form taken by Cardy’s formula in the case of an equilateral triangle. Stas even calls it the “Cardy-Carleson” formula in this case. Furthermore, this particular conformal invariance was conjectured by Aizenman.")

#text("Also, it is interesting that this whole problem was first popularized among mathematicians by Langlands, whose 1992 AMS Colloquium Lectures were partly devoted to it and who published an influential article with Pouliot and St-Aubin (")#link("http://www.ams.org/journals/bull/1994-30-01/home.html")[#text("http://www.ams.org/journals/bull/1994-30-01/home.html")]#text(") in 1994.")

#text("Best,")#linebreak()#text(" Russ")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46709")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2010")])]

#text("Thanks for the references!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46702")[#strong[#text("Las medallas Fields 2010 | Gaussianos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2010")]

#text("[…] Tao nos habla en su blog de los galardonados con la medalla […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46761")[#strong[#text("ICM2010 — final post « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2010")]

#text("[…] Terence Tao on the work of Lindenstrauss, Ngo, Smirnov and Villani […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/abffa09c500faecb8705951eb7f2b185311b080188e03cd5a0b3b1a934ca6e1d-1d7ff34fbdca5b1d6bd974f014ace44847c3ae402435ce26786f6aa134ba1f0f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mathematics on public radio « Xi'an's Og")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46785")[#strong[#text("Mathematics on public radio « Xi'an's Og")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2010")])]

#text("[…] abound! I found the panelists did a very good job last Wednesday night. (Note that Terry Tao gave a summary of the four panelists’ achievements on his blog.) In linking pure and applied maths, ie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35c65fd371e7790b1cbb2810e28f89b97b9221e060b8c39639a57ba1f64d4d3f-b34329660638148f6ce3a28539f6c646b62e93aeea91e2ac712105e40acf9b84.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fields Medal 2010 « Suhaimi Ramly")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-46956")[#strong[#text("Fields Medal 2010 « Suhaimi Ramly")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2010")])]

#text("[…] I do not have any comment regarding the winners since I am not really familiar with their work. Terry Tao, who has plenty of intelligent things to say about everything math, explains the works of the winners here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-47631")[#strong[#text("Mabruk Elon, India, and More « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")]

#text("[…] their works along with informal descriptions that you can find on this page, you can also look at Terry Tao’s blog and at Gowers’ blog. The ICM lectures of the prize winners can be found on this page and they […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a1c0729754a5831d15c016e49d8df86edee83e15d3d801b6bf09c34574b4a39-5221f8f2b3d20fe7a82fc382f4831eb20e1d23c3d9725bc1c36ba3c9b2112d74.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On Self-Avoiding Walks | Honglang Wang's Blog")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-49004")[#strong[#text("On Self-Avoiding Walks | Honglang Wang's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2010")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/ (a")[#text("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/ (a")]#text(" post about the winners in icm2010, including this area) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f32339931e6d5a23927cbf3292c0357279696dfd4f369ca295eca97f045399e-1ff92aed8dd633408b0eeb2a019bbec7e1ffd57e75d323af180fba36a5cf8ccf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of It’s just another talk, to be honest « It's cold outside")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-49810")[#strong[#text("It’s just another talk, to be honest « It's cold outside")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/")[#text("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5fee6a8440fec79c5bf663d56433432875072e8bc793cf9742994f51a060b2b-58272268b7c306a61b182be321f546df60b362c36da4a0bdad5692a4f76e58e8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giải Nevanlinna 2010 « MFEPE")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-56984")[#strong[#text("Giải Nevanlinna 2010 « MFEPE")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2011")])]

#text("[…] đề này rất gần với Universality (hay Invariance) principle trong toán vật lý (xem bài của Tào về Smirnov). Nôm na mà nói, thường ta tin rằng một định lý đúng với một mô hình (hay […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2499df23d7b3d308918ff345957883bb4c0bc5eac5237f8a707551f872395eb6-5aa292973633595ef1320f73612c344486d37f26582648fc1e887d209bc0a3c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-62145")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2011")])]

#text("Regarding the work of Cedric Villani on the Boltzmann equation, I have a couple of questions related to your first model, the one with the densities ${f(t,v_1), f(t,v_2), f(t,v_3), f(t, v_4)$ . Can these four densities be thought of as probability distributions parameterized by time?")#linebreak()#text(" The second question relates to statistical ensembles. Suppose at time $t=0$ we have $N$ gas molecules in a box with $N$ very large. Each molecule has three position coordinates and three momentum coordinates. The state of the system is described by $6N$ real numbers. If the box or container is attached to a very large mass, such as the earth, the velocity (and hence")#linebreak()#text(" momentum) of the container can be approximated by")#linebreak()#text(" zero. With conservation of total kinetic energy and")#linebreak()#text(" of total momentum of all $6N$ molecules, under")#linebreak()#text(" Newtonian mechanics, the system has $6N-6$ degrees of")#linebreak()#text(" freedom. The set of states can be taken as a closed and")#linebreak()#text(" bounded subset of $R^{6N}$, of dimension $6N-6$.")#linebreak()#text(" If $\\mu$ is a probability measure on the $6N-6$-dimensional set (for time $t=0$), then, roughly")#linebreak()#text(" speaking, following Newtonian mechanics and the laws")#linebreak()#text(" for inelastic collisions of molecules with molecules,")#linebreak()#text(" molecules with the container, at time $t>0$ one")#linebreak()#text(" might get a probability distribution $mu_t$ on")#linebreak()#text(" the bounded subset of $R^{6N}$ of dimension $6N-6$.")

#text("Does Villani’s work imply some kind of convergence")#linebreak()#text(" of an arbitrary probability distribution $mu$ as")#linebreak()#text(" above (following Newtonian mechanics) to")#linebreak()#text(" Maxwellian distributions? Lastly, it’s not")#linebreak()#text(" clear to me what to make the diameters of")#linebreak()#text(" the molecules: for inter-molecular collisions,")#linebreak()#text(" one would need a strictly positive diameter.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-62164")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2011")])]

#text("Dear Dave,")

#text("One can certainly consider probabilistic models in which collisions occur according to some Poisson-type process, in which case the densities ")#mi("f(t,v)")#text(" can be viewed as probability intensities for such a process. This would however be a probabilistic simplified model for the (deterministic) N-body collision problem, rather than a perfectly accurate description of the latter problem.")

#text("Villani’s work works within the Boltzmann framework, which is only a simplified model of the full N-particle system (in particular, it assumes the molecular chaos hypothesis). So it does not directly give any rigorous results concerning the full system (which is substantially more complicated than the Boltzmann model), but it is certainly conceivable that Villani’s work will play a role in the future study of that system and of its approximability to the Boltzmann model.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-204469")[#strong[#text("Matthew Kennedy awarded CMS 2012 Doctoral Prize « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2012")]

#text("[…] work. Tim Gowers and Terry Tao have set a fine example in their expositions of the works of Fields Medalists or Abel Prize laureates. These are among the most interesting and important posts out […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7365d26ecb21910b5a1817c3649395d6bd4ba42b58d3b8db7733aec76f59848-dc42d7ae27fd4ba6ddac44a242adfadfb08f5656ed5b461ec56e4ed105f07a69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.G.")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-238049")[#strong[#text("T.G.")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2013")])]

#text("Professor Tao,")

#text("Here is a poll to test people’s expectations for 2014: ")#link("https://sites.google.com/site/fieldsmedal2014poll/")[#text("https://sites.google.com/site/fieldsmedal2014poll/")]

#text("T.G.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7365d26ecb21910b5a1817c3649395d6bd4ba42b58d3b8db7733aec76f59848-dc42d7ae27fd4ba6ddac44a242adfadfb08f5656ed5b461ec56e4ed105f07a69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.G.")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-238180")[#strong[#text("T.G.")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2013")])]

#text("One more question was added to the poll.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/112694a366c1f6b193951b68314bc3d4757a69db709c3ddf11067886db443027-62f9bcf01e580e4cb982052f472101a81f613b128dc9e8a9319459548196458f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eric")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-238296")[#strong[#text("Eric")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2013")])]

#text("Thanks for the input, that was fun!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7365d26ecb21910b5a1817c3649395d6bd4ba42b58d3b8db7733aec76f59848-dc42d7ae27fd4ba6ddac44a242adfadfb08f5656ed5b461ec56e4ed105f07a69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.G.")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-238427")[#strong[#text("T.G.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2013")])]

#text("Eric, no problem. Bhargava, Lurie and Avila are clear leaders but it’s a surprisingly tight race for the fourth place!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.G.")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-238708")[#strong[#text("T.G.")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2013")])]

#text("Favorites after first 101 votes are:")

#text("Bhargava – 42, Lurie – 31, Avila -30, Naor – 20.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7365d26ecb21910b5a1817c3649395d6bd4ba42b58d3b8db7733aec76f59848-dc42d7ae27fd4ba6ddac44a242adfadfb08f5656ed5b461ec56e4ed105f07a69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.G.")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-239461")[#strong[#text("T.G.")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2013")])]

#text("After 160 votes:")

#text("Bhargava – 64, Avila – 50, Naor – 41, Lurie – 40.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-239536")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2013")])]

#text("This survey might have a flaw… the names are alphabetically sorted so the results look biased towards the #1 and #2. Poor Akshay ")#strong[#text("V")]#text("enkatesh and Scott ")#strong[#text("S")]#text("heffield!")

#text("Standard survey design issues – the ordering of choices is known to make a huge difference in survey decisions. It needs to be random.")#linebreak()#text(" ")#link("http://www.howto.gov/customer-experience/collecting-feedback/basics-of-survey-and-question-design")[#text("http://www.howto.gov/customer-experience/collecting-feedback/basics-of-survey-and-question-design")]#linebreak()#text(" ")#link("http://help.surveymonkey.com/articles/en_US/kb/Design-Tips-How-to-create-and-administer-effective-surveys")[#text("http://help.surveymonkey.com/articles/en_US/kb/Design-Tips-How-to-create-and-administer-effective-surveys")]

#text("It’s still fun to speculate. I’m still busy trying to understand what happened in 2010.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7365d26ecb21910b5a1817c3649395d6bd4ba42b58d3b8db7733aec76f59848-dc42d7ae27fd4ba6ddac44a242adfadfb08f5656ed5b461ec56e4ed105f07a69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.G.")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-239541")[#strong[#text("T.G.")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2013")])]

#text("This is not an issue because we are dealing with mathematicians. As you can see, the average over the bottom half is bigger. As for 2010, I recommend to start by reading the papers Terry Tao discusses in the post above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-239544")[#strong[#text("David")]]#text(size: 9pt, fill: rgb("596477"), " · 24 July 2013")])]

#text("This is exactly what happened in 2010. I hope the Fields Committee this year will not forget to sort the nominees in random order.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7365d26ecb21910b5a1817c3649395d6bd4ba42b58d3b8db7733aec76f59848-dc42d7ae27fd4ba6ddac44a242adfadfb08f5656ed5b461ec56e4ed105f07a69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of T.G.")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-242287")[#strong[#text("T.G.")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2013")])]

#text("The survey is now complete, and a new poll is released:")

#link("https://sites.google.com/site/fieldsmedal2014poll/")[#text("https://sites.google.com/site/fieldsmedal2014poll/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avila, Bhargava, Hairer, Mirzakhani | What's new")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-404903")[#strong[#text("Avila, Bhargava, Hairer, Mirzakhani | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2014")])]

#text("[…] which is a new initiative of the IMU and the Simons foundation). This time last year, I wrote a blog post discussing one result from each of the 2010 medallists; I thought I would try to repeat the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-420733")[#strong[#text("My great WordPress blog – Econlinks: Of Maths, Efficiency, and Language")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] Tao brief and informative on the 2010 Fields medalists (Le Monde est aussi très heureux et honoré pour Ngo et Villani, “deux facettes de […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5fee6a8440fec79c5bf663d56433432875072e8bc793cf9742994f51a060b2b-58272268b7c306a61b182be321f546df60b362c36da4a0bdad5692a4f76e58e8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giải Nevanlinna 2010 | MFEPE")]], [#link("https://terrytao.wordpress.com/2010/08/19/lindenstrauss-ngo-smirnov-villani/comment-page-1/#comment-486426")[#strong[#text("Giải Nevanlinna 2010 | MFEPE")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2017")])]

#text("[…] đề này rất gần với Universality (hay Invariance) principle trong toán vật lý (xem bài của Tào về Smirnov). Nôm na mà nói, thường ta tin rằng một định lý đúng với một mô hình (hay […]")
]
