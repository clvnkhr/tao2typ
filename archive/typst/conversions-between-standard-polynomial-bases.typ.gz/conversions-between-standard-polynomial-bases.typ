// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/
// Converted to Typst by tao2typ: "2026-10-14T16:38:32.507422+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Conversions between standard polynomial bases", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Conversions between standard polynomial bases")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 April 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/")[#text("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("(This post is mostly intended for my own reference, as I found myself repeatedly looking up several conversions between polynomial bases on various occasions.)")

#text("Let ")#mi("{\\mathrm{Poly}_{\\leq n}}")#text(" denote the vector space of polynomials ")#mi("{P:{\\bf R} \\rightarrow {\\bf R}}")#text(" of one variable ")#mi("{x}")#text(" with real coefficients of degree at most ")#mi("{n}")#text(". This is a vector space of dimension ")#mi("{n+1}")#text(", and the sequence of these spaces form a ")#link("https://en.wikipedia.org/wiki/Filtered_algebra")[#text("filtration")]#text(":")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Poly}_{\\leq 0} \\subset \\mathrm{Poly}_{\\leq 1} \\subset \\mathrm{Poly}_{\\leq 2} \\subset \\dots")]]

#text("A standard basis for these vector spaces are given by the monomials ")#mi("{x^0, x^1, x^2, \\dots}")#text(": every polynomial ")#mi("{P(x)}")#text(" in ")#mi("{\\mathrm{Poly}_{\\leq n}}")#text(" can be expressed uniquely as a linear combination of the first ")#mi("{n+1}")#text(" monomials ")#mi("{x^0, x^1, \\dots, x^n}")#text(". More generally, if one has any sequence ")#mi("{Q_0(x), Q_1(x), Q_2(x)}")#text(" of polynomials, with each ")#mi("{Q_n}")#text(" of degree exactly ")#mi("{n}")#text(", then an easy induction shows that ")#mi("{Q_0(x),\\dots,Q_n(x)}")#text(" forms a basis for ")#mi("{\\mathrm{Poly}_{\\leq n}}")#text(".")

#text("In particular, if we have ")#emph[#text("two")]#text(" such sequences ")#mi("{Q_0(x), Q_1(x), Q_2(x),\\dots}")#text(" and ")#mi("{R_0(x), R_1(x), R_2(x), \\dots}")#text(" of polynomials, with each ")#mi("{Q_n}")#text(" of degree ")#mi("{n}")#text(" and each ")#mi("{R_k}")#text(" of degree ")#mi("{k}")#text(", then ")#mi("{Q_n}")#text(" must be expressible uniquely as a linear combination of the polynomials ")#mi("{R_0,R_1,\\dots,R_n}")#text(", thus we have an identity of the form")

#align(center)[#tao-fit-display[#mitex("Q_n(x) = \\sum_{k=0}^n c_{QR}(n,k) R_k(x)")]]

#text("for some ")#emph[#text("change of basis coefficients")]#text(" ")#mi("{c_{QR}(n,k) \\in {\\bf R}}")#text(". These coefficients describe how to convert a polynomial expressed in the ")#mi("{Q_n}")#text(" basis into a polynomial expressed in the ")#mi("{R_k}")#text(" basis.")

#text("Many standard combinatorial quantities ")#mi("{c(n,k)}")#text(" involving two natural numbers ")#mi("{0 \\leq k \\leq n}")#text(" can be interpreted as such change of basis coefficients. The most familiar example are the binomial coefficients ")#mi("{\\binom{n}{k}}")#text(", which measures the conversion from the shifted monomial basis ")#mi("{(x+1)^n}")#text(" to the monomial basis ")#mi("{x^k}")#text(", thanks to (a special case of) the binomial formula:")

#align(center)[#tao-fit-display[#mitex("(x+1)^n = \\sum_{k=0}^n \\binom{n}{k} x^k,")]]

#text("thus for instance")

#tao-aligned(keep: true)[


#tao-math("(x+1)^3  & = \\binom{3}{0} x^0 + \\binom{3}{1} x^1 + \\binom{3}{2} x^2 + \\binom{3}{3} x^3", block: true)



#tao-math(" & = 1 + 3x + 3x^2 + x^3.", block: true)
]

#text("More generally, for any shift ")#mi("{h}")#text(", the conversion from ")#mi("{(x+h)^n}")#text(" to ")#mi("{x^k}")#text(" is measured by the coefficients ")#mi("{h^{n-k} \\binom{n}{k}}")#text(", thanks to the general case of the binomial formula.")

#text("But there are other bases of interest too. For instance if one uses the ")#link("https://en.wikipedia.org/wiki/Falling_and_rising_factorials")[#text("falling factorial basis")]

#align(center)[#tao-fit-display[#mitex("(x)_n := x (x-1) \\dots (x-n+1)")]]

#text("then the conversion from falling factorials to monomials is given by the ")#link("https://en.wikipedia.org/wiki/Stirling_numbers_of_the_first_kind")[#text("Stirling numbers of the first kind")]#text(" ")#mi("{s(n,k)}")#text(":")

#align(center)[#tao-fit-display[#mitex("(x)_n = \\sum_{k=0}^n s(n,k) x^k,")]]

#text("thus for instance")

#tao-aligned(keep: true)[


#tao-math("(x)_3  & = s(3,0) x^0 + s(3,1) x^1 + s(3,2) x^2 + s(3,3) x^3", block: true)



#tao-math(" & = 0 + 2 x - 3x^2 + x^3", block: true)
]

#text("and the conversion back is given by the ")#link("https://en.wikipedia.org/wiki/Stirling_numbers_of_the_second_kind")[#text("Stirling numbers of the second kind")]#text(" ")#mi("{S(n,k)}")#text(":")

#align(center)[#tao-fit-display[#mitex("x^n = \\sum_{k=0}^n S(n,k) (x)_k")]]

#text("thus for instance")

#tao-aligned(keep: true)[


#tao-math("x^3  & = S(3,0) (x)_0 + S(3,1) (x)_1 + S(3,2) (x)_2 + S(3,3) (x)_3", block: true)



#tao-math(" & = 0 + x + 3 x(x-1) + x(x-1)(x-2).", block: true)
]

#text("If one uses the binomial functions ")#mi("{\\binom{x}{n} = \\frac{1}{n!} (x)_n}")#text(" as a basis instead of the falling factorials, one of course can rewrite these conversions as")

#align(center)[#tao-fit-display[#mitex("\\binom{x}{n} = \\sum_{k=0}^n \\frac{1}{n!} s(n,k) x^k")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^n = \\sum_{k=0}^n k! S(n,k) \\binom{x}{k}")]]

#text("thus for instance")

#align(center)[#tao-fit-display[#mitex("\\binom{x}{3} = 0 + \\frac{1}{3} x - \\frac{1}{2} x^2 + \\frac{1}{6} x^3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^3 = 0 + \\binom{x}{1} + 6 \\binom{x}{2} + 6 \\binom{x}{3}.")]]

#text("As a slight variant, if one instead uses ")#link("https://en.wikipedia.org/wiki/Falling_and_rising_factorials")[#text("rising factorials")]

#align(center)[#tao-fit-display[#mitex("(x)^n := x (x+1) \\dots (x+n-1)")]]

#text("then the conversion to monomials yields the unsigned Stirling numbers ")#tao-math("{\\left|s(n,k)\\right|}", block: false)#text(" of the first kind:")

#align(center)[#tao-fit-display[#mitex("(x)^n = \\sum_{k=0}^n |s(n,k)| x^k")]]

#text("thus for instance")

#align(center)[#tao-fit-display[#mitex("(x)^3 = 0 + 2x + 3x^2 + x^3.")]]

#text("One final basis comes from the ")#link("https://en.wikipedia.org/wiki/Polylogarithm")[#text("polylogarithm functions")]

#align(center)[#tao-fit-display[#mitex("\\mathrm{Li}_{-n}(x) := \\sum_{j=1}^\\infty j^n x^j.")]]

#text("For instance one has")

#tao-aligned(keep: true)[


#tao-math("\\mathrm{Li}_1(x)  & = -\\log(1-x)", block: true)



#tao-math("\\mathrm{Li}_0(x)  & = \\frac{x}{1-x}", block: true)



#tao-math("\\mathrm{Li}_{-1}(x)  & = \\frac{x}{(1-x)^2}", block: true)



#tao-math("\\mathrm{Li}_{-2}(x)  & = \\frac{x}{(1-x)^3} (1+x)", block: true)



#tao-math("\\mathrm{Li}_{-3}(x)  & = \\frac{x}{(1-x)^4} (1+4x+x^2)", block: true)



#tao-math("\\mathrm{Li}_{-4}(x)  & = \\frac{x}{(1-x)^5} (1+11x+11x^2+x^3)", block: true)
]

#text("and more generally one has")

#align(center)[#tao-fit-display[#mitex("\\mathrm{Li}_{-n-1}(x) = \\frac{x}{(1-x)^{n+2}} E_n(x)")]]

#text("for all natural numbers ")#mi("{n}")#text(" and some polynomial ")#mi("{E_n}")#text(" of degree ")#mi("{n}")#text(" (the ")#emph[#text("Eulerian polynomials")]#text("), which when converted to the monomial basis yields the (shifted) ")#link("https://en.wikipedia.org/wiki/Eulerian_number")[#text("Eulerian numbers")]

#align(center)[#tao-fit-display[#mitex("E_n(x) = \\sum_{k=0}^n A(n+1,k) x^k.")]]

#text("For instance")

#tao-aligned(keep: true)[


#tao-math("E_3(x)  & = A(4,0) x^0 + A(4,1) x^1 + A(4,2) x^2 + A(4,3) x^3", block: true)



#tao-math(" & = 1 + 11x + 11x^2 + x^3.", block: true)
]

#text("These particular coefficients also have useful combinatorial interpretations. For instance:")

#list(
[#text("The binomial coefficient ")#mi("{\\binom{n}{k}}")#text(" is of course the number of ")#mi("{k}")#text("-element subsets of ")#mi("{\\{1,\\dots,n\\}}")#text(".")],
[#text("The unsigned Stirling numbers ")#tao-math("{\\left|s(n,k)\\right|}", block: false)#text(" of the first kind are the number of permutations of ")#mi("{\\{1,\\dots,n\\}}")#text(" with exactly ")#mi("{k}")#text(" cycles. The signed Stirling numbers ")#mi("{s(n,k)}")#text(" are then given by the formula ")#tao-math("{s(n,k) = (-1)^{n-k} \\left|s(n,k)\\right|}", block: false)#text(".")],
[#text("The Stirling numbers ")#mi("{S(n,k)}")#text(" of the second kind are the number of ways to partition ")#mi("{\\{1,\\dots,n\\}}")#text(" into ")#mi("{k}")#text(" non-empty subsets.")],
[#text("The Eulerian numbers ")#mi("{A(n,k)}")#text(" are the number of permutations of ")#mi("{\\{1,\\dots,n\\}}")#text(" with exactly ")#mi("{k}")#text(" ascents.")]
)

#text("These coefficients behave similarly to each other in several ways. For instance, the binomial coefficients ")#mi("{\\binom{n}{k}}")#text(" obey the well known Pascal identity")

#align(center)[#tao-fit-display[#mitex("\\binom{n+1}{k} = \\binom{n}{k} + \\binom{n}{k-1}")]]

#text("(with the convention that ")#mi("{\\binom{n}{k}}")#text(" vanishes outside of the range ")#mi("{0 \\leq k \\leq n}")#text("). In a similar spirit, the unsigned Stirling numbers ")#tao-math("{\\left|s(n,k)\\right|}", block: false)#text(" of the first kind obey the identity")

#align(center)[#tao-fit-display[#tao-math("\\left|s(n+1,k)\\right| = n \\left|s(n,k)\\right| + \\left|s(n,k-1)\\right|", block: true)]]

#text("and the signed counterparts ")#mi("{s(n,k)}")#text(" obey the identity")

#align(center)[#tao-fit-display[#mitex("s(n+1,k) = -n s(n,k) + s(n,k-1).")]]

#text("The Stirling numbers of the second kind ")#mi("{S(n,k)}")#text(" obey the identity")

#align(center)[#tao-fit-display[#mitex("S(n+1,k) = k S(n,k) + S(n,k-1)")]]

#text("and the Eulerian numbers ")#mi("{A(n,k)}")#text(" obey the identity")

#align(center)[#tao-fit-display[#mitex("A(n+1,k) = (k+1) A(n,k) + (n-k+1) A(n,k-1).")]]

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87fcdf948ed4a24fdb21db199cbbcb2dc5973c8b1dd607a450ca667cfca0b38f-a63cdb090ca0c34d07f7a5cad08a9df60dd7a1ee47d738fa208d560597727ebb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Per Ekman")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514639")[#strong[#text("Per Ekman")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")])]

#text("As someone that’s currently learning a bout the Binomial Theorem on my free time this couldn’t have been posted at a better time.")#linebreak()#text(" Thank you so much for sharing!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asahay22")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514640")[#strong[#text("asahay22")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")])]

#text("Hmmm, do the basis change coefficients from the standard basis to an orthogonal basis relative to some integral inner product (e.g. Chebyshev polynomials) also have a combinatorial interpretation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514646")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")])]

#text("The basis change coefficients between the classical orthogonal polynomials and the monomial basis tend to be variants of binomial coefficients (for instance they often are expressible as ratios of products of factorials, times some other simple factors like powers of 2). For instance to convert monomials ")#mi("x^n")#text(" to Chebyshev polynomials ")#mi("T_k(x)")#text(", one has the identity ")#mi("x^n = \\sum_{k=0}^n 2^{1_{k \\neq 0}-n} \\binom{n}{(n-k)/2} T_k(x)")#text(" (with the convention that the binomial coefficient vanishes if the bottom argument is not an integer).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/001285b92333340239a104e427924550a420acf5d064394650c5220328c739c2-ce664b615b465d4326e554bc2f60928cec7e16c8318c0b52d6d2eb640b74e646.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jake")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514677")[#strong[#text("Jake")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2019")])]

#text("See also things like Salzer’s method : ")#link("https://dl.acm.org/citation.cfm?doid=355611.362548")[#text("https://dl.acm.org/citation.cfm?doid=355611.362548")]#text(" and this chebfun discussion : ")#link("http://www.chebfun.org/examples/cheb/FastChebyshevLegendreTransform.html")[#text("http://www.chebfun.org/examples/cheb/FastChebyshevLegendreTransform.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514682")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2019")])]

#text("The coefficients of (weighted) orthogonal polynomials expansion can also be evaluated by their corresponding (weighted) integral representation as inner products.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bbd1c5586275751f8862892da0ddb8a1eaaba210633a9df1eb330599cf5f4bb2-7913f9a06f21062ad4fd5c5a4df6c5d1e362badc241ab0d9736f3895f5a28f42.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lou")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514652")[#strong[#text("Lou")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2019")])]

#text("Very nice. Any analogues for multivariate polynomials?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514794")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("See e.g. spherical harmonics (which are orthogonal polynomials on the unit sphere ")#mi("S^2")#text(", or the more general ")#mi("S^n")#text(" with respect to its Haar measure) with application to polynomial approximation on spheres.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd366d60058a5a463c592880db8bcad746981d9cf730e5e200b2aa3963f3eb6a-8cd11ef2cf4d09d96bc08e5ac907ccc87b4f84cbadc84a240767b5f7fbc22aff.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Sánchez Terraf")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514665")[#strong[#text("Pedro Sánchez Terraf")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2019")])]

#text("Dear Terry,")#linebreak()#text(" in the second line of the post you might like “…one variable x and of degree at most $n$”.")#linebreak()#text(" Best wishes!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/994e265f2c0ce92cd86b1443a7501e96ee170f1cd677d88ea5f7875b8068c08a-06db246c3c9f10ca307f6a406728634259056d0e42f65efad6caf2f2206daaa8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of greghighermathhelp")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514676")[#strong[#text("greghighermathhelp")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2019")])]

#text("I was just learning about the calculus of finite differences last week, where the conversion of monomials into falling factorials allows for the evaluation of sums of kth powers, which I learned is a problem with a very long history. Now here it is again, with a nice connection to binomial coefficients and other combinatorial quantities! Thanks for fleshing this out.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514696")[#strong[#text("Conversions between standard polynomial bases - Nevin Manimala's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2019")]

#text("[…] by /u/HigherMathHelp [link] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c6ddc266250e232f77ba32147a3add382397d854e674a84a6731bd4ab1098b82-e9f827008d4dba7c8895ae817d518fa34a9789d3fec9442a06301fe3166a6459.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of LaurentC")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514698")[#strong[#text("LaurentC")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2019")])]

#text("There may lack a “minus” in your formula of $Li_1=-\\long(1-x)$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arch1")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514743")[#strong[#text("Arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2019")])]

#text("2nd paragraph of the post proper: “…can be expressed uniquely as *a linear combination of* the first n+1 monomials…”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c89853cdf26cf84543916280076886c3245aaf95e36280c118bb169cd5ce3eb-6ff672ca546e1797098d69ba2edfcba305202a2280f9150ba7f4c1660f23a294.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raymond E Rogers")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514757")[#strong[#text("Raymond E Rogers")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("You can systematize a lot of polynomial conversions and sequences by means of Sheffer generating functions and substituting an appropriate “creation” matrix for the indexing variable; giving a coefficient matrix. The Appell sequences are straightforward, and the generalized forms (Sheffer) require going through the matrix Jordan form.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29dbe0a9c8105c1103187ea3eca8f5deec3966b8dad586a6168daafc61418d2f-87627a80b6f46cff2ec16d5aa8e51db24bb7fe1aff8ece60b7162344df9267ec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rodolfo Niborski")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514789")[#strong[#text("Rodolfo Niborski")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2019")])]

#text("Three formulas from the bottom :")#linebreak()#text(" “and the signed counterparts” instead of “unsigned”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Burger")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514867")[#strong[#text("Ralph Burger")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("I once tried to find an explicit transformation for Fibonacci polynomials from ")#mi("F_n(x+1)")#text(" to the ")#mi("F_m(x)")#text(" basis, but failed to get a recursion free expression. Any ideas on that?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("The first thing I would suggest is to compute the first few coefficients and enter that into the OEIS to see if you get a hit. (For instance, the Stirling numbers of the first kind appear as ")#link("https://oeis.org/A008275")[#text("https://oeis.org/A008275")]#text(" , the Stirling numbers of the second kind appear as ")#link("https://oeis.org/A008277")[#text("https://oeis.org/A008277")]#text(" , and the Eulerian numbers appear as ")#link("https://oeis.org/A008292")[#text("https://oeis.org/A008292")]#text(" .) If the sequence is not already in the OEIS, you can of course submit it in case some future researcher also stumbles upon it.")

#text("As an alternative to the OEIS one can also simply do a web search for some of the specific large numerical coefficients that you find. (For instance, if you pick a handful of large unsigned Stirling numbers of the first kind, such as 109584, 22449, and 13132, and do a web search, many of the hits will relate to the Stirling numbers.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raphael Berger")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514877")[#strong[#text("Raphael Berger")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("Thanks a lot for replying (my grandchildren will hear that)! OEIS is a great suggestion; I did it, just didn’t mention it, thought that won’t fit the small margin here (")#link("https://math.stackexchange.com/questions/2731420/variable-transformation-x-to-x1-in-fibonacci-polynomial-f-nx")[#text("https://math.stackexchange.com/questions/2731420/variable-transformation-x-to-x1-in-fibonacci-polynomial-f-nx")]#text(") ;-) So its not there, and afaiu 2D sequences are not really supported by OIES. (Since we already meet, I have a thought on the Töplitz conjecture, you don’t happen to have a post on it here?). All the best!! — Raphael B.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c89853cdf26cf84543916280076886c3245aaf95e36280c118bb169cd5ce3eb-6ff672ca546e1797098d69ba2edfcba305202a2280f9150ba7f4c1660f23a294.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raymond E Rogers")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514881")[#strong[#text("Raymond E Rogers")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("I might not understand but the recursion in these cases (rational polynomial generating functions) is always the denominator applied to the series, with the numerator acting as startup/arbitrary constants.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/03e5910e8b61abd35ae2a87e9541c9570a8a79f5016cd42e5a42e4809f7682ff-f37e9ccc79a1f755b0a8c8e86941bc5bde3c63054e1f9c809a468140cea2117e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ralph Burger")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514883")[#strong[#text("Ralph Burger")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("I do not understand exactly what you mean by apply, but as I wrote, the recursion is the easy bit, I aimed at the recursion-FREE expression (which might be a bad literal translation from the german “rekursionsfrei” and could be possibly paraphrased: “non-recursive”).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c89853cdf26cf84543916280076886c3245aaf95e36280c118bb169cd5ce3eb-6ff672ca546e1797098d69ba2edfcba305202a2280f9150ba7f4c1660f23a294.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raymond E Rogers")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514888")[#strong[#text("Raymond E Rogers")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("As I read it, you want the closed form of the generating function? In that case, just substitute your x+1 into the generating function and do a partial fraction expansion on it. Then solve the first order terms in closed form. We should probably move this discussion out of this forum.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af9853f04dfe22ed2a56bd62e551ec0fe31be52959a7add64cd63cd6ad3e50c7-be9f8885044f629a3c3b4ab4e39b74a40d46109b40071b7e11a1be02cec27201.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raymond Rogers")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514896")[#strong[#text("Raymond Rogers")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2019")])]

#text("It occurs to me that you just want new coefficients? In an elementary form: just write out the polynomial as a coefficient array times a verticle base array; say (C_(x+1))*B1(X+1) Now expand (x+1)^n and you see it’s just a summation of binomial entries times X. Treat it as a convolution (or some such) and you see that you can convert the base to P()*B2(X) Where P() is the Pascal matrix with terms (n,k). Having rewritten it, you just use “associativity” and the new polynomial coefficients are C_x=C_(x+1)*P() and the new polynomial (actually the same one) reads C_x*B2(x). I hope this is closer to what you want.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514904")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("Dear Raymond, thank you for your suggestion. My email is ")#link("mailto:berger@chem.helsinki.fi")[#text("berger@chem.helsinki.fi")]#text(". Maybe its better to continue")#linebreak()#text(" by email.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-514905")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("ps. in the link to math stack exchange you seeexactly how far i got. the problem is the secobd step after the binom. expansion to get back to fibonacci polynomials in x.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9a3207776ebe80184079d7b9bf120d700b99e5527bc168b2524bba0499981c55-77acb1fdac7b79c943c6cad929c02ef5b116e2cafe018ee312687e8ed0264c39.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JDM")]], [#link("https://terrytao.wordpress.com/2019/04/07/conversions-between-standard-polynomial-bases/#comment-515013")[#strong[#text("JDM")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2019")])]

#text("I’m going to confess that I thought a lot of the discussion of Hilbert spaces of Lp spaces could be ameliorated if we use a basis of some kind. Has anyone in number theory computed a Gowers norm yet?")
]
