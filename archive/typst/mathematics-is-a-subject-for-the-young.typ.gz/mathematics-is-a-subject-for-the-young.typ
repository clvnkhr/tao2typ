// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/
// Converted to Typst by tao2typ: "2026-10-27T12:29:45.093547+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics is a subject for the young", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics is a subject for the young")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/")[#text("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-27 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://cims.nyu.edu/~tristanb/")[#text("Tristan Buckmaster")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("This blog post expands on a theme mentioned at the end of ")#link("https://www.ias.edu/math/events/members-colloquium-106")[#text("my recent talk")]#text(" at the ")#emph[#text("Institute for Advanced Study")]#text(" on October 19.")

#emph[#text("I would like to thank Matei Coiculescu, Jaume de Dios Pont, Nestor Guillen, Bryna Kra, Terence Tao and Rachel Ward for their valuable comments and suggestions.")]

#text("It is often said that mathematics is a young person’s game, and that mathematicians do their best work early in their careers. I believe this is about to become true in a completely different sense. Mathematics is changing faster than at any point in its history. Today’s graduate students and postdocs will shape its future. Our responsibility is to protect their ideas and recognize their contributions.")

#text("In ")#link("https://cims.nyu.edu/~tristanb/statement.pdf")[#text("my statement on September 7th")]#text(", the night ")#link("https://alpo.ge")[#text("Levent Alpöge")]#text(" and I released ")#link("https://cims.nyu.edu/~tristanb/euler.pdf")[#text("our Euler result")]#text(" and the day before ")#link("https://openai.com/index/navier-stokes-solution/")[#text("OpenAI announced its Navier–Stokes result")]#text(", I wrote that we had reached a ")#emph[#text("Deep Blue–Kasparov")]#text(" moment. ")#link("https://en.wikipedia.org/wiki/Deep_Blue_versus_Garry_Kasparov")[#text("When Deep Blue beat Kasparov in 1997")]#text(", the headline was that a machine had surpassed one of the greatest chess players of all time. Beyond just marking the moment a machine eclipsed human intellect, I chose this analogy because of the nature of the machine itself. Deep Blue was a purpose-built IBM supercomputer, entirely inaccessible to the general public. Today a program on a mobile phone plays far stronger chess than Deep Blue ever did.")

#text("This is where I think mathematics is now. OpenAI’s proof ")#link("https://www.cnbc.com/2026/09/09/openai-navier-stokes-math-problem-solved.html")[#text("reportedly required the coordination of 10,000 agents over 88 hours")]#text(", ")#link("https://www.scientificamerican.com/article/openai-unleashes-hundreds-more-math-results-upon-a-field-already-in-shock/")[#text("at an estimated cost in the millions")]#text(" to solve a problem with ")#link("https://www.claymath.org/millennium/navier-stokes-equation/")[#text("a $1 million bounty")]#text(". At present, computation on this scale is entirely out of reach for the wider mathematical community. However, given the exponential growth in capabilities paired with decreasing costs, such a comparable computation may soon be more broadly accessible.")

#text("The question is no longer whether machines can do research mathematics, but how the subject will change as a result.")

#text("Chess did not die with the advent of modern chess engines. Engines democratized high-level preparation, resulting in the most globally diverse generation of top players ever. When I told a reporter that ")#link("https://www.abc.net.au/news/2026-09-11/racing-to-solve-maths-problems-pointless-tristan-buckmaster-says/107141628")[#text("“the game is up,”")]#text(" I meant to describe the end of the academic rat race, the race to be the first to resolve a famous open problem is over. Mathematics as a subject is not.")

#text("Mathematics differs from chess in one important way, though: it is not performative. Chess survives partly because people love watching humans play. I am not going to convince anyone to watch two Fields medallists duke it out on a livestream proving a theorem. What gives it lasting relevance is something else: human understanding.")

#text("Suppose that tomorrow a machine certifies a proof of ")#link("https://www.claymath.org/millennium/riemann-hypothesis/")[#text("the Riemann hypothesis")]#text(" — whether with pages of AI slop or via ")#link("https://en.wikipedia.org/wiki/Lean_%28proof_assistant%29")[#text("a Lean file")]#text(". No one doubts that the Riemann hypothesis is true. A certification would convert thousands of conditional theorems into unconditional ones. Mathematicians would still be left with the question: ")#emph[#text("why")]#text(" is it true? ")#link("https://terrytao.wordpress.com/2026/09/12/after-math/")[#text("De Toffoli and Duede")]#text(" captured this perfectly with their reference to Deep Thought, the computer in ")#emph[#link("https://en.wikipedia.org/wiki/The_Hitchhiker%27s_Guide_to_the_Galaxy")[#text("The Hitchhiker’s Guide to the Galaxy")]]#text(" that analyzes the meaning of life for 7.5 million years and returns the answer “42.”")

#text("Mathematics has never been a list of true statements. Certifying a result settles the question, not the search for understanding.")

#strong[#text("Bridging mathematics and physics: ")]#text("One area I see as an exciting prospect for applying modern AI systems is the intersection of mathematics and physics. Indeed, I do not believe it is a surprise that some of the most exciting results to come out of AI so far have been in mathematical physics. Historically, mathematics and physics were inextricably linked, each serving as inspiration for the other: Newton developed calculus to formulate classical mechanics, Fourier analysis grew out of the study of thermal diffusion, Riemannian geometry supplied the mathematical underpinning of general relativity, and the needs of quantum mechanics shaped functional analysis. In the past decades, however, mathematics and physics have diverged. Physics is driven by heuristic arguments that are not true in the strictest sense, but are morally true and allow one to arrive at the correct answer. Quantum field theory is the standard example, where renormalization and the path integral make remarkably accurate predictions while still lacking a rigorous foundation. Closing the gaps in physical derivations is immensely challenging, and this is a key reason for the divergence of the fields. Rigorous derivation is not just an exercise in pedantry. It points to gaps in the physical theory, identifies the precise regimes and time scales on which an effective description is valid, and provides clues towards a more complete theory.")

#text("In years preceding the advent of AI in mathematics, a beautiful example of success in this pursuit, is ")#link("https://arxiv.org/abs/2104.11204")[#text("Deng and Hani’s derivation of the wave kinetic equation")]#text(" as a large box limit of the nonlinear Schrödinger equation. Later, with Ma, they gave ")#link("https://arxiv.org/abs/2408.07818")[#text("an analogous derivation of the Boltzmann equation from hard-sphere dynamics")]#text(" for as long as the Boltzmann solution exists, ")#link("https://arxiv.org/abs/2503.01800")[#text("resolving Hilbert’s sixth problem for rarefied gases")]#text(". The combinatorial analysis behind these results is a tour de force, and it took years of work. LLMs could potentially allow us to carry out such a program for other effective theories, where doing it by hand would frankly be out of reach. Ultimately, one could hope that LLMs will allow us to extend this standard of rigorous proof to all branches of the physical sciences.")

#strong[#text("Protecting our ideas: ")]#text("Currently, there are some fundamental structural problems in terms of how AI companies interact with the mathematical community.")

#text("AI companies, who strip mine our data, including unpublished work, private notes and research grant applications, have an egregious conflict of interest in competing against their own customers with unlimited resources and internal models unavailable to the public — this is not confined to mathematics but applies more broadly. ")#link("https://openai.com/index/navier-stokes-solution/")[#text("By OpenAI’s own account")]#text(", its push on the Millennium problems was spurred by rumors that a rival had solved two of them — demonstrating that caution, due diligence, and basic ethics can be cast aside simply to avoid being one-upped by a rival.")

#text("On October 6th, ")#link("https://github.com/openai/math")[#text("OpenAI released hundreds of manuscripts")]#text(" with proofs that were mostly unreadable and in some cases false. In the release, ")#link("https://decrypt.co/380366/openai-secret-ai-model-cracked-hundreds-math-problems-one-prompt")[#text("they misleadingly claimed that the work took on average three hours of computation on a single agent")]#text(": ")#link("https://www.scientificamerican.com/article/openai-unleashes-hundreds-more-math-results-upon-a-field-already-in-shock/")[#text("they later admitted that they did not count numerous failed attempts at the problems")]#text(" ")#link("https://github.com/openai/math/blob/main/README.md#L5")[#text("as well as previous work done by other agents")]#text(" — rendering the three hours claim essentially meaningless. Again, OpenAI did essentially no due diligence, failing to investigate whether once again they may be building on the private, unreleased work of their customers, some of whom were graduate students and postdocs who were literally days away from releasing their own work.")

#link("https://x.com/polynoamial/status/2093451221273387477")[#text("In August, OpenAI claimed")]#text(" that ")#link("https://x.com/nihilunbounded/status/2108084325631832126")[#text("such a dump would be `distasteful’")]#text(", that their `main focus is shipping great models so everyone can use them to make discoveries of their own’. After Navier–Stokes, OpenAI had teased us with supposed solutions to additional Millennium problems, yet they achieved none. A natural question is to ask why OpenAI would go through with such a PR stunt that risks alienating their customers. These companies are spending tens of billions of dollars a year more than they earn, which helps to explain their thirst for PR stunts and their willingness to take such seemingly inexplicable risks.")

#text("Mathematicians now type half-formed ideas into commercial models every day. These sessions are invaluable to an AI company: they provide a road map of our thought process, and reveal which research directions are promising. Until recently, AI-assisted proofs of important mathematical results were considered a pipe dream, and many of us were simply not concerned with data privacy since we never imagined today’s capabilities arriving so quickly.")

#text("It is imperative to protect our ideas and not let AI companies become the ultimate gatekeepers of knowledge. In this vein, I would like to see:")

#list(
[#text("Collective enterprise agreements with AI companies should become ubiquitous. Many universities already have institutional agreements with AI providers, and these offer far better protections than consumer agreements. Even so, such agreements could be further strengthened by including ")#emph[#text("zero data retention")]#text(" clauses and auditing provisions to ensure that the conditions of the agreements are respected. Many mathematicians, myself included, do their research on consumer subscriptions that those agreements do not cover. We need to make sure all academics work under the protection of such agreements.")],
[#text("We need stricter regulatory guardrails on user data. More generally, we need stricter regulations governing how AI companies collect data. Training on user data must be explicitly opt-in rather than opt-out. Finally, deceptive practices, such as absorbing an entire session’s worth of data as a result of a user providing feedback on a single response, must be explicitly banned.")],
[#text("We should further invest in open-weight infrastructure, assisting in the development of open-weight models. We cannot assume the interests of Academia and the AI companies are aligned. Academic institutions that control where their models are run can circumvent the fear of having their ideas stolen by trillion dollar corporations. Chess was democratized by engines anyone could run at home. Shared, open infrastructure for mathematics, funded in an independent way, is a lofty goal worth pursuing.")]
)

#text("Less reliance on user data benefits both sides: leading to more trust from the academics and the encouragement of new innovative ways to train models.")

#strong[#text("Recognizing contributions: ")]#link("https://www.youtube.com/watch?v=M0--ZH1lOzg&t=285s")[#text("As Tao put it at the ICM this summer")]#text(", we are moving from an ")#emph[#text("era of proof scarcity")]#text(" to an ")#emph[#text("era of proof abundance")]#text(". Our credit system was built for the era of scarcity. Being first to a famous result was a reasonable proxy for depth of understanding, because nobody could get there without understanding a great deal along the way. That proxy no longer holds and so we will need new ways of assigning credit that are not simply correlated with access to resources.")

#text("Some concrete suggestions:")

#list(
[#text("Reward well written exposition of important results in mathematics.")],
[#text("AI disclosures are a mixed bag and there is currently a perverse incentive not to disclose the use of AI. Disclosing AI assistance should not diminish a result and detailed disclosures should become standard.")],
[#text("Development of shared tools and resources, as well as contributions to large collaborative projects should earn recognition, mimicking practices in other sciences.")],
[#text("Mathematicians should be evaluated on the ideas and methods they developed, not just on whether or not they were first to prove a result.")]
)

#text("More generally, we will need to move away from bean counting publications in top journals. Whatever replaces it must still offer transparent ways of evaluating work, rather than relying on reputation and personal connections, which tends to produce closed networks and patronage.")

#strong[#text("The future of mathematics: ")]#text("Chess did not end in 1997. Mathematics will not end in 2026. I am however convinced that within the next few years it will be unrecognizable. That future will not be shaped by me or my peers. It will be shaped by the next generation.")

#text("I am already amazed by what our students and postdocs at NYU are doing with these tools. I suspect that in their hands the line between pure and applied mathematics will blur further, perhaps disappear, and that we will see a richer connection between mathematical proofs and the physical sciences.")

#text("For the next generation of mathematicians to flourish, we need protections and control over user data, restraint from AI companies, a lower barrier to entry to the use of frontier-level models, and a new credit system that rewards understanding rather than access. Mathematics has long been said to belong to the young. They will decide what it becomes.")

#emph[#text("AI Disclaimer: I used LLMs to help edit this post, including suggesting wording for some passages. ")]

#heading(level: 1)[#text("Comments (55)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698537")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I wish people would stop saying “young” when what they really mean is “early-career.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698539")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I have seen over and over the comparison with chess most often without the obvious mention of what the main difference is: it’s not whether people would “watch two Fields medallists duke it out on a livestream proving a theorem”, it’s whether this can be a profession for more than around a hundred people in the world")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698569")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("That mostly depends on funding. I can totally imagine the NSF, Simons Foundation, XTX Foundation etc being willing to fund this kind of “Math 2.0”. Plus, if there is more applied math involved, perhaps it will pay for itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9a26d07b23d3b08937d705bf63be4e9cfb155b0c3c71efb989592a9df73904-2fa35e19c5de7c145ea2c70abf3921818c497d07d64ed2ed68245c54b93966ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of objecteclecticf375435795")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698574")[#strong[#text("objecteclecticf375435795")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("The Simons Foundation etc has done great work, but they will certainly not fund hundreds (rather thousands) of math departments around the world.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698582")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I didn’t mention the universities themselves which of course are the main sources of funding. Yes, those as well. Universe fund people to study things that are already out there. We have literature departments, astronomy departments, etc. A math 2.0 department makes sense.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698619")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I think the comparison of Math 2.0 departments as akin to Departments of Literature or Art [within the context of university intellectual values/working conditions/funding] are apt.")

#text("It’s a good mental exercise to determine a future in which this is the norm. A starting point may be to properly familiarize ourselves with the working conditions in our sister departments, and to learn from how they hire/assign credit/supervise students, etc.")

#text("-Nilima Nigam")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nic")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698540")[#strong[#text("Nic")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("While I am grateful for this posti, just want to share my desconsolation (as a reader) at the fact that so many texts I read recently seem be written in the same voice or style. Someone tell me I am not the only one 😦")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698647")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Well, those who care to write in a recognizable authentic style still need to write on their own. The writer of this post obviously didn’t care about how it sounds, he just wanted to get his thoughts and ideas across.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Regarding the trajectory from Deep Blue to mobile phones: That was the golden age of Moore’s law. But Moore’s law has ended, so we won’t see that again.")

#text("Regarding the chess analogy: There are a couple of billionaires sponsoring the top tournaments. If AI should get to Stockfish vs. human level, mathematics will not have that support.")

#text("Fortunately, I don’t think AI is remotely there yet.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698658")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("I came to the comments to say pretty much the same. Sure, compute is growing exponentially, but we’ve been in the (increasingly smaller) single % digits of improvement for a decade, and the doubling of computing power between generations ended two decades ago. Maybe we should begin to accept that we’ve reached peak compute, that expected improvements will be marginal, and that, barring some unexpected development in electronics, we won’t see another 10x of raw performance increase. We’ve entered an era of specialization, where most of the improvement will come from specialized hardware and software optimization, and not from better technology, and that comes with strong limitations and tradeoffs.")

#text("Also, a bit of an aside, I don’t know where the author buys their computers, but I’m pretty sure we’re not seeing a decrease in cost, at all. This should normalize in a couple of years, maybe, but still… worst time to make such claim!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698550")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Dear Tristan,")#linebreak()#text("On the topic of protecting our ideas, I have found the essay of Satya Nadella on the reverse information paradox (see ")#link("https://x.com/satyanadella/article/2076323181154230284")[#text("https://x.com/satyanadella/article/2076323181154230284")]#text(") to be particularly insightful. Mathematician aren’t the only ones suffering from IP theft and I believe it would be good to work with other professions inside and outside of academia, which will soon also be as strongly impacted by AI, to revise the current terms of fair use, in addition to your suggestions on how to proceed.")#linebreak()#text("– A physics postdoc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698560")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I don’t think we do a particularly good job at the moment of recognizing the contributions of young mathematicians, even if they stand on the shoulders of giants. I really hope this changes in the near future (including recognizing those who contributed to math that lead to a breakthrough solution within the 722 paper dump).")

#text("I feel a bit iffy about “protecting ideas.” For most people, you sound like a bit of a conspiracy theorist when you accuse OpenAI for stealing your ideas. I still think we should have a culture of being generous with sharing ideas to foster community. Though there should be some restrictions, just like what we have before the AI stuff dropped.")

#text("I very much agree with your vision of mathematical physics, though I think this extends a bit further than merely mathematical physics. Perhaps the era of obsessing over big conjectures of others is over, and a new era of mathematical self-discovery is dawning. Pick a phenomena we encounter in our everyday lives that we don’t understand (I’m sure there are many!) and attempt to understand it, using whatever tools we have available including mathematics!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698568")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Have you seen ")#link("https://citedbyagi.com/")[#text("https://citedbyagi.com/")]#text(" ? It’s a great website!")

#text("I too am skeptical that OpenAI solved Navier-Stokes by looking at Tristan and Levent’s private Codex chats, but it’s true that OpenAI did rush to solve it before them with the internal agents and it is kind of understandable that Tristan would think that. I agree that it would be good if he got over this, and focused on the future of mathematics. The quicker everyone moves on from the OpenAI vs Levent/Tristan/Anthropic fight over NS, the better.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698566")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("What gives [mathematics] lasting relevance is something else: human understanding.")
]

#text("I don’t think this is quite right. ")#emph[#text("We")]#text(" (mathematicians) work for our own personal reasons, including our enjoyment of understanding, but for ")#emph[#text("society")]#text(" mathematics is also useful, in ways that chess isn’t. A proof of the Extended Riemann Hypothesis we could not understand would still make various effectively algorithms unconditionally correct. A mathematical model of high-")#mi("T_\\mathrm{c}")#text(" superconductors could lead to better devices even if only LLMs could understand the model and calculate with it.")

#text("Nearly all our endeavors are paid for by society (whether by the government, for those of us who work in public universities or are paid by government grants, or by private organizations such as those who work in private universities or in industry research labs), and that’s where accountability must ultimately lie. Otherwise we’d return to the historical situation of very few professional mathematicians. Fermat was a jurist; Kronecker was a businessman; Grassmann was a gymnasium teacher.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698573")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Lior, I think EHR is a particularly terrible example. EHR has more experimental and other evidence behind it than just about anything in science; it can simply be taken as true for all practical purposes. The point of a proof of EHR would be both the achievement (assuming it is done by humans; it makes little sense to speak of the achievement of a machine) and the great improvements in understanding it would certainly depend on – if done by humans; without that if, it’s all much less clear, though I suppose one could reverse-engineer *something*.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698652")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Conceded — embarrassing to me since I usually make the “ERH is experimentally true” point in other contexts — so thank you, Harald. But I wouldn’t be so confident a proof of ERH (or any other mathematical advance) wouldn’t lead to further understanding that would have applications. When Minkowski developed his “geometry of numbers” in the late 19th century he didn’t specifically plan for Lattice Cryptosystems to be develped 100 years later. Indeed I shouldn’t have treated ERH (or any particular result) as an end unto itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fdc94626fb3f1d14afd48c0102842980e6950c98012c6b5b6a51777f7788402-4fc6cc3b74447582f22292ac2d32af7fbad470059d4ca65937d23b2547ea7499.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of dpthurst")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698674")[#strong[#text("dpthurst")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("That’s a better point for the use of proving ERH, but isn’t it also very close to Tristan’s original point?")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2fd5eacabd67720620519331aa530f904a802952c0410cbdd4524013d67f345-b77199f927d387ab00906ad9d8deecd1f3282ab7c97221717e82e5934504fdf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698567")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("This post (which on the whole I find excellent) contains two important accusations of dishonesty by OpenAI in describing how much effort their models took to produce these results, both of which are hyperlinked, but (so far as I can see) for only one of them does what’s at the far end of the hyperlink support the accusation. (And even for that one, the claim of dishonesty based on it seems kinda overblown to me.)")

#text("“")#link("https://www.scientificamerican.com/article/openai-unleashes-hundreds-more-math-results-upon-a-field-already-in-shock/")[#text("they later admitted that they did not count numerous failed attempts at the problems")]#text("“: the nearest thing I can find in the linked page is “The OpenAI spokesperson also told ")#emph[#text("Scientific American")]#text(" that some results might have taken multiple attempts.” which doesn’t so far as I can see contradict OpenAI’s earlier claim, which per Tristan’s link claiming that OpenAI falsely claimed to have taken only one prompt for every attempt was “almost everything came from a single prompt handed to a single AI agent, though some may have taken multiple attempts”. I don’t see here either any evidence for “numerous” nor for the alleged discrepancy between their original claim and what they said later.")

#text("“")#link("https://github.com/openai/math/blob/main/README.md#L5")[#text("as well as previous work done by other agents")]#text("“: this links to the README on OpenAI’s GitHub repo for the alleged proofs; this does indeed say “Some outputs build upon earlier results produced by the models.”")

#text("I don’t see that OpenAI ever claimed that literally every result their models claimed to produce came from a single prompt; it looks to me as if what they always said was that that was the case for almost all but some took multiple attempts. So far as I can see, “numerous failed attempts” is pure speculation.")

#text("(I wouldn’t be terrible surprised if it were ")#emph[#text("correct")]#text(" speculation; my opinion of OpenAI’s honesty is not very high. But there’s a difference between “they lied and then admitted it” which is what Tristan is claiming, and “they said something that I suspect was a lie”.)")

#text("As for the “previous work”: clearly this ")#emph[#text("could")]#text(" mean something like “we first of all spent weeks instructing the model to almost-but-not-quite solve problems, and then we gave it a single prompt for each problem asking it to finish the job”, but … well, if I pose a tough problem to a human mathematician and they solve it quickly, I don’t find that less impressive merely because maybe they’ve thought about related things before; the understanding that comes from their having done that is part of why they’re impressive.")

#text("This would all be so very much clearer if OpenAI revealed a lot more about what prompts they fed to their models when. But presumably they see that as commercially sensitive information, and again no one expects human mathematicians to reveal every conversation they have had on some topic before publishing a paper about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698594")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I agree with this reply. I also agree with many aspects of this post, but mostly I agree that there are serious ethical issues and a danger to democracy for the mathematical community if AI companies like openai and anthropic manage to privatize the means of mathematical production. This issue includes the use of internal models and compute not available to ordinary users except through insiders connexion. But it also includes increasingly expensive subscription and not having access to information about the models, their thinking process and their training process (this is why I strongly support new initiatives like open math model).")

#text("However, I can’t help feeling slightly cheated by the post. The talk about early-career mathematicians is well-intentioned and I of course agree, but it seems little little more than a fig leaf for what is the main purpose of the post: accuse openai without, in fact, providing any real evidence. To be clear, I don’t like openai either. But what is ethically different about the way the author of the post has teamed up with Levent, who had no expertise in PDE analysis and fluid mechanics but works for Anthropic and gave him access to Anthropic’s compute and models not accessible to ordinary users? It seems at least possible to me that the author has done on a small scale what he accuses openai to have done on a large scale.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698707")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("Hear hear, and while we are at it with criticizing the transparency of OpenAI’s release, and their failure to investigate conflicts of interest with customer data – can you offer some transparency on your usage of internal Anthropic resources via Levent?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698575")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Can someone please explain what this “democratization” that everybody is talking about means? No professional mathematician in most (non-western) countries is able to pay hundreds of dollars (more than their monthly salary) to professional AI models. So, a US citizen with no relation to mathematics “solving” problems before professional mathematicians from poorer countries is “democracy in mathematics”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698636")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("It was probably a rhetorical question, but in Silicon Valley “democratization” is the marketing term for stealing something, putting it on a web service and then being the new middleman.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99786d589e9a01cfbeb49bb98edcfdd7292ff385fc9a7e7d2fe23f41032f081f-9b4c9b15a5befe7fbaa19f538cb26a3fdf9fb4e255597f2156291100eeb07d32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ziad Baroudi")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698579")[#strong[#text("Ziad Baroudi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I am a maths/IT secondary (middle+high) school teacher, not a mathematician. I read this while supervising a year 10 trigonometry test! Articles like this one give me words I can use when asked by a student whether pursuing mathematics or maths-related degree is worth it in age of AI.")

#text("I want to express my admiration for the mathematicians whose essays I read on this blog. They make me realise how good mathematicians are at deep thinking and clear expression.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698585")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Chess didn’t end, but correspondence chess did.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698589")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("As an undergraduate mathematics student who firmly believes that mathematical research is my “raison d’être”, I find myself grappling with a concern that I suspect many of my generation (and beyond) share. Beyond the familiar stages of grief, perhaps the most pressing question is this: How can someone without an established reputation build one in an era when AI can contribute to mathematical research?")

#text("I fear that, as AI becomes increasingly involved in our field, every new result may be met with the same question: “Did you prove this yourself, without any assistance from AI?” I personally refuse to let AI prove a mathematical statement for me, partly out of pride. But how convincing is this stance—or any more nuanced position—when the real challenge is convincing the mathematical community that one’s work is genuinely one’s own?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698634")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Right now is the in fact the ")#strong[#text("best ")]#text("time to build an established reputation (though I must admit, it is also one of the riskiest times to enter math). It’s just that the most important skill is no longer problem solving ability. Right now in October 2026, the more important skills are creativity, leadership, communication, and teaching.")

#text("Obsessing over conjectures people made decades or centuries ago (such as the twin prime conjecture or the Riemann hypothesis) is and has always been overrated, and now is the best time ever to break out of this tradition. Math has tunnel-visioned far too much on these “important” conjectures when in fact these conjectures are just observed phenomena people made decades or centuries ago. So make more of these observations yourself! There are so many mathematical phenomena we encounter in our everyday lives we hardly understand. Let your imagination go wild!")

#text("You could be a leader in using AI to study these interesting everyday phenomena you see. If people sense that your mathematics and in particular taste is genuine, you will be recognized. Be one of the inspirational heroes the field (which is in chaos) needs. Be the beacon of light that illuminates the path for others.")

#text("Or don’t use AI if you don’t wish to. You don’t need AI to be particularly creative in your approach to mathematics or to lead others past this chaotic period of mathematics.")

#text("P.S. I particularly find Danny Calegari’s view nice: ")#link("https://www.quantamagazine.org/how-failure-has-made-mathematics-stronger-20240522/")[#text("https://www.quantamagazine.org/how-failure-has-made-mathematics-stronger-20240522/")]#text(". See also his response to the 100+ open problems in proofs and prompts: ")#link("https://proofsandprompts.com/2026/10/08/100-reactions-to-100-solutions/comment-page-1/")[#text("https://proofsandprompts.com/2026/10/08/100-reactions-to-100-solutions/comment-page-1/")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2919a2bd6f23d40609e215496608f5bd4261d04e6eca9a5351d85150b239f117-cd24097b516a9fabc44eb06bc0f5e8d5a73a83fe9b7a29b9bc268594a7da7ab0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of generouslydff7bc0de8")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698590")[#strong[#text("generouslydff7bc0de8")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("On chess comparison :")

#text("Chess barely survives today. It is not a career recommended even by the very top players.(There is noone recommending it to their kid, most players regret their career choices.)")

#text("Rules of chess are easy to learn, but difficult to master. Maths is much more difficult and even more difficult to maste. (It takes many years and a career decision just to reach the open set definition.)")

#text("Chess is a board game; maths is at the foundation of all sciences. Losing chess can be bad, but ok., on the other hand we need maths and mathematicians at every generation just to preserve the level of science (a modest goal).")

#text("The main threat is fast dehumanization of maths in a possibly single generation. I am afraid there won’t be any sufficiently well trained humans to check or understand AI output. Can you recommend a youngster a maths career today however he /she is talented? Much more precious maths is at a bigger peril, imo.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698612")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Although there are many examples, “open set” is an unfortunate one. Topology can be taught in elementary school. I have, and the kids get it. The order in which subjects are taught is not only driven by complexity, but also social need and historical inertia play a role. The arithmetic of complex numbers could be learn near the end of elementary school, and it would make simpler other subjects (trigonometry could, in principle, be discarded because of it). We don’t do that, due to history. The ideas developed in a different order, and we keep doing things in that order.")

#text("But yes, lots of other concepts require building on long chains of previous concepts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/42028cd6e661bc59c241127924d6bdc14923cc192886bd1347c4bed05457d946-f12ad66f521690c2a8ac5f1610a907a3ef224301b9186167332a434970ca6e80.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pierre Menard, Author of the Quixote")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698597")[#strong[#text("Pierre Menard, Author of the Quixote")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("One more comparison with chess and I throw myself of a cliff")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698601")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Serre is not young?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698654")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Serre 70+ ")#link("https://link.springer.com/book/9783032107640#overview")[#text("https://link.springer.com/book/9783032107640#overview")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2fd5eacabd67720620519331aa530f904a802952c0410cbdd4524013d67f345-b77199f927d387ab00906ad9d8deecd1f3282ab7c97221717e82e5934504fdf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698603")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I don’t think anyone was ever recommending chess to children (theirs or others’) as a career. (Maaaaybe in the Cold-War-era Soviet Union?) High-level chess has almost always been played by people who learned the game as a child and were instantly fascinated, and continue to play it for the sheer love of the game. Very few chess players can make a living from tournament winnings, and that was always true. Some more can make a living from teaching chess, and that was always true. Nowadays a few more can make a living from chess-as-entertainment, via online video. But it’s never ever been a Sensible Career Choice.")

#text("Mathematics might end up like that as a result of AI, and that would be very bad for mathematicians’ career prospects. But the fact that chess is like that isn’t because computers got good at chess; chess was like that before computers were any good at it.")

#text("(At least, such is my understanding. If someone who’s actually studied the history of chess comes along and contradicts me, I defer to them.)")

#text("For the avoidance of doubt, I don’t see this as particularly encouraging. My argument isn’t “see, computers didn’t hurt chess that much”. Chess wasn’t hurt badly by computers becoming better than humans because chess never really depended on humans being best, even though in fact humans happened to be best for a long time. (Track racing wasn’t hurt badly by bicycles and cars being faster, but cheetahs had always been faster. Weightlifting wasn’t hurt badly by forklift trucks being stronger, but gorillas had always been stronger.) Chess was a way for humans to compete with other humans, and what little money was in it was there because sometimes humans like watching other humans compete with other other humans.")

#text("A lot of mathematics, like almost all chess, is done “for the love of the game”. But a lot of ")#emph[#text("funding")]#text(" for mathematics is premised on its (immediate or eventual or purely hypothetical maybe-way-in-the-future) utility. If it turns out that machines can produce that utility better than mathematicians (a question that’s still at least a bit up for grabs, I think, but I know which way I’d bet) then the people currently paying for mathematics to be done will be unlikely to keep paying humans to do it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65331f44337dc01288f25ba1948469169578b5bc142d9fd0f7a3102a47134b3d-0496f7f2c1fa90c4a48cadf7a431f38d412280dd13d8bbf33927cee6840883d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anatol Wegner")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698605")[#strong[#text("Anatol Wegner")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("“Many kinds of men devote themselves to Science, and not all for the sake of Science herself. There are some who come into her temple because it offers them the opportunity to display their particular talents. To this class of men science is a kind of sport in the practice of which they exult, just as an athlete exults in the exercise of his muscular prowess. There is another class of men who come into the temple to make an offering of their brain pulp in the hope of securing a profitable return. These men are scientists only by the chance of some circumstance which offered itself when making a choice of career. If the attending circumstance had been different they might have become politicians or captains of business. Should an angel of God descend and drive from the Temple of Science all those who belong to the categories I have mentioned, I fear the temple would be nearly emptied. But a few worshipers would still remain—some from former times and some from ours. To these latter belongs our Planck. And that is why we love him.” – Albert Einstein on Max Planck")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/966258889de92c21affd4779c32673f2932ccb3fcc2c1a98cead1e7decd5112e-4f13846a0ac30bcc1a8cf91d066c128ae294357813b7946410ffc692629a8fcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benny Wahwah")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698620")[#strong[#text("Benny Wahwah")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("The AI oligarchs may be playing the role of Einstein’s Angel of God.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65331f44337dc01288f25ba1948469169578b5bc142d9fd0f7a3102a47134b3d-0496f7f2c1fa90c4a48cadf7a431f38d412280dd13d8bbf33927cee6840883d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anatol Wegner")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698606")[#strong[#text("Anatol Wegner")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Those who are willing to work with and accommodate AI companies who are openly working towards the dehumanization and destruction of mathematics as we know it should at least have the decency of leaving the field – there is funding and demand enough for them outside of academia. Those who remain should wake up and focus on putting the AI labs, their machines and minions to shame with the urgency the current situation demands.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698607")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("The suggestion “Reward well written exposition of important results in mathematics.” is not useful. The researcher with more compute power can produce them more successfully and with more volume than the one without. In a very near future, that might be possible with little researcher involvement too.")

#text("The suggestion “Mathematicians should be evaluated on the ideas and methods they developed, not just on whether or not they were first to prove a result.” is not a suggestion. That is already (part of) the case. What is fundamentally different is how to evaluate this little part “they developed”. Here is an actual suggestion, in person contests.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698609")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("I doubt that the loss of the “value of being first” can be replaced. Us humans cannot rewrite our innate values, and being the best (of which being first is a special case) is something we do innately value. Whatever agglomeration of simulated rewards (“recognizing contributions”, “lauding clear exposition”, . . .) we settle on is unlikely to match up.")

#text("This is a permanent demoralization, at best.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698617")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Absolutely every single problem posed at the IMO (and most other competitions) is a problem that already has a solution. None of the students is the first at solving them. Yet, all find plenty of enjoyment finding their own solutions. The best find plenty of recognition and doors opened for career continuation just for solving those non-new problems.")

#text("And why stop at competitions? The entirety of elementary, undergraduate, and even the early graduate studies (for those taking comprehensive exams), are evaluated through already solved problems.")

#text("It is but a minimal change to extend the use of in person examinations/contests to late graduate studies, and early academic career. What is true is that education tends to have large inertia to apply changes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/966258889de92c21affd4779c32673f2932ccb3fcc2c1a98cead1e7decd5112e-4f13846a0ac30bcc1a8cf91d066c128ae294357813b7946410ffc692629a8fcf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benny Wahwah")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698621")[#strong[#text("Benny Wahwah")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("“To this class of men science is a kind of sport in the practice of which they exult, just as an athlete exults in the exercise of his muscular prowess”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698672")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("No complex value is an “innate values”. It is even questionable whether any value at all is innate.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698618")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Tristan single-handedly brought the claim on the table that OpenAI was using private chats and notes in proving their results, and is still pushing it with the 700+ papers. If they could come up with a right approach to Quasi-RH, do they really need your idea?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eac303e6c7471a79961e0e85fe0b187b690f0613fd57b0a9e1d8f5e48630a7f0-75171483cb34b59a6c8a49e96a19e6ca9e61c6c96b2a000115a4810376359fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698640")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("They’d have no clue how to have gotten Quasi-RH without Sarnak’s or others work and it does remain to be seen whether there is anything in the AI generated work that would discourage somelike him to scrab his own general intuition and vision of how to approach the problem.")

#text("Indeed discarding human bias is the huge strength of the bots, in this case the Quasi RH doesn’t explicitly construct any L functions, I think it’s quite interesting to consider how a human and lets say a student who couldn’t have developed much repute yet dropped a paper claiming a result in a well known area but using totally alien methods that are hardly explained well, would the entire community be pouring over it or would they demand they rewrite it?")

#text("Henri Poincare’s philosophical writings point out how nomalism would make science certain but strip it of all significance, sounds a lot like answering questions about fluid mechanics without actually learning anything at all about how fluids behave.")

#text("I don’t think this is the end but it does put significant pressure on academic institution and individuals to get their philosophy and methods right, simultaneously it is immediately disruptive which is destructive to the mediation and time such immense reflection requires, and also raises the issue that this all wasn’t necessarily in order regardless of AI related shocks.")

#text("What are we doing and why are we here? The cults around this technology perhaps should inspire some introspection on the religious orgin of many prestigious institutions. Are we mathematicians concerned about mathematics in the abstract or social oppurtunities and positions, it seems more like the former, and that’s not to shame or dismiss concerns -> should an institution like UCLA continue on like nothing is admiss amid the creation of an AI powered non-democratic surveillance state? The disruption to nominal activity and being forced to philosophize and engage with other realities might just be our friend here")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2fd5eacabd67720620519331aa530f904a802952c0410cbdd4524013d67f345-b77199f927d387ab00906ad9d8deecd1f3282ab7c97221717e82e5934504fdf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698683")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("Scarcely any mathematician ever would have had any clue how to do anything of importance without others’ work.")

#text("(Obviously it’s a different matter if the AIs have been learning from what mathematicians thought was private exploration. Even more so, if they had ticked the “please do not train on my conversations” box. But the mere fact that the AIs made use of existing published work is hardly a criticism of them. That’s how mathematics is ")#emph[#text("supposed")]#text(" to work.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eac303e6c7471a79961e0e85fe0b187b690f0613fd57b0a9e1d8f5e48630a7f0-75171483cb34b59a6c8a49e96a19e6ca9e61c6c96b2a000115a4810376359fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kęstutis")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698687")[#strong[#text("Kęstutis")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("I horrendously made some mistakes typing that, I meant to say at the end it seems like the latter -> we are concerned about social oppurtunities and positions. That is I am in agreement with you and am trying to be a realist")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698696")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("There is little doubt that these systems are autonomously generating some amazing proofs (even if they are hard to read). But the issue of privacy of data is a different matter from this: people have a right to know what’s being done with data they’ve been told remains their own, and the derived data from chats is useful for training (in particular for training on research taste, problem selection, and readability, which aren’t subject to the same type of verifiable rewards as just solving an abstract problem). People have a right to know whether they are contributing to this. For the moment, if AI companies were training only on self-play in math, it seems possible that AI systems would get very good at boring problems with long mechanical proofs, but have no superhuman abilities in the type of math people actually find interesting. (Discerning ‘interest’ via autonomous self-play may be accomplished eventually, but I’m not aware of a robust method to do so yet.)")

#text("If you don’t believe there’s the possibility of something odd going on, try sending ")#link("mailto:privacy@openai.com")[#text("privacy@openai.com")]#text(" an email to ask something like “If I am a paying customer and have opted out in the toggle ‘Improve the model for everyone’, can you assure me that none of the data generated from my prompts is used for model training? I include in this derivatives of my conversation (such as semantic, de-identified, synthetic, etc. representations of it).” See what sort of response you get. It would be in the interest of OpenAI to clarify this yet I’m not aware of them doing so. The language of even their enterprise API contract leaves this ambiguous. In full sincerity, I would be very happy to be corrected on this.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/132e60be994028a0ab28b54dda6695b38a85ea0ef01a8efee4cfd9f0af7eabbc-21646f121b2d3e0cc13ecac40683d597871424129ed8dc99d972680da23c1594.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("There’s no need to hedge bets on this; even the CEO of Microsoft says that most improvement comes from user sessions not self-play. See the article linked by a previous commenter: ")#link("https://x.com/satyanadella/article/2076323181154230284)")[#text("https://x.com/satyanadella/article/2076323181154230284")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/65080bb7d505da14b6a4a164aa715e1712e2136178bc95a773266766eb59b9e3-0d541c1adad19ad7c0ed2e023f1ff966433358b2ba7b24bb61da9fd3c78087bb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of repagulum")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698629")[#strong[#text("repagulum")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("“competing against their own customers with unlimited resources and internal models unavailable to the public”")

#text("Tristan, could you comment, please, you have said yourself previously that you used both internal model and internal compute from Anthropic, obviously both also not available to public. Do or did you consider this to be ok during your research with Levent (and Matei?) on Navier-Stokes and related problems?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("The button for “not training on the prompts” invites malicious compliance:")

#text("As we can see in any search on current political issues, models are very good to use an Internet search and integrate the results into the answer.")

#text("OpenAI could simply store all the prompts in a searchable database, which technically is not training but still use them in a proof.")

#text("Personally, I would not trust even zero data retention agreements. As we know, some people have been reported to the FBI and you need the logs for that.")

#text("Knowing Silicon Valley and the incompetence in security in the AI companies, probably everything is stored but at best not accessed, similar to the fact that it is very hard for a user to actually wipe an email from a web server.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698792")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Thank you for saying this. This is a serious concern about practices of private tech companies that’s obviously credible and completely independent of the capabilities of llms. The number of down votes on your comment and those similar to it makes me think that OpenAI may be astro turfing the comment section of this blog to protect their reputation. This is a high profile blog and they stand to lose a lot with their upcoming IPO")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52ead9b97e19fad13a79c12cca6de2a9f0c14fe8f8a9de494d175340fa838f37-b307c4a338a0b0443966317746dd1f6f48e9a5ad7da195e48e487cc3d1e68bd9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J.Sugar")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698639")[#strong[#text("J.Sugar")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2026")])]

#text("Lot of mathematicians suspect that the classical Riemann hypothesis is NOT true. There are results as back as 1980-s that imply that the classical Riemann hypothesis is not true, especially because some of the strongest tools which were very useful over finite fields clearly do not transfer over to the classical case, and in fact implying that the classical RH is not true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Richard Townsend")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698657")[#strong[#text("Richard Townsend")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("I think it’s likely that in a couple of years, we won’t need humans even to do exposition, communication, teaching etc. AIs will fill that space too – at least, that’s certainly a strong possibility. IMO we need to prepare for a world where all the functions of mathematicians can be done better by AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/132e60be994028a0ab28b54dda6695b38a85ea0ef01a8efee4cfd9f0af7eabbc-21646f121b2d3e0cc13ecac40683d597871424129ed8dc99d972680da23c1594.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2026")])]

#text("It’s disappointing to see so many comments dismiss Tristan’s concerns out of hand. Like many users, I didn’t realize privacy was opt-out by default until recently. Just because OpenAI’s Terms of Service legally allow them to train on user session data doesn’t mean it’s ethically sound.")

#text("Framing this as a claim of direct plagiarizing misses the point entirely. These models synthesize inputs—they aren’t mere “stochastic parrots.” However, user session data remains vital to model improvement, and anyone familiar with these tools understands how valuable that training feedback loop is.")

#text("Consider an analogy: If you casually shared an unfinished, novel idea with a colleague at a conference, and a month later they published a paper built on that exact idea without acknowledging you, you’d rightly feel aggrieved—regardless of whether their paper applied it to a completely different problem, or whether your idea would have ultimately worked for yours.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fe74866dc7400715df2bff0c1dae33905344574137c9eba5c9703facb6d24231-849ce890489a74b498ceea49598476f3cc19d682d13a76e1f5abae7f2ed7c88b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Himanee Arjunwadkar")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698713")[#strong[#text("Himanee Arjunwadkar")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2026")])]

#text("I could manage to browse buckmaster’s essay. I think he talks about a future plan for mathematics, amongst other things. Are there enough funds? I am a well-wisher.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698772")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2026")])]

#text("Excellent post. Mathematics will certainly be very different from what it used to be. AI has already proved its capacity to do excellent mathematical research across all fields at once, which no mathematician can presently do. There will certainly be resistance from all sides, from anxious beginners to editorial boards and prize committees. But the superiority of AI is so overwhelming that this resistance cannot last long; it would soon look ridiculous. The mathematicans society is broken. One might mourn it, but as you say, it will be a relief to be rid of the “bean counting publications in top journals” and to move away from “closed networks and patronage.”")

#text("What, then, will be the future of mathematics? This question belongs to the broader context of the future of all intellectual activities, those at a medium level being easily replaced, at little expense, by machines. So the real question concerns the future of mathematicians, not of mathematics, and it is tied to the future of universities. In many institutions, the teaching duties of mathematicians may increase, particularly if access to top AI is limited, and their research output may become merely anecdotal. There may be no need for as many research mathematicians as today. It is not unlikely that AI companies will provide financial support for research, as some high-frequency trading firms already do. Patronage would not disappear, only change its address, and not necessarily for the worse.")

#text("Since the issue is general and not specific to mathematics, it is very difficult to predict what will happen. But we should not be too pessimistic, nor too encouraging either.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cead9176238007808d93d5f1512cd45031963dec04c7a85cb63fba44dbbacdf-c6104ca163bdd923d15de907d0c507beb294fa182eb1bacacef963a02fbbc601.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jmdpark")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698814")[#strong[#text("jmdpark")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2026")])]

#text("Nice read, thanks Tristan.")
]
