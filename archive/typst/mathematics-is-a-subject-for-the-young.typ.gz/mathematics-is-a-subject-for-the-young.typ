// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/
// Converted to Typst by tao2typ: "2026-10-22T12:09:21.496428+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mathematics is a subject for the young", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mathematics is a subject for the young")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 21 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/")[#text("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-22 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This is a guest post by ")#link("https://cims.nyu.edu/~tristanb/")[#text("Tristan Buckmaster")]#text(". This blog post was initially written in a different file format and converted using AI. — T.]")]

#text("This blog post expands on a theme mentioned at the end of ")#link("https://www.ias.edu/math/events/members-colloquium-106")[#text("my recent talk")]#text(" at the ")#emph[#text("Institute for Advanced Study")]#text(" on October 19.")

#emph[#text("I would like to thank Matei Coiculescu, Jaume de Dios Pont, Nestor Guillen, Bryna Kra, Terence Tao and Rachel Ward for their valuable comments and suggestions.")]

#text("It is often said that mathematics is a young person’s game, and that mathematicians do their best work early in their careers. I believe this is about to become true in a completely different sense. Mathematics is changing faster than at any point in its history. Today’s graduate students and postdocs will shape its future. Our responsibility is to protect their ideas and recognize their contributions.")

#text("In ")#link("https://cims.nyu.edu/~tristanb/statement.pdf")[#text("my statement on September 7th")]#text(", the night ")#link("https://alpo.ge")[#text("Levent Alpöge")]#text(" and I released ")#link("https://cims.nyu.edu/~tristanb/euler.pdf")[#text("our Euler result")]#text(" and the day before ")#link("https://openai.com/index/navier-stokes-solution/")[#text("OpenAI announced its Navier–Stokes result")]#text(", I wrote that we had reached a ")#emph[#text("Deep Blue–Kasparov")]#text(" moment. ")#link("https://en.wikipedia.org/wiki/Deep_Blue_versus_Garry_Kasparov")[#text("When Deep Blue beat Kasparov in 1997")]#text(", the headline was that a machine had surpassed one of the greatest chess players of all time. Beyond just marking the moment a machine eclipsed human intellect, I chose this analogy because of the nature of the machine itself. Deep Blue was a purpose-built IBM supercomputer, entirely inaccessible to the general public. Today a program on a mobile phone plays far stronger chess than Deep Blue ever did.")

#text("This is where I think mathematics is now. OpenAI’s proof ")#link("https://www.cnbc.com/2026/09/09/openai-navier-stokes-math-problem-solved.html")[#text("reportedly required the coordination of 10,000 agents over 88 hours")]#text(", ")#link("https://www.scientificamerican.com/article/openai-unleashes-hundreds-more-math-results-upon-a-field-already-in-shock/")[#text("at an estimated cost in the millions")]#text(" to solve a problem with ")#link("https://www.claymath.org/millennium/navier-stokes-equation/")[#text("a $1 million bounty")]#text(". At present, computation on this scale is entirely out of reach for the wider mathematical community. However, given the exponential growth in capabilities paired with decreasing costs, such a comparable computation may soon be more broadly accessible.")

#text("The question is no longer whether machines can do research mathematics, but how the subject will change as a result.")

#text("Chess did not die with the advent of modern chess engines. Engines democratized high-level preparation, resulting in the most globally diverse generation of top players ever. When I told a reporter that ")#link("https://www.abc.net.au/news/2026-09-11/racing-to-solve-maths-problems-pointless-tristan-buckmaster-says/107141628")[#text("“the game is up,”")]#text(" I meant to describe the end of the academic rat race, the race to be the first to resolve a famous open problem is over. Mathematics as a subject is not.")

#text("Mathematics differs from chess in one important way, though: it is not performative. Chess survives partly because people love watching humans play. I am not going to convince anyone to watch two Fields medallists duke it out on a livestream proving a theorem. What gives it lasting relevance is something else: human understanding.")

#text("Suppose that tomorrow a machine certifies a proof of ")#link("https://www.claymath.org/millennium/riemann-hypothesis/")[#text("the Riemann hypothesis")]#text(" — whether with pages of AI slop or via ")#link("https://en.wikipedia.org/wiki/Lean_%28proof_assistant%29")[#text("a Lean file")]#text(". No one doubts that the Riemann hypothesis is true. A certification would convert thousands of conditional theorems into unconditional ones. Mathematicians would still be left with the question: ")#emph[#text("why")]#text(" is it true? ")#link("https://terrytao.wordpress.com/2026/09/12/after-math/")[#text("De Toffoli and Duede")]#text(" captured this perfectly with their reference to Deep Thought, the computer in ")#emph[#link("https://en.wikipedia.org/wiki/The_Hitchhiker%27s_Guide_to_the_Galaxy")[#text("The Hitchhiker’s Guide to the Galaxy")]]#text(" that analyzes the meaning of life for 7.5 million years and returns the answer “42.”")

#text("Mathematics has never been a list of true statements. Certifying a result settles the question, not the search for understanding.")

#strong[#text("Bridging mathematics and physics: ")]#text("One area I see as an exciting prospect for applying modern AI systems is the intersection of mathematics and physics. Indeed, I do not believe it is a surprise that some of the most exciting results to come out of AI so far have been in mathematical physics. Historically, mathematics and physics were inextricably linked, each serving as inspiration for the other: Newton developed calculus to formulate classical mechanics, Fourier analysis grew out of the study of thermal diffusion, Riemannian geometry supplied the mathematical underpinning of general relativity, and the needs of quantum mechanics shaped functional analysis. In the past decades, however, mathematics and physics have diverged. Physics is driven by heuristic arguments that are not true in the strictest sense, but are morally true and allow one to arrive at the correct answer. Quantum field theory is the standard example, where renormalization and the path integral make remarkably accurate predictions while still lacking a rigorous foundation. Closing the gaps in physical derivations is immensely challenging, and this is a key reason for the divergence of the fields. Rigorous derivation is not just an exercise in pedantry. It points to gaps in the physical theory, identifies the precise regimes and time scales on which an effective description is valid, and provides clues towards a more complete theory.")

#text("In years preceding the advent of AI in mathematics, a beautiful example of success in this pursuit, is ")#link("https://arxiv.org/abs/2104.11204")[#text("Deng and Hani’s derivation of the wave kinetic equation")]#text(" as a large box limit of the nonlinear Schrödinger equation. Later, with Ma, they gave ")#link("https://arxiv.org/abs/2408.07818")[#text("an analogous derivation of the Boltzmann equation from hard-sphere dynamics")]#text(" for as long as the Boltzmann solution exists, ")#link("https://arxiv.org/abs/2503.01800")[#text("resolving Hilbert’s sixth problem for rarefied gases")]#text(". The combinatorial analysis behind these results is a tour de force, and it took years of work. LLMs could potentially allow us to carry out such a program for other effective theories, where doing it by hand would frankly be out of reach. Ultimately, one could hope that LLMs will allow us to extend this standard of rigorous proof to all branches of the physical sciences.")

#strong[#text("Protecting our ideas: ")]#text("Currently, there are some fundamental structural problems in terms of how AI companies interact with the mathematical community.")

#text("AI companies, who strip mine our data, including unpublished work, private notes and research grant applications, have an egregious conflict of interest in competing against their own customers with unlimited resources and internal models unavailable to the public — this is not confined to mathematics but applies more broadly. ")#link("https://openai.com/index/navier-stokes-solution/")[#text("By OpenAI’s own account")]#text(", its push on the Millennium problems was spurred by rumors that a rival had solved two of them — demonstrating that caution, due diligence, and basic ethics can be cast aside simply to avoid being one-upped by a rival.")

#text("On October 6th, ")#link("https://github.com/openai/math")[#text("OpenAI released hundreds of manuscripts")]#text(" with proofs that were mostly unreadable and in some cases false. In the release, ")#link("https://decrypt.co/380366/openai-secret-ai-model-cracked-hundreds-math-problems-one-prompt")[#text("they misleadingly claimed that the work took on average three hours of computation on a single agent")]#text(": ")#link("https://www.scientificamerican.com/article/openai-unleashes-hundreds-more-math-results-upon-a-field-already-in-shock/")[#text("they later admitted that they did not count numerous failed attempts at the problems")]#text(" ")#link("https://github.com/openai/math/blob/main/README.md#L5")[#text("as well as previous work done by other agents")]#text(" — rendering the three hours claim essentially meaningless. Again, OpenAI did essentially no due diligence, failing to investigate whether once again they may be building on the private, unreleased work of their customers, some of whom were graduate students and postdocs who were literally days away from releasing their own work.")

#link("https://x.com/polynoamial/status/2093451221273387477")[#text("In August, OpenAI claimed")]#text(" that ")#link("https://x.com/nihilunbounded/status/2108084325631832126")[#text("such a dump would be `distasteful’")]#text(", that their `main focus is shipping great models so everyone can use them to make discoveries of their own’. After Navier–Stokes, OpenAI had teased us with supposed solutions to additional Millennium problems, yet they achieved none. A natural question is to ask why OpenAI would go through with such a PR stunt that risks alienating their customers. These companies are spending tens of billions of dollars a year more than they earn, which helps to explain their thirst for PR stunts and their willingness to take such seemingly inexplicable risks.")

#text("Mathematicians now type half-formed ideas into commercial models every day. These sessions are invaluable to an AI company: they provide a road map of our thought process, and reveal which research directions are promising. Until recently, AI-assisted proofs of important mathematical results were considered a pipe dream, and many of us were simply not concerned with data privacy since we never imagined today’s capabilities arriving so quickly.")

#text("It is imperative to protect our ideas and not let AI companies become the ultimate gatekeepers of knowledge. In this vein, I would like to see:")

#list(
[#text("Collective enterprise agreements with AI companies should become ubiquitous. Many universities already have institutional agreements with AI providers, and these offer far better protections than consumer agreements. Even so, such agreements could be further strengthened by including ")#emph[#text("zero data retention")]#text(" clauses and auditing provisions to ensure that the conditions of the agreements are respected. Many mathematicians, myself included, do their research on consumer subscriptions that those agreements do not cover. We need to make sure all academics work under the protection of such agreements.")],
[#text("We need stricter regulatory guardrails on user data. More generally, we need stricter regulations governing how AI companies collect data. Training on user data must be explicitly opt-in rather than opt-out. Finally, deceptive practices, such as absorbing an entire session’s worth of data as a result of a user providing feedback on a single response, must be explicitly banned.")],
[#text("We should further invest in open-weight infrastructure, assisting in the development of open-weight models. We cannot assume the interests of Academia and the AI companies are aligned. Academic institutions that control where their models are run can circumvent the fear of having their ideas stolen by trillion dollar corporations. Chess was democratized by engines anyone could run at home. Shared, open infrastructure for mathematics, funded in an independent way, is a lofty goal worth pursuing.")]
)

#text("Less reliance on user data benefits both sides: leading to more trust from the academics and the encouragement of new innovative ways to train models.")

#strong[#text("Recognizing contributions: ")]#link("https://www.youtube.com/watch?v=M0--ZH1lOzg&t=285s")[#text("As Tao put it at the ICM this summer")]#text(", we are moving from an ")#emph[#text("era of proof scarcity")]#text(" to an ")#emph[#text("era of proof abundance")]#text(". Our credit system was built for the era of scarcity. Being first to a famous result was a reasonable proxy for depth of understanding, because nobody could get there without understanding a great deal along the way. That proxy no longer holds and so we will need new ways of assigning credit that are not simply correlated with access to resources.")

#text("Some concrete suggestions:")

#list(
[#text("Reward well written exposition of important results in mathematics.")],
[#text("AI disclosures are a mixed bag and there is currently a perverse incentive not to disclose the use of AI. Disclosing AI assistance should not diminish a result and detailed disclosures should become standard.")],
[#text("Development of shared tools and resources, as well as contributions to large collaborative projects should earn recognition, mimicking practices in other sciences.")],
[#text("Mathematicians should be evaluated on the ideas and methods they developed, not just on whether or not they were first to prove a result.")]
)

#text("More generally, we will need to move away from bean counting publications in top journals. Whatever replaces it must still offer transparent ways of evaluating work, rather than relying on reputation and personal connections, which tends to produce closed networks and patronage.")

#strong[#text("The future of mathematics: ")]#text("Chess did not end in 1997. Mathematics will not end in 2026. I am however convinced that within the next few years it will be unrecognizable. That future will not be shaped by me or my peers. It will be shaped by the next generation.")

#text("I am already amazed by what our students and postdocs at NYU are doing with these tools. I suspect that in their hands the line between pure and applied mathematics will blur further, perhaps disappear, and that we will see a richer connection between mathematical proofs and the physical sciences.")

#text("For the next generation of mathematicians to flourish, we need protections and control over user data, restraint from AI companies, a lower barrier to entry to the use of frontier-level models, and a new credit system that rewards understanding rather than access. Mathematics has long been said to belong to the young. They will decide what it becomes.")

#emph[#text("AI Disclaimer: I used LLMs to help edit this post, including suggesting wording for some passages. ")]

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b7b3926b86891cd8fedf7356c5670a2085f0c301511360deb7eaae9c13e3adf-339354f41f3a9dec6adc3e2b49e3163e5e3e83c3605a89451fd3c1823b3f1267.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of just different")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698537")[#strong[#text("just different")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I wish people would stop saying “young” when what they really mean is “early-career.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698539")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I have seen over and over the comparison with chess most often without the obvious mention of what the main difference is: it’s not whether people would “watch two Fields medallists duke it out on a livestream proving a theorem”, it’s whether this can be a profession for more than around a hundred people in the world")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698569")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("That mostly depends on funding. I can totally imagine the NSF, Simons Foundation, XTX Foundation etc being willing to fund this kind of “Math 2.0”. Plus, if there is more applied math involved, perhaps it will pay for itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9a26d07b23d3b08937d705bf63be4e9cfb155b0c3c71efb989592a9df73904-2fa35e19c5de7c145ea2c70abf3921818c497d07d64ed2ed68245c54b93966ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of objecteclecticf375435795")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698574")[#strong[#text("objecteclecticf375435795")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("The Simons Foundation etc has done great work, but they will certainly not fund hundreds (rather thousands) of math departments around the world.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698582")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I didn’t mention the universities themselves which of course are the main sources of funding. Yes, those as well. Universe fund people to study things that are already out there. We have literature departments, astronomy departments, etc. A math 2.0 department makes sense.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nic")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698540")[#strong[#text("Nic")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("While I am grateful for this posti, just want to share my desconsolation (as a reader) at the fact that so many texts I read recently seem be written in the same voice or style. Someone tell me I am not the only one 😦")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e27f9c09b1352d7eec02dcbab8c7a4fd13e098935b67b56ed34c6a7e0ebf22-2d444d96e435285db8460d4295138b85a5b591de0925c89d7e66281122b13418.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698546")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Regarding the trajectory from Deep Blue to mobile phones: That was the golden age of Moore’s law. But Moore’s law has ended, so we won’t see that again.")

#text("Regarding the chess analogy: There are a couple of billionaires sponsoring the top tournaments. If AI should get to Stockfish vs. human level, mathematics will not have that support.")

#text("Fortunately, I don’t think AI is remotely there yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698550")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Dear Tristan,")#linebreak()#text("On the topic of protecting our ideas, I have found the essay of Satya Nadella on the reverse information paradox (see ")#link("https://x.com/satyanadella/article/2076323181154230284")[#text("https://x.com/satyanadella/article/2076323181154230284")]#text(") to be particularly insightful. Mathematician aren’t the only ones suffering from IP theft and I believe it would be good to work with other professions inside and outside of academia, which will soon also be as strongly impacted by AI, to revise the current terms of fair use, in addition to your suggestions on how to proceed.")#linebreak()#text("– A physics postdoc")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698560")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I don’t think we do a particularly good job at the moment of recognizing the contributions of young mathematicians, even if they stand on the shoulders of giants. I really hope this changes in the near future (including recognizing those who contributed to math that lead to a breakthrough solution within the 722 paper dump).")

#text("I feel a bit iffy about “protecting ideas.” For most people, you sound like a bit of a conspiracy theorist when you accuse OpenAI for stealing your ideas. I still think we should have a culture of being generous with sharing ideas to foster community. Though there should be some restrictions, just like what we have before the AI stuff dropped.")

#text("I very much agree with your vision of mathematical physics, though I think this extends a bit further than merely mathematical physics. Perhaps the era of obsessing over big conjectures of others is over, and a new era of mathematical self-discovery is dawning. Pick a phenomena we encounter in our everyday lives that we don’t understand (I’m sure there are many!) and attempt to understand it, using whatever tools we have available including mathematics!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f39f29a10b59d96025b737c4dc7b6dfe6820e2388f4f9fe209635af7ae1d821-bcec43b88c94773ef732401844cff0daa66cadee2b49c0a0df384d3f7133104a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698568")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Have you seen ")#link("https://citedbyagi.com/")[#text("https://citedbyagi.com/")]#text(" ? It’s a great website!")

#text("I too am skeptical that OpenAI solved Navier-Stokes by looking at Tristan and Levent’s private Codex chats, but it’s true that OpenAI did rush to solve it before them with the internal agents and it is kind of understandable that Tristan would think that. I agree that it would be good if he got over this, and focused on the future of mathematics. The quicker everyone moves on from the OpenAI vs Levent/Tristan/Anthropic fight over NS, the better.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63b49eb890ed710b8c76993bc58baae29a2e3c8cccefffcddbfee8eec8351751-0b5f8ed2fd0af0be5adcb141fe77cbdbe858a8085e65a8f6a868d46e73aa5efe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698566")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("What gives [mathematics] lasting relevance is something else: human understanding.")
]

#text("I don’t think this is quite right. ")#emph[#text("We")]#text(" (mathematicians) work for our own personal reasons, including our enjoyment of understanding, but for ")#emph[#text("society")]#text(" mathematics is also useful, in ways that chess isn’t. A proof of the Extended Riemann Hypothesis we could not understand would still make various effectively algorithms unconditionally correct. A mathematical model of high-")#mi("T_\\mathrm{c}")#text(" superconductors could lead to better devices even if only LLMs could understand the model and calculate with it.")

#text("Nearly all our endeavors are paid for by society (whether by the government, for those of us who work in public universities or are paid by government grants, or by private organizations such as those who work in private universities or in industry research labs), and that’s where accountability must ultimately lie. Otherwise we’d return to the historical situation of very few professional mathematicians. Fermat was a jurist; Kronecker was a businessman; Grassmann was a gymnasium teacher.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f75391d90ab5162036bd88ea8e0e040f9460e357a84d19624a5c2f0aec3cf18c-3a434a9769d5c64eb490c2d41670b021c86b1e1016af418efb5448eb980aeeac.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698573")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Lior, I think EHR is a particularly terrible example. EHR has more experimental and other evidence behind it than just about anything in science; it can simply be taken as true for all practical purposes. The point of a proof of EHR would be both the achievement (assuming it is done by humans; it makes little sense to speak of the achievement of a machine) and the great improvements in understanding it would certainly depend on – if done by humans; without that if, it’s all much less clear, though I suppose one could reverse-engineer *something*.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2fd5eacabd67720620519331aa530f904a802952c0410cbdd4524013d67f345-b77199f927d387ab00906ad9d8deecd1f3282ab7c97221717e82e5934504fdf3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of g")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698567")[#strong[#text("g")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("This post (which on the whole I find excellent) contains two important accusations of dishonesty by OpenAI in describing how much effort their models took to produce these results, both of which are hyperlinked, but (so far as I can see) for only one of them does what’s at the far end of the hyperlink support the accusation. (And even for that one, the claim of dishonesty based on it seems kinda overblown to me.)")

#text("“")#link("https://www.scientificamerican.com/article/openai-unleashes-hundreds-more-math-results-upon-a-field-already-in-shock/")[#text("they later admitted that they did not count numerous failed attempts at the problems")]#text("“: the nearest thing I can find in the linked page is “The OpenAI spokesperson also told ")#emph[#text("Scientific American")]#text(" that some results might have taken multiple attempts.” which doesn’t so far as I can see contradict OpenAI’s earlier claim, which per Tristan’s link claiming that OpenAI falsely claimed to have taken only one prompt for every attempt was “almost everything came from a single prompt handed to a single AI agent, though some may have taken multiple attempts”. I don’t see here either any evidence for “numerous” nor for the alleged discrepancy between their original claim and what they said later.")

#text("“")#link("https://github.com/openai/math/blob/main/README.md#L5")[#text("as well as previous work done by other agents")]#text("“: this links to the README on OpenAI’s GitHub repo for the alleged proofs; this does indeed say “Some outputs build upon earlier results produced by the models.”")

#text("I don’t see that OpenAI ever claimed that literally every result their models claimed to produce came from a single prompt; it looks to me as if what they always said was that that was the case for almost all but some took multiple attempts. So far as I can see, “numerous failed attempts” is pure speculation.")

#text("(I wouldn’t be terrible surprised if it were ")#emph[#text("correct")]#text(" speculation; my opinion of OpenAI’s honesty is not very high. But there’s a difference between “they lied and then admitted it” which is what Tristan is claiming, and “they said something that I suspect was a lie”.)")

#text("As for the “previous work”: clearly this ")#emph[#text("could")]#text(" mean something like “we first of all spent weeks instructing the model to almost-but-not-quite solve problems, and then we gave it a single prompt for each problem asking it to finish the job”, but … well, if I pose a tough problem to a human mathematician and they solve it quickly, I don’t find that less impressive merely because maybe they’ve thought about related things before; the understanding that comes from their having done that is part of why they’re impressive.")

#text("This would all be so very much clearer if OpenAI revealed a lot more about what prompts they fed to their models when. But presumably they see that as commercially sensitive information, and again no one expects human mathematicians to reveal every conversation they have had on some topic before publishing a paper about it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698594")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I agree with this reply. I also agree with many aspects of this post, but mostly I agree that there are serious ethical issues and a danger to democracy for the mathematical community if AI companies like openai and anthropic manage to privatize the means of mathematical production. This issue includes the use of internal models and compute not available to ordinary users except through insiders connexion. But it also includes increasingly expensive subscription and not having access to information about the models, their thinking process and their training process (this is why I strongly support new initiatives like open math model).")

#text("However, I can’t help feeling slightly cheated by the post. The talk about early-career mathematicians is well-intentioned and I of course agree, but it seems little little more than a fig leaf for what is the main purpose of the post: accuse openai without, in fact, providing any real evidence. To be clear, I don’t like openai either. But what is ethically different about the way the author of the post has teamed up with Levent, who had no expertise in PDE analysis and fluid mechanics but works for Anthropic and gave him access to Anthropic’s compute and models not accessible to ordinary users? It seems at least possible to me that the author has done on a small scale what he accuses openai to have done on a large scale.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698575")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Can someone please explain what this “democratization” that everybody is talking about means? No professional mathematician in most (non-western) countries is able to pay hundreds of dollars (more than their monthly salary) to professional AI models. So, a US citizen with no relation to mathematics “solving” problems before professional mathematicians from poorer countries is “democracy in mathematics”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99786d589e9a01cfbeb49bb98edcfdd7292ff385fc9a7e7d2fe23f41032f081f-9b4c9b15a5befe7fbaa19f538cb26a3fdf9fb4e255597f2156291100eeb07d32.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ziad Baroudi")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698579")[#strong[#text("Ziad Baroudi")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("I am a maths/IT secondary (middle+high) school teacher, not a mathematician. I read this while supervising a year 10 trigonometry test! Articles like this one give me words I can use when asked by a student whether pursuing mathematics or maths-related degree is worth it in age of AI.")

#text("I want to express my admiration for the mathematicians whose essays I read on this blog. They make me realise how good mathematicians are at deep thinking and clear expression.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698585")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("Chess didn’t end, but correspondence chess did.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698589")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("As an undergraduate mathematics student who firmly believes that mathematical research is my “raison d’être”, I find myself grappling with a concern that I suspect many of my generation (and beyond) share. Beyond the familiar stages of grief, perhaps the most pressing question is this: How can someone without an established reputation build one in an era when AI can contribute to mathematical research?")

#text("I fear that, as AI becomes increasingly involved in our field, every new result may be met with the same question: “Did you prove this yourself, without any assistance from AI?” I personally refuse to let AI prove a mathematical statement for me, partly out of pride. But how convincing is this stance—or any more nuanced position—when the real challenge is convincing the mathematical community that one’s work is genuinely one’s own?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2919a2bd6f23d40609e215496608f5bd4261d04e6eca9a5351d85150b239f117-cd24097b516a9fabc44eb06bc0f5e8d5a73a83fe9b7a29b9bc268594a7da7ab0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of generouslydff7bc0de8")]], [#link("https://terrytao.wordpress.com/2026/10/21/mathematics-is-a-subject-for-the-young/comment-page-1/#comment-698590")[#strong[#text("generouslydff7bc0de8")]]#text(size: 9pt, fill: rgb("596477"), " · 21 October 2026")])]

#text("On chess comparison :")

#text("Chess barely survives today. It is not a career recommended even by the very top players.(There is noone recommending it to their kid, most players regret their career choices.)")

#text("Rules of chess are easy to learn, but difficult to master. Maths is much more difficult and even more difficult to maste. (It takes many years and a career decision just to reach the open set definition.)")

#text("Chess is a board game; maths is at the foundation of all sciences. Losing chess can be bad, but ok., on the other hand we need maths and mathematicians at every generation just to preserve the level of science (a modest goal).")

#text("The main threat is fast dehumanization of maths in a possibly single generation. I am afraid there won’t be any sufficiently well trained humans to check or understand AI output. Can you recommend a youngster a maths career today however he /she is talented? Much more precious maths is at a bigger peril, imo.")
]
