// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/
// Converted to Typst by tao2typ: "2026-10-14T16:35:38.295721+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The Kakeya set and maximal conjectures for algebraic varieties over finite fields", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The Kakeya set and maximal conjectures for algebraic varieties over finite fields")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")[#text("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.wisc.edu/~ellenber/")[#text("Jordan Ellenberg")]#text(", ")#link("http://www.math.ucla.edu/people/pages/oberlin.shtml")[#text("Richard Oberlin")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" the paper “")#link("http://arxiv.org/abs/0903.1879")[#text("The Kakeya set and maximal conjectures for algebraic varieties over finite fields")]#text("“, submitted to ")#link("http://www.ucl.ac.uk/Mathematics/Mathematika/")[#text("Mathematika")]#text(". This paper builds upon some ")#link("http://arxiv.org/abs/0803.2336")[#text("work of Dvir")]#text(" and later authors on the Kakeya problem in finite fields, which I have discussed in this ")#link("https://terrytao.wordpress.com/2008/03/24/dvirs-proof-of-the-finite-field-kakeya-conjecture/")[#text("earlier blog post")]#text(". Dvir established the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Kakeya set conjecture for finite fields.")]#text(" Let F be a finite field, and let E be a subset of ")#mi("F^n")#text(" that contains a line in every direction. Then E has cardinality at least ")#tao-math("c_n \\left|F\\right|^n", block: false)#text(" for some ")#mi("c_n > 0")#text(".")
]

#text("The initial argument of Dvir gave ")#mi("c_n = 1/n!")#text(". This was improved to ")#mi("c_n = c^n")#text(" for some explicit ")#mi("0 < c < 1")#text(" by ")#link("http://arxiv.org/abs/0808.2499")[#text("Saraf and Sudan")]#text(", and recently to ")#mi("c_n =1/2^n")#text(" by ")#link("http://arxiv.org/abs/0901.2529")[#text("Dvir, Kopparty, Saraf, and Sudan")]#text(", which is within a factor 2 of the optimal result.")

#text("In our work we investigate a somewhat different set of improvements to Dvir’s result. The first concerns the ")#emph[#text("Kakeya maximal function")]#text(" ")#mi("f^*: {\\Bbb P}^{n-1}(F) \\to {\\Bbb R}")#text(" of a function ")#mi("f: F^n \\to {\\Bbb R}")#text(", defined for all directions ")#mi("\\xi \\in {\\Bbb P}^{n-1}(F)")#text(" in the projective hyperplane at infinity by the formula")

#align(center)[#tao-fit-display[#tao-math("f^*(\\xi) = \\sup_{\\ell // \\xi} \\sum_{x \\in \\ell} \\left|f(x)\\right|", block: true)]]

#text("where the supremum ranges over all lines ")#mi("\\ell")#text(" in ")#mi("F^n")#text(" oriented in the direction ")#mi("\\xi")#text(". Our first result is the endpoint ")#mi("L^p")#text(" estimate for this operator, namely")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Kakeya maximal function conjecture in finite fields.")]#text(" We have ")#tao-math("\\left\\| f^* \\right\\|_{\\ell^n({\\Bbb P}^{n-1}(F))} \\leq C_n \\left|F\\right|^{(n-1)/n} \\left\\|f\\right\\|_{\\ell^n(F^n)}", block: false)#text(" for some constant ")#mi("C_n > 0")#text(".")
]

#text("This result implies Dvir’s result, since if f is the indicator function of the set E in Dvir’s result, then ")#tao-math("f^*(\\xi) = \\left|F\\right|", block: false)#text(" for every ")#mi("\\xi \\in {\\Bbb P}^{n-1}(F)")#text(". However, it also gives information on more general sets E which do not necessarily contain a line in every direction, but instead contain a certain fraction of a line in a subset of directions. The exponents here are best possible in the sense that all other ")#mi("\\ell^p \\to \\ell^q")#text(" mapping properties of the operator can be deduced (with bounds that are optimal up to constants) by interpolating the above estimate with more trivial estimates. This result is the finite field analogue of a long-standing (and still open) conjecture for the Kakeya maximal function in Euclidean spaces; we rely on the polynomial method of Dvir, which thus far has not extended to the Euclidean setting (but note the very interesting variant of this method ")#link("http://arxiv.org/abs/0811.2251")[#text("by Guth")]#text(" that has established the endpoint multilinear Kakeya maximal function estimate in this setting, see ")#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("this blog post")]#text(" for further discussion).")

#text("It turns out that a direct application of the polynomial method is not sufficient to recover the full strength of the maximal function estimate; but by combining the polynomial method with the Nikishin-Maurey-Pisier-Stein “method of random rotations” (as interpreted nowadays by Stein and later by Bourgain, and originally inspired by the factorisation theorems of Nikishin, Maurey, and Pisier), one can already recover a “restricted weak type” version of the above estimate. If one then enhances the polynomial method with the “method of multiplicities” (as introduced by ")#link("http://arxiv.org/abs/0808.2499")[#text("Saraf and Sudan")]#text(") we can then recover the full “strong type” estimate; a few more details below the fold.")

#text("It turns out that one can generalise the above results to more general affine or projective algebraic varieties over finite fields. In particular, we showed")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Kakeya maximal function conjecture in algebraic varieties.")]#text(" Suppose that ")#mi("W \\subset {\\Bbb P}^N")#text(" is an (n-1)-dimensional algebraic variety. Let ")#mi("d \\geq 1")#text(" be an integer. Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sup_{\\gamma \\ni x; \\gamma \\not \\subset W} \\sum_{y \\in \\gamma} f(y) \\right\\|_{\\ell^n_x(W(F))} \\leq C_{n,d,N,W} \\left|F\\right|^{(n-1)/n} \\left\\|f\\right\\|_{\\ell^n({\\Bbb P}^N(F))}", block: true)]]

#text("for some constant ")#mi("C_{n,d,N,W} > 0")#text(", where the supremum is over all irreducible algebraic curves ")#mi("\\gamma")#text(" of degree at most d that pass through x but do not lie in W, and W(F) denotes the F-points of W.")
]

#text("The ordinary Kakeya maximal function conjecture corresponds to the case when N=n, W is the hyperplane at infinity, and the degree d is equal to 1. One corollary of this estimate is a Dvir-type result: a subset of ")#mi("{\\Bbb P}^N(F)")#text(" which contains, for each x in W, an irreducible algebraic curve of degree d passing through x but not lying in W, has cardinality ")#tao-math("\\gg \\left|F\\right|^n", block: false)#text(" if ")#tao-math("\\left|W\\right| \\gg \\left|F\\right|^{n-1}", block: false)#text(". (In particular this implies a lower bound for Nikodym sets worked out ")#link("http://arxiv.org/abs/0803.3525")[#text("by Li")]#text(".) The dependence of the implied constant on W is only via the degree of W.")

#text("The techniques used in the flat case can easily handle curves ")#mi("\\gamma")#text(" of higher degree (provided that we allow the implied constants to depend on d), but the method of random rotations does not seem to work directly on the algebraic variety W as there are usually no symmetries of this variety to exploit. Fortunately, we can get around this by using a “random projection trick” to “flatten” W into a hyperplane (after first expressing W as the zero locus of some polynomials, and then composing with the graphing map for such polynomials), reducing the non-flat case to the flat case.")

#text("Below the fold, I wish to sketch two of the key ingredients in our arguments, the random rotations method and the random projections trick. (We of course also use some algebraic geometry, but mostly low-tech stuff, on the level of ")#link("http://en.wikipedia.org/wiki/Bezout%27s_theorem")[#text("Bezout’s theorem")]#text(", though we do need one non-trivial result of Kleiman (from ")#link("http://www.ams.org/mathscinet-getitem?mr=354655")[#text("SGA6")]#text("), that asserts that bounded degree varieties can be cut out by a bounded number of polynomials of bounded degree.)")

#text("[Update, March 14: See also ")#link("http://quomodocumque.wordpress.com/2009/03/14/blogging-is-good-for-math-or-kakeya-problems-over-finite-fields/")[#text("Jordan’s own blog post on our paper")]#text(".]")

#heading(level: 1)[#metadata(none) <tao-b6a98526c39869da11e2>#text("— The random rotations method —")]

#text("The random rotations method allows one to amplify a result about large sets into an estimate about small sets, by observing that large sets can be created by taking many random rotations (or translations, etc.) of a given small set; it is useful in any situation which enjoys symmetries that one can push small sets around this way (e.g. a ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous space")]#text(" will do nicely). Let’s see how it works in this context. Dvir’s argument lets us give the following conclusion (stated somewhat informally):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1.")]#text(" Let E be a subset of ")#mi("F^n")#text(" which contains lines in J different directions. If ")#tao-math("\\left|J\\right| \\sim \\left|F\\right|^{n-1}", block: false)#text(", then ")#tao-math("\\left|E\\right| \\gtrsim \\left|F\\right|^n", block: false)#text(". (Implied constants here are allowed to depend on n.)")
]

#text("We now amplify this by the random rotations method to extend from the large J case to the small J case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2.")]#text(" Let E be a subset of ")#mi("F^n")#text(" which contains lines in J different directions. Then ")#tao-math("\\left|E\\right| \\gtrsim \\left|J\\right| \\left|F\\right|", block: false)#text(".")
]

#strong[#text("Proof. ")]#text("If ")#tao-math("\\left|J\\right| \\sim \\left|F\\right|^{n-1}", block: false)#text(" then we are done by Proposition 1 already, so suppose that J is much smaller than ")#tao-math("\\left|F\\right|^{n-1}", block: false)#text(". (There are only ")#tao-math("O(\\left|F\\right|^{n-1})", block: false)#text(" directions available in ")#mi("F^n")#text(".) Let m be an integer such that ")#tao-math("Jm \\sim \\left|F\\right|^{n-1}", block: false)#text(".")

#text("We use the ")#link("http://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(" (and more precisely, the first moment method). Now let ")#mi("R_1, R_2, \\ldots, R_m: F^n \\to F^n")#text(" be m randomly chosen “rotations”, or more precisely invertible linear transformations, and consider the set ")#mi("E^{\\prime} := \\bigcup_{i=1}^m R_i(E)")#text(". Clearly, ")#tao-math("\\left|E^{\\prime}\\right| \\leq m \\left|E\\right|", block: false)#text(". On the other hand, we expect ")#mi("E^{\\prime}")#text(" to contain lines in about ")#tao-math("\\left|F\\right|^{n-1}", block: false)#text(" different directions. Indeed, pick any direction ")#mi("\\xi")#text(". Then ")#mi("R_i^{-1}(\\xi)")#text(" has a probability about ")#tao-math("J/\\left|F\\right|^{n-1}", block: false)#text(" of being one of the J directions of the lines that E contains; this is also the probability that ")#mi("R_i(E)")#text(" contains a line in the direction ")#mi("\\xi")#text(". If we choose each of the ")#mi("R_i")#text(" independently at random, then basic probability then tells us that for each direction ")#mi("\\xi")#text(", that E’ will contain a line in the direction ")#mi("\\xi")#text(" with probability about ")#tao-math("1 - (1 - J/\\left|F\\right|^{n-1})^m \\sim 1", block: false)#text(". From linearity of expectation we thus see that the expected number of directions along which E’ contains a line is ")#tao-math("\\sim \\left|F\\right|^{n-1}", block: false)#text(", so in particular we will have ")#tao-math("\\gtrsim \\left|F\\right|^{n-1}", block: false)#text(" such lines for at least one choice of E’. Applying Proposition 1 to that choice we obtain ")#tao-math("m\\left|E\\right| \\geq \\left|E^{\\prime}\\right| \\gtrsim \\left|F\\right|^n", block: false)#text(", and so ")#tao-math("\\left|E\\right| \\gtrsim J \\left|F\\right|", block: false)#text(" as required.")

#heading(level: 1)[#text("— The random projection trick —")]

#text("The random projection trick is a different application of the probabilistic method. It uses the fact that random maps tend to be “mostly injective” whenever the range is larger than the domain (and, dually, are “mostly surjective” when the domain is larger than the range); this often allows one to cut either the domain or range down in size until they are roughly equal. It is used in a number of places in the literature, for instance in ")#link("http://www.ams.org/mathscinet-getitem?mr=1281447")[#text("Ruzsa’s proof of Freiman’s theorem")]#text(".")

#text("For instance, we have the following statement (stated a bit informally to simplify the formulation):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1.")]#text(" Let E be a subset of ")#mi("F^n")#text(", and let ")#mi("T: F^n \\to F^m")#text(" be a random linear transformation. If ")#tao-math("\\left|E\\right| \\lesssim \\left|F\\right|^m", block: false)#text(", then ")#tao-math("\\left|T(E)\\right| \\sim \\left|E\\right|", block: false)#text(" with high probability.")
]

#strong[#text("Proof. ")]#text("Consider the number of “collisions”,")

#align(center)[#tao-math("X := \\left| \\{ (x,y) \\in E: T(x) = T(y) \\} \\right|", block: false)#text(".")]

#text("On the one hand, each pair ")#mi("(x,y)")#text(" has a probability of ")#tao-math("\\left|F\\right|^{-m}", block: false)#text(" of contributing a collision if x and y are distinct, and a probability 1 of contributing a collision if they are equal. Thus")

#align(center)[#tao-math("{\\Bbb E} X \\sim \\left|E\\right| + \\left|F\\right|^{-m} \\left|E\\right|^2 \\sim \\left|E\\right|", block: false)#text(".")]

#text("From ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]#text(" we conclude that ")#tao-math("X = O(\\left|E\\right|)", block: false)#text(" with high probability.")

#text("On the other hand, we can write ")#tao-math("X := \\sum_{z \\in T(E)} \\left|T^{-1}(z) \\cap E\\right|^2", block: false)#text(". Since ")#tao-math("\\left|E\\right| = \\sum_{z \\in T(E)} \\left|T^{-1}(z) \\cap E\\right|", block: false)#text(", we conclude from the Cauchy-Schwarz inequality that")

#align(center)[#tao-math("\\left|X\\right| \\geq \\left|E\\right|^2 / \\left|T(E)\\right|", block: false)#text(",")]

#text("and the claim follows. ")#mi("\\Box")

#strong[#text("Remark. ")]#text(" While T is “mostly injective” once ")#tao-math("\\left|E\\right| \\lesssim \\left|F\\right|^m", block: false)#text(" (in the sense that ")#tao-math("\\left|T(E)\\right| \\sim \\left|E\\right|", block: false)#text("), T will not be ")#emph[#text("completely")]#text(" injective with high probability until ")#tao-math("\\left|E\\right| \\lesssim \\left|F\\right|^{m/2}", block: false)#text(", thanks to the ")#link("http://en.wikipedia.org/wiki/Birthday_paradox")[#text("birthday paradox")]#text(". ")#mi("\\diamond")

#text("Here is a typical way in which one can hope to use this trick for Kakeya-type problems. A simple modification of Dvir’s original argument (as done in this ")#link("http://arxiv.org/abs/0803.3525")[#text("paper of Li")]#text(") gives")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3.")]#text(" (Nikodym-type estimate) Let E be a subset of ")#mi("F^n")#text(" of size ")#tao-math("\\left|E\\right| \\sim \\left|F\\right|^n", block: false)#text(", and let ")#mi("G")#text(" be another set in ")#mi("F^n")#text(" such that for every point x in E, there exists a line ")#mi("\\ell_x")#text(" passing through x such that G contains ")#mi("\\ell_x \\backslash \\{x\\}")#text(". Then ")#tao-math("\\left|G\\right| \\sim \\left|F\\right|^n", block: false)#text(".")
]

#text("The random rotations trick (or more precisely, the random translations trick) from the preceding section lets us extend this result to smaller values of |E| (shrinking |G| proportionally). But here I wish to discuss a different extension, using the random projections trick instead:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3.")]#text(" (Nikodym-type estimate) Let ")#mi("N \\geq n")#text(". Let E be a subset of ")#mi("F^N")#text(" of size ")#tao-math("\\left|E\\right| \\sim \\left|F\\right|^n", block: false)#text(", and let ")#mi("G")#text(" be another set in ")#mi("F^N")#text(" such that for every point x in E, there exists a line ")#mi("\\ell_x")#text(" passing through x such that G contains ")#mi("\\ell_x \\backslash \\{x\\}")#text(". Then ")#tao-math("\\left|G\\right| \\gtrsim \\left|F\\right|^n", block: false)#text(".")
]

#strong[#text("Proof. ")]#text("By Lemma 1, we can find a linear map ")#mi("T: F^N \\to F^n")#text(" such that ")#tao-math("\\left|T(E)\\right| \\sim \\left|F\\right|^n", block: false)#text(". Then observe that T(G) obeys the same hypotheses as G, but with E replaced by T(E). By Proposition 2, ")#tao-math("\\left|T(G)\\right| \\sim \\left|F\\right|^n", block: false)#text(", and the claim follows. ")#mi("\\Box")

#text("—")

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09a2c8a76df94aa2d44fd8323d391fc38919263c954ae99d01596d518ef38c28-0370e89d9bf8be3d6b2fdb36449c16719e27eab11d4404e6d7078d6e670dbef5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liangpan Li")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36670")[#strong[#text("Liangpan Li")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("What is the exact meaning of the notation “~” in Proposition 3 and many other places? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09a2c8a76df94aa2d44fd8323d391fc38919263c954ae99d01596d518ef38c28-0370e89d9bf8be3d6b2fdb36449c16719e27eab11d4404e6d7078d6e670dbef5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liangpan Li")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36674")[#strong[#text("Liangpan Li")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2009")])]

#text("Now let us talk about sets in the Euclidean spaces Rn. A Kakeya set is any set of points in Euclidean space which contains a unit line segment in every direction. In your 1999 Duke Math J. paper, you called a set E to be Nikodym if for every x belongs to Rn, there is a line L passing through x such that the intersection of L and E contains a unit line segment. This definition is different from the original definition of the Nikodym set by the Polish mathematician Otton M. Nikodym. OK, let us follow your definition. The famous Kakeya/Nikodym conjecture asserts that the Kakeya/Nikodym set has full (Hausdorff, Minkowski) dimension.")

#text("Given a COMPACT Nikodym set E in Rn, it is easy to see that E is also a Kakeya set. (Why? Choosing a direction e, let a person standing at the origin walk through the direction e, then …, then by the standard compactness argument, E contains a unit line segment in the direction e.) So a compact Nikodym set has both the properties of a Nikodym set and a Kakeya set. A compact Kakeya set need not to be a Nikodym set. Maybe people could first solve the Euclidean Nikoym set conjecture under the requirement that the set is also compact .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36715")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("This might be a dumb question, but could it be easier to work with Kakeya sets in ")#mi("\\mathbb{C}")#text(" instead of in the reals?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36725")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2009")])]

#text("Dear Liangpan: as stated in the post, the ")#mi("\\sim")#text(" notation is an informal one; I use it to mean equivalence up to constants. One can of course reconstruct a formalised version of these propositions by going through the proofs (and more precise results of this type are in my paper with Jordan and Richard).")

#text("Dear Peter: Certainly all of the results over ")#mi("{\\Bbb R}")#text(" carry over to ")#mi("{\\Bbb C}")#text(" without difficulty; there is for instance a thesis of David Alvarez that works out some of this. One new feature in ")#mi("{\\Bbb C}")#text(" is the presence of subfields of index 2, which can cause some near-counterexamples to the Kakeya conjecture in this setting. For instance, in ")#mi("{\\Bbb C}^3")#text(" one has the Heisenberg group ")#mi("\\{ (z_1,z_2,z_3): Im(z_3) = Im(z_1 \\overline{z_2}) \\}")#text(", which has five real dimensions (and thus has complex dimension 5/2, in some sense), and yet contains a four real dimensional (thus two complex dimensional, in some sense) family of complex lines. These lines are not all contained inside a complex plane, but they do contain many parallel lines and so this does not directly contradict the Kakeya conjecture in this setting; however it does indicate that in the presence of subfields, one does need to exploit the hypothesis that lines point in different directions. (Dvir’s argument, for instance, does this, and indeed his argument is insensitive to the presence of subfields.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87a870e8818dc22b85c392e9f134a7eb1060d7ff08a385cddfa07b027736bbb5-c2243ed8a00fa802a0a7eae6e90a02d7f052a30076be02c30935a6ee420f78cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott McKuen")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36748")[#strong[#text("Scott McKuen")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("Can any of the finite field results be carried over to the complex numbers by using the ideas from the earlier post on Serre’s paper and the Ax-Grothendieck theorem? Also, is anything known about the Kakeya problem in pseudofinite fields?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36762")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("Dear Scott,")

#text("It is of course a tantalising suggestion. The Kakeya problem in R or C is not of the “finitary algebraic” nature to which the type of transference principle mentioned in the Serre post applies directly, but there have been more indirect ways to transfer the _ideas_ from the finite field world to the continuous setting, as discussed for instance in my earlier post")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2008/11/27/the-kakeya-conjecture-and-the-ham-sandwich-theorem/")[#text("The Kakeya conjecture and the Ham Sandwich theorem")]
]

#text("Similarly, the Kakeya conjecture does not seem to be of the “first-order” type needed to easily move from finite fields to pseudofinite fields. In our paper with Jordan and Richard, we discuss briefly the possibility of extending the results to other fields and rings (and perhaps even to schemes) but it seems that some additional ideas are needed in order to get satisfactory results.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JSE")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36764")[#strong[#text("JSE")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2009")])]

#text("Scott, somebody else just asked me that last week! I agree with TT that it’s a very interesting question. Of course, the polynomial method relies crucially on the fact that the finite field is finite — the order of the field is used as a bound for degrees of polynomials throughout. (Where the polynomial method is used in a Euclidean setting, as in the work of Guth and Guth-Katz, you usually start by discretizing your problem in some way so that “a line has about N points,” and N then plays the role of |F|.)")

#text("Here’s a prequel to your question: is it clear what the right _statement_ of the Kakeya set and Kakeya maximal conjectures should be over a pseudo-finite field? For instance, are there examples of such fields which have nice enough metric structure for the desired bound on Hausdorff dimension to make sense? Or is there some other way in this setting that one should be able to say “Kakeya sets are big”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87a870e8818dc22b85c392e9f134a7eb1060d7ff08a385cddfa07b027736bbb5-c2243ed8a00fa802a0a7eae6e90a02d7f052a30076be02c30935a6ee420f78cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of isotropy")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36828")[#strong[#text("isotropy")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("JSE – I believe pseudofinite fields come with model-theoretic notions of dimension and measure on definable sets that look somewhat like Hausdorff dimension and Hausdorff measure – I don’t know if they coincide (I don’t know anything about metric spaces over pseudofinite fields).")

#text("Ax showed any pseudofinite field ")#mi("K")#text(" is elementarily equivalent to an ultraproduct of finite fields. The underlying ultrafilter is on the set of prime powers, so it picks out certain orders of finite fields for the components of the ultraproduct – let ")#mi("F")#text(" be a component, of order ")#mi("n")#text(", and let ")#mi("\\phi(x_1,...,x_k)")#text(" a ring formula defining a subset of ")#mi("F^k")#text(".")

#text("Consider for each natural number ")#mi("d")#text(" the quantity:")

#tao-math("\\frac{\\left|\\phi(F)\\right|}{n^d}", block: false)

#text("If you look at this over all ")#mi("F")#text(" in the ultraproduct, and for some ")#mi("d")#text(" this quantity has a limit ")#mi("\\mu_d")#text(" in the ultrafilter sense, then we say ")#mi("d")#text(" is the dimension of ")#mi("\\phi(K)")#text(" and ")#mi("\\mu_d")#text(" is its measure. Like with Hausdorff dimension, ")#mi("\\mu_d")#text(" is only nonzero and finite for at most one ")#mi("d")#text(".")

#text("This might be a substitute notion of dimension for Kakeya sets in pseudofinite fields. I think this all comes from a 1992 paper of Chatzidakis, van den Dries, and Macintyre – “Definable Sets over Finite Fields” in Crelle’s.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87a870e8818dc22b85c392e9f134a7eb1060d7ff08a385cddfa07b027736bbb5-c2243ed8a00fa802a0a7eae6e90a02d7f052a30076be02c30935a6ee420f78cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Scott McKuen")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-36829")[#strong[#text("Scott McKuen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2009")])]

#text("Sorry! That comment by “isotropy” was my response to JSE. Somehow my email got partly dumped into the name field.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbdd89534ac98d5f9e51db92b57b4810ad0b9f4049cc813acd87120e857e7907-a60588adfb103b905cb77b69a8d7786f8b54eb0f5fff5fe61e9f3503d4abb214.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oyunlar")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-37952")[#strong[#text("oyunlar")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("Great news, thanks Scott!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Recent progress on the Kakeya conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-38693")[#strong[#text("Recent progress on the Kakeya conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2009")])]

#text("[…] and also generalises to other families of curves in algebraic varieties, as was done recently by Ellenberg, Oberlin, and myself (see this blog post for further discussion). There are even some tentative indications that these […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The two-ends reduction for the Kakeya maximal conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-38778")[#strong[#text("The two-ends reduction for the Kakeya maximal conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2009")])]

#text("[…] Indeed, to deduce (2) from Conjecture 2 one can perform another dyadic decomposition, this time based on the dyadic range of the densities . Conversely, (2) implies Conjecture 2 in the case , and the remaining case can then be deduced by the random rotations trick (discussed in this earlier post). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An equivalence between inverse sumset theorems and inverse conjectures for the U^3 norm « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-39634")[#strong[#text("An equivalence between inverse sumset theorems and inverse conjectures for the U^3 norm « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2009")])]

#text("[…] Conjecture 3 was observed by Ruzsa; basically, the idea is to use the random projection trick (cf. this post) to view the set A in Conjecture 1 as a graph of a function over a base of cardinality roughly […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-40043")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("Dear Terry,")

#text("Concerning the paper mentioned at the very beginning of the post: could you kindly explain Remark 4.19? Either I don’t understand the construction, or I don’t see why it works; that is, why the set in question is a k-plane Kakeya set.")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-40046")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2009")])]

#text("Dear anonymous,")

#text("Given a n-k+1-dimensional Kakeya set E in ")#mi("F^{n-k+1} \\subset F^n")#text(", the set ")#mi("E^{\\prime} := E \\cup (F^n \\backslash F^{n-k+1})")#text(" is a k-plane Kakeya set in ")#mi("F^n")#text(". This is because given every orientation of a k-plane in ")#mi("F^n")#text(", one can find a k-plane ")#mi("\\pi")#text(" with that orientation whose intersection with ")#mi("F^{n-k+1}")#text(" is contained in a line (it may be a point or empty if the orientation is sufficiently “parallel” to ")#mi("F^{n-k+1}")#text("). Translating this plane around, one can eventually fit it inside E’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/765ff73ee64b336b2df579226349b909b7fdb57a569700b78000cb7a4c5de82d-655fd52c93ab8620d986fe1da6d05af52341990803098badd2ef39ad1e279181.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ilyaraz")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-44608")[#strong[#text("ilyaraz")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("It might be a silly question but nevertheless.")

#text("Suppose we have ")#mi("n")#text(" linearly independent ")#mi("2n")#text("-dimensional vectors over ")#mi("\\mathbb{F}_2")#text(". We project them on a random ")#mi("n + O(1)")#text("-dimensional subspace. How can we estimate a probability that images will be linearly independent?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-44620")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("As stated, your question is ambiguous because there is more than one way to project a vector space onto a subspace (this is not a Hilbert space, and one does not have a canonical orthogonal projection). But in general, when asking whether n vectors ")#mi("X_1,\\ldots,X_n")#text(" are linearly independent, a common way to proceed is to first compute the conditional probabilities that, for any fixed ")#mi("X_1,\\ldots,X_{i-1}")#text(", that ")#mi("X_i")#text(" does not lie in the span of ")#mi("X_1,\\ldots,X_{i-1}")#text("; the final probability can then be obtained by integrating together all these conditional probabilities. In many situations one has enough independence or martingale structure that one can in fact just multiply together all the conditional probabilities rather than perform a complicated integral.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/765ff73ee64b336b2df579226349b909b7fdb57a569700b78000cb7a4c5de82d-655fd52c93ab8620d986fe1da6d05af52341990803098badd2ef39ad1e279181.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ilyaraz")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-44630")[#strong[#text("ilyaraz")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("Term ‘projection’ is used incorrectly, I agree.")

#text("What I am trying to say is the following. Suppose we have ")#mi("n \\times 2n")#text(" matrix ")#mi("A")#text(" with a maximum rank (over ")#mi("\\mathbb{F}_2")#text("). We multiply it by a random ")#mi("2n \\times n + O(1)")#text(" matrix B. How can we estimate a probability that ")#mi("AB")#text(" will have maximum rank?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/676cf66b6da78912d1502f9af0f00ec7abe873dd23ea251e46f5a3da6a04b226-62d297be75b435b5bc1e90c50155b251b5cf3ab08a0dd69b01171a4c82203e0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kenneth Maples")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-44633")[#strong[#text("Kenneth Maples")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2010")])]

#text("Hi ilyaraz,")

#text("I’m assuming by random matrix you mean one chosen uniformly from the space of ")#mi("2 n \\times n + C")#text(" matrices over ")#mi("\\mathbb{F}_2")#text(". Other distributions require a little more care.")

#text("Following Terry’s suggestion, we can observe that the columns of the product ")#mi("AB")#text(" are independent random variables, so it suffices to study the probability that the ")#mi("j")#text("th column of ")#mi("AB")#text(" lies in the span of the previous ")#mi("j - 1")#text(" columns, conditioning on the dimension of that span.")

#text("Each column of the product is of the form ")#mi("A Y_j")#text(" where ")#mi("Y_j")#text(" is the ")#mi("j")#text("th column of ")#mi("B")#text(". The mapping ")#mi("A : \\mathbb{F}_2^{2n} \\to \\mathbb{F}_2^{n}")#text(" is linear and surjective, so in particular the cardinalities of the fibres over each point are equal. In particular, our probability distribution (uniform) on the columns of ")#mi("B")#text(" pushes forward to the uniform probability distribution on the columns of ")#mi("AB")#text(". You can then calculate the chance that ")#mi("AB")#text(" has full rank by direct counting, where the probability gets arbitrarily close to ")#mi("1")#text(" as you send ")#mi("C \\to \\infty")#text("; the rate of convergence should be exponential in ")#mi("C")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-44708")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 May 2010")])]

#text("Prof. Tao:")

#text("In the proof in the section “random projection method”, at the very end it says")

#tao-math("m\\left|E\\right| \\leq \\left|E^{\\prime}\\right| \\lesssim \\left|F\\right|^n", block: false)

#text("and should be")

#tao-math("m\\left|E\\right| \\geq \\left|E^{\\prime}\\right| \\gtrsim \\left|F\\right|^n", block: false)

#text("Also, it seems that ")#mi("J")#text(" already stands for a number, not a set , so there is no need to use ")#tao-math("\\left|J\\right|", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An incidence theorem in higher dimensions « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-50822")[#strong[#text("An incidence theorem in higher dimensions « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2011")])]

#text("[…] this strategy (and also a generic projection argument to cut down the ambient dimension, as used in this previous paper with Ellenberg and Oberlin, and an induction on dimension), we obtain in our paper a higher-dimensional incidence theorem: […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stein’s maximal principle « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-52613")[#strong[#text("Stein’s maximal principle « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2011")])]

#text("[…] been used repeatedly in harmonic analysis. For instance, I used the random rotations trick in a recent paper with Jordan Ellenberg and Richard Oberlin on Kakeya-type estimates in finite fields. The random sums trick is by now a standard tool to build […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-116791")[#strong[#text("“Kakeya sets over non-archimedean local rings,” by Dummit and Hablicsek « Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2011")]

#text("[…] this week by UW grad students Evan Dummit and Márton Hablicsek answers a question left open in a paper of mine with Richard Oberlin and Terry Tao. Let me explain why I was interested in this question and why I like Evan and Marci’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on the Nash embedding theorem | What's new")]], [#link("https://terrytao.wordpress.com/2009/03/12/the-kakeya-set-and-maximal-conjectures-for-algebraic-varieties-over-finite-fields/#comment-468513")[#strong[#text("Notes on the Nash embedding theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2016")])]

#text("[…] if , then it is possible to project from to by the random projection trick (discussed in this previous post). Indeed, if one picks a random element of the unit sphere, and then lets be the (random) […]")
]
