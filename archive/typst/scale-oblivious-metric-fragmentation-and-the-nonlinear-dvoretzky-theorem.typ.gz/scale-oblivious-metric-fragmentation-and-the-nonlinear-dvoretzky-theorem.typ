// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/
// Converted to Typst by tao2typ: "2026-10-14T16:36:07.974012+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Scale-oblivious metric fragmentation and the nonlinear Dvoretzky theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Scale-oblivious metric fragmentation and the nonlinear Dvoretzky theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/")[#text("https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.cims.nyu.edu/~naor/")[#text("Assaf Naor")]#text(" and I have just uploaded to the arXiv our joint paper “")#link("http://arxiv.org/abs/1003.4013")[#text("Scale-oblivious metric fragmentation and the nonlinear Dvoretzky theorem")]#text("“.")

#text("Consider a finite metric space ")#mi("{(X,d)}")#text(", with ")#mi("{X}")#text(" being a set of ")#mi("{n}")#text(" points. It is not always the case that this space can be isometrically embedded into a Hilbert space such as ")#mi("{\\ell^2}")#text("; for instance, in a Hilbert space every pair of points has a unique midpoint, but uniqueness can certainly fail for finite metric spaces (consider for instance the graph metric on a four-point diamond). The situation improves, however, if one allows (a) the embedding to have some distortion, and (b) one is willing to embed just a subset of ")#mi("{X}")#text(", rather than all of ")#mi("{X}")#text(". More precisely, for any integer ")#mi("{n}")#text(" and any ")#emph[#text("distortion")]#text(" ")#mi("{D \\geq 1}")#text(", let ")#mi("{k(n,D)}")#text(" be the largest integer with the property that given every ")#mi("{n}")#text("-point metric space ")#mi("{(X,d)}")#text(", there exists a ")#mi("{k}")#text("-point subset ")#mi("{Y}")#text(" of ")#mi("{X}")#text(", and a map ")#mi("{f: Y \\rightarrow \\ell^2}")#text(", which has distortion at most ")#mi("{D}")#text(" in the sense that")

#align(center)[#tao-fit-display[#tao-math("d(y,y^{\\prime}) \\leq \\left\\| f(y) - f(y^{\\prime}) \\right\\|_{\\ell^2} \\leq D d(y,y^{\\prime})", block: true)]]

#text("for all ")#mi("{y,y^{\\prime} \\in Y}")#text(".")

#link("http://www.ams.org/mathscinet-getitem?mr=868175")[#text("Bourgain, Figiel, and Milman")]#text(" established that for any fixed ")#mi("{D>1}")#text(", one has the lower bound ")#mi("{k(n,D) \\gg_D \\log n}")#text(", and also showed for ")#mi("{D}")#text(" sufficiently close to ")#mi("{1}")#text(" there was a matching upper bound ")#mi("{k(n,D) \\ll_D \\log n}")#text(". This type of result was called a ")#emph[#text("nonlinear Dvoretsky theorem")]#text(", in analogy with the ")#link("http://en.wikipedia.org/wiki/Dvoretzky's_theorem")[#text("linear Dvoretsky theorem")]#text(" that asserts that given any ")#mi("{n}")#text("-dimensional normed vector space and ")#mi("{D > 1}")#text(", there existed a ")#mi("{k}")#text("-dimensional subspace which embedded with distortion ")#mi("{D}")#text(" into ")#mi("{\\ell^2}")#text(", with ")#mi("{k \\sim_D \\log n}")#text(". In other words, one can ensure that about ")#mi("{\\log n}")#text(" of the ")#mi("{n}")#text(" points in an arbitrary metric space behave in an essentially Euclidean manner, and that this is best possible if one wants the distortion to be small.")

#link("http://www.ams.org/mathscinet-getitem?mr=2120456")[#text("Bartel, Linial, Mendel, and Naor")]#text(" observed that there was a threshold phenomenon at ")#mi("{D=2}")#text(". Namely, for ")#mi("{D < 2}")#text(", the Bourgain-Figiel-Milman bounds were sharp with ")#mi("{k(n,D) \\sim_D \\log n}")#text("; but for ")#mi("{D>2}")#text(" one instead had a power law")

#align(center)[#tao-fit-display[#mitex("n^{1-B(D)} \\ll_D k(n,D) \\ll n^{1-b(D)}")]]

#text("for some ")#mi("{0 < b(D) \\leq B(D) < 1}")#text(". In other words, once one allows distortion by factors greater than ")#mi("{2}")#text(", one can now embed a polynomial portion of the points, rather than just a logarithmic portion, into a Hilbert space. This has some applications in theoretical computer science to constructing “approximate distance oracles” for high-dimensional sets of data. (The situation at the critical value ")#mi("{D=2}")#text(" is still unknown.)")

#text("In the special case that the metric ")#mi("{d}")#text(" is an ")#link("http://en.wikipedia.org/wiki/Ultrametric_space")[#text("ultrametric")]#text(", so that the triangle inequality ")#mi("{d(x,z) \\leq d(x,y) + d(y,z)}")#text(" is upgraded to the ")#emph[#text("ultra-triangle inequality")]#text(" ")#mi("{d(x,z) \\leq \\max(d(x,y), d(y,z))}")#text(", then it is an easy exercise to show that ")#mi("{X}")#text(" can be embedded isometrically into a Hilbert space, and in fact into a sphere of radius ")#mi("{\\text{diam}(X)/\\sqrt{2}}")#text(". Indeed, this can be established by an induction on the cardinality of ")#mi("{X}")#text(", using the ultrametric inequality to partition any finite ultrametric space ")#mi("{X}")#text(" of two or more points into sets of strictly smaller diameter that are all separated by ")#mi("{\\text{diam}(X)}")#text(", and using the inductive hypothesis and Pythagoras’ theorem.")

#text("One can then replace the concept of embedding into a Hilbert space, with the apparently stronger concept of embedding into an ultrametric space; this is useful for the computer science applications as ultrametrics have a tree structure which allows for some efficient algorithms for computing distances in such spaces. As it turns out, all the preceding constructions carry over without difficulty to this setting; thus, for ")#mi("{D<2}")#text(", one can embed a logarithmic number of points with distortion ")#mi("{D}")#text(" into an ultrametric space, and for ")#mi("{D>2}")#text(" one can embed a polynomial number of points.")

#text("One can view the task of locating a subset of a metric space that is equivalent (up to bounded distortion) to an ultrametric as that of ")#emph[#text("fragmenting")]#text(" a metric space into a tree-like structure. For instance, the standard metric on the arithmetic progression ")#mi("{\\{1,\\ldots,3^m\\}}")#text(" of length ")#mi("{n=3^m}")#text(" is not an ultrametric (and in fact needs a huge distortion factor of ")#mi("{3^m}")#text(" in order to embed into an ultrametric space), but if one restricts to the Cantor-like subset of integers in ")#mi("{\\{1,\\ldots,3^m\\}}")#text(" whose base ")#mi("{3}")#text(" expansion consists solely of ")#mi("{0}")#text("s and ")#mi("{1}")#text("s, then one easily verifies that the resulting set is fragmented enough that the standard metric is equivalent (up to a distortion factor of ")#mi("{3}")#text(") to an ultrametric, namely the metric ")#mi("{d(x,y) := 3^{j}/2}")#text(" where ")#mi("{j}")#text(" is the largest integer for which ")#mi("{3^j}")#text(" divides ")#mi("{y-x}")#text(" and ")#mi("{x \\neq y}")#text(".")

#text("The above fragmentation constructions were somewhat complicated and deterministic in nature. ")#link("http://www.ams.org/mathscinet-getitem?mr=2101227")[#text("Mendel and Naor")]#text(" introduced a simpler probabilistic method, based on random partition trees of ")#mi("{X}")#text(", which reproved the above results in the high-distortion case ")#mi("{D \\gg 1}")#text(" (with ")#mi("{b(D), B(D) \\sim 1/D}")#text(" in the limit ")#mi("{D \\rightarrow \\infty}")#text("). However, this method had inherent limitations in the low-distortion case, in particular failing for ")#mi("{D < 3}")#text(" (basically because the method would establish a stronger embedding result which fails in that regime).")

#text("In this paper, we introduce a variant of the random partition tree method, which involves a random fragmentation at a randomly chosen set of scales, that works all the way down to ")#mi("{D>2}")#text(" and gives a clean value for the exponent ")#mi("{b(D)}")#text(", namely ")#mi("{2e/D}")#text("; in fact we have the more precise result that we can take ")#mi("{b(D)}")#text(" to be ")#mi("{1-\\theta}")#text(", where ")#mi("{0 < \\theta < 1}")#text(" is the unique solution to the equation")

#align(center)[#tao-fit-display[#mitex("\\frac{2}{D} = (1-\\theta) \\theta^{\\theta/(1-\\theta)},")]]

#text("and that this is the limit of the method if one chooses a “scale-oblivious” approach that applies uniformly to all metric spaces, ignoring the internal structure of each individual metric space.")

#text("The construction ends up to be relatively simple (taking about three pages). The basic idea is as follows. Pick two scales ")#mi("{R > r > 0}")#text(", and let ")#mi("{x_1, x_2, x_3, \\ldots}")#text(" be a random sequence of points in ")#mi("{X}")#text(" (of course, being finite, every point in ")#mi("{X}")#text(" will almost surely be visited infinitely often by this sequence). We can then partition ")#mi("{X}")#text(" into pieces ")#mi("{Y_1, Y_2, \\ldots}")#text(", by defining ")#mi("{Y_m}")#text(" to be the set of points ")#mi("{x}")#text(" for which ")#mi("{x_m}")#text(" is the first point in the sequence to lie in the ball ")#mi("{B(x,R)}")#text(". We then let ")#mi("{S_m}")#text(" be the subset of ")#mi("{Y_m}")#text(" in which ")#mi("{x_m}")#text(" actually falls in the smaller ball ")#mi("{B(x,r)}")#text(". As a consequence, we see that each ")#mi("{S_m}")#text(" is contained in a ball of radius ")#mi("{r}")#text(" (namely ")#mi("{B(x_m,r)}")#text("), but that any two ")#mi("{S_m, S_{m^{\\prime}}}")#text(" are separated by a distance of at least ")#mi("{R-r}")#text(" (from the triangle inequality). This gives one layer of a quasi-ultrametric tree structure on ")#mi("{\\bigcup_m S_m}")#text("; if one iterates this over many different pairs of scales ")#mi("{R, r}")#text(", one gets a full quasi-ultrametric tree structure, which one can then adjust with bounded distortion to a genuine ultrametric structure. The game is then to optimise the choice of ")#mi("{R, r}")#text(" so as to maximise the portion of ")#mi("{X}")#text(" that remains in the tree; it turns out that a suitably random choice of such scales is the optimal one.")

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yan Shen")]], [#link("https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/#comment-43977")[#strong[#text("Yan Shen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("Hey Professor Tao, this is entirely off of the topic of this particular post and probably all of your other posts as well, but I was just wondering what your personal philosophical views towards mathematics was? Are you a Platonic realist? Or do you adopt the viewpoint of mathematical fictionalism? Or perhaps something entirely different altogether? I find mathematical fictionalism to be a particularly reasonable point of view, given that it seems rather absurd to posit the existence of objects transcending the physical world of space-time.")

#link("http://plato.stanford.edu/entries/fictionalism-mathematics/")[#text("http://plato.stanford.edu/entries/fictionalism-mathematics/")]

#text("By the way, the mathematics on this blog is light-years beyond my comprehension… :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/#comment-44005")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("Mathematics can be used to model the real world, but this does not imply that mathematical objects are “real” in any ontological sense. Conversely, real world intuition is very useful for thinking about mathematical concepts, but this again does not directly impact whether one should view concepts as “real” or not.")

#text("As long as one maintains the ")#link("http://en.wikipedia.org/wiki/Map%E2%80%93territory_relation")[#text("map-territory distinction")]#text(" between a real-world system, and a mathematical model of that system, I find that one’s philosophical interpretation of mathematical concepts makes very little practical difference in doing mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1a29b83d3715f084733cbf3b4d6ebeb0bd60852598b56cfdcefb1ca59292e95-be295ea13410f76f66eab689ea4c87a5f2c5418a1f6f3a28544dee0db39727c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of konradswanepoel")]], [#link("https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/#comment-43979")[#strong[#text("konradswanepoel")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2010")])]

#text("In your definition of an ultrametric on the Cantor-like subset of ")#mi("\\{1,\\dots,3^n\\}")#text(", I think you meant the largest ")#mi("j")#text(" for which ")#mi("3^j")#text(" divides ")#mi("x-y")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/#comment-44001")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2010")])]

#text("Another small typo — at one point you write “a logarithmic points” when you clearly mean “a logarithmic number of points”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yan Shen")]], [#link("https://terrytao.wordpress.com/2010/03/22/scale-oblivious-metric-fragmentation-and-the-nonlinear-dvoretzky-theorem/#comment-44038")[#strong[#text("Yan Shen")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2010")])]

#text("Thanks for the response Professor Tao! I assume based off of your response that you remain ontologically non-committal on the issue of mathematical realism. Judging by the large number of thumbs down my comment received, I’m guessing that your readers either felt I was posting something entirely off topic, or are in fact fervently Platonic realist. Either way, thanks for the response, and once again I apologize for deviating off the topic of your particular post.")
]
