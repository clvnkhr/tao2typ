// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/
// Converted to Typst by tao2typ: "2026-10-14T15:17:09.083426+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245C, Notes 1: Interpolation of L^p spaces", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245C, Notes 1: Interpolation of L^p spaces")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the previous two quarters, we have been focusing largely on the “soft” side of real analysis, which is primarily concerned with “qualitative” properties such as convergence, compactness, measurability, and so forth. In contrast, we will begin this quarter with more of an emphasis on the “hard” side of real analysis, in which we study estimates and upper and lower bounds of various quantities, such as norms of functions or operators. (Of course, the two sides of analysis are closely connected to each other; an understanding of both sides and their interrelationships, are needed in order to get the broadest and most complete perspective for this subject.)")

#text("One basic tool in hard analysis is that of ")#emph[#text("interpolation")]#text(", which allows one to start with a hypothesis of two (or more) “upper bound” estimates, e.g. ")#mi("{A_0 \\leq B_0}")#text(" and ")#mi("{A_1 \\leq B_1}")#text(", and conclude a family of intermediate estimates ")#mi("{A_\\theta \\leq B_\\theta}")#text(" (or maybe ")#mi("{A_\\theta \\leq C_\\theta B_\\theta}")#text(", where ")#mi("{C_\\theta}")#text(" is a constant) for any choice of parameter ")#mi("{0 < \\theta < 1}")#text(". Of course, interpolation is not a magic wand; one needs various hypotheses (e.g. linearity, sublinearity, convexity, or complexifiability) on ")#mi("{A_i, B_i}")#text(" in order for interpolation methods to be applicable. Nevertheless, these techniques are available for many important classes of problems, most notably that of establishing boundedness estimates such as ")#tao-math("{\\left\\| T f \\right\\|_{L^q(Y, \\nu)} \\leq C \\left\\| f \\right\\|_{L^p(X, \\mu)}}", block: false)#text(" for linear (or “linear-like”) operators ")#mi("{T}")#text(" from one Lebesgue space ")#mi("{L^p(X,\\mu)}")#text(" to another ")#mi("{L^q(Y,\\nu)}")#text(". (Interpolation can also be performed for many other normed vector spaces than the Lebesgue spaces, but we will just focus on Lebesgue spaces in these notes to focus the discussion.) Using interpolation, it is possible to reduce the task of proving such estimates to that of proving various “endpoint” versions of these estimates. In some cases, each endpoint only faces a portion of the difficulty that the interpolated estimate did, and so by using interpolation one has split the task of proving the original estimate into two or more simpler subtasks. In other cases, one of the endpoint estimates is very easy, and the other one is significantly more difficult than the original estimate; thus interpolation does not really simplify the task of proving estimates in this case, but at least clarifies the relative difficulty between various estimates in a given family.")

#text("As is the case with many other tools in analysis, interpolation is not captured by a single “interpolation theorem”; instead, there are a family of such theorems, which can be broadly divided into two major categories, reflecting the two basic methods that underlie the principle of interpolation. The ")#emph[#text("real interpolation method")]#text(" is based on a divide and conquer strategy: to understand how to obtain control on some expression such as ")#tao-math("{\\left\\| T f \\right\\|_{L^q(Y, \\nu)}}", block: false)#text(" for some operator ")#mi("{T}")#text(" and some function ")#mi("{f}")#text(", one would divide ")#mi("{f}")#text(" into two or more components, e.g. into components where ")#mi("{f}")#text(" is large and where ")#mi("{f}")#text(" is small, or where ")#mi("{f}")#text(" is oscillating with high frequency or only varying with low frequency. Each component would be estimated using a carefully chosen combination of the extreme estimates available; optimising over these choices and summing up (using whatever linearity-type properties on ")#mi("{T}")#text(" are available), one would hope to get a good estimate on the original expression. The strengths of the real interpolation method are that the linearity hypotheses on ")#mi("{T}")#text(" can be relaxed to weaker hypotheses, such as sublinearity or quasilinearity; also, the endpoint estimates are allowed to be of a weaker “type” than the interpolated estimates. On the other hand, the real interpolation often concedes a multiplicative constant in the final estimates obtained, and one is usually obligated to keep the operator ")#mi("{T}")#text(" fixed throughout the interpolation process. The proofs of real interpolation theorems are also a little bit messy, though in many cases one can simply invoke a standard instance of such theorems (e.g. the Marcinkiewicz interpolation theorem) as a black box in applications.")

#text("The ")#emph[#text("complex interpolation method")]#text(" instead proceeds by exploiting the powerful tools of complex analysis, in particular the ")#link("http://en.wikipedia.org/wiki/Maximum_modulus_principle")[#text("maximum modulus principle")]#text(" and its relatives (such as the ")#link("http://en.wikipedia.org/wiki/Phragm%C3%A9n-Lindel%C3%B6f_principle")[#text("Phragmén-Lindelöf principle")]#text("). The idea is to rewrite the estimate to be proven (e.g. ")#tao-math("{\\left\\| T f \\right\\|_{L^q(Y, \\nu)} \\leq C \\left\\| f \\right\\|_{L^p(X, \\mu)}}", block: false)#text(") in such a way that it can be embedded into a family of such estimates which depend holomorphically on a complex parameter ")#mi("{s}")#text(" in some domain (e.g. the strip ")#mi("{\\{ \\sigma+it: t \\in {\\bf R}, \\sigma \\in [0,1]\\}}")#text(". One then exploits things like the maximum modulus principle to bound an estimate corresponding to an interior point of this domain by the estimates on the boundary of this domain. The strengths of the complex interpolation method are that it typically gives cleaner constants than the real interpolation method, and also allows the underlying operator ")#mi("{T}")#text(" to vary holomorphically with respect to the parameter ")#mi("{s}")#text(", which can significantly increase the flexibility of the interpolation technique. The proofs of these methods are also very short (if one takes the maximum modulus principle and its relatives as a black box), which make the method particularly amenable for generalisation to more intricate settings (e.g. multilinear operators, mixed Lebesgue norms, etc.). On the other hand, the somewhat rigid requirement of holomorphicity makes it much more difficult to apply this method to non-linear operators, such as sublinear or quasilinear operators; also, the interpolated estimate tends to be of the same “type” as the extreme ones, so that one does not enjoy the upgrading of weak type estimates to strong type estimates that the real interpolation method typically produces. Also, the complex method runs into some minor technical problems when target space ")#mi("{L^q(Y,\\nu)}")#text(" ceases to be a Banach space (i.e. when ")#mi("{q<1}")#text(") as this makes it more difficult to exploit duality.")

#text("Despite these differences, the real and complex methods tend to give broadly similar results in practice, especially if one is willing to ignore constant losses in the estimates or epsilon losses in the exponents.")

#text("The theory of both real and complex interpolation can be studied abstractly, in general normed or quasi-normed spaces; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=482275")[#text("this book")]#text(" for a detailed treatment. However in these notes we shall focus exclusively on interpolation for Lebesgue spaces ")#mi("{L^p}")#text(" (and their cousins, such as the weak Lebesgue spaces ")#mi("{L^{p,\\infty}}")#text(" and the Lorentz spaces ")#mi("{L^{p,r}}")#text(").")

#metadata(none) <tao-52f19ca798ee4a8115d5>

#heading(level: 1)[#strong[#text(" — 1. Interpolation of scalars — ")]]

#text("As discussed in the introduction, most of the interesting applications of interpolation occur when the technique is applied to operators ")#mi("{T}")#text(". However, in order to gain some intuition as to why interpolation works in the first place, let us first consider the significantly simpler (though rather trivial) case of interpolation in the case of scalars or functions.")

#text("We begin first with scalars. Suppose that ")#mi("{A_0, B_0, A_1, B_1}")#text(" are non-negative real numbers such that ")#metadata(none) <tao-b70a14ee1e15d7aa94bd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("A_0 \\leq B_0")]]

#text(" and ")#metadata(none) <tao-ec31682fde561917952f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("A_1 \\leq B_1.")]]

#text(" Then clearly we will have ")#metadata(none) <tao-4c70233e24207acba8d5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("A_\\theta \\leq B_\\theta")]]

#text(" for every ")#mi("{0 \\leq \\theta \\leq 1}")#text(", where we define ")#metadata(none) <tao-9c1815da1a094ee3a97e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("A_\\theta := A_0^{1-\\theta} A_1^\\theta")]]

#text(" and ")#metadata(none) <tao-60aece7251e204c13356>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("B_\\theta := B_0^{1-\\theta} B_1^\\theta;")]]

#text(" indeed one simply raises ")#link(<tao-b70a14ee1e15d7aa94bd>)[#text("(1)")]#text(" to the power ")#mi("{1-\\theta}")#text(", ")#link(<tao-ec31682fde561917952f>)[#text("(2)")]#text(" to the power ")#mi("{\\theta}")#text(", and multiplies the two inequalities together. Thus for instance, when ")#mi("{\\theta = 1/2}")#text(" one obtains the geometric mean of ")#link(<tao-b70a14ee1e15d7aa94bd>)[#text("(1)")]#text(" and ")#link(<tao-ec31682fde561917952f>)[#text("(2)")]#text(":")

#align(center)[#tao-fit-display[#mitex("A_0^{1/2} A_1^{1/2} \\leq B_0^{1/2} B_1^{1/2}.")]]

#text("One can view ")#mi("{A_\\theta}")#text(" and ")#mi("{B_\\theta}")#text(" as the unique log-linear functions of ")#mi("{\\theta}")#text(" (i.e. ")#mi("{\\log A_\\theta}")#text(", ")#mi("{\\log B_\\theta}")#text(" are (affine-)linear functions of ")#mi("{\\theta}")#text(") which equal their boundary values ")#mi("{A_0,A_1}")#text(" and ")#mi("{B_0,B_1}")#text(" respectively as ")#mi("{\\theta = 0,1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" If ")#mi("{A_0 = A L^{1/p_0}}")#text(" and ")#mi("{A_1 = A L^{1/p_1}}")#text(" for some ")#mi("{A,L>0}")#text(" and ")#mi("{0 < p_0,p_1 \\leq \\infty}")#text(", then the log-linear interpolant ")#mi("{A_\\theta}")#text(" is given by ")#mi("{A_\\theta = A L^{1/p_\\theta}}")#text(", where ")#mi("{0 < p_\\theta \\leq \\infty}")#text(" is the quantity such that ")#mi("{\\frac{1}{p_\\theta} = \\frac{1-\\theta}{p_0} + \\frac{\\theta}{p_1}}")#text(".")
]

#text("The deduction of ")#link(<tao-4c70233e24207acba8d5>)[#text("(3)")]#text(" from ")#link(<tao-b70a14ee1e15d7aa94bd>)[#text("(1)")]#text(", ")#link(<tao-ec31682fde561917952f>)[#text("(2)")]#text(" is utterly trivial, but there are still some useful lessons to be drawn from it. For instance, let us take ")#mi("{A_0=A_1=A}")#text(" for simplicity, so we are interpolating two upper bounds ")#mi("{A \\leq B_0}")#text(", ")#mi("{A \\leq B_1}")#text(" on the same quantity ")#mi("{A}")#text(" to give a new bound ")#mi("{A \\leq B_\\theta}")#text(". But actually we have a refinement available to this bound, namely ")#metadata(none) <tao-cd28bc329f0cd6c53dbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("A_\\theta \\leq B_\\theta \\min( \\frac{B_0}{B_1}, \\frac{B_1}{B_0} )^\\varepsilon")]]

#text(" for any sufficiently small ")#mi("{\\varepsilon > 0}")#text(" (indeed one can take any ")#mi("{\\varepsilon}")#text(" less than or equal to ")#mi("{\\min(\\theta,1-\\theta)}")#text("). Indeed one sees this simply by applying ")#link(<tao-4c70233e24207acba8d5>)[#text("(3)")]#text(" with ")#mi("{\\theta}")#text(" with ")#mi("{\\theta-\\varepsilon}")#text(" and ")#mi("{\\theta+\\varepsilon}")#text(" and taking minima. Thus we see that ")#link(<tao-4c70233e24207acba8d5>)[#text("(3)")]#text(" is only sharp when the two original bounds ")#mi("{B_0, B_1}")#text(" are comparable; if instead we have ")#mi("{B_1 \\sim 2^n B_0}")#text(" for some integer ")#mi("{n}")#text(", then ")#link(<tao-cd28bc329f0cd6c53dbb>)[#text("(6)")]#text(" tells us that we can improve ")#link(<tao-4c70233e24207acba8d5>)[#text("(3)")]#text(" by an exponentially decaying factor of ")#tao-math("{2^{-\\varepsilon \\left|n\\right|}}", block: false)#text(". The geometric series formula tells us that such factors are absolutely summable, and so in practice it is often a useful heuristic to pretend that the ")#mi("{n=O(1)}")#text(" cases dominate so strongly that the other cases can be viewed as negligible by comparison.")

#text("Also, one can trivially extend the deduction of ")#link(<tao-4c70233e24207acba8d5>)[#text("(3)")]#text(" from ")#link(<tao-b70a14ee1e15d7aa94bd>)[#text("(1)")]#text(", ")#link(<tao-ec31682fde561917952f>)[#text("(2)")]#text(" as follows: if ")#mi("{\\theta \\rightarrow A_\\theta}")#text(" is a function from ")#mi("{[0,1]}")#text(" to ")#mi("{{\\bf R}^+}")#text(" which is log-convex (thus ")#mi("{\\theta \\mapsto \\log A_\\theta}")#text(" is a convex function of ")#mi("{\\theta}")#text(", and ")#link(<tao-b70a14ee1e15d7aa94bd>)[#text("(1)")]#text(", ")#link(<tao-ec31682fde561917952f>)[#text("(2)")]#text(" hold for some ")#mi("{B_0, B_1 > 0}")#text(", then ")#link(<tao-4c70233e24207acba8d5>)[#text("(3)")]#text(" holds for all intermediate ")#mi("{\\theta}")#text(" also, where ")#mi("{B_\\theta}")#text(" is of course defined by ")#link(<tao-60aece7251e204c13356>)[#text("(5)")]#text(". Thus one can interpolate upper bounds on log-convex functions. However, one certainly cannot interpolate lower bounds: lower bounds on a log-convex function ")#mi("{\\theta \\rightarrow A_\\theta}")#text(" at ")#mi("{\\theta=0}")#text(" and ")#mi("{\\theta=1}")#text(" yield no information about the value of, say, ")#mi("{A_{1/2}}")#text(". Similarly, one cannot extrapolate upper bounds on log-convex functions: an upper bound on, say, ")#mi("{A_0}")#text(" and ")#mi("{A_{1/2}}")#text(" does not give any information about ")#mi("{A_1}")#text(". (However, an upper bound on ")#mi("{A_0}")#text(" coupled with a ")#emph[#text("lower")]#text(" bound on ")#mi("{A_{1/2}}")#text(" gives a lower bound on ")#mi("{A_1}")#text("; this is the contrapositive of an interpolation statement.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that the sum ")#mi("{f+g}")#text(", product ")#mi("{fg}")#text(", or pointwise maximum ")#mi("{\\max(f,g)}")#text(" of two log-convex functions ")#mi("{f,g: [0,1] \\rightarrow {\\bf R}^+}")#text(" is log-convex.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" Every non-negative log-convex function ")#mi("{\\theta \\mapsto A_\\theta}")#text(" is convex, thus in particular ")#mi("{A_\\theta \\leq (1-\\theta) A_0 + \\theta A_1}")#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(" (note that this generalises the arithmetic mean-geometric mean inequality). Of course, the converse statement is not true.")
]

#text("Now we turn to the complex version of the interpolation of log-convex functions, a result known as ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f%27s_theorem")[#text("Lindelöf’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Lindelöf’s theorem)")]#text(" ")#metadata(none) <tao-540cb2d1a1eaef2cd1b6>#text(" Let ")#mi("{s \\mapsto f(s)}")#text(" be a holomorphic function on the strip ")#mi("{S := \\{ \\sigma+it: 0 \\leq \\sigma \\leq 1; t \\in {\\bf R} \\}}")#text(", which obeys the bound ")#metadata(none) <tao-e4ee80cfa07821f0bf44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|f(\\sigma+it)\\right| \\leq A \\exp( \\exp( (\\pi - \\delta) \\left|t\\right|) )", block: true)]]

#text(" for all ")#mi("{\\sigma+it \\in S}")#text(" and some constants ")#mi("{A, \\delta > 0}")#text(". Suppose also that ")#tao-math("{\\left|f(0+it)\\right| \\leq B_0}", block: false)#text(" and ")#tao-math("{\\left|f(1+it)\\right| \\leq B_1}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". Then we have ")#tao-math("{\\left|f(\\theta+it)\\right| \\leq B_\\theta}", block: false)#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(", where ")#mi("{B_\\theta}")#text(" is of course defined by ")#link(<tao-60aece7251e204c13356>)[#text("(5)")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" The hypothesis ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("(7)")]#text(" is a qualitative hypothesis rather than a quantitative one, since the exact values of ")#mi("{A, \\delta}")#text(" do not show up in the conclusion. It is quite a mild condition; any function of exponential growth in ")#mi("{t}")#text(", or even with such super-exponential growth as ")#tao-math("{O( \\left|t\\right|^{\\left|t\\right|})}", block: false)#text(" or ")#tao-math("{O(e^{\\left|t\\right|^{O(1)}})}", block: false)#text(", will obey ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("(7)")]#text(". The principle however fails without this hypothesis, as one can see for instance by considering the holomorphic function ")#mi("{f(s) := \\exp( - i \\exp(\\pi i s) )}")#text(".")
]

#emph[#text("Proof:")]#text(" Observe that the function ")#mi("{s \\mapsto B_0^{1-s} B_1^s}")#text(" is holomorphic and non-zero on ")#mi("{S}")#text(", and has magnitude exactly ")#mi("{B_\\theta}")#text(" on the line ")#mi("{\\text{Re}(s)=\\theta}")#text(" for each ")#mi("{0 \\leq \\theta \\leq 1}")#text(". Thus, by dividing ")#mi("{f}")#text(" by this function (which worsens the qualitative bound ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("(7)")]#text(" slightly) we may reduce to the case when ")#mi("{B_\\theta = 1}")#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(".")

#text("Suppose we temporarily assume that ")#mi("{f(\\sigma+it) \\rightarrow 0}")#text(" as ")#tao-math("{\\left|\\sigma+it\\right| \\rightarrow \\infty}", block: false)#text(". Then by the maximum modulus principle (applied to a sufficiently large rectangular portion of the strip), it must then attain a maximum on one of the two sides of the strip. But ")#tao-math("{\\left|f\\right| \\leq 1}", block: false)#text(" on these two sides, and so ")#tao-math("{\\left|f\\right| \\leq 1}", block: false)#text(" on the interior as well.")

#text("To remove the assumption that ")#mi("{f}")#text(" goes to zero at infinity, we use the ")#link("https://terrytao.wordpress.com/2009/02/28/tricks-wiki-give-yourself-an-epsilon-of-room/")[#text("trick of giving ourselves an epsilon of room")]#text(". Namely, we multiply ")#mi("{f(s)}")#text(" by the holomorphic function ")#mi("{g_\\varepsilon(s) := \\exp( \\varepsilon i \\exp(i[(\\pi-\\delta/2) s + \\delta/4]) )}")#text(" for some ")#mi("{\\varepsilon > 0}")#text(". A little complex arithmetic shows that the function ")#mi("{f(s) g_\\varepsilon(s) g_\\varepsilon(1-s)}")#text(" goes to zero at infinity in ")#mi("{S}")#text(" (the ")#mi("{g_\\varepsilon(s)}")#text(" factor decays fast enough to damp out the growth of ")#mi("{f}")#text(" as ")#mi("{\\text{Im}(s) \\rightarrow -\\infty}")#text(", while the ")#mi("{g_\\varepsilon(1-s)}")#text(" damps out the growth as ")#mi("{\\text{Im}(s) \\rightarrow +\\infty}")#text("), and is bounded in magnitude by ")#mi("{1}")#text(" on both sides of the strip ")#mi("{S}")#text(". Applying the previous case to this function, then taking limits as ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" With the notation and hypotheses of Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("4")]#text(", show that the function ")#tao-math("{\\sigma \\mapsto \\sup_{t \\in {\\bf R}} \\left|f(\\sigma+it)\\right|}", block: false)#text(" is log-convex on ")#mi("{[0,1]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Hadamard three-circles theorem)")]#text(" Let ")#mi("{f}")#text(" be a holomorphic function on an annulus ")#tao-math("{\\{ z \\in {\\bf C}: R_1 \\leq \\left|z\\right| \\leq R_2 \\}}", block: false)#text(". Show that the function ")#tao-math("{r \\mapsto \\sup_{\\theta \\in [0,2\\pi]} \\left|f(re^{i\\theta})\\right|}", block: false)#text(" is log-convex on ")#mi("{[R_1,R_2]}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Phragmén-Lindelöf principle)")]#text(" Let ")#mi("{f}")#text(" be as in Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("4")]#text(", but suppose that we have the bounds ")#tao-math("{f(0+it) \\leq C(1+\\left|t\\right|)^{a_0}}", block: false)#text(" and ")#tao-math("{f(1+it) \\leq C(1+\\left|t\\right|)^{a_1}}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text(" and some exponents ")#mi("{a_0,a_1 \\in {\\bf R}}")#text(" and a constant ")#mi("{C>0}")#text(". Show that one has ")#tao-math("{f(\\sigma+it) \\leq C^{\\prime} (1+\\left|t\\right|)^{(1-\\sigma) a_0 + \\sigma a_1}}", block: false)#text(" for all ")#mi("{\\sigma+it \\in S}")#text(" and some constant ")#mi("{C^{\\prime}}")#text(" (which is allowed to depend on the constants ")#mi("{A, \\delta}")#text(" in ")#link(<tao-e4ee80cfa07821f0bf44>)[#text("(7)")]#text("). (Hint: it is convenient to work first in a half-strip such as ")#mi("{\\{ \\sigma+it \\in S: t \\geq T \\}}")#text(" for some large ")#mi("{T}")#text(". Then multiply ")#mi("{f}")#text(" by something like ")#mi("{\\exp( - ((1-z)a_0+z a_1) \\log(-iz) )}")#text(" for some suitable branch of the logarithm and apply a variant of Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("4")]#text(" for the half-strip. A more refined estimate in this regard is ")#link("http://www.ams.org/mathscinet-getitem?mr=117200")[#text("due to Rademacher")]#text(".) This particular version of the principle gives the ")#emph[#text("convexity bound")]#text(" for Dirichlet series such as the Riemann zeta function. Bounds which exploit the deeper properties of these functions to improve upon the convexity bound are known as ")#emph[#text("subconvexity bounds")]#text(" and are of major importance in analytic number theory, which is of course well outside the scope of this course.")
]

#heading(level: 1)[#strong[#text(" — 2. Interpolation of functions — ")]]

#text("We now turn to the interpolation in function spaces, focusing particularly on the Lebesgue spaces ")#mi("{L^p(X)}")#text(" and the weak Lebesgue spaces ")#mi("{L^{p,\\infty}(X)}")#text(". Here, ")#mi("{X = (X, {\\mathcal X},\\mu)}")#text(" is a fixed measure space. It will not matter much whether we deal with real or complex spaces; for sake of concretness we work with complex spaces. Then for ")#mi("{0 < p < \\infty}")#text(", recall (see ")#link("https://terrytao.wordpress.com/2009/01/09/245b-notes-3-lp-spaces/")[#text("245B Notes 3")]#text(") that ")#mi("{L^p(X)}")#text(" is the space of all functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" whose ")#mi("{L^p}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p(X)} := (\\int_X \\left|f\\right|^p\\ d\\mu)^{1/p}", block: true)]]

#text("is finite, modulo almost everywhere equivalence. The space ")#mi("{L^\\infty(X)}")#text(" is defined similarly, but where ")#tao-math("{\\left\\|f\\right\\|_{L^\\infty(X)}}", block: false)#text(" is the essential supremum of ")#tao-math("{\\left|f\\right|}", block: false)#text(" on ")#mi("{X}")#text(".")

#text("A simple test case in which to understand the ")#mi("{L^p}")#text(" norms better is that of a ")#emph[#text("step function")]#text(" ")#mi("{f = A 1_E}")#text(", where ")#mi("{A}")#text(" is a non-negative number and ")#mi("{E}")#text(" a set of finite measure. Then one has ")#tao-math("{\\left\\|f\\right\\|_{L^p(X)} = A \\mu(E)^{1/p}}", block: false)#text(" for ")#mi("{0 < p \\leq \\infty}")#text(". Observe that this is a log-convex function of ")#mi("{1/p}")#text(". This is a general phenomenon:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Log-convexity of ")#mi("{L^p}")#text(" norms)")]#text(" ")#metadata(none) <tao-05e868955b41dbf10b1b>#text(" Let that ")#mi("{0 < p_0 < p_1 \\leq \\infty}")#text(" and ")#mi("{f \\in L^{p_0}(X) \\cap L^{p_1}(X)}")#text(". Then ")#mi("{f \\in L^p(X)}")#text(" for all ")#mi("{p_0 \\leq p \\leq p_1}")#text(", and furthermore we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f\\right\\|_{L^{p_\\theta}(X)} \\leq \\left\\|f\\right\\|_{L^{p_0}(X)}^{1-\\theta} \\left\\|f\\right\\|_{L^{p_1}(X)}^{\\theta}", block: true)]]

#text("for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(", where the exponent ")#mi("{p_\\theta}")#text(" is defined by ")#mi("{1/p_\\theta := (1-\\theta)/p_0 + \\theta/p_1}")#text(".")

#text("In particular, we see that the function ")#tao-math("{1/p \\mapsto \\left\\|f\\right\\|_{L^p(X)}}", block: false)#text(" is log-convex whenever the right-hand side is finite (and is in fact log-convex for all ")#mi("{0 \\leq 1/p < \\infty}")#text(", if one extends the definition of log-convexity to functions that can take the value ")#mi("{+\\infty}")#text("). In other words, we can interpolate any two bounds ")#tao-math("{\\left\\|f\\right\\|_{L^{p_0}(X)} \\leq B_0}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{L^{p_1}(X)} \\leq B_1}", block: false)#text(" to obtain ")#tao-math("{\\left\\|f\\right\\|_{L^{p_\\theta}(X)} \\leq B_\\theta}", block: false)#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(".")
]

#text("Let us give several proofs of this lemma. We will focus on the case ")#mi("{p_1 < \\infty}")#text("; the endpoint case ")#mi("{p_1=\\infty}")#text(" can be proven directly, or by modifying the arguments below, or by using an appropriate limiting argument, and we leave the details to the reader.")

#text("The first proof is to use ")#link("http://en.wikipedia.org/wiki/H%C3%B6lder%27s_inequality")[#text("Hölder’s inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p_\\theta}(X)}^{p_\\theta} = \\int_X \\left|f\\right|^{(1-\\theta) p_\\theta} \\left|f\\right|^{\\theta p_\\theta} \\ d\\mu \\leq \\left\\| \\left|f\\right|^{(1-\\theta) p_\\theta} \\right\\|_{L^{p_0/((1-\\theta) p_\\theta)}} \\left\\| \\left|f\\right|^{\\theta p_\\theta} \\right\\|_{L^{p_1/(\\theta p_\\theta)}}", block: true)]]

#text("when ")#mi("{p_1}")#text(" is finite (with some minor modifications in the case ")#mi("{p_1 = \\infty}")#text(").")

#text("Another (closely related) proof proceeds by using the log-convexity inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right|^{p_\\theta} \\leq (1-\\alpha) \\left|f(x)\\right|^{p_0} + \\alpha \\left|f(x)\\right|^{p_1}", block: true)]]

#text("for all ")#mi("{x}")#text(", where ")#mi("{0 < \\alpha < 1}")#text(" is the quantity such that ")#mi("{p_\\theta = (1-\\alpha) p_0 + \\alpha p_1}")#text(". If one integrates this inequality in ")#mi("{x}")#text(", one already obtains the claim in the normalised case when ")#tao-math("{\\left\\|f\\right\\|_{L^{p_0}(X)} = \\left\\|f\\right\\|_{L^{p_1}(X)} = 1}", block: false)#text(". To obtain the general case, one can multiply the function ")#mi("{f}")#text(" and the measure ")#mi("{\\mu}")#text(" by appropriately chosen constants to obtain the above normalisation; we leave the details as an exercise to the reader. (The case when ")#tao-math("{\\left\\|f\\right\\|_{L^{p_0}(X)}}", block: false)#text(" or ")#tao-math("{\\left\\|f\\right\\|_{L^{p_1}(X)}}", block: false)#text(" vanishes is of course easy to handle separately.)")

#text("A third approach is more in the spirit of the real interpolation method, avoiding the use of convexity arguments. As in the second proof, we can reduce to the normalised case ")#tao-math("{\\left\\|f\\right\\|_{L^{p_0}(X)} = \\left\\|f\\right\\|_{L^{p_1}(X)} = 1}", block: false)#text(". We then split ")#tao-math("{f = f 1_{\\left|f\\right| \\leq 1} + f 1_{\\left|f\\right| > 1}}", block: false)#text(", where ")#tao-math("{1_{\\left|f\\right| \\leq 1}}", block: false)#text(" is the indicator function to the set ")#tao-math("{\\{ x: \\left|f(x)\\right| \\leq 1\\}}", block: false)#text(", and similarly for ")#tao-math("{1_{\\left|f\\right|>1}}", block: false)#text(". Observe that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f 1_{\\left|f\\right| \\leq 1} \\right\\|_{L^{p_\\theta}(X)}^{p_\\theta} = \\int_{\\left|f\\right| \\leq 1} \\left|f\\right|^{p_\\theta}\\ d\\mu \\leq \\int_X \\left|f\\right|^{p_0}\\ d\\mu = 1", block: true)]]

#text("and similarly")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f 1_{\\left|f\\right| > 1} \\right\\|_{L^{p_\\theta}(X)}^{p_\\theta} = \\int_{\\left|f\\right| > 1} \\left|f\\right|^{p_\\theta}\\ d\\mu \\leq \\int_X \\left|f\\right|^{p_1}\\ d\\mu = 1", block: true)]]

#text("and so by the quasi-triangle inequality (or triangle inequality, when ")#mi("{p_\\theta \\geq 1}")#text(")")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p_\\theta}(X)} \\leq C", block: true)]]

#text("for some constant ")#mi("{C}")#text(" depending on ")#mi("{p_\\theta}")#text(". Note, by the way, that this argument gives the inclusions ")#metadata(none) <tao-70813aaf05c41977270c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("L^{p_0}(X) \\cap L^{p_1}(X) \\subset L^{p_\\theta}(X) \\subset L^{p_0}(X) + L^{p_1}(X).")]]



#text("This is off by a constant factor by what we want. But one can eliminate this constant by using the ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text(". Indeed, if one replaces ")#mi("{X}")#text(" with a Cartesian power ")#mi("{X^M}")#text(" (with the product ")#mi("{\\sigma}")#text("-algebra ")#mi("{{\\mathcal X}^M}")#text(" and product measure ")#mi("{\\mu^M}")#text("), and replace ")#mi("{f}")#text(" by the tensor power ")#mi("{f^{\\otimes M}: (x_1,\\ldots,x_M) \\mapsto f(x_1) \\ldots f(x_M)}")#text(", we see from many applications of the Fubini-Tonelli theorem that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f^{\\otimes M} \\right\\|_{L^p(X^M)} = \\left\\|f\\right\\|_{L^p(X)}^M", block: true)]]

#text("for all ")#mi("{p}")#text(". In particular, ")#mi("{f^{\\otimes M}}")#text(" obeys the same normalisation hypotheses as ")#mi("{f}")#text(", and thus by applying the previous inequality to ")#mi("{f^{\\otimes M}}")#text(", we obtain")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p_\\theta}(X)}^M \\leq C", block: true)]]

#text("for every ")#mi("{M}")#text(", where it is key to note that the constant ")#mi("{C}")#text(" on the right is independent of ")#mi("{M}")#text(". Taking ")#mi("{M^{th}}")#text(" roots and then sending ")#mi("{M \\rightarrow \\infty}")#text(", we obtain the claim.")

#text("Finally, we give a fourth proof in the spirit of the complex interpolation method. By replacing ")#mi("{f}")#text(" by ")#tao-math("{\\left|f\\right|}", block: false)#text(" we may assume ")#mi("{f}")#text(" is non-negative. By expressing non-negative measurable functions as the monotone limit of simple functions and using the monotone convergence theorem, we may assume that ")#mi("{f}")#text(" is a simple function, which is then necessarily of finite measure support from the ")#mi("{L^p}")#text(" finiteness hypotheses. Now consider the function ")#tao-math("{s \\mapsto \\int_X \\left|f\\right|^{(1-s)p_0 + s p_1}\\ d\\mu}", block: false)#text(". Expanding ")#mi("{f}")#text(" out in terms of step functions we see that this is an analytic function of ")#mi("{f}")#text(" which grows at most exponentially in ")#mi("{s}")#text("; also, by the triangle inequality this function has magnitude at most ")#tao-math("{\\int_X \\left|f\\right|^{p_0}}", block: false)#text(" when ")#mi("{s=0+it}")#text(" and magnitude ")#tao-math("{\\int_X \\left|f\\right|^{p_1}}", block: false)#text(" when ")#mi("{s=1+it}")#text(". Applying Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("4")]#text(" and specialising to the value of ")#mi("{s}")#text(" for which ")#mi("{(1-s)p_0+sp_1 = p_\\theta}")#text(" we obtain the claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" If ")#mi("{0 < \\theta < 1}")#text(", show that equality holds in Lemma ")#link(<tao-05e868955b41dbf10b1b>)[#text("9")]#text(" if and only if ")#tao-math("{\\left|f\\right|}", block: false)#text(" is a step function.")
]

#text("Now we consider variants of interpolation in which the “strong” ")#mi("{L^p}")#text(" spaces are replaced by their “weak” counterparts ")#mi("{L^{p,\\infty}}")#text(". Given a measurable function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(", we define the ")#emph[#text("distribution function")]#text(" ")#mi("{\\lambda_f: {\\bf R}^+ \\rightarrow [0,+\\infty]}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\lambda_f(t) := \\mu ( \\{ x \\in X: \\left|f(x)\\right| \\geq t \\} ) = \\int_X 1_{\\left|f\\right| \\geq t}\\ d\\mu.", block: true)]]

#text("This distribution function is closely connected to the ")#mi("{L^p}")#text(" norms. Indeed, from the calculus identity")

#align(center)[#tao-fit-display[#tao-math("\\left|f(x)\\right|^p = p \\int_0^\\infty 1_{\\left|f(x)\\right| \\geq t} t^{p}\\ \\frac{dt}{t}", block: true)]]

#text("and the Fubini-Tonelli theorem, we obtain the formula ")#metadata(none) <tao-6ea43e45ff5cd60af903>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| f \\right\\|_{L^p(X)}^p = p \\int_0^\\infty \\lambda_f(t) t^{p}\\ \\frac{dt}{t}", block: true)]]

#text(" for all ")#mi("{0 < p < \\infty}")#text(", thus the ")#mi("{L^p}")#text(" norms are essentially moments of the distribution function. The ")#mi("{L^\\infty}")#text(" norm is of course related to the distribution function by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^\\infty(X)} = \\inf \\{ t \\ge 0: \\lambda_f(t) = 0 \\}.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-7f2c7bc80b97eb6fd2b7>#text(" Show that we have the relationship")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{L^p(X)}^p \\sim_p \\sum_{n \\in {\\bf Z}} \\lambda_f(2^n) 2^{np}", block: true)]]

#text("for any measurable ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" and ")#mi("{0 < p < \\infty}")#text(", where we use ")#mi("{X \\sim_p Y}")#text(" to denote a pair of inequalities of the form ")#mi("{c_p Y \\leq X \\leq C_p Y}")#text(" for some constants ")#mi("{c_p, C_p > 0}")#text(" depending only on ")#mi("{p}")#text(". (Hint: ")#mi("{\\lambda_f(t)}")#text(" is non-increasing in ")#mi("{t}")#text(".) Thus we can relate the ")#mi("{L^p}")#text(" norms of ")#mi("{f}")#text(" to the dyadic values ")#mi("{\\lambda_f(2^n)}")#text(" of the distribution function; indeed, for any ")#mi("{0 < p \\leq \\infty}")#text(", ")#tao-math("{\\left\\|f\\right\\|_{L^p(X)}}", block: false)#text(" is comparable (up to constant factors depending on ")#mi("{p}")#text(") to the ")#mi("{\\ell^p({\\bf Z})}")#text(" norm of the sequence ")#mi("{n \\mapsto 2^n \\lambda_f(2^n)^{1/p}}")#text(".")
]

#text("Another relationship between the ")#mi("{L^p}")#text(" norms and the distribution function is given by observing that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^p(X)}^p =\\int_X \\left|f\\right|^p\\ d\\mu \\geq \\int_{\\left|f\\right| \\geq t} t^p\\ d\\mu = t^p \\lambda_f(t)", block: true)]]

#text("for any ")#mi("{t > 0}")#text(", leading to ")#link("http://en.wikipedia.org/wiki/Chebyshev%27s_inequality")[#text("Chebyshev’s inequality")]

#align(center)[#tao-fit-display[#tao-math("\\lambda_f(t) \\leq \\frac{1}{t^p} \\left\\|f\\right\\|_{L^p(X)}^p.", block: true)]]

#text("(The ")#mi("{p=1}")#text(" version of this inequality is also known as ")#link("http://en.wikipedia.org/wiki/Markov%27s_inequality")[#text("Markov’s inequality")]#text(". In probability theory, Chebyshev’s inequality is often specialised to the case ")#mi("{p=2}")#text(", and with ")#mi("{f}")#text(" replaced by a normalised function ")#mi("{f - \\mathop{\\bf E} f}")#text(". Note that, as with many other Cyrillic names, there are also a large number of alternative spellings of Chebyshev in the Roman alphabet.)")

#text("Chebyshev’s inequality motivates one to define the ")#emph[#text("weak ")#mi("{L^p}")#text(" norm")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}(X)}}", block: false)#text(" of a measurable function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" for ")#mi("{0 < p < \\infty}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}(X)} := \\sup_{t > 0} t \\lambda_f(t)^{1/p},", block: true)]]

#text("thus Chebyshev’s inequality can be expressed succinctly as")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}(X)} \\leq \\left\\|f\\right\\|_{L^p(X)}.", block: true)]]

#text("It is also natural to adopt the convention that ")#tao-math("{\\left\\|f\\right\\|_{L^{\\infty,\\infty}(X)} = \\left\\|f\\right\\|_{L^\\infty(X)}}", block: false)#text(". If ")#mi("{f, g: X \\rightarrow {\\bf C}}")#text(" are two functions, we have the inclusion")

#align(center)[#tao-fit-display[#tao-math("\\{ \\left|f+g\\right| \\geq t \\} \\subset \\{ \\left|f\\right| \\geq t/2\\} \\cup \\{ \\left|g\\right| \\geq t/2 \\}", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\lambda_{f+g}(t) \\leq \\lambda_f(t/2) + \\lambda_g(t/2);")]]

#text("this easily leads to the quasi-triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f+g\\right\\|_{L^{p,\\infty}(X)} \\lesssim_p \\left\\|f\\right\\|_{L^{p,\\infty}(X)} + \\left\\|f\\right\\|_{L^{p,\\infty}(X)}", block: true)]]

#text("where we use ")#mi("{X \\lesssim_p Y}")#text(" as shorthand for the inequality ")#mi("{X \\leq C_p Y}")#text(" for some constant ")#mi("{C_p}")#text(" depending only on ")#mi("{p}")#text(" (it can be a different constant at each use of the ")#mi("{\\lesssim_p}")#text(" notation). [Note: in analytic number theory, it is more customary to use ")#mi("{\\ll_p}")#text(" instead of ")#mi("{\\lesssim_p}")#text(", following Vinogradov. However, in analysis ")#mi("{\\ll}")#text(" is sometimes used instead to denote “much smaller than”, e.g. ")#mi("{X \\ll Y}")#text(" denotes the assertion ")#mi("{X \\leq cY}")#text(" for some sufficiently small constant ")#mi("{c}")#text(".]")

#text("Let ")#mi("{L^{p,\\infty}(X)}")#text(" be the space of all ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" which have finite ")#mi("{L^{p,\\infty}(X)}")#text(", modulo almost everywhere equivalence; this space is also known as weak ")#mi("{L^p(X)}")#text(". The quasi-triangle inequality soon implies that ")#mi("{L^{p,\\infty}(X)}")#text(" is a quasi-normed vector space with the ")#mi("{L^{p,\\infty}(X)}")#text(" quasi-norm, and Chebyshev’s inequality asserts that ")#mi("{L^{p,\\infty}(X)}")#text(" contains ")#mi("{L^p(X)}")#text(" as a subspace (though the ")#mi("{L^p}")#text(" norm is not a restriction of the ")#mi("{L^{p,\\infty}(X)}")#text(" norm).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 12")]#text(" ")#metadata(none) <tao-cf2560256cff37849be5>#text(" If ")#mi("{X = {\\bf R}^n}")#text(" with the usual measure, and ")#mi("{0 < p < \\infty}")#text(", then the function ")#tao-math("{f(x) := \\left|x\\right|^{-n/p}}", block: false)#text(" is in weak ")#mi("{L^p}")#text(", but not strong ")#mi("{L^p}")#text(". It is also not in strong or weak ")#mi("{L^q}")#text(" for any other ")#mi("{q}")#text(". But the “local” component ")#tao-math("{\\left|x\\right|^{-n/p} 1_{\\left|x\\right| \\leq 1}}", block: false)#text(" of ")#mi("{f}")#text(" is in strong and weak ")#mi("{L^q}")#text(" for all ")#mi("{q < p}")#text(", and the “global” component ")#tao-math("{\\left|x\\right|^{-n/p} 1_{\\left|x\\right| > 1}}", block: false)#text(" of ")#mi("{f}")#text(" is in strong and weak ")#mi("{L^q}")#text(" for all ")#mi("{q > p}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" ")#metadata(none) <tao-bcbf2692a9bd7bcfa04e>#text(" For any ")#mi("{0 < p,q \\leq \\infty}")#text(" and ")#mi("{f: X \\rightarrow {\\bf C}}")#text(", define the ")#emph[#text("(dyadic) Lorentz norm")]#text(" ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}(X)}}", block: false)#text(" to be ")#mi("{\\ell^q({\\bf Z})}")#text(" norm of the sequence ")#mi("{n \\mapsto 2^n \\lambda_f(2^n)^{1/p}}")#text(", and define the ")#emph[#text("Lorentz space")]#text(" ")#mi("{L^{p,q}(X)}")#text(" be the space of functions ")#mi("{f}")#text(" with ")#tao-math("{\\left\\|f\\right\\|_{L^{p,q}(X)}}", block: false)#text(" finite, modulo almost everywhere equivalence. Show that ")#mi("{L^{p,q}(X)}")#text(" is a quasi-normed space, which is equivalent to ")#mi("{L^{p,\\infty}(X)}")#text(" when ")#mi("{q=\\infty}")#text(" and to ")#mi("{L^p(X)}")#text(" when ")#mi("{q=p}")#text(". Lorentz spaces arise naturally in more refined applications of the real interpolation method, and are useful in certain “endpoint” estimates that fail for Lebesgue spaces, but which can be rescued by using Lorentz spaces instead. However, we will not pursue these applications in detail here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{X}")#text(" be a finite set with counting measure, and let ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be a function. For any ")#mi("{0 < p < \\infty}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^{p,\\infty}(X)} \\leq \\left\\|f\\right\\|_{L^p(X)} \\lesssim_p \\log^{1/p}(1+\\left|X\\right|) \\left\\|f\\right\\|_{L^{p,\\infty}(X)}.", block: true)]]

#text("(Hint: to prove the second inequality, normalise ")#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}(X)} = 1}", block: false)#text(", and then manually dispose of the regions of ")#mi("{X}")#text(" where ")#mi("{f}")#text(" is too large or too small.) Thus, in some sense, weak ")#mi("{L^p}")#text(" and strong ")#mi("{L^p}")#text(" are equivalent “up to logarithmic factors”.")
]

#text("One can interpolate weak ")#mi("{L^p}")#text(" bounds just as one can strong ")#mi("{L^p}")#text(" bounds: if ")#tao-math("{\\left\\|f\\right\\|_{L^{p_0,\\infty}(X)} \\leq B_0}", block: false)#text(" and ")#tao-math("{\\left\\|f\\right\\|_{L^{p_1,\\infty}(X)} \\leq B_1}", block: false)#text(", then ")#metadata(none) <tao-986e5d44b5263dd1f280>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\|f\\right\\|_{L^{p_\\theta,\\infty}(X)} \\leq B_\\theta", block: true)]]

#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(". Indeed, from the hypotheses we have")

#align(center)[#tao-fit-display[#mitex("\\lambda_f(t) \\leq \\frac{B_0^{p_0}}{t^{p_0}}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\lambda_f(t) \\leq \\frac{B_1^{p_1}}{t^{p_1}}")]]

#text("for all ")#mi("{t > 0}")#text(", and hence by scalar interpolation (using an interpolation parameter ")#mi("{0<\\alpha<1}")#text(" defined by ")#mi("{p_\\theta = (1-\\alpha)p_0+\\alpha p_1}")#text(", and after doing some algebra) we have ")#metadata(none) <tao-7aa5ae9ecf82f6fc5208>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\lambda_f(t) \\leq \\frac{B_\\theta^{p_\\theta}}{t^{p_\\theta}}")]]

#text(" for all ")#mi("{0 < \\theta < 1}")#text(".")

#text("As remarked in the previous section, we can improve upon ")#link(<tao-7aa5ae9ecf82f6fc5208>)[#text("(11)")]#text("; indeed, if we define ")#mi("{t_0}")#text(" to be the unique value of ")#mi("{t}")#text(" where ")#mi("{B_0^{p_0} / t^{p_0}}")#text(" and ")#mi("{B_1^{p_1}/t^{p_1}}")#text(" are equal, then we have")

#align(center)[#tao-fit-display[#mitex("\\lambda_f(t) \\leq \\frac{B_\\theta^{p_\\theta}}{t^{p_\\theta}} \\min( t/t_0, t_0/t)^\\varepsilon")]]

#text("for some ")#mi("{\\varepsilon > 0}")#text(" depending on ")#mi("{p_0, p_1, \\theta}")#text(". Inserting this improved bound into ")#link(<tao-6ea43e45ff5cd60af903>)[#text("(9)")]#text(" we see that we can improve the weak-type bound ")#link(<tao-986e5d44b5263dd1f280>)[#text("(10)")]#text(" to a strong-type bound ")#metadata(none) <tao-895d138f2b2e7dfe8e02>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\left\\|f\\right\\|_{L^{p_\\theta}(X)} \\leq C_{p_0,p_1,\\theta} B_\\theta", block: true)]]

#text(" for some constant ")#mi("{C_{p_0,p_1,\\theta}}")#text(". Note that one cannot use the tensor power trick this time to eliminate the constant ")#mi("{C_{p_0,p_1,\\theta}}")#text(" as the weak ")#mi("{L^p}")#text(" norms do not behave well with respect to tensor product. Indeed, the constant ")#mi("{C_{p_0,p_1,\\theta}}")#text(" must diverge to infinity in the limit ")#mi("{\\theta \\rightarrow 0}")#text(" if ")#mi("{p_0 \\neq \\infty}")#text(", otherwise it would imply that the ")#mi("{L^{p_0}}")#text(" norm is controlled by the ")#mi("{L^{p_0,\\infty}}")#text(" norm, which is false by Example ")#link(<tao-cf2560256cff37849be5>)[#text("12")]#text("; similarly one must have a divergence as ")#mi("{\\theta \\rightarrow 1}")#text(" if ")#mi("{p_1 \\neq \\infty}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{0 < p_0 < p_1 \\leq \\infty}")#text(" and ")#mi("{0 < \\theta < 1}")#text(". Refine the inclusions in ")#link(<tao-70813aaf05c41977270c>)[#text("(8)")]#text(" to")

#tao-aligned(keep: true)[


#tao-math("L^{p_0}(X) \\cap L^{p_1}(X)  & \\subset L^{p_0,\\infty}(X) \\cap L^{p_1,\\infty}(X) \\subset L^{p_\\theta}(X) \\subset", block: true)



#tao-math(" & \\subset L^{p_\\theta,\\infty}(X) \\subset L^{p_0}(X) + L^{p_1}(X) \\subset L^{p_0,\\infty}(X) + L^{p_1,\\infty}(X).", block: true)
]
]

#text("Define the ")#emph[#text("strong type diagram")]#text(" of a function ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" to be the set of all ")#mi("{1/p}")#text(" for which ")#mi("{f}")#text(" lies in strong ")#mi("{L^p}")#text(", and the ")#emph[#text("weak type diagram")]#text(" to be the set of all ")#mi("{1/p}")#text(" for which ")#mi("{f}")#text(" lies in weak ")#mi("{L^p}")#text(". Then both the strong and weak type diagrams are connected subsets of ")#mi("{[0,+\\infty)}")#text(", and the strong type diagram is contained in the weak type diagram, and contains in turn the interior of the weak type diagram. By experimenting with linear combinations of the examples in Example ")#link(<tao-cf2560256cff37849be5>)[#text("12")]#text(" we see that this is basically everything one can say about the strong and weak type diagrams, without further information on ")#mi("{f}")#text(" or ")#mi("{X}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be a measurable function which is in an ")#mi("{L^p(X)}")#text(" space for some finite ")#mi("p")#text(". Show that there exists a unique non-increasing left-continuous function ")#mi("{f^*: {\\bf R}^+ \\rightarrow [0,+\\infty]}")#text(" such that ")#mi("{\\lambda_{f^*}(t) = \\lambda_f(t)}")#text(" for all ")#mi("{t > 0}")#text(", and in particular ")#tao-math("{\\left\\|f\\right\\|_{L^p(X)} = \\left\\|f^*\\right\\|_{L^p({\\bf R}^+)}}", block: false)#text(" for all ")#mi("{0 < p \\leq \\infty}")#text(", and ")#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}(X)} = \\left\\|f^* \\right\\|_{L^{p,\\infty}({\\bf R}^+)}}", block: false)#text(". (Hint: first look for the formula that describes ")#mi("{f^*(x)}")#text(" for some ")#mi("{x > 0}")#text(" in terms of ")#mi("{\\lambda_f(t)}")#text(".) The function ")#mi("{f^*}")#text(" is known as the ")#emph[#text("non-increasing rearrangement")]#text(" of ")#mi("{f}")#text(", and the spaces ")#mi("{L^p(X)}")#text(" and ")#mi("{L^{p,\\infty}(X)}")#text(" are examples of ")#emph[#text("rearrangement-invariant spaces")]#text(". There are a class of useful ")#link("http://en.wikipedia.org/wiki/Rearrangement_inequality")[#text("rearrangement inequalities")]#text(" that relate ")#mi("{f}")#text(" to its rearrangements, and which can be used to clarify the structure of rearrangement-invariant spaces, but we will not pursue this topic here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" ")#metadata(none) <tao-6a42f3b5d1154428a125>#text(" Let ")#mi("{(X,{\\mathcal X},\\mu)}")#text(" be a ")#mi("{\\sigma}")#text("-finite measure space, let ")#mi("{1 < p < \\infty}")#text(", and ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be a measurable function. Show that the following are equivalent:")

#list(
[#mi("{f}")#text(" lies in ")#mi("{L^{p,\\infty}(X)}")#text(", thus ")#tao-math("{\\left\\|f\\right\\|_{L^{p,\\infty}(X)} \\leq C}", block: false)#text(" for some finite ")#mi("{C}")#text(".")],
[#text("There exists a constant ")#mi("{C^{\\prime}}")#text(" such that ")#tao-math("{\\left|\\int_X f 1_E\\ d\\mu\\right| \\leq C^{\\prime} \\mu(E)^{1/p^{\\prime}}}", block: false)#text(" for all sets ")#mi("{E}")#text(" of finite measure.")]
)

#text("Furthermore show that the best constants ")#mi("{C, C^{\\prime}}")#text(" in the above statements are equivalent up to multiplicative constants depending on ")#mi("{p}")#text(", thus ")#mi("{C \\sim _p C^{\\prime}}")#text(". Conclude that the modified weak ")#mi("{L^{p,\\infty}(X)}")#text(" norm ")#tao-math("{\\left\\| f\\right\\|_{\\tilde L^{p,\\infty}(X)} := \\sup_E \\mu(E)^{-1/p^{\\prime}} \\left|\\int_X f 1_E\\ d\\mu\\right|}", block: false)#text(", where ")#mi("{E}")#text(" ranges over all sets of positive finite measure, is a genuine norm on ")#mi("{L^{p,\\infty}(X)}")#text(" which is equivalent to the ")#mi("{L^{p,\\infty}(X)}")#text(" quasinorm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Let ")#mi("{n > 1}")#text(" be an integer. Find a probability space ")#mi("{(X,{\\mathcal X},\\mu)}")#text(" and functions ")#mi("{f_1,\\ldots,f_n:X \\rightarrow {\\bf R}}")#text(" with ")#tao-math("{\\left\\|f_j\\right\\|_{L^{1,\\infty}(X)} \\leq 1}", block: false)#text(" for ")#mi("{j=1,\\ldots,n}")#text(" such that ")#tao-math("{\\left\\|\\sum_{j=1}^n f_j\\right\\|_{L^{1,\\infty}(X)} \\geq c n \\log n}", block: false)#text(" for some absolute constant ")#mi("{c>0}")#text(". (Hint: exploit the logarithmic divergence of the harmonic series ")#mi("{\\sum_{j=1}^\\infty \\frac{1}{j}}")#text(".) Conclude that there exists a probability space ")#mi("{X}")#text(" such that the ")#mi("{L^{1,\\infty}(X)}")#text(" quasi-norm is not equivalent to an actual norm.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{(X,{\\mathcal X},\\mu)}")#text(" be a ")#mi("{\\sigma}")#text("-finite measure space, let ")#mi("{0 < p < \\infty}")#text(", and ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be a measurable function. Show that the following are equivalent:")

#list(
[#mi("{f}")#text(" lies in ")#mi("{L^{p,\\infty}(X)}")#text(".")],
[#text("There exists a constant ")#mi("{C}")#text(" such that for every set ")#mi("{E}")#text(" of finite measure, there exists a subset ")#mi("{E^{\\prime}}")#text(" with ")#mi("{\\mu(E^{\\prime}) \\geq \\frac{1}{2} \\mu(E)}")#text(" such that ")#tao-math("{\\left|\\int_X f 1_{E^{\\prime}}\\ d\\mu\\right| \\leq C \\mu(E)^{1/p^{\\prime}}}", block: false)#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20")]#text(" Let ")#mi("{(X,{\\mathcal X},\\mu)}")#text(" be a measure space of finite measure, and ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" be a measurable function. Show that the following two statements are equivalent:")

#list(
[#text("There exists a constant ")#mi("{C > 0}")#text(" such that ")#tao-math("{\\left\\|f\\right\\|_{L^p(X)} \\leq Cp}", block: false)#text(" for all ")#mi("{1 \\leq p < \\infty}")#text(".")],
[#text("There exists a constant ")#mi("{c > 0}")#text(" such that ")#tao-math("{\\int_X e^{c\\left|f\\right|}\\ d\\mu < \\infty}", block: false)#text(".")]
)
]

#heading(level: 1)[#strong[#text(" — 3. Interpolation of operators — ")]]

#text("We turn at last to the central topic of these notes, which is interpolation of operators ")#mi("{T}")#text(" between functions on two fixed measure spaces ")#mi("{X = (X,{\\mathcal X},\\mu)}")#text(" and ")#mi("{Y = (Y,{\\mathcal Y},\\nu)}")#text(". To avoid some (very minor) technicalities we will make the mild assumption throughout that ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are both ")#mi("{\\sigma}")#text("-finite, although much of the theory here extends to the non-")#mi("{\\sigma}")#text("-finite setting.")

#text("A typical situation is that of a linear operator ")#mi("{T}")#text(" which maps one ")#mi("{L^{p_0}(X)}")#text(" space to another ")#mi("{L^{q_0}(Y)}")#text(", and also maps ")#mi("{L^{p_1}(X)}")#text(" to ")#mi("{L^{q_1}(Y)}")#text(" for some exponents ")#mi("{0 < p_0,p_1,q_0,q_1 \\leq \\infty}")#text("; thus (by linearity) ")#mi("{T}")#text(" will map the larger vector space ")#mi("{L^{p_0}(X) + L^{p_1}(X)}")#text(" to ")#mi("{L^{q_0}(Y) + L^{q_1}(Y)}")#text(", and one has some estimates of the form ")#metadata(none) <tao-a16aa9358fda90896ec6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\left\\| T f \\right\\|_{L^{q_0}(Y)} \\leq B_0 \\left\\| f\\right\\|_{L^{p_0}(X)}", block: true)]]

#text(" and ")#metadata(none) <tao-eab731a94ceb9138439d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("\\left\\| T f \\right\\|_{L^{q_1}(Y)} \\leq B_1 \\left\\| f\\right\\|_{L^{p_1}(X)}", block: true)]]

#text(" for all ")#mi("{f \\in L^{p_0}(X), f \\in L^{p_1}(X)}")#text(" respectively, and some ")#mi("{B_0, B_1 > 0}")#text(". We would like to then interpolate to say something about how ")#mi("{T}")#text(" maps ")#mi("{L^{p_\\theta}(X)}")#text(" to ")#mi("{L^{q_\\theta}(Y)}")#text(".")

#text("The complex interpolation method gives a satisfactory result as long as the exponents allow one to use duality methods, a result known as the ")#link("http://en.wikipedia.org/wiki/Riesz-Thorin_theorem")[#text("Riesz-Thorin theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Riesz-Thorin theorem)")]#text(" Let ")#mi("{0 < p_0,p_1 \\leq \\infty}")#text(" and ")#mi("{1 \\leq q_0,q_1 \\leq \\infty}")#text(". Let ")#mi("{T: L^{p_0}(X) + L^{p_1}(X) \\rightarrow L^{q_0}(Y) + L^{q_1}(Y)}")#text(" be a linear operator obeying the bounds ")#link(<tao-a16aa9358fda90896ec6>)[#text("(13)")]#text(", ")#link(<tao-eab731a94ceb9138439d>)[#text("(14)")]#text(" for all ")#mi("{f \\in L^{p_0}(X), f \\in L^{p_1}(X)}")#text(" respectively, and some ")#mi("{B_0, B_1 > 0}")#text(". Then we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f \\right\\|_{L^{q_\\theta}(Y)} \\leq B_\\theta \\left\\| f\\right\\|_{L^{p_\\theta}(X)}", block: true)]]

#text("for all ")#mi("{0 < \\theta < 1}")#text(" and ")#mi("{f \\in L^{p_\\theta}(X)}")#text(", where ")#mi("{1/p_\\theta := (1-\\theta)/p_0 + \\theta/p_1}")#text(", ")#mi("{1/q_\\theta := (1-\\theta)/q_0 + \\theta/q_1}")#text(", and ")#mi("{B_\\theta := B_0^{1-\\theta} B_1^\\theta}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" When ")#mi("{X}")#text(" is a point, this theorem essentially collapses to Lemma ")#link(<tao-05e868955b41dbf10b1b>)[#text("9")]#text(" (and when ")#mi("{Y}")#text(" is a point, this is a dual formulation of that lemma); and when ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are both points; this collapses to interpolation of scalars.")
]

#emph[#text("Proof:")]#text(" If ")#mi("{p_0=p_1}")#text(" then the claim follows from Lemma ")#link(<tao-05e868955b41dbf10b1b>)[#text("9")]#text(", so we may assume ")#mi("{p_0 \\neq p_1}")#text(", which in particular forces ")#mi("{p_\\theta}")#text(" to be finite. By symmetry we can take ")#mi("{p_0 < p_1}")#text(". By multiplying the measures ")#mi("{\\mu}")#text(" and ")#mi("{\\nu}")#text(" (or the operator ")#mi("{T}")#text(") by various constants, we can normalise ")#mi("{B_0=B_1=1}")#text(" (the case when ")#mi("{B_0=0}")#text(" or ")#mi("{B_1=0}")#text(" is trivial). Thus we have ")#mi("{B_\\theta=1}")#text(" also.")

#text("By Hölder’s inequality, the bound ")#link(<tao-a16aa9358fda90896ec6>)[#text("(13)")]#text(" implies that ")#metadata(none) <tao-e8fbf6d78f0178cd47b2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left|\\int_Y (Tf) g\\ d\\nu\\right| \\leq \\left\\| f\\right\\|_{L^{p_0}(X)} \\left\\|g\\right\\|_{L^{q^{\\prime}_0}(Y)}", block: true)]]

#text(" for all ")#mi("{f \\in L^{p_0}(X)}")#text(" and ")#mi("{g \\in L^{q^{\\prime}_0}(Y)}")#text(", where ")#mi("{q^{\\prime}_0}")#text(" is the dual exponent of ")#mi("{q_0}")#text(". Similarly we have ")#metadata(none) <tao-4c18b7a6e5a96b0cf07a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\int_Y (Tf) g\\ d\\nu\\right| \\leq \\left\\| f\\right\\|_{L^{p_1}(X)} \\left\\|g\\right\\|_{L^{q^{\\prime}_1}(Y)}", block: true)]]

#text(" for all ")#mi("{f \\in L^{p_1}(X)}")#text(" and ")#mi("{g \\in L^{q^{\\prime}_1}(Y)}")#text(".")

#text("We now claim that ")#metadata(none) <tao-0a8125a9f9ab79e4a5bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#tao-math("\\left|\\int_Y (Tf) g\\ d\\nu\\right| \\leq \\left\\| f\\right\\|_{L^{p_\\theta}(X)} \\left\\|g\\right\\|_{L^{q^{\\prime}_\\theta}(Y)}", block: true)]]

#text(" for all ")#mi("{f}")#text(", ")#mi("{g}")#text(" that are simple functions with finite measure support. To see this, we first normalise ")#tao-math("{\\left\\| f\\right\\|_{L^{p_\\theta}(X)} = \\left\\|g\\right\\|_{L^{q^{\\prime}_\\theta}(Y)} = 1}", block: false)#text(". Observe that we can write ")#tao-math("{f = \\left|f\\right| \\text{sgn}(f)}", block: false)#text(", ")#tao-math("{g = \\left|g\\right| \\text{sgn}(g)}", block: false)#text(" for some functions ")#mi("{\\text{sgn}(f), \\text{sgn}(g)}")#text(" of magnitude at most ")#mi("{1}")#text(". If we then introduce the quantity")

#align(center)[#tao-fit-display[#tao-math("F(s) := \\int_Y (T [ \\left|f\\right|^{(1-s) p_\\theta/p_0 + s p_\\theta/p_1} \\text{sgn}(f) ]) [ \\left|g\\right|^{(1-s) q^{\\prime}_\\theta/q^{\\prime}_0 + s q^{\\prime}_\\theta/q^{\\prime}_1} \\text{sgn}(g) ]\\ d\\nu", block: true)]]

#text("(with the conventions that ")#mi("{q^{\\prime}_\\theta/q^{\\prime}_0, q^{\\prime}_\\theta/q^{\\prime}_1 = 1}")#text(" in the endpoint case ")#mi("{q^{\\prime}_0=q^{\\prime}_1=q^{\\prime}_\\theta=\\infty}")#text(") we see that ")#mi("{F}")#text(" is a holomorphic function of ")#mi("{s}")#text(" of at most exponential growth which equals ")#mi("{\\int_Y (Tf) g\\ d\\nu}")#text(" when ")#mi("{s=\\theta}")#text(". When instead ")#mi("{s=0+it}")#text(", an application of ")#link(<tao-e8fbf6d78f0178cd47b2>)[#text("(15)")]#text(" shows that ")#tao-math("{\\left|F(s)\\right| \\leq 1}", block: false)#text("; a similar claim obtains when ")#mi("{s=1+it}")#text(" using ")#link(<tao-4c18b7a6e5a96b0cf07a>)[#text("(16)")]#text(". The claim now follows from Theorem ")#link(<tao-540cb2d1a1eaef2cd1b6>)[#text("4")]#text(".")

#text("The estimate ")#link(<tao-0a8125a9f9ab79e4a5bc>)[#text("(17)")]#text(" has currently been established for simple functions ")#mi("{f, g}")#text(" with finite measure support. But one can extend the claim to any ")#mi("{f \\in L^{p_\\theta}(X)}")#text(" (keeping ")#mi("{g}")#text(" simple with finite measure support) by decomposing ")#mi("{f}")#text(" into a bounded function and a function of finite measure support, approximating the former in ")#mi("{L^{p_\\theta}(X) \\cap L^{p_1}(X)}")#text(" by simple functions of finite measure support, and approximating the latter in ")#mi("{L^{p_\\theta}(X) \\cap L^{p_0}(X)}")#text(" by simple functions of finite measure support, and taking limits using ")#link(<tao-e8fbf6d78f0178cd47b2>)[#text("(15)")]#text(", ")#link(<tao-4c18b7a6e5a96b0cf07a>)[#text("(16)")]#text(" to justify the passage to the limit. One can then also allow arbitrary ")#mi("{g \\in L^{q^{\\prime}_\\theta}(Y)}")#text(" by using the monotone convergence theorem. The claim now follows from the duality between ")#mi("{L^{q_1}(Y)}")#text(" and ")#mi("{L^{q^{\\prime}_1}(Y)}")#text(". ")#mi("\\Box")

#text("Suppose one has a linear operator ")#mi("{T}")#text(" that maps simple functions of finite measure support on ")#mi("{X}")#text(" to measurable functions on ")#mi("{Y}")#text(" (modulo almost everywhere equivalence). We say that such an operator is of ")#emph[#text("strong type ")#mi("{(p,q)}")]#text(" if it can be extended in a continuous fashion to an operator on ")#mi("{L^p(X)}")#text(" to an operator on ")#mi("{L^q(Y)}")#text("; this is equivalent to having an estimate of the form ")#tao-math("{\\left\\| Tf \\right\\|_{L^q(Y)} \\leq B \\left\\|f\\right\\|_{L^p(X)}}", block: false)#text(" for all simple functions ")#mi("{f}")#text(" of finite measure support. (The extension is unique if ")#mi("{p}")#text(" is finite or if ")#mi("{X}")#text(" has finite measure, due to the density of simple functions of finite measure support in those cases. Annoyingly, uniqueness fails for ")#mi("{L^\\infty}")#text(" of an infinite measure space, though this turns out not to cause much difficulty in practice, as the conclusions of interpolation methods are usually for finite exponents ")#mi("{p}")#text(".) Define the ")#emph[#text("strong type diagram")]#text(" to be the set of all ")#mi("{(1/p,1/q)}")#text(" such that ")#mi("{T}")#text(" is of strong type ")#mi("{(p,q)}")#text(". The Riesz-Thorin theorem tells us that if ")#mi("{T}")#text(" is of strong type ")#mi("{(p_0,q_0)}")#text(" and ")#mi("{(p_1,q_1)}")#text(" with ")#mi("{0 < p_0,p_1 \\leq \\infty}")#text(" and ")#mi("{1 \\leq q_0, q_1 \\leq \\infty}")#text(", then ")#mi("{T}")#text(" is also of strong type ")#mi("{(p_\\theta,q_\\theta)}")#text(" for all ")#mi("{0 < \\theta < 1}")#text("; thus the strong type diagram contains the closed line segment connecting ")#mi("{(1/p_0,1/q_0)}")#text(" with ")#mi("{(1/p_1,1/q_1)}")#text(". Thus the strong type diagram of ")#mi("{T}")#text(" is convex in ")#mi("{[0,+\\infty) \\times [0,1]}")#text(" at least. (As we shall see later, it is in fact convex in all of ")#mi("{[0,+\\infty)^2}")#text(".) Furthermore, on the intersection of the strong type diagram with ")#mi("{[0,1] \\times [0,+\\infty)}")#text(", the operator norm ")#tao-math("{\\left\\|T\\right\\|_{L^p(X) \\rightarrow L^q(Y)}}", block: false)#text(" is a log-convex function of ")#mi("{(1/p,1/q)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" If ")#mi("{X = Y = [0,1]}")#text(" with the usual measure, show that the strong type diagram of the identity operator is the triangle ")#mi("{\\{ (1/p,1/q) \\in [0,+\\infty) \\times [0,+\\infty): 1/p \\leq 1/q \\}}")#text(". If instead ")#mi("{X=Y={\\bf Z}}")#text(" with the usual counting measure, show that the strong type diagram of the identity operator is the triangle ")#mi("{\\{ (1/p,1/q) \\in [0,+\\infty) \\times [0,+\\infty): 1/p \\geq 1/q \\}}")#text(". What is the strong type diagram of the identity when ")#mi("{X=Y={\\bf R}}")#text(" with the usual measure?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{T}")#text(" (resp. ")#mi("{T^*}")#text(") be a linear operator from simple functions of finite measure support on ")#mi("{Y}")#text(" (resp. ")#mi("{X}")#text(") to measurable functions on ")#mi("{Y}")#text(" (resp. ")#mi("{X}")#text(") modulo a.e. equivalence that are absolutely integrable on finite measure sets. We say ")#mi("{T, T^*}")#text(" are ")#emph[#text("formally adjoint")]#text(" if we have ")#mi("{\\int_Y (Tf) \\overline{g}\\ d\\nu = \\int_X f \\overline{T^* g}\\ d\\mu}")#text(" for all simple functions ")#mi("{f,g}")#text(" of finite measure support on ")#mi("{X, Y}")#text(" respectively. If ")#mi("{1 \\leq p,q \\leq \\infty}")#text(", show that ")#mi("{T}")#text(" is of strong type ")#mi("{(p,q)}")#text(" if and only if ")#mi("{T^*}")#text(" is of strong type ")#mi("{(q^{\\prime},p^{\\prime})}")#text(". Thus, taking formal adjoints reflects the strong type diagram around the line of duality ")#mi("{1/p+1/q=1}")#text(", at least inside the Banach space region ")#mi("{[0,1]^2}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" There is a powerful extension of the Riesz-Thorin theorem known as the ")#emph[#text("Stein interpolation theorem")]#text(", in which the single operator ")#mi("{T}")#text(" is replaced by a family of operators ")#mi("{T_s}")#text(" for ")#mi("{s \\in S}")#text(" that vary holomorphically in ")#mi("{s}")#text(" in the sense that ")#mi("{\\int_Y (T_s 1_E) 1_F\\ d\\nu}")#text(" is a holomorphic function of ")#mi("{s}")#text(" for any sets ")#mi("{E, F}")#text(" of finite measure. Roughly speaking, the Stein interpolation theorem asserts that if ")#mi("{T_{j+it}}")#text(" is of strong type ")#mi("{(p_j,q_j)}")#text(" for ")#mi("{j=0,1}")#text(" with a bound growing at most exponentially in ")#mi("{t}")#text(", and ")#mi("{T_s}")#text(" itself grows at most exponentially in ")#mi("{t}")#text(" in some sense, then ")#mi("{T_\\theta}")#text(" will be of strong type ")#mi("{(p_\\theta,q_\\theta)}")#text(". A precise statement of the theorem and some applications can be found in ")#link("http://www.ams.org/mathscinet-getitem?mr=1232192")[#text("Stein’s book on harmonic analysis")]#text(".")
]

#text("Now we turn to the real interpolation method. Instead of linear operators, it is now convenient to consider ")#emph[#text("sublinear operators")]#text(" ")#mi("{T}")#text(" mapping simple functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" of finite measure support in ")#mi("{X}")#text(" to ")#mi("{[0,+\\infty]}")#text("-valued measurable functions on ")#mi("{Y}")#text(" (modulo almost everywhere equivalence, as usual), obeying the homogeneity relationship")

#align(center)[#tao-fit-display[#tao-math("\\left|T( cf )\\right| = \\left|c\\right| \\left|Tf\\right|", block: true)]]

#text("and the pointwise bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|T(f + g)\\right| \\leq \\left|Tf\\right| + \\left|Tg\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|Tf - Tg\\right| \\leq \\left|T(f-g)\\right|", block: true)]]

#text("for all ")#mi("{c \\in {\\bf C}}")#text(", and all simple functions ")#mi("{f, g}")#text(" of finite measure support.")

#text("Every linear operator is sublinear; also, the absolute value ")#tao-math("{Tf := \\left|Sf\\right|}", block: false)#text(" of a linear (or sublinear) operator is also sublinear. More generally, any ")#emph[#text("maximal operator")]#text(" of the form ")#tao-math("{T f := \\sup_{\\alpha \\in A} \\left|S_\\alpha f\\right|}", block: false)#text(", where ")#mi("{(S_\\alpha)_{\\alpha \\in A}}")#text(" is a family of sub-linear operators, is also a non-negative sublinear operator; note that one can also replace the supremum here by any other norm in ")#mi("{\\alpha}")#text(", e.g. one could take an ")#mi("{\\ell^p}")#text(" norm ")#tao-math("{(\\sum_{\\alpha \\in A} \\left|S_\\alpha f\\right|^p)^{1/p}}", block: false)#text(" for any ")#mi("{1 \\leq p \\leq \\infty}")#text(". (After ")#mi("{p=\\infty}")#text(" and ")#mi("{p=1}")#text(", a particularly common case is when ")#mi("{p=2}")#text(", in which case ")#mi("{T}")#text(" is known as a ")#emph[#text("square function")]#text(".)")

#text("The basic theory of sublinear operators is similar to that of linear operators in some respects. For instance, continuity is still equivalent to boundedness:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Let ")#mi("{T}")#text(" be a sublinear operator, and let ")#mi("{0 < p, q \\leq \\infty}")#text(". Assume that either ")#mi("{p}")#text(" is finite, or ")#mi("{X}")#text(" has finite measure. Then the following are equivalent:")

#list(
[#mi("{T}")#text(" can be extended to a continuous operator from ")#mi("{L^p(X)}")#text(" to ")#mi("{L^q(Y)}")#text(".")],
[#text("There exists a constant ")#mi("{B > 0}")#text(" such that ")#tao-math("{\\left\\|Tf\\right\\|_{L^q(Y)} \\leq B \\left\\|f\\right\\|_{L^p(X)}}", block: false)#text(" for all simple functions ")#mi("{f}")#text(" of finite measure support.")],
[#mi("{T}")#text(" can be extended to a operator from ")#mi("{L^p(X)}")#text(" to ")#mi("{L^q(Y)}")#text(" such that ")#tao-math("{\\left\\|Tf\\right\\|_{L^q(Y)} \\leq B \\left\\|f\\right\\|_{L^p(X)}}", block: false)#text(" for all ")#mi("{f \\in L^p(X)}")#text(" and some ")#mi("{B > 0}")#text(".")]
)

#text("Show that the extension mentioned above is unique. Finally, show that the same equivalences hold if ")#mi("{L^q(Y)}")#text(" is replaced by ")#mi("{L^{q,\\infty}(Y)}")#text(" throughout.")
]

#text("We say that ")#mi("{T}")#text(" is of ")#emph[#text("strong type ")#mi("{(p,q)}")]#text(" if any of the above equivalent statements (for ")#mi("{L^q(Y)}")#text(") hold, and of ")#emph[#text("weak type ")#mi("{(p,q)}")]#text(" if any of the above equivalent statements (for ")#mi("{L^{q,\\infty}(Y)}")#text(") hold. We say that a linear operator ")#mi("{S}")#text(" is of strong or weak type ")#mi("{(p,q)}")#text(" if its non-negative counterpart ")#tao-math("{\\left|S\\right|}", block: false)#text(" is; note that this is compatible with our previous definition of strong type for such operators. Also, Chebyshev’s inequality tells us that strong type ")#mi("{(p,q)}")#text(" implies weak type ")#mi("{(p,q)}")#text(".")

#text("We now give the real interpolation counterpart of the Riesz-Thorin theorem, namely the ")#link("http://en.wikipedia.org/wiki/Marcinkiewicz_interpolation_theorem")[#text("Marcinkeiwicz interpolation theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 27 (Marcinkiewicz interpolation theorem)")]#text(" Let ")#mi("{0 < p_0, p_1, q_0, q_1 \\leq \\infty}")#text(" and ")#mi("{0 < \\theta < 1}")#text(" be such that ")#mi("{q_0 \\neq q_1}")#text(", and ")#mi("{p_i \\leq q_i}")#text(" for ")#mi("{i=0,1}")#text(". Let ")#mi("{T}")#text(" be a sublinear operator which is of weak type ")#mi("{(p_0,q_0)}")#text(" and of weak type ")#mi("{(p_1,q_1)}")#text(". Then ")#mi("{T}")#text(" is of strong type ")#mi("{(p_\\theta,q_\\theta)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 28")]#text(" Of course, the same claim applies to linear operators ")#mi("{S}")#text(" by setting ")#tao-math("{T := \\left|S\\right|}", block: false)#text(". One can also extend the argument to ")#emph[#text("quasilinear")]#text(" operators, in which the pointwise bound ")#tao-math("{\\left|T(f+g)\\right| \\leq \\left|Tf\\right| + \\left|Tg\\right|}", block: false)#text(" is replaced by ")#tao-math("{\\left|T(f+g)\\right| \\leq C(\\left|Tf\\right|+\\left|Tg\\right|)}", block: false)#text(" for some constant ")#mi("{C > 0}")#text(", but this generalisation only appears occasionally in applications. The conditions ")#mi("{p_0 \\leq q_0, p_1 \\leq q_1}")#text(" can be replaced by the variant condition ")#mi("{p_\\theta \\leq q_\\theta}")#text(" (see Exercise ")#link(<tao-cb7bf562420b82e97ee1>)[#text("31")]#text(", Exercise ")#link(<tao-73b9c5a13313b0e7eda1>)[#text("33")]#text("), but cannot be eliminated entirely: see Exercise ")#link(<tao-35d29871051cc0c98e6f>)[#text("32")]#text(". The precise hypotheses required on ")#mi("{p_0,p_1,q_0,q_1,p_\\theta,q_\\theta}")#text(" are rather technical and I recommend that they be ignored on a first reading.")
]

#emph[#text("Proof:")]#text(" For notational reasons it is convenient to take ")#mi("{q_0, q_1}")#text(" finite; however the arguments below can be modified without much difficulty to deal with the infinite case (or one can use a suitable limiting argument); we leave this to the interested reader.")

#text("By hypothesis, there exist constants ")#mi("{B_0, B_1 > 0}")#text(" such that ")#metadata(none) <tao-ecbc574df99b1f7ae00b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\lambda_{Tf}(t) \\leq B_0^{q_0} \\left\\|f\\right\\|_{L^{p_0}(X)}^{q_0} / t^{q_0}", block: true)]]

#text(" and ")#metadata(none) <tao-fa3198053435549e9392>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\lambda_{Tf}(t) \\leq B_1^{q_1} \\left\\|f\\right\\|_{L^{p_1}(X)}^{q_1} / t^{q_1}", block: true)]]

#text(" for all simple functions ")#mi("{f}")#text(" of finite measure support, and all ")#mi("{t > 0}")#text(". Let us write ")#mi("{A \\lesssim B}")#text(" to denote ")#mi("{A \\leq C_{p_0,p_1,q_0,q_1,\\theta,B_0,B_1} B}")#text(" for some constant ")#mi("{C_{p_0,p_1,q_0,q_1,\\theta,B_0,B_1}}")#text(" depending on the indicated parameters. By ")#link(<tao-6ea43e45ff5cd60af903>)[#text("(9)")]#text(", it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_0^\\infty \\lambda_{Tf}(t) t^{q_\\theta} \\frac{dt}{t} \\lesssim \\left\\|f\\right\\|_{L^{p_\\theta}(X)}^{q_\\theta}.", block: true)]]

#text("By homogeneity we can normalise ")#tao-math("{\\left\\|f\\right\\|_{L^{p_\\theta}(X)}=1}", block: false)#text(".")

#text("Actually, it will be more slightly convenient to work with the dyadic version of the above estimate, namely ")#metadata(none) <tao-4c62f0a5523c4ea94d2f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\sum_{n \\in {\\bf Z}} \\lambda_{Tf}(2^n) 2^{q_\\theta n} \\lesssim 1;")]]

#text(" see Exercise ")#link(<tao-7f2c7bc80b97eb6fd2b7>)[#text("11")]#text(". The hypothesis ")#tao-math("{\\left\\|f\\right\\|_{L^{p_\\theta}(X)}=1}", block: false)#text(" similarly implies that ")#metadata(none) <tao-39e741eddb03e3118da6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sum_{m \\in {\\bf Z}} \\lambda_f(2^m) 2^{p_\\theta m} \\lesssim 1.")]]

#text(" The basic idea is then to get enough control on the numbers ")#mi("{\\lambda_{Tf}(2^n)}")#text(" in terms of the numbers ")#mi("{\\lambda_f(2^m)}")#text(" that one can deduce ")#link(<tao-4c62f0a5523c4ea94d2f>)[#text("(20)")]#text(" from ")#link(<tao-39e741eddb03e3118da6>)[#text("(21)")]#text(".")

#text("When ")#mi("{p_0=p_1}")#text(", the claim follows from direct substitution of ")#link(<tao-ecbc574df99b1f7ae00b>)[#text("(18)")]#text(", ")#link(<tao-fa3198053435549e9392>)[#text("(19)")]#text(" (see also the discussion in the previous section about interpolating strong ")#mi("{L^p}")#text(" bounds from weak ones), so let us assume ")#mi("{p_0 \\neq p_1}")#text("; by symmetry we may take ")#mi("{p_0 < p_1}")#text(", and thus ")#mi("{p_0 < p_\\theta < p_1}")#text(". In this case we cannot directly apply ")#link(<tao-ecbc574df99b1f7ae00b>)[#text("(18)")]#text(", ")#link(<tao-fa3198053435549e9392>)[#text("(19)")]#text(" because we only control ")#mi("{f}")#text(" in ")#mi("{L^{p_\\theta}}")#text(", not ")#mi("{L^{p_0}}")#text(" or ")#mi("{L^{p_1}}")#text(". To get around this, we use the basic real interpolation trick of ")#emph[#text("decomposing")]#text(" ")#mi("{f}")#text(" into pieces. There are two basic choices for what decomposition to pick. On one hand, one could adopt a “minimalistic” approach and just decompose into two pieces")

#align(center)[#tao-fit-display[#mitex("f = f_{\\geq s} + f_{<s}")]]

#text("where ")#tao-math("{f_{\\geq s} := f 1_{\\left|f\\right| \\geq s}}", block: false)#text(" and ")#tao-math("{f_{<s} := f 1_{\\left|f\\right| < s}}", block: false)#text(", and the threshold ")#mi("{s}")#text(" is a parameter (depending on ")#mi("{n}")#text(") to be optimised later. Or we could adopt a “maximalistic” approach and perform the dyadic decomposition")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{m \\in {\\bf Z}} f_m")]]

#text("where ")#tao-math("{f_m = f 1_{2^m \\leq \\left|f\\right| < 2^{m+1}}}", block: false)#text(". (Note that only finitely many of the ")#mi("{f_m}")#text(" are non-zero, as we are assuming ")#mi("{f}")#text(" to be a simple function.) We will adopt the latter approach, in order to illustrate the dyadic decomposition method; the former approach also works, but we leave it as an exercise to the interested reader.")

#text("From sublinearity we have the pointwise estimate")

#align(center)[#tao-fit-display[#mitex("Tf \\leq \\sum_m Tf_m")]]

#text("which implies that")

#align(center)[#tao-fit-display[#mitex("\\lambda_{Tf}(2^n) \\leq \\sum_m \\lambda_{Tf_m}( c_{n,m} 2^n )")]]

#text("whenever ")#mi("{c_{n,m}}")#text(" are positive constants such that ")#mi("{\\sum_m c_{n,m} = 1}")#text(", but for which we are otherwise at liberty to choose. We will set aside the problem of deciding what the optimal choice of ")#mi("{c_{n,m}}")#text(" is for now, and continue with the proof.")

#text("From ")#link(<tao-ecbc574df99b1f7ae00b>)[#text("(18)")]#text(", ")#link(<tao-fa3198053435549e9392>)[#text("(19)")]#text(", we have two bounds for the quantity ")#mi("{\\lambda_{Tf_m}( c_{n,m} 2^n )}")#text(", namely")

#align(center)[#tao-fit-display[#tao-math("\\lambda_{Tf_m}( c_{n,m} 2^n ) \\lesssim c_{n,m}^{-q_0} 2^{-nq_0} \\left\\| f_m \\right\\|_{L^{p_0}(X)}^{q_0}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\lambda_{Tf_m}( c_{n,m} 2^n ) \\lesssim c_{n,m}^{-q_1} 2^{-nq_1} \\left\\| f_m \\right\\|_{L^{p_1}(X)}^{q_1}.", block: true)]]

#text("From construction of ")#mi("{f_m}")#text(" we can bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f_m \\right\\|_{L^{p_0}(X)} \\lesssim 2^m \\lambda_f(2^m)^{1/p_0}", block: true)]]

#text("and similarly for ")#mi("{p_1}")#text(", and thus we have")

#align(center)[#tao-fit-display[#mitex("\\lambda_{Tf_m}( c_{n,m} 2^n ) \\lesssim c_{n,m}^{-q_i} 2^{-nq_i} 2^{m q_i} \\lambda_f(2^m)^{q_i/p_i}.")]]

#text("for ")#mi("{i=0,1}")#text(". To prove ")#link(<tao-4c62f0a5523c4ea94d2f>)[#text("(20)")]#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_n 2^{n q_\\theta} \\sum_m \\min_{i=0,1} c_{n,m}^{-q_i} 2^{-nq_i} 2^{m q_i} \\lambda_f(2^m)^{q_i/p_i} \\lesssim 1.")]]

#text("It is convenient to introduce the quantities ")#mi("{a_m := \\lambda_f(2^m) 2^{m p_\\theta}}")#text(" appearing in ")#link(<tao-39e741eddb03e3118da6>)[#text("(21)")]#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sum_m a_m \\lesssim 1")]]

#text("and our task is to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_n 2^{n q_\\theta} \\sum_m \\min_{i=0,1} c_{n,m}^{-q_i} 2^{-nq_i} 2^{m q_i} 2^{-m q_i p_\\theta / p_i} a_m^{q_i/p_i} \\lesssim 1.")]]

#text("Since ")#mi("{p_i \\leq q_i}")#text(", we have ")#mi("{a_m^{q_i/p_i} \\lesssim a_m}")#text(", and so we are reduced to the purely numerical task of locating constants ")#mi("{c_{n,m}}")#text(" with ")#mi("{\\sum_m c_{n,m} \\leq 1}")#text(" for all ")#mi("{n}")#text(" such that ")#metadata(none) <tao-6b8510cde6de81a95ddd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_n 2^{n q_\\theta} \\min_{i=0,1} c_{n,m}^{-q_i} 2^{-nq_i} 2^{m q_i} 2^{-m q_i p_\\theta / p_i} \\lesssim 1")]]

#text(" for all ")#mi("{m}")#text(".")

#text("We can simplify this expression a bit by collecting terms and making some substitutions. The points ")#mi("{(1/p_0,1/q_0), (1/p_\\theta,1/q_\\theta), (1/p_1,1/q_1)}")#text(" are collinear, and we can capture this by writing")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{p_i} = \\frac{1}{p_\\theta} + x_i; \\quad \\frac{1}{q_i} = \\frac{1}{q_\\theta} + \\alpha x_i")]]

#text("for some ")#mi("{x_0 > 0 > x_1}")#text(" and some ")#mi("{\\alpha \\in {\\bf R}}")#text(". We can then simplify the left-hand side of ")#link(<tao-6b8510cde6de81a95ddd>)[#text("(22)")]#text(" to")

#align(center)[#tao-fit-display[#mitex("\\sum_{n} \\min_{i=0,1} c_{n,m}^{-q_i} (2^{n \\alpha q_\\theta - m p_\\theta})^{q_i x_i}.")]]

#text("Note that ")#mi("{q_0 x_0}")#text(" is positive and ")#mi("{q_1 x_1}")#text(" is negative. If we then pick ")#mi("{c_{n,m}}")#text(" to be a sufficiently small multiple of ")#tao-math("{2^{-\\beta \\left|n \\alpha q_\\theta - m p_\\theta\\right|}}", block: false)#text(" for a suitabe small constant ")#mi("{\\beta}")#text(", we obtain the claim by summing geometric series. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 29")]#text(" A closer inspection of the proof (or a rescaling argument to reduce to the normalised case ")#mi("{B_0=B_1=1}")#text(", as in preceding sections) reveals that one establishes the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf\\right\\|_{L^{q_\\theta}(Y)} \\leq C_{p_0,p_1,q_0,q_1,\\theta,C} B_0^{1-\\theta} B_1^\\theta \\left\\|f\\right\\|_{L^{p_\\theta}(X)}", block: true)]]

#text("for all simple functions ")#mi("{f}")#text(" of finite measure support (or for all ")#mi("{f \\in L^{p_\\theta}(X)}")#text(", if one works with the continuous extension of ")#mi("{T}")#text(" to such functions), and some constant ")#mi("{C_{p_0,p_1,q_0,q_1,\\theta,C} > 0}")#text(". Thus the conclusion here is weaker by a multiplicative constant from that in the Riesz-Thorin theorem, but the hypotheses are weaker too (weak-type instead of strong-type). Indeed, we see that the constant ")#mi("{C_{p_0,p_1,q_0,q_1,\\theta}}")#text(" must blow up as ")#mi("{\\theta \\rightarrow 0}")#text(" or ")#mi("{\\theta \\rightarrow 1}")#text(".")
]

#text("The power of the Marcinkiewicz interpolation theorem, as compared to the Riesz-Thorin theorem, is that it allows one to weaken the hypotheses on ")#mi("{T}")#text(" from strong type to weak type. Actually, it can be weakened further. We say that a non-negative sublinear operator ")#mi("{T}")#text(" is ")#emph[#text("restricted weak-type ")#mi("{(p,q)}")]#text(" for some ")#mi("{0 < p,q \\leq \\infty}")#text(" if there is a constant ")#mi("{B > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^{q,\\infty}(Y)} \\leq B \\mu(E)^{1/p}", block: true)]]

#text("for all sets ")#mi("{E}")#text(" of finite measure and all simple functions ")#mi("{f}")#text(" with ")#tao-math("{\\left|f\\right| \\leq 1_E}", block: false)#text(". Clearly restricted weak-type ")#mi("{(p,q)}")#text(" is implied by weak-type ")#mi("{(p,q)}")#text(", and thus by strong-type ")#mi("{(p,q)}")#text(". (One can also define the notion of ")#emph[#text("restricted strong-type ")#mi("{(p,q)}")]#text(" by replacing ")#mi("{L^{q,\\infty}(Y)}")#text(" with ")#mi("{L^q(Y)}")#text("; this is between strong-type ")#mi("{(p,q)}")#text(" and restricted weak-type ")#mi("{(p,q)}")#text(", but is incomparable to weak-type ")#mi("{(p,q)}")#text(".)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" ")#metadata(none) <tao-8e6a645f7d8eb33e7690>#text(" Show that the Marcinkiewicz interpolation theorem continues to hold if the weak-type hypotheses are replaced by restricted weak-type hypothesis. (Hint: where were the weak-type hypotheses used in the proof?)")
]

#text("We thus see that the strong-type diagram of ")#mi("{T}")#text(" contains the interior of the restricted weak-type or weak-type diagrams of ")#mi("{T}")#text(", at least in the triangular region ")#mi("{\\{ (1/p,1/q) \\in [0,+\\infty)^2: p \\geq q \\}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" ")#metadata(none) <tao-cb7bf562420b82e97ee1>#text(" Suppose that ")#mi("{T}")#text(" is a sublinear operator of restricted weak-type ")#mi("{(p_0,q_0)}")#text(" and ")#mi("{(p_1,q_1)}")#text(" for some ")#mi("{0 < p_0,p_1,q_0,q_1 \\leq \\infty}")#text(". Show that ")#mi("{T}")#text(" is of restricted weak-type ")#mi("{(p_\\theta,q_\\theta)}")#text(" for any ")#mi("{0 < \\theta < 1}")#text(", or in other words the restricted type diagram is convex in ")#mi("{[0,+\\infty)^2}")#text(". (This is an easy result requiring only interpolation of scalars.) Conclude that the hypotheses ")#mi("{p_0 \\leq q_0, p_1 \\leq q_1}")#text(" in the Marcinkiewicz interpolation theorem can be replaced by the variant ")#mi("{p_\\theta < q_\\theta}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" ")#metadata(none) <tao-35d29871051cc0c98e6f>#text(" For any ")#mi("{\\alpha \\in {\\bf R}}")#text(", let ")#mi("{X_\\alpha}")#text(" be the natural numbers ")#mi("{{\\bf N}}")#text(" with the weighted counting measure ")#mi("{\\sum_{n \\in {\\bf N}} 2^{\\alpha n} \\delta_n}")#text(", thus each point ")#mi("{n}")#text(" has mass ")#mi("{2^{\\alpha n}}")#text(". Show that if ")#mi("{\\alpha > \\beta > 0}")#text(", then the identity operator from ")#mi("{X_\\alpha}")#text(" to ")#mi("{X_\\beta}")#text(" is of weak-type ")#mi("{(p,q)}")#text(" but not strong-type ")#mi("{(p,q)}")#text(" when ")#mi("{1 < p,q < \\infty}")#text(" and ")#mi("{\\alpha/p = \\beta/q}")#text(". Conclude that the hypotheses ")#mi("{p_0 \\leq q_0, p_1 \\leq q_1}")#text(" cannot be dropped entirely.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" ")#metadata(none) <tao-73b9c5a13313b0e7eda1>#text(" Suppose we are in the situation of the Marcinkiewicz interpolation theorem, with the hypotheses ")#mi("{p_0 \\leq q_0, p_1 \\leq q_1}")#text(" replaced by ")#mi("{p_0 \\neq p_1}")#text(". Show that for all ")#mi("{0 < \\theta < 1}")#text(" and ")#mi("{1 \\leq r \\leq \\infty}")#text(" there exists a ")#mi("{B > 0}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f \\right\\|_{L^{q_\\theta,r}(Y)} \\leq B \\left\\|f\\right\\|_{L^{p_\\theta,r}(X)}", block: true)]]

#text("for all simple functions ")#mi("{f}")#text(" of finite measure support, where the Lorentz norms ")#mi("{L^{p,q}}")#text(" were defined in Exercise ")#link(<tao-bcbf2692a9bd7bcfa04e>)[#text("13")]#text(". (Hint: repeat the proof of the Marcinkiewicz interpolation theorem, but partition the sum ")#mi("{\\sum_{n,m}}")#text(" into regions of the form ")#mi("{\\{ n \\alpha q_\\theta - m p_\\theta = k + O(1) \\}}")#text(" for integer ")#mi("{k}")#text(". Obtain a bound for each summand which decreases geometrically as ")#mi("{k \\rightarrow \\pm \\infty}")#text(".) Conclude that the hypotheses ")#mi("{p_0 \\leq q_0, p_1 \\leq q_1}")#text(" in the Marcinkiewicz interpolation theorem can be replaced by ")#mi("{p_\\theta \\leq q_\\theta}")#text(". This Lorentz space version of the interpolation theorem is in some sense the “right” version of the theorem, but the Lorentz spaces are slightly more technical to deal with than the Lebesgue spaces, and the Lebesgue space version of Marcinkiewicz interpolation is largely sufficient for most applications.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" For ")#mi("{i=1,2}")#text(", let ")#mi("{X_i = (X_i,{\\mathcal X}_i, \\mu_i), Y_i = (Y_i,{\\mathcal Y}_i,\\nu_i)}")#text(" be ")#mi("{\\sigma}")#text("-finite measure spaces, and let ")#mi("{T_i}")#text(" be a linear operator from simple functions of finite measure support on ")#mi("{X_i}")#text(" to measurable functions on ")#mi("{Y_i}")#text(" (modulo almost everywhere equivalence, as always). Let ")#mi("{X = X_1 \\times X_2}")#text(", ")#mi("{Y = Y_1 \\times Y_2}")#text(" be the product spaces (with product ")#mi("{\\sigma}")#text("-algebra and product measure). Show that there exists a unique (modulo a.e. equivalence) linear operator ")#mi("{T}")#text(" defined on linear combinations of indicator functions ")#mi("{1_{E_1 \\times E_2}}")#text(" of product sets of sets ")#mi("{E_1 \\subset X_1}")#text(", ")#mi("{E_2 \\subset X_2}")#text(" of finite measure, such that")

#align(center)[#tao-fit-display[#mitex("T 1_{E_1 \\times E_2}(y_1,y_2) := T_1 1_{E_1}(y_1) T_2 1_{E_2} (y_2)")]]

#text("for a.e. ")#mi("{(y_1,y_2) \\in Y}")#text("; we refer to ")#mi("{T}")#text(" as the ")#emph[#text("tensor product")]#text(" of ")#mi("{T_1}")#text(" and ")#mi("{T_2}")#text(" and write ")#mi("{T = T_1 \\otimes T_2}")#text(". Show that if ")#mi("{T_1, T_2}")#text(" are of strong-type ")#mi("{(p,q)}")#text(" for some ")#mi("{1 \\leq p \\leq q < \\infty}")#text(" with operator norms ")#mi("{B_1,B_2}")#text(" respectively, then ")#mi("{T}")#text(" can be extended to a bounded linear operator on ")#mi("{L^p(X)}")#text(" to ")#mi("{L^q(Y)}")#text(" with operator norm exactly equal to ")#mi("{B_1 B_2}")#text(", thus")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_1 \\otimes T_2 \\right\\|_{L^p(X_1 \\times X_2) \\rightarrow L^q(Y_1 \\times Y_2)} = \\left\\| T_1 \\right\\|_{L^p(X_1) \\rightarrow L^q(Y_1)} \\left\\| T_2 \\right\\|_{L^p(X_2) \\rightarrow L^q(Y_2)}.", block: true)]]

#text("(Hint: for the lower bound, show that ")#mi("{T_1 \\otimes T_2(f_1 \\otimes f_2) = (T_1 f_1) \\otimes (T_2 f_2)}")#text(" for all simple functions ")#mi("{f_1,f_2}")#text(". For the upper bound, express ")#mi("{T_1 \\times T_2}")#text(" as the composition of two other operators ")#mi("{T_1 \\otimes I_1}")#text(" and ")#mi("{I_2 \\otimes T_2}")#text(" for some identity operators ")#mi("{I_1, I_2}")#text(", and establish operator norm bounds on these two operators separately.) Use this and the tensor power trick to deduce the Riesz-Thorin theorem (in the special case when ")#mi("{1 \\leq p_i \\leq q_i < \\infty}")#text(" for ")#mi("{i=0,1}")#text(", and ")#mi("{q_0 \\neq q_1}")#text(") from the Marcinkiewicz interpolation theorem. Thus one can (with some effort) avoid the use of complex variable methods to prove the Riesz-Thorin theorem, at least in some cases.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Hölder’s inequality for Lorentz spaces)")]#text(" Let ")#mi("{f \\in L^{p_1,r_1}(X)}")#text(" and ")#mi("{g \\in L^{p_2,r_2}(X)}")#text(" for some ")#mi("{0 < p_1,p_2,r_1,r_2 \\leq \\infty}")#text(". Show that ")#mi("{fg \\in L^{p_3,r_3}(X)}")#text(", where ")#mi("{1/p_3=1/p_1+1/p_2}")#text(" and ")#mi("{1/r_3=1/r_1+1/r_2}")#text(", with the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\|fg\\right\\|_{L^{p_3,r_3}(X)} \\leq C_{p_1,p_2,r_1,r_2} \\left\\|f\\right\\|_{L^{p_1,r_1}(X)} \\left\\|g\\right\\|_{L^{p_2,r_2}(X)}", block: true)]]

#text("for some constant ")#mi("{C_{p_1,p_2,r_1,r_2}}")#text(". (This estimate is due to ")#link("http://www.ams.org/mathscinet-getitem?mr=146673")[#text("O’Neil")]#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 36")]#text(" Just as interpolation of functions can be clarified by using step functions ")#mi("{f= A 1_E}")#text(" as a test case, it is instructive to use rank one operators such as")

#align(center)[#tao-fit-display[#mitex("Tf := A \\langle f, 1_E \\rangle 1_F = A (\\int_E f\\ d\\mu) 1_F")]]

#text("where ")#mi("{E \\subset X, F \\subset Y}")#text(" are finite measure sets, as test cases for the real and complex interpolation methods. (After understanding the rank one case, I then recommend looking at the rank two case, e.g. ")#mi("{Tf := A_1 \\langle f, 1_{E_1} \\rangle 1_{F_1} + A_2 \\langle f, 1_{E_2} \\rangle 1_{F_2}}")#text(", where ")#mi("{E_2, F_2}")#text(" could be very different in size from ")#mi("{E_1, F_1}")#text(".)")
]

#heading(level: 1)[#strong[#text(" — 4. Some examples of interpolation — ")]]

#text("Now we apply the interpolation theorems to some classes of operators. An important such class is given by the ")#emph[#text("integral operators")]

#align(center)[#tao-fit-display[#mitex("Tf(y) := \\int_X K(x,y) f(x)\\ d\\mu(x)")]]

#text("from functions ")#mi("{f: X \\rightarrow {\\bf C}}")#text(" to functions ")#mi("{Tf: Y \\rightarrow {\\bf C}}")#text(", where ")#mi("{K: X \\times Y \\rightarrow {\\bf C}}")#text(" is a fixed measurable function, known as the ")#emph[#text("kernel")]#text(" of the integral operator ")#mi("{T}")#text(". Of course, this integral is not necessarily convergent, so we will also need to study the sublinear analogue")

#align(center)[#tao-fit-display[#tao-math("\\left|T\\right| f(y) := \\int_X \\left|K(x,y)\\right| \\left|f(x)\\right|\\ d\\mu(x)", block: true)]]

#text("which is well-defined (though it may be infinite).")

#text("The following useful lemma gives us strong-type bounds on ")#tao-math("{\\left|T\\right|}", block: false)#text(" and hence ")#mi("{T}")#text(", assuming certain ")#mi("{L^p}")#text(" type bounds on the rows and columns of ")#mi("{K}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 37 (Schur’s test)")]#text(" Let ")#mi("{K: X \\times Y \\rightarrow {\\bf C}}")#text(" be a measurable function obeying the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| K(x, \\cdot) \\right\\|_{L^{q_0}(Y)} \\leq B_0", block: true)]]

#text("for almost every ")#mi("{x \\in X}")#text(", and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| K(\\cdot, y) \\right\\|_{L^{p^{\\prime}_1}(X)} \\leq B_1", block: true)]]

#text("for almost every ")#mi("{y \\in Y}")#text(", where ")#mi("{1 \\leq p_1, q_0 \\leq \\infty}")#text(" and ")#mi("{B_0, B_1 > 0}")#text(". Then for every ")#mi("{0 < \\theta < 1}")#text(", ")#tao-math("{\\left|T\\right|}", block: false)#text(" and ")#mi("{T}")#text(" are of strong-type ")#mi("{(p_\\theta,q_\\theta)}")#text(", with ")#mi("{Tf(y)}")#text(" well-defined for all ")#mi("{f \\in L^{p_\\theta}(X)}")#text(" and almost every ")#mi("{y \\in Y}")#text(", and furthermore")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^{q_\\theta}(Y)} \\leq B_\\theta \\left\\| f\\right\\|_{L^{p_\\theta}(X)}.", block: true)]]

#text("Here we adopt the convention that ")#mi("{p_0 := 1}")#text(" and ")#mi("{q_1 := \\infty}")#text(", thus ")#mi("{q_\\theta = q_0/(1-\\theta)}")#text(" and ")#mi("{p^{\\prime}_\\theta = p^{\\prime}_1/\\theta}")#text(".")
]

#emph[#text("Proof:")]#text(" The hypothesis ")#tao-math("{\\left\\| K(x, \\cdot) \\right\\|_{L^{q_0}(Y)} \\leq B_0}", block: false)#text(", combined with ")#link("http://en.wikipedia.org/wiki/Minkowski_inequality")[#text("Minkowski’s integral inequality")]#text(", shows us that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|T\\right| f \\right\\|_{L^{q_0}(Y)} \\leq B_0 \\left\\|f\\right\\|_{L^1(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^1(X)}")#text("; in particular, for such ")#mi("{f}")#text(", ")#mi("{Tf}")#text(" is well-defined almost everywhere, and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f \\right\\|_{L^{q_0}(Y)} \\leq B_0 \\left\\|f\\right\\|_{L^1(X)}.", block: true)]]

#text("Similarly, Hölder’s inequality tells us that for ")#mi("{f \\in L^{p_1}(X)}")#text(", ")#mi("{Tf}")#text(" is well-defined everywhere, and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f \\right\\|_{L^{\\infty}(Y)} \\leq B_1 \\left\\|f\\right\\|_{L^{p_1}(X)}.", block: true)]]

#text("Applying the Riesz-Thorin theorem we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T f \\right\\|_{L^{q_\\theta}(Y)} \\leq B_\\theta \\left\\|f\\right\\|_{L^{p_\\theta}(X)}", block: true)]]

#text("for all simple functions ")#mi("{f}")#text(" with finite measure support; replacing ")#mi("{K}")#text(" with ")#tao-math("{\\left|K\\right|}", block: false)#text(" we also see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|T\\right| f \\right\\|_{L^{q_\\theta}(Y)} \\leq B_\\theta \\left\\|f\\right\\|_{L^{p_\\theta}(X)}", block: true)]]

#text("for all simple functions ")#mi("{f}")#text(" with finite measure support, and thus (by monotone convergence) for all ")#mi("{f \\in L^{p_\\theta}(X)}")#text(". The claim then follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 38")]#text(" ")#metadata(none) <tao-5fdf7aae385d0979fa0b>#text(" Let ")#mi("{A = (a_{ij})_{1 \\leq i \\leq n, 1 \\leq j \\leq m}}")#text(" be a matrix such that the sum of the magnitudes of the entries in every row and column is at most ")#mi("{B}")#text(", i.e. ")#tao-math("{\\sum_{i=1}^n \\left|a_{ij}\\right| \\leq B}", block: false)#text(" for all ")#mi("{j}")#text(" and ")#tao-math("{\\sum_{j=1}^m \\left|a_{ij}\\right| \\leq B}", block: false)#text(" for all ")#mi("{i}")#text(". Then one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Ax \\right\\|_{\\ell^p_m} \\leq B \\left\\|x\\right\\|_{\\ell^p_n}", block: true)]]

#text("for all vectors ")#mi("{x \\in {\\bf C}^n}")#text(" and all ")#mi("{1 \\leq p \\leq \\infty}")#text(". Note the extreme cases ")#mi("{p=1}")#text(", ")#mi("{p=\\infty}")#text(" can be seen directly; the remaining cases then follow from interpolation.")

#text("A useful special case arises when ")#mi("{A}")#text(" is an ")#emph[#mi("{S}")#text("-sparse")]#text(" matrix, which means that at most ")#mi("{S}")#text(" entries in any row or column are non-zero (e.g. ")#link("http://en.wikipedia.org/wiki/Permutation_matrix")[#text("permutation matrices")]#text(" are ")#mi("{1}")#text("-sparse). We then conclude that the ")#mi("{\\ell^p}")#text(" operator norm of ")#mi("{A}")#text(" is at most ")#tao-math("{S \\sup_{i,j} \\left|a_{i,j}\\right|}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Establish Schur’s test by more direct means, taking advantage of the duality relationship")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g\\right\\|_{L^p(Y)} := \\sup \\{ \\left|\\int_Y g h\\right|: \\left\\|h\\right\\|_{L^{p^{\\prime}}(Y)} \\leq 1 \\}", block: true)]]

#text("for ")#mi("{1 \\leq p \\leq \\infty}")#text(", as well as ")#link("http://en.wikipedia.org/wiki/Young%27s_inequality")[#text("Young’s inequality")]#text(" ")#mi("{xy \\leq \\frac{1}{r} x^r +\\frac{1}{r^{\\prime}} x^{r^{\\prime}}}")#text(" for ")#mi("{1 < r < \\infty}")#text(". (You may wish to first work out Example ")#link(<tao-5fdf7aae385d0979fa0b>)[#text("38")]#text(", say with ")#mi("{p=2}")#text(", to figure out the logic.)")
]

#text("A useful corollary of Schur’s test is ")#link("http://en.wikipedia.org/wiki/Young%27s_inequality")[#text("Young’s convolution inequality")]#text(" for the convolution ")#mi("{f*g}")#text(" of two functions ")#mi("{f: {\\bf R}^n \\rightarrow {\\bf C}}")#text(", ")#mi("{g: {\\bf R}^n \\rightarrow {\\bf C}}")#text(", defined as")

#align(center)[#tao-fit-display[#mitex("f*g(x) := \\int_{{\\bf R}^n} f(y) g(x-y)\\ dy")]]

#text("provided of course that the integrand is absolutely convergent.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Young’s inequality)")]#text(" Let ")#mi("{1 \\leq p,q,r \\leq \\infty}")#text(" be such that ")#mi("{\\frac{1}{p} + \\frac{1}{q} = \\frac{1}{r} + 1}")#text(". Show that if ")#mi("{f \\in L^p({\\bf R}^n)}")#text(" and ")#mi("{g \\in L^q({\\bf R}^n)}")#text(", then ")#mi("{f*g}")#text(" is well-defined almost everywhere and lies in ")#mi("{L^r({\\bf R}^n)}")#text(", and furthermore that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{L^r({\\bf R}^n)} \\leq \\left\\|f\\right\\|_{L^p({\\bf R}^n)} \\left\\|g\\right\\|_{L^q({\\bf R}^n)}.", block: true)]]

#text("(Hint: Apply Schur’s test to the kernel ")#mi("{K(x,y) := g(x-y)}")#text(".)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 41")]#text(" There is nothing special about ")#mi("{{\\bf R}^n}")#text(" here; one could in fact use any locally compact group ")#mi("{G}")#text(" with a bi-invariant ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(". On the other hand, if one specialises to ")#mi("{{\\bf R}^n}")#text(", then it is possible to improve Young’s inequality slightly, to")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{L^r({\\bf R}^n)} \\leq (A_p A_q A_{r^{\\prime}})^{n/2} \\left\\|f\\right\\|_{L^p({\\bf R}^n)} \\left\\|g\\right\\|_{L^q({\\bf R}^n)}.", block: true)]]

#text("where ")#mi("{A_p := p^{1/p} / (p^{\\prime})^{1/p^{\\prime}}}")#text(", a ")#link("http://www.ams.org/mathscinet-getitem?mr=385456")[#text("result of Beckner")]#text("; the constant here is best possible, as can be seen by testing the inequality in the case when ")#mi("{f, g}")#text(" are Gaussians.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]#text(" Let ")#mi("{1 < p < \\infty}")#text(", and let ")#mi("{f \\in L^p({\\bf R}^n)}")#text(", ")#mi("{g \\in L^{p^{\\prime}}({\\bf R}^n)}")#text(". Young’s inequality tells us that ")#mi("{f*g \\in L^\\infty({\\bf R}^n)}")#text(". Refine this further by showing that ")#mi("{f*g \\in C_0({\\bf R}^n)}")#text(", i.e. ")#mi("{f*g}")#text(" is continuous and goes to zero at infinity. (")#emph[#text("Hint:")]#text(" first show this when ")#mi("{f, g \\in C_c({\\bf R}^n)}")#text(", then use a limiting argument.)")
]

#text("We now give a variant of Schur’s test that allows for weak estimates.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 43 (Weak-type Schur’s test)")]#text(" Let ")#mi("{K: X \\times Y \\rightarrow {\\bf C}}")#text(" be a measurable function obeying the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| K(x, \\cdot) \\right\\|_{L^{q_0,\\infty}(Y)} \\leq B_0", block: true)]]

#text("for almost every ")#mi("{x \\in X}")#text(", and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| K(\\cdot, y) \\right\\|_{L^{p^{\\prime}_1,\\infty}(X)} \\leq B_1", block: true)]]

#text("for almost every ")#mi("{y \\in Y}")#text(", where ")#mi("{1 < p_1, q_0 < \\infty}")#text(" and ")#mi("{B_0, B_1 > 0}")#text(" (note the endpoint exponents ")#mi("{1,\\infty}")#text(" are now excluded). Then for every ")#mi("{0 < \\theta < 1}")#text(", ")#tao-math("{\\left|T\\right|}", block: false)#text(" and ")#mi("{T}")#text(" are of strong-type ")#mi("{(p_\\theta,q_\\theta)}")#text(", with ")#mi("{Tf(y)}")#text(" well-defined for all ")#mi("{f \\in L^{p_\\theta}(X)}")#text(" and almost every ")#mi("{y \\in Y}")#text(", and furthermore")

#align(center)[#tao-fit-display[#tao-math("\\left\\| Tf \\right\\|_{L^{q_\\theta}(Y)} \\leq C_{p_1,q_0,\\theta} B_\\theta \\left\\| f\\right\\|_{L^{p_\\theta}(X)}.", block: true)]]

#text("Here we again adopt the convention that ")#mi("{p_0 := 1}")#text(" and ")#mi("{q_1 := \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" From Exercise ")#link(<tao-6a42f3b5d1154428a125>)[#text("17")]#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\int_Y |K(x,y)| 1_E(y)\\ d\\nu(y) \\lesssim B_0 \\mu(E)^{1/q^{\\prime}_0}")]]

#text("for any measurable ")#mi("{E \\subset Y}")#text(", where we use ")#mi("{A \\lesssim B}")#text(" to denote ")#mi("{A \\leq C_{p_1,q_0,\\theta} B}")#text(" for some ")#mi("{C_{p_1,q_0,\\theta}}")#text(" depending on the indicated parameters. By the Fubini-Tonelli theorem, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\int_Y |T| f(y) 1_E(y)\\ d\\nu(y) \\lesssim B_0 \\mu(E)^{1/q^{\\prime}_0} \\left\\|f\\right\\|_{L^1(X)}", block: true)]]

#text("for any ")#mi("{f \\in L^1(X)}")#text("; by Exercise ")#link(<tao-6a42f3b5d1154428a125>)[#text("17")]#text(" again we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|T\\right| f \\right\\|_{L^{q_0,\\infty}(Y)} \\lesssim B_0 \\left\\|f\\right\\|_{L^1(X)}", block: true)]]

#text("thus ")#tao-math("{\\left|T\\right|}", block: false)#text(" is of weak-type ")#mi("{(1,q_0)}")#text(". In a similar vein, from yet another application of Exercise ")#link(<tao-6a42f3b5d1154428a125>)[#text("17")]#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\left|T\\right| f \\right\\|_{L^{\\infty}(Y)} \\lesssim B_1 \\mu(F)^{1/p_1}", block: true)]]

#text("whenever ")#mi("{0 \\leq f \\leq 1_F}")#text(" and ")#mi("{F \\subset X}")#text(" has finite measure; thus ")#tao-math("{\\left|T\\right|}", block: false)#text(" is of restricted type ")#mi("{(p_1,\\infty)}")#text(". Applying Exercise ")#link(<tao-8e6a645f7d8eb33e7690>)[#text("30")]#text(" we conclude that ")#tao-math("{\\left|T\\right|}", block: false)#text(" is of strong type ")#mi("{(p_\\theta,q_\\theta)}")#text(" (with operator norm ")#mi("{\\lesssim B_\\theta}")#text("), and the claim follows. ")#mi("\\Box")

#text("This leads to a weak-type version of Young’s inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 44 (Weak-type Young’s inequality)")]#text(" Let ")#mi("{1 < p,q,r < \\infty}")#text(" be such that ")#mi("{\\frac{1}{p} + \\frac{1}{q} = \\frac{1}{r} + 1}")#text(". Show that if ")#mi("{f \\in L^p({\\bf R}^n)}")#text(" and ")#mi("{g \\in L^{q,\\infty}({\\bf R}^n)}")#text(", then ")#mi("{f*g}")#text(" is well-defined almost everywhere and lies in ")#mi("{L^r({\\bf R}^n)}")#text(", and furthermore that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f*g\\right\\|_{L^r({\\bf R}^n)} \\leq C_{p,q} \\left\\|f\\right\\|_{L^p({\\bf R}^n)} \\left\\|g\\right\\|_{L^{q,\\infty}({\\bf R}^n)}.", block: true)]]

#text("for some constant ")#mi("{C_{p,q} > 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 45")]#text(" Refine the previous exercise by replacing ")#mi("{L^r({\\bf R}^n)}")#text(" with the Lorentz space ")#mi("{L^{r,p}({\\bf R}^n)}")#text(" throughout.")
]

#text("Recall that the function ")#tao-math("{1/\\left|x\\right|^\\alpha}", block: false)#text(" will lie in ")#mi("{L^{n/\\alpha,\\infty}({\\bf R}^n)}")#text(" for ")#mi("{\\alpha > 0}")#text(". We conclude")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 46 (Hardy-Littlewood-Sobolev fractional integration inequality)")]#text(" ")#metadata(none) <tao-59bbcf1e281fdf241c5d>#text(" Let ")#mi("{1 < p, r < \\infty}")#text(" and ")#mi("{0 < \\alpha < n}")#text(" be such that ")#mi("{\\frac{1}{p} + \\frac{\\alpha}{n} = \\frac{1}{r} + 1}")#text(". If ")#mi("{f \\in L^p({\\bf R}^n)}")#text(", then the function ")#mi("{I_\\alpha f}")#text(", defined as")

#align(center)[#tao-fit-display[#tao-math("I_\\alpha f(x) := \\int_{{\\bf R}^n} \\frac{f(y)}{\\left|x-y\\right|^\\alpha}\\ dy", block: true)]]

#text("is well-defined almost everywhere and lies in ")#mi("{L^r({\\bf R}^n)}")#text(", and furthermore that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| I_\\alpha f \\right\\|_{L^r({\\bf R}^n)} \\leq C_{p,\\alpha,n} \\left\\|f\\right\\|_{L^p({\\bf R}^n)}", block: true)]]

#text("for some constant ")#mi("{C_{p,\\alpha,n} > 0}")#text(".")
]

#text("This inequality is of importance in the theory of Sobolev spaces, which we will discuss in a subsequent lecture.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 47")]#text(" Show that Corollary ")#link(<tao-59bbcf1e281fdf241c5d>)[#text("46")]#text(" can fail at the endpoints ")#mi("{p=1}")#text(", ")#mi("{r=\\infty}")#text(", or ")#mi("{\\alpha=n}")#text(".")
]

#emph[#text("Update")]#text(", Apr 6: another exercise added; note renumbering.")

#emph[#text("Update")]#text(", Apr 8: some formatting errors fixed.")

#emph[#text("Update")]#text(", Sep 14: definition of sublinearity fixed.")

#heading(level: 1)[#text("Comments (148)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-3/#comment-689476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2025")])]

#text("I wonder if there is an interpolation result of Riesz-Thorin type for norms of linear operators on the L_p x L_p, where the norm of the product space L_p x L_p is ||(f,g)||_p=(E|f|^p+E|g|^p)^1/p. Thank you.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-3/#comment-689481")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2025")])]

#text("Sure, one can identify ")#mi("L^p(X) \\times L^p(X)")#text(" with ")#mi("L^p(X \\times \\{1,2\\})")#text(" as normed vector spaces in a straightforward fashion (giving ")#mi("X \\times \\{1,2\\}")#text(" the measure given by two copies of the measure on ")#mi("X")#text(").")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-3/#comment-689489")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2025")])]

#text("Dr Tao, I know that not every mathematical terms have a precise definition, but I wonder does the term “Interpolation” have?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-3/#comment-693495")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("Is the ")#emph[#text("distribution function")]#text(" defined in this post a generalization of the cumulative distribution function?")

#text("(Or are they simply similar in name but unrelated?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-3/#comment-693497")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2026")])]

#text("I am ")#link("https://claude.ai/share/a76bf759-7f68-4884-a0ff-103792acd3d5")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-44101")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2010")])]

#text("Dear Prof. Tao,")

#text("some errata for your proof of the Marcinkiewicz interpolation theorem:")

#text("In equation (22), there should be no summation over m.")

#text("In the last equation (“simplify the left-hand side of (22) to…”), the summation goes over n instead of m, and the exponent of ")#mi("c_{n,m}")#text(" is ")#mi("-q_i")#text(", not ")#mi("-q_i x_i")#text(".")

#text("This affects the choice of the c’s, i.e. ")#tao-math("c_{n,m} = 2^{- \\left|n \\alpha q_\\theta - m p_\\theta\\right| x} d(n)", block: false)#text(" with ")#mi("x = min(x_0, x_1) / 2")#text(" would do. The normalization sequence satisfies $d(n) = O(1)$ automatically given ")#mi("\\sum_m c_{n,m} = 1")#text(".")

#text("I also wonder whether, at the end of the proof of the Riesz-Thorin theorem, the decomposition of f into a bounded and a finitely supported function could be omitted in case ")#mi("1 < p_\\theta < \\infty")#text(" (when the sum of the norms of the components is greater then the norm of f itself). It does provide continuity of ")#mi("T : L^{p_\\theta}(X) \\to L^{q_\\theta}(Y)")#text(" (with norm 2), so that the conclusion follows because it actually has norm 1 on a dense subspace (of simple functions), but can one do without it?")

#text("best regards, pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-44103")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2010")])]

#text("Thanks for the correction!")

#text("One can try to extend the main argument directly to general ")#mi("L^{p_\\theta}")#text(" functions rather than just to simple functions with finite measure support; from a conceptual viewpoint this is more natural, but from a technical viewpoint it basically requires one to establish the continuity of ")#mi("L^{p_\\theta}")#text(" to ")#mi("L^{q_\\theta}")#text(" beforehand to justify various formal operations, which is inconvenient as this is part of what one is trying to prove in the first place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3d1e00ae3ac8f4cb33f37da16fc590310287011b292d90c5e5958432fb2d6971-ee4daa0a64127414fff44bb194723ef1740d2f9687fc38c243fec2d1a012be7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alex")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-686997")[#strong[#text("alex")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2025")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I think there might be some errata: the choice of ")#mi("\\beta")#text(" for ")#mi("c_{n,m}")#text(" in (22) should be replaced by ")#mi("\\beta := \\dfrac{1}{2} \\max(-x_0,x_1) 0>x_1")#text(" and we should ensure ")#mi("(x_0 + \\beta) >0")#text(" and ")#mi("(x_1-\\beta) < 0")#text(".")#linebreak()#text(" Best regards, alex")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-44125")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2010")])]

#text("Dear Prof. Tao,")

#text("I am experiencing slight difficulties with Exercise 21 (Marcinkiewicz theorem, Lorentz space version).")

#text("Doing the same calculations as in the given proof of the special case, I obtain (this time with ")#mi("a_m = \\lambda_f (2^m)^{r/p_\\theta} 2^{r m}")#text(" and ")#mi("\\sum_m a_m = 1")#text("), as a sufficient condition the existence of summable (over m) c’s such that")#linebreak()#text(" ")#mi("\\sum_n \\left( \\sum_m \\min_i c_{n,m}^{-q_i} a_m^{p_\\theta q_i / (p_i r)} 2^{-n q_i + q_\\theta n + m q_i - p_\\theta m q_i/p_i} \\right)^{r/q_\\theta} = O(1)")#text(".")

#text("Now, assuming the easiest case ")#mi("r=q_\\theta")#text(", the exponent of ")#mi("a_m")#text(" is less than 1 for one of the i's (unless ")#mi("q_0 p_1 = p_0 q_1")#text("). Even then, I could not think of an approach to finding c's that uses all the information: whatever I came up with looked like it would work without any assumptions on a's and was therefore false. Could you give some further indications?")

#text("kind regards, pavel")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-44127")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2010")])]

#text("Ah, yes, this is a little delicate, in part because the decomposition of f used here is actually not the optimal one for this problem – it decomposes the height ")#mi("2^m")#text(" of the function dyadically (vertical dyadic decomposition), when in fact it is the width ")#mi("\\lambda_f(2^m)")#text(" that ought to be dyadically decomposed (horizontal dyadic decomposition). One can still recover from this point by decomposing the sequence ")#mi("a_m")#text(" into dyadic pieces, but this is quite messy.")

#text("Another approach is to use frequency envelopes. Pick a small ")#mi("\\varepsilon > 0")#text(" and replace ")#mi("a_m")#text(" by the slightly larger envelope ")#tao-math("b_m := \\sup_{m^{\\prime}} 2^{-\\varepsilon\\left|m-m^{\\prime}\\right|} a_{m^{\\prime}}", block: false)#text(". The point of doing so is that the ")#mi("b_m")#text(" obey a Lipschitz property ")#tao-math("2^{-\\varepsilon \\left|m-m^{\\prime}\\right|} b_{m^{\\prime}} \\leq b_m \\leq  2^{\\varepsilon \\left|m-m^{\\prime}\\right|} b_{m^{\\prime}}", block: false)#text(" but are still summable in ")#mi("\\ell^1")#text(". One then chooses ")#mi("c_{n,m}")#text(" to be adapted to the crossover point between the two quantities in the ")#mi("\\min")#text(" (modifying the ")#mi("n \\alpha q_\\theta - m p_\\theta")#text(" term by some multiple of ")#mi("\\log b_m")#text("); as long as the Lipschitz parameter ")#mi("\\varepsilon")#text(" is small enough, one will still be able to close the argument.")

#text("I may elaborate on the frequency envelope approach in a subsequent blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d4e5cf041bd75cc4830d15bcd18e20818378b8a44051d72ef71e8857f4a67d01-05704d916e28f9916b5cb5d11fee2ec849714e3de123f22bcc29ba312a3a8109.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wenying Gan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-51734")[#strong[#text("Wenying Gan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2011")])]

#text("Dear Prof. Tao:")

#text("I think there is a typo in $Ex 8$. There should be a index 1/p for log(1+|X|). Or the result we need to prove is incorrect. Thanks in advance.")

#text("Best")#linebreak()#text(" Wenying Gan")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6497c48c5b1a229e8a9bec33cf1e49a934591e6c0201f16e57ebf4aa1d90476-8fc20c33da5ccc74f1db06091ffd6fbc912060a79609619ba4c8a51f98e2a39f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gandhi Viswanathan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-189510")[#strong[#text("Gandhi Viswanathan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2012")])]

#text("Dear Professor Tao,")

#text("The “Control Level Sets” tricki page you cite earlier also lacks the (1/p) index mentioned in this comment about Ex 8. Can we assume the same correction is needed in the tricki ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-189512")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2012")])]

#text("Yes; I edited the tricki page accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6497c48c5b1a229e8a9bec33cf1e49a934591e6c0201f16e57ebf4aa1d90476-8fc20c33da5ccc74f1db06091ffd6fbc912060a79609619ba4c8a51f98e2a39f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gandhi Viswanathan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-189514")[#strong[#text("Gandhi Viswanathan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2012")])]

#text("Thanks!")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stein’s interpolation theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-52201")[#strong[#text("Stein’s interpolation theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2011")])]

#text("[…] where are functions depending on in a suitably analytic manner, for instance taking for some test function , and similarly for . If are chosen properly, will depend analytically on as well, and the two hypotheses (1), (2) give bounds on and for respectively. The Lindelöf theorem then gives bounds on intermediate values of , such as ; and the Riesz-Thorin theorem can then be deduced by a duality argument. (This is covered in many graduate real analysis texts; I myself covered it here.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of X")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-136639")[#strong[#text("X")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2012")])]

#text("Dear Prof. Tao,")#linebreak()#text(" There is one thing unclear for me In your statement of Lindelof’s Theorem. Suppose ")#mi("\\delta")#text(" is very small, then if ")#mi("t \\rightarrow -\\infty")#text(", then the bound goes to ")#mi("A")#text(". So I think the theorem doesn’t cover directly the case where the bound is, for example, ")#mi("A \\exp(t^2)")#text(".")

#text("Could you please help explain a bit?")

#text("Thank you!")

#text("X")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-136701")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2012")])]

#text("The factor ")#mi("g_\\varepsilon(1-s)")#text(" will damp out the growth as ")#mi("t \\to -\\infty")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6497c48c5b1a229e8a9bec33cf1e49a934591e6c0201f16e57ebf4aa1d90476-8fc20c33da5ccc74f1db06091ffd6fbc912060a79609619ba4c8a51f98e2a39f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gandhi Viswanathan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-188019")[#strong[#text("Gandhi Viswanathan")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2012")])]

#text("Dear Professor Tao, I noticed that the quantity ")#mi("s")#text(" defined via ")#mi("{(1-s)p_0+sp_1 = p_\\theta}")#text(" in the complex analysis (4th) proof of Lemma 2 above is identical to the quantity ")#mi("\\alpha")#text(" defined below Lemma 2 in the 2nd proof (via Jensen’s inequality).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-218592")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2013")])]

#text("In Remark 2, ")#mi("A,\\sigma")#text(" should be ")#mi("A,\\delta")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8f434e4a56998f737422a0884c2860b0bcdc395c5c458c0a92d0b306479c241b-fa4557564fbd83b325b3a0d450d39f5cac3110ca695b6f10205d2c3325d84078.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-246176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2013")])]

#text("Dear Professor Tao,")#linebreak()#text(" I was wandering if for $p1$ such that $\\frac{1}{p}+\\frac{1}{q}=2$ one has a young type inequality for the convolution. That is $||f*g||_{1}\\leq C||f||_{p} ||g||_{q}$")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-315842")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("For remark 8, is it necessary that the Haar measure is “bi”-invariant? Is the commutativity of the convolution implicitly used anywhere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-315913")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("The bi-invariance of Haar measure is needed in order to ensure the map ")#mi("x \\mapsto x^{-1}")#text(" is measure-preserving, otherwise one has to be very careful how to define convolution, as various definitions of convolution that are equivalent in the bi-invariant setting may now cease to be equivalent.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-315930")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2014")])]

#text("Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7a386a7aa0e79f9694687232ea5724b3e51bffa8dcafe66470777500c3525127-911f6e0f197aaf4e711d61056385e21d41fae43a06f7a66a7c7b81fbc77c17ae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of urbano")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-324087")[#strong[#text("urbano")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2014")])]

#text("Dear Professor Tao,")#linebreak()#text(" is it also possible to show that ")#tao-math("\\left|\\left|f(x,y)\\right|\\right|_{L^{p,\\infty}_{x,y}}\\leq \\left|f(x,y)\\right||_{L^p_x(L^{p,\\infty}_{y})}", block: false)#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-451447")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2015")])]

#text("Dear Prof. Tao, thanks for the nice post.")

#text("One small comment: In equation (7) in the statement of Lindelöf’s theorem, I believe you want to put |t| instead of t in the exponent of the right hand side. Otherwise, the theorem still holds true, but the statement is needlessly weak.")

#text("Best regards, Felix V.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-452149")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2015")])]

#text("Dear Prof. Tao,")

#text("I think I found a problem in Exercise 17: For sublinear operators,")#linebreak()#text(" it seems that “boundedness” in the sense of ")#tao-math("\\left\\| Tf\\right\\| _{q}\\lesssim\\left\\| f\\right\\| _{p}", block: false)#linebreak()#text(" for all step functions does not(!) imply that T can be extended")#linebreak()#text(" continuously to all of ")#mi("L^{p}")#text(".")

#text("My counterexample is the following: Define for simple functions ")#mi("f:\\mathbb{R}\\to\\mathbb{C}")#linebreak()#text(" ")#tao-math("Tf:=e^{i\\pi\\cdot\\int\\left|f\\left(y\\right)\\right|dy}\\cdot\\left\\| f\\right\\| _{2}\\in\\mathbb{C}.", block: false)#linebreak()#text(" Here, ")#mi("\\mathbb{C}")#text(" can be regarded as an ")#mi("L^{p}")#text("-space on a singleton")#linebreak()#text(" set. For simple functions, Tf is indeed well-defined with ")#tao-math("\\left|Tf\\right|=\\left\\| f\\right\\| _{2}", block: false)#text(",")#linebreak()#text(" which implies")#linebreak()#text(" ")#tao-math("\\left|T\\left(cf\\right)\\right| = \\left\\| cf\\right\\| _{2}=\\left|c\\right|\\left\\| f\\right\\| _{2}=\\left|c\\right|\\cdot\\left|Tf\\right|", block: false)#linebreak()#text(" and")#linebreak()#text(" ")#tao-math("\\left|T\\left(f+g\\right)\\right| = \\left\\| f+g\\right\\| _{2}\\leq\\left\\| f\\right\\| _{2}+\\left\\| g\\right\\| _{2}=\\left|Tf\\right|+\\left|Tg\\right|,", block: false)#linebreak()#text(" so that T is indeed sublinear and “bounded”.")

#text("But T itself is not continuous (and thus admits no continuous extension)")#linebreak()#text(" with respect to the ")#mi("L^{2}")#text("-norm: If we take ")#mi("f:=\\chi_{\\left[0,1\\right]}")#linebreak()#text(" and ")#mi("f_{n}:=\\chi_{\\left[0,1\\right]}+\\frac{1}{n}\\chi_{\\left[10+n,10+2n\\right]}")#text(",")#linebreak()#text(" then ")#tao-math("\\left\\| f_{n}-f\\right\\| _{2}\\to0", block: false)#text(", but $Tf=e^{i\\pi}\\left\\Vert f\\right\\Vert _{2}=-1$ and ")#tao-math("Tf_{n}=e^{2\\pi i}\\left\\| f_{n}\\right\\| _{2}\\to\\left\\| f\\right\\| _{2}=1", block: false)#linebreak()#text(" for ")#mi("n\\to\\infty")#text(".")

#text("Best regards, Felix V.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/af92eec58d03a3a6901742a94e863e26d705c386dea4a4cedd29aff9cc464718-4d7c5d9d1cabb3b57e6c467647ed415825145a984b65d392832824a4c5352a2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix V.")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-452150")[#strong[#text("Felix V.")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2015")])]

#text("Oh, I just noted that you require ")#mi("Tf")#text(" to have values in ")#mi("[0,\\infty]")#text(". But you also claim that every linear operator is sublinear, which certainly does not hold if we require values in ")#mi("[0,\\infty]")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-452155")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2015")])]

#text("Sorry, there was an additional hypothesis in the definition of sublinearity (namely that ")#tao-math("\\left|Tf-Tg\\right| \\leq \\left|T(f-g)\\right|", block: false)#text(") that was not corrected in the post (though it was noted in the errata for the published version of these notes).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9d04b28c3971d5ec379d77d5a5a861fc85d7d22c15965733f5feb13fc4d69ce9-d8a4eb22cb1adadbe34f0b6efbd1a9a52b6f8000bc07281e37d3257b1566fb87.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-462408")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2015")])]

#text("Typo? In Riesz-Thorin Theorem missing parantheses around 1-\\theta?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-462821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2015")])]

#text("Dear Prof. Tao,")

#text("I guess that in Lemma 9, $p$ and $L^p(X)$ should be replaced by $p_\\theta$ and $L^{p_\\theta}(X)$, resp.")

#emph[#text("[Actually, I prefer to leave the qualitative portion of the lemma (which I presume is the part you are referring to) in terms of a ")#mi("p")#text(" parameter instead of a ")#mi("\\theta")#text(" parameter, as the latter is only useful for the quantitative estimate. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ddd06d73b6a2ec9c120e7aca6177926cd1e210a60b340a15dae474367d1658a-6531876a869c34f3d6edec5d03461ff7f4ed82ce2c1a3b4297bba072924aadea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-463466")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2015")])]

#text("About Exercise 16,")

#text("I think Exercise 16 should be corrected a little bit. If substitute t with 0 and f*(0) respectively, we might have the measure of X is infinite and ||f||_{inf}<= f*(0)")

#link("http://math.stackexchange.com/questions/257365/questions-related-to-distribution-function-and-its-inverse")[#text("http://math.stackexchange.com/questions/257365/questions-related-to-distribution-function-and-its-inverse")]

#text("In this site, altering some of the definitions and conditions makes things going well.")

#text("It would be appreciated if you check.")

#emph[#text("[The ")#mi("t=0")#text(" case should not have been present and is now deleted – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-463500")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2015")])]

#text("Dear Prof. Tao,")

#text("In Exercise 17, is p` is the dual exponent of p?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ddd06d73b6a2ec9c120e7aca6177926cd1e210a60b340a15dae474367d1658a-6531876a869c34f3d6edec5d03461ff7f4ed82ce2c1a3b4297bba072924aadea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jiwoong Jang")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-464380")[#strong[#text("Jiwoong Jang")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2015")])]

#text("Dear Prof. Tao,")

#text("In the exercise about the marcinkiewicz theorem on the Lorentz spaces, I see your point that adopting the frequency envelope b_m of a_m works, but only in the particular case of $r<=q_\\theta$. If r is large, I still do not know how to eliminate the r portion of the exponent of b_m.")

#text("Could you give me a direction to go? Or, Is it enough to prove all the things? I`m now considering the quasi-metric structure of $l^{q_\\theta/r}(\\mathbb{Z})$.")

#text("Best")#linebreak()#text(" Jang")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-469147")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#emph[#text("… from the calculus identity")#linebreak()#text(" ")#tao-math("\\displaystyle  \\left|f(x)\\right|^p = p \\int_0^\\infty 1_{\\left|f\\right| \\geq t} t^{p}\\ \\frac{dt}{t}", block: false)]

#text("and the Fubini-Tonelli theorem, we obtain the formula…")

#text("Some typo here? The left hand side is a function in ")#mi("x")#text(" while the right hand side is a number?")

#emph[#text("[The ")#tao-math("\\left|f\\right|", block: false)#text(" on the RHS should be ")#tao-math("\\left|f(x)\\right|", block: false)#text(", now fixed – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benson")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-470093")[#strong[#text("Benson")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2016")])]

#text("Dear Prof,")#linebreak()#text(" Is there any work done on application of any of the interpolation theorems to signal and image processing . I will like to know.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-473162")[#strong[#text("Lecture 9. Diffusion semigroups in L^p | Research and Lecture notes")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2016")]

#text("[…] proof of the theorem can be found in this post by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of VMT")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-474821")[#strong[#text("VMT")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#text("Hi Professor,")#linebreak()#text(" I have some little corrections to your instructive proof of Marcinkiewicz interpolation:")#linebreak()#text(" in (22) there should be only the sum over n.")#linebreak()#text(" In the last display of the proof, m should be replaced with n and ")#mi("c_{n,m}^{-q_i x_i}")#text(" with ")#mi("c_{n,m}^{-q_i}")#text(".")#linebreak()#text(" I guess one should then take ")#mi("c_{n,m}")#text(" a sufficiently small multiple of ")#tao-math("2^{-\\beta\\left|n\\alpha q_\\theta-mp_\\theta\\right|}", block: false)#text(", where ")#tao-math("\\beta:=\\frac{1}{2}\\min\\{\\left|x_0\\right|,\\left|x_1\\right|\\}", block: false)#text(".")#linebreak()#text(" Finally, there are three references to (16), (19) which should be replaced with (18), (19).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-477064")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2017")])]

#text("(1) In Section 3, what is the definition of ")#mi("L^p+L^q")#text("? Is it the same or different from the “direct sum”?")

#emph[#text("[No: see ")#link("https://en.wikipedia.org/wiki/Minkowski_addition")[#text("https://en.wikipedia.org/wiki/Minkowski_addition")]#text(" – T.]")]

#text("(2) In Stein and Weiss’s ")#emph[#text("Introduction to Fourier Analysis on Enclidean Spaces")]#text(", the linear operator ")#mi("T")#text(" in the Riesz-Thorin Theorem is defined on a set of simple functions of sets of finite measures. Are that version equivalent to the one in this note? Is there any historical reason or theoretical convenience in Stein-Weiss’s version?")

#emph[#text("[It makes little difference in practice, since a bounded linear operator on a dense subclass of a normed vector space can always be uniquely extended to a bounded linear operator on the full space. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-477084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2017")])]

#text("In remark 29 (lines 4 and 7), it seems that the constant ")#mi("C")#text(" (with several subscripts) should not contain the subscript ")#mi("C")#text(".")

#text("Is the best possible constant (as a function of its subscripts) known up to a multiplication by an absolute constant?")

#emph[#text("[Yes – I believe this is discussed for instance in Bergh and Lofstrom. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-478269")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2017")])]

#text("– Right after (6), would you elaborate what the following remark means?")

#text("The geometric series formula tells us that such factors are absolutely summable, and so in practice it is often a useful heuristic to pretend that the ")#mi("{n=O(1)}")#text(" cases dominate so strongly that the other cases can be viewed as negligible by comparison.")

#text("Do you have an example when one would like to sum the factors ")#tao-math("2^{-\\varepsilon\\left|n\\right|}", block: false)#text("?")

#text("– “However, one certainly cannot interpolate lower bounds: (i)lower bounds on a log-convex function {\\theta \\rightarrow A_\\theta} at {\\theta=0} and {\\theta=1} yield no information about the value of, say, {A_{1/2}}. (ii)Similarly, one cannot extrapolate upper bounds on log-convex functions: an upper bound on, say, {A_0} and {A_{1/2}} does not give any information about {A_1}. (However, an upper bound on {A_0} coupled with a lower bound on {A_{1/2}} gives a lower bound on {A_1}; this is the contrapositive of an interpolation statement.)”")

#text("I’m a little confused with this remark. For (i), if one looks at the log-convex function (5), then (3) means one can interpolate lower bounds?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-478400")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("See for instance the argument deriving (12) from (11) (here we use a continuous variable ")#mi("t")#text(" instead of a discrete one ")#mi("2^n")#text(", but the principle is the same. See also the proof of Theorem 27.)")

#text("The function ")#mi("\\theta \\mapsto B_\\theta")#text(" in (5) is log-convex as well as log-concave, which is why one can interpolate lower bounds for that function. However, most log-concave functions will not be log-convex.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-478280")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2017")])]

#text("In the second proof Lemma 9, one can divide ")#mi("f")#text(" by its ")#mi("L^{p_0}")#text(" or ")#mi("L^{p_1}")#text(" norm to achieve one of the normalizations. How can one do it simultaneously for both? Why is the measure ")#mi("\\mu")#text(" also allowed to change?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-478401")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("If ")#mi("(X, {\\mathcal X}, \\mu)")#text(" is a measure space, then so is ")#mi("(X, {\\mathcal X}, c\\mu)")#text(" for any ")#mi("c>0")#text(". It is then a simple matter of algebra to find, given any measure space ")#mi("(X, {\\mathcal X}, \\mu)")#text(" and any ")#mi("f")#text(" in both ")#mi("L^{p_0}")#text(" and ")#mi("L^{p_1}")#text(" of that space, constants ")#mi("c_1, c_2")#text(" such that ")#tao-math("\\left\\|c_1 f \\right\\|_{L^{p_0}( X, {\\mathcal X}, c_2 \\mu)} = \\left\\|c_1 f \\right\\|_{L^{p_1}( X, {\\mathcal X}, c_2 \\mu)} = 1", block: false)#text(". If we know how to prove Lemma 9 in this case, a little further algebra then recovers Lemma 9 in the general case.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-478350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2017")])]

#text("In the third proof of Lemma 9, typos in the tensor power:")

#text("The component x_m should be x_M and the underlying measure space for the tensor power should be X^M")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-478407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 February 2017")])]

#text("One more in")

#text("we see from many applications of the Fubini-Tonelli theorem that")

#tao-math("\\displaystyle  \\left\\| f^{\\otimes M} \\right\\|_{L^p(X)} = \\left\\|f\\right\\|_{L^p(X)}^M", block: false)

#text("the left hand side should be")

#tao-math("\\displaystyle \\left\\| f^{\\otimes M} \\right\\|_{L^p(X^M)}", block: false)

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-478906")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 March 2017")])]

#text("In the set of your notes (")#link("http://www.math.ucla.edu/~tao/247a.1.06f/notes1.pdf")[#text("http://www.math.ucla.edu/~tao/247a.1.06f/notes1.pdf")]#text(") on harmonic analysis, the first sentence of the introduction to the Vinogradov notation is very confusing (page 5):")

#text("In (modified) Vinogradov notation, the notation ")#mi("X\\lesssim Y")#text(" (read: ")#mi("X")#text(" is less than or")#linebreak()#text(" comparable to ")#mi("Y")#text(" ) or ")#mi("Y\\lesssim X")#text(" is used synonymously with ")#tao-math("\\left|X\\right| \\leq CY", block: false)#text(" or ")#mi("X = O(Y)")#text(".")

#text("I think you mean")

#tao-math("\\left|X\\right|\\lesssim Y", block: false)#text(" (resp. ")#mi("X\\lesssim Y")#text(") is used synonymously with")#linebreak()#text(" ")#tao-math("\\left|X\\right| \\leq CY", block: false)#text(" or ")#mi("X = O(Y)")

#text("just as indicated in this post?")

#emph[#text("[Correction added to 247a page, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("In the first proof of Lemma 9, Hölder is used. It is said in your 247a notes 1 that Lemma 9 actually implies Hölder also.")

#text("The hint there says that one should consider the convexity of ")#tao-math("\\left|f\\right|^\\alpha\\left|g\\right|^\\beta", block: false)#text(" with respect to a measure ")#tao-math("\\left|f\\right|^\\gamma\\left|g\\right|^\\delta\\mu", block: false)#text(" for some constants ")#mi("\\alpha,\\beta,\\gamma,\\delta")#text(".")

#text("I don’t understand what this really means. Would you elaborate a little bit more?")

#emph[#text("[Apply Lemma 9 with ")#mi("f")#text(" replaced by ")#tao-math("\\left|f\\right|^\\alpha \\left|g\\right|^\\beta", block: false)#text(" and ")#mi("\\mu")#text(" replaced by ")#tao-math("\\left|f\\right|^\\gamma \\left|g\\right|^\\delta \\mu", block: false)#text(", and for a carefully selected choice of ")#mi("p_0, p_1, \\theta, \\alpha, \\beta, \\gamma, \\delta")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2017")])]

#text("1. Suppose one wants to prove the Holder ")#tao-math("\\left\\|fg\\right\\|_{r}\\leq\\left\\|f\\right\\|_p\\left\\|g\\right\\|_q", block: false)#text(" with ")#mi("\\frac{1}{p}+\\frac{1}{q}=\\frac{1}{r}")#text(". Suppose in Lemma 9, ")#tao-math("\\left\\|f\\right\\|_r\\leq\\left\\|f\\right\\|_{p^{\\prime}}^{1-t}\\left\\|g\\right\\|_{q^{\\prime}}^t", block: false)#text(" with ")#mi("\\frac{1}{r}=\\frac{1-t}{p^{\\prime}}+\\frac{t}{q^{\\prime}}")#text(". One can then choose any ")#mi("0<t<1")#text(" with ")#mi("t(p+q)\\neq p")#text(", then let")#linebreak()#text(" ")#mi("\\displaystyle p^{\\prime}=p(1-t),\\quad q^{\\prime}=qt")#linebreak()#text(" and")#linebreak()#text(" ")#mi("\\displaystyle \\alpha=\\frac{r}{r-q^{\\prime}t},\\quad \\beta=\\frac{r}{r-p^{\\prime}(1-t)}")

#mi("\\displaystyle \\delta=-\\beta p^{\\prime},\\quad\\gamma=-\\alpha q^{\\prime}")#text(".")

#text("The constants do not need to be unique, right?")

#text("2. It is said in the hint that one needs to first reduce to the case of finite measure space and ")#mi("f")#text(" and ")#mi("g")#text(" everywhere non-vanishing simple functions. Why is that so? It seems that one can get the proof by directly manipulate the constants so that one can match the exponents of the two inequalities (Holder and the log-convexity).")

#emph[#text("[One needs various ")#mi("L^p")#text(" norms to be finite and non-zero in order to justify some algebraic manipulations, such as raising these norms to a negative power. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-488930")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2017")])]

#text("Why can one replace ")#mi("\\mu")#text(" by ")#tao-math("\\left|f\\right|^\\gamma\\left|g\\right|^\\delta\\mu", block: false)#text(" in Lemma 9? Isn’t Lemma 9 only true when one replace ")#mi("\\mu")#text(" by ")#mi("c\\mu")#text(" where ")#mi("c")#text(" is a (nonnegative) constant?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489221")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2017")])]

#text("Lemma 9 is true for arbitrary non-negative measures ")#mi("\\mu")#text(", which gives one the (powerful) freedom to multiply ")#mi("\\mu")#text(" by arbitrary non-negative weights, not just constants.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-488932")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2017")])]

#text("I attempted what was suggested directly:")

#tao-math("\\displaystyle  (\\int \\left|f\\right|^{\\alpha r}\\left|g\\right|^{\\beta r}\\left|f\\right|^\\gamma\\left|g\\right|^\\delta\\ d\\mu)^{1/r}\\\\ \\leq (\\int \\left|f\\right|^{\\alpha p}\\left|g\\right|^{\\beta p}\\left|f\\right|^\\gamma\\left|g\\right|^\\delta\\ d\\mu)^{(1-\\theta)/p}\\\\ (\\int \\left|f\\right|^{\\alpha q}\\left|g\\right|^{\\beta q}\\left|f\\right|^\\gamma\\left|g\\right|^\\delta\\ d\\mu)^{\\theta/q}", block: false)#linebreak()#text(" which seems not quite true…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2017")])]

#text("This is a correct inequality. One now has to select the parameters carefully to obtain the desired conclusion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2017")])]

#text("Suppose one wants to prove Hölder for ")#mi("(r,p,q)")#text(". Assume the log-convexity for ")#mi("(r^{\\prime},p^{\\prime},q^{\\prime},\\theta)")#text(". Apply Lemma 9 with ")#mi("f")#text(" replaced by ")#tao-math("\\left|f\\right|^\\alpha \\left|g\\right|^\\beta", block: false)#text(" and ")#mi("d\\mu")#text(" replaced by ")#tao-math("\\left|f\\right|^\\gamma \\left|g\\right|^\\delta d\\mu", block: false)#text(". Comparing the exponents, we want")#linebreak()#text(" ")#mi("\\displaystyle \\alpha r^{\\prime}+\\gamma = r,\\quad \\beta r^{\\prime}+\\delta = r\\\\ \\beta p^{\\prime}+\\delta = 0,\\quad \\alpha p^{\\prime}+\\gamma = p\\\\ \\alpha q^{\\prime}+\\gamma = 0,\\quad \\beta q^{\\prime}+\\delta = q\\\\ \\frac{1-\\theta}{p^{\\prime}}=\\frac{1}{p},\\quad \\frac{\\theta}{q^{\\prime}}=\\frac{1}{q}")

#text("So if we let ")#mi("\\theta\\in(0,1)")#text(" such that ")#mi("\\theta(p+q)\\neq p")#text(" and")#linebreak()#text(" ")#mi("\\displaystyle r^{\\prime}=r,\\ \\ p^{\\prime}=(1-\\theta)p,\\ \\ q^{\\prime}=\\theta q\\\\ \\alpha = \\frac{p}{[(1-\\theta)p-\\theta q]}\\\\ \\beta = \\frac{q}{\\theta q-(1-\\theta)p}\\\\ \\delta = -\\beta p^{\\prime}\\\\ \\gamma = -\\alpha q^{\\prime}")#linebreak()#text(" then we have the desired result.")

#text("Where one needs to first reduce to the case of finite measure space and f and g everywhere non-vanishing simple functions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489224")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2017")])]

#text("If some of the exponents ")#mi("\\alpha,\\beta,\\gamma,\\delta")#text(" are negative, you will have a division by zero problem if one did not prepare in advance by reducing to the case when ")#mi("f,g")#text(" were everywhere non-vanishing.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479032")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("In 247a notes 1 Problem 5.9, it is said that one can differentiate ")#tao-math("\\log\\left\\|f\\right\\|_p", block: false)#text(" twice with respect to ")#mi("\\alpha:=1/p")#text(" to get the log convexity of the ")#mi("L^p")#text(" norm. Why should one use ")#mi("1/p")#text(" instead of ")#mi("p")#text("?")

#emph[#text("[The function ")#tao-math("1/p \\to \\log \\left\\|f\\right\\|_p", block: false)#text(" is convex, but the function ")#tao-math("p \\mapsto \\log \\left\\|f\\right\\|_p", block: false)#text(" is usually not convex. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479034")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2017")])]

#text("As it is mentioned in the notes, this approach is messy. Has anyone performed the calculation ever to show that this is indeed doable? (Lots of terms would appear when calculating the second derivative. Still possible to see that the second derivative is positive?)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2017")])]

#text("Another version of (7) in Theorem is given in the 247a notes 1:")

#tao-math("\\displaystyle \\left|f(z)\\right|\\leq C_1 e^{C_2\\exp[(\\pi-\\delta)\\left|z\\right|]}", block: false)

#text("Are these two versions equivalent? (Since it could be that ")#mi("\\pi-\\delta<0")#text(" and a positive constant is missing in front of the \"inner\" exponential function in (7), I'm not sure about this.)")

#emph[#text("[Yes, they are equivalent. Note that one has the freedom to reduce ")#mi("\\delta")#text(" if desired, in particular one can assume that ")#mi("\\pi - \\delta")#text(" is positive. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479091")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2017")])]

#text("According to this set of notes")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2016/09/22/246a-notes-1-complex-differentiation/")[#text("246A, Notes 1: complex differentiation")]
]

#text("holomorphic functions are defined on open subsets of ")#mi("{\\bf C}")#text(". What does the function ")#mi("f")#text(" being holomorphic on the strip ")#mi("S")#text(" (which is closed) mean? (What does one mean that ")#mi("f")#text(" is holomorphic on the boundary?)")

#emph[#text("[It means that the function extends to be holomorphic on some open neighbourhood of the strip. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479093")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 March 2017")])]

#text("In the proof of Theorem 4, would you elaborate why is the function ")#mi("h(s):=s\\mapsto B_0^{1-s}B_1^s")#text(" holomorphic and non-zero on ")#mi("S")#text("?")

#text("Isn’t it true that one needs to define ")#mi("h")#text(" using the complex logarithm, which is not holomorphic at ")#mi("z=0")#text("? Moreover, what branch one needs to use for the function ")#mi("h")#text("?")

#emph[#text("[One only needs to take logarithms of the positive real constants ")#mi("B_0, B_1")#text("; at no point does one need to take logarithms of the complex variable ")#mi("s")#text(". -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479160")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 March 2017")])]

#text("In the last step of passage to the limit of Theorem 21 (Riesz-Thorin theorem), one decomposes ")#mi("{f}")#text(" into a bounded function and a function of finite measure support and then approximates each piece by simple functions. How would one put the two approximations together to get the approximation for ")#mi("f")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479178")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2017")])]

#text("In Lemma 9 and Theorem 21; the exponents ")#mi("p_i")#text(" are in ")#mi("[0,\\infty]")#text(" while the ")#mi("q_i")#text(" are in ")#mi("[1,\\infty]")#text(". Can we change the range for ")#mi("q_i")#text(" to be also in ")#mi("[0,\\infty]")#text("? (Or is there a typo so that the ")#mi("p_i")#text(" should also in ")#mi("[1,\\infty]")#text("?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479179")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2017")])]

#text("It is said at the beginning of section 3 that “much of the theory here extends to the non-")#mi("{\\sigma}")#text("-finite setting.”")

#text("Is the ")#mi("\\sigma")#text("-finite assumption implicitly used somewhere in the proof of Theorem 21? (Or is the theorem true in the non-")#mi("{\\sigma}")#text("-finite setting?)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479191")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2017")])]

#text("In Lemma 9, what norm should one use for the space ")#mi("L^{p_0}(X)\\cap L^{p_1}(X)")#text("?")

#text("In Theorem 21, what norm should one use for the Minkowski sums ")#mi("L^{p_0}+L^{p_1}")#text(" and ")#mi("L^{q_0}+L^{q_1}")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479258")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("I don’t believe I using a norm for these spaces anywhere in my text, but the standard norm on the intersection ")#mi("X \\cap Y")#text(" of two normed vector spaces is defined as ")#tao-math("\\left\\|f\\right\\|_{X \\cap Y} := \\max( \\left\\|f\\right\\|_X, \\left\\|f\\right\\|_Y )", block: false)#text(" (one can also use the equivalent norm ")#tao-math("\\left\\|f\\right\\|_X + \\left\\|f\\right\\|_Y", block: false)#text("), and the standard norm on the sum ")#mi("X+Y")#text(" is ")#tao-math("\\left\\|f\\right\\|_{X+Y} := \\inf( \\left\\|f_1\\right\\|_X + \\left\\|f_2\\right\\|_Y: f=f_1+f_2, f_1 \\in X, f_2 \\in Y \\}", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-479195")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2017")])]

#text("In the definition of the distribution function, several other books (e.g. Folland) use ")#mi(">")#text(" instead of ")#mi("\\geq")#text(" in the formula")

#tao-math("\\displaystyle  \\lambda_f(t) := \\mu ( \\{ x \\in X: \\left|f(x)\\right| \\geq t \\} ) = \\int_X 1_{\\left|f\\right| \\geq t}\\ d\\mu", block: false)

#text("In practice of doing analysis (in the case that ")#tao-math("\\mu ( \\{ x \\in X: \\left|f(x)\\right| = t \\} ) > 0", block: false)#text("), how much difference would this make? For instance, would it affect the proof of Mincinkiewicz interpolation theorem?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("Instead of being right-continuous, one gets ")#mi("\\lambda_f")#text(" being left-continuous here. That’s the only difference I think. In practice, may be not a big deal.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jack")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489554")[#strong[#text("jack")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("It is said in Wikipedia (")#link("https://en.wikipedia.org/wiki/Lorentz_space")[#text("https://en.wikipedia.org/wiki/Lorentz_space")]#text(") that the Lorentz space norm ")#tao-math("{\\left\\|f\\right\\|_{L^{1,\\infty }}}", block: false)#text(" with ")#tao-math("{f(x)=\\left|x-1\\right|^{-1}}", block: false)#text(" is the area of the largest rectangle with sides parallel to the coordinate axes that can be inscribed in the graph.")

#text("However, direct calculation shows that the area of any inscribed rectangle is")#linebreak()#text(" ")#tao-math("\\displaystyle \\frac{(2-x)-x}{\\left|1-x\\right|}=2,\\quad x\\in(-\\infty, 1).", block: false)

#text("What goes wrong? Can it be explained by Exercise 13?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489556")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("The Lorentz norm of an indicator function can be calculated easily. But when it goes to general functions, even just simple functions, the calculation becomes much more difficult. What is this norm really about?")

#text("Maybe its property such as ")#mi("L(p,q_1)\\subset L(p,q_2)")#text(" is more important than what it really is?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-489570")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2017")])]

#text("Yes, the Lorentz space norm of this function is equal to ")#mi("2")#text(". As it turns out the dyadic Lorentz space norm is also equal to ")#mi("2")#text(". (In general, the two expressions will be comparable, but not identical.) I find the dyadic norm to be a bit more tractable in computations (for instance it is easy to compute for linear combinations of a few indicator functions, particularly if the sets involved are disjoint and the coefficients are lacunary).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-490028")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("In Stein-Weiss, the following inequality is used for the proof of ")#mi("L(p,q_1)\\subset L(p,q_2)")#text(" (")#mi("1\\leq p<\\infty")#text(" and ")#mi("1\\leq q_1\\leq q_2<\\infty")#text("):")

#mi("\\displaystyle \\left(\\sum_{k=-\\infty}^{\\infty} [f^*(2^{k-1})]^{q_2}\\int_{2^k-1}^{2^k}t^{(q_2/p)-1}\\ dt\\right)^{q_1/q_2} \\leq B^{\\prime} \\sum_{k=-\\infty}^{\\infty}[f^*(2^{k-1})]^{q_1}2^{kq_1/p_2}")

#text("How is this inequality done?")

#emph[#text("[Upper bound the integral, and then use the monotonicity of ")#mi("\\ell^q")#text(" norms. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-490056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2017")])]

#text("Using the monotonicity of ")#mi("\\ell^q")#text(" norms, one has")#linebreak()#text(" ")#mi("\\displaystyle  \\left(\\sum_{k=-\\infty}^{\\infty} [f^*(2^{k-1})]^{q_2}2^{kq_2/p}\\right)^{q_1/q_2} \\leq \\sum_{k=-\\infty}^{\\infty} [f^*(2^{k-1})]^{q_1}2^{kq_1/p}")#linebreak()#text(" It seems that one cannot get the exponent in ")#mi("2^{kq_1/p}")#text(" right.")

#text("Rewriting the RHS as")#linebreak()#text(" ")#mi("\\displaystyle \\sum_{k=-\\infty}^{\\infty} [f^*(2^{k-1})]^{q_1}2^{kq_1/q_2}(2^{kq_1/p-kq_1/q_2})")#linebreak()#text(" what ")#mi("B^{\\prime}")#text(" should one use?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-490107")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2017")])]

#text("If in Stein-Weiss, ")#mi("p_2")#text(" is a typo which should be ")#mi("p")#text(", then the first inequality here has already given the conclusion.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-491840")[#strong[#text("Prove $L^{p_theta }(X)subset L^{p_0}(X)+L^{p_1}(X),$ where $frac{1}{p_theta }:=frac{1-theta }{p_0}+frac{theta }{p_1}.$ | Questions")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2018")]

#text("[…] 245C, Notes 1: Interpolation of L^p spaces […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093f42428c5178c855bd751694e5f1c74335a14073b5c2669c9b8c102cf7ceba-08750b13ea407ac9e3276cb67a5579f080a488735539017981d5b858e11ae4ca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-553116")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("Dear Professor Tao. I have a question regarding the weak ")#mi("L^{p,\\infty}")#text(" spaces. Assume that ")#mi("X = \\cup X_n")#text(", where the sets ")#mi("X_n")#text(" are disjoints, and ")#mi("1<p<\\infty")#text(". Is it true that")

#tao-math("\\displaystyle \\sum_{n = 1}^{n=N} \\left\\| f \\right\\|^p_{L^{p,\\infty}(X_n)} \\leq C \\left\\| f \\right\\|^p_{L^{p,\\infty}(X)}", block: false)

#text("with a constant independent of ")#mi("N")#text("?")

#text("Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-553121")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2020")])]

#text("No. Consider the case when ")#mi("X = \\{1,\\dots,N\\}")#text(" with counting measure and ")#mi("X_n = \\{n\\}")#text("; then the estimate would be claiming that the ")#mi("\\ell^p(X)")#text(" norm is controlled by the ")#mi("\\ell^{p,\\infty}(X)")#text(" norm uniformly in ")#mi("N")#text(", which is false.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-609277")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2020")])]

#text("In exercise 14, ")#tao-math("(1+log\\left|X\\right|)", block: false)#text(" should be ")#tao-math("(1+log\\left|X\\right|)^{1/p}", block: false)#text(" instead? there is a similar problem here:")#link("https://math.stackexchange.com/questions/762622/inequality-of-strong-lp-and-weak-lp-norm-on-a-finite-set-with-counting-mea")[#text("https://math.stackexchange.com/questions/762622/inequality-of-strong-lp-and-weak-lp-norm-on-a-finite-set-with-counting-mea")]

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-609883")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("Dear Prof.Tao:")#linebreak()#text(" How to continuously extend a linear continuous operator on the subspace of $L^\\infty$ to $L^\\infty$?")#linebreak()#text(" Given any subspace $S$ of $L^\\infty$, and $T$ is linear continuous operator on $S$ into some Banach space $B$, is there any general method to extend from $S$ to $L^\\infty$ in linear continuous manner?")#linebreak()#text(" In this post, it is said that we can maybe non-uniquely extend from the space of simple measurable with finite measure support to $L^\\infty$ in a linear continuous manner, how to do this, any hint? I am stuck in this problem, thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-609940")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("Both existence and uniqueness are problematic in general. If one of the ")#mi("L^\\infty")#text(" spaces involves a finite measure then it becomes a complete Banach lattice and the usual proof of Hahn-Banach goes through to give existence of an extension, and sigma-finite measures might still be OK, but I think general measures are not. (There is a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=45940")[#text("theorem of Kelley")]#text(" that says that a Hahn-Banach type extension theorem for a Banach space target ")#mi("Y")#text(" is possible if and only if ")#mi("Y")#text(" is isomorphic to the space of continuous functions on a Stonean space, which when applied to ")#mi("L^\\infty")#text(" using Gelfand duality I think comes down to requiring the underlying measure algebra to be complete, which is true when the measure is finite or sigma-finite but I believe there are counterexamples in general.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-610027")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("Is it possible to extend the interpolation theorem with restricted weak-type bounds for operators defined on mixed L^p(L^q) spaces?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-610057")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2020")])]

#text("Partially, but the more detailed answer is rather complicated; see for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=482127")[#text("this paper of Fernandez")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5935711814e65809c044b8f80497e2700e1bd9192b296cab7ba09e415d6456b-7b23d2dc3efe445dabebd78dd516d52044711560e13c66af98874caedac41396.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gerd Wachsmuth")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-631576")[#strong[#text("Gerd Wachsmuth")]]#text(size: 9pt, fill: rgb("596477"), " · 21 July 2021")])]

#text("In Exercise 34, I think one needs ")#mi("p \\le q")#text(" for the estimate of ")#mi("T_1 \\otimes T_2")#text(", see also ")#link("https://mathoverflow.net/questions/336970/the-norm-of-tensor-product-operator-on-lp-spaces")[#text("https://mathoverflow.net/questions/336970/the-norm-of-tensor-product-operator-on-lp-spaces")]#text(".")

#text("Otherwise, it would be possible to deduce the Riesz-Thorin interpolation theorem in the real case with constant $1$ only under the requirement $p_\\theta \\le q_\\theta$ via Marcinkiewicz (or without any requirement via the complex Riesz-Thorin theorem). This, however, is not true, see, e.g., ")#link("https://link.springer.com/article/10.1007/s000130050241")[#text("https://link.springer.com/article/10.1007/s000130050241")]#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-644710")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2022")])]

#text("Dear Prof. Tao,")#linebreak()#text(" Is it possible to prove the continuous embeddings of L^\\infty(L^2)\\capL^2(H^1) in L^{4,1}(H^{1/2}) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-644997")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2022")])]

#text("No, there is no such embedding. Consider a function of the form ")#mi("\\sum_{n=1}^\\infty n^{-2/3} 1_{I_n}(t) \\psi_n(x)")#text(", where ")#mi("\\psi_n")#text(" is a function of frequency ")#mi("2^n")#text(" normalised in ")#mi("L^2")#text(" (so that its ")#mi("H^{1/2}")#text(" norm is like ")#mi("2^{n/2}")#text(" and its ")#mi("H^1")#text(" norm is like ")#mi("2^n")#text(") and the ")#mi("I_n")#text(" are disjoint time intervals of length ")#mi("2^{-2n}")#text(". Then one can check that this function is bounded in ")#mi("L^\\infty(L^2)")#text(" and ")#mi("L^2(H^1)")#text(" but not ")#mi("L^{4,1}(H^{1/2})")#text(". (More generally, one should experiment with various combinations of rescaled and translated bump functions in order to gain intuition as to whether a given interpolation inequality might be true.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-646112")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2022")])]

#text("Dear prof. Tao,")#linebreak()#text(" I read the Riesz Thorin interpolation for vector valued.(For explanation, if i want to get l2 sum of Lp norm, Enough to check sup of L2 and l1 sum of Lq norm) But, Vector valued version RT interpolation that I read has the assumption that the operator T is a linear operator. In the proof, Linearity is needed, when proceeding approximation argument. is it possible to use Vector valued Risez thorin Interpolation theorem for sublinear case?(not marcinkiewicz interpolation for vector valued. It does not interpolate the norm of valued) Would you recommend the refer for this sub linear version of proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-649105")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2022")])]

#text("No. Riesz Thorin interpolation only works for linear operators, while Marcinkiewicz interpolation also works for sublinear operators.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-649113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2022")])]

#text("Thanks for replying!")#linebreak()#text(" In page 464 of Harmonic Analysis: Real-Variable Methods, Orthogonality, and Oscillatory Integrals by Stein, I read the middle part of this page using interpolation for sublinear operator. Would you please tell me the interpolation statement they use?")#linebreak()#text(" At first, I think, this is the interpolation which is in page 399 problem 5.5.2 of Classical Fourier Analysis by L.Grafakos.")#linebreak()#text(" But in here, we need the linearity assumption. You may recommend a reference paper or book for this interpolation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-649564")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2022")])]

#text("Stein’s book refers to Lorentz spaces interpolation of mixed norms. Dr. Tao mentioned a paper by Fernandez in one of the comments, and the URL is:")

#link("https://core.ac.uk/download/pdf/81999059.pdf")[#text("Click to access 81999059.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-649565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2022")])]

#text("Proposition 9.1 on page 143.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-687164")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2025")])]

#text("By definition the weak Lp norm of a function f is dominated by its Lp norm. Since the weak Lp norm is supposed to describe something that the Lp norm misses, what is the intuition for a smaller weak Lp norm function vs a larger weak Lp norm function, given that they have the same Lp norms?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-687169")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 February 2025")])]

#text("If the ")#mi("L^p")#text(" norm is kept fixed, then the weak ")#mi("L^p")#text(" norm is maximized when the ")#mi("L^p")#text(" norm is primarily coming from a single scale, and is conversely small when the ")#mi("L^p")#text(" “energy” is “dispersed” among many scales. It may be instructive to work with the explicit functions ")#mi("x \\mapsto A 1_{1 < x < R} x^{-1/p}")#text(" for some ")#mi("R>1")#text(" and ")#mi("A>0")#text(", and compute both the ")#mi("L^p")#text(" and weak ")#mi("L^p")#text(" norms, to get some intuition.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of J")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-687166")[#strong[#text("J")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2025")])]

#text("Follow-up to my earlier question for clarification: By definition, the weak L^p norm of a function f is always smaller than or equal to its L^p norm. Since the weak L^p norm is supposed to capture something the L^p norm misses, what intuition can we develop about a function with a smaller weak L^p norm compared to one with a larger weak L^p norm, assuming both functions have the same L^p norm?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-688752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2025")])]

#text("In Ex. 8 (Phragmén-Lindelöf), a better auxiliary function to use might be an exponential with something with $frac{1}{2} log(2 – z^2)$, say (instead of $log(- i z)$). The change is very slight and the hinted proof still goes through, but this allows one to handle all $t in mathbb{R}$ at once, without having to truncate to $t geq R gg 1$ or consider separate signs. It also improves the implicit constant, in a sense: there is no dependence on $A$ or $delta$ from the growth condition on $f$, though there _is_ now some dependence on the $a_i$.")

#text("(I recently had to run a complex interpolation, and the initial estimate of $A$ in the strip was quite bad, blowing up with respect to another parameter, so it was important to get constants uniform in the _a priori_ growth of $f$.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-2/#comment-688817")[#strong[#text("Complex Interpolation in Sobolev Spaces – (In)Complete Thoughts")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2025")]

#text("[…] on our holomorphic function; for this reason, the result outlined in Tao’s notes (Exercise 8, here) was not suitable for our purposes, as the stated constant really depends on the size condition. (I […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37582")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("Following up on an old comment: ")#link("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-33400")[#text("https://terrytao.wordpress.com/2007/05/10/open-question-boundedness-of-the-trilinear-hilbert-transform/#comment-33400")]

#text("I have often wondered if there is a counterexample to a multilinear interpolation statement of the following form. If T(f,g) is a multilinear operator given by convolution with an appropriate kernel (where we have the bilinear Hilbert Transform in mind as an example) such that T(f,1) and T(1,g) are bounded linear operators (say from L^p to L^p, for a range of p’s), then T(f,g) satisfies some Holder-type multilinear bounds (after ruling out degenerate cases such as $\\int f(x+t)g(x+t)/t$). At a high level my question is, should all of these multilinear results people have been working on lately really follow from some multilinear interpolation theorem that hasn’t been found yet?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37592")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("fyi, example 2, 10 are displaying errors. ")#emph[#text("[Fixed – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d655f257a1ba7d52f0759075d02c9a0b4ba20dcf68eca59cbc40ae6e070226bc-8b503f9f58f230e16536bf4d79b60b0fd22758b8d197669d4fea7da6c96cc391.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The discussion of Real Analysis:1 « Liu Xiaochuan’s Weblog")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37622")[#strong[#text("The discussion of Real Analysis:1 « Liu Xiaochuan’s Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2009")])]

#text("[…] title of this post is:’Interpolation of L^p spaces‘, of which I have no idea at all before […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37653")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("Dear Anon,")

#text("Well, it’s easy to cook up bilinear operators T(f,g) which actually vanish when f=1 or g=1, but are non-trivial otherwise (e.g. let’s work on a compact domain such as the circle, and consider the product of the mean zero version ")#mi("f - \\int f")#text(" of f with the mean zero version of g), so it is quite unlikely that one can get much control on a general T(f,g) out of knowledge of T(f,1) and T(1,g) for various f, g.")

#text("This is in contrast to the linear setting, where we of course have the T(1) theorem. The difference there is that if one looks at the bilinear form ")#mi("\\langle Tf, g \\rangle")#text(" for a Calderon-Zygmund operator T and starts decomposing it into various components, one soon sees that the dominant components either come from the terms where g is localised and f is slowly varying (and can thus be modeled to some extent by a multiple of 1), or when f is localised and g is slowly varying, or when f and g are both localised and bounded to the same interval. These three cases can be handled by an appropriate hypothesis on T(1), an appropriate hypothesis on ")#mi("T^*(1)")#text(", and a weak boundedness hypothesis respectively.")

#text("For the bilinear Hilbert transform, we have the frequency modulation invariance which dethrones the privileged nature of the function 1. Instead, a more reasonable hypothesis would be to assume control of things like ")#mi("T( f, e^{i \\xi x} )")#text(" and ")#mi("T( e^{i \\xi x}, g )")#text(" for arbitrary frequencies ")#mi("\\xi")#text(" (and one also needs to consider the adjoint expression ")#mi("\\langle T(f,g), e^{i \\xi x} \\rangle")#text("). In some ways, one can view the existing proofs of the boundedness of the bilinear Hilbert transform as a reduction to these model cases; the general trilinear form ")#mi("\\langle T(f,g), h \\rangle")#text(" is decomposed into many components, which are then reassembled into “trees” in phase space, each of which can be estimated by a paraproduct analysis resembling that needed to understand (variants) of expressions such as ")#mi("\\langle T(f,g), e^{i \\xi x} \\rangle")#text(". So the “divide and conquer” philosophy underlying real interpolation is still very much present in the proofs, even if they don’t show up on the level of formal interpolation theorems. (This tends to be typical with any advanced form of harmonic analysis; the general philosophies are common to many problems, but are difficult to formalise as a universal lemma or other abstract tool; instead, each individual operator or expression needs to be manged “by hand”.)")

#text("On the other hand, I could well imagine that the abstract combinatorics of collecting tiles into trees, trees into forests, and then summing up over forests could be formalised into some sort of interpolation result concerning L^p-like norms of sequences of numbers indexed by tiles. This could perhaps provide a unifying framework for many of the bilinear Hilbert transform-like results out there in the literature.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anon2")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37702")[#strong[#text("anon2")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("I believe the statement of Lindelöf’s theorem (theorem 1) in equation (7) has some typos.")

#text("Also, I think the sentence beginning “Thus we see that (3) is only sharp when…” has a few typos that make it a bit confusing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37704")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("in the definition of distribution function the image may be infinity. Why do we take ")#mi("R_{+}")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2009")])]

#text("in lemma 5, in the second condition is it ")#mi("p^{\\prime}_1")#text(" or ")#mi("p_1")#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37724")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("Thanks for the corrections! (But I believe the exponent in Lemma 5 is indeed ")#mi("p^{\\prime}_1")#text(" as stated.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37729")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("Thanks I was not sure I just wanted to check it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2009")])]

#text("In second paragraph of the proof of Theorem 1, it seems the limit is ")#mi("f(\\sigma+it) \\rightarrow 0")#text(". ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37777")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("Dear Professor Tao:")

#text("I got stuck in Exercise 4. Are you sure the mutiplier in the hint is correct?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37780")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("Dear Liuxiaochuan: Ah, yes. For that multiplier to work, one has to apply a Lindelof-type theorem to a half-strip rather than a strip. (It is possible to work on the strip directly, but one has to use a more sophisticated multiplier.) I’ve adjusted the hint accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37806")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" I still have soubts about exercise 4. I am wondering if the multiplier should be ")#mi("{\\exp( - ((1-z)a_0+z a_1) \\log(-i-z) )}")#text(" for upper half strip, instead of ")#mi("\\log(-iz)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37820")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("Dear Liuxiaochuan,")

#text("I think the multiplier is correct as it stands. One needs the imaginary part of the logarithmic factor to decay like O(1/t) so as not to create an exponential term in the magnitude of the multiplier. With ")#mi("\\log(-i-z)")#text(", the imaginary part is close to ")#mi("-\\pi/2")#text(" (or ")#mi("3\\pi/2")#text(", etc. depending on what branch of the logarithm one takes), and this will lead the multiplier growing or decaying exponentially in t (depending on what ")#mi("a_0")#text(" and ")#mi("a_1")#text(" are).")

#text("One can take ")#mi("\\log(-i-iz)")#text(" instead of ")#mi("\\log(-iz)")#text(" if one is worried about the pole at the origin, but if one is working in a sufficiently high half-strip, this is pole is not a problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37841")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2009")])]

#text("Dear Professor:")

#text("Thank you so much, I finally got this exercise! ha!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37874")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("Dear Prof. Tao,")

#text("There seems some problem for the choices of ")#mi("s")#text(" above excercise 5. I guess the first ")#mi("s")#text(" is ")#mi("s=it")#text(". I was wondering if you could help to explain a little or give a hint about the motivation of using Lorentz space. Is it related to the Lorentz transform in the special relativity? The Lorentz space seems related to Besov space (I tried to find some explanation on wiki, unfortunately it only gives a very brief definition.)")

#text("Thanks a lot in avdance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37875")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2009")])]

#text("Thanks for the correction! Lorentz spaces were created by the mathematician George Lorentz, who I believe is unrelated to the physicist Hendrik Lorentz of Lorentz transformation fame.")

#text("Lorentz spaces are a “logarithmic” refinement of the Lebesgue spaces that can help discern finer integrability properties of a function. For instance, consider a function f on [0,1] of the form ")#tao-math("f(x) = \\left|x\\right|^{-a} \\log^{-b}(x)", block: false)#text(". Knowing which ")#mi("L^p")#text(" spaces f belongs to tells you what a is, but not what b is; but knowing what ")#mi("L^{p,q}")#text(" spaces f lies in reveals both indices. (The same, incidentally, is true for the Besov space norms, although the additional exponent in the Besov space definition measures distribution in dyadic frequency ranges ")#tao-math("\\left|\\xi\\right| \\sim 2^n", block: false)#text(", rather than distribution in magnitudes ")#tao-math("\\left|f\\right| \\sim 2^n", block: false)#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254C, Notes 2: The Fourier transform « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-37982")[#strong[#text("254C, Notes 2: The Fourier transform « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("[…] Young’s inequality (Exercise 25 of Notes 1) we know that is defined a.e., and lies in ; indeed, we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758f78bdc69374a138e14ceeda93836fe67ee98b33063997a5d1536e927a6a7b-f32ad8715309a76f5b93bdfcc1fd214f5cf8e03a4e7bdbab14e6aeaa778ef957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samir")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38068")[#strong[#text("Samir")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2009")])]

#text("Dear Professor Tao,")

#text("Do you think you could provide a little advice for exercise 2? I’m surprisingly having more trouble with that than some of the later ones! Thanks!")

#text("Samir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758f78bdc69374a138e14ceeda93836fe67ee98b33063997a5d1536e927a6a7b-f32ad8715309a76f5b93bdfcc1fd214f5cf8e03a4e7bdbab14e6aeaa778ef957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samir")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38076")[#strong[#text("Samir")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2009")])]

#text("Hi Professor Tao,")

#text("I think I’ve proved the assertion in ex. 2, so feel free to disregard that last comment unless it serves the many other readers of your blog, or current students in 245C.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38142")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In the last sentence before Lemma 2, I believe what you really meant is ‘ a log-convex function of ")#mi("{p}")#text(", if I’m right.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38147")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In Exercise 5, should ")#tao-math("\\left|f\\right|", block: false)#text(" as a step function also be asked to only take two values(one be 0)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38156")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2009")])]

#text("Dear Liuxiaochuan,")

#text("Actually I do mean 1/p, i.e. the function ")#mi("t \\mapsto A \\mu(E)^t")#text(" is a (non-strictly) log-convex function of t. In interpolation, 1/p is the more important parameter than p.")

#text("The property of being a step function (i.e. being equal to ")#mi("A 1_E")#text(" for some A, E) is equivalent to that of taking two values, one of them zero.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38180")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" In exercise 6, I don’t underdtand the first line after the formular. Are there any typos?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2009")])]

#text("Ah, wordpress ate the < and > signs again. Fixed now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/758f78bdc69374a138e14ceeda93836fe67ee98b33063997a5d1536e927a6a7b-f32ad8715309a76f5b93bdfcc1fd214f5cf8e03a4e7bdbab14e6aeaa778ef957.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Samir")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38208")[#strong[#text("Samir")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2009")])]

#text("Dear Professor Tao,")

#text("In lemma 2, you state: ")#tao-math("{1/p \\mapsto \\log \\left\\|f\\right\\|_{L^p(X)}}", block: false)#text(" is a log-convex function of ")#mi("1/p")#text(". Shouldn’t this read: ")#tao-math("{1/p \\mapsto \\left\\|f\\right\\|_{L^p(X)}}", block: false)#text(" is a log-convex function…? Alternatively, if we leave the log function as written, then it is a convex function, correct?")

#text("Samir")

#emph[#text("[Corrected, thanks – T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38277")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2009")])]

#text("Dear Professor Tao:")#linebreak()#text(" I failed to figure out exercise 8, even with the hint. Could your please help me out? How to dispose of the regions of X where f is too large or too small?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38283")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Dear Prof. Tao and Xiaochuan,")

#text("I also tried this exercise, and did it in the following way: W.l.o.g. we assume ")#tao-math("\\left|f(x_1)\\right| \\geq \\left|f(x_2)\\right| \\geq \\ldots \\geq \\left|f(x_{\\left|X\\right|})\\right|", block: false)#text(", by ")#tao-math("\\left|\\left|f\\right|\\right|_{\\infty, p}=1", block: false)#text(", we have ")#tao-math("\\left|f\\right| \\leq \\sum_{k=1}^{\\left|X\\right|} (\\frac 1k)^{1/p} 1_{x_k}", block: false)#text(". Hence, ")#tao-math("\\sum_k \\left|f(x_k)\\right|^p  \\leq \\sum_k \\frac 1k \\leq C log(1+\\left|X\\right|) .", block: false)#text(" If I am wrong, please help to delete it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38289")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("Dear PDEbeginner:")#linebreak()#text(" I guess you are right. Thank you so much.")

#text("But in this way, the hint is not used, maybe Professor Tao’s hint points out another method of this exercise. Let’s just wait for his summarization. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38295")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2009")])]

#text("There is more than one way to solve the problem. The way the hint suggests is to discard all the points x for which |f(x)| exceeds 1 (this is the empty set) or is less than ")#tao-math("\\left|X\\right|^{-1/p}", block: false)#text(" (this is not the empty set, but gives an acceptable contribution to the ")#mi("L^p")#text(" norm of ")#mi("f")#text("). The remainder can be dealt with by the distributional formula for the L^p norm.")

#text("I’ve put the solution on the tricki article")

#link("http://www.tricki.org/article/Control_level_sets")[#text("http://www.tricki.org/article/Control_level_sets")]

#text("as it is a good example of the technique.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38343")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2009")])]

#text("Dear Professor Tao:")

#text("In(10), I guess ")#mi("p_\\theta")#text(" is not defined by ")#mi("{1/p_\\theta := (1-\\theta)/p_0 + \\theta/p_1}")#text(", but rather ")#mi("p_\\theta=(1-\\theta)p_0 +\\theta p_1")#text(", am I right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38347")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2009")])]

#text("Actually, I want to keep ")#mi("p_\\theta")#text(" as the harmonic average ")#mi("1/p_\\theta = (1-\\theta)/p_0 + \\theta/p_1")#text(", in order to keep the final constant as ")#mi("B_\\theta = B_0^{1-\\theta} B_1^\\theta")#text(". When performing the scalar interpolation, one would need to use a different parameter, say ")#mi("\\alpha")#text(", defined by ")#mi("p_\\theta = (1-\\alpha) p_0 + \\alpha p_1")#text(", but if one does the algebra one can check that the constant in (11) is indeed ")#mi("B_\\theta^{p_\\theta}")#text(" at the end of the day.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38366")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2009")])]

#text("Dear Professor Tao:")

#text("In exercise 12, why can the inequality ")#tao-math("{\\left\\|\\sum_{j=1}^n f_j\\right\\|_{L^{1,\\infty}(X)} \\geq c \\log n}", block: false)#text(" ensure that the quasi-norm is not equivalent to an actual norm? I think it should be at least larger than n.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38379")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Dear Liuxiaochuan,")

#text("There was a misprint in that exercise; the ")#mi("\\log n")#text(" should be ")#mi("n \\log n")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245C, Notes 4: Sobolev spaces « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-38481")[#strong[#text("245C, Notes 4: Sobolev spaces « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2009")])]

#text("[…] integration . By the Hardy-Littlewood-Sobolev theorem on fractional integration (Corollary 7 of Notes 1) we conclude […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6cc1d900de38e979cf231a4f9561c62ce20548548ff2b9898f5f1ca64fbd071d-0867faf9d1b08b1506361c4429a2db2a418162f2a1013f3e084415206000e90b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of liuxiaochuan")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-39804")[#strong[#text("liuxiaochuan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2009")])]

#text("Dear Professor Tao:")

#text("In exercise 13, what is p’ when ")#mi("0<p\\leq 1")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-39805")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2009")])]

#text("Dear Liuxiaochuan,")

#mi("p^{\\prime}=p/(p-1)")#text(" will be a negative number in this case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-39814")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2009")])]

#text("Dear Prof. Tao.")

#text("It looks like that by the trick of collapsing to a point in Marcinkiewicz’s interpolation theorem we can expect the following inequality to be true:")

#text("$latex$")

#text("Is this right? Thank you very much")

#emph[#text("[I am guessing you are encountering the bug that the < and > signs inside a latex environment in WordPress are sometimes interpreted as HTML. Try &lt; and &gt; instead. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-39819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2009")])]

#text("I´ll try again…")

#text("It looks like that by the trick of collapsing to a point in Marcinkiewicz’s interpolation theorem we can expect the following inequality to be true:")

#tao-math("< \\displaystyle \\left\\| f\\right\\|_{L^{p,q}(X)} \\leq C_{p,p_0,p_1} \\left\\|f\\right\\|_{L^{p_0}(X)}^{1-\\theta} \\left\\|f\\right\\|_{L^{p_1}(X)}^{\\theta} >", block: false)

#text("Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-39825")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2009")])]

#text("Yes, this is correct (assuming the usual hypotheses on ")#mi("p,q,p_0,p_1")#text(", of course). One can also establish this bound more directly by using the distribution function of f.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-40074")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Dear All,")

#text("Perhaps someone reading can help me out here…")

#text("I think understand the strengthening of (3) to get (6) but am getting confused about the strengthening of the bound on the distribution function in (11) to get the next line.")

#text("Is this performed in a similar way? – If so perhaps I am just lost in the algebra of the exponents. And what is the relevance of t_0? Or just notationally convenient?")

#text("Many Thanks to anyone who can help,")

#text("Spence")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-40075")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Dear Spence,")

#text("I would recommend drawing a graph of the quantities ")#mi("B_0^{p_0}/t^{p_0}")#text(", ")#mi("B_1^{p_1}/t^{p_1}")#text(", ")#mi("B_\\theta^{p_\\theta}/t^{p_\\theta}")#text(", and ")#mi("\\frac{B_\\theta^{p_\\theta}}{t^{p_\\theta}} \\min( t/t_0, t_0/t)^\\epsilon")#text(" as functions of t, to see what is going on. (The picture is clearest if one uses a log-log plot, so that all functions become linear.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-40082")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2009")])]

#text("Dear Professor Tao,")

#text("Much clearer now. Thank you very much.")

#text("Best,")

#text("Spencer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcb7765dcebcb66b358418fd292f07b386c0a7291a90aeb9f6bca628bfb97942-d37902696adeaffae267d8a41e7d46cff565608798c847245651b7b074aca171.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Spencer")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-40087")[#strong[#text("Spencer")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Dear Prof. Tao,")

#text("In the last paragraph of the Riesz-Thorin proof you have the sentence beginnning: “But one can extend the claim to any ")#mi("f \\in L^{p_{\\theta}}(X)")#text(" (keeping ")#mi("g")#text(" simple with finite measure support)…..”")

#text("You describe a decomposition of ")#mi("f")#text(" and then how to approximate the two parts separately. However, as it stands at the moment, is seems to me that the two approximations are exactly the same and work would as one. I may be wrong but perhaps the second occurence of ")#mi("L^{p_{\\theta}}(X) \\cap L^{p_1}(X)")#text(" is in fact ")#mi("L^{p_{\\theta}}(X) \\cap L^{p_0}(X)")#text("?")

#text("I’m also fairly sure that the phantom equation (18) is in fact line (16), though the link does snap back to (16).")

#text("Best Regards,")

#text("Spencer")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-40091")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2009")])]

#text("Spencer: Thanks for the corrections!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-40976")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("Dear Prof. Tao,")

#text("There seems some problem for (6). The following case seems a counterexample:")

#mi("A_0=5, B_0=10; A_1=100, B_1=1000")#text(",")

#text("Take ")#mi("\\theta=\\epsilon=1/2")#text(".")

#text("I think the RHS should be ")#mi("B_\\theta min\\{(\\frac{A_1B_0}{A_0B_1})^{\\epsilon} , (\\frac{A_0B_1}{A_1B_0})^{\\epsilon}\\}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-40977")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2009")])]

#text("(6) is specific to the special case ")#mi("A_0=A_1=A")#text(", as mentioned a few lines earlier.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-41044")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2009")])]

#text("Dear Prof. Tao,")

#text("In the proof of Theorem 1, the term ")#mi("is")#text(" of ")#mi("g_\\epsilon")#text(" seems to be ")#mi("-is")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-41046")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2009")])]

#text("Oops, I made a mistake in the above comments, because I printed out all the notes several months ago and read the old version. I will be more careful before making a comments.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-41335")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2009")])]

#text("Dear Prof. Tao,")

#text("I think ")#mi("[0,1] \\times [0,\\infty]")#text(" should be $[0,\\infty] \\times [0,1]$ just above exercise 15.")

#text("There seems some problems in the definition of sublinear operator just above exercise 17: ")#tao-math("T(cf)=\\left|c\\right| Tf", block: false)#text(" and ")#mi("T(f+g) \\leq Tf+Tg")#text(". If we take ")#tao-math("\\left|T(f+g)\\right| \\leq \\left|Tf\\right|+\\left|Tg\\right|", block: false)#text(", there seems some problems in exercise 17. On the other hand, the definition of sublinear function in wiki also has no absolute value.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PDEbeginner")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-41738")[#strong[#text("PDEbeginner")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#text("Dear Prof. Tao,")

#text("I just finished reading this note, there are two small corrections (I think):")

#text("1. In the proof of Theorem 4, the expression below ‘To prove (20)’ seems to forget a sum over ")#mi("m")#text(".")

#text("2. In the last exercise, ‘(7)’ should be ‘Corollary 7’")

#text("I also have a question: Can we establish the weak-type Schur’s test by a more direct approach as in exercise 24? I tried to do it, but failed.")

#text("Thanks a lot in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-41741")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2009")])]

#text("Thanks for the corrections!")

#text("One can prove Schur’s test directly if one knows about the duality between ")#mi("L^{p,\\infty}")#text(" and ")#mi("L^{p^{\\prime},1}")#text(", but this requires a small amount of knowledge of Lorentz spaces (actually much of the theory required is already buried in the above notes in various places, particularly in the exercises). Ultimately the proof is basically the same as the one given here, though, after one unpacks all the definitions and theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 1: Concentration of measure « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-43069")[#strong[#text("254A, Notes 1: Concentration of measure « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2010")])]

#text("[…] The idea is then to estimate the tail of and by two different means. With , the point is that the variables have been made bounded by fiat, and so the more powerful large deviation inequalities can now be put into play. With , in contrast, the underlying variables are certainly not bounded, but they tend to have small zeroth and first moments, and so the bounds based on those moment methods tend to be powerful here. (Readers who are familiar with harmonic analysis may recognise this type of divide and conquer argument as an interpolation argument.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 0: A review of probability theory « What’s new")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-43092")[#strong[#text("254A, Notes 0: A review of probability theory « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2010")])]

#text("[…] The idea is then to estimate the tail of and by two different means. With , the point is that the variables have been made bounded by fiat, and so the more powerful large deviation inequalities can now be put into play. With , in contrast, the underlying variables are certainly not bounded, but they tend to have small zeroth and first moments, and so the bounds based on those moment methods tend to be powerful here. (Readers who are familiar with harmonic analysis may recognise this type of divide and conquer argument as an interpolation argument.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4884d92efc2429015564dc243f5bf0927642752a6d866c09fdc518193c7642b3-9c9b71046c26261b498aea800b1f5da89194d568a06bc65dbdf13e7f0b7dda3d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/comment-page-1/#comment-43973")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("Dear Pr. Tao, it seems to me that there is a typo in the statement of the Riesz-Thorin theorem. In the definition of $p_theta$ and $q_theta$, there should be brackets around 1-\\theta.")

#emph[#text("[Corrected, thanks – T.]")]
]
