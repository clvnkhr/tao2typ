// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/26/frank-morgan-new-ams-blog/
// Converted to Typst by tao2typ: "2026-10-14T15:17:06.923417+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Frank Morgan) New AMS blog", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Frank Morgan) New AMS blog")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/26/frank-morgan-new-ams-blog/")[#text("https://terrytao.wordpress.com/2009/03/26/frank-morgan-new-ams-blog/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#emph[#text("[This article was guest authored by ")#link("http://math.williams.edu/morgan")[#text("Frank Morgan")]#text(", the vice president of the American Mathematical Society.]")]#linebreak()#text(" The American Mathematical Society (AMS) has launched a new blog")

#link("http://mathgradblog.williams.edu/")[#text("http://mathgradblog.williams.edu/")]

#text("by and for graduate students, with initial entries ranging from “Finding an Advisor” to “Getting a Job.” Although graduate students have long been institutional members of the AMS, the two groups may not always have fully appreciated each other. Graduate students sometimes wonder why they are getting all this “junk mail,” and AMS governance has had relatively minor contact with graduate students. In fact, graduate students are the future of the AMS, and conversely they need the AMS and its support for mathematics. Hence I think that it is a bright sign of the times to see the AMS launching this blog by and for graduate students. Graduate students interested in joining the editorial board or others interested in helping out can email me at ")#link("mailto:Frank.Morgan@williams.edu")[#text("Frank.Morgan@williams.edu")]#text("; we seek a large and diverse board. Meanwhile check out the new blog and post some comments on the entries you find there.")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c99be9b51ffeaba0488ac5a820c66cff4fdd345c5530de317391471ca037a7-29d397b384d569338a539952d844eefa912edd9b18155a8cd25717ef3d5cce86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Academic Career Links")]], [#link("https://terrytao.wordpress.com/2009/03/26/frank-morgan-new-ams-blog/#comment-37524")[#strong[#text("Academic Career Links")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2009")])]

#text("Just a technicality: in the links bar, under “Mathematics”,")#linebreak()#text(" the title for the link to the blog mentioned in this post may need some fixing :) ")#emph[#text("[Fixed, thanks – T.]")]
]
