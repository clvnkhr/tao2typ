// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/
// Converted to Typst by tao2typ: "2026-10-14T15:20:15.501362+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Uhlenbeck’s theorem on connections with small curvature", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Uhlenbeck’s theorem on connections with small curvature")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 March 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/")[#text("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I was pleased to learn this week that ")#link("http://www.abelprize.no/c73996/seksjon/vis.html?tid=74011&strukt_tid=73996")[#text("the 2019 Abel Prize")]#text(" was awarded to ")#link("https://en.wikipedia.org/wiki/Karen_Uhlenbeck")[#text("Karen Uhlenbeck")]#text(". Uhlenbeck laid much of the foundations of modern geometric PDE. One of the few papers I have in this area is in fact ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2053951")[#text("a joint paper with Gang Tian")]#text(" extending a famous ")#link("https://mathscinet.ams.org/mathscinet/search/publdoc.html?pg1=MR&s1=648355&loc=fromreflist")[#text("singularity removal theorem of Uhlenbeck for four-dimensional Yang-Mills connections")]#text(" to higher dimensions. In both these papers, it is crucial to be able to construct “Coulomb gauges” for various connections, and there is a clever trick of Uhlenbeck for doing so, introduced in ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=648356")[#text("another important paper of hers")]#text(", which is absolutely critical in my own paper with Tian. Nowadays it would be considered a standard technique, but it was definitely not so at the time that Uhlenbeck introduced it.")

#text("Suppose one has a smooth connection ")#mi("{A}")#text(" on a (closed) unit ball ")#mi("{B(0,1)}")#text(" in ")#mi("{{\\bf R}^n}")#text(" for some ")#mi("{n \\geq 1}")#text(", taking values in some Lie algebra ")#mi("{{\\mathfrak g}}")#text(" associated to a compact Lie group ")#mi("{G}")#text(". This connection then has a curvature ")#mi("{F(A)}")#text(", defined in coordinates by the usual formula ")#metadata(none) <tao-c2242e2c12190babaf9f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("F(A)_{\\alpha \\beta} = \\partial_\\alpha A_\\beta - \\partial_\\beta A_\\alpha + [A_\\alpha,A_\\beta].")]]



#text(" It is natural to place the curvature in a scale-invariant space such as ")#mi("{L^{n/2}(B(0,1))}")#text(", and then the natural space for the connection would be the Sobolev space ")#mi("{W^{n/2,1}(B(0,1))}")#text(". It is easy to see from ")#link(<tao-c2242e2c12190babaf9f>)[#text("(1)")]#text(" and Sobolev embedding that if ")#mi("{A}")#text(" is bounded in ")#mi("{W^{n/2,1}(B(0,1))}")#text(", then ")#mi("{F(A)}")#text(" will be bounded in ")#mi("{L^{n/2}(B(0,1))}")#text(". One can then ask the converse question: if ")#mi("{F(A)}")#text(" is bounded in ")#mi("{L^{n/2}(B(0,1))}")#text(", is ")#mi("{A}")#text(" bounded in ")#mi("{W^{n/2,1}(B(0,1))}")#text("? This can be viewed as asking whether the curvature equation ")#link(<tao-c2242e2c12190babaf9f>)[#text("(1)")]#text(" enjoys “elliptic regularity”.")

#text("There is a basic obstruction provided by gauge invariance. For any smooth gauge ")#mi("{U: B(0,1) \\rightarrow G}")#text(" taking values in the Lie group, one can gauge transform ")#mi("{A}")#text(" to")

#align(center)[#tao-fit-display[#mitex("A^U_\\alpha := U^{-1} \\partial_\\alpha U + U^{-1} A_\\alpha U")]]

#text("and then a brief calculation shows that the curvature is conjugated to")

#align(center)[#tao-fit-display[#mitex("F(A^U)_{\\alpha \\beta} = U^{-1} F_{\\alpha \\beta} U.")]]

#text("This gauge symmetry does not affect the ")#mi("{L^{n/2}(B(0,1))}")#text(" norm of the curvature tensor ")#mi("{F(A)}")#text(", but can make the connection ")#mi("{A}")#text(" extremely large in ")#mi("{W^{n/2,1}(B(0,1))}")#text(", since there is no control on how wildly ")#mi("{U}")#text(" can oscillate in space.")

#text("However, one can hope to overcome this problem by ")#emph[#text("gauge fixing")]#text(": perhaps if ")#mi("{F(A)}")#text(" is bounded in ")#mi("{L^{n/2}(B(0,1))}")#text(", then one can make ")#mi("{A}")#text(" bounded in ")#mi("{W^{n/2,1}(B(0,1))}")#text(" ")#emph[#text("after")]#text(" applying a gauge transformation. The ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=648356")[#text("basic and useful result of Uhlenbeck")]#text(" is that this can be done if the ")#mi("{L^{n/2}}")#text(" norm of ")#mi("{F(A)}")#text(" is sufficiently small (and then the conclusion is that ")#mi("{A}")#text(" is small in ")#mi("{W^{n/2,1}}")#text("). (For large connections there is a serious issue related to the ")#link("https://en.wikipedia.org/wiki/Gribov_ambiguity")[#text("Gribov ambiguity")]#text(".) In my (much) ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2053951")[#text("later paper with Tian")]#text(", we adapted this argument, replacing Lebesgue spaces by Morrey space counterparts. (This result was also independently obtained at about the same time ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1993420")[#text("by Meyer and Riviére")]#text(".)")

#text("To make the problem elliptic, one can try to impose the ")#emph[#text("Coulomb gauge condition")]#text(" ")#metadata(none) <tao-2c26b46b68ffc68ff99b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\partial^\\alpha A_\\alpha = 0")]]



#text(" (also known as the ")#emph[#text("Lorenz gauge")]#text(" or ")#emph[#text("Hodge gauge")]#text(" in various papers), together with a natural boundary condition on ")#mi("{\\partial B(0,1)}")#text(" that will not be discussed further here. This turns ")#link(<tao-c2242e2c12190babaf9f>)[#text("(1)")]#text(", ")#link(<tao-2c26b46b68ffc68ff99b>)[#text("(2)")]#text(" into a divergence-curl system that is elliptic at the linear level at least. Indeed if one takes the divergence of ")#link(<tao-c2242e2c12190babaf9f>)[#text("(1)")]#text(" using ")#link(<tao-2c26b46b68ffc68ff99b>)[#text("(2)")]#text(" one sees that ")#metadata(none) <tao-34dfab9d2253ceeb68a2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial^\\alpha F(A)_{\\alpha \\beta} = \\Delta A_\\beta + \\partial^\\alpha [A_\\alpha,A_\\beta]")]]



#text(" and if one could somehow ignore the nonlinear term ")#mi("{\\partial^\\alpha [A_\\alpha,A_\\beta]}")#text(" then we would get the required regularity on ")#mi("{A}")#text(" by standard elliptic regularity estimates.")

#text("The problem is then how to handle the nonlinear term. If we already knew that ")#mi("{A}")#text(" was small in the right norm ")#mi("{W^{n/2,1}(B(0,1))}")#text(" then one can use Sobolev embedding, Hölder’s inequality, and elliptic regularity to show that the second term in ")#link(<tao-34dfab9d2253ceeb68a2>)[#text("(3)")]#text(" is small compared to the first term, and so one could then hope to eliminate it by perturbative analysis. However, proving that ")#mi("{A}")#text(" is small in this norm is exactly what we are trying to prove! So this approach seems circular.")

#text("Uhlenbeck’s clever way out of this circularity is a textbook example of what is now known as a “continuity” argument. Instead of trying to work just with the original connection ")#mi("{A}")#text(", one works with the rescaled connections ")#mi("{A^{(t)}_\\alpha(x) := t A_\\alpha(tx)}")#text(" for ")#mi("{0 \\leq t \\leq 1}")#text(", with associated rescaled curvatures ")#mi("{F(A^{(t)})_\\alpha = t^2 F(A)_{\\alpha \\beta}(tx)}")#text(". If the original curvature ")#mi("{F(A)}")#text(" is small in ")#mi("{L^{n/2}}")#text(" norm (e.g. bounded by some small ")#mi("{\\varepsilon>0}")#text("), then so are all the rescaled curvatures ")#mi("{F(A^{(t)})}")#text(". We want to obtain a Coulomb gauge at time ")#mi("{t=1}")#text("; this is difficult to do directly, but it is trivial to obtain a Coulomb gauge at time ")#mi("{t=0}")#text(", because the connection vanishes at this time. On the other hand, once one has successfully obtained a Coulomb gauge at some time ")#mi("{t \\in [0,1]}")#text(" with ")#mi("{A^{(t)}}")#text(" small in the natural norm ")#mi("{W^{n/2,1}}")#text(" (say bounded by ")#mi("{C \\varepsilon}")#text(" for some constant ")#mi("{C}")#text(" which is large in absolute terms, but not so large compared with say ")#mi("{1/\\varepsilon}")#text("), the perturbative argument mentioned earlier (combined with the qualitative hypothesis that ")#mi("{A}")#text(" is smooth) actually works to show that a Coulomb gauge can also be constructed and be small for all sufficiently close ")#emph[#text("nearby")]#text(" times ")#mi("{t^{\\prime} \\in [0,1]}")#text(" to ")#mi("{t}")#text("; furthermore, the perturbative analysis actually shows that the nearby gauges enjoy a slightly better bound on the ")#mi("{W^{n/2,1}}")#text(" norm, say ")#mi("{C\\varepsilon/2}")#text(" rather than ")#mi("{C\\varepsilon}")#text(". As a consequence of this, the set of times ")#mi("{t}")#text(" for which one has a good Coulomb gauge obeying the claimed estimates is both open and closed in ")#mi("{[0,1]}")#text(", and also contains ")#mi("{t=0}")#text(". Since the unit interval ")#mi("{[0,1]}")#text(" is connected, it must then also contain ")#mi("{t=1}")#text(". This concludes the proof.")

#text("One of the lessons I drew from this example is to not be deterred (especially in PDE) by an argument seeming to be circular; if the argument is still sufficiently “nontrivial” in nature, it can often be modified into a usefully non-circular argument that achieves what one wants (possibly under an additional qualitative hypothesis, such as a continuity or smoothness hypothesis).")

#heading(level: 1)[#text("Comments (13)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0955e0f8208dccb5b3dde8ae8f9e68bc4dd978beb7bf382939995cad14d77b69-e63428a19e275197cb2cb9e1f9af259dc01d343a30e1be5aca16f8e8fb0234f2.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of porton")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-513994")[#strong[#text("porton")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("What is “smooth connection”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514002")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("You’d have to read a book on differential geometry, but the bare definition can be found on Wikipedia:")

#link("https://en.wikipedia.org/wiki/Connection_(principal_bundle)")[#text("https://en.wikipedia.org/wiki/Connection_(principal_bundle)")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-513997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")])]

#text("Thank you, Terrry for the notes. All her papers are behind paywall.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514052")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2019")])]

#text("Here is the (free, I hope) links to the first mentioned paper by Uhlenbeck ")#link("https://link.springer.com/content/pdf/10.1007/BF01947068.pdf")[#text("removable singularities in Yang Mills Fields")]#text(" and to the second mentioned paper ")#link("https://link.springer.com/content/pdf/10.1007/BF01947069.pdf")[#text("Connections with")#emph[#text("L")]#emph[#text("P")]#text(" bounds on curvature")]#text(".‏ A link to the 2002 arxived version of Tao-Tian’s paper ")#link("https://arxiv.org/abs/math/0209352")[#text("is here")]#text(". And here is a link to a ")#link("https://arxiv.org/abs/1811.03135")[#text("recent arxived paper")]#text(" by Penny Smith and Karen Uhlenbeck that proposes a simpler proof for the Tao-Tian theorem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514054")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2019")])]

#text("Thanks for this! I didn’t know that Smith and Uhlenbeck had found a simpler and stronger proof of my 2002 paper with Tian just last year, which in turn extended Uhlenbeck’s original 1982 paper. Funny how things came full circle after almost 40 years…")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514011")[#strong[#text("TYI38 Lior Kalai: Monty Hall Meets Survivor | Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2019")]

#text("[…] the prize and additional material may be found in the Abel Prize page (Additional sources: I, II, III, IV, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bfa0c4385ae96963e98a762a59e760d084c20bb08c5de8b0c784ee27588fb04d-6bffb221df6658f0b7ac32594d2feecb02e740754065808f6aa689a7b13c5c37.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deaneyang")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514031")[#strong[#text("deaneyang")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2019")])]

#text("” the perturbative analysis actually shows that the nearby gauges enjoy a slightly better bound on the {W^{n/2,1}} norm, say {C\\varepsilon/2} rather than {C\\varepsilon}.”")

#text("Am I wrong in believing that this is the crucial technical step? The rest is relatively straightforward, but, as you say, the scale invariance means the estimate does not improve as you iterate. Somehow the scale invariance has to be broken.")

#text("And isn’t this related to the “amplification” technique you wrote about a while back?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514033")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2019")])]

#text("Right, this is the key perturbative step. One rewrites the equation (3) as")

#mi("\\displaystyle \\Delta A_\\beta = \\partial^\\alpha F(A)_{\\alpha \\beta} - \\partial^\\alpha [A_\\alpha,A_\\beta].")

#text("If one already knows that ")#mi("A")#text(" is bounded in ")#mi("W^{n/2,1}")#text(" by ")#mi("C \\varepsilon")#text(" (or even say ")#mi("2 C \\varepsilon")#text("), and ")#mi("F(A)")#text(" is bounded in ")#mi("L^{n/2}")#text(" by ")#mi("\\varepsilon")#text(", then inserting this into the RHS of the above equation and using elliptic regularity one obtains a nontrivial new bound on ")#mi("A")#text(" in ")#mi("W^{n/2,1}")#text(", basically of the form ")#mi("O(\\varepsilon) + O(C \\varepsilon)^2")#text(", which is less than ")#mi("C \\varepsilon/2")#text(" if the constants are all chosen correctly.")

#text("I guess it can indeed be viewed as a sort of amplification; the nonlinear equation (3) permits one to “amplify” a weak bound on ")#mi("A")#text(" to a strong bound, and this combined with the continuity argument allows one to obtain the strong bound unconditionally.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514080")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2019")])]

#text("Dear Terry,")#linebreak()#text(" Beside Yang Mills problem, I want to mention about Navier Stoke equation. I am not a mathematician, but I love maths very crazily. I am worried about you in doing any progress of Navier Stokes. I think Navier Stokes is much many times harder than Poincare conjecture. Because all images and constructions of Poincare are firm, stable, not move, not change.In constrast of Navier Stokes always change, move, not firm and stables.If Navier Stokes is successfull, I think human beings will know the past, the current, the future of the Earth. Is it right? Waiting your reply.Thanks very much.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2019")])]

#text("NS is merely an idealized (Newtonian) modeling for fluids which only approximates the real world physical laws.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48a1f693a36ae8c511e6e8c1ebba0d1d2be51d483acd3957d3110fb4a16ac2e8-69a1f737851cf5885f1bc5e3ae888890b61ef13a8b844217dfb4d80a4372fc52.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-514350")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2019")])]

#text("Tom Mrowka also sketched a new proof of Tao-Tian’s theorem at John Morgan’s 60th birthday conference in 2006, but the proof is never published.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ec4d2278f8b45e80790546703a54c4e513c2bf7c27cf66243fc18ad89bda0d7-50c1dcf7c6effd46cca7c091de8593af68e02a1d194c55540e6cc8cea8113190.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of SRichter")]], [#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-515689")[#strong[#text("SRichter")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2019")])]

#text("Fascinating. I’m a 2nd-semester math student and I found it was a very interesting read. Just needed to google")#linebreak()#text(" – Geometric PDE")#linebreak()#text(" – 4-Dimensional Yang-Mills connection")#linebreak()#text(" – Coloumb Gauges")#linebreak()#text(" – Smooth connection")#linebreak()#text(" – Lie Algebra")#linebreak()#text(" – Lie Group")#linebreak()#text(" – Curvature (this one will be taught this semester, I think)")#linebreak()#text(" – Scale-Invariant Space")#linebreak()#text(" – L^n/2")#linebreak()#text(" – Sobolev space, Sobolev embedding")#linebreak()#text(" – Elliptic regularity")#linebreak()#text(" – Curvature Tensor")#linebreak()#text(" – Gauge Transformation, Gauge Symmetry, Gauge fixing")#linebreak()#text(" – Lebesgue spaces, Morrey spaces")#linebreak()#text(" – Divergence-curl system")#linebreak()#text(" – “Elliptic at the linear level”")#linebreak()#text(" – Standard elliptic regularity elements")#linebreak()#text(" – Perturbative Analysis")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/03/19/uhlenbecks-theorem-on-connections-with-small-curvature/#comment-684531")[#strong[#text("Log-Concavity and Conformal Gauges – Gabe Khan's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 March 2024")]

#text("[…] in geometry and mathematical physics. There is a good blog post by Terry Tao on the topic and another on Uhlenbeck’s work when she won the Abel […]")
]
