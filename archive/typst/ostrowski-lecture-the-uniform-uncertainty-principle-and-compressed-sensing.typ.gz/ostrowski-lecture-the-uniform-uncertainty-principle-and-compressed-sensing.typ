// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/
// Converted to Typst by tao2typ: "2026-10-14T06:52:26.622907+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Ostrowski lecture: The uniform uncertainty principle and compressed sensing", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Ostrowski lecture: The uniform uncertainty principle and compressed sensing")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 April 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/")[#text("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("For much of last week I was in Leiden, Holland, giving one of the ")#link("http://www.nmc2007.nl/index.php?page=ostrowski")[#text(" Ostrowski prize")]#text(" lectures at the ")#link("http://www.nmc2007.nl/index.php")[#text("annual meeting of the Netherlands mathematical congress")]#text(". My talk was not on the subject of the prize (arithmetic progressions in primes), as this was covered by a talk of ")#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" there, but rather on a certain “uniform uncertainty principle” in Fourier analysis, and its relation to compressed sensing; this is work which is joint with ")#link("http://www.acm.caltech.edu/~emmanuel/")[#text("Emmanuel Candes")]#text(" and also partly with ")#link("http://users.ece.gatech.edu/~justin/")[#text("Justin Romberg")]#text(".")

#metadata(none) <tao-eab44562306b02247755>#text(" As mentioned in the ")#link("https://terrytao.wordpress.com/2007/04/13/compressed-sensing-and-single-pixel-cameras/")[#text("previous post here")]#text(", compressed sensing is a relatively new measurement paradigm which seeks to capture the “essential” aspects of a high-dimensional object using as few measurements as possible. There are many contexts in which compressed sensing is potentially useful, but for this talk (which is focussed on theory rather than applications) I will just consider a single toy model arising from Fourier analysis. Specifically, the object we seek to measure will be a complex function ")#mi("f: {\\Bbb Z}/{N \\Bbb Z} \\to {\\Bbb C}")#text(" on the cyclic group of N elements (or if you wish, a column vector of N complex numbers). In practice one should think of N as being of moderately large size, e.g. ")#mi("N \\sim 10^6")#text(". Given such a function, one can form its (discrete) Fourier transform ")#mi("\\hat f: {\\Bbb Z}/{N \\Bbb Z} \\to {\\Bbb C}")#text("; for this talk it will be convenient to normalise this Fourier transform as")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = \\frac{1}{\\sqrt{N}} \\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} f(x) e^{-2\\pi i x\\xi/N}.")]]

#text("We suppose that we can measure some (but perhaps not all) of the Fourier coefficients of f, and ask whether we can reconstruct f from this information; the objective is to use as few Fourier coefficients as possible. More specifically, we fix a set ")#mi("\\Lambda \\subset {\\Bbb Z}/N{\\Bbb Z}")#text(" of “observable” frequencies, and pose the following two questions:")

#enum(start: 1, 
[#text("Let N be a known integer, let ")#mi("f:  {\\Bbb Z}/N {\\Bbb Z} \\to {\\Bbb C}")#text(" be an unknown function, let ")#mi("\\Lambda \\subset {\\Bbb Z}/N{\\Bbb Z}")#text(" a known set of frequencies, and let ")#mi("c_\\xi = \\hat f(\\xi)")#text(" be a sequence of known Fourier coefficients of f for all ")#mi("\\xi \\in \\Lambda")#text(". Is it possible to reconstruct f uniquely from this information?")],
[#text("If so, what is a practical algorithm for finding f?")]
)

#text("For instance, if ")#mi("\\Lambda")#text(" is the whole set of frequencies, i.e. ")#mi("\\Lambda = {\\Bbb Z}/N{\\Bbb Z}")#text(", then the answer to Q1 is “yes” (because the Fourier transform is injective), and an answer to Q2 is provided by the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("f(x) = \\frac{1}{\\sqrt{N}} \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} c_\\xi e^{2\\pi i x\\xi}")]]

#text("which can be computed quite quickly, for instance by using the ")#link("http://en.wikipedia.org/wiki/Fast_Fourier_transform")[#text("fast Fourier transform")]#text(".")

#text("Now we ask what happens when ")#mi("\\Lambda")#text(" is a proper subset of ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(". Then the answer to Q1, as stated above, is “no” (and so Q2 is moot). One can see this abstractly by a degrees-of-freedom argument: the space of all functions f on N points has N degrees of freedom, but we are only making ")#tao-math("\\left|\\Lambda\\right|", block: false)#text(" measurements, thus leaving ")#tao-math("N - \\left|\\Lambda\\right|", block: false)#text(" remaining degrees of freedom in the unknown function f. If ")#tao-math("\\left|\\Lambda\\right|", block: false)#text(" is strictly less than N, then there are not enough measurements to pin down f precisely. More concretely, we can easily use the Fourier inversion formula to concoct a function f which is not identically zero, but whose Fourier transform vanishes on ")#mi("\\Lambda")#text(" (e.g. consider a plane wave whose frequency lies outside of ")#mi("\\Lambda")#text("). Such a function is indistinguishable from the zero function as far as the known measurements are concerned.")

#text("However, we can hope to recover unique solvability for this problem by making an additional hypothesis on the function f. There are many such hypotheses one could make, but for this toy problem we shall simply assume that f is ")#emph[#text("sparse")]#text(". Specifically, we fix an integer S between 1 and N, and say that a function f is ")#emph[#text("S-sparse")]#text(" if f is non-zero in at most S places, or equivalently if the support ")#mi("\\text{supp}(f) := \\{ x \\in {\\Bbb Z}/N{\\Bbb Z}: f(x) \\neq 0\\}")#text(" has cardinality less than or equal to S. We now ask the following modified versions of the above two questions:")

#enum(start: 1, 
[#text("Let S and N be known integers, let ")#mi("f:  {\\Bbb Z}/N{\\Bbb Z} \\to {\\Bbb C}")#text(" be an unknown S-sparse function, let ")#mi("\\Lambda \\subset {\\Bbb Z}/N{\\Bbb Z}")#text(" a known set of frequencies, and let ")#mi("c_\\xi = \\hat f(\\xi)")#text(" be a sequence of known Fourier coefficients of f for all ")#mi("\\xi \\in \\Lambda")#text(". Is it possible to reconstruct f uniquely from this information?")],
[#text("If so, what is a practical algorithm for finding f?")]
)

#text("Note that while we know how sparse f is, we are not given to know exactly ")#emph[#text("where")]#text(" f is sparse – there are S positions out of the N total positions where f might be non-zero, but we do not know which S positions these are. The fact that the support is not known a priori is one of the key difficulties with this problem. Nevertheless, setting that problem aside for the moment, we see that f now has only S degrees of freedom instead of N, and so by repeating the previous analysis one might now hope that the answer to Q1 becomes yes as soon as ")#tao-math("\\left|\\Lambda\\right| \\geq S", block: false)#text(", i.e. one takes at least as many measurements as the sparsity of f.")

#text("Actually, one needs at least ")#tao-math("\\left|\\Lambda\\right| \\geq 2S", block: false)#text(" (if 2S is less than or equal to N), for the following reason. Suppose that ")#tao-math("\\left|\\Lambda\\right|", block: false)#text(" was strictly less than 2S. Then the set of functions supported on {1,…,2S} has more degrees of freedom than are measured by the Fourier coefficients at ")#mi("\\Lambda")#text(". By elementary linear algebra, this therefore means that there exists a function f supported on {1,…,2S} whose Fourier coefficients vanish on ")#mi("\\Lambda")#text(", but is not identically zero. If we split ")#mi("f = f_1 - f_2")#text(" where ")#mi("f_1")#text(" is supported on {1,…,S} and ")#mi("f_2")#text(" is supported on {S+1,…,2S}, then we see that ")#mi("f_1")#text(" and ")#mi("f_2")#text(" are two distinct S-sparse functions whose Fourier transforms agreed on Lambda, thus contradicting unique recoverability of f.")

#text("One might hope that this necessary condition is close to being sharp, so that the answer to the modified Q1 is yes as soon as ")#tao-math("\\left|\\Lambda\\right|", block: false)#text(" is larger than 2S. By modifying the arguments of the previous paragraph we see that Q1 fails if and only if there exists a non-zero 2S-sparse function whose Fourier transform vanished on all of ")#mi("\\Lambda")#text(", but one can hope that this is not the case, because of the following heuristic:")#strong[]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Uncertainty principle")]#text(" (informal): If a function is sparse and not identically zero, then its Fourier transform should be non-sparse.")
]

#text("This type of principle is motivated by the ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("Heisenberg uncertainty principle in physics")]#text("; the size of the support of f is a proxy for the spatial uncertainty of f, whereas the size of the support of ")#mi("\\hat f")#text(" is a proxy for the momentum uncertainty of f. There are a number of ways to make this principle precise. One standard one is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Discrete uncertainty principle")]#text(": If f is not identically zero, then ")#tao-math("\\left|\\text{supp}(f)\\right| \\times \\left|\\text{supp}(\\hat f)\\right| \\geq N", block: false)#text(". ")#strong[]
]

#strong[#text("Proof")]#text(": Combine the Plancherel identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|f(x)\\right|^2 = \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat f(\\xi)\\right|^2", block: true)]]

#text("with the elementary inequalities")

#tao-aligned(keep: true)[


#tao-math("\\sup_{x \\in {\\Bbb Z}/N{\\Bbb Z}}  \\left|f(x)\\right|  & \\leq \\frac{1}{\\sqrt {N}} \\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat f(\\xi)\\right|", block: true)



#tao-math("\\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|f(x)\\right|^2  & \\leq \\left|\\text{supp}(f)\\right| (\\sup_{x \\in {\\Bbb Z}/N{\\Bbb Z}}  \\left|f(x)\\right|)^2", block: true)
]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat f(\\xi)\\right| \\leq \\left|\\text{supp}(\\hat f)\\right|^{1/2}  (\\sum_{\\xi \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|\\hat f(\\xi)\\right|^2)^{1/2}.", block: true)]]

#mi("\\Box")

#text("By applying this principle we see that we obtain unique recoverability as soon as ")#tao-math("\\left|\\Lambda\\right| > N - N/2S", block: false)#text(", but this is a rather lousy criterion – for most values of S, it means that one has to measure almost all of the Fourier coefficients to recover f! At that point one may as well measure all of the coefficients so that one can recover both sparse and non-sparse f easily via the Fourier inversion formula.")

#text("There are cases in which the condition ")#tao-math("\\left|\\Lambda\\right| > N - N/2S", block: false)#text(" cannot be improved. A good example is provided by the ")#link("http://en.wikipedia.org/wiki/Dirac_comb")[#text("Dirac comb")]#text(", in which N is a square number, and f is the indicator function of the multiples ")#mi("\\{ 0, \\sqrt{N}, 2\\sqrt{N}, \\ldots, N-\\sqrt{N}\\}")#text(" of ")#mi("\\sqrt{N}")#text(". As is well known, this function is its own Fourier transform. If we then set ")#mi("\\Lambda")#text(" to be the complement of the multiples of ")#mi("\\sqrt{N}")#text(", then we see that even though we are measuring almost all the frequencies – ")#mi("N - \\sqrt{N}")#text(" of them to be precise – we cannot distinguish the ")#mi("\\sqrt{N}")#text("-sparse Dirac comb f from the zero function; we have unluckily chosen only those frequencies ")#mi("\\Lambda")#text(" which totally fail to intersect the support of the Fourier transform of f.")

#text("One can concoct several further counterexamples of this type, but they require various subgroups of ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" (such as the multiples of ")#mi("\\sqrt{N}")#text(", when N is square). One can ask what happens when the ambient group has no non-trivial subgroups, i.e. when N is prime. Then things become better, thanks to a classical result of ")#link("http://en.wikipedia.org/wiki/Nikolai_Chebotaryov")[#text("Chebotarev")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Chebotarev lemma")]#text(": Let N be prime. Then every square minor of the Fourier matrix ")#mi("(e^{2\\pi i jk/N})_{ 1\\leq j,k \\leq N}")#text(" is invertible.")
]

#text("This lemma has been rediscovered or reproved at least seven times in the literature (I myself ")#link("http://front.math.ucdavis.edu/math.CA/0308286")[#text("rediscovered it once")]#text("); there is a nice ")#link("http://www.ams.org/mathscinet-getitem?mr=1395088")[#text("survey paper on Chebotarev’s work")]#text(" which summarises some of this. (A nice connection to the setting of this talk, pointed out to me by ")#link("http://www.math.leidenuniv.nl/~hwl/")[#text("Hendrik Lenstra")]#text(" here at Leiden: Chebotarev’s lemma was originally conjectured to be true by ")#link("http://en.wikipedia.org/wiki/Alexander_Ostrowski")[#text("Ostrowski")]#text(".) As a quick corollary of this lemma, we obtain the following improvement to the uncertainty principle in the prime order case. ")#strong[]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Uncertainty principle for cyclic groups of prime order")]#text(": If N is prime and f is not identically zero, then ")#tao-math("\\left|\\text{supp}(f)\\right| + \\left|\\text{supp}(\\hat f)\\right| \\geq N+1", block: false)#text(".")
]

#text("From this one can quickly show that one does indeed obtain unique recoverability for S-sparse functions in cyclic groups of prime order whenever one has ")#tao-math("\\left|\\Lambda\\right| \\geq 2S", block: false)#text(", and that this condition is absolutely sharp. (There is a generalisation of the above uncertainty principle to composite N ")#link("http://arxiv.org/abs/math/0312407")[#text("due to Meshulam")]#text(", but the results are not as easy to state.)")

#text("This settles the (modified) Q1 posed above, at least for groups of prime order. But it does not settle Q2 – the question of exactly ")#emph[#text("how")]#text(" one recovers f from the given data ")#mi("N, S, \\Lambda, (c_\\xi)_{\\xi \\in \\Lambda}")#text(". One can consider a number of simple-minded strategies to recover f:")

#enum(start: 1, 
[#strong[#text("Brute force")]#text(". If we knew precisely what the support ")#mi("\\text{supp}(f)")#text(" of f was, we can use linear algebra methods to solve for f in terms of the coefficients ")#mi("c_\\xi")#text(", since we have ")#tao-math("\\left|\\Lambda\\right|", block: false)#text(" equations in S unknowns (and Chebotarev guarantees that this system has maximal rank). So we can simply exhaust all the possible combinations for ")#mi("\\text{supp}(f)")#text(" (there are roughly ")#mi("\\binom{N}{S}")#text(" of these) and apply linear algebra to each combination. This works, but is horribly computationally expensive, and is completely impractical once N and S are of any reasonable size, e.g. larger than 1000.")],
[#mi("l^0")#text(" ")#strong[#text("minimisation")]#text(". Out of all the possible functions f which match the given data (i.e. ")#mi("\\hat f(\\xi) = c_\\xi")#text(" for all ")#mi("\\xi \\in \\Lambda")#text("), find the sparsest such solution, i.e. the solution which minimises the “")#mi("l^0")#text(" norm” ")#tao-math("\\left\\|f\\right\\|_{l^0} := \\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|f(x)\\right|^0 = \\left|\\text{supp}(f)\\right|", block: false)#text(". This works too, but is still impractical: the general problem of finding the sparsest solution to a linear system of equations contains the infamous ")#link("http://en.wikipedia.org/wiki/Subset_sum_problem")[#text("subset sum decision problem")]#text(" as a special case (we’ll leave this as an exercise to the reader) and so this problem is NP-hard in general. (Note that this does ")#emph[#text("not")]#text(" imply that the original problem Q1 is similarly NP-hard, because that problem involves a specific linear system, which turns out to be rather different from the specific linear system used to encode subset-sum.)")],
[#mi("l^2")#text(" ")#strong[#text("minimisation")]#text(" (i.e. the ")#link("http://en.wikipedia.org/wiki/Least_squares")[#text("method of least squares")]#text("). Out of all the possible functions f which match the given data, find the one of least energy, i.e. which minimises the ")#mi("l^2")#text(" norm ")#tao-math("\\left\\|f\\right\\|_{l^2} := (\\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|f(x)\\right|^2)^{1/2}", block: false)#text(". This method has the advantage (unlike 1 and 2) of being extremely easy to carry out; indeed, the minimiser is given explicitly by the formula ")#mi("f(x) = \\frac{1}{\\sqrt{N}} \\sum_{\\xi \\in \\Lambda} c_\\xi e^{2\\pi i x \\xi/N}")#text(". Unfortunately, this minimiser not guaranteed at all to be S-sparse, and indeed the uncertainty principle suggests in fact that the ")#mi("l^2")#text(" minimiser will be highly non-sparse.")]
)

#text("So we have two approaches to Q2 which work but are computationally infeasible, and one approach which is computationally feasible but doesn’t work. It turns out however that one can take a “best of both worlds” approach halfway between method 2 and method 3, namely:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#mi("l^1")#text(" ")#strong[#text("minimisation")]#text(" (or ")#emph[#text("basis pursuit")]#text("): Out of all the possible functions f which match the given data, find the one of least energy, i.e. which minimises the ")#mi("l^1")#text(" norm ")#tao-math("\\left\\|f\\right\\|_{l^1} := \\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|f(x)\\right|", block: false)#text(".")
]

#text("The key difference between this minimisation problem and the ")#mi("l^0")#text(" problem is that the ")#mi("l^1")#text(" norm is ")#emph[#text("convex")]#text(", and so this minimisation problem is no longer NP-hard but can be solved in reasonable (though not utterly trivial) time by ")#link("http://en.wikipedia.org/wiki/Convex_optimization")[#text("convex programming")]#text(" techniques such as the ")#link("http://en.wikipedia.org/wiki/Simplex_algorithm")[#text("simplex method")]#text(". So the method is computationally feasible; the only question is whether the method actually works to recover the original S-sparse function f.")

#text("Before we reveal the answer, we can at least give an informal geometric argument as to why ")#mi("l^1")#text(" minimisation is more likely to recover a sparse solution than ")#mi("l^2")#text(" minimisation. The set of all f whose Fourier coefficients match the observed data ")#mi("c_\\xi")#text(" forms an affine subspace of the space of all functions. The ")#mi("l^2")#text(" minimiser can then be viewed geometrically by taking ")#mi("l^2")#text(" balls (i.e. Euclidean balls) centred at the origin, and gradually increasing the radius of the ball until the first point of contact with the affine subspace. In general, there is no reason to expect this point of contact to be sparse (i.e. to lie on a high-codimension coordinate subspace). If however we replace ")#mi("l^2")#text(" with ")#mi("l^1")#text(", then the Euclidean balls are replaced by octahedra, which are much “pointier” (especially in high dimensions) and whose corners lie on coordinate subspaces. So the point of first contact is now much more likely to be sparse. The idea of using ")#mi("l^1")#text(" as a “convex relaxation” of ")#mi("l^0")#text(" is a powerful one in applied mathematics; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2238069")[#text("this article")]#text(" on the topic.")

#text("It turns out that if ")#mi("\\Lambda")#text(" and f are structured in a perverse way, then basis pursuit does not work (and more generally, any algorithm to solve the problem is necessarily very unstable). We already saw the Dirac comb example, which relied on the composite nature of N. But even when N is prime, we can construct pseudo-Dirac comb examples which exhibit the problem: if f is for instance a discretised bump function adapted to an arithmetic progression such as ")#mi("\\{ -\\lfloor \\sqrt{N} \\rfloor, \\ldots, \\lfloor\\sqrt{N}\\rfloor\\}")#text(", then elementary Fourier analysis reveals that the Fourier transform of f will be highly concentrated (though not completely supported) on a dual progression (which in the above example will also be basically ")#mi("\\{ -\\lfloor \\sqrt{N} \\rfloor, \\ldots, \\lfloor\\sqrt{N}\\rfloor\\}")#text(", and have a rapidly decreasing tail away from this progression. (This is related to the well-known fact that the Fourier transform of a ")#link("http://en.wikipedia.org/wiki/Schwartz_space")[#text("Schwartz function")]#text(" is again a Schwartz function.) If we pick ")#mi("\\Lambda")#text(" to be far away from this progression – e.g. ")#mi("\\Lambda = \\{ \\lfloor N/3 \\rfloor,\\ldots,\\lfloor 2N/3 \\rfloor\\}")#text(", then the Fourier transform will be very small on ")#mi("\\Lambda")#text(". As a consequence, while we know abstractly that exact reconstruction of f is possible if N is a large prime assuming infinite precision in the measurements, any presence of error (e.g. roundoff error) will mean that f is effectively indistinguishable from the zero function. In particular it is not hard to show that basis pursuit fails in general in this case.")

#text("The above counterexamples used very structured examples of sets of observed frequencies ")#mi("\\Lambda")#text(", such as arithmetic progressions. On the other hand, it turns out, remarkably enough, that if instead one selects ")#emph[#text("random")]#text(" sets of frequencies ")#mi("\\Lambda")#text(" of some fixed size ")#tao-math("\\left|\\Lambda\\right|", block: false)#text(" (thus choosing uniformly at arndom among all the ")#tao-math("\\binom{N}{\\left|\\Lambda\\right|}", block: false)#text(" possibilities), then things become much better. Intuitively, this is because all the counterexamples that obstruct solvability tend to have their Fourier transform supported in very structured sets, and the dichotomy between structure and randomness means that a random subset of ")#mi("{\\Bbb Z}/N{\\Bbb Z}")#text(" is likely to contain a proportional fraction of all structured sets. One specific manifestation of this is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Uniform Uncertainty Principle")]#text(" (UUP): If Lambda is a random set with ")#tao-math("\\left|\\Lambda\\right| \\gg S \\log^4 N", block: false)#text(", then with overwhelming probability (at least ")#mi("1 - O(N^{-A})")#text(" for any fixed A), we have the approximate local Plancherel identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_{\\xi \\in \\Lambda} \\left|\\hat f(\\xi)\\right|^2 \\approx \\frac{\\left|\\Lambda\\right|}{N} \\sum_{x \\in {\\Bbb Z}/N{\\Bbb Z}} \\left|f(x)\\right|^2", block: true)]]

#text("for all 4S-sparse functions f, where by ")#mi("X \\approx Y")#text(" we mean that X and Y differ by at most 10%. (N is not required to be prime.)")
]

#text("The above formulation is a little imprecise; see ")#link("http://arxiv.org/abs/math.CA/0410542")[#text("this paper")]#text(" (which had ")#mi("\\log^6 N")#text(" instead of ")#mi("\\log^4 N")#text(") or ")#link("http://arxiv.org/abs/math/0602559")[#text("this one")]#text(" for more rigorous versions. This principle asserts that if the random set ")#mi("\\Lambda")#text(" is just a little bit bigger than S (by a couple logs), then it is not possible for the Fourier transform of an S-sparse function to avoid ")#mi("\\Lambda")#text(", and moreover the set ")#mi("\\Lambda")#text(" must receive its “fair share” of the ")#mi("l^2")#text(" energy, as predicted by Plancherel’s theorem. The “uniform” nature of this principle rests of the fact that it applies for ")#emph[#text("all")]#text(" S-sparse functions f, with no exceptions. For a single function f, this type of localisation of the Plancherel identity is quite easy to prove using ")#link("http://en.wikipedia.org/wiki/Chernoff%27s_inequality")[#text("Chernoff’s inequality")]#text(", and uses the same phenomena that explain why ")#link("http://en.wikipedia.org/wiki/Monte_Carlo_integration")[#text("Monte Carlo integration")]#text(" is so effective. To extend this to all sparse f, the main strategy (first used in this type of context ")#link("http://www.ams.org/mathscinet-getitem?mr=989397")[#text("by Bourgain")]#text(") is to exploit the fact that the set of sparse f has low ")#link("http://mathworld.wolfram.com/KolmogorovEntropy.html")[#text("metric entropy ")]#text("and so can be described efficiently by a relatively small number of functions. (The principle cannot possibly extend to ")#emph[#text("all")]#text(" functions f, since it is certainly possible to create non-zero functions whose Fourier transform vanishes everywhere on ")#mi("\\Lambda")#text(".)")

#text("By using this principle (and variants of this principle), one can indeed show that basis pursuit works:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem")]#text(" [")#link("http://www.ams.org/mathscinet-getitem?mr=2236170")[#text("CRT")]#text("], [")#link("http://arxiv.org/abs/math.CA/0410542")[#text("CT")]#text("]. Suppose ")#mi("\\Lambda")#text(" is a random set with ")#tao-math("\\left|\\Lambda\\right| \\gg S \\log N", block: false)#text(". Then any given S-sparse function f will be recovered exactly by ")#mi("l^1")#text(" minimisation with overwhelming probability. If one makes the stronger hypothesis ")#tao-math("\\left|\\Lambda\\right| \\gg S \\log^4 N", block: false)#text(", then with overwhelming probability ")#emph[#text("all")]#text(" S-sparse functions will be recovered exactly by ")#mi("l^1")#text(" minimisation. (Again, N is not required to be prime.)")
]

#text("Roughly speaking, the idea in the latter result is to use the UUP to show that the Fourier coefficients of any sparse (or ")#mi("l^1")#text("-bounded) competitor with disjoint support to the true S-sparse solution is going to be rather orthogonal to the true solution, and thus unlikely to be present in an ")#mi("l^1")#text(" minimiser. The former result is more delicate and combinatorial, and requires computing high moments of random Fourier minors.")

#text("The method is rather robust; there is some ")#link("http://www.arxiv.org/abs/math.NA/0503066")[#text("followup work")]#text(" which demonstrates stability of the basis pursuit method with respect to several types of noise. See also the ")#link("http://www.acm.caltech.edu/~emmanuel/papers/CompressiveSampling.pdf")[#text("ICM proceedings article of Emmanuel Candes")]#text(" for a recent survey. It can also be abstracted from this toy Fourier problem to a more general problem of recovering sparse or compressible data from few measurements. As long as the measurement matrix obeys an appropriate generalisation of the UUP, the basis pursuit methods are quite effective (both in theory, in numerical experiments, and more recently in laboratory prototypes).")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (43)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-489")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2007")])]

#text("Thank you for this post. I am not a mathematician so please forgive my ignorance on that subject matter but you said:")

#text("“..For a single function f, this type of localisation of the Plancherel identity… uses the same phenomena that explain why Monte Carlo integration is so effective.”")

#text("Do you mean to say that Monte Carlo integration is working well because the function to be integrated is sparse ? In the affirmative, does this mean that if I were to know better the sparsity of a function to be integrated using a Monte Carlo technique, I could, in principle, accelerate the convergence rate of that integration ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-493")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2007")])]

#text("Dear Igor,")

#text("Here we are summing the Fourier transform of f (or more precisely, ")#tao-math("\\left|\\hat f(\\xi)\\right|^2", block: false)#text(") rather than f itself. The uncertainty principle tells us that as f is sparse, the Fourier transform of f should be “smooth” or “structured” (or “low complexity”). For these types of functions, Monte Carlo integration works rather well (though there are other integration schemes that are even faster).")

#text("Compressed sensing methods are only moderately fast from a computational perspective; their main strength lies in the fact that they can give accurate results (after reasonable amounts of computation) from relatively small amounts of data; they are thus valuable in situations where computation is relatively cheap but measurement is expensive. These types of algorithms, for instance, would allow one to compute the integral of a function f exactly (not just approximately) if one knew that the ")#emph[#text("Fourier transform")]#text(" of f was sparse, and one sampled f at a fairly small number of randomly chosen values. (In fact, one would recover all of f, not just its integral.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-496")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2007")])]

#text("Thank you for your time.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e14070aaf61842c0399191a9bb95788359f444b55267237580b942af839d574f-5dbdb8aba3911f781f4bd724deb9f69ac307ad1183c7a744942ebc691dd981f2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Weiyu Xu")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-582")[#strong[#text("Weiyu Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2007")])]

#text("It is very nice to see you remain active in the compressive sensing area.")#linebreak()#text(" This topic is very interesting, but I would like to know what open problems still look interesting to the applied mathematics and singal processing society? It seems to me that most have been done,… I would appreciate it if you can share with us your opinions about the future directions of the compressive sensing area.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-591")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2007")])]

#text("Dear Weiyu,")

#text("It appears to me that research in this area is now being primarily driven by fairly concrete applications (imaging, MRI, etc.) rather than by theory; in particular, there is a lot of work on efficient implementation of algorithms, numerical simulation, testing on real-world signals, etc. But there are still some interesting theoretical questions of a rather vague and broad nature – these types of applied fields don’t seem to lend themselves to the kind of precise conjectures one sees in pure mathematics. One is derandomisation; all of the measurement ensembles for which the really strong compressed sensing results are known have to be generated by a random process; no deterministic compressed sensing method which is rigorously backed by theory is known. Another question is to see whether one can improve the two basic algorithms of basis pursuit and matching pursuit and obtain better results (in either accuracy, speed, or robustness); given the lack of lower bounds in this subject it is difficult to tell how close the current algorithms are to being optimal. A third is to relax the hypotheses on the measurement ensemble, in particular to allow for some limited amount of linear dependence (or near-dependence) between columns of the measuremement matrix.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c52500db607fab6649ed8557f2a07c09ac30206e6e19a14b2202a31c54befa5f-1e4b9156ba89931a5d769d6a3a0f48d01e56ee45624f27ee4ded09f91369f10a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sri Hari")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-609")[#strong[#text("Sri Hari")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2007")])]

#text("Dear Tao,")

#text("I am novice in the field of mathematics and I want to ask what do you mean by “degrees of freedom” of a function space ? Is it the number of complex exponentials which make the signal I mean is it the dimension of the Fourier basis?")

#text("Thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-632")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2007")])]

#text("In this case, yes. More generally, degrees of freedom refer to the number of independent real numbers one needs to fully describe the state of an object; it can be made precise with various mathematical notions of “dimension” but in this post I am using it mostly in an informal heuristic sense.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oz")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-659")[#strong[#text("oz")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Thanx a lot for two very interesting posts.")

#text("I have a problem which appears to be conceptually similar to the ‘compressed sensing’ problems.")#linebreak()#text(" The problem is finding a sparse convex representation:")

#text("Suppose you’re given m points a_1,.., a_m in R^n with m > > n.")#linebreak()#text(" You’re also given a point b which is a sparse convex combination of the points, i.e. b = \\sum_{i} x_i a_i where the x_i’s are non-negative and sum to one, and only k of them are non-zero (k < n, but still too large to enumerate all sets of k points …). The goal is to find the weights x –")#linebreak()#text(" this amounts to finding a sparse positive solution for Ax=b, (here A is the matrix whose columns are a_1,..,a_m) so to me it looks like the setting mentioned in the post, and my guess is that the two approaches (i.e. ‘greedy’ and ‘convex optimization’) could work here.")

#text("Any suggestions/known results for this problem?")

#text("Thanx,")#linebreak()#text(" oz")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-661")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2007")])]

#text("Dear Oz,")

#text("Assuming that the a_1,…,a_m are dispersed more or less randomly, it seems that one can simply plug in either of the two algorithms mentioned above to find a sparse solution to Ax=b. It is not ")#emph[#text("a priori")]#text(" positive, but if k < < n and the a_1,…,a_m are in general position then there can be at most one k-sparse solution, so if a k-sparse positive solution exists, this method will find it (assuming that the hypotheses necessary for the reconstruction method to work are satisfied, of course).")

#text("One could add the positivity constraints to the linear program one solves for the basis pursuit method, but my guess is that this will not significantly improve performance, though one should try some numerical experiments both ways to see if this is the case.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/089af42b6de33865363accf89896726d69fbff5dbad8131d978f116cc1c48f6c-bdd943e2ac8103b7a611b6b9cd1bbf72ce462d5f55e40845e23397804164b1b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Utpal Sarkar")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-746")[#strong[#text("Utpal Sarkar")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2007")])]

#text("Dear Terence,")

#text("Do you know if your uncertainty principle for cyclic groups of prime order generalizes to general finite abelian groups if you restrict to functions whose support is not contained in any proper subgroup?")

#text("Thanks,")

#text("Utpal")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-748")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2007")])]

#text("Dear Uptal,")

#text("That’s an interesting question; I don’t have any counterexample to your conjecture (though one should probably look first at ")#mi("{\\Bbb Z}/p{\\Bbb Z} \\times {\\Bbb Z}/2{\\Bbb Z}")#text("). As I said in the main post, the best uncertainty principle for arbitrary groups known is ")#link("http://arxiv.org/abs/math/0312407")[#text("by Meshulam")]#text(", and it is not well understood exactly how sharp his estimates are (though I believe they are quite sharp for p-groups). Such a result also seems consistent with Kneser’s theorem (just as the Cauchy-Davenport inequality is a consequence of the uncertainty principle in the prime order case, as discussed in ")#link("http://front.math.ucdavis.edu/math.CA/0308286")[#text("my own paper")]#text("); in the best case scenario, it would provide a new proof of Kneser’s theorem, which would be very worthwhile.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d8dc5ed1b08e183dc7de91bc78b11d018df408b7563ea33898aa2e9dcd6f171-72fdbc2a2444b09305d7141a001a31089a7831bdbbf023dc6e6ef0819d793f48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sadegh Jokar")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-785")[#strong[#text("Sadegh Jokar")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2007")])]

#text("Dear Terence,")

#text("CS is really interesting. I am working on this topic and your joint paper with Emmanuel is really useful and important. I have some questions about that.")

#text("I am wondering if UUP is also holds for Wavelets? If it holds, could you please give me a reference for that?")

#text("Also another question is that are Fourier+Wavlets satisfying on RIP conditon?")#linebreak()#text(" If yes could you let me know what is \\delta_k in that case or where can I find the proof of this fact?")

#text("Third question is that it appear to me that for given matrix A, to check that A satisfies on RIP conditon is NP-Hard. Is there any methods to check for special class of matrices that this matrices are satisfying in this condition or not? It looks to me similar to finding the sparsest solutiond of underdetermined linear system in some cases using tractable BP method.")

#text("Also as last question, if for given $k $, $A$ has RIP constant $\\delta_k$ and $B$ has RIP constant $\\beta_k$, can someone say something about the RIP constant of $A+B$ in terms of $\\delta_k$ and $\\beta_k$ and some additional information about $A^TB$?")

#text("I will be appreciate, if you could help me to find the solutions for these questions?")

#text("Thanks.")#linebreak()#text(" Sadegh")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-787")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2007")])]

#text("Dear Sadegh,")

#text("I believe the wavelet basis does not have good UUP type properties with regard to signals that are sparse in the Dirac basis, because the fine wavelet coefficients have too much correlation with some members of the Dirac basis. (There are some general results of Candes and Romberg which show that the UUP holds for random samples of a basis if there are no large correlations between that elements of that basis and elements where the signal is suspected to be sparse.)")

#text("For Fourier-Wavelet I think there is a similar problem with the very coarse wavelets, which are quite concentrated in the Fourier side. Of course, Gaussian-wavelet is OK, because a Gaussian matrix composed with any other matrix is still basically a Gaussian matrix.")

#text("It is an open problem (which I was intending to blog about at some point) to find a non-trivial class of matrices for which the UUP property can be detected in a reasonable amount of time (e.g. in polynomial time). By non-trivial, I mean that there is a non-zero probability that the matrix actually has the UUP property. In particular, no determinstic example of large UUP matrices are known in which there are significantly more columns than rows. (An orthonormal matrix obeys UUP but this is rather uninteresting, and must have at most as many columns as rows.)")

#text("As for sums of matrices, one only has really good bounds on the singular values of A+B (and hence on the RIP type constants) in terms of those of A and B if one of the two matrices A, B is very small; so there should be some results about the stability of RIP or UUP under small perturbations, but when summing two large matrices together, virtually anything can happen.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8d8dc5ed1b08e183dc7de91bc78b11d018df408b7563ea33898aa2e9dcd6f171-72fdbc2a2444b09305d7141a001a31089a7831bdbbf023dc6e6ef0819d793f48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sadegh")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-921")[#strong[#text("Sadegh")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2007")])]

#text("Dear Terence,")

#text("Thanks a lot for your useful comments and your response.")#linebreak()#text(" About my question on RIP.")#linebreak()#text(" Except Fourier, do you know another deterministic dictionary that satisfied in RIP condition with small delta?")#linebreak()#text(" or do you have any guess, which dictionary should have small RIP constant?")#linebreak()#text(" It seems that for deterministic case, there are not so many examples that have small RIP constant.(Fourier and cyclic matrices constructed by De Vore)")

#text("Thanks again for your time,")

#text("Sadegh")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/77f9004a8070308449beff2e26c64ca4419b100dd84939568144a0d44a9cee93-fab60cc3b4a847ca501e3921f49dc33f5bc8c7b5a51d285abb185f746126f523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peyman Milanfar")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-2057")[#strong[#text("Peyman Milanfar")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2007")])]

#text("Dear Terence,")

#text("I wonder if the CS reconstruction results generalize to the case where the signal of interest is under-sampled. That is to say, if the Fourier spectrum contains aliasing artifacts as a result of sampling below the Nyquist rate, can one say anything about the possibility of accurate reconstruction from a sparse set of spectral data?")

#text("Thanks,")#linebreak()#text(" Peyman")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-2064")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 June 2007")])]

#text("Dear Peyman,")

#text("I’m not sure I understand your question. If you are sampling below the Nyquist rate, then any two frequencies which are aliased to each other will be indistinguishable even if one has a full set of measurements, so certainly they will also be indistinguishable in a CS framework when one only has a partial set of measurements. However, one can still reconstruct the Fourier coefficients up to aliasing by the usual CS methods, if the number of measurements one takes exceeds the sparsity of the Fourier coefficients by a sufficiently large factor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peyman Milanfar")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-2212")[#strong[#text("Peyman Milanfar")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2007")])]

#text("Thanks, you answered my question. I wanted to know whether there was anything technical that would prevent the reconstruction results from being valid (up to aliasing).")

#text("Cheers,")#linebreak()#text(" Peyman")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8586b8fdaabd6702ead9f6479812b3c1c06b1816eaf01e29ec157da9c3ecdb81-4ebf1bdac9a89a0868225ec388d3e30682328ed652819b5723a6132ac2283463.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ajay Bangla")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-2807")[#strong[#text("Ajay Bangla")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2007")])]

#text("Dear Prof. Terence,")

#text("Thank you for this approachable article.")

#text("Prof. Candes in the paper titled ”Compressive Sampling” comments that the dual of the phenomenon of reconstructing a S sparse signal from its partial Fourier coefficients can be interpreted as a new non-linear sampling theorem. By dual I mean that the signal is S sparse in frequency domain and we collect K random time samples. This new sampling theorem can be seen as a generalization on the Nyquist sampling theorem which assumes that the support set in frequency domain in connected.")

#text("Assume that we are given a set of K randomly picked time samples. If S <K/2, then we have a unique solution. If S> K/2, then we have")#linebreak()#text(" multiple(possibly infinite) solutions consistent with the given")#linebreak()#text(" measurements. These solutions can be considered as aliases of the the")#linebreak()#text(" sparsest solution. For Nyquist sampling the aliasing signals have a")#linebreak()#text(" simple relation. Can we expect the aliases to have a structured relation")#linebreak()#text(" in this case as well? Something like all the aliases have their support")#linebreak()#text(" size/lp norm differing by a multiple of some constant.")

#text("thanks,")#linebreak()#text(" Ajay")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-2812")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2007")])]

#text("Dear Ajay,")

#text("It is true that S < K/2 is the theoretical limit for guaranteed unique recovery, but in practice all known algorithms break down a little bit before this threshold, typically requiring a condition such as S < cK for some small absolute constant c (c = 0.2 is typical). Not much is known about what happens beyond this threshold. Once S > K, then the problem becomes genuinely underdetermined and there are of course many solutions; for any given set of S frequencies, then (assuming we are doing a DFT on a cyclic group of prime order), we can always find infinitely many solutions supported on those frequencies to match K given measurements, in fact there is an S-K dimensional linear space of solutions.")

#text("It is conceivable that for S slightly larger than K/2 that one may still have ")#emph[#text("generic")]#text(" unique recovery, even if unique recovery fails in the worst case. There are however no rigorous results in this direction, and certainly no knowledge about the structure of the solution set.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8586b8fdaabd6702ead9f6479812b3c1c06b1816eaf01e29ec157da9c3ecdb81-4ebf1bdac9a89a0868225ec388d3e30682328ed652819b5723a6132ac2283463.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ajay Bangla")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-2815")[#strong[#text("Ajay Bangla")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2007")])]

#text("Dear Prof. Terence,")

#text("Thank you for your response.")

#text("If there is a structure on the solution set, then may be we could have an extension to compressed sensing analogous to the bandpass sampling theorem wrt the Nyquist theorem. One way to put this is if S sparse signals can be recovered using K measurements, then what can we say about recovery of signals with at most S zero coefficients with the same K measurements. It does look like a hopeless case as now there is N-S-K dimensional linear space of solutions. I guess one way to address this new problem would be swap the measurement & synthesis basis. For the time being, let us not worry about the recovery algorithms.")

#text("thanks,")#linebreak()#text(" Ajay")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kelly")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-10732")[#strong[#text("Kelly")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2007")])]

#text("Dear Terence,")

#text("I recently read some papers on Compressive Sensing. It is a very interesting subject.")

#text("I am thinking of applying it to single frame super-resolution. My idea is that low-resolution image is undersampled somehow from high-resolution image, although lack of data, we might somehow by solving some l1 norm problem to recover it by applying the idea of CS. Can you highlight on this problem?")

#text("And by the way, there is a reweighted l1 norm algorithm, which actually transform l1 norm problem to “pseudo l0 norm problem”(in my opinion). In that algorithm, one just reweight xi by abs(x(i-1)). I saw some numerical experiments on that algorithm and found it promising. Can you comment on this algorithm? How about the efficiency of that algorithm?")

#text("Thanks~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-10778")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear Kelly,")

#text("If the low-resolution image is sampled in physical space (e.g. sampling the image at an equally spaced set of points) then one unfortunately runs into significant aliasing problems and compressed sensing methods are ineffective; they do not find a way to evade the Shannon limit, for instance. CS only works when you take measurements in a basis which is extremely “skew” with respect to the basis in which your data is known or suspected to be sparse or compressible. Even then, one of course cannot obtain a accurate resolution which has higher entropy than the number of observed measurements, regardless of how fancy one’s algorithms are.")

#text("I am not so familiar with the algorithmic aspects of l^1 minimisation, but it seems to me that you are giving up one of the key advantages of the l^1 minimisation problem – namely, convexity – for an uncertain benefit. All the really fast algorithms for solving l^1 minimisation that I know of rely crucially on convexity at one point or another, but there could of course be other methods for solving this problem also. (But if convexity is no longer required in the recovery algorithm, then one could replace l^1 by norms with better CS properties, e.g. l^p for p < 1.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d673d9b3e9ff664b048a243397f1756f4cfaee98f073b4186a1396d6da741ac-38cab0c5d213f9c1aa1f47d8a8c3a19490ed36bd7997a03dda17e6c9535e88b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Igor Carron")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-14166")[#strong[#text("Igor Carron")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2007")])]

#text("Dear Terence,")

#text("Following up on Kelly’s question, if giving up convexity seems to be providing a more rapid reconstruction technique, how do you think this heuristic of seemingly always finding a global minimum will ever rely on more sound mathematics ?")

#text("Case in point:")

#text("Emmanuel Candes and Mike Wakin and Stephen Boyd have devised the Reweighted L1 algorithm :")

#link("http://www.eecs.umich.edu/~wakin/papers/rwl1-oct2007.pdf")[#text("Click to access rwl1-oct2007.pdf")]

#text("while")

#text("Rick Chartrand and Wotao Yin have devised a Reweighted Lp (p<1) algorithm which seems to perform even better than the reweighted L1:")

#link("http://math.lanl.gov/Research/Publications/Docs/chartrand-2008-iteratively.pdf")[#text("Click to access chartrand-2008-iteratively.pdf")]

#text("Igor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-27864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear Professor Tao,")

#text("I am reading your paper “Decoding by linear programming”. Here is a question, in Lemma 2.1 and 2.2, you show that the inner product of w and v_i,")#linebreak()#text(" =c_i for i \\in T")

#text("Is this what you really want to prove? Coz in the beginning of Section II, property i) says you wanna show")

#text("=sign(c_i) for i \\in T")

#text("Need your help, thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-27868")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear anonymous,")

#text("For applications, one would apply Lemma 2.1 and 2.2 with ")#mi("c_i")#text(" replaced by the sign vector ")#mi("\\text{sgn}(c_i)")#text(" (see e.g. the applications of these lemmas on page 11). But in order to prove these lemmas it is more convenient to work with more general vectors than sign vectors.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-27869")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear Prof. Tao,")

#text("Thank you for your reply.")

#text("Lemma 2.1 and 2.2 show that a vector w can be found s.t. the inner product of w and v_i is equal to c_i for i \\in T. (1)")

#text("However, what is needed in the proof on page 11 is a vector w, s.t. the inner product of w and v_i is equal to sign(c_i) for i \\in T. (2)")

#text("I don’t see why (1) is more general than (2). i.e. I don’t quite understand how I can apply lemma (2.1) (2.2) to find a vector w such that properties i) and ii) are satisfied.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-27870")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear Anonymous,")

#text("Lemma 2.1 and Lemma 2.2 are valid for any vector c_i. In particular, one can substitute a sign vector, say ")#mi("c_i := \\text{sign}(c^{\\prime}_i)")#text(", for that vector as a special case of those two lemmas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-27871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2008")])]

#text("Dear Prof. Tao,")

#text("Thank you so much! You are right.")

#text("BTW, it’s a great paper!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The uniform uncertainty principle and compressed sensing « What’s new")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-33760")[#strong[#text("The uniform uncertainty principle and compressed sensing « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2008")])]

#text("[…] principle and compressed sensing“. The content of this talk overlaps substantially with my Ostrowski lecture on the same topic; the slides I prepared for the Seville lecture can be found […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Markus")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-34099")[#strong[#text("Markus")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Dear Terence,")

#text("i have a question about your paper “robust uncertainty principles : …”")

#text("and especially concerning application of the theoretical results in that paper for reconstructing a 2d image with sparse gradient.")#linebreak()#text(" you reconstruct such an object by minimizing the total variation of image $f(t_1, t_2)$ subject to measurement constraints.")#linebreak()#text(" in one dimension you show the how exact recovery results (of sparse objects) with $l^1$ minimization imply exact recovery (of objects with sparse gradient) with TV minimization. is there a similar argument also for higher dimension?")

#text("another question:")#linebreak()#text(" in the main theorem the high probability of exact recovery is stated for fixed $f$. does this theorem also hold in a form like “choose $\\Omega$ at random, then with high probability this set is such that any $f$ with small support is reconstructed exactly”")#linebreak()#text(" or a form like “fix $\\Omega$ and choose sparse $f$ in some random manner, then with high probability it is reconstrcted exactly”")

#text("best regards, markus")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-34106")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Dear Markus,")

#text("The TV norm is basically the l^1 norm of the (discretised) gradient nabla f of f, and so one can deduce exact recovery of TV norm for signals of sparse gradient from the general theory of exact recovery of l^1 norms for sparse signals [one has to extend this theory to vector-valued signals, since the gradient is a vector, but this is routine]. (Note that the gradient is not free to range over all possible vector-valued signals, as it must be “curl-free” in some sense, but this restriction does not cause any trouble – if a signal is already a global minimiser without this restriction, and obeys that restriction, then it is certainly also a minimiser with the restriction in place.)")

#text("As for the second question, the recovery result is of the former type (in contrast to our first paper with Justin, which gave a result of the second time). Indeed, once the measurement matrix obeys the RIP (which we call the UUP in that paper), the rest of the arguments are deterministic and one gets exact recovery for all sparse signals. The only place randomness comes in is in ensuring the RIP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Markus")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-34133")[#strong[#text("Markus")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2008")])]

#text("Dear Terence,")

#text("thank you for the reply!")

#text("do I understand correctly that on could argue for (possibly non-Fourier) Matrix F as follows: assume $D F = F nabla $ for some linear D,")#linebreak()#text(" replace in $ min_x ||nabla x||_1 s.t. F x = y $ gradient $nabla x$ by z and then solve $ min_z ||z||_1 s.t. F z = D y $")#linebreak()#text(" in the case that F = Fourier-matrix, D would be something like mulitplication with (i* omega_1, i*omega_2)")

#text("to your second reply, thanks i found the related discussion in sec. 5 of your paper with e.c. “decoding by linear programming”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa915471efffca12233a1d98055ec739d38378154a31fb43f89e18b943789a8e-422690beaaa84c8c83f76b7a8b73ef1e019ade414e88fcae381c0f07a8964697.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giannis")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-42396")[#strong[#text("Giannis")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2009")])]

#text("Dear Prof. Tao,")

#text("I am new to the concept of CS and I am very excited about the theory behind it and of course about its applications.")#linebreak()#text(" I am curious to know if the theory can provide us with some metric of the sparsity of a known signal. Precisely the inequality of UUP that constrains the norm of a sparse projected signal doesn’t tell us about non-sparse signals. What happens then to their projections? Can we infer if a signal is sparse just by the projections?")

#text("Best regards,")

#text("Giannis Chantas, Phd")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eed083050ff622e87e285263270968c6c3c3319a3dfdd89740afd84e3bc8cd8f-cb3067cdccd373bea64b62cc339cce8e3253c1f88663269964c14b4d331f056e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohammad")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-47222")[#strong[#text("Mohammad")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2010")])]

#text("I’m working on the application of CS in OFDM systems. One of the issues I encountered is as follows: Since pilots are used as")#linebreak()#text(" the information, random selection of the rows of the FFT matrix can not be used and a deterministic approach should be used. There are some papers about deterministic selection of the FFT matrix, but they all suggested to use cyclic difference sets (CDS) for the selection of the rows of the FFT matrix. This approach is not practical since there is no CDS for practical values of FFT matrix (like N=64, 256, …)")

#text("Are you aware of any other deterministic way to select the rows of FFT matrix or this is an open problem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-69393")[#strong[#text("On Understanding Probability Puzzles | Nair Research Notes")]]#text(size: 9pt, fill: rgb("596477"), " · 22 August 2011")]

#text("[…] the difference when seen from an experimental point of view. Here is the statement taken from Tao’s blog. In the theorem below, the signal , thought of as a complex vector of size . And is the set of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-73905")[#strong[#text("Controlled Complexity · The Low Rank and Sparsity Technique for Data Recovery")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2011")]

#text("[…] uncertainty principle also plays a crucial role in compressive sensing. See Tao’s blog for more on this. So far, we have a condition on which guarantees , i.e., the sparse tangent space […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-226295")[#strong[#text("Effective Financial Theories | Research Notebook")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2013")]

#text("[…] sensing and was introduced by Candes and Tao (2005) and Donoho (2006). See Terry Tao’s blog post for an excellent introduction. For example, suppose that only the first stock had high returns of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-231346")[#strong[#text("How signals, geometry, and topology are influencing data science - Strata")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2013")]

#text("[…] are complex but geometric intuition can be used to explain some of the key ideas, as explained here by Tao. (3) I encountered another strand of manifold learning, used for semi-supervised learning, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6b8290bd74c2ee08e20bb747ad1a8be3d41135668a2d6dc7f36ce9c0b70bdf4d-95abbfad74fe0d47ad3bdcf7bbcd973e00e7015907541db3e08a68d43fbff6e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Khalida")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-247685")[#strong[#text("Khalida")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2013")])]

#text("Sir,")#linebreak()#text(" I would like to know what is principle of “Compressed Sensing” please post it Sir.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ba7cbee5f26f6049e865ee2b437ad02d0b268cde3c6f194db10084eab5240d28-a5c14c3c4cb40964a001048dd1e64ebe5330a0e6438793f6b2832cae7a78c577.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of How signals, geometry, and topology are influencing data science | The Gradient Flow")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-266152")[#strong[#text("How signals, geometry, and topology are influencing data science | The Gradient Flow")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2014")])]

#text("[…] are complex but geometric intuition can be used to explain some of the key ideas, as explained here by Tao. (3) I encountered another strand of manifold learning, used for semi-supervised learning, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/915d2ca3efed20cb37d633eb4f1699d0482c459c492eb81e365b06df19793837-e3ed552e9d225e1906b36ceed62291899e7815f2163770bdc4246252e4886dd2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wang Jing")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-428899")[#strong[#text("Wang Jing")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2014")])]

#text("Dear Professor Tao,")

#text("I am reading the journal version of your paper “Decoding by linear programming”. Can I ask some questions about the appendix “proof of lemma 2.2”:")#linebreak()#text(" 1. do you assume S = S’?")#linebreak()#text(" 2. applying lemma 2.1 iteratively, how can we get a sequence of vectors w_n+1? do we fix T_{n_1} to get an exception set as T_{n}? how can we get =")#linebreak()#text(" thank you~")

#text("Wang Jing")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-428926")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2014")])]

#text("There are some typos in the statement and proof of that lemma; in particular, some of the constants ")#mi("\\delta_S")#text(" in the paper should in fact be ")#mi("\\delta_{2S}")#text(", and when applying Lemma 2.1, ")#mi("T")#text(" should be ")#mi("T_0 \\cup T_n")#text(" and ")#mi("T_{n+1}")#text(" is the set ")#mi("E")#text(" produced from that lemma.")

#text("Note that sharper results to this paper have since been obtained, see")

#link("http://www-stat.stanford.edu/~candes/papers/RIP.pdf")[#text("Click to access RIP.pdf")]

#text("and")

#link("http://arxiv.org/abs/0911.1564")[#text("http://arxiv.org/abs/0911.1564")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/04/15/ostrowski-lecture-the-uniform-uncertainty-principle-and-compressed-sensing/#comment-429023")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2014")])]

#text("Thank you for your reply!")
]
]
]
