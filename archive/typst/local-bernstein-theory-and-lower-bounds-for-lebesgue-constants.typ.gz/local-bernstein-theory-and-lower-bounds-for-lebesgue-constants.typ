// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/
// Converted to Typst by tao2typ: "2026-10-14T11:15:41.308681+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Local Bernstein theory, and lower bounds for Lebesgue constants", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Local Bernstein theory, and lower bounds for Lebesgue constants")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 March 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/")[#text("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("https://arxiv.org/abs/2603.21453")[#text("Local Bernstein theory, and lower bounds for Lebesgue constants")]#text("“. This paper was initially motivated by a ")#link("https://www.erdosproblems.com/1153")[#text("problem of Erdős")]#text("} on Lagrange interpolation, but in the course of solving that problem, I ended up modifying some very classical arguments of Bernstein and his contemporaries (Boas, Duffin, Schaeffer, Riesz, etc.) to obtain “local” versions of these classical “Bernstein-type inequalities” that may be of independent interest.")

#text("Bernstein proved many estimates concerning the derivatives of polynomials, trigonometric polynomials, and entire functions of exponential type, but perhaps ")#link("https://en.wikipedia.org/wiki/Bernstein%27s_theorem_(polynomials)")[#text("his most famous inequality")]#text(" in this direction is:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Bernstein’s inequality for trigonometric polynomials)")]#text(" ")#metadata(none) <tao-d8f780825f78872fdbe1>#text(" Let ")#mi("{P: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a trigonometric polynomial of degree at most ")#mi("{n}")#text(", with ")#tao-math("{\\left|P(x)\\right| \\leq A}", block: false)#text(" for all ")#mi("{x}")#text(". Then ")#tao-math("{\\left|P^{\\prime}(x)\\right| \\leq n A}", block: false)#text(" for all ")#mi("{x}")#text(".")
]

#text("Similar inequalities concerning ")#mi("{L^p}")#text(" norms of derivatives of Littlewood-Paley components of functions are now ubiquitious in the modern theory of nonlinear dispersive PDE (where they are also called Bernstein estimates), but this will not be the focus of this current post.")

#text("A trigonometric polynomial ")#mi("{P}")#text(" of degree ")#mi("{n}")#text(" is of ")#emph[#text("exponential type ")#mi("{n}")]#text(" in the sense that ")#tao-math("{P(z) = O(\\exp(n\\left|z\\right|))}", block: false)#text(" for complex ")#mi("{z}")#text(". Bernstein in fact proved a more general result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Bernstein’s inequality for functions of exponential type)")]#text(" ")#metadata(none) <tao-46d8585dc86e757518af>#text(" Let ")#mi("{f: {\\bf C} \\rightarrow {\\bf C}}")#text(" be an entire function of exponential type at most ")#mi("{\\lambda}")#text(", with ")#tao-math("{\\left|f(x)\\right| \\leq A}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(". Then ")#tao-math("{\\left|f^{\\prime}(x)\\right| \\leq \\lambda A}", block: false)#text(" for all ")#mi("{x \\in {\\bf R}}")#text(".")
]

#text("There are several proofs of this lemma – see for instance ")#link("https://arxiv.org/abs/1903.10801")[#text("this survey of Queffélec and Zarouf")]#text(". In the case that ")#mi("{f}")#text(" is real-valued on ")#mi("{{\\bf R}}")#text(", there is a ")#link("https://zbmath.org/0018.40901")[#text("nice proof by Duffin and Schaeffer")]#text(", which we sketch as follows. Suppose we normalize ")#mi("{A=\\lambda=1}")#text(", and adjust ")#mi("{f}")#text(" by a suitable damping factor so that ")#mi("{f(z)}")#text(" actually decays slower than ")#tao-math("{\\exp(\\left|z\\right|)}", block: false)#text(" as ")#mi("{z \\rightarrow \\infty}")#text(". Then, for any ")#mi("{0 < \\alpha < 1}")#text(" and ")#mi("{x_0 \\in {\\bf R}}")#text(", one can use Rouche’s theorem to show that the function ")#mi("{\\cos(x-x_0) - \\alpha f(x)}")#text(" has the same number of zeroes as ")#mi("{\\cos(x-x_0)}")#text(" in a suitable large rectangle; but on the other hand one can use the intermediate value theorem to show that ")#mi("{\\cos(x-x_0) - \\alpha f(x)}")#text(" has at least as many zeroes than ")#mi("{\\cos(x-x_0)}")#text(" in the same rectangle. Among other things, this prevents double zeroes from occuring, which turns out to give the desired claim ")#tao-math("{\\left|f^{\\prime}(x)\\right| \\leq 1}", block: false)#text(" after some routine calculations (in fact one obtains the stronger bound ")#tao-math("{\\left|f(x)\\right|^2 + \\left|f^{\\prime}(x)\\right|^2 \\leq 1}", block: false)#text(" for all real ")#mi("{x}")#text(").")

#text("The first main result of the paper is to obtain localized versions of Lemma ")#link(<tao-46d8585dc86e757518af>)[#text("2")]#text(" (as well as some related estimates). Roughly speaking, these estimates assert that if ")#mi("{f}")#text(" is holomorphic on a wide thin rectangle passing through the real axis, is bounded by ")#mi("{A}")#text(" on the intersection of the real axis with this rectangle, and is “locally of exponential type” in the sense that it is bounded by ")#tao-math("{O(\\exp( \\lambda \\left|\\mathrm{Im} z\\right|))}", block: false)#text(" on the upper and lower edges of this rectangle (and obeys some very mild growth conditions on the remaining sides of this rectangle), then ")#tao-math("{\\left|f^{\\prime}(x)\\right|}", block: false)#text(" can be bounded by ")#mi("{\\lambda A}")#text(" plus small errors on the real line, with some additional estimates away from the real line also available. The proof proceeds by a modification of the Duffin–Schaeffer argument, together with the two-constant theorem of Nevanlinna (and some standard estimates of harmonic measures on rectangles) to deal with the effect of the localization. (As a side note, this latter argument was provided to me ")#link("https://chatgpt.com/share/69c40a06-81d4-83e8-a343-81ef49b0c4c4")[#text("by ChatGPT")]#text(", as I was not previously aware of the Nevanlinna two-constant theorem.)")

#text("Once one localizes this “Bernstein theory”, it becomes suitable for the analysis of (real-rooted, monic) polynomials ")#mi("{P}")#text(" of a high degree ")#mi("{n}")#text(", which are not bounded globally on ")#mi("{{\\bf R}}")#text(" (and grow polynomially rather than exponentially at infinity), but which can exhibit “local exponential type” behavior on various intervals, particularly in regions where the logarithmic potential")

#align(center)[#tao-fit-display[#tao-math("U_\\mu(z) := \\frac{1}{n} \\log \\frac{1}{\\left|P(z)\\right|} = \\int \\log \\frac{1}{\\left|z-x\\right|}\\ d\\mu(x)", block: true)]]

#text("behaves like a smooth function (here ")#mi("{\\mu = \\frac{1}{n} \\sum_{j=1}^k \\delta_{x_j}}")#text(" is the empirical measure of the roots ")#mi("{x_1,\\dots,x_n}")#text(" of ")#mi("{P}")#text("). A key example is the (monic) Chebyshev polynomials ")#mi("{2^{1-n} T_n(x)}")#text(", which locally behave like sinusoids on the interval ")#mi("{[-1,1]}")#text(" (and are locally of exponential type above and below this interval):")

#image("../assets/c38cbddf4d44ffa3041332630e12bc41f8261cb744cf8127f51959b5ed4f1b3c-b11d835320b9b74f1b9b90d974bbfd452e2ac93f00e4faf9544a2fefa9900780.png", width: 90%)

#text("This becomes relevant in the theory of Lagrange interpolation. Recall that if ")#mi("{x_1 < \\dots < x_n}")#text(" are real numbers and ")#mi("{Q}")#text(" is a polynomial of degree less than ")#mi("{n}")#text(" then one has the interpolation formula")

#align(center)[#tao-fit-display[#mitex("Q(z) = \\sum_{j=1}^k Q(x_k) \\ell_j(z)")]]

#text("where the Lagrange basis functions ")#mi("{\\ell_j(z)}")#text(" are defined by the formula")

#align(center)[#tao-fit-display[#mitex("\\ell_k(z) := \\prod_{i \\neq k} \\frac{z - x_i}{x_k - x_i}.")]]

#text("In terms of the monic polynomial ")#mi("{P(z) := \\prod_{j=1}^n (z-x_j)}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\ell_k(z) = \\frac{P(z)}{(z-x_k) P^{\\prime}(x_k)}.")]]

#text("The stability and convergence properties of Lagrange interpolation are closely related to the ")#emph[#text("Lebesgue function")]

#align(center)[#tao-fit-display[#tao-math("\\Lambda(z) := \\sum_{k=1}^n \\left|\\ell_k(z)\\right|,", block: true)]]

#text("and for a given interval ")#mi("{I}")#text(", the quantity ")#mi("{\\sup_{x \\in I} \\Lambda(x)}")#text(" is known as the ")#emph[#text("Lebesgue constant")]#text(" for that interval.")

#text("If one chooses the interpolation points ")#mi("{x_1,\\dots,x_n}")#text(" poorly, then the Lebesgue constant can be extremely large. However, if one selects these points to be the roots of the aforementioned monic Chebyshev polynomials, then it is known that ")#mi("{\\sup_{x \\in I} \\Lambda(x) = \\frac{2}{\\pi} \\log n - O(1)}")#text(" for all fixed intervals ")#mi("{I}")#text(" in ")#mi("{[-1,1]}")#text(". In the case ")#mi("{I = [-1,1]}")#text(", it was ")#link("https://zbmath.org/0098.04103")[#text("shown by Erdős")]#text("} that this is the best possible value of the Lebesgue constant up to ")#mi("{O(1)}")#text(" errors for interpolation on ")#mi("{[-1,1]}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\sup_{x \\in [-1,1]} \\Lambda(x) \\geq \\frac{2}{\\pi} \\log n - O(1)")]]

#text("whenever ")#mi("{-1 \\leq x_1 < \\dots < x_n \\leq 1}")#text(" (a more precise bound was ")#link("https://zbmath.org/0722.41007")[#text("later shown by Vertesi")]#text("). Erdős and Turán ")#link("https://zbmath.org/0098.27102")[#text("then asked")]#text(" if the same lower bound")

#metadata(none) <tao-446c0c22b6c40d2b0ce9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sup_{x \\in I} \\Lambda(x) \\geq \\frac{2}{\\pi} \\log n - O(1)")]]

#text("held for more general intervals ")#mi("{I}")#text(". This is shown in our paper; a variant integral bound")

#metadata(none) <tao-54c201e16ad5f7ecae4f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_I \\Lambda(x)\\ dx \\geq \\frac{4}{\\pi^2} |I| \\log n - o(\\log n)")]]

#text("is also established, answering a separate question of Erdős. These lower bounds had previously obtained up to constants ")#link("https://zbmath.org/0391.41003")[#text("by Erdős and Szabados")]#text("}; the main issue was to obtain the sharp constant in the main term.")

#text("In terms of the monic polynomial ")#mi("{P}")#text(", these two estimates can be written as")

#align(center)[#tao-fit-display[#tao-math("\\sup_{x \\in I} \\sum_{k=1}^n \\frac{\\left|P(x)\\right|}{\\left|x-x_k\\right|\\left|P^{\\prime}(x_k)\\right|} \\geq \\frac{2}{\\pi} \\log n - O(1)", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\int_I \\sum_{k=1}^n \\frac{\\left|P(x)\\right|}{\\left|x-x_k\\right|\\left|P^{\\prime}(x_k)\\right|}\\ dx \\geq \\frac{4}{\\pi^2} |I| \\log n - o(\\log n).", block: true)]]

#text("Using the intuition that ")#mi("{P}")#text(" should behave locally like a trigonometric polynomial, and performing some renormalizations, one can extract the following toy problem to work with first:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Problem 3")]#text(" Let ")#mi("{P: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a trigonometric polynomial of degree ")#mi("{n}")#text(" with ")#mi("{2n}")#text(" roots ")#mi("{x_1 < \\dots < x_{2n}}")#text(" in ")#mi("{[0, 2\\pi)}")#text(".")

#list(
[#text("(i) Show that")

#metadata(none) <tao-62f4ddbee12e2e2623fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\sup_{x \\in [0,2\\pi)} \\sum_{k=1}^{2n} \\frac{\\left|P(x)\\right|}{\\left|P^{\\prime}(x_k)\\right|} \\geq 2.", block: true)]]],
[#text("(ii) Show that")

#metadata(none) <tao-1a20f6d5510e063e9244>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\int_0^{2\\pi} \\sum_{k=1}^{2n} \\frac{\\left|P(x)\\right|}{\\left|P^{\\prime}(x_k)\\right|}\\ dx \\geq 8.", block: true)]]]
)
]

#text("It is easy to check that the lower bounds of ")#mi("{2}")#text(" and ")#mi("{8}")#text(" are sharp by considering the case when ")#mi("{P}")#text(" is a sinusoid ")#mi("{P(x) = A \\sin(n(x-x_0))}")#text(".")

#text("The bound ")#link(<tao-62f4ddbee12e2e2623fe>)[#text("(3)")]#text(" is immediate from Bernstein’s inequality (Lemma ")#link(<tao-d8f780825f78872fdbe1>)[#text("1")]#text("). By applying a local version of this inequality, I was able to get a weak version of the claim ")#link(<tao-446c0c22b6c40d2b0ce9>)[#text("(1)")]#text(" in which ")#mi("{O(1)}")#text(" was replaced with ")#mi("{o(\\log n)}")#text("; see ")#link("https://terrytao.wordpress.com/wp-content/uploads/2026/02/erdos-1153-1.pdf")[#text("this early version of the paper")]#text(", which was developed ")#link("https://www.erdosproblems.com/forum/thread/1153")[#text("through conversations")]#text(" with Nat Sothanaphan and Aron Bhalla. By combining this argument with ideas from the ")#link("https://zbmath.org/0098.04103")[#text("older work of Erdős")]#text("}, I was able to establish ")#link(<tao-446c0c22b6c40d2b0ce9>)[#text("(1)")]#text(".")

#text("The bound ")#link(<tao-54c201e16ad5f7ecae4f>)[#text("(2)")]#text(" took me longer to establish, and involved a non-trivial amount of playing around with AI tools, the story of which I would like to share here. I had discovered the toy problem ")#link(<tao-1a20f6d5510e063e9244>)[#text("(4)")]#text(", but initially was not able to establish this inequality; ")#link("https://deepmind.google.com/science/alphaevolve/experiment/7475342617996536880")[#text("AlphaEvolve seemed to confirm it numerically")]#text(" (with sinusoids appearing to be the extremizer), but did not offer direct clues on how to prove this rigorously. At some point I realized that the left-hand side factorized into the expressions ")#mi("{\\int_0^{2\\pi} |P(x)|\\ dx}")#text(" and ")#tao-math("{\\sum_{k=1}^{2n} \\frac{1}{\\left|P^{\\prime}(x_k)\\right|}}", block: false)#text(", and tried to bound these expressions separately. Perturbing around a sinusoid ")#mi("{A \\sin(n(x-x_0))}")#text(", I was able to show that the ")#mi("{L^1}")#text(" norm ")#mi("{\\int_0^{2\\pi} |P(x)|\\ dx}")#text(" was a local minimum as long as one only perturbed by lower order Fourier modes, keeping the frequency ")#mi("{n}")#text(" coefficients unchanged. Guessing that this local minimum was actually a global minimum, this led me to conjecture the general lower bound")

#align(center)[#tao-fit-display[#tao-math("\\int_0^{2\\pi} |P(x)|\\ dx \\geq 4 \\left|a_n+ib_n\\right|", block: true)]]

#text("whenever ")#mi("{P}")#text(" was a degree ")#mi("{n}")#text(" trigonometric polynomial with highest frequency components ")#mi("{a_n \\cos(nx) + b_n \\sin(nx)}")#text(". ")#link("https://deepmind.google.com/science/alphaevolve/experiment/3643944856706753832")[#text("AlphaEvolve numerically confirmed this inequality to be likely to be true also")]#text(". I still did not see how to prove this inequality, but I decided to try my luck ")#link("https://chatgpt.com/share/69c20593-0680-83e8-a8f5-dad3ae2e626b")[#text("giving it to ChatGPT Pro")]#text(", which recognized it as an ")#mi("{L^1}")#text(" approximation problem and gave me a duality-based proof (based ultimately on the Fourier expansion of the square wave). With some further discussion, I was able to adapt this proof to functions of global exponential type (replacing the Fourier manipulations with contour shifting arguments, in the spirit of the Paley-Wiener theorem), which roughly speaking gave me half of what I needed to establish ")#link(<tao-54c201e16ad5f7ecae4f>)[#text("(2)")]#text(". However, I still needed the matching lower bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k=1}^{2n} \\frac{1}{\\left|P^{\\prime}(x_k)\\right|} \\geq \\frac{2}{\\left|a_n+ib_n\\right|}", block: true)]]

#text("on the other factor in the toy problem. Again, AlphaEvolve could ")#link("https://deepmind.google.com/science/alphaevolve/experiment/6743963478425032944")[#text("numerically confirm that this inequality was likely to be true")]#text(", but now the quantity I was trying to control did not look convex or linear in ")#mi("{P}")#text(", and so the previous duality method did not seem to apply. At this point I switched to pen and paper; eventually I realized that the expression almost looked like a sum of residues, and eventually after playing around with contour integrals of ")#mi("{\\frac{e^{inz}}{P(z)}}")#text(" using the residue theorem I was able to establish ")#link(<tao-1a20f6d5510e063e9244>)[#text("(4)")]#text(", and then with a bit more (human) effort I could move from the toy problem back to the original problem to obtain ")#link(<tao-54c201e16ad5f7ecae4f>)[#text("(2)")]#text(". Quite possibly AI tools would also have been able to assist with these steps, but they were not necessary here; their main value for me was in quickly confirming that the approach I had in mind was numerically plausible, and in recognizing the right technique to solve one part of the toy problem I had isolated. (I also used AI tools for several other secondary tasks, such as literature review, proofreading, and generating pictures, but these applications of AI have matured to the point where using them for this purpose is almost mundane.)")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2026")])]

#text("In the last display, two inequalities appear")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cee7ff3d89f11b44c3fee3ebba656a25298f40ead1fb45f1417a75cc2588b66f-0e44f6dc250daa56655653384c059ea72241e93832a6b8225f83562222217fad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yemon Choi")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692055")[#strong[#text("Yemon Choi")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2026")])]

#text("A non-mathematical remark/question: is there any particular reason why the paper uses the numbering convention in which each type of numbered environment (Theorem, Remark, Lemma) has its own separate counter, rather than having all numbered environments sharing a common counter? Or was this just a case of having no particular preference?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692058")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2026")])]

#text("Hmm, that is indeed a bit odd. No, there was no reason for that, and I prefer not having different classes of environments share the same number, so I will change this in the next revision of the ms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8afd437da1e36ab156fcdc0ff4e6d28e8e48582473c360ab6e4aac8a8a94880e-11086e67d63e97b981d0240d596254a1217fc1a92c53dccae70ac8508b5737eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of André Pierro de Camargo")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692066")[#strong[#text("André Pierro de Camargo")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2026")])]

#text("Dear professor Tao, allow me to draw your attention to an open problem of a related nature. Let us fix a reference interval, say ")#mi("[-1,1]")#text(". The Lebesgue constant")

#tao-math("\\displaystyle \\Lambda(\\mathbf{x}) = \\max\\limits_{x \\in [-1,1]} \\sum\\limits_{j = 1}^{n} \\left|\\ell_j(x)\\right|", block: false)

#text("is the condition number of polynomial interpolation in the Lagrange basis ")#mi("B = \\{\\ell_1(x), \\ell_2(x), \\dots, \\ell_n(x)\\}")#text(" in the sense that it governs the behavior of numerical errors in the computation of the polynomial")

#mi("\\displaystyle p(x) = \\sum\\limits_{j = 1}^{n} y_j \\ell_j(x)")

#text("that interpolates the real vector ")#mi("\\mathbf{y} = (y_1, \\dots, y_n)")#text(" at the real nodes ")#mi("\\mathbf{x} = (x_1,\\dots, x_n)")#text(", ")#mi("x_i \\in [-1, 1] \\ \\forall \\ i")#text(". ")#mi("\\Lambda(\\mathbf{x})")#text(" is invariant under permutation of the nodes and this suggests that there will be no significant differences in the propagation of rounding errors in the computation of ")#mi("p(x)")#text(" when we permute the nodes. Remarkably, the situation is completely different when we consider Newton’s formula")

#mi("\\displaystyle p(x) = \\sum\\limits_{i = 1}^{n} y[ x_1, \\dots, x_i] \\prod\\limits_{\\scriptsize\\begin{array}{c} j = 1 \\end{array}}^{i-1} (x - x_j),")

#text("to compute ")#mi("p(x)")#text(". In this case, the associated condition number is")

#tao-math("\\displaystyle \\begin{array}{ccl} \\Lambda_{\\mathcal N}(\\mathbf{x}) = \\max\\limits_{x \\in [-1,1]} \\sum\\limits_{\\ell = 1}^{n} c_\\ell(\\mathbf{x}) p_{\\ell}(x), \\ \\ c_\\ell(\\mathbf{x}) = \\sum\\limits_{j = 1}^{\\ell} \\prod\\limits_{{\\scriptsize \\begin{array}{c} k = 1 \\\\ k \\neq j \\end{array}}}^{\\ell} \\frac{1}{\\left|x_j - x_k\\right|}, \\ \\ p_\\ell(x) = \\prod\\limits_{\\scriptsize\\begin{array}{c} j = 1 \\end{array}}^{\\ell-1} |x - x_j|. \\end{array}", block: false)

#text("Among the many differences between ")#mi("\\Lambda_{\\mathcal N}(\\mathbf{x})")#text(" and ")#mi("\\Lambda(\\mathbf{x})")#text(" is the fact that ")#mi("\\Lambda_{\\mathcal N}(\\mathbf{x})")#text(" is not invariant under permutations of the nodes. Moreover, while")

#mi("\\displaystyle \\Lambda(\\mathbf{x^{cheb}}) = \\frac{2}{\\pi} \\log(n) + O(1),")

#text("for the Chebyshev points, ")#mi("\\Lambda_{\\mathcal N}(\\mathbf{x^{cheb}})")#text(" grows exponentially in ")#mi("n")#text(" for the Chebyshev nodes in increasing order (the details of these facts can be found in this paper: ")#link("https://www.sciencedirect.com/science/article/abs/pii/S0021904523000059")[#text("https://www.sciencedirect.com/science/article/abs/pii/S0021904523000059")]#text("). However, it was noted empirically in the literature that the growth of ")#mi("\\Lambda_{\\mathcal N}(\\mathbf{x^{cheb}})")#text(" can be substantially diminished if one sorts ")#mi("\\mathbf{x^{cheb}}")#text(" in a Leja ordering (see definition below). An open question is to obtain effective upper bounds for")

#mi("\\displaystyle \\Lambda_{\\mathcal N}(\\mathbf{x^{cheb}})")

#text("for ")#mi("\\mathbf{x^{cheb}}")#text(" in a Leja ordering. Some numerical experiments suggested that ")#mi("\\Lambda_{\\mathcal N}(\\mathbf{x^{cheb}})")#text(", with ")#mi("\\mathbf{x^{cheb}}")#text(" in a Leja ordering, may also grow logarithmically in ")#mi("n")#text(". A Leja ordering for ")#mi("\\{ x_1, x_2, \\dots, x_n \\}")#text(" is defined as follows:")

#list(
[#text("choose ")#mi("x_1^{\\prime} \\in \\{ x_1, x_2, \\dots, x_n \\}")#text(" such that ")#tao-math("\\left|x_1^{\\prime}\\right| = \\max\\limits_i \\left|x_i\\right|", block: false)#text(".")],
[#text("for ")#mi("2 \\leq j \\leq n")#text(", choose ")#mi("x_j^{\\prime} \\in \\{ x_1, x_2, \\dots, x_n \\}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\prod\\limits_{k = 1}^{j-1} (x_j^{\\prime} - x_k^{\\prime}) \\right| = \\max\\limits_{1 \\leq \\ell \\leq n} \\left|\\prod\\limits_{k = 1}^{j-1} (x_\\ell - x_k^{\\prime}) \\right|.", block: true)]]]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692069")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2026")])]

#text("The links to the AlphaEvolve conversations do not work for me.")

#emph[#text("[A Google account is required to view them. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692093")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2026")])]

#text("It doesn’t work for me either, even logged in to google. I think you might need special AlphaEvolve access for it to work.")

#text("To avoid this issue, and possible dead links in the future, I wonder if these responses could be copied and hosted separately; perhaps with some extra detail about the model used, etc, for posterity.")

#emph[#text("[AlphaEvolve should be launched publicly within a few months; hopefully the links will start working more broadly then. The data on the linked pages is rather complex in structure and not easy to copy over to a separate file. -T]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692070")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2026")])]

#text("Very intrigued by ChatGPT’s use of Nevanlinna two-constant theorem in localization step. Do you expect this framework to extend to weighted interpolation or to nodes on more general compact sets than intervals ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692077")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2026")])]

#text("Regarding the Boas inequality (Theorem 1.1(ii)): it may be worth recording an alternative proof that avoids the Duffin–Schaeffer zero-counting argument entirely, using instead the Green’s function of ")#mi("\\mathbb{C} \\setminus [-1,1]")#text(".")

#text("After normalizing ")#mi("\\lambda = A = 1")#text(", fix ")#mi("x_0")#text(" with ")#tao-math("\\left|f(x_0)\\right| < 1", block: false)#text(" (the case ")#tao-math("\\left|f(x_0)\\right| = 1", block: false)#text(" forces ")#mi("f^{\\prime}(x_0) = 0")#text(" since ")#mi("f")#text(" has a real extremum). Write ")#mi("f(z) = \\cos\\theta(z)")#text(" locally, with ")#mi("\\theta(x_0) \\in (0,\\pi)")#text(" real. Define ")#tao-math("\\rho(w) = \\log\\left|w + \\sqrt{w^2 - 1}\\right|", block: false)#text(", the Green’s function of ")#mi("\\mathbb{C} \\setminus [-1,1]")#text(" with pole at infinity.")

#text("Then ")#mi("u(z) := \\rho(f(z))")#text(" is subharmonic on ")#mi("\\mathbb{C}")#text(", vanishes on ")#mi("\\mathbb{R}")#text(" (since ")#tao-math("\\left|f(x)\\right| \\leq 1", block: false)#text("), and satisfies ")#tao-math("u(z) \\leq \\left|z\\right| + O(1)", block: false)#text(" from the exponential type bound. By the Phragmen-Lindelof principle in each half-plane, ")#tao-math("u(x + iy) \\leq \\left|y\\right|", block: false)#text(".")

#text("Since ")#tao-math("\\rho(w) = \\left|\\mathrm{Im}(\\arccos w)\\right|", block: false)#text(" locally, this gives ")#tao-math("\\left|\\mathrm{Im}\\, \\theta(x_0 + iy)\\right| \\leq \\left|y\\right|", block: false)#text(". Expanding ")#mi("\\theta(x_0 + iy) = \\theta(x_0) + iy\\theta^{\\prime}(x_0) + o(y)")#text(" with ")#mi("\\theta^{\\prime}(x_0)")#text(" real (by the Schwarz reflection principle), we get ")#tao-math("\\left|\\theta^{\\prime}(x_0)\\right| \\leq 1", block: false)#text(". Then ")#mi("f^{\\prime}(x_0) = -\\sin\\theta(x_0) \\cdot \\theta^{\\prime}(x_0)")#text(" gives ")#mi("f^{\\prime}(x_0)^2 \\leq 1 - f(x_0)^2")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692087")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2026")])]

#text("Very nice! This argument also seems to recover the Duffin-Schaeffer inequality (Theorem 1.1(iii)). Does this argument appear in the literature somewhere? It actually ties in very well with the proof of the Nevanlinna two constant theorem (implicitly used in the proof of Lemma 2.3), and in particular the argument should localize to give an alternate proof of Theorem 1.2.")

#text("My (recently emeritus) colleague John Garnett has long extolled the virtues of harmonic measure to me, but I am only now beginning to appreciate the power of using such measures (or conformal mapping, for that matter)…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/03/23/local-bernstein-theory-and-lower-bounds-for-lebesgue-constants/#comment-692223")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2026")])]

#text("In the abstract, the first sentence of the second paragraph should probably be rephrased in order to avoid the formula leeking into the page margin.")

#text("This is also the case in the following places:")

#list(
[#text("P. 2, l. 2")],
[#text("P. 20, l. 14")],
[#text("P. 20, l. 18")],
[#text("P. 30, l. –")]
)
]
