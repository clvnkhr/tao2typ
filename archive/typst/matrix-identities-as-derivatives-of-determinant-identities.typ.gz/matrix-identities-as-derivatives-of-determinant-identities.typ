// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/
// Converted to Typst by tao2typ: "2026-10-14T16:36:57.902090+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Matrix identities as derivatives of determinant identities", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Matrix identities as derivatives of determinant identities")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 13 January 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")[#text("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Determinant")[#text("determinant")]#text(" ")#mi("{\\det(A)}")#text(" of a square matrix ")#mi("{A}")#text(" obeys a large number of important identities, the most basic of which is the multiplicativity property ")#metadata(none) <tao-f48da1228834a60f749a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\det(AB) = \\det(A) \\det(B)")]]

#text(" whenever ")#mi("{A,B}")#text(" are square matrices of the same dimension. This identity then generates many other important identities. For instance, if ")#mi("{A}")#text(" is an ")#mi("{n \\times m}")#text(" matrix and ")#mi("{B}")#text(" is an ")#mi("{m \\times n}")#text(" matrix, then by applying the previous identity to equate the determinants of ")#mi("{\\begin{pmatrix} 1 & -A \\\\ B & 1 \\end{pmatrix} \\begin{pmatrix} 1 & A \\\\ 0 & 1 \\end{pmatrix}}")#text(" and ")#mi("{\\begin{pmatrix} 1 & A \\\\ 0 & 1 \\end{pmatrix} \\begin{pmatrix} 1 & -A \\\\ B & 1 \\end{pmatrix}}")#text(" (where we will adopt the convention that ")#mi("{1}")#text(" denotes an identity matrix of whatever dimension is needed to make sense of the expressions being computed, and similarly for ")#mi("{0}")#text(") we obtain the ")#link("https://en.wikipedia.org/wiki/Weinstein%E2%80%93Aronszajn_identity")[#text("Weinstein-Aronszajn determinant identity")]#text(" ")#metadata(none) <tao-e211ff386269bbaa83ee>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\det( 1 + AB ) = \\det( 1 + BA ).")]]

#text(" This identity, which converts an ")#mi("{n \\times n}")#text(" determinant into an ")#mi("{m \\times m}")#text(" determinant, is very useful in random matrix theory (a point ")#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/")[#text("emphasised in particular by Deift")]#text("), particularly in regimes in which ")#mi("{m}")#text(" is much smaller than ")#mi("{n}")#text(".")

#text("Another identity generated from ")#link(<tao-f48da1228834a60f749a>)[#text("(1)")]#text(" arises when trying to compute the determinant of a ")#mi("{(n+m) \\times (n+m)}")#text(" block matrix")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}")]]

#text("where ")#mi("{A}")#text(" is an ")#mi("{n \\times n}")#text(" matrix, ")#mi("{B}")#text(" is an ")#mi("{n \\times m}")#text(" matrix, ")#mi("{C}")#text(" is an ")#mi("{m \\times n}")#text(" matrix, and ")#mi("{D}")#text(" is an ")#mi("{m \\times m}")#text(" matrix. If ")#mi("{A}")#text(" is invertible, then we can manipulate this matrix via block Gaussian elimination as")

#tao-aligned(keep: true)[


#tao-math("\\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}  & = \\begin{pmatrix} A & 0 \\\\ 0 & 1 \\end{pmatrix} \\begin{pmatrix} 1 & A^{-1} B \\\\ C & D \\end{pmatrix}", block: true)



#tao-math(" & = \\begin{pmatrix} A & 0 \\\\ 0 & 1 \\end{pmatrix} \\begin{pmatrix} 1 & 0 \\\\ C & 1 \\end{pmatrix} \\begin{pmatrix} 1 & A^{-1} B \\\\ 0 & D - C A^{-1} B \\end{pmatrix}", block: true)
]

#text("and on taking determinants using ")#link(<tao-f48da1228834a60f749a>)[#text("(1)")]#text(" we obtain the ")#emph[#text("Schur determinant identity")]#text(" ")#metadata(none) <tao-ca127a74284f153ef0b1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\det \\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix} = \\det(A) \\det( D - C A^{-1} B )")]]

#text(" relating the determinant of a block-diagonal matrix with the determinant of the ")#link("http://en.wikipedia.org/wiki/Schur_complement")[#text("Schur complement")]#text(" ")#mi("{D-C A^{-1} B}")#text(" of the upper left block ")#mi("{A}")#text(". This identity can be viewed as the correct way to generalise the ")#mi("{2 \\times 2}")#text(" determinant formula")

#align(center)[#tao-fit-display[#mitex("\\det \\begin{pmatrix} a & b \\\\ c & d \\end{pmatrix} = ad-bc = a ( d - c a^{-1} b).")]]

#text("It is also possible to use determinant identities to deduce other matrix identities that do not involve the determinant, by the technique of ")#link("http://en.wikipedia.org/wiki/Matrix_differentiation")[#text("matrix differentiation")]#text(" (or equivalently, matrix linearisation). The key observation is that near the identity, the determinant behaves like the trace, or more precisely one has ")#metadata(none) <tao-e1fd6c028c076f1cda5c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\det( 1 + \\varepsilon A ) = 1 + \\varepsilon \\text{tr}(A) + O(\\varepsilon^2)")]]

#text(" for any bounded square matrix ")#mi("{A}")#text(" and infinitesimal ")#mi("{\\varepsilon}")#text(". (If one is uncomfortable with infinitesimals, one can interpret this sort of identity as an asymptotic as ")#mi("{\\varepsilon\\rightarrow 0}")#text(".) Combining this with ")#link(<tao-f48da1228834a60f749a>)[#text("(1)")]#text(" we see that for square matrices ")#mi("{A,B}")#text(" of the same dimension with ")#mi("{A}")#text(" invertible and ")#mi("{A^{-1}, B}")#text(" invertible, one has")

#tao-aligned(keep: true)[


#tao-math("\\det( A + \\varepsilon B )  & = \\det(A) \\det(1 + \\varepsilon A^{-1} B )", block: true)



#tao-math(" & = \\det(A) (1 + \\varepsilon \\text{tr}( A^{-1} B ) + O(\\varepsilon^2) )", block: true)
]

#text("for infinitesimal ")#mi("{\\varepsilon}")#text(". To put it another way, if ")#mi("{A(t)}")#text(" is a square matrix that depends in a differentiable fashion on a real parameter ")#mi("{t}")#text(", then we have the ")#link("https://en.wikipedia.org/wiki/Jacobi%27s_formula")[#text("Jacobi formula")]

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\det(A(t)) = \\det(A(t)) \\text{tr}( A(t)^{-1} \\frac{d}{dt} A(t) )")]]

#text("whenever ")#mi("{A(t)}")#text(" is invertible. (Note that if one combines this identity with ")#link("http://en.wikipedia.org/wiki/Cofactor_(linear_algebra)#Cofactor_expansion")[#text("cofactor expansion")]#text(", one recovers ")#link("http://en.wikipedia.org/wiki/Cramer%27s_rule")[#text("Cramer’s rule")]#text(".)")

#text("Let us see some examples of this differentiation method. If we take the Weinstein-Aronszajn identity ")#link(<tao-e211ff386269bbaa83ee>)[#text("(2)")]#text(" and multiply one of the rectangular matrices ")#mi("{A}")#text(" by an infinitesimal ")#mi("{\\varepsilon}")#text(", we obtain")

#align(center)[#tao-fit-display[#mitex("\\det( 1 + \\varepsilon A B ) = \\det( 1 + \\varepsilon B A);")]]

#text("applying ")#link(<tao-e1fd6c028c076f1cda5c>)[#text("(4)")]#text(" and extracting the linear term in ")#mi("{\\varepsilon}")#text(" (or equivalently, differentiating at ")#mi("{\\varepsilon}")#text(" and then setting ")#mi("{\\varepsilon=0}")#text(") we conclude the cyclic property of trace:")

#align(center)[#tao-fit-display[#mitex("\\text{tr}(AB) = \\text{tr}(BA).")]]

#text("To manipulate derivatives and inverses, we begin with the ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series")]#text(" approximation")

#align(center)[#tao-fit-display[#mitex("(1 + \\varepsilon A)^{-1} = 1 - \\varepsilon A + O(\\varepsilon^2)")]]

#text("for bounded square ")#mi("{A}")#text(" and infinitesimal ")#mi("{\\varepsilon}")#text(", which then leads to the more general approximation")

#align(center)[#tao-fit-display[#mitex("(A + \\varepsilon B)^{-1} = (1 + \\varepsilon A^{-1} B)^{-1} A^{-1}")]]

#metadata(none) <tao-1e57584a938ed2eef2fb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("= A^{-1} - \\varepsilon A^{-1} B A^{-1} + O(\\varepsilon^2)")]]

#text(" for square matrices ")#mi("{A,B}")#text(" of the same dimension with ")#mi("{B, A^{-1}}")#text(" bounded. To put it another way, we have")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} A(t)^{-1} = -A(t)^{-1} (\\frac{d}{dt} A(t)) A(t)^{-1}")]]

#text("whenever ")#mi("{A(t)}")#text(" depends in a differentiable manner on ")#mi("{t}")#text(" and ")#mi("{A(t)}")#text(" is invertible.")

#text("We can then differentiate (or linearise) the Schur identity ")#link(<tao-ca127a74284f153ef0b1>)[#text("(3)")]#text(" in a number of ways. For instance, if we replace the lower block ")#mi("{D}")#text(" by ")#mi("{D + \\varepsilon H}")#text(" for some test ")#mi("{m \\times m}")#text(" matrix ")#mi("{H}")#text(", then by ")#link(<tao-e1fd6c028c076f1cda5c>)[#text("(4)")]#text(", the left-hand side of ")#link(<tao-ca127a74284f153ef0b1>)[#text("(3)")]#text(" becomes (assuming the invertibility of the block matrix)")

#align(center)[#tao-fit-display[#mitex("(\\det \\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}) (1 + \\varepsilon \\text{tr} \\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}^{-1} \\begin{pmatrix} 0 & 0 \\\\ 0 & H \\end{pmatrix} + O(\\varepsilon^2) )")]]

#text("while the right-hand side becomes")

#align(center)[#tao-fit-display[#mitex("\\det(A) ( \\det(D-BA^{-1}C) + \\varepsilon \\text{tr}( (D-BA^{-1}C)^{-1} H ) + O(\\varepsilon^2) );")]]

#text("extracting the linear term in ")#mi("{\\varepsilon}")#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("\\text{tr} (\\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}^{-1} \\begin{pmatrix} 0 & 0 \\\\ 0 & H \\end{pmatrix}) = \\text{tr}( (D-BA^{-1}C)^{-1} H ).")]]

#text("As ")#mi("{H}")#text(" was an arbitrary ")#mi("{m \\times m}")#text(" matrix, we conclude from duality that the lower right ")#mi("{m \\times m}")#text(" block of ")#mi("{\\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}^{-1}}")#text(" is given by the inverse ")#mi("{(D-BA^{-1}C)^{-1}}")#text(" of the Schur complement:")

#align(center)[#tao-fit-display[#mitex("\\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}^{-1} = \\begin{pmatrix} ?? & ?? \\\\ ?? & (D-BA^{-1}C)^{-1} \\end{pmatrix}.")]]

#text("One can also compute the other components of this inverse in terms of the Schur complement ")#mi("{D-BA^{-1} C}")#text(" by a similar method (although the formulae become more complicated). As a variant of this method, we can perturb the block matrix in ")#link(<tao-ca127a74284f153ef0b1>)[#text("(3)")]#text(" by an infinitesimal multiple of the identity matrix giving ")#metadata(none) <tao-88d4266fd4e6338d13b8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\det \\begin{pmatrix} A+\\varepsilon & B \\\\ C & D+\\varepsilon \\end{pmatrix} = \\det(A+\\varepsilon) \\det( D +\\varepsilon - C (A+\\varepsilon)^{-1} B ).")]]

#text(" By ")#link(<tao-e1fd6c028c076f1cda5c>)[#text("(4)")]#text(", the left-hand side is")

#align(center)[#tao-fit-display[#mitex("(\\det \\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}) (1 + \\varepsilon \\text{tr} \\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}^{-1} + O(\\varepsilon^2) ).")]]

#text("From ")#link(<tao-1e57584a938ed2eef2fb>)[#text("(5)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("D + \\varepsilon - C (A+ \\varepsilon)^{-1} B = D - C A^{-1} B + \\varepsilon(1 + C A^{-2} B) + O(\\varepsilon^2)")]]

#text("and so from ")#link(<tao-e1fd6c028c076f1cda5c>)[#text("(4)")]#text(" the right-hand side of ")#link(<tao-88d4266fd4e6338d13b8>)[#text("(6)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\det(A) \\det(D-CA^{-1} B) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\times ( 1 + \\varepsilon (\\text{tr}(A^{-1}) + \\text{tr}( (D-CA^{-1} B)^{-1} (1 + C A^{-2} B)) ) + O(\\varepsilon^2) );")]]

#text("extracting the linear component in ")#mi("{\\varepsilon}")#text(", we conclude the identity ")#metadata(none) <tao-fb2b9bb163acf7e3ad50>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("\\text{tr} \\begin{pmatrix} A & B \\\\ C & D \\end{pmatrix}^{-1} = \\text{tr}(A^{-1}) + \\text{tr}( (D-CA^{-1} B)^{-1} (1 + C A^{-2} B))")]]

#text(" which relates the trace of the inverse of a block matrix, with the trace of the inverse of one of its blocks. This particular identity turns out to be useful in random matrix theory; I hope to elaborate on this in a later post.")

#text("As a final example of this method, we can analyse low rank perturbations ")#mi("{A+BC}")#text(" of a large (")#mi("{n \\times n}")#text(") matrix ")#mi("{A}")#text(", where ")#mi("{B}")#text(" is an ")#mi("{n \\times m}")#text(" matrix and ")#mi("{C}")#text(" is an ")#mi("{m \\times n}")#text(" matrix for some ")#mi("{m<n}")#text(". (This type of situation is also common in random matrix theory, for instance it arose in ")#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/")[#text("this previous paper of mine")]#text(" on outliers to the circular law.) If ")#mi("{A}")#text(" is invertible, then from ")#link(<tao-f48da1228834a60f749a>)[#text("(1)")]#text(" and ")#link(<tao-e211ff386269bbaa83ee>)[#text("(2)")]#text(" one has the ")#link("http://en.wikipedia.org/wiki/Matrix_determinant_lemma")[#text("matrix determinant lemma")]

#align(center)[#tao-fit-display[#mitex("\\det( A + BC ) = \\det(A) \\det( 1 + A^{-1} BC) = \\det(A) \\det(1 + CA^{-1} B);")]]

#text("if one then perturbs ")#mi("{A}")#text(" by an infinitesimal matrix ")#mi("{\\varepsilon H}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\det( A + BC + \\varepsilon H ) = \\det(A + \\varepsilon H ) \\det(1 + C(A+\\varepsilon H)^{-1} B).")]]

#text("Extracting the linear component in ")#mi("{\\varepsilon}")#text(" as before, one soon arrives at")

#align(center)[#tao-fit-display[#mitex("\\text{tr}( (A+BC)^{-1} H ) = \\text{tr}( A^{-1} H ) - \\text{tr}( (1 + C A^{-1} B)^{-1} C A^{-1} H A^{-1} B )")]]

#text("assuming that ")#mi("{A}")#text(" and ")#mi("{A+BC}")#text(" are both invertible; as ")#mi("{H}")#text(" is arbitrary, we conclude (after using the cyclic property of trace) the ")#link("http://en.wikipedia.org/wiki/Sherman%E2%80%93Morrison_formula")[#text("Sherman-Morrison formula")]

#align(center)[#tao-fit-display[#mitex("(A+BC)^{-1} = A^{-1} - A^{-1} B (1 + C A^{-1} B)^{-1} C A^{-1}")]]

#text("for the inverse of a low rank perturbation ")#mi("{A+BC}")#text(" of a matrix ")#mi("{A}")#text(". While this identity can be easily verified by direct algebraic computation, it is somewhat difficult to ")#emph[#text("discover")]#text(" this identity by such algebraic manipulation; thus we see that the “determinant first” approach to matrix identities can make it easier to find appropriate matrix identities (particularly those involving traces and/or inverses), even if the identities one is ultimately interested in do not involve determinants. (As differentiation typically makes an identity lengthier, but also more “linear” or “additive”, the determinant identity tends to be shorter (albeit more nonlinear and more multiplicative) than the differentiated identity, and can thus be slightly easier to derive.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Use the “determinant first” approach to derive the ")#link("http://en.wikipedia.org/wiki/Woodbury_matrix_identity")[#text("Woodbury matrix identity")]#text(" (also known as the ")#link("http://en.wikipedia.org/wiki/Binomial_inverse_theorem")[#text("binomial inverse theorem")]#text(")")

#align(center)[#tao-fit-display[#mitex("(A+BDC)^{-1} = A^{-1} - A^{-1} B (D^{-1} + CA^{-1} B)^{-1} C A^{-1}")]]

#text("where ")#mi("{A}")#text(" is an ")#mi("{n \\times n}")#text(" matrix, ")#mi("{B}")#text(" is an ")#mi("{n \\times m}")#text(" matrix, ")#mi("{C}")#text(" is an ")#mi("{m \\times n}")#text(" matrix, and ")#mi("{D}")#text(" is an ")#mi("{m \\times m}")#text(" matrix, assuming that ")#mi("{A}")#text(", ")#mi("{D}")#text(" and ")#mi("{A+BDC}")#text(" are all invertible.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{A,B}")#text(" be invertible ")#mi("{n \\times n}")#text(" matrices. Establish the identity")

#align(center)[#tao-fit-display[#mitex("\\det(A + B) \\det(A - B) = \\det(B) \\det( AB^{-1} A - B)")]]

#text("and differentiate this in ")#mi("{A}")#text(" to deduce the identity")

#align(center)[#tao-fit-display[#mitex("(A+B)^{-1} + (A-B)^{-1} = 2 (A - BA^{-1} B)^{-1}")]]

#text("(assuming that all inverses exist) and thence")

#align(center)[#tao-fit-display[#mitex("(A+B)^{-1} = (A - BA^{-1} B)^{-1} + (B - AB^{-1} A)^{-1}.")]]

#text("Rotating ")#mi("{B}")#text(" by ")#mi("{i}")#text(" then gives")

#align(center)[#tao-fit-display[#mitex("(A+iB)^{-1} = (A + BA^{-1} B)^{-1} - i (B + AB^{-1} A)^{-1},")]]

#text("which is useful for inverting a matrix ")#mi("{A+iB}")#text(" that has been split into a self-adjoint component ")#mi("{A}")#text(" and a skew-adjoint component ")#mi("{iB}")#text(".")
]

#heading(level: 1)[#text("Comments (45)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213094")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("Thanks! I’m about to start teaching a matrix analysis course in which I was going to cover most of this material, though I hadn’t thought of quite this viewpoint on the second half. I think you’ve just saved me the work of preparing one lecture.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-215327")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2013")])]

#text("I’m also delighted to discover that telling my browser to print this page results in a printout of the content of the post without all the links on the left.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e19ddec416b90e479531003cfa4c2793f67aabe09f8c7b2e7a5efa0e0754ecc8-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of José Carlos Santos")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213096")[#strong[#text("José Carlos Santos")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("When you wrote “{n+m \\times n+m} square matrices”, what you meant was “{(n+m) \\times (n+m)} square matrices”.")

#emph[#text("[Parentheses added – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matrix identities as derivatives of determinant identities « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213098")[#strong[#text("Matrix identities as derivatives of determinant identities « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("[…] via Matrix identities as derivatives of determinant identities. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213105")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("Should the matrix [1,C;0,1] above equation (3) be [1,0;C,1]?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3664eddee1b27a3825a279bd199db267796628cf2efaa95044989e685f249619-bcf983cb4f7d08b31f94e804aad5083e891ca98541d7df442b5d927617ee509f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joseph Nebus")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213114")[#strong[#text("Joseph Nebus")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("I think I’m most startled to realize that I don’t remember having encountered Sylvester’s determinant identity before. It seems like a wonderful little bit to show off. (But I suppose everyone’s life is filled with wonderful little bits they run across only surprisingly late.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e84b6f8e0e937f4fb4aa554bcbc4ab0cfed90db5f356bcfca1a5dc032206eb-df0274d4fa00182253b22e6fdbcf17c1937d8d5713184d5d85ead37c4e2a9a72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ����Ԫ")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213139")[#strong[#text("����Ԫ")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("Hello, I’m a big fan of Terry Tao’s “What’s new” blog, however mainland China has blocked the WordPress. Therefore, I would appreciate it very much if you could send me full copy of each new post better in PDF rather than just e-mail since the character won’t show up.")

#text("Send from Ted")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of I am not an anoymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-215976")[#strong[#text("I am not an anoymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2013")])]

#text("I use freegate + Autoproxy(a plugin of firefox) to circumvent the GFW,you can download freegate here:")#link("http://forums.internetfreedom.org/index.php?topic=18444.0")[#text("http://forums.internetfreedom.org/index.php?topic=18444.0")]

#text("Also,there are several other ways to circumvent the great firewall of China,there are some discussion here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2009/04/27/wordpress-blocked-again-by-great-firewall-of-china/")[#text("WordPress blocked again by great firewall of China?")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213208")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2013")])]

#text("Hi,")

#text("Is there a minus missing on the right-hand side of the equation below (5)? (the equation of the derivative of A(t) inverse)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/297ba35fceba57126d9613193c7cd9b835407adfe13d536390a27ced310e32e2-a380eea33e7db527042e9dcd6848d8e1ec0adf2e9b8d886dab8b90081140dfe3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213237")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2013")])]

#text("One identity that has been useful for me recently involves two matrices ")#mi("A, B \\in SL_2(\\mathbb C)")#text(". The identity is")

#mi("tr(A) tr(B) = tr(AB) + tr(AB^{-1})")

#text("Out of curiosity, do you know if this can be derived using the methods you described? The identity isn’t hard to prove using the fact that a matrix satisfies its own characteristic polynomial, but I don’t know a very satisfying proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2013")])]

#text("Hmm, that is a puzzle. It can be deduced by differentiating the ")#mi("2 \\times 2")#text(" matrix identity")

#mi("\\det(A+B) = \\det(A) + \\det(B) + \\text{tr}(A) \\text{tr}(B) - \\text{tr}(AB),")#text(" (*)")

#text("which is valid for arbitrary ")#mi("2 \\times 2")#text(" matrices ")#mi("A,B")#text(", in the ")#mi("A")#text(" direction (at ")#mi("A=0")#text("), but then I don’t know of a good reason (other than brute force calculation) as to why (*) holds, other than an observation that five quantities ")#mi("\\det(A), \\det(B), \\text{tr}(A), \\text{tr}(B), \\text{tr}(AB)")#text(" parameterise the ")#mi("8-3=5")#text("-dimensional space of pairs ")#mi("(A,B)")#text(" of ")#mi("2 \\times 2")#text(" matrices up to conjugation, so ")#emph[#text("some")]#text(" identity of the form (*) ought to exist, and then degree considerations indicate that it should have the homogeneous structure indicated in (*).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-269307")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2014")])]

#text("The identity det(X + Y) = det(X) + det(Y) – tr(XY) + tr(X)tr(Y) is a special case of the identity described in Reutenauer and Schuetzenberger’s paper giving the determinant of the sum of k square matrices of order n as a sum of k^n terms. For example, if X and Y are 3×3 matrices then det(X + Y) = det(X) + det(Y) – tr(XY)tr(X) – tr(XY)tr(Y) + c(X)tr(Y) + tr(X)c(Y) + tr(XXY) + tr(XYY) , where c(X) = (tr(X)^2 – tr(X^2)) / 2.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213679")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2013")])]

#text("One thing that comes to mind in this context are polynomial identities for the ring of matrices like the Amitsur-Levitzki identity (See, e.g. ")#link("http://gilkalai.wordpress.com/2009/05/12/the-amitsur-levitski-theorem-for-a-non-mathematician/")[#text("http://gilkalai.wordpress.com/2009/05/12/the-amitsur-levitski-theorem-for-a-non-mathematician/")]#text(" ) For those there is a result by Processi and by Razmislov which asserts that all PI identities are derived from the Cayley-Hamilton theorem, which is a sort of determinant-identity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/804187220acfc511bce41df0aaf194cbeaf8daacb1c69d558094cd0df1ab4f46-5ac97d46f637a2247fe52fd4b0d98b6ac4203fcdde3fb2adb547af1da3c85431.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A researcher")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213778")[#strong[#text("A researcher")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2013")])]

#text("Hello Gil, would you be able to give us a suitable source for the Processi or Razmislov works? Further, could you explain what do you mean by “all PI identities are derived from the C-H theorem”? I thought that to find the generating set of all PI identities of the ring of matrices is an open problem. Only for 2×2 matrices it was solved by Drenski in 1981. But maybe we’re talking about different definitions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213844")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2013")])]

#text("Perhaps for the results I mentioned “are derived” is quite a description of generating sets.")

#text("There is an article “Polynomial identities and the Cayley-Hamilton theorem” by Edward Formanek in The Mathematical Intelligencer 11(89) 37-39 which describes the related works of Processi and Razmislov. Rowen’s BAMS book review of a book by Formanek and Drensky ")#link("http://www.ams.org/bull/2006-43-02/S0273-0979-06-01082-2/S0273-0979-06-01082-2.pdf")[#text("http://www.ams.org/bull/2006-43-02/S0273-0979-06-01082-2/S0273-0979-06-01082-2.pdf")]#text(" contains a lot of interesting information.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cac4ac695ca9396f9a4e8c3d5bd08a2777ff385f78635998acb1c35d07f9595b-dfb19a4df41561828a6862c9c927ceb28c8955ec96a4d4de75b850d89193e9af.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Higham")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213836")[#strong[#text("Nick Higham")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2013")])]

#text("There are lots of nice result along these lines. One of my favorites is ")#mi("Af(BA) = f(AB)A")#text(" for any ")#mi("m\\times n")#text(" ")#mi("A")#text(" and ")#mi("n\\times m")#text(" ")#mi("B")#text(" such that both matrix functions (where ")#mi("f")#text(" maps square matrices to square matrices) are defined. In particular, ")#mi("A(BA)^{1/2} = (AB)^{1/2}A")#text(". The proofs are easy using the theory of matrix functions (see Section 1.8 of ")#link("http://www.maths.manchester.ac.uk/~higham/fm/index.php")[#text("http://www.maths.manchester.ac.uk/~higham/fm/index.php")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45743b4340a70d588fef6205a94d375f453e552b2af4d0b5130419770dcef97e-c5fe8943a0f98a80bd5668f0386738a6b1339f1a25ee0fb40a7ddd56005e362e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-213974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2013")])]

#text("As usual, a wonderful to learn from exposition. I was thinking if Prof. Tao could have also related determinant (det) to the rank function. I mean, the current literature suggests det as a good surrogate for the rank, than, for example, the trace function. Probably, this could have motivated some tighter approximations for the rank operator which can be immensely useful, for instance, in numerical optimization. Of course, other application for this very aspect arises in compressive sensing, and, Prof. Tao is again a seminal contributor in this area of signal processing!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/856944f43d3e77fa479b5c351d98fd1c99292c5e397e6e5e68305db2414c8963-cd3a7179ce8db682d85486cbd8b956da9e5cea93032114c8631c9f27cbe524eb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amit Bhaya")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-215209")[#strong[#text("Amit Bhaya")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2013")])]

#text("There’s also the lovely and well known formula \\det \\exp A = \\exp trace(A) with its connection to Liouville’s theorem on conservation of phase space volume by Hamiltonian flows (since Hamiltonian matrices have zero trace).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db8d6b0dd2a6763d429dc1cf12832eba7cee8c5fabaf7f58f8efedd737dcb082-e83980425ea387257586dea87a9302a3c4bf0f607bfa896cd18468b74fcc5cea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of teobanica")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-215342")[#strong[#text("teobanica")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2013")])]

#text("Hello, I’m teaching some linear algebra this semester, and, as always, quite hard to get through the first definitions, as to be able to start speaking about the magics of ")#mi("\\det")#text(".. There’s actually this problem with the very definition of ")#mi("\\det(A)")#text(": is that a volume (intuitive and nice and everything), or some more abstract thing? I learned in Romania, using abstract stuff, now I’m teaching in France, and I have to use abstract stuff as well (otherwise I’d be probably put on the death row by my colleagues :) On the other hand a Russian colleague of mine told me that, at least some 20 years ago, ")#mi("\\det(A)")#text(" was by definition a volume, in Moscow! (that’s probably why Russians are so good at it) I was wondering how the situation in the US is: any choice allowed? For math students of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-215887")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2013")])]

#text("Dear Professor Tao,")

#text("I did the calculation of the products of the two matrices X and Y, and it does not seem to give the Sylvester determinant equaltiy. Could this point be further elaborated on?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-215912")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2013")])]

#text("Oops, I didn’t set up the matrices correctly. It should be OK now…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/374d807c8c94c6ef145d38b68a4dc172907c50a9192cfb28103cbfe20de259ac-6f7e7fb244605ee3ed366d49d1cb3978bc01710d47c70af937a7aad8ecea0f5c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-239466")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2013")])]

#text("If I’m not missing something, I think you really wanted the second product to simply be the first one in reverse order, instead of using the matrix with a 0 and a -B.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-216677")[#strong[#text("Artificial Intelligence Blog · “Matrix identities as derivatives of determinant identities”")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2013")]

#text("[…] Check out Terence Tao‘s wonderful post ”Matrix identities as derivatives of determinant identities“. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/57744d317aabf2623318a0b93bec2c13a4c686b4cea94c1c7eafa52c7a7eaf31-ee1e69b722b749f580dce786d1e425137d5db5835597cc3689cef46fec32a06e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Craig Tracy")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-216994")[#strong[#text("Craig Tracy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2013")])]

#text("For an account of the use of the Sylvester det identity, det(I+AB)=det(I+BA), in random matrix theory, see C. Tracy & H. Widom, “Correlation functions, cluster functions and spacing distributions for random matrices”, J. of Statistical Physics 92 (1998) 809-835.")

#link("http://www.math.ucdavis.edu/~tracy/selectedPapers/1990s/CV59.pdf")[#text("Click to access CV59.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Supercommutative gaussian integration, and the gaussian unitary ensemble « What’s new")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-217222")[#strong[#text("Supercommutative gaussian integration, and the gaussian unitary ensemble « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2013")])]

#text("[…] later in this post. By the trick of matrix differentiation of the determinant (as reviewed in this recent blog post), one can also use this method to compute matrix-valued statistics such […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-222388")[#strong[#text("Study Hacks » Blog Archive » You Can Be Busy or Remarkable — But Not Both")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2013")]

#text("[…] new year, he’s written nine long posts, full of mathematical equations and fun titles, like “Matrix identities as derivatives of determinant identities.” His most recent post is 3700 words long! And that’s a normal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37e0bb58d41a69bb6bc2114c79a925e10c6a0f71686fba4f4d06d8968c693625-801ba2f4e1bee7145a968183b616cc151b98e10dc8fc07d93ebd228530b2ff38.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Kloster")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-264583")[#strong[#text("Kyle Kloster")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("I’m having trouble with the derivation of the block inverse form, above (6):")#linebreak()#text(" the term ")#mi("CA^{-1}B")#text(" in (3) now appears as ")#mi("BA^{-1}C")#text(", and I can’t figure out why. Then, equating the linear terms in ")#mi("\\epsilon")#text(" is said to yield")

#mi("\\text{tr}( [ A, B; C, D]^{-1} [0, 0; 0, H] ) = \\text{tr}( (D - BA^{-1}C)^{-1} H )")

#text("I don’t understand what happened to the other coefficients of these linear terms, ")#mi("\\text{det}(A)")#text(" for the right-hand side, and ")#mi("\\text{det}( [ A, B; C, D] )")#text(" for the left-hand side.")

#text("What am I missing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-264624")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Oops, there were some typos in the text (in particular, all occurrences of ")#mi("BA^{-1} C")#text(", which doesn’t even make sense as a matrix product, should be ")#mi("C A^{-1} B")#text(" instead); hopefully they are corrected now.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/37e0bb58d41a69bb6bc2114c79a925e10c6a0f71686fba4f4d06d8968c693625-801ba2f4e1bee7145a968183b616cc151b98e10dc8fc07d93ebd228530b2ff38.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kyle Kloster")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-264625")[#strong[#text("Kyle Kloster")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Thanks for the response!")#linebreak()#text(" There is still one occurrence of $BA^{-1}C$, in the paragraph immediately prior to equation (6).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-264631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2014")])]

#text("Typo: Exercise 2: “thence” –> “hence”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-305632")[#strong[#text("My Math Diary")]]#text(size: 9pt, fill: rgb("596477"), " · 20 April 2014")]

#text("[…] Derivative of determinant: Terry Tao, Stack […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Derived multiplicative functions | What's new")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-419783")[#strong[#text("Derived multiplicative functions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2014")])]

#text("[…] identities, such as (1). This phenomenon is analogous to the one in linear algebra discussed in this previous blog post, in which many of the trace identities used there are derivatives of determinant identities. For […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75cad2adb8e93236280cef121d310aab493501396b3086365056142825ca9455-75a844c9c04ef92de02313a8edb0cb755fecd635d7a9420c1d5a8c23874d1445.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pascal")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-479589")[#strong[#text("Pascal")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2017")])]

#text("Hi, may i know is there any analytic formula for the derivative of adjugate matrix w.r.t itself or its elements? i.e.")

#mi("\\displaystyle \\frac{\\partial \\text{adj}(A)}{\\partial A}")

#text("or")

#mi("\\displaystyle \\frac{\\partial \\text{adj}(A)}{\\partial a_{ij}}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Quantitative continuity estimates | What's new")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-481108")[#strong[#text("Quantitative continuity estimates | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 May 2017")])]

#text("[…] is a scalar such that is non-zero. (See also this previous blog post for more discussion of these sorts of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-481762")[#strong[#text("起源笔记 / 基于云数据的网络松鼠症分布模型设计一文")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2017")]

#text("[…] a scalar such that is non-zero. (See also this previous blog post for more discussion of these sorts of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3eea900f7db0889d1101979191e77706a6cd480a6cc40942c0cebade1d955f12-398fb1a0916c28f9e77a4cd4e9f856805d7aa76da52d6feb0beda5f7ad57e8de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of user777")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-484174")[#strong[#text("user777")]]#text(size: 9pt, fill: rgb("596477"), " · 23 July 2017")])]

#text("Is it possible to have any such derivations for permanent-trace or permanent-determinant?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dodgson condensation from Schur complementation | What's new")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-485539")[#strong[#text("Dodgson condensation from Schur complementation | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2017")])]

#text("[…] can in turn be used to establish many further identities; in particular, as shown in A HREF=”")#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities&#8230")[#text("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities&#8230")]#text("; previous post, it implies the Schur determinant […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-486308")[#strong[#text("Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2017")])]

#text("[…] the other hand, by the Woodbury matrix identity (discussed in this previous blog post), we […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-487698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("Is there any book which discusses this stuff and particularly identity 4 and its corresponding identity")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/145648907e49afb4d6d322d549062476ef414e1401c740fb77cc0bd784d38b24-3a202662e3be43bb9b8e9333c27aa7a57dce6b02c53fd11908f31c6a14d22834.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-503558")[#strong[#text("Chris")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2018")])]

#text("how can I find the derivative of det(I-2itA∑) ? Please help!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-504156")[#strong[#text("DREAM PETER SARNAK 21 AUGUST 2018 | zulfahmed")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2018")]

#text("[…] what is necessary to understand is the relation between determinant and trace and Terry has a very nice article clarifying these issues so we can understand the relations clearly: “The key observation is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f792960d6b1259917bf2bfd2ccff19db97dcd003d52a443f54f33b68e0eae79a-0e70dd22c3c74a32547537ca88f95cf79573016fdfcda1d6e0375f4d0dce166e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Leonardo Torres")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-514937")[#strong[#text("Leonardo Torres")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("What is a reference for (4)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-514941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2019")])]

#text("characteristic polynomial")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/067339b9e776a0090ca13d6ef39566081cc9c466a4bd30d3733561013891764f-a61e32216f5bbce6d48a17089f56ded88c751638336f1085d6081c9f29340402.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gilad Lerman")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-636980")[#strong[#text("Gilad Lerman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2021")])]

#text("Typo: In Exercise 2 the minus sign between the two inverses in the last two equations should be a plus sign (just found these notes when searching for material relevant for some teaching notes I write and I like it)")

#emph[#text("[Minus sign in the third equation corrected; the minus sign in the fourth equation however appears to be correct – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/067339b9e776a0090ca13d6ef39566081cc9c466a4bd30d3733561013891764f-a61e32216f5bbce6d48a17089f56ded88c751638336f1085d6081c9f29340402.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gilad Lerman")]], [#link("https://terrytao.wordpress.com/2013/01/13/matrix-identities-as-derivatives-of-determinant-identities/#comment-636989")[#strong[#text("Gilad Lerman")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2021")])]

#text("yes, of course (I focused on the third line)")
]
