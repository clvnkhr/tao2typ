// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/
// Converted to Typst by tao2typ: "2026-10-14T11:04:31.901435+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Venn and Euler type diagrams for vector spaces and abelian groups", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Venn and Euler type diagrams for vector spaces and abelian groups")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 November 2021")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/")[#text("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A popular way to visualise relationships between some finite number of sets is via ")#link("https://en.wikipedia.org/wiki/Venn_diagram")[#text("Venn diagrams")]#text(", or more generally ")#link("https://en.wikipedia.org/wiki/Euler_diagram")[#text("Euler diagrams")]#text(". In these diagrams, a set is depicted as a two-dimensional shape such as a disk or a rectangle, and the various Boolean relationships between these sets (e.g., that one set is contained in another, or that the intersection of two of the sets is equal to a third) is represented by the Boolean algebra of these shapes; Venn diagrams correspond to the case where the sets are in “general position” in the sense that all non-trivial Boolean combinations of the sets are non-empty. For instance to depict the general situation of two sets ")#mi("{A,B}")#text(" together with their intersection ")#mi("{A \\cap B}")#text(" and ")#mi("{A \\cup B}")#text(" one might use a Venn diagram such as")

#align(center)[#image("../assets/61dc0ce401a2131f4a18998bfd5eb2b8f03e03690513d20814f82755475eb6dd-25ab58284518106b71af304d9d4281c1205cc743e18f7d3d86a1c09c12c553d1.png", width: 90%, alt: "venn")]

#text("(where we have given each region depicted a different color, and moved the edges of each region a little away from each other in order to make them all visible separately), but if one wanted to instead depict a situation in which the intersection ")#mi("{A \\cap B}")#text(" was empty, one could use an Euler diagram such as")

#align(center)[#image("../assets/aa037c370bce379f2eba5413e022574d427d08f3643f9f3e06016677fcd2d433-786cda58ae614d5070a15bf556a504b2e98fbe28e0da61d44125e756b018f5ec.png", width: 90%, alt: "euler")]

#text("One can use the area of various regions in a Venn or Euler diagram as a heuristic proxy for the cardinality ")#tao-math("{\\left|A\\right|}", block: false)#text(" (or measure ")#mi("{\\mu(A)}")#text(") of the set ")#mi("{A}")#text(" corresponding to such a region. For instance, the above Venn diagram can be used to intuitively justify the inclusion-exclusion formula")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cup B\\right| = \\left|A\\right| + \\left|B\\right| - \\left|A \\cap B\\right|", block: true)]]

#text("for finite sets ")#mi("{A,B}")#text(", while the above Euler diagram similarly justifies the special case")

#align(center)[#tao-fit-display[#tao-math("\\left|A \\cup B\\right| = \\left|A\\right| + \\left|B\\right|", block: true)]]

#text("for finite ")#emph[#text("disjoint")]#text(" sets ")#mi("{A,B}")#text(".")

#text("While Venn and Euler diagrams are traditionally two-dimensional in nature, there is nothing preventing one from using one-dimensional diagrams such as")

#align(center)[#image("../assets/5bacd79bd4cb700f03509df837bedff6723507642bce69e8f39deebe9ab987ac-b4f606e47796e8e58e70ed395081c4f8484923b3d2f65c5f8273717f8f61569e.png", width: 90%, alt: "venn1d")]

#text("or even three-dimensional diagrams such as this one from Wikipedia:")

#align(center)[#image("../assets/f312f4138bccd6f7fc93f5dfe938132140cd324a2c8a14770f150bc23efd9c66-1186b63c85992f9e4cb37737a0c5def6387922d722664b9d3d27aaf5a38038e8.png", width: 90%, alt: "venn-3d")]

#text("Of course, in such cases one would use length or volume as a heuristic proxy for cardinality or measure, rather than area.")

#text("With the addition of arrows, Venn and Euler diagrams can also accommodate (to some extent) functions between sets. Here for instance is a depiction of a function ")#mi("{f: A \\rightarrow B}")#text(", the image ")#mi("{f(A)}")#text(" of that function, and the image ")#mi("{f(A^{\\prime})}")#text(" of some subset ")#mi("{A^{\\prime}}")#text(" of ")#mi("{A}")#text(":")

#align(center)[#image("../assets/c3b34297b10062c91668cae69d70738c103537e0f8e05484092575c2f871e54f-b06a99788bfe8c029193aff319ff7fa20b63a5139d15950b4c21047d8c02b19c.png", width: 90%, alt: "afb")]

#text("Here one can illustrate surjectivity of ")#mi("{f: A \\rightarrow B}")#text(" by having ")#mi("{f(A)}")#text(" fill out all of ")#mi("{B}")#text("; one can similarly illustrate injectivity of ")#mi("{f}")#text(" by giving ")#mi("{f(A)}")#text(" exactly the same shape (or at least the same area) as ")#mi("{A}")#text(". So here for instance might be how one would illustrate an injective function ")#mi("{f: A \\rightarrow B}")#text(":")

#align(center)[#image("../assets/31c730b8ff6c98a4c6a90b7d1315ecacab73e9ffbe1fcace32438061949e6bf6-f6859b38f03ffca98dde8d2c05b0792667112b23b80f194722f8e719254b04ba.png", width: 90%, alt: "afb-injective")]

#text("Cartesian product operations can be incorporated into these diagrams by appropriate combinations of one-dimensional and two-dimensional diagrams. Here for instance is a diagram that illustrates the identity ")#mi("{(A \\cup B) \\times C = (A \\times C) \\cup (B \\times C)}")#text(":")

#align(center)[#image("../assets/e72425bf09e1f21f000e416d5e220576521429e0aba5f914cd91b42db9b70937-6e32b78d808cba214c24043e0d32372651bdcfef7396213aa85347fde06ae31b.png", width: 90%, alt: "cartesian")]

#text("In this blog post I would like to propose a similar family of diagrams to illustrate relationships between ")#emph[#text("vector spaces")]#text(" (over a fixed base field ")#mi("{k}")#text(", such as the reals) or ")#emph[#text("abelian groups")]#text(", rather than sets. The categories of (")#mi("{k}")#text("-)vector spaces and abelian groups are quite similar in many ways; the former consists of ")#link("https://en.wikipedia.org/wiki/Module_(mathematics)")[#text("modules")]#text(" over a base field ")#mi("{k}")#text(", while the latter consists of modules over the integers ")#mi("{{\\bf Z}}")#text("; also, both categories are basic examples of ")#link("https://en.wikipedia.org/wiki/Abelian_category")[#text("abelian categories")]#text(". The notion of a dimension in a vector space is analogous in many ways to that of cardinality of a set; see ")#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")[#text("this previous post")]#text(" for an instance of this analogy (in the context of Shannon entropy). (UPDATE: I have learned that an essentially identical notation has also been proposed in an ")#link("https://www.3blue1brown.com/blog/exact-sequence-picturebook")[#text("unpublished manuscript of Ravi Vakil")]#text(".)")

#metadata(none) <tao-c83f058796547c7c2d0b>

#text("As with Venn and Euler diagrams, the diagrams I propose for vector spaces (or abelian groups) can be set up in any dimension. For simplicity, let’s begin with one dimension, and restrict attention to vector spaces (the situation for abelian groups is basically identical). In this one-dimensional model we will be able to depict the following relations and operations between vector spaces:")

#list(
[#text("The inclusion ")#mi("{W \\leq V}")#text(" of one vector space ")#mi("{V}")#text(" in another ")#mi("{W}")#text(" (here I prefer to use the group notation ")#mi("{\\leq}")#text(" for inclusion rather than the set notation ")#mi("{\\subseteq}")#text(").")],
[#text("The quotient ")#mi("{V/W}")#text(" of a vector space ")#mi("{V}")#text(" by a subspace ")#mi("{W}")#text(".")],
[#text("A linear transformation ")#mi("{T: V \\rightarrow W}")#text(" between vector spaces, as well as the kernel ")#mi("{\\mathrm{ker}(T)}")#text(", image ")#mi("{\\mathrm{im}(T)}")#text(", cokernel ")#mi("{\\mathrm{coker}(T) = W/\\mathrm{im}(T)}")#text(", and the coimage ")#mi("{\\mathrm{coim}(T) = V/\\mathrm{ker}(T)}")#text(".")],
[#text("A single short or long exact sequence between vector spaces.")],
[#text("(A heuristic proxy for) the dimension of a vector space.")],
[#text("Direct sum ")#mi("{V \\oplus W}")#text(" of two spaces.")]
)

#text("The idea is to use half-open intervals ")#mi("{[a,b)}")#text(" in the real line for any ")#mi("{a<b}")#text(" to model vector spaces. In fact we can make an explicit correspondence: let us identify each half-open interval ")#mi("{[a,b)}")#text(" with the (infinite-dimensional) vector space")

#align(center)[#tao-fit-display[#mitex("[a,b) \\equiv \\{ f \\in C([a,b]): f(b) = 0 \\},")]]

#text("that is ")#mi("{[a,b)}")#text(" is identified with the space of continuous functions ")#mi("{f:[a,b] \\rightarrow {\\bf R}}")#text(" on the interval ")#mi("{[a,b]}")#text(" that vanish at the right-endpoint ")#mi("{b}")#text(". Such functions can be continuously extended by zero to the half-line ")#mi("{[a,+\\infty)}")#text(".")

#text("Note that if ")#mi("{a < b < c}")#text(" then the vector space ")#mi("{[a,b)}")#text(" is a subspace of ")#mi("{[a,c)}")#text(", if we extend the functions in both spaces by zero to the half-line ")#mi("{[a,+\\infty)}")#text("; furthermore, the quotient of ")#mi("{[a,c)}")#text(" by ")#mi("{[a,b)}")#text(" is naturally identifiable with ")#mi("{[b,c)}")#text(". Thus, an inclusion ")#mi("{W \\leq V}")#text(", as well as the quotient space ")#mi("{V/W}")#text(", can be modeled here as follows:")

#align(center)[#image("../assets/032b0d356ba0a41d5b7ab20040def3324c4e6216d8bfa62b23f7c10dd0982602-6062741eb0ce1b88f86afb4f6f0dabb8be72ef1e6fc89bf7e73731a09ce4b74f.png", width: 90%, alt: "coker")]

#text("In contrast, if ")#mi("{a < b < c < d}")#text(", it is significantly less “natural” to view ")#mi("{[b,c)}")#text(" as a subspace of ")#mi("{[a,d)}")#text("; one could do it by extending functions in ")#mi("{[b,c)}")#text(" to the right by zero and to the left by constants, but in this notational convention one should view such an identification as “artificial” and to be avoided.")

#text("All of the spaces ")#mi("{[a,b)}")#text(" are infinite dimensional, but morally speaking the dimension of the vector space ")#mi("{[a,b)}")#text(" is “proportional” to the length ")#mi("{b-a}")#text(" of the corresponding interval. Intuitively, if we try to discretise this vector space by sampling at some mesh of spacing ")#mi("{\\varepsilon}")#text(", one gets a finite-dimensional vector space of dimension roughly ")#mi("{(b-a)/\\varepsilon}")#text(". Already the above diagram now depicts the basic identity")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim}(V) = \\mathrm{dim}(W) + \\mathrm{dim}(V/W)")]]

#text("between a finite-dimensional vector space ")#mi("{V}")#text(", a subspace ")#mi("{W}")#text(" of that space, and a quotient of that space.")

#text("Note that if ")#mi("{a < b < c < d}")#text(", then there is a linear transformation ")#mi("{T}")#text(" from the vector space ")#mi("{[a,c)}")#text(" to the vector space ")#mi("{[b,d)}")#text(" which takes a function ")#mi("{f}")#text(" in ")#mi("{[a,c)}")#text(", restricts it to ")#mi("{[b,c)}")#text(", then extends it by zero to ")#mi("{[b,d)}")#text(". The kernel of this transformation is ")#mi("{[a,b)}")#text(", the image is (isomorphic to) ")#mi("{[b,c)}")#text(", the ")#link("https://en.wikipedia.org/wiki/Cokernel")[#text("cokernel")]#text(" is (isomorphic to) ")#mi("{[c,d)}")#text(", and the ")#link("https://en.wikipedia.org/wiki/Coimage")[#text("coimage")]#text(" is (isomorphic to) ")#mi("{[b,c)}")#text(". With this in mind, we can now depict a general linear transformation ")#mi("{T: V \\rightarrow W}")#text(" and its associated spaces by the following diagram:")

#align(center)[#image("../assets/46b9425a345b97d4e2f72b8fdd1d0cc3da4e3ae9ede670565377854d6bbac5df-469c281e5094a4461c6b06233eef0ea35e921ce2ccca86dbaa1a30104b38b396.png", width: 90%, alt: "rank-nullity")]

#text("Note how the ")#link("https://en.wikipedia.org/wiki/Isomorphism_theorems#Theorem_A_(groups)")[#text("first isomorphism theorem")]#text(" and the ")#link("https://en.wikipedia.org/wiki/Rank%E2%80%93nullity_theorem")[#text("rank-nullity theorem")]#text(" are heuristically illustrated by this diagram. One can specialise to the case of injective, surjective, or bijective transformations ")#mi("{T}")#text(" by degenerating one or more of the half-open intervals in the above diagram to the empty interval. A left shift on ")#mi("{[a,b)}")#text(" gives rise to a nilpotent linear transformation ")#mi("{T}")#text(" from ")#mi("{[a,b)}")#text(" to itself:")

#align(center)[#image("../assets/4a81c21df61a5670a54ef5c48c3b662b609f968ba59bf1070596cf9e0dd5e80d-bcea5974dd84dc25ca314d823603500718558cfe4d34f1084b7f4e32b8a74ebf.png", width: 90%, alt: "nilpotent")]

#text("In a similar spirit, a ")#link("https://en.wikipedia.org/wiki/Exact_sequence#Short_exact_sequence")[#text("short exact sequence")]#text(" ")#mi("{0 \\rightarrow U \\rightarrow V \\rightarrow W \\rightarrow 0}")#text(" of vector spaces (or abelian groups) can now be depicted by the diagram")

#align(center)[#image("../assets/d47d6934e13259bd16227e06baf7e129b00df80a7bfc3e726b69c1287bed8bc0-c400060d1f2d7c9785b9b4292d5057e197459c5ec2bba613126cc3a8d2a9acb9.png", width: 90%, alt: "short-exact")]

#text("and a ")#link("https://en.wikipedia.org/wiki/Exact_sequence")[#text("long exact sequence")]#text(" ")#mi("{V_1 \\rightarrow V_2 \\rightarrow V_3 \\rightarrow \\dots}")#text(" can similarly be depicted by the diagram")

#align(center)[#image("../assets/d71a057f63843d8935e69e7edb9782bbcc76c632cb48d128c320eae3401a3420-cb0add94208804126d2f9755a5c858002104e7a36e82ef3365208f3158eca394.png", width: 90%, alt: "long-exact")]

#text("UPDATE: As I have learned from an ")#link("https://www.3blue1brown.com/blog/exact-sequence-picturebook")[#text("unpublished manuscript of Ravi Vakil")]#text(", this notation can also easily depict the cohomology groups ")#mi("{H^1,H^2,H^3,\\dots}")#text(" of a ")#link("https://en.wikipedia.org/wiki/Chain_complex")[#text("cochain complex")]#text(" ")#mi("{A^0 \\rightarrow A^1 \\rightarrow A^2 \\rightarrow A^3 \\rightarrow \\dots}")#text(" by the diagram")

#align(center)[#image("../assets/31ac40b1953f1eb577b8d38129ca16402969d44db69fad67dd2392c0703674bd-13e8c2b04650cf1f0d0e9da016c69c75717f3c839c8b114c09827df1352ab86a.png", width: 90%, alt: "cohomology")]

#text("and similarly depict the homology groups ")#mi("{H_1, H_2, H_3, \\dots}")#text(" of a ")#link("https://en.wikipedia.org/wiki/Chain_complex")[#text("chain complex")]#text(" ")#mi("{A_0 \\leftarrow A_1 \\leftarrow A_2 \\leftarrow \\dots}")#text(" by the diagram")

#align(center)[#image("../assets/d59644872a26aac5db4ee6919a2b30f1a9eda37c61c9ddb948c6b19ca459b298-784ddd54bb2aa70cbb7769410cee47c01dabdde3c18c00cba8088f8236531713.png", width: 90%, alt: "homology")]

#text("One can associate the disjoint union of half-open intervals to the direct sum of the associated vector spaces, giving a way to depict direct sums via this notation:")

#align(center)[#image("../assets/cbd8eda24b3304f1004ebf395a9309dd4dca40705baa86a4b5f2985ba79325ac-689c0703da1bdb6245eb4455288eebd23007576908de65aeb6099e19eaad7db7.png", width: 90%, alt: "direct-sum")]

#text("To increase the expressiveness of this notation we now move to two dimensions, where we can also depict the following additional relations and operations:")

#list(
[#text("The intersection ")#mi("{U \\cap V}")#text(" and sum ")#mi("{U+V}")#text(" of two subspaces ")#mi("{U,V \\leq W}")#text(" of an ambient space ")#mi("{W}")#text(";")],
[#text("Multiple short or long exact sequences;")],
[#text("The tensor product ")#mi("{U \\otimes V}")#text(" of two vector spaces ")#mi("{U,V}")#text(".")]
)

#text("Here, we replace half-open intervals by half-open sets: geometric shapes ")#mi("{S}")#text(", such as polygons or disks, which contain some portion of the boundary (drawn using solid lines) but omit some other portion of the boundary (drawn with dashed lines). Each such shape can be associated with a vector space, namely the continuous functions on ")#mi("{\\overline{S}}")#text(" that vanish on the omitted portion of the boundary. All of the relations that were previously depicted using one-dimensional diagrams can now be similarly depicted using two-dimensional diagrams. For instance, here is a two-dimensional depiction of a vector space ")#mi("{V}")#text(", a subspace ")#mi("{W}")#text(", and its quotient ")#mi("{V/W}")#text(":")

#align(center)[#image("../assets/d904c9d474a63b135c8792b4ea1440cc29a921964e894579e943fe97ca6eca93-b9653922845c462c540c11328f865703fd7882053204507ea05c0946b8775a02.png", width: 90%, alt: "coker-2D")]

#text("(In this post I will try to consistently make the lower and left boundaries of these regions closed, and the upper and right boundaries open, although this is not essential for this notation to be applicable.)")

#text("But now we can depict some additional relations. Here for instance is one way to depict the intersection ")#mi("{U \\cap V}")#text(" and sum ")#mi("{U+V}")#text(" of two subspaces ")#mi("{U,V \\leq W}")#text(":")

#align(center)[#image("../assets/4eb5179f12d3f49f86477d076eae9ebc1a16068a6b0a7e0a60adee01a93f0e8e-9cd97264390ee7be40d7b7e2ec29c1c174762495ca99b1b24b544f669e114dba.png", width: 90%, alt: "uvw")]

#text("Note how this illustrates the identity")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim}(U + V) = \\mathrm{dim}(U) + \\mathrm{dim}(V) - \\mathrm{dim}(U \\cap V)")]]

#text("between finite-dimensional vector spaces ")#mi("{U, V}")#text(", as well as some standard isomorphisms such as ")#mi("{(U+V)/U \\equiv V/(U \\cap V)}")#text(".")

#text("Two finite subgroups ")#mi("{H,K}")#text(" of an abelian group ")#mi("{G}")#text(" are said to be ")#emph[#text("commensurable")]#text(" if ")#mi("{H \\cap K}")#text(" is a finite index subgroup of ")#mi("{H+K}")#text(". One can depict this by making the area of the region between ")#mi("{H \\cap K}")#text(" and ")#mi("{H+K}")#text(" small and/or colored with some specific color:")

#align(center)[#image("../assets/9c0c110d386595a60db929ffc8996690fbadba10bc73f0eb6b1b90318c8a3267-32793b2b25890685cb7a71a979aa5acce60b4e80f6461deab52d5d2be2011a3d.png", width: 90%, alt: "ghk")]

#text("Here the commensurability of ")#mi("{H,K}")#text(" is equivalent to the finiteness of the groups ")#mi("{H / (H \\cap K) \\equiv (H+K)/K}")#text(" and ")#mi("{K / (H \\cap K) \\equiv (H+K)/H}")#text(", which correspond to the gray triangles in the above diagram. Now for instance it becomes intuitively clear why commensurability should be an equivalence relation.")

#text("To illustrate how this notation can support multiple short exact sequences, I gave myself the exercise of using this notation to depict the ")#link("https://en.wikipedia.org/wiki/Snake_lemma")[#text("snake lemma")]#text(", as labeled by this following diagram taken from the just linked Wikipedia page:")

#align(center)[#image("../assets/38ddeca5f5010ef1f1372e4a6381678a643d07fe42822e48b0cb0beda5ae21a3-e8a4673c5b03671537b27e7c584fd3ee1c89d365d82ee202137e29701f6e1c33.png", width: 90%, alt: "snake")]

#text("This turned out to be remarkably tricky to accomplish without introducing degeneracies (e.g., one of the kernels or cokernels vanishing). Here is one solution I came up with; perhaps there are more elegant ones. In particular, there should be a depiction that more explicitly captures the duality symmetry of the snake diagram.")

#align(center)[#image("../assets/e22dab41d7708cb59831b6497a0f362416e91596fb2c526d4369022a43211497-95dfb64e841decc19b147f1f753b65ed7f8e1f3b772c087a1593726cee66193b.png", width: 90%, alt: "bigsnake")]

#text("Here, the maps between the six spaces ")#mi("{A,B,C,A^{\\prime},B^{\\prime},C^{\\prime}}")#text(" are the obvious restriction maps (and one can visually verify that the two squares in the snake diagram actually commute). Each of the kernel and cokernel spaces of the three vertical restriction maps ")#mi("{a,b,c}")#text(" are then associated to the union of two of the subregions as indicated in the diagram. Note how the overlaps between these kernels and cokernels generate the long exact “snake”.")

#text("UPDATE: by modifying a similar diagram in an ")#link("https://www.3blue1brown.com/blog/exact-sequence-picturebook")[#text("unpublished manuscript of Ravi Vakil")]#text(", I can now produce a more symmetric version of the above diagram, again with a very visible “snake”:")

#align(center)[#image("../assets/6c3fefd435d946ec69f6fc415bd56d22b3b92154bcf75dfe15964954a0cee987-d753f0c9247435dfc291ccb85fe9d1863d845fadf1b829429a1e1d7f2caf9059.png", width: 90%, alt: "newsnake")]

#text("With our notation, the (algebraic) tensor product of an interval ")#mi("{[a,b)}")#text(" and another interval ")#mi("{[c,d)}")#text(" is not quite ")#mi("{[a,b) \\times [c,d)}")#text(", but this becomes true if one uses the ")#mi("{C^*}")#text("-algebra version of the tensor product, thanks to the ")#link("https://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(". So one can plausibly use Cartesian products as a proxy for the vector space tensor product. For instance, here is a depiction of the relation ")#mi("{(U \\otimes W) / (V \\otimes W) \\equiv (U/V) \\otimes W}")#text(" when ")#mi("{V}")#text(" is a subspace of ")#mi("{U}")#text(":")

#align(center)[#image("../assets/89cb110dc2d20b2bf276b1e1c517f36b640d2d07fc93ee8822419e4c90b539e1-01cf2f07d28ff941a85118411ecba2e2ad60a42fe9d30b64209ac6d703a2f417.png", width: 90%, alt: "tensor-quotient")]

#text("There are unfortunately some limitations to this notation: for instance, no matter how many dimensions one uses for one’s diagrams, these diagrams would suggest the incorrect identity")

#align(center)[#tao-fit-display[#mitex("\\mathrm{dim}(U +V + W) = \\mathrm{dim} U + \\mathrm{dim} V + \\mathrm{dim} W - \\mathrm{dim} (U \\cap V) - \\mathrm{dim} (U \\cap W) - \\mathrm{dim} (V \\cap W) + \\mathrm{dim}(U \\cap V \\cap W),")]]

#text("(which incidentally is, at this time of writing, the ")#link("https://mathoverflow.net/a/23501/766")[#text("highest-voted answer")]#text(" to the MathOverflow question “")#link("https://mathoverflow.net/questions/23478/examples-of-common-false-beliefs-in-mathematics")[#text("Examples of common false beliefs in mathematics")]#text("“). (See also ")#link("https://terrytao.wordpress.com/2017/03/01/special-cases-of-shannon-entropy/")[#text("this previous blog post")]#text(" for a similar phenomenon when using sets or vector spaces to model entropy of information variables.) Nevertheless it seems accurate enough to be of use in illustrating many common relations between vector spaces and abelian groups. With appropriate grains of salt it might also be usable for further categories beyond these two, though for non-abelian categories one should proceed with caution, as the diagram may suggest relations that are not actually true in this category. For instance, in the category of topological groups one might use the diagram")

#align(center)[#image("../assets/6b02b12e840102b7cd8b73ac3061c4b057a7e4bc267a660b05f8de8e1b8dbd6d-e60a6c7f9d054e83b22c5b4c068ec79e52fae017209ef0bf0ea3305a5fc0fc5f.png", width: 90%, alt: "topgroup")]

#text("to describe the fact that an arbitrary topological group splits into a connected subgroup and a ")#link("https://en.wikipedia.org/wiki/Totally_disconnected_group")[#text("totally disconnected")]#text(" quotient, or in the category of finite-dimensional Lie algebras over the reals one might use the diagram")

#align(center)[#image("../assets/1f6a90387e3762f4a9cf7c6bff641637b58f1af73be4a58cb3aa580ab25980c8-1c8bef42d1768857c04c921bee468287865db4b7dd2fc8aa45da6ec21e773bb4.png", width: 90%, alt: "liealg")]

#text("to describe the fact that such algebras split into the ")#link("https://en.wikipedia.org/wiki/Radical_of_a_Lie_algebra")[#text("solvable radical")]#text(" and a ")#link("https://en.wikipedia.org/wiki/Semisimple_Lie_algebra")[#text("semisimple")]#text(" quotient.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9539794bf32d89b8da8631392db0777412aa5f411207b7c49425d1fff755789d-083283f64e0ca2910772ccf9e9ba7617baa01093bbb3ff88ad63b5e9b3a7003f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yitzi Litt")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636833")[#strong[#text("Yitzi Litt")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2021")])]

#text("Your use of that 3-dimensional diagram from Wikipedia got me thinking—I don’t know if it would be the most effective use of your time, but do you ever contribute to math articles on Wikipedia? They tend to be the first results people find when doing online research, and a lot of work could be done in improving the quality of higher-level math articles there.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Ask you students to do it. It is a good way to learn to communicate math.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-637962")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2021")])]

#text("I’ll tell my students to work on that!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636835")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2021")])]

#text("It seems the image just after “Thus, an inclusion {W \\leq V}, as well as the quotient space {V/W}, can be modeled here as follows:” is not visible.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e6a37a4c2a0347d09ee02a4dbfb4c957645badaf49c5317dc4396f4bb33261d-c8a2630495db31b42014620b2e20c00a832c875dbd1f56b6245eb87f61ead64a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of saber abdsamad")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636838")[#strong[#text("saber abdsamad")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2021")])]

#text("Thank you a million")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636846")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("It seems the key point here is that sums and quotients in an abelian category share certain similarities with Boolean operations, which is why these Booleon visual representations can capture some aspects of their behavior.")

#text("But the visualizations go wrong when these similarities end. Indeed, the reason why")#linebreak()#text(" ")#mi("\\displaystyle \\mathrm{dim}(U +V + W) = \\mathrm{dim} U + \\mathrm{dim} V + \\mathrm{dim} W - \\mathrm{dim} (U \\cap V) - \\mathrm{dim} (U \\cap W) - \\mathrm{dim} (V \\cap W) + \\mathrm{dim}(U \\cap V \\cap W)")#linebreak()#text(" fails is because ")#mi("(U+V) \\cap W \\neq (U \\cap W) + (V \\cap W)")#text(", as pointed out on MathOverflow. Here the analogy between sums and unions breaks down, as the identity ")#mi("(U \\cup V) \\cap W = (U \\cap W) \\cup (V \\cap W)")#text(" does hold.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636849")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("(I meant to say that quotients are analogous to taking complements, not intersections)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636855")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("This is the distributive law (where union is interpreted as addition and intersection is interpreted as multiplication) – this is illustrated also by a probability measure over its measurable sets.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/050520acdb98e0c9a495ff6013ecd3d53704666518a2b9c35949e560b89e2535-4558249137f7efe2cd45bea0bb5a8235b10715074f8ce48ffea40ec1f6e50eff.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mµvh 773")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636850")[#strong[#text("Mµvh 773")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Thanks for this article. I think it’s a good thing to take some time to think about the elementary concepts to better understand them. Notations, terminology and visual representations are really important for this purpose.")

#text("Furthermore, at the end of the list of what the one-dimensional model can represent, there is a tensor product symbol instead of a direct sum.")

#text("Moreover, there seem to be two missing images, replaced by textual placeholders. (Maybe it’s a bug from my browser.)")#linebreak()#text(" – Right after “For instance, here is a two-dimensional depiction of a vector space…”, there is a placeholder “coker-2D”.")#linebreak()#text(" – In place of the snake lemma diagram from Wikipedia, there is a placeholder “snake”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("is it suitable to the structure of ORF？")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11a24b38007dc03aa218f3eb92b8e79681e6f810e378f3bfa2729b078f8609ac-505d6030ec57e5ef3a5aa385754c06d78ee8b223b1e093b26795af5b0a91bc31.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajan Anantharaman")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636852")[#strong[#text("Rajan Anantharaman")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Thanks")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636857")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("The limitations/false belief you mention made me think of a basic problem in algebraic geometry. In algebra (say, of ideals in rings) one faces a lattice of linear subspaces whereas in geometry (say, of algebraic subsets of C^n) one faces a lattice of subsets. It’s impossible on the face of things to set up a genuine correspondence between these concepts because the latter is a distributive lattice, whereas the former is only a modular lattice.")

#text("One can fix this by restricting from all ideals to radical ideals, which is a subposet that isn’t a sublattice (the join operation is different — I join J is not I+J but sqrt{I+J}), and then things work out thanks to the Nullstellensatz.")

#text("Anyway I think you have the same issue here, that it’s hard to model the non-distributive lattice of linear subspaces using the distributive lattice of subsets of the plane (your pictures).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b9d2b471a95950cf9ab900a2a956433a802e53dd7dce19b8f99e969eecbfb6d-928b219cdc034ba412fab685a5c24ece80537934e15e706cc872bf337f74deba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of allenknutson")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636858")[#strong[#text("allenknutson")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Oops, not too different from what Rex points out.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/447ac5d4f850ff9b1b8baef78c21d8b72ef530401a31f0392e5fcae3ec2643f0-5af156fe1ad02906d5711bf81e559383e3ae3c5a5db1ad997d99f4bc5271a6dd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Herkes")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636860")[#strong[#text("Daniel Herkes")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Thank you so much for this article. I found it illuminating, indeed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Both cardinality and dimension can be interpreted as quantitative complexity measures for their corresponding mathematical structures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636868")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("Such a good and well-written article, this make me re-consider basic concepts. Thanks for sharing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/02242c47c189bdeee6118d74b2f6d153f67b1257413b83486b2a8af92c31af13-2924c613ac702b4e69366a83b09c13ca5a2388f04ed910d1e729ca540e073d0d.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terrence Tao: Venne & Euler Type Diagrams for Vector Spaces and Abelian Groups | Math Online Tom Circle")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636876")[#strong[#text("Terrence Tao: Venne & Euler Type Diagrams for Vector Spaces and Abelian Groups | Math Online Tom Circle")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2021")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian&#8230")[#text("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636880")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2021")])]

#text("Reblogged this on ")#link("https://scoutmathematics.wordpress.com/2021/11/09/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/")[#text("Aditya Guha Roy's weblog")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f5fbcae8fa2e6db3cfd7a8e2d31c7620f87815c0e20a4ce698aad3bbfdfacf54-8d015a52c761b2bcd3156446c9c87b0cbc13b67115090102060d61913cb62b81.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of DT")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636887")[#strong[#text("DT")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2021")])]

#text("You could formalize some aspect of your diagrams with sheaf theory. To each domain U in R^n, with some dashed parts on the boundary, you can consider the sheaf of continuous functions on U-closure that vanish on the dashed parts. Similar to your story, there’s an interesting homomorphism (sheaf of [a,b)) –> (sheaf of [c,d)) exactly when a < c < b < d.")

#text("New sheaves can be built from old ones by taking direct sums, kernels and cokernels. The more complicated diagrams in the post might match sheaves of this form. If at the start \"continuous functions\" are replaced by \"locally constant functions,\" the things built this way are called \"constructible sheaves.\"")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636915")[#strong[#text("Venn Vectors? – The nth Root")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2021")]

#text("[…] A popular way to visualise relationships between some finite number of sets is via Venn diagrams, or more generally Euler diagrams. In these diagrams, a set is depicted as a two-dimensional shape such as a disk or a rectangle, and the various Boolean relationships between these sets (e.g., that one set is contained in another, or that the intersection of two of the sets is equal to a third) is represented by the Boolean algebra of these shapes; Venn diagrams correspond to the case where the sets are in “general position” in the sense that all non-trivial Boolean combinations of the sets are non-empty. For instance to depict the general situation of two sets together with their intersection and one might use a Venn diagram such as … (What’s new / Terry Tao) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cb494461e4227fc760398a7b4f79d876e3d5159331759c9de724d7026bc1a64-f16b27a8814218c3040363c4e9cad3c0155e128c287aa4b5b3d4df51fd50a291.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Grieser")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636926")[#strong[#text("Daniel Grieser")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2021")])]

#text("This kind of representation is also useful in the theory of Fredholm operators. I have used it in an index theory class to give a direct (and still intelligible) proof that the composition of Fredholm operators is Fredholm, and that the indices add up.")#linebreak()#text(" (To make it more analogous to the standard way or representing maps I drew the intervals vertically, not horizontally.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-636927")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2021")])]

#text("Such concise representation may help also (perhaps after some generalization) to discover new structural patterns and relations among general mathematical structures.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-637076")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2021")])]

#text("Update: the unpublished manuscript of Ravi Vakil mentioned in the post is now available online at ")#link("https://www.3blue1brown.com/blog/exact-sequence-picturebook")[#text("https://www.3blue1brown.com/blog/exact-sequence-picturebook")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a50558aa1b180def34b75df4928f170b17b189569422afc0b8a4b015794c311-28905f85011fa07e1bd29038ebe4728d044cde5ae5da1cdee99a560baaf94a61.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Just curious")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-637082")[#strong[#text("Just curious")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2021")])]

#text("Great minds think perhaps alike.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12e65c6f3cd64852a591d42b6bebccc8a6fc98d17c9eb76fb08649bdf0990a68-0ee26c3e16bc1ec9aee5fe9632040d86aa6d7d7395633fb00a5e7f7e5a17ade6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francyelle Almeida")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-637402")[#strong[#text("Francyelle Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2021")])]

#text("Follow the Flow: sets, relations, and categories as")#linebreak()#text(" special cases of functions with no domain. ")#link("https://arxiv.org/pdf/1912.00801.pdf")[#text("https://arxiv.org/pdf/1912.00801.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a8e7ee6bda04af3635453a7939ce6953c5a80e4610e2d1be3dbd991e1d366690-6d95ab0a96bbf24d61084a61701364323983685829a819df5fca04b660967a91.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Francesco Minnocci")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-638127")[#strong[#text("Francesco Minnocci")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2021")])]

#text("Just a note: it looks like you switched `H_3` and `H_2` in the example diagram depicting the Homology groups of a chain complex.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69b9ad58345a579e8e5499f60aab26804a6452c4d14642d07997c5a0a0c9c206-c587e1e14d2fddfd8da4bfe28b0ee4b7c40209d5783f99c4986d3977fac334de.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xinwen Liu")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-638980")[#strong[#text("Xinwen Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2022")])]

#text("In his 1935 textbook LOGIC (in Chinese) Jin Yuelin (1895-1984) uses a kind of dashed Venn type diagrams to formulate the distribution laws in calculus of classes. ")#link("https://link.springer.com/chapter/10.1007/978-3-030-86062-2_26")[#text("https://link.springer.com/chapter/10.1007/978-3-030-86062-2_26")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-682351")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2023")])]

#text("There are some solid (closed) lines in the interior of the diagram showing intersection and sum of subspaces, but I think these should all be dashed (open) lines.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2021/11/07/venn-and-euler-type-diagrams-for-vector-spaces-and-abelian-groups/#comment-689530")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2025")])]

#text("Dear Dr. Tao, regarding the incorrect dim(U+V+W)")#linebreak()#text(" formula you mentioned: while it is easy to find counterexamples (like take 3 lines in a plane), I am wondering what the underlying reason of this failure is. It feels so counterintuitive——Is there a deeper structural explanation for why this analogy fails?")
]
