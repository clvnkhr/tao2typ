// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/
// Converted to Typst by tao2typ: "2026-10-14T16:37:30.445043+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Discretised wave equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Discretised wave equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 November 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/")[#text("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Wave_equation")[#text("wave equation")]#text(" is usually expressed in the form")

#align(center)[#tao-fit-display[#mitex("\\partial_{tt} u - \\Delta u = 0")]]

#text("where ")#mi("{u \\colon {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a function of both time ")#mi("{t \\in {\\bf R}}")#text(" and space ")#mi("{x \\in {\\bf R}^d}")#text(", with ")#mi("{\\Delta}")#text(" being the Laplacian operator. One can generalise this equation in a number of ways, for instance by replacing the spatial domain ")#mi("{{\\bf R}^d}")#text(" with some other manifold and replacing the Laplacian ")#mi("{\\Delta}")#text(" with the Laplace-Beltrami operator or adding lower order terms (such as a potential, or a coupling with a magnetic field). But for sake of discussion let us work with the classical wave equation on ")#mi("{{\\bf R}^d}")#text(". We will work formally in this post, being unconcerned with issues of convergence, justifying interchange of integrals, derivatives, or limits, etc.. One then has a conserved energy")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\frac{1}{2} \\left|\\nabla u(t,x)\\right|^2 + \\frac{1}{2} \\left|\\partial_t u(t,x)\\right|^2\\ dx", block: true)]]

#text("which we can rewrite using integration by parts and the ")#mi("{L^2}")#text(" inner product ")#mi("{\\langle, \\rangle}")#text(" on ")#mi("{{\\bf R}^d}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\langle -\\Delta u(t), u(t) \\rangle + \\frac{1}{2} \\langle \\partial_t u(t), \\partial_t u(t) \\rangle.")]]

#text("A key feature of the wave equation is ")#emph[#text("finite speed of propagation")]#text(": if, at time ")#mi("{t=0}")#text(" (say), the initial position ")#mi("{u(0)}")#text(" and initial velocity ")#mi("{\\partial_t u(0)}")#text(" are both supported in a ball ")#tao-math("{B(x_0,R) := \\{ x \\in {\\bf R}^d: \\left|x-x_0\\right| \\leq R \\}}", block: false)#text(", then at any later time ")#mi("{t>0}")#text(", the position ")#mi("{u(t)}")#text(" and velocity ")#mi("{\\partial_t u(t)}")#text(" are supported in the larger ball ")#mi("{B(x_0,R+t)}")#text(". This can be seen for instance (formally, at least) by inspecting the exterior energy")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|x-x_0\\right| > R+t} \\frac{1}{2} \\left|\\nabla u(t,x)\\right|^2 + \\frac{1}{2} \\left|\\partial_t u(t,x)\\right|^2\\ dx", block: true)]]

#text("and observing (after some integration by parts and differentiation under the integral sign) that it is non-increasing in time, non-negative, and vanishing at time ")#mi("{t=0}")#text(".")

#text("The wave equation is second order in time, but one can turn it into a first order system by working with the pair ")#mi("{(u(t),v(t))}")#text(" rather than just the single field ")#mi("{u(t)}")#text(", where ")#mi("{v(t) := \\partial_t u(t)}")#text(" is the velocity field. The system is then")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u(t)  & = v(t)", block: true)



#tao-math("\\partial_t v(t)  & = \\Delta u(t)", block: true)
]

#text("and the conserved energy is now ")#metadata(none) <tao-381cfb6e1e428419d5d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{2} \\langle -\\Delta u(t), u(t) \\rangle + \\frac{1}{2} \\langle v(t), v(t) \\rangle.")]]

#text("Finite speed of propagation then tells us that if ")#mi("{u(0),v(0)}")#text(" are both supported on ")#mi("{B(x_0,R)}")#text(", then ")#mi("{u(t),v(t)}")#text(" are supported on ")#mi("{B(x_0,R+t)}")#text(" for all ")#mi("{t>0}")#text(". One also has time reversal symmetry: if ")#mi("{t \\mapsto (u(t),v(t))}")#text(" is a solution, then ")#mi("{t \\mapsto (u(-t), -v(-t))}")#text(" is a solution also, thus for instance one can establish an analogue of finite speed of propagation for negative times ")#mi("{t<0}")#text(" using this symmetry.")

#text("If one has an eigenfunction")

#align(center)[#tao-fit-display[#mitex("-\\Delta \\phi = \\lambda^2 \\phi")]]

#text("of the Laplacian, then we have the explicit solutions")

#tao-aligned(keep: true)[


#tao-math("u(t)  & = e^{\\pm it \\lambda} \\phi", block: true)



#tao-math("v(t)  & = \\pm i \\lambda e^{\\pm it \\lambda} \\phi", block: true)
]

#text("of the wave equation, which formally can be used to construct all other solutions via the principle of superposition.")

#text("When one has vanishing initial velocity ")#mi("{v(0)=0}")#text(", the solution ")#mi("{u(t)}")#text(" is given via functional calculus by")

#align(center)[#tao-fit-display[#mitex("u(t) = \\cos(t \\sqrt{-\\Delta}) u(0)")]]

#text("and the propagator ")#mi("{\\cos(t \\sqrt{-\\Delta})}")#text(" can be expressed as the average of half-wave operators:")

#align(center)[#tao-fit-display[#mitex("\\cos(t \\sqrt{-\\Delta}) = \\frac{1}{2} ( e^{it\\sqrt{-\\Delta}} + e^{-it\\sqrt{-\\Delta}} ).")]]

#text("One can view ")#mi("{\\cos(t \\sqrt{-\\Delta} )}")#text(" as a minor of the full wave propagator")

#tao-aligned(keep: true)[


#tao-math("U(t)  & := \\exp \\begin{pmatrix} 0 & t \\\\ t\\Delta & 0 \\end{pmatrix}", block: true)



#tao-math(" & = \\begin{pmatrix} \\cos(t \\sqrt{-\\Delta}) & \\frac{\\sin(t\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}} \\\\ \\sin(t\\sqrt{-\\Delta}) \\sqrt{-\\Delta} & \\cos(t \\sqrt{-\\Delta} ) \\end{pmatrix}", block: true)
]

#text("which is unitary with respect to the energy form ")#link(<tao-381cfb6e1e428419d5d6>)[#text("(1)")]#text(", and is the fundamental solution to the wave equation in the sense that ")#metadata(none) <tao-c5718558396e4afeeeab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\begin{pmatrix} u(t) \\\\ v(t) \\end{pmatrix} = U(t) \\begin{pmatrix} u(0) \\\\ v(0) \\end{pmatrix}.")]]

#text("Viewing the contraction ")#mi("{\\cos(t\\sqrt{-\\Delta})}")#text(" as a minor of a unitary operator is an instance of the “")#link("http://en.wikipedia.org/wiki/Naimark%27s_dilation_theorem")[#text("dilation trick")]#text("“.")

#text("It turns out (as I learned from Yuval Peres) that there is a useful discrete analogue of the wave equation (and of all of the above facts), in which the time variable ")#mi("{t}")#text(" now lives on the integers ")#mi("{{\\bf Z}}")#text(" rather than on ")#mi("{{\\bf R}}")#text(", and the spatial domain can be replaced by discrete domains also (such as graphs). Formally, the system is now of the form ")#metadata(none) <tao-31f78e7ffc3c06ef69da>

#tao-aligned(keep: true)[


#tao-math("u(t+1)  & = P u(t) + v(t)", block: true, numbering: n => [#text("(3)")])



#tao-math("v(t+1)  & = P v(t) - (1-P^2) u(t)", block: true)
]

#text("where ")#mi("{t}")#text(" is now an integer, ")#mi("{u(t), v(t)}")#text(" take values in some Hilbert space (e.g. ")#mi("{\\ell^2}")#text(" functions on a graph ")#mi("{G}")#text("), and ")#mi("{P}")#text(" is some operator on that Hilbert space (which in applications will usually be a self-adjoint contraction). To connect this with the classical wave equation, let us first consider a rescaling of this system")

#tao-aligned(keep: true)[


#tao-math("u(t+\\varepsilon)  & = P_\\varepsilon u(t) + \\varepsilon v(t)", block: true)



#tao-math("v(t+\\varepsilon)  & = P_\\varepsilon v(t) - \\frac{1}{\\varepsilon} (1-P_\\varepsilon^2) u(t)", block: true)
]

#text("where ")#mi("{\\varepsilon>0}")#text(" is a small parameter (representing the discretised time step), ")#mi("{t}")#text(" now takes values in the integer multiples ")#mi("{\\varepsilon {\\bf Z}}")#text(" of ")#mi("{\\varepsilon}")#text(", and ")#mi("{P_\\varepsilon}")#text(" is the wave propagator operator ")#mi("{P_\\varepsilon := \\cos( \\varepsilon \\sqrt{-\\Delta} )}")#text(" or the heat propagator ")#mi("{P_\\varepsilon := \\exp( - \\varepsilon^2 \\Delta/2 )}")#text(" (the two operators are different, but agree to fourth order in ")#mi("{\\varepsilon}")#text("). One can then formally verify that the wave equation emerges from this rescaled system in the limit ")#mi("{\\varepsilon \\rightarrow 0}")#text(". (Thus, ")#mi("{P}")#text(" is not exactly the direct analogue of the Laplacian ")#mi("{\\Delta}")#text(", but can be viewed as something like ")#mi("{P_\\varepsilon = 1 - \\frac{\\varepsilon^2}{2} \\Delta + O( \\varepsilon^4 )}")#text(" in the case of small ")#mi("{\\varepsilon}")#text(", or ")#mi("{P = 1 - \\frac{1}{2}\\Delta + O(\\Delta^2)}")#text(" if we are not rescaling to the small ")#mi("{\\varepsilon}")#text(" case. The operator ")#mi("{P}")#text(" is sometimes known as the ")#emph[#text("diffusion operator")]#text(")")

#text("Assuming ")#mi("{P}")#text(" is self-adjoint, solutions to the system ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(" formally conserve the energy ")#metadata(none) <tao-df2f48cbadfcd621ef30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{1}{2} \\langle (1-P^2) u(t), u(t) \\rangle + \\frac{1}{2} \\langle v(t), v(t) \\rangle.")]]

#text("This energy is positive semi-definite if ")#mi("{P}")#text(" is a contraction. We have the same time reversal symmetry as before: if ")#mi("{t \\mapsto (u(t),v(t))}")#text(" solves the system ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(", then so does ")#mi("{t \\mapsto (u(-t), -v(-t))}")#text(". If one has an eigenfunction")

#align(center)[#tao-fit-display[#mitex("P \\phi = \\cos(\\lambda) \\phi")]]

#text("to the operator ")#mi("{P}")#text(", then one has an explicit solution")

#tao-aligned(keep: true)[


#tao-math("u(t)  & = e^{\\pm it \\lambda} \\phi", block: true)



#tao-math("v(t)  & = \\pm i \\sin(\\lambda) e^{\\pm it \\lambda} \\phi", block: true)
]

#text("to ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(", and (in principle at least) this generates all other solutions via the principle of superposition.")

#text("Finite speed of propagation is a lot easier in the discrete setting, though one has to offset the support of the “velocity” field ")#mi("{v}")#text(" by one unit. Suppose we know that ")#mi("{P}")#text(" has unit speed in the sense that whenever ")#mi("{f}")#text(" is supported in a ball ")#mi("{B(x,R)}")#text(", then ")#mi("{Pf}")#text(" is supported in the ball ")#mi("{B(x,R+1)}")#text(". Then an easy induction shows that if ")#mi("{u(0), v(0)}")#text(" are supported in ")#mi("{B(x_0,R), B(x_0,R+1)}")#text(" respectively, then ")#mi("{u(t), v(t)}")#text(" are supported in ")#mi("{B(x_0,R+t), B(x_0, R+t+1)}")#text(".")

#text("The fundamental solution ")#mi("{U(t) = U^t}")#text(" to the discretised wave equation ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(", in the sense of ")#link(<tao-c5718558396e4afeeeab>)[#text("(2)")]#text(", is given by the formula")

#tao-aligned(keep: true)[


#tao-math("U(t)  & = U^t = \\begin{pmatrix} P & 1 \\\\ P^2-1 & P \\end{pmatrix}^t", block: true)



#tao-math(" & = \\begin{pmatrix} T_t(P) & U_{t-1}(P) \\\\ (P^2-1) U_{t-1}(P) & T_t(P) \\end{pmatrix}", block: true)
]

#text("where ")#mi("{T_t}")#text(" and ")#mi("{U_t}")#text(" are ")#link("http://en.wikipedia.org/wiki/Chebyshev_polynomials")[#text("the Chebyshev polynomials of the first and second kind")]#text(", thus")

#align(center)[#tao-fit-display[#mitex("T_t( \\cos \\theta ) = \\cos(t\\theta)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("U_t( \\cos \\theta ) = \\frac{\\sin((t+1)\\theta)}{\\sin \\theta}.")]]

#text("In particular, ")#mi("{P}")#text(" is now a minor of ")#mi("{U(1) = U}")#text(", and can also be viewed as an average of ")#mi("{U}")#text(" with its inverse ")#mi("{U^{-1}}")#text(": ")#metadata(none) <tao-4454123f357213f62214>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\begin{pmatrix} P & 0 \\\\ 0 & P \\end{pmatrix} = \\frac{1}{2} (U + U^{-1}).")]]

#text("As before, ")#mi("{U}")#text(" is unitary with respect to the energy form ")#link(<tao-df2f48cbadfcd621ef30>)[#text("(4)")]#text(", so this is another instance of the dilation trick in action. The powers ")#mi("{P^n}")#text(" and ")#mi("{U^n}")#text(" are discrete analogues of the heat propagators ")#mi("{e^{t\\Delta/2}}")#text(" and wave propagators ")#mi("{U(t)}")#text(" respectively.")

#text("One nice application of all this formalism, which I learned from Yuval Peres, is the ")#link("http://www.ams.org/mathscinet-getitem?mr=837740")[#text("Varopoulos-Carne inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Varopoulos-Carne inequality)")]#text(" Let ")#mi("{G}")#text(" be a (possibly infinite) regular graph, let ")#mi("{n \\geq 1}")#text(", and let ")#mi("{x, y}")#text(" be vertices in ")#mi("{G}")#text(". Then the probability that the ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("simple random walk")]#text(" at ")#mi("{x}")#text(" lands at ")#mi("{y}")#text(" at time ")#mi("{n}")#text(" is at most ")#mi("{2 \\exp( - d(x,y)^2 / 2n )}")#text(", where ")#mi("{d}")#text(" is the graph distance.")
]

#text("This general inequality is quite sharp, as one can see using the standard Cayley graph on the integers ")#mi("{{\\bf Z}}")#text(". Very roughly speaking, it asserts that on a regular graph of reasonably controlled growth (e.g. polynomial growth), random walks of length ")#mi("{n}")#text(" concentrate on the ball of radius ")#mi("{O(\\sqrt{n})}")#text(" or so centred at the origin of the random walk.")

#emph[#text("Proof:")]#text(" Let ")#mi("{P \\colon \\ell^2(G) \\rightarrow \\ell^2(G)}")#text(" be the graph Laplacian, thus")

#align(center)[#tao-fit-display[#mitex("Pf(x) = \\frac{1}{D} \\sum_{y \\sim x} f(y)")]]

#text("for any ")#mi("{f \\in \\ell^2(G)}")#text(", where ")#mi("{D}")#text(" is the degree of the regular graph and sum is over the ")#mi("{D}")#text(" vertices ")#mi("{y}")#text(" that are adjacent to ")#mi("{x}")#text(". This is a contraction of unit speed, and the probability that the random walk at ")#mi("{x}")#text(" lands at ")#mi("{y}")#text(" at time ")#mi("{n}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\langle P^n \\delta_x, \\delta_y \\rangle")]]

#text("where ")#mi("{\\delta_x, \\delta_y}")#text(" are the Dirac deltas at ")#mi("{x,y}")#text(". Using ")#link(<tao-4454123f357213f62214>)[#text("(5)")]#text(", we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\langle (\\frac{1}{2} (U + U^{-1}))^n \\begin{pmatrix} 0 \\\\ \\delta_x\\end{pmatrix}, \\begin{pmatrix} 0 \\\\ \\delta_y\\end{pmatrix} \\rangle")]]

#text("where we are now using the energy form ")#link(<tao-df2f48cbadfcd621ef30>)[#text("(4)")]#text(". We can write")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{2} (U + U^{-1}))^n = {\\bf E} U^{S_n}")]]

#text("where ")#mi("{S_n}")#text(" is the simple random walk of length ")#mi("{n}")#text(" on the integers, that is to say ")#mi("{S_n = \\xi_1 + \\dots + \\xi_n}")#text(" where ")#mi("{\\xi_1,\\dots,\\xi_n = \\pm 1}")#text(" are independent uniform Bernoulli signs. Thus we wish to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\langle U^{S_n} \\begin{pmatrix} 0 \\\\ \\delta_x\\end{pmatrix}, \\begin{pmatrix} 0 \\\\ \\delta_y\\end{pmatrix} \\rangle \\leq 2 \\exp(-d(x,y)^2 / 2n ).")]]

#text("By finite speed of propagation, the inner product here vanishes if ")#tao-math("{\\left|S_n\\right| < d(x,y)}", block: false)#text(". For ")#tao-math("{\\left|S_n\\right| \\geq d(x,y)}", block: false)#text(" we can use Cauchy-Schwarz and the unitary nature of ")#mi("{U}")#text(" to bound the inner product by ")#mi("{1}")#text(". Thus the left-hand side may be upper bounded by")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n\\right| \\geq d(x,y) )", block: true)]]

#text("and the claim now follows from the ")#link("http://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff inequality")]#text(". ")#mi("\\Box")

#text("This inequality has many applications, particularly with regards to relating the entropy, mixing time, and concentration of random walks with volume growth of balls; see ")#link("http://mypage.iu.edu/~rdlyons/prbtree/book.pdf")[#text("this text of Lyons and Peres")]#text(" for some examples.")

#text("For sake of comparison, here is a continuous counterpart to the Varopoulos-Carne inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Continuous Varopoulos-Carne inequality)")]#text(" Let ")#mi("{t > 0}")#text(", and let ")#mi("{f,g \\in L^2({\\bf R}^d)}")#text(" be supported on compact sets ")#mi("{F,G}")#text(" respectively. Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle e^{t\\Delta/2} f, g \\rangle\\right| \\leq \\sqrt{\\frac{2t}{\\pi d(F,G)^2}} \\exp( - d(F,G)^2 / 2t ) \\left\\|f\\right\\|_{L^2} \\left\\|g\\right\\|_{L^2}", block: true)]]

#text("where ")#mi("{d(F,G)}")#text(" is the Euclidean distance between ")#mi("{F}")#text(" and ")#mi("{G}")#text(".")
]

#emph[#text("Proof:")]#text(" By Fourier inversion one has")

#tao-aligned(keep: true)[


#tao-math("e^{-t\\xi^2/2}  & = \\frac{1}{\\sqrt{2\\pi t}} \\int_{\\bf R} e^{-s^2/2t} e^{is\\xi}\\ ds", block: true)



#tao-math(" & = \\sqrt{\\frac{2}{\\pi t}} \\int_0^\\infty e^{-s^2/2t} \\cos(s \\xi )\\ ds", block: true)
]

#text("for any real ")#mi("{\\xi}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\langle e^{t\\Delta/2} f, g\\rangle = \\sqrt{\\frac{2}{\\pi}} \\int_0^\\infty e^{-s^2/2t} \\langle \\cos(s \\sqrt{-\\Delta} ) f, g \\rangle\\ ds.")]]

#text("By finite speed of propagation, the inner product ")#mi("{\\langle \\cos(s \\sqrt{-\\Delta} ) f, g \\rangle\\ ds}")#text(" vanishes when ")#mi("{s < d(F,G)}")#text("; otherwise, we can use Cauchy-Schwarz and the contractive nature of ")#mi("{\\cos(s \\sqrt{-\\Delta} )}")#text(" to bound this inner product by ")#tao-math("{\\left\\|f\\right\\|_{L^2} \\left\\|g\\right\\|_{L^2}}", block: false)#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle e^{t\\Delta/2} f, g\\rangle\\right| \\leq \\sqrt{\\frac{2}{\\pi t}} \\left\\|f\\right\\|_{L^2} \\left\\|g\\right\\|_{L^2} \\int_{d(F,G)}^\\infty e^{-s^2/2t}\\ ds.", block: true)]]

#text("Bounding ")#mi("{e^{-s^2/2t}}")#text(" by ")#mi("{e^{-d(F,G)^2/2t} e^{-d(F,G) (s-d(F,G))/t}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Observe that the argument is quite general and can be applied for instance to other Riemannian manifolds than ")#mi("{{\\bf R}^d}")#text(".")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435494")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2014")])]

#text("In the last line, the L^2 norms should be of f,g rather than F,G.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9d6c587f0179a9e9cd79521e2b6e113d0cb1f812e0a24e3149da324234575b5-b393abd8e95f8ff6c0382edd82d629c7d085349005e0c6c3c8751e025646bf26.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435499")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2014")])]

#text("Also, shouldn’t we use the bound ")#mi("e^{-s^2/2t}\\le e^{-d(F,G)^2/2t}e^{-d(F,G)(s-d(F,G))/t}")#text("? This leads to another ")#mi("d(F,G)")#text(" in the reciprocal for the bound in the theorem.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435567")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("\\colon instead of : for maps.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435722")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("Terry: Have you really corrected it? :)")

#emph[#text("[Web version is now corrected also. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbc18fa1121b8fa9882913bae34c8ee95f5625eeca6286b1a2ad23ba28677eac-4b48c0ccfb856201ce86b093cbda2eddf8c25a173a1979df1f1fa74ff2800c19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observer")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435571")[#strong[#text("observer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("Probabilistic ideas can also be used to get other generalized laplacians, e.g., (18) in ")#link("http://www.stt.msu.edu/~mcubed/Relativistic.pdf")[#text("http://www.stt.msu.edu/~mcubed/Relativistic.pdf")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbc18fa1121b8fa9882913bae34c8ee95f5625eeca6286b1a2ad23ba28677eac-4b48c0ccfb856201ce86b093cbda2eddf8c25a173a1979df1f1fa74ff2800c19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aza")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-451596")[#strong[#text("Aza")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2015")])]

#text("Relativistic laplacian?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa01b2dc905b1532d3ce1fd5308b5249049b4cd5d6c459e37ccf68a978714190-42bd8a11c485ff08764cec99a586fe52a05126fcfd0619def32998b28f2914ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435572")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("There is a whole family of “finite speed propagation” estimates for spin systems with local interactions, called Lieb-Robinson bounds (")#link("http://en.wikipedia.org/wiki/Lieb-Robinson_bounds")[#text("http://en.wikipedia.org/wiki/Lieb-Robinson_bounds")]#text("), which look quite similar to the (discrete) Varopoulos-Carne inequality. It would be interesting to know if there is a deeper relation between both. (by the way, it is spelled “Varopoulos” and not “Varopoulous”)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb44e2738f7c3f1c593ab72676656f5ac8b514847e02263d3aac0111d89e7bc1-1678ced985578c8de61fcc0acfb1f566d73425eea6f6b4182282ebef7414067a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435687")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("The operator P defined at the beginning of the proof of Theorem 1 is the random walk (or “diffusion”) operator; the Laplacian of the graph is I-P.")

#emph[#text("[Some comments added on this – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435754")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("Does there exist similar discretized framework for nonlinear equations, such as Yang-Mills or wave maps?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435784")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("I don’t know about these specific equations. Several of the standard completely integrable systems (e.g. KdV, cubic 1D NLS) have discrete models (some in which space is discretised, and some in which both space and time are discretised, i.e. lattice models); see e.g. the literature on lattice KdV equations.")

#text("Presumably the discrete wave equation discussed here has a Lagrangian formulation, in which case it looks plausible that one could then derive a discrete Yang-Mills or wave maps equation by modifying the Lagrangian in the obvious ways. I might try to play with finding such a formulation later, though I won’t have much time for this in the next few days.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-436358")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("For what it’s worth, I did compute that solutions to the discretised wave equation are critical points for the Lagrangian")

#mi("\\sum_t \\frac{1}{2} \\langle u(t), (1-P^2) u(t) \\rangle + \\frac{1}{2} \\langle v(t), v(t) \\rangle - \\langle v(t), u(t+1) - Pu(t) \\rangle")

#text("but it is not obvious to me how to adapt this Lagrangian to a wave map or Yang-Mills setting.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae5081a0ea3b96d03e0da32de46f3948f685dd5249fd2d7930aede7ccd3479a-7d3cc7c17d94f43bfc751e45441c1f924ba27d8ea7605583ed6704d775f0dee7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-435930")[#strong[#text("M")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2014")])]

#text("thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-436062")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2014")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2014/11/08/discretised-wave-equations/")[#text("Being simple")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8831c28918f694948e6b5259716111419afba243579a58971108cbab996ffe7e-dd1c349211d2b3b8f8e399c4494264464eaae9b1e70aef9b62b59d4d0e090ba5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-436352")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("There are quite a few symbols here. Perhaps I’ll reblog it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8831c28918f694948e6b5259716111419afba243579a58971108cbab996ffe7e-dd1c349211d2b3b8f8e399c4494264464eaae9b1e70aef9b62b59d4d0e090ba5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-436353")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("Reblogged this on ")#link("http://sciencedefeated.wordpress.com/2014/11/09/discretised-wave-equations/")[#text("Science and Math Defeated")]#text(" and commented:")#linebreak()#text(" Can anyone please explain this to me? I can’t really figure out what the symbols mean.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8831c28918f694948e6b5259716111419afba243579a58971108cbab996ffe7e-dd1c349211d2b3b8f8e399c4494264464eaae9b1e70aef9b62b59d4d0e090ba5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-436882")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2014")])]

#text("Who on earth besides me is rating my comments down?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-437631")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2014")])]

#text("Me!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-437610")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2014")]

#text("Did you really take cosine of the Laplacian, ")#mi("\\cos (\\Delta)")#text(" ? I am always confused because you can talk about diffusion and you can talk about waves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-437626")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2014")]

#text("I am not so sure. If your two points are very close VC inequality says the probability tends to zero. Even if G is finite?")

#text("The content of the Varopolos-Carne inequality is a bound that works for any Cayley graph?")

#text("The VC inequality in the case of the Integers can be proven using the DeMoivre-Laplace limit theorem. Or using the the entropy formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/289756243f7a9076852582e94043b949751d4b776678afe0e1467adccf9087ec-7fc3b0c90ebf30110758a3b3688b1707c3c8436434b562fb1c51be9fa3f3a315.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-440560")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2014")])]

#text("The solutions to the discretized wave equation can be used to cluster graphs…..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diegus")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/#comment-463234")[#strong[#text("Diegus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2015")])]

#text("got it until time discretization eq (3) as {\\varepsilon} > 0 as P not for “heat propagation” but as a -discretization unit- where U(t) = U_t for zeroing epsilon where U(1) = U only if epsilon closes in to zero.. the opposite if U(1) for stateless epsilon?")
]
