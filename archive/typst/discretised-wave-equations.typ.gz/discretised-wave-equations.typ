// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/
// Converted to Typst by tao2typ: "2026-11-05T14:56:57.558962+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Discretised wave equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Discretised wave equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 November 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/")[#text("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-11-05 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Wave_equation")[#text("wave equation")]#text(" is usually expressed in the form")

#align(center)[#tao-fit-display[#mitex("\\partial_{tt} u - \\Delta u = 0")]]

#text("where ")#mi("{u \\colon {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf C}}")#text(" is a function of both time ")#mi("{t \\in {\\bf R}}")#text(" and space ")#mi("{x \\in {\\bf R}^d}")#text(", with ")#mi("{\\Delta}")#text(" being the Laplacian operator. One can generalise this equation in a number of ways, for instance by replacing the spatial domain ")#mi("{{\\bf R}^d}")#text(" with some other manifold and replacing the Laplacian ")#mi("{\\Delta}")#text(" with the Laplace-Beltrami operator or adding lower order terms (such as a potential, or a coupling with a magnetic field). But for sake of discussion let us work with the classical wave equation on ")#mi("{{\\bf R}^d}")#text(". We will work formally in this post, being unconcerned with issues of convergence, justifying interchange of integrals, derivatives, or limits, etc.. One then has a conserved energy")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\frac{1}{2} \\left|\\nabla u(t,x)\\right|^2 + \\frac{1}{2} \\left|\\partial_t u(t,x)\\right|^2\\ dx", block: true)]]

#text("which we can rewrite using integration by parts and the ")#mi("{L^2}")#text(" inner product ")#mi("{\\langle, \\rangle}")#text(" on ")#mi("{{\\bf R}^d}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\langle -\\Delta u(t), u(t) \\rangle + \\frac{1}{2} \\langle \\partial_t u(t), \\partial_t u(t) \\rangle.")]]

#text("A key feature of the wave equation is ")#emph[#text("finite speed of propagation")]#text(": if, at time ")#mi("{t=0}")#text(" (say), the initial position ")#mi("{u(0)}")#text(" and initial velocity ")#mi("{\\partial_t u(0)}")#text(" are both supported in a ball ")#tao-math("{B(x_0,R) := \\{ x \\in {\\bf R}^d: \\left|x-x_0\\right| \\leq R \\}}", block: false)#text(", then at any later time ")#mi("{t>0}")#text(", the position ")#mi("{u(t)}")#text(" and velocity ")#mi("{\\partial_t u(t)}")#text(" are supported in the larger ball ")#mi("{B(x_0,R+t)}")#text(". This can be seen for instance (formally, at least) by inspecting the exterior energy")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|x-x_0\\right| > R+t} \\frac{1}{2} \\left|\\nabla u(t,x)\\right|^2 + \\frac{1}{2} \\left|\\partial_t u(t,x)\\right|^2\\ dx", block: true)]]

#text("and observing (after some integration by parts and differentiation under the integral sign) that it is non-increasing in time, non-negative, and vanishing at time ")#mi("{t=0}")#text(".")

#text("The wave equation is second order in time, but one can turn it into a first order system by working with the pair ")#mi("{(u(t),v(t))}")#text(" rather than just the single field ")#mi("{u(t)}")#text(", where ")#mi("{v(t) := \\partial_t u(t)}")#text(" is the velocity field. The system is then")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u(t)  & = v(t)", block: true)



#tao-math("\\partial_t v(t)  & = \\Delta u(t)", block: true)
]

#text("and the conserved energy is now ")#metadata(none) <tao-381cfb6e1e428419d5d6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{1}{2} \\langle -\\Delta u(t), u(t) \\rangle + \\frac{1}{2} \\langle v(t), v(t) \\rangle.")]]

#text("Finite speed of propagation then tells us that if ")#mi("{u(0),v(0)}")#text(" are both supported on ")#mi("{B(x_0,R)}")#text(", then ")#mi("{u(t),v(t)}")#text(" are supported on ")#mi("{B(x_0,R+t)}")#text(" for all ")#mi("{t>0}")#text(". One also has time reversal symmetry: if ")#mi("{t \\mapsto (u(t),v(t))}")#text(" is a solution, then ")#mi("{t \\mapsto (u(-t), -v(-t))}")#text(" is a solution also, thus for instance one can establish an analogue of finite speed of propagation for negative times ")#mi("{t<0}")#text(" using this symmetry.")

#text("If one has an eigenfunction")

#align(center)[#tao-fit-display[#mitex("-\\Delta \\phi = \\lambda^2 \\phi")]]

#text("of the Laplacian, then we have the explicit solutions")

#tao-aligned(keep: true)[


#tao-math("u(t)  & = e^{\\pm it \\lambda} \\phi", block: true)



#tao-math("v(t)  & = \\pm i \\lambda e^{\\pm it \\lambda} \\phi", block: true)
]

#text("of the wave equation, which formally can be used to construct all other solutions via the principle of superposition.")

#text("When one has vanishing initial velocity ")#mi("{v(0)=0}")#text(", the solution ")#mi("{u(t)}")#text(" is given via functional calculus by")

#align(center)[#tao-fit-display[#mitex("u(t) = \\cos(t \\sqrt{-\\Delta}) u(0)")]]

#text("and the propagator ")#mi("{\\cos(t \\sqrt{-\\Delta})}")#text(" can be expressed as the average of half-wave operators:")

#align(center)[#tao-fit-display[#mitex("\\cos(t \\sqrt{-\\Delta}) = \\frac{1}{2} ( e^{it\\sqrt{-\\Delta}} + e^{-it\\sqrt{-\\Delta}} ).")]]

#text("One can view ")#mi("{\\cos(t \\sqrt{-\\Delta} )}")#text(" as a minor of the full wave propagator")

#tao-aligned(keep: true)[


#tao-math("U(t)  & := \\exp \\begin{pmatrix} 0 & t \\\\ t\\Delta & 0 \\end{pmatrix}", block: true)



#tao-math(" & = \\begin{pmatrix} \\cos(t \\sqrt{-\\Delta}) & \\frac{\\sin(t\\sqrt{-\\Delta})}{\\sqrt{-\\Delta}} \\\\ \\sin(t\\sqrt{-\\Delta}) \\sqrt{-\\Delta} & \\cos(t \\sqrt{-\\Delta} ) \\end{pmatrix}", block: true)
]

#text("which is unitary with respect to the energy form ")#link(<tao-381cfb6e1e428419d5d6>)[#text("(1)")]#text(", and is the fundamental solution to the wave equation in the sense that ")#metadata(none) <tao-c5718558396e4afeeeab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\begin{pmatrix} u(t) \\\\ v(t) \\end{pmatrix} = U(t) \\begin{pmatrix} u(0) \\\\ v(0) \\end{pmatrix}.")]]

#text("Viewing the contraction ")#mi("{\\cos(t\\sqrt{-\\Delta})}")#text(" as a minor of a unitary operator is an instance of the “")#link("http://en.wikipedia.org/wiki/Naimark%27s_dilation_theorem")[#text("dilation trick")]#text("“.")

#text("It turns out (as I learned from Yuval Peres) that there is a useful discrete analogue of the wave equation (and of all of the above facts), in which the time variable ")#mi("{t}")#text(" now lives on the integers ")#mi("{{\\bf Z}}")#text(" rather than on ")#mi("{{\\bf R}}")#text(", and the spatial domain can be replaced by discrete domains also (such as graphs). Formally, the system is now of the form ")#metadata(none) <tao-31f78e7ffc3c06ef69da>

#tao-aligned(keep: true)[


#tao-math("u(t+1)  & = P u(t) + v(t)", block: true, numbering: n => [#text("(3)")])



#tao-math("v(t+1)  & = P v(t) - (1-P^2) u(t)", block: true)
]

#text("where ")#mi("{t}")#text(" is now an integer, ")#mi("{u(t), v(t)}")#text(" take values in some Hilbert space (e.g. ")#mi("{\\ell^2}")#text(" functions on a graph ")#mi("{G}")#text("), and ")#mi("{P}")#text(" is some operator on that Hilbert space (which in applications will usually be a self-adjoint contraction). To connect this with the classical wave equation, let us first consider a rescaling of this system")

#tao-aligned(keep: true)[


#tao-math("u(t+\\varepsilon)  & = P_\\varepsilon u(t) + \\varepsilon v(t)", block: true)



#tao-math("v(t+\\varepsilon)  & = P_\\varepsilon v(t) - \\frac{1}{\\varepsilon} (1-P_\\varepsilon^2) u(t)", block: true)
]

#text("where ")#mi("{\\varepsilon>0}")#text(" is a small parameter (representing the discretised time step), ")#mi("{t}")#text(" now takes values in the integer multiples ")#mi("{\\varepsilon {\\bf Z}}")#text(" of ")#mi("{\\varepsilon}")#text(", and ")#mi("{P_\\varepsilon}")#text(" is the wave propagator operator ")#mi("{P_\\varepsilon := \\cos( \\varepsilon \\sqrt{-\\Delta} )}")#text(" or the heat propagator ")#mi("{P_\\varepsilon := \\exp( - \\varepsilon^2 \\Delta/2 )}")#text(" (the two operators are different, but agree to fourth order in ")#mi("{\\varepsilon}")#text("). One can then formally verify that the wave equation emerges from this rescaled system in the limit ")#mi("{\\varepsilon \\rightarrow 0}")#text(". (Thus, ")#mi("{P}")#text(" is not exactly the direct analogue of the Laplacian ")#mi("{\\Delta}")#text(", but can be viewed as something like ")#mi("{P_\\varepsilon = 1 - \\frac{\\varepsilon^2}{2} \\Delta + O( \\varepsilon^4 )}")#text(" in the case of small ")#mi("{\\varepsilon}")#text(", or ")#mi("{P = 1 - \\frac{1}{2}\\Delta + O(\\Delta^2)}")#text(" if we are not rescaling to the small ")#mi("{\\varepsilon}")#text(" case. The operator ")#mi("{P}")#text(" is sometimes known as the ")#emph[#text("diffusion operator")]#text(")")

#text("Assuming ")#mi("{P}")#text(" is self-adjoint, solutions to the system ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(" formally conserve the energy ")#metadata(none) <tao-df2f48cbadfcd621ef30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\frac{1}{2} \\langle (1-P^2) u(t), u(t) \\rangle + \\frac{1}{2} \\langle v(t), v(t) \\rangle.")]]

#text("This energy is positive semi-definite if ")#mi("{P}")#text(" is a contraction. We have the same time reversal symmetry as before: if ")#mi("{t \\mapsto (u(t),v(t))}")#text(" solves the system ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(", then so does ")#mi("{t \\mapsto (u(-t), -v(-t))}")#text(". If one has an eigenfunction")

#align(center)[#tao-fit-display[#mitex("P \\phi = \\cos(\\lambda) \\phi")]]

#text("to the operator ")#mi("{P}")#text(", then one has an explicit solution")

#tao-aligned(keep: true)[


#tao-math("u(t)  & = e^{\\pm it \\lambda} \\phi", block: true)



#tao-math("v(t)  & = \\pm i \\sin(\\lambda) e^{\\pm it \\lambda} \\phi", block: true)
]

#text("to ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(", and (in principle at least) this generates all other solutions via the principle of superposition.")

#text("Finite speed of propagation is a lot easier in the discrete setting, though one has to offset the support of the “velocity” field ")#mi("{v}")#text(" by one unit. Suppose we know that ")#mi("{P}")#text(" has unit speed in the sense that whenever ")#mi("{f}")#text(" is supported in a ball ")#mi("{B(x,R)}")#text(", then ")#mi("{Pf}")#text(" is supported in the ball ")#mi("{B(x,R+1)}")#text(". Then an easy induction shows that if ")#mi("{u(0), v(0)}")#text(" are supported in ")#mi("{B(x_0,R), B(x_0,R+1)}")#text(" respectively, then ")#mi("{u(t), v(t)}")#text(" are supported in ")#mi("{B(x_0,R+t), B(x_0, R+t+1)}")#text(".")

#text("The fundamental solution ")#mi("{U(t) = U^t}")#text(" to the discretised wave equation ")#link(<tao-31f78e7ffc3c06ef69da>)[#text("(3)")]#text(", in the sense of ")#link(<tao-c5718558396e4afeeeab>)[#text("(2)")]#text(", is given by the formula")

#tao-aligned(keep: true)[


#tao-math("U(t)  & = U^t = \\begin{pmatrix} P & 1 \\\\ P^2-1 & P \\end{pmatrix}^t", block: true)



#tao-math(" & = \\begin{pmatrix} T_t(P) & U_{t-1}(P) \\\\ (P^2-1) U_{t-1}(P) & T_t(P) \\end{pmatrix}", block: true)
]

#text("where ")#mi("{T_t}")#text(" and ")#mi("{U_t}")#text(" are ")#link("http://en.wikipedia.org/wiki/Chebyshev_polynomials")[#text("the Chebyshev polynomials of the first and second kind")]#text(", thus")

#align(center)[#tao-fit-display[#mitex("T_t( \\cos \\theta ) = \\cos(t\\theta)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("U_t( \\cos \\theta ) = \\frac{\\sin((t+1)\\theta)}{\\sin \\theta}.")]]

#text("In particular, ")#mi("{P}")#text(" is now a minor of ")#mi("{U(1) = U}")#text(", and can also be viewed as an average of ")#mi("{U}")#text(" with its inverse ")#mi("{U^{-1}}")#text(": ")#metadata(none) <tao-4454123f357213f62214>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\begin{pmatrix} P & 0 \\\\ 0 & P \\end{pmatrix} = \\frac{1}{2} (U + U^{-1}).")]]

#text("As before, ")#mi("{U}")#text(" is unitary with respect to the energy form ")#link(<tao-df2f48cbadfcd621ef30>)[#text("(4)")]#text(", so this is another instance of the dilation trick in action. The powers ")#mi("{P^n}")#text(" and ")#mi("{U^n}")#text(" are discrete analogues of the heat propagators ")#mi("{e^{t\\Delta/2}}")#text(" and wave propagators ")#mi("{U(t)}")#text(" respectively.")

#text("One nice application of all this formalism, which I learned from Yuval Peres, is the ")#link("http://www.ams.org/mathscinet-getitem?mr=837740")[#text("Varopoulos-Carne inequality")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Varopoulos-Carne inequality)")]#text(" Let ")#mi("{G}")#text(" be a (possibly infinite) regular graph, let ")#mi("{n \\geq 1}")#text(", and let ")#mi("{x, y}")#text(" be vertices in ")#mi("{G}")#text(". Then the probability that the ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("simple random walk")]#text(" at ")#mi("{x}")#text(" lands at ")#mi("{y}")#text(" at time ")#mi("{n}")#text(" is at most ")#mi("{2 \\exp( - d(x,y)^2 / 2n )}")#text(", where ")#mi("{d}")#text(" is the graph distance.")
]

#text("This general inequality is quite sharp, as one can see using the standard Cayley graph on the integers ")#mi("{{\\bf Z}}")#text(". Very roughly speaking, it asserts that on a regular graph of reasonably controlled growth (e.g. polynomial growth), random walks of length ")#mi("{n}")#text(" concentrate on the ball of radius ")#mi("{O(\\sqrt{n})}")#text(" or so centred at the origin of the random walk.")

#emph[#text("Proof:")]#text(" Let ")#mi("{P \\colon \\ell^2(G) \\rightarrow \\ell^2(G)}")#text(" be the graph Laplacian, thus")

#align(center)[#tao-fit-display[#mitex("Pf(x) = \\frac{1}{D} \\sum_{y \\sim x} f(y)")]]

#text("for any ")#mi("{f \\in \\ell^2(G)}")#text(", where ")#mi("{D}")#text(" is the degree of the regular graph and sum is over the ")#mi("{D}")#text(" vertices ")#mi("{y}")#text(" that are adjacent to ")#mi("{x}")#text(". This is a contraction of unit speed, and the probability that the random walk at ")#mi("{x}")#text(" lands at ")#mi("{y}")#text(" at time ")#mi("{n}")#text(" is")

#align(center)[#tao-fit-display[#mitex("\\langle P^n \\delta_x, \\delta_y \\rangle")]]

#text("where ")#mi("{\\delta_x, \\delta_y}")#text(" are the Dirac deltas at ")#mi("{x,y}")#text(". Using ")#link(<tao-4454123f357213f62214>)[#text("(5)")]#text(", we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\langle (\\frac{1}{2} (U + U^{-1}))^n \\begin{pmatrix} 0 \\\\ \\delta_x\\end{pmatrix}, \\begin{pmatrix} 0 \\\\ \\delta_y\\end{pmatrix} \\rangle")]]

#text("where we are now using the energy form ")#link(<tao-df2f48cbadfcd621ef30>)[#text("(4)")]#text(". We can write")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{2} (U + U^{-1}))^n = {\\bf E} U^{S_n}")]]

#text("where ")#mi("{S_n}")#text(" is the simple random walk of length ")#mi("{n}")#text(" on the integers, that is to say ")#mi("{S_n = \\xi_1 + \\dots + \\xi_n}")#text(" where ")#mi("{\\xi_1,\\dots,\\xi_n = \\pm 1}")#text(" are independent uniform Bernoulli signs. Thus we wish to show that")

#align(center)[#tao-fit-display[#mitex("{\\bf E} \\langle U^{S_n} \\begin{pmatrix} 0 \\\\ \\delta_x\\end{pmatrix}, \\begin{pmatrix} 0 \\\\ \\delta_y\\end{pmatrix} \\rangle \\leq 2 \\exp(-d(x,y)^2 / 2n ).")]]

#text("By finite speed of propagation, the inner product here vanishes if ")#tao-math("{\\left|S_n\\right| < d(x,y)}", block: false)#text(". For ")#tao-math("{\\left|S_n\\right| \\geq d(x,y)}", block: false)#text(" we can use Cauchy-Schwarz and the unitary nature of ")#mi("{U}")#text(" to bound the inner product by ")#mi("{1}")#text(". Thus the left-hand side may be upper bounded by")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n\\right| \\geq d(x,y) )", block: true)]]

#text("and the claim now follows from the ")#link("http://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff inequality")]#text(". ")#mi("\\Box")

#text("This inequality has many applications, particularly with regards to relating the entropy, mixing time, and concentration of random walks with volume growth of balls; see ")#link("http://mypage.iu.edu/~rdlyons/prbtree/book.pdf")[#text("this text of Lyons and Peres")]#text(" for some examples.")

#text("For sake of comparison, here is a continuous counterpart to the Varopoulos-Carne inequality:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Continuous Varopoulos-Carne inequality)")]#text(" Let ")#mi("{t > 0}")#text(", and let ")#mi("{f,g \\in L^2({\\bf R}^d)}")#text(" be supported on compact sets ")#mi("{F,G}")#text(" respectively. Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle e^{t\\Delta/2} f, g \\rangle\\right| \\leq \\sqrt{\\frac{2t}{\\pi d(F,G)^2}} \\exp( - d(F,G)^2 / 2t ) \\left\\|f\\right\\|_{L^2} \\left\\|g\\right\\|_{L^2}", block: true)]]

#text("where ")#mi("{d(F,G)}")#text(" is the Euclidean distance between ")#mi("{F}")#text(" and ")#mi("{G}")#text(".")
]

#emph[#text("Proof:")]#text(" By Fourier inversion one has")

#tao-aligned(keep: true)[


#tao-math("e^{-t\\xi^2/2}  & = \\frac{1}{\\sqrt{2\\pi t}} \\int_{\\bf R} e^{-s^2/2t} e^{is\\xi}\\ ds", block: true)



#tao-math(" & = \\sqrt{\\frac{2}{\\pi t}} \\int_0^\\infty e^{-s^2/2t} \\cos(s \\xi )\\ ds", block: true)
]

#text("for any real ")#mi("{\\xi}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\langle e^{t\\Delta/2} f, g\\rangle = \\sqrt{\\frac{2}{\\pi}} \\int_0^\\infty e^{-s^2/2t} \\langle \\cos(s \\sqrt{-\\Delta} ) f, g \\rangle\\ ds.")]]

#text("By finite speed of propagation, the inner product ")#mi("{\\langle \\cos(s \\sqrt{-\\Delta} ) f, g \\rangle\\ ds}")#text(" vanishes when ")#mi("{s < d(F,G)}")#text("; otherwise, we can use Cauchy-Schwarz and the contractive nature of ")#mi("{\\cos(s \\sqrt{-\\Delta} )}")#text(" to bound this inner product by ")#tao-math("{\\left\\|f\\right\\|_{L^2} \\left\\|g\\right\\|_{L^2}}", block: false)#text(". Thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle e^{t\\Delta/2} f, g\\rangle\\right| \\leq \\sqrt{\\frac{2}{\\pi t}} \\left\\|f\\right\\|_{L^2} \\left\\|g\\right\\|_{L^2} \\int_{d(F,G)}^\\infty e^{-s^2/2t}\\ ds.", block: true)]]

#text("Bounding ")#mi("{e^{-s^2/2t}}")#text(" by ")#mi("{e^{-d(F,G)^2/2t} e^{-d(F,G) (s-d(F,G))/t}}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Observe that the argument is quite general and can be applied for instance to other Riemannian manifolds than ")#mi("{{\\bf R}^d}")#text(".")

#heading(level: 1)[#text("Comments (21)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54e882343bcd80f3b4ce4a9829200966b9b166e515738f45163d69235f101c88-78b005d885866742240745d6ea1313675fb34b0a806d42779b5bad54ef6a605c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435494")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2014")])]

#text("In the last line, the L^2 norms should be of f,g rather than F,G.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54e882343bcd80f3b4ce4a9829200966b9b166e515738f45163d69235f101c88-78b005d885866742240745d6ea1313675fb34b0a806d42779b5bad54ef6a605c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Cook")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435499")[#strong[#text("Nick Cook")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2014")])]

#text("Also, shouldn’t we use the bound ")#mi("e^{-s^2/2t}\\le e^{-d(F,G)^2/2t}e^{-d(F,G)(s-d(F,G))/t}")#text("? This leads to another ")#mi("d(F,G)")#text(" in the reciprocal for the bound in the theorem.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435567")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("\\colon instead of : for maps.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c85b1951f8a78f312e438ee638df9d5874d7ac9e2468cd092ac4124a5293f350-52fc9493ff777e3522ac72f04d77065d71f50f5221e7ad6749d5e7fb81ad1ebe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435722")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("Terry: Have you really corrected it? 🙂")

#emph[#text("[Web version is now corrected also. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86c9e95ae7f6d4a94ef4698d3a44a02f22087902b188d8d25bf119e340862f10-1444efd155d4d6456d2cafa933e84742302b3494a35f2a0790773c73f3e9de97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observer")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435571")[#strong[#text("observer")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("Probabilistic ideas can also be used to get other generalized laplacians, e.g., (18) in ")#link("http://www.stt.msu.edu/~mcubed/Relativistic.pdf")[#text("http://www.stt.msu.edu/~mcubed/Relativistic.pdf")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/86c9e95ae7f6d4a94ef4698d3a44a02f22087902b188d8d25bf119e340862f10-1444efd155d4d6456d2cafa933e84742302b3494a35f2a0790773c73f3e9de97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aza")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-451596")[#strong[#text("Aza")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2015")])]

#text("Relativistic laplacian?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cabff2e63def146180e269cb1645d10e6070c31aa29345e29d0d6eb763b7386-4c430ef8315d5a28f4f1083d712c9e829c0d7d5a3aaf3cd7b8c44b03fa14ca92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pedro Lauridsen Ribeiro")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435572")[#strong[#text("Pedro Lauridsen Ribeiro")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("There is a whole family of “finite speed propagation” estimates for spin systems with local interactions, called Lieb-Robinson bounds (")#link("http://en.wikipedia.org/wiki/Lieb-Robinson_bounds")[#text("http://en.wikipedia.org/wiki/Lieb-Robinson_bounds")]#text("), which look quite similar to the (discrete) Varopoulos-Carne inequality. It would be interesting to know if there is a deeper relation between both. (by the way, it is spelled “Varopoulos” and not “Varopoulous”)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c97c956d93f45dd413307f9b5c4b21d181bc738ff6a51d872b17e1b921ddf7cd-9d71889d86843a2ce3048bd5cfd4442c1f6da663eed8d82cf3cbf8b267fb2108.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of luca")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435687")[#strong[#text("luca")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("The operator P defined at the beginning of the proof of Theorem 1 is the random walk (or “diffusion”) operator; the Laplacian of the graph is I-P.")

#emph[#text("[Some comments added on this – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/475ffc409cc3da7fe6753ddafde1e26b49f727023a271879a6be41c7387793c7-bada37d6351fa978007901ca5ff6571656ccc5fb728657e7a96ffa059c181c00.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435754")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("Does there exist similar discretized framework for nonlinear equations, such as Yang-Mills or wave maps?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435784")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 November 2014")])]

#text("I don’t know about these specific equations. Several of the standard completely integrable systems (e.g. KdV, cubic 1D NLS) have discrete models (some in which space is discretised, and some in which both space and time are discretised, i.e. lattice models); see e.g. the literature on lattice KdV equations.")

#text("Presumably the discrete wave equation discussed here has a Lagrangian formulation, in which case it looks plausible that one could then derive a discrete Yang-Mills or wave maps equation by modifying the Lagrangian in the obvious ways. I might try to play with finding such a formulation later, though I won’t have much time for this in the next few days.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/31ba223f9a57196040fea96d6478e296f90e9db4feed0d353d17993cf3584382-43039ad31b587c643179ffceb1ac96269a994437368ae6388d32e0905af63eb8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-436358")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("For what it’s worth, I did compute that solutions to the discretised wave equation are critical points for the Lagrangian")

#mi("\\sum_t \\frac{1}{2} \\langle u(t), (1-P^2) u(t) \\rangle + \\frac{1}{2} \\langle v(t), v(t) \\rangle - \\langle v(t), u(t+1) - Pu(t) \\rangle")

#text("but it is not obvious to me how to adapt this Lagrangian to a wave map or Yang-Mills setting.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/29a18c49d10103182ca119ef10114ea43d9242c525a506f0a064cd7dcc026144-b27b9864cacfbc98f4281543f451ef984678fa36f9f6e66b71d76757b71531db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of M")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-435930")[#strong[#text("M")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2014")])]

#text("thank you")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4b70119692e71b528af1f9152d594412bac8c5d8720059aa29172179dbcb1b43-394ca547beca280725c74c7616c02486082b5b3e089c9c390477453f8cc9bbae.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-436062")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 8 November 2014")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2014/11/08/discretised-wave-equations/")[#text("Being simple")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caba27c36f3025d76cb963933b682341bfeaa97a80418dab55d94a94fe581f94-ea557c04a24126598584ca2c0b57e7f0777dec1610949585d6d6e283efe31e6a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-436352")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("There are quite a few symbols here. Perhaps I’ll reblog it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caba27c36f3025d76cb963933b682341bfeaa97a80418dab55d94a94fe581f94-ea557c04a24126598584ca2c0b57e7f0777dec1610949585d6d6e283efe31e6a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-436353")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("Reblogged this on ")#link("http://sciencedefeated.wordpress.com/2014/11/09/discretised-wave-equations/")[#text("Science and Math Defeated")]#text(" and commented:")#linebreak()#text(" Can anyone please explain this to me? I can’t really figure out what the symbols mean.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/caba27c36f3025d76cb963933b682341bfeaa97a80418dab55d94a94fe581f94-ea557c04a24126598584ca2c0b57e7f0777dec1610949585d6d6e283efe31e6a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of notedscholar")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-436882")[#strong[#text("notedscholar")]]#text(size: 9pt, fill: rgb("596477"), " · 10 November 2014")])]

#text("Who on earth besides me is rating my comments down?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-437631")[#strong[#text("")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2014")])]

#text("Me!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d980d344250ef9ac82d6bc48803eec8acaa58927e0f297a490ff8e4de40af1b4-c2b5178843fa49b042ce0b48c83c374c6f4cfae1d522ed08a829ed274e392706.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-437610")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2014")])]

#text("Did you really take cosine of the Laplacian, ")#mi("\\cos (\\Delta)")#text(" ? I am always confused because you can talk about diffusion and you can talk about waves.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d980d344250ef9ac82d6bc48803eec8acaa58927e0f297a490ff8e4de40af1b4-c2b5178843fa49b042ce0b48c83c374c6f4cfae1d522ed08a829ed274e392706.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-437626")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2014")])]

#text("I am not so sure. If your two points are very close VC inequality says the probability tends to zero. Even if G is finite?")

#text("The content of the Varopolos-Carne inequality is a bound that works for any Cayley graph?")

#text("The VC inequality in the case of the Integers can be proven using the DeMoivre-Laplace limit theorem. Or using the the entropy formula.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/97962686dc1e3f02be85e63acc56c728a77eda20534c57f41508e3d9c70e1774-42705c337dff4db185db0956a166decb32bfa44828dd33c445131d6254c77740.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-440560")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2014")])]

#text("The solutions to the discretized wave equation can be used to cluster graphs…..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/399fda5b55da0037fde0bc5505fcf942e3c8c5de563cfa1bf1b10ea08368616f-87e5855df4c826383610cd1b932c9436e27ea7de33cb68ecb3f3d83dc8e063f7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diegus")]], [#link("https://terrytao.wordpress.com/2014/11/05/discretised-wave-equations/comment-page-1/#comment-463234")[#strong[#text("Diegus")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2015")])]

#text("got it until time discretization eq (3) as {\\varepsilon} > 0 as P not for “heat propagation” but as a -discretization unit- where U(t) = U_t for zeroing epsilon where U(1) = U only if epsilon closes in to zero.. the opposite if U(1) for stateless epsilon?")
]
