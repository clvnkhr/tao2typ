// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/
// Converted to Typst by tao2typ: "2026-10-14T16:37:56.079879+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 June 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/")[#text("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

#text("I’ve just posted to the arXiv my paper “")#link("http://arxiv.org/abs/1606.08481")[#text("Finite time blowup for Lagrangian modifications of the three-dimensional Euler equation")]#text("“. This paper is loosely in the spirit of ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("other")]#text(" ")#link("https://terrytao.wordpress.com/2016/02/27/finite-time-blowup-for-a-supercritical-defocusing-nonlinear-wave-system/")[#text("recent")]#text(" ")#link("https://terrytao.wordpress.com/2016/03/08/finite-time-blowup-for-high-dimensional-nonlinear-wave-systems-with-bounded-smooth-nonlinearity/")[#text("papers")]#text(" of mine in which I explore how close one can get to supercritical PDE of physical interest (such as the Euler and Navier-Stokes equations), while still being able to rigorously demonstrate finite time blowup for at least some choices of initial data. Here, the PDE we are trying to get close to is the incompressible inviscid Euler equations")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\nabla p", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)
]

#text("in three spatial dimensions, where ")#mi("{u}")#text(" is the velocity vector field and ")#mi("{p}")#text(" is the pressure field. In vorticity form, and viewing the vorticity ")#mi("{\\omega}")#text(" as a ")#mi("{2}")#text("-form (rather than a vector), we can rewrite this system using the language of differential geometry as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\omega + {\\mathcal L}_u \\omega  & = 0", block: true)



#tao-math("u  & = \\delta \\tilde \\eta^{-1} \\Delta^{-1} \\omega", block: true)
]

#text("where ")#mi("{{\\mathcal L}_u}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" along ")#mi("{u}")#text(", ")#mi("{\\delta}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Hodge_dual#The_codifferential")[#text("codifferential")]#text(" (the adjoint of the differential ")#mi("{d}")#text(", or equivalently the negative of the divergence operator) that sends ")#mi("{k+1}")#text("-vector fields to ")#mi("{k}")#text("-vector fields, ")#mi("{\\Delta}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Laplace_operators_in_differential_geometry#Hodge_Laplacian")[#text("Hodge Laplacian")]#text(", and ")#mi("{\\tilde \\eta}")#text(" is the identification of ")#mi("{k}")#text("-vector fields with ")#mi("{k}")#text("-forms induced by the Euclidean metric ")#mi("{\\tilde \\eta}")#text(". The equation")#mi("{u = \\delta \\tilde \\eta^{-1} \\Delta^{-1} \\omega}")#text(" can be viewed as ")#link("https://en.wikipedia.org/wiki/Biot%E2%80%93Savart_law")[#text("the Biot-Savart law")]#text(" recovering velocity from vorticity, expressed in the language of differential geometry.")

#text("One can then generalise this system by replacing the operator ")#mi("{\\tilde \\eta^{-1} \\Delta^{-1}}")#text(" by a more general operator ")#mi("{A}")#text(" from ")#mi("{2}")#text("-forms to ")#mi("{2}")#text("-vector fields, giving rise to what I call the ")#emph[#text("generalised Euler equations")]

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\omega + {\\mathcal L}_u \\omega  & = 0", block: true)



#tao-math("u  & = \\delta A \\omega.", block: true)
]

#text("For example, the surface quasi-geostrophic (SQG) equations can be written in this form, as discussed in ")#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/")[#text("this previous post")]#text(". One can view ")#mi("{A \\omega}")#text(" (up to Hodge duality) as a ")#link("https://en.wikipedia.org/wiki/Vector_potential")[#text("vector potential")]#text(" for the velocity ")#mi("{u}")#text(", so it is natural to refer to ")#mi("{A}")#text(" as a vector potential operator.")

#text("The generalised Euler equations carry much of the same geometric structure as the true Euler equations. For instance, the transport equation ")#mi("{\\partial_t \\omega + {\\mathcal L}_u \\omega = 0}")#text(" is equivalent to the ")#link("https://en.wikipedia.org/wiki/Kelvin%27s_circulation_theorem")[#text("Kelvin circulation theorem")]#text(", which in three dimensions also implies the transport of vortex streamlines and the conservation of ")#link("https://en.wikipedia.org/wiki/Helicity_(fluid_mechanics)")[#text("helicity")]#text(". If ")#mi("{A}")#text(" is self-adjoint and positive definite, then the famous Euler-Poincaré interpretation of the true Euler equations as geodesic flow on an infinite dimensional Riemannian manifold of volume preserving diffeomorphisms (as discussed in ")#link("https://terrytao.wordpress.com/2010/06/07/the-euler-arnold-equation/")[#text("this previous post")]#text(") extends to the generalised Euler equations (with the operator ")#mi("{A}")#text(" determining the new Riemannian metric to place on this manifold). In particular, the generalised Euler equations have a Lagrangian formulation, and so by Noether’s theorem we expect any continuous symmetry of the Lagrangian to lead to conserved quantities. Indeed, we have a conserved Hamiltonian ")#mi("{\\frac{1}{2} \\int \\langle \\omega, A \\omega \\rangle}")#text(", and any spatial symmetry of ")#mi("{A}")#text(" leads to a conserved impulse (e.g. translation invariance leads to a conserved momentum, and rotation invariance leads to a conserved angular momentum). If ")#mi("{A}")#text(" behaves like a pseudodifferential operator of order ")#mi("{-2}")#text(" (as is the case with the true vector potential operator ")#mi("{\\tilde \\eta^{-1} \\Delta^{-1}}")#text("), then it turns out that one can use energy methods to recover the same sort of classical local existence theory as for the true Euler equations (up to and including the famous ")#link("http://www.ams.org/mathscinet-getitem?mr=763762")[#text("Beale-Kato-Majda criterion")]#text(" for blowup).")

#text("The true Euler equations are suspected of admitting smooth localised solutions which blow up in finite time; there is now substantial numerical evidence for this blowup, but it has not been proven rigorously. The main purpose of this paper is to show that such finite time blowup can at least be established for certain generalised Euler equations that are somewhat close to the true Euler equations. This is similar in spirit to my previous paper on ")#link("https://terrytao.wordpress.com/2014/02/04/finite-time-blowup-for-an-averaged-three-dimensional-navier-stokes-equation/")[#text("finite time blowup on averaged Navier-Stokes equations")]#text(", with the main new feature here being that the modified equation continues to have a Lagrangian structure and a vorticity formulation, which was not the case with the averaged Navier-Stokes equation. On the other hand, the arguments here are not able to handle the presence of viscosity (basically because they rely crucially on the Kelvin circulation theorem, which is not available in the viscous case).")

#text("In fact, three different blowup constructions are presented (for three different choices of vector potential operator ")#mi("{A}")#text("). The first is a variant of ")#link("https://terrytao.wordpress.com/2016/02/01/finite-time-blowup-for-an-euler-type-equation-in-vorticity-stream-form/")[#text("one discussed previously on this blog")]#text(", in which a “neck pinch” singularity for a vortex tube is created by using a non-self-adjoint vector potential operator, in which the velocity at the neck of the vortex tube is determined by the circulation of the vorticity somewhat further away from that neck, which when combined with conservation of circulation is enough to guarantee finite time blowup. This is a relatively easy construction of finite time blowup, and has the advantage of being rather stable (any initial data flowing through a narrow tube with a large positive circulation will blow up in finite time). On the other hand, it is not so surprising in the non-self-adjoint case that finite blowup can occur, as there is no conserved energy.")

#text("The second blowup construction is based on a connection between the two-dimensional SQG equation and the three-dimensional generalised Euler equations, discussed in ")#link("https://terrytao.wordpress.com/2015/04/19/embedding-the-sqg-equation-in-a-modified-euler-equation/")[#text("this previous post")]#text(". Namely, any solution to the former can be lifted to a “two and a half-dimensional” solution to the latter, in which the velocity and vorticity are translation-invariant in the vertical direction (but the velocity is still allowed to contain vertical components, so the flow is not completely horizontal). The same embedding also works to lift solutions to generalised SQG equations in two dimensions to solutions to generalised Euler equations in three dimensions. Conveniently, even if the vector potential operator for the generalised SQG equation fails to be self-adjoint, one can ensure that the three-dimensional vector potential operator is self-adjoint. Using this trick, together with a two-dimensional version of the first blowup construction, one can then construct a generalised Euler equation in three dimensions with a vector potential that is both self-adjoint and positive definite, and still admits solutions that blow up in finite time, though now the blowup is now a vortex sheet creasing at on a line, rather than a vortex tube pinching at a point.")

#text("This eliminates the main defect of the first blowup construction, but introduces two others. Firstly, the blowup is less stable, as it relies crucially on the initial data being translation-invariant in the vertical direction. Secondly, the solution is not spatially localised in the vertical direction (though it can be viewed as a compactly supported solution on the manifold ")#mi("{{\\bf R}^2 \\times {\\bf R}/{\\bf Z}}")#text(", rather than ")#mi("{{\\bf R}^3}")#text("). The third and final blowup construction of the paper addresses the final defect, by replacing vertical translation symmetry with axial rotation symmetry around the vertical axis (basically, replacing Cartesian coordinates with cylindrical coordinates). It turns out that there is a more complicated way to embed two-dimensional generalised SQG equations into three-dimensional generalised Euler equations in which the solutions to the latter are now axially symmetric (but are allowed to “swirl” in the sense that the velocity field can have a non-zero angular component), while still keeping the vector potential operator self-adjoint and positive definite; the blowup is now that of a vortex ring creasing on a circle.")

#text("As with the previous papers in this series, these blowup constructions do not ")#emph[#text("directly")]#text(" imply finite time blowup for the true Euler equations, but they do at least provide a barrier to establishing global regularity for these latter equations, in that one is forced to use some property of the true Euler equations that are not shared by these generalisations. They also suggest some possible blowup mechanisms for the true Euler equations (although unfortunately these mechanisms do not seem compatible with the addition of viscosity, so they do not seem to suggest a viable Navier-Stokes blowup mechanism).")

#heading(level: 1)[#text("Comments (45)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470154")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("In the family of creases where blowup can occur for these generalized Euler equations, are there restrictions on the allowed variations in curvature along the crease?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470187")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2016")])]

#text("The examples I have involve blowup along either a straight line or a circle. One advantage of the differential geometry formalism, though, is that one can easily apply a diffeomorphic change of coordinates to the underlying space ")#mi("{\\bf R}^3")#text(" and obtain an equivalent generalised Euler equation system in which one conjugates the vector potential operator by the diffeomorphism. This creates a new generalised Euler equation that can blow up on anything diffeomorphic to a line or circle, while the vector potential operator still has the same qualitative features (basically behaving like a pseudodifferential operator of order -2), because these features are stable with respect to diffeomorphisms.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelfhopkins")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470156")[#strong[#text("samuelfhopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("I don’t understand the last parenthetical comment. If the Euler equations are just the Navier-Stokes equations with zero viscosity, why isn’t showing that the Euler equations can blow up enough to show that the Navier-Stokes equations can blow?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470160")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("I think non-zero viscosity could in principle dampen any developing singularities: whether it does or not, even if the Euler equations exhibit finite-time blow-up, is of course a million-dollar question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4104555c4798f2f9fd4d1aa182870411312642afb9a8b8cfbe3c17bd040cb958-08b7e708743df7722cb8ada811348cb491ef825c83599677abcc372284e3edf6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anthony Carapetis")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470162")[#strong[#text("Anthony Carapetis")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("It would certainly be an example of blowup for NS, but removing the viscosity significantly changes the character of the equations, so both cases are interesting in their own right. The Millennium prize problem (")#link("http://www.claymath.org/sites/default/files/navierstokes.pdf")[#text("http://www.claymath.org/sites/default/files/navierstokes.pdf")]#text("), for example, imposes positive viscosity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470255")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("I’m generally curious about your thoughts on applying vanishing viscosity to the problem. What would the outcome be, would any of the conclusions substantively change?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470259")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("I’m not sure what problem you are referring to, but it is widely believed that for the Euler equations (in which the viscosity is zero), finite time blowup should be possible, and perhaps even quite generic. For positive viscosity (Navier-Stokes), there is less consensus, but personally I believe it should be possible to construct some very special solutions which blow up in finite time, even if “generic” solutions will continue to exhibit global regularity (for some vaguely defined notion of “generic”).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470266")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("A couple of points that favor the consideration vanishing viscosity:")#linebreak()#text(" 1. In compressible Euler one has a “blow up” in the formation of shocks and vanishing viscosity is critical in choosing physically relevant solutions. It would seem that a similar result would be useful here.")#linebreak()#text(" 2. Evidence from the physical world would seem to indicate that solutions exhibiting blow-up in turbulence should be rather generic as the dissipative character of turbulence is rather universal. Again vanishing viscosity should be a route to achieve this end.")#linebreak()#text(" 3. It would seem to me that the blow up we seek isn’t catastrophic, but rather more like shocks where the derivatives become as large as they need to be only limited by whatever the finite value of viscosity may be as so the solutions achieve a self-similarity.")

#text("I can’t speak to whether the incompressible equations exhibit these characters (perhaps they do not!), but the observations of the physical universe would seem to indicate the truth of such behavior. In the reality such a blow up would be a generic and almost ever-present feature of the solutions in the limit of large Reynolds number (i.e., vanishing viscosity).")

#text("Perhaps the true discussion to consider is what the objective of the work is visa-vis reality and the Euler equations. Is the focus the zero viscosity Euler equations? I might submit that the zero viscosity Euler equations have little to no relevance to the behavior of fluids in the physical universe. The Euler equations in the vanishing viscosity limit most certainly do have relevance. At least to my mind this is an extremely important distinction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2016")])]

#text("Well, as long as the solution stays smooth (and localised), there is no distinction between the zero viscosity solution of the Euler equations and the vanishing viscosity limit of Navier-Stokes (this is a classical result, going back at least to the ")#link("http://www.ams.org/mathscinet-getitem?mr=277929")[#text("work of Swann in 1971")]#text("). So for the purpose of the global regularity problem, the zero viscosity and vanishing viscosity formulations are equivalent. It’s only after the formation of shocks or other singularities that the distinction becomes significant.")

#text("(That said, I actually do use the vanishing viscosity method to establish local existence for the generalised Euler equations in my paper. But I establish uniqueness using the zero viscosity formulation, as the existence argument uses compactness and so does not easily yield uniqueness.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d20c2faf00b92e29e07961c027448d5fb3592bc4eb027a7e9f55243a7db9cd-f7f871630eb512b4f840bb9c8b184ed30c5c8883bfb9ab9ca332914b9ddebed1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nicholas Pizzo")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470280")[#strong[#text("Nicholas Pizzo")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2016")])]

#text("It’s always interesting to consider singularities in theories that rely on the continuum hypothesis (eg physically, what is a “point” vortex?). As you think it’s likely that there are blowup solutions to the Euler equations, is there any insight into what physics are missing from the governing equation, as we don’t observe this behavior in nature. (A related example comes from plasmas governed by the 2+1 NLS equation, which has blowup solutions which are not physical, as Landau damping becomes significant for very small scales).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2016")])]

#text("Well, if there is a (stable) finite time blowup to the Euler equations, and one takes a physical fluid with initial conditions that would lead to this finite time Euler blowup, then probably what will happen is either (a) the viscosity effects of the physical fluid become significant at some point and dissipate the energy that would have otherwise gone to form the blowup, or else (b) the turbulence in the finite time blowup approaches the molecular level, at which point the continuum approximation becomes invalid and some other dynamics takes over. (There are other possibilities, such as the velocity reaching relativistic levels so that the non-relativistic Euler equations cease to be a good approximation, but I doubt this would actually occur for reasonable physical initial data.) I think there is already experimental evidence of (b) for colloid suspensions (such as mud, or blood) in which the particles are large enough that one can experimentally detect breakdown of Euler or Navier-Stokes type behaviour, but I don’t know the literature well in this area.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9c18a97abbec7e74bc762cf198501d91639cd314eafdf0ddb11c0c4e38902a39-2724fc75f9b2f88e8e8fc3ba88942046683efafcfcfca092c094fefc056b8767.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bill Rider")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470361")[#strong[#text("Bill Rider")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2016")])]

#text("I will just remind you that your work is with the divergence-free equations, i.e., incompressible. By the time the flow is relativistic the equations are already deeply invalid. Incompressible equations depend upon the Mach number being very nearly zero, and sound speeds are measured in 100’s or 1000’s of meters per second, light is 300,000,00 m/s. The physical validity of the approximations you’re working with are too rarely considered and may be far more limiting than typically accounted for.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470394")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("Whichever experimental results you refer to, a rational interpretation may be that, in certain physical situations such as colloid suspensions, the (extreme) motions might not be suitably described by a continuum, or perhaps the fluid media are exceedingly anisotropic and highly non-homogeneous with non-uniform density. This is by no means an evidence of a breakdown of the Euler or Navier-Stokes equations. Rather the equations have their limitations, as expected. It has been well-known that these equations do not work properly in strongly non-Newtonian fluids.")

#text("The validity/applicability of the Euler equations as a continuum model and the conjectured singular behaviour of the equations in incompressible Newtonian fluids are completely separate issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470417")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 July 2016")])]

#text("The physical justification of idealised equations such as the incompressible Euler equations is plausible as long as certain parameters of the fluid stay within a certain range, for instance if the pressure or velocity does not get too large, and the length scale of turbulent behaviour does not get too small. On the other hand, the local existence theory of these idealised equations says, roughly speaking, that these parameters do stay bounded if and only if no singularities form. Hence, a theoretical guarantee of global regularity for these equations gives support to the physical justifiability of these equations, whilst theoretical examples of blowup suggest that there are physical initial conditions of fluids which evolve into regimes in which the idealised equations are no longer valid. The connection is not rigorous though, as any putative global regularity result may lead to bounds on velocity, pressure, length scale, etc. that far exceed the physical ranges in which the idealised equations are justified. (For instance, the famous Beale-Kato-Majda criterion for regularity asserts that a solution to the Euler equations stays regular as long as the vorticity stays integrable in time; but the bounds obtained on statistics such as the velocity grow double exponentially fast in the bound on the integral of the velocity, making the bound more or less useless in physical applications.) Conversely, there may be a mathematical example of initial conditions that lead to finite time blowup, but these conditions may have enormous initial energy or incredibly tiny initial length scale that may make these conditions practically impossible to realise by a physical fluid.")

#text("Still, at a heuristic level, any mathematical mechanism for establishing regularity has a chance of having a physical counterpart that keeps the fluid in the range where the idealised equations are a reasonable approximation, and conversely any mathematical demonstration of blowup may have a physical counterpart which is analogous but not completely identical to the mathematical solution.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470530")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2016")])]

#text("It appears that divergence-free NS actually might be able to do both – represent a valid model but with some additional conditions, as well as not (otherwise). There is an explicit example of a smooth, divergence-free fluid velocity vector field, with bounded energy on R3, no singularities, infinitely continuously differentiable, zero at origin, zero towards infinity for which, together with nice behaving force field does not have solutions for all positions in R3 at t=0. I believe that you might be interested to see all details, including formal document and mathematica file with validating math and diagrams. If I do not find some unexpected omission(s), I would be more than glad to share once ready.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470602")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2016")])]

#text("I am bit confused, regarding turbulence and causality, so I will feel free to share my humble opinion, using simple common-sense. I see dynamics of fluids as function of just two things (excluding external forces like gravity) – fluid molecules and their interactions. From point of view of a single fluid molecule, its interactions are predominantly affected by electro-magnetic forces of immediately neighboring fluid molecules. Therefore, pressure, macroscopic fluid flow and turbulence must be direct manifestations of those inter-molecular interactions. If otherwise, question is what else there is? If nothing else, than that’s all there is.")#linebreak()#text(" In that context, regarding (b) “the turbulence in the finite time blowup approaches the molecular level”, I am confused about turbulence approaching molecular level. Some macroscopic visualization of dissipative turbulent flow might look like spiraling ‘ever deeper’ towards ‘molecular level’, but drivers of such turbulent flow themselves cannot be detached from ‘molecular level’, as that’s all there is – molecules and their interactions.")#linebreak()#text(" It’s another thing how choices are made to abstract Reality in form easier for mathematical manipulation, including continuum assumption/hypothesis.")

#text("I wonder if anyone knows, how it came to be that whole fluid dynamics, which is meant to be reliable and supported by formalisms, can be built on an assumption/hypothesis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2016")])]

#text("Continuum fluid equations such as the Euler equations are basically ")#link("https://en.wikipedia.org/wiki/Mean_field_theory")[#text("mean field approximations")]#text(" of the underlying microscopic equations of motion. As long as the motion of the individual particles at molecular scales behaves like a mean velocity u and near-constant density together with some random noise (like Brownian motion), one can extract an approximate equation for the mean velocity field, which happens to become the Euler equations under idealised situations. Actually, the incompressible Euler equations arise from multiple approximation processes of this sort; the microscopic N-body equations of molecules first approximate to the Boltzmann equation, then to the compressible viscous Euler equation, then to the incompressible inviscid Euler equation. Justifying each of these approximations rigorously is still a work in progress in some cases. But the mean field approximation holds up well as long as the mean velocity field does not oscillate at the molecular scale, i.e. if all turbulent behaviour stays above this scale.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2016")])]

#text("Is it possible to approximate also the molecular scale noise by some stochastic model ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470607")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2016")])]

#text("Thanks for prompt reply Terry.")#linebreak()#text(" I hope that you don’t mind some ‘thinking loud’ again, using some plain common sense – in case that real nature of turbulence is due to behavior of group of molecules jointly representing a fluid parcel, which dynamics is modeled by mean field approximation, then we have mathematical model(s) being capable to describe such behavior.")#linebreak()#text(" On the other hand, in case that the essence of turbulence is on a molecular level, and in case that ‘mean field approximation’ discarded as ‘noise’ information which carries the essence of ability to mathematically model turbulence, then with current fluid models, we would not be able to describe it, as models might be lacking such capacity. For sake of comparison – it would be as if ECG is approximated with some simple trigonometric function, and all one can see is that patient is alive, but without details which typical ECG can provide. In scenario like that, with current mathematical models, we might be in position to identify possibly some thresholds of turbulence, however, we might not be in position to fully model it, of course, assuming that cause is well postulated and as such modeled. In scenario like that, new model beyond existing would be required.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("Is it possible (assuming some type of finite time blowup – at the origin, say) to “design” special (global) new nonlinear transformation of space-time coordinates (perhaps with space-time dependent rotation) for which the assumed type of blowup can be made sufficiently simple to allow standard analysis?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470343")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2016")])]

#text("One possibility is that of a self-similar ansatz, which under suitable rescaled coordinates would become a steady-state solution of the Euler equations with an additional scaling correction to the velocity field. Such self-similar solutions cannot exist if the vorticity is sufficiently localised (basically because of energy conservation), and there are various results by Chae relaxing the localisation requirement, however as far as I know a self-similar solution that is slowly decaying in space has not yet been ruled out. As I remarked in the paper, I attempted to construct such a self-similar solution, but was not able to do so (particularly if one wanted to impose self-adjointness on the vector potential operator, as this together with self-similarity imposed a lot of constraints on the solution).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")])]

#text("Euler derived his equations according to the physical principles of the classical Newtonian dynamics (with negligible viscous effects for incompressible fluids).")

#text("Are you saying that your generalised equations come from a generalisation of the classical dynamics?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470372")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2016")])]

#text("The generalised Euler equations have a Lagrangian formulation, so they can in principle be derived from a classical mechanics system if one postulates a certain form for the action (which will involve some nontrivial interaction between different components of the fluid, and also a non-isotropic version of the kinetic energy). Presumably one could discretise this action and formally view the equations as a continuum limit of some N-particle system with an (admittedly artificial) action.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470392")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 July 2016")])]

#text("The Euler equations have a Lagrangian description (as given in textbooks on fluids) which is presumably different from yours!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470634")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2016")])]

#text("The Lagrangian description of the Euler equations is a consequence of the Hamiltonian action (generalized from the Maxwell-Boltzmann kinetic theory) or the conservation laws which have concrete physical meanings. Do you mind to explain the physical nature of your (extra) artificial action leading to your equations?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470642")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2016")])]

#text("I don’t know what criteria you are using to evaluate whether a given action is “physical” or not, but the laws of classical mechanics allow one to write down an essentially arbitrary Hamiltonian or action (subject to reasonable regularity conditions) to create dynamics; additional properties of the Hamiltonian or action, such as invariance under various symmetries, or minimal coupling, are desirable but not absolutely essential to create a meaningful dynamics that could potentially model some physics. Of course, such an arbitrary dynamics will probably not be realised in our actual physical universe, but one could posit the existence of a hypothetical universe in which these dynamics were the physical law. For instance, one could imagine a universe where kinetic energy was not an isotropic quadratic function of the velocity, but varied with the direction of velocity and also was somewhat nonlocal with respect to the velocity field. In the context of the generalised Euler equations, this would essentially correspond to replacing the Laplacian operator appearing in the Biot-Savart law with a more general pseudodifferential operator, and this is very roughly the type of modification I am using in my paper (there is also some spatial dependence of the action or Hamiltonian, in addition to velocity anisotropy and nonlocality). I don’t have any proposed mechanism though for what might generate this sort of anisotropy.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd497945ef7a73024dd80e83d640cd0bb573f80e1775254d60f6433fb8033047-bcf8a5b456de5be821c57d1937b2997f7fb7a87abace516dc208cd96eb2d3ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470651")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2016")])]

#text("Based on that, one could conclude that equations probably do not correspond to our actual physical universe?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470655")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2016")])]

#text("It seems that some motivation to consider (artificial) toy models (in addition to their mathematical properties which are sufficiently interesting) is to gain some physical insight on the behavior of the more complicated (physical) ones.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd497945ef7a73024dd80e83d640cd0bb573f80e1775254d60f6433fb8033047-bcf8a5b456de5be821c57d1937b2997f7fb7a87abace516dc208cd96eb2d3ee2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470662")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2016")])]

#text("Regarding criteria if action is physical or not – how about checking against three Newton’s laws? Would they work to start with?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470700")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("They obey ")#link("https://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamilton’s laws of motion")]#text(", which are a generalisation of Newton’s laws. On the other hand, Newton’s third law, which is equivalent in the Hamiltonian formalism to conservation of momentum (or translation invariance of the Hamiltonian) is not obeyed by most of the systems considered here, because the vector potential operator ")#mi("A")#text(" used here is not translation invariant (there is inhomogeneity in space).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470718")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2016")])]

#text("As you indicated, third Newton’s law is not obeyed, or in other words, if momentum is not conserved for most of the systems considered, I am having hard time understanding how Navier-Stokes equations could be used at all? NS equations themselves were derived using conservation of momentum, therefore, wouldn’t introduction of non-applicability of third Newton’s law, and equivalently conservation of momentum, invalidate whole NS equation itself? I wonder on which basis we can refer to NS equations as such, if we add constructs to them which are in opposition to the core postulates on which NS equation itself is built on?")#linebreak()#text(" Based on questions asked on this forum, I believe that many people possibly did not grasped the fact that momentum is not conserved for most of the systems considered, and that such systems are exploratory ‘mathematical toy models’, which might not be in that form applicable at all to our physical reality.")#linebreak()#text(" I did not realize that until now, so I believe that it might be useful to emphasize such important facts upfront, as I am afraid that people which might otherwise contribute, could get lost.")#linebreak()#text(" I wonder if we exhausted mathematical models in our reality in order to have to move on to an abstract one? Did we really use all we could, in alignment with laws of physics? Also, I wonder, in case of any conclusions made with those models, which criteria would be used to differentiate what relates to reality vs. one modeled by toy models? Also, question arises, at which point something modeled stops being fluid – I would imagine that one fluid parcel can impact neighboring ones due to third Newton law, however, it appears that toy models might allow fluid parcels not to do that…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470747")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 July 2016")])]

#text("It’s worth noting that Newton’s third law only applies to closed systems (with no interaction with an external universe), and Newtonian mechanics can happily consider open systems in which Newton’s third law is seemingly violated (e.g. a particle in a potential well or other external field). The language of Hamiltonian mechanics or Lagrangian mechanics is better suited here as they can handle more general physical systems of interest than the original framework of Newtonian mechanics (although one sometimes has to go beyond these mechanics also for certain open systems, in order to model dissipative effects, ")#link("https://en.wikipedia.org/wiki/Conservative_force#Nonconservative_forces")[#text("non-conservative external forces")]#text(" or ")#link("https://en.wikipedia.org/wiki/Nonholonomic_system")[#text("non-holonomic dynamics")]#text(" coming from external interactions and constraints). In particular, Hamiltonian mechanics can produce dynamics from any (reasonably regular) Hamiltonian function on phase space; it is only the subclass of Hamiltonians that are translation invariant that happen to obey momentum conservation (and Newton’s third law), but Hamiltonian mechanics is not restricted solely to that subclass. Similarly for Lagrangian mechanics (with the Lagrangian action playing the role of the Hamiltonian function).")

#text("(Actually, it is also possible for Newton’s third law to break down in closed systems also if there is breaking of translation symmetry. For instance, Newtonian gravity on a curved static spatial domain (note that this is NOT the same as general relativity) would fail to have a conserved total momentum due to the non-translation-invariance of the total gravitational energy, and so Newton’s third law would fail in this case.)")

#text("The momentum-nonconserving components of the dynamics in the type of generalised Euler equations can be viewed as being somewhat like a magnetised fluid in a spatially inhomogeneous external magnetic field (though the forces exerted here are not exactly what is given by the Lorentz force law). That model also does not conserve momentum unless one incorporates the electromagnetic field into the system and assigns it a momentum also. It is likely that one could similarly introduce a somewhat artificial field to the generalised Euler equations with an assigned momentum in order to restore the momentum conservation law, though this would complicate the mathematics for little gain.")

#text("In any event, the point of toy models is usually not to reproduce the underlying fundamental physics that is used to derive the true equations, but rather to reproduce the ")#emph[#text("consequences")]#text(" of those equations. To give just one example, ")#link("https://en.wikipedia.org/wiki/Sonic_black_hole")[#text("acoustic black holes")]#text(" are useful toy models for gravitational black holes because their equations of motion are mathematically similar, even though the physical derivation of these equations are completely different.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ateravis")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-471059")[#strong[#text("ateravis")]]#text(size: 9pt, fill: rgb("596477"), " · 26 July 2016")])]

#text("Terry, I would assume that it would depend on how you define a ‘closed system’ as well as ‘external universe’. In case that under ‘closed system’ one includes conservation of mass, and equivalently energy, then in ‘open systems’ which might lose or gain energy/mass, Navier-Stokes is not applicable at all, as it is constructed on the basis of conservation of mass (including momentum/energy). From the moment that choice is made to diverge from mathematics corresponding to recognized classic-mechanical laws of physics, from that point on Navier-Stokes does not make sense anymore, and any arbitrary equation with any name that comes with it can be taken to represent anything else other than what represents classical-mechanical description of our Universe. We all know that NS has very specific physical context which includes conservation of mass, so the moment that (or similar included property) is taken away, it does not represent NS anymore.")#linebreak()#text(" If we cannot be certain that some quantifiable action can result with equal and opposite reaction, question is on which basis do we have a ‘freedom’ to choose laws for toy models and, on which basis can we deduct any conclusions in such circumstances? Also, I would like to emphasize, that ‘seemingly violated’ third Newton’s law with potential well is not really an example in support of violation of third Newton’s law and your point. In that scenario action of particle captured by potential well is reflected in form of reaction of atoms/molecules forming such well, which is in essence transferred to temperature oscillatory energy. That is what ‘seeming violation’ makes ‘seeming’, however, not real violation.")#linebreak()#text(" Regarding breaking down Newton’s third law in closed systems by breaking translation symmetry in case of curved static spatial domain, which is not the same as general relativity – In such scenario question is on which basis can we curve static spatial domain without taking general relativity into account, and still to be able to claim that modeled system is ‘real’? In that particular case, choice of curved spatial domain without any relationship to general and possibly special relativity is again departure from how recognized laws of physics representing our reality. In alternate realities, no doubt, anything is possible.")#linebreak()#text(" Intention of using ‘toy models’ in order to reproduce consequences is quite understandable, however, I am afraid that fading or removing relationship with mathematics representing laws of physics might give us freedom of choice, taking us away from ability to back-trace conclusions to the core rationale why is it done after all, which in this case is fluid dynamics. Acoustic black holes as toy models of real black holes is in my opinion something else, as we model one physical thing with another, easier to manipulate and understood, however, both are equally real.")#linebreak()#text(" I firmly believe that way forward (overall) is in a new model based on solid understanding and modeling of physical processes governing fluid molecular motion and inter-molecular interactions. That way, shortcomings of current model(s) might become quite visible…")#linebreak()#text(" One more point – with NS for incompressible fluids we do not have range of length scale at which NS is applicable. With such lack of scope of applicability, one could wonder if it is applicable both on quantum scale as well as at level of general relativity – mathematically it appears to be the case as no additional conditions are imposed. If so, question is if we are expecting NS to solve much larger question of unifying quantum mechanics with general relativity? Maybe that is where the answer is after all…")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470435")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2016")])]

#text("Can you concoct some examples (with definite initial numerical data) for each of your blow-up schemes ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470494")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2016")])]

#text("Yes, the constructions in the paper are explicit (though a little messy, and not optimised for numerical simulation).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470610")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2016")])]

#text("Admittedly the ‘examples’ are more than ‘messy’ for numerical purposes, if ever feasible, as the initial-boundary value problem, because your equations are different from the true Euler’s in ‘unknown’ territories where actual computations may possibly clarify.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470599")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2016")])]

#text("Just a LaTeX note: You should use ")#mi("\\langle")#text(" and ")#mi("\\rangle")#text(" instead of .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 July 2016")])]

#text("I’ll give it another go: you should use ")#mi("\\langle")#text(" and ")#mi("\\rangle")#text(" instead of $latex $.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470778")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("In the first math expression on page 24, there is an unwanted linebreak just before the first inequality.")

#emph[#text("[I’m afraid I don’t see the issue. Can you elaborate? -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-470789")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2016")])]

#text("I must have been looking at one of the references in your paper because there’s nothing wrong with this paper at the aforementioned place. (Sorry for the confusion.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-471292")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2016")])]

#text("At the top of page 9 in your paper, the sentence containing “where in the last two cases we interpret the differential operators…, where in the latter two cases we interpret the differential operators…” was typed incorrectly.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-471438")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2016")])]

#text("Terry, I believe that you might be interested in velocity vector field ")#mi("\\vec{u}(\\vec{x})")#text(" which has bounded energy ")#tao-math("\\int _{R^{3} }\\left|\\vec{u}\\right|^{2} dx=\\pi ^{2}", block: false)#text(" over all of ")#mi("R^3")#text(" space. The velocity vector field: ")#mi("u_{i} (\\vec{x})=2\\frac{x_{h(i-1)} -x_{h(i+1)} }{\\left(1+\\sum _{j=1}^{3}x_{j}^{2}  \\right)^{2} }")#text(" ; ")#mi("i=\\{ 1,2,3\\}")#text(" where ")#mi("h(l)=\\left\\{\\begin{array}{ccc} {l} & {;1\\le l\\le 3} & {} \\\\ {1} & {;l=4} & {} \\\\ {3} & {;l=0} & {} \\end{array}\\right.")#text(" is smooth, divergence-free, continuously differentiable ")#mi("u(\\vec{x})\\in C^{\\infty }")#text(", it has zero velocity at coordinate origin, and velocity converges to zero for ")#tao-math("\\left|\\vec{x}\\right|\\to \\infty", block: false)#text(". Also, force vector field ")#mi("\\vec{f}(\\vec{x},t)=(0,0,\\frac{1}{1+t^{2} (\\sum _{j=1}^{3}x_{j}  )^{2} )})")#text(" proves to be smooth, continuously differentiable ")#mi("f(\\vec{x},t)\\in C^{\\infty }")#text(", converging to zero for ")#tao-math("\\left|\\vec{x}\\right|\\to \\infty", block: false)#text(". Applying ")#mi("\\vec{u}(\\vec{x})")#text(" and ")#mi("\\vec{f}(\\vec{x},t)")#text(" in incompressible Navier-Stokes equations results with three mutually different solutions for pressure ")#mi("p(\\vec{x}, t)")#text(", one of which has term ")#mi("\\frac{1}{t}ArcTan(t \\sum _{i=1}^{3}x_{i})")#text(" that evaluates to ")#mi("\\frac{0}{0}")#text(" at ")#mi("t=0")#text(", which is indeterminate for all positions ")#mi("\\vec{x} \\in R^{3}")#text(".")

#text("If interested, here is link to Wolfam Mathematica file demonstrating it:")

#link("https://db.tt/JYDzQ26I")[#text("Link to Wolfram Mathematica file ")]

#text("I also have full PDF article with all details. If interested (anyone), I will be glad to share. Please let me know: ")#link("mailto:kodza@yahoo.com")[#text("kodza@yahoo.com")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-471480")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2016")])]

#text("Terry, you might also be interested to check out video on YouTube regarding Incompressible NS open questions as well:")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-471855")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2016")])]

#text("Based on earlier comments exchanged about the meaning and applicability of incompressible vs. compressible fluids, you might be interested in the analysis of the fluid velocity vector field divergence ")#mi("\\nabla \\cdot \\vec{u}=-\\frac{1}{\\rho } (\\frac{\\partial \\rho }{\\partial t} +\\vec{u}\\cdot \\nabla \\rho )")#text(" derived directly from the continuity equation, ensuring conservation of mass. Each of two terms ")#mi("\\frac{\\partial \\rho }{\\partial t}")#text(" and ")#mi("\\vec{u}\\cdot \\nabla \\rho")#text(" within the brackets might be zero, positive, or negative. In case that both terms ")#mi("\\frac{\\partial \\rho }{\\partial t}")#text(" and ")#mi("\\vec{u}\\cdot \\nabla \\rho")#text(" are of equal value and opposite sign, their sum is zero, resulting in zero divergence ")#mi("\\nabla \\cdot \\vec{u}=0")#text(". This means that fluid density ")#mi("\\rho")#text(" can change over time as well as over space, while the resulting velocity vector field can be divergence-free ")#mi("\\nabla \\cdot \\vec{u}=0")#text(" for as long as the sum of the terms, ")#mi("\\frac{\\partial \\rho }{\\partial t}")#text(" and ")#mi("\\vec{u}\\cdot \\nabla \\rho")#text(" results with zero. Once statement for velocity divergence is applied to the Navier-Stokes equation for compressible fluids we get: ")#mi("\\frac{\\partial \\vec{u}}{\\partial t} +(\\vec{u}\\cdot \\nabla )\\vec{u}=-\\frac{1}{\\rho } \\nabla \\bar{p}+\\nu (\\Delta \\vec{u}+\\frac{1}{3} \\nabla (\\frac{1}{\\rho } (\\frac{\\partial \\rho }{\\partial t} +\\vec{u}\\cdot \\nabla \\rho )))+\\vec{f}")#text(". From that, condition for vanishing viscosity term of NS equation is derived: ")#mi("\\nabla (\\frac{1}{\\rho } (\\frac{\\partial \\rho }{\\partial t} +\\vec{u}\\cdot \\nabla \\rho ))=-3\\Delta \\vec{u}")#text(". Following a few additional steps, even more elementary condition for vanishing viscosity can be derived, which states that velocity divergence ")#mi("\\nabla \\cdot \\vec{u}=-\\frac{1}{\\rho } (\\frac{\\partial \\rho }{\\partial t} +\\vec{u}\\cdot \\nabla \\rho )")#text(" must be harmonic function satisfying Laplace’s equation ")#mi("\\Delta (\\nabla \\cdot \\vec{u})=0")#text(". As such condition is in function of fluid density rate of change over space and time, that might be helpful in better understanding underlying physical mechanisms responsible for triggering turbulence in fluids. If interested in more details, related paper is available on arXiv: ")#link("http://arxiv.org/abs/1608.07214")[#text("http://arxiv.org/abs/1608.07214")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5300af1818b8761458a6f02cfea203aa82326dfa94d21ebf450c03d10cbb52ee-cf9c768b018abac89ec66cccb335f859e5e145972366ade7b7ce092b5046b429.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dejan Kovacevic")]], [#link("https://terrytao.wordpress.com/2016/06/29/finite-time-blowup-for-lagrangian-modifications-of-the-three-dimensional-euler-equation/#comment-471935")[#strong[#text("Dejan Kovacevic")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2016")])]

#text("Terry, you might also be interested to check out video on YouTube regarding divergence in function of fluid density, and conditions for vanishing viscosity term of the Navier-Stokes equations for compressible fluids:")#linebreak()
]
