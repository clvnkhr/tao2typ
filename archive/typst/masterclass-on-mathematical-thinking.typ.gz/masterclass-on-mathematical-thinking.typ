// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/
// Converted to Typst by tao2typ: "2026-10-14T16:39:00.055148+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Masterclass on mathematical thinking", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Masterclass on mathematical thinking")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 January 2022")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/")[#text("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("About a year ago, I was contacted by ")#link("https://www.masterclass.com/")[#text("Masterclass")]#text(" (a subscription-based online education company) on the possibility of producing a series of classes with the premise of explaining mathematical ways of thinking (such as reducing a complex problem to simpler sub-problems, abstracting out inessential aspects of a problem, or applying transforms or analogies to find new ways of thinking about a problem). After a lot of discussion and planning, as well as a film shoot over the summer, the series is ")#link("https://www.masterclass.com/classes/terence-tao-teaches-mathematical-thinking")[#text("now completed")]#text(". As per their business model, the full lecture series is only available to subscribers of their platform, but the above link does contain a ")#link("https://www.youtube.com/watch?v=axzFfSvQdYQ")[#text("trailer")]#text(" and some sample content.")

#heading(level: 1)[#text("Comments (83)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639742")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Is there any particular reason why you decided to do these lectures through a for-profit company instead of just making the material publicly available (for example through this blog)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639743")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("This weblog already has many pages where different suggestions for thinking mathematically have been suggested by professor Tao. In fact if you read through his blogposts carefully, you will often find examples of how he changed the odor of a problem by viewing it differently.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639744")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("The production values of the lecture series given by Masterclass would not be possible for me to replicate by myself. (For instance, the film shoot alone involved well over a dozen people, including makeup, prop design, camera and lighting crew, director, editing, etc., in a custom studio with professional-quality recording equipment. The professional scriptwriting services were also very valuable, improving the selection and arrangement of material in ways I would not have thought of.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("How many classes? Are the lectures on going, or have they all been finished? Are they target at the general public or professional mathematicians?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639750")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("In the end we produced a series of 12 short lectures, the titles of which should be visible from the web page linked to in the post. The target audience is the general public, without presupposing any exposure to advanced mathematics (or even high school mathematics, really).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("I finished all 12 chapters of your masterclass. Great content and very inspiring. Thank you Prof. Tao!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("It seems that Masterclass is an online form of “The Great Course” series, which are in DVD format, and you can borrow from local library for free.")#linebreak()#text(" Maybe one can get free subscription from libraries.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639748")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("That seems curious to me. Are the scriptwriters knowledgeable about math? If not, how would it be possible for them to know what material is essential, or the optimal way to arrange it (unless they are doing it from the perspective of a student audience)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639749")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("The scriptwriting process was a collaborative one; I submitted some material on proposed lecture topics, and after many (remote) meetings with the producer and writers we were able to pick out the most promising topics and develop them into a coherently arranged series. One or two of the people involved did have some mathematical training, but actually I think the fact that many of the writers did not have this background was in fact helpful for this particular type of outreach project, as they could tell when a proposed topic was too technical or assumed too much prior exposure to mathematics.")

#text("As a side note, I did have some very enjoyable discussions with the staff at Masterclass about the analogies between the creative process in mathematics and the creative process in filmmaking. Unexpectedly, a lot of the experiences I had working on a mathematical problem resonated with the filmmakers, and vice versa, despite working in ostensibly very different fields.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd08c47d45feabd858fb9adac52d7aa7ec6e7510a8206b481108672b9548dff4-667181df0f7e532ac30b573de74c7dd665d32c37df151d377e732ea63d7847d9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mayson Lancaster")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639767")[#strong[#text("Mayson Lancaster")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("I wonder how close to those production values you could come in collaboration with the community on the site OfficeHours.global? It might be worthwhile checking it out, perhaps starting by attending their Saturday education session. Links:")

#link("https://officehours.global")[#text("https://officehours.global")]#linebreak()#text(" ‘")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d286623368c887eafaa10f691b2add0d1b8381eec78a3a5283ca677eef00ba7a-157da4c1306e68bd6d25c5d51e9d17af5f144e1991985e06baf6d8c1a2a685b9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alfagaffel")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639755")[#strong[#text("alfagaffel")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Using this blog Professor Tao will certainly reach out to people. However, the people using the Masterclass in not the same.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18a7866c654cf3fe1ab1279db62496f1558286f44647c5b36d79ac83fd1c4771-6f3e77fee47e6083ed03276fb5c145cccb35c5dd51132e7b400ddf4c6d140ff4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639791")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("There is already a huge amount of free material available at this blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ee2c385dc5131a1f0df94d9c4d1abac5eaa626e0f8b0b21d5f6abfd9d0cf28-b3a7bc1d767d1922e06ed0aaee2882740dd19d61e3abac54e6f8151c47960fdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Aguilar")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639868")[#strong[#text("Jaime Aguilar")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("It’s so he can fool dumb people like me into buying it and spending $200 for condescending videos.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ee2c385dc5131a1f0df94d9c4d1abac5eaa626e0f8b0b21d5f6abfd9d0cf28-b3a7bc1d767d1922e06ed0aaee2882740dd19d61e3abac54e6f8151c47960fdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jaime Aguilar")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639869")[#strong[#text("Jaime Aguilar")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("He was my hero and I admired what he did because I thought it was right; even though I knew Jack about his mathematics section")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/68ee2c385dc5131a1f0df94d9c4d1abac5eaa626e0f8b0b21d5f6abfd9d0cf28-b3a7bc1d767d1922e06ed0aaee2882740dd19d61e3abac54e6f8151c47960fdb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JAIME AGUILAR Robles")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640630")[#strong[#text("JAIME AGUILAR Robles")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2022")])]

#text("I picked up your new edition “solving mathematical problems” ebook from Amazon and love it. I had the first edition which I gifted to one of my profs from CWU in Washington years ago. I think she worked w/ prime numbers too.")#linebreak()#text(" Thank you for all the hard work!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639752")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Wow, this master class looks a lot interesting.")

#text("I am a mathlete competing in the Math Olympiad. I can solve some problems in IMO. I finished top 20 nationally 2020, but didn’t make it to the national team. I failed again in 2021, although I think I’m really close to it.")

#text("I’m currently a freshman in high school and have two years left to make the national team.")

#text("I’m wondering if this will help me solve the problem better, will it help my journey IMO?")

#text("By the way, how about your book “Solving Mathematical Problems”, what do you think of the book now after you’ve been doing math for so long? Do you think this will help me prepare IMO?")

#text("Do you have any other suggestions, book lists, what to do to prepare IMO?")

#text("I really admire you, you are a role model in my eyes.")

#text("I am really looking forward to working in mathematics. At the same time competing, I’m also working on university math, but I’d love to win the gold medal, which I think is a stepping stone to becoming a mathematician.")

#text("Thanks for answering!")

#text("-Mingdao Zou, from Sweden")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7fe2c5dbc73049213eafd51cfd545cdb4ef667e55e7b832ec4209558052b219b-3310ce61e764de979bb0c99543c42954a3a577409f1eb4100de80b0801211ba6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Kipper")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639798")[#strong[#text("David Kipper")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("Well, a gold medal in the IMO surely could be helpful for a carreer as a mathematician, but it isn’t a necessity, and the experience of solving many hard problems, especially when young, is a big boost for your thinking and learning skills.")#linebreak()#text(" However, there are quite a few differences between more advanced(say, graduate level and above)mathematics, and olympiads in general.")#linebreak()#text(" For example, you know that the problems you’re presented with in the IMO can all be solved and in a certain time limit, which is really very different from the impression you get about mathematical research.")#linebreak()#text(" When taking for example a class in algebraic geometry, and taking the test home, where you have maybe 3-4 days to prove maybe 2 out of 3 statements, there are again similarities, but also many differences.")#linebreak()#text(" And finally, my personal impression(=opinion which might be wrong) is that this series of lectures isn’t for you. Not that you necesarily wouldn’t benefit, but maybe the total amount of time you’ll invest in all 12 lectures wouldn’t stimulate you as well as reading for the same lenght of time Polyà’s “How to solve it”, or any similar, more advanced resource. A problem book(in the sense of Gelbaum, 1001 problems in NT, etc.)however, might “hit” your brain harder, which is what you want at this stage. Good luck!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639819")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("Yes, I’ve read “How to Solve It” by Polyà and even Terrys solving Mathematical Problems.")

#text("From Terrys experience with Olympic problems, Terry seems to have this idea and make the strategy more concrete.")

#text("The difference is that Polyas’ strategy was more general, since he lived before the Math Olympics, and Terry made it more specific.")

#text("We can see that Polyas strategy was:")

#text("Understanding the problem->Come up with ideas/seeing the big picture->Reasoning to prove the problem")

#text("Also the last step to review and reflect, but I won’t add it here for convenience.")

#text("So I basically call it: Understand -> Observe -> Prove")

#text("Terry, he starts by understanding different aspects of the problem, like what it asks us to do, the data we have and the objective.")

#text("Then, choose a good one from various notations or expressions that fits with the big picture, which is a process of observation and selection.")

#text("Now that we have more data, we will try to understand it by association of ideas, and correlating it with the knowledge we have.")

#text("After that, he said we have the tools we need and we will get to understand the problem deeper. He does this by modifying the problem, namely analysis and synthesis.")

#text("An example is considering a special case of the problem, such as an extreme or degenerate case. By then we understand the problem and see the pattern, and we can go back to the original problem with an idea, and even the result we proved.")

#text("He got more aggressive examples of modifications. But they all have the same purpose to understand the problem.")

#text("“These aggressive exercises can also help in getting an instinctive feel of what strategies are likely to work, and which ones are likely to fail.” Terry says in his book.")

#text("The next step is to prove result of our problem.")

#text("Note: He didn’t mention this, but Polya did: Any results we proved were actually a reflection of a plan, which meant we had to observe and come up with ideas first. Without ideas, we don’t know which direction to go, what steps to take.")

#text("The final step he mentioned was simplifying, leveraging data and reaching tactical goals.")

#text("He calls this step the longest to solve the problem and rarely explains how it works.")

#text("This is the part where most people misunderstand what Terry is telling us.")

#text("It gets confusing, but actually how it works is it loops back to the comprehension part, and then the next again.")

#text("This means: Understanding -> Observing -> Reasoning, is actually a cyclic process that repeats over and over again.")

#text("Solving a problem isn’t easy, it’s not a straight sequence of steps you take and then you’re done.")

#text("In fact, this last “title” is already a combination of understanding, transforming the problem to simpler one, observation, dialectical thinking by looking at the big picture, and reasoning to prove results.")

#text("Anyway, this is my experience in solving many problems, limited by my cognition.")

#text("I am eager to learn more!")

#text("Sadly, I have now decided to buy the masterclass. I want to follow up on Terry’s work. We’ll see how it goes. :’v")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639821")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("By the way, by looking at the big picture, I mean looking at how things are connected, how a certain variable affect with each other, how the pattern affects, looking at the similarities and differences between elements.")

#text("And also what is the hidden connections in the background? Can the problem be reduced, transformed, generalized, and specialized to any situation? What’s the constant? How about looking at the problem from a changing perspective?")

#text("Of course, there are more strategies to observe, and many, many tactics.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640359")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2022")])]

#text("I like your being so very strategic in your thinking. It will take you far! (Maybe not to a GM in the IMO, but something more important to achieving a satisfying career: becoming an effective practicing mathematician.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639835")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("These are very good ideas! It may be added that each selected special sub-problem should be sufficiently simple but still capture many features of the original problem to be used as a “toy model” and a nutural “building block” for the original problem.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639855")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("You’re right, that’s the rule to remember.")

#text("Anyways, these books are good as reference books for elementary mathematical thinking and thinking methods, but it is a bit reluctant to read these books if you take a step forward and comprehend the way of mathematical thinking systematically and thoroughly.")

#text("The more I learn, the more exciting it seems to be. I know I have to work hard to learn these high things, but more important it is to think mathematically, to understand how things are connected, to know all the patterns and hopefully discover new things and to learn more about what mathematics is all about.")

#text("I’m really looking forward to future math challenges!")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6e9af35a2768f5ad9f2492080107f6b14d5f457961c0e59cbed517b5ed5ddbd-4f856fbb74f4f360dca4b001a1e9f8006d1467bb0c8efb0965ff2b20138821f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of achraf")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639754")[#strong[#text("achraf")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Can you provide us a free access to the series ? Because masterclass is a paid platform.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639864")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("What is told is not free, what is free is not told.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639756")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Is there a general method to reduce a problem into “natural” sub-problems?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639757")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Note: I have read your post “Advice on mathematics competitions”.")

#text("And I’m still confused due to my knowledge limitations.")

#text("I have a study plan for IMO and I am working hard.")

#text("But there’s still uncertainty here, like I can’t fathom the minds of people who get perfect socres IMO, it seems to be the best for them. I’m wondering what’s to separate best from the rest? Especially after trying again and failing in 2021.")

#text("Einstein said not only to work hard, but also to be efficient, I don’t have as much advantage as you in IQ. And I really want to aim high and aim for a gold medalist and even perfect score.")

#text("I’d really appreciate it if you have an answer to clear my mind!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("I’m quite sure there are many top mathematicians in the world who didn’t make their national team so it is not the end of the world if you don’t. See ")#link("https://www.reddit.com/r/math/comments/xvkft/real_math_versus_international_mathematical/")[#text("https://www.reddit.com/r/math/comments/xvkft/real_math_versus_international_mathematical/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639784")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("I know you’re right, there are a lot of things to focus on and all to be a mathematician. IMO, a stepping stone to Terry, who says that while it’s not everything, problem solving is still part of real mathematics. I’m currently working hard and it’s a lot of work. What should I value more to archive better results and what else can I do?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639785")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("I see IMO as a stepping stone, this is Terry’s too")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcc8946f803e2fd7a6157d43b3a347a85dfdccc1a772a4fe526012aa745e91ff-b32507acb466766f9be1685d880c057ea5d929c88b1bbb6a4e287c2627f485ba.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Fry")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639758")[#strong[#text("David Fry")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Said it before, & I’ll say it again: Terry is destined to be on a much larger stage in order to fulfill his purpose. So what if he makes a few bucks for his valuable time to ultimately reach the world stage?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639760")[#strong[#text("Masterclass on mathematical thinking by Terrence Tao - The web development company Lzo Media - Senior Backend Developer")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")]

#text("[…] Article URL: ")#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/")[#text("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639761")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Sounds great! I love Masterclass and the great quality of their videos. Looking forward to watching them!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb2cb41ab755d27c139d6a59c6eab3d8e0640e7f9c8ed74721416b9ba6d7b4db-8d6935b0e49bc9e55c4abc372e49068dee8bc75078dabaedd681a54ebf30a31d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prithvi")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639763")[#strong[#text("Prithvi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Hey Terrence, would you consider doing a similar thing but with a target audience of those that have let’s say an undergraduate level of exposure to mathematics? And if there was a cost that need to be recovered you could put it on patreon? I’m sure there are many others like myself who would greatly appreciate seeing how you apply “a mathematical way of thinking” to problems that are perhaps difficult for us but more intuitive for yourself? just spitballing")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb2cb41ab755d27c139d6a59c6eab3d8e0640e7f9c8ed74721416b9ba6d7b4db-8d6935b0e49bc9e55c4abc372e49068dee8bc75078dabaedd681a54ebf30a31d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prithvi")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639764")[#strong[#text("Prithvi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("I think your recent nines of safety post, would be a perfect example.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb2cb41ab755d27c139d6a59c6eab3d8e0640e7f9c8ed74721416b9ba6d7b4db-8d6935b0e49bc9e55c4abc372e49068dee8bc75078dabaedd681a54ebf30a31d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prithvi")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639765")[#strong[#text("Prithvi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Also sorry for misspelling your name.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639766")[#strong[#text("Masterclass on mathematical thinking")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")]

#text("[…] Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639771")[#strong[#text("Masterclass on mathematical thinking by harmonicseq - HackTech News")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")]

#text("[…] Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ba51e8511b208a4d0f8daa0f7ca6979a03f01385b318825d7cb82b6ba89d457-02068d031e061de54042a278e8c8db1b67b787038da660e3f8952957e32aae37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johann")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639772")[#strong[#text("Johann")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Pricey, but likely to be amazing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639773")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Aah, that tic-tac-toe problem of summing 3 number up to 15 is very special to me. I discovered it while playing a similar game with my grandfather as a child. It brought me so good memories.")

#text("I think this way of thinking about mathematical problem-solving as a game is quite effective. I remember hearing about it over media from Paul Erdos’s bio-documentary “N is a number” where he speaks about the Supreme Fascist and it seems very effective to think about a problem as a hurdle being put up by the SF and nature being your friend, so together you apply tools to solve the problem and send the SF to hell.")#linebreak()#text(" Probabilistic ideas can then be interpreted as a random adversary who would throw in some extra help or sometimes hurdles thus limiting our actions or increasing their range of application in some sense.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aditya Guha Roy")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639774")[#strong[#text("Aditya Guha Roy")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("For those who are puzzled and needs a hint: think about filling up numbers in a 3 by 3 grid so that the numbers in each of the tic-tac-toe winning positions sum to 15.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6bc674352a5210cc5eb4a399d5b10c2e41dee7e6151b3f041b571adaf5bcd61c-f89ccb3a31d9f295367df7a5652fee423b078b1883305d49c6303ad83512dd08.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Grace Fenton")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639777")[#strong[#text("Grace Fenton")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2022")])]

#text("Watching it and getting more and more excited to find opportunities to practice these concepts after each lesson… so good! Especially the problem transformation lessons!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("I dropped out of math department and decided to get married with someone…thanks for your company in maths. best wishes~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639796")[#strong[#text("Masterclass on mathematical thinking – Cyber Geeks Global")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")]

#text("[…] Comments…Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9938e6bbc587c45b865de1fb7094ae12f8bf038871a8c58822903c1a57fa8056-ea651d2eca1e59bb8a4928a617fc049481098e0b35beedff1cbb8bbf18f0038b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("wow")#linebreak()#text(" that’s great news")#linebreak()#text(" Mister Tao !!")#linebreak()#text(" I’ve always waited for something like this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4d7b7fd53e619dc7e86c4c0ef7fafde670e28a5e597eb6db8af5327e83852e67-5c9d1c8178a5e7dcaf878f9be21ad9db93e2b08e645436340872af2030ba3772.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zenifer Cheruveettil")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639801")[#strong[#text("Zenifer Cheruveettil")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("This course may be a very good thing in the sense that it’s another tool to spark interest towards mathematics. But looking at the lesson plan, it looks like it is too high level for those who had some training (formal or otherwise) in undergraduate level of mathematics?")

#text("So far, the best course which I’ve found in this area is a [](course) from Keith Devlin in Coursera (")#link("https://www.coursera.org/learn/mathematical-thinking/home/welcome")[#text("https://www.coursera.org/learn/mathematical-thinking/home/welcome")]#text(")")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639805")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2022")])]

#text("Good, this is great for who can afford it. Definitely, I would take it if I could.")#linebreak()#text(" By the way, talking about solving difficult problems through easier ones… anyone knows an elementary proof that ax = 1 module m has solutions if and only if a and m are coprime integers? I know a proof using the Bézout’s identity, but I was wondering if there exists some direct method in this particular problem.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/097a4d5133f182db0e69d4c8b545f1e04ffe71834194bb0c5514993838312913-be24c73e8383858c44fd3f54eca00b77b675548c40c6fb0e21384600734295e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YahyaAA1")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640357")[#strong[#text("YahyaAA1")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2022")])]

#text("Hint: That ax = 1 (modulo m) has solutions if and only if a and m are coprime is fairly easy to show, if you just remember and apply the definition of what it means to be =1 (modulo m).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/654860f7ab3bccdacdd1edf4ed9ca7a452824bc33757d21bd183dd0012aafae1-bef87085757bcf462a3a59c721d677df37b119c3fd1e9113e67b868e9183be0f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Edgawliet")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-641906")[#strong[#text("Edgawliet")]]#text(size: 9pt, fill: rgb("596477"), " · 26 March 2022")])]

#text("First, sorry for this delayed reply, but somehow the notification to my account didn’t reach me.")#linebreak()#text(" Now, thanks for your suggestion! If I recall correctly, be = 1 module m means that the variable x is either 1 or is 1 + a multiple of m, that is x = km + 1 for some integer k. Is that what you mean?")#linebreak()#text(" Indeed, I start in this way and found some interesting facts (at least for me) but not enough to prove the general case, I tried also using induction, but with no result.")#linebreak()#text(" Nonetheless, I did a little research, and it happens there is a proof using the well ordering principle with the set { h: h = ax+my} and I grasp this.")#linebreak()#text(" You were suggesting this, or do you have another proof?")#linebreak()#text(" I really appreciate your help. Thanks.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639817")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("Tao you sucks. You just like money. What a moron")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639836")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")])]

#text("You don’t have the talent and opportunity to make more money, don’t blame others for doing so. Use the time and energy to improve yourself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639872")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("Well, I don’t think he’s short of money. Maybe he even did the masterclass for free.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639874")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("I can feel his energy hearing him speak, maybe he’s just trying to inspire a wider audience.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/470d0c45aa85085a87dfa2f37333a06e9311dc6ffe5374adb178f56fdf49a582-ccbce61a214fc155cd6c71bca7fb8411faf17cc9da1e2582c0aaa3c9c9238618.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of marouane")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640119")[#strong[#text("marouane")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2022")])]

#text("you are right, he is not intelligent yet to buy a domain name for this current blog so old template, …. Terence is overrated by the media, I am sure 100% he doesn’t have the capabilities to solve the current conjectures in number theory")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639830")[#strong[#text("Masterclass on mathematical thinking - pentestswap")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2022")]

#text("[…] Read More […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639870")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("The astronomical calculations in section “Choosing the problem to solve” are very interesting!")

#text("The essence of mathematical thinking activities is the reasonable (movement) changes under the guidance of mathematical thinking methodology.")

#text("The highest purpose of mathematical problem-solving thinking is change (transformation).")

#text("The essence of mathematical problem-solving is to constantly change, constantly modify the form of the problem, and constantly change the way of thinking and the mindset.")

#text("Mathematician Polya believes that “the process of solving a problem is a process of constantly modifying the problem and constantly inducing inspiration.”")

#text("Terry said it well in Masterclass!")

#text("The process of constantly exploring the way to solve problems is mainly characterized by the process of constantly modifying problems and making adjustments: constantly reflecting and negating and negating the negation, constantly changing our way of thinking and thinking methods, changing our way of looking at problems The dimensions of the problem, modifying the appearance of the problem, constantly change our problem-solving operations, and constantly combine reflection and problem-solving strategies to make changes and changes in thinking. Change is movement, we need to be looking for the flaws and breakthroughs of problems in the movement, looking for flaws and breakthroughs in the problem during the change process, looking for inspiration, and looking for means and opportunities to solve problems.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2022")])]

#text("Such continued process of thinking on hard problems may generate methods and theories which are more important than the particular original problem (e.g. Galois theory was motivated by polynomial equations, analytic number theory developed to prove the PNT, and the modularity theorem was proved after Wiles’ proof of FLT)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639900")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("That “Solving Problems with Stories” talk was amazing!")

#text("By solving problems with stories, we activate analogical thinking. By finding a narrative model, we can now transfer properties from one to the other.")

#text("I can relate this to the combinatorial identity problem, which I solved in Olympiad contests!")

#text("Solving problems with story, by looking for the mediation model (narrative model), finding the “same” in different objects, what a clever transformation of the problem by analogy!")

#text("Next, his “recognize the ocean from a drop of water” was really shocking!")

#text("This is the highest level of analogy!")

#text("By finding theconnections between things, we can get through everything!")

#text("The organic connection between the constituent elements of the system, this connection is the “law”.")

#text("By understanding and grasping the laws of the system, human beings can even recognize things that cannot be seen with the eyes or heard with the ears.")

#text("For example, as early as 1916, Einstein predicted the existence of gravitational waves based on general relativity, but it was not until 2015, more than 100 years later, that American researchers detected gravitational waves for the first time.")

#text("Einstein had never been to space and had no advanced cosmic detection tools, but based solely on general relativity, he predicted the existence of gravitational waves in 1916. This is the power of mastering the laws of the system!")

#text("Mathematics in the law, a glimpse, a wider world!")

#text("To innovate, we must make analogies, and analogies must cross borders. To cross borders, we must find differences from commonplace similarities, and find similarities from irrelevant differences.")

#text("Seeing through the essence of various things at a glance, seeing the entire sea from a drop of water, and seeing the entire forest from a single tree, is the highest state of learning. People with this “high realm” can always do everything.")

#text("Terry is like those who have reached the other side, those who have seen the real scenery after overcoming obstacles, those who stand on a high place and “see the mountains and small”!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639901")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("By the way, while he reasoned by analogy, he actually used both deduction and induction. Deductive reasoning is to use the same in different contexts. Inductive reasoning is finding the same in the difference.")

#text("Analogy, deduction, induction, these three means of reasoning combine to make mathematical arguments wonderful!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639902")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("Well said, at end of “Solving problems with story”!")

#text("Mathematics is not black or white, one of the core of mathematical thinking is dialect thinking.")

#text("For example, I can see connections between classes “Finding the problem to solve”“Solving the problem with story”.")

#text("Looking for a problem to solve, using a story to solve the problem is actually a black and white coexistence. One is abstract transformation, the other is concrete narrative.")

#text("Going back and forth with the black and white wasteland is really magical about what it can really do.")

#text("Terry is not like those theoretical people who talk a lot of theories all day long without actually doing them.")

#text("For example, the old saying ‘to look at the problem dialectically’ is more often a mantra. If you just talk but don’t practice, you don’t know how to practice!")

#text("Briefly talk about the difficulty of mathematical problems from the objective and subjective aspects, that is, why they are difficult.")

#text("Objectively, the difficulty of mathematical problems is mainly due to the existence of contradictions. The contradictions here refer to the contradictions in dialectics, not the logical contradictions in logical reasoning.")

#text("Simple questions, smooth sailing, straight from the known conditions to the conclusion.")

#text("We often say that the economic base determines the superstructure, the productive forces determine the production relations, and the structure in biology determines the function. In fact, it can also be understood that the two must be matched and adapted. If they do not adapt to each other, there will be negative obstacles and development issues.")

#text("For difficult problems, there is generally a contradiction between the known conditions and the conclusion, or there is a contradiction between the known conditions. The contradiction is inconsistency, and if it is not suitable, it will cause problems in solving the problem, which makes it difficult to directly obtain the problem from the known conditions to draw conclusions.")

#text("For example, in a geometry problem, some elements (such as some line segments) in the graph are scattered and far apart, so it is difficult to be related or not closely related, and it is difficult to draw conclusions if the relationship is not close, think about separation of hydrogen and oxygen, it is difficult to produce relationship, therefore difficult to produce water by chemical reaction, the same reason, this is the contradiction in the question that makes the question difficult.")

#text("As problem solvers, we need to identify these contradictions, think to resolve contradictions, think to transform contradictions, and think over mountains or other ways to overcome obstacles.")

#text("For geometric problems, we make auxiliary lines or geometric transformations, such as translation (moving position), to gather those geometric elements that are far apart to make the relationship closer, and it is easy to produce conclusions.")

#text("However, in order to identify, resolve, and transform contradictions, we must have a set of mature thinking methodology to guide us to think effectively, find flaws in problems, explore breakthroughs in problem-solving, and brew out ideas for problem-solving. I just mentioned auxiliary lines and geometric transformations, but if you don’t master mathematical thinking methods, it is difficult to quickly make correct auxiliary lines.")

#text("As Terry says: If our teachings in school does not pay attention to the learning and training of mathematical thinking methods, many students will find mathematics difficult to learn, which is subjectively difficult. While some don’t think it’s too difficult, because he has a high level of thought, uses Mathematical thinking methodology to control skills, has a flexible and open-minded dialectical mind, and has rules and regulations.")

#text("Terry is really trying to change the way the masses think about mathematics!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639908")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("These ideas about general mathematical structures and classification of the morphisms (i.e. similarities) among them, are important in category theory, model theory and universal algebra.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cbbb148fbb9bff5519298ad5bd9a83c80cec32c6958d6d13ef43a82a0bce12a-71dd6a9c757926d19ea4d413c50a94b6b43750668e6dc040a2ac1034a0d4da20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yoyontzin")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639916")[#strong[#text("yoyontzin")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("Lecture 7. 7: 58 He said: In tic-tac-toe the strongest opening move is actually to play the centerpiece")#linebreak()#text(" BUT This is not true. It is better to start in a corner.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639917")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("NOT REALLY. a square divided into small cells，no matter how many cells it has，the central one（ or four）always has the highest potential energy，which means，this cell has the highest probability and the number you put in restrain the freedom of others which is so essential that it almost can decide other steps …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cbbb148fbb9bff5519298ad5bd9a83c80cec32c6958d6d13ef43a82a0bce12a-71dd6a9c757926d19ea4d413c50a94b6b43750668e6dc040a2ac1034a0d4da20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yoyontzin")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639943")[#strong[#text("yoyontzin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("well… Not in this case. The best move is to start in a corner.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639919")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("like the contest game，Chinese go （it has 19*19 cells，black and white chess pieces），we often start from the corner to test each other and to extention the battle line…but start from the center is also a fantastic tactics，which is called the COSMIC FLOW…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cbbb148fbb9bff5519298ad5bd9a83c80cec32c6958d6d13ef43a82a0bce12a-71dd6a9c757926d19ea4d413c50a94b6b43750668e6dc040a2ac1034a0d4da20.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yoyontzin")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639944")[#strong[#text("yoyontzin")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("In the case of tic tac toe is much easier to analyze all the consequences of your moves. It is fairly easy to calculate the probability of winning depending on each initial move. And guess what, the initial move with the best probability to win is if you start in the corner.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639950")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("well，I just generalize this kind of game，and try to provide different way of thinking～I think they share the same abstract kenel～")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639951")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("and how to define the word ESSENTIAL，or how to understand the word ESSENTIAL？I think at least we can measure it in two directions：")#linebreak()#text(" 1. based on sequencial- progress-accumulation；")#linebreak()#text(" 2. based on direction-progress-accumulation.")#linebreak()#text(" here，when we discuss the word ESSENTIAL，I think we need to choose to avoid discussing point 1 because we assign different weight to each step factitiously…")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Liewyee")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639922")[#strong[#text("Liewyee")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2022")])]

#text("whether you celebrate it or not，today is Chinese New year，the Spring Festival，have a good day，Tao~")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639925")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("Terry, happy Chinese new year!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639934")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2022")])]

#text("This transformation of thinking is really wonderful!")

#text("Especially the transformation strategy of the opposites.")

#text("For example, the abstract-concrete strategy, when encountering an abstract problem, if it is difficult to solve, then the idea is concrete; when encountering a specific problem, if it is difficult to solve, it is abstract. In a sentence, if the abstract is not enough, it is concrete, and if the concrete is not enough, it is abstract. It is necessary to flexibly and dialectically use abstract and concrete dialectical connection to transform and adapt.")

#text("Direct strategy: Complex-Simple, General-Special, Primary-Secondary, Known-Unknown, Unfamiliar-Familiar, Forward-Reverse, Higher-Lower, Global-Local, Number/Const-Variable.")

#text("There are many other indirect ones, such as internal-external, number-form, which are based on some concepts of unity of opposites and contradictory connections or similar connections in dialectical thinking to adopt flexible strategies.")

#text("The strategy of advancing and retreating from opposite sides should be combined with the contradiction analysis method to find out the harmonious and disharmonious factors existing in the problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639963")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2022")])]

#text("The transformation lesson tells us that thinking needs to be flexible, which is largely inseparable from divergent thinking, dialectical thinking and problem-solving strategies: such as the abstraction principle, use the dialectical relationship between abstraction and concrete to solve problems (abstraction principle: when you feel trapped in When in the quagmire of concreteness, we must abstract the problem, remove the rough, remove the false and preserve the true, filter and strip some non-essential noise and interference factors, obtain the essential abstract problem description and the essential problem model, conduct research on the basis of abstraction, and then put The research results are applied to the original problem; the principle of concretization: when there is no experience in abstract problems and lack of perceptual and rational knowledge, retreat is the way forward, first study the specific and simple simplified situation, and obtain perceptual knowledge, experience, and rational knowledge. Inspiration, law, and some experience or rational knowledge, then return to abstract issues. In general, flexible use of the relationship between abstraction and concreteness is a sentence: if the abstraction is not good, it is concrete, and if the concrete is not good, it is abstract), use general and special dialectical relations to solve problems(consider special cases/generalizations). Problem-solving strategies are not all dialectical thinking. Some problem-solving strategies such as feature-driven thinking, plausible reasoning, plausible assumptions & plausible assumptions & conjectures & imagination, intention-based thinking, etc. But the mathematical thinking is usually combined with dialectical thinking.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639965")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2022")])]

#text("Looking at a problem dialectically is by no means what many people understand. Many people think it is empty talk and slick sophistry.")

#text("But we actually use dialectical relations to help solve problems, such as abstract and concrete, general and special, direct and indirect, combination of numbers and shapes (number and shape), and closure and expansion in the characteristics of figures. Another example is constants/numbers and variables (unknowns). Their boundaries and divisions are not static. When solving problems, sometimes constants/numbers should be regarded as variables, as a specific value of variables, and the variables in the problem as constants, variables and constant roles are transformed into each other. The dialectical relationship between constants and variables also has many specific problem-solving examples to demonstrate, such as the calculation in space that Terry talked about.")

#text("The flexible use of abstraction and concreteness, forward thinking and reverse thinking mentioned earlier all indicate that we should look at problems flexibly and dialectically, and not to rigidify our own viewpoints, perspectives, and thinking. Dialectical thinking guides us to think flexibly, and dialectics is a flexible method of change.")

#text("They can play a tactical and strategic guiding role in problem-solving reflection, problem-solving strategy formulation, and the application of mathematical thinking methods. The core of problem-solving reflection is to summarize and identify the experience and lessons in the process of problem-solving, and dialectical thinking must be required. Problem-solving strategies such as the reverse thinking when straight is difficult, and feature-driven thinking (thinking based on features, carrying out thinking activities such as associative analogies), and direct if not indirect, abstract if not concrete, concrete if not abstract, which one does not reflect dialectical thinking?")

#text("The transformation in mathematical thinking methods, the transformation of complexity into simplicity, and the unfamiliar into familiarity, all embody dialectical thinking. For example, the combination of numbers and shapes is also due to the dialectical relationship between numbers and shapes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-639973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 February 2022")])]

#text("Such thinking methods are useful not only for the solution of problems but also for developement of new theories and simplification of existing theories.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640006")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2022")])]

#text("Tao has been emphasizing the importance of failure to us again and again, I don’t know if anyone has noticed.")

#text("Lao Tzu often uses water as a metaphor for things. Water is the softest thing in this world. Put water in any container, and the water will change with the shape of the container. However, water is the most rigid thing in the world. Once an overwhelming force is formed, water can engulf everything and destroy everything. The hardness and softness of water proves that things in the world have two directions of relative development.")

#text("This interesting phenomenon abounds in life. Observing the streets after it has rained, you will find that only low-lying places can hold water, and raised ground cannot hold water. When people fight, they can only fight more powerfully by sending their fists back. If there is no retraction process, there will be no strong blows. When the worm is moving forward, it can only move forward if it curls up; if it does not curl up, the worm cannot move forward. When a frog jumps, it can only jump high by bending its legs. If there is no process of bending its knees, it cannot jump high. These examples in life show that everything contains two opposite aspects of itself, which is what we call “yin and yang”. Only by fully grasping these two aspects can we better control the development of things.")

#text("In this way, everything has two sides, and even if people need one of them, the opposite side cannot be excluded or ignored. Therefore, we can not only pay attention to the magic of cleverness, and sometimes be confused. In the same way, we can’t just like the smooth sailing and loathe stress and difficulty. Because people often encounter bigger crises hidden when things are going well, and pressure and difficulties can often bring people new challenges, stimulate the potential of the human body, and bring people new breakthroughs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640013")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2022")])]

#text("In other words, a distinguishable object can exist only in inhomogeneous space (because in homogeneous space there are no distinguishable objects or patterns).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/addf0fa52113d2524fa91b62f3fe0f022ebc23c9c4c665e8708122ff2b84743b-9b950fe76b28a36d9cfed528b24347ea208e9165528f2d49bbedc4c4a52ca4cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathedaone")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640007")[#strong[#text("mathedaone")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2022")])]

#text("Terry Tao, do you have a theoretical system for mathematical thinking?")

#text("Anyways, I look forward to following your work.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b3d40e1bf8cbf44df0e0be7cf23579618c0812ea5f79233c0ea0f3864348607c-9e0e71ca8541d33415e99c01837f9e2cb8a0e97d041464280dd2ad72fece7121.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andriy")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640118")[#strong[#text("Andriy")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2022")])]

#text("Good day! I want to introduce you to the number that I invented (K) and I want to ask you to check if it is greater than the Graham number. To do this, we need to introduce the concept of “factorial transition”. A factorial transition is the calculation of a number raised to a factorial, when the result of this calculation needs to be raised to the factorial again. In this case, the factorial transition is equal to one. My number consists of a googolplex raised to a factorial, with a factorial transition equal to the googolplex:")

#text("K=10^10^100!…F…!,")

#text("Were F=10^10^100.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Professor Cosine")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-640631")[#strong[#text("Professor Cosine")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2022")])]

#text("Thank you Andriy. This is very interesting mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/45e64b37470c2f1b3a4b4a69fd3437b3a087ffb6423974c1169ceee55ac72481-d42be15bd53754fcc449f3c9a16d337cd279cfd1559c5295eb1a174b5717dfaa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Russ Lyons")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-641545")[#strong[#text("Russ Lyons")]]#text(size: 9pt, fill: rgb("596477"), " · 16 March 2022")])]

#text("It’s too bad that the site prominently showcases Matthew Walker on sleep, who (apparently) has committed research misconduct: see ")#link("https://statmodeling.stat.columbia.edu/2020/03/24/why-we-sleep-a-tale-of-institutional-failure/")[#text("https://statmodeling.stat.columbia.edu/2020/03/24/why-we-sleep-a-tale-of-institutional-failure/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-657320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2022")])]

#text("All the lectures are on Youtube if one is interested.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-659203")[#strong[#text("IIT Madras Researchers Develop New Approach for accurate detection of Earthquakes - The Free Media")]]#text(size: 9pt, fill: rgb("596477"), " · 18 October 2022")]

#text("[…] the unique aspects of this research, Ms. Kanchan Aggarwal, Ph.D. Scholar, IIT Madras, said, “Information of P-wave arrival is crucial in determining other source parameters of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2add68dec7f00ec44c3f78eb1dfd5f1a59030eb26417155c4fe939cbcbc75dc4-9b0f3b85c5d31d057a2e577da2a3abe2e29e67744bb7aec827739bf39c0ee92a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuval Levental")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-672416")[#strong[#text("Yuval Levental")]]#text(size: 9pt, fill: rgb("596477"), " · 22 January 2023")])]

#text("I watched the masterclass videos on Friday and they already helped me solve a significant problem! Namely, using the part where you combine multiple approaches to solve problems.")

#text("In the fall, I decided to switch from regular floss to a “water flosser” (which cleans teeth with a water stream). This was really fun to use! Today though, a piece of food was stuck in my teeth. I was using the Waterpik to try to get the piece out, with limited success. Then, I used a piece of floss that was next to me. The piece was gone in a second!")

#text("Many studies compare water flossing to regular flossing. But has there ever been a study where someone uses both approaches in tandem? I will start doing that, and my teeth will be extremely clean every day, practically guaranteed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ab1792f47109e3ee6c4f4e9717348629b4a382ca1d296e1227267fafa88a3fad-3671257372a71a95304e254f5c958fc7e689313a023fcfd514f9ed4e186f5383.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hao Sun")]], [#link("https://terrytao.wordpress.com/2022/01/27/masterclass-on-mathematical-thinking/#comment-686992")[#strong[#text("Hao Sun")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2025")])]

#text("Kepler’s Wine Barrel problem is basically whats the largest amount of wine an absurdly generous wine merchant could give you. ")#linebreak()#text("It’s an interesting problem you mention in your masterclass but it’s motivation is rather strange.")
]
