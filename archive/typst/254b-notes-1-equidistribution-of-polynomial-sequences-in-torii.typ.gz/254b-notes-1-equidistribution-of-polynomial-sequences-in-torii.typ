// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/
// Converted to Typst by tao2typ: "2026-10-14T16:36:08.377746+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254B, Notes 1: Equidistribution of polynomial sequences in tori", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254B, Notes 1: Equidistribution of polynomial sequences in tori")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 March 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")[#text("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("(Linear) ")#link("http://en.wikipedia.org/wiki/Fourier_analysis")[#text("Fourier analysis")]#text(" can be viewed as a tool to study an arbitrary function ")#mi("{f}")#text(" on (say) the integers ")#mi("{{\\bf Z}}")#text(", by looking at how such a function correlates with ")#emph[#text("linear phases")]#text(" such as ")#mi("{n \\mapsto e(\\xi n)}")#text(", where ")#mi("{e(x) := e^{2\\pi i x}}")#text(" is the fundamental character, and ")#mi("{\\xi \\in {\\bf R}}")#text(" is a frequency. These correlations control a number of expressions relating to ")#mi("{f}")#text(", such as the expected behaviour of ")#mi("{f}")#text(" on arithmetic progressions ")#mi("{n, n+r, n+2r}")#text(" of length three.")

#text("In this course we will be studying higher-order correlations, such as the correlation of ")#mi("{f}")#text(" with quadratic phases such as ")#mi("{n \\mapsto e(\\xi n^2)}")#text(", as these will control the expected behaviour of ")#mi("{f}")#text(" on more complex patterns, such as arithmetic progressions ")#mi("{n, n+r, n+2r, n+3r}")#text(" of length four. In order to do this, we must first understand the behaviour of ")#link("http://en.wikipedia.org/wiki/Exponential_sum")[#text("exponential sums")]#text(" such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N e( \\alpha n^2 ).")]]

#text("Such sums are closely related to the ")#link("http://en.wikipedia.org/wiki/Equidistribution")[#text("distribution")]#text(" of expressions such as ")#mi("{\\alpha n^2 \\text{ mod } 1}")#text(" in the unit circle ")#mi("{{\\bf T} := {\\bf R}/{\\bf Z}}")#text(", as ")#mi("{n}")#text(" varies from ")#mi("{1}")#text(" to ")#mi("{N}")#text(". More generally, one is interested in the distribution of polynomials ")#mi("{P: {\\bf Z}^d \\rightarrow {\\bf T}}")#text(" of one or more variables taking values in a torus ")#mi("{{\\bf T}}")#text("; for instance, one might be interested in the distribution of the quadruplet ")#mi("{(\\alpha n^2, \\alpha (n+r)^2, \\alpha(n+2r)^2, \\alpha(n+3r)^2)}")#text(" as ")#mi("{n,r}")#text(" both vary from ")#mi("{1}")#text(" to ")#mi("{N}")#text(". Roughly speaking, once we understand these types of distributions, then the general machinery of quadratic Fourier analysis will then allow us to understand the distribution of the quadruplet ")#mi("{(f(n), f(n+r), f(n+2r), f(n+3r))}")#text(" for more general classes of functions ")#mi("{f}")#text("; this can lead for instance to an understanding of the distribution of arithmetic progressions of length ")#mi("{4}")#text(" in the primes, if ")#mi("{f}")#text(" is somehow related to the primes.")

#text("More generally, to find arithmetic progressions such as ")#mi("{n,n+r,n+2r,n+3r}")#text(" in a set ")#mi("{A}")#text(", it would suffice to understand the equidistribution of the quadruplet ")#mi("{(1_A(n), 1_A(n+r), 1_A(n+2r), 1_A(n+3r))}")#text(" in ")#mi("{\\{0,1\\}^4}")#text(" as ")#mi("{n}")#text(" and ")#mi("{r}")#text(" vary. This is the starting point for the fundamental connection between ")#emph[#text("combinatorics")]#text(" (and more specifically, the task of finding patterns inside sets) and ")#emph[#text("dynamics")]#text(" (and more specifically, the theory of equidistribution and recurrence in measure-preserving dynamical systems, which is a subfield of ")#link("http://en.wikipedia.org/wiki/Ergodic_theory")[#text("ergodic theory")]#text("). This connection was explored in one of my previous classes; it will also be important in this course (particularly as a source of motivation), but the primary focus will be on finitary, and Fourier-based, methods.")

#text("The theory of equidistribution of polynomial orbits was developed in the linear case by Dirichlet and Kronecker, and in the polynomial case by Weyl. There are two regimes of interest; the (qualitative) ")#emph[#text("asymptotic regime")]#text(" in which the scale parameter ")#mi("{N}")#text(" is sent to infinity, and the (quantitative) ")#emph[#text("single-scale regime")]#text(" in which ")#mi("{N}")#text(" is kept fixed (but large). Traditionally, it is the asymptotic regime which is studied, which connects the subject to other asymptotic fields of mathematics, such as dynamical systems and ergodic theory. However, for many applications (such as the study of the primes), it is the single-scale regime which is of greater importance. The two regimes are not directly equivalent, but are closely related: the single-scale theory can be usually used to derive analogous results in the asymptotic regime, and conversely the arguments in the asymptotic regime can serve as a simplified model to show the way to proceed in the single-scale regime. The analogy between the two can be made tighter by introducing the (qualitative) ")#emph[#text("ultralimit regime")]#text(", which is formally equivalent to the single-scale regime (except for the fact that explicitly quantitative bounds are abandoned in the ultralimit), but resembles the asymptotic regime quite closely.")

#text("We will view the equidistribution theory of polynomial orbits as a special case of ")#link("http://en.wikipedia.org/wiki/Ratner%27s_theorems")[#text("Ratner’s theorem")]#text(", which we will study in more generality later in this course.")

#text("For the finitary portion of the course, we will be using ")#emph[#text("asymptotic notation")]#text(": ")#mi("{X \\ll Y}")#text(", ")#mi("{Y \\gg X}")#text(", or ")#mi("{X = O(Y)}")#text(" denotes the bound ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some absolute constant ")#mi("{C}")#text(", and if we need ")#mi("{C}")#text(" to depend on additional parameters then we will indicate this by subscripts, e.g. ")#mi("{X \\ll_d Y}")#text(" means that ")#tao-math("{\\left|X\\right| \\leq C_d Y}", block: false)#text(" for some ")#mi("{C_d}")#text(" depending only on ")#mi("{d}")#text(". In the ultralimit theory we will use an analogue of asymptotic notation, which we will review later in these notes.")

#metadata(none) <tao-08d2b6540c1f0259ef6f>

#heading(level: 1)[#strong[#text(" — 1. Asymptotic equidistribution theory — ")]]

#text("Before we look at the single-scale equidistribution theory (both in its finitary form, and its ultralimit form), we will first study the slightly simpler, and much more classical, asymptotic equidistribution theory.")

#text("Suppose we have a sequence of points ")#mi("{x(1), x(2), x(3), \\ldots}")#text(" in a compact metric space ")#mi("{X}")#text(". For any finite ")#mi("{N > 0}")#text(", we can define the probability measure")

#align(center)[#tao-fit-display[#mitex("\\mu_N := {\\bf E}_{n \\in [N]} \\delta_{x(n)}")]]

#text("which is the average of the ")#link("http://en.wikipedia.org/wiki/Dirac_measure")[#text("Dirac point masses")]#text(" on each of the points ")#mi("{x(1),\\ldots,x(N)}")#text(", where we use ")#mi("{{\\bf E}_{n \\in [N]}}")#text(" as shorthand for ")#mi("{\\frac{1}{N} \\sum_{n=1}^N}")#text(" (with ")#mi("{[N] := \\{1,\\ldots,N\\}}")#text("). ")#emph[#text("Asymptotic equidistribution theory")]#text(" is concerned with the limiting behaviour of these probability measures ")#mi("{\\mu_N}")#text(" in the limit ")#mi("{N \\rightarrow \\infty}")#text(", for various sequences ")#mi("{x(1),x(2),\\ldots}")#text(" of interest. In particular, we say that the sequence ")#mi("{x: {\\bf N} \\rightarrow X}")#text(" is ")#emph[#text("asymptotically equidistributed")]#text(" on ")#mi("{{\\bf N}}")#text(" with respect to a reference ")#link("http://en.wikipedia.org/wiki/Borel_measure")[#text("Borel probability measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{X}")#text(" if the ")#mi("{\\mu_N}")#text(" converge in the vague topology to ")#mi("{\\mu}")#text(", or in other words that ")#metadata(none) <tao-248fb276f60f01c8aab4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf E}_{n \\in [N]} f(x(n)) = \\int_X f\\ d\\mu_N \\rightarrow \\int_X f\\ d\\mu")]]



#text(" for all continuous scalar-valued functions ")#mi("{f \\in C(X)}")#text(". Note (from the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(") that any sequence is asymptotically equidistributed with respect to at most one Borel probability measure ")#mi("{\\mu}")#text(".")

#text("It is also useful to have a slightly stronger notion of equidistribution: we say that a sequence ")#mi("{x: {\\bf N} \\rightarrow X}")#text(" is ")#emph[#text("totally asymptotically equidistributed")]#text(" if it is asymptotically equidistributed on every infinite arithmetic progression, i.e. that the sequence ")#mi("{n \\mapsto x(qn+r)}")#text(" is asymptotically equidistributed for all integers ")#mi("{q \\geq 1}")#text(" and ")#mi("{r \\geq 0}")#text(".")

#text("A doubly infinite sequence ")#mi("{(x(n))_{n \\in {\\bf Z}}}")#text(", indexed by the integers rather than the natural numbers, is said to be asymptotically equidistributed relative to ")#mi("{\\mu}")#text(" if both halves of the sequence ")#mi("{x(1), x(2), x(3), \\ldots}")#text(" and ")#mi("{x(-1), x(-2), x(-3), \\ldots}")#text(" are asymptotically equidistributed relative to ")#mi("{\\mu}")#text(". (This omits ")#mi("{x(0)}")#text(" entirely, but it is easy to see that any individual element of the sequence has no impact on the asymptotic equidistribution.) Similarly, one can define the notion of a doubly infinite sequence being totally asymptotically equidistributed relative to ")#mi("{\\mu}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" If ")#mi("{X = \\{0,1\\}}")#text(", and ")#mi("{x(n) := 1}")#text(" whenever ")#mi("{2^{2j} \\leq n < 2^{2j+1}}")#text(" for some natural number ")#mi("{j}")#text(" and ")#mi("{x(n):=0}")#text(" otherwise, show that the sequence ")#mi("{x}")#text(" is not asymptotically equidistributed with respect to any measure. Thus we see that asymptotic equidistribution requires all scales to behave “the same” in the limit.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" If ")#mi("{x: {\\bf N} \\rightarrow X}")#text(" is a sequence into a compact metric space ")#mi("{X}")#text(", and ")#mi("{\\mu}")#text(" is a probability measure on ")#mi("{X}")#text(", show that ")#mi("{x}")#text(" is asymptotically equidistributed with respect to ")#mi("{\\mu}")#text(" if and only if one has")

#align(center)[#tao-fit-display[#tao-math("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\left|\\{ 1 \\leq n \\leq N: x(n) \\in U \\}\\right| = \\mu(U)", block: true)]]

#text("for all open sets ")#mi("{U}")#text(" in ")#mi("{X}")#text(" whose boundary ")#mi("{\\partial U}")#text(" has measure zero. (")#emph[#text("Hint:")]#text(" for the “only if” part, use ")#link("http://en.wikipedia.org/wiki/Urysohn%27s_lemma")[#text("Urysohn’s lemma")]#text(". For the “if” part, reduce ")#link(<tao-248fb276f60f01c8aab4>)[#text("(1)")]#text(" to functions ")#mi("{f}")#text(" taking values between ")#mi("{0}")#text(" and ")#mi("{1}")#text(", and observe that almost all of the level sets ")#mi("{\\{ y \\in X: f(y) < t \\}}")#text(" have a boundary of measure zero.) What happens if the requirement that ")#mi("{\\partial U}")#text(" have measure zero is omitted?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Let ")#mi("{x}")#text(" be a sequence in a compact metric space ")#mi("{X}")#text(" which is equidistributed relative to some probability measure ")#mi("{\\mu}")#text(". Show that for any open set ")#mi("{U}")#text(" in ")#mi("{X}")#text(" with ")#mi("{\\mu(U) > 0}")#text(", the set ")#mi("{\\{ n \\in {\\bf N}: x(n) \\in U \\}}")#text(" is infinite, and furthermore has positive lower density in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\lim \\inf_{N \\rightarrow \\infty} \\frac{1}{N} \\left|\\{ 1 \\leq n \\leq N: x(n) \\in U \\}\\right| > 0.", block: true)]]

#text("In particular, if the support of ")#mi("{\\mu}")#text(" is equal to ")#mi("{X}")#text(", show that the set ")#mi("{\\{ x(n): n \\in {\\bf N}\\}}")#text(" is dense in ")#mi("{X}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" Let ")#mi("{x: {\\bf N} \\rightarrow X}")#text(" be a sequence into a compact metric space ")#mi("{X}")#text(" which is equidistributed relative to some probability measure ")#mi("{\\mu}")#text(". Let ")#mi("{\\varphi: {\\bf R} \\rightarrow {\\bf R}}")#text(" be a compactly supported, piecewise continuous function with only finitely many pieces. Show that for any ")#mi("{f \\in C(X)}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n \\in {\\bf N}} \\varphi(n/N) f(x(n)) = (\\int_X f\\ d\\mu) (\\int_0^\\infty \\varphi(t)\\ dt)")]]

#text("and for any open ")#mi("{U}")#text(" whose boundary has measure zero, one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n \\in {\\bf N}: x(n) \\in U} \\varphi(n/N) = \\mu(U) (\\int_0^\\infty \\varphi(t)\\ dt).")]]
]

#text("In this set of notes, ")#mi("{X}")#text(" will be a torus (i.e. a compact connected abelian Lie group), which from the theory of Lie groups is isomorphic to the standard torus ")#mi("{{\\bf T}^d}")#text(", where ")#mi("{d}")#text(" is the dimension of the torus. This torus is then equipped with ")#link("http://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(", which is the unique Borel probability measure on the torus which is translation-invariant. One can identify the standard torus ")#mi("{{\\bf T}^d}")#text(" with the standard fundamental domain ")#mi("{[0,1)^d}")#text(", in which case the Haar measure is equated with the usual Lebesgue measure. We shall call a sequence ")#mi("{x_1, x_2, \\ldots}")#text(" in ")#mi("{{\\bf T}^d}")#text(" (asymptotically) ")#emph[#text("equidistributed")]#text(" if it is (asymptotically) equidistributed with respect to Haar measure.")

#text("We have a simple criterion for when a sequence is asymptotically equidistributed, that reduces the problem to that of estimating exponential sums:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1 (Weyl equidistribution criterion)")]#text(" ")#metadata(none) <tao-e3d8c301b327d61d49b7>#text(" Let ")#mi("{x: {\\bf N} \\rightarrow {\\bf T}^d}")#text(". Then ")#mi("{x}")#text(" is asymptotically equidistributed if and only if ")#metadata(none) <tao-b3f100f173fd4df6974c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\lim_{N \\rightarrow \\infty} {\\bf E}_{n \\in [N]} e( k \\cdot x(n) ) = 0")]]



#text(" for all ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(", where ")#mi("{e(y) := e^{2\\pi i y}}")#text(". Here we use the dot product")

#align(center)[#tao-fit-display[#mitex("(k_1,\\ldots,k_d) \\cdot (x_1,\\ldots,x_d) := k_1 x_1 + \\ldots + k_d x_d")]]

#text("which maps ")#mi("{{\\bf Z}^d \\times {\\bf T}^d}")#text(" to ")#mi("{{\\bf T}}")#text(".")
]

#emph[#text("Proof:")]#text(" The “only if” part is immediate from ")#link(<tao-248fb276f60f01c8aab4>)[#text("(1)")]#text(". For the “if” part, we see from ")#link(<tao-b3f100f173fd4df6974c>)[#text("(2)")]#text(" that ")#link(<tao-248fb276f60f01c8aab4>)[#text("(1)")]#text(" holds whenever ")#mi("{f}")#text(" is a plane wave ")#mi("{f(y) := e(k \\cdot y)}")#text(" for some ")#mi("{k \\in {\\bf Z}^d}")#text(" (checking the ")#mi("{k=0}")#text(" case separately), and thus by linearity whenever ")#mi("{f}")#text(" is a trigonometric polynomial. But by Fourier analysis (or from the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text("), the trigonometric polynomials are dense in ")#mi("{C({\\bf T}^d)}")#text(" in the uniform topology. The claim now follows from a standard limiting argument. ")#mi("\\Box")

#text("As one consequence of this proposition, one can reduce multidimensional equidistribution to single-dimensional equidistribution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2")]#text(" ")#metadata(none) <tao-08625ba4fdd10aa2b2b0>#text(" Let ")#mi("{x: {\\bf N} \\rightarrow {\\bf T}^d}")#text(". Then ")#mi("{x}")#text(" is asymptotically equidistributed in ")#mi("{{\\bf T}^d}")#text(" if and only if, for each ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(", the sequence ")#mi("{n \\mapsto k \\cdot x(n)}")#text(" is asymptotically equidistributed in ")#mi("{{\\bf T}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Show that a sequence ")#mi("{x:{\\bf N} \\rightarrow {\\bf T}^d}")#text(" is totally asymptotically equidistributed if and only if one has ")#metadata(none) <tao-6647be23d44790070291>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\lim_{N \\rightarrow \\infty} {\\bf E}_{n \\in [N]} e( k \\cdot x(n) ) e( \\alpha n ) = 0")]]



#text(" for all ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(" and all rational ")#mi("{\\alpha}")#text(".")
]

#text("This quickly gives a test for equidistribution for linear sequences, sometimes known as the ")#link("http://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("equidistribution theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-e478be9c3ffbf35539d8>#text(" Let ")#mi("{\\alpha, \\beta \\in {\\bf T}^d}")#text(". By using the geometric series formula, show that the following are equivalent:")

#list(
[#text("The sequence ")#mi("{n \\mapsto n \\alpha + \\beta}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf N}}")#text(".")],
[#text("The sequence ")#mi("{n \\mapsto n \\alpha + \\beta}")#text(" is totally asymptotically equidistributed on ")#mi("{{\\bf N}}")#text(".")],
[#text("The sequence ")#mi("{n \\mapsto n \\alpha + \\beta}")#text(" is totally asymptotically equidistributed on ")#mi("{{\\bf Z}}")#text(".")],
[#mi("{\\alpha}")#text(" is ")#emph[#text("irrational")]#text(", in the sense that ")#mi("{k \\cdot \\alpha \\neq 0}")#text(" for any non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" One can view Exercise ")#link(<tao-e478be9c3ffbf35539d8>)[#text("5")]#text(" as an assertion that a linear sequence ")#mi("{x_n}")#text(" will equidistribute itself unless there is an “obvious” algebraic obstruction to it doing so, such as ")#mi("{k \\cdot x_n}")#text(" being constant for some non-zero ")#mi("{k}")#text(". This theme of algebraic obstructions being the “only” obstructions to uniform distribution will be present throughout the course.")
]

#text("Exercise ")#link(<tao-e478be9c3ffbf35539d8>)[#text("5")]#text(" shows that linear sequences with irrational shift ")#mi("{\\alpha}")#text(" are equidistributed. At the other extreme, if ")#mi("{\\alpha}")#text(" is ")#emph[#text("rational")]#text(" in the sense that ")#mi("{m\\alpha = 0}")#text(" for some positive integer ")#mi("{m}")#text(", then the sequence ")#mi("{n \\mapsto n \\alpha + \\beta}")#text(" is clearly periodic of period ")#mi("{m}")#text(", and definitely not equidistributed.")

#text("In the one-dimensional case ")#mi("{d=1}")#text(", these are the only two possibilities. But in higher dimensions, one can have a mixture of the two extremes, that exhibits irrational behaviour in some directions and periodic behaviour in others. Consider for instance the two-dimensional sequence ")#mi("{n \\mapsto (\\sqrt{2} n, \\frac{1}{2} n) \\text{ mod } {\\bf Z}^2}")#text(". The first coordinate is totally asymptotically equidistributed in ")#mi("{{\\bf T}}")#text(", while the second coordinate is periodic; the shift ")#mi("{(\\sqrt{2}, \\frac{1}{2})}")#text(" is neither irrational nor rational, but is a mixture of both. As such, we see that the two-dimensional sequence is equidistributed with respect to Haar measure on the group ")#mi("{{\\bf T} \\times (\\frac{1}{2}{\\bf Z} / {\\bf Z})}")#text(".")

#text("This phenomenon generalises:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Ratner’s theorem for abelian linear sequences)")]#text(" Let ")#mi("{T}")#text(" be a torus, and let ")#mi("{x(n) := n\\alpha + \\beta}")#text(" for some ")#mi("{\\alpha, \\beta \\in T}")#text(". Then there exists a decomposition ")#mi("{x = x^{\\prime} + x^{\\prime\\prime}}")#text(", where ")#mi("{x^{\\prime}(n) := n \\alpha^{\\prime}}")#text(" is totally asymptotically equidistributed on ")#mi("{{\\bf Z}}")#text(" in a subtorus ")#mi("{T^{\\prime}}")#text(" of ")#mi("{T}")#text(" (with ")#mi("{\\alpha^{\\prime} \\in T^{\\prime}}")#text(", of course), and ")#mi("{x^{\\prime\\prime}(n) = n \\alpha^{\\prime\\prime} + \\beta}")#text(" is periodic (or equivalently, that ")#mi("{\\alpha^{\\prime\\prime} \\in T}")#text(" is rational).")
]

#emph[#text("Proof:")]#text(" We induct on the dimension ")#mi("{d}")#text(" of the torus ")#mi("{T}")#text(". The claim is vacuous for ")#mi("{d=0}")#text(", so suppose that ")#mi("{d \\geq 1}")#text(" and that the claim has already been proven for tori of smaller dimension. Without loss of generality we may identify ")#mi("{T}")#text(" with ")#mi("{{\\bf T}^d}")#text(".")

#text("If ")#mi("{\\alpha}")#text(" is irrational, then we are done by Exercise ")#link(<tao-e478be9c3ffbf35539d8>)[#text("5")]#text(", so we may assume that ")#mi("{\\alpha}")#text(" is not irrational; thus ")#mi("{k \\cdot \\alpha = 0}")#text(" for some non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(". We then write ")#mi("{k = m k^{\\prime}}")#text(", where ")#mi("{m}")#text(" is a positive integer and ")#mi("{k^{\\prime} \\in {\\bf Z}^d}")#text(" is ")#emph[#text("irreducible")]#text(" (i.e. ")#mi("{k^{\\prime}}")#text(" is not a proper multiple of any other element of ")#mi("{{\\bf Z}^d}")#text("); thus ")#mi("{k^{\\prime} \\cdot \\alpha}")#text(" is rational. We may thus write ")#mi("{\\alpha = \\alpha_1 + \\alpha_2}")#text(", where ")#mi("{\\alpha_2}")#text(" is rational, and ")#mi("{k^{\\prime} \\cdot \\alpha_1 = 0}")#text(". Thus, we can split ")#mi("{x = x_{1} + x_{2}}")#text(", where ")#mi("{x_{1}(n) := n \\alpha_1}")#text(" and ")#mi("{x_{2}(n) := n \\alpha_2 + \\beta}")#text(". Clearly ")#mi("{x_{2}}")#text(" is periodic, while ")#mi("{x_{1}}")#text(" takes values in the subtorus ")#mi("{T_1 := \\{ y \\in T: k^{\\prime} \\cdot y = 0 \\}}")#text(" of ")#mi("{T}")#text(". The claim now follows by applying the induction hypothesis to ")#mi("{T_1}")#text(" (and noting that the sum of two periodic sequences is again periodic). ")#mi("\\Box")

#text("As a corollary of the above proposition, we see that any linear sequence ")#mi("{n \\mapsto n\\alpha + \\beta}")#text(" in a torus ")#mi("{T}")#text(" is equidistributed in some union of finite cosets of a subtorus ")#mi("{T^{\\prime}}")#text(". It is easy to see that this torus ")#mi("{T}")#text(" is uniquely determined by ")#mi("{\\alpha}")#text(", although there is a slight ambiguity in the decomposition ")#mi("{x=x^{\\prime}+x^{\\prime\\prime}}")#text(" because one can add or subtract a periodic linear sequence taking values in ")#mi("{T}")#text(" from ")#mi("{x^{\\prime}}")#text(" and add it to ")#mi("{x^{\\prime\\prime}}")#text(" (or vice versa).")

#text("Having discussed the linear case, we now consider the more general situation of ")#emph[#text("polynomial")]#text(" sequences in tori. To get from the linear case to the polynomial case, the fundamental tool is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4 (van der Corput inequality)")]#text(" ")#metadata(none) <tao-e54a5df6ff5bc3208e2c>#text(" Let ")#mi("{a_1,a_2,\\ldots}")#text(" be a sequence of complex numbers of magnitude at most ")#mi("{1}")#text(". Then for every ")#mi("{1 \\leq H \\leq N}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} a_n\\right| \\ll ({\\bf E}_{h \\in [H]} \\left|{\\bf E}_{n \\in [N]} a_{n+h} \\overline{a_n}\\right|)^{1/2} + \\frac{1}{H^{1/2}} + \\frac{H^{1/2}}{N^{1/2}}.", block: true)]]
]

#emph[#text("Proof:")]#text(" For each ")#mi("{h \\in [H]}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\in [N]} a_n = {\\bf E}_{n \\in [N]} a_{n+h} + O( H/N )")]]

#text("and hence on averaging")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\in [N]} a_n = {\\bf E}_{n \\in [N]} {\\bf E}_{h \\in [H]} a_{n+h} + O( H/N ).")]]

#text("Applying Cauchy-Schwarz, we conclude")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}_{n \\in [N]} a_n \\ll ({\\bf E}_{n \\in [N]} \\left|{\\bf E}_{h \\in [H]} a_{n+h}\\right|^2)^{1/2} + H/N .", block: true)]]

#text("We expand out the left-hand side as")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\in [N]} a_n \\ll ({\\bf E}_{h, h^{\\prime} \\in [H]} {\\bf E}_{n \\in [N]} a_{n+h} \\overline{a_{n+h^{\\prime}}})^{1/2} + H/N .")]]

#text("The diagonal contribution ")#mi("{h=h^{\\prime}}")#text(" is ")#mi("{O(1/H)}")#text(". By symmetry, the off-diagonal contribution can be dominated by the contribution when ")#mi("{h > h^{\\prime}}")#text(". Making the change of variables ")#mi("{n \\mapsto n-h^{\\prime}}")#text(", ")#mi("{h \\mapsto h+h^{\\prime}}")#text(" (accepting a further error of ")#mi("{O(H^{1/2}/N^{1/2})}")#text("), we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5 (van der Corput lemma)")]#text(" ")#metadata(none) <tao-e61228236bddb7297fa4>#text(" Let ")#mi("{x: {\\bf N} \\rightarrow {\\bf T}^d}")#text(" be such that the derivative sequence ")#mi("{\\partial_h x: n \\mapsto x(n+h)-x(n)}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf N}}")#text(" for all positive integers ")#mi("{h}")#text(". Then ")#mi("{x_n}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf N}}")#text(". Similarly with ")#mi("{{\\bf N}}")#text(" replaced by ")#mi("{{\\bf Z}}")#text(".")
]

#emph[#text("Proof:")]#text(" We just prove the claim for ")#mi("{{\\bf N}}")#text(", as the claim for ")#mi("{{\\bf Z}}")#text(" is analogous (and can in any case be deduced from the ")#mi("{{\\bf N}}")#text(" case.)")

#text("By Proposition ")#link(<tao-e3d8c301b327d61d49b7>)[#text("1")]#text(", we need to show that for each non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(", the exponential sum")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} e( k \\cdot x(n) )\\right|", block: true)]]

#text("goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(". Fix an ")#mi("{H > 0}")#text(". By Lemma ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("4")]#text(", this expression is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\ll ({\\bf E}_{h \\in [H]} \\left|{\\bf E}_{n \\in [N]} e( k \\cdot (x(n+h)-x(n)) )\\right| )^{1/2} + \\frac{1}{H^{1/2}} + \\frac{H^{1/2}}{N^{1/2}}.", block: true)]]

#text("On the other hand, for each fixed positive integer ")#mi("{h}")#text(", we have from hypothesis and Proposition ")#link(<tao-e3d8c301b327d61d49b7>)[#text("1")]#text(" that ")#tao-math("{\\left|{\\bf E}_{n \\in [N]} e( k \\cdot (x(n+h)-x(n)) )\\right|}", block: false)#text(" goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(". Taking limit superior as ")#mi("{N \\rightarrow \\infty}")#text(", we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{N \\rightarrow \\infty} \\left|{\\bf E}_{n \\in [N]} e( k \\cdot x(n) )\\right| \\ll \\frac{1}{H^{1/2}}.", block: true)]]

#text("Since ")#mi("{H}")#text(" is arbitrary, the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" There is ")#link("http://en.wikipedia.org/wiki/Van_der_Corput_lemma_(harmonic_analysis)")[#text("another famous lemma by van der Corput")]#text(" concerning oscillatory integrals, but it is not directly related to the material discussed here.")
]

#text("Corollary ")#link(<tao-e61228236bddb7297fa4>)[#text("5")]#text(" has the following immediate corollary:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6 (Weyl equidistribution theorem for polynomials)")]#text(" Let ")#mi("{s \\geq 1}")#text(" be an integer, and let ")#mi("{P(n) = \\alpha_s n^s + \\ldots + \\alpha_0}")#text(" be a polynomial of degree ")#mi("{s}")#text(" with ")#mi("{\\alpha_0,\\ldots,\\alpha_s \\in {\\bf T}^d}")#text(". If ")#mi("{\\alpha_s}")#text(" is irrational, then ")#mi("{n \\mapsto P(n)}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf Z}}")#text(".")
]

#emph[#text("Proof:")]#text(" We induct on ")#mi("{s}")#text(". For ")#mi("{s=1}")#text(" this follows from Exercise ")#link(<tao-e478be9c3ffbf35539d8>)[#text("5")]#text(". Now suppose that ")#mi("{s > 1}")#text(", and that the claim has already been proven for smaller values of ")#mi("{s}")#text(". For any positive integer ")#mi("{h}")#text(", we observe that ")#mi("{P(n+h)-P(n)}")#text(" is a polynomial of degree ")#mi("{s-1}")#text(" in ")#mi("{n}")#text(" with leading coefficient ")#mi("{sh\\alpha_s n^{s-1}}")#text(". As ")#mi("{\\alpha_s}")#text(" is irrational, ")#mi("{sh\\alpha_s}")#text(" is irrational also, and so by the induction hypothesis, ")#mi("{P(n+h)-P(n)}")#text(" is asymptotically equidistributed. The claim now follows from Corollary ")#link(<tao-e61228236bddb7297fa4>)[#text("5")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Let ")#mi("{P(n) = \\alpha_s n^s + \\ldots + \\alpha_0}")#text(" be a polynomial of degree ")#mi("{s}")#text(" in ")#mi("{{\\bf T}^d}")#text(". Show that the following are equivalent:")

#list(
[#mi("{P}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf N}}")#text(".")],
[#mi("{P}")#text(" is totally asymptotically equidistributed on ")#mi("{{\\bf N}}")#text(".")],
[#mi("{P}")#text(" is totally asymptotically equidistributed on ")#mi("{{\\bf Z}}")#text(".")],
[#text("There does not exist a non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(" such that ")#mi("{k \\cdot \\alpha_1 = \\ldots = k \\cdot \\alpha_s = 0}")#text(".")]
)

#text("(")#emph[#text("Hint:")]#text(" it is convenient to first use Corollary ")#link(<tao-08625ba4fdd10aa2b2b0>)[#text("2")]#text(" to reduce to the one-dimensional case.)")
]

#text("This gives a polynomial variant of Ratner’s theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7 (Ratner’s theorem for abelian polynomial sequences)")]#text(" ")#metadata(none) <tao-ed08ac43f2dd77336aa3>#text(" Let ")#mi("{T}")#text(" be a torus, and let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{T}")#text(" of some degree ")#mi("{s \\geq 0}")#text(". Show that there exists a decomposition ")#mi("{P = P^{\\prime} + P^{\\prime\\prime}}")#text(", where ")#mi("{P^{\\prime}, P^{\\prime\\prime}}")#text(" are polynomials of degree ")#mi("{s}")#text(", ")#mi("{P^{\\prime}}")#text(" is totally asymptotically equidistributed in a subtorus ")#mi("{T^{\\prime}}")#text(" of ")#mi("{T}")#text(" on ")#mi("{{\\bf Z}}")#text(", and ")#mi("{P^{\\prime\\prime}}")#text(" is periodic (or equivalently, that all non-constant coefficients of ")#mi("{P^{\\prime\\prime}}")#text(" are rational).")
]

#text("In particular, we see that polynomial sequences in a torus are equidistributed with respect to a finite combination of Haar measures of cosets of a subtorus. Note that this finite combination can have multiplicity; for instance, when considering the polynomial map ")#mi("{n \\mapsto (\\sqrt{2} n, \\frac{1}{3} n^2) \\text{ mod } {\\bf Z}^2}")#text(", it is not hard to see that this map is equidistributed with respect to ")#mi("{1/3}")#text(" times the Haar probability measure on ")#mi("{({\\bf T}) \\times \\{ 0 \\text{ mod } {\\bf Z} \\}}")#text(", plus ")#mi("{2/3}")#text(" times the Haar probability measure on ")#mi("{({\\bf T}) \\times \\{ \\frac{1}{3} \\text{ mod } {\\bf Z} \\}}")#text(".")

#text("Exercise ")#link(<tao-ed08ac43f2dd77336aa3>)[#text("7")]#text(" gives a satisfactory description of the asymptotic equidistribution of arbitrary polynomial sequences in tori. We give just one example of how such a description can be useful:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Recurrence)")]#text(" ")#metadata(none) <tao-92401b7494e24105a024>#text(" Let ")#mi("{T}")#text(" be a torus, let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{T}")#text(", and let ")#mi("{n_0}")#text(" be an integer. Show that there exists a sequence ")#mi("{n_j}")#text(" of positive integers going to infinity such that ")#mi("{P(n_j) \\rightarrow P(n_0)}")#text(".")
]

#text("We discussed recurrence for one-dimensional sequences ")#mi("{x: n \\mapsto x(n)}")#text(". It is also of interest to establish an analogous theory for multi-dimensional sequences, as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 7")]#text(" A multidimensional sequence ")#mi("{x: {\\bf Z}^m \\rightarrow X}")#text(" is ")#emph[#text("asymptotically equidistributed")]#text(" relative to a probability measure ")#mi("{\\mu}")#text(" if, for every continuous, compactly supported function ")#mi("{\\varphi: {\\bf R}^m \\rightarrow {\\bf R}}")#text(" and every function ")#mi("{f \\in C(X)}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{N^m} \\sum_{n \\in {\\bf Z}^m} \\varphi(n/N) f( x(n) ) \\rightarrow (\\int_{{\\bf R}^m} \\varphi) (\\int_X f\\ d\\mu)")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(". The sequence is ")#emph[#text("totally asymptotically equidistributed")]#text(" relative to ")#mi("{\\mu}")#text(" if the sequence ")#mi("{n \\mapsto x(qn+r)}")#text(" is asymptotically equidistributed relative to ")#mi("{\\mu}")#text(" for all positive integers ")#mi("{q}")#text(" and all ")#mi("{r \\in {\\bf Z}^m}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that this definition of equidistribution on ")#mi("{{\\bf Z}^m}")#text(" coincides with the preceding definition of equidistribution on ")#mi("{{\\bf Z}}")#text(" in the one-dimensional case ")#mi("{m=1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Multidimensional Weyl criterion)")]#text(" Let ")#mi("{x: {\\bf Z}^m \\rightarrow {\\bf T}^d}")#text(" be a multidimensional sequence. Show that ")#mi("{x}")#text(" is asymptotically equidistributed if and only if ")#metadata(none) <tao-b4999e119b711ba74f4d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N^m} \\sum_{n \\in {\\bf Z}^m: n/N \\in B} e( k \\cdot x(n) ) = 0")]]



#text(" for all ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(" and all rectangular boxes ")#mi("{B}")#text(" in ")#mi("{{\\bf R}^m}")#text(". Then show that ")#mi("{x}")#text(" is totally asymptotically equidistributed if and only if ")#metadata(none) <tao-a3c149c25dc09872bd0c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N^m} \\sum_{n \\in {\\bf Z}^m: n/N \\in B} e( k \\cdot x(n) ) e( \\alpha \\cdot n ) = 0")]]



#text(" for all ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(", all rectangular boxes ")#mi("{B}")#text(" in ")#mi("{{\\bf R}^m}")#text(", and all rational ")#mi("{\\alpha \\in {\\bf Q}^m}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" ")#metadata(none) <tao-e538db9cbb6c1245e25a>#text(" Let ")#mi("{\\alpha_1,\\ldots,\\alpha_m, \\beta \\in {\\bf T}^d}")#text(", and let ")#mi("{x: {\\bf Z}^m \\rightarrow {\\bf T}^d}")#text(" be the linear sequence ")#mi("{x(n_1,\\ldots,n_m) := n_1 \\alpha_1 + \\ldots + n_m \\alpha_m + \\beta}")#text(". Show that the following are equivalent:")

#list(
[#text("The sequence ")#mi("{x}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf Z}^m}")#text(".")],
[#text("The sequence ")#mi("{x}")#text(" is totally asymptotically equidistributed on ")#mi("{{\\bf Z}^m}")#text(".")],
[#text("We have ")#mi("{(k \\cdot \\alpha_1,\\ldots,k \\cdot \\alpha_m) \\neq 0}")#text(" for any non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12 (Multidimensional van der Corput lemma)")]#text(" ")#metadata(none) <tao-70a1176fa12427c3d929>#text(" Let ")#mi("{x: {\\bf Z}^m \\rightarrow {\\bf T}^d}")#text(" be such that the sequence ")#mi("{\\partial_h x: n \\mapsto x(n+h)-x(n)}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf Z}^m}")#text(" for all ")#mi("{h}")#text(" outside of a hyperplane in ")#mi("{{\\bf R}^m}")#text(". Show that ")#mi("{x}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf Z}^m}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" Let")

#align(center)[#tao-fit-display[#mitex("P(n_1,\\ldots,n_m) := \\sum_{i_1,\\ldots,i_m \\geq 0: i_1+\\ldots+i_m \\leq s} \\alpha_{i_1,\\ldots,i_m} n_1^{i_1} \\ldots n_m^{i_m}")]]

#text("be a polynomial map from ")#mi("{{\\bf Z}^m}")#text(" to ")#mi("{{\\bf T}^d}")#text(" of degree ")#mi("{s}")#text(", where ")#mi("{\\alpha_{i_1,\\ldots,i_m} \\in {\\bf T}^d}")#text(" are coefficients. Show that the following are equivalent:")

#list(
[#mi("{P}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf Z}^m}")#text(".")],
[#mi("{P}")#text(" is totally asymptotically equidistributed on ")#mi("{{\\bf Z}^m}")#text(".")],
[#text("There does not exist a non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(" such that ")#mi("{k \\cdot \\alpha_{i_1,\\ldots,i_m} = 0}")#text(" for all ")#mi("{(i_1,\\ldots,i_m) \\neq 0}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Ratner’s theorem for abelian multidimensional polynomial sequences)")]#text(" ")#metadata(none) <tao-e8aed3f3e7ce15a3bc81>#text(" Let ")#mi("{T}")#text(" be a torus, and let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{{\\bf Z}^m}")#text(" to ")#mi("{T}")#text(" of some degree ")#mi("{s \\geq 0}")#text(". Show that there exists a decomposition ")#mi("{P = P^{\\prime} + P^{\\prime\\prime}}")#text(", where ")#mi("{P^{\\prime}, P^{\\prime\\prime}}")#text(" are polynomials of degree ")#mi("{s}")#text(", ")#mi("{P^{\\prime}}")#text(" is totally asymptotically equidistributed in a subtorus ")#mi("{T^{\\prime}}")#text(" of ")#mi("{T}")#text(" on ")#mi("{{\\bf Z}^m}")#text(", and ")#mi("{P^{\\prime\\prime}}")#text(" is periodic with respect to some finite index sublattice of ")#mi("{{\\bf Z}^m}")#text(" (or equivalently, that all non-constant coefficients of ")#mi("{P^{\\prime\\prime}}")#text(" are rational).")
]

#text("We give just one application of this multidimensional theory, that gives a hint as to why the theory of equidistribution of polynomials may be relevant:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Szemerédi’s theorem for polynomial Bohr sets)")]#text(" ")#metadata(none) <tao-4db4767b4c282c8e22c5>#text(" Let ")#mi("{T}")#text(" be a torus, let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{T}")#text(", and let ")#mi("{U}")#text(" be an open ball of ")#mi("{T}")#text(". Let ")#mi("{A \\subset {\\bf Z}}")#text(" be the set ")#mi("{\\{ n \\in{\\bf Z}: P(n) \\in U \\}}")#text(". Show that if the set ")#mi("{A}")#text(" has positive upper density in the sense that ")#tao-math("{\\limsup_{N \\rightarrow \\infty} \\frac{\\left|A \\cap [-N,N]\\right|}{2N+1} > 0}", block: false)#text(", then ")#mi("{A}")#text(" contains arbitrarily long arithmetic progressions. (")#emph[#text("Hint:")]#text(" consider the polynomial map from ")#mi("{{\\bf Z}^2}")#text(" to ")#mi("{T^k}")#text(" that maps ")#mi("{(a,r)}")#text(" to ")#mi("{(P(a),\\ldots,P(a+(k-1)r))}")#text(". One can also use the one-dimensional theory by freezing ")#mi("{a}")#text(" and only looking at the equidistribution in ")#mi("{r}")#text(".)")
]

#heading(level: 1)[#strong[#text(" — 2. Single-scale equidistribution theory — ")]]

#text("We now turn from the asymptotic equidistribution theory to the equidistribution theory at a single scale ")#mi("{N}")#text(". Thus, instead of analysing the qualitative distribution of infinite sequence ")#mi("{x: {\\bf N} \\rightarrow X}")#text(", we consider instead the quantitative distribution of a finite sequence ")#mi("{x: [N] \\rightarrow X}")#text(", where ")#mi("{N}")#text(" is a (large) natural number and ")#mi("{[N] := \\{1,\\ldots,N\\}}")#text(". To make everything quantitative, we will replace the notion of a continuous function by that of a ")#link("http://en.wikipedia.org/wiki/Lipschitz_continuity")[#text("Lipschitz function")]#text(". Recall that the (inhomogeneous) Lipschitz norm ")#tao-math("{\\left\\|f\\right\\|_{Lip}}", block: false)#text(" of a function ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" on a metric space ")#mi("{X = (X,d)}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{Lip} := \\sup_{x \\in X} \\left|f(x)\\right| + \\sup_{x,y \\in X: x \\neq y} \\frac{\\left|f(x)-f(y)\\right|}{d(x,y)}.", block: true)]]

#text("We also define the homogeneous Lipschitz seminorm")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{\\dot{Lip}} := \\sup_{x,y \\in X: x \\neq y} \\frac{\\left|f(x)-f(y)\\right|}{d(x,y)}.", block: true)]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 8")]#text(" Let ")#mi("{X = (X,d)}")#text(" be a compact metric space, let ")#mi("{\\delta > 0}")#text(", let ")#mi("{\\mu}")#text(" be a probability measure on ")#mi("{X}")#text(". A finite sequence ")#mi("{x: [N] \\rightarrow X}")#text(" is said to be ")#emph[#mi("{\\delta}")#text("-equidistributed")]#text(" relative to ")#mi("{\\mu}")#text(" if one has ")#metadata(none) <tao-25352d33fff0003db2f3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|{\\bf E}_{n \\in [N]} f(x(n)) - \\int_X f\\ d\\mu\\right| \\leq \\delta \\left\\|f\\right\\|_{Lip}", block: true)]]



#text(" for all Lipschitz functions ")#mi("{f: X \\rightarrow {\\bf R}}")#text(".")

#text("We say that the sequence ")#mi("{x_1,\\ldots,x_N \\in X}")#text(" is ")#emph[#text("totally ")#mi("{\\delta}")#text("-equidistributed")]#text(" relative to ")#mi("{\\mu}")#text(" if one has")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in P} f(x(n)) - \\int_X f\\ d\\mu\\right| \\leq \\delta \\left\\|f\\right\\|_{Lip}", block: true)]]

#text("for all Lipschitz functions ")#mi("{f: X \\rightarrow {\\bf R}}")#text(" and all arithmetic progressions ")#mi("{P}")#text(" in ")#mi("{[N]}")#text(" of length at least ")#mi("{\\delta N}")#text(".")
]

#text("In these notes, we will only apply this concept to the torus ")#mi("{{\\bf T}^d}")#text(" with the Haar measure ")#mi("{\\mu}")#text(" and the metric inherited from the Euclidean metric. However, in subsequent notes we will also consider equidistribution in other spaces, most notably on ")#link("http://en.wikipedia.org/wiki/Nilmanifold")[#text("nilmanifolds")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{x(1), x(2), x(3), \\ldots}")#text(" be a sequence in a metric space ")#mi("{X = (X,d)}")#text(", and let ")#mi("{\\mu}")#text(" be a probability measure on ")#mi("{X}")#text(". Show that the sequence ")#mi("{x(1), x(2), \\ldots}")#text(" is asymptotically equidistributed relative to ")#mi("{\\mu}")#text(" if and only if, for every ")#mi("{\\delta > 0}")#text(", ")#mi("{x(1),\\ldots,x(N)}")#text(" is ")#mi("{\\delta}")#text("-equidistributed relative to ")#mi("{\\mu}")#text(" whenever ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta}")#text(", or equivalently if ")#mi("{x(1),\\ldots,x(N)}")#text(" is ")#mi("{\\delta(N)}")#text("-equidistributed relative to ")#mi("{\\mu}")#text(" for all ")#mi("{N>0}")#text(", where ")#mi("{\\delta(N) \\rightarrow 0}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(". (")#emph[#text("Hint:")]#text(" You will need the ")#link("http://en.wikipedia.org/wiki/Arzel%C3%A0%E2%80%93Ascoli_theorem")[#text("Arzelá-Ascoli theorem")]#text(".)")

#text("Similarly, show that ")#mi("{x(1), x(2), \\ldots}")#text(" is totally asymptotically equidistributed relative to ")#mi("{\\mu}")#text(" if and only if, for every ")#mi("{\\delta > 0}")#text(", ")#mi("{x(1),\\ldots,x(N)}")#text(" is totally ")#mi("{\\delta}")#text("-equidistributed relative to ")#mi("{\\mu}")#text(" whenever ")#mi("{N}")#text(" is sufficiently large depending on ")#mi("{\\delta}")#text(", or equivalently if ")#mi("{x(1),\\ldots,x(N)}")#text(" is totally ")#mi("{\\delta(N)}")#text("-equidistributed relative to ")#mi("{\\mu}")#text(" for all ")#mi("{N>0}")#text(", where ")#mi("{\\delta(N) \\rightarrow 0}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" More succinctly, (total) asymptotic equidistribution of ")#mi("{x(1), x(2), \\ldots}")#text(" is equivalent to (total) ")#mi("{o_{N \\rightarrow \\infty}(1)}")#text("-equidistribution of ")#mi("{x(1),\\ldots,x(N)}")#text(" as ")#mi("{N \\rightarrow \\infty}")#text(", where ")#mi("{o_{n \\rightarrow \\infty}(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(". (Thus we see that asymptotic notation such as ")#mi("{o_{n \\rightarrow \\infty}(1)}")#text(" can efficiently conceal a surprisingly large number of quantifiers.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{N_0}")#text(" be a large integer, and let ")#mi("{x(n) := n/N_0 \\text{ mod } 1}")#text(" be a sequence in the standard torus ")#mi("{{\\bf T} = {\\bf R}/{\\bf Z}}")#text(" with Haar measure. Show that whenever ")#mi("{N}")#text(" is a positive multiple of ")#mi("{N_0}")#text(", then the sequence ")#mi("{x(1),\\ldots,x(N)}")#text(" is ")#mi("{O(1/N_0)}")#text("-equidistributed. What happens if ")#mi("{N}")#text(" is not a multiple of ")#mi("{N_0}")#text("?")

#text("If furthermore ")#mi("{N \\geq N_0^2}")#text(", show that ")#mi("{x(1),\\ldots,x(N)}")#text(" is ")#mi("{O(1/\\sqrt{N})}")#text("-equidistributed. Why is a condition such as ")#mi("{N \\geq N_0^2}")#text(" necessary?")
]

#text("Note that the above exercise does not specify the exact relationship between ")#mi("{\\delta}")#text(" and ")#mi("{N}")#text(" when one is given an asymptotically equidistributed sequence ")#mi("{x(1), x(2), \\ldots}")#text("; this relationship is the additional piece of information provided by single-scale equidistribution that is not present in asymptotic equidistribution.")

#text("It turns out that much of the asymptotic equidistribution theory has a counterpart for single-scale equidistribution. We begin with the Weyl criterion.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9 (Single-scale Weyl equidistribution criterion)")]#text(" ")#metadata(none) <tao-f93cf797671e2fd02d3a>#text(" Let ")#mi("{x_1,x_2,\\ldots,x_N}")#text(" be a sequence in ")#mi("{{\\bf T}^d}")#text(", and let ")#mi("{0 < \\delta < 1}")#text(".")

#list(
[#text("If ")#mi("{x_1,\\ldots,x_N}")#text(" is ")#mi("{\\delta}")#text("-equidistributed, and ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(" has magnitude ")#tao-math("{\\left|k\\right| \\leq \\delta^{-c}}", block: false)#text(", then one has")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} e( k \\cdot x_n )\\right| \\ll_d \\delta^c", block: true)]]

#text("if ")#mi("{c > 0}")#text(" is a small enough absolute constant.")],
[#text("Conversely, if ")#mi("{x_1,\\ldots,x_N}")#text(" is ")#emph[#text("not")]#text(" ")#mi("{\\delta}")#text("-equidistributed, then there exists ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(" with magnitude ")#tao-math("{\\left|k\\right| \\ll_d \\delta^{-C_d}}", block: false)#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} e( k \\cdot x_n )\\right| \\gg_d \\delta^{C_d}", block: true)]]

#text("for some ")#mi("{C_d}")#text(" depending on ")#mi("{d}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" The first claim is immediate as the function ")#mi("{x \\mapsto e(k \\cdot x)}")#text(" has mean zero and Lipschitz constant ")#tao-math("{O_d(\\left|k\\right|)}", block: false)#text(", so we turn to the second claim. By hypothesis, ")#link(<tao-25352d33fff0003db2f3>)[#text("(6)")]#text(" fails for some Lipschitz ")#mi("{f}")#text(". We may subtract off the mean and assume that ")#mi("{\\int_{{\\bf T}^d} f = 0}")#text("; we can then normalise the Lipschitz norm to be one; thus we now have")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} f(x_n)\\right| > \\delta.", block: true)]]

#text("We introduce a summation parameter ")#mi("{R \\in {\\bf N}}")#text(", and consider the ")#link("http://en.wikipedia.org/wiki/Fej%C3%A9r_kernel")[#text("Fejér partial Fourier series")]

#align(center)[#tao-fit-display[#mitex("F_R f(x) := \\sum_{k \\in {\\bf Z}^d} m_R(k) \\hat f(k) e(k \\cdot x)")]]

#text("where ")#mi("{\\hat f(k)}")#text(" are the Fourier coefficients")

#align(center)[#tao-fit-display[#mitex("\\hat f(k) := \\int_{{\\bf T}^d} f(x) e(-k \\cdot x)\\ dx")]]

#text("and ")#mi("{m_R}")#text(" is the Fourier multiplier")

#align(center)[#tao-fit-display[#tao-math("m_R(k_1,\\ldots,k_d) := \\prod_{j=1}^d (1-\\frac{\\left|k_j\\right|}{R})_+.", block: true)]]

#text("Standard Fourier analysis shows that we have the convolution representation")

#align(center)[#tao-fit-display[#mitex("F_R f(x) = \\int_{{\\bf T}^d} f(y) K_R(x-y)")]]

#text("where ")#mi("{K_R}")#text(" is the Fejér kernel")

#align(center)[#tao-fit-display[#mitex("K_R(x_1,\\ldots,x_d) := \\prod_{j=1}^d \\frac{1}{R} ( \\frac{\\sin( \\pi Rx_j )}{\\sin( \\pi x_j )})^2.")]]

#text("Using the kernel bounds")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf T}^d} K_R = 1")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|K_R(x)\\right| \\ll_d \\prod_{j=1}^d R(1+R \\left\\|x_j\\right\\|_{{\\bf T}})^{-2},", block: true)]]

#text("where ")#tao-math("{\\left\\|x\\right\\|_{{\\bf T}}}", block: false)#text(" is the distance from ")#mi("{x}")#text(" to the nearest integer, and the Lipschitz nature of ")#mi("{f}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("F_R f (x) = f(x) + O_d( 1/R ).")]]

#text("Thus, if we choose ")#mi("{R}")#text(" to be a sufficiently small multiple of ")#mi("{1/\\delta}")#text(" (depending on ")#mi("{d}")#text("), one has")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} F_R f(x_n)\\right| \\gg \\delta", block: true)]]

#text("and thus by the pigeonhole principle (and the trivial bound ")#mi("{\\hat f(k) = O(1)}")#text(" and ")#mi("{\\hat f(0)=0}")#text(") we have")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} e( k \\cdot x_n )\\right| \\gg_d \\delta^{O_d(1)}", block: true)]]

#text("for some non-zero ")#mi("{k}")#text(" of magnitude ")#tao-math("{\\left|k\\right| \\ll_d \\delta^{-O_d(1)}}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#text("There is an analogue for total equidistribution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" ")#metadata(none) <tao-1b8d4aa083095b5fe68b>#text(" Let ")#mi("{x_1,x_2,\\ldots,x_N}")#text(" be a sequence in ")#mi("{{\\bf T}^d}")#text(", and let ")#mi("{0 < \\delta < 1}")#text(".")

#list(
[#text("If ")#mi("{x_1,\\ldots,x_N}")#text(" is totally ")#mi("{\\delta}")#text("-equidistributed, ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(" has magnitude ")#tao-math("{\\left|k\\right| \\leq \\delta^{-c_d}}", block: false)#text(", and ")#mi("{a}")#text(" is a rational of height at most ")#mi("{\\delta^{-c_d}}")#text(", then one has")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} e( k \\cdot x_n ) e(a n)\\right| \\ll_d \\delta^{c_d}", block: true)]]

#text("if ")#mi("{c_d > 0}")#text(" is a small enough constant depending only on ")#mi("{d}")#text(".")],
[#text("Conversely, if ")#mi("{x_1,\\ldots,x_N}")#text(" is ")#emph[#text("not")]#text(" totally ")#mi("{\\delta}")#text("-equidistributed, then there exists ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(" with magnitude ")#tao-math("{\\left|k\\right| \\ll_d \\delta^{-C_d}}", block: false)#text(", and a rational ")#mi("{a}")#text(" of height ")#mi("{O_d(\\delta^{-C_d})}")#text(", such that")

#align(center)[#tao-fit-display[#tao-math("\\left|{\\bf E}_{n \\in [N]} e( k \\cdot x_n ) e(an)\\right| \\gg_d \\delta^{C_d}", block: true)]]

#text("for some ")#mi("{C_d}")#text(" depending on ")#mi("{d}")#text(".")]
)
]

#text("This gives a version of Exercise ")#link(<tao-e478be9c3ffbf35539d8>)[#text("5")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-ab6057ce9ec28c653b9c>#text(" Let ")#mi("{\\alpha, \\beta \\in {\\bf T}^d}")#text(", let ")#mi("{N \\geq 1}")#text(", and let ")#mi("{0 < \\delta < 1}")#text(". Suppose that the linear sequence ")#mi("{(\\alpha n + \\beta)_{n=1}^N}")#text(" is not totally ")#mi("{\\delta}")#text("-equidistributed. Show that there exists a non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(" with ")#tao-math("{\\left|k\\right| \\ll_d \\delta^{-O_d(1)}}", block: false)#text(" such that ")#tao-math("{\\left\\|k \\cdot \\alpha \\right\\|_{{\\bf T}} \\ll_d \\delta^{-O_d(1)}/N}", block: false)#text(".")
]

#text("Next, we give an analogue of Corollary ")#link(<tao-e61228236bddb7297fa4>)[#text("5")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Single-scale van der Corput lemma)")]#text(" ")#metadata(none) <tao-23b5c7df45cf97f68365>#text(" Let ")#mi("{x_1, x_2, \\ldots, x_N \\in {\\bf T}^d}")#text(" be a sequence which is not totally ")#mi("{\\delta}")#text("-equidistributed for some ")#mi("{0 < \\delta \\leq 1/2}")#text(". Let ")#mi("{1 \\leq H \\leq \\delta^{C_d} N}")#text(" for some sufficiently large ")#mi("{C_d}")#text(" depending only on ")#mi("{d}")#text(". Then there exists at least ")#mi("{\\delta^{C_d} H}")#text(" integers ")#mi("{h \\in [-H,H]}")#text(" such that the sequence ")#mi("{(x_{n+h}-x_n)_{n=1}^N}")#text(" is not totally ")#mi("{\\delta^{C_d}}")#text("-equidistributed (where we extend ")#mi("{x_n}")#text(" by zero outside of ")#mi("{\\{1,\\ldots,N\\}}")#text("). (")#emph[#text("Hint:")]#text(" apply Lemma ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("4")]#text(".)")
]

#text("Just as in the asymptotic setting, we can use the van der Corput lemma to extend the linear equidistribution theory to polynomial sequences. To get satisfactory results, though, we will need an additional input, namely the following classical lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Vinogradov lemma)")]#text(" ")#metadata(none) <tao-8a2539e2b69d9daf9d58>#text(" Let ")#mi("{\\alpha \\in {\\bf T}}")#text(", ")#mi("{0 < \\epsilon < 1/100}")#text(", ")#mi("{100\\epsilon < \\delta < 1}")#text(", and ")#mi("{N \\geq 100/\\delta}")#text(". Suppose that ")#tao-math("{\\left\\| n \\alpha \\right\\|_{{\\bf T}} \\leq \\epsilon}", block: false)#text(" for at least ")#mi("{\\delta N}")#text(" values of ")#mi("{n \\in [-N,N]}")#text(". Then there exists a positive integer ")#mi("{q = O(1/\\delta)}")#text(" such that ")#tao-math("{\\left\\| \\alpha q \\right\\|_{{\\bf T}} \\ll \\frac{\\epsilon q}{\\delta N}}", block: false)#text(".")
]

#text("The key point here is that one starts with many multiples of ")#mi("{\\alpha}")#text(" being somewhat close (")#mi("{O(\\epsilon)}")#text(") to an integer, but concludes that there is a single multiple of ")#mi("{\\alpha}")#text(" which is ")#emph[#text("very")]#text(" close (")#mi("{O(\\epsilon/N)}")#text(", ignoring factors of ")#mi("{\\delta}")#text(") to an integer.")

#emph[#text("Proof:")]#text(" By the pigeonhole principle, we can find two distinct integers ")#mi("{n, n^{\\prime} \\in [-N,N]}")#text(" with ")#tao-math("{\\left|n-n^{\\prime}\\right| \\ll 1/\\delta}", block: false)#text(" such that ")#tao-math("{\\left\\| n\\alpha\\right\\|_{{\\bf T}}, \\left\\|n^{\\prime}\\alpha \\right\\|_{{\\bf T}} \\leq \\epsilon}", block: false)#text(". Setting ")#tao-math("{q := \\left|n^{\\prime}-n\\right|}", block: false)#text(", we thus have ")#tao-math("{\\left\\| q \\alpha \\right\\|_{{\\bf T}} \\leq 2\\epsilon}", block: false)#text(". We may assume that ")#mi("{q\\alpha \\neq 0}")#text(" since we are done otherwise. Since ")#mi("{N \\geq 100/\\delta}")#text(", we have ")#mi("{N/q \\geq 10}")#text(" (say).")

#text("Now partition ")#mi("{[-N,N]}")#text(" into ")#mi("{q}")#text(" arithmetic progressions ")#mi("{\\{ nq+r: -N/q + O(1) \\leq n \\leq N/q + O(1) \\}}")#text(" for some ")#mi("{r=0,\\ldots,q-1}")#text(". By the pigeonhole principle, there must exist an ")#mi("{r}")#text(" for which the set")

#align(center)[#tao-fit-display[#tao-math("\\{ -N/q+O(1) \\leq n \\leq N/q+O(1): \\left\\| \\alpha (nq+r)\\right\\|_{{\\bf T}} \\leq \\epsilon \\}", block: true)]]

#text("has cardinality at least ")#mi("{\\delta N/q}")#text(". On the other hand, since ")#tao-math("{\\left\\| q \\alpha \\right\\|_{{\\bf T}} \\leq 2\\epsilon \\leq 0.02}", block: false)#text(", we see that this set consists of intervals of length at most ")#tao-math("{2\\epsilon / \\left\\| q \\alpha \\right\\|_{{\\bf T}}}", block: false)#text(", punctuated by gaps of length at least ")#tao-math("{0.9 / \\left\\|q\\alpha\\right\\|_{{\\bf T}}}", block: false)#text(" (say). Since the gaps are at least ")#mi("{0.45/\\epsilon}")#text(" times as large as the intervals, we see that if two or more these intervals appear in the set, then the cardinality of the set is at most ")#mi("{100 \\epsilon N/q < \\delta N/q}")#text(", a contradiction. Thus at most one interval appears in the set, which implies that ")#tao-math("{2\\epsilon/\\left\\|q\\alpha\\right\\|_{{\\bf T}} \\geq \\delta N/q}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" The numerical constants can of course be improved, but this is not our focus here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21")]#text(" ")#metadata(none) <tao-35c20f9d8dfbd47ae538>#text(" Let ")#mi("{P: {\\bf Z} \\rightarrow {\\bf T}^d}")#text(" be a polynomial sequence ")#mi("{P(n) := \\alpha_s n^s + \\ldots + \\alpha_0}")#text(", let ")#mi("{N \\geq 1}")#text(", and let ")#mi("{0 < \\delta < 1}")#text(". Suppose that the polynomial sequence ")#mi("{P}")#text(" is not totally ")#mi("{\\delta}")#text("-equidistributed on ")#mi("{[N]}")#text(". Show that there exists a non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(" with ")#tao-math("{\\left|k\\right| \\ll_{d,s} \\delta^{-O_{d,s}(1)}}", block: false)#text(" such that ")#tao-math("{\\left\\|k \\cdot \\alpha_s \\right\\|_{{\\bf T}} \\ll_{d,s} \\delta^{-O_{d,s}(1)}/N^s}", block: false)#text(". (")#emph[#text("Hint:")]#text(" Induct on ")#mi("{s}")#text(" starting with Exercise ")#link(<tao-ab6057ce9ec28c653b9c>)[#text("19")]#text(" for the base case, and then using Exercise ")#link(<tao-23b5c7df45cf97f68365>)[#text("20")]#text(" and Lemma ")#link(<tao-8a2539e2b69d9daf9d58>)[#text("10")]#text(" to continue the induction.)")
]

#text("Note the ")#mi("{N^s}")#text(" denominator; the higher-degree coefficients of a polynomial need to be ")#emph[#text("very")]#text(" rational in order not to cause equidistribution.")

#text("The above exercise only controls the top degree coefficient, but we can in fact control all coefficients this way:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-919a11f948095f31d922>#text(" With the hypotheses of Exercise ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("21")]#text(", we can in fact find a non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(" with ")#tao-math("{\\left|k\\right| \\ll_{d,s} \\delta^{-O_{d,s}(1)}}", block: false)#text(" such that ")#tao-math("{\\left\\|k \\cdot \\alpha_i \\right\\|_{{\\bf T}} \\ll_{d,s} \\delta^{-O_{d,s}(1)}/N^i}", block: false)#text(" for all ")#mi("{i=0,\\ldots,s}")#text(".")
]

#emph[#text("Proof:")]#text(" We shall just establish the one-dimensional case ")#mi("{d=1}")#text(", as the general dimensional case then follows from Exercise ")#link(<tao-1b8d4aa083095b5fe68b>)[#text("18")]#text(".")

#text("The case ")#mi("{s \\leq 1}")#text(" follows from Exercise ")#link(<tao-ab6057ce9ec28c653b9c>)[#text("19")]#text(", so assume inductively that ")#mi("{s > 1}")#text(" and that the claim has already been proven for smaller values of ")#mi("{s}")#text(". We allow all implied constants to depend on ")#mi("{s}")#text(". From Exercise ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("21")]#text(", we already can find a positive ")#mi("{k}")#text(" with ")#mi("{k = O( \\delta^{-O(1)})}")#text(" such that ")#tao-math("{\\left\\| k \\alpha_s \\right\\|_{{\\bf T}} \\ll \\delta^{-O(1)}/N^s}", block: false)#text(". We now partition ")#mi("{[N]}")#text(" into arithmetic progressions of spacing ")#mi("{k}")#text(" and length ")#mi("{N^{\\prime} \\sim \\delta^{C} N}")#text(" for some sufficiently large ")#mi("{C}")#text("; then by the pigeonhole principle, we see that ")#mi("{P}")#text(" fails to be totally ")#mi("{\\gg \\delta^{O(1)}}")#text("-equidistributed on one of these progressions. But on one such progression (which can be identified with ")#mi("{[N^{\\prime}]}")#text(") the degree ")#mi("{s}")#text(" component of ")#mi("{P}")#text(" is essentially constant (up to errors much smaller than ")#mi("{\\delta}")#text(") if ")#mi("{C}")#text(" is large enough; if one then applies the induction hypothesis to the remaining portion of ")#mi("{P}")#text(" on this progression, we can obtain the claim. ")#mi("\\Box")

#text("This gives us the following analogue of Exercise ")#link(<tao-ed08ac43f2dd77336aa3>)[#text("7")]#text(". We say that a subtorus ")#mi("{T}")#text(" of some dimension ")#mi("{d^{\\prime}}")#text(" of a standard torus ")#mi("{{\\bf T}^d}")#text(" has ")#emph[#text("complexity")]#text(" at most ")#mi("{M}")#text(" if there exists an invertible linear transformation ")#mi("{L \\in SL_d({\\bf Z})}")#text(" with integer coefficients (which can thus be viewed as a homeomorphism of ")#mi("{{\\bf T}^d}")#text(" that maps ")#mi("{T}")#text(" to the standard torus ")#mi("{{\\bf T}^{d^{\\prime}} \\times \\{0\\}^{d-d^{\\prime}}}")#text(", and such that all coefficients have magnitude at most ")#mi("{M}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Show that every subtorus (i.e. compact connected Lie subgroup) ")#mi("{T}")#text(" of ")#mi("{{\\bf T}^d}")#text(" has finite complexity. (")#emph[#text("Hint:")]#text(" Let ")#mi("{V}")#text(" be the Lie algebra of ")#mi("{T}")#text(", then identify ")#mi("{V}")#text(" with a subspace of ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{T}")#text(" with ")#mi("{V / (V \\cap {\\bf Z}^d)}")#text(". Show that ")#mi("{V \\cap {\\bf Z}^d}")#text(" is a full rank sublattice of ")#mi("{V}")#text(", and is thus generated by ")#mi("{\\text{dim}(V)}")#text(" independent generators.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12 (Single-scale Ratner’s theorem for abelian polynomial sequences)")]#text(" ")#metadata(none) <tao-2c36c9d1e1c141b7fa87>#text(" Let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{{\\bf T}^d}")#text(" of some degree ")#mi("{s \\geq 0}")#text(", and let ")#mi("{F: {\\bf R}^+ \\rightarrow {\\bf R}^+}")#text(" be an increasing function. Then there exists an integer ")#mi("{1 \\leq M \\leq O_{F,s,d}(1)}")#text(" and a decomposition")

#align(center)[#tao-fit-display[#mitex("P = P_{smth} + P_{equi} + P_{rat}")]]

#text("into polynomials of degree ")#mi("{s}")#text(", where")

#list(
[#text("(")#mi("{P_{smth}}")#text(" is smooth) The ")#mi("{i^{th}}")#text(" coefficient ")#mi("{\\alpha_{i,smth}}")#text(" of ")#mi("{P_{smth}}")#text(" has size ")#mi("{O( M / N^i )}")#text(". In particular, on the interval ")#mi("{[N]}")#text(", ")#mi("{P_{smth}}")#text(" is Lipschitz with homogeneous norm ")#mi("{O_{s,d}(M/N)}")#text(".")],
[#text("(")#mi("{P_{equi}}")#text(" is equidistributed) There exists a subtorus ")#mi("{T}")#text(" of ")#mi("{{\\bf T}^d}")#text(" of complexity at most ")#mi("{M}")#text(" and some dimension ")#mi("{d^{\\prime}}")#text(", such that ")#mi("{P_{equi}}")#text(" takes values in ")#mi("{T}")#text(" and is totally ")#mi("{1/F(M)}")#text("-equidistributed on ")#mi("{[N]}")#text(" in this torus (after identifying this torus with ")#mi("{{\\bf T}^{d^{\\prime}}}")#text(" using an invertible linear transformation of complexity at most ")#mi("{M}")#text(").")],
[#text("(")#mi("{P_{rat}}")#text(" is rational) The coefficients ")#mi("{\\alpha_{i,rat}}")#text(" of ")#mi("{P_{rat}}")#text(" are such that ")#mi("{q \\alpha_{i,rat}=0}")#text(" for some ")#mi("{1 \\leq q \\leq M}")#text(" and all ")#mi("{0 \\leq i \\leq s}")#text(". In particular, ")#mi("{q P_{rat} = 0}")#text(" and ")#mi("{P_{rat}}")#text(" is periodic with period ")#mi("{q}")#text(".")]
)

#text("If furthermore ")#mi("{F}")#text(" is of polynomial growth, and more precisely ")#mi("{F(M) \\leq K M^{A}}")#text(" for some ")#mi("{A, K \\geq 1}")#text(", then one can take ")#mi("{M \\ll_{A,s,d} K^{O_{A,s,d}(1)}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2")]#text(" Consider the linear flow ")#mi("{P(n) := (\\sqrt{2} n, (\\frac{1}{2} + \\frac{1}{N}) n) \\text{ mod } {\\bf Z}^2}")#text(" in ")#mi("{{\\bf T}^2}")#text(" on ")#mi("{[N]}")#text(". This flow can be decomposed into a smooth flow ")#mi("{P_{smth}(n) := (0, \\frac{1}{N} n) \\text{ mod } {\\bf Z}^2}")#text(" with a homogeneous Lipschitz norm of ")#mi("{O(1/N)}")#text(", an equidistributed flow ")#mi("{P_{equi}(n) := (\\sqrt{2} n, 0) \\text{ mod } {\\bf Z}^2}")#text(" which will be ")#mi("{\\delta}")#text("-equidistributed on the subtorus ")#mi("{{\\bf T}^1 \\times \\{0\\}}")#text(" for a reasonably small ")#mi("{\\delta}")#text(" (in fact one can take ")#mi("{\\delta}")#text(" as small as ")#mi("{N^{-c}}")#text(" for some small absolute constant ")#mi("{c > 0}")#text("), and a rational flow ")#mi("{P_{rat}(n) := (0, \\frac{1}{2} n) \\text{ mod } {\\bf Z}^2}")#text(", which is periodic with period ")#mi("{2}")#text(". This example illustrates how all three components of this decomposition arise naturally in the single-scale case.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" Comparing this result with the asymptotically equidistributed analogue in Example ")#link(<tao-ed08ac43f2dd77336aa3>)[#text("7")]#text(", we notice several differences. Firstly, we now have the smooth component ")#mi("{P_{smth}}")#text(", which did not previously make an appearance (except implicitly, as the constant term in ")#mi("{P^{\\prime}}")#text("). Secondly, the equidistribution of the component ")#mi("{P_{equi}}")#text(" is not infinite, but is the next best thing, namely it is given by an arbitrary function ")#mi("{F}")#text(" of the quantity ")#mi("{M}")#text(", which controls the other components of the decomposition.")
]

#emph[#text("Proof:")]#text(" The case ")#mi("{s=0}")#text(" is trivial, so suppose inductively that ")#mi("{s \\geq 1}")#text(", and that the claim has already been proven for lower degrees. Then for fixed degree, the case ")#mi("{d=0}")#text(" is vacuously true, so we make a further inductive assumption ")#mi("{d \\geq 1}")#text(" and the claim has already been proven for smaller dimensions (keeping ")#mi("{s}")#text(" fixed).")

#text("If ")#mi("{P}")#text(" is already totally ")#mi("{1/F(1)}")#text("-equidistributed then we are done (setting ")#mi("{P_{equi}=P}")#text(" and ")#mi("{P_{smth}=P_{rat}=0}")#text(" and ")#mi("{M=1}")#text("), so suppose that this is not the case. Applying Exercise ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("21")]#text(", we conclude that there is some non-zero ")#mi("{k \\in {\\bf Z}^d}")#text(" with ")#tao-math("{\\left|k\\right| \\ll_{d,s} F(1)^{O_{d,s}(1)}}", block: false)#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| k \\cdot \\alpha_i \\right\\|_{{\\bf T}} \\ll_{d,s} F(1)^{O_{d,s}(1)} / N^i", block: true)]]

#text("for all ")#mi("{i=0,\\ldots,s}")#text(". We split ")#mi("{k = mk^{\\prime}}")#text(" where ")#mi("{k^{\\prime}}")#text(" is irreducible and ")#mi("{m}")#text(" is a positive integer. We can therefore split ")#mi("{\\alpha_i = \\alpha_{i,smth} + \\alpha_{i,rat} + \\alpha^{\\prime}_i}")#text(" where ")#mi("{\\alpha_{i,smth} = O( F(1)^{O_{d,s}(1)}/N^i}")#text(", ")#mi("{q \\alpha_i = 0}")#text(" for some positive integer ")#mi("{q = O_{d,s}( F(1)^{O_{d,s}(1)} )}")#text(", and ")#mi("{k^{\\prime} \\cdot \\alpha^{\\prime}_i = 0}")#text(". This then gives a decomposition ")#mi("{P = P_{smth} + P^{\\prime} + P_{rat}}")#text(", with ")#mi("{P^{\\prime}}")#text(" taking values in the subtorus ")#mi("{\\{ x \\in {\\bf T}^d: k^{\\prime} \\cdot x = 0 \\}}")#text(", which can be identified with ")#mi("{{\\bf T}^{d-1}}")#text(" after an invertible linear transformation with integer coefficients of size ")#mi("{O_{d,s}( F(1)^{O_{d,s}(1)} )}")#text(". If one applies the induction hypothesis to ")#mi("{P^{\\prime}}")#text(" (with ")#mi("{F}")#text(" replaced by a suitably larger function ")#mi("{F^{\\prime}}")#text(") one then obtains the claim.")

#text("The final claim about polynomial bounds can be verified by a closer inspection of the argument (noting that all intermediate steps are polynomially quantitative, and that the length of the induction is bounded by ")#mi("{O_{d,s}(1)}")#text("). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" It is instructive to see how this smooth-equidistributed-rational decomposition evolves as ")#mi("{N}")#text(" increases. Roughly speaking, the torus ")#mi("{T}")#text(" that the ")#mi("{P_{equi}}")#text(" component is equidistributed on is stable at most scales, but there will be a finite number of times in which a “growth spurt” occurs and ")#mi("{T}")#text(" jumps up in dimension. For instance, consider the linear flow ")#mi("{P(n) := (n/N_0, n/N_0^2) \\text{ mod } {\\bf Z}^2}")#text(" on the two-dimensional torus. At scales ")#mi("{N \\ll N_0}")#text(" (and with ")#mi("{F}")#text(" fixed, and ")#mi("{N_0}")#text(" assumed to be sufficiently large depending on ")#mi("{F}")#text("), ")#mi("{P}")#text(" consists entirely of the smooth component. But as ")#mi("{N}")#text(" increases past ")#mi("{N_0}")#text(", the first component of ")#mi("{P}")#text(" no longer qualifies as smooth, and becomes equidistributed instead; thus in the range ")#mi("{N_0 \\ll N \\ll N_0^2}")#text(", we have ")#mi("{P_{smth}(n) = (0,n/N_0^2) \\text{ mod } {\\bf Z}^2}")#text(" and ")#mi("{P_{equi}(n) = (n/N_0,0) \\text{ mod } {\\bf Z}^2}")#text(" (with ")#mi("{P_{rat}}")#text(" remaining trivial), with the torus ")#mi("{T}")#text(" increasing from the trivial torus ")#mi("{\\{0\\}^2}")#text(" to ")#mi("{{\\bf T}^1 \\times \\{0\\}}")#text(". A second transition occurs when ")#mi("{N}")#text(" exceeds ")#mi("{N_0^2}")#text(", at which point ")#mi("{P_{equi}}")#text(" encompasses all of ")#mi("{P}")#text(". Evolving things in a somewhat different direction, if one then increases ")#mi("{F}")#text(" so that ")#mi("{F(1)}")#text(" is much larger than ")#mi("{N_0^2}")#text(", then ")#mi("{P}")#text(" will now entirely consist of a rational component ")#mi("{P_{rat}}")#text(". These sorts of dynamics are not directly seen if one only looks at the asymptotic theory, which roughly speaking is concerned with the limit after taking ")#mi("{N \\rightarrow \\infty}")#text(", and ")#emph[#text("then")]#text(" taking a second limit by making the growth function ")#mi("{F}")#text(" go to infinity.")
]

#text("There is a multidimensional version of Proposition ")#link(<tao-2c36c9d1e1c141b7fa87>)[#text("12")]#text(", but we will not describe it here; see ")#link("http://arxiv.org/abs/0709.3562")[#text("this paper of Ben Green and myself")]#text(" for a statement (and also see the next section for the ultralimit counterpart of this statement).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" These single-scale abelian Ratner theorems are a special case of a more general single-scale ")#emph[#text("nilpotent")]#text(" Ratner theorem, which will play an important role in later aspects of the theory, and which was the main result of the aforementioned paper of Ben Green and myself.")
]

#text("As an example of this theorem in action, we give a single-scale strengthening of Exercise ")#link(<tao-92401b7494e24105a024>)[#text("8")]#text(" (and Exercise ")#link(<tao-4db4767b4c282c8e22c5>)[#text("15")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Recurrence)")]#text(" ")#metadata(none) <tao-6706fd6fe8580bacb911>#text(" Let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{{\\bf Z}}")#text(" to ")#mi("{{\\bf T}^d}")#text(" of degree ")#mi("{s}")#text(", and let ")#mi("{N \\geq 1}")#text(" be an integer. Show that for every ")#mi("{\\epsilon > 0}")#text(" and ")#mi("{N > 1}")#text(", and every integer ")#mi("{n_0 \\in [N]}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ n \\in [N]: \\left\\|P(n)-P(n_0)\\right\\| \\leq \\epsilon \\}\\right| \\gg_{d,s} \\epsilon^{O_{d,s}(1)} N.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Multiple recurrence)")]#text(" With the notation of Exercise ")#link(<tao-6706fd6fe8580bacb911>)[#text("23")]#text(", establish that")

#align(center)[#tao-fit-display[#tao-math("|\\{ r \\in [-N,N]: \\left\\|P(n_0+jr)-P(n_0)\\right\\| \\leq \\epsilon", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\text{ for } j=0,1,\\ldots,k-1 \\}| \\gg_{d,s,k} \\epsilon^{O_{d,s,k}(1)} N")]]

#text("for any ")#mi("{k \\geq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Syndeticity)")]#text(" A set of integers is ")#emph[#text("syndetic")]#text(" if it has bounded gaps (or equivalently, if a finite number of translates of this set can cover all of ")#mi("{{\\bf Z}}")#text("). Let ")#mi("{P: {\\bf Z} \\rightarrow {\\bf T}^d}")#text(" be a polynomial and let ")#mi("{\\epsilon > 0}")#text(". Show that the set ")#tao-math("{\\{ n \\in {\\bf Z}: \\left\\|P(n) - P(n_0)\\right\\| \\leq \\epsilon \\}}", block: false)#text(" is syndetic. (")#emph[#text("Hint:")]#text(" first reduce to the case when ")#mi("{P}")#text(" is (totally) asymptotically equidistributed. Then, if ")#mi("{N}")#text(" is large enough, show (by inspection of the proof of Exercise ")#link(<tao-35c20f9d8dfbd47ae538>)[#text("21")]#text(") that the translates ")#mi("{P(\\cdot+n_0)}")#text(" are ")#mi("{\\epsilon}")#text("-equidistributed on ")#mi("{[N]}")#text(" uniformly for all ")#mi("{n \\in {\\bf Z}}")#text(", for any fixed ")#mi("{\\epsilon > 0}")#text(". Note how the asymptotic theory and the single-scale theory need to work together to obtain this result.)")
]

#heading(level: 1)[#strong[#text(" — 3. Ultralimit equidistribution theory — ")]]

#text("The single-scale theory was somewhat more complicated than the asymptotic theory, in part because one had to juggle parameters such as ")#mi("{N, \\delta}")#text(", and (for the Ratner-type theorems) ")#mi("{F}")#text(" as well. However, one can clean up this theory somewhat (especially if one does not wish to quantify the dependence of bounds on the equidistribution parameter ")#mi("{\\delta}")#text(") by using an ultralimit, which causes the ")#mi("{\\delta}")#text(" and ")#mi("{F}")#text(" parameters to disappear, at the cost of converting the finitary theory to an infinitary one. Ultralimit analysis was discussed in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous blog post")]#text("; we give a quick review here.")

#text("We first fix a ")#link("http://en.wikipedia.org/wiki/Ultrafilter")[#text("non-principal ultrafilter")]#text(" ")#mi("{\\alpha_\\infty \\in \\beta {\\bf N} \\backslash {\\bf N}}")#text(". A property ")#mi("{P_\\alpha}")#text(" pertaining to a natural number ")#mi("{\\alpha}")#text(" is said to hold ")#emph[#text("for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")]#text(" if the set of ")#mi("{\\alpha}")#text(" for which ")#mi("{P_\\alpha}")#text(" holds lies in the ultrafilter ")#mi("{\\alpha_\\infty}")#text(". Two sequences ")#mi("{(x_\\alpha)_{\\alpha \\in {\\bf N}}, (y_\\alpha)_{\\alpha \\in {\\bf N}}}")#text(" of objects are ")#emph[#text("equivalent")]#text(" if one has ")#mi("{x_\\alpha = y_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(", and we define the ")#emph[#text("ultralimit")]#text(" ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" to be the equivalence class of all sequences equivalent to ")#mi("{(x_\\alpha)_{\\alpha \\in {\\bf N}}}")#text(", with the convention that ")#mi("{x}")#text(" is identified with its own ultralimit ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(". Given any sequence ")#mi("{X_\\alpha}")#text(" of sets, the ")#link("http://en.wikipedia.org/wiki/Ultraproduct")[#text("ultraproduct")]#text(" ")#mi("{\\prod_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha}")#text(" is the space of all ultralimits ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(", where ")#mi("{x_\\alpha \\in X_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(". The ultraproduct ")#mi("{\\prod_{\\alpha \\rightarrow \\alpha_\\infty} X}")#text(" of a single set ")#mi("{X}")#text(" is the ")#emph[#text("ultrapower")]#text(" of ")#mi("{X}")#text(" and is denoted ")#mi("{*X}")#text(".")

#text("Ultralimits of real numbers (i.e. elements of ")#mi("{*{\\bf R}}")#text(") will be called ")#emph[#text("limit real numbers")]#text("; similarly one defines limit natural numbers, limit complex numbers, etc. Ordinary numbers will be called ")#emph[#text("standard")]#text(" numbers to distinguish them from limit numbers, thus for instance a limit real number is an ultralimit of standard real numbers. All the usual arithmetic operations and relations on standard numbers are inherited by their limit analogues; for instance, a limit real number ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" is larger than another ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} y_\\alpha}")#text(" if one has ")#mi("{x_\\alpha > y_\\alpha}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(". The axioms of a non-principal ultrafilter ensure that these relations and operations on limit numbers obey the same axioms as their standard counterparts (the formalisation of this principle is ")#link("http://en.wikipedia.org/wiki/Ultraproduct#.C5.81o.C5.9B.27s_theorem")[#text("Los’s theorem")]#text(").")

#text("Ultraproducts of sets will be called ")#emph[#text("limit sets")]#text("; they are roughly analogous to “measurable sets” in measure theory. Ultraproducts of finite sets will be called ")#emph[#text("limit finite sets")]#text(". Thus, for instance, if ")#mi("{N = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} N_\\alpha}")#text(" is a limit natural number, then ")#mi("{[N] = \\prod_{\\alpha \\rightarrow \\alpha_\\infty} [N_\\alpha]}")#text(" is a limit finite set, and can be identified with the set of limit natural numbers between ")#mi("{1}")#text(" and ")#mi("{N}")#text(".")

#text("Given a sequence of functions ")#mi("{f_\\alpha: X_\\alpha \\rightarrow Y_\\alpha}")#text(", we can form the ")#emph[#text("ultralimit")]#text(" ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} f_\\alpha: \\lim_{\\alpha \\rightarrow \\alpha_\\infty} X_\\alpha \\rightarrow \\lim_{\\alpha \\rightarrow \\alpha_\\infty} Y_\\alpha}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(\\lim_{\\alpha \\rightarrow \\alpha_\\infty} f_\\alpha)(\\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha) := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} f_\\alpha(x_\\alpha);")]]

#text("one easily verifies that this is a well-defined function between the two ultraproducts. We refer to ultralimits of functions as ")#emph[#text("limit functions")]#text("; they are roughly analogous to “measurable functions” in measurable theory. We identify every standard function ")#mi("{f: X \\rightarrow Y}")#text(" with its ultralimit ")#mi("{\\lim_{\\alpha \\rightarrow \\alpha_\\infty} f: *X \\rightarrow *Y}")#text(", which extends the original function ")#mi("{f}")#text(".")

#text("Given two limit numbers ")#mi("{X, Y}")#text(", we write ")#mi("{X \\ll Y}")#text(", ")#mi("{Y \\gg X}")#text(", or ")#mi("{X = O(Y)}")#text(" if we have ")#tao-math("{\\left|X\\right| \\leq CY}", block: false)#text(" for some standard ")#mi("{C > 0}")#text(". We also write ")#mi("{X = o(Y)}")#text(" if we have ")#tao-math("{\\left|X\\right| \\leq cY}", block: false)#text(" for every standard ")#mi("{c>0}")#text("; thus for any limit numbers ")#mi("{X, Y}")#text(" with ")#mi("{Y>0}")#text(", exactly one of ")#tao-math("{\\left|X\\right| \\gg Y}", block: false)#text(" and ")#mi("{X=o(Y)}")#text(" is true. A limit real is said to be ")#emph[#text("bounded")]#text(" if it is of the form ")#mi("{O(1)}")#text(", and ")#emph[#text("infinitesimal")]#text(" if it is of the form ")#mi("{o(1)}")#text("; similarly for limit complex numbers. Note that the bounded limit reals are a subring of the limit reals, and the infinitesimal limit reals are an ideal of the bounded limit reals.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26")]#text(" Show that every bounded limit real number ")#mi("{x}")#text(" has a unique decomposition ")#mi("{x = \\text{st}(x) + (x-\\text{st}(x))}")#text(", where ")#mi("{\\text{st}(x)}")#text(" is a standard real (called the ")#emph[#text("standard part")]#text(" of ")#mi("{x}")#text(") and ")#mi("{x-\\text{st}(x)}")#text(" is infinitesimal.")
]

#text("We now give the analogue of single-scale equidistribution in the ultralimit setting.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 13 (Ultralimit equidistribution)")]#text(" Let ")#mi("{X = (X,d)}")#text(" be a standard compact metric space, let ")#mi("{N}")#text(" be an unbounded limit natural number, and let ")#mi("{x: [N] \\rightarrow *X}")#text(" be a limit function. We say that ")#mi("{x}")#text(" is ")#emph[#text("equidistributed")]#text(" with respect to a (standard) Borel probability measure ")#mi("{\\mu}")#text(" on ")#mi("{X}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\text{st} {\\bf E}_{n \\in [N]} f(x(n)) = \\int_X f\\ d\\mu")]]

#text("for all standard continuous functions ")#mi("{f \\in C(X)}")#text(". Here, we define the expectation of a limit function in the obvious limit manner, thus")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\in [N]} f(x(n)) = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} {\\bf E}_{n \\in [N_\\alpha]} f(x_\\alpha(n))")]]

#text("if ")#mi("{N = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} N_\\alpha}")#text(" and ")#mi("{x = \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(".")

#text("We say that ")#mi("{x}")#text(" is ")#emph[#text("totally equidistributed")]#text(" relative to ")#mi("{\\mu}")#text(" if the sequence ")#mi("{n \\mapsto x(qn+r)}")#text(" is equidistributed on ")#mi("{[N/q]}")#text(" for every standard ")#mi("{q > 0}")#text(" and ")#mi("{r \\in {\\bf Z}}")#text(" (extending ")#mi("{x}")#text(" arbitrarily outside ")#mi("{[N]}")#text(" if necessary).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" One could just as easily replace the space of continuous functions by any dense subclass in the uniform topology, such as the space of Lipschitz functions.")
]

#text("The ultralimit notion of equidistribution is closely related to that of both asymptotic equidistribution and single-scale equidistribution, as the following exercises indicate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27 (Asymptotic equidistribution vs. ultralimit equidistribution)")]#text(" Let ")#mi("{x: {\\bf N} \\rightarrow X}")#text(" be a sequence into a standard compact metric space (which can then be extended from a map from ")#mi("{*{\\bf N}}")#text(" to ")#mi("{*X}")#text(" as usual), let ")#mi("{\\mu}")#text(" be a Borel probability measure on ")#mi("{X}")#text(". Show that ")#mi("{x}")#text(" is asymptotically equidistributed on ")#mi("{{\\bf N}}")#text(" with respect to ")#mi("{\\mu}")#text(" if and only if ")#mi("{x}")#text(" is equidistributed on ")#mi("{[N]}")#text(" for every unbounded natural number ")#mi("{N}")#text(" and every choice of non-principal ultrafilter ")#mi("{\\alpha_\\infty}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Single-scale equidistribution vs. ultralimit equidistribution)")]#text(" For every ")#mi("{\\alpha \\in {\\bf N}}")#text(", let ")#mi("{N_\\alpha}")#text(" be a natural number that goes to infinity as ")#mi("{\\alpha \\rightarrow \\infty}")#text(", let ")#mi("{x_\\alpha: [N_\\alpha] \\rightarrow X}")#text(" be a map to a standard compact metric space. Let ")#mi("{\\mu}")#text(" be a Borel probability measure on ")#mi("{X}")#text(". Write ")#mi("{N := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} N_\\alpha}")#text(" and ")#mi("{x := \\lim_{\\alpha \\rightarrow \\alpha_\\infty} x_\\alpha}")#text(" for the ultralimits. Show that ")#mi("{x}")#text(" is equidistributed with respect to ")#mi("{\\mu}")#text(" if and only if, for every standard ")#mi("{\\delta > 0}")#text(", ")#mi("{x_\\alpha}")#text(" is ")#mi("{\\delta}")#text("-equidistributed with respect to ")#mi("{\\mu}")#text(" for all ")#mi("{\\alpha}")#text(" sufficiently close to ")#mi("{\\alpha_\\infty}")#text(".")
]

#text("In view of these correspondences, it is thus not surprising that one has ultralimit analogues of the asymptotic and single-scale theory. These analogues tend to be ")#emph[#text("logically equivalent")]#text(" to the single-scale counterparts (once one concedes all quantitative bounds), but are ")#emph[#text("formally similar")]#text(" (though not identical) to the asymptotic counterparts, thus providing a bridge between the two theories, which we can summarise by the following three statements:")

#list(
[#text("Asymptotic theory is analogous to ultralimit theory (in particular, the statements and proofs are formally similar);")],
[#text("ultralimit theory is logically equivalent to qualitative finitary theory; and")],
[#text("quantitative finitary theory is a strengthening of qualitative finitary theory.")]
)

#text("For instance, here is the ultralimit version of the Weyl criterion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Ultralimit Weyl equidistribution criterion)")]#text(" ")#metadata(none) <tao-93f62b797cc04c8fdf27>#text(" Let ")#mi("{x: [N] \\rightarrow *{\\bf T}^d}")#text(" be a limit function for some unbounded ")#mi("{N}")#text(" and standard ")#mi("{d}")#text(". Then ")#mi("{x}")#text(" is equidistributed if and only if ")#metadata(none) <tao-e457ce862fc450a4d8b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf E}_{n \\in [N]} e( k \\cdot x(n) ) = o(1)")]]



#text(" for all standard ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(". {")#emph[#text("Hint:")]#text(" mimic the proof of Proposition ")#link(<tao-e3d8c301b327d61d49b7>)[#text("1")]#text(".}")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Use Exercise ")#link(<tao-93f62b797cc04c8fdf27>)[#text("29")]#text(" to recover a weak version of Proposition ")#link(<tao-f93cf797671e2fd02d3a>)[#text("9")]#text(", in which the quantities ")#mi("{\\delta^{c_d}}")#text(", ")#mi("{\\delta^{C_d}}")#text(" are replaced by (ineffective) functions of ")#mi("{\\delta}")#text(" that decay to zero as ")#mi("{\\delta \\rightarrow 0}")#text(". Conversely, use this weak version to recover Exercise ")#link(<tao-93f62b797cc04c8fdf27>)[#text("29")]#text(". (")#emph[#text("Hint:")]#text(" see ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("this previous blog post")]#text(" for further examples of this type of logical equivalence between ultralimit statements and qualitative finitary statements.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 31")]#text(" With the notation of Exercise ")#link(<tao-93f62b797cc04c8fdf27>)[#text("29")]#text(", show that ")#mi("{x}")#text(" is totally equidistributed if and only if")

#align(center)[#tao-fit-display[#mitex("{\\bf E}_{n \\in [N]} e( k \\cdot x(n) ) e( \\theta n ) = o(1)")]]

#text("for all standard ")#mi("{k \\in {\\bf Z}^d \\backslash \\{0\\}}")#text(" and standard rational ")#mi("{\\theta}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" With the notation of Exercise ")#link(<tao-93f62b797cc04c8fdf27>)[#text("29")]#text(", show that ")#mi("{x}")#text(" is equidistributed in ")#mi("{{\\bf T}^d}")#text(" on ")#mi("{[N]}")#text(" if and only if ")#mi("{k \\cdot x}")#text(" is equidistributed in ")#mi("{{\\bf T}}")#text(" on ")#mi("{[N]}")#text(" for every non-zero standard ")#mi("{k \\in {\\bf Z}^d}")#text(".")
]

#text("Now we establish the ultralimit version of the linear equidistribution criterion:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" ")#metadata(none) <tao-e0c7c2de2714b1802f14>#text(" Let ")#mi("{\\alpha, \\beta \\in *{\\bf T}^d}")#text(", and let ")#mi("{N}")#text(" be an unbounded integer. Show that the following are equivalent:")

#list(
[#text("The sequence ")#mi("{n \\mapsto n \\alpha + \\beta}")#text(" is equidistributed on ")#mi("{[N]}")#text(".")],
[#text("The sequence ")#mi("{n \\mapsto n \\alpha + \\beta}")#text(" is totally equidistributed on ")#mi("{[N]}")#text(".")],
[#mi("{\\alpha}")#text(" is ")#emph[#text("irrational to scale ")#mi("{1/N}")]#text(", in the sense that ")#mi("{k \\cdot \\alpha \\neq O(1/N)}")#text(" for any non-zero standard ")#mi("{k \\in {\\bf Z}^d}")#text(".")]
)
]

#text("Note that in the ultralimit setting, assertions such as ")#mi("{k \\cdot\\alpha \\neq O(1/N)}")#text(" make perfectly rigorous sense (it means that ")#tao-math("{\\left|k \\cdot \\alpha\\right| \\geq C/N}", block: false)#text(" for every standard ")#mi("{C}")#text("), but when using finitary asymptotic big-O notation")

#text("Next, we establish the analogue of the van der Corput lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34 (van der Corput lemma, ultralimit version)")]#text(" ")#metadata(none) <tao-0ee77c05c90d25ea00a5>#text(" Let ")#mi("{N}")#text(" be an unbounded integer, and let ")#mi("{x: [N] \\rightarrow *{\\bf T}^d}")#text(" be a limit sequence. Let ")#mi("{H = o(N)}")#text(" be unbounded, and suppose that the derivative sequence ")#mi("{\\partial_h x: n \\mapsto x(n+h)-x(n)}")#text(" is equidistributed on ")#mi("{[N]}")#text(" for ")#mi("{\\gg H}")#text(" values of ")#mi("{h \\in [H]}")#text(" (extending ")#mi("{x}")#text(" by arbitrarily outside of ")#mi("{[N]}")#text("). Show that ")#mi("{x}")#text(" is equidistributed on ")#mi("{[N]}")#text(". Similarly “equidistributed” replaced by “totally equidistributed”.")
]

#text("Here is the analogue of the Vinogradov lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Vinogradov lemma, ultralimit version)")]#text(" ")#metadata(none) <tao-ea4104be7255d9873d2a>#text(" Let ")#mi("{\\alpha \\in *{\\bf T}}")#text(", ")#mi("{N}")#text(" be unbounded, and ")#mi("{\\epsilon > 0}")#text(" be infinitesimal. Suppose that ")#tao-math("{\\left\\| n \\alpha \\right\\|_{{\\bf T}} \\leq \\epsilon}", block: false)#text(" for ")#mi("{\\gg N}")#text(" values of ")#mi("{n \\in [-N,N]}")#text(". Show that there exists a positive standard integer ")#mi("{q}")#text(" such that ")#tao-math("{\\left\\| \\alpha q \\right\\|_{{\\bf T}} \\ll \\epsilon / N}", block: false)#text(".")
]

#text("These two lemmas allow us to establish the ultralimit polynomial equidistribution theory:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" ")#metadata(none) <tao-f4f65541d2b47ca26f43>#text(" Let ")#mi("{P: *{\\bf Z} \\rightarrow *{\\bf T}^d}")#text(" be a polynomial sequence ")#mi("{P(n) := \\alpha_s n^s + \\ldots + \\alpha_0}")#text(" with ")#mi("{s,d}")#text(" standard, and ")#mi("{\\alpha_0,\\ldots,\\alpha_s \\in *{\\bf T}^d}")#text(". Let ")#mi("{N}")#text(" be an unbounded natural number. Suppose that ")#mi("{P}")#text(" is not totally equidistributed on ")#mi("{[N]}")#text(". Show that there exists a non-zero standard ")#mi("{k \\in {\\bf Z}^d}")#text(" with ")#tao-math("{\\left\\|k \\cdot \\alpha_s \\right\\|_{{\\bf T}} \\ll N^{-s}}", block: false)#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" ")#metadata(none) <tao-4c9de8859cd181391bcb>#text(" With the hypotheses of Exercise ")#link(<tao-f4f65541d2b47ca26f43>)[#text("36")]#text(", show in fact that there exists a non-zero standard ")#mi("{k \\in {\\bf Z}^d}")#text(" such that ")#tao-math("{\\left\\|k \\cdot \\alpha_i \\right\\|_{{\\bf T}} \\ll N^{-i}}", block: false)#text(" for all ")#mi("{i=0,\\ldots,s}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 38 (Ultralimit Ratner’s theorem for abelian polynomial sequences)")]#text(" ")#metadata(none) <tao-cff76bb29071cffaf321>#text(" Let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{*{\\bf Z}}")#text(" to ")#mi("{*{\\bf T}^d}")#text(" of some standard degree ")#mi("{s \\geq 0}")#text(". Let ")#mi("{N}")#text(" be an unbounded natural number. Then there exists a decomposition")

#align(center)[#tao-fit-display[#mitex("P = P_{smth} + P_{equi} + P_{rat}")]]

#text("into polynomials of degree ")#mi("{s}")#text(", where")

#list(
[#text("(")#mi("{P_{smth}}")#text(" is smooth) The ")#mi("{i^{th}}")#text(" coefficient ")#mi("{\\alpha_{i,smth}}")#text(" of ")#mi("{P_{smth}}")#text(" has size ")#mi("{O( N^{-i} )}")#text(". In particular, on the interval ")#mi("{[N]}")#text(", ")#mi("{P_{smth}}")#text(" is Lipschitz with homogeneous norm ")#mi("{O(1/N)}")#text(".")],
[#text("(")#mi("{P_{equi}}")#text(" is equidistributed) There exists a standard subtorus ")#mi("{T}")#text(" of ")#mi("{{\\bf T}^d}")#text(", such that ")#mi("{P_{equi}}")#text(" takes values in ")#mi("{T}")#text(" and is totally equidistributed on ")#mi("{[N]}")#text(" in this torus.")],
[#text("(")#mi("{P_{rat}}")#text(" is rational) The coefficients ")#mi("{\\alpha_{i,rat}}")#text(" of ")#mi("{P_{rat}}")#text(" are standard rational elements of ")#mi("{{\\bf T}^d}")#text(". In particular, there is a standard positive integer ")#mi("{q}")#text(" such that ")#mi("{q P_{rat} = 0}")#text(" and ")#mi("{P_{rat}}")#text(" is periodic with period ")#mi("{q}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Show that the torus ")#mi("{T}")#text(" is uniquely determined by ")#mi("{P}")#text(", and decomposition ")#mi("{P = P_{smth} + P_{equi} + P_{rat}}")#text(" in Exercise ")#link(<tao-cff76bb29071cffaf321>)[#text("38")]#text(" is unique up to expressions taking values in ")#mi("{T}")#text(" (i.e. if one is given another decomposition ")#mi("{P = P^{\\prime}_{smth} + P^{\\prime}_{equi}, P^{\\prime}_{rat}}")#text(", then ")#mi("{P_i}")#text(" and ")#mi("{P^{\\prime}_i}")#text(" differ by expressions taking values in ")#mi("{T}")#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Recurrence)")]#text(" Let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{*{\\bf Z}}")#text(" to ")#mi("{*{\\bf T}^d}")#text(" of some standard degree ")#mi("{s}")#text(", and let ")#mi("{N}")#text(" be an unbounded natural number. Show that for every standard ")#mi("{\\epsilon > 0}")#text(" and every ")#mi("{n_0 \\in N}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ n \\in [N]: \\left\\|P(n)-P(n_0)\\right\\| \\leq \\epsilon \\}\\right| \\gg N", block: true)]]

#text("and more generally")

#align(center)[#tao-fit-display[#tao-math("\\left|\\{ r \\in [-N,N]: \\left\\|P(n_0+jr)-P(n_0)\\right\\| \\leq \\epsilon \\text{ for } j=0,1,\\ldots,k-1 \\}\\right| \\gg N", block: true)]]

#text("for any standard ")#mi("{k}")#text(".")
]

#text("As before, there are also multidimensional analogues of this theory. We shall just state the main results without proof:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 14 (Multidimensional equidistribution)")]#text(" Let ")#mi("{X}")#text(" be a standard compact metric space, let ")#mi("{N}")#text(" be an unbounded limit natural number, let ")#mi("{m \\geq 1}")#text(" be standard, and let ")#mi("{x: [N]^m \\rightarrow *X}")#text(" be a limit function. We say that ")#mi("{x}")#text(" is ")#emph[#text("equidistributed")]#text(" with respect to a (standard) Borel probability measure ")#mi("{\\mu}")#text(" on ")#mi("{X}")#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\text{st} {\\bf E}_{n \\in [N]^m} 1_{B}(n/N) f(x(n)) = \\text{mes}(\\Omega) \\int_X f\\ d\\mu")]]

#text("for every standard box ")#mi("{B \\subset [0,1]^m}")#text(" and for all standard continuous functions ")#mi("{f \\in C(X)}")#text(".")

#text("We say that ")#mi("{x}")#text(" is ")#emph[#text("totally equidistributed")]#text(" relative to ")#mi("{\\mu}")#text(" if the sequence ")#mi("{n \\mapsto x(qn+r)}")#text(" is equidistributed on ")#mi("{[N/q]^d}")#text(" for every standard ")#mi("{q > 0}")#text(" and ")#mi("{r \\in {\\bf Z}^m}")#text(" (extending ")#mi("{x}")#text(" arbitrarily outside ")#mi("{[N]}")#text(" if necessary).")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" One can replace the indicators ")#mi("{1_B}")#text(" by many other classes, such as indicators of standard convex sets, or standard open sets whose boundary has measure zero, or continuous or Lipschitz functions.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Multidimensional ultralimit Ratner’s theorem for abelian polynomial sequences)")]#text(" ")#metadata(none) <tao-e8224038bf8cc8a0d566>#text(" Let ")#mi("{m,d,s \\geq 0}")#text(" be standard integers, and let ")#mi("{P}")#text(" be a polynomial map from ")#mi("{*{\\bf Z}^m}")#text(" to ")#mi("{*{\\bf T}^d}")#text(" of degree ")#mi("{s}")#text(". Let ")#mi("{N}")#text(" be an unbounded natural number. Then there exists a decomposition")

#align(center)[#tao-fit-display[#mitex("P = P_{smth} + P_{equi} + P_{rat}")]]

#text("into polynomials of degree ")#mi("{s}")#text(", where")

#list(
[#text("(")#mi("{P_{smth}}")#text(" is smooth) The ")#mi("{i^{th}}")#text(" coefficient ")#mi("{\\alpha_{i,smth}}")#text(" of ")#mi("{P_{smth}}")#text(" has size ")#tao-math("{O( N^{-\\left|i\\right|} )}", block: false)#text(" for every multi-index ")#mi("{i = (i_1,\\ldots,i_m)}")#text(". In particular, on the interval ")#mi("{[N]}")#text(", ")#mi("{P_{smth}}")#text(" is Lipschitz with homogeneous norm ")#mi("{O(1/N)}")#text(".")],
[#text("(")#mi("{P_{equi}}")#text(" is equidistributed) There exists a standard subtorus ")#mi("{T}")#text(" of ")#mi("{{\\bf T}^d}")#text(", such that ")#mi("{P_{equi}}")#text(" takes values in ")#mi("{T}")#text(" and is totally equidistributed on ")#mi("{[N]^m}")#text(" in this torus.")],
[#text("(")#mi("{P_{rat}}")#text(" is rational) The coefficients ")#mi("{\\alpha_{i,rat}}")#text(" of ")#mi("{P_{rat}}")#text(" are standard rational elements of ")#mi("{{\\bf T}^d}")#text(". In particular, there is a standard positive integer ")#mi("{q}")#text(" such that ")#mi("{q P_{rat} = 0}")#text(" and ")#mi("{P_{rat}}")#text(" is periodic with period ")#mi("{q}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" This is implicitly in ")#link("http://arxiv.org/abs/0709.3562")[#text("this paper of Ben Green and myself")]#text("; the result is phrased using the language of single-scale equidistribution, but this easily implies the ultralimit version. ")#mi("\\Box")

#emph[#text("Update, Apr 5:")]#text(" Another exercise added; some corrections.")

#heading(level: 1)[#text("Comments (46)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44033")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2010")])]

#text("Dear Terry,")#linebreak()#text(" Will there be applications to, say, dispersive PDEs in this course, or only number-theoretic oriented applications?")#linebreak()#text(" Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44034")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2010")])]

#text("An overview of the course can be found at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/03/09/course-announcement-254b-higher-order-fourier-analysis/")[#text("Course announcement: 254B, Higher order Fourier analysis")]
]

#text("The focus will be primarily on applications in additive combinatorics. There are tantalising hints that higher order Fourier analysis could also be useful in some aspects of harmonic analysis, such as the theory of the trilinear Hilbert transform, or the Lambda(p) problem for sets such as the square numbers, but there has been little concrete progress in this direction so far.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44037")[#strong[#text("Diego")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2010")])]

#text("Thanks Terry, I’ll try to keep up.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/baec7f0a5374b0dcd4555caf89c9b966d2e1c8af73aa5084dbe684a48a4d66ce-69d5fb383a25b029cceee5798b67ef83f95ea936eeca59cb7aca71b1762e9377.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vincent")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44041")[#strong[#text("Vincent")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2010")])]

#text("Thank you for the interesting notes! A stupid notational question though: what is the meaning of the dot in the Weyl Criterion for equidistribution? Does it take values in the ordinary torus T?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44043")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2010")])]

#text("Small typo. \\Phi should be U in Exercise 3.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Josh")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44068")[#strong[#text("Josh")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2010")])]

#text("“…it is not hard to see that this map is equidistributed with respect to 1/3 times the Haar probability measure on (T)\\times {0 mod Z}, plus 2/3 times the Haar probability measure on (T)\\times {1 mod Z}”")

#text("Perhaps the last statement should be “(T)\\times {1/3 mod Z}” ?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de3dd1c181c0346698e7d0b761a893a8243fd8c4094aa38b1ddd36286c49ece-ddbfe294ab43e27f6eca7e5ad70fab64b190c1bec39adfd38c98cdf6c5c3e292.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eckhard")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44106")[#strong[#text("Eckhard")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2010")])]

#text("First, thank you for the notes and the whole blog, which I find very interesting to read.")#linebreak()#text(" Second, I think the plural of ‘torus’ is ‘tori’, not ‘torii’.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44108")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2010")])]

#text("In the definition of totally delta-equidistributed, I think f(n) should read f(x(n)).")

#text("Thanks for the great notes–Jason")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa8e0026304bde0f0335731a84ccbdbd60b2de97830af815694eae4db91ec8ea-3cf2a76b6c008bca6d7c5aa49697694f074fc6a07bc98dca6b68efdb2d60ac2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brad")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44109")[#strong[#text("brad")]]#text(size: 9pt, fill: rgb("596477"), " · 5 April 2010")])]

#text("Perhaps I’m missing something, but for the Fejer kernel estimates, I think one has only 1/(R \\|x_j\\|^2) rather than 1/(R\\|x_j\\|)^2; and to get the O(1/R) bound I think one has to resort to the full force of a \\min(R,1/(R\\|x_j\\|^2)) estimate (at any rate I did).")

#text("More pedantically, the expression involving a product of sines should have x_j multiplied by 2\\pi, I think.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44143")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2010")])]

#text("One minor thing, the error term H/N in the proof of corollary 5 should be changed to sqrt(H/N) too.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44145")[#strong[#text("Jason")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2010")])]

#text("Small detail: In Exercise 21, should “the linear sequence P” read “the polynomial sequence P” ? ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44183")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 12 April 2010")])]

#text("In the beginning of Section 3, you say")#linebreak()#text(" “thus for any limit numbers {X, Y} with {Y>0}, exactly one of {X=O(Y)} and {X=o(Y)} is true”.")

#text("Doesn’t X=o(Y) imply X=O(Y) by your definition? Maybe it should be changed to “exactly one of {Y=O(|X|)} and {X=o(Y)} is true”.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fa8e0026304bde0f0335731a84ccbdbd60b2de97830af815694eae4db91ec8ea-3cf2a76b6c008bca6d7c5aa49697694f074fc6a07bc98dca6b68efdb2d60ac2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brad")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44283")[#strong[#text("brad")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2010")])]

#text("There’s a classical metric theory of asymptotic equidistribution; for example, for any increasing sequence of integers ")#mi("n_1, n_2, ...")#text(", the sequence ")#mi("n_1 \\alpha, n_2 \\alpha , ...")#text(" is equidistributed mod 1 for almost all ")#mi("\\alpha")#text(". Is their any analogue of these results in the single scale case? For instance, one might make the following guess:")

#text("For a fixed sequence of increasing integers ")#mi("n_1, n_2, ...")#text(" and any ")#mi("\\epsilon > 0")#text(", for almost all ")#mi("\\alpha")#text(", there is a sequence ")#mi("\\delta_N")#text(" (depending on ")#mi("\\alpha")#text(") so that ")#mi("\\sum \\delta_N /N^{1/2 + \\epsilon} < +\\infty")#text(" and ")#mi("((n_1 \\alpha, n_2 \\alpha, ..., n_N \\alpha))")#text(" is ")#mi("\\delta_N")#text("-equidistributed for all N.")

#text("If I'm not mistaken this is true in the case that ")#mi("n_k = k")#text(", but there might be other obstructions for less canonical sequences. (There is also another motivation, by analogy to Carleson's theorem, using partial summation.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2010")])]

#text("It seems quite likely that most of the classical results of asymptotic equidistribution have more quantitative single-scale counterparts, but the literature of the latter is much sparser currently than that of the former. A very rough rule of thumb is that as long as one avoids the use of the ergodic theorem (which is perhaps the first genuinely asymptotic result that utilises multiple scales), or the use of infinitary topological tools such as closures and compactifications, then asymptotic equidistribution arguments are usually fairly easy to make quantitative (and the bounds are then usually “polynomial” in nature in some sense).")

#text("Note though that the exact value of ")#mi("\\delta_N")#text(" here will be somewhat sensitive to the precise definition of equidistribution. In my notes here, I used a notion based on the Lipschitz norm, but this is not the only possible choice, and if one uses a different quantitative measure of equidistribution, then one might get a different power of ")#mi("N")#text(" showing up. But I would guess that a polynomially quantitative version of the above theorem should probably exist.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 3: Linear patterns « What’s new")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44354")[#strong[#text("254B, Notes 3: Linear patterns « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("[…] for any cyclic group and any subset of that group (analogues of this identity also exist for other finite abelian groups, and to a lesser extent to non-abelian groups also, although that is not the focus of my current discussion). As it turns out, linear Fourier analysis is not able to discern higher order patterns, such as arithmetic progressions of length four; we give some demonstrations of this below the fold, taking advantage of the polynomial recurrence theory from Notes 1. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-44743")[#strong[#text("254B, Lecture Notes 4: Equidistribution of polynomials over finite fields « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2010")])]

#text("[…] starting point for this course (Notes 1) was the study of equidistribution of polynomials from the integers to the unit circle. We now […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-45208")[#strong[#text("254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("[…] theory (which generalises the equidistribution theory of polynomial flows on tori from Notes 1) and show that they are indeed obstructions to the Gowers norm being small. This leads to the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-46596")[#strong[#text("ICM2010 — Lindenstrauss laudatio « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] on it. (That is not the only post of Terry’s on that topic: another I would recommend is this one. More generally, you can click on promising tags such as “Ratner’s theorems” and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-141052")[#strong[#text("Waring’s Problem: Lecture 2 « Theorem of the week")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2012")]

#text("[…] Tao has some notes about equidistribution and Weyl’s inequality on his blog, which give another […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8c2016a95d7871dcb511ae984e701ed78c8c69bcbea8aed09b3f13b3dbc827a-acbdc4f59b530120b45a1ec4380cb421d042b21bae300a1a2688683d5cfce060.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joel Moreira")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-250146")[#strong[#text("Joel Moreira")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2013")])]

#text("Why is Exercise 15 called Szemeredi’s theorem for polynomials? Does it imply Szemeredi’s theorem (or polynomial Szemeredi) in some sense? Thank you.")

#emph[#text("[Exercise reworded to make the connection to Szemeredi’s theorem clearer – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-446798")[#strong[#text("How do you prove that $p(n xi)$ for $xi$ irrational and $p$ a polynomial is uniformly distributed modulo 1? | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2014")]

#text("[…] is a fairly good exposition in Terry Tao’s post, see Corollaries 4-6. Here is a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-447321")[#strong[#text("Convergence of $sum limits_{n=1}^{infty}sin(n^k)/n$ | CL-UAT")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2014")]

#text("[…] So this is ")#tao-fit-display[#mitex("sum_{n=1}^N S_n/(n(n+1)) + S_N/(N+1).")]#text(" The second term goes to zero by Weyl’s polynomial equidistribution theorem. So your question is equivalent to the question of whether $sum s_n/(n(n+1))$ converges. We may as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-454158")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("Can you go through the second-to-last sentence in the proof of Lemma 10 more slowly. Why do you get ")#mi("100\\epsilon N/q")#text(" ?")

#text("I reasoned set has size at most ")#mi("2N/q")#text(" and we need to fit two intervals + a gap which is about 50 times larger.")

#text("Then I reasons the set is at most ")#mi("2N\\epsilon/q")#text(" but that might be false.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-454160")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("The length of each gap is at least ")#mi("0.45/\\varepsilon")#text(" as long as either of the neighbouring intervals, each of which have length at least 1, so the number of integers in each gap is at least ")#mi("\\frac{1}{10\\varepsilon}")#text(" times the number of integers in the neighbouring intervals (one can tighten the factor of 10 a bit if needed, but this is certainly enough of a safety margin to deal with roundoff error). Summing, this shows that the total number of integers in the gaps is at least ")#mi("\\frac{1}{20 \\varepsilon}")#text(" times the total number of integers in the intervals, which gives the claim since there are only about ")#mi("2N/q")#text(" integers in all.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-482348")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2017")])]

#text("I’m having a little trouble with exercise 4: total asymptotic equidistribution seems to be equivalent to")

#mi("\\displaystyle \\frac{1}{N} \\sum_{n \\leq N} e( m \\cdot x(qn + r) ) = o_{N\\to \\infty, m,q,r}(1)")

#text("for any non-zero ")#mi("m")#text(", and any ")#mi("q \\geq 1, r \\geq 0")#text(". Not sure how to connect this to the statement")

#mi("\\frac{1}{N} \\sum_{n \\leq N} e( m \\cdot x(n) + n \\alpha ) = o_{N\\to \\infty, m, \\alpha}(1)")

#text("for rational ")#mi("\\alpha")#text(" without some sort of structural assumption on the sequence ")#mi("x(n)")#text("…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-482349")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2017")])]

#text("Below remark 1:")#linebreak()#text(" “…if {\\alpha} is rational in the sense that {m\\alpha = 0} for some positive integer {m}…”")#linebreak()#text(" Do you mean that {m\\alpha = 0 \\mod 1}?")

#emph[#mi("\\alpha")#text(" is an element of a torus here, not a Euclidean space. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-483057")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2017")])]

#text("Write ")#mi("\\alpha = a/q")#text(". Each natural number ")#mi("n")#text(" can be uniquely expressed as ")#mi("n = qn^{\\prime} + r")#text(" for some ")#mi("0 \\leq r < q")#text(". This can be used to break up sums of the second type into sums of the first type. To go in the reverse direction, one needs to perform a Fourier expansion in ")#mi("{\\bf Z}/q{\\bf Z}")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-482367")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2017")])]

#text("In the second half of exercise 17, should the sequence be ")#mi("O(N^{-1/2})")#text(" equidistributed rather that ")#mi("O(N_0^{-1/2})")#text(" equidistributed?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-482484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 June 2017")])]

#text("In exercise 20, should the condition")

#tao-fit-display[#mitex("1 \\leq H \\leq \\delta^{-C_d} N")]

#text("be replaced with")

#tao-fit-display[#mitex("1 \\leq H \\leq \\delta^{C_d} N")]

#text("instead?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f9292715849af3007dc0ec220dfca13aa33456dd05e207f3fec50d5fc15b84-f8feb5bab40d831d3b0ccece0c5bc908c750cf07ab066484381318e1fc819972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farlabb")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-486834")[#strong[#text("farlabb")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2017")])]

#text("I am trying to understand the proof of proposition 1 (Weyls equidistribution criterion) and I don’t understand the “if” part. I think I am missing something silly, but here it goes: If ")#mi("f_k(y):=e^{2\\pi i k\\cdot y}")#text(" then we have that ")#mi("\\int_{T^d}f_k d\\mu=0")#text(" for ")#mi("k\\neq 0")#text(", so assuming equation (2) we indeed have that (1) holds for such functions. In general, if ")#mi("f(y)=\\sum_{k\\in \\mathbb{Z}^d}c_kf_k(y)")#text(" is any function, then by linearity I get that ")#mi("\\frac {1}{N}\\sum_{n=1}^N\\sum_{k\\in \\mathbb{Z}^d}c_kf_k(x(n))=\\sum_{k\\in \\mathbb{Z}^d}c_k\\frac{1}{N}\\sum_{n=1}^nf_k(x(n))\\rightarrow 0")#text(". So I get that integral of any function on the torus is just 0, which seems weird to me. Could you explain in more detail the limiting argument to me? A lot of thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-486841")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2017")])]

#text("The contribution of ")#mi("k=0")#text(" has to be treated separately. If (1) holds for a sequence of functions ")#mi("f_i")#text(" that tend uniformly to a limit ")#mi("f")#text(", then it is not hard to show that (1) also holds for ")#mi("f")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/47f9292715849af3007dc0ec220dfca13aa33456dd05e207f3fec50d5fc15b84-f8feb5bab40d831d3b0ccece0c5bc908c750cf07ab066484381318e1fc819972.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of farlabb")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-487370")[#strong[#text("farlabb")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2017")])]

#text("Dear prof. Tao, I am having trouble with exercise 4. I do not understand how to show that if ")#mi("x")#text(" is totally asymptotically equidistributed, then ")#mi("\\lim_{N\\rightarrow \\infty} \\frac{1}{N}\\sum_{n=1}^Ne(k\\cdot x(n)+\\alpha n)=0")#text(". Using your hint I could prove the converse to this, but I do not understand how to use your hint (fourier expansion in ")#mi("Z/qZ")#text(" ) to prove this case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-487697")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 October 2017")])]

#text("Fourier expansion is not needed for the converse direction. If ")#mi("\\alpha = a/q")#text(", split up the ")#mi("n")#text(" summation into ")#mi("q")#text(" sums over arithmetic progressions modulo ")#mi("q")#text(" by making a change of variables ")#mi("n = qm + r")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cabdea9e3773cc48ced90571bb8e9a70cf89f94e865cdceca448ee3a4894bba2-acfa815108d4e352043a922171b1e35d9dd97a54bcf76a84b8b8e7872d4e1b75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maths student")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-514271")[#strong[#text("Maths student")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2019")])]

#text("I believe that the uniqueness of the asymptotic equidistribution needs only the easy implication of Riesz’ representation theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-520726")[#strong[#text("Extreme Events Modeling Using Continued Fractions - Data Science Central")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2019")]

#text("[…] being the n-th prime number, or h(n) being an integer power of n (see here and corollary 6 in this tutorial). Then the distribution of the sequence z(n), including its limiting median SQRT(2)/2, is […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-635718")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2021")])]

#text("In Lemma 11, I’m having a hard time figuring out how to identify the pigeon-holed arithmetic progression ")#mi("P")#text(", which lives inside ")#mi("[N]")#text(", with the progression ")#mi("[N^{\\prime}]")#text(", where ")#mi("N^{\\prime}")#text(" is the length of ")#mi("P")#text(". My concern is that we are translating ")#mi("P")#text(" by a constant on the order of ")#mi("N")#text(",")#linebreak()#text(" ")#mi("P = \\{ r_0 + l k : l \\leq N^{\\prime} \\}")#linebreak()#text(" but identifying ")#mi("P")#text(" with ")#mi("N^{\\prime}")#text(" seems to discount the effect of the shift by ")#mi("r_0")#text(", which would change the coefficients of the relevant polynomial")#linebreak()#text(" ")#mi("l \\mapsto p(r_0 +lk)")#text(" has different coefficients that ")#mi("n \\mapsto p(n)")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-636226")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2021")])]

#text("The stated conclusion of Lemma 11 is invariant with respect to these shifts (the powers of ")#mi("N")#text(" that show up cancel each other out).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6151aa379f338bffdaf264c1c7edff99b085c752ffa28b30d7d6df67fd97e6e8-1baeb4109d375378053065f98f8e5f237b9768612299c333fa2962f305717fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Novice")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-637539")[#strong[#text("Novice")]]#text(size: 9pt, fill: rgb("596477"), " · 26 November 2021")])]

#text("Dear Prof Tao,")

#text("In the statement of the Proposition 3, we have that ")#mi("x^{\\prime}(n)")#text(" is totally asymptotically equidistributed on ")#mi("\\mathbf{Z}")#text(" in a **subtorus** ")#mi("T^{\\prime}")#text(" of ")#mi("T")#text(". How is this **subtorus** defined?")

#text("In the proof of proposition we have defined the subtorus ")#mi("T_1")#text(" and then we apply induction hypothesis, but no where it is described how subtorus ")#mi("T^{\\prime}")#text(" is defined?")

#text("Can you please elaborate on this? Thankyou!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-637651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2021")])]

#text("The subtorus ")#mi("T^{\\prime}")#text(" is constructed recursively. After identifying ")#mi("T")#text(" with ")#mi("{\\bf T}^d")#text(", there are two cases. If ")#mi("\\alpha")#text(" is irrational, then Exercise 5 lets us take ")#mi("T^{\\prime} = {\\bf T}^d")#text(". Otherwise, we take ")#mi("T^{\\prime}")#text(" to be whatever subtorus was recursively assigned to ")#mi("T_1")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6151aa379f338bffdaf264c1c7edff99b085c752ffa28b30d7d6df67fd97e6e8-1baeb4109d375378053065f98f8e5f237b9768612299c333fa2962f305717fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Novice")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-637756")[#strong[#text("Novice")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2021")])]

#text("Dear Prof Tao,")

#text("Also, can you please explain how are we able to apply induction hypothesis to the subtorus ")#mi("T_1")#text(" ?")

#text("To apply induction hypothesis we need ")#mi("T_1")#text(" to have dimension less than the dimension of ")#mi("T")#text(" since we assumed that such a decomposition exists for tori of smaller dimension.")

#text("But I don’t see why the subtorus ")#mi("T_1")#text(" of ")#mi("T")#text(" has dimension less than d (=dimension of ")#mi("T = \\mathbf{T}^d")#text(")")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-637979")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2021")])]

#text("The dimension of a torus is equal to the dimension of its tangent space at the origin. The tangent space of ")#mi("T_1")#text(" at the origin is a linear subspace of the tangent space ")#mi("{\\bf R}^d")#text(" of ")#mi("T = {\\bf T}^d")#text(" that cannot be all of ")#mi("{\\bf R}^d")#text(" (since the exponential map would then make ")#mi("T_1")#text(" equal to ")#mi("T")#text("), so it has dimension at most ")#mi("d-1")#text(".")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-638306")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2021")])]

#text("Can I get a hint with Exercises 23/24? I can approximate the set by a Fejer kernel argument, so it looks like I’m interested in analyzing quantities like")

#tao-math("\\mathbf{E}_{[N]} \\mathbf{E}_{B} (1 - \\left|\\frac{k}{B}\\right|)_+ \\cdot e(kP(n))", block: false)

#text("(or take the expectation of arithmetic progressions). I can see an upper bound in terms of a maximum of")

#mi("(1 + M +N +B)^{-\\theta}, \\; \\; \\; 0 < \\theta")

#text("where")

#mi("M")

#text("is the minimal “stopping time” that ")#mi("P_{EQ} = 0")#text(" using a polynomial growth function")

#mi("F(M) = C M^C")#text(".")

#text("But, I’m having trouble with the lower bound. Any hints?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-638312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2021")])]

#text("Ah, a single AP does the job")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6151aa379f338bffdaf264c1c7edff99b085c752ffa28b30d7d6df67fd97e6e8-1baeb4109d375378053065f98f8e5f237b9768612299c333fa2962f305717fd0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Novice")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-639055")[#strong[#text("Novice")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2022")])]

#text("Dear Prof. Tao,")

#text("Can you please give some explaination on how to proceed for exercise 17? I am unable to bound the difference by ")#tao-math("O(\\frac{1}{N_0})*\\left|\\left|f_{Lip}\\right|\\right|", block: false)#text(" for the case when ")#mi("N")#text(" is a multiple of ")#mi("N_0")#text(" (from the definition of ")#mi("\\delta")#text("-equidistribution) . Similarly I am not unable to bound the difference for the case when ")#mi("N \\geq N_0^2")#text(".")

#emph[#text("[Try the case ")#mi("N=N_0")#text(" first. Think about why a Riemann sum of a Lipschitz function is close to the Riemann integral. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-693265")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("It seems that Proposition 1 conveys something somewhat similar to Lévy’s continuity theorem. But I don’t know whether this connection is precise, and is such a connection useful?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/03/28/254b-notes-1-equidistribution-of-polynomial-sequences-in-torii/#comment-693272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2026")])]

#text("Yes, these are very similar theorems, and could probably be unified in some suitable abstract harmonic analysis framework involving the Fourier transform on an arbitrary locally compact abelian group.")
]
]
