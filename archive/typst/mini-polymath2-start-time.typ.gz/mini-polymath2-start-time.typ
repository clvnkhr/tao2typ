// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/06/27/mini-polymath2-start-time/
// Converted to Typst by tao2typ: "2026-10-14T08:59:40.461877+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Mini-polymath2 start time", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Mini-polymath2 start time")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 June 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/06/27/mini-polymath2-start-time/")[#text("https://terrytao.wordpress.com/2010/06/27/mini-polymath2-start-time/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In view of feedback, I have decided to start the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Imo_2010")[#text("mini-polymath2 project")]#text(" at ")#link("http://www.timeanddate.com/worldclock/fixedtime.html?year=2010&month=7&day=8&hour=16&min=0&sec=0&p1=0 16:00 UTC July 8")[#text("16:00 July 8 UTC")]#text(", at which time I will select one of the ")#link("http://www.imo2010org.kz/")[#text("2010 IMO")]#text(" questions to solve. The actual project will be run on the ")#link("http://polymathprojects.org/")[#text("polymath blog")]#text("; this blog will host the discussion threads and post-experiment analysis.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (3)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6e67010639132cd3578d4d9f8615ea08ee844a5acdcb885d3728638165b04bf8-2c870f2026246c69813eee1d4721f755de625663ea00ea21e899fc1d3e926595.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. Buchanan")]], [#link("https://terrytao.wordpress.com/2010/06/27/mini-polymath2-start-time/#comment-45800")[#strong[#text("D. Buchanan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2010")])]

#text("There is another forum set up to discuss the IMO questions at")

#link("http://www.artofproblemsolving.com/Forum/viewforum.php?f=644")[#text("http://www.artofproblemsolving.com/Forum/viewforum.php?f=644")]

#text("There is obviously nothing there yet, but there will be soon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/06/27/mini-polymath2-start-time/#comment-45841")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2010")])]

#text("I suggest strongly that anybody interested in joining the polymath does NOT visit that link.")#linebreak()#text(" The questions are directly followed by answers and attempts at answers.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2010/06/27/mini-polymath2-start-time/#comment-575590")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 19 July 2020")])]

#text("Did the mini polymath project stop ? Or, is there a possibility that it will begin once more, if we find good quality problems ?")
]
