// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/
// Converted to Typst by tao2typ: "2026-10-14T16:39:24.451815+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A random variable visualizer", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A random variable visualizer")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 July 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/")[#text("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("With the advent of modern coding agents, many visualization projects that I had proposed in the past, but dropped due to the time and complexity of the coding portion of the task, have now become relatively feasible, in that a reasonable quality prototype (suitable for non-mission-critical tasks such as providing secondary visual aids, where it is not absolutely necessary that the product is 100% bug-free) can now be generated in a matter of hours using such tools. I don’t immediately plan to work on my entire backlog of such projects, but I did spend a few hours this weekend on one such project, namely the proposal from ")#link("https://terrytao.wordpress.com/2016/05/13/visualising-random-variables/")[#text("this 2016 blog post")]#text(" to visualize random variables as animated quantities, which can be either viewed numerically or displayed as a scatterplot. After some ")#link("https://teorth.github.io/tao-web/apps/random-variables-making-of.html")[#text("back and forth with the coding agent")]#text(", I was able to come up with ")#link("https://teorth.github.io/tao-web/apps/random-variables.html")[#text("a working app")]#text(". Here is a screenshot of the app displaying a visualization of ")#link("https://en.wikipedia.org/wiki/Berkson%27s_paradox")[#text("Berkson’s paradox")]#text(", which asserts that independent variables can become correlated to each other after applying a conditioning:")

#align(center)[
#link("https://terrytao.wordpress.com/wp-content/uploads/2026/07/image-3.png")[#image("../assets/e6b8530f372fbee3873650fe7cc857856971da5ecd290ee9b0c54994f4919f25-076a15e7238df47d09db56aee66784f9bb8eb37c846cc7078e62c3ace069ee80.png", width: 90%)]
]

#text("The app in fact is a “compiler” for a small, custom programming language (think of a simplified hybrid of Python and Excel) which allows for the introduction of random variables, manipulates them through operations such as arithmetic operations or conditioning, and then plots them as animations or as text. (The screenshot above is static, but when the app is live, it will update at the indicated speed.)")

#text("As always, I would be happy to receive feedback on the app, which I hope can be useful as a visual aid to understand basic probabilistic concepts such as independence or conditioning.")

#heading(level: 1)[#text("Comments (7)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0abfe11b36bd5996d6de04408952903069000f45c94f845d143ca49fdc800a14-5f700e884bdd38666bc18eadfb2e3ff5aef7e64848a86065b5e5b730a3d38fb9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathan Clisby")]], [#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/#comment-693345")[#strong[#text("Nathan Clisby")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("Thanks for this! It is a great tool for exploring and understanding random variables, and I particularly like the fact that you’ve implemented a little language that allows people to experiment on their own.")

#text("I’ve dabbled a bit with creating interactive visualisations via LLMs – projects that would be infeasible just due to the time commitment suddenly become achievable and fun. I think that these sorts of custom tools can be really useful for research (depending on the topic), communication, teaching (for use in lectures), and learning (for student exploration, where “students” might be other researchers).")

#text("(I’ll add that I think the link for “a working app” was probably meant to be: ")#link("https://teorth.github.io/tao-web/apps/random-variables.html")[#text("https://teorth.github.io/tao-web/apps/random-variables.html")]#text(" )")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/#comment-693346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2026")])]

#text("The link to the app should be ")#link("https://teorth.github.io/tao-web/apps/random-variables.html")[#text("https://teorth.github.io/tao-web/apps/random-variables.html")]

#text("Cheers,")#linebreak()#text("Paul Dyson")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/#comment-693360")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Great tool. One idea that popped is that if it were implemented as a Python notebook, it would be “open” for further hacking for the students and also “explorable”, allowing to dig into the details underneath.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/#comment-693370")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("Good suggestion! After some further interaction with the coding agent (recorded at the end of ")#link("https://teorth.github.io/tao-web/apps/random-variables-making-of.html")[#text("this log")]#text(", if you are interested), I’ve now implemented the ability to “export” any program in this visualizer tool (including any of the preset examples) into a self-contained Python file that gives a (static) rendering of the statistics and plots that the visualizer does. A decent student with some Python background should be able to modify that exported file to create further visualizations of the data.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/#comment-693373")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2026")])]

#text("thanks，🐟🐟")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/#comment-693425")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2026")])]

#text("Wow I like this app!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/07/12/a-random-variable-visualizer/#comment-693442")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2026")])]

#text("Reminds me of Squiggle! ")#link("https://www.squiggle-language.com/")[#text("https://www.squiggle-language.com/")]#linebreak()#text("In a good way.")
]
