// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/
// Converted to Typst by tao2typ: "2026-10-14T16:37:32.714750+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Supplement 2: A little bit of complex and Fourier analysis", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Supplement 2: A little bit of complex and Fourier analysis")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 5 December 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")[#text("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We will shortly turn to the complex-analytic approach to multiplicative number theory, which relies on the basic properties of ")#link("http://en.wikipedia.org/wiki/Analytic_function")[#text("complex analytic functions")]#text(". In this supplement to the main notes, we quickly review the portions of complex analysis that we will be using in this course. We will not attempt a comprehensive review of this subject; for instance, we will completely neglect the ")#link("http://en.wikipedia.org/wiki/Conformal_geometry")[#text("conformal geometry")]#text(" or ")#link("http://en.wikipedia.org/wiki/Riemann_surface")[#text("Riemann surface")]#text(" aspect of complex analysis, and we will also avoid using the various boundary convergence theorems for Taylor series or Dirichlet series (the latter type of result is traditionally utilised in multiplicative number theory, but I personally find them a little unintuitive to use, and will instead rely on a slightly different set of complex-analytic tools). We will also focus on the “local” structure of complex analytic functions, in particular adopting the philosophy that such functions behave locally like complex polynomials; the classical “global” theory of entire functions, while traditionally used in the theory of the Riemann zeta function, will be downplayed in these notes. On the other hand, we will play up the relationship between complex analysis and Fourier analysis, as we will incline to using the latter tool over the former in some of the subsequent material. (In the traditional approach to the subject, the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]#text(" is used in place of the Fourier transform, but we will not emphasise the role of the Mellin transform here.)")

#text("We begin by recalling the notion of a ")#link("http://en.wikipedia.org/wiki/Holomorphic_function")[#text("holomorphic function")]#text(", which will later be shown to be essentially synonymous with that of a ")#link("http://en.wikipedia.org/wiki/Analytic_function")[#text("complex analytic function")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Holomorphic function)")]#text(" Let ")#mi("{\\Omega}")#text(" be an open subset of ")#mi("{{\\bf C}}")#text(", and let ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" be a function. If ")#mi("{z \\in {\\bf C}}")#text(", we say that ")#mi("{f}")#text(" is ")#emph[#text("complex differentiable")]#text(" at ")#mi("{z}")#text(" if the limit")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}(z) := \\lim_{h \\rightarrow 0; h \\in {\\bf C} \\backslash \\{0\\}} \\frac{f(z+h)-f(z)}{h}")]]

#text("exists, in which case we refer to ")#mi("{f^{\\prime}(z)}")#text(" as the (complex) ")#emph[#text("derivative")]#text(" of ")#mi("{f}")#text(" at ")#mi("{z}")#text(". If ")#mi("{f}")#text(" is differentiable at every point ")#mi("{z}")#text(" of ")#mi("{\\Omega}")#text(", and the derivative ")#mi("{f^{\\prime}: \\Omega \\rightarrow {\\bf C}}")#text(" is continuous, we say that ")#mi("{f}")#text(" is ")#emph[#text("holomorphic")]#text(" on ")#mi("{\\Omega}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that a function ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" is holomorphic if and only if the two-variable function ")#mi("{(x,y) \\mapsto f(x+iy)}")#text(" is continuously differentiable on ")#mi("{\\{ (x,y) \\in {\\bf R}^2: x+iy \\in \\Omega\\}}")#text(" and obeys the ")#link("http://en.wikipedia.org/wiki/Cauchy%E2%80%93Riemann_equations")[#text("Cauchy-Riemann equation")]#text(" ")#metadata(none) <tao-2b6bdfb2a0c30eaf5b7e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{\\partial}{\\partial x} f(x+iy) = \\frac{1}{i} \\frac{\\partial}{\\partial y} f(x+iy).")]]
]

#text("Basic examples of holomorphic functions include complex polynomials")

#align(center)[#tao-fit-display[#mitex("P(z) = a_n z^n + \\dots + a_1 z + a_0")]]

#text("as well as the complex exponential function")

#align(center)[#tao-fit-display[#mitex("\\exp(z) := \\sum_{n=0}^\\infty \\frac{z^n}{n!}")]]

#text("which are holomorphic on the entire complex plane ")#mi("{{\\bf C}}")#text(" (i.e., they are ")#link("http://en.wikipedia.org/wiki/Entire_function")[#text("entire functions")]#text("). The sum or product of two holomorphic functions is again holomorphic; the quotient of two holomorphic functions is holomorphic so long as the denominator is non-zero. Finally, the composition of two holomorphic functions is holomorphic wherever the composition is defined.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-2bec6b1747db8bd1a7bb>

#list(
[#text("(i) Establish ")#link("http://en.wikipedia.org/wiki/Euler%27s_formula")[#text("Euler’s formula")]

#align(center)[#tao-fit-display[#mitex("\\exp(x+iy) = e^x (\\cos y + i \\sin y)")]]

#text("for all ")#mi("{x,y \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" it is a bit tricky to do this starting from the trigonometric definitions of sine and cosine; I recommend either using the Taylor series formulations of these functions instead, or alternatively relying on the ordinary differential equations obeyed by sine and cosine.)")],
[#text("(ii) Show that every non-zero complex number ")#mi("{z}")#text(" has a ")#link("http://en.wikipedia.org/wiki/Complex_logarithm")[#text("complex logarithm")]#text(" ")#mi("{\\log(z)}")#text(" such that ")#mi("{\\exp(\\log(z))=z}")#text(", and that this logarithm is unique up to integer multiples of ")#mi("{2\\pi i}")#text(".")],
[#text("(iii) Show that there exists a unique ")#link("http://en.wikipedia.org/wiki/Principal_branch")[#text("principal branch")]#text(" ")#mi("{\\text{Log}(z)}")#text(" of the complex logarithm in the region ")#mi("{{\\bf C} \\backslash (-\\infty,0]}")#text(", defined by requiring ")#mi("{\\text{Log}(z)}")#text(" to be a logarithm of ")#mi("{z}")#text(" with imaginary part between ")#mi("{-\\pi}")#text(" and ")#mi("{\\pi}")#text(". Show that this principal branch is holomorphic with derivative ")#mi("{1/z}")#text(".")]
)
]

#text("In real analysis, we have the fundamental theorem of calculus, which asserts that")

#align(center)[#tao-fit-display[#mitex("\\int_a^b F^{\\prime}(t)\\ dt = F(b) - F(a)")]]

#text("whenever ")#mi("{[a,b]}")#text(" is a real interval and ")#mi("{F: [a,b] \\rightarrow {\\bf R}}")#text(" is a continuously differentiable function. The complex analogue of this fact is that ")#metadata(none) <tao-d12991253498ebd95339>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\int_\\gamma F^{\\prime}(z)\\ dz = F(\\gamma(1)) - F(\\gamma(0))")]]

#text("whenever ")#mi("{F: \\Omega \\rightarrow {\\bf C}}")#text(" is a holomorphic function, and ")#mi("{\\gamma: [0,1] \\rightarrow \\Omega}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Methods_of_contour_integration")[#text("contour")]#text(" in ")#mi("{\\Omega}")#text(", by which we mean a piecewise continuously differentiable function, and the ")#link("http://en.wikipedia.org/wiki/Methods_of_contour_integration")[#text("contour integral")]#text(" ")#mi("{\\int_\\gamma f(z)\\ dz}")#text(" for a continuous function ")#mi("{f}")#text(" is defined via change of variables as")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z)\\ dz := \\int_0^1 f(\\gamma(t)) \\gamma^{\\prime}(t)\\ dt.")]]

#text("The complex fundamental theorem of calculus ")#link(<tao-d12991253498ebd95339>)[#text("(2)")]#text(" follows easily from the real fundamental theorem and the chain rule.")

#text("In real analysis, we have the rather trivial fact that the integral of a continuous function on a closed contour is always zero:")

#align(center)[#tao-fit-display[#mitex("\\int_a^b f(t)\\ dt + \\int_b^a f(t)\\ dt = 0.")]]

#text("In complex analysis, the analogous fact is significantly more powerful, and is known as ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_integral_theorem")[#text("Cauchy’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Cauchy’s theorem)")]#text(" Let ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" be a holomorphic function in a simply connected open set ")#mi("{\\Omega}")#text(", and let ")#mi("{\\gamma: [0,1] \\rightarrow \\Omega}")#text(" be a closed contour in ")#mi("{\\Omega}")#text(" (thus ")#mi("{\\gamma(1)=\\gamma(0)}")#text("). Then ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Use Stokes’ theorem to give a proof of Cauchy’s theorem.")
]

#text("A useful reformulation of Cauchy’s theorem is that of contour shifting: if ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" is a holomorphic function on a open set ")#mi("{\\Omega}")#text(", and ")#mi("{\\gamma, \\tilde \\gamma}")#text(" are two contours in an open set ")#mi("{\\Omega}")#text(" with ")#mi("{\\gamma(0)=\\tilde \\gamma(0)}")#text(" and ")#mi("{\\gamma(1) = \\tilde \\gamma(1)}")#text(", such that ")#mi("{\\gamma}")#text(" can be continuously deformed into ")#mi("{\\tilde \\gamma}")#text(", then ")#mi("{\\int_\\gamma f(z)\\ dz = \\int_{\\tilde \\gamma} f(z)\\ dz}")#text(". A basic application of contour shifting is the ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_integral_formula")[#text("Cauchy integral formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Cauchy integral formula)")]#text(" Let ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" be a holomorphic function in a simply connected open set ")#mi("{\\Omega}")#text(", and let ")#mi("{\\gamma: [0,1] \\rightarrow \\Omega}")#text(" be a closed contour which is simple (thus ")#mi("{\\gamma}")#text(" does not traverse any point more than once, with the exception of the endpoint ")#mi("{\\gamma(0)=\\gamma(1)}")#text(" that is traversed twice), and which encloses a bounded region ")#mi("{U}")#text(" in the anticlockwise direction. Then for any ")#mi("{z_0 \\in U}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz= 2\\pi i f(z_0).")]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{\\varepsilon > 0}")#text(" be a sufficiently small quantity. By contour shifting, one can replace the contour ")#mi("{\\gamma}")#text(" by the sum (concatenation) of three contours: a contour ")#mi("{\\rho}")#text(" from ")#mi("{\\gamma(0)}")#text(" to ")#mi("{z_0+\\varepsilon}")#text(", a contour ")#mi("{C_\\varepsilon}")#text(" traversing the circle ")#tao-math("{\\{z: \\left|z-z_0\\right|=\\varepsilon\\}}", block: false)#text(" once anticlockwise, and the reversal ")#mi("{-\\rho}")#text(" of the contour ")#mi("{\\rho}")#text(" that goes from ")#mi("{z_0+\\varepsilon}")#text(" to ")#mi("{\\gamma_0}")#text(". The contributions of the contours ")#mi("{\\rho, -\\rho}")#text(" cancel each other, thus")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma \\frac{f(z)}{z-z_0}\\ dz = \\int_{C_\\varepsilon} \\frac{f(z)}{z-z_0}\\ dz.")]]

#text("By a change of variables, the right-hand side can be expanded as")

#align(center)[#tao-fit-display[#mitex("2\\pi i \\int_0^1 f(z_0 + \\varepsilon e^{2\\pi i t})\\ dt.")]]

#text("Sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(", we obtain the claim. ")#mi("\\Box")

#text("The Cauchy integral formula has many consequences. Specialising to the case when ")#mi("{\\gamma}")#text(" traverses a circle ")#tao-math("{\\{ z: \\left|z-z_0\\right|=r\\}}", block: false)#text(" around ")#mi("{z_0}")#text(", we conclude the mean value property ")#metadata(none) <tao-82523faea1b0f2da676a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("f(z_0) = \\int_0^1 f(z_0 + re^{2\\pi i t})\\ dt")]]

#text("whenever ")#mi("{f}")#text(" is holomorphic in a neighbourhood of the disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(". In a similar spirit, we have the ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(" for holomorphic functions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Maximum principle)")]#text(" ")#metadata(none) <tao-9baf3a40312f39849f46>#text(" Let ")#mi("{\\Omega}")#text(" be a simply connected open set, and let ")#mi("{\\gamma}")#text(" be a simple closed contour in ")#mi("{\\Omega}")#text(" enclosing a bounded region ")#mi("{U}")#text(" anti-clockwise. Let ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" be a holomorphic function. If we have the bound ")#tao-math("{\\left|f(z)\\right| \\leq M}", block: false)#text(" for all ")#mi("{z}")#text(" on the contour ")#mi("{\\gamma}")#text(", then we also have the bound ")#tao-math("{\\left|f(z_0)\\right| \\leq M}", block: false)#text(" for all ")#mi("{z_0 \\in U}")#text(".")
]

#emph[#text("Proof:")]#text(" We use an argument of Landau. Fix ")#mi("{z_0 \\in U}")#text(". From the Cauchy integral formula and the triangle inequality we have the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z_0)\\right| \\leq C_{z_0,\\gamma} M", block: true)]]

#text("for some constant ")#mi("{C_{z_0,\\gamma} > 0}")#text(" depending on ")#mi("{z_0}")#text(" and ")#mi("{\\gamma}")#text(". This ostensibly looks like a weaker bound than what we want, but we can miraculously make the constant ")#mi("{C_{z_0,\\gamma}}")#text(" disappear by the “")#link("https://terrytao.wordpress.com/2007/09/05/amplification-arbitrage-and-the-tensor-power-trick/")[#text("tensor power trick")]#text("“. Namely, observe that if ")#mi("{f}")#text(" is a holomorphic function bounded in magnitude by ")#mi("{M}")#text(" on ")#mi("{\\gamma}")#text(", and ")#mi("{n}")#text(" is a natural number, then ")#mi("{f^n}")#text(" is a holomorphic function bounded in magnitude by ")#mi("{M^n}")#text(" on ")#mi("{\\gamma}")#text(". Applying the preceding argument with ")#mi("{f, M}")#text(" replaced by ")#mi("{f^n, M^n}")#text(" we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z_0)\\right|^n \\leq C_{z_0,\\gamma} M^n", block: true)]]

#text("and hence")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z_0)\\right| \\leq C_{z_0,\\gamma}^{1/n} M.", block: true)]]

#text("Sending ")#mi("{n \\rightarrow \\infty}")#text(", we obtain the claim. ")#mi("\\Box")

#text("Another basic application of the integral formula is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 8")]#text(" ")#metadata(none) <tao-f8dcb34308e5c69f46a3>#text(" Every holomorphic function ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" is complex analytic, thus it has a convergent Taylor series around every point ")#mi("{z_0}")#text(" in the domain. In particular, holomorphic functions are smooth, and the derivative of a holomorphic function is again holomorphic.")
]

#text("Conversely, it is easy to see that complex analytic functions are holomorphic. Thus, the terms “complex analytic” and “holomorphic” are synonymous, at least when working on open domains. (On a non-open set ")#mi("{\\Omega}")#text(", saying that ")#mi("{f}")#text(" is analytic on ")#mi("{\\Omega}")#text(" is equivalent to asserting that ")#mi("{f}")#text(" extends to a holomorphic function of an open neighbourhood of ")#mi("{\\Omega}")#text(".) This is in marked contrast to real analysis, in which a function can be continuously differentiable, or even smooth, without being real analytic.")

#emph[#text("Proof:")]#text(" By translation, we may suppose that ")#mi("{z_0=0}")#text(". Let ")#mi("{C_r}")#text(" be a a contour traversing the circle ")#tao-math("{\\{ z: \\left|z\\right|=r\\}}", block: false)#text(" that is contained in the domain ")#mi("{\\Omega}")#text(", then by the Cauchy integral formula one has")

#align(center)[#tao-fit-display[#mitex("f(z) = \\frac{1}{2\\pi i} \\int_{C_r} \\frac{f(w)}{w-z}\\ dw")]]

#text("for all ")#mi("{z}")#text(" in the disk ")#tao-math("{\\{ z: \\left|z\\right| < r \\}}", block: false)#text(". As ")#mi("{f}")#text(" is continuously differentiable (and hence continuous) on ")#mi("{C_r}")#text(", it is bounded. From the geometric series formula")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{w-z} = \\frac{1}{w} + \\frac{1}{w^2} z + \\frac{1}{w^3} z^2 + \\dots")]]

#text("and dominated convergence, we conclude that")

#align(center)[#tao-fit-display[#mitex("f(z) = \\sum_{n=0}^\\infty (\\frac{1}{2\\pi i} \\int_{C_r} \\frac{f(w)}{w^{n+1}}\\ dw) z^n")]]

#text("with the right-hand side an absolutely convergent series for ")#tao-math("{\\left|z\\right| < r}", block: false)#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Establish the generalised Cauchy integral formulae")

#align(center)[#tao-fit-display[#mitex("f^{(k)}(z_0) = \\frac{k!}{2\\pi i} \\int_\\gamma \\frac{f(z)}{(z-z_0)^{k+1}}\\ dz")]]

#text("for any non-negative integer ")#mi("{k}")#text(", where ")#mi("{f^{(k)}}")#text(" is the ")#mi("{k}")#text("-fold complex derivative of ")#mi("{f}")#text(".")
]

#text("This in turn leads to a converse to Cauchy’s theorem, known as ")#link("http://en.wikipedia.org/wiki/Morera%27s_theorem")[#text("Morera’s theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 10 (Morera’s theorem)")]#text(" ")#metadata(none) <tao-e678ac9196f5bddb34ad>#text(" Let ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(" be a continuous function on an open set ")#mi("{\\Omega}")#text(" with the property that ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for all closed contours ")#mi("{\\gamma: [0,1] \\rightarrow \\Omega}")#text(". Then ")#mi("{f}")#text(" is holomorphic.")
]

#emph[#text("Proof:")]#text(" We can of course assume ")#mi("{\\Omega}")#text(" to be non-empty and connected (hence path-connected). Fix a point ")#mi("{z_0 \\in \\Omega}")#text(", and define a “primitive” ")#mi("{F: \\Omega \\rightarrow {\\bf C}}")#text(" of ")#mi("{f}")#text(" by defining ")#mi("{F(z_1) = \\int_\\gamma f(z)\\ dz}")#text(", with ")#mi("{\\gamma: [0,1] \\rightarrow \\Omega}")#text(" being any contour from ")#mi("{z_0}")#text(" to ")#mi("{z_1}")#text(" (this is well defined by hypothesis). By mimicking the proof of the real fundamental theorem of calculus, we see that ")#mi("{F}")#text(" is holomorphic with ")#mi("{F^{\\prime}=f}")#text(", and the claim now follows from Corollary ")#link(<tao-f8dcb34308e5c69f46a3>)[#text("8")]#text(". ")#mi("\\Box")

#text("An important consequence of Morera’s theorem for us is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 11 (Locally uniform limit of holomorphic functions is holomorphic)")]#text(" Let ")#mi("{f_n: \\Omega \\rightarrow {\\bf C}}")#text(" be holomorphic functions on an open set ")#mi("{\\Omega}")#text(" which converge locally uniformly to a function ")#mi("{f: \\Omega \\rightarrow {\\bf C}}")#text(". Then ")#mi("{f}")#text(" is also holomorphic on ")#mi("{\\Omega}")#text(".")
]

#emph[#text("Proof:")]#text(" By working locally we may assume that ")#mi("{\\Omega}")#text(" is a ball, and in particular simply connected. By Cauchy’s theorem, ")#mi("{\\int_\\gamma f_n(z)\\ dz = 0}")#text(" for all closed contours ")#mi("{\\gamma}")#text(" in ")#mi("{\\Omega}")#text(". By local uniform convergence, this implies that ")#mi("{\\int_\\gamma f(z)\\ dz = 0}")#text(" for all such contours, and the claim then follows from Morera’s theorem. ")#mi("\\Box")

#text("Now we study the zeroes of complex analytic functions. If a complex analytic function ")#mi("{f}")#text(" vanishes at a point ")#mi("{z_0}")#text(", but is not identically zero in a neighbourhood of that point, then by Taylor expansion we see that ")#mi("{f}")#text(" factors in a sufficiently small neighbourhood of ")#mi("{z_0}")#text(" as ")#metadata(none) <tao-41a093100bbbb59e31dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f(z) = (z-z_0)^n g(z_0)")]]

#text("for some natural number ")#mi("{n}")#text(" (which we call the ")#emph[#text("order")]#text(" or ")#emph[#text("multiplicity")]#text(" of the zero at ")#mi("{f}")#text(") and some function ")#mi("{g}")#text(" that is complex analytic and non-zero near ")#mi("{z_0}")#text("; this generalises the ")#link("http://en.wikipedia.org/wiki/Factor_theorem")[#text("factor theorem")]#text(" for polynomials. In particular, the zero ")#mi("{z_0}")#text(" is isolated if ")#mi("{f}")#text(" does not vanish identically near ")#mi("{z_0}")#text(". We conclude that if ")#mi("{\\Omega}")#text(" is connected and ")#mi("{f}")#text(" vanishes on a neighbourhood of some point ")#mi("{z_0}")#text(" in ")#mi("{\\Omega}")#text(", then it must vanish on all of ")#mi("{\\Omega}")#text(" (since the maximal connected neighbourhood of ")#mi("{z_0}")#text(" in ")#mi("{\\Omega}")#text(" on which ")#mi("{f}")#text(" vanishes cannot have any boundary point in ")#mi("{\\Omega}")#text("). This implies ")#link("http://en.wikipedia.org/wiki/Identity_theorem")[#text("unique continuation")]#text(" of analytic functions: if two complex analytic functions on ")#mi("{\\Omega}")#text(" agree on a non-empty open set, then they agree everywhere. In particular, if a complex analytic function does not vanish everywhere, then all of its zeroes are isolated, so in particular it has only finitely many zeroes on any given compact set.")

#text("Recall that a rational function is a function ")#mi("{f}")#text(" which is a quotient ")#mi("{g/h}")#text(" of two polynomials (at least outside of the set where ")#mi("{h}")#text(" vanishes). Analogously, let us define a ")#link("http://en.wikipedia.org/wiki/Meromorphic_function")[#text("meromorphic function")]#text(" on an open set ")#mi("{\\Omega}")#text(" to be a function ")#mi("{f: \\Omega \\backslash S \\rightarrow {\\bf C}}")#text(" defined outside of a discrete subset ")#mi("{S}")#text(" of ")#mi("{\\Omega}")#text(" (the ")#emph[#text("singularities")]#text(" of ")#mi("{f}")#text("), which is locally the quotient ")#mi("{g/h}")#text(" of holomorphic functions, in the sense that for every ")#mi("{z_0 \\in \\Omega}")#text(", one has ")#mi("{f=g/h}")#text(" in a neighbourhood of ")#mi("{z_0}")#text(" excluding ")#mi("{S}")#text(", with ")#mi("{g, h}")#text(" holomorphic near ")#mi("{z_0}")#text(" and with ")#mi("{h}")#text(" non-vanishing outside of ")#mi("{S}")#text(". If ")#mi("{z_0 \\in S}")#text(" and ")#mi("{g}")#text(" has a zero of equal or higher order than ")#mi("{h}")#text(" at ")#mi("{z_0}")#text(", then the singularity is ")#link("http://en.wikipedia.org/wiki/Removable_singularity")[#text("removable")]#text(" and one can extend the meromorphic function holomorphically across ")#mi("{z_0}")#text(" (by the holomorphic factor theorem ")#link(<tao-41a093100bbbb59e31dc>)[#text("(4)")]#text("); otherwise, the singularity is non-removable and is known as a ")#emph[#text("pole")]#text(", whose order is equal to the difference between the order of ")#mi("{h}")#text(" and the order of ")#mi("{g}")#text(" at ")#mi("{z_0}")#text(". (If one wished, one could extend meromorphic functions to the poles by embedding ")#mi("{{\\bf C}}")#text(" in the ")#link("http://en.wikipedia.org/wiki/Riemann_sphere")[#text("Riemann sphere")]#text(" ")#mi("{{\\bf C} \\cup \\{\\infty\\}}")#text(" and mapping each pole to ")#mi("{\\infty}")#text(", but we will not do so here. One could also consider non-meromorphic functions with ")#link("http://en.wikipedia.org/wiki/Essential_singularity")[#text("essential singularities")]#text(" at various points, but we will have no need to analyse such singularities in this course.) If the order of a pole or zero is one, we say that it is ")#emph[#text("simple")]#text("; if it is two, we say it is ")#emph[#text("double")]#text("; and so forth.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Show that the space of meromorphic functions on a non-empty open set ")#mi("{\\Omega}")#text(", quotiented by almost everywhere equivalence, forms a field.")
]

#text("By quotienting two Taylor series, we see that if a meromorphic function ")#mi("{f}")#text(" has a pole of order ")#mi("{n}")#text(" at some point ")#mi("{z_0}")#text(", then it has a Laurent expansion")

#align(center)[#tao-fit-display[#mitex("f = \\sum_{m=-n}^\\infty a_m (z-z_0)^m,")]]

#text("absolutely convergent in a neighbourhood of ")#mi("{z_0}")#text(" excluding ")#mi("{z_0}")#text(" itself, and with ")#mi("{a_{-n}}")#text(" non-zero. The Laurent coefficient ")#mi("{a_{-1}}")#text(" has a special significance, and is called the ")#link("http://en.wikipedia.org/wiki/Residue_(complex_analysis)")[#text("residue")]#text(" of the meromorphic function ")#mi("{f}")#text(" at ")#mi("{z_0}")#text(", which we will denote as ")#mi("{\\text{Res}(f;z_0)}")#text(". The importance of this coefficient comes from the following significant generalisation of the Cauchy integral formula, known as the ")#link("http://en.wikipedia.org/wiki/Residue_theorem")[#text("residue theorem")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13 (Residue theorem)")]#text(" Let ")#mi("{f}")#text(" be a meromorphic function on a simply connected domain ")#mi("{\\Omega}")#text(", and let ")#mi("{\\gamma}")#text(" be a closed contour in ")#mi("{\\Omega}")#text(" enclosing a bounded region ")#mi("{U}")#text(" anticlockwise, and avoiding all the singularities of ")#mi("{f}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\int_\\gamma f(z)\\ dz = 2\\pi i \\sum_\\rho \\text{Res}(f;\\rho)")]]

#text("where ")#mi("{\\rho}")#text(" is summed over all the poles of ")#mi("{f}")#text(" that lie in ")#mi("{U}")#text(".")
]

#text("The residue theorem is particularly useful when applied to ")#link("http://en.wikipedia.org/wiki/Logarithmic_derivative")[#text("logarithmic derivatives")]#text(" ")#mi("{f^{\\prime}/f}")#text(" of meromorphic functions ")#mi("{f}")#text(", because the residue is of a specific form:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{f}")#text(" be a meromorphic function on an open set ")#mi("{\\Omega}")#text(" that does not vanish identically. Show that the only poles of ")#mi("{f^{\\prime}/f}")#text(" are simple poles (poles of order ")#mi("{1}")#text("), occurring at the poles and zeroes of ")#mi("{f}")#text(" (after all removable singularities have been removed). Furthermore, the residue of ")#mi("{f^{\\prime}/f}")#text(" at a pole ")#mi("{z_0}")#text(" is an integer, equal to the order of zero of ")#mi("{f}")#text(" if ")#mi("{f}")#text(" has a zero at ")#mi("{z_0}")#text(", or equal to negative the order of pole at ")#mi("{f}")#text(" if ")#mi("{f}")#text(" has a pole at ")#mi("{z_0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 15")]#text(" The fact that residues of logarithmic derivatives of meromorphic functions are automatically integers is a remarkable feature of the complex analytic approach to multiplicative number theory, which is difficult (though not entirely impossible) to duplicate in other approaches to the subject. Here is a sample application of this integrality, which is challenging to reproduce by non-complex-analytic means: if ")#mi("{f}")#text(" is meromorphic near ")#mi("{z_0}")#text(", and one has the bound ")#tao-math("{\\left|\\frac{f^{\\prime}}{f}(z_0+t)\\right| \\leq \\frac{0.9}{t} + O(1)}", block: false)#text(" as ")#mi("{t \\rightarrow 0^+}")#text(", then ")#mi("{\\frac{f^{\\prime}}{f}}")#text(" must in fact stay bounded near ")#mi("{z_0}")#text(", because the only integer of magnitude less than ")#mi("{0.9}")#text(" is zero.")
]

#metadata(none) <tao-3d1a9e09d678bed2cff8>

#heading(level: 1)[#strong[#text(" — 1. Local approximation of meromorphic functions — ")]]

#text("Suppose ")#mi("{f}")#text(" is a non-zero rational function ")#mi("{f =P/Q}")#text(", then by the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(" (see Exercise ")#link(<tao-943a1abf223ddf833460>)[#text("19")]#text(" below) one can write")

#align(center)[#tao-fit-display[#mitex("f(z) = c \\frac{\\prod_\\rho (z-\\rho)}{\\prod_\\zeta (z-\\zeta)}")]]

#text("for some non-zero constant ")#mi("{c}")#text(", where ")#mi("{\\rho}")#text(" ranges over the zeroes of ")#mi("{P}")#text(" (counting multiplicity) and ")#mi("{\\zeta}")#text(" ranges over the zeroes of ")#mi("{Q}")#text(" (counting multiplicity), and assuming ")#mi("{z}")#text(" avoids the zeroes of ")#mi("{Q}")#text(". Taking absolute values and then logarithms, we arrive at the formula ")#metadata(none) <tao-d69a1f191c8d5a0ce9f6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\log \\left|f(z)\\right| = \\log \\left|c\\right| + \\sum_\\rho \\log\\left|z-\\rho\\right| - \\sum_\\zeta \\log \\left|z-\\zeta\\right|,", block: true)]]

#text("as long as ")#mi("{z}")#text(" avoids the zeroes of both ")#mi("{P}")#text(" and ")#mi("{Q}")#text(". Alternatively, taking logarithmic derivatives, we arrive at the closely related formula ")#metadata(none) <tao-3f2d9b7700a6ece24221>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\frac{f^{\\prime}(z)}{f(z)} = \\sum_\\rho \\frac{1}{z-\\rho} - \\sum_\\zeta \\frac{1}{z-\\zeta},")]]

#text("again for ")#mi("{z}")#text(" avoiding the zeroes of both ")#mi("{P}")#text(" and ")#mi("{Q}")#text(". Thus we see that the zeroes and poles of a rational function ")#mi("{f}")#text(" describe the behaviour of that rational function, as well as close relatives of that function such as the log-magnitude ")#tao-math("{\\log\\left|f\\right|}", block: false)#text(" and log-derivative ")#mi("{\\frac{f^{\\prime}}{f}}")#text(".")

#text("In the complex approach to multiplicative number theory, it is desirable to generalise the above formulae to the case when ")#mi("{f}")#text(" is a meromorphic function rather than a rational one, to understand the extent to which the behaviour of a meromorphic function is controlled by its zeroes and poles. Classically, one achieves this goal by working on the entire complex plane and exploiting the tool of ")#link("http://en.wikipedia.org/wiki/Weierstrass_factorization_theorem")[#text("Weierstrass factorisation")]#text(". However, for most applications in analytic number theory, one can instead work with ")#emph[#text("local")]#text(" factorisations, which are more flexible, removing the need to consider distant poles and zeroes by trading them for a manageable boundary term. The most well known example of such a local factorisation is ")#link("http://en.wikipedia.org/wiki/Jensen%27s_formula")[#text("Jensen’s formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 16 (Jensen’s formula)")]#text(" ")#metadata(none) <tao-c87f42bd454c031b875b>#text(" Let ")#mi("{f}")#text(" be a meromorphic function on an open neighbourhood of a disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(", with all removable singularities removed. Then, if ")#mi("{z_0}")#text(" is neither a zero nor a pole of ")#mi("{f}")#text(", we have ")#metadata(none) <tao-21c9625fc6b6db6a0baf>

#tao-aligned(keep: true)[


#tao-math("\\log \\left|f(z_0)\\right|  & = \\int_0^1 \\log \\left|f(z_0+re^{2\\pi i t})\\right|\\ dt + \\sum_{\\rho: \\left|\\rho-z_0\\right| \\leq r} \\log \\frac{\\left|\\rho-z_0\\right|}{r}", block: true, numbering: n => [#text("(7)")])



#tao-math(" & - \\sum_{\\zeta: \\left|\\zeta-z_0\\right| \\leq r} \\log \\frac{\\left|\\zeta-z_0\\right|}{r}", block: true)
]

#text("where ")#mi("{\\rho}")#text(" and ")#mi("{\\zeta}")#text(" range over the zeroes and poles of ")#mi("{f}")#text(" respectively (counting multiplicity) in the disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r\\}}", block: false)#text(".")
]

#text("One should view ")#link(<tao-21c9625fc6b6db6a0baf>)[#text("(7)")]#text(" as a truncated (or localised) variant of ")#link(<tao-d69a1f191c8d5a0ce9f6>)[#text("(5)")]#text(". Note also that the summands ")#tao-math("{\\log \\frac{\\left|\\rho-z_0\\right|}{r}, \\log \\frac{\\left|\\zeta-z_0\\right|}{r}}", block: false)#text(" are always non-positive.")

#emph[#text("Proof:")]#text(" By perturbing ")#mi("{r}")#text(" slightly if necessary, we may assume that none of the zeroes or poles of ")#mi("{f}")#text(" (which form a discrete set) lie on the boundary circle ")#tao-math("{\\{ z: \\left|z-z_0\\right| = r \\}}", block: false)#text(". By translating and rescaling, we may then normalise ")#mi("{z_0=0}")#text(" and ")#mi("{r=1}")#text(", thus our task is now to show that ")#metadata(none) <tao-3879d6995a5cdfe52e9d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\log \\left|f(0)\\right| = \\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right|\\ dt + \\sum_{\\rho: \\left|\\rho\\right| < 1} \\log \\left|\\rho\\right| - \\sum_{\\zeta: \\left|\\zeta\\right| < 1} \\log \\left|\\zeta\\right|.", block: true)]]

#text("We may remove the poles and zeroes inside the disk ")#tao-math("{\\{ z: \\left|z\\right| < 1 \\}}", block: false)#text(" by the useful device of ")#link("http://en.wikipedia.org/wiki/Blaschke_product")[#text("Blaschke products")]#text(". Suppose for instance that ")#mi("{f}")#text(" has a zero ")#mi("{\\rho}")#text(" inside the disk. Observe that the function ")#metadata(none) <tao-8172b90bd44320037349>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("B_\\rho(z) := \\frac{\\rho - z}{1 - \\overline{\\rho} z}")]]

#text("has magnitude ")#mi("{1}")#text(" on the unit circle ")#tao-math("{\\{ z: \\left|z\\right| = 1\\}}", block: false)#text(", equals ")#mi("{\\rho}")#text(" at the origin, has a simple zero at ")#mi("{\\rho}")#text(", but has no other zeroes or poles inside the disk. Thus Jensen’s formula ")#link(<tao-3879d6995a5cdfe52e9d>)[#text("(8)")]#text(" already holds if ")#mi("{f}")#text(" is replaced by ")#mi("{B_\\rho}")#text(". To prove ")#link(<tao-3879d6995a5cdfe52e9d>)[#text("(8)")]#text(" for ")#mi("{f}")#text(", it thus suffices to prove it for ")#mi("{f/B_\\rho}")#text(", which effectively deletes a zero ")#mi("{\\rho}")#text(" inside the disk from ")#mi("{f}")#text(" (and replaces it instead with its inversion ")#mi("{1/\\overline{\\rho}}")#text("). Similarly we may remove all the poles inside the disk. As a meromorphic function only has finitely many poles and zeroes inside a compact set, we may thus reduce to the case when ")#mi("{f}")#text(" has no poles or zeroes on or inside the disk, at which point our goal is simply to show that")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|f(0)\\right| = \\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right|\\ dt.", block: true)]]

#text("Since ")#mi("{f}")#text(" has no zeroes or poles inside the disk, the logarithmic derivative ")#mi("{\\frac{f^{\\prime}}{f}}")#text(" has no poles in the disk, and so by Cauchy’s theorem has a primitive ")#mi("{F}")#text(". By the chain rule, ")#mi("{\\exp(F)/f}")#text(" has zero derivative on the disk and is thus constant, thus on taking complex logarithms (see Exercise ")#link(<tao-2bec6b1747db8bd1a7bb>)[#text("3")]#text(") we see that ")#mi("{F}")#text(" is equal to a logarithm of ")#mi("{f}")#text(" up to a constant. Subtracting the constant, we thus can find a holomorphic function ")#mi("{\\log f}")#text(" that is a branch of the complex logarithm of ")#mi("{f}")#text(", thus ")#mi("{\\exp(\\log f) = f}")#text(". In particular, the real part of ")#mi("{\\log f}")#text(" is ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(". The claim now follows by applying the mean value property ")#link(<tao-82523faea1b0f2da676a>)[#text("(3)")]#text(" to ")#mi("{\\log f}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" (This exercise is intended for readers familiar with distribution theory, as discussed for instance in ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("this previous blog post")]#text(".) If ")#mi("{f}")#text(" is holomorphic on an open set ")#mi("{\\Omega}")#text(", establish the formula")

#align(center)[#tao-fit-display[#tao-math("\\Delta \\log \\left|f\\right| = -2\\pi \\sum_\\rho \\delta_\\rho + 2\\pi \\sum_\\zeta \\delta_\\zeta", block: true)]]

#text("in the sense of distributions, where ")#mi("{\\rho}")#text(" and ")#mi("{\\zeta}")#text(" range over the zeroes and poles of ")#mi("{f}")#text(" respectively (counting multiplicity), ")#mi("{\\delta_z}")#text(" denotes the Dirac measure at a complex number ")#mi("{z}")#text(", and ")#mi("{\\Delta}")#text(" is the distributional Laplacian ")#mi("{\\Delta := \\frac{\\partial^2}{\\partial x^2} + \\frac{\\partial^2}{\\partial y^2}}")#text(", with ")#mi("{x,y}")#text(" denoting the real and imaginary parts of the complex variable ")#mi("{z}")#text(". In particular, we see that ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(" is a ")#link("http://en.wikipedia.org/wiki/Harmonic_function")[#text("harmonic")]#text(" function away from the zeroes and poles of ")#mi("{f}")#text(", and a ")#link("http://en.wikipedia.org/wiki/Subharmonic_function")[#text("subharmonic function")]#text(" away from the poles of ")#mi("{f}")#text(".")
]

#text("One application of Jensen’s formula is to control zeroes of a holomorphic function ")#mi("{f}")#text(", given upper and lower bounds on ")#tao-math("{\\left|f(z)\\right|}", block: false)#text(" at various points in the complex plane. Here are some examples:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18")]#text(" Use Jensen’s formula to prove ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_(complex_analysis)")[#text("Liouville’s theorem")]#text(": a bounded holomorphic function ")#mi("{f}")#text(" on the entire complex plane is necessarily constant. (")#emph[#text("Hint:")]#text(" apply Jensen’s formula in a large disk to ")#mi("{f-c}")#text(" for various constants ")#mi("{c}")#text(" to conclude that ")#mi("{f-c}")#text(" either vanishes entirely or has no zeroes whatsoever.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" ")#metadata(none) <tao-943a1abf223ddf833460>#text(" Use Jensen’s formula to prove the ")#link("http://en.wikipedia.org/wiki/Fundamental_theorem_of_algebra")[#text("fundamental theorem of algebra")]#text(": a complex polynomial ")#mi("{P(z)}")#text(" of degree ")#mi("{n}")#text(" has exactly ")#mi("{n}")#text(" complex zeroes (counting multiplicity), and can thus be factored as ")#mi("{P(z) = c (z-z_1) \\dots (z-z_n)}")#text(" for some complex numbers ")#mi("{c,z_1,\\dots,z_n}")#text(" with ")#mi("{c \\neq 0}")#text(". (Note that the fundamental theorem was invoked previously in this section, but only for motivational purposes, so the proof here is non-circular.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Shifted Jensen’s formula)")]#text(" ")#metadata(none) <tao-3d6ae8ac38dd20f70b27>#text(" Let ")#mi("{f}")#text(" be a meromorphic function on an open neighbourhood of a disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(", with all removable singularities removed. Show that ")#metadata(none) <tao-d917018c300dd8d83386>

#tao-aligned(keep: true)[


#tao-math("\\log \\left|f(z)\\right|  & = \\int_0^1 \\log \\left|f(z_0+re^{2\\pi i t})\\right| \\Re \\frac{r e^{2\\pi i t} + (z-z_0)}{r e^{2\\pi i t} - (z-z_0)}\\ dt", block: true, numbering: n => [#text("(10)")])



#tao-math(" & + \\sum_{\\rho: \\left|\\rho-z_0\\right| \\leq r} \\log \\frac{\\left|\\rho-z\\right|}{\\left|r - \\rho^* (z-z_0)\\right|}", block: true)



#tao-math(" & - \\sum_{\\zeta: \\left|\\zeta-z_0\\right| \\leq r} \\log \\frac{\\left|\\zeta-z\\right|}{\\left|r - \\zeta^* (z-z_0)\\right|}", block: true)
]

#text("for all ")#mi("{z}")#text(" in the open disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| < r\\}}", block: false)#text(" that are not zeroes or poles of ")#mi("{f}")#text(", where ")#mi("{\\rho^* = \\frac{\\overline{\\rho-z_0}}{r}}")#text(" and ")#mi("{\\zeta^* = \\frac{\\overline{\\zeta-z_0}}{r}}")#text(". (The function ")#mi("{\\Re \\frac{r e^{2\\pi i t} + (z-z_0)}{r e^{2\\pi i t} - (z-z_0)}}")#text(" appearing in the integrand is sometimes known as the ")#link("http://en.wikipedia.org/wiki/Poisson_kernel")[#text("Poisson kernel")]#text(", particularly if one normalises so that ")#mi("{z_0=0}")#text(" and ")#mi("{r=1}")#text(".)")
]

#text("Just as ")#link(<tao-21c9625fc6b6db6a0baf>)[#text("(7)")]#text(" and ")#link(<tao-d917018c300dd8d83386>)[#text("(10)")]#text(" give truncated variants of ")#link(<tao-d69a1f191c8d5a0ce9f6>)[#text("(5)")]#text(", we can create truncated versions of ")#link(<tao-3f2d9b7700a6ece24221>)[#text("(6)")]#text(". The following crude truncation is adequate for our applications:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 21 (Truncated formula for log-derivative)")]#text(" ")#metadata(none) <tao-460ae9dccd6be97f7a91>#text(" Let ")#mi("{f}")#text(" be a holomorphic function on an open neighbourhood of a disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r \\}}", block: false)#text(" that is not identically zero on this disk. Suppose that one has a bound of the form ")#tao-math("{\\left|f(z)\\right| \\leq M^{O_{c_1,c_2}(1)} \\left|f(z_0)\\right|}", block: false)#text(" for some ")#mi("{M \\geq 1}")#text(" and all ")#mi("{z}")#text(" on the circle ")#tao-math("{\\{ z: \\left|z-z_0\\right| = r\\}}", block: false)#text(". Let ")#mi("{0 < c_2 < c_1 < 1}")#text(" be constants. Then one has the approximate formula")

#align(center)[#tao-fit-display[#tao-math("\\frac{f^{\\prime}(z)}{f(z)} = \\sum_{\\rho: \\left|\\rho - z_0\\right| \\leq c_1 r} \\frac{1}{z-\\rho} + O_{c_1,c_2}( \\frac{\\log M}{r} )", block: true)]]

#text("for all ")#mi("{z}")#text(" in the disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| < c_2 r \\}}", block: false)#text(" other than zeroes of ")#mi("{f}")#text(". Furthermore, the number of zeroes ")#mi("{\\rho}")#text(" in the above sum is ")#mi("{O_{c_1,c_2}(\\log M)}")#text(".")
]

#emph[#text("Proof:")]#text(" To abbreviate notation, we allow all implied constants in this proof to depend on ")#mi("{c_1,c_2}")#text(".")

#text("We mimic the proof of Jensen’s formula. Firstly, we may translate and rescale so that ")#mi("{z_0=0}")#text(" and ")#mi("{r=1}")#text(", so we have ")#tao-math("{\\left|f(z)\\right| \\leq M^{O(1)} \\left|f(0)\\right|}", block: false)#text(" when ")#tao-math("{\\left|z\\right|=1}", block: false)#text(", and our main task is to show that ")#metadata(none) <tao-93850b707585e404e495>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\frac{f^{\\prime}(z)}{f(z)} - \\sum_{\\rho: \\left|\\rho\\right| \\leq c_1} \\frac{1}{z-\\rho} = O( \\log M )", block: true)]]

#text("for ")#tao-math("{\\left|z\\right| \\leq c_2}", block: false)#text(". Note that if ")#mi("{f(0)=0}")#text(" then ")#mi("{f}")#text(" vanishes on the unit circle and hence (by the maximum principle) vanishes identically on the disk, a contradiction, so we may assume ")#mi("{f(0) \\neq 0}")#text(". From hypothesis we then have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|f(z)\\right| \\leq \\log \\left|f(0)\\right| + O(\\log M)", block: true)]]

#text("on the unit circle, and so from Jensen’s formula ")#link(<tao-21c9625fc6b6db6a0baf>)[#text("(7)")]#text(" we see that ")#metadata(none) <tao-db4f552e9a7a7f2498e3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{\\rho: \\left|\\rho\\right| \\leq 1} \\log \\frac{1}{\\left|\\rho\\right|} = O(\\log M).", block: true)]]

#text("In particular we see that the number of zeroes with ")#tao-math("{\\left|\\rho\\right| \\leq c_1}", block: false)#text(" is ")#mi("{O(\\log M)}")#text(", as claimed.")

#text("Suppose ")#mi("{f}")#text(" has a zero ")#mi("{\\rho}")#text(" with ")#tao-math("{c_1 < \\left|\\rho\\right| \\leq 1}", block: false)#text(". If we factor ")#mi("{f = B_\\rho g}")#text(", where ")#mi("{B_\\rho}")#text(" is the Blaschke product ")#link(<tao-8172b90bd44320037349>)[#text("(9)")]#text(", then")

#tao-aligned(keep: true)[


#tao-math("\\frac{f^{\\prime}}{f}  & = \\frac{B^{\\prime}_\\rho}{B_\\rho} + \\frac{g^{\\prime}}{g}", block: true)



#tao-math(" & = \\frac{g^{\\prime}}{g} + \\frac{1}{z-\\rho} - \\frac{1}{z-1/\\overline{\\rho}}.", block: true)
]

#text("Observe from Taylor expansion that the distance between ")#mi("{\\rho}")#text(" and ")#mi("{1/\\overline{\\rho}}")#text(" is ")#tao-math("{O( \\log \\frac{1}{\\left|\\rho\\right|} )}", block: false)#text(", and hence ")#tao-math("{\\frac{1}{z-\\rho} - \\frac{1}{z-1/\\overline{\\rho}} = O( \\log \\frac{1}{\\left|\\rho\\right|} )}", block: false)#text(" for ")#tao-math("{\\left|z\\right| \\leq c_2}", block: false)#text(". Thus we see from ")#link(<tao-db4f552e9a7a7f2498e3>)[#text("(12)")]#text(" that we may use Blaschke products to remove all the zeroes in the annulus ")#tao-math("{c_1 < \\left|\\rho\\right| \\leq 1}", block: false)#text(" while only affecting the left-hand side of ")#link(<tao-93850b707585e404e495>)[#text("(11)")]#text(" by ")#mi("{O( \\log M)}")#text("; also, removing the Blaschke products does not affect ")#tao-math("{\\left|f(z)\\right|}", block: false)#text(" on the unit circle, and only affects ")#tao-math("{\\log \\left|f(0)\\right|}", block: false)#text(" by ")#mi("{O(\\log M)}")#text(" thanks to ")#link(<tao-db4f552e9a7a7f2498e3>)[#text("(12)")]#text(". Thus we may assume without loss of generality that there are no zeroes in this annulus.")

#text("Similarly, given a zero ")#mi("{\\rho}")#text(" with ")#tao-math("{\\left|\\rho\\right| \\leq c_1}", block: false)#text(", we have ")#mi("{\\frac{1}{z-1/\\overline{\\rho}} = O(1)}")#text(", so using Blaschke products to remove all of these zeroes also only affects the left-hand side of ")#link(<tao-93850b707585e404e495>)[#text("(11)")]#text(" by ")#mi("{O(\\log M)}")#text(" (since the number of zeroes here is ")#mi("{O(\\log M)}")#text("), with ")#tao-math("{\\log \\left|f(0)\\right|}", block: false)#text(" also modified by at most ")#mi("{O(\\log M)}")#text(". Thus we may assume in fact that ")#mi("{f}")#text(" has no zeroes whatsoever within the unit disk. We may then also normalise ")#mi("{f(0) = 1}")#text(", then ")#tao-math("{\\log \\left|f(e^{2\\pi i t})\\right| \\leq O(\\log M)}", block: false)#text(" for all ")#mi("{t \\in [0,1]}")#text(". By Jensen’s formula again, we have")

#align(center)[#tao-fit-display[#tao-math("\\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right|\\ dt = 0", block: true)]]

#text("and thus (by using the identity ")#tao-math("{\\left|x\\right| = 2 \\max(x,0) - x}", block: false)#text(" for any real ")#mi("{x}")#text(") ")#metadata(none) <tao-7f1b55b860590406f84f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#tao-math("\\int_0^1 |\\log \\left|f(e^{2\\pi i t})\\right|\\ dt \\ll \\log M.", block: true)]]

#text("On the other hand, from ")#link(<tao-d917018c300dd8d83386>)[#text("(10)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\log \\left|f(z)\\right| = \\int_0^1 \\log \\left|f(e^{2\\pi i t})\\right| \\Re \\frac{e^{2\\pi i t} + z}{e^{2\\pi i t} - z}\\ dt", block: true)]]

#text("which implies from ")#link(<tao-7f1b55b860590406f84f>)[#text("(13)")]#text(" that ")#tao-math("{\\log \\left|f(z)\\right|}", block: false)#text(" and its first derivatives are ")#mi("{O( \\log M )}")#text(" on the disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq c_2 \\}}", block: false)#text(". But recall from the proof of Jensen’s formula that ")#mi("{\\frac{f^{\\prime}}{f}}")#text(" is the derivative of a logarithm ")#mi("{\\log f}")#text(" of ")#mi("{f}")#text(", whose real part is ")#tao-math("{\\log \\left|f\\right|}", block: false)#text(". By the Cauchy-Riemann equations for ")#mi("{\\log f}")#text(", we conclude that ")#mi("{\\frac{f^{\\prime}}{f} = O(\\log M)}")#text(" on the disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq c_2 \\}}", block: false)#text(", as required. (One could also have proceeded here via the ")#link("http://en.wikipedia.org/wiki/Borel%E2%80%93Carath%C3%A9odory_theorem")[#text("Borel-Carathéodory theorem")]#text(".) ")#mi("\\Box")

#text("A variant of the above argument allows one to make precise the heuristic that holomorphic functions locally look like polynomials:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (Local Weierstrass factorisation)")]#text(" Let the notation and hypotheses be as in Theorem ")#link(<tao-460ae9dccd6be97f7a91>)[#text("21")]#text(". Then show that")

#align(center)[#tao-fit-display[#mitex("f(z) = P(z) \\exp( g(z) )")]]

#text("for all ")#mi("{z}")#text(" in the disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| < c_2 r \\}}", block: false)#text(", where ")#mi("{P}")#text(" is a polynomial whose zeroes are precisely the zeroes of ")#mi("{f}")#text(" in ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq c_1r \\}}", block: false)#text(" (counting multiplicity) and ")#mi("{g}")#text(" is a holomorphic function on ")#tao-math("{\\{ z: \\left|z-z_0\\right| < c_2 r \\}}", block: false)#text(" of magnitude ")#mi("{O_{c_1,c_2}( \\log M )}")#text(" and first derivative ")#mi("{O_{c_1,c_2}( \\log M / r )}")#text(" on this disk. Furthermore, show that the degree of ")#mi("{P}")#text(" is ")#mi("{O_{c_1,c_2}(\\log M)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" The classical theory of ")#emph[#text("Beurling factorization")]#text(" of ")#link("http://en.wikipedia.org/wiki/Hardy_space")[#text("Hardy space functions")]#text(" on the disk into inner functions, outer functions, and Blaschke products can be viewed as a sort of limiting case of the above exercise when ")#mi("{c_1,c_2 \\rightarrow 1}")#text("; see for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2261424")[#text("this text of Garnett")]#text(" for a treatment. However, we will not need this limiting theory in our applications.")
]

#heading(level: 1)[#strong[#text(" — 2. The Fourier-Laplace and Fourier transforms — ")]]

#text("There are a number of connections between complex analysis and Fourier analysis. The best known connection perhaps is between complex analytic functions on the unit disk ")#tao-math("{\\{ z: \\left|z\\right| \\leq 1 \\}}", block: false)#text(" and Fourier analysis on the unit circle ")#tao-math("{\\{ z: \\left|z\\right|=1\\}}", block: false)#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Complex analysis on disk versus Fourier analysis on circle)")]

#list(
[#text("Let ")#mi("{f}")#text(" be a complex analytic function on the unit disk ")#tao-math("{\\{z: \\left|z\\right| \\leq 1 \\}}", block: false)#text(", and define the Fourier coefficients")

#align(center)[#tao-fit-display[#mitex("\\hat f(n) := \\int_0^1 f(e^{2\\pi i t}) e^{-2\\pi i nt}\\ dt")]]

#text("for ")#mi("{n \\in {\\bf Z}}")#text(". Show that ")#mi("{\\hat f(n) = 0}")#text(" for all negative ")#mi("{n}")#text(", and one has the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("f(z) = \\sum_{n=0}^\\infty \\hat f(n) z^n")]]

#text("(as an absolutely convergent series) in the interior ")#tao-math("{\\{ z: \\left|z\\right| < 1 \\}}", block: false)#text(" of the disk.")],
[#text("Conversely, let ")#mi("{(c_n)_{n=0}^\\infty}")#text(" be an absolutely summable sequence of complex numbers. Show that the function")

#align(center)[#tao-fit-display[#mitex("f(z) := \\sum_{n=0}^\\infty c_n z^n")]]

#text("is a continuous function on the unit disk ")#tao-math("{\\{z: \\left|z\\right| \\leq 1 \\}}", block: false)#text(" that is holomorphic on the interior of this disk, and that ")#mi("{\\hat f(n) = c_n}")#text(" for all ")#mi("{n \\geq 0}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 25")]#text(" The relationship between the boundary behaviour of holomorphic functions ")#mi("{f}")#text(" on the disk, and the integrability properties of the function ")#mi("{f}")#text(" on the unit circle, is a very delicate topic, involving the theory of Hardy spaces as well as tools from harmonic analysis, and will not be discussed here; see for instance the ")#link("http://www.ams.org/mathscinet-getitem?mr=2261424")[#text("text of Garnett")]#text(" for further discussion.")
]

#text("We will not explicitly use the above connection between complex analysis and Fourier analysis in this course (although some traces of it might be discerned in the material in the previous sections of this set of notes). Instead, we will discuss a slightly different link between the two subjects, linking complex analysis on the half-space ")#mi("{\\{ s: \\text{Re}(s) \\geq 0 \\}}")#text(" with the ")#link("http://en.wikipedia.org/wiki/Laplace_transform")[#text("Fourier-Laplace transform")]#text(" on the half-line. Namely, given an absolutely integrable measurable function ")#mi("{f: [0,+\\infty) \\rightarrow {\\bf C}}")#text(", the ")#emph[#text("Laplace transform")]#text(" ")#mi("{{\\mathcal L} f: [0,+\\infty) \\rightarrow {\\bf C}}")#text(" is defined by the formula")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L} f(s) := \\int_0^\\infty f(u) e^{-su}\\ du.")]]

#text("Actually, for absolutely integrable ")#mi("{f}")#text(" there is no difficulty extending the Laplace transform to the half-space ")#mi("{\\{ s: \\text{Re}(s) \\geq 0 \\}}")#text(" by exactly the same formula, giving rise to the ")#emph[#text("Fourier-Laplace transform")]#text(". On the imaginary axis ")#mi("{s = -it}")#text(", this becomes the Fourier transform:")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L} f(-it) = \\int_{\\bf R} f(u) e^{itu}\\ du,")]]

#text("where we extend ")#mi("{f}")#text(" by zero to the entire real line. If we also assume ")#mi("{f}")#text(" to be compactly supported, then the Fourier-Laplace transform extends to the entire complex plane ")#mi("{{\\bf C}}")#text(".")

#text("An application of ")#link("http://en.wikipedia.org/wiki/Fubini%27s_theorem")[#text("Fubini’s theorem")]#text(" reveals that the integral of ")#mi("{{\\mathcal L} f(s)}")#text(" in any closed contour in the domain of definition vanishes, so by Morera’s theorem (Corollary ")#link(<tao-e678ac9196f5bddb34ad>)[#text("10")]#text(") we conclude that ")#mi("{{\\mathcal L} f}")#text(" is holomorphic on the right half-space ")#mi("{\\{ s: \\text{Re}(s) > 0 \\}}")#text(" (if ")#mi("{f}")#text(" is absolutely integrable on ")#mi("{[0,+\\infty)}")#text(") or on ")#mi("{{\\bf C}}")#text(" (if ")#mi("{f}")#text(" is compactly supported).")

#text("If we have a bit of smoothness on ")#mi("{f}")#text(", then we can establish some asymptotics on the Fourier-Laplace transform:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 26")]#text(" Let ")#mi("{f: [0,+\\infty)}")#text(" be compactly supported and continuously twice differentiable. Then we have ")#metadata(none) <tao-c0e2e04a83dfb5b561ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#tao-math("{\\mathcal L} f(s) = \\frac{f(0)}{s} + O_f( \\frac{1}{\\left|s\\right|^2} )", block: true)]]

#text("for all ")#mi("{s}")#text(" in the half-space ")#mi("{\\{ s: \\text{Re}(s) \\geq 0 \\}}")#text(" with ")#mi("{s \\neq 0}")#text(".")
]

#emph[#text("Proof:")]#text(" By an integration by parts, we have")

#tao-aligned(keep: true)[


#tao-math("{\\mathcal L} f(s)  & = \\int_0^\\infty f(u) e^{-su}\\ du", block: true)



#tao-math(" & = \\frac{f(0)}{s} + \\frac{1}{s} \\int_0^\\infty f^{\\prime}(u) e^{-su}\\ du", block: true)



#tao-math(" & = \\frac{f(0)}{s} + \\frac{f^{\\prime}(0)}{s^2} + \\frac{1}{s^2} \\int_0^\\infty f^{\\prime\\prime}(u) e^{-su}\\ du;", block: true)
]

#text("since ")#mi("{f^{\\prime\\prime}}")#text(" is continuous and compactly supported, and ")#mi("{e^{-su}}")#text(" is bounded in magnitude by ")#mi("{1}")#text(", the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 27")]#text(" ")#metadata(none) <tao-f9ed2b54fd72ac165257>#text(" Let ")#mi("{f: [0,+\\infty) \\rightarrow {\\bf C}}")#text(" be compactly supported and continuously twice differentiable. Then we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{T \\rightarrow +\\infty} \\int_{-T}^T {\\mathcal L} f( c + it)\\ dt = \\pi f(0)")]]

#text("for any ")#mi("{c \\geq 0}")#text(". (Note from ")#link(<tao-c0e2e04a83dfb5b561ba>)[#text("(14)")]#text(" that the limit exists.)")
]

#emph[#text("Proof:")]#text(" By contour shifting (using ")#link(<tao-c0e2e04a83dfb5b561ba>)[#text("(14)")]#text(" to handle error terms) we see that the integral is independent of ")#mi("{c}")#text(", so we may take ")#mi("{c}")#text(" to be large. Applying ")#link(<tao-c0e2e04a83dfb5b561ba>)[#text("(14)")]#text(" and the fundamental theorem of calculus, we see that")

#align(center)[#tao-fit-display[#mitex("\\int_{-T}^T {\\mathcal L} f( c + it)\\ dt = \\frac{f(0)}{i} (\\log( c+iT ) - \\log(c-iT)) + O_f( \\int_{-T}^T \\frac{dt}{c^2 + t^2} )")]]

#text("using the ")#link("http://en.wikipedia.org/wiki/Complex_logarithm")[#text("principal branch of the logarithm")]#text(". The integral ")#mi("{\\int_{-T}^T \\frac{dt}{c^2 + t^2}}")#text(" is ")#mi("{O(1/c)}")#text(", and ")#mi("{\\log( c+IT ) - \\log(c-iT)}")#text(" converges to ")#mi("{\\pi i}")#text(" as ")#mi("{T \\rightarrow +\\infty}")#text(". Taking limits as ")#mi("{T \\rightarrow \\infty}")#text(", and then sending ")#mi("{c}")#text(" to infinity, we obtain the claim. ")#mi("\\Box")

#text("This gives a proof of one of the basic identities in Fourier analysis, the ")#link("http://en.wikipedia.org/wiki/Fourier_inversion_theorem")[#text("Fourier inversion formula")]#text(". Given any absolutely integrable function ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(", let us define the ")#link("http://en.wikipedia.org/wiki/Fourier_transform")[#text("Fourier transform")]#text(" ")#mi("{\\hat f: {\\bf R} \\rightarrow {\\bf C}}")#text(" by the formula ")#metadata(none) <tao-02391bb51ceb491b531d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("\\hat f(\\xi) := \\int_{\\bf R} f(u) e^{i\\xi u}\\ du.")]]

#text("(Here we use a normalisation of the Fourier transform that aligns with the traditional normalisations in complex analysis; other normalisations are used in other fields of mathematics.) We first recall some basic estimates and symmetries:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Basic estimates on Fourier transform)")]#text(" ")#metadata(none) <tao-fa37be71bea1abe98954>#text(" Let ")#mi("{k \\geq 0}")#text(" be an integer, and let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be compactly supported and ")#mi("{k}")#text(" times continuously differentiable (this is interpreted simply as continuity if ")#mi("{k=0}")#text(").")

#list(
[#text("(i) Establish the pointwise bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\leq \\frac{1}{\\left|\\xi\\right|^k} \\int_{\\bf R} |f^{(k)}(u)|\\ du", block: true)]]

#text("for all ")#mi("{\\xi \\in {\\bf R}}")#text(", where ")#mi("{f^{(k)}}")#text(" denotes the ")#mi("{k}")#text("-fold derivative of ")#mi("{f}")#text(", and with the convention that the inequality is trivially true when ")#mi("{\\xi=0}")#text(" and ")#mi("{k>0}")#text(".")],
[#text("(ii) Suppose in addition that ")#mi("{f}")#text(" is supported in the interval ")#mi("{[a,b]}")#text(". Show that ")#mi("{\\hat f}")#text(" extends holomorphically to the entire complex plane (with the formula ")#link(<tao-02391bb51ceb491b531d>)[#text("(15)")]#text(" valid now for all ")#mi("{\\xi \\in {\\bf C}}")#text("), with the pointwise bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\leq \\max( e^{a \\text{Im}(\\xi)}, e^{b \\text{Im}(\\xi)} ) \\frac{1}{\\left|\\xi\\right|^k} \\int_{\\bf R} |f^{(k)}(u)|\\ du", block: true)]]

#text("for all ")#mi("{\\xi \\in {\\bf C}}")#text(". (There is a converse to this result known as the ")#link("http://en.wikipedia.org/wiki/Paley%E2%80%93Wiener_theorem")[#text("Paley-Wiener theorem")]#text(", but we will not establish or need it here.)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29 (Basic symmetries of the Fourier transform)")]#text(" ")#metadata(none) <tao-0599b22abfb1eb4db9c1>#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be absolutely integrable.")

#list(
[#text("(i) If ")#mi("{g(u) := f(u-u_0)}")#text(" for some ")#mi("{u_0 \\in {\\bf R}}")#text(" and all ")#mi("{u \\in {\\bf R}}")#text(", show that ")#mi("{\\hat g(\\xi) = e^{i u_0 \\xi} \\hat f(\\xi)}")#text(" for all ")#mi("{\\xi \\in {\\bf R}}")#text(".")],
[#text("(ii) If ")#mi("{g(u) := f(u) e^{-i\\xi_0 u}}")#text(" for some ")#mi("{\\xi_0 \\in {\\bf R}}")#text(" and all ")#mi("{u \\in {\\bf R}}")#text(", show that ")#mi("{\\hat g(\\xi) = \\hat f(\\xi-\\xi_0)}")#text(" for all ")#mi("{\\xi \\in {\\bf R}}")#text(".")],
[#text("(iii) If ")#mi("{g(u) := f(\\lambda u)}")#text(" for some ")#mi("{\\lambda \\in {\\bf R} \\backslash \\{0\\}}")#text(" and all ")#mi("{u \\in {\\bf R}}")#text(", show that ")#tao-math("{\\hat g(\\xi) = \\frac{1}{\\left|\\lambda\\right|} \\hat f(\\xi/\\lambda)}", block: false)#text(" for all ")#mi("{\\xi \\in {\\bf R}}")#text(".")],
[#text("(iv) If ")#mi("{g(u) := \\overline{f(u)}}")#text(" for all ")#mi("{u \\in {\\bf R}}")#text(", show that ")#mi("{\\hat g(\\xi) = \\overline{\\hat f(-\\xi)}}")#text(" for all ")#mi("{\\xi \\in {\\bf R}}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 30 (Fourier inversion formula)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be compactly supported and continuously twice differentiable. Then the Fourier transform ")#mi("{\\hat f: {\\bf R} \\rightarrow {\\bf C}}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{\\bf R} f(u) e^{i\\xi u}\\ du")]]

#text("is bounded and absolutely integrable, and one has the inversion formula")

#align(center)[#tao-fit-display[#mitex("f(u) = \\frac{1}{2\\pi} \\int_{\\bf R} \\hat f(\\xi) e^{-i \\xi u}\\ d\\xi")]]

#text("for any ")#mi("{u \\in {\\bf R}}")#text(". More generally, one has")

#align(center)[#tao-fit-display[#mitex("f(u) = \\frac{e^{ut}}{2\\pi} \\int_{\\bf R} \\hat f(\\xi+it) e^{-i \\xi u}\\ d\\xi")]]

#text("for any ")#mi("{t \\in {\\bf R}}")#text(", where again the integrand is absolutely integrable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 31")]#text(" One can certainly relax the support and smoothness hypotheses on ")#mi("{f}")#text(", particularly if one is willing to work in rougher function spaces, such as the space of tempered distributions; see e.g. ")#link("https://terrytao.wordpress.com/2009/04/06/the-fourier-transform/")[#text("these")]#text(" ")#link("https://terrytao.wordpress.com/2009/04/19/245c-notes-3-distributions/")[#text("previous notes")]#text(". Similarly for the other Fourier-analytic results presented below. But for the purpose of this course, it will suffice to restrict attention to fairly well behaved functions ")#mi("{f}")#text(", such as those that are compactly supported and twice continuously differentiable.")
]

#emph[#text("Proof:")]#text(" From Exercise ")#link(<tao-fa37be71bea1abe98954>)[#text("28")]#text(" with ")#mi("{k=0,2}")#text(" we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\hat f(\\xi)\\right| \\ll_f \\min(1, \\frac{1}{\\left|\\xi\\right|^2}),", block: true)]]

#text("and so ")#mi("{\\hat f}")#text(" is bounded and absolutely integrable as claimed.")

#text("By Exercise ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("29")]#text("(i) we may assume without loss of generality that ")#mi("{u=0}")#text(", thus our task is now to show that")

#align(center)[#tao-fit-display[#mitex("f(0) = \\frac{1}{2\\pi} \\int_{\\bf R} \\hat f(\\xi)\\ d\\xi.")]]

#text("We introduce the components ")#mi("{f_+, f_-: [0,+\\infty) \\rightarrow {\\bf C}}")#text(" of ")#mi("{f}")#text(" by the formulae")

#align(center)[#tao-fit-display[#mitex("f_\\pm(u) := f(\\pm u)")]]

#text("for ")#mi("{u \\in [0,+\\infty)}")#text(", and observe that the Fourier transform ")#mi("{\\hat f}")#text(" of ")#mi("{f}")#text(" is related to the Fourier-Laplace transforms of ")#mi("{f_+, f_-}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = {\\mathcal L} f_+( -i \\xi ) + {\\mathcal L} f_-( i \\xi ).")]]

#text("From Corollary ")#link(<tao-f9ed2b54fd72ac165257>)[#text("27")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\lim_{T \\rightarrow +\\infty} \\int_{-T}^T {\\mathcal L} f_\\pm( \\mp i \\xi )\\ d\\xi = \\pi f(0)")]]

#text("for either choice of sign; summing, we obtain the first claim. The second claim then follows by replacing ")#mi("{f(u)}")#text(" by ")#mi("{e^{-ut} f(u)}")#text(" (or by shifting the contour). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 32")]#text(" In the above proof, ")#mi("{\\hat f(\\xi)}")#text(" is split into a function ")#mi("{{\\mathcal L} f_+( -i \\xi )}")#text(" extending holomorphically and boundedly to the upper half-plane, and a function ")#mi("{{\\mathcal L} f_-( i \\xi )}")#text(" extending holomorphically and boundedly to the lower half-plane. Such a decomposition solves a very simple example of the ")#link("http://en.wikipedia.org/wiki/Riemann%E2%80%93Hilbert_problem")[#text("Riemann-Hilbert problem")]#text(", but we will not discuss this problem further in this course.")
]

#text("The inversion formula gives an important identity, essentially due ")#link("http://en.wikipedia.org/wiki/Parseval%27s_theorem")[#text("to Parseval")]#text(" and ")#link("http://en.wikipedia.org/wiki/Plancherel_theorem")[#text("to Plancherel")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 33 (Parseval-Plancherel identities)")]#text(" Let ")#mi("{f, g: {\\bf R} \\rightarrow {\\bf C}}")#text(" be compactly supported and continuously twice differentiable. Then we have")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(u) \\overline{g(u)}\\ du = \\frac{1}{2\\pi} \\int_{\\bf R} \\hat f(\\xi) \\overline{\\hat g(\\xi)}\\ d\\xi.")]]

#text("In particular")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\left|f(u)\\right|^2\\ du = \\frac{1}{2\\pi} \\int_{\\bf R} \\left|\\hat f(\\xi)\\right|^2\\ d\\xi", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} f(u) g(u)\\ du = \\frac{1}{2\\pi} \\int_{\\bf R} \\hat f(\\xi) \\hat g(-\\xi)\\ d\\xi.")]]
]

#emph[#text("Proof:")]#text(" By the inversion formula we may write ")#mi("{\\int_{\\bf R} f(u) \\overline{g(u)}\\ du}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\int_{\\bf R} \\int_{\\bf R} \\hat f(\\xi) e^{-i\\xi u} \\overline{g(u)}\\ d\\xi du.")]]

#text("The claim then follows from Fubini’s theorem. ")#mi("\\Box")

#text("In the next set of notes, we will use a version of the above identity, which we will call a ")#link("http://en.wikipedia.org/wiki/Perron%27s_formula")[#text("truncated Perron formula")]#text(", to express smoothed summatory functions of arithmetic functions ")#mi("{f}")#text(" as contour integrals of the associated Dirichlet series ")#mi("{{\\mathcal D} f}")#text(".")

#text("Finally, we record another important Fourier identity, the ")#link("http://en.wikipedia.org/wiki/Poisson_summation_formula")[#text("Poisson summation formula")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 34 (Poisson summation)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be a compactly supported, twice continuously differentiable function. Then ")#metadata(none) <tao-4ce7bcf6e148d5048b8e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\sum_{n \\in {\\bf Z}} f(n) = \\sum_{m \\in {\\bf Z}} \\hat f(2\\pi m).")]]
]

#emph[#text("Proof:")]#text(" There are many ways to prove this identity, but given the spirit of this set of notes, it seems appropriate to give a complex analysis proof. By Exercise ")#link(<tao-0599b22abfb1eb4db9c1>)[#text("29")]#text("(i) we may assume without loss of generality that ")#mi("{f}")#text(" is supported on the positive real axis. By the dominated convergence theorem, the left-hand side of ")#link(<tao-4ce7bcf6e148d5048b8e>)[#text("(16)")]#text(" may thus be written as")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} \\sum_{n=0}^\\infty f(n) e^{-\\varepsilon n}.")]]

#text("From the Fourier inversion formula and dominated convergence again, we may rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} \\frac{1}{2\\pi} \\int_{\\bf R} \\hat f(\\xi) \\sum_{n=0}^\\infty e^{-in\\xi} e^{-\\varepsilon n}\\ d\\xi;")]]

#text("summing the geometric series, this becomes")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} \\frac{1}{2\\pi} \\int_{\\bf R} \\frac{\\hat f(\\xi)}{1 - e^{-\\varepsilon-i\\xi}}\\ d\\xi.")]]

#text("Observe that the function ")#mi("{\\xi \\mapsto \\frac{\\hat f(\\xi)}{1 - e^{-\\varepsilon-i\\xi}}}")#text(" is meromorphic on the upper half-plane ")#mi("{\\{ \\xi: \\text{Im}(\\xi) \\geq 0 \\}}")#text(", with poles at ")#mi("{2\\pi m+i\\varepsilon}")#text(" for ")#mi("{m \\in {\\bf Z}}")#text(" with residue ")#mi("{-i \\hat f( 2\\pi m+i\\varepsilon)}")#text(". A routine application of the residue theorem (using Exercise ")#link(<tao-fa37be71bea1abe98954>)[#text("28")]#text(" to handle error terms) allows us to write the previous expression as")

#align(center)[#tao-fit-display[#mitex("\\lim_{\\varepsilon \\rightarrow 0^+} \\sum_{m \\in {\\bf Z}} \\hat f(2\\pi m + i\\varepsilon ),")]]

#text("and the claim then follows from one final application of dominated convergence. ")#mi("\\Box")

#text("There will be at least two key applications of the Poisson summation formula in this course. One is to establish the functional equation for the Riemann zeta function (as well as truncated versions of this equation, for instance involving the sum ")#mi("{\\sum_n n^{it} \\psi(n/N)}")#text(" for some smooth cutoff ")#mi("{\\psi}")#text(" and parameters ")#mi("{N, t}")#text("). The other is to obtain good bounds for smooth sums ")#mi("{\\sum_n \\psi(n/N)}")#text(" with error terms that are significantly better than what one can obtain just from the integral test (Lemma 2 from ")#link("https://terrytao.wordpress.com/2014/11/23/254a-notes-1-elementary-multiplicative-number-theory/")[#text("previous notes")]#text(") or the fundamental theorem of calculus (Exercise 11 from the same notes):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35 (Good error bounds on smooth sums)")]#text(" Let ")#mi("{\\psi}")#text(" be a compactly supported, ")#mi("{k}")#text(" times continuously differentiable function for some ")#mi("{k \\geq 2}")#text(". Use the Poisson summation formula to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\psi(n/N) = N \\int_{\\bf R} \\psi + O_{\\psi,k}( N^{1-k} )")]]

#text("for all ")#mi("{N \\gg 1}")#text(". (This should be compared with the error term of ")#mi("{O_\\psi(1)}")#text(" that one would have obtained using the methods from previous notes.) This estimate illustrates a ")#link("http://www.tricki.org/article/Smoothing_sums")[#text("basic principle")]#text(", namely that smoother sums enjoy better asymptotics.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36 (Fourier transform of Gaussian)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf R}}")#text(" be the function defined by")

#align(center)[#tao-fit-display[#mitex("f(u) := e^{- u^2 / 2}")]]

#text("for ")#mi("{u \\in {\\bf R}}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) = \\sqrt{2\\pi} e^{-\\xi^2/2}")]]

#text("for all ")#mi("{\\xi \\in {\\bf R}}")#text(". (Hint: it is not difficult to establish this claim with ")#mi("{\\sqrt{2\\pi}}")#text(" replaced by some unknown positive constant ")#mi("{c}")#text("; but then one can use the Fourier inversion formula to compute ")#mi("{c}")#text(".) Conclude the functional equation")

#align(center)[#tao-fit-display[#mitex("\\theta(z) = \\frac{1}{\\sqrt{-iz}} \\theta(-\\frac{1}{z})")]]

#text("whenever ")#mi("{z}")#text(" is an element of the upper half-space ")#mi("{\\{ z \\in {\\bf C}: \\text{Im}(z)> 0 \\}}")#text(", with the principal branch ")#mi("{\\sqrt{z} := \\exp( \\frac{1}{2} \\text{Log}(z) )}")#text(" of the complex square root, and ")#mi("{\\theta}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Theta_function")[#text("theta function")]

#align(center)[#tao-fit-display[#mitex("\\theta(z) := \\sum_{n\\in {\\bf Z}} e^{\\pi i n^2 z}.")]]

#text("(Hint: use the Poisson summation formula and the symmetries of the Fourier transform.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37 (Mellin inversion formula)")]#text(" Let ")#mi("{f: [0,+\\infty) \\rightarrow {\\bf C}}")#text(" be a continuous, compactly supported function. Establish the ")#link("http://en.wikipedia.org/wiki/Inverse_Laplace_transform")[#text("Mellin inversion formula")]

#align(center)[#tao-fit-display[#mitex("f(u) = \\frac{1}{2\\pi i} \\lim_{T \\rightarrow +\\infty} \\int_{c-iT}^{c+iT} e^{su} {\\mathcal L} f(z)\\ dz")]]

#text("for all ")#mi("{u>0}")#text(" and ")#mi("{c>0}")#text(", where the integral is along the straight line contour from ")#mi("{c-iT}")#text(" to ")#mi("{c+iT}")#text(". What happens when ")#mi("{u=0}")#text(" or ")#mi("{u<0}")#text("?")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 38")]#text(" By a simple change of variables, the above formula also leads to an ")#link("http://en.wikipedia.org/wiki/Mellin_inversion_theorem")[#text("inversion formula")]#text(" for the ")#link("http://en.wikipedia.org/wiki/Mellin_transform")[#text("Mellin transform")]

#align(center)[#tao-fit-display[#mitex("{\\mathcal M} f(s) := \\int_0^\\infty x^s f(x) \\frac{dx}{x}")]]

#text("defined for compactly supported absolutely integrable ")#mi("{f: (0,+\\infty) \\rightarrow {\\bf C}}")#text(" and ")#mi("{s \\in {\\bf C}}")#text(", but we will not use this transform or inversion formula here.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39 (Qualitative uncertainty principle)")]#text(" Let ")#mi("{f: {\\bf R} \\rightarrow {\\bf C}}")#text(" be an absolutely integrable function such that ")#mi("{f}")#text(" and ")#mi("{\\hat f}")#text(" are both compactly supported. Show that ")#mi("{f}")#text(" is identically zero. (This is a special case of the ")#emph[#text("Hardy uncertainty principle")]#text(", discussed in ")#link("https://terrytao.wordpress.com/2009/02/18/hardys-uncertainty-principle/")[#text("this previous post")]#text(".)")
]

#text("(The exercises below should be placed earlier in this set of notes, but are at the end to avoid renumbering issues.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40 (Borel-Carathéodory theorem)")]#text(" Let ")#mi("{f}")#text(" be a complex analytic function in a disk ")#tao-math("{\\{ z: \\left|z-z_0\\right| \\leq r\\}}", block: false)#text(". Show that for any ")#mi("{0 < c < 1}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|f^{\\prime}(z)\\right| \\ll_c \\frac{1}{r} \\int_0^{2\\pi} |\\text{Re} f( z_0 + r e^{i\\theta})|\\ d\\theta", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|f(z)\\right| \\leq \\left|f(0)\\right| + O_c( \\int_0^{2\\pi} |\\text{Re} f( z_0 + r e^{i\\theta})|\\ d\\theta ).", block: true)]]

#text("for all ")#mi("{z}")#text(" in the disk ")#tao-math("{\\{z: \\left|z-z_0\\right| \\leq c r \\}}", block: false)#text(". (")#emph[#text("Hint:")]#text(" there are various ways to proceed here. One is to apply Exercise ")#link(<tao-3d6ae8ac38dd20f70b27>)[#text("20")]#text(" to ")#mi("{\\exp(f)}")#text(" and differentiate.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41 (Hadamard three-lines theorem)")]

#list(
[#text("(i) Let ")#mi("{\\sigma_0 < \\sigma_1}")#text(" and ")#mi("{A_0,A_1 > 0}")#text(" be real numbers. Suppose that ")#mi("{f}")#text(" is a complex analytic function in a strip ")#mi("{\\{ s: \\sigma_0 \\leq \\text{Re}(s) \\leq \\sigma_1 \\}}")#text(" such that ")#tao-math("{\\left|f(\\sigma_0+it)\\right| \\leq A_0}", block: false)#text(" and ")#tao-math("{\\left|f(\\sigma_1+it)\\right| \\leq A_1}", block: false)#text(" for all ")#mi("{t \\in {\\bf R}}")#text(". Suppose also that one has the crude growth condition ")#tao-math("{f(\\sigma+it) \\ll \\exp( O( \\left|t\\right|^{O(1)} ) )}", block: false)#text(" for all ")#mi("{\\sigma_0 \\leq \\sigma \\leq \\sigma_1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". Show that ")#tao-math("{\\left|f((1-\\theta)\\sigma_0+\\theta \\sigma_1+it)\\right| \\leq A_0^{1-\\theta} A_1^\\theta}", block: false)#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". (")#emph[#text("Hint:")]#text(" one can normalise ")#mi("{\\sigma_0=0, \\sigma_1=1, A_0=A_1=1}")#text(". Use the maximum principle to verify the claim in the case that ")#mi("{f(\\sigma+it)}")#text(" goes to zero as ")#mi("{t \\rightarrow \\pm \\infty}")#text(". To handle the general case, mollify ")#mi("{f}")#text(" by multiplying by functions such as ")#mi("{\\exp( \\varepsilon i \\exp(i[(\\pi-\\delta/2) s + \\delta/4]) )}")#text(" for suitable ")#mi("{\\varepsilon,\\delta > 0}")#text(".)")],
[#text("(ii) Let ")#mi("{\\sigma_0 < \\sigma_1}")#text(" and ")#mi("{\\alpha_0, \\alpha_1 \\in {\\bf R}}")#text(" be real numbers, and let ")#mi("{f}")#text(" be complex analytic function in a strip ")#mi("{\\{ s: \\sigma_0 \\leq \\text{Re}(s) \\leq \\sigma_1 \\}}")#text(" such that ")#tao-math("{f(\\sigma_j+it) \\ll (1+\\left|t\\right|)^{\\alpha_j}}", block: false)#text(" for ")#mi("{j=0,1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(", and ")#tao-math("{f(\\sigma_it) \\ll \\exp( O( \\left|t\\right|^{O(1)}) )}", block: false)#text(" for ")#mi("{\\sigma_0 \\leq \\sigma \\leq \\sigma_1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(". Show that ")#tao-math("{f((1-\\theta)\\sigma_0+\\theta \\sigma_1+it) \\ll (1+\\left|t\\right|)^{(1-\\theta)\\alpha_0+\\theta\\alpha_1}}", block: false)#text(" for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(" and ")#mi("{t \\in {\\bf R}}")#text(".")]
)
]

#heading(level: 1)[#text("Comments (24)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-443999")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("I think you mean 254A in the title.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd83df368f5a465e4458f676823fe63af18caa3828a7c8d866400b549db7ea66-50338db75eee8858da9108c36b9554c86942eff17d4d12f7588cd08b81d90776.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-444007")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("“We will not attempt a comprehensive review of this subject; for instance, we will completely neglect the conformal geometry or Riemann surface aspect of complex analysis” ;-(")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c26f0315cfad3587dfc501754697db37f9f564cd97d5838243638aa8ba5798a-8aa9f769fdd27b5f12508cfbafa4ead5b70b23ed8ee71a85228df2d8c75ce653.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rogier Brussee")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-444025")[#strong[#text("Rogier Brussee")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("In cor. 34, the Plancherel formula misses a hat on g.")

#text("As always, very nice notes.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/617e2a383bd51a429ce0f71475477b430cbe0fae5076f9020c73ce215302275e-7bd00c3f8f7b57c5fdbdb381d0efe070ab46d1d958d5d102206e96511f93dc77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jlackm")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-444072")[#strong[#text("jlackm")]]#text(size: 9pt, fill: rgb("596477"), " · 5 December 2014")])]

#text("Dear Professor Tao,")

#text("can one easily use Stokes’ theorem to prove Cauchy’s integral formula without assuming continuity of the partial derivatives? A priori they aren’t even Riemann integrable, and I’ve never seen this done before. This would be very nice if it’s true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-444110")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 6 December 2014")])]

#text("Goursat’s proof of Cauchy’s theorem (and hence the integral formula) requires only complex differentiability at each point, without continuity (although when combined with Morera’s theorem, one can recover this continuity and even obtain complex analyticity). See e.g. Stein-Shakarchi ")#link("http://press.princeton.edu/chapters/s02_7563.pdf")[#text("http://press.princeton.edu/chapters/s02_7563.pdf")]#text(" . In most applications, though, whenever one establishes differentiability of a function, one also establishes continuous differentiability without much additional effort, so this additional relaxation of hypotheses is not a significant strengthening of Cauchy’s theorem in practice.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5bf23ebe11fcbe0a61f64f59239b469fe4ee5076b883e15afea619b4b55ffb4b-054844e28292f70f825dd0fb4a8a6b451c1cdf5bd9a9f72293281da9ef6261fb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Avi Levy")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-444432")[#strong[#text("Avi Levy")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2014")])]

#text("In the paragraph preceeding Exercise 12, right after the definition of a meromorphic function: “which is locally to the quotient {g/h} of holomorphic functions” (I think you’re missing a word or two).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d1e8524076171c12ae4d45145b6fcd6a22fafb0c256d0d17940a7b8351fff8-7dccf94ca8b29f3c9ea02e229abf05db0755c35ac93f39ffc1a19f25e2cbfe9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peteg")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-445403")[#strong[#text("peteg")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("In the proof of Corollary 8, what allows you to switch the sum and the integral?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-445409")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2014")])]

#text("The dominated convergence theorem (note that ")#mi("f(w)")#text(" is uniformly bounded on the contour ")#mi("C_r")#text(", and ")#mi("\\frac{1}{w^{n+1}}z^n")#text(" is bounded in magnitude by ")#tao-math("\\frac{\\left|z\\right|^n}{r^{n+1}}", block: false)#text(", which is absolutely convergent when summed in ")#mi("n")#text("). One could also use Fubini’s theorem here if desired.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d1e8524076171c12ae4d45145b6fcd6a22fafb0c256d0d17940a7b8351fff8-7dccf94ca8b29f3c9ea02e229abf05db0755c35ac93f39ffc1a19f25e2cbfe9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peteg")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-447091")[#strong[#text("peteg")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2014")])]

#text("In the proof of Jensen’s formula, for the case where f has no zeros or poles in the unit disc, would a valid argument be that since log f is analytic, it satisfies the mean value property?")

#emph[#text("[Yes; this is essentially the strategy used to prove this formula in this blog post. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1d1e8524076171c12ae4d45145b6fcd6a22fafb0c256d0d17940a7b8351fff8-7dccf94ca8b29f3c9ea02e229abf05db0755c35ac93f39ffc1a19f25e2cbfe9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of peteg")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-447609")[#strong[#text("peteg")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2014")])]

#text("Can you expand on the hint for exercise 18?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-448584")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("Suppose for instance that ")#mi("f")#text(" is not zero at the origin, but has at least one zero ")#mi("\\rho")#text(". Apply Jensen’s formula to a disk ")#tao-math("\\{\\left|z\\right| \\leq r\\}", block: false)#text(" and obtain a contradiction for sufficiently large ")#mi("r")#text(" if ")#tao-math("\\left|f\\right|", block: false)#text(" is bounded.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-451886")[#strong[#text("254A, Notes 6: Large values of Dirichlet polynomials, zero density estimates, and primes in short intervals | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2015")])]

#text("[…] by exploiting the smooth nature of . Namely, by using the Poisson summation formula (Theorem 34 of Supplement 2), we can rewrite (2) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-451970")[#strong[#text("254A, Notes 3: The large sieve and the Bombieri-Vinogradov theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 15 February 2015")])]

#text("[…] hence by Exercise 28 of Supplement 2, we have the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-452285")[#strong[#text("254A, Notes 7: Linnik’s theorem on primes in arithmetic progressions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 February 2015")])]

#text("[…] Jensen’s theorem (Theorem 16 of Supplement 2), we conclude that for any given non-principal and any , there are at most zeroes of (counting […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-452616")[#strong[#text("254A, Supplement 7: Normalised limit profiles of the log-magnitude of the Riemann zeta function (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 March 2015")])]

#text("[…] A major topic of interest of analytic number theory is the asymptotic behaviour of the Riemann zeta function in the critical strip in the limit . For the purposes of this set of notes, it is a little simpler technically to work with the log-magnitude of the zeta function. (In principle, one can reconstruct a branch of , and hence itself, from using the Cauchy-Riemann equations, or tools such as the Borel-Carathéodory theorem, see Exercise 40 of Supplement 2.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5a7154af14355408b90d68a39dc152f74423bf3e72d94fd30805d38408473f6-1faf98a79327cf03d99eafdf5db6f8034e8a9ba4701ea6151b596a9ab4714efa.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terry Tao: 254A, Supplement 2: A little bit of complex and Fourier analysis | What’s new – Collected Links")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-467348")[#strong[#text("Terry Tao: 254A, Supplement 2: A little bit of complex and Fourier analysis | What’s new – Collected Links")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2016")])]

#text("[…] 254A, Supplement 2: A little bit of complex and Fourier analysis | What’s new n this supplement to the main notes, we quickly review the portions of complex analysis that we will be using in this course. We will not attempt a comprehensive review of this subject; for instance, we will completely neglect the conformal geometry or Riemann surface aspect of complex analysis, and we will also avoid using the various boundary convergence theorems for Taylor series or Dirichlet series (the latter type of result is traditionally utilised in multiplicative number theory, but I personally find them a little unintuitive to use, and will instead rely on a slightly different set of complex-analytic tools). We will also focus on the “local” structure of complex analytic functions, in particular adopting the philosophy that such functions behave locally like complex polynomials; the classical “global” theory of entire functions, while traditionally used in the theory of the Riemann zeta function, will be downplayed in these notes. On the other hand, we will play up […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-470231")[#strong[#text("254A, Supplement 3: The Gamma function and the functional equation (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2016")])]

#text("[…] 34 from Supplement 2, at least in the case when is twice continuously differentiable and compactly supported), which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8276f0954b97549ceff275f57c29082e0589d500a659640812d803d6fbd0c170-0ea9f76c3e76b42cf50f9c9e28b096afd33cf0cef6e93d3b23a1c0acc573910a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-472600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("In the statement of Theorem 21, should the error term in the approximation formula for ")#mi("\\frac{f^{\\prime}(z)}{f(z)}")#text(" be ")#mi("O_{c_1,c_2,d}(\\frac{\\log M}{r})")#text(", where d is the number of zeroes of ")#mi("f")#text(" in the annulus ")#tao-math("c_1 < \\left|\\rho\\right| \\leq 1", block: false)#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-472604")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("No, because the bound (12) allows one to control the combined contribution of these zeroes, as explained in the proof.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-472619")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2016")])]

#text("Thanks! I’ve got it now.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-477027")[#strong[#text("254A, Notes 2: Complex-analytic multiplicative number theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2017")])]

#text("[…] come from the general theory of local factorisations of meromorphic functions, as discussed in Supplement 2; the passage from (4) to (2) is accomplished by such tools as the residue theorem and the Fourier […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6389ce7c3593c0b3fdeda317075cb3e693dae6b75f92170f2c10b5142adf7e37-9361ed76527be549df139beb8553b55a70326b3ee557f14c7cc2cd27658be283.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-481930")[#strong[#text("Five-Value Theorem of Nevanlinna – Elmar Klausmeier's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 5 June 2017")])]

#text("[…] 254A, Supplement 2: A little bit of complex and Fourier analysis, proves Poisson-Jensen formula for the logarithm of a meromorphic function in relation to its zeros within a disk […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0ad8628ed7b3559ee7d1c7c79ce140077a19786556a8f4f9a4f5a9ebd7a996e5-fb72ee89b825c5bfd2450d0e030ac82e73fda0b55ee3eb11778352b1349c45b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Helene")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-517702")[#strong[#text("Helene")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2019")])]

#text("In Ex. 35, is it enough to assume that $N \\geq 1,$ instead of $N >> 1?$")

#emph[#text("[The latter case already subsumes the former. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2014/12/05/245a-supplement-2-a-little-bit-of-complex-and-fourier-analysis/#comment-635697")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] 22 of Notes 2) it is a routine matter (using Proposition 16 from Notes 2 and Exercise 28 of Supplement 2) to arrive at the […]")
]
