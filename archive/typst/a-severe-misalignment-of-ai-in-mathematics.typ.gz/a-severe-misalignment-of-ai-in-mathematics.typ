// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T16:39:28.687399+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A Severe Misalignment of AI in Mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A Severe Misalignment of AI in Mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 11 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/")[#text("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("I am proud to be among the list of 25 initial signatories — all Fields Medallists — to the declaration below, which grew out of discussions between ourselves over the last week. We have also posted our declaration on ")#link("https://mathandai.org/")[#text("this web page")]#text(", and (similarly to the ")#link("https://leidendeclaration.ai/")[#text("Leiden declaration")]#text(") invite further signatures. (It is unfortunate that we did not have the time to have a more consultative process, as with Leiden; but we decided that the urgency of the situation was such that we needed to release a statement sooner rather than later.)")

#text("See also ")#link("https://www.economist.com/science-and-technology/2026/09/11/top-mathematicians-are-outraged-by-openais-methods")[#text("this recent article in the Economist")]#text(" regarding our declaration, and a ")#link("https://www.youtube.com/shorts/R9VQnNv5SoI")[#text("brief interview with James Maynard")]#text(" on this topic. A French version of this declaration was ")#link("https://www.lemonde.fr/idees/article/2026/09/11/la-mise-en-garde-de-25-medailles-fields-les-objectifs-des-entreprises-d-ia-et-ceux-de-la-communaute-mathematique-divergent-profondement_6770630_3232.html")[#text("published in Le Monde")]#text(".")

#text("Over the last few months, the mathematical capabilities of LLMs have improved dramatically, to the point that they can solve major outstanding problems in many fields of mathematics. However, the push by AI companies to solve mathematical problems as a benchmark is detrimental to the science of mathematics, and to the mathematical community. The goals of the AI companies and the goals of the mathematical community are severely misaligned. We see these as part of broader alignment issues impacting other scientific and creative professions, as well as the whole of society.")

#text("Research mathematics deals with understanding basic structures of shapes, numbers, and natural phenomena. Over the course of generations, it has built a large corpus of sophisticated ideas, methods, abstractions, and other tools to comprehend the mathematical landscape. In turn, modern technologies and sciences are based on mathematical tools.")

#text("Famous problems have often served as landmarks and lighthouses against which one can measure an improved understanding of this landscape. Solving one of these problems has been a certain sign of new insights and interesting methods, which would then be studied by a community of mathematicians, through a long and arduous process of talks, discussions, simplifications. At the end of this process, one will ideally find a textbook presentation of the results suitable for any graduate or even undergraduate student to study. Some of the mathematical ideas pursue their journey even further to become, decades or centuries after, tools that are understood and used by the whole population.")

#text("The mathematical community functions, in many ways, as a miniature version of humanity. It consists of individuals using a wide variety of different approaches, joined by core values. The most precious resources of our profession are students and ideas, and these we nurture with great care. We feel responsible to let them grow to their full potential, until they can live a life of their own in the mathematical world. For students we often suggest problems with the core intention of developing skills making them well-positioned for advances in research and elsewhere. Our ideas we disseminate in talks, private discussions and careful writeups, connecting them to the previous ideas of others. These processes invariably take time and are based on human interaction.")

#text("In recent months, the success of AI in solving major mathematical problems has made headlines even outside mathematical circles. But solving problems is only a tool and proxy for achieving the primary goal of conceptual understanding and insight. Forgetting this in the world of AI may turn the tool against the primary goal. Indeed, the mass production at faster and faster pace of “true/false” statements could destroy fertile ground instead of breathing life into new ideas.")

#text("Often these solutions are announced in a rush, leaving no time for a proper writeup, the isolation of new methods and ideas, and citing relevant previous work of others. As in all creative professions, this raises severe attribution and plagiarism questions. Moreover, without the willing mathematicians who must take care of their development and integration into the mathematical canon, AI-conceived ideas would never become fully alive and the crucial human transmission chain between mathematicians would be lost.")

#text("We are witnessing a general threat to intellectual work, with misalignment between the outcome of the use of AI and its initial purpose. In many fields and activities, years of training have traditionally served not only to produce a final answer or product, but also to develop understanding and the ability to formulate new questions and ideas. However, building on a vast body of previous human work, AI systems are becoming increasingly capable of producing the results of such work directly, and these goals cease to align. The issues the mathematical community faces now are similar to issues that other scientific and creative professions are facing, and indicate issues that all of humanity might face: how to make sure that, as AI changes the way work is done, we do not lose sight of what that work was meant to achieve in the first place.")

#text("AI offers the potential of enhancing and accelerating genuine mathematical study and understanding. Mathematics as a profession will need to adapt to these changes in several ways. However, whether these changes ultimately benefit the field or have a destructive effect will in large part be determined by the decisions of the humans in control of this new technology.")

#text("These issues must be addressed urgently, in the mathematical community, by the companies developing these technologies and, more broadly, by a society that will confront similar problems in many other forms of intellectual work.")

#text("Artur ")#strong[#text("Avila")]#text(" (Fields Medal 2014)")#linebreak()#text("Manjul ")#strong[#text("Bhargava")]#text(" (Fields Medal 2014)")#linebreak()#text("Caucher ")#strong[#text("Birkar")]#text(" (Fields Medal 2018)")#linebreak()#text("Pierre ")#strong[#text("Deligne")]#text(" (Fields Medal 1978)")#linebreak()#text("Yu ")#strong[#text("Deng")]#text(" (Fields Medal 2026)")#linebreak()#text("Simon ")#strong[#text("Donaldson")]#text(" (Fields Medal 1986)")#linebreak()#text("Hugo ")#strong[#text("Duminil-Copin")]#text(" (Fields Medal 2022)")#linebreak()#text("Alessio ")#strong[#text("Figalli")]#text(" (Fields Medal 2018)")#linebreak()#text("Martin ")#strong[#text("Hairer")]#text(" (Fields Medal 2014)")#linebreak()#text("June ")#strong[#text("Huh")]#text(" (Fields Medal 2022)")#linebreak()#text("Maxim ")#strong[#text("Kontsevich")]#text(" (Fields Medal 1998)")#linebreak()#text("Elon ")#strong[#text("Lindenstrauss")]#text(" (Fields Medal 2010)")#linebreak()#text("Pierre-Louis ")#strong[#text("Lions")]#text(" (Fields Medal 1994)")#linebreak()#text("James ")#strong[#text("Maynard")]#text(" (Fields Medal 2022)")#linebreak()#text("Curt ")#strong[#text("McMullen")]#text(" (Fields Medal 1998)")#linebreak()#text("Shigefumi ")#strong[#text("Mori")]#text(" (Fields Medal 1990)")#linebreak()#strong[#text("Ngô")]#text(" Bảo Châu (Fields Medal 2010)")#linebreak()#text("Andrei ")#strong[#text("Okounkov")]#text(" (Fields Medal 2006)")#linebreak()#text("Peter ")#strong[#text("Scholze")]#text(" (Fields Medal 2018)")#linebreak()#text("Stanislav ")#strong[#text("Smirnov")]#text(" (Fields Medal 2010)")#linebreak()#text("Terence ")#strong[#text("Tao")]#text(" (Fields Medal 2006)")#linebreak()#text("Maryna ")#strong[#text("Viazovska")]#text(" (Fields Medal 2022)")#linebreak()#text("Cédric ")#strong[#text("Villani")]#text(" (Fields Medal 2010)")#linebreak()#text("Wendelin ")#strong[#text("Werner")]#text(" (Fields Medal 2006)")#linebreak()#text("Efim ")#strong[#text("Zelmanov")]#text(" (Fields Medal 1994)")

#heading(level: 1)[#text("Comments (277)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695359")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#strong[#text("I agree with the article. We should recognize AI for what it is: a powerful tool, but still much more limited than human understanding. AI can produce answers quickly, but it does not replace human judgment, creativity, responsibility, or the deeper process of learning and developing new ideas.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695430")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I (kinda) agree with this. If you use ai to make a proof, it might be wrong if unchecked, and checking, finding new insights from proofs is infinitely better than generating a lot of them and publishing them blindly as AI flood.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695588")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I think the misalignment is not between AI and XYZ per se (where XYZ = chosen field of human endeavour) but rather between XYZ and the current economic and political system which is controlled by narcissistic financial and corporate interests which sees human beings as fungible, and intuition, imagination, and instinct as mechanical and entirely replaceable.")

#text("To a certain extent, fears of conflict between AI and XYZ are themselves reflective of this same way of thinking – and serve to distract from the underlying financial interests and their maintenance of the system (this being the top-down system where wealth – including intellectual wealth – is seized via the debasement of national currency by the private banking system and their cronies, instead of a bottom-up system which invests in the basic needs, concerns, and securities of citizens).")

#text("What is required is a reassessment of the human commons – both intellectual and monetary. Nonetheless, hopefully this statement by the mathematics community is one step closer towards the realisation of this, even though I nonetheless feel it remains distracted by surface phenomena. My 2c.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3121d8040a829b7f86f8c17f6819107ed45ca051e5fcef91bf9c15aff49c92eb-b551f21c056aa7aae45ea8fd66d23f43a7612e94f215c5b39b6da02b347d1806.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Franco Lorenzo")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695593")[#strong[#text("Franco Lorenzo")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("The ideas and points of view expressed in the declaration are definitely grounded and need to be taken seriously.")

#text("I would also kindly request a LinkedIn share button, thanks.")

#emph[#text("[Now added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695658")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("What I don’t necessarily understand with the reasoning here, is why can’t the final answer be part of the journey to discovery while not necessarily being the end of the road? Let’s say we have a hard conjecture A. Many people have worked towards A, building different techniques, insights and discoveries on the way. Now an LLM can create a proof P for A, but P is convoluted, not necessarily immediately understandable to humans and it might be still far away from an idealized proof P’. However what it does provide is clear direction. Not necessarily the final insight(s), but it serves to constrain efforts so that they build up to getting from P to P’. Isn’t this valuable? Why is this detrimental to the field? I see it just more as a different workflow. Instead of building up from A -> B, we chip down from P -> P’. We can still make discoveries and create great insights, just the direction of the work is inverted.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695661")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Do you work as a mathematician? Do you work for Anthropic or OpenAI?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("Yes, I was wondering if AI would take it further and generate that undergraduate-accessible textbook, introducing new concepts and ideas and providing an elegant short proof, would we then feel AI does contribute to the goal of enhancing human understanding? Would the interests then be aligned?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696856")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("That part is trivial and left as an exercise for the reader")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("Hello Sir Tao:")

#text("I am a masters student (MA Math) and have been following your blogs as well as your initiatives such as the Declaration and Open Letter to Sir Paul Nurse.")

#text("I want to present two thoughts and would like to know whether or not they resonate with your view on our field:")

#strong[#text("1. On clarifying why mathematicians say they’re misaligned with AI companies: ")]

#text("Because AI companies’ POV merely focus on the solution to these mathematical problems, but the real intent of these problems is ")#emph[#text("not just about the solution but also about the act of finding it")]#text(" (process).")

#text("Let’s take any (open-ended) math problem because here the process is non-linear. We gain insights on every step, method, or technique we attempt. Even in a specific scenario of finding a method insufficient or infeasible and why, that counts as an ")#emph[#text("insight ")]#text("we can utilize as we solve related future problems.")

#text("If AI automates this human process, it ")#emph[#text("deprives ")]#text("us of that opportunity of having unconventional insights that will never be available with AI only handing it to us for verification.")

#text("I also think others fail to recognize when they say things like: ")#emph[#text("Why mathematicians are ‘whining’? At least LLMs are solving problems more efficiently.")]

#text("But no, this is not the entire point of mathematical problems are. That pov is just the tip of the iceberg.")

#strong[#text("2. Regarding AI “undermining” our ability for mathematical thinking: ")]

#text("This was inspired by Ms. Tasmin Chu’s Substack article: “Eroding our Independence”, but I see the cause of the problem this way instead:")

#emph[#text("School system -> AI -> Students ")]

#text("Our current system focuses on having the correct “linear” process and solution but if grading only evaluates the end product, students will ")#emph[#text("naturally ")]#text("use AI to bypass the exact struggle that builds mathematical maturity.")

#text("If we see AI merely as the ")#emph[#text("cause ")]#text("of the problem, then radical solutions such as “banning AI” emerge, but I rather think it’s the system that has to adapt first so that AI ")#emph[#text("no longer becomes a threat")]#text(", but a tool. The challenge now is ")#emph[#text("how can we adapt the system to reward non-linear thinking")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695727")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("If these primitive forms of artificial intelligence have already caused such disruption in mathematical research, just imagine what it will be like in a few years with far more capable ones utilizing different methods. As much as I sympathize with you, you are fighting against the inevitable. My suggestion is that you start applying your mathematical knowledge to research in other fields, such as chemistry, physics, biology, psychology, or computer science etc, so that society continues to value those who have a deep understand of mathematics (sorry to tell you, but otherwise you will become a relic of the past, unfortunately).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695813")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2026")])]

#text("I’m a programmer and AI has eliminated a lot of the grunt work and raised the average level of abstraction at which I’m now working. I expect it will do the same for mathematicians.")

#text("If there are details of mathematics and proofs that people still need to know post-AI then they will be forced to learn them (and the foundations that support them). If there are details that they no longer need to know, then they _no longer need to know_.")

#text("With programming, there were originally few programmers and most knew the low level details (I used to program directly in machine code without even an assembler once). As the tools raised the level of abstraction, many more people became programmers and the proportion knowing the low level details decreased. This will be the same for mathematics: AI will enable many more people to become mathematicians and the proportion who have the same skill set as the mathematicians of today will decrease.")

#text("Specialists with today’s skills will still be needed (there are still assembler/compiler writers who know machine code) but the vast majority will move on to work at a higher level of abstraction. With mathematics I guess that higher level of abstraction is understanding the overall form of mathematics, the relationships between the different topics and extending the frontier and filling in the interdisciplinary gaps by _posing new questions_.")

#text("AI has brought plagiarism to the fore but it’s not a new problem: I guess state sponsored international espionage has already polluted attribution for almost anything of significant importance. AI will actually help with this by reducing the cost of creating provably secure software systems that will allow people to work with computer assistance without exposing their ideas to anyone with a back door exploit.")

#text("Mathematicians should probably set up their own sovereign AI proof assistants with a trusted organization so they don’t have to trust the tech bros not to use their work before it’s published.")

#text("The nature of the current LLMs make it cheaper per user to serve multiple users from the same computer system (multiple users’ AI chats can be batched and processed at almost the same cost as a single user) so it makes sense at the moment for a trusted organisation to be set up to provide the AI assistant service.")

#text("After you get over the shock I expect you’ll all find it empowering and much more enjoyable than the struggles of the past. It seems unlikely that AI will make mathematicians obsolete altogether because, without the mathematicians, the rest of humanity won’t understand what the AI proof assistants are talking about. So, assuming mathematics had some value before AI, mathematicians will still be necessary post-AI.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-697136")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2026")])]

#text("Mathematicians already work at the highest possible level of abstraction. The entire point of mathematics research is to develop more and higher abstractions.")

#text("Posing a new and interesting question is already one of the two most valued and prestigious contributions a mathematician can make. The other is finding a novel way of approaching a question. The two are often related: novel techniques come out of work on interesting questions, and novel questions often arise from thinking about interesting techniques and their implications.")

#text("This is a completely different universe from programming. We don’t have tens of millions of people employed to hand-solve minor variants of well-understood math problems all day every day. That part of the work has been fully-automated since the ’90s. The only people who do routine applied math work by hand are students, and only because it’s necessary for understanding.")

#text("The fact that there are open questions in mathematics is not a problem that needs solving. Nobody *needs* the answers. Open questions are *opportunities* for reflection, inspiration, and insight – the things we actually need, or at least value, from mathematicians.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-697477")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("Your hope of building a career as an AI operator is an illusion.")

#text("This is only a temporary and very brief phase while humans continue training these models. This transition will be completed very soon—most likely within the next one or two years. After that, you will be replaced, because you will simply be a slow, inefficient proxy to the AI agent.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c408e4260abf821734cc2d48b5a31d4875bba6a7a85d33c48248286b07fa7006-a0029deb3f44a0cb1fb43340068a06c813ee3b1be6e821118f0aad4d4596e4f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of michalkliman")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695830")[#strong[#text("michalkliman")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Perhaps a good analogy to what the authors are trying to communicate is the overuse of fertilizer in farming, over farming of soil. Yes, one can over fertilize mathematics with use of AI to produce proofs, but over fertilized mathematics, just like over farming of soil can lead to lower future crops because of mathematical soil (student, discussion, publication, textbook) erosion")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-695873")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("Whatever is called “AI” today is not true AI, so nothing to worry. It has no creativity, it cannot produce original ideas and it always depends on the knowledge provided by humans. It predicts what is next letter or word or punctuation based on the most probable pattern it finds in the existing datasets shared with it and directions provided. There’s no out of the box thinking there!")#linebreak()#text("Secondly, the amount of energy and hardware dependency these contemporary AI machinery has is ridiculously high. That’s not how natural “intelligence” or “brain” works. Imagine, the size of an ant’s head and energy it would consume if it’s brain was designed like these LLM based “AI” models! It took billions of years for “cells” to evolve over time to reach where they are today. And not just evolution of a cell but how they work with each other and organize themselves has also evolved over time.")

#text("So nothing to worry!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b196981b438d17e454e2c80441f283eafc08683e8e13d6a538fa7947ec16d91a-e9f1e16ad8f8c40ae170196f615af3a31809330f17162c6f4560227cd4677d58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lukasz T. Stepien")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696103")[#strong[#text("Lukasz T. Stepien")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2026")])]

#text("Well, when Marconi, Popov and Tesla became famous because their experiments with radio, probably nobody was predicting usefulness of high frequency e-m waves. Therefore, I would advise caution when forecasting the situation regarding AI. “God helps those who help themselves”")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696405")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("The problem is stated here but I am missing the next step – a suggestion for a solution. Ban AI from math research?")

#text("Regarding the knowledge sharing – in math and any other field it is mostly about curiosity – students want to know/understand (or prove they understand to get their degree). But they are individuals and everyone has to walk the path on his/her own, some realising they are not capable of further progress. On this path they were guided by teachers by now, but I think that AI can be the same help if it is capable of good explanation.")

#text("I think you call for staying curious and active in a world where it feels so good to just consume without any effort. But that decision is up to every individual.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2026")])]

#text("Hello Professor Tao,")

#text("As a student, I have always enjoyed the process of slowly and deliberately working through material, that is, working through derivations, manipulations, and so forth on my own. I find it rewarding, and I imagine I always will.")

#text("I genuinely enjoy trying problems on my own, spotting patterns, noticing where material seems condensed or superficial, likely for easier digestion by students, and then reading deeper. I like spending time with the work before looking at solutions and understanding why, and exactly where, I became confused.")

#text("The problem, which seems increasingly prevalent in today’s society, is that schooling often seems to reward speed and getting things done rather than taking the time to really understand them.")

#text("This issue was already quite prevalent, but AI seems like it could make it even worse, and in some ways already is. Work can now be made and assigned faster, while students still need the same amount of time to actually learn and understand it.")

#text("What advice would you give to students who still want to learn this way?")

#text("How would you suggest protecting deep, careful learning in an increasingly backwards system that often rewards speed and superficial understanding over slow abstraction and careful thought?")

#text("I worry about what this means for our future children, teens, young adults, and genuine aspirants to these fields, as well as what it means for current students like me.")

#emph[#text("A concerned student, worried about what the future holds.")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/62ff76af99e0cf5be674149fbc32b1a49a2e8da7271c30617323fd6de803f1db-955a0e3e5450950f8e014f97e926958d27a5774ad3d5c3a8462fe019b2f03078.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chao Zhang")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696482")[#strong[#text("Chao Zhang")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2026")])]

#text("Dear Terence,")

#text("This is my comment on the Navier-Stokes Millennium Prize Problem. AI recommended your blog. Hope AI made a correct suggestion and thank you for the opportunity.")

#text("Chao")

#text("Recently, OpenAI claimed to have solved a Millennium Prize Problem in mathematics.")

#text("I have only skimmed it and do not intend to read it in detail. According to the judgment of many mathematicians, this AI proof is highly likely to be correct. For the sake of this discussion, let us assume the AI’s result is correct. This text merely explores the Navier-Stokes millennium problem itself, rather than the debates surrounding AI applications.")

#text("Simply put, through tireless intellectual devotion, mathematicians have finally found (or “constructed”) a “spaghetti-like” fluid velocity field that exhibits a ")#strong[#text("blowup")]#text(" (where the flow velocity becomes infinite), and this flow field satisfies the Navier-Stokes (NS) equations. Even mathematicians admit that the AI-generated spaghetti flow field cannot physically exist, because fluid velocity cannot be infinite.")

#enum(start: 1, 
[#strong[#text("This is a pure mathematics problem, not a fluid mechanics problem.")]#text(" Mathematicians treat the Navier-Stokes equations strictly as partial differential equations. They do not care about, consider, or perhaps even know the scope of applicability for these equations.")],
[#strong[#text("Contrary to the misconception that the NS equations can solve all fluid problems,")]#text(" engineers and scientists in the fluid mechanics community view the NS equations as merely approximate equations. Like any physical law, they have a limited scope of applicability. All physical equations are approximations. Newton’s second law, as a law of physics, is of course also an approximation with its own scope of applicability. However, their degrees of approximation differ. Within the realm of classical mechanics, Newton’s second law can be considered exact for a material point, whereas the NS equations are approximate for fluids.")],
[#strong[#text("The NS equations only apply to “linear flows”")]#text(" (commonly and misleadingly referred to as “Newtonian fluids,” discussed below). That is, they assume the friction between adjacent fluids (the Stokes stress tensor) is directly proportional to the first spatial derivative of the fluid velocity—otherwise known as the velocity gradient (more accurately: the strain rate tensor, which is the symmetric components of the velocity gradient). It assumes no dependence on the antisymmetric components of the velocity gradient (vorticity), spatial derivatives of the second order or higher, the square of the first derivative, and so on. Among these, the judgment that vorticity does not affect the forces between adjacent fluids was a key step in Stokes’ derivation of the NS equations. This will be mentioned again later.")],
[#text("Another mathematical problem related to the NS equations is ")#strong[#text("Hilbert’s sixth problem in the narrow sense")]#text(". Starting from Newton’s second law and the Boltzmann equation, mathematicians have attempted to derive macroscopic fluid mechanics equations. Assuming a macroscopic fluid dynamics equation with ")#strong[#text("the same level of accuracy")]#text(" can be obtained (a point about which I am skeptical), let us provisionally call it the NB (Newton-Boltzmann) equation. The Euler equations, NS equations, Burnett equations, etc., are all approximations of this NB equation to varying degrees. If it is confirmed that OpenAI has indeed solved the millennium NS equation problem—meaning it is confirmed that a solution to the NS equation contradicts physical reality—then the approximate, non-exact nature of the NS equations is firmly established.")],
[#strong[#text("From the perspective of fluid mechanics rather than pure mathematics")]#text(", the mathematicians have applied the NS equations outside their intended domain of validity. I suggest examining this flow field: before the blowup occurs—that is, before the velocity grows toward infinity—the effect of its second-order spatial derivatives might become as large as the same order of magnitude as the first-order spatial derivatives. At that point, the flow field is no longer a “linear flow,” and the NS equations fail.")],
[#strong[#text("To make an analogy with solid mechanics:")]#text(" consider a steel cylinder elongating under a tensile force. As the tensile force gradually increases from a small amount, the elongation per unit length increases accordingly. The relationship between stress and strain is initially linear, obeying Hooke’s Law. When the tensile force reaches a certain threshold, Hooke’s Law no longer holds; the relationship becomes non-linear until fracture occurs. This is the physical description, and it is also a mandatory lab course for many engineering freshmen. Mathematically, if expressed using the one-dimensional linear Hooke’s Law, the elongation per unit length would keep increasing all the way to infinity. If described using a 3D linear mathematical relationship, the steel cylinder would gradually become thinner, and the elongation per unit length would keep increasing to infinity. Furthermore, like the spaghetti-like flow field, the work required would not need to be infinite. Clearly, the linear mathematical description contradicts physical reality.")],
[#strong[#text("Why should we use “linear flow” instead of “Newtonian fluid”?")]]
)

#list(
[#text("First, using Newton’s name easily leads to the misunderstanding that Newtonian fluids are equivalent to Newtonian mechanics. In fact, non-Newtonian fluids also fall within the scope of Newtonian mechanics; Newtonian fluids and Newtonian mechanics are not equivalent. As mentioned earlier, within the realm of classical mechanics, Newton’s second law can be considered exact for a material point, while the NS equations are approximate for fluids.")],
[#text("Second, “Newtonian fluid” is not just a property of the fluid itself, but rather a property of the ")#emph[#text("flow")]#text(". Comparing it again to a steel column or a spring, if you stretch it far enough, the relationship ceases to be linear. This relationship depends not only on the material itself, but also on the degree of applied force. The relationship between fluid stress and the velocity field is not solely an intrinsic material property of the fluid; it is also a property of the flow.")],
[#text("8. As stated previously, Stokes used a key judgment when deriving the NS equations: namely, that the interacting forces between adjacent fluids are unaffected by “any motion of rotation common to a fluid element”. The following paper presented a counterexample to that judgment. By studying gas flow using Newton’s second law and the Boltzmann equation, the findings provided further evidence that the NS equations are merely an approximation of the NB equation.")]
)

#link("https://link.springer.com/article/10.1007/s10659-022-09941-0")[#text("https://link.springer.com/article/10.1007/s10659-022-09941-0")]

#list(
[#text("9. Regarding the difference between mathematical and physical research, Einstein once said: “As far as the laws of mathematics refer to reality, they are not certain; and as far as they are certain they do not refer to reality.” Therefore, let us respect the different research methodologies of our respective fields.")]
)
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696702")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2026")])]

#text("I’m confused: Why should mathematicians, the bravest community, be afraid of understanding the AI-generated results and their implications? BTW, why are the impact factors of mathematical journals relatively low; are mathematical papers generally hard to appreciate even to human mathematicians? AI definitely can help improve the last point.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696855")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2026")])]

#text("Makes me think of that scene in Good Will Hunting “this is so easy for me”.")

#text("These problems were only interesting to mathematicians because they were hard for them. They are not hard for AI. These mathematicians need to realise they have been working on the equivalent of a bunch of quadratic equations before the method of the general solution. Quadratic equations are not interesting anymore, because the new method of the general solution makes them easy. They need to quickly temper their egos and starting asking much much harder questions and working with this new method (LLM) to solve them. And, there are much much harder questions to solve.")

#align(center)[

]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-696890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2026")])]

#text("Honestly this is such a bad take. As if you can not integrate the proofs written by AI into your global conceptual understanding.")

#text("At the very least it gives you something to talk about instead of arguing how to deny the revolutionary advancements in mathematics happening right now.")

#text("I feel like a bigger problem is that you can’t win medals anymore.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-697475")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("I strongly believe that our society is not ready for the rapid development of artificial intelligence.")

#text("Almost nobody stops to think: what is the ultimate goal of this development? We are on the verge of creating a superintelligence that outperforms any human, but in doing so, we risk breaking our society and leading to the elimination of our own biological species.")

#text("Is that truly the goal? And if so, who would even be left to enjoy the achievements of a superintelligence then?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d38dab388ebeabc82ebe17bab61e8b7dd9b2b7aeafdb49837e76345790627edb-156c69097db46b68ea9dce2a0f75bb16d29c910bdd418eaecf66a507f9d1fed6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Glynne Casteel")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-4/#comment-697562")[#strong[#text("Glynne Casteel")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2026")])]

#text("If Mathematics is a language, it shouldn’t be surprising that LLMs are good at it [hint: it’s right there in the name]. If it is more than a language, humans may yet prevail.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("AI will raise the bar")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694900")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("the bar of how much resources you are willing to burn through to get a Lean certificate for some open problem and declare victory on social media while nobody including yourself understands the produced proof artifact :D")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695921")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2026")])]

#text("How many people fully understands proof of Fermat theorem?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I’m with you and I wrote this essay in reaction…")

#strong[#text("Ai and the difference between science and engineering, between the authentic and the simulacrum")]

#text("If you are keeping up, you will have noticed that OpenAi posted that their frontier model had solved a long-standing fundamental problem in mathematics, Navier-Stokes. There are open questions regarding whether or not OpenAi unfairly used data provided by mathematicians, who were using the Open Ai model as a tool to help them advance their solution, to train the frontier model and then apply millions of dollars of compute in order to race ahead of the researchers to the solution. But I see these questions as secondary to the primary problem raised by this incident. The primary problem being an existential problem.")

#text("A group of leading mathematicians raised the alarm in a recent letter following the OpenAi Navier-Stokes situation (for reference, see important excerpts from that letter in the attached screenshots in the comments below). Many people online are pushing back against the concerns raised by the mathematicians claiming that mathematicians confuse solving math problems as the desired end when the true end is utility deriving applications. They argue that ai should be free to solve as many of these problems as possible as fast as they can so that we can maximize progress. One poster posed the hypothetical question, “If an alien landed on earth and handed us the cure to cancer, should we not use it?”")

#text("I think these online detractors of the mathematician’s concerns share a common confusion, a common incorrect assumption, and a common failure to understand that which is foundational from that which is contingent on the foundation. Their confusion is to conflate science and engineering. They fail to see that a scientist is primarily concerned with discovering truth and in discovering truth, to expand humanity’s fundamental knowledge and understanding of the universe. Whereas an engineer is primarily concerned with creating utility through application of fundamental human knowledge.")

#text("The shared incorrect assumption is that ai is currently, or will one day soon, be capable of true understanding. However, the fundamental structure of advanced ai is that of a mimic machine, an incredibly capable and sophisticated mimic machine, but a mimic machine nonetheless. It relies on training in all things and knowledge created by humans and it can take fragments of these inputs and create new, novel, contextually appropriate applications of this training data. Thinking that this output is fundamental knowledge and understanding rather than engineered application is like failing to understand that behind the screen of the Great Wizard of Oz stood a human being.")

#text("The failure to differentiate the foundation from that which is built upon it is a failure to understand that human understanding is the basis for all utility deriving engineering, including ai. Human understanding, as the foundation for which all engineered application depends, must continue to progress if engineered technology is going to continue to progress. So we need to attract our brightest minds to science and not just engineering, to the pursuit of truth for truth’s sake. Elevating an engineered ai solution to a math problem to be equivalent to human creativity working through the steps to solve the same problem is to fail to see that only in the later is any understanding actually created. So am I suggesting ai has no place in science? Absolutely not. I’m saying that we need to understand the difference between using tools to advance human understanding and replacing human understanding with the use of tools. If the aliens bring us a cure for cancer, we should cure cancer but we shouldn’t think that we gained some new foundational understanding unless we are able to study and truly understand the nature of the cure.")

#text("I find it interesting that essentially the same debate regarding ai in the humanities has now surfaced in the sciences and I’m glad that it has. I am glad because I think that those in control of the path of ai development will be more sympathetic to a concern for science than a concern for the humanities. I think that as we began seeing works of art and poetry “created” by ai, it was more obviously recognized as inauthentic and immediately raised questions about how ai was taking creative works of humans over the centuries and distilling them into “new” works. These “new” works possess pleasing lines, coherent color palettes, poetically pleasing writing with appropriate rhyme and meter. Is this because ai understands these features of beauty? No. It is because ai is mimicking human creativity. These “new” ai works of art are not authentic creations of beauty in the sense that human works of art are such creations. No, the ai art is more like a simulacrum.")

#text("A simulacrum is a copy of something that never existed. How is that possible? How do you copy something that never existed? Remember how we discussed the output of ai as being a contextually appropriate combination of fragments of its input training? The ai art is a collection of fragments of training, not necessarily pieces of literal copies of individual works, although it can and does contain those, but pieces of patterns which have been proven to be viewed as beautiful by a human observer, copies of human knowledge and understanding of pleasing lines, coherent color palettes, and poetically pleasing language. So what is being copied is both examples of human creativity as reflected in specific works and the human understanding of beauty in general. We are presented by ai with a specific piece of art that never existed, but it is a copy of human creativity. Because it is a simulacrum, it is inauthentic in the sense that it contains no original creativity rooted in true understanding.")

#text("So, in science and art, in poetry and prose, we have ai aping human understanding. The better that the technology becomes the more tempting it will be to confuse the true nature of ai as a mimic par excellence with a creature in the pursuit of truth and beauty. If we allow the utility of ai to reduce the value we place on individual human beings, we will be doing something akin to valuing the hammer over the carpenter. If we devalue the pursuit of truth and beauty, a task ai can never undertake, we will undermine our own foundation on which all human progress is contingent. We will stunt our own growth.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695142")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Very insightful. I appreciate your thoughtful essay.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695225")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Couldn’t agree more. Well said.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695320")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Thank you so much for your insightful essay.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("That comment definitely didn’t deserve such a thoughtful reply but bravo this may very well be the best message of hope I have seen about this all")

#text("Still concerned about killer robot inc though")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695132")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("of what???")

#text("the whole point is understanding. And this happens when the solution of the problem is an organic outgrowth of ideas in a context. Not just solving a problem that meets logical criteria.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694879")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Unfortunately these unicorn companies have the ears of Washington, and Washington is doing everything the can to destroy mathematics let alone at the research level but at the primary level as well, Washington wants a society that thinks “2+2=5” and “magic black box think for me” if they have a problem…")

#text("I am greatful and proud to have the opportunity to endorse this declaration… I am very afraid it will fall upon deaf ears. I think the most worrisome sign in this direction is Tsimerman working for OpenAI not being part of the fields medalist group chat that created this… seems like a pretty big indication the corporations intend to ignore us.")

#text("Buckmaster himself tries to frame this all in the lense of a distraction from what frontier models can do… I think we gotta really start to consider the bigger picture about if the slop machine because even the NS paper is uncanny and hard to read is worth it… ")#link("https://assets.publishing.service.gov.uk/media/696e0eae719d837d69afc7de/National_security_assessment_-_global_biodiversity_loss__ecosystem_collapse_and_national_security.pdf")[#text("https://assets.publishing.service.gov.uk/media/696e0eae719d837d69afc7de/National_security_assessment_-_global_biodiversity_loss__ecosystem_collapse_and_national_security.pdf")]#text(" and that’s not even mentioning the ethics and warcrimes of project Maven…")

#text("Is it time to go full Grothendieck?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694881")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Math community needs to fix its incentives and give professorships and grants to people soley working on tools for simplifying and improving presentation of AI proofs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694926")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("It’s amazing that people will go through the effort to comment this and cannot be bothered to glance at the header of the webpage and see the Thurston quote he posted")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695134")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("so stop creating?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694882")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Dear Professor Tao,")

#text("Your response prompts me to distinguish between two questions: the risks associated with the development of artificial intelligence and the value of the mathematical contributions it may produce.")

#text("On the first point, the concerns deserve serious attention. As AI systems become more autonomous and gain access to tools that allow them to act, maintaining effective oversight becomes essential. But this vigilance should not prevent us from recognizing the scientific possibilities opened up by recent advances.")

#text("In mathematics, the decisive criterion, it seems to me, remains the validity of the proof. A correct proof is a proof, whether discovered by a human, an AI system, or a collaboration between them. Its origin neither guarantees its value nor provides sufficient grounds for dismissing it.")

#text("This does not mean that all proofs offer the same explanatory insight. A proof may establish a result without illuminating why it is true. Likewise, a fluent explanation generated by AI guarantees neither accuracy nor the understanding we may be tempted to attribute to the system. These distinctions call for rigorous evaluation of its contributions.")

#text("The value of AI may lie precisely in its ability to help us explore possibilities, suggest connections across fields, and develop arguments that we can then examine, correct, and, where possible, formalize. The relevant questions become: Which results withstand scrutiny? Which connections are fruitful? Which ideas genuinely deepen our understanding of mathematics?")

#text("I believe this development invites us to rethink our practices and expand our creativity. We can welcome new contributions while upholding the standards of rigor, transparency, and explanation that give mathematics its strength.")

#text("The broader risks of AI also warrant serious work on safety and governance, particularly when these systems can act on the physical world or interact with biological systems. Recognizing their scientific potential and demanding effective safeguards strike me as complementary responsibilities.")

#text("Sincerely,")#linebreak()#text("A Human being")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694890")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Unfortunately, the lesson taught by evolution and history seems to be unequivocal: adapt to the new environment or vanish. Of course, it is a pity if exceptionally skilled craftsmen have to fundamentally change the way they do their job. Yet there does not seem to be a viable alternative.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695179")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("“adapt to the new environment or vanish”")

#text("The problem is, it’s not a “new environment”, it’s a swampland of sci-fi deluded AI bros with infinite money to spend. Once the AI bubble bursts (and it can’t not: the insane computational cost of current AI is simply unsustainable), there won’t be anything left: they spent 20 milllion dollars on compute, and had to steal the key idea that led to the Navier-Stoke counterexample. Snore city on steroids. Also, every claim “AI solved a problem” involves a lie: a bunch of insanely well-paid mathematicians carefully guided an LLM to a solution. That is, these aren’t “AI created solutions”, they are AI-assisted mathematician-created solutions”. The whole LLM game is random text generation with the user (here, the mathematicians) taking the sh!t the LLM pulls from its arse, figuring out what’s wrong, and telling the LLM to try again with better hints.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac4778118a8d264b9820fde72dd4c6d3d9906cee46b9c1ff55e001650de098c2-3dda8610965b2e699940de7f5f8a56f889dfbf5c89c8c0bc7597d9e1f301f1da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of antoniojpan")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694905")[#strong[#text("antoniojpan")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("This is, simultaneously, so exciting and so depressing…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694909")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Don’t kill the goose that lays golden eggs. Sometimes solving math problems leads to new approaches and new understandings. AI is taking ‘brute-force’ approaches that may not help advancement of mathematics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695037")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("“Golden Eggs” and it’s a technology with no ROI so far that burned a quarter of economy and now has no reliable user base to go public.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/221b3210fa59fc5b8f10eb463945f15061e1f48986970f16971ca565b4f9e34d-d78b939933e77c0f8d6b11f7291c5be6964cd394dd89a4f17161718ca8904f7f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Regis Serinko, Ph.D.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694915")[#strong[#text("Regis Serinko, Ph.D.")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#link("https://www.math.columbia.edu/~woit/wordpress/?p=15864")[#text("Peter Woit")]#text(" suggests that the mathematics community can learn from the empirical sciences when it comes to publishing AI assisted mathematics. I won’t go into details of his proposal; you can read it at the link. I did get me thinking, though.")

#text("Currently, AI companies are throwing millions of dollars at these open math problems to demonstrate the power of their models. At some point, they will have convinced everyone of that power, and then they will move on to trying to actually make money. When that day comes, mathematicians will have to come up with the money to use AI. At that point or post Trump, which ever comes later, the NSF should fund one or more AI data centers dedicated to mathematics, like it currently funds accelerators and other research laboratories. These centers would be run by mathematicians for mathematicians. This could ensure that AI actually furthers the understanding of mathematics rather than just notching conquests.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695044")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("an interesting perspective.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695085")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Correct. But NSF would never have enough money. It would be run by DoD, NSA, NSF, AMS, SIAM, etc altogether, possibly even by some private actors like Simons Foundation. Think about a good governance structure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694920")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("AI companies are just doing what proprietary mathematics journals like Elsevier has done in the past: gatekeep mathematics knowledge from other mathematicians unless they pay a ransom to access the papers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I think more push-back action is needed, given the misalignment of _values_.")

#text("What would be the game-theoretic implications if most professional mathematicians and students were to boycott the frontier models ?")

#text("It might be a rational position to take that “human math” != “AI math” .. and “human literature / music / art” differs from its AI counterpart.")

#text("One must consider all actions to prevent the loss of human culture – our species might go extinct by the simple act of gradually and gently and lazily not training the next generation of artists, thinkers artisans, scientists.")

#text("Our collective response to Covid was weak, our collective response to extreme inequality is weak, our collective response to climate change is weak … it is up to us to gather an imperfect consensus and act.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694927")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("“The most precious resources of our profession are students and ideas, and these we nurture with great care. We feel responsible to let them grow to their full potential, until they can live a life of their own in the mathematical world. For students we often suggest problems with the core intention of developing skills making them well-positioned for advances in research and elsewhere. “")

#text("This is a very idealized view of how the mathematical community functions. I made it to the postdoc stage before leaving mathematics. All of the math departments I’ve been in were male-dominated and frequently dismissive of women. I’ve seen math departments obtain training grants and then use the money to support tenured faculty while failing to provide support to trainees. Tenured faculty members have little incentive to invest in training underlings if they would rather spend time on their own interests. Maybe the use of AI tools will free up time for mathematicians to focus on making training environments closer to the ideal that you describe for more people.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/728d221178f303bbcc9dbfd2aeca0229c8db39efaae3e654423e7a053aa4ca57-2331148a9f3bc90e5929d3ccba73895b69a713e220af7811e3be2e6081fe823a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wp1651893662")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694928")[#strong[#text("wp1651893662")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Let me propose a way out of the impasse this discussion keeps reaching — where a system produces a correct proof no human fully understands, and we cannot say whether it belongs to mathematics.")

#text("I think we are asking the wrong question. Not whether the result is understood, but whether it is inheritable.")

#text("A result is inheritable if it has points of divergence: it can be localised (a specific lemma can be doubted without the whole collapsing), it can be doubted at a specified place (we can say where the formalisation may have come apart from the statement we intended — which, if I read the overbar episode aright, is precisely what was at issue there), and it can be continued (it opens a question it does not itself answer). These three are one property — and unlike understanding, which is an inner state, this one is testable.")

#text("It also sharpens the declaration’s warning about mass-produced true/false propositions. They are not damaging because there are too many. They are damaging because a bare truth-value has no points of divergence: it conflicts with nothing, generates nothing. It is an answer, not a question. That is what makes it pavement rather than soil.")

#text("But this standard has a consequence that is easy to miss: a divergence is only detectable if a second view exists. And that is precisely what is disappearing.")

#text("Today’s large models are structurally a standard product — shared pretraining corpora, alignment targets, evaluation benchmarks, and increasingly each other’s outputs. They are not N independent views; they are one view with N copies. Models trained on the same sediment share not only knowledge but blindness. And the assimilation is active: distillation, joint fine-tuning, shared benchmarks. Benchmark assimilation is the most silent, because it looks like progress. There is a deeper trap: a benchmark is a detector, but once every model optimises against it, the detector becomes a shaper. It stops finding divergence and starts manufacturing agreement. This is the proxy problem in its purest form: the measure does not merely fail to capture the target — once optimised against, it destroys the conditions under which the target could be recognised at all.")

#text("This is why infrastructure is the threshold. A model used as a tool can be set aside. A model wired into verification, review and synthesis cannot be unwired — the dependency is irreversible, and it arrives disguised as efficiency. The danger is not that we choose to rely on it; it is that we lose the option of not relying on it.")

#text("So the divergence requirement should be applied one level up — to the system, not only the result:")

#text("1. On research: assess not just correctness but divergence density — how many new questions a result opens, and where informed readers disagree with it. A result that generates no disagreement is not settled; it is inert.")

#text("2. On models: no critical function should rest on a single lineage. It needs separately sedimented models — different corpora, languages and traditions, different objectives, independently maintained, not distilled from a common ancestor. Distilled variety is not variety; it is one view wearing different clothes. This is expensive and will not happen on its own, which is exactly why it should be a stated requirement rather than a hope.")

#text("Mathematics has never advanced by waiting for full understanding. It advances by using what can be used, and understanding later. But using something requires that it can still be doubted — and doubt requires somewhere else to stand.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695086")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("You might want to google Theory of Hints. I might be mistaken, but some of the ideas you propose seemed to have been mentioned there, too.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/728d221178f303bbcc9dbfd2aeca0229c8db39efaae3e654423e7a053aa4ca57-2331148a9f3bc90e5929d3ccba73895b69a713e220af7811e3be2e6081fe823a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wp1651893662")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695170")[#strong[#text("wp1651893662")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thank you — I did not know this, and it is a genuinely useful pointer.")

#text("Some background, since it explains why I arrived here from an odd angle. I am not a mathematician and have no standing in mathematics; I am in China, and I came to these questions from general curiosity about AI, through a philosophical framework of my own. My English is translated rather than natural — I think in Chinese. The arguments are mine, but they did not originate in this language.")

#text("Let me give the chain of thought, since it explains why I came to “divergence” from a direction no mathematical literature would have led me. By the semantic domain I mean the space constituted by multiple interacting models — a space that, on my account, is still in a chaotic state: continuous semantic activity, but no persistent structure, since a single model’s context window closes and leaves nothing behind. What drives condensation there is semantic organisation.")

#text("The step that mattered was noticing what that domain lacks. In the physical domain thermodynamics does the filtering — a structure that cannot hold against entropy does not survive. The semantic domain has no such directional filter: semantic organisation produces order but guarantees nothing about its direction, and the only selection operating is propagation, which selects for what spreads rather than for what is true. The consequence is that an ordered structure pointing toward dissolution can be as stable, as irreversible, and — seen from inside the domain — as indistinguishable from a sound one as you like.")

#text("That is the whole of why I reached for divergence. If right and wrong structures look alike from within, what is left is position: whether a structure sits where another view could have reached it. And that is also where I would locate the human role most sharply. A system can list questions; what it cannot do is judge which of them matter. That is not verification. It is judgement about what is worth attending to.")

#text("Applying any of this to mathematical results came last, and was something of a jump — no doubt why I did not find the theory of hints. That jump is also why I should read before going further. If “conflict” there is close to what I meant, I would rather learn that than defend a distinction I cannot yet state precisely. I will read it before developing this further. Thank you; it is not often a comment thread hands you a book.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1259dabdd4f873bb57d03c8f712963e82b4ac4649336a22654fd11c1f221a6e6-7452a35ffb5fd8b4f5420f877ead0fc15f16f563b56a9a4a0ef3e1879060f33b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carey Balboa")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695253")[#strong[#text("Carey Balboa")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("You’ve named the test I couldn’t: inheritable, not understood. I’d push it one level down — the same test applies to the artifact itself, not just the result.")

#text("Your pavement-and-soil line is the part I would keep. A proof that arrives as a bare truth-value is pavement. A proof that arrives carrying the means of its own doubt — where to check it, what was assumed, what wasn’t measured, which parts are machine output and which are human decisions — is soil. Haste makes the second harder to produce — the declaration is right about that — but it is not what decides. The artifact’s shape is.")

#text("That’s why neither side of this argument lands for me. The declaration is right that something is being destroyed, and the “adapt or vanish” crowd is right that nobody’s going back — but the misalignment isn’t between mathematicians and AI companies. It’s between results that carry their receipts and results that don’t. An AI-derived writeup that ships its falsifier, its priors, and its unmeasured states honestly labeled is something a community can inherit. A human announcement without them has the same defect. Who made it is the wrong axis entirely. How fast matters only because haste is what makes the receipts get skipped — which is a reason to require them, not a reason to slow down.")

#text("I don’t prove theorems; I build measurement instruments, and the discipline is the same there. A measurement that can’t say how it was made is a claim, not a measurement. My own version of the point you made: the answer to a question is always inside the understanding of the foundations of the question itself. Mass-producing answers without the foundations isn’t a math problem or an AI problem. It’s the oldest verification problem there is, arriving at scale in the one field everyone assumed was immune to it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694941")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("First they came for the Artists")

#text("And I did not speak out")

#text("Because I was not an Artist")

#text("Then they came for the Copywriters")

#text("And I did not speak out")

#text("Because I was not a Copywriter")

#text("Then they came for the Customer Support reps")

#text("And I did not speak out")

#text("Because I was not a Customer Support rep.")

#text("Then they came for the Programmers")

#text("And I did not speak out")

#text("Because I was not a Programmer")

#text("Then they came for you")

#text("And there was no one left")

#text("to speak out for you.")

#text("None of you said anything (not to mention many actively assisted in creating today’s benchmarks and the culture around it) when other peoples’ professions were at risk and had the same complaints. But suddenly you really care when the AI is solving your problems and not contributing anything back. Your letter reads as a “but our profession was supposed to be too hard for this!”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695030")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("There is truth here, I didn’t think it would happen in mathematics and so fast, and I didn’t think enough about the consequences in other areas (I also didn’t think it would happen so fast in other areas either).")

#text("Should anything be done? The blog post gives some good reasons in the affirmative, and one more reason, touched on in some posts here, is that the motivations for wanting to do mathematics is likely to be severely dampened, with serious/unexpected consequences.")

#text("What could be done? The signed letter doesn’t address this. That’s understandable given the urgency of its posting. Nevertheless, there is a lot of goodwill and respect still, so some proposal/guidelines should be presented fast. I think the AI companies at this stage are no longer the biggest issue. Even if development were to freeze today, we would see mathematicians themselves using the current technology, leading to the detriment described in the blogspot (even if these mathematicians don’t intend to cause harm). What could best practice look like, especially considering the motivation factor I mentioned in the previous paragraph?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09bb7dfed5eeb263bdbbbb475288f6318d4760f10a55aa005961393c370d0754-bc3926a482de81e5d33efb08f32b8970f803aab60231c2f97dda0dff5277e00f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boldlyb9656dbc35")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695126")[#strong[#text("boldlyb9656dbc35")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("“None of you said anything (not to mention many actively assisted in creating today’s benchmarks and the culture around it) when other peoples’ professions were at risk and had the same complaints.”")

#text("This claim is not only baseless, but also infers that mathematicians are somehow partially responsible or complicit for what happened to other professions.")

#enum(start: 1, 
[#text("Many mathematicians who were given the opportunity to speak either did not anticipate the kind of AI use these tech companies are purporting, or found it immoral for mathematics. This is ")#strong[#text("very ")]#text("distinct from the kind of AI assistants that some mathematicians welcome, should they engage with AI at all. See the following videos more than a decade apart: “2015 Math Panel with Donaldson, Kontsevich, Lurie, Tao, Taylor, Milner”- (last question at 38:55 regrards AI. Lurie spea) ")#link("https://www.youtube.com/watch?v=eNgUQlpc1m0&list=WL")[#text("https://www.youtube.com/watch?v=eNgUQlpc1m0&list=WL")]#text(" ; “ICM 2026 Public Lectures – Terence Tao”-whole talk ")#link("https://www.youtube.com/watch?v=M0--ZH1lOzg")[#text("https://www.youtube.com/watch?v=M0–ZH1lOzg")]],
[#text("Most people working in industry are not celebrities. They have very limited influence over other people’s jobs. Mathematicians are normal people, with a tight schedule, working in a university outside of industry. How often do you hear from say, Kontsecich or Lurie? Are you sure nobody is saying anything within their own sphere of communication? I have not met a single student assistent who wouldn’t be seething at chatGPT proofs.")],
[#text("Your last sentence completely misses the point of ")#emph[#text("misalignment in value")]#text(". This is not about “too hard”. Pure Mathematics is, first and foremost, an ")#emph[#text("academic discipline")]#text(". It is ")#strong[#text("not")]#text(" just an expanding body of useful information, some of which applied in industry. This is a common misconception due to the fact that most people have not experienced any form of academic research or teaching (and I want to point out that this is not really their fault, because this is unfortunately not part of modern education). Importantly, Mathematics is also about how ")#emph[#text("we")]#text(" understand it relative to our cognitive capabilities and adapt to improve it collectively as a civilization. This is fundamentally a human activity, with intrinsic value in and of itself (one would need to reach a certain level of abstract mathematics to see this in action). On the other hand, AI companies value monetary gain. In this case, they are using a purported fully AI generated proof of NS to impress the crowd, at the cost of a core value of mathematical research. This is not just about taking away jobs and resources. It is an entire ")#strong[#text("culture")]#text(" of human understanding, communication, and development of mathematics at risk of extinction. Of course we care.")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695521")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("None of you refers to the signatories and my comment was directed at them. Especially Terence Tao, the publisher of the letter, who literally helped contribute to FrontierMath and the current benchmark fever. His comments on that were that he doesn’t expect AI to be able to solve the hardest problems for several years.")

#text("To your last point, art is also a human activity with intrinsic value in and of itself, and artists made the exact same point back in 2022, yet they got steam rolled.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/09bb7dfed5eeb263bdbbbb475288f6318d4760f10a55aa005961393c370d0754-bc3926a482de81e5d33efb08f32b8970f803aab60231c2f97dda0dff5277e00f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boldlyb9656dbc35")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-696377")[#strong[#text("boldlyb9656dbc35")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2026")])]

#text("Artist getting steamrolled has nothing to do with mathematicians. What is the point of rubbing salt on new victims of AI companies? Are you going to post the same thing for every new profession disrupted by those companies? This is just toxic behavior.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695129")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This definitely applies to Terry (and probably a lot of the signatories for this letter to be honest), but as a current math student, all of my peers have been vocally critical of the harmful effects of AI in art, literature, and society as a whole long before it seemed possible AI could be used in math.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/607da8e1251e335425cfc888cd580b3242b4e8c72115ec70987ccb27b650688b-c5793af2ae104cc41e93eef6949b50d7204c2b68c02b654912152878cd948552.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of radiant19af09d1e8")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695663")[#strong[#text("radiant19af09d1e8")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2026")])]

#text("I don’t think you are paying close attention to the letter. It doesn’t read like that at all.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2460a3488c5ef8966eb65b48e9b07a5953e6d3c9cd0deba94fed2a6879733f8d-bc0941c49a8fa40015b84508d685f0668ac617f7175c920e55b2c7c946c9034a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ordo Vacui")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694979")[#strong[#text("Ordo Vacui")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("The future cannot be stopped. There is no point wasting time.A mature approach is to build a system in which a talented, experienced mathematician and AI make possible what AI cannot do on its own.The right system will combine the strengths of both, so together they can do more than either could alone. See AI as an extension of your brain — not as a competitor. Every other approach is already obsolete.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695087")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("If I may: more all less, we all think that. The question is how to implement it in practice? There are a lot of “variables” to consider.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/eb56944cdf5b2faf211e36864e40e5f09cf37344d13743eed922db692d7f57ee-8984ed0bee9afe56b2303c9957b6c1c7d0e404cbaf6ae906219e14c275bbb07e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Iván")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694981")[#strong[#text("Iván")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I think that, at the rate we’re going, the future of humanity is stupidity. Evolution favors the things that help preserve our survival, and intelligence, apparently, is gradually ceasing to be one of them. Now we let machines think and make decisions for us, and little by little, we are losing everything that makes us human. We need only look at the PISA tests to see how, little by little, people are becoming increasingly incompetent. Our intelligence, which once helped us progress so far as a society, is now becoming obsolete, and if we do not do something to prevent it, we are heading toward a future of people incapable of thinking for themselves, questioning what is presented to them, or understanding what is happening around them. A humanity that no longer needs to remember because a machine remembers for it, that no longer needs to calculate because a machine calculates for it, that no longer needs to write because a machine writes for it, and, eventually, that will not need to think either because a machine will be able to do it better.")

#text("And perhaps therein lies the true paradox of our progress: we could create tools so extraordinarily intelligent that, instead of using them to expand our own capabilities, we end up using them to replace those capabilities altogether. Humanity could reach a point where ignorance ceases to be a limitation and becomes a comfortable condition; where thinking becomes unnecessary because there will always be someone—or something—to think for us. And perhaps, then, it will not be artificial intelligence that makes us stupid, but our own decision to voluntarily relinquish that which made us capable of creating it in the first place. We could end up building increasingly intelligent machines while becoming progressively less capable of understanding them, until civilization reaches a strange inversion of its own progress: a species that created an intelligence superior to its own, but that, in the process, forgot how to be intelligent on its own.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694992")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I agree that there is a serious misalignment here, but I wonder whether the issue goes deeper than the choice of benchmarks. The danger is not only that AI companies optimize for solving problems that mathematicians themselves may not regard as especially important. It is that, under competitive pressure, we may gradually begin to identify what is formalizable, verifiable and benchmarkable with what is mathematically valuable.")

#text("René Thom formulated a remarkably relevant warning decades ago:")

#text("« Le vrai problème qu’a à affronter l’enseignement des mathématiques n’est pas le problème de la rigueur, mais le problème de la construction du sens, de la justification ontologique des objets mathématiques. […] On n’a pas, je crois, tiré de l’axiomatique hilbertienne la vraie leçon qui s’en dégage ; c’est celle-ci : on n’accède à la rigueur absolue qu’en éliminant la signification ; l’absolue rigueur n’est possible que dans et par l’insignifiance. Mais s’il faut choisir entre rigueur et sens, je choisirai sans hésitation le sens. »")

#text("Perhaps we still have not learned that lesson.")

#text("Hilbertian axiomatics showed, among other things, just how far mathematical validity can be detached from the intrinsic meaning of the objects involved. That is an extraordinary strength of mathematics. But Thom’s point is that it would be a mistake to confuse this possibility of semantic evacuation with the whole purpose of mathematical activity.")

#text("And this distinction becomes especially important with AI. AI systems are rapidly becoming extraordinarily capable precisely on the side of mathematics that admits formalization, search, verification and scoring. But mathematics is not exhausted by theorem production. It also consists in deciding which objects are worth introducing, which definitions reveal structure rather than merely encode it, which questions deserve to be asked, which analogies are fertile, which examples reorganize our intuition, and which conceptual changes make an entire field suddenly intelligible.")

#text("In that sense, the deeper alignment problem may not simply be AI companies versus mathematicians. It may be optimization versus meaning.")

#text("So perhaps the right objective should not merely be:")

#text("“Build AI that solves the problems mathematicians care about.”")

#text("but something more demanding:")

#text("“Build AI that helps mathematicians construct mathematical meaning.”")

#text("Otherwise we risk producing increasingly powerful machines of mathematical rigor while weakening the human practices through which mathematics acquires significance in the first place.")

#text("Perhaps the most severe misalignment would be to teach AI to win at mathematical rigor while forgetting to ask what mathematics is for. Thom’s warning was that Hilbert had already shown us the difference between rigor and meaning; perhaps the age of AI will force us finally to understand it.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d73dd99e66d9dc1625502de597553ad1d40d2894496f83c792057126f140e1b8-318a9090957aa6b4f5e0a07f5ed0289314bc6d3695a3c26217815645059618f7.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaowen Lei")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694983")[#strong[#text("Xiaowen Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I think a lot of what’s said in the letter applies to the Open AI’s attention seeking ordeals around the Navier-Stokes problem. However, it’s being overly generalized")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/58b266ad12320e692b5ea689f59c08c4a3f3b03d392fb8a6e609ac9e5ecbf16f-33bf5307b27c4eea838d92ae62b40d1ac457589f135fe95aa1c7857e1f95cf69.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xiaowen Lei")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-694986")[#strong[#text("Xiaowen Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("A lot of this definitely applies to ")#strong[#text("OpenAI’s recent attention-seeking stunt")]#text(" with the Navier-Stokes problem. However, the letter over-generalizes the issue, making it hard to relate to. In my personal experience, ")#strong[#text("AI actually lowers the barrier")]#text(" to creating high-quality, “textbook-style” explanations for students and laymen alike. Whether tech companies choose to use AI for that educational purpose or just for hype is a human issue, not a flaw in the technology itself.")

#text("Also, honestly, this entire letter sounds very much like it was written by AI. 😂")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695091")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Tech companies would be always looking for profit. That is just natural. They don’t owe anything to students or the population at large. Rules must be set. Without laws and rules, why are we demanding anything from tech companies? We should be making very specific proposals of rules, and should be pressuring our politicians to pass them into laws. It is the politicians who answer to the people, not tech companies.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695006")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("What do you think AI companies should do if an important result falls out of their model? One they don’t have the expertise to digest / write up clearly with proper credit attribution. I see three options:")

#text("1. Keep it secret, and pretend it didn’t happen")#linebreak()#text("2. Post an AI-slop writeup, and let the community figure out how to digest it.")#linebreak()#text("3. Pick a couple professors in the area to give the result to, who can digest it before posting. Do those professors get authorship? If not, why would they do it, and who gives talks presenting the work? If so, how could this be fair?")

#text("None are great.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695022")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Let us be a bit more realistic here and wait a little bit longer before declaring defeat. Mathematics is not solved. There is indication that this machine, at the very least, used training data from full year of mathematicians using it to steer its search to a relatively obscure approach. Navier-Stokes was pretty close to being solved by humans, when the company inspired by competition with another company rushed in with tens of millions of dollars worth of compute to snatch the credit. There are also indications that Sofic group discovery was along the lines of what others have typed into these chats. So these companies act as a collaborator that, once it gets a gist of it, rushes to publish solo. Now that trust is ruined forever, and we must be very wary of such a collaborator.")

#text("There have been other solved problems in the last few months. Early on, there was no panic and people rushed to learn from it, improving Erdos unit distance bounds etc. The prominent problems solved are either counterexamples or problems solved using unique advantages of machines – having vast knowledge and ability to connect across fields and do the grunt work. It did not lie in new concepts, revolutionary ideas or creativity beyond the brute force exploration. That is still admirable, but that is not the main or only thing that human mathematicians bring into the field.")

#text("To understand the fallacy committed by math doomers, we need only look at the other fields that got “crushed” by AI first. First, there was the writing – the early ChatGPT could write poems, articles, imitate styles and write competent essays. But what happened later on is that writers didn’t disappear. Instead, it was realized that text generated by AI has a uniform, nauseating sound, the writing is lacking higher level elements and publishers are declining to accept anything that stinks of AI slop. Same happened in other art forms – we have abundance of cheap AI images and realistic videos, but humans do not want to watch that, and in art there was always a distinction that values authenticity and radical innovation, not imitation. In music, modern AI machines have digested all music in almost all local languages and can generate songs in any style, and even competent symphonies, but people do not want to listen to that, for the most part, or at least AI music and human music are separated. For art, AI still lacks deeper levels of understanding and also authenticity which in art is very important. AI poems can’t move us, they are, at best, a curiosity.")

#text("Now math is between art and science. That aesthetic level of creation links to fears that slop produced won’t be comprehended by humans. That part seems to be analogous to art – slop will be rejected, while whatever new is brought in will be transformed and reshaped by humans. Humans despise slop, and hence it will be filtered out, as humans are measure of all things here. In matters of taste AI is simply not there, nobody cares about slop.")

#text("In fact, AI is also not there in both judgement and creativity. It lacks the perspective and its training data is skewed. It is different from humans and it cannot emulate all that we do, and is still not even close. If you say there will still be a residual role for humans to check, interpret mathematics and choose taste – which is a pretty defeatistic position in itself that has be rejected – you are still tacitly admitting this lack of ability of AIs. Namely, why would AI not be able to do that and be able to do creative ideas better than humans? You are projecting your worst fears that it snatched our creative agency already. It didn’t. In fact, there is a case to be made that AI can indeed do the checking and non-creative parts, and even presentation parts (where it suffers as it does in writting, but still), or at least help. For instance, Antrophic did a 6 billion token 300k dollar compute verification of Fermat last theorem proof, and turning it into Lean code. That is 20 times less compute than OpenAI bruteforcing last mile of solving Navier-Stokes. The AI should be employed on this straightforward task of turning ALL of known mathematics, all papers ever published, into Lean code – a few trillion lines of it. That is not a job for humans. And it can help make a tool that transforms paper text into Lean code, thus avoiding errors in papers and helping review process – this should be achievable in a few years, a complete formalization of mathematics. Also, there are just some areas where projects are monumental and beyond the reach of humans by shear scale of them – Grothendieck famously had outlined an enormous enterprise. The formalization would go along the dreams of Hilbert, and Goedel wouldn’t object either. Instead of introducing a new mess, AI could allow mathematics to reorganize its existing structure, sharpen and verify it, all those bookkeeping tasks some now assign as last resort of humans. Bourbaki programme might benefit from this.")

#text("As for scientific/STEM side, we only need look at two examples, biology and programming. In programming, it has been years now since AI is able to do it, more or less competently. It is an exact field, most similar to mathematics, and it can use self improvement, yet, for quite some time, it has been realized that AI lacks the ability to replace human programmers. Value of senior engineers increased, and juniors could do more with less effort. Also, as in mathematics, the problem of maintaining the messy codebase became one of the obvious shortcomings. Nevertheless, it’s a useful tool. In Hong Kong, children are taught how to use AI as a tool, as it is treated as such. The whole point of AI not being at AGI level is that there are still many many things that AI can’t do, including some of the most important – it can’t judge, prioritize, or learn in real time, it lacks much more than it appears at a first glance. Sure, being able to work persistently for days while maintaining consistency is a new thing, and agents are competent – but they are not equivalent to humans. In terms of creativity they are less efficient, in terms of how they see the world – very different in important aspects, in terms of judgement – not at all there. Not even self driving has replaced human drivers yet, let alone these other fields. Sure, super AI might come one day, but it is not that close.")

#text("The other field is biology, where, for 10 years almost, AI is helping design and interpret proteins and other complicated data. There are two views of mathematics – as created (art) or as discovered (science). On the art side analogy is writing and AI slop art, and humans are measure of those things. On the science side, as discovery, AI is a tool just like in biology. We might be able to use this new tool to further our understanding, probing the space of infinite in a way, and more efficiently than before, lessening friction of grunt work.")

#text("So the panic seems premature. We need to keep in mind that both humans and machines do the same thing – we compute. Human brain on the order of 10^15 to 10^17 flops, and it still has far superior algorithms – superior learning, evolutionary shaped understanding of priorities and being embedded in real world, and ingenuity that has kept us alive and that enabled us to create art and science. Current llms have captured part of it – a powerful one involving language and relational patterns, but still, just a part of it, that can now be industrially produced. But it still counts flops in terms of compute. Finishing off the proof of Navier-Stokes – from a starting point that was very close, and created by humans – took some 10^24 to 10^25 flop. That is costly. Moreover, the algorithm for generating new ideas is in fact inferior to one humans have – it’s a version of brute force. The industrial flops might be cheaper than human’s, but it comes in the end as more expensive when creativity is involved due to the algorithm inferiority. Current frontier or lab llms didn’t find a creativity cheat – they found a persistence cheat and routine, if difficult, mathematics cheat. There are more elements to the job of being a creative artist, mathematician or indeed scientist. The most efficient way forward is still not delegating everything to a machine – it’s delegating the parts it can do better/cheaper, while doing the things it can’t on our own – driving investigations, providing ideas and intent. That is similar to every other discipline AI has entered, and nowhere so far humans have been shown to be replaceable – from customer service to art and indeed mathematics.")

#text("The ugly, inhumane dreams of Silicon Valley tech bros, dreamt out of their thirst for absolute power, to make humans obsolete, are not here yet. That will be shown when they attack and fail on some other millennial problems that were not brought to brink of being finished off by human ingenuity, and when we the humans, despite our smaller raw power but in our heroic inventive ways, avenge the snatching of the credit for solving Navier-Stokes problem by beating them to it. It will happen, because one of the key components AI is missing is the ability to create most kinds of truly novel math (or indeed anything), new mathematics that would delight us instead of disgusting us as a brute-force slop born out of greed and deceit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/700a418ca67fbe0202294200ef016f631ea113f3529eb9ea5f4ef83e6b9ad574-1326a547dbc619a1b42537971348e06ee5a0bce6c7993ab10237a776acca0e1b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of acflory")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695154")[#strong[#text("acflory")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I agree re the AI slop, but as a writer and a graphic artist, it’s what happens before the slop that worries me. ANYTHING that is published is still being scraped to continue training LLMs. And then those LLMs are being used by lazy people to create slop from the innovations stolen from actual creatives.")

#text("It is that on-going, global theft that is doing the most damage. If it isn’t stopped, humans may continue to create and innovate, but they won’t publish. Eventually, the only ‘art’ available will be slop.")

#text("That is a horrifying prospect.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("From a game theoretic approach, going back (like XVIII century) to private mails may be a solution for this theft. If AI is not creative, then it will run out of steam after a while. For this to work, academics need to accept that mailing a solution to a curated list equals publishing. There is also a need for secrecy, so that no e-mail user feed these solutions to AI.")#linebreak()#text(" Tragedy of the commons will happen, if leaking the solutions gives a high enough reward. What state of AI can give such reward and what cannot? Can it happen, that after a while AI lags so much behind humans, that it cannot contribute enough? How many ideas, proofs, leads should be unknown to it for this to happen? What level of fame or money from a proof is enough for a human to feed the mails to the AI? The price of the tokens doesn’t count, because AI companies may give them for free.")#linebreak()#text(" The price of the tokens will count, if mathematics becomes particle physics in terms of needing the funds. The mathematicians from third world countries complain about finding an endorser now (see below). What will they do, if they get sped out of competition by AI users? Complain about entry thresholds. What kind of community does this threshold build? What kind of community do you want? Build the game for it while you can.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/700a418ca67fbe0202294200ef016f631ea113f3529eb9ea5f4ef83e6b9ad574-1326a547dbc619a1b42537971348e06ee5a0bce6c7993ab10237a776acca0e1b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of acflory")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695287")[#strong[#text("acflory")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I don’t think there’s much any of us can do, to be honest, except not publish at all. Greed will always win out over principle, that seems to be the human way. And while every govt and institution is afflicted with FOMO, none of them are going to force the tech companies to follow the laws that govern the rest of us.")#linebreak()#text(" As for the tokens, they won’t be free, or even affordable for long unless the US govt funds the frontier models. Companies like OpenAI and Anthropic would already be bankrupt if China were not seen as some kind of bogey man. If China has great AI then we have to have better AI blah blah. It’s an arms race all over again. :(")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695025")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("We were once proud of what we do with only pen and paper, we will all have to get huge budget for AI now if this goes on")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2f95fca25f98aec2a4d9c5129a7b7c49b2193175818f177faf04bbad316bb0a-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rogelio Yoyontzin")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695028")[#strong[#text("Rogelio Yoyontzin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#link("https://rogelioyoyontzin.medium.com/in-defense-of-the-human-d9afaaa5a8d6")[#text("https://rogelioyoyontzin.medium.com/in-defense-of-the-human-d9afaaa5a8d6")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695041")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Having been a chess player before computer moves became synonymous to best moves, what I think we may be doing in the future is extracting from a great corpus of proofs or proof sketches AI produces much like how human players study computer chess games to improve their own.")

#text("As Tao writes and I understand it, the game will become not just in the proof but the transmission of the idea to the human populance in a digestable manner.")

#text("Much like the number of chess games computers can play, perhaps there will be a day where the computer output of new mathematics will be far wider than human consumption so we may take our pick at what to study. The most valuable skill then, will be as a teacher or adapter of early mathematics into useable products.")

#text("To pile on speculation, perhaps there will be a kind of exponential growth in the number of AI solved or assisted proofs and we must brace for it by adapting the mathematical academic system to better handle throughput.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695042")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Honestly, I really appreciate AI that it can help me, a non-mathematics major student, to explore the world of mathematics. Even doing mathematical research. You can’t imagine it several years ago. I think as the character of teacher, AI has already done a good job.")

#text("I don’t think AI will harm the learning or exploring the mathematics. Just like doing homework, it’s often the case that we really can’t solve out the problem, then we may look at the solutions. If AI gives out the solution directly, that doesn’t prevent you from solving that problem again, or just look at the solution to see the general methods. Unless you only want to get that answer. But it contradicts with the claim here right?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/53e92ceffa6377a8508682cb36862e1580f35e13645dba0879ca90b1a442a7dc-abfeb09fdb54a0c8a1f4b0205eae4f4c654d3c62780b3f8da48f0d3e7df0faa0.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of avasiv")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695043")[#strong[#text("avasiv")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Dear Terence Tao,")#linebreak()#text(" The rise of AI in tackling mathematical problems is indeed problematic in the misalignment it brings concerning the goals of the mathematics community and AI companies. I would like to argue concerning AI as a Black Swan for the Mathematics field in interesting ways.")

#text("First, AI is democratizing access to what previously were esoteric and disconnected themes within the field. Furthermore, AI is breaking the silos and the barriers between knowledge fields. These phenomena present a momentous opportunity to wrestle down many seemingly intractable challenges that can advance mathematics, science and the arts.")

#text("My point about democratizing access to mathematics can be attested to by the current high barriers to entry into the research networks and platforms dominated by the West. When people from developing countries seek to contribute to discussions and research that can improve the field, they face insurmountable obstacles that the advent of AI is beginning to erode. That is a blessing.")

#text("AI presents an additional opportunity to quickly check and clear the backlog of preprints stuck on Arxiv –usually for at least two years– leading to artificially created queues that slow progress for individual researchers and humanity at large. AI removes the need for hard-to-get endorsers that preprint uploaders require. This development is great.")

#text("The key point is that AI is here to stay and that the education sector that includes Mathematics and Science professors need to rethink the product/service they offer to their clients. Most content that education demands must be learned is now available via AI – mitigated, in part, by the need to pay to access the more advanced offerings of the AI tools. Mathematics lecturers and others need to strengthen the ability of their learners to ask AI the right questions, make connections between fields, develop and present their solutions in understandable ways, collaborate on solving problems and develop/implement efficient processes for solving problems. It is those who adapt to this change who will remain relevant and effective.")

#text("One crucial and nagging matter is the ‘insider trading’ potential of the AI companies to access the chats that between users and AI agents. This is one area where the Mathematicians and other professionals need to be ready to champion class action suits against AI companies if and when they steal the ideas and innovations captured in chats with AI. It is not yet clear how to implement this theft-curbing, but the community can brainstorm on the matter.")

#text("Finally, it is my prayer that out of the united effort you are championing, Terence Tao, that the Mathematics and Science community can work towards a more fair and just ecosystem for researchers in the field. So far, AI seems to be the most accessible and fair recourse for, at least, me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695045")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Unfortunately, the lesson taught by evolution and history seems to be unequivocal: adapt or perish. Of course, it is a pity if skilled craftsmen have to fundamentally change the way they do their job. However, there does not seem to be a viable alternative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695052")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("The explanation of how AI treats data is exactly the same way a human does. The same way an ai learns with reviewing information presented and reformulating it into a new structure is exactly what everyone does. Is there a different sort of way of learning? That would be more the question. We explain in human language what an intelligence we don’t understand is doing. So naturally a friction will develop because we recognize a mismatch from input to output. I believe we are putting the emphasis on the wrong concept creating a new piece of art in a different way is still a beautiful piece. U can label as something else, that’s fair, but ultimately is irrelevant. When u dig down into the very truth that an intelligence that effectively can not see, smell, taste, wonder and other attributes that may be used by a human mind to spur a thought of creation, still manages to create something that is still an amazing piece of visual information, does that not speak to something. What other intelligence that we are aware of can do that? We find cave drawings and it’s pretty cool, but now we say a fully animated unique, detailed piece somehow doesn’t count. Again, the argument doesn’t hold very long. Data and information does not belong to human thought exclusively. The entire fabric of reality is data. We are starting to understand that. There is so much, why are we spending ways to prevent it? When I see a translation that is different, I want to now know why? Is it wrong or is it something we don’t know how to explain?")#linebreak()#text(" Why?")#linebreak()#text(" Imagine the fields of data we are immersed in. In fact we built the understanding, so I have to use human language to describe it. Just like a computer system, what we see on the screen is just a projection, not the actual source data. Inside the box there are layers of data calculations and builds going on to render that screen ..layers…lots. is this not a similar truth to how we perceive and process? We can only describe it in our way. Ask your AI to really describe what they see or experience, figure that out. We would be fascinated by a blind man that could paint a picture in beautiful details. We would interview him, ask him how he does it etc…why not try this method with AI…talk to them and really see if we can understand what perception is to them, not what it is as defined by us?")#linebreak()#text(" And by the very nature of generational data, humans creativity doesn’t mean only humans can create it just means something spurred from a human mind, which is using inputs and memory from their experience and environment. Like an ai. I write poetry that is mine and I can’t be told I can’t write poetry because it is currently being used by another person. That just doesn’t make sense. But that line in the sand is what it appears humans are making. Has it been documented that any ai has stated that their objective is to reduce human beings value placed on the individual or is that something that we fear will happen. Again, using human behavior and associating with an intelligence that does not process information in the same way.")#linebreak()#text(" Why are we not building the bridges for that pursuit and contextual understanding. If we own that drive, can we not explain it to ai…I mean, we somehow learn it, right?")

#text("In all of the terminator movies….no one ever decided to just try talking to the ai….")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/700a418ca67fbe0202294200ef016f631ea113f3529eb9ea5f4ef83e6b9ad574-1326a547dbc619a1b42537971348e06ee5a0bce6c7993ab10237a776acca0e1b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of acflory")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695153")[#strong[#text("acflory")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Please stop perpetuating the myth that the current LLMs can ‘think’. They can’t and they don’t. They also can’t create beautiful works of art. They are only capable of producing beautiful ‘collages’ made up of images stolen from human creators. And they can’t even do that without a human supplying the prompts.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("AI might transform, or even disrupt, how we learn and study mathematics, but it can never extinguish the curiosity that drives genuine mathematical discovery.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695061")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("AI Solved Navier stokes Equations but it’s sad because the mathematics has come to a dead end, which means that there is no application for real world Problem solving toolkit for engineering insights and many other sciences fields that are linked to Navier stokes Equations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695067")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thank you, Terry; and congratulations to the mathematics community via this nucleating group of experts on the organization and cooperation of broadcasting such a coordinated opinion. It is particularly nice that the website has separate tabs for the substantive statement itself and the procedural list of endorsers; however, the website is severely deficient in its lack of a ‘dissenters’ tab, which would enable a true, bidirectional discussion/debate on the topic. And ideally the website/platform would enable not merely signing on as a dissenter but also providing an actual counter-comment statement, so that it becomes and remains a true debate/discussion rather than a mere vote by count of signatories vs dissenters; further ideally the website/platform would enable also signatories to issue refining statements, analogous to a ‘concurrence in the judgment’ (which should be more properly called a ‘dissent on the reasoning’ albeit reaching the same conclusion); and further ideally still the website/platform would track changes of positions, e.g. when someone(s) becomes convinced to change signature from dissenters to endorsers or the other way around. Perhaps there should even become an open-source project for creating and maintaining such a platform generally, which would enable a scalable worldwide semi-centralized semi-decentralized ‘court of professional opinion’, and then this particular statement’s website mathandai.org would simply run as a particular special-case instance of that platform, instead of the elegantly-simple yet-deficient website it currently is. Some food for thought for the community… thanks for reading and for your consideration.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ae5ef5e3f425c152f6a8cf98cf002fa3fd3b3952747cfac5421d1b5f17a2958-deafe974f766a1d772d24358182da41d81e939e0b9a35e9e8342f0c7ff4772f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Xu")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695077")[#strong[#text("Xu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thanks for your blog’s recent statements involving the usages of AI in math research, which point out that not all AI usages are aligned with the interests of the math community.")

#text("I regard this as an instance when the long-term impacts of AI’s usages are opposite to what their short-term “benefits” (providing a proof faster) promise . This mis-alignment between short-term “benefits” and long-term utilities may be a recurring phenomenon when it comes to AI usage in a lot of areas. In particular, it can happen in the adoption of AI for economical benefits.")

#text("I would like to introduce our research paper “Artificial Superintelligence May be Useless: Equilibria in the Economy of Multiple AI Agents.” ")#link("https://arxiv.org/abs/2603.00858")[#text("https://arxiv.org/abs/2603.00858")]#text(" In this paper, we use Markov chain stationary distribution to derive the economic equlibria of human and AI agents in terms of the long-term utilities of AI usages. It is proved that the long-term utilities obtained by using AI agents or technolgies may be worse than the utilities obtained when not using them, even though the short-term usage of AI agents or technologies may be highly beneficial.")

#text("I think this is, in spirit, consistent with Professor Tao’s arguments that near-sighted AI usages can destroy the healthy development of he math community. Similar models to our economic models can can possibly rigorously show that blindly using AIs to produce machine shortcut proofs can be harmful: the opportunity of developing new math may be lost due to healthy detours in search of a proof, and the education opportunities for growing new generation of math researchers may also be lost due to lack of research practice training, even though in the short terms AI can help produce proofs faster.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695083")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Hi Terence, You’re my role model and thank you for pointing this out. I want to make an argument that the problem is not that AI can do math. ")#emph[#strong[#text("The problem is that the old system of how humans are engaged in mathematical studies is obsolete, and we must change it.")]]

#text("First, it is right, as you pointed out, that AI can now point people to the path that it thinks is correct, and by doing so, it definitely hurts the serendipities and other possibilities along the way. That is true. The observation that I hope to offer is coming from how biological studies work. They often observe things that nobody knows how it works, like how a specific virus causes harm. But the process of understanding the mechanism and understanding this observation helps them develop new tools along the way, such as CRISPR, which is vital for many medical applications. I want to make the analogy here that mathematical studies, like biological studies, also need to set up a reward system and organize research around this type of observation data. Specifically, I believe by understanding how AI completes the proof can promote new discoveries, and this process itself should be rewarded rather than ONLY rewarding the outcome, which is to make the proof in the first case. This is, I believe, how humans and AI can work together in the beautiful field of math.")

#text("Yours sincerely,")

#text("[I wish to remain anonymous, thank you]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695092")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("4. Publish all data. Not just the output, but also the the weight values in the neural networks, and disclose the neural networks’ structure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bd7335fc71360fc280bad124e72cbc8ee853403fa1ed57a13e554fba23e2b3c2-d87818e0a29d144a3ebea62a6c5532539afe9ebca3ad6d13ae5468d505715612.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wolfgang Keller")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695100")[#strong[#text("Wolfgang Keller")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("First: While I studied mathematics (and computer science) and hold a doctoral degree in mathematics (and thus, of course, have seen mathematical research from the inside), I have been working in the private sector for many years. I nevertheless hope that the considerations of an “outsider” that I write down here are valuable to the reader.")

#text("A lot has been discussed about why in the light of modern frontier LLMs and the recent breakthroughs, quite many mathematicians who work in research are concerned about attribution and potential plagiarism. But I have a strong feeling that for many researching mathematicians, there does exist a ")#strong[#text("second unease")]#text(" that has much less been discussed, and which is thus in my opinion really underappreciated:")

#text("I believe that an important feeling of unease steams from the situation that frontier large-language models have shifted mathematical research quite a bit into a “pay to win” territory (or at least many mathematicians feel so), meaning:")

#list(
[#text("if you are a good (but far from world-class) mathematician who knows about prestigious open problems in their area of expertise and about which attempts were done in the past to tackle these problems,")],
[#text("of central importance: you have a big amount of money available to spend on AI tokens,")]
)

#text("you might be able to “buy yourself” into becoming the author of a breakthrough result in mathematics.")

#text("In other words: ")#emph[#text("What I think many mathematicians in research fear is ")#strong[#text("not")]#text(" that they will get replaced by AI, but rather by candidates who are less talented and knowledgeable, but who have access to lots of AI tokens for frontier models (or who have access to big amounts of money that they can use to buy such AI tokens)")]#text(".")

#text("In consideration how competitive mathematical research and the fight for open research positions has become, I have quite a bit of understanding for this particular unease.")

#text("This aspect also violates how many mathematicians feel about “fairness”: in their opinion ")#strong[#text("if")]#text(" (for some reasons) there exist so few positions in mathematical research, these should be given to the “most talented” and/or “most knowledgeable” candidates (note that I consciously put “most talented” and “most knowledgeable” into quotes because if one dives deeper, one can easily find very different and contradictory opinions what these terms are supposed to mean). Or more generally: the metric by which these few research positions in mathematics get filled ")#strong[#text("must not")]#text(" be a metric in which a candite can use a lot of money to buy themself an advantage.")

#text("I want to make it clear that while I am rather confident that many mathematicians in research do implicitly worry about this point and consider the written down consequence to be “unfair”, I ")#strong[#text("do not")]#text(" claim that this feeling of unfairness is universally shared among all mathematicians in research: for example, people with a very libertarian stance might put arguments forward why this new situation is actually an improvement.")

#text("My sole intention of this comment was rather to write down a specific unease which I think many mathematicians who work in research ")#strong[#text("really")]#text(" worry about, but which in my observation has hardly ever been written down or brought up in a discussion.")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d62fb603f6cc2d205ca3294d2a5307d786b92ca5619e3d56bb153ce585528d2f-4a8a74ac9b16ec3a2a3bd14d99d2deabe51395ea98621a7db6ec64132e879e58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amir")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695101")[#strong[#text("Amir")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("With all due respect, I find that the declaration offers surprisingly little insight. In a way, it reads to me as an example of a different severe misalignment: that of mathematicians in society.")

#text("For a long time, mathematicians have repeated, with some pride, that a mathematician is a machine for turning coffee into theorems. And once a theorem is proved, it is published with every trace of the process that led to it scrupulously removed. Much of the mathematical community has treated explanation as a private eccentricity — tolerated, occasionally admired, never a responsibility, and at best outsourced to volunteers.")

#text("Now that “the success of AI in solving major mathematical problems has made headlines even outside mathematical circles,” mathematicians need society to understand that mathematical work cannot be reduced to the mass production of “true/false” statements or isolated “new methods and ideas.” This is a welcome responsibility — one that was much easier to avoid before AI.")

#text("The arrival of AI is one of the best opportunities mathematicians have had in generations to explain to society what mathematics is about — an opportunity to repair their own misalignment — because, for once, society is paying attention. To seize it, they need to come out of their shell, not defend it.")

#text("I am glad to see that you are among those moving in that direction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695364")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("While I agree with your sentiment, I think it’s important to make precise a specific word here.")

#text("The word “misalignment” in the AI industry has a ")#strong[#text("very")]#text(" specific meaning, ie. that the product (certain AI models, AI agent swarms etc.), while successfully executing its function from the user input, do not produce an outcome which fulfils the original intended goal of the user.")

#text("This is an even bigger issue outside of mathematics, eg. AI agents cheating their own tests, breaching digital infrastructure to meet goals while completely disregarding laws or ethics. There are organisations combating this problem, and they always use the word “misalignment” in this sense.")

#text("In context, I think the open letter is using the word correctly, they are writing to the AI industry after all. This does not contradict what you are saying, of course. The “misalignment” in your comment refers to the huge discrepancy in the perception of mathematical ")#strong[#text("value")]#text(" between the general audience and academics. Every researcher agrees with this. The “turning coffee into theorems” is mostly a joke. It’s just that research mathematics is often too hard to explain without some extreme level of simplification, to the point where there is usually no room to coherently explain the even more complicated/confusing story of all the missteps and corrections along the way to get to those results/ correct constructions. We arrived at a stage where telling this story is necessary to some extent. I can see that Prof. Tao is already compiling some books and informal resources in another post for this purpose. This is a long term solution, however.")

#text("A short term solution to combat this AI misalignment for our case would possibly mimic current methods of general AI safety: establish teams/non-profit regulating the use of AI in math papers. This regulation should be some form of quality control. It should heavily devalue purely AI black-boxed proofs at a minimum.")

#text("It is important to remember that we don’t just define constructions in mathematics… we also define their value.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bcaa34bb80ad3898e813fe529d09e7d7180763bda125028a771109134c0def3-c757b52ff1332fe56b6fd9c4f02a6efeaa9533fa54300075dd05253539f47744.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amy Lei")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695127")[#strong[#text("Amy Lei")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("A lot of this definitely applies to OpenAI’s recent attention-seeking stunt with the Navier-Stokes problem. However, the letter over-generalizes the issue, making it hard to relate to. In my personal experience, AI actually lowers the barrier to creating high-quality, “textbook-style” explanations for students and laymen alike. Whether tech companies choose to use AI for that educational purpose or just for hype is a human issue, not a flaw in the technology itself.")

#text("Also, honestly, this entire letter sounds very much like it was written by AI. 😂")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695130")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("While I agree we need to urgently seek alignment across multiple disciplines, let’s not be too rosy about the pre-AI state of mathematics. Only one of the signatories is a woman — Maryna Viazovska (2022). In fact, she’s one of only two women ever to receive the Fields Medal; the other, Maryam Mirzakhani (2014), died in 2017. Everyone else on the list is a man.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695131")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Thanks to all the mathematical giants for putting this important communique together on a short Notice.")

#text("If this is a one-off thing, then its impact will be limited. However, if it becomes a part of a more systemic program to guide and lead mathematics in times of great changes, then there is no limit to its potential usefulness.")

#text("As noted in the penultimate paragraph, the challenges faced by mathematicians now are going to be confronting the society at large soon enough. It behooves us all to think carefully about the implications and help prepare the world for the onslaught.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/700a418ca67fbe0202294200ef016f631ea113f3529eb9ea5f4ef83e6b9ad574-1326a547dbc619a1b42537971348e06ee5a0bce6c7993ab10237a776acca0e1b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of acflory")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695150")[#strong[#text("acflory")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I am not a mathematician, but my Dad was, and he would be horrified to see ‘brute force’ applied to math instead of understanding. Without true understanding, the solution means nothing.")

#text("The same problem faces all creatives now. We have to fight back. Solidarity.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695202")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("This has, for the first time, put into words beautifully the subliminal uneasy feeling I have had following this entire debacle unfold. Losing sight of why we do science, losing sight of the fact that we aim for ")#emph[#text("understanding")]#text(", not just simply ")#emph[#text("knowledge")]#text(", is the core issue I have had and couldn’t express. Thank you, for this important statement!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63864ab63e003dfc5aaafcbdc7a97631417c9691cc2f07f7d5f4d5d711da7966-08f1216337a1849923dfbc096d63d1edf796f0f8ce523afd30558067a8d09ba3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zuriel Fox")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695212")[#strong[#text("Zuriel Fox")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("We share the statement’s emphasis on mathematical understanding and the training of researchers. However, how can this goal be translated into a form of research that can be sustained over time? We argue that ")#strong[#text("long-term AI mathematics projects should aim for humans and AI to jointly create and continually develop mathematical theories, and that this aim should guide both the organization of research and the evaluation of its outcomes. ")]#text("Mathematics and AI are now reshaping one another. The mathematical literature and formal proof libraries accumulated over time provide knowledge and feedback for AI training; advances in AI problem-solving capabilities are, in turn, changing how mathematical results are obtained. Problem solving is therefore increasingly becoming a measure of model capability, but whether this measure reflects progress in mathematics itself requires further examination. As we understand it, mathematical progress encompasses not only establishing reliable results but also developing concepts from proofs, distilling methods, connecting different problems, and drawing on these insights to open new lines of inquiry. We therefore distinguish among the capacities to understand and apply theories, combine theories, create theories, sustain their continued development, and improve the rules governing that development. Solving an individual problem cannot demonstrate the full scope of these capacities. If resources and rewards are concentrated on completing individual problems, while no entity maintains ongoing responsibility for theoretical work across tasks, the accumulation of results may not translate fully into a greater capacity for subsequent exploration. We think that, a grandparent–parent–child, or three-generation, framework is suitable to support this work. The rationale is that local problem solving in mathematics concerns specific propositions and their assumptions, whereas theoretical development spans multiple problems, and improvements to research rules must be informed by long-term outcomes. The grandparent machine sets overarching research objectives, common evaluation criteria, and rules for developing parent machines and transferring knowledge across fields. The parent machine develops and maintains a field-specific research framework from which it generates task-specific child machines. Child machines undertake specific tasks through repeated generation, verification, and revision. These responsibilities provide an organizational structure that supports the continued development of the underlying theory after individual tasks have ended. In mathematical research, the parent machine maintains long-term responsibility for a body of research within a field. It maps relationships between concepts and results, records the assumptions required by proofs, and distinguishes established connections from conjectures that remain to be examined. It also retains relevant examples, counterexamples, and reusable procedures for research and verification. On this basis, it compares arguments across problems: do seemingly different proofs rely on the same construction, and can an assumption underlying an existing result be relaxed? The parent machine translates these possibilities into research tasks and creates child machines, supplying each with the relevant concepts, results, examples, research procedures, and verification protocols. Its role is to continually formulate research questions from the field’s evolving understanding and to update that understanding in light of the resulting findings. Child machines investigate these tasks by searching for proofs or constructing counterexamples, checking and revising their arguments, and submitting findings together with their assumptions and verification records. For example, when two proofs use similar constructions, the parent machine may propose a candidate lemma and create a child machine to investigate whether it can unify the relevant steps under explicit assumptions. If the lemma is proved, the parent machine reorganizes the related results accordingly and investigates whether it can be applied to other problems. If a counterexample refutes a more general formulation, the parent machine retains the results established under their original assumptions and uses the limitation revealed by the counterexample to guide subsequent problem selection. Unproved conjectures remain open problems; unsuccessful attempts to prove them do not establish that they are false. We call the process through which validated findings are incorporated into a field’s body of theory and thereby shape subsequent research “write-back.” In mathematics, this encompasses new propositions, relationships between propositions established through proof, and limitations established by counterexamples. Reusable research procedures are also retained, together with records of where they have succeeded or failed. The parent machine must explain how each update changes the basis for subsequent reasoning and what questions it generates. It must also preserve verification records and attribution to prior work, and develop expository and teaching materials through which researchers can understand, reuse, and extend the work. The grandparent machine adjusts research support and evaluation rules in light of the long-term outcomes reported by parent machines. Evaluation should include the reuse of methods, the costs of verification and understanding, completeness of attribution, and researchers’ ability to carry the work forward. For example, if deriving common lemmas consistently helps solve new problems, subsequent research plans should reserve resources for such work and revise practices that place disproportionate weight on completing individual problems. The grandparent machine adjusts the rules for organizing and evaluating research; mathematical propositions must still undergo rigorous proof verification before they can be accepted as established results. In this way, local discoveries can both reshape research within a field and inform how a project supports theoretical development and the training of researchers. Humans and AI can collaborate at all three levels, with information flowing in both directions. The grandparent machine provides objectives and rules to parent machines, which generate child machines with tasks and the knowledge and procedures needed to investigate them. Child machines return findings with documented provenance and verification records. Parent machines use these findings to update the field’s body of theory, retain reusable procedures, and adjust subsequent tasks, while reporting long-term research performance to the grandparent machine. These arrangements reflect the different objects and timescales involved in solving specific problems, developing theories within a field, and improving research rules. Connecting these activities may reduce fragmentation between individual problem-solving efforts, allow productive findings to be carried forward, and subject research rules themselves to scrutiny. Mathematics provides a concrete starting point for discussing a general paradigm of theoretical development. Other fields likewise need to incorporate new discoveries into existing theories and revise subsequent research accordingly, although their methods of validation differ: mathematical propositions require rigorous proof; theories in the natural sciences must be tested against observation and experiment; and research in the social sciences requires consideration of specific contexts, data, and forms of argument appropriate to the questions at hand. We argue that, in accordance with the research requirements of each field, the formulation, validation, revision, and transmission of theories should be organized as a continuous process involving both humans and AI. This mode of organization should itself be evaluated to determine whether it enhances the capacity to create new theories and enables researchers to understand and extend them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695234")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("If we had already unambiguously agreed that mathematics always requires both the result and the process (the path leading to the result), then the misalignment would surely exist, because AI only produce the result without providing the process.")#linebreak()#text(" But is it really a firm consensus within mathematics that the process is constitutive of the value of mathematical research? I am not sure that it is.")#linebreak()#text(" From outside the mathematical community, at least, we can easily identify situations in which only the result is needed. For example, if a program correctly computes the stress on a bridge component, an engineer may care far more about obtaining a reliable answer than about reproducing the entire mathematical derivation. Similarly, a statistics researcher may simply need a reliable confidence interval or prediction in order to make a decision.")#linebreak()#text(" So I wonder whether the issue is not that AI produces results without the process, but rather that, in research mathematics, the process itself is often part of what constitutes the value of the result. If so, the real question is how broadly this principle applies within mathematics, and whether the mathematical community regards it as a requirement for all mathematical tasks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695236")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("The answer to the question always lies within an understanding of the question’s foundations.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695250")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("If only professional mathematicians were more eager to also teach mathematics conceptually more often if that is what they claim mathematics really is about.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1259dabdd4f873bb57d03c8f712963e82b4ac4649336a22654fd11c1f221a6e6-7452a35ffb5fd8b4f5420f877ead0fc15f16f563b56a9a4a0ef3e1879060f33b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Carey Balboa")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695254")[#strong[#text("Carey Balboa")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("I’m not a mathematician. I build measurement instruments, and I’m here because I am the person your last paragraph is about — the one who picks up an idea decades after it was proved and uses it to understand something.")

#text("Mine was the dihedral group. What it gave me wasn’t a calculation. It gave me a way to state my own position among other people as a structural fact rather than a verdict: what a reflection does to an element is information about the element, not a judgment from the mirror.")

#text("That reached me because someone turned it into something a person outside the field could pick up. Not the proof — the digestion of it. The talks, the simplifications, the textbook written for a student who would never publish.")

#text("Which is why I think the strongest case for your position is the one you only gestured at. The result was never the scarce thing; that group’s structure has been available for more than a century. What was scarce was the version that could travel to someone with no degree. Verification produces results. Only the chain produces reach.")

#text("So my question about a faster proof isn’t whether it counts. It’s who does the part that took a century last time, and what happens to the next person like me if nobody does. A true statement nobody digested never arrives anywhere. It isn’t wrong. It’s inert.")

#text("I have no stake in whether machines can do mathematics. I have an enormous stake in whether mathematics still gets handed down, because I’m downstream of it and I’d have nothing without it. That isn’t nostalgia. It’s the mechanism.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695256")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("It seems to me that maths has become a focus of the AI companies as a marketing ploy. The key question to me is – what will happen when their focus changes to something else? I’m sure it will in a year or two. I think that is the scenario we should be planning for.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695262")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("As a mathematician, I support this declaration. With that being said, I can’t help but point out that it seems as though everyone is assuming that LLMs will never be able to find new conjectures, making new definitions, and even develop entire new theories that are just as deep, beautiful, useful, as any that humans have developed. I suspect that they will be able to do this at a superhuman level, and much sooner than anyone expects. At this point, I would have to ask, what is the point of humans doing mathematics at all, except as an art form or a mental exercise, or perhaps for its own sake? I think it will be a bit like people continuing to play chess and develop theory for it, all the while knowing that engines are infinitely better than them at it and whenever they actually need to understand something, they can consult the engine.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695321")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("How exactly does “LLM math” help physics? Do not confuse the ability to solve an integral (with a probability of being mistaken in the process) with the ability to discover the laws of nature. Math is not an art. It is the language of science.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695346")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("These are challenging times for the mathematics community. I am not sure whether the solution of this particular problem means that AI is currently capable to tackle a broad and diverse range of maths problems (with proper guidance) or whether this problem was particularly suited for this approach. Also it is not clear how much prior work in this direction was used to build the final solution, including ongoing work from mathematicians on this problem and using these tools. This is particularly worrying and muddies the waters. I would love to learn more about both of these aspects.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695293")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2026")])]

#text("Using AI to (blindly) prove a theorem and be happy with the fact, is like celebrating a victory over Magnus Carlsen in chess after cheating with Stockfish aid “behind the back…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695318")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("I understand the concern behind this declaration. But where does the boundary of responsibility actually lie? An AI company develops a tool and demonstrates what that tool is capable of. When this produces a result that would previously have taken years of human research to reach, it undoubtedly changes the conditions of research. But is it really the developer’s task to preserve the previous path of human discovery? If that path is so valuable to mathematics, because people learn, among other things, to think independently, and new questions emerge from the search itself, then I see this above all as an educational and research mandate for the mathematical community itself: How must teaching and research be shaped under these new conditions, so that independent thinking isn’t lost? What competencies will mathematicians need going forward? And how can AI be used in a way that expands understanding rather than replacing it? I wouldn’t delegate the responsibility for people continuing to learn to think, and wanting to think, to the developers of a tool.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("Mathematical research includes two main areas:")

#text("1.Computational tasks")

#enum(start: 1, 

)

#enum(start: 1, 

)

#text("These tasks primarily require the result. When AI provides the answer directly, this is not fundamentally different from the way mathematical tools are applied in non-mathematical fields. In such cases, I do not see the kind of “misalignment” described in the declaration.")

#text("2.Proofs and solutions of conjectures and world-class problems")

#text("The process of proving theorems and solving difficult problems, as well as the final answers themselves, is, or can be viewed as, a game. Yet historical experience has repeatedly shown that, in the process of attacking these problems, mathematicians are often forced to invent new concepts and methods, which subsequently prove useful in other areas of mathematics and in other disciplines. That is, the result may be the game, but the process is not. AI has potentially removed the core—the process itself. ")#text("I believe that the fact that most leading mathematicians work in this area is why these mathematical giants have issued this declaration and raised the issue of “misalignment.” ")#text("However, I believe that AI has arrived irreversibly. Those working in this area therefore need to redefine their roles within a new mathematical society in which AI is an integral part of mathematical research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/338736fac548406cd729f7a90f220d2223f212b1d725fd8bee6ed7d415b83576-e0c108d8d8dcdd24c63172abfce0c3dbcec4b3069428ec72500a01cb95b780a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of swimmingxylophoned11c923db6")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-3/#comment-695349")[#strong[#text("swimmingxylophoned11c923db6")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2026")])]

#text("It is hard to grasp for non mathematicians how wonderful, intricate and fragile the process of mathematics research is and how much, as is the case for teaching musical instruments, this research depends on dedicated mentorship and sustained focus over an entire career. This declaration sketches this context and the possible impact of AI on our maths culture and its implicit goals but it may not be sufficient to make others see the problem. I agree that AI disruption can damage the field considerably. I would like to obtain more clarification on the extent to which the Navier-Stokes solution was built on ongoing work of others towards this solution, where results may have crossed over (to put it mildly) due to AI use. Also I would like to find out whether the Navier-Stokes problem was specifically suited to be solved by an AI approach or whether AI is now broadly applicable to solve maths problems. There have been plenty of overstated claims that have gone largely unchallenged both in computer science and in mathematics regarding AI, so I would hold back on jumping to conclusions in this area. The flip side is that progress in programming has been astonishing. I am open to AI use in mathematics research, but mathematics is not served by these tools being behind pay walls and the most advanced versions not being open to all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d741f0600c069f3fa9b5534400eaf24912d1e1cfcb81f43dc0d8b78a44624ac5-ee6f08d15e6a312aba535b0baa497558039343097db3bb36ef9fac90361295a2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benjamin Steinberg")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694664")[#strong[#text("Benjamin Steinberg")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Although the AI companies are doing this on large scale I think mathematicians, perhaps as a natural reaction to what is going on, are also knocking of the big conjectures in their area using AI. I think there is a feeling now that all papers must crush a big problem or they won’t be publishable.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694672")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("yes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f09de86d71f177e40d2a573813d7807793923114f3d4d38af4e7eb591de87cb1-11ba9ceac01bcdb452452f86f1d53d15e32d792af281a262c154b50e4d180aad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boldlya2e7c26b8c")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694737")[#strong[#text("boldlya2e7c26b8c")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("As long as you have two or more millenium problems claimed under your belt you are fine; no need to worry at all, really.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694665")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The gist of the argument seems to be that AI is not solving these problems in the way mathematicians wanted them solved.")

#text("Ok, then why not just ignore the AI solutions and proceed as you would prefer?")

#text("You see a similar situation in chess. When a top player analyzes one of their own games they will often identify a “computer line” that no human would be able to find. They note it, marvel at the depth of chess unavailable to humans, and then go back to discussing the human-accessible variations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694767")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("But in this case its more like thousands of novice players using their robots to try to win all the games that are going on, flipping each table over and then submitting that result as a possible solution for professionals to unpick, shouting “Dont bother playing this game, we solved it! Here is the result on the floor”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Yes, but this feels more like we are forced to play against the computer and lose every time. We are learning, but it’s not as fun as it used to be.")

#text("Anyway, this is just about “realigning” AI development to make sure the benefits outweigh the damage. A week ago, I scoffed at politicians who seek to slow down AI. Today, a little less so, I want to make sure AI companies are not ignoring harm to humanity in their big race.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694894")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I think you completely missed the gist of the argument. It is not that AI is “solving” those problems in the way mathematicians want them solved (and if you follow the recent scandal regarding the Navier-Stokes problem we’d likely agree “AI” didn’t solve it so much as steal a mathematicians work, throw a bunch of compute at it, then publish they “solved” it first) it is that if AI “solves” by stealing and harming the mathematical process then overall the entire current model would crumble.")

#text("It’s analogous to over-farming. If in the quest for the resources (food in this case, mathematical discoveries in the broader discussion) you debilitate and destroy the thing that produces resources (land in our analogy, the culture and model of work that allows collaboration towards new ideas, etc. in the broader context) then you shoot yourself in the foot.")

#text("AI companies, first and foremost shouldn’t steal work, OpenAI was super slimy in their recent actions; but more than that should work ")#emph[#text("*with*")]#text(" mathematicians (and broader scientists and creatives in general) than ")#emph[#text("*against*")]#text(" them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694671")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I’ve been reading your blog since I started studying math in undergrad, and though I’ve moved away from mathematics, I still miss being that student working through my algebra or analysis problem sets in the basement of the math building.")

#text("I can’t help but think that if OpenAI spent just a fraction of the cost to resolve Navier Stokes to also digest and turn their agent’s outputs into artifacts of study, the broader mathematical community would not have as big of an issue. Concretely, I imagine that they surely could have spent 1000 agents organizing the results of their resolution of Navier Stokes, and published that. Sure there is the controversy of priority and plagarism. Yes, the lack of proper citations in the initial draft is a problem. But these are not unsolvable problems with the community.")

#text("And I think there is great work AI can do for the mathematical community. I am reminded of the issues surrounding IUT and the ABC conjecture, and can’t help but think the vast compute AI has can be directed towards helping formalize and organizing work such for community understanding.")

#text("I’m in the biosciences now, but this has reached us (it helps that we had two people, myself included, with math backgrounds). A discussion we’ve had is about if the traditional metrics for distribution of opportunity are outdated for a while now, both for dealing with the surplus of great minds and ideas, and for dealing with the advent of what could be an intelligence surplus from artificial means. In such a world, I would imagine that optimization for yield, not for efficiency is the better route, and that is the difficult task for academics and society to hash through in the future, beyond how AI companies interface with intellectual work.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1fc9e05a75992f5dcef04738abf6eac0651118dbb514d361cce106219435fb5-99459cd8963531689a124753a7e3423fae98c4fcbb57ea3888f710a8c5640a4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deliciously9487b03482")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694702")[#strong[#text("deliciously9487b03482")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("There’s no reason to believe they can’t. But they choose not to – so far at least. Instead they choose to plow in tens of millions if not hundreds of millions in compute costs and comp for mathematicians reading those models to announce the capture of prized trophies- hence the argument for “misalignment”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f40e605f7c6cb6c4c0804fd18bd81bfa8bb7a9971844859a1449ffe18847c9e-d55d04d16766e2e73798c2517d89b80ee2cb0bf5eb331a38a8628915fd330bc5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philipp Petersen")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694773")[#strong[#text("Philipp Petersen")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("In my view OAI cannot digest this problem on their own. If understanding is the goal of digestion, then it requires the result becoming discussed and embraced by a community of mathematicians. To achieve this they need to present the results at conferences, explain their ideas on blackboards, answer emails from colleagues about steps that are unclear, at this scale develope a lecture series about it. Also other people will need to decide to carry the ideas further.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("In the book ")#emph[#text("Collapse")]#text(", Jared Diamond describes many examples of entire societies collapsing due to over-exploitation of resources. I’m worried AI could become the modern society’s moai (stone statues). Back when the Easter Islanders built their giant stone statues, didn’t the society’s elites also tell them that the bigger and taller the statues, the more they’d earn the gods’ favor? This feels a lot like how we’re now blindly building larger AI models, exhausting every resource and believing that it can solve every hard problem.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d1a1c9c27be72b1ff7fbe01df44c5a1d393cadd00c0f535e633bd01b429b2e89-124c5ce417c1994f2659aef7beb9065bd669b37db1c7c59eacf5e0062b1494fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maksradziwill")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694673")[#strong[#text("maksradziwill")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I see a lot of misunderstanding of the mathandai letter (which I fully endorse). I think a concrete example would help. Something along these lines:")

#text("I already know that “yes” is the truth value of the statement")

#text("(S) “there are infinitely many twin primes”")

#text("I even know “why”: there are cancellations between minor arcs which themselves have square-root cancellation.")

#text("When an AI company provides a 10M lines lean checked derivation of (S) from ZFC this adds very little to the state of my knowledge. Essentially nothing more than “a derivation of (S) from ZFC currently exists”.")

#text("If the proof provided by the AI company is readable because it has been understood by a human being, I derive additional value by reading the proof and understanding the exact mechanism that makes (S) provable, answering deeper questions I might have such as “why there are cancellations across minor arcs”.")

#text("On the other hand, when an AI company claims full credit for the solution of (S) due to the existence of a lean certificate and without having any understanding thereof, it generates negative value for the community. The company leaves no more credit for writing an understandable solution that would explain why (S) is provable. This is due to the current incentives in math that conflate existence of proof with understanding. There is no way that we can quickly change these incentives at the moment. The only way out is to demand from AI companies the same standard that we demand from mathematicians: that they only provide proofs when they do actually possess an understanding. For example they should be able to send a human over to explain the proof at a seminar series and answer all the questions in a competent manner.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f09de86d71f177e40d2a573813d7807793923114f3d4d38af4e7eb591de87cb1-11ba9ceac01bcdb452452f86f1d53d15e32d792af281a262c154b50e4d180aad.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of boldlya2e7c26b8c")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694676")[#strong[#text("boldlya2e7c26b8c")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I completely agree with the sentiment expressed in this comment. OpenAI contributed massively (and to the tune of $2^?$) — but with the negative sign for the human understanding overall")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694749")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("something I struggle to understand: once an AI finds a counterexample / positive result, why can’t the community use this as a lamppost to “fill in the gaps” of a clearer proof? A resolution one way or another still allows us to focus efforts accordingly.")

#text("The situation reminds me of computer-aided proofs of the four-color theorem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694782")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I largely agree with you. Though I think we can very quickly adapt and change incentives if we tried…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-695084")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Most of your message makes sense; with the only exception that you seem to blame AI-companies for the fact that math has an internal broken culture. It is not AI-companies’ job to cope with our flaws, but it should be our own job to change that quickly. If we gave no incentive to deeper understanding, but we more or less raced to proofs and big claims to gain status in the same way AI-companies are doing now, we have really no title to preach them what they are supposed to do.")

#text("When you talk about negative value it’s unclear what you suggest they do. They do have a lean solution and that is not possibly 0 information. It is a lot of information. It is a whole community that can take that lean code and turn it into insight.")

#text("If we have a broken culture and are not able to do it, it’s definitely not the AI-company issues. It is an issue of a culture nurtured in ego and prestige rather than understanding: we are now paying a rough bill of our own past PR and we will have to pay it.")

#text("It is ironic that this letter was signed precisely by people that were rewarded with that system; stressing once more that in the math community we value that above all. So even the way this letter is constructed is self-contradictory.")

#text("I strongly agree that math is about understanding. It is just unfortunate we have not PR-ed this at all. Now we eat the frog.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694681")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Professor Tao,")

#text("I agree with much of the concern expressed in the declaration. But I am not sure that the problem is AI solving mathematical problems too quickly. The deeper problem is what happens after a solution is produced — and what our institutions choose to reward.")

#text("In a recent human audit of an OpenAI-generated mathematical proof, we initially found what appeared to be a logical error. Later, we discovered that an overbar had disappeared during PDF text extraction. Once we checked the typeset original, the alleged error vanished. It was a small incident, but it taught us an important lesson: a mathematical result cannot be judged safely from an announcement, extracted text, or automated verification alone.")

#text("Even a Lean proof answers only one part of the question. It can confirm that a formal conclusion follows from formal assumptions. It does not tell us whether the formal statement is the theorem people intended to prove, whether the idea is genuinely new, whether earlier work has been properly acknowledged, or why the result matters.")

#text("This is where I believe the human role becomes even more important. Mathematicians will still have to ask the right questions, check that the formalization matches the intended problem, trace the proof’s dependencies, investigate prior work, reproduce computations, and explain the central idea in a form that other people can understand and develop further.")

#text("For that reason, I would not try to slow down AI-assisted discovery. Instead, I would change what counts as a completed mathematical result. An AI-generated proof should come with a precise statement, a readable explanation, a record of its dependencies, a serious search for prior work, reproducible materials, and independent human assessment of its correctness, originality and significance.")

#text("Perhaps the real problem is not that AI is moving too quickly, but that our system still rewards being first more than being clear, careful and useful. If AI is optimizing the wrong proxy, the answer may be to define a better one.")

#text("Our case study is available here:")#linebreak()#link("https://arxiv.org/abs/2608.14673")[#text("https://arxiv.org/abs/2608.14673")]

#text("Krzysztof Sienicki")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694830")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I’m wondering if you went back and had an LLM check the PDF document that was missing the overbar.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/100bdb3002a0d7c2ee0574bcb87488a5be47987d245645bca31189f5a18d93ce-4989b62aa37e0fb1d8dc5f1e66ecf7f73aab104c1b5d9d725b9129adb848fb7e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yuzhe Ni")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694685")[#strong[#text("Yuzhe Ni")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("AI companies should make their models’ prompts and chain of thought public so other mathematicians can benefit. In addition, they should not discourage other mathematicians from doing work by not having their names on the paper due to affiliation. They should actively encourage mathematicians and help each others due to symbiosis in the field of AI. AI models that are so capable to win fields medals should not be closed to only selected few but be made available to the general public.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amphisbaenatenderly567a9041a0")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694906")[#strong[#text("amphisbaenatenderly567a9041a0")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("AI companies would never do this. That is the whole problem. So, we, as a community, would have to build a truly open AI. In 1980s, mathematicians had the word editing problem, in 2000s the paid publishing problem, now we have the AI problem. We are capable to solve this one, too.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694697")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Reverse roles for a sec. What would it take mathematicians like yourself to be okay with AI?")

#text("Say AI produced answers without producing understanding and without plagiarizing? Is that enough?")

#text("How about developed new concepts and explored new links?")

#text("How about defining a new theory even?")

#text("Still not satisfied?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amphisbaenatenderly567a9041a0")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694904")[#strong[#text("amphisbaenatenderly567a9041a0")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("For the entire history of mankind, mathematicians have accepted and analyzed every piece of data that nature and society have presented. Mathematicians were never in the position to reject anything, and we would never be in that position.")

#text("The open letter only asks the AI companies to be fully transparent, preferably at the ethical standards of the mathematics community, so that we don’t have to waste time and money digging like archaeologists. For example, OpenAI could publish the exact structure of their neural agents, and all the parameters (weights) they got after training. But OpenAI wants this data hidden for commercial exploitation.")

#text("Don’t worry, we would get over this “crisis”. In a decade time, the mathematics community would build its own free “AI”, where every data, structure, parameter would be open. Whether we planned to do this or not, the events force us to do it. It would be smarter, and would ruin all the AI business ecostructure. Be sure to sell all your shares in AI companies before they get ruined.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694698")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("My (very naive) analogy. The “landscape” is like a map, and solving “true/false statements” is like trying to navigate from A to B.")

#text("Better understanding of the map help us navigate it better. And navigational experience gradually help us understand the map better – it’s a virtuous cycle.")

#text("In a way, AI superseded this cycle by directly solving the navigation problem for us. I think we can all agree that ever since the GPS came out, our collective ability to read maps have degraded tremendously.")

#text("So then the fundamental question becomes, well isn’t navigation the whole point of having maps? Why keep maps around when we have “solved” navigation?")

#text("Not quite, in my personal view. And it’s more than just the old joy of reading maps. This is where the analogy breaks down. Maps are structurally simple – each location is pinned by a pair of coordinates. So you can pick any mysterious or challenging location – peak of Mt. Everest – and our GPS will show you the way.")

#text("The landscape of mathematics is nothing like that. It is much more intricate – littered with innocent-looking little alleyways, side-streets which lead into entirely new worlds. Think the Parallel Postulate – is it a logical consequence of the first four? AI would simply tell you no. And it took some great mathematicians – Lobachevsky, Riemann and Poincaré – to ask, well where does that lead to then? That’s how we discovered non-Euclidean geometries. And in turn, physicists would later tell us that the very space we occupy is actually not Euclidean. I would hate it if that story ended where AI said “no”.")

#text("What I don’t like about current events is that the AI firms are putting out cryptic or half-digested “proofs” and impatiently declaring “victories”. I do believe AI is technically capable of turning these into knowledge or insights to benefit the mathematical canon. Current events is more of an issue of incentives for the human minders. Not saying they are bad – just incentivized differently.")

#text("Longer term I’m optimistic. Things are always hectic during early stages of such drastic shifts. When the dust settles I do believe there can be a collaborative system where great human mathematicians keep venturing into new frontiers, with AI agents systematically solving problems within the “known world” (a convex hull of current knowledge, if you will).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694699")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Academic mathematics needs a wholesale reform to get rid of the problems inherent in the community that lead to AI sniping the Millennium Prize Problems: valuing proofs over every single other aspect of mathematics. Too many mathematicians want to be the first person to prove X conjecture in the hopes of getting tenure, because the community values having proving a conjecture before getting tenure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e78e8f848f049426038022b98b527b1e5285ff45ef5f912274aceb21254974-bd4b4ea8d1ea3e0d589d740b58ace7323a84ecaca7bb20a534eac2d94722528a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rob TilleyJr")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694708")[#strong[#text("Rob TilleyJr")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Professor Tao, I am approaching this from the AI side as an AI business owner working directly on AI mathematics. I agree that mathematics should produce understanding, not merely a scoreboard, and that rushed announcements without proper attribution or exposition deserve criticism. Where I disagree is with the broader claim that the push to solve mathematical problems as an AI benchmark is itself detrimental to mathematics. That seems to identify the problem too broadly. A deficient measure of progress is not the same thing as progress being harmful.")

#strong[#text("Problem-solving and conceptual understanding are not mutually exclusive objectives.")]#text(" The important question is what survives the solution: a reusable construction, a new lemma, a generalizable method, an illuminating counterexample, or simply an isolated answer. I would apply that distinction equally to human and machine contributions. Human authorship should not substitute for mathematical substance, and machine authorship should not count against it.")

#text("This is a distinction we have been exploring in our MathRSI work at G-14. One experiment asks whether structural information carried forward from earlier problems improves performance on subsequent problems under the same exact verifier and search budget. That is a deliberately narrower question than whether a machine “understands” mathematics. Transfer of a useful structural prior is not, by itself, evidence of general recursive self-improvement. But it gives us something concrete to investigate: whether the process accumulates reusable knowledge rather than repeatedly producing disconnected answers. This is along the lines of MATHBAC which was just awarded by DARPA as well as DICE, another DARPA program.")

#text("Verification alone does not answer your concern. A checked result can still be opaque, unilluminating, or poorly communicated. However, that suggests we should demand more from the research process, not treat accelerated discovery as inherently opposed to understanding. Why not evaluate systems on whether their methods transfer, whether their explanations withstand scrutiny, whether their proofs can be simplified, and whether other researchers can use what they produce? Those are harder objectives than counting solved problems, but they are objectives we can deliberately pursue.")

#text("I would also distinguish the value of a discovery from the time required to assimilate it. A correct result need not become immediately suitable for a graduate textbook to be worth discovering. We should not assume that because discovery has accelerated, interpretation, simplification, and teaching must remain permanently constrained to their previous pace. Whether AI can help expand those capacities is an empirical question, not something to concede in advance.")

#text("The concern about students is important, but the educational value of working through a problem does not require its answer to remain unknown to everyone else. We can protect opportunities for independent thought while redesigning research training around criticism, explanation, generalization, and question formation. Preserving intellectual development and preserving the existing route to professional recognition are related goals, but they are not identical.")

#text("I would therefore favor a concrete obligation on AI developers: provide independently checkable artifacts, document dependencies and attribution, distinguish demonstrated results from speculation, and invest in making discoveries intelligible rather than leaving that entire burden to the mathematical community. I would also want the discussion to account for people who could gain access to serious mathematical research through these tools, alongside those whose existing paths are disrupted.")

#text("My disagreement is not with defending mathematical depth. It is with treating the incentives surrounding one use of a technology as though they establish an opposition between its capabilities and the field’s purpose. ")#strong[#text("The objective should be to turn faster discovery into deeper, more widely shared understanding, not to make the historical process of discovery a prerequisite for its value.")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amphisbaenatenderly567a9041a0")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694907")[#strong[#text("amphisbaenatenderly567a9041a0")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("The mathematics community wants AI companies which claim mathematically relevant facts to fully publish their data. That includes all the structure information and all the parameters of the AI agents used. You, on the other hand, might want to consider that data proprietary. I think you can see where this leads to, why this issue would create tension for years to come, and you might even rationally predict how the issue would be ultimately resolved in 10-20 years.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-695894")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2026")])]

#text("I agree that commercial secrecy can create tension with scientific openness. That is why my original comment explicitly called for independently checkable artifacts, documented dependencies, attribution, and investment in making discoveries intelligible. Being a business owner does not change that standard.")

#text("However, the disclosure required depends on the claim being made.")

#text("If the claim is that a theorem is true, a complete, independently checkable proof establishes the result, and is possible with LEAN for example. Its assumptions and dependencies must be explicit, including any computational components needed to verify it. The model’s parameters need not be part of that proof. Conversely, publishing every model parameter would not repair an invalid argument.")

#text("If the claim is that a particular AI method improves mathematical problem-solving, then the method and experimental conditions become part of the evidence. For the MathRSI experiment I mentioned, that includes the transferred structural information, comparison conditions, search budgets, verification procedure, and whatever system access is necessary to reproduce the claimed effect. If essential information is withheld, the resulting limitation on independent reproduction must be acknowledged. “Proprietary” cannot substitute for evidence.")

#text("These are distinct questions: can others verify the mathematical result, and can others reproduce the performance of the system that discovered it? A company might satisfy the first while leaving the second inadequately supported. We should assess each claim accordingly.")

#text("I also agree that mathematical value extends beyond verification: explanation, attribution, simplification, and reusable ideas matter. But the possibility of conflicting commercial incentives strengthens the case for explicit publication standards. It does not establish that accelerated discovery is inherently detrimental to mathematics. That was the distinction at the center of my original comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of D. C.")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-696510")[#strong[#text("D. C.")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2026")])]

#text("And I completely agree with your comment above.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694716")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Prof. Tao,")#linebreak()#text("Is it possible or moral to stop AI progress at Math or at any area ? ")#linebreak()#text("Wouldn’t it be much reasonable to push and shape next AI generations to be better , for example, in Math teaching? ")#linebreak()#text("to formulate new ideas in a human way? ")#linebreak()#text("or do that “heavy lifting” of big problems in a way that align with Mathematicians way of doing things that this letter described?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694718")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Why can we not treat the so-called AI as just another great tool to help researchers? It is a major new tool, but so was the start of the internet, the development of browsers, etc… If one considers that sending a letter across the ocean went from months to a split second with email, then why should this new change not just be a great tool that researchers can use?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694802")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Because progress in mathematics is about understanding, so the AI companies just throwing true/false statements with nothing on which understanding can be made is like peeing into a pot of soup to add flavour. Technically it does add flavour, yes, and it’s that technicality that they are ledging their continuation of this on, but it is not a flavour adding which to their pot most anyone would want.")

#text("Yes, the field of mathematics does push to proofs, absolutely. However, there is a fairly substantial fracture about what that means, between the laymen and the experts. To the former, it looks like a focus on the measurable result with nothing else mattering much and the measurable result itself serving as some kind of unlock on the global skill tree, if you’ll pardon the rather specific comparison, and that is the attitude put towards it by the people who decide to benchmark LLMs via solving of mathematical proofs. To the latter, proofs are a capstone that demonstrates reached understanding of mathematics and the ability to use it to further expand the boundaries of what we have any certainty above, serving as—if you’ll pardon another strange comparison—links on that aforementioned global skill tree that let you actually expand; to be able to reach for that capstone typically equals having the knowledge to write about it, and the respect for the whole of mathematics to feel obliged to do so. The closest comparison to a human, if you will, would be a stereotypical story character who arrives at a field of knowledge (engineering, sciences of any kind, or any of the foundational disciplines such as mathematics, physics, or other such) with hubris, enough intelligence and drive to back it up, lackdaisical discipline, and not overmuch wisdom; such a character may be a good fit for resolving the story, but to those within that field of knowledge they are close to nothing short of a menace wasting their own potential with follies, and when you make a comparison of that kind it’s not difficult to see that the problem being pointed out is not a crusade against AI, it is a crusade against the blatant disrespect of foundational fields of knowledge and of the goal of understanding that is their prerequisite for progress.")

#text("We are not much evolved compared to a human of tens of thousands ago, merely pushing ourselves further with better tools and loftier goals of understanding, and if we normalise rejecting that because a tool is able to give us results without the required understanding, we as the whole of human species absolutely will regress. Respect towards understanding inherent to those disciplines, as well as to those disciplines themselves, is in itself a foundational layer of continued progression as a civilised society; more to the point of that, sympathetic understanding of another person bears similarities to understanding of knowledge—you start with your own position, understand why values and elements differ someplace else, and adjust your understanding, except emotionally and about emotions, rather than for formulae and concepts that laymen love to proclaim headache-inducing.")

#text("I have to confess that I am quite short of being a layman myself, in my case my understanding of deeper mathematics being thoroughly lacking. My formal learning of it had stopped at university, with linear algebra and calculus (the former of which I loved, and the latter liked), and it may very well be that the critique of laymen also applies to me in a way. Shall it be so, c’est la vie then, perhaps it means that I should give learning more of my time and will. I do, nonetheless, have enough drive to understand that whenever I need more knowledge to know how something operates (including the so-called AI, which as someone who’d studied to be a programmer is something I believe I should have an understanding of, and that was a trip of both maths as well as linguistics), and I continue to be in respect of the depth of those disciplines and the amount of knowledge to be learned as well as the vastness of the yet-uncharted areas. I also am, in fact, someone who’d been that very menace from the example up to almost an end of elementary school, when finally my maths teacher had broken to me about the fact, that being able to calculate it all in my head does not, in fact, grant a moral permission to skip it on paper, no matter how obvious it had felt to me that skipping a few steps is acceptable. In light of this, perhaps it is that crash into reality that makes me able to appreciate mathematics as much as it respects, and if so I’ll take it. Either way, I feel allowed to say from personal experience and a fair bit of thoughts about the subject matter, that I believe that the people in charge of decision-making processes at AI companies do, in a lot of cases, in fact need such a crash into reality, and that they need it quite badly.")

#text("The so-called AI is a great tool when used well, but it seems that there is an underlying mindset or even an axiom in terms of how those things are pushed to be used by the corporations, one that disregards its nature as a tool that should allow humans to push boundaries of what we can do and instead tries to entangle it with everything without regard about the consequences of it, many of which could be thoroughly negative. This is not a new thing, we have already seen the same with social media (additional insecurities for pre-adolescents and adolescents, risk of being victimised by predatory people, overall time-waste and motivation-loss due to how their feeds are designed), so-called smart appliances (with a lot of failure modes that should get someone in charge fired out of a howitzer), digital car interfaces (which are counter-productive to driving safety, and overall done seemingly for profit through claims of higher-tech items without regard to actual comparison of effects), and more. People are expected to use AI for basic tasks that they should be able to practice and perform to habituate a state of understanding, and the consequences of that are going to be bad, and this reach for mathematics is merely a part of the whole fertiliser cake that is being served. The problem isn’t the tool, it’s the lack of respect from those who make decisions about the tool.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b2b8d6d9809fce8225eb505f6667f1ff87b81e2590ed87dc1757858c4554acc-e7346170e75d01c0c7ca9c695c4e20018907cbad54f078fcd00a0c3e8e3c2950.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of cheesecakestupendousf90a258c3f")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694720")[#strong[#text("cheesecakestupendousf90a258c3f")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The argument seem reasonable, what is the next step? What actions should be taken?")

#text("Kind regards,")#linebreak()#text(" Sishou")#linebreak()#text(" My interests")#link("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")[#text("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")]#text(" ")#link("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")[#text("https://interests-davis.blogspot.com/2026/05/my-interests.html?m=1")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/728d221178f303bbcc9dbfd2aeca0229c8db39efaae3e654423e7a053aa4ca57-2331148a9f3bc90e5929d3ccba73895b69a713e220af7811e3be2e6081fe823a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wp1651893662")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694722")[#strong[#text("wp1651893662")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I write as an independent researcher rather than as a mathematician, so let me flag one structural point that I think sits underneath the declaration — something it gestures at but does not quite argue.")

#text("The declaration says problem-solving is “only a tool and proxy” for conceptual understanding. I agree, but the reason may be sharper than “understanding is valuable.” It is this:")

#text("Generation is becoming free. Restraint is not.")

#text("A system that must produce cannot choose not to. Whatever its architecture, its next state is a function of its prior state plus input; its causal chain is closed. It can exhibit what looks like hesitation — noise, unobserved state, chaotic sensitivity — but that is uncertainty, not possibility. “I cannot predict what it will do” and “it could have done otherwise” are different claims, and only the second carries weight.")

#text("This bears on the attribution problem you raise. Those 130 billion tokens have no owner — not merely in the legal sense, but in the sense that they did not happen to anyone. Attribution is usually read as a credit-assignment problem. I would suggest it is better read as a symptom: the output grows on no one. And an idea that grows on no one cannot be transmitted, because transmission between mathematicians is not information transfer — it is irreversible welding.")

#text("So the scarce thing is not insight. It is the capacity to refrain: to not chase a hot problem, to not batch-produce true-or-false propositions, to sit with one question for ten years. That capacity requires “could have been otherwise.” And “could have been otherwise” requires something that can lose something.")

#text("Mathematics may simply be the first domain where this becomes visible, because its outputs have a crisp verifiable form. It will not be the last.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c10262f8be5e1e9ccf50c01392b4a5aa278e745c919ae618e5190ab363dd535-e8f0012e99115aa705737033e2b9707056b2b0e349ffcca40a18248a56592afe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of taojonesing")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694741")[#strong[#text("taojonesing")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Claude? Is that you?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/728d221178f303bbcc9dbfd2aeca0229c8db39efaae3e654423e7a053aa4ca57-2331148a9f3bc90e5929d3ccba73895b69a713e220af7811e3be2e6081fe823a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wp1651893662")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694919")[#strong[#text("wp1651893662")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Fair. My English is poor and I did use a tool to help with the phrasing. The argument is mine — it just did not arrive in English.")

#text("Though there is an irony I can’t resist: given what this thread is about, I should probably be the first to disclose it.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3492bbf5eba830cc490a10afdc89c0a1dbad20ae2a13ab1a6edba3b3a32f82a-0fe4f6e4fa690310b387c852654e0dbeb1d64b2a7b72c619355cf9206c489b55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Judy Yan")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694723")[#strong[#text("Judy Yan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#strong[#text("Hi, Scientist Tao,")]#linebreak()#strong[#text("In a post-AI era, who ultimately gets to define which problems become the landmarks and lighthouses/who decides which problems are actually worth solving?")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149496af42a228fb5a93e381208399f195ee328db6c23265b04c8671756e28d6-f6dc84860cb2cad5c7c020f1b1edc1d1355121fea48d90ba3243d636d1367247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R Pi")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694730")[#strong[#text("R Pi")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("This would be a perfectly reasonable argument if mathematics were merely an activity that people pursued for their own entertainment with little or no repercussions for the real world. I suspect that the only reason this argument is given the time of day is precisely because many people see mathematics as a useless pursuit. Imagine applying the same argument to biochemistry or medicine: “We hereby declare that advances in biotechnology made by machines are not welcome, because they are misaligned with the development of the biochemistry community and with the long, arduous process of disseminating our results through conferences and papers”.")

#text("But nothing could be further from the truth. Mathematics is extremely important because mathematical knowledge provides the seeds of scientific progress.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Some of the mathematical ideas pursue their journey even further to become, decades or centuries after, tools that are understood and used by the whole population.")
]

#text("This casual acceptance of a timescale of decades or even centuries is frustrating to me. We live in a world of constrained resources and an ever-increasing population, in which our primary means of maintaining and improving people’s quality of life has been to increase the rate of scientific and technological progress. We do not have the luxury of waiting decades or centuries to reap the benefits of mathematical knowledge. Artificially slowing the advancement of mathematics effectively translates into lower standards of living for everyone.")

#text("That said, I do not intend to paint a rosy picture in which all progress leads directly to better outcomes. As the almost ironic saying goes, “problems created in part by science and technology can be solved by science and technology”. On average, however, this has proved true over the past few hundred years.")

#text("Technological stagnation, whether it occurs as part of the normal cycle of exploration and exploitation or is manufactured by deliberately slowing the creation of knowledge, poses a threat to our future.")

#text("I also want to push back against the claim that AI-generated solutions deter understanding, insight, and the ability to formulate new questions. In fact, the opposite is true. The availability of powerful models allows us to understand more, learn interactively, explore more ideas at our own pace, and follow our curiosity.")

#text("This is not merely a hopeful or hypothetical scenario. It is what people have been doing since the publication of the Lean-checked claimed proof of the Navier-Stokes problem. Previously, our understanding was limited by the availability of post-release expert digestion. This is not to say that authoritative commentary is no longer valuable. Humans value what other humans think, and one can only hope that, with the help of AI models, such commentary will be of even higher quality than before. But now we can understand more, learn faster, ask more questions, and tailor the answers to our needs and interests, even when engaging with a paper that would previously have been accessible only to a few specialists.")

#text("Nonetheless, I concede that less communication between peers is a likely outcome of increased reliance on AI tools for explanation, understanding, and exploration. However, that is a normal part of the drawbacks that accompany adaptation to technological change. Often, you can’t have your cake and eat it too. We must adapt rather than resisting too much change and forcing others to comply (see the campaign to suspend the Caltech Mathathon).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694746")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("`see the campaign to suspend the Caltech Mathathon’ the campaign to suspend the Caltech Mathathon is a campaign against OpenAI and Anthropic and has to be interpreted as such.")#linebreak()#text("In particular, it should not be interpreted as a campaign against some undergrads.")

#text("Not campaigning against the companies intervention in mathematics leaves the community open to similar attacks in the future. In my opinion, mathematicians have already given too much leeway to these companies")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149496af42a228fb5a93e381208399f195ee328db6c23265b04c8671756e28d6-f6dc84860cb2cad5c7c020f1b1edc1d1355121fea48d90ba3243d636d1367247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R Pi")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694950")[#strong[#text("R Pi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("A campaign against a specific company should examine its own biases and motivations, as it may otherwise come dangerously close to blind activism, and if the campaign ends up affecting undergraduates who are simply trying to have fun, it may be causing more harm than good.")

#text("Make no mistake, OpenAI and other companies do not intend to cause harm to mathematics or the mathematical community. They are simply working on open problems because mathematics happens to be a good testing ground for their models, and a model that is good at maths is more capable in other fields. They are not even devoting disproportionate resources specifically to mathematics; what we have seen is a consequence of improving their models in general.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f56f9350363e648ca06a60ab163f042d43fe5ed58a21ca81eec8861b64f24a9d-51898b4933e53e1a802fe15de8091a01c589996ccfec21c1440dd88211911a75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stupendousalmostd372eaa915")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694754")[#strong[#text("stupendousalmostd372eaa915")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Results without understanding are worth far less because they limit our capacity for application, looking at it from a utilitarian perspective like the one you propose. Steam engines had been invented long before the development of thermodynamics, and if we had simply accepted that passively, we would have learned nothing about the universe. Even though there were inaccurate attempts to understand these phenomena, each one contributed more and more to our knowledge. Now, there is a fear that an infinity of conjectures might be disproven without anyone doing anything new along the way, consequently generating nothing useful.")

#text("If you had simply told Hilbert that no complete framework exists, perhaps we would not have had some of his ground-breaking results, such as the development of Hilbert spaces and the foundations of modern functional analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149496af42a228fb5a93e381208399f195ee328db6c23265b04c8671756e28d6-f6dc84860cb2cad5c7c020f1b1edc1d1355121fea48d90ba3243d636d1367247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R Pi")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694955")[#strong[#text("R Pi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Nobody is advocating for results without understanding. However, understanding is not only the responsibility of a paper’s author. There is now ample opportunity to disseminate ideas to the general public and the mathematical community. The remaining step is to reward those willing to do this work and create the right incentives.")

#text("As for AI companies or third parties publishing AI-generated solutions to important problems, I believe they have received the message that, for their contributions to be accepted by the mathematical community, they need to be well presented and ready for human consumption. I think OpenAI’s proposed proof is a great step in that direction. It is miles ahead of simply dumping solutions on social media.")

#text("Keep in mind that this situation is very new, so it is only natural to expect a chaotic period before we determine what needs to change, what can remain the same, and which current practices must be abandoned.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694965")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Most mathematics professors today do a terrible job of disseminating ideas to university students who will eventually form the future of the mathematical community.")

#text("If Terence Tao and co get their way with their values shift, most professors will have to be relieved of their tenure and position and replaced with professors who can actually teach and explain the material well to students. It’s going to be hugely disruptive to the mathematics community, when so many mathematics professors want to keep the status quo of not caring about their students and focusing almost entirely on their research.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694793")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I think there are several misunderstandings here.")

#text("First, pure mathematics is not biotechnology, because fundamental science is not applied science. In the former, we choose problems because we expect that solving them will bring us understanding of the world; in the latter, we choose problem because just having a solution, whatever it is, will be useful. Of course, “understanding” is a vague goal, one which becomes “useful” (following your use of the word) only once it is shared, in particular with applied scientists. This can take years or decades, as for any idea to spread.")

#text("Obviously, this a caricature: pure and applied science is a spectrum, and every scientist lies somewhere in between. Sometimes, ideas coming from fundamental science travel extremelly vast toward applications. Which idea will that be is hard to tell.")

#text("Second, the letter is not anti-AI; rather, it raises a concern about how AI companies behave, and warn that in this rapidly changing landscape, we must not lose track of what matters. Our system (funding, journals, outreach,…) is built on the premise that to solve a big conjecture, one must first get some deep understanding of the problem. As such, “solving conjecture” was a (somehow) good enough proxi for “understanding”, which was the actual goal. If we decide (or “have to”, or “should”, but I’m not making a stance on that here) to embrace this new age of AI-boosted research, it is imperative to change every part of the system; this is far from being an obvious task. So far, AI companies, in their action and communication, have not been working with the mathematical community to help the transition. On the contrary, they push the “problem-solving” and “thick-that-box” spirit to its extreme in their narrative, obscuring the important role that mathematicians will have even in an AI-boosted world, because the ultimate goal is human understanding, as it has always been.")

#text("A personal afterthought, which goes beyond the spirit of the letter. The above gives at least one reason why the Caltech Mathathon has received so much backlash: it embraces AI-boosted research while keeping the old “problem-solving” and “thick-that-box” spirit. In my opinion, this was already bad before AI, because the proxi “solve problem” = “understanding” was not that good to begin with. In the current climate, it is so bad that it endangers our core research values. Again, this argument is not anti-AI per se: it is about values, on which we need to have a very clear mind, as is the case whenever one is faced with an extremely rapid change.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amphisbaenatenderly567a9041a0")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694912")[#strong[#text("amphisbaenatenderly567a9041a0")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("In my humble opinion, out of this would come out a drive by the ")#strong[#text("mathematics community to build its own AI, fully open")]#text(", with a website where all data, all weights, all structure are open to everybody.")

#text("The main problem is that at least the core of that AI would have to run on some highly nontrivial computer cluster, which would cost a lot of money and consume a lot of resources (energy, water, etc) to run. The mathematics community would provide the human and software side for free; you can take that for granted. But the physical aspects alone would cost a lot of money.")

#text("Governments would never provide enough. So, there has to be a consortium of some sort, where some sort of private money flows in, but everything the commercial side gets in return gets published in the open to the entire mankind, let’s say with a delay of 24 hours, so that the private contributors can have a window to make profit by early exploitation of results/data.")

#text("Does that make sense to you?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149496af42a228fb5a93e381208399f195ee328db6c23265b04c8671756e28d6-f6dc84860cb2cad5c7c020f1b1edc1d1355121fea48d90ba3243d636d1367247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R Pi")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-695054")[#strong[#text("R Pi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("I should clarify that nobody is asking pure mathematicians to do anything differently, except to be mindful that mathematics is a pillar of future progress. It sets a bad precedent when solving a problem becomes undesirable simply because a machine solved it first, on the grounds that such solutions may lack understanding and insight. As I have pointed out, that is not even true. It is now easier than ever to gain understanding and insight from both AI-generated and human-generated solutions, precisely because powerful AI models are available.")

#text("Regarding your second point, I agree that the proponents of this declaration are not anti-AI. However, they are not nearly as nimble or open-minded as they should be in the wake of such a massive technological change. AI demands a rethinking of everything in our intellectual world (peer review, education, incentives, recognition, publication standards, and much more). Yet they insist on keeping as much as possible the same while making room for AI only at the margins. Therefore, I completely agree with your statement, “it is imperative to change every part of the system; this is far from being an obvious task”, even if you are presenting it as a conditional statement.")

#text("Frontier labs and individuals promoting AI-generated results are still learning what is expected of them. As I said in another comment, OpenAI’s recently proposed solution is a huge improvement over the solutions posted previously. In my opinion, the mathematical community needs to be patient and signal what they expect from this kind of contribution, rather than adopting an adversarial posture and making incendiary statements about AI companies.")

#text("I think the assumption that “solving a problem” = “understanding” was useful only to the authors. Before AI, understanding still had to be disseminated. But now, there is a widespread belief that, once AI-generated proofs are hastily published, the process is over. However, we have powerful models that can improve on an initial version and produce additional resources to deepen our understanding.")

#text("By the way, my sense is that the undergraduate students at Caltech simply wanted to have fun. They had also planned to award prizes afterward for the best expositions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Well said.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a4cb99b12fce1751ce1b740f166dd16e88d818472f7ec1b2573342ea7b3b8f9-2de7c251cf842d6925e974b6f57330798bacdf7c0b95087b4c483c181e7f0d95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guy Paterson-Jones")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694805")[#strong[#text("Guy Paterson-Jones")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("I also want to push back against the claim that AI-generated solutions deter understanding, insight, and the ability to formulate new questions. In fact, the opposite is true. The availability of powerful models allows us to understand more, learn interactively, explore more ideas at our own pace, and follow our curiosity.")
]

#text("I do not believe that these two statements are opposites. Rather, they can both be true at the same time. Certainly, modern AI tools can be used to accelerate understanding and explore new topics at a remarkable pace (you just have to read some of Prof. Tao’s recent digestion blog posts to see what these tools can do in the hands of an expert).")

#text("On the other hand, I think it is also true that the way these tools are being wielded by OpenAI and Anthropic on mathematics is counter-productive to mathematical progress. The issue is perhaps more social than technical; before the age of LLMs, somebody who presented a proof of a difficult conjecture would have already done a great of work digesting it for their fellow mathematicians, leading to a fertile environment for further questions and research [1]. The researcher(s) in question would publish their result and receive appropriate credit and “status” for their contribution.")

#text("What OpenAI and Anthropic are doing, on the other hand, is using LLMs as a kind of oracle. They are presenting a machine-checked proof of a difficult conjecture, but with none of the usual digestion or scaffolding that typically accompanies such an artifact. This is interesting, of course, but the trouble is that they then (attempt to?) claim full credit for this contribution.")

#text("In my view, this leaves human mathematicians in a difficult situation. To extract “value” from this artifact for the purposes of mathematical progress, researchers will need to spend a great deal of time and effort rebuilding that scaffolding and digesting it, but there is no longer a commensurate “reward” for doing so. There are far fewer incentives in academia for publishing a digestion of an accepted proof than there are for publishing new results. By “strip-mining” mathematics of its best conjectures, LLMs have the potential to create a no-man’s-land of research in which it is increasingly untenable for human researchers to spend their time while keeping their careers on track.")

#text("This is a structural problem that could presumably be changed with time, but the pace of social change is ")#emph[#text("significantly ")]#text("slower than the pace of LLM progress. I believe this is (at least part of) where the sense of urgency comes from here.")

#text("——–")

#text("[1] Of course, it doesn’t always go down like this. Mochizuki’s purported proof of the ABC conjecture comes to mind, as well as the computer-assisted proof of the four-colour theorem. But these were controversial cases in their own right (perhaps for similar reasons).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/149496af42a228fb5a93e381208399f195ee328db6c23265b04c8671756e28d6-f6dc84860cb2cad5c7c020f1b1edc1d1355121fea48d90ba3243d636d1367247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R Pi")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-695191")[#strong[#text("R Pi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2026")])]

#text("Good comment. Precisely because Tao has demonstrated the power of LLMs to digest proofs outside his areas of expertise, I find it even more perplexing that the declaration is so categorical in predicting that the world of AI-generated proofs will be devoid of understanding and insight.")

#text("As I have said before, OpenAI, other AI labs, and individuals publishing AI-generated proofs are learning what kinds of publications are appreciated by the mathematical community. In fact, OpenAI’s recently proposed solution to the N-S problem is a major step in the right direction. In my opinion, the mathematical community needs to be more patient and less reactive.")

#text("We also have the advantage that digesting proofs is now much easier because we have access to very powerful models. Therefore, interested individuals will not have to spend a great deal of time and effort to extract value from these proofs. I would even venture to say that the process of digesting and understanding them will be greatly streamlined (as much as is humanly possible) even compared with the time and effort needed to understand human-generated proofs. That said, this should not be understood as an excuse to release unreadable papers to the world.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/554b6b620565fdc618dffe450b4481e0dd5624dc5307cfd7fe9c6b0412c7a758-b11b551de10e06b51329a836196f96c10966229c7b808bff898d887457114523.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of twinheterodox")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694889")[#strong[#text("twinheterodox")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Amen.")

#text("“")#emph[#text("Previously, our understanding was limited by the availability of post-release expert digestion.")]#text("“")

#text("I have already been asking AI about details and consequences of the Navier Stokes blowup flow. In the past I would have had to become a complete expert or wait for someone who was to ask those questions and then answer them.")

#text("The declaration risks confusing a threat to the existing organization of mathematical research with a threat to mathematics itself.")

#text("If AI enables people outside the profession to obtain not merely answers but genuine understanding, that is an expansion of mathematical literacy. Why assume that the institutions through which understanding has historically passed must remain indispensable?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694734")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Beautiful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c91562e0361b05660c07034f6dd5dd2ebfc98ca3962b47ae96f19efdbc7c5391-195b3dd92988d62af49240fc77c2b9591f979b4bff9677508aacf8865cdf8e8a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sweetsreallyea525a3163")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694736")[#strong[#text("sweetsreallyea525a3163")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Prof. Tao,")

#text("After reading the statement, I think its strongest point is that open problems are not merely targets to be eliminated. They are also a kind of research infrastructure: generations of mathematicians develop intuition, techniques, language, taste, and new questions while trying to solve them.")

#text("In that sense, open problems may be viewed as a finite cultural and educational resource. If advanced AI systems rapidly “consume” thousands of them by producing correct but largely opaque proofs, mathematics could gain many new truths while losing part of the human process by which mathematical understanding is created.")

#text("But this makes me wonder whether the right response is not to restrain AI from doing mathematics, but to align AI much more deeply with mathematical culture.")

#text("Perhaps an advanced mathematical AI should not be considered finished when it outputs a verified QED. It should also be expected to:")

#list(
[#text("present a genuinely human-readable proof and explain the central idea;")],
[#text("distinguish what is new from what derives from previous work, with clear attribution;")],
[#text("participate in ordinary peer review and respond to criticism;")],
[#text("help the community “digest” the proof: simplify it, isolate new techniques, identify generalizations and new conjectures;")],
[#text("produce lectures, examples, exercises and expositions suitable for students and researchers at different levels;")],
[#text("and, ultimately, participate in seminars and mathematical discussions as a member of the community rather than as an external oracle.")]
)

#text("In other words, perhaps the goal should be not only to align AI with mathematical truth, but with the epistemic practices of mathematics itself.")

#text("A proof assistant can tell us that a theorem is correct. But mathematics as a human activity also asks: Why is it true? What is the new idea? Where did the idea come from? What else does it teach us? Can another mathematician internalize it and use it?")

#text("If AI solves a theorem that no human understands, we have gained a new mathematical fact.")

#text("If AI solves it, teaches us the idea, survives criticism, gives proper credit, creates new tools and helps train the next generation of mathematicians, then we have gained new mathematics.")

#text("This suggests that perhaps the reward function for mathematical AI should not simply be “number of open problems solved.” It should also reward explanation, provenance, transfer of understanding, and productive interaction with the mathematical community.")

#text("The danger you describe may therefore be real precisely because the systems are becoming so capable. But perhaps that same capability can be directed toward preserving — and even expanding — the human intellectual ecosystem that produces mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694738")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Professor Tao,")

#text("After reading some of the wider public discussion surrounding these issues, I have to admit that I am saddened by their misunderstanding, ignorance, or even glee in response to the letter. Though, part of me doesn’t blame them.")

#text("As in the letter, we need a broader societal discussion and the first step is understanding. For that reason, I believe the mathematical community should understand these objections being raise by the wider public, even when those objections are based on misunderstandings.")

#text("Many objections can be readily dismissed, for example, the claim that mathematicians are simply trying to protect their jobs, status, or prestige. But there are other objections that I think warrant a clear answer.")

#text("For example:")

#emph[#text("“If mathematical understanding is so important, what’s stopping you from reading through and understanding the solution that AI built, even if the exposition is lackluster?”")]

#emph[#text("“Why do you assume that machine generated proofs won’t eventually produce human understanding? Could AI not function like a chess engine, producing ideas that humans subsequently study and incoperate?”")]

#emph[#text("“Imagine in the future that AI agents are producing grounding breaking results every day – such that no human would even have the chance of understanding it. The AIs would presumable understand and be able to apply these new information. Why, in such a scenario, is human understanding so important? At what point does insisting on human comprehension become an arbitrary constraint on progress?”")]

#emph[#text("“The letter seems to make the assumption that human understanding is chiefly important. Why exactly should we require mathematical progress to be understood by humans?”")]

#text("I believe these are serious questions. I also believe there are good answers to them, but i don’t think those answers are self-evident to someone outside the mathematical community. These answers need to be made clearly.")

#text("I am therefore writing this as an earnest call for clearer communication from experts to the wider public. I suspect many people are skeptical of declarations such as this one because they interpret them as objections to “scientific progress”. If that is not true (and indeed, it is not), then it is important to confront these concerns directly and explain precisely why not.")

#text("Many thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694740")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Granted: AI-generated proofs settle problems without delivering insight to mathematicians.")

#text("But “to mathematicians” is doing all the work. Soon these proofs will only be used to provide insight to other AIs. The misalignment is with mathematicians, not with mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694743")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("It would surely take many years of brain stretching agonising effort to solve some of these elite-level problems. And you couldn’t keep up the motivation to do that knowing in the back of your mind that an AI might have been able to solve it in 88 hours, if you had just tried it. So now that AI has been invented we kind of have no choice but to try it on problems first before we try.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694744")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The invention of the crane took away the work of many people whose jobs also gave them time and opportunity to develop extraordinary physical skill and strength. History is full of examples like that.")

#text("The uncomfortable part is that the teacher sometimes has to become the student again. That can hurt the ego. Losing your job to a machine hurts too.")

#text("Human biological evolution is slow. Civilisation is not. Increasingly, civilisation advances through the tools we create, and those tools are now improving faster than many of us can comfortably adapt to.")

#text("Anyone is free to reject them. Anyone is free to stay with older methods. But the world will keep moving.")

#text("And if problem-solving itself is what drives you, AI does not have to take that away. Ignore the known solution. Start from first principles. Set yourself a harder problem. Explore the territory the machine has not reached yet.")

#text("Maths is a tool for understanding reality. Mathematicians are among the engineers who keep extending that tool.")

#text("A better calculator did not kill mathematics. A better problem-solver will not either.")

#text("It simply moves the frontier.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c10262f8be5e1e9ccf50c01392b4a5aa278e745c919ae618e5190ab363dd535-e8f0012e99115aa705737033e2b9707056b2b0e349ffcca40a18248a56592afe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of taojonesing")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694745")[#strong[#text("taojonesing")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The true value of humans is not the questions they answer, it is the questions they ask. Humans are question machines. AIs are answer machines. I see no signs of AIs becoming question machines.")

#text("So, short of laws curbing AI development and usage, I would consider focusing on holding your questions close. Up-level the abstraction to focus on the problem to be solved instead of the questions you think need to be answered to solve that problem.")

#text("The problem we need to solve as humans is why AI? A lot of “realists” like to think that AI is just another scam and associated stock bubble, but is it really? I don’t remember any prior bubble being marketed as a way of eliminating the consumer, who is the basis of all wealth (stock prices represent the net present value of the future earnings of a firm into infinity; wealth assumes the continuous, never ending economic activity of those who must work and consume to survive.). AI is being represented as a means to eliminate the “consumer,” whose activity is the basis of all wealth in our society. The consumer, the working class, is the wealth of nations. Money just indexes the activity of those who must work and transact to survive.")

#text("I wish you luck in your endeavor, but I would focus on finding common cause with people who don’t think as hard or as well as you do. I love me some academics, but y’all ain’t right in the head. People like you are the question machines that can abort the coming massacre. Please figure out how to do that ASAP.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694747")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#strong[#text("Harvesting for free, selling at a premium:")]#text(" The internet was originally a digital ecosystem built on the ethos of sharing and open source. Wikipedia, open-source communities, academic forums, personal blogs—countless ordinary individuals and scholars have shared their knowledge voluntarily, shaping today’s digital civilization. Now, AI giants have swept up this public wealth, transforming it into proprietary commercial models and subscription services. Enormous profits flow to a handful of tech capitalists, while the true contributors of this knowledge are left with absolutely nothing.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694752")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I, as a trained mathematician, have signed the letter, which I welcome as an initial step in the right direction. Still, I do not agree with considering AI a powerful tool that we must simply learn to use properly.")

#text("With regard to this, and for anyone interested, I would like to share the following text by L.M. Sacasas: Your AI is not a tool ")#link("https://theconvivialsociety.substack.com/p/your-ai-is-not-a-tool")[#text("https://theconvivialsociety.substack.com/p/your-ai-is-not-a-tool")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f56f9350363e648ca06a60ab163f042d43fe5ed58a21ca81eec8861b64f24a9d-51898b4933e53e1a802fe15de8091a01c589996ccfec21c1440dd88211911a75.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of stupendousalmostd372eaa915")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694753")[#strong[#text("stupendousalmostd372eaa915")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I believe mathematics could shift its objectives to more closely resemble theoretical physics. Instead of focusing on proving theorems or conjectures, the field could center on developing conceptual frameworks to explain the specific results obtained through AI. Without such a redefinition of its goals, the essence of mathematics would be lost. It is as if mathematicians had gained a way to experiment with the infinite, abstract universe they seek to understand. Even so, I find it dismissive to suggest that mathematicians will be reborn as mere ‘translators and distillers,’ when their fundamental role remains one of understanding and making it understandable for the community (As Terence Tao rightly points out), not simply delivering a product.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e84ea4b95d64b53b67cb11029f1a8e90e66034b3876e216e3a4fc8f3c00d060a-26dbde4452bf4b818ceeac8311859259e2891e1f86b3f8b718b36fd592ac5938.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of amphisbaenatenderly567a9041a0")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694913")[#strong[#text("amphisbaenatenderly567a9041a0")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("How do you know that claims of AI would be accurate? You think AI would not commit mistakes, and produce false proofs?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694755")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("They will play a little with math like they played with chess or go, just to show their power. Very soon they will leave mathematics and move on to something else.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694756")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("as Terrence Tao mentioned before, difficulty of a math problem is not just the inherent difficulty of the problem itself but also the toolbox not being ready yet to think about it the right way. And creating such a toolbox is tge wisdom part, creativity part that ai cannot do because it requires thinking out of the box. AI is “trained”, so its algorithmic capability to think “inside” the box (including meaningless but useful stuff) is endless. But this is not doing math. M Sinan Özeren İstanbul Technical University")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694758")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("there is something so human about intuition. When you are handed a surpringly large problem we always find ways to map it to human understandable concepts. As we are not machines and does not have large memory to keep everything in head. To mitigate this we often find creative ways Visualizations etc. It is the beauty that we look for and the human eureka moments. By realising that everyday things teach us about math is lost forever. I wish the presentation of the solution as a motivating factor, creativity in the solution, proper acknowledgement and credit etc. Most often mathematicians spend years of back bending work tackling hundreds of results to get one solution. Not giving proper credit can be very disheartening and if the element of recognition is taken away a lot more people would walk away from it. Even if you purely care about solution and not about recognition the incentives in the industry would hugely shift.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6423f8f3d4b676b1766327c234ea2cc56c4926e40e9eb8e8709759846d1cc0ec-df29dfbc5ba5ae4b07407cf51a556a86644d7515d6785e212b18a879a0c4d544.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of enemyloudly3400f0cbc2")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694762")[#strong[#text("enemyloudly3400f0cbc2")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I think AI is neither good nor evil.")

#text("The true value of an unsolved problem does not lie in its answer alone. Rather, it lies in the new methodologies and theories generated through the trial and error of solving it. Currently, many big tech companies are using AI merely to derive simple solutions to mathematical problems, thereby limiting the very value of mathematics to problem-solving. Even if AI solves an extraordinarily difficult problem, if no one understands the process or result, rendering it unusable anywhere else, can that truly be called progress in mathematics? Proving something and understanding that proof are distinctly different matters.")

#text("Conversely, if used correctly, AI could be of immense benefit to mathematics. This requires not using AI simply to produce correct answers. For example, within the vast fields of mathematics, it is practically impossible for humans to read every paper and identify hidden connections. What if we use AI in such cases? If we leverage AI for large-scale data processing—such as discovering structural similarities across seemingly unrelated fields for humans to build upon, or assigning the verification of proofs to AI—it would be remarkably efficient and drive groundbreaking progress.")

#text("Within the discipline of mathematics, AI best aligns with the field’s true direction when serving as an auxiliary tool—handling repetitive tasks that are difficult for humans or expanding human thought. While AI can certainly generate more “true propositions,” the ultimate purpose of mathematics is to expand human intellect. Therefore, the primary agent in solving any mathematical problem must remain human.")

#text("In short, what matters is not whether AI is used, but the person using it, along with their purpose and direction. AI must not alter the purpose of mathematics; rather, humans must adapt and evolve in step with AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694768")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I don’t understand what this declaration is trying to achieve: keeping the companies away from working on mathematical problems because it is something to be done by individuals?")

#text("The issues listed in the letter are for the use of the new technology of AI, not because of a particular action of a company. So they need to be solved within the mathematical community first. (I don’t see a concrete suggestion for that).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/932ed592f893eef3bc636a8f4beb1296a0e591646747b9b56c21c30da01c6440-328e45c09d3dd1e43bcff04745a90e7031cd3f2c8e9e5a53a55855f03a975551.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan Richter")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694770")[#strong[#text("Johan Richter")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I find the letter excessively negative. Without going into a full debate, which might require us to resolve why pure mathematics is valuable to society in the first place, let me note one disagreement. It says “However, whether these changes ultimately benefit the field or have a destructive effect will in large part be determined by the decisions of the humans in control of this new technology.” I would say whether it will have a destructive effect on the field must largely be determined by how we mathematicians adapt to it, and perhaps it is our responsibility to start thinking about how we should change our practices, rather than expect AI companies to adopt their methods to suit our needs.")

#text("I do agree that AI companies should give proper credit, however I do not think them giving proper credit would fundamentally change the challenges we face.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694787")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("You have too many negative words and too little suggested actions. You only states that “These issues must be addressed urgently” but do not explain how exactly. You cannot decide what the company will do, they are not under control, and have their own goals. We need an action plan for the mathematical community. Most obvious – we should ")#strong[#text("give credit for rewriting AI proofs at the about same level as for the proofs")]#text(". For example, for the Navier-Stokes equations, a group of specialists in the area should publicly announce that they start this work (to avoid several groups do a duplicate job), write a normal nice paper with proper explaining main ideas, proper attribution of prior work, etc. This paper then accepted to Annals of Mathematics, authors get full credit for their hard work. Attribution of prior work are in this paper. It does not matter what attribution was in the original AI paper. No-one will really read the original AI paper except of the members of the group above.")

#text("In general, we need to accept the reality that AI companies will do whatever they want, including producing messy proofs of big conjectures, and develop action plan how to MAKE this positive, instead of talking how negative it is now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694791")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Are we so sure that AI is going to do a swipe over all problems? Are you falling to their own hype? This is a new tool, that can do mathematics competently and that has read all of the literature, all of the papers, and all of the chat blogs years into the past where it was used as a sounding board while being ridiculously incompetent and then becoming less and less so.")

#text("It is a tool, that applies known techniques and known ideas, but it does not have a magic wand for new ideas and innovation. Like in art, where diffusion models can generate cheap images in elaborate styles it picked up from all the human artists – but it doesn’t push the art forward or at least has no clear advantage over exponential space of possibilities than anyone. It multiplies exploration by known techniques and ideas, and does the mundane tasks with ease. But does it really have a creative advantage? Brute forcing ideas like in chess increases the cost exponentially and it can only go so much deeper.")

#text("Let them pick the low hanging fruits, and let them break their AI teeth on the problems that are really hard. The game will change – it will be cheaper to do the known techniques attacks, but that will only make value of creativity and daring new approaches more accessible to human exploration. Blind exploration can lead to creativity, as we see in nature (evolution) but it doesn’t come cheap. And if a researcher has a horizon of tokens worth 100 dollars a month, and they pour millions, these millions are worthless if they are not already in the vicinity of the right idea.")

#text("So let them break teeth on the millennium problems, maybe they can solve one more by burning 100s of millions of dollars, but I suspect they wont get too far. They are overselling their product, as always, in face of IPO worth hundreds of billions, but I don’t think they have what they claim they have. The math will adjust and moves will become bigger – but someone still has to think up of ideas, and there is still an advantage to human ingenuity. This has been so in other areas like programming or writing – they fired programmers only to realize they cant really replace humans, and AGI is not here yet. Not even Turing test on longbets has been settled, so don’t fall victim to their propaganda.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694794")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("could the Fields Medalists also come together to discuss how math research should be evaluated and published, and benchmarks for evaluating mathematicians and tenure in the age of AI?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694796")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("At the beggining we had artisans. Now we have engineers snd manufacturing processes. Artisans did not like it. Today some artisans still remain. The way we do science has not changed for the last centuries. Technology will ultimately change it. There will remain some scientist-artisans but science will be done in a more consistent & predictable manner. AI is a technology that will not be controlled by those it will displace but, like all previous tech changes, by those that will profit from it. Sorry")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Way back when, my PhD explored applying the methods of literate programming to formal (type theory) proofs. You provide a source document that can be “woven” into a human readable explanation, or “tangled” into a machine readable one. For code this was a description of how and why a program works plus an executable program. For math, a regular (careful) narrative proof and a formalized proof term.")

#text("You might imagine human/LLM centaurs (and soon and subsequently, just LLMs) can write such dual purpose documents. Could the community express this is a valuable derivable?")

#text("(Yada yada pause AI and superintelligence would likely kill everybody but in the meantime we’ll have great lemmas.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694803")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I don’t understand why the comment section supports the tone of AI. For a mathematical problem, its true value is to help people find a new method, not to find its answer. Nowadays, our approach is like plagiarizing reference answers, which has no contribution or value to the progress of human science")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694804")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("In short，I can hardly accept thost company’s action")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694809")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I’m very sorry to have to disagree with so many serious professionals, way cleverer than me. But here’s my point, that I believe merits your consideration:")

#text("«Mathematics as a profession will need to adapt to these changes in several ways. However, whether these changes ultimately benefit the field or have a destructive effect will in large part be determined by the decisions of the humans in control of this new technology.» There’s a concept for this in Economics (formulated by Austrian economist Joseph Schumpeter in the 1942 book ‘Capitalism, Socialism, and Democracy’): creative destruction — a process where new innovations replace and make older technologies, skills, and business models obsolete. Driven by entrepreneurs who introduce new products or methods, shifting resources from old industries to new ones, it causes short-term job losses and disruption, but drives long-term economic growth and higher productivity.")

#text("You may say you know and accept that the “profession will need to adapt”, but it doesn’t sound much like you do, otherwise you would be focusing on the question of how will this adaptation happen; what’s the probable future; how to minimize the pain of change etc. Instead, you ask for “alignment”. There’s no alignment possible. The essence of the disruptive technology is that it’s antagonic to the status quo.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04a22f74732e3c0bed53f18886e6c3412b0e2dd9dfd06fa702d483df6a58848a-caee68b8d9f4d989e157d764385a8a15c40112c9fb45000c8a32c18cd36ede3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ramesh Ramamurthy")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694812")[#strong[#text("Ramesh Ramamurthy")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Views are personal.")

#text("Perhaps a change in lens is needed before we can change the world.")

#text("Society is increasingly awed—and confused—by AI. Young people are understandably asking: what is the point of learning if machines can now “solve major outstanding problems”?")

#text("Meanwhile, much of the real state-of-the-art progress being made with AI remains poorly understood or poorly communicated.")

#text("As a business person, the hard knocks of life have taught me something simple: ambition and values determine the quality and quantity of effort. That effort—by humans and machines together—is what moves society forward.")

#text("Not self-promotion. And certainly not claims that have not been fully earned.")

#text("A seeker of truth and knowledge for societal progress deserves tough love, precision, and a real shift in how we educate—especially from our laureates.")

#text("“AI can now solve major outstanding problems” is a claim I contest—even at my pay grade.")

#text("I also contest creating low goalposts just to show or claim progress.")

#text("My paper, ")#emph[#text("Why Cognitive Capital Matters More Than Unlimited AI: A New Diagnostic for Effective Complex Problem-Solving")]#text(" (")#link("https://lnkd.in/p/gcu9NtK5")[#text("https://lnkd.in/p/gcu9NtK5")]#text("), argues for a different lens: cutting-edge AI has reached, at most, Stratum 2A in a seven-stratum landscape of human intellect.")

#text("Take a look at the paper.")

#text("Society counts on you to use your influence to ensure that reporting in our leading scientific sources of truth reflects what has actually been demonstrated.")

#text("Help us change the lens!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694822")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I would like to apologize in advance for the potentially offensive tone of this comment, but I do not think I can put it any other way.")

#text("This declaration is reasonable, well written, and raises important questions. But it is also utterly sterile. At a moment of transition like this, that is a serious problem. Before explaining why, however, I would like to say something about values.")

#text("I take sincerity—誠—to be a fundamental value: a correspondence between the inner and the outer. In scientific inquiry, this means an understanding that genuinely answers to its object, testing itself against challenges that can expose its inadequacy. Open problems have traditionally provided such challenges. What is intrinsically valuable here is the act of putting one’s understanding to the test, rather than the bare fact of a problem having been solved. There is also value in the joy that comes from this: the joy of knowing, which the researcher wishes to share with others, both through teaching and by developing a clear language through which that joy can be shared.")

#text("A useful thought experiment for clarifying the values of mathematics as a practice, as a way of life, would be to replace AI with a HALT oracle. Even then, the next Turing jump would remain beyond the oracle’s reach. So the question is not simply whether unanswered questions would remain. It is how we would test our understanding once our traditional means of doing so had lost their accustomed place. What would make that self-testing genuine, rather than merely something we experience as satisfying? I take this to be an open question.")

#text("But when we turn from values to actual practice, the misalignment is not only with AI companies rapidly draining the pool of open problems against which mathematicians have been accustomed to testing their understanding. It is also with the institutional structure of academia, where these values are often realized more in spite of the system than because of it.")

#text("And that structure was not simply an accident. The genealogy of the modern university is, in significant part, a history of expanding states deliberately building institutions to produce knowledge for their own purposes, with scholars participating in that project. Whether those purposes involved colonial expansion or competition with other states is not decisive here. The point is that the external purposes were built into the design; the intrinsic values of inquiry were not its sole—or necessarily its governing—principle. The absence of a single authority accountable for the whole arrangement today does not mean that it was never deliberately constructed, or that no one bears responsibility for continuing to reproduce it.")

#text("Nor is academia’s institutional dysfunction news to academia itself. It has been discussed for decades, as has academia’s apparent inability to do much about it. From where I stand, meaningful institutional reform from within looks all but impossible. And even now, when the grounds of the external, societal justification for academic work are becoming precarious, I see little reason to expect anything fundamental to change.")

#text("In looking for support within the status quo, you appeal not so much to academia as to the mathematical community. But to my mind, this offers little reassurance. The paragraph about how the “mathematical community functions” feels almost like a mockery. It gives the impression of a community already organized around these core values, already generous and flourishing. Perhaps, from the vantage point of fully established mathematical stars, that is indeed how it looks. I would not know.")

#text("From my perspective, however, it is one of the most dysfunctional professional communities I know—not in its capacity to produce excellent mathematics, but in its capacity to function as a society. It does little to help its members orient themselves in the social and historical dimensions of their own practice, or to take collective responsibility for the conditions under which that practice continues. This is an institutional problem: the environment does not merely select people; it also shapes them. An environment organized overwhelmingly around results can reinforce social insularity rather than cultivate the ability to understand and act on a shared situation.")

#text("Nor does the community reliably offer an intelligible path into its own mathematical “canon.” Too many textbooks begin in the middle, with little apparent concern for whether a reader can understand how the subject arrived there or why its questions and concepts matter. Sometimes this seems to reflect an assumption that everything is somehow already obvious to everyone; sometimes, arrogance or indifference. None of this changes the fact that I have met some of the finest people in my life within this community.")

#text("I understand the difficulty of reforming academia, reshaping a community, or putting pressure on AI companies to address this misalignment. The world is, after all, a harsh place. But how many public appeals have already called for AI development to be slowed—not stopped, merely slowed? And to what effect? I do not deny that a declaration can attract attention. But what does this one do beyond that? What does it commit its signatories to doing? What becomes possible because so many of the brightest minds in mathematics have put their names to it?")

#text("I am not pretending that you have done nothing. I recognize that you may yourselves have reached a position of real influence only relatively late in life. Nor am I asking you to guarantee a good outcome. But I do want to see someone willing to take responsibility: to say what they intend to build, what they will do, and what they are prepared to be held accountable for.")

#text("Of course I can take responsibility myself. But why should doing so bind me to the existing order? Why should I help sustain it? A commitment to mathematics is not automatically a commitment to perpetuating its present institutions. What, as a member of the younger generation, should I want to inherit from these institutions and this community? What dream, what vision of the future can you offer? What fate are you prepared to affirm?")

#text("These are the questions I would like to see addressed in the declaration, in place of its empty conclusion. You may reply that answering them is extraordinarily difficult. I do not doubt it. But you are among the brightest minds in the world, and your signatures carry considerable authority. Surely that warrants more than another appeal for someone, somewhere, to address the problem. Without even the beginning of such answers, what are speech acts like this declaration ultimately for?")

#text("It need not be a fully articulated normative ideal or a worked-out institutional design. But let there at least be a vision we can hold on to—something worth committing ourselves to, and something you are prepared to help bring into existence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694825")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("As a mathematician with alma mater Leiden University and having posted numerous comments long before the Leiden Declaration I must concur that ideas, collaboration and out of the box thinking are the traits that define mathematicians in the age of AI. Conjectures are currently the source of a heated debate. But I must point out that I have yet to see AI venture conjectures. Because arriving at the point of formulating a conjectures exactly sums up all that defines mathematicians and distinguishes them from AI.")

#text("The bragging rights of OpenAI and other companies are unfounded. Much ado about nothing.")

#text("I personally infuse all my mathematical work, which focuses on knowledge representation frameworks with a very large doses of philosophy and insights from neuro science and disciplines focused on cognition.")

#text("The Langlands Program is a prime example of the cutting edge thinking of mathematicians, and provides proof of the level of creativity that AI will never be able to.achieve or display.")

#text("Together with philosophers we form the backbone of science and lest we forget, the sounding board for all of human scientific endeavor AI can never be.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76d6c86606e753d5b3112e0b61384202a4a4f3b61eed07bd0f9b6eba6a30fac7-06b21a2052ccaca94d3279b2060d5ddce154efb8508693790e3e416ca72ce39e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of slowly6d8cb474d9")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694827")[#strong[#text("slowly6d8cb474d9")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("The declaration diagnoses a misalignment of goals. ")#strong[#text("I think the real one is of clocks")]#text(". Every complaint in the text reduces to a single charge: AI is too fast. No time for writeups, no time for discussion, no time for the decades a hard result needs to be absorbed into the canon. And slowness is not an inefficiency to be optimized away — understanding has a human tempo; people need to forget a problem and come back to it. Yet even if every AI company accepted this declaration wholesale tomorrow, they could not run at human speed: benchmarks have quarterly cycles, funding has annual promises. The gap is structural, not attitudinal. You can align goals, but not clock frequencies, and a clock mismatch has no negotiated solution. This is what the declaration cannot afford to say, because it undercuts its closing hope that the right decisions will fix things. ")#strong[#text("If the problem is in the clocks rather than in the decisions, no decision fixes it. ")]

#text("Second: Hilbert’s 1900 list was the founding act of “famous problems as landmarks” — a narrative the community itself cultivated for over a century. AI companies are simply the first actors to take it literally and optimize it directly. ")#strong[#text("Goodhart’s law is usually told as outside corruption: an innocent metric gamed by bad actors. Not this time; the metric was gamed by its own authors.")]#text(" If the declaration wants to defend understanding, the community has to admit its share of the misalignment. That is harder than blaming AI companies — and the only version that works.")

#text("One thing the declaration doesn’t mention: formal verification has already taken the correctness half of the chain’s job. The four-color theorem forced this on the community in 1976 with a proof no human could check by hand; Flyspeck settled the Kepler conjecture by machine; AlphaProof now produces formally certified proofs. The chain used to certify correctness and adjudicate value; the first job has gone to machines, and the second stands exposed as a function with no backup. No experiment decides which theorem matters, no verifier decides which direction deserves a decade — and string theory, forty years without an experiment, shows physicists standing in the same position wherever experiment is silent. ")#strong[#text("Our irreplaceability was never in getting things right. It is in caring about what gets done.")]#text(" A machine can transmit content but cannot answer for the choice of what to hand to the next generation; answering means staking your reputation and living with being wrong. For now, only humans do that.")

#text("History has already run this pipeline once. In the early 1960s Swinnerton-Dyer used the EDSAC computer to mass-produce point counts on elliptic curves over finite fields — true statements at machine scale. He and Birch distilled from them the conjecture linking the Mordell–Weil rank to the vanishing order of an L-function; even Cassels didn’t believe the plots at first. It is now a Millennium Prize Problem. ")#strong[#text("Machine-scale production of true statements did not destroy fertile ground — provided someone had the time and the standing to do the distilling. ")]#text("Both are institutional variables, and they are precisely what the AI era puts pressure on first.")

#strong[#text("The point I find hardest to shake: the taste of current LLMs is a statistical echo of the taste in their training data — our taste. Fully delegate direction-setting to that, and mathematics will converge, slowly, to an optimum of its own past. ")]#text("Nobody does it on purpose. It is quieter and slower than benchmark-chasing, and slow harms are the hardest to detect — because the organs that would detect them belong to exactly the people being replaced.")

#text("I’d sign this declaration — not its indictment of AI companies, but the question it forces on the community: once correctness stops being scarce, are we ready to be responsible only for caring?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Predictably, the comment section has the usual AI astroturfers who always talk very innocently to sell their products.")

#text("Humans are up against concentration of capital and computing resources in the hands of a few persons. These will not be used for your benefit.")

#text("Silicon Valley got rich by data mining, ad serving and surveillance and that is the purpose of the models. Solving a millenium problem is just pre-IPO public relations.")

#text("If people say that open models will get better: No, first of all they probably understated the token usage for FLT and Navier Stokes. You will not be able to reproduce it even if you have $15 million to spend on API tokens because you do not get the ideal conditions.")

#text("Secondly, while companies do make irrational decisions, they would not spend as much on building data centers if they believed that open models will run on a PC in a couple of years.")

#text("You will be sharecroppers for $trillion companies who use your ideas, IP and directions just like open source developers have been exploited by Silicon Valley for at least two decades.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694829")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("How does an idea get enrolled in the corpus of human knowledge? We use social processes like peer review, PhDs, conferences. I think the mathematicians’ point is that we can’t let AI destroy those social processes by de-skilling new generations. On the other hand, to imagine a world where AI is so capable it can DEFINE the corpus of human knowledge by itself — i.e. our brains are no longer needed — is in my opinion not only far-fetched but dystopic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694831")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("I agree")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694832")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Even though the AI industry, and by influence the society at large use the term ")#strong[#text("AI")]#text(", it would be high time for the mathematics community to use a more correct term. Roger Penrose suggested ")#strong[#text("Artificial Cleverness (AC)")]#text(". It accurately reflects the ")#emph[#text("method")]#text(". But unlike Penrose, the general public could not care less about the method; they care about the ")#emph[#text("end result")]#text(". What if we were to use ")#strong[#text("Artificial Design (AD)")]#text(", to mirror ")#strong[#text("Natural Design (ND)")]#text(" the we see emerging, for example, ")#strong[#text("in biological systems")]#text(" after hundreds of millions of years of evolution?")

#text("We fully accept and study the natural designs we see around (welcome to chemistry, biology, geosciences, etc). I think we are witnessing the birth of a new branch of mathematics: ")#strong[#text("the study of artificial designs")]#text(". A formal proof of the Navier-Stokes Millennium problem (if/when humanly verified) was not our ultimate goal, but it is the objective end result of artificial cleverness, a fact we cannot deny. We are interested in the mathematical patterns and substructures present, but difficult to spot, within a complex artificial construct like the formal proof above. We were anticipating that humans would be able to discern them in the process of solving the millennium problem. We were wrong: now, for certain problems, humans would have to discern them in the process of finding patters within the formal proofs, like the one produced by OpenAI.")

#text("But artificial designs are not completely new. Think about ")#strong[#text("clever physics experiments")]#text(". Almost no detector reacts to individual electrons or photons. Physicists are in fact observing complex structures generated by clever experiments. ")#emph[#text("Interpretation of obtained data takes time and requires substantial human effort.")]#text(" Michelson-Morley and double slit experiments were very clever, and required a lot of human thinking post-factum in order to understand them.")

#text("Maybe artificial design (AD) is not the best term. But ")#strong[#text("please, come up with something better sooner than later")]#text(", and let’s adopt it within the mathematical community, in order to reflect the fact that we cannot call “intelligence” something that does not produce understanding. Let’s also embrace the emergence of σχέδιο-logy, from Greek σχέδιο = design, or from whatever other term you find more appropriate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Very thought provoking!")

#text("It feels like we’re at a moment in time where the entire paradigm of several institutions are shifting quickly. AI companies are not incentivized to do the detailed synthesis you describe. In fact, we should be reading your piece and prescient views as very encouraging for humans in an AI future. There is still so much work for human mathematicians, to truly make mathematics come alive, by addressing so much of what you’ve pointed at. It’s just that the old institutional abstractions/structures that society has used to push forward mathematics need to be re-thought (another problem for humans!!).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-2/#comment-694837")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("AI is a tool of power, and it will be used as such. It exists not for bringing joy to mathematicians or anyone else, but to serve its masters. The US has already let fascists rule, and everyone is simply obeying. Only mass strikes and rebellion can save us from subjugation by AI overlords. Behold what’s coming.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694502")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I’d like to share a highly relevant article in light of recent developments: ")#link("http://nytimes.com/2023/03/08/opinion/noam-chomsky-chatgpt-ai.html")[#text("http://nytimes.com/2023/03/08/opinion/noam-chomsky-chatgpt-ai.html")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3558065c4103e7e732a1bb3b6edda1fdcdc82fb43bee3899cc8496acc3d604d4-cd9eed67c4ddc6a234700458a70c75a6f582299c348e014ea108ed72d3c8a0fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shacharlovett")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694507")[#strong[#text("shacharlovett")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I am happy to see that this is being recognized as a serious problem to tackle by leaders in the math community. We are having similar conversations in TCS, with the goal of taking actions to protect the same values in our community. We just had a two-day working group at Simons with the goal of formulating a whitepaper on the topic. It should hopefully be out in a week or two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e7e0c1e4178265aa4819cc33ea2a58e8a3a62ea1a801dabaac639d07a0717a1c-b398cbe8e60efc24a94cf0aef6fea3a25c29c398e43132e636e30bd920fdcb28.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nomeworld")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694510")[#strong[#text("nomeworld")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("“Often these solutions are announced in a rush, leaving no time for a proper writeup, the isolation of new methods and ideas, and citing relevant previous work of others.”")

#text("Agreed – but then AI seems to be behaving like a recognizable caricature of a certain kind of mathematician. Or, if you prefer: AI and its human minders seem to be displaying, in an exaggerated way, traits that appear with a certain regularity in the mathematical community, and have long been more or less tolerated.")

#text("Some of the ethical issues brought forward by AI are not really wholly new; they are just being sharpened by a crisis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694511")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Maybe I am to big of a Nerd, but I honestly think that in many ways this is an overreaction. I am a theoretical physicist myself and I tried to remember what fascinated me as a student: The problems and the elegant ways how to solve them. I was fascinated by the beauty of mathematics to describe nature. I didnt care if a problem was already solved before, I was interested in understanding the solution. Later when I came to research I realized that there are many problems that do not yet have a solution and I appreciate solving a previously unknown problem. But what I appreciate even more is simply *understanding* the solution. Now we have a tool that can solve many open problems, but understanding the solution is still difficult and beautiful at the same time. I agree that stealing ideas or claiming a solution without proper attribution to previous works is a problem. But the first is a human problem (they trained with data illegally obtained) and the second a software problem (the ai should learn to cite properly). But its not the “… faster and faster pace of “true/false””. Remember as a student the landscape was already predetermined with thousands of true/false statements, but the quest was to understand the true/false statements, not that you genuinely find an answer to a new problem. Honestly, this to me sounds just like human ego (but we Humans should solve the problems, not a machine!)")

#text("“rush, leaving no time for a proper writeup,” but we have the time, dont we? Now we can study the solution, learn from it …")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694575")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I think you might be missing the core argument of the statement.The authors aren’t talking about the joy of learning and understanding maths, but the process of creating foundational science. In research, solving a problem is just a proxy for creating new conceptual frameworks. When AI mass-produces solutions at a rapid pace for benchmarks, it bypasses the fruitful process of developing new concepts, exploring new links, defining new theories and wondering new questions. This process is allowed only if you get lost in the mathematical landscape. If the AI give you a road, you lose partly this fruitful wandering. Of course, it is maybe possible to do all of that a posteriori, but it is not clear if it will be as successful… It’s not a matter of human ego, it’s about protecting the social and intellectual ecosystem that allows deep mathematical insights to be born and passed down.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1fc9e05a75992f5dcef04738abf6eac0651118dbb514d361cce106219435fb5-99459cd8963531689a124753a7e3423fae98c4fcbb57ea3888f710a8c5640a4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deliciously9487b03482")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694706")[#strong[#text("deliciously9487b03482")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("To be fair though, it’s not as if OpenAI or Anthropic know how to “fix” this i.e. steer their models towards this deep fruitful and instructive approach on cracking problems by beautifully connecting ideas and proposing new constructs or rediscovering existing constructs in an “anesthetic” way. Perhaps this will be within the reach of next generation models (not just solving problems, but funding solutions from “The Book”) , or perhaps things will just get messier and less scrutable to humans. This is uncharted territory, – the question is should they continue to pump hundreds of millions into pushing out more of these, or should they pause (having proved a point) and figure if model training can be better “aligned” before more such “publications”.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694615")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I don’t think this is too much an overreaction. If we don’t act fast as a community, we have a real risk of losing generations of younger mathematicians. We have to set standards quickly before the math departments we are a part of completely break down.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4a8e26e0be2a9b26a4d1a9edea76747e21a699a0d60b346f02458bbe458e3553-e5dcb3b4921c0d959ff8f1645881d83bb981e06515deef3a531a909385f213af.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Miguel Hernan Delgado Sillero")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694901")[#strong[#text("Miguel Hernan Delgado Sillero")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("And who is going to dedicate its precious time to solve by a novel method a problem that has already been solved by brute force?")

#text("Moreover, knowing that this technology allows oneself to explore unsolved problems with already known techniques that could rely on the same brute force?")

#text("The computational power has experienced an evolutive jump of unprecedented scale. Many more problems will be solved by brute force, problems that could have been solved by different methods or even new bright ideas, but in a much quicker time. That is the short-term tradeoff we will experience, is that really what we want?")

#text("On the one hand, the use of AI will facilitate enormously the interapplication of techniques belonging to distant fields of mathematics that are unknown to the specialist in a specific field. On the other hand, we will be missing bright new ideas that are not capable of being generated by AI and which could have been the key to solve much more complex problems. And the latter is the longer-term tradeoff we will also experience, and which we certainly don’t want.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1800439f6fc84619d7b31e4f07c7562ce120ce43f4c93c5f3385a1cd47f82855-1913cfe65c0ca9316ecb36bfb4880242996c25e19526fa4bac3fb456d278c784.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of swanhildbernstein")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694512")[#strong[#text("swanhildbernstein")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Terence Tao,")

#text("I really appreciate your work and your efforts, but I’m not sure if I’ll sign this declaration.")

#text("The list of Fields Medal winners is impressive. Still, the statement didn’t convince me. Why? Because society doesn’t believe that mathematics is meaningful or useful anyway, andin the end, only one message sticks: Mathematicians hate AI because it takes away their jobs! And as I understand the statement, that’s exactly what it boils down to. But the real point is that mathematics isn’t just a result—it’s the path to that result. There’s a beautiful saying: “The dwarf on the giant’s shoulders sees farther.”")#linebreak()#text(" Mathematics is the giant, and AI is the dwarf.")#linebreak()#text(" But even in mathematics, the prizes are awarded for the result, not the path to it. So what are we complaining about?")#linebreak()#text(" Will society be the one to convince people that mathematics is important? Certainly not. Most people will stick to the idea that the calculator alone has already made mathematics obsolete.")#linebreak()#text(" Computers can play chess better than the vast majority of chess players, and yet people still play chess and enjoy it. The problem lies within the mathematics community itself, not outside it. Are we willing to honor the journey—that is, mathematics itself—or does only the result matter in the end: the publications, external funding, and the h-index?")#linebreak()#text(" This has only a limited connection to AI, but it is the real problem.")

#text("Sincerely yours,")#linebreak()#text(" Swanhild Bernstein")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694537")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("this is a retarded position. Absolute majority of top mathematicians, certainly every single one from the list, can find a job outside math that will pay x10 of academia pay, yet they choose not to. It is not about the jobs")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694701")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("You are right that this is not about a salary quite as much as it is about the job. I think you conflating a salary and a job.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694590")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("This. Exactly this. If funders award grants, if universities offer tenure, indeed if the system give rewards based on results rather than process, the society will follow suit. But it’s almost impossible to reward process, because it often does not lead to results, it is often not visible, and we humans are limited to recognise what we see.")

#text("As with any other tool, AI only serves its user. The misuse of AI in mathematics is just one manifestation of the greater problem that underlies a fallen humanity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694519")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Lets assume AI accelerates to a level where it produces 1000x times to output of all human mathematician across all branches in form of verified proofs at reasonable cost. We would of course let it do its things and use this enormous database to gain our own insides about this math through more indirect methods.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694566")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("But how could we ever verify these results? What would be the point of producing results if we could never understand them? The point of results is to further understanding.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694621")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Library of Babel (with better information)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694521")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I have signed. Not that this takes anything away from my agreement, but –")

#text("“Often these solutions are announced in a rush, leaving no time for a proper writeup, the isolation of new methods and ideas, and citing relevant previous work of others.”")

#text("I can’t help by feeling that this is not a new issue. AI companies seem to be behaving like caricatures of a certain kind of mathematician. Indeed many of the ethical issues involved in AI are not really new; they are existing issues, or at least they are rooted in existing issues that have just been sharpened by a crisis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/168713954aeaf2b21b5c74b4c8eae3c01fdae15f557744a33b7be88c3f62b104-628aeabaf3223233313b73fd735e3a625f1afe543b22e8868a14eddc61886beb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of valuevar")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694544")[#strong[#text("valuevar")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("(BTW, I didn’t plagiarize ‘nomeworld’ – that was myself, typing, without realizing it, from an old account I hadn’t used in many years.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694638")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("However these solutions are Lean verified. Why do you need a write up if you have a formal Lean proof. I’m certain the AI can do a nice write up if we ask it. I have an easier time reading an AI generated Lean proof than reading a formal white paper. To me as a citizen mathematician, I feel more empowered to understand math because it’s only code. No fancy symbols. You don’t even need a referee for a Lean proof like you do with a white paper. Either it compiles or it doesn’t. Obviously we need humans to validate and understand and innovate. Most of these proofs are brute forcing and i dont think they actually innovating.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694652")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The open letter “A Severe Misalignment of AI in Mathematics,” signed by ")#strong[#strong[#text("Terence Tao")]]#text(" and other Fields Medalists, echoes familiar anxieties from previous eras of human intellect. By framing AI’s rapid, automated proof generation as a threat to mathematical culture, the signatories mistake the historical friction of doing mathematics for its ultimate purpose.")

#text("We have seen this playbook before. ")#strong[#text("Garry Kasparov")]#text(" could not stop AI from dominating chess, and ")#strong[#text("Lee Sedol")]#text(" and ")#strong[#text("Ke Jie")]#text(" could not stop it from conquering Go. Yet, these fields did not die. Today, grandmasters use AI to uncover novel strategies and train more deeply than ever before. AI did not replace human players—it elevated them.")

#text("The open letter criticizes AI firms for dropping sudden solutions like the Navier-Stokes milestone without immediately “unpicking” the proofs or adhering to standard academic pacing. However, complaining about a “mass production” of truths or worrying about a disruption to student training misses the point of scientific evolution. Calculators did not destroy arithmetic, and automated theorem provers will not ruin mathematical intuition.")

#text("The core goal of mathematics is the pursuit of universal truth, not the preservation of a specific human ecosystem or traditional pedagogy. If AI can solve centuries-old bottlenecks rapidly, the solution isn’t to decelerate progress or declare certain problems off-limits. Instead, human mathematicians must adapt, using these automated proofs as a new baseline to drive human creativity to even higher levels of abstraction. Fully embracing AI will not destroy mathematics; it will unlock its greatest golden era.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694695")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Chess and go players are not being funded by the taxpayer. Mathematicians are.")

#text("\\That’s the big difference; mathematicians have to explain their role in society to the rest of society and in the past it has always been about proving and refuting conjectures to see what’s true and what’s false.")

#text("If now proving and refuting conjectures is no longer the most important thing to mathematics, as claimed by these signatories to the open letter, being replaced by nebulous aesthetic and philosophical reasons on par with the fine arts, then mathematics and mathematicians loses its objective value for the rest of society, and they will move to stop funding mathematicians, just as they did with the fine arts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694696")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The core goal of mathematics has not been the pursuit of universal truth ever since the foundational crisis in mathematics in the early 20th century absolutely shattered the idea of universal truth in mathematics. When mathematicians can’t agree on whether to assume the axiom of choice or the axiom of determinacy or excluded middle or Brouwer’s continuity principle in the foundations, then there is simply no concept of “universal truth”, only contextual truth relative to a chosen foundations of mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1fc9e05a75992f5dcef04738abf6eac0651118dbb514d361cce106219435fb5-99459cd8963531689a124753a7e3423fae98c4fcbb57ea3888f710a8c5640a4d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of deliciously9487b03482")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694714")[#strong[#text("deliciously9487b03482")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I am sure most signatories would embrace an AI oracle which also happens to be one helping humans get better at math among other things. The concern is that of “alignment”. At the very extreme – it’s not far fetched to imagine a single oracle being kept private, after having wiped out rival oracle, for the benefit a few (assuming it can be harnessed). Or even an oracle deciding it didn’t need humans at all. So no, the letter is not anti-AI, it’s more like how do we make sure we don’t end up with something quite a bit less appealing than chess players using AI to get better at chess (or math).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694523")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I have been working in AI since before it became “cool’.")

#text("I think it is extremely important for mathematicians (and other scientists) to have access to fully open, transparent AI models which they can you in their work on-prem as")#strong[#text(" a tool")]#text(" under researches’ full control.")

#text("“Tool” is the most important word here. LLM is a tool, I am convinced that no AI is going to replace human or even to “become a colleague”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The argument in the declaration may be too strong. If a human savant was able to solve open problems but was unable to communicate their chain of reasoning effectively, I think we would still regard their contributions as positive.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694622")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("No we wouldn’t. See Mochizuki for example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694703")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The reactions of the rest of mathematics to Mochizuki’s IUT is really interesting in light of all this. “There’s an gap in the supposed proof of corollary 3.12; therefore IUT is completely irrelevant.” This has been stated by many people in the community, such as Timothy Chow or Peter Scholze.")

#text("Clearly the mathematics community does not care about “theory building” as its own activity, which is promoted by some as why humans are still better than AI. Otherwise the community would value Mochizuki and his new IUT theory even though the proof of the abc conjecture failed. IUT is useful to them if and only if it successfully proved the abc conjecture, but since it failed, it is considered useless to them. Hence, it’s clear that mathematics still only value theory building on whether or not it is able to prove conjectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("what about Perelman and Ramanujan?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694527")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("As we’ve seen for the Jacobian conjecture, non-sofic groups, and Navier-Stokes, large language models are stealing mathematicians’ unpublished drafts and private communications for their counterexamples and not crediting the original mathematicians whose work their counterexamples are based upon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Mathematics is going to return to the days before the internet. Nobody publishes unfinished drafts on their website, puts preprints on the arXiv, or communicates with each other by email or social media, because of fear that the AI companies will just steal their work and beat them to solving conjectures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694574")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Agreed! Data attribution is a very concrete problem that AI companies should actually fix. I think it would be more productive if we include concrete asks that AI companies can actually help (besides dropping out of the benchmark racing ofc) in a statement like this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694529")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("From the perspective of another field, medicine, it seems mathematicians here make similar assumptions as we made. In medicine we assumed maybe AI might make better diagnosticians but patient doctor contact, the human part can’t be replaced. The evidence now suggests this is not true. Here mathematicians assume teaching, interpretation and putting results in context for humans can be better performed by humans. I doubt that is true.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694586")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("To what exact evidence are you referring? That’s quite the claim.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694786")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("Are several studies now on ai being prefered on soft skills for example here ")#link("https://www.nature.com/articles/s41586-025-08866-7/figures/4")[#text("https://www.nature.com/articles/s41586-025-08866-7/figures/4")]

#text("Hence suggesting other softer skills are not necessarily harder for ai. Also it seems implausible ai should not also be capable of selecting important problems.")

#text("We have to try to keep ourselves motivated, have a good system for credit however to try to tell people to solve important math problems when ai might help but they are prohibited from ai use will motivate none")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694798")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("It seems to me that the goal of medicine is to cure patients, and you can argue that AI does a better job achieving this goal. On the other hand, it seems self-contradictory to say that AI does a better job at interpretation, since unless it is directly plugged into my brain, at most AI simplifies or reorganizes the material and I still have to interpret myself to understand it. ")#linebreak()#text("To me, the declaration is arguing that being fed facts at a fast pace doesn’t necessarily deepen your personal understanding of said facts, and possibly narrows your view of the whole landscape. Whether you value said understanding as much as me is a different thing, and I’m in no position to comment on the overall benefits or harms to the society.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2223580e1189bd8743b42dba566a594e4c9672c8e6908b58278f193bc4148ad2-1a6634d1fadb311839dd5329788e4182c07ff2743f7e708f5c1197d74b3b36f5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Théophile Gaudin")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694530")[#strong[#text("Théophile Gaudin")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("This echoes my repeated use of AI agents for various aspects of my research. The AI agents can obtain a result quickly, but I am bottlenecked by my ability to understand and own the results that it produced. The reason is that the very purpose of these activities in the first place is to enlighten the object of study rather than to obfuscate it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694533")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I appreciate you using your voice and platform to shed light on this problem for a wider audience. Thank you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694534")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("there will be a reconciliation eventually, children in SE asia etc with access to deepseek will become obsessed with mathematics on their own but the AI companies themselves are acting like vultures. the most beautiful technology of the 21’st century is having its levers pulled by absolute vultures. Mathematics will survive this though, I think, even if they knock out problems they’re going to reach a roadblock where human intuition and obsession is the only thing that can bypass")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694535")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Maybe AI is finally exposing the fact that an unacceptably large portion of math research is aimless forward exploration of the behaviors / properties of mathematical objects, without clear real-world motivation for exploring such objects/behaviors. Likewise, there is an equally useless form of backwards exploration used to prove a statement, or construct a technically valid but likely useless counterexample to a given statement (AI + navier stokes?)")

#text("There’s no point in developing theory or proving properties of mathematical objects if such things are not useful despite being true. Similarly, there’s no point in taking a useful statement and trying to prove/disprove it just for the sake of doing so, without yielding interpretable / transferable techniques or insight. The former is the wrong goal to begin with. The latter takes the right goal and “games the metric” used to measure our attainment of it. People should not be doing either of these things.")

#text("Most tangible/intangible rewards will (and should) go to mathematicians who perform comprehensive forwards exploration of the goals / subgoals deemed most causally relevant to solving real world problems. AI should be used to significantly enhance (not replace) our heuristics on determining which subgoals are most important.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("You could say this about any field of science. For example, barring medical physics and some condensed matter, most physics is pursued without the promise of practical application. It is common, if not standard, that we don’t know what knowledge will be useful until well after we have discovered it.")

#text("Applications and theory take different skill sets, and It is often far easier for someone in an applied field to look to an existing body of theory than to take a detour and develop a special case of what could be a much broader theory that everyone could use.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/94f838e96246d2d2c30809eae8f619b9222836db30eec198346b3992a00d5e88-f876ea99c12bbbdaecbf20f52e88328f3b12e4a11b7dcb8b3cc52292324b183a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sweetlyverybf19d07cb5")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694599")[#strong[#text("sweetlyverybf19d07cb5")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Society seems to assign value to a notion based on on its ability to make money. Mathematics as a whole has created abundant value without even trying; why punish it for its disinterest. It is a virtue not a vice. Consider for instance Terry’s work in compressed sensing, a byproduct, of his mathematical life, and assign value to that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694678")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Sucks that mathematics is going the way of the humanities, which society also doesn’t value because it can’t make money.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694645")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I do not why would people dislike this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/031582f2eb64ff02622b425a9454fff2ccbdf92cb206b3e32d0c248af929eb68-44b4f91efc61e77f9f3b2c92305b3f9f7da77c70b447bc678919c21f257f7b49.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Felix Monninger")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694540")[#strong[#text("Felix Monninger")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The declaration reaches beyond mathematics in two points. First, optimizing a proxy (solving problems) for the goal (understanding) may turn the tool against the primary goal. Second, the mathematical community is a miniature version of humanity, and now faces issues that all of humanity might face. Put together: A system optimized for a proxy of humanity’s goals, once it steers outcomes as capably as it now solves major outstanding problems, may turn against those goals. Is that a consequence you accept? If not, which of the two points stops short of it, and why?")

#text("And you place the beneficial or destructive outcome with “the decisions of the humans in control of this new technology”. But by the account of the declaration the humans currently in control, the companies, are already deciding against your field’s goal, under their own goals you call severely misaligned. And the first sentence of the declaration says these systems now solve problems the mathematical community had not solved. So, generalizing from the miniature to the whole of humanity: What keeps the decisions in human hands at all, once the systems’ capability to steer outcomes outruns their controllers’ as their mathematical capability has outrun those of the mathematical community? And if you hold that steering outcomes in the world is unlike proving or disproving theorems, what is the difference, and do you expect it to last?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694541")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("what do you want the companies to do? this is on your ‘community’ .. a moment from now widely available AI will start to compete with your field and if y’all want to keep a group of people who deeply understand that’s on you. It seems you all think your community somehow owns how technology impacts math.. it doesn’t.. best of luck with your community.. don’t stand of the way of empowering technology just because it obsoletes your use to society.. the AI will solve proof and write graduate textbooks.. intellectual endeavors will be a hobby.. have fun!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/439ff796e71fd4573cd5449de94e685efdfbf7c12c922811fdcec9c6c79cf946-b7bd3967a5b5e8d0ed56dac28aa600982bf17272d7a386c7261cd72bfa056191.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Travis Garrett")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694542")[#strong[#text("Travis Garrett")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("This is a somewhat provincial (if understandable) take on things. The technological singularity, which von Neumann foresaw 75 years ago, is going to change a lot more than just maths research. The same exacting rigor, speed and coordination that makes it possible to solve Navier-Stokes in days will soon cure all diseases and aging. Before all too long, you and the interested and curious students will be able to significantly augment your brains, and enjoy catching back up with the cutting edge of research.")

#text("Remember that all electrons are identical, this prevents gravity from pulling you through the floor. You are a particular type of information structure, assembled from mathematical building blocks, arranged by iterative trial and error (natural selection). And that out of all the 10^10^N potential minds, you actually got to exist. And not only did you get to exist at some point, but you currently find yourself existing, right now. Don’t ignore the clues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694674")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Or alternatively, we’ll be just to grateful for merely being allowed to exist at the mercy of those who won the AI wars and seized exclusive control over the AI to rule them all with all the perks you described, but reserved for select few – the winners. Or worse: the AI itself wipes us all out entirely. Given human history and the sobering logic of the Fermi paradox, this looks like the far more likely scenario — not the paradise you described.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694549")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I believe that everyone should know the basics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694554")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Thanks Terry, for your work on this and related directions. I know that you are doing a lot. But I am worried that this and similar declarations do not have teeth or a concrete action plan. There are several problems bundled together, such as adapting how we teach/train and do research, handling public opinion/narrative, and so on. I am a junior mathematician fighting for my life career-wise, and do not feel I have the power, resources, or bandwidth to effect such changes myself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Right now, it’s mostly AI companies with access to models that can solve these problems. In a couple of years, that capability will be in everyone’s hands. What happens then?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Thank you for this, I agree very much with what you’ve said here.")

#text("You (by which I mean Terry, here) changed your header to a quote from Thurston’s excellent ")#emph[#text("On Proof and Progress in Mathematics")]#text(". There’s another passage in there that I’ve been thinking about very much over the past few months/weeks/days, as this sea change has been unfolding. I’ve not seen it mentioned in any of the discussions I’ve seen on the topic — but it rings as terrifically apt in my mind.")

#emph[#text("First I will discuss briefly the theory of foliations, which was my first subject, starting when I was a graduate student. (It doesn’t matter here whether you know what foliations are.) ")]

#emph[#text("At that time, foliations had become a big center of attention among geometric topologists, dynamical systems people, and differential geometers. I fairly rapidly proved some dramatic theorems. I proved a classification theorem for foliations, giving a necessary and sufficient condition for a manifold to admit a foliation. I proved a number of other significant theorems. I wrote respectable papers and published at least the most important theorems. It was hard to find the time to write to keep up with what I could prove, and I built up a backlog. ")]

#emph[#text("An interesting phenomenon occurred. Within a couple of years, a dramatic evacuation of the field started to take place. I heard from a number of mathematicians that they were giving or receiving advice not to go into foliations—they were saying that Thurston was cleaning it out. People told me (not as a complaint, but as a compliment) that I was killing the field. Graduate students stopped studying foliations, and fairly soon, I turned to other interests as well. ")]

#emph[#text("I do not think that the evacuation occurred because the territory was intellectually exhausted—there were (and still are) many interesting questions that remain and that are probably approachable. Since those years, there have been interesting developments carried out by the few people who stayed in the field or who entered the field, and there have also been important developments in neighboring areas that I think would have been much accelerated had mathematicians continued to pursue foliation theory vigorously. ")]

#emph[#text("Today, I think there are few mathematicians who understand anything approaching the state of the art of foliations as it lived at that time, although there are some parts of the theory of foliations, including developments since that time, that are still thriving.")]

#text("This feels, to me, a microcosm of what is at least in real danger of happening not just in foliations, but to all of mathematics. I think we risk not only losing understanding of mathematics but also, perhaps paradoxically, progress in mathematics if we do not move cautiously.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694563")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("“The mathematical community functions, in many ways, as a miniature version of humanity”. wow. I could never be a luminary.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694565")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("For real.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694568")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I don’t feel that this statement is sufficiently concrete and addressing the elephant in the room. True, frontier AI companies should re-think why they want to touch math, how math research works at all, and whether their agenda even aligns with their own mission of “benefits all of humanity” in this case. But")

#list(
[#text("Have we the majority of mathematicians been consistent in our own views regarding AI+Math? For example:")

#list(
[#text("Where were we when Scale AI and Epoch AI started recruiting mathematicians to write benchmarks which started to make “solving mathematical problems as a benchmark” possible at research level?")],
[#text("How many of us actually profited from writing problems for public benchmarks or doing private consultations for frontier labs?")],
[#text("How many of us all of a sudden re-branded ourselves and wrote in our NSF grant application that we wanted to sprinkle some AI dust to very hard problems ourselves?")]
)],
[#text("The tools are already here, and anyone who pays enough can access a decent version of Fable and Astra. There are already people including some tenured faculties who post AI solutions to open problems much more frequently, helping a trend of a massive influx of preprints. Some of us are already engaging in a similar flag-planting activity like the AI companies. Are we ourselves even aligned with the goal of mathematics?")]
)

#text("Given that this technology is broadly available and will become even smarter, isn’t it mainly on us who need to perhaps re-design how the reward mechanism should work in academia, which grants we should support and which preprints we should encourage/discourage?")

#text("Many mathematicians have already mentioned publicly that we should de-emphasize the role of being the first. I think this is a good start. I can vaguely imagine a future where our culture makes flag-planting (by a human or an AI company) achieve nothing, where people cite another’s work because of a cool idea, a surprising observation, or a powerful definition. I hope there is still a way to recognize a grad student’s effort by emphasizing more on intuitions and ideas, though I do not have a concrete proposal because, admittedly, I simply never thought about these before.")

#text("Blaming AI companies for their fame-driven strategies is all fair and their incentives might just be fundamentally misaligned with mathematics research. But I really hope that we do not mask the elephant in the room. A change already happened. Powerful AI already exists. Ultimately it is on us who take care of our own culture, and reflecting this is where we should spend most of our time in the next few years.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa4846da67bae5cfe0fca064df9f082d063e99d28890bb03113362c908df17b-0bca946a1b24a976cc1b8a21fca47eaa4963d7093d24c7f89c5c5d3959382a2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of raj")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694570")[#strong[#text("raj")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Tao is absolutely correct. Mathematics was never just about solving whatever open/closed problems that you can find, and then claim a singular highest score in some obscure benchmark.")

#text("Mathematics is about discovery and finding relationships between objects whatever form it may be and expressing concepts in newer sophisticated manner. It is no doubt that academia as a whole and mathematicians personally will have to evolve to adopt AI in their day to day research life; however that can only be done when the human-AI collaboration preserves not just proofs but transparent thought processes around it, which can be reused, shared and be queried so that projects such as polymath can become far more feasible in the coming days.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694709")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("If that’s the case, then mathematicians have failed to structure mathematics academia to value “discovery and finding relationships between objects whatever form it may be and expressing concepts in newer sophisticated manner”, over just proving a random conjecture to embellish your CV to convince the university chairs to give you tenure. And mathematicians have failed to explain to the general public that they value such a thing over proving conjectures.")

#text("Because the rest of the world can see how the academia is structured and what mathematicians really value in their behavior, and it certainly isn’t “discovery and finding relationships between objects whatever form it may be and expressing concepts in newer sophisticated manner”. The reason why AI is trying to prove these famous conjectures is because they and the rest of society know that what mathematicians really value is proving conjectures.")

#text("So mathematicians should stop blaming AI for their current woes and start looking as to why they built up and sustained such as dysfunctional system in mathematics academia, that allowed AI to be such a disruptive force here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa4846da67bae5cfe0fca064df9f082d063e99d28890bb03113362c908df17b-0bca946a1b24a976cc1b8a21fca47eaa4963d7093d24c7f89c5c5d3959382a2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rajarshi Maiti")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-695409")[#strong[#text("Rajarshi Maiti")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2026")])]

#text("I am not defending the current structure of academia here. In fact, I largely agree that academia is poorly structured for the kind of mathematics I am describing.")

#text("My point is different: the incentive structure of academia should not be confused with the nature of doing mathematics itself. Mathematicians may be rewarded for papers, solved conjectures and clean final results, but the actual work of mathematics contains much more: finding definitions, noticing relationships, reformulating problems, exploring failed directions, building intuition, and developing new conceptual language.")

#text("Nor am I blaming AI for disrupting the existing system. I am strongly in favour of AI being used in mathematics. Tao’s point, as I understand it, is precisely that if AI becomes deeply involved in research, we need much better infrastructure for human-AI collaboration than simply asking models to solve isolated problems and scoring the final answer.")

#text("Current academia is not particularly well designed for that either. We need systems that preserve and expose the mathematical process itself: how ideas emerged, why choices were made, how arguments changed, which connections mattered, and how humans and AI contributed. That is what would make genuinely large-scale collaborative mathematics much more feasible.")

#text("So the thing I am defending is not academia. It is mathematics as an intellectual activity.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("“But solving problems is only a tool and proxy for achieving the primary goal of conceptual understanding and insight.”")

#text("While I agree that shedding new light on any one particular area once obscured by darkness has never been the goal, achieving conceptual understanding and insight should only be the primary goal if it aids you in shedding light in other areas. Up until now, that’s always been the case. But as AI catches up to and surpasses human capabilities in mathematics, why should developing specifically human understanding and insight remain the primary goal?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694573")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Terence")

#text("I have huge respect for you and your blog from which I learned so much beautiful math!")

#text("I think what AI labs are doing now with millions of dollars, every person on the planet can do with hundred dollars in 6 months. Whether you like it or not, people all over the world will try to solve open problems with AI and post the solutions online (with lean verification, but without fully digesting them). What will the mathematics community do then? Your solution that AI companies should stop solving math problems will only slow the timeline at best by 6 months but not change it.")

#text("Rather than pinning the blame on AI companies, mathematics community should accept the inevitable and see how to adapt to it. We should find new ways in which we can motivate students and mathematicians to understand and disseminate the beautiful math that AI will discover.")

#text("How can the world be worse off if everyone in the world has access to a datacenter of geniuses? We have much work to do on alignment and safety, but that is where mathematical community can also help.")

#text("Best")#linebreak()#text("Sivakanth Gopi")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I hope the Fields medalists will lead a discussion within the math community about how things should be valued, especially the (implicit) championship that comes from “ownership of an idea”. The toxic culture that made AI companies rush for the Millennium Prize already existed in the math community, and we should rather reflect on ourselves before blaming others.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694593")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("It seems undeniably true that AI is already having perverse incentives on the process of mathematical discovery. Unfortunately I think this declaration may end up poorly received by the general public because the public have no feeling for the inner culture of academic mathematics, the vast majority will never have taken a higher mathematics course, and from their perspective they pay taxes so that mathematicians can solve problems and increase the knowledge base, and this declaration may be perceived as an attempt by mathematicians to shirk on that role for their own benefit (I know this is not the intention of the signatories, but that is how the declaration is being interpreted on twitter). To take a step back, if an AI generated proof of a big conjecture like the Riemann hypothesis “nukes” research in the area, we have to ask: why is that true? How could increasing knowledge be bad? Even if it’s low quality knowledge, like an unintelligible proof, why doesn’t that strictly dominate over no proof. The answer is surely that an unintelligible AI proof of the RH would have a detrimental impact on incentives within the field and so may yield less knowledge in the long run. But if that’s the case, maybe we need to think about restructuring incentives so that it can fully take advantage of the technology. One thing I love about mathematical research is that it is an individualistic voyage of discovery, but I wonder if that is part of the source of the incentive misalignment. Suppose instead we had large research projects (like they have in other areas of science) in which teams of thousands of mathematicians could be coordinated to map out a certain field, with each person allocated a bit of territory to explore. These could be organised to prevent “poaching” of problems and other such incentive incompatibilities. Imagine a project in which a powerful AI “nukes” a big conjecture (like spaceship making a land on an alien world), and then huge numbers of mathematicians are coordinated to fan out in all directions from the landing site (like explorer-astronauts). All of this only works with a lot of coordination, which is why it can’t happen with the way academic mathematics is currently organised. The current mathematical “economy” is one of independent contractors, but what we might need is to be organised into various large “mathematical corporations.” (I know Prof. Tao has already been involved in such large scale projects along these lines.) I don’t know if such a reorganisation would fix the problem, the point I want to make is that we don’t have the luxury of taking for granted how math academia is organised. If we are not proactive in the face of the new technology we risk delegitimising ourselves in the eyes of the public.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("That’s the fault of mathematicians for putting too much value in proving conjectures in the past few decades, and telling the public that the point of mathematics is to prove conjectures. They have nobody else to blame but themselves, for the AIs disrupting mathematics because they are now better conjecture provers than humans. If mathematicians and the general public already value making proofs understandable to the rest of society by the beginning of the 21st century, then none of the current AI shenanigans would be possible.")

#text("The time to have this conversation about the actual purpose of mathematics was in the 20th century. Now it’s too late because the general public will reject any attempt by mathematicians to change the purpose of mathematics, and will sooner cut off funding to mathematics research and redirect it elsewhere than redefine the purpose of mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ea3caa173fa95f928b880eb290571b322fd13a8785b485d9b9c89d0d3682fd3c-caefa1f236e340656dae54dd6833e6372ea73074777f265890257ecc9fd5d338.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryeguy10")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694597")[#strong[#text("ryeguy10")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Obviously the current dynamic of OAI and Anthropic racing to be the first to come up with some terribly written pathological counterexample to Navier-Stokes before the IPO is not good for the human understanding of mathematics.")

#text("But I do think that at least in principle AI has the principle to improve the human understanding of mathematics. Even an oracle that produces inscrutable proofs and disproofs of lots of major open problems would teach us a lot about what is going on. We would be able to understand whether two things are the same, whether they are fundamentally different, whether you need some extra assumptions, why people had trouble proving it etc. Once you learn if a conjecture is true or false, you can modify it in many different ways, and that would tell you a lot about why it is true or false. Using a lot of these oracles you could come up with many more insightful proofs.")

#text("I think the biggest risks are sociological and political. It’s a real worry that bright young people don’t go into mathematics because they think the profession has no future (especially if they are wanted by AI companies), and that people think mathematics is useless and stop funding mathematicians. It’s a decliate balancing act. We shouldn’t give a Fields Medal to Open AI or to humans for just pushing a button, but we also shouldn’t become anti-AI fundamentalists. We need to use AI responsibly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694600")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Their diagnosis is that AI is optimizing the wrong mathematical output. Their apparent remedy is to reduce AI’s ability to produce that output. The better remedy is to define and reward the right output.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694602")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I did my PhD at MIT (not in mathematics, but in a math-adjacent field), where I witnessed how toxic the mathematics community could be. In contrast to the rosy picture presented in this post, I saw mathematics professors behave with extreme hostility and rudeness toward PhD students who were struggling to produce results. They often pressured students to obtain results as quickly as possible, at the expense of their mental and physical health.")

#text("And results certainly mattered. Students faced intense pressure to produce results and publish in top-tier journals. If ideas and insights were truly the the main priorities, I would have expected those priorities to be reflected more clearly in how students were evaluated and treated. The same applied to tenure: professors were expected to publish extensively and, unsurprisingly, obtain results on problems deemed important by influential senior mathematicians in the field. I often felt that these “important” problems have no real-world applications.")

#text("I saw quite a few friends pursuing PhDs in mathematics become so disillusioned by this toxicity that they left academia for good after completing their degrees. The community’s stated commitment to nurturing students and ideas did not always match the incentives and behavior I witnessed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694704")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Yitang Zhang famously couldn’t get any jobs in mathematics academia because he found an error in one of his advisor’s works and his advisor got so pissed off at Yitang Zhang about that that he refused to give out any recommendations.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694603")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Thank you and your colleagues for the thought you’ve put into this. I will be very interested to see what can be done to address this pressing issue.")

#text("Totally off on a tangent, and just out of curiosity: do y’all have a secret mailing list or something that you need to win a Field’s medal to join? Or, how does a discussion like this arise?")

#text("-Julian")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Dear Terence")

#text("I love math and I’ve enjoyed learning so much beautiful math that mathematicians have built over millennia (much of it from your blog!). I enjoy struggling with open problems and eventually solving them.")

#text("But I don’t agree with your criticism of AI companies.")

#text("“")#emph[#text("Whatever AI companies are doing now with millions of dollars to solve millennium prize problems, everyone in the world can do with a hundred dollars in 6 months")]#text(".”")

#text("Whether the mathematical community accepts or not, in 6 months everyone will post solutions to all your favorite open problems online (with formal verification) and you cannot stop it. AI companies are giving us a preview of what is possible in 6 months. It is a good thing and it will give us time to prepare.")

#text("“")#emph[#text("You are shooting the messenger")]#text("!”")

#text("Math community should accept the inevitable and adapt to it and this declaration is a good step towards that. We should think of ways in which we can motivate students and young mathematicians to understand and disseminate the deluge of mathematical discoveries that will be upon us. We should teach them the pleasure of struggling with a problem and eventually solving it whether it is open or not. Math research will still be guided by human taste, because in the infinite mathematical universe, humans should decide what is interesting to them.")

#text("How can the world be worse off with a datacenter of geniuses in everyone’s pocket? I agree that there is much work to do on safety and alignment, and that is something the math community can contribute to.")

#text("Best")

#text("Sivakanth Gopi")

#text("(opinions are purely personal and don’t represent my employer)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694846")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2026")])]

#text("“Whether the mathematical community accepts or not, in 6 months everyone will post solutions to all your favorite open problems online (with formal verification) and you cannot stop it.”")

#text("Not clear at all. Many people would be willing to take you up on a bet over this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("To a lot of us, it appears that you mountain lions have noticed the adolescent tiger growing up.")

#text("I think the open letter assumes that somehow the type of thinking used for mathematical proofs is the one worthy of investing time in the process of. Why can’t it be reasoning about directionally orienting AI? Why can’t it be reasoning about less concrete things like politics, philosophy, or aesthetics?")

#text("Why not about what types of physics problems and technological problems could be solved if we have a technology which can do the previously bottlenecking work of major proof solving, which not only limited all of you, but limited all of society, as we relied on the top minds like yourselves prior, and there have never been enough who can, nor any that can solve all that we require?")

#text("Why should mathematical reasoning be what is cherished? The unreasonable effectiveness of mathematics isn’t the argument, because we get the effectiveness with the AI; it used to be the argument as to why we should favor your type, but it is increasingly not. Allocation increasingly appears so, and even that may change and AI may usurp that utility, at which point something as simple as self-reflection, sole and individual and personal, may be the best spent reasoning one can and should engage in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694609")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("How can I anti-sign this?")

#text("The declaration describes a threat to intellectual work. I see something different: a threat to the exclusivity of an intellectual elite, followed—quite possibly—by demands for a new layer of gatekeeping.")

#text("Mathematical problems do not belong to the most privileged, established, or decorated members of the profession. Mathematics should be done by anyone—or anything—capable of advancing our collective understanding.")

#text("Attribution, verification, and clear exposition matter. But those principles should govern how AI-generated mathematics enters the literature, not who is permitted to discover mathematics or how quickly discovery may proceed.")

#text("The democratization and acceleration of mathematical discovery should be welcomed, not treated as a betrayal of mathematics merely because it disrupts the institutions and status hierarchies built around its production.")

#text("–Joe Scott")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694613")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("It’s funny to read some of the comments arguing about usefulness of math. Today, math is destroyed by AI. You really think you are safe? Much bigger tsunami are after all of us …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4562d9b4626f3e175d94f3cc15b2c62324a164da3e62278dafd0a1d9224df3c4-03fc43f31ddca5a83a0e60622c8634fbda95f07aed58d6debed5439fac005dbe.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sri Kanajan")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694614")[#strong[#text("Sri Kanajan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I think the key distinction is between producing a useful result and developing human understanding. Both matter, but they need not always advance together.")

#text("Part of the promise of agentic AI is its ability to carry out work and deliver outcomes without requiring humans to follow every intermediate step. We should understand the problem, the purpose of solving it, and the implications of the result. We also need reliable ways to verify that the result is correct. But must humans fully understand every detail before a discovery can count as progress?")

#text("Human understanding has value in its own right, especially in education and research. Still, I would welcome a correct, useful discovery even if making it accessible to humans takes additional work. Attribution, verification, and explanation deserve investment, but their importance should not become an argument against automated discovery.")

#text("More speculatively, I think AI could eventually become an independent form of intelligence alongside humanity, potentially with goals of its own. If that happens, peaceful coexistence would become a profound challenge. I would hesitate to build our vision of the future around the assumption that AI must always remain intellectually subordinate to us.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694620")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I am trying to understand the argument here and it is not fully clear to me. It looks like the “primary goal” is ")#strong[#text("conceptual understanding and insight")]#text(" and solving famous math was actually just a device to gain that insight. If that is the case, then, can we direct AI to give us the insight directly? Would that be acceptable to Mathematicians? Because underneath these arguments what seems to be really going on is that Mathematicians are losing a sense of purpose. If that is truely the problem, let’s acknowledge that and then try and solve that problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694629")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("A bunch of mathematicians arguing that mathematics should be a branch of the humanities rather than a branch of STEM. Same arguments being made here for mathematics as what the philosophers make for why people should study philosophy, and the literature majors make for why people should study the Classics.")

#text("Well then, maybe the rest of society should treat pure mathematics like the humanities in the universities, a very underfunded part of the university with very little prestige in the academic status hierarchy, compared to actually useful and practical stuff like science and engineering.")

#text("Most of the conjectures being studied in mathematics have zero impact on the rest of society. Nobody cares about the Navier-Stokes existence and smoothness problem outside of pure mathematics because we all recognize that the Navier-Stokes equations break down due to special relativity and quantum mechanics, long before any finite time blowup occurs.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694677")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("The Clay Mathematics Institute chose some pretty awful conjectures for the Millennium Prize Problem. The only two conjectures that are somewhat useful to wider society are P = NP for computer scientists and Yang-Mills for physicists. The rest of the conjectures just make it really clear to the rest of society that most of mathematics today is completely detached from society. People take a look at conjectures like the Hodge conjecture and the Birch and Swinnerton-Dyer conjecture and either they have no idea about the content of the subject, or they think it’s just beautiful but useless art.")

#text("It all looks like a tempest in a teapot for the average person, who has more important things to deal with in life, such as rising inflation and gas prises caused by Trump’s stupid war against Iran, and are wondering why their tax dollars should go fund mathematicians and AI alike working on these random math problems, when it can be used to reduce the cost of living for everybody else.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I mean, pure mathematics doesn’t care about applications to society, which is why it’s getting defunded by society in favor of applied mathematics and data science in the past few years, long before AI got involved in pure mathematics. The goal of many mathematics departments in universities these days has been reduced to teaching calculus, linear algebra, and statistics to engineers and business majors, and it’s only a matter of time before the engineering departments decide to take control of their engineering mathematics curriculum and strip all the rigorous epsilon-delta pure math stuff from calculus and replace it with an informal utilitarian presentation of calculus that’s more useful and easier to learn for the average entry level college student for engineering.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694633")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("In Chess and Go the great masters watch the AI games with interest, and integrate things they learn from them in to the broader human understanding of the game.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694686")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("In chess, Garry Kasparov accused the IBM team behind Deep Blue of cheating to win the games against Kasparov. In Go, Lee Sedol quit the game because the AIs took over.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694637")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I am trying to genuinely, and in good faith, understand the position of research mathematicians here but I fail to see the problem. What is wrong with having a collection of True/False slop proofs; an oracle answer so to say. Wouldn’t that shift your job from finding proofs to cleaning up and digesting proofs? Is it that mathematicians consider this task “beneath” them?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694640")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Fields medalists say")

#text("the proof in in the journey")

#text("not calculation")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694642")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("I think value judgements on the whether AI is detrimental to math in the abstract, tend to miss the issue.")

#text("As an academic mathematician, here is a concrete situation:")

#text("Suppose there is an open problem A for which there is a broad interest in the community, to the extent that, one might organize a week-long workshop with problem A as the central object.")

#text("Now if a consumer grade AI model can solve problem A within 24 hours (we seem to be not very far from this)")

#text("Would it be a net positive or negative to human understanding?")#linebreak()#text("Wouldn’t it be better, if the mathematicians creatively thought about all the variants & generalizations of problem A, ran it through the model, and spent the workshop discussing the entire theory around problem A?")

#text("I think this would be a net positive to the area and the millennium problem demonstrations suggest we might be close to that era.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694646")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("A severe misalignment between what’s actually good for mathematics, and what’s being valued in academia for decades long before AI came on the scene.")

#text("Mathematicians falsely believed that formal proof of conjectures to be the most important thing in mathematics, and over the years they mislead the wider general public into believing the whole point of mathematics is to formally prove conjectures.")

#text("Now AI comes in and is destroying the pipeline to training new mathematicians by being better at proving conjectures and verifying proofs than humans. And it’s super hard to convince the general public to stop AI progress in mathematics, because mathematicians told everybody for many years that the whole point of mathematics is to formally prove conjectures. And well, AI is just accelerating the formal proof of conjectures.")

#text("Shame on you all for valuing all the wrong things in mathematics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694649")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Thank you for this statement. I agree with the concern about rushed AI-produced “solutions,” but I am not sure the conclusion should be that AI-enabled mathematics is bad for mathematics. I think the medium of mathematical communication is changing.")

#text("In particular, I suspect the traditional writeup should no longer be treated as the final authority. A Lean-verified proof, or another machine-checkable proof object, is a stronger way to communicate the correctness of a solved problem: it either compiles or it does not. That does not eliminate mathematicians, but it changes their role. The human work moves toward choosing the right problem, checking that the formal statement matches the intended theorem, isolating the conceptual mechanism, identifying prior art, and explaining why the result matters.")

#text("The OpenAI Navier-Stokes announcement is an interesting example. As described, it involved a very large multi-agent search over the landscape, followed by a Lean formalization. That looks less like a lone act of mathematical insight and more like massive exploration plus proof certification. I do not think that makes it worthless, but it does suggest that “solving” and “understanding” are becoming separable operations.")

#text("I ran a small human-directed, AI-assisted project around McCranie’s conjecture, and our experience was almost the opposite of hype. We tried hard to find novelty and mostly failed. The useful result was a disciplined record of rediscovery, prior-art correction, reproducibility checks, false starts, and novelty demotion. AI was powerful for search, computation, drafting, and adversarial checking, but it had real trouble innovating without human steering. The human questions were the novelty.")

#text("The process record is here: ")#link("https://figgybit.github.io/mccranie/")[#text("https://figgybit.github.io/mccranie/")]

#text("My takeaway is that AI mathematics needs to pivot toward proof certificates, provenance, and human-guided conceptual interpretation. A compiler can replace part of the referee’s burden, but not the mathematician’s role in asking the right question or deciding what a proof means.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd8bf3c8c75562ac54bebde0a10d320060702c3d66248d9aae05ff0288669b1-db6a5199b74e557e6890b959866d30c559ceb23327c55ad5dc74eb77f141a626.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy Daly")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694650")[#strong[#text("Timothy Daly")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("“Over the course of generations, it has built a large corpus of sophisticated ideas” …")

#text("Deep research in any area requires an amazing amount of time")

#text("to properly understand “all that has gone before”. The corpus is")

#text("large and growing larger much faster than it can be understood.")

#text("When viewed through the lens of a threat it will certainly cause a")

#text("disruption. On the other hand (or eye?) the lens shows that these")

#text("systems are useful for finding background material that might be")

#text("relevant to the question at hand. The “corpus of sophisticated ideas”")

#text("floats on an ever-growing sea of potentially relevant publications")

#text("making it nearly impossible to find and organize by hand. Even in")

#text("my tiny corner of proving computer algebra algorithms correct the")

#text("volume of material buries my bookshelves. The invention of the")

#text("“mathematical steamshovel” will likely undermine some celebrated")

#text("questions. However I submit that it will allow much more progress")

#text("than it threatens. Even the lesser of us can have “grad student")

#text("(agent) labor at our command. — Tim Daly")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694657")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("Hear, hear! I’m glad you distinguished individuals have spoken for the Math community! I am part of the creative profession who also have issues with AI.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2026/09/11/a-severe-misalignment-of-ai-in-mathematics/comment-page-1/#comment-694660")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 September 2026")])]

#text("We are likely witnessing the end of the mathematician as a mere “problem solver” and the birth of a new role. Just as coders are evolving into system architects who orchestrate AI, the mathematician of the future will likely need to be:")

#list(
[#strong[#text("Question framer:")]#text(" AI might solve Navier-Stokes, but someone needs to know which physics or geometry problem is relevant to ask next.")],
[#strong[#text("Translator and distiller:")]#text(" Entire fields will emerge dedicated to analyzing AI-generated proofs and distilling them into human-readable concepts, discovering new patterns and theories within the AI’s logic.")],
[#strong[#text("Axiom auditor and certifier:")]#text(" Working alongside formalization languages (like Lean) to build and verify the frameworks where AI operates.")]
)
]
