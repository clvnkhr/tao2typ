// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/
// Converted to Typst by tao2typ: "2026-10-14T16:37:30.119629+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The “bounded gaps between primes” Polymath project – a retrospective", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The “bounded gaps between primes” Polymath project – a retrospective")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 30 September 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/")[#text("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("The (presumably) final article arising from the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(" has now been uploaded to the arXiv as “")#link("http://arxiv.org/abs/1409.8361")[#text("The “bounded gaps between primes” Polymath project – a retrospective")]#text("“. This article, submitted to the ")#link("http://www.ems-ph.org/journals/journal.php?jrn=news")[#text("Newsletter of the European Mathematical Society")]#text(", consists of personal contributions from ten different participants (at varying levels of stage of career, and intensity of participation) on their own experiences with the project, and some thoughts as to what lessons to draw for any subsequent Polymath projects. (At present, I do not know of any such projects being proposed, but from recent experience I would imagine that some opportunity suitable for a Polymath approach will present itself at some point in the near future.)")

#text("This post will also serve as the latest (and probably last) of the Polymath8 threads (rolling over ")#link("https://terrytao.wordpress.com/2014/07/20/variants-of-the-selberg-sieve-and-bounded-intervals-containing-many-primes/")[#text("this previous post")]#text("), to wrap up any remaining discussion about any aspect of this project.")

#heading(level: 1)[#text("Comments (110)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-473852")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2016")])]

#text("Note that if ")#mi("Q, P = Q +2")#text(" are primes greater than ")#mi("3")#text(", it is easy to verify that ")#mi("Q = -1 (mod 3)")#text(" and ")#mi("P= Q+2 = 1(mod 3)")#text(", which implies your observation that ")#mi("Q-2")#text(" is divisible by ")#mi("3")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/600feb2c1b3645184117a90d2f5a0227582bb7b6a1b1146f5a49678f9c64132b-1af16243d5d695376ad810f0ba33ef8c52c8d0cd0d039dba54677a1e9248c7a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sultan M.")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-473893")[#strong[#text("Sultan M.")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2016")])]

#text("I am very thankful for your clear explaination")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-515694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2019")])]

#text("As this project has been inactive for many years it is perhaps unlikely that too many of the former participants are still following this thread. Nevertheless, this seems like the right place to make a small announcement: I have been informed that the Polymath8b paper “Variants of the Selberg Sieve, and bounded intervals containing many primes” ")#link("https://link.springer.com/article/10.1186/s40687-014-0012-7")[#text("published in Research in the Mathematical Sciences")]#text(" was just selected for the inaugural “Best Paper Award” by that journal (an official announcement of this shall be made shortly). This award comes with a modest cash prize ($500) which obviously cannot be accepted by the pseudonymic DHJ Polymath. However, they can donate this prize to some charitable cause instead. The editor at RMS handling the paper, Ken Ono, suggested donating to the AMS “")#link("http://www.ams.org/programs/students/wwtbam/wwtbam")[#text("Who wants to be a mathematician?")]#text("” contest; other suggestions are welcome.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c4e6eedfb5a83ec41e37056f0d97f3d3ca44e4fbab5e7916bc6f537ce7758fc-6f6d9683c4eea1a2cc9006791c56eaf659f1f426fa2df727faa455f5abb46bb7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robert Silverman Silverman")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-515703")[#strong[#text("Robert Silverman Silverman")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2019")])]

#text("What about the Number Theory Foundation? Established by John Selfridge, I believe.")

#text("Number Theory Foundation")#linebreak()#text(" Department of Mathematics")#linebreak()#text(" Dartmouth College")#linebreak()#text(" Hanover, NH 03755")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dec3dfe912f0f9610dca1fd2e42293c5b0b1e95850187b2f0f4b272220a9bc1-1769e7e563f28db536d3e62685c13faceb09cade4dfc67510b85517e70dc6e59.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-515705")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2019")])]

#text("I think this is a good idea. The number theory foundation is likely to support the kind of mathematics that was related to this Polymath project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-515876")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2019")])]

#text("This sounds like a very appropriate use of the funds, especially since the NTF nowadays is ")#link("https://math.illinois.edu/research/faculty-research/number-theory/number-theory-foundation")[#text("primarily sponsoring")]#text(" a best paper award of its own (the Selfridge prize). I will let RMS know that this is where we would like the prize funds to be directed.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-540139")[#strong[#text("Failing fast and failing forward - Back-to-Front Maths | Kennedy PressBack-to-Front Maths | Kennedy Press")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2020")]

#text("[…] [3] ")#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrosp&#8230")[#text("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrosp&#8230")]#text("; […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-554428")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2020")])]

#text("This is a quick update for anyone still interested in the Polymath8 admissible tuples database, which stores the best upper bounds on H(k) we have for k up to 5000, along with an admissible tuple that achieves this bound. The company that was hosting this database was recently acquired and the new owner no longer offers a zero-cost hosting option. I moved the database to a static DataTable that you can browse and search at ")#link("https://math.mit.edu/~primegaps")[#text("https://math.mit.edu/~primegaps")]#text(" (JavaScript required).")

#text("Using static tables means we can no longer easily accept online submissions, but if anyone manages to improve a tuple, feel free to email me and I can update the database manually.")

#text("p.s. On an unrelated note, I am happy to report that the Number Theory Foundation is back in business. The link Terry posted on 7 May 2019 used to lead to a notice that the NTF planned to fund only the Selfridge Prize going forward, but this is no longer true; if you click on the link in Terry’s Post you will find yourself redirected to our new web site.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0e5271b2781e56ef767ea3e4dc78e6113a2b735e2cea985d1b41f206c62133f-71609775799bcb3d7f78708acbec1e313deef87635579bc71dd2b94693ec5f04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Paul Barnett")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-2/#comment-657789")[#strong[#text("Paul Barnett")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2022")])]

#text("It seems that all of this work is based on the sieve of Eratosthenes. Could we combine this by doing the same work on another sieve? For example using a multiplication grid where {primes}={integers}-{grid numbers-repeats}")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of crust")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-425295")[#strong[#text("crust")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2014")])]

#text("typo on p. 4:")

#text("but (0, 2, 4) was not -> but (0, 2, 4) is not")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b68955b06b58e54bef8a91a65aa3950472e80a10d40ba7116a38e4049e174c7e-7aba43b5eabeb579cd618e1526385d3ba515607f26dc07ef4f4dd400360c3d45.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of crust")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-425342")[#strong[#text("crust")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2014")])]

#text("p.5: peak -> peek")#linebreak()#text(" p.11: didnt -> didn’t")#linebreak()#text(" p.11: participants some -> participants; some")#linebreak()#text(" p.11: Much if the -> Much of the")#linebreak()#text(" p.11: compelling there -> compelling; there")#linebreak()#text(" p.12: felt as I needed -> felt as if I needed (or: felt I needed)")#linebreak()#text(" p.12: and shortly after -> and shortly thereafter")#linebreak()#text(" p.16: was written-up -> was written up")#linebreak()#text(" p.17: anybody to bring its -> anybody to bring their")#linebreak()#text(" p.17: participation to -> participation in")

#text("A fascinating read.")

#emph[#text("[Thanks, this will be corrected in the next revision of the ms – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0cb0330bec14e969fdc9e63e8988a0e409e7b1f883eac6de1a1c336f4e8ce900-ce8c9d08d3ee0c23c4d39c17f434c0d46387238e57836a070daa5521e35f1d3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of hm")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-425443")[#strong[#text("hm")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2014")])]

#text("A great read indeed. So basically a polymath project, to be successful, seems to require a blog owner knowledgeable in at least parts of the background material AND ready to shelve other projects. And it seems all participants have greatly benefited from it in various ways. I hope these successes will lead to more high quality blogs come to life and attempt other projects.")

#text("A few topics I can’t resist mentionning: the Hadwiger-Nelson problem, and the Jacobian conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-426113")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2014")])]

#text("P. 2, l. -6: “")#mi("70000000")#text("” –> “")#mi("70\\,000\\,000")#text("”")#linebreak()#text(" P. 3, l. 2: “")#mi("63, 374, 611")#text("” –> “")#mi("63\\,374\\,611")#text("”")#linebreak()#text(" P. 3, l. 4: “")#mi("59, 874, 594")#text("” –> “")#mi("59\\,874\\,594")#text("”")#linebreak()#text(" P. 3, l. 6: “")#mi("59, 470, 640")#text("” –> “")#mi("59\\,470\\,640")#text("”")

#emph[#text("[Thanks, this will be corrected in the revised version of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-426125")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2014")])]

#text("P. 15, l. 17: “often works…)” –> “often works).” [two things]")#linebreak()#text(" P. 15, l. -7: “Ph. Michel and” –> “P. Michel, and” [two things]")#linebreak()#text(" P. 15, l. -4: “Michel and I” –> “Michel, and I”")#linebreak()#text(" P. 16, l. 1, 6: “Ph. Michel’s” –> “P. Michel’s” [two places]")#linebreak()#text(" P. 16, l. 1: “Summer” –> “summer of” [two things]")#linebreak()#text(" P: 16, l. -9: “me –my” –> “me — my”")#linebreak()#text(" P: 16, l. -7: “Deshouillers-Iwaniec– but” –> “Deshouillers-Iwaniec — but”")#linebreak()#text(" P: 16, l. -4: “theory – the” –> “theory — the”")#linebreak()#text(" P: 16, l. -3: “progressions – due” –> “progressions — due”")#linebreak()#text(" P. 17, l. 13: “ “type III sums” ” –> “ “type III” sums ”")

#emph[#text("[Thanks, this will be corrected in the revised version of the ms. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59a55408d26b13e212198b0774c823b811caf27aec4aeb44ae20f5d7944aca64-68fad027bd214c09756241c77e2cc6676463ebece9338fc53fad8e10dcf3167f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Irkutsk")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-426407")[#strong[#text("Irkutsk")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2014")])]

#text("p. 7: “computationaly” -> “computationally”")

#emph[#text("[Thanks, this will be added to the next revision of the ms -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-427244")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2014")])]

#text("In Polymath8b paper (page 16), it seems that “")#mi("J_{i, \\varepsilon}(F)")#text("” (in theorem 3.14 statement) should be “")#mi("J_{i, 1-\\varepsilon}(F)")#text("” (according to its definition in theorem 3.12).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-427401")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2014")])]

#text("In Polymath8b paper (page 62), in the fourth line above (133) “polynomials ")#mi("P_i")#text("” should be “polyhedra ")#mi("P_i")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-427417")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2014")])]

#text("In Polymath8b paper (page 64), in the definitions of ")#mi("I(F)")#text(" for the polytopes ")#mi("S_{xyz}, U_{xyz}")#text(", their integrands should be squared (i.e. ")#mi("F^2")#text(" instead of ")#mi("F")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-427437")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2014")])]

#text("In Polymath8b paper (page 65), in the second line below the diagram it seems clearer to delete “each of” (which is somewhat confusing – as may incorrectly be interpreted that each region has 8 integrals).")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-427450")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2014")])]

#text("In this page it also seems clearer to replace")#linebreak()#text(" “")#mi("J = 2(J_1 + ... +J_8)")#text("” (with still undefined meaning) by “")#mi("J(F)  = 6(J_1+ ... +J_8)")#text("” – which is the expression for ")#mi("J(F)")#text(" in the previous page.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-427656")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2014")])]

#text("The expression “")#mi("J(F) = 2(J_1 + ... + J_8)")#text("” should be")#linebreak()#text(" “")#mi("J(F) = 6(J_1 + ... +J_8)")#text("” – in accordance with the expression for ")#mi("J(F)")#text(" in page 64.")

#text("The correct expression is implemented (as “")#mi("J_{sum}")#text("“) in the code in “Notes on polytope decomposition”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-428223")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2014")])]

#text("Just heard back from Andrew Granville on the 8a submission. The referees had two final comments on the last revision, one concerning the trace weight section of the paper, and the other concerning the amount of power savings needed for exponential sums. I vaguely recall that any non-trivial amount of power savings would be sufficient to get non-trivial Type I/II sums in the range needed (M,N between ")#mi("x^{1/3}")#text(" and ")#mi("x^{2/3}")#text(", if one wishes to avoid all use of Type III sums), after a sufficient number of applications of q-van der Corput, but I’ll double check this and make the remark more detailed accordingly. Meanwhile, if someone (Emmanuel or Phillippe?) could check the other referee point, that would be great.")

#text("—")

#text("In Remark 4.3 they still write that they just need a power saving on one-variable exponential sums to get non-trivial estimates, whereas you wrote they need more than p^{1/4} saving. I asked in the referee report whether that remark was correct, and since they didn’t change anything I guess they are sure about it.")#linebreak()#text(" It does make sense to me (they only lose logarithmic factors except when they apply Poisson summation — then they lose a power of x the exponent of which tends to 0 with varpi and delta). But it would be desirable to provide more details, such as references to specific points in the argument, for otherwise the remark may be more confusing than helpful.")

#text("– (what is now) remark 6.2: In the 1st paragraph, F has to be a middle extension sheaf. In the second one, it should say “generically pure” instead of “punctually pure”")#linebreak()#text(" – Theorem 6.5: “where (…) denotes the Tate-twisted coinvariant space” is wrong, it is just the coinvariant space. If it were Tate-twisted, you wouldn’t need to multiply the trace by q.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-429521")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2014")])]

#text("I’ve just sent the revised version of 8a back to ANT.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-428661")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2014")])]

#text("In Polymath8b paper (page 20), the proof of theorem 3.6(i) may be slightly simplified by replacing the asymptotic inequality on ")#mi("[d_1,  d^{\\prime}_1]  /cdots [d_k, d^{\\prime}_k]")#text(" (in the fourth line above section 4.2) by the explicit (and stronger) inequality")

#mi("\\prod_{i=1}^k (d_i d^{\\prime}_i) \\leq x^{1-\\varepsilon}")

#text("(which follows directly from (27)).")

#text("And also replacing “")#mi("[d_1, d^{\\prime}_1] \\cdots [d_k, d^{\\prime}_k]")#text("” in the third line above section 4.2, by “")#mi("\\prod_{i=1}^k (d_i d^{\\prime}_i)")#text("“.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-429869")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2014")])]

#text("In Polymath8b paper, it seems from the proof of theorem 3.5(i) that the strict inequality in (23) can be relaxed to “")#mi("\\leq \\vartheta")#text("” (since (23) is used in the proof only to bound ")#mi("q")#text(" by ")#mi("x^{\\vartheta + o(1)}")#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-430059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2014")])]

#text("Retropspective article:")

#text("P. 8, l. 19: “")#mi("1.951, ...)")#text("” –> “")#mi("1.951, \\dots)")#text("”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-430329")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2014")])]

#text("In Polymath8b paper (page 34), in the second line below (80), it seems clearer to insert “on ")#mi("[0, \\infty)^k")#text("” after “express ")#mi("f_3")#text("” (because the restriction of ")#mi("f_3")#text(" to ")#mi("[0, \\infty]^k")#text(" is compactly supported – and therefore can be represented as the uniform limit of the compactly supported functions in (81), but not(!) ")#mi("f_3")#text(" itself – which is not necessarily compactly supported.)")

#text("Similarly, in the ninth line below (81), it is clearer to insert “on ")#mi("[0, \\infty]^k")#text("” after “can be expressed”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-431904")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2014")])]

#text("In Polymath8b paper (page 59), the numerical upper bounds in table 3 should be rounded up (i.e. increased by ")#mi("10^{-5}")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433253")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("A small application of the Polymath8b methods: assuming GEH, we can get infinitely many pairs n,m of products of exactly two primes that differ by at most 2 (a ")#link("http://arxiv.org/abs/math/0609615")[#text("previous paper of Goldston, Graham, Pintz, and Yildirim")]#text(" obtained a bound of 6 unconditionally). The proof uses the admissible tuple ")#mi("(3n+1, 3n+2, 2n+1)")#text(" of affine-linear forms, and the results in 8b show that there are infinitely many tuples for which at least two of the elements are prime, which implies that two of ")#mi("6n+2, 6n+3, 6n+4")#text(" are products of exactly two primes, giving the claim.")

#text("I think this is the limit of the method, that is to say one should not be able to use the method to find products of two primes that differ by exactly one, although I don’t have a formal parity problem obstruction to back up this assertion. (Of course, one of these products will be twice a prime.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433283")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("I must be missing something really obvious here, for which I apologise in advance, but surely at most one of 6n+2 and 6n+4 can be a multiple of two primes, since one of them must be a multiple of 4? Doesn’t that lead to the stronger claim? – i.e. there are infinitely many n for which either both 6n+2 and 6n+3 are multiples of two primes or both 6n+3 and 6n+4 are?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("Oops, that was silly of me – the tuple is in fact not admissible after all, since one of ")#mi("3n+1")#text(" and ")#mi("3n+2")#text(" is always even. But if one uses the tuple ")#mi("(6n+1, 10n+1, 15n+2)")#text(" instead, this is now admissible and one can use ")#mi("(30n+3, 30n+4, 30n+5)")#text(" to get the products of two primes within 2 of each other.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433299")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("Whew :-)")

#text("Very nice result. Can your method prove corresponding bounds for three (etc) products of two primes? Or for products of three (etc) primes?")

#text("Also, is there hope for a milder strengthening in which the difference is exactly 2 rather than at most 2?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433306")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("Well, since we can get ")#mi("m")#text(" primes in an interval of length ")#mi("H_m")#text(", we can certainly get ")#mi("m")#text(" semiprimes (products of exactly two primes) in an interval of length ")#mi("2H_m")#text(", simply by doubling all the primes in the former interval. One can probably do better than this crude estimate by choosing k-tuples more cleverly, or by arguing as in the GGPY paper and directly counting the density of semiprimes rather than the density of primes in the GPY sieve. But of course the interval is not going to be as small as 2 any more.")

#text("I think one can get products of k-primes within 2 apart on GEH by the same method, e.g. one can find infinitely many n such that two of ")#mi("(6n+1)/7, (10n+11)/11, (15n+12)/13")#text(" are prime (this requires ")#mi("n")#text(" to be in a certain residue class mod ")#mi("7 \\times 11 \\times 13")#text(", as per the Chinese remainder theorem, to make these three quantities all integers), and then two of ")#mi("30n+3, 30n+4, 30n+5")#text(" will be the product of exactly three primes.")

#text("Getting semiprimes exactly two apart is unfortunately about the same difficulty as the twin prime conjecture (see ")#link("http://www.ams.org/mathscinet-getitem?mr=396435")[#text("this paper of Bombieri")]#text(" for a linkage between the two problems assuming EH). Actually there is a loophole: Bombieri shows that getting the _conjectured asymptotic_ for twin primes is equivalent to getting the conjectured asymptotic for twin semiprimes, assuming EH (and normalising the semiprimes by ")#mi("\\Lambda * \\Lambda")#text(", actually for this claim I think one needs GEH rather than EH). It might be possible though to exhibit a very thin set of twin semiprimes without necessarily having any implications for twin primes. For instance, if there are only finitely many twin semiprimes, then the prime tuples conjecture fails for an infinite family of pairs of linear forms, namely the forms ")#mi("cpn+a, cqn+b")#text(" with ")#mi("p,q")#text(" prime and ")#mi("pb-qa=2")#text("; each such instance of the tuples conjecture corresponds to a sparse set of potential twin semiprimes. Unfortunately, it doesn’t look like the GPY method forces the tuples conjecture to hold for at least one of these pairs, but perhaps a future method could do something like this, even if it falls short of forcing the tuples conjecture for a specific pair such as ")#mi("n,n+2")#text(". (For instance, if the graph connecting linear forms together by connecting ")#mi("cpn+a")#text(" with ")#mi("cqn+b")#text(" whenever ")#mi("p,q")#text(" prime and ")#mi("pb-qa=2")#text(" contains an odd cycle, then there is hope. Maybe if one replaces semiprimes by products of exactly k primes for some large k then there is a better chance of success.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433315")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("OK, thinking about it more, I have an ")#emph[#text("approach")]#text(" to proving the claim “there exist infinitely many semiprimes that differ by exactly 12” on GEH that doesn’t obviously violate the parity obstruction. However, it doesn’t follow directly from the polymath8b sieve, but requires another sieve with a certain property, and one would have to hunt numerically for such a sieve similar to how we had to work for many weeks to find the sieve that gave ")#mi("H_1 \\leq 6")#text(". I can replace ")#mi("12")#text(" by any multiple of ")#mi("12")#text(", but in order to keep admissibility mod 2 and 3 I was not able to make the argument below work for just 2, i.e. I don’t have a route to twin semiprimes this way.")

#text("The argument goes as this. Suppose for contradiction that semiprimes never differed by exactly 12. Now consider the admissible tuple ")#mi("n-6, n, n+6")#text(". If ")#mi("n")#text(" is prime, then ")#mi("n+6")#text(" cannot be prime, otherwise ")#mi("2n")#text(" and ")#mi("2n+12")#text(" would be semiprimes differing by exactly 12. Similarly, if ")#mi("n")#text(" is prime, then ")#mi("n-6")#text(" cannot be prime. Also, ")#mi("n+6")#text(" and ")#mi("n-6")#text(" cannot both be semiprime. We conclude that if ")#mi("n")#text(" is prime, then at least one of ")#mi("n - 6")#text(" or ")#mi("n+6")#text(" has to have at least three prime factors counting multiplicity, i.e. ")#mi("\\Omega(n+6) \\geq 3")#text(" or ")#mi("\\Omega(n-6) \\geq 3")#text(". So if we can find a sieve ")#mi("\\nu(n)")#text(" on ")#mi("[x,2x]")#text(" such that")

#mi("\\sum_n \\nu(n) 1_{n \\text{ prime}} < \\sum_n \\nu(n) 1_{\\Omega(n+6) \\geq 3} + \\sum_n \\nu(n) 1_{\\Omega(n-6) \\geq 3}")

#text("then we win. Now the existence of such a sieve is not directly blocked by parity, because we are allowing ")#mi("n+6")#text(" and ")#mi("n-6")#text(" to both have an even or odd number of prime factors. However, one still needs to construct ")#mi("\\nu")#text(". In principle one could use the polymath8b calculations to write down an explicit inequality involving a three-dimensional smooth functions F with various support and marginal constraints that one would have to find a solution to, but it's going to be a bit messy.")

#text("Perhaps more feasible is to show the existence of some explicit ")#mi("k, h")#text(" for which one can show (on GEH) that there are infinitely many ")#mi("n")#text(" with ")#mi("\\Omega(n) = \\Omega(n+h) = k")#text(". (The above argument is aimed at ")#mi("k=2, h=12")#text(", but it may end up being better to consider larger values of ")#mi("h,k")#text(".) Of course, \"explicit\" is key: we know for instance that the above assertion is true for at least one of ")#mi("(k,h) = (2,1), (2,2)")#text(" from my previous blog comment, but we don't know which.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433318")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2014")])]

#text("Actually, ")#mi("(k,h) = (3,60)")#text(" works, i.e. one can find infinitely many pairs of products of three primes that differ by exactly 60. We start with the admissible tuple ")#mi("n, n+4, n+10")#text(" and conclude that we can find infinitely many n such that two of ")#mi("n, n+4, n+10")#text(" are prime. If ")#mi("n,n+4")#text(" are prime then ")#mi("\\Omega(15n) = \\Omega(15n+60) = 3")#text(". If ")#mi("n,n+10")#text(" are prime then ")#mi("\\Omega(6n) = \\Omega(6n+60)=3")#text(". If ")#mi("n+4,n+10")#text(" are prime then ")#mi("\\Omega(10n+40) = \\Omega(10n+40+60)=3")#text(".")

#text("It may be possible to find a smaller pair than (3,60) by some variant of this method.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433483")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("According to the wikipedia article “Chen Prime” is a prime ")#mi("p")#text(" such that ")#mi("p+2")#text(" is either a prime or a product of two primes. Chen proved (in 1966) that there are infinitely many such primes.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433439")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("using ")#mi("8n+1,9n+1,12n+1")#text(" gives consecutive products of exactly two primes differing by 1.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Maynard")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433441")[#strong[#text("James Maynard")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Sorry, this is rubbish – please ignore!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433467")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("In addition to seeking smaller (k,h) for which (on GEH) there are infinitely many products of exactly k primes differing by exactly h, am I right in saying that the question h=1, k at most 2 [apologies for my capitulation on getting WordPress to treat angle brackets nicely] is still open? In other words, does GEH imply that there are infinitely many pairs (n,n+1) of which one is twice a prime and the other is either a prime or a semiprime? After playing with the case h=1, k=2 for a while I am reasonably convinced that it indeed suffers a parity obstruction, though I can’t crystallise it – Terry, could you possibly outline the basis for your original pessimism on that point? – but the case h=1, k at most 2 intuitively seems like it might be freer of such issues.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433471")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Ah, indeed this seems to be easy: using the tuple (n, 2n+1, 3n+2) we get the consecutive prime-or-semiprime pairs (2n+1, 2n+2) or (3n+2, 3n+3) or (6n+3, 6n+4) depending on which members of the tuple are prime.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433475")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("Gah – what James said…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433477")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2014")])]

#text("A slight modification of ")#link("http://en.wikipedia.org/wiki/Chen's_theorem")[#text("Chen’s theorem")]#text(" will produce infinitely many primes ")#mi("p")#text(" such that ")#mi("2p+1")#text(" is either a prime or a semiprime.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434198")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("If ")#mi("2p+1")#text(" is also prime, than ")#mi("p")#text(" is a “Sophie Germain prime” (it is conjectured that there are infinitely many such primes.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434193")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("While I haven’t been able to improve the ")#mi("k=3")#text(" gap, surprisingly I can improve ")#mi("h")#text(" by increasing ")#mi("k")#text(" to get ")#mi("(k,h)=(4,30)")#text(". Use the admissible 3-tuple ")#mi("2n+1,5n+1,7n+1")#text(".")

#text("For instance, if ")#mi("2n+1,5n+1")#text(" are simultaneously prime, then multiply the first by ")#mi("2\\cdot 5\\cdot 5")#text(" and the second by ")#mi("2\\cdot 2\\cdot 5")#text(" to get ")#mi("100n+50,100n+20")#text(" are both products of 4 primes. Similarly if ")#mi("2n+1,7n+1")#text(" are both prime, multiply the first by ")#mi("2\\cdot 3\\cdot 7")#text(" and the second by ")#mi("2\\cdot 2\\cdot 3")#text(" to get ")#mi("84n+42,84n+12")#text(" are both products of 4 primes. I’ll leave the last case for readers to work out.")

#text("On a slightly different track, would people find it interesting to construct an explicit pair ")#mi("(k,h)")#text(" that holds without GEH? If so I could give it some thought. (This would involve finding an appropriate admissible 246-tuple, which might be out of reach. But it may be interesting to see how close we can get.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434194")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("Nice! I’d certainly be interested. Maybe start with the EH case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434207")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("The EH case isn’t too bad. If I didn’t make any mistakes, I believe the admissible 4-tuple ")#mi("n,n+12,n+30,n+42")#text(" will work to give ")#mi("(k,h)=(4,1260)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434234")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("Unfortunately for EH we need to take admissible 5-tuples rather than 4-tuples (because we can only use ")#mi("M_k")#text(" technology if GEH is not available, and we only have ")#mi("M_k > 2")#text(" for ")#mi("k \\geq 5")#text(").")

#text("Without GEH or EH, we need to work with admissible 50-tuples.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434251")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("Oh, for the 246 vs. 50, I was thinking of the smallest diameter! A 50-tuple is much more doable.")

#text("Here is an admissible 8-tuple: ")#mi("n+T*\\{0,8,20,28,438,610,41733,794055 \\}")#text(" (with ")#mi("T=2\\cdot 3\\cdot 5\\cdot 7")#text(" to get admissibility).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-433940")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2014")])]

#text("In Polymath8b paper (page 56), it seems clearer to insert in the second line above (125) “square-integrable symmetric” before “functions ")#mi("b_1, ... , b_n")#text("” (since (126) holds provided that these functions are square- integrable, and (127) holds provided that these functions are also symmetric.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434191")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("Is it possible (perhaps under RH) to transfere bounds on the spacing between consecutive primes to corresponding ones on the spacing between consecutive zeros of ")#mi("\\zeta (s)")#text(" on the critical line?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434236")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2014")])]

#text("I don’t think so, but ")#link("http://www.ams.org/mathscinet-getitem?mr=1018376")[#text("Goldston and Montgomery")]#text(" did show that the pair correlation conjecture (which basically governs spacings between consecutive zeroes, or more precisely differences between nearby (but not necessarily consecutive) zeroes) was equivalent to an assertion about the variance in the error term in the prime number theorem in short intervals ")#mi("[x, x+x^c]")#text(". James was able to use the bounded gaps between primes technology produce a sparse set of intervals ")#mi("[x,x+x^c]")#text(" with ")#mi("\\gg \\log x")#text(" primes for very small values of c, but this is well short of what is needed to get to the Goldston-Montgomery claim. Basically, the bounded gaps between primes machinery (a) produces a lower bound on primes in various sets, but this lower bound is well short of the conjectural truth, and (b) it only works for a fairly sparse set of configurations. On the other hand, the zeroes of the zeta function control asymptotics for primes (or products of primes) in generic intervals, and are not so sensitive to what happens in a sparse set of intervals.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434377")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("Thanks for the explanation!")

#text("So it seems that (in general), a claim about a (sufficiently) sparse set of primes can’t be simply reformulated by a corresponding equivalent claim on the zeros of the zeta function (i.e. the corresponding claim is generally weaker than the original one.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434375")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("I just realised that much of the above discussion was anticipated in ")#link("http://arxiv.org/abs/math/0609615")[#text("this paper of Goldston, Graham, Pintz, and Yildirim")]#text(" and ")#link("http://arxiv.org/abs/0803.2636")[#text("its followup")]#text(". In the first paper, GGPY establish unconditionally the analogue of DHL(3,2) for semiprimes: given any three admissible linear forms, one can find infinitely many values of n such that at least two of the forms are semiprime (product of exactly two primes). In the second paper, they use that to establish the ")#mi("(k,h) = (4,1)")#text(" claim. The idea is to find n such that two of ")#mi("\\Omega(4m+1)=3, \\Omega(5m+1)=2, \\Omega(6m+1)=3")#text(" hold, that is to say two of “4m+1 is the product of three primes”, “5m+1 is semiprime”, and “6m+1 is the product of three primes” hold. This can be accomplished for instance by first finding l such that two of 28l+3, 385l+41, 66l+7 are semiprime, and then setting m = 77l+8. (These odd looking forms arise from the Chinese remainder theorem, as discussed in Section 2 of the second GGPY paper.) Once one has the desired m, then one of the pairs (20m+4,20m+5), (12m+2,12m+3), (30m+5,30+6) will work.")

#text("On GEH, the same argument now gives ")#mi("(k,h)=(3,1)")#text(". In fact I would conjecture that a modification of the argument gives ")#mi("(3,h)")#text(" for any ")#mi("h")#text(", which would mean on GEH that every integer can be expressed in the form ")#mi("p_1 p_2 p_3 - p_4 p_5 p_6")#text(" for some primes ")#mi("p_1,p_2,p_3,p_4,p_5,p_6")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434385")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("I *think* I can get (k,h) = (2,12) on GEH by a modification of the proof of Chen’s theorem, but I have to double check the calculations which are a bit messy. Chen’s theorem tells us, for instance, that one can find infinitely primes p such that p+6 is almost prime (the product of at most two primes). Similarly for p+6 replaced by p-6. I think that if one assumes GEH, one can get the stronger assertion that there are infinitely many primes p such that p+6 and p-6 are ")#strong[#text("both")]#text(" almost prime. (Chen’s argument uses only the Bombieri-Vinogradov theorem, which heuristically is only “half as powerful” as GEH, so one should expect a result that is approximately “twice as strong” if one uses GEH.) If so, then by the argument from ")#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/#comment-433315")[#text("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/#comment-433315")]#text(" , one of the triplets (p-6,p+6), (2p, 2p+12), (2p-12, 2p) will be a pair of semiprimes differing by exactly 12.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434387")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("Unfortunately, the double-check revealed that my calculations were faulty (I had applied the upper and lower bounds for the linear sieve to what is now a two-dimensional sieve). It may not be as easy to obtain the claimed strengthening of Chen’s theorem on GEH after all.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434410")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("Now trying to modify Chen’s argument to produce infinitely many primes p such that (p+6)(p-6) has at most 4 prime factors, as this will also suffice. Calculations are a mess though.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434898")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2014")])]

#text("Just trying to make sure I understand what is known and what is open here, specifically in the unconditional setting (no EH or GEH). Am I right in saying that the following are known, where “(k,h)” means “infinitely many pairs [n,n+h] are both the product of exactly k primes”:")

#text("– (k,h) for all h, for all k at least 4")#linebreak()#text(" – (1,h) for all h that are the width of an admissible n-tuple, n at least 50")#linebreak()#text(" – (3,h) for selected h, of which the smallest is h=60")

#text("and that the following are open:")

#text("– (2,h) for all h, pending a report from Terry regarding his attack on (2,12)")#linebreak()#text(" – (3,h) for all h other than 60 and a few others that can be achieved using the same approach")

#text("Is this an accurate summary? I’m thinking that surely we know something about (2,h), since semiprimes are denser than primes, but I haven’t seen any specifics. Also, I’m somewhat confused about the weaker property “at least one pair [n,n+h] are both the product of exactly k primes”. For which [k,h], if any, is this known but the “infinitely many” case is not?")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434997")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2014")])]

#text("Unconditionally: the GGPY paper establishes (k,1) for all k at least 4, and it is likely that their method also gives (k,h) for all h and all k at least 4, although this has not been checked yet. By using an admissible 50-tuple, one should be able to get (3,h) for some enormous value of h, but this has not been worked out. I don’t think there are any results for (2,h) or (1,h) known unconditionally.")

#text("On GEH: the GGPY method gives (k,1) for all k at least 3, and it is likely that their method also gives (k,h) for all h and all k at least 3, although this has not been checked yet. This would supersede what Pace and I worked out, which was (3,60) and (4,30) respectively (and one can probably replace 60 or 30 by multiples thereof). I have an approach for (2,12) (and more generally (2,12m) for any m), but the sieve-theoretic calculations turned out to be quite nasty and I am no longer confident I can modify the Chen argument to work here. The Chen argument, when used for instance to find primes p with p+6 almost prime, relies on the inequality")

#mi("\\# \\{ p \\leq x-6: p+6 \\text{ almost prime}\\} \\geq \\# \\{ p \\leq x-6: p+6\\ z\\text{-rough} \\}")#linebreak()#text(" ")#mi("\\quad - \\frac{1}{2} \\sum_{z \\leq p_1 \\leq x^{1/3}} \\# \\{ p \\leq x-6: p+6 \\ z\\text{-rough}, p_1 | p+6 \\}")#linebreak()#text(" ")#mi("\\quad - \\frac{1}{2} \\sum_{z \\leq p_1 \\leq x^{1/3} < p_2 \\leq p_3} 1_{\\text{prime}, \\leq x-6}(p_1p_2p_3 - 6)")

#text("for some parameter z (e.g. ")#mi("z = x^{1/8}")#text("), where ")#mi("z")#text("-rough means \"no prime factor less than z\". This reflects the fact that if a number has at least three prime factors and is less than ")#mi("x")#text(", then either it has at least two factors less than or equal to ")#mi("x^{1/3}")#text(", or it has one factor less than or equal to ")#mi("x^{1/3}")#text(" and is of the form ")#mi("p_1p_2p_3")#text(" for some ")#mi("p_1 \\leq x^{1/3} < p_2 \\leq p_3")#text(". One then uses the linear sieve to lower bound the first term on the RHS and upper bound the other two terms. For the ")#mi("(p+6)(p-6)")#text(" term one has to use the quadratic sieve rather than the linear sieve, but the bounds here are significantly less favorable and it doesn't look like I'm going to get ")#mi("(p+6)(p-6)")#text(" to have as few as four prime factors with this method. (One may be able to get something like six or seven if one really tries, but this won't lead to any result for k=2.)")

#text("Finally, even on GEH there is no result of the form (1,h) known for any _specific_ value of h, as this is of comparable difficulty to the twin prime conjecture (which asserts (1,2)). Of course, from 8b we know that (1,h) is true for at least one of h=2, h=4, h=6, but we can't say which. (Using the tuple n,n+6,n+12 we can also say that one of (1,6) and (1,12) is true, but again we can't say which.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-435098")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2014")])]

#text("In the GGPY paper linked above, there seems to be a problem in the statement of Theorem 1. My guess is that the authors meant to say that only ")#mi("\\nu")#text(" of the forms are ")#mi("E_2")#text(" (rather than ")#mi("\\nu+1")#text(" of them), but this is only a guess.")

#text("Using the the theorem as stated, taking ")#mi("k=2, \\nu=1, \\vartheta=1/2, B:=2/\\vartheta=4")#text(" yields ")#mi("C_1(\\nu)=e^{1-\\gamma}=1.526...")#text(" which would get exact gaps of any even size between ")#mi("E_2")#text(" numbers!")

#text("This also seems to necessitate a change to the constant stated in Corollary 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-435116")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 November 2014")])]

#text("Oh, I see, it has to do with Footnote 2. The o(1) error here is with regards to the asymptotic limit ")#mi("\\nu \\to \\infty")#text(", and so the theorem gives no explicit value of ")#mi("k")#text(" for any fixed value of ")#mi("\\nu")#text(", such as ")#mi("\\nu=1")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-435183")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2014")])]

#text("Oh, good catch! I must have re-read those first few pages ten times, but never really looked at the footnote.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/900f331aaf0d8380d0b98bd41f31726d408d29bca595cafba6223a9f9b00ef10-ccfbe68fc7789fa8f614eb5f78c452a4e89d0562671ba12bcf82711b188e22ea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luq Malik")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434403")[#strong[#text("Luq Malik")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("Reblogged this on ")#link("http://luqmalik.wordpress.com/2014/10/31/the-bounded-gaps-between-primes-polymath-project-a-retrospective/")[#text("Luq Malik")]#text(" and commented:")#linebreak()#text(" If you haven’t been following the polymath Project, concerning “the bounded gaps between primes” and major implications about the Goldbach conjecture, you should get up to snuff immediately, as the results are piling up exponentially. Initiated by eminent mathematician and expositor Terence Tao, PMP exemplifies the extraordinary power of collaborative research.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434450")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("On a possible improvement in theorem 3.8:")

#text("In Polymath8b paper, in the proof of theorem 3.8 (page 35), the inequality (84) is somewhat stronger than required by theorem 3.5(i) (assumption (23)). Therefore, in order to exploit this slight inefficiency, suppose that in (84) (perhaps by using symmetry) it is possible to have also")

#mi("S(f_{1, j}) = ... = S(f_{k, j})")

#text("Than ")#mi("\\frac{\\vartheta}{2}")#text(" in (84) can be replaced by")

#mi("\\min (\\frac{k}{k-1} \\frac{\\vartheta}{2}, \\frac{1}{2})")

#text("Which implies that in (72) (and also in the key inequality assumption of theorem 3.8), ")#mi("\\vartheta")#text(" may be replaced by")#linebreak()#text(" ")#mi("\\min(\\frac{k}{k-1} \\vartheta , 1)")#text(".")

#text("To illustrate the improvement, we have for ")#mi("\\vartheta = 1/2")#text(" and ")#mi("m=1")#text(" the condition ")#mi("M_k > 4 - 4/k")#text(" which for ")#mi("k=50")#text(" is")#linebreak()#text(" ")#mi("M_{50} > 3.92")#text(" which is verified using the lower bound 3.93586 in Table 3 (page 59). This gives the current record for ")#mi("H_1")#text(" (without the epsilon enlargement!)")#linebreak()#text(" Moreover, for ")#mi("k=49")#text(" we have the condition")#linebreak()#text(" ")#mi("M_{49} > 4 - 4/49 = 3.918367...")#text(" which is almost(!) verified by the lower bound ")#mi("M_{49} \\geq 3.918281...")#text(" given by Ignace (in Table 2 of “Krylov method for lower bounding ")#mi("M_k")#text("“) – using polynomials up to degree 25. It seems that ")#mi("k=49")#text(" (a new record!) can be verified by increasing very slightly the maximal degree above 25.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434469")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2014")])]

#text("Yes, one can enlarge the simplex ")#mi("{\\mathcal R}_k = \\{ (t_1,\\dots,t_k): t_1 + \\dots + t_k \\leq 1 \\}")#text(" to ")#mi("{\\mathcal R}^{\\prime}_k = \\{ (t_1,\\dots,t_k): \\sum_{i \\neq i_0} t_i \\leq 1 \\text{ for all } i_0 \\}")#text(" from this observation, replacing ")#mi("M_k")#text(" by the quantity which I think we called ")#mi("M^{\\prime}_k")#text(". In principle ")#mi("M^{\\prime}_k")#text(" could be as large as ")#mi("\\frac{k}{k-1} M_k")#text(" but in practice it is smaller because we are not always in the ideal case ")#mi("S(f_{1,j}) = \\dots = S(f_{k,j})")#text(" (just because the function ")#mi("F")#text(" is symmetric, this does not mean that the various components of ")#mi("F")#text(" need to be symmetric). If I recall correctly, the problem with working with ")#mi("M^{\\prime}_k")#text(" in the medium dimensional setting k=49 or k=50 was that the integrals were just too hard to compute (and the Krylov method becomes complicated very quickly, with lots of piecewise polynomial functions flying around).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434593")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2014")])]

#text("I agree that ")#mi("F")#text(" should be supported on ")#mi("\\mathcal R^{\\prime}_k")#text(" Otherwise, it is not difficult to show that for any ")#mi("f_4")#text(" of the form (82) which is not(!) supported on ")#mi("(\\vartheta /2)\\mathcal R^{\\prime}_k")#text(", there is alway one (j-th) component for which (23) is not satisfied, i.e.")

#mi("\\sum_{i \\neq i_0} S(f_{i, j}) > \\vartheta /2")

#text("For some ")#mi("j")#text(" and ")#mi("i_0")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-435596")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 6 November 2014")])]

#text("More precisely, ")#mi("F")#text(" should be supported on the intersection of ")#mi("\\mathcal R^{\\prime}_k")#text(" and ")#mi("(1/ \\vartheta) \\mathcal R_k")#text(" – needed to apply (in the proof of theorem 3.8) both theorems 3.5(i) and 3.6(i).")

#text("It is easy to verify that this intersection is ")#mi("\\mathcal R^{\\prime}_k")#text(" whenever ")#mi("\\vartheta \\leq 1-1/k")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-434574")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2014")])]

#text("The Polymath8b paper is now published at ")#link("http://www.resmathsci.com/content/1/1/12")[#text("http://www.resmathsci.com/content/1/1/12")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-436203")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("In Polymath8b paper, in the proof of lemma 6.1 (page 42), the integrand ")#mi("F^2/G_i")#text(" is undefined (being “")#mi("\\frac {0}{0}")#text("“) for ")#mi("(t_1, ... , t_{i-1}, t{i+1}, ... , t_k) \\notin \\mathcal R_{k-1}")#text(". Therefore, in the fourth line of the proof, “")#mi("t_1, ... , t_{i-1}, t_{i+1}, ... , t_k \\geq 0")#text("” should be")#linebreak()#text(" “")#mi("(t_1, ... , t_{i-1}, t_{i+1}, ... ,t_k) \\in \\mathcal R_{k-1}")#text("“.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-436305")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2014")])]

#text("Now “??” appears (everywhere) instead of reference numbers.")

#emph[#text("[Fixed, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-437944")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2014")])]

#text("The Polymath8a paper is now accepted for publication at Algebra & Number Theory. I will go ahead and upload the final version of the paper source files to their web site.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-438192")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 November 2014")])]

#text("Nice. Will the latest version also be uploaded to arXiv?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-439243")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2014")])]

#text("I now have galley proofs for the retrospective article at ")#link("https://terrytao.files.wordpress.com/2014/11/nl94_proofs.pdf")[#text("https://terrytao.files.wordpress.com/2014/11/nl94_proofs.pdf")]#text(" .The EMS would like them back by the end of the week, so this is the last chance to have any corrections to them to be made in print.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-439371")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2014")])]

#text("The partial information (“to appear”) for Ref. [47] (Zhang’s paper) should be updated.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-439393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2014")])]

#text("Comments to the references:")

#text("[19], [20], [30], [38], [43]: Full stop missing at the end of the references.")#linebreak()#text(" [39]: En-dash instead of hyphen to indicate page range.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-444902")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2014")])]

#text("In Polymath8b paper (page 33), in the fourth line below (74), it seems that “")#mi("F_2")#text(" stays away” should be “")#mi("F_2")#text(" support stays away”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-444969")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2014")])]

#text("Galley proofs for the Polymath8a paper are now available at ")#link("http://ef.msp.org/articles/proofs/ant/140204-Polymath.pdf")[#text("http://ef.msp.org/articles/proofs/ant/140204-Polymath.pdf")]

#text("The corrections and queries look minor, and I think I can address them myself in a few days. This is the last chance to make any changes to the published version of 8a, so let me know if there are any such changes to make before returning the proofs by next week or so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-445009")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2014")])]

#text("In the last line of Lemma 3.4 (and probably in other places too) the ellipses should NOT be centered as the referee claims; see page 172 in The TeXbook.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-445076")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2014")])]

#text("For all the maps, \\colon should be used instead of : in order to get the correct spacing.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-448339")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2015")])]

#text("In Polymath8b paper, it seems that the proof of theorem 3.8 (in page 33) can be slightly simplified by constructing ")#mi("F_2")#text(" directly from ")#mi("F")#text(" by multiplying ")#mi("F")#text(" with the cutoff function ")#mi("1_R")#text(" (")#mi("R")#text(" can be chosen to be the region given by the third line below (74)).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-448595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2015")])]

#text("Polymath8a has now been published at ")#link("http://msp.org/ant/2014/8-9/index.xhtml")[#text("http://msp.org/ant/2014/8-9/index.xhtml")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-450839")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2015")])]

#text("The documentary “Counting from infinity”, about Yitang Zhang (and, tangentially, about Polymath8), produced with the support of MSRI and the Simons foundation, is now finished: ")#link("http://www.zalafilms.com/films/countingindex.html")[#text("http://www.zalafilms.com/films/countingindex.html")]#text(" .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-450854")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2015")])]

#text("Can the documentary be watch online for free (legally, of course) somewhere?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b83bbd7a94cc71811b9a9397d388196a23f245102dd6e58079aa3aafe289565-3625ba68bcc18dbb4c72ce2446178147350b5b6ed8a1bc90b78081688da4b407.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zhang Tan")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-450885")[#strong[#text("Zhang Tan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2015")])]

#text("2")

#text("n.2+1=3,5")

#text("n.2.3+1=7,13,19,25")#linebreak()#text(" n.2.3+5=11,17,23,29")

#text("n.2.3.5+1=31,61,91,121,151,181")#linebreak()#text(" n.2.3.5+7=37,67,97,127,157,187")#linebreak()#text(" n.2.3.5+11=41,71,101,131,161,191 row a")#linebreak()#text(" n.2.3.5+13=43,73,103,133,163,193 row b")#linebreak()#text(" n.2.3.5+17=47,77,107,137,167,197")#linebreak()#text(" n.2.3.5+19=49,79,109,139,169,199")#linebreak()#text(" n.2.3.5+23=53,83,113,143,173,203")#linebreak()#text(" n.2.3.5+29=59,89,119,149,179,209")

#text("This is a sieve to generate prime numbers")

#text("On the left hand side of = is the first nth prime numbers multiplied together added with a co-prime.")

#text("On the right hand side of = is all the possible co-primes generated for the next sieve and all possible prime numbers.")

#text("All non-prime numbers on the right hand side of = are made up of the co-primes to the first nth prime numbers multiplied together.")

#text("As you can see gaps of 2 between two prime numbers are possible.")

#text("Starting with the set n.2.3+1 and n.2.3+5 the probability of a pair of numbers which differ by 2 and does not have a factor of 5 is 3/5.")

#text("Starting with the set n.2.3+1 and n.2.3+5 the probability of a pair of numbers which differ by 2 and does not have a factor of 5 and 7 is 3/5 multiplied by 5/7.")

#text("Starting with the set n.2.3+1 and n.2.3+5 the probability of a pair of numbers which differ by 2 and does not have a factor of 5 and 7 and 11 is 3/5 multiplied by 5/7 multiplied by 9/11.")

#text("There must exist a twin prime in n.2.3+1 and n.2.3+5.")

#text("Start with the next set n.2.3.5+coprime the probability of a pair of numbers in row a and row b which differ by 2 and does not have a factor of 7 is 5/7.")

#text("Start with the next set n.2.3.5+coprime the probability of a pair of numbers in row a and row b which differ by 2 and does not have a factor of 7 and 11 is 5/7 multiplied by 9/11")

#text("There must exist a twin prime in n.2.3.5+11 and n.2.3.5+13.")

#text("Each n.2.3.5…. + coprime has a gap of 2 from the previous sieve.")

#text("I hope this clearifies the possibility of twin primes.")

#text("Regards")

#text("Zhang")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-450987")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2015")])]

#text("I would like to hear a new theory that will help to advance research on twin primes, and it will push forward to the effects on the theorem Gold Bach!:")#linebreak()#text(" Or I and J two intervals whose lengths are: n, m, then:")#linebreak()#text(" Limit [P (I) / P (J)] = n / m, where “n” tends to infinity")#linebreak()#text(" Since P ([a, b]) is the number of prime numbers contained in the interval [a, b]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-450990")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2015")])]

#text("Sorry sorry!, I repeat my new theory")#linebreak()#text(" If I and J is tow intervals: I = [a, a n], and J = [b, b + Kn]")#linebreak()#text(" Limit [P (J) / P (I)] = K, where “n” tends to infinity")#linebreak()#text(" Since P ([c, d]) is the number of prime numbers contained in the interval [c, d]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451088")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2015")])]

#text("It is interesting to observe that the (very good) lower bound")#linebreak()#text(" ")#mi("M_k \\geq \\log k - \\log \\log \\log k + O(1)")#linebreak()#text(" was obtained using only(!) functions ")#mi("F")#text(" of the special form")#linebreak()#text(" ")#mi("F(t_1, ... , t_k) := (\\prod_i f(t_i))1_{\\mathcal R_k}")

#text("Is there a simple (perhaps intuitive) explanation for such a good bound (in spite of using a very restricted class of functions in ")#mi("L^2(\\mathcal R_k)")#text(")?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451102")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2015")])]

#text("New article in upcoming issue of New Yorker:")#linebreak()#text(" ")#link("http://www.newyorker.com/magazine/2015/02/02/pursuit-beauty")[#text("http://www.newyorker.com/magazine/2015/02/02/pursuit-beauty")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbc18fa1121b8fa9882913bae34c8ee95f5625eeca6286b1a2ad23ba28677eac-4b48c0ccfb856201ce86b093cbda2eddf8c25a173a1979df1f1fa74ff2800c19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observer")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451113")[#strong[#text("observer")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2015")])]

#text("Locks making job! It would be interesting to hear about industrial experience of other mathematicians. E.g., I worked with drunkards on a car assembly line and between each task I read an English book.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451172")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("Sorry!, Correction of orthographe et grammaire:")#linebreak()#text(" New Theory: whatever has two integers “r” and “N” then N, and “r*N + 1” are relatively prime,((Coprimes))")#linebreak()#text(" Demonstration:")#linebreak()#text(" Suppose “p” is one of the divisors of “N”, then this “p” itself is a divisor of “r*N” so this “p” can not divide (a * N + 1)")#linebreak()#text(" Find yourself a potential Error?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451173")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 29 January 2015")])]

#text("Generalization:")#linebreak()#text(" Whatever N, a, and b are 3 integers :")#linebreak()#text(" If “N”, and “b” do not have a common divisor less than, or equal to “b”, then: “N”, and “a * n + b” will be coprime !,")#linebreak()#text(" Demonstration:")#linebreak()#text(" assume that “p” is a divisor of “N”, it is also a divisor of “a * N”")#linebreak()#text(" so this “p” can not be a divisor of “a * N + b” Except for cases where:")#linebreak()#text(" “p” = “b”, or “p” divides “b”")#linebreak()#text(" (( I would like to know your opinion on this new theorem ))")#linebreak()#text(" <>")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451265")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2015")])]

#text("J’ai démontré qu’il y a , au moins, un premier entre N, et (3/2)N, quelque soit N > 3, est-ce que c’est important, selon vous ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f48af667e2379833f24c6484a4253f1a6d56fc04ade7862b3f9210ec86b4d1a-d8e75ce9c60eaf93cf589af6be6053f9e33f7b05ece2097a05309a9f6f06e81b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Koussay")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451266")[#strong[#text("Koussay")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2015")])]

#text("*** Soient les 2 intervales: J1 = [ a , a + n] , et J2 = [ b , b + kn], on note:")#linebreak()#text(" P( [c,d] ) = le nombre des nombres premiers entre c, et d,")#linebreak()#text(" Alors Limite{ P(J2)/P(J1) } = k, lorsque n tend vers l’infini,")#linebreak()#text(" Je vais publier la démonstration, si vous me confirme l’importance de ce new théory!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-451267")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2015")])]

#text("Please stop this gibberish now!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-453230")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("Why the “singular series” ")#mi("\\mathfrak S")#text(" (actually defined as a product over primes) is not called “singular product”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-453249")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 March 2015")])]

#text("Historically, the singular series was first computed by Hardy and Littlewood using their circle method as a sum over major arcs. Later, it was realised that one could factor the series into an Euler product that was simpler and more conceptually natural, and so the singular series is often now defined in its equivalent product form.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-454096")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 April 2015")])]

#text("In Polymath8b paper (page 60), the current lower bound 2.00558 in the RHS of (128) should be slightly smaller (since the ratio in the LHS is 2.0055790…).")

#emph[#text("[Thanks, this has been corrected in the Dropbox version of the paper, but I don’t think I’ll try to change the arXiv or published version unless a more significant erratum is needed. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-454271")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2015")])]

#text("In Polymath8b paper (page 33), in the proof of theorem 3.8 it is clear that the denominator ")#mi("I(F_3)")#text(" of (75) approximates the denominator ")#mi("I(F_2)")#text(" of (74) since ")#mi("F_3")#text(" approximates ")#mi("F_2")#text(" in ")#mi("L^2")#text(", but the approximation of the corresponding numerators is not sufficiently clear (although it follows from the continuity of the functionals ")#mi("J_i")#text(" in ")#mi("L^2")#text(" – which is equivalent to ")#mi("M_k < \\infty")#text(" – but this is proved only later(!) in corollary 6.4).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-454272")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2015")])]

#text("Continuity of the ")#mi("J_i")#text(" in ")#mi("L^2")#text(" can be proven fairly easily by a number of means (for instance, it is easy to see that the ")#mi("J_i")#text(" are bounded on both ")#mi("L^1")#text(" and ")#mi("L^\\infty")#text(", and then one can apply interpolation; of course, the Cauchy-Schwarz argument used to prove Corollary 6.4 also works here, and one can also use a sufficiently general form of Schur’s test).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-455286")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2015")])]

#text("One of the Polymath8b bounds has just been improved… the bound on ")#mi("H_m")#text(" for large ")#mi("m")#text(" has improved from ")#mi("O( m \\exp( (4-\\frac{28}{157} m) ) \\approx \\exp( 3.821 m )")#text(" to ")#mi("O( \\exp( 3.815 m ) )")#text(", by ")#link("http://arxiv.org/abs/1505.01815")[#text("Baker and Irving")]#text(". The main idea is to replace the von Mangoldt function ")#mi("\\Lambda")#text(" in the GPY argument by a slightly smaller (and occasionally negative) function with a slightly better exponent of distribution, using a sieve of Harman.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-455403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2015")])]

#text("It is interesting to observe that the exponent of distribution")#linebreak()#text(" ")#mi("1/2 +  2 \\varpi")#text(" with ")#mi("\\varpi =  7/600")#text(", is determined in Polymath8a paper by two “active” constraints:")

#text("1. Combinatorial constraint (lemma 2.7, page 11):")

#mi("\\sigma > \\frac {1}{10}")

#text("2. A constraint for new type I estimate (theorem 2.8(iii), page 11):")

#mi("\\frac {160}{3} \\varpi +16 \\delta + \\frac {34}{9} \\sigma < 1")

#text("In the paper by Baker and Irving, the combinatorial constraint is no more active, and is (effectively) replaced by the new active constraint:")

#text("1′. A constraint for type III estimate (Polymath8a paper, theorem 2.8(v)):")

#mi("\\sigma > \\frac {1}{18} + \\frac{28}{9} \\varpi + \\frac{2}{9} \\delta")

#text("Which (as explained in lemma 6) gives the (slightly larger) exponent of distribution for the function ")#mi("\\rho")#text(", where (effectively) the constraint on ")#mi("\\sigma")#text(" is slightly relaxed to ")#mi("\\sigma > 1/10 - 22/3295")#text(".")#linebreak()#text(" Note that this relaxed constraint on ")#mi("\\sigma")#text(" is no longer combinatorial! (it is determined by the non-combinatorial constraints 2 and 1′ above).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fdda0155bd21aab43ed9c30a0e2e815bbbca3ab238427f13c0baa6558f38cd8-84045178191edbfa7b19ef43ee139359d59227bb709b2fcb4c9a0037afc4486a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-456989")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 6 July 2015")])]

#text("Sorry for being so late to this new party. Does the Baker/Irving result revive interest in improving the Type III estimates? There are two ideas for improving the Type III estimates that are mentioned at ")#link("http://michaelnielsen.org/polymath1/index.php?title=Distribution_of_primes_in_smooth_moduli")[#text("http://michaelnielsen.org/polymath1/index.php?title=Distribution_of_primes_in_smooth_moduli")]#text(" but became uninteresting after the relevant border for maximising \\varpi became the Type I/combinatorial one, but I have no sense of how much the resulting improvements might turn out to be. Does the Baker/Irving work still leave a limit on the extent to which a combinatorial constraint is pushed out of the picture, or is that aspect really entirely gone (as was the hope when we were discussing a succession of Type IV, Type V etc limits)? (There’s also the approach to improving Type I mentioned in ")#link("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/#comment-306762")[#text("https://terrytao.wordpress.com/2014/04/14/polymath8b-x-writing-the-paper-and-chasing-down-loose-ends/#comment-306762")]#text(" – two 1D vdC’s rather than the elusive 2D option.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-457238")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2015")])]

#text("In the home page for the Polymath8 project, it seems appropriate to add a remark to the current records table that this improved bound on ")#mi("H_m")#text(" is by Baker and Irving (not by the Polymath8 project).")

#emph[#text("[Fair enough – I’ve added a reference. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-455309")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2015")])]

#text("It seems that there is a difficulty in the derivation of lemma 15 (page 21) in the proof of lemma 1 in this paper. More precisely, by replacing the “detection function” ")#mi("\\theta (n)")#text(" (used in Polymath8b paper) by the function ")#mi("\\rho(n)")#text(", then by using lemma 3.4 (page 10 in Polymath8b paper) both(!) the numerator and the denominator of the key inequality")#linebreak()#text(" ")#mi("(\\beta _1 + ... + \\beta _k) / \\alpha > m")#linebreak()#text(" are (apparently) multiplied by the same(!) factor")#linebreak()#text(" ")#mi("(1 - c_1 +o(1)) / \\log x")#linebreak()#text(" which (after cancellation) should give the same result of theorem 3.10 (in Polymath8b paper) without(!) the factor ")#mi("1 - c_1")#text(" in lemma 15 in this paper.")#linebreak()#text(" This should improve the condition on ")#mi("c_0")#text(" in lemma 1 to")#linebreak()#text(" ")#mi("c_0 > 2 m / \\theta")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-455319")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2015")])]

#text("I believe the ")#mi("1-c_1")#text(" factor doesn’t show up in the denominator term, which does not involve ")#mi("\\rho")#text(" or ")#mi("\\theta")#text(" (it is basically just the sum ")#mi("\\sum_{x \\leq n \\leq 2x: x = b\\ (W)} \\nu(n)")#text(", up to some other normalising factors).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-455327")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 May 2015")])]

#text("Yes, It was my mistake! (I saw the estimate of ")#mi("\\sum \\rho(n)")#text(" which has this factor, and forgot that the denominator should be related to ")#mi("\\sum \\nu(n)")#text(" estimate.)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/feda2708ab41aeb5a863f024d1bdf0b1d8e756e1e19ef3e175c14fd9820c8eca-3335bed4a94ed4d3a639469274e25dfa6b77c1b83e32303b80b4b71de3b79cf8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mixedmath")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-457304")[#strong[#text("mixedmath")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2015")])]

#text("Dr. Tao, I wonder what the next Polymath project might be, or where it might come from. Perhaps Polymath8 and Polymath9 are still recent, but I do not know of any current proposals for Polymaths. Are you aware of current proposals — or relatedly, do you have any thoughts for another good polymath project?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-457379")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2015")])]

#text("For each positive integer ")#mi("m")#text(", let ")#mi("N_m")#text(" be the smallest integer ")#mi("n")#text(" for which ")#mi("p_{n+m} - p_n = H_m")#text(". Is it possible to find an upper bound on ")#mi("N_m")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-457382")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 July 2015")])]

#text("Not exactly, but we do have the result of Maynard ")#link("http://arxiv.org/abs/1405.2593")[#text("http://arxiv.org/abs/1405.2593")]#text(" that for sufficiently large x, there are intervals in ")#mi("[x,2x]")#text(" of length ")#mi("\\log^\\varepsilon x")#text(" that contain ")#mi("\\gg \\log\\log x")#text(" primes, which implies that for any m, there is an n such that ")#mi("p_{n+m} - p_n \\ll \\exp(O(m))")#text(" for some ")#mi("n \\ll \\exp(\\exp(O(m)))")#text(". However, while this gap ")#mi("p_{n+m}-p_n")#text(" is bounded, it may not equal the absolute minimal value ")#mi("H_m")#text(" of this gap, which may potentially only occur much later in the sequence of primes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-469664")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 June 2016")])]

#text("In the Polymath8b paper, since the discussion in the parity problem section is (as stated) “somewhat informal and heuristic in nature”, is it possible to make it sufficiently rigorous to imply a theorem that ")#mi("H_1 \\leq 6")#text(" is best possible using certain (well defined!) standard sieve methods?")#linebreak()#text(" Otherwise, what could be the existing loopholes in that discussion – which (hopefully) still enable improvement of ")#mi("H_1 \\leq 6")#text(" by (well defined class of) standard sieve methods?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/600feb2c1b3645184117a90d2f5a0227582bb7b6a1b1146f5a49678f9c64132b-1af16243d5d695376ad810f0ba33ef8c52c8d0cd0d039dba54677a1e9248c7a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sultan M.")]], [#link("https://terrytao.wordpress.com/2014/09/30/the-bounded-gaps-between-primes-polymath-project-a-retrospective/comment-page-1/#comment-473846")[#strong[#text("Sultan M.")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2016")])]

#text("Dear POLYMATH8 Members:")

#text("First forgive me for my poor English;")

#text("Secondly: if we have Twin Primes of gap 2 on the form: P- Q = 2 , where P & Q are prime numbers , I had noticed that Q – 2 in all the cases that I had tested always equalls a")

#text("Multiple of 3 , the first pair that ” My Claims” applys to is (5,7) , so :")

#text("7- 5 = 2 , then 5 – 2 = 3 , which is the first Multiple of 3 .")

#text("Also :")

#text("13 – 11 = 2 , then 11 – 2 = 9 , which is the third Multiple of 3 ,")

#text("199 – 197 = 2 , then 197 – 2 = 195 , which equalls 3 x 65 ,")

#text("421 – 419 = 2 , then 419 – 2 = 417 , which equalls 3 x 139 ,")

#text("7936141 – 7936139 = 2 , then 7936139 – 2 = 7936137 , which equalls 3 x 2645379 ,")

#text("And so on.")

#text("In every case that I had encountered the same thing happened ; also I had noticed that if we generalized the above equations in the form : Q – 2 = 3 x M , where 3M is a")

#text("Multiple of 3 , the Decimal place of “Units” in any M in all the cases that I had examined always be 3 or 5 or 9 , for example :")

#text("19 – 17 = 2 , then 17 – 2 = 15 , which equalls 3 x 5 , so we have only one decimal place which is of course is Units with value of 5 , for more explanation we take the following")

#text("examples ;")

#text("283 – 281 = 2 , then 281 – 2 = 279 , which is 3 x 93 , so by looking at the decimal place of Units in 93 we found 3 ,")

#text("523 – 521 = 2 , then 521 – 2 = 519 , which is 3 x 173 , here we had 3 in the decimal place of units ,")

#text("241 – 239 = 2 , then 239 – 2 = 237 , which is 3 x 79 , here we had 9 in the decimal place of units ,")

#text("5001121 – 5001119 = 2 , then 5001119 – 2 =5001117 , which is 3 x 1667039 , here we had 9 in the decimal place of units ,")

#text("11034349 – 11034347 = 2 , then 11034347 – 2 = 11034345 , which is 3 x 3678115 , here we had 5 in the decimal place of units , and so on.")
]
