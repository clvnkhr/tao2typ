// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/
// Converted to Typst by tao2typ: "2026-10-14T11:12:17.102444+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What are the odds, II: the Venezuelan presidential election", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What are the odds, II: the Venezuelan presidential election")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 August 2024")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/")[#text("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In a ")#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/")[#text("previous blog post")]#text(", I discussed how, from a ")#link("https://en.wikipedia.org/wiki/Bayesian_probability")[#text("Bayesian perspective")]#text(", learning about some new information ")#mi("{E}")#text(" can update one’s perceived ")#link("https://en.wikipedia.org/wiki/Odds")[#text("odds")]#text(" ")#mi("{{\\mathbb P}(H_1) / {\\mathbb P}(H_0)}")#text(" about how likely an “alternative hypothesis” ")#mi("{H_1}")#text(" is, compared to a “null hypothesis” ")#mi("{H_0}")#text(". The mathematical formula here is ")#metadata(none) <tao-952e9a8b19d48ab1f725>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\frac{{\\mathbb P}(H_1|E)}{{\\mathbb P}(H_0|E)} = \\frac{{\\mathbb P}(E|H_1)}{{\\mathbb P}(E|H_0)} \\frac{{\\mathbb P}(H_1)}{{\\mathbb P}(H_0)}.")]]

#text(" ")#text(" Thus, provided one has")

#list(
[#text("(i) A precise formulation of the null hypothesis ")#mi("{H_0}")#text(" and the alternative hypothesis ")#mi("{H_1}")#text(", and the new information ")#mi("{E}")#text(";")],
[#text("(ii) A reasonable estimate of the prior odds ")#mi("{{\\mathbb P}(H_1) / {\\mathbb P}(H_0)}")#text(" of the alternative hypothesis ")#mi("{H_1}")#text(" being true (compared to the null hypothesis ")#mi("{H_0}")#text(");")],
[#text("(iii) A reasonable estimate of the probability ")#mi("{{\\mathbb P}(E|H_0)}")#text(" that the event ")#mi("{E}")#text(" would occur under the null hypothesis ")#mi("{H_0}")#text("; and")],
[#text("(iv) A reasonable estimate of the probability ")#mi("{{\\mathbb P}(E|H_1)}")#text(" that the event ")#mi("{E}")#text(" would occur under the alternative hypothesis ")#mi("{H_1}")#text(",")]
)

#text("one can then obtain an estimate of the posterior odds ")#mi("{{\\mathbb P}(H_1|E) / {\\mathbb P}(H_0|E)}")#text(" of the alternative hypothesis being true after observing the event ")#mi("{E}")#text(". Ingredient (iii) is usually the easiest to compute, but is only one of the key inputs required; ingredients (ii) and (iv) are far trickier, involve subjective non-mathematical considerations, and as discussed in the previous post, depend rather crucially on ingredient (i). For instance, selectively reporting some relevant information for ")#mi("{E}")#text(", and withholding other key information from ")#mi("{E}")#text(", can make the final mathematical calculation ")#mi("{{\\mathbb P}(H_1|E) / {\\mathbb P}(H_0|E)}")#text(" misleading with regard to the “true” odds of ")#mi("{H_1}")#text(" being true compared to ")#mi("{H_1}")#text(" based on all available information, even if the calculation was technically accurate with regards to the partial information ")#mi("{E}")#text(" provided. Also, the computation of the relative odds of two competing hypotheses ")#mi("{H_0}")#text(" and ")#mi("{H_1}")#text(" can become somewhat moot if there is a third hypothesis ")#mi("{H_2}")#text(" that ends up being more plausible than either of these two hypotheses. Nevertheless, the formula ")#link(<tao-952e9a8b19d48ab1f725>)[#text("(1)")]#text(" can still lead to useful conclusions, albeit ones that are qualified by the particular assumptions and estimates made in the analysis.")

#text("At a qualitative level, the Bayesian identity ")#link(<tao-952e9a8b19d48ab1f725>)[#text("(1)")]#text(" is telling us the following: if an alternative hypothesis ")#mi("{H_1}")#text(" was already somewhat plausible (so that the prior odds ")#mi("{{\\mathbb P}(H_1) / {\\mathbb P}(H_0)}")#text(" was not vanishingly small), and the observed event ")#mi("{E}")#text(" was significantly more likely to occur under hypothesis ")#mi("{H_1}")#text(" than under ")#mi("{H_0}")#text(", then the hypothesis ")#mi("{H_1}")#text(" becomes significantly more plausible (in that the posterior odds ")#mi("{{\\mathbb P}(H_1|E) / {\\mathbb P}(H_0|E)}")#text(" become quite elevated). This is quite intuitive, but as discussed in the previous post, a lot hinges on how one is defining the alternative hypothesis ")#mi("{H_1}")#text(".")

#text("In the ")#link("https://terrytao.wordpress.com/2022/10/03/what-are-the-odds/")[#text("previous blog post")]#text(", this calculation was initially illustrated with the following choices of ")#mi("{H_0}")#text(", ")#mi("{H_1}")#text(", and ")#mi("{E}")#text(" (thus fulfilling ingredient (i)):")

#list(
[#mi("{E}")#text(" was the event that the October 1, 2022 PSCO Grand Lotto in the Phillippines drew the numbers ")#mi("{9, 18, 27, 36, 45, 54}")#text(" (that is to say, consecutive multiples if ")#mi("{9}")#text("), though not necessarily in that order;")],
[#mi("{H_0}")#text(" was the null hypothesis that the lottery was fair and the numbers were drawn uniformly at random (without replacement) from the set ")#mi("{\\{1,\\dots,55\\}}")#text("; and")],
[#mi("{H_1}")#text(" was the alternative hypothesis that the lottery was rigged by some corrupt officials for their personal gain.")]
)

#text("In this case, ingredient (iii) can be computed mathematically and precisely:")

#metadata(none) <tao-129c6f6e5eed36241e70>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\mathbb P}(E|H_0) = \\frac{1}{\\binom{55}{6}} = \\frac{1}{28,989,675}.")]]

#text("And, with a not inconceivable level of cynicism about the integrity of the lottery, the prior odds (ingredient (ii)) can be argued to be non-negligible. However, ingredient (iv) was nearly impossible to estimate: indeed, as argued in that post, there is no reason to suspect that ")#mi("{{\\mathbb P}(E|H_1)}")#text(" is much larger than the tiny probability ")#link(<tao-129c6f6e5eed36241e70>)[#text("(2)")]#text(", and in fact it could well be smaller (since would likely be in the interest of corrupt lottery officials to not draw attention to their activities). So, despite the very small numerical value of the probability ")#link(<tao-129c6f6e5eed36241e70>)[#text("(2)")]#text(", this did not lead to any significant increase in the odds of the alternative hypothesis. In the previous blog post, several other variants ")#mi("{H^{\\prime}_1}")#text(", ")#mi("{H^{\\prime\\prime}_1}")#text(", ")#mi("{H^{\\prime\\prime\\prime}_1}")#text(" of the alternative hypothesis ")#mi("{H_1}")#text(" were also discussed; the conclusion was that while some choices of alternative hypothesis could lead to elevated probabilities for ingredient (iv), they came at the cost of significantly reducing the prior odds in ingredient (ii), and so no alternative hypothesis was located which ended up being significantly more plausible than the null hypothesis ")#mi("{H_0}")#text(" after observing the event ")#mi("{E}")#text(".")

#text("In this post, I would like to run the same analysis on a numerical anomaly in the recent Venezuelan presidential election of June 28, 2024. Here are the ")#link("https://www.albatcp.org/en/2024/07/29/cne-announced-nicolas-maduro-moros-victory-with-51-20/")[#text("officially reported vote totals")]#text(" for the two main candidates, incumbent president Nicolás Maduro and opposition candidate Edmundo González, in the election:")

#list(
[#text("Maduro: 5,150,092 votes")],
[#text("González: 4,445,978 votes")],
[#text("Other: 462,704 votes")],
[#text("Total: 10,058,774 votes.")]
)

#text("The numerical anomaly is that if one multiplies the total number of voters ")#mi("{10,058,774}")#text(" by the round percentages ")#mi("{51.2\\%}")#text(", ")#mi("{44.2\\%}")#text(", ")#mi("{4.6\\%}")#text(", one recovers exactly the above vote counts after rounding to the nearest integer:")

#tao-aligned(keep: true)[


#tao-math("51.2\\% \\times 10,058,774  & = 5,150,092.288", block: true)



#tao-math("44.2\\% \\times 10,058,774  & = 4,445,978.108", block: true)



#tao-math("4.6\\% \\times 10,058,774  & = 462,703.604.", block: true)
]

#text("Let us try to apply the above Bayesian framework to this situation, bearing in mind the caveats that this analysis is only strong as the inputs supplied and assumptions made (for instance, to simplify the discussion, we will not also discuss information from ")#link("https://www.edisonresearch.com/edison-research-conducts-exit-poll-in-venezuela/")[#text("exit polling")]#text(", which in this case gave significantly different predictions from the percentages above).")

#text("The first step (ingredient (i)) is to formulate the null hypothesis ")#mi("{H_0}")#text(", the alternative hypothesis ")#mi("{H_1}")#text(", and the event ")#mi("{E}")#text(". Here is one possible choice:")

#list(
[#mi("{E}")#text(" is the event that the reported vote total for Maduro, González, and Other are all equal to the nearest integer of the total number of voters, multiplied by a round percentage with one decimal point (i.e., an integer multiple of ")#mi("{0.1\\%}")#text(").")],
[#mi("{H_0}")#text(" is the null hypothesis that the vote totals were reported accurately (or with only inconsequential inaccuracies).")],
[#mi("{H_1}")#text(" is the alternative hypothesis that the vote totals were manipulated by officials from the incumbent administration.")]
)

#text("Ingredient (ii) – the prior odds that ")#mi("{H_1}")#text(" is true over ")#mi("{H_0}")#text(" – is highly subjective, and an individual’s estimation of (ii) would likely depend on, or at least be correlated with, their opinion of the current Venezulan administration. Discussion of this ingredient is therefore more political than mathematical, and I will not attempt to quantify it further here. Now we turn to (iii), the estimation of the probability ")#mi("{{\\mathbb P}(E|H_0)}")#text(" that ")#mi("{E}")#text(" occurs given the hypothesis ")#mi("{H_0}")#text(". This cannot be computed exactly without a precise probabilistic model of the voting electorate, but let us make a rough order of magnitude calculation as follows. One can focus on the anomaly just for the number of votes received by Maduro and González, since if both of these counts were the nearest integer to a round percentages then just from simple subtraction the number of votes for “other” would also be forced to also be the nearest integer from a round percentage, possibly plus or minus one due to carries, so up to a factor of two or so we can ignore the latter anomaly. As a simple model, suppose that the voting percentages for Maduro and González were distributed more or less uniformly in some square ")#mi("{[p-\\varepsilon,p+\\varepsilon] \\times [q-\\varepsilon,q+\\varepsilon]}")#text(", where ")#mi("{p, q}")#text(" are some proportions not too close to either ")#mi("{0}")#text(" or ")#mi("{1}")#text(", and ")#mi("{\\varepsilon}")#text(" is some reasonably large margin of error (the exact values of these parameters will end up not being too important, nor will the specific shape of the distribution; indeed, the shape and size of the square here only impacts the analysis through the area ")#mi("{(2\\varepsilon)^2}")#text(" of the square, and even this quantity cancels itself out in the end). Thus, the number of votes for Maduro is distributed in an interval of length about ")#mi("{2\\varepsilon N}")#text(", where ")#mi("{N = 10,058,774}")#text(" is the number of voters, and similarly for González, so the total number of different outcomes here is ")#mi("{(2\\varepsilon N)^2}")#text(", and by our model we have a uniform distribution amongst all these outcomes. On the other hand, the total number of attainable round percentages for Maduro is about ")#mi("{(2\\varepsilon) / 0.1\\% = 1000 \\times 2\\varepsilon}")#text(", and similarly for González, so our estimate for ")#mi("{{\\mathbb P}(E|H_0)}")#text(" is")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}(E|H_0) \\approx \\frac{(1000 \\times 2\\varepsilon)^2}{(2\\varepsilon N)^2} = (1000/N)^2 \\approx 10^{-8}.")]]

#text("This looks quite unlikely! But we are not done yet, because we also need to estimate ")#mi("{{\\mathbb P}(E|H_1)}")#text(", the probability that the event ")#mi("{E}")#text(" would occur under the alternative hypothesis ")#mi("{H_1}")#text(". Here one has to be careful, because while it ")#emph[#text("could")]#text(" happen under hypothesis ")#mi("{H_1}")#text(" that the vote counts were manipulated to be exactly the nearest integer to a round percentage, this is not the only outcome under this hypothesis, and indeed one could argue that it would not be in the interest of an administration to generate such a striking numerical anomaly. But one can create a reasonable chain of events with which to estimate (from below) this probability by a kind of “")#link("https://en.wikipedia.org/wiki/Drake_equation")[#text("Drake equation")]#text("“. Consider the following variants of ")#mi("{H_1}")#text(":")

#list(
[#mi("{H^{\\prime}_1}")#text(": ")#mi("{H_1}")#text(" is true, and the administration directs election officials to report vote outcomes with some explicitly preferred (round) percentages, regardless of the actual election results.")],
[#mi("{H^{\\prime\\prime}_1}")#text(": ")#mi("{H^{\\prime}_1}")#text(" is true, and the election officials dutifully generate a report by multiplying these preferred percentages by the total number ")#mi("{N}")#text(" of voters, and rounding to the nearest integer, without any attempt to disguise their actions.")]
)

#text("By the ")#link("https://en.wikipedia.org/wiki/Chain_rule_(probability)")[#text("chain rule for conditional probability")]#text(", one has a lower bound")

#align(center)[#tao-fit-display[#mitex("{\\mathbb P}(E|H_1) \\geq {\\mathbb P}(E, H^{\\prime\\prime}_1, H^{\\prime}_1|H_1) = {\\mathbb P}(E|H^{\\prime\\prime}_1) {\\mathbb P}(H^{\\prime\\prime}_1|H^{\\prime}_1) {\\mathbb P}(H^{\\prime}_1|H_1).")]]

#text("Inserting this into ")#link(<tao-952e9a8b19d48ab1f725>)[#text("(1)")]#text(", we obtain our final lower bound:")

#align(center)[#tao-fit-display[#mitex("\\frac{{\\mathbb P}(H_1|E)}{{\\mathbb P}(H_0|E)} \\gtrapprox 10^8 \\times {\\mathbb P}(E|H^{\\prime\\prime}_1) {\\mathbb P}(H^{\\prime\\prime}_1|H^{\\prime}_1) {\\mathbb P}(H^{\\prime}_1|H_1) \\frac{{\\mathbb P}(H_1)}{{\\mathbb P}(H_0)}.")]]

#text("This is about as far as one can get purely with mathematical analysis. Beyond this, one has to make some largely subjective estimations for each of the remaining probabilities and odds in this formula. As mentioned, the prior odds ")#mi("{{\\mathbb P}(H_1)/{\\mathbb P}(H_0)}")#text(" will likely depend on the individual making this calculation, and will not be discussed further here. The remaining question then is how large the probabilities ")#mi("{{\\mathbb P}(H^{\\prime}_1|H_1)}")#text(", ")#mi("{{\\mathbb P}(H^{\\prime\\prime}_1|H^{\\prime}_1)}")#text(", and ")#mi("{{\\mathbb P}(E|H^{\\prime\\prime}_1)}")#text(" are. In other words:")

#list(
[#text("If one assumes that the administration wishes to manipulate the vote totals, how likely is it ")#emph[#text("a priori")]#text(" (i.e., without being aware of the anomaly ")#mi("{E}")#text(") that they would do so by explictly selecting preferred round percentages and then requesting that election officials report these percentages?")],
[#text("If one assumes that election officials are being ordered to report vote totals to reflect a preferred round percentage, how likely is it ")#emph[#text("a priori")]#text(" that they would follow the orders without question, and performing simple rounding instead of any more sophisticated numerical manipulation?")],
[#text("If one assumes that election officials did indeed follow the orders as above, how likely is it ")#emph[#text("a priori")]#text(" that the report would be published as is without any concerns raised by other officials or observers?")]
)

#text("If one’s estimate of the product of these three probabilities multiplies to be significantly greater than ")#mi("{10^{-8}}")#text(", then we can conclude that the event ")#mi("{E}")#text(" has indeed significantly raised the odds of some sort of voting manipulation present. The scenario described above is somewhat plausible, especially in light of the anomaly ")#mi("{E}")#text(", and so certainly the ")#emph[#text("posterior")]#text(" probabilities ")#mi("{{\\mathbb P}(H^{\\prime}_1|H_1,E)}")#text(", ")#mi("{{\\mathbb P}(H^{\\prime\\prime}_1|H^{\\prime}_1,E)}")#text(" seem quite large (and the posterior probability ")#mi("{{\\mathbb P}(E|H^{\\prime\\prime}_1,E)}")#text(" is of course equal to ")#mi("{1}")#text("). But it is important here to avoid ")#link("https://en.wikipedia.org/wiki/Confirmation_bias")[#text("confirmation bias")]#text(" and work only with ")#emph[#text("a priori")]#text(" probabilities – roughly speaking, the probabilities that one would assign to such events on July 27, 2024, before knowledge of the anomaly ")#mi("{E}")#text(" came to light. Nevertheless, even after accounting for confirmation bias, I think it is plausible that the above product of ")#emph[#text("a priori")]#text(" probabilities is indeed significantly larger than ")#mi("{10^{-8}}")#text(" (for instance, to assign probabilities somewhat randomly, this would be the case of each of the conditional probabilities ")#mi("{{\\mathbb P}(H^{\\prime}_1|H_1)}")#text(", ")#mi("{{\\mathbb P}(H^{\\prime\\prime}_1|H^{\\prime}_1)}")#text(" and ")#mi("{{\\mathbb P}(E|H^{\\prime\\prime}_1)}")#text(" all exceed ")#mi("{1\\%}")#text("), giving credence to the theory of the election report being manipulated (though it is possible that the manipulation could occur through a third hypothesis ")#mi("{H_2}")#text(" not covered by the original two hypotheses, such as a software glitch). If one adds in additional information beyond the purely numerical anomaly ")#mi("{E}")#text(", such as the fact that the reported totals were not broken down further by voting district (which would be less likely under hypothesis ")#mi("{H_0}")#text(" than hypothesis ")#mi("{H_1}")#text("), and that ")#link("https://www.edisonresearch.com/edison-research-conducts-exit-poll-in-venezuela/")[#text("exit polls gave significantly different results")]#text(" from the reported totals (which is again less likely under hypothesis ")#mi("{H_0}")#text(" than hypothesis ")#mi("{H_1}")#text("), the evidence for voting irregularities becomes quite significant.")

#text("One can contrast this analysis with that of the Phillipine lottery in the original post. In both cases the probability ")#mi("{{\\mathbb P}(E|H_0)}")#text(" of the observed event under the null hypothesis was extremely small. However, in the case of the Venezuelan election, there is a plausible causal chain ")#mi("{H_1 \\implies H^{\\prime}_1 \\implies H^{\\prime\\prime}_1 \\implies E}")#text(" that leads to an elevated probability ")#mi("{{\\mathbb P}(E|H_1)}")#text(" of the observed event under the alternative hypothesis, whereas in the case of the lottery, only extremely implausible chains could be constructed that would lead to the specific outcome of a multiples-of-9 lottery draw for that specific lottery on that specific date.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (82)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685462")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("Dear Prof. Tao, would you care to provide a similar analysis of the 2020 US election?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685471")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("At the risk of being naive, I think that perhaps this could indeed be an instructive opportunity to have a good-faith discussion on this topic centered around quantitative analysis rather than political rhetoric. Why don’t you start out by proposing the setup (ingredient (i)). What do you claim to be the null hypothesis ")#mi("H_0")#text(", what do you claim to be the alternative hypothesis ")#mi("H_1")#text(", and what do you claim to be the new information ")#mi("E")#text(" that would cause an update of prior odds of the alternative hypothesis? It is necessary to have precise descriptions of all three statements before we can proceed with the rest of the analysis.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685769")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2024")])]

#text("The setup: in the 2020 presidential election, in Michigan state, 138,339 consecutive votes came in all voted for candidate B (")#link("https://archive.is/nQzbT/b675664926da1e0f397832a4218bf060ae099e98.jpg")[#text("https://archive.is/nQzbT/b675664926da1e0f397832a4218bf060ae099e98.jpg")]#text("). Before these votes, 51.64% of the votes went for candidate T, 46.75% of the votes went for candiate B, 1.15% for candidate J, 0.25% for candidate T and 0.15% for candidate DB")

#text("H0: all 138,339 votes are indeed all casted by real people")

#text("H1: all 138,339 votes or part of those votes are fabricated to help candidate B")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2024")])]

#text("Looking at the media coverage at the time at ")#link("https://www.usatoday.com/story/news/factcheck/2020/11/04/fact-check-typo-led-false-post-michigan-votes-biden/6164385002/")[#text("https://www.usatoday.com/story/news/factcheck/2020/11/04/fact-check-typo-led-false-post-michigan-votes-biden/6164385002/")]#text(" ")#link("https://www.nytimes.com/2020/11/04/technology/biden-michigan-votes.html")[#text("https://www.nytimes.com/2020/11/04/technology/biden-michigan-votes.html")]#text(" , it appears that there is a third hypothesis:")

#text("H2: A clerk at Shiawassee County had mistakenly input the voter tally for Biden as 153,710 instead of 15,371, and the typo propagated to the unofficial statewide tally that was being reported in real time before being corrected some minutes later. [The final tally in this county for Biden ")#link("https://www.electionreporting.com/4539283c-3f09-4fdf-ad93-0bfd82d32be1/county/8f0eb06b-28bd-46f8-a245-85d0c6a3adc0")[#text("was actually 15,347")]#text(", presumably due to a small number (0.16% or so) of spoiled or incorrectly tallied ballots that were detected between the initial real-time informal count, and the official finalized count.]")

#text("This would then be a competing hypothesis to H1. It can be an instructive exercise to try to estimate the values ")#mi("{\\mathbf P}(H_1)")#text(", ")#mi("{\\mathbf P}(E|H_1)")#text(", ")#mi("{\\mathbf P}(H_2)")#text(", and ")#mi("{\\mathbf P}(E|H_2)")#text(" to compare the relative strengths of the hypotheses. The specificity of the numbers and the specific county do make the probabilities somewhat challenging to estimate accurately, though; it may be easier to try to estimate instead the hypotheses that (a) *some* significant input errors briefly occurred in *some* county, and (b) fabrication of votes led to *some* noticeable alteration in running reported totals without any attempt to make the alteration non-suspicious (e.g., by adding them slowly over time).")

#text("This example also illustrates the importance of having precinct-level data available, rather than just aggregated totals, as it can allow one to readily localize numerical anomalies to their source.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685807")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2024")])]

#text("Thanks for your reply and information. I have read such explanation before, but there is still one part that is very bizarre: On the screenshot, the poll for Biden went up from 1,992,356 to 2,130,695 (+138,339). If the clerk made the typo of 153,710 instead of 15,371, shouldn’t we see the number goes up to 2,146,066 (+153,710) instead? Why did the number go up not by the typo, but by the difference of the typo and the original number? Let’s call this fact E2, it seems that P(H2 | E2) is pretty low and thus P(H2) is pretty low as well?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685840")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2024")])]

#text("Given that ")#mi("138,339 = 153,710 - 15,371")#text(", a plausible explanation here is that at some earlier point in time, the correct value of ")#mi("15,371")#text(" was input into the running unofficial real-time tally for the Biden vote in this county, but at some later time, when an updated set of data was uploaded, an incorrect value of ")#mi("153,710")#text(" was input, overwriting the previous (correct) count and causing the temporary spike in unofficial real-time tally by ")#mi("138,339")#text(", which was subsequently corrected some minutes afterwards (and in any event did not make it into the official certified tally, which came several days afterward and presumably came with more thorough data checking safeguards than the real-time tally).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685463")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("Nice to have the analysis, on the other hand, it is obvious that with such exact percentages it is made up and that the people making it up first decided about the percentages, and then about the absolute votes. In autocratic states with clever manipulators they do it the other way round of course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685464")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("Would be so kind as to formulate your main conclusion as you if you were addressing a five-year old? In other words, did Maduro win the election cleanly?")

#text("Thanks ind avance for your reply!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685473")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("The short summary is that the theory that the reported election results were in fact obtained as the result of the administration directing certain preferred percentages to be reported (i.e., the causal chain ")#mi("H_1 \\implies H^{\\prime}_1 \\implies H^{\\prime\\prime}_1 \\implies E")#text(") seems to be a significantly more plausible theory than the theory that the reported election results genuinely reflected the election outcome (the causal chain ")#mi("H_0 \\implies E")#text("). However, the analysis is incomplete for two reasons. Firstly, there is additional information ")#mi("E^{\\prime}")#text(" (such as the exit polling) that would further update the relative plausibility of these two theories. Secondly, there may be alternative causal chains, e.g., ")#mi("H_2 \\implies H^{\\prime}_2 \\implies H^{\\prime\\prime}_2 \\implies E")#text(", that are significantly more likely than either of the two theories proposed to explain the event ")#mi("E")#text(". So one should view this analysis as a simplified preliminary analysis only.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Have you ever met a five-year old? :P")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Go to excel, assume you have 1,000,000 votes. Type in an arbitrary (or random) vote count for one candidate and calculate the percentage of the total that corresponds to. How often is it that you end up with a number that is a “nice” percentage, like “45.10000”? It is far more likely that you get “45.153833”, lots of random numbers at the end.")

#text("Note that you need to use a large number for the total. If you use say 10 then you will always get round numbers because, for example, 3/10 is 30.000%")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685506")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("One thing worth pointing out is that a very similar causal chain is possible even if the election was legitimate. In this scenario, a true exaxt vote total and true rounded percentages were handed off from one person to another without explaining that the percentages were rounded, and the second person did the multiplication. Some sort of miscommunication like that. I think it’s reasonable to say this chain is much less likely to happen in a legitimate election than the equivalent chain in a rigged election, but it’s gotta be more than 10^{–8}.")

#text("The fact that it happened ")#emph[#text("again")]#text(" on the 2nd only makes this more bizarre.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685465")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("why are you embarassing yourself by typing low level commentary on math subject you are not expert on?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685524")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2024")])]

#text("This is Terrence tao…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685528")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("Hi, Nicolas Maduro")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685467")[#strong[#text("What are the odds, II: the Venezuelan presidential election – aquamarine-lark-270283.hostingersite.com")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")]

#text("[…] ends up being more plausible than either of these two hypotheses. Nevertheless, the formula (1) can still lead to useful conclusions, albeit ones that are qualified by the particular […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685468")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2024")])]

#text("I found it easier to think in terms of increments of 0.1%, which correspond to 10,058.777 votes. It’s highly implausible to think that both candidates landed on votes that were multiples of 10,0588.777. Venky Nagar.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685469")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("I don’t know whether the vote was rigged but your analysis leaves out crucial facts: First, that Venezuela has been regularly accused of faking election results by the US (which has repeatedly backed illegal coups against the country) despite international election observers having declared them fair. ")#linebreak()#text("Second, it should be noted that the exit polls you refer to are funded by the NED, the regime change apparatus of the US. ")#linebreak()#text("Third and finally, there is a a plausible innocuous explanation for obtaining those numbers: the raw vote tallies may have been imputed from the percentages and overall total if the raw tallies were dropped somewhere along the line while communicating them to the ultimate publisher.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685474")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("As stated in the post, I am not using exit polling data in the current analysis (it would require a rather more sophisticated mathematical analysis), nor am I taking a position on the a priori validity of the alternative hypothesis ")#mi("H_1")#text(". But we can analyze your third point within the framework of the post. If I understand correctly, you are proposing an alternate causal chain ")#mi("H_0 \\implies H^{\\prime}_0 \\implies H^{\\prime\\prime}_0 \\implies E")#text(" where the intermediate hypotheses are as follows:")

#mi("H^{\\prime}_0")#text(": ")#mi("H_0")#text(" holds, and the raw vote totals were communicated by an election authority to another government agency, but only in the form of rounded percentages, with the raw votes withheld.")

#mi("H^{\\prime\\prime}_0")#text(": ")#mi("H^{\\prime}_0")#text(" holds, and the second government agency inputed the raw vote totals from the rounded percentages by multiplying and then multiplying to the nearest integer (as opposed to rounding to something more suitable for this level of accuracy, such as to the nearest thousand).")

#text("The question is then to estimate the following ")#emph[#text("a priori")]#text(" probabilities:")

#mi("{\\mathbb P}(H^{\\prime}_0|H_0)")#text(": How likely is it ")#emph[#text("a priori")]#text(" that the agency responsible for publishing election results would only receive rounded percentages from the agency responsible for tallying votes, rather than raw numbers?")

#mi("{\\mathbb P}(H^{\\prime\\prime}_0|H^{\\prime}_0)")#text(": How likely is it ")#emph[#text("a priori")]#text(" that said agency, if only receiving rounded percentages, would then convert them to imputed totals that rounded to the nearest integer rather than to a more realistic accuracy, instead of asking the originating agency for the raw totals?")

#mi("{\\mathbb P}(E|H^{\\prime\\prime}_0)")#text(": How likely is it ")#emph[#text("a priori")]#text(" that this agency would then present these imputed totals as the exact truth without any mention of the imputation, and not update them with the raw totals even several days after the anomalies were noticed?")

#text("I don’t know about your estimation of these three probabilities, but actually I find it hard to give each of them a plausibility of even ")#mi("1\\%")#text(", and when multiplied together, this is only barely more plausible than the random chance theory, but still less plausible than the directed percentage theory.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685485")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("I replied basically with the same answer in another comment but everything rests on your prior beliefs (and their uncertainties), a fact which is obscured by your use of (albeit simple) mathematical notation, which I find surprising given that you are famous for advocating for plain language in lieu of math-speak when it makes things clearer.")

#text("As to your point estimates I find them absurd. For example the probability that they not update the totals to correct the error was obviously near zero even a priori, because even if they committed fraud they would “fix” it after it was pointed out, not the 99% or whatever you estimated.")

#text("I also find your near-zero belief that anyone would ever have to impute numbers because those they received from some other department were incomplete to be completely unreasonable, even more so given that these were intermediate results.")

#text("Moreover point estimates convey a degree of certainty that do not exist. I think if you use reasonable confidence intervals you get something that is virtually uninformative after multiplying them. As an aside this multiply-point-estimates technique is something the rationalist community uses and which has fooled them and others into a false sense of precision and rigor.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685488")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("I misstated the problem with the not-corrected results assumption: In that case problem wasn’t with your estimate of the probability of occurring (0%) of something that occurred it’s that the thing was obviously never actually going to occur but you assumed that it had (fraud or no fraud the results were going to be fixed).")

#text("I would also add that assigning a 1% probability that percentages, if they are rounded, be rounded to a whole integer is nonsense. I would be that that is the most likely rounding for percentages by far you would find in, for example, Excel. We also don’t know what the purpose of the rounded number was. You assume it is was to maintain immaculate voting records but the rounded number could have been the one produced to present to the public or for an internal dashboard (and then misused), in both those cases rounding to the nearest integer makes sense.")

#text("This isn’t CERN, it’s a large government bureaucracy reporting interim results. It’s far more than 1% probable that someone produced a rounded number and someone else used it for a purpose it was not intended. Or the “publisher” of the data could not get in touch with the “producer” in whatever time constraint they were under. Or some other miscommunication. Even if you haven’t yourself worked in a large bureaucratic organization you must have heard that they are full of dysfunction, miscommunication, personal conflict, etc. All of which regularly produce far less-believable errors than this one.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac068f007ec94de58d9e10b346eea07bbf69b10d1b8277543c0d67db14436595-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Peden")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685498")[#strong[#text("William Peden")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("In its second bulletin of results, the problem was fixed:")

#link("https://en.wikipedia.org/wiki/2024_Venezuelan_presidential_election#Results_announced_by_the_National_Electoral_Council_(CNE)")[#text("https://en.wikipedia.org/wiki/2024_Venezuelan_presidential_election#Results_announced_by_the_National_Electoral_Council_(CNE)")]

#text("… except for the invalid/null vote count, which still has the same phenomenon.")

#text("Do you think that, this time, the rounded number mistake only happened for the invalid/null vote count?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685505")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("I can’t reply directly to William Peden (comment depth limit?) so as to the question “do you think that, this time, the rounded number mistake only happened for the invalid/null vote count?”, I’m not sure what additional information you think this yields. Either they committed fraud and, after being notified, continue to make the same error, or they did not and, again after being notified, continue to make the same error.")

#text("I don’t understand how either hypothesis is strengthened with the new information. My impression is that you believe that they are much more likely to continue making the same mistake if the origin of the mistake was fraud. I don’t understand how that is true.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685514")[#strong[#text("William Peden")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2024")]

#text("No, that’s not quite what I am saying. Let me try to clarify.")

#text("The error is not exactly the same type of error. It is the same general phenomenon (the type of error that typically occurs when making up results) but not the same error. However, the phenomenon of 0.41000% invalid votes is also extremely improbable, with the most likely hypothesis giving a high likelihood to this phenomenon being that of artificially generated results.")

#text("Please read the Wiki article for the data.")

#text("This whole controversy could have been avoided if the CNE had released the detailed results and tally sheets within the typical 48 hours, which is not hard given that it’s electronic voting, but the release has been delayed.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685502")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("I have deliberately chosen to use simple mathematical notation in this post precisely in order to help make things clearer, in particular by removing ambiguity in the selection of hypotheses such as ")#mi("H_0")#text(" or ")#mi("H_1")#text(". Without this level of precision, any discussion runs into the risk of appealing to a “")#link("https://en.wikipedia.org/wiki/Motte-and-bailey_fallacy")[#text("motte and bailey")]#text("” fallacy, for instance by using vaguely described notions of an event ")#mi("E")#text(" and hypothesis ")#mi("H_0, H_1")#text(" to downplay or exaggerate the various ingredients (ii), (iii), (iv) that are implicit even in a qualitative discussion.")

#text("As I have already stressed in the original post, the conclusions of a mathematical analysis can only be applied when the hypotheses of that analysis are reasonably accurate (with the extent to what constitutes “reasonable” depending on the robustness of the analysis). This is an important caveat, and critical examination of the underlying hypotheses of an analysis is to be highly encouraged, alongside mathematicial critique of the analysis itself. I like your idea of assigning “reasonable confidence intervals” to various intermediate probabilities such as ")#mi("{\\bf P}(H^{\\prime}_0|H_0)")#text("; this again I think is a way to move the discussion forward and quantify the level of certainty or uncertainty present in the analysis.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-686707")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2024")])]

#text("In 2017, the voting machine company told us the turnout was overstated by at least 1M votes. I wonder if they are using turnout manipulation (?). Just a notion as I was reading your analysis. For some reason, they needed/wanted the long-standing voting machines’ software for three more elections (somewhat secretly done) in 2017…2018…I do think it is far-fetched that any country would “loose” raw vote totals in passing information along — perhaps a bit less so if one wanted to deceive. Too sloppy, a bit silly (?)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Manipulated by whom ? : “The highest electoral authority reported that the data transmission system suffered a sabotage attack, which adversely delayed the transmission of the electoral results of the 2024 Presidential Election. In this regard, it was stated that an immediate request was made to the Prosecutor General of the Republic to initiate an investigation into the terrorist actions against the electoral system, polling centers, and electoral officials.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685475")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Sabotage is a plausible competing hypothesis, let’s call it ")#mi("H_2")#text(". It is important to state these hypotheses precisely in order to do any analysis, so I propose")

#mi("H_2")#text(": A foreign government hacked into the data transmission system of the electoral agency and was able to gain the ability to manipulate at least some of the electoral data.")

#text("In order for this to be a plausible alternate explanation, we need a causal chain of events such as ")#mi("H_2 \\implies H^{\\prime}_2 \\implies H^{\\prime\\prime}_2 \\implies E")#text(" that would then lead to the specific outcome ")#mi("E")#text(" that was observed, namely that the hack would somehow produce reported electoral results that were almost exactly rounded percentages, and that no finer breakdown of the results (e.g., by electoral district) were reported. I don’t immediately see a candidate such causal chain that has a non-negligible ")#emph[#text("a priori")]#text(" probability; do you have one in mind? (To put it another way: what is a plausible motivation for said foreign government to select a manipulation procedure that would result in totals arising from round percentages, rather than a more subtle manipulation that would not raise such obvious red flags?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685476")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("I don’t find the sabotage hypothesis that plausible but it’s absurd to object to it on the grounds that the manipulation would be too obvious while simultaneously ignoring the same objection in the case of potential manipulation from the Maduro government, especially considering that the opposition was loudly proclaiming that they would allege fraud if they didn’t win.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685477")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Well, the difference here is that the hypothesis ")#mi("H_2")#text(" already presumes an extremely high level of competence on the part of the foreign government, in that they were able to hack into the electoral commission of another country without being detected. (cf. the rhetorical tactic of casting one’s enemies as simultaneously “too strong” and “too weak”). In contrast, the hypothesis ")#mi("H_1")#text(" presumes authoritarian control and some degree of corruption, but does not otherwise presume competence.")

#text("But, assumptions of competence aside, perhaps a better argument is the following. As discussed in the post, the conditional probability estimate ")#mi("{\\mathbb P}(E|H_0) \\approx 10^{-8}")#text(" was valid under very general hypotheses – basically, that the vote outcomes was distributed in a region such as ")#mi("[p-\\varepsilon,p+\\varepsilon] \\times [q-\\varepsilon, q+\\varepsilon]")#text(" where the margin of error ")#mi("\\varepsilon")#text(" was significantly larger than the accuracy ")#mi("0.001")#text(" of the round percentages. Pretty much any manipulation effort I can think of would focus on shifting the center ")#mi("(p,q)")#text(" of this distribution rather than reducing the margin of error ")#mi("\\varepsilon")#text(". So one would expect ")#mi("{\\mathbb P}(E|H_2)")#text(" to also be about ")#mi("10^{-8}")#text(" in most sabotage scenarios, leading to no elevation in the odds of this hypothesis. About the only scenario I can think that would work here to elevate this hypothesis ")#mi("H_2")#text(" is if the foreign infiltrator was able to spoof the first step ")#mi("H^{\\prime}_1")#text(" in the causal chain ")#mi("H_1 \\implies H^{\\prime}_1 \\implies H^{\\prime\\prime}_1 \\implies E")#text(", namely that if the foreign agency was somehow able to impersonate Maduro and convince the electoral agency to report votes according to prescribed percentages. But this would have been found out almost immediately.")

#text("(Another consideration against the foreign infiltration hypothesis is that such an agency would presumably be not a supporter of the incumbent administration, and would therefore be motivated to produce results leading to a electoral defeat rather than an electoral victory.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685481")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("I don’t think anyone disputes the part that can be shown (at least intuitively) by simple arithmetic (and which more advanced math confirms) that the reported raw tallies are not real. What remains is the question of why (I.e. was it honestly imputed).")

#text("And that question, as I think you demonstrate, rests entirely on your prior beliefs and the uncertainty about them. Dressing that fact up in mathematics serves to obscure the issue and conveys, intentionally or otherwise, an air of objectivity and certainty that does not exist.")

#text("And this is more than a fun math puzzle, the consequences for Venezuelans are very serious. Given the history in the region I think you want to ask yourself (on a personal moral level, of course their will be no professional consequences)whether you want to potentially contribute to an illegal overthrow of a democratically elected government.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685499")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("I think the real world consequences of an event like this are precisely the reason why we should have more mathematical analysis of the situation, rather than less, specifically in order to isolate, test, and inspect the hypotheses and assumptions that such an analysis rests on. Without quantitative analysis, I find that discussions on such topics tend to degenerate to unproductive political rhetoric. In contrast, I think the current discussion here has been quite productive in evaluating said hypotheses and updating them. In particular, in addition to the original two hypotheses of “random chance” and “preselected percentages”, we now have a third viable hypothesis of “incompetent data handling” that we can usefully compare against the other two hypotheses and move the discussion forward. For instance, it would now be of interest to look at past election announcements by the CNE and see if similar rounding anomalies were present in those prior announcements. If such rounding is systemic, this gives increased credence to the incompetence hypothesis; however, if it is unique to this current election, this then gives relative elevation to the preselected percentage theory. As I noted in my other comment, the existence of a similar rounding error in the second announcement does hint at a systemic problem with the internal workflow at the CNE of preparing the official announcements of the most consequential and high-profile election in Venezuela. Even if such a problem does not rise to the level of outright fraud, it is at the very least highly unprofessional, and is a non-trivial issue that deserves to be discussed and highlighted. Also, I hope we can agree that the timely release of precinct-level electoral results (which would have largely eliminated this whole issue occurring in the first place) should be strongly encouraged.")

#text("The relationship between mathematics and the real world is a complex one. It is certainly a mistake to believe that a real-world question can be fully resolved by a purely mathematical analysis. However, it is also a mistake to believe that mathematics has and should have no role whatsoever in a real-world issue. What mathematics does is to identify what hypotheses are required to justify a given conclusion. This allows one to shift the discussion from a discussion of the conclusion (which often subjectively influenced by one’s feelings on the conclusion), to a discussion of the hypotheses, which can often be done in a more objective fashion, and can narrow the scope of disagreement between people who have reached different conclusions from the same data. In this particular case, it seems that we have narrowed the discussion to the possible level of bureaucratic incompetence at the CNE, which I think is an improvement over, say, discussing potential conspiratorial involvement by foreign governments.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685472")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("If I understand correctly, the main reason why H1 could potentially make sense is because of the exact numbers of votes each candidate recieved.")

#text("Could you provide any kind of election results for which this theoretical argument would make no sense? (I fail to understand what is so special about these exact numbers).")

#text("Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("There is some new information as of yesterday that changes the analysis somewhat. As it turns out, <A HREF=”")#link("https://www.youtube.com/watch?v=pB7g4y4M4s8")[#text("https://www.youtube.com/watch?v=pB7g4y4M4s8")]#text("“>the original announcement</A> from July 28 was a provisional one in which only 80% of the votes had been counted. On Aug 2, a <A HREF=”")#link("https://www.youtube.com/watch?v=JUpJvh0kn9g")[#text("https://www.youtube.com/watch?v=JUpJvh0kn9g")]#text("“>new announcement</A> was made, in which updated totals were provided: according to the announcement, there were now 12,386,669 votes received, of which Maduro received 6,408,844 (~ 51.7398%) and Gonzales 5,326,104 (~42.998%). The round percentage anomaly for these votes is no longer present (Gonzales’ percentage is somewhat close to 43%, but not so close to raise significant red flags). On the other hand, the announced number of invalid votes (explicitly stated by the CNE president at 4:37 as 50,785) is precisely 0.41% rounded to the nearest integer.")

#text("On the one hand, this actually supports to some extent the alternate causal explanation ")#mi("H_0 \\implies H^{\\prime}_0 \\implies H^{\\prime\\prime}_0 \\implies E")#text(" that in the first announcement, and in a portion of the second announcement, the vote statistics were initially communicated in terms of percentages, rounded and then reconverted back to imputed vote counts without rechecking against the raw data. The value of 50,785 for the number of invalid votes reported in the second report is inconsistent with the other statistics reported; if one subtracts the reported votes each candidate received from the total number of votes, one obtains 50,335 (~0.406%) rather than 50,785. This suggests (consistently with ")#mi("H_0 \\implies H^{\\prime}_0 \\implies H^{\\prime\\prime}_0 \\implies E")#text(") that the invalid vote count was somehow converted to a percentage, rounded up, and then reconverted back to a (slightly incorrect) vote count in the official announcement, and it becomes more plausible that a similar sequence of events occurred in the original announcement.")

#text("On the other hand, the alternate causal chain ")#mi("H_1 \\implies H^{\\prime}_1 \\implies H^{\\prime\\prime}_1 \\implies E")#text(" is still viable; one can posit that having been caught out with artificial vote counts the first announcement, that the CNE was more careful the second time around to not repeat the same mistake, but were careless with regards to the invalid vote statistics. The fact that a breakdown of voting results by precinct remains unavailable also continues to elevate this causal chain over the alternatives. Nevertheless, there is now a plausible competing theory ")#mi("H_0 \\implies H^{\\prime}_0 \\implies H^{\\prime\\prime}_0 \\implies E")#text(" to take into consideration.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685482")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("The new information is completely useless because as you say, if it was fraud, they would have corrected the mistake.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685483")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("(they would have obviously corrected it after it was pointed out to them)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d213d49715135e8108a71b536b66bf2fcbbd786d67e31dcdef78c6ee16e0038-62b981a06386a6df056bc9688f8a71a5fe156d1349550abff93af918d4cd9ca4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marios K.")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685484")[#strong[#text("Marios K.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Thanks for the interesting analysis.")

#text("Would it be possible to clarify what would be the “numerical anomaly” in the first place though? Shouldn’t the percentages correspond to the actual votes?")

#text("So doing 5150092/10058774 = 0.5119999, which is 51.2%. Then, when someone does the inverse (multiply the total number with the percentage) wouldn’t they expect to get the specific number of votes?")

#text("It seems I’m misunderstanding something")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685487")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("No if you round the percentage the corresponding tally would change. That is the tally corresponding to 51.2% and 51.234% are different.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7d213d49715135e8108a71b536b66bf2fcbbd786d67e31dcdef78c6ee16e0038-62b981a06386a6df056bc9688f8a71a5fe156d1349550abff93af918d4cd9ca4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marios K.")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685490")[#strong[#text("Marios K.")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Where does the 51.234% come from?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685491")[#strong[#text("What are the odds, II: the Venezuelan presidential election cashew22 on")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")]

#text("[…] Article URL: ")#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/")[#text("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Magnificent Professor Tao")

#text("Do you have this either on pics like a blackboard with graphics or an excel a Venn’s diagram")

#text("I find your analysis wonderful I would like to learn more")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685493")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Analysis is tainted because you knew at the outset the outcome you want to get.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685494")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2024")])]

#text("Prof. Steve Miller did an analysis using Benford’s law.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685497")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("For the sake of argument, rather than viewing “multiple of 1/1000” as an anomaly, one could also view “multiple of 1/999” and “multiple of 1/1001” as anomalies. If one accepts that “multiple of 1/k” is an anomaly whenever k is in the range [750, 1249], then it is unlikely that any election with 10 million voters can avoid all 500 anomalies. There have been at least 500 elections worldwide so far with roughly ten million voters. So it would not be unlikely that a “multiple of 1/1000” anomaly was detected in Venezuela.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685501")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("Let’s use ")#mi("E^{\\prime}")#text(" to denote your alternative proposed anomaly “percentages are an integer multiple of ")#mi("1/k")#text(" for ")#mi("k \\in [750,1249]")#text("“. It is true that ")#mi("{\\mathbb P}(E^{\\prime}|H_0)")#text(" of ")#mi("E^{\\prime}")#text(" occurring under the null hypothesis ")#mi("H_0")#text(" is about 500 times larger than ")#mi("{\\mathbb P}(E|H_0)")#text(" (and significantly larger still, if as you suggest, we allow consideration of all elections occurring worldwide this year (say), rather than just the Venezuelan election). On the other hand, the probability of ")#mi("{\\mathbb P}(E^{\\prime}|H_1)")#text(" occurring under the alternative hypothesis is more or less identical to that of ")#mi("{\\mathbb P}(E|H_1)")#text(", since while it is conceivable that authorities might direct the electoral commission to report a specific round percentage such as ")#mi("51.2\\%")#text(", it is not plausible that they would direct that commission to report a specific fraction such as ")#mi("511/999")#text(". So, an observation of the event ")#mi("E^{\\prime}")#text(" would not elevate the odds of hypothesis ")#mi("H_1")#text(" to anywhere near the extent that the event ")#mi("E")#text(" would. (Incidentally, this is a similar situation to that of the Phillipine lottery discussed in the previous blog post.)")

#text("This is a good demonstration, by the way, of how selective reporting of events can affect the updating of odds. If one was only informed of the event ")#mi("E^{\\prime}")#text(" but was unaware of the event ")#mi("E")#text(", then no significant suspicions would be raised, and one could indeed explain ")#mi("E^{\\prime}")#text(" as a coincidence. But if one knew the more refined information ")#mi("E")#text(", then as discussed in the post, this causes the relative odds of the random chance hypothesis to go down significantly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685503")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2024")])]

#text("I agree. I just wanted to outline the devil’s argument regarding the sensitivity of the final odds to the “1/1000 multiples are fishy” criterion. Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685516")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2024")])]

#text("Very interesting post with good good for thought. The general question of “detecting lies with statistics” is very interesting and very tricky.")

#text("Here is a 2006 ")#link("https://gilkalai.wordpress.com/wp-content/uploads/2020/06/ester.ppt")[#text("power point presentation entitled ")#strong[#emph[#text("How to detect lies with statistics")]]#text(" by Maya Bar-Hillel.")]#text(" It described a planned research project (that at the end was not pursued) of Maya Bar-Hillel with Yossi Rinott, David Budescu and myself. The presentation contains various interesting examples.")

#text("Bar-Hillel’s title is taken after the famous book by Farrell Huff “How to lie with statistics”. A famous quip by Fred Mosteller referring to Huff’s book was: “It is easy to lie with statistics, but easier to lie without them.” Maya’s own conclusion was that: “It is possible to detect (some) lies with statistics, but easier to detect them with other means”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685517")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2024")])]

#text("It is clear to all and does not need extensive calculations, that Maduro regime is not particularly democratic, and will win any election in Venezuela one way or another. But at least Maduro regime does not commit a genocide live on tv like US, UK, or Israel does, on which you are deafeningly silent.")

#text("Plainly it is easier to discuss and condemn evil that cannot hurt you like the Maduro regime, or evil that has already been beaten by others like Nazis.")

#text("You are just one conformist human being among billions of others, engaging in cheap intellectual tricks while the most disgusting event of history is unfolding right before our eyes.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685518")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2024")])]

#text("On the contrary, Terry failed to post after October 7 like he posted after the invasion of Ukraine. If anything he is too left-wing. Anyway, it is Hamas that’s genocidal.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685520")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2024")])]

#text("To put thing in perspective, Terry did sign some sort of open letter of condemnation for the October 7 atrocities but, as far as I know, has not signed anything similar for the post October 7 atrocities.")

#text("I sincerely believe Terry would have signed both had it not been the high likelihood of the hypothesis that signing the latter is career/relationship damaging.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685975")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2024")])]

#text("What’s the point of this? You seem to be saying that the analysis is correct, that the Maduro government probably manipulated the election results. Are you going to go to the social media of all those billions of people to criticize them for not publishing anything criticizing the Israeli invasion of the Gaza Strip? Maybe if Terry had said that the Venezuelan elections were “the most disgusting thing in history,” your comment would be apropos.")

#text("By the way, while certainly what is “most disgusting” is subjective, so I can’t really say that the Israeli atrocities in the Gaza Strip, with a confirmed death toll of over 40,000 and probably a real death toll at least several times higher, are objectively not the most disgusting thing in history, there are events that have killed many more people (the Holocaust, King Leopold’s administration of the Belgian Congo, even the US invasion of Iraq on the somewhat lower end), events that have killed people at a much higher temporal rate (the firebombing of Tokyo, the atomic bombing of Hiroshima and Nagasaki), events that killed people in particularly horrible ways, events that wiped out entire peoples, events, and so forth. So while I would definitely agree with “disgusting,” “most disgusting event in history” is certainly a more contentious label.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685826")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2024")])]

#text("Dear kind soul, I would like to gently remind you that we all recognize the hurt from October 7th – yet we also recognize that hurting others back is not necessary for healing. This is not to say that the October 7th attack is in any way to be condoned; there were people massacred and people are rightfully angry. Yet also recognize that we humans are one species, and we all share a common story. Each of us can influence that story, through division or through unity.")

#text("Which one will you choose?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685519")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2024")])]

#text("Not sure if you have seen the final results presented by the Venezuelan government:")

#align(center)[

]

#text("candidate;votes")#linebreak()#text("null;50785")#linebreak()#text("Maduro;6408844")#linebreak()#text("Gonzales;5326104")#linebreak()#text("Luiz Martins;152360")#linebreak()#text("Antonio;116421")#linebreak()#text("Benjamim;92903")#linebreak()#text("Jose Brito;84231")#linebreak()#text("Javier;64452")#linebreak()#text("Claudio;40902")#linebreak()#text("Marquez;29611")#linebreak()#text("Ceballos;20056")

#text("with the final number of votes for all candidates. Spoiler: no perfect coincidences here as before, but the results are still odd. Maybe you want to do your own analysis before seeing mine, but in case you are interested:")

#link("https://www.facebook.com/danielvictor.tausk/posts/pfbid02AjoTU2vV4rJp22pMV97QK89taYUdGP9acegV6SWnLNeYCP1WTtzTvbJeh6MseyLfl")[#text("https://www.facebook.com/danielvictor.tausk/posts/pfbid02AjoTU2vV4rJp22pMV97QK89taYUdGP9acegV6SWnLNeYCP1WTtzTvbJeh6MseyLfl")]

#text("(it is in portuguese, but you can get automatic translation).")

#text("Spoiler: I strongly suspect they knew people were commenting about the perfect coincidence on the internet, so this time they invented percentages with two decimal places, calculated the number of votes and then changed the numbers a little bit to make they look more realistic. But they didn’t change the numbers enough. My test yields a p-value of around 1 in a million. I then successfully validated the test in more than 10 thousand Brazilian elections:")

#link("https://www.facebook.com/danielvictor.tausk/posts/pfbid0nHoGEbLHCfZ1TuypiMFmURBrrBYMhN2ug1TCJCCPYpJaPmqznxb8deSTMfp8uSwQl")[#text("https://www.facebook.com/danielvictor.tausk/posts/pfbid0nHoGEbLHCfZ1TuypiMFmURBrrBYMhN2ug1TCJCCPYpJaPmqznxb8deSTMfp8uSwQl")]

#text("Daniel Tausk")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4d982784b9831d1c4b11982b62a5da5af40e9e9122c681a5554b03d550fca2e-ce98b74d14adc3f0aa29743aa6519e70f9f8d12f5279f62877a2df40eb81c649.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hollis Williams")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685527")[#strong[#text("Hollis Williams")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2024")])]

#text("Hi Terry, just to point out the name of the politician is Edmundo González, not Edmundo Gonzáles.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685529")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2024")])]

#text("Being unaware of the misrepresentations and crimes of one’s own government is the most likely hypothesis here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685550")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("Dr. Tao — this is nonsense and quite beneath you.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685551")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2024")])]

#text("You’re grasping: “As I noted in my other comment, the existence of a similar rounding error in the second announcement does hint at a systemic problem with the internal workflow at the CNE of preparing the official announcements of the most consequential and high-profile election in Venezuela.” The “systemic problem with the internal workflow” could be this: compute percentages based on votes per candidate / total votes and report votes as percentages times the total vote count, “rounded” to preserve sum (introducing negligible error). The fact that it happened the same way twice indicates that there’s an algorithm being followed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685571")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2024")])]

#text("I highly dislike this kind of analysis (if it is actually applied to reach a conclusion or to sway one way or the other) since it is NOT empirical since it depends on gut feeling numbers which are not derived by empirical means nor are tested empirically. Mathematical models of real world problems should be judged on how they perform empirically (if they are not specifically, for example (there are more exceptions), designed for theoretical purposes) – if this can’t be done they should be considered only with great caution and most likely the model is of little practical use. What is the use of a model which can’t be empirically tested (as noted there are exceptions)? I highly doubt that the model + the info above gives us any more knowledge than just the info alone.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685618")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2024")])]

#text("*Whether or not fraud was committed*, the published result reflects stupidity, incompetence and unreliability at several levels (either percentages were fraudulently preset and nobody thought of fudging the invented numbers a little, or the election was not grossly fraudulent, totals were calculated, percentages were computed, only percentages were communicated, and someone deduced spurious totals from them and published them instead of the actual totals).")

#text("Come to think of it, that level of stupidity and unreliability is a sufficient explanation, so this event doesn’t increase the probability of fraud as much as I thought. Uh. Thanks for helping me think this through.")

#text("(Personally, not being naïve, I still strongly suspect fraud, as does much of the Latin American left.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2024")])]

#text("Can you now calculate the odds that Israel is committing genocide? Or would you lose your comfortable UCLA position for doing that?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685949")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2024")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("Given that")

#align(center)[
#mi("138,339 = 153,710 - 15,371")
]

#text(", a plausible explanation here is that at some earlier point in time, the correct value of")

#align(center)[
#mi("15,371")
]

#text("was input into the running unofficial real-time tally for the Biden vote in this county, but at some later time, when an updated set of data was uploaded, an incorrect value of")

#align(center)[
#mi("153,710")
]

#text("was input, overwriting the previous (correct) count and causing the temporary spike in unofficial real-time tally by")

#align(center)[
#mi("138,339")
]

#text(", which was subsequently corrected some minutes afterwards (and in any event did not make it into the official certified tally, which came several days afterward and presumably came with more thorough data checking safeguards than the real-time tally).")
]

#text("(excuse me for commenting here, since my previous comment did not show up) Right, that’s definitely a possibility. But it would require the staffs who double check the vote to make sure the votes are enter correctly to be even more error prone than the staffs who enter the number initially.")

#text("I’m not gonna claim whether it’s likely or not since I’m not trying to start an argument here. But each people’s judgment of the magnitude of P(H2 | E2) definitely has their own faith in the system baked into it. Thus some people’s questioning of the justness of the election process is not totally baseless.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685954")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2024")])]

#text("In this scenario, it is only the staff who entered in the data to the unofficial tally who were careless; no error needs to be made on the part of the certifying staff. More precisely, a plausible timeline is as follows:")

#text("On the day of the election:")#linebreak()#text(" * A county staff member responsible for uploading data to the unofficial tally for that county correctly inputs 15,371 into that tally as the results come in.")#linebreak()#text(" * At some later point on time, the data is updated, overwriting the previous tally, but this time the input was incorrectly given as 153,710 due to a manual data entry error. This makes its way to the real-time aggregate displays on various news sites, causing the suspicious-looking spike.")#linebreak()#text(" * A few minutes later, the staff realizes the error and corrects the input back to the correct version of 15,371 (perhaps as part of a larger data update), bringing the tally back to the correct value.")

#text("Several days after the election:")#linebreak()#text(" * The data is double-checked to be correct and entered into the certified record.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685960")[#strong[#text("Terence Tao, matemático: “La probabilidad de autenticidad de los resultados electorales en Venezuela es de 1 entre 100 millones” | Ciencia – Información Center")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")]

#text("[…] matemático a enigmas de actualidad, como las recientes elecciones presidenciales de Venezuela. En su blog, el matemático llamó la atención sobre los resultados oficiales, con porcentajes extrañamente […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685964")[#strong[#text("Terence Tao, matemático: “La probabilidad de autenticidad de los resultados electorales en Venezuela es de 1 entre 100 millones” - Candil Digital | El lucero que ilumina las noticias del mundo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")]

#text("[…] matemático a enigmas de actualidad, como las recientes elecciones presidenciales de Venezuela. En su blog, el matemático llamó la atención sobre los resultados oficiales, con porcentajes extrañamente […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685965")[#strong[#text("Terence Tao, matemático: “La probabilidad de autenticidad de los resultados electorales en Venezuela es de 1 entre 100 millones” - Periódico Interactivo | La interacción es la base de la sociedad")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")]

#text("[…] matemático a enigmas de actualidad, como las recientes elecciones presidenciales de Venezuela. En su blog, el matemático llamó la atención sobre los resultados oficiales, con porcentajes extrañamente […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685966")[#strong[#text("Terence Tao, matemático: “La probabilidad de autenticidad de los resultados electorales en Venezuela es de 1 entre 100 millones” - BrujulaInformativa - La dirección hacia la verdad")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")]

#text("[…] matemático a enigmas de actualidad, como las recientes elecciones presidenciales de Venezuela. En su blog, el matemático llamó la atención sobre los resultados oficiales, con porcentajes extrañamente […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685969")[#strong[#text("El mejor matemático del mundo calculó que hubo fraude en las presidenciales – EspNews24")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")]

#text("[…] Terence Tao analizó lo que sucedió en las elecciones del 28 de julio. Lo hizo a nivel estadístico y de resultados. El experto suele aplicar esta ciencia a temas de actualidad a través de su blog. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685970")[#strong[#text("Terence Tao, matemático: “La probabilidad de autenticidad de los resultados electorales en Venezuela es de 1 entre 100 millones” -")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")]

#text("[…] matemático a enigmas de actualidad, como las recientes elecciones presidenciales de Venezuela. En su blog, el matemático llamó la atención sobre los resultados oficiales, con porcentajes extrañamente […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685971")[#strong[#text("Terence Tao, matemático: “La probabilidad de autenticidad de los resultados electorales en Venezuela es de 1 entre 100 millones” - VozUniversal | Periódico que le da voz a todo el universo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2024")]

#text("[…] matemático a enigmas de actualidad, como las recientes elecciones presidenciales de Venezuela. En su blog, el matemático llamó la atención sobre los resultados oficiales, con porcentajes extrañamente […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-685976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2024")])]

#text("Can electoral fraud be demonstrated through Bayesian analysis?")

#text("Please see the book “The Power of Math: The Venezuelan Electronic Voting System that spread througout the world”.")

#link("https://www.amazon.es/Power-Math-Guillermo-Salas/dp/B0DBZFZ7KF")[#text("https://www.amazon.es/Power-Math-Guillermo-Salas/dp/B0DBZFZ7KF")]

#text("Have the mathematics the power to decipher how the electronic voting system imposed by Chavismo in Venezuela works?")

#text("In 2004, a referendum was held in Venezuela on which the permanence of Hugo Chávez in the presidency of the Republic depended. The official result gave him the victory and thanks to that he was able to remain in power. This was the debut of the voting machines of Smartmatic.")

#text("The lack of transparency that marked that event left many Venezuelans with the feeling of fraud. Several groups of academics produced writings that show evidence, based on statistical mathematics against the veracity of the results that the machines had given.")#linebreak()#text("Some of them were published by important scientific journals such as International Statistical Review and Statistical Science.")

#text("Smartmatic began a vertiginous expansion that led it to become a world leader in voting automation. This started only seven months after that referendum with the purchase")#linebreak()#text("of Sequoia Voting System, a company that years later would become the property of Dominion Voting System. For all this, deciphering how the voting machines that debuted in the Venezuela governed by Chávez work is a relevant and global issue.")

#text("Throughout this book, its author Guillermo Salas physicist and co-author of the article Analysis of the 2004 Venezuela Referendum: The Official Results Versus the Petition Signatures published by Statistical Science, shows a series of facts that allow the reader to answer by themselves if the mathematics have the power to decipher how this voting")#linebreak()#text("system works or not. It does it using simple, intuitive and enjoyable language, which does not require specialized knowledge from the reader.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/98bcf4357fae4d8bac33abdb8719473f4aa9a1350badf870f27721857701b6d4-d59e91f2807b9b8ec64b7df769b620c852c056bf08ffca58255da7606eef7f71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Day")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-686500")[#strong[#text("Daniel Day")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2024")])]

#text("Does this Bayesian argument apply equally to the disputed Georgian parliamentary elections, or does that case merit a similar argument of its own?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-686508")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2024")])]

#text("Here the situation is much more complicated, because there is a lot more data present with the Georgian elections, in contrast to the Venezuela election where basically only one data point was produced (the claimed national vote totals, with no breakdown into precincts). My understanding is that the irregularities here were not primarily coming from numerical anomalies in the reported totals, but rather from discrepancies with exit polling, which can in principle still be analyzed from a Bayesian perspective, but would require a significantly more sophisticated statistical analysis than the one used in this blog post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55c1e1651c14e17b128ccdc73e9c75e3964ec7ee09d46ab8c50cd926ebf34bcf-822591e9478384bd1210fb6f297a7ca1ef0169875ddb3898c666d26edf087662.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ogechi")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-686506")[#strong[#text("Ogechi")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2024")])]

#text("One can always come with an interesting sequence of numbers any given list of integers might be part of. The probability of the sequence to occur depends on one’s sophistication only. The more one is sophisticated, the more paranoid one might become.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1db1103c601de4c64620e806b5b13ee6b98927b75e9a05ecba1e0fc20b96c02-f87e6cc404bd168b676e468928cc2b396798a12554359e4aa6308c44847bb247.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Celina Summers")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-686571")[#strong[#text("Celina Summers")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2024")])]

#text("I think the analysis is fatally flawed because the irrelevant question is asked.")

#text("The relevant question would be: what is the average time span during which an established lottery from all over the world draws the combination to be considered unusual enough. There are many established lotteries around the world, they make many draws per year, and there are a lot of unusual combinations (think of all the consecutive ones etc).")

#text("The same applies to elections.")

#text("If the calculated time span is much longer than what is actually observed, then one can start wondering if there is any faul play involved.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-686576")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2024")])]

#text("Well, the Venezuelan presidential election has one feature that most other elections don’t: in this particular case, the final election results were reported only as aggregate national numbers, with no breakdown into precincts (or indeed any other supporting data) provided. For most elections in which such breakdowns are provided, and the aggregate national numbers are simply the sum of the precinct-level numbers, then any numerical anomalies in the national numbers are more or less equally explainable by random chance and by electoral manipulation hypotheses, and even extremely rare numerical coincidences would show up eventually at either national or precinct levels for one of the many elections that occur worldwide, similar to the situation with lotteries. But here, it is the one of the very few elections for which precinct-level breakdowns were never provided that also contained the rare numerical anomaly in the reported total, and this is much harder to explain by chance than by either a electoral manipulation hypothesis or an incompetent electoral administration hypothesis.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ca1c63b077d2a55a179d29747943259f2432c92df56fcf7952e024e6ee27d06-c313af2c90ba93db92707f0c1c019505b541cde77c023916c40bb33822fd7e9a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Est-ce qu’une serviette peut changer le cours de l’histoire d’une Nation ? – Unión Gran Venecia")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-686777")[#strong[#text("Est-ce qu’une serviette peut changer le cours de l’histoire d’une Nation ? – Unión Gran Venecia")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2024")])]

#text("[…] L’annonce de son contenu a été faite par diffusion radio, tv, internet la nuit, déjà le 29/7/2024. Ce premier bulletin a été donné, relayé avec les résultats donnés dans la serviette et extrapolés les nombre de votes au pourcentages (La démonstration de que cela fut ainsi, de que la probabilité de cette Hypothèse 1 (H1), i.e., la manipulation du résultat ainsi, est ici en lien qui suit, en anglais, sans état d’âme, par une pure analyse mathématicienne et de probabilités versus l’Hypothèse 0 (H0), celle de la non manipulation ")#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/")[#text("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/")]#text("). […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aadab578296db33beb9679774564fbe432989194ae7ab63ec3f3a8ba1b226119-69bf241915c186327830aab9dd3792b30b705e738a99b727ffb29da0b9921763.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kingdomfortunately34d2cab1c7")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-688043")[#strong[#text("kingdomfortunately34d2cab1c7")]]#text(size: 9pt, fill: rgb("596477"), " · 15 May 2025")])]

#text("Hello there! Greetings from Ecuador. I loved this post. Math has the ability to uncover harsh truths that would remain otherwise hidden from the public eye.")

#text("I just wanted to share an article I found recently that manages to demonstrate a bad practice just with math:")

#link("https://economics.sas.upenn.edu/system/files/2019-07/SSRN-id3241707.pdf")[#text("Killer acquisitions")]#text(". By Colleen Cunningham, Florian Ederer, and Song Ma.")

#text("It is beautiful. They show that pharma companies are more likely (I interpret it that way, maybe I am wording it incorrectly) to TERMINATE a drug development project that they acquire from another company if it overlaps with their own drug development projects. To prove this, they had to compare it with the rate of drug development advancement in the general population of these type of companies. Any thoughts on this? What could have they done better?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-689486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2025")])]

#text("Dr Tao,")

#text("“witholding” should be “withholding”. ")#emph[#text("[Corrected, thanks – T.]")]

#text("I would like to ask: why you don’t use the tool of “p-values”? I guess the reason is p-hacking. So now I am unclear about what exactly does p-values convey in practice?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-689505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2025")])]

#text("Broadly speaking, p-values have scientific value as long as one has committed to using (and disclosing) them on specific experiments prior to the experiment being conducted, but are unreliable for ad hoc use after an experiment (or uncontrolled event) has occurred, due to issues such as p-hacking. In particular, they are quite difficult to apply with any degree of meaningfulness to current events, unless one sets up the methodology for doing so before the events are to take place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-689513")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2025")])]

#text("Dr Tao, regarding your point that p-values are unreliable for “ad hoc use after an experiment”:")#linebreak()#text(" Is this intuitively the same as the “Texas Sharpshooter Fallacy”? (where one paints the bullseye around the bullet holes only after the shots are fired to claim accuracy.).")

#text("Also I find p-values confusing because the math formula is the same whether I planned it or not. Thus I don’t know what “scientific value” changes in this way.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-689532")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2025")])]

#text("If you do an experiment and measure 100 variables, the probability of one of them deviating from an expectation is very high, and that’s exactly what p-hacking is. You measure everything, and publish the one thing that randomly falls outside of the norm as significant. When you do this, the p-value doesn’t represent what it’s supposed to represent, i.e.: the probability of obtaining the result under H0, because you built H0 a posteriori. You are, as you cleverly pointed out, drawing a target around the bullet holes.")

#text("When used correctly, you state your hypothesis H0 about a single variable, run your experiment, and compute your p-value. Only then you can trust that the p-value represents what’s supposed to represent. Always, of course, keeping in mind that the p-value represents a likelihood, not a certainty. That’s why you always repeat experiments, and why publication bias (i.e.: not publishing negative results) screws with the validity of p-value.")

#text("On its own, there’s nothing wrong with the p-value, it’s just maths. But like with all maths, you work from a premise, and if you violate the premise, your conclusions won’t follow.")

#text("I’m not as eloquent as Terry, but I hope this helped (and hopefully Prof. Tao will correct any mistake I may have made, I’m not a mathematician, I just use this type of maths a lot).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2024/08/02/what-are-the-odds-ii-the-venezuelan-presidential-election/#comment-689607")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2026")])]

#text("“Using statistics to search for evidence of fraud or anomalies is a respected forensic tool in established democracies. In Brazil, however, publishing a paper applying the ")#strong[#text("Cochran-Mantel-Haenszel (CMH) test")]#text(" to our 2022 election data would likely land the author in a prison cell—right next to the January 8th protesters or former President Bolsonaro, who has become a primary target of political persecution.")

#text("For those unfamiliar, the CMH test is designed to analyze the association between two binary categorical variables while controlling for a third confounding variable (stratification). In our case, the variables are the ")#strong[#text("Vote Choice")]#text(" (Candidate 22 vs. 13) and the ")#strong[#text("Voting Machine Model")]#text(" (‘Pre-2020 models’ vs. ‘2020 model’).")

#text("Theoretically, the machine model should act like a fair coin or a fair die: it should not influence the voting outcome. Critics often argue: ‘But machines are distributed geographically, and each region has its own voter profile.’ That is precisely why the CMH test is necessary: it uses ")#strong[#text("location")]#text(" as the confounding variable to control for this.")

#text("The results are striking. It is statistically easier to defend that smoking for 50 years is NOT related to cancer than to claim there was ‘no statistical anomaly’ directing votes to a specific candidate in the older, less secure machines. Interestingly, this is the exact same group of machines that showed 100% log errors, as pointed out by the engineer Carlos Rocha (an alumnus of ITA, Brazil’s MIT) in the study commissioned by the PL party.")

#text("It is a tragedy that valid statistical inquiry has been criminalized here. If only a competent mind or a renowned neutral institution would take this seriously and run the numbers…")

#text("Reference to the data and study: ")#link("https://github.com/JohnRobson/Eleicoes2022")[#text("https://github.com/JohnRobson/Eleicoes2022")]#text("“")
]
