// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/09/16/sair-competition-lean-kernel-challenge/
// Converted to Typst by tao2typ: "2026-10-14T15:21:20.377168+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "SAIR competition – Lean Kernel Challenge", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("SAIR competition – Lean Kernel Challenge")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 September 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/09/16/sair-competition-lean-kernel-challenge/")[#text("https://terrytao.wordpress.com/2026/09/16/sair-competition-lean-kernel-challenge/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("We’re excited to launch Stage 1 of the Lean Kernel Challenge, a multi-stage competition to improve the performance of verified computation in the Lean 4 kernel that the whole community can benefit from.")

#text("The Lean Kernel Challenge brings the community together to develop faster algorithms and better representations for verified computation. Through these collective contributions, the competition aims to support Lean’s development and benefit Lean users worldwide.")

#text("Verified computation uses the Lean kernel to check computational results as part of a proof. Stage 1 is the first, experimental stage of the series, beginning with fundamental problems. Later stages will cover a broader range of mathematical and scientific fields and more complex problems.")

#text("The Lean Kernel Challenge is inspired by the ")#link("https://github.com/leanprover/lean-kernel-arena")[#text("Lean Kernel Arena")]#text(", and we thank its contributors. Lean Kernel Arena benchmarks alternative Lean proof checkers; the Lean Kernel Challenge focuses on algorithms and representations for verified computation, beginning in Stage 1 with fixed tasks evaluated by a fixed Lean kernel.")

#text("Stage 1 features eight problems: Fibonacci, integer partitions, the Mertens function, prime counting, matrix permanent, Rule 110, SHA-256, and polynomial discriminant.")

#text("For each problem, develop an algorithm and prove in Lean that it matches the supplied specification for every input.")

#text("Submission deadline: November 20, 2026, 23:59 AoE (UTC−12).")

#text("Competition and submissions:")#linebreak()#link("https://competition.sair.foundation/competitions/lean-kernel-challenge")[#text("https://competition.sair.foundation/competitions/lean-kernel-challenge")]

#text("SAIR Playground:")#linebreak()#link("https://playground.sair.foundation/playground/lean-kernel-challenge")[#text("https://playground.sair.foundation/playground/lean-kernel-challenge")]

#text("Official repo:")#linebreak()#link("https://github.com/SAIRcompetition/lean-kernel-challenge")[#text("https://github.com/SAIRcompetition/lean-kernel-challenge")]

#text("Thank you for participating and supporting SAIR competitions!")

#text("Co-organized by Lean FRO and the SAIR Foundation.")#linebreak()#text("Organizing committee: Joachim Breitner, Leonardo de Moura, Kim Morrison, and Terence Tao.")

#heading(level: 1)[#text("Comments (1)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7c1cd903354450d0c8e6069406f2d99d2a58342de0b7c1015c6bf066acbfb0b5-657eb716c63b513efa244c369622c0386ad2695d24faf7fde046631946800dae.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brianbeverly1")]], [#link("https://terrytao.wordpress.com/2026/09/16/sair-competition-lean-kernel-challenge/#comment-695530")[#strong[#text("brianbeverly1")]]#text(size: 9pt, fill: rgb("596477"), " · 17 September 2026")])]

#text("I’ll give it the old college try.")

#text("Fibonacci reminds me of a series, like the zeta function, mapping curves over the number line.")

#text("Mertens’ function is interesting and has a ton of logs.")

#text("Rule 110 reminds me of Bernoulli for some reason. Like, all neighbors have to conserve a number, so if P increases somewhere along the streamline flow, then Velocity changes. Part of the problem is that pressure acts infinitely fast and is independent of time, instead of the speed of sound being 3.5 km/s in water. I think infinity is justified as an approximation since 3.5 km is a long stretch even for hydrologists, but it also means viscosity will physically catch pressure before velocity diverges.")

#text("The polynomial discriminant is interesting because the sign maps to real or complex numbers, and the roots are degenerate when it equals zero.")

#text("SHA-256 is interesting as a one-way map that converts any string into a fixed length of numbers, but it loses information in the mapping and generates entropy.")

#text("This is an interesting list. A core memory of mine is getting chewed out by a math prof in numerical analysis who also threatened to defenestrate my class on my birthday. Then he passed out a midterm. I’ve been chewed out before probably be chewed out again.")

#align(center)[

]
]
