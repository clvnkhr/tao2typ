// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/
// Converted to Typst by tao2typ: "2026-10-14T15:16:59.875085+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An inverse theorem for the uniformity seminorms associated with the action of F^infty_p", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An inverse theorem for the uniformity seminorms associated with the action of F^infty_p")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 January 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")[#text("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.ohio-state.edu/~vitaly/")[#text("Vitaly Bergelson")]#text(", ")#link("http://www.technion.ac.il/~tamarzr/")[#text("Tamar Ziegler")]#text(", and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/0901.2602")[#text("An inverse theorem for the uniformity seminorms associated with the action of ")#mi("F^\\infty_p")]#text("“. This paper establishes the ergodic inverse theorems that are needed in our ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("other recent paper")]#text(" to establish the inverse conjecture for the Gowers norms over finite fields in high characteristic (and to establish a partial result in low characteristic), as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem. ")]#text("Let ")#mi("{\\Bbb F}")#text(" be a finite field of characteristic p. Suppose that ")#mi("X = (X,{\\mathcal B},\\mu)")#text(" is a probability space with an ")#link("http://en.wikipedia.org/wiki/Ergodic_(adjective)")[#text("ergodic")]#text(" measure-preserving action ")#mi("(T_g)_{g \\in {\\Bbb F}^\\omega}")#text(" of ")#mi("{\\Bbb F}^\\omega")#text(". Let ")#mi("f \\in L^\\infty(X)")#text(" be such that the Gowers-Host-Kra seminorm ")#tao-math("\\left\\|f\\right\\|_{U^k(X)}", block: false)#text(" (defined in a ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("previous post")]#text(") is non-zero.")

#enum(start: 1, 
[#text("In the high-characteristic case ")#mi("p \\geq k")#text(", there exists a phase polynomial g of degree <k (as defined in the ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("previous post")]#text(") such that ")#tao-math("\\left|\\int_X f \\overline{g}\\ d\\mu\\right| > 0", block: false)#text(".")],
[#text("In general characteristic, there exists a phase polynomial of degree <C(k) for some C(k) depending only on k such that ")#tao-math("\\left|\\int_X f \\overline{g}\\ d\\mu\\right| > 0", block: false)#text(".")]
)
]

#text("This theorem is closely analogous to a similar theorem of ")#link("http://www.ams.org/mathscinet-getitem?mr=2150389")[#text("Host and Kra")]#text(" on ergodic actions of ")#mi("{\\Bbb Z}")#text(", in which the role of phase polynomials is played by functions that arise from nilsystem factors of X. Indeed, our arguments rely heavily on the machinery of Host and Kra.")

#text("The paper is rather technical (60+ pages!) and difficult to describe in detail here, but I will try to sketch out (in very broad brush strokes) what the key steps in the proof of part 2 of the theorem are. (Part 1 is similar but requires a more delicate analysis at various stages, keeping more careful track of the degrees of various polynomials.)")

#heading(level: 1)[#metadata(none) <tao-f5f600aff736fab7422e>#text("— A model case —")]

#text("The theorem needs to be proven for all functions f with non-zero Gowers-Host-Kra norm in all ergodic systems, but to simplify the exposition let us look at a fairly specific type of function in a fairly specific type of system. Namely, we will assume that the system X is a ")#emph[#text("circle extension")]#text(" ")#mi("X = Y \\times_\\rho S^1")#text(" of another ergodic ")#mi("{\\Bbb F}^\\omega")#text("-system Y by a ")#emph[#text("cocycle")]#text(" ")#mi("\\rho: {\\Bbb F}^\\omega \\times Y \\to S^1")#text(", i.e. a measurable function obeying the cocycle identity")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\rho(g+h,y) = \\rho(g,y) \\rho(h,T_g y)")]]

#text("for all ")#mi("g,h \\in F^\\omega")#text(" and almost every ")#mi("y \\in Y")#text(". The circle extension X is defined as the Cartesian product ")#mi("\\{ (y,u): y \\in Y, u \\in S^1 \\}")#text(" with shift map ")#mi("T_g: (y,u) \\mapsto (T_g y, \\rho(g,y) u)")#text(" (here we abuse notation a bit and use ")#mi("T_g")#text(" to simultaneously denote the action on X and on Y). The function ")#mi("f\\in L^\\infty(X)")#text(" we shall pick is the vertical coordinate function ")#mi("f(y,u) := u")#text(".")

#text("Finally, we make the assumption that the base space Y (or more precisely, its ")#mi("\\sigma")#text("-algebra) is already generated by phase polynomials of bounded degree.")

#text("Very roughly speaking, we can reduce the general case to the above case by an induction on k, together with some standard theory of Mackey and Furstenberg on isometric extensions and group extensions (cf. ")#link("https://terrytao.wordpress.com/2008/01/24/254a-lecture-6-isometric-systems-and-isometric-extensions/")[#text("my lectures")]#text(" on the topological dynamics counterpart to these topics), and of Furstenberg-Weiss on characteristic factors, together with some Fourier analysis to reduce matters from (abelian) group extensions to circle extensions. These reductions are standard in the ergodic theory literature, but somewhat technical, and I will not discuss them further here.")

#heading(level: 1)[#text("— Cocycles and coboundaries —")]

#text("Our task is to show that the vertical coordinate function ")#mi("f(y,u)=u")#text(", which we assume to have non-zero Gowers-Host-Kra seminorm, correlates with some bounded degree polynomial. To do this, it suffices to express the cocycle ")#mi("\\rho")#text(" in the form")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\rho(g,y) = P(g,y) \\Delta_g F(y)")]]

#text("for some measurable functions ")#mi("F: Y \\to S^1")#text(", ")#mi("P: {\\Bbb F}^\\omega \\times Y \\to S^1")#text(", where ")#mi("\\Delta_g F(y) := F(T_g y) \\overline{F(y)}")#text(" and ")#mi("P(g,\\cdot)")#text(" is a phase polynomial of bounded degree for each ")#mi("g \\in {\\Bbb F}^\\omega")#text(". Indeed, we can rearrange (2) as")

#align(center)[#tao-fit-display[#mitex("\\Delta_g [ f(y,u) / F(y) ] = P(g,y)")]]

#text("and so all derivatives of ")#mi("f(y,u) / F(y)")#text(" are phase polynomials of bounded degree, which implies that ")#mi("f(y,u)/F(y)")#text(" is itself a phase polynomial of bounded degree, thus ")#mi("f(y,u)")#text(" is the product of F with a phase polynomial of bounded degree. But ")#mi("F \\in L^\\infty(Y)")#text(", which is generated by phase polynomials of bounded degree, and so ")#mi("f(y,u)")#text(" can be approximated by a linear combination of phase polynomials of bounded degree, and thus in particular must correlate with at least one of them, as desired.")

#text("It thus remains to establish (2). Cocycles of the form ")#mi("\\Delta_g F(y)")#text(" are known as ")#emph[#text("coboundaries")]#text(", and two cocycles which differ by a coboundary are said to be ")#emph[#text("cohomologous")]#text(" [see ")#link("https://terrytao.wordpress.com/2008/12/21/cohomology-for-dynamical-systems/")[#text("my previous post")]#text(" for further discussion]. Thus, our task is to show the cocycle ")#mi("\\rho")#text(" is cohomologous to a phase polynomial of bounded degree.")

#heading(level: 1)[#text("— The finite type condition —")]

#text("We have yet to use the hypothesis that the vertical coordinate function ")#mi("f: (y,u) \\mapsto u")#text(" has non-zero ")#mi("U^k(X)")#text(" norm. For this, we use a key observation of Host-Kra that this hypothesis implies (in fact it is basically equivalent to) a certain ")#emph[#text("finite type")]#text(" condition on the cocycle ")#mi("\\rho")#text(". We derive this condition somewhat informally as follows. If ")#tao-math("\\left\\|f\\right\\|_{U^k(X)}", block: false)#text(" is non-zero, then this means that the expected value of the expression")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("d^{[k]} f( x ) := \\prod_{\\omega \\in \\{0,1\\}^k} f(x_\\omega)^{\\text{sgn}(\\omega)}")]]

#text("is non-zero, where ")#mi("x = (x_\\omega)_{\\omega \\in \\{0,1\\}^k}")#text(" ranges over “k-dimensional parallelopipeds” in X. (This can be made precise by using the ")#emph[#text("cubic measures")]#text(" ")#mi("\\mu^{[k]}")#text(" of Host and Kra, but let us ignore this technical detail here.)")

#text("One way to make a k-dimensional parallelopiped is to start with a (k-1)-dimensional parallelopiped ")#mi("y = (y_\\omega)_{\\omega \\in \\{0,1\\}^{k-1}}")#text(", shift it by a group element g, and glue the two (k-1)-dimensional parallelopipeds together. When one does so, the quantity (3) simplifies to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("d^{[k-1]} \\rho(g,y) := \\prod_{\\omega \\in \\{0,1\\}^k} \\rho(g,y_\\omega)^{\\text{sgn}(\\omega)}.")]]

#text("Note that as ")#mi("\\rho")#text(" does not depend on the vertical coordinate u, one can view the ")#mi("y_\\omega")#text(" as living in Y rather than in X.")

#text("We expect (4) to have a non-zero average in some sense. If we define the limiting average")

#align(center)[#tao-fit-display[#mitex("F(y) := {\\Bbb E}_g d^{[k-1]} \\rho(g,y)")]]

#text("(where ")#mi("{\\Bbb E}_g")#text(" denotes the limit after averaging g along a ")#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Følner sequence")]#text(") we thus expect F to be non-zero at least some of the time; to simplify the discussion let us pretend that it is in fact always non-zero. The cocycle equation (1) implies that")

#align(center)[#tao-fit-display[#mitex("F( T_g y ) = d^{[k-1]} \\rho(g, y) F(y)")]]

#text("and so, after defining ")#tao-math("F^{\\prime} := F/\\left|F\\right|", block: false)#text(", we see that ")#mi("d^{[k-1]} \\rho(h, y)")#text(" is a coboundary:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("d^{[k-1]} \\rho(g,y) = \\Delta_g F(y).")]]

#text("When ")#mi("\\rho")#text(" obeys this condition, we say that it is of ")#emph[#text("type")]#text(" ")#mi("<k-1")#text(". The challenge is now to “integrate” the derivative ")#mi("d^{[k-1]}")#text(" out of (5) and obtain (2).")

#heading(level: 1)[#text("— Vertical differentiation —")]

#text("The parallelopiped-based derivatives ")#mi("d^{[k-1]}")#text(" are difficult to work with directly (unless k is very small). It is convenient to replace them with a simpler type of derivative, a “vertical” derivative. To explain this, we first decompose Y as an extension ")#mi("Y = Z \\times_\\phi U")#text(" of a “simpler” system Z (where “simpler” means, roughly speaking, that we can generate it using polynomials of strictly lower degree than what one needs for Y), where U is a compact abelian group and ")#mi("\\phi: {\\Bbb F}^\\omega \\times Z \\to U")#text(" is a cocycle. It turns out that we can always decompose Y in this fashion, because Y is generated by polynomials; furthermore we can make the cocycle ")#mi("\\phi")#text(" a polynomial of bounded degree.")

#text("Once one does this, the system Y not only has an action of ")#mi("{\\Bbb F}^\\omega")#text(", but also has an action of the vertical group U, which commutes with the ")#mi("{\\Bbb F}^\\omega")#text(" action. Given any ")#mi("u \\in U")#text(", we can now define the ")#emph[#text("vertical derivative")]#text(" ")#mi("\\Delta_u f")#text(" of any function ")#mi("f \\in L^\\infty(Y)")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\Delta_u f(y,v) := f(y,uv) \\overline{f(y,v)}.")]]

#text("It turns out that the general theory of cubic measures, as worked out by Host and Kra, allows one to relate vertical derivatives ")#mi("\\Delta_u")#text(" to the parallelogram derivatives ")#mi("d^{[k-1]}")#text(" (basically, the point is that the group U happens to preserve the cubic measures ")#mi("\\mu^{[k-1]}")#text(" when applied correctly). Because of this, it is possible to deduce from (5) the “Conze-Lesigne type” equation")

#align(center)[#mi("\\Delta_{u_1} \\ldots \\Delta_{u_{k-1}} \\rho(g,y) = \\Delta_g F_{u_1,\\ldots,u_{k-1}}(y)")#text(" (5′)")]

#text("for all ")#mi("u_1,\\ldots,u_{k-1} \\in U")#text(". This equation is more tractable than (5) for a number of reasons, one of which being that y now lives in the system Y, rather than being a ")#mi("k-1")#text("-dimensional parallelopiped of points in Y. Our task is now to repeatedly integrate away the vertical derivatives on the left-hand side of (5′) to obtain (2).")

#text("This procedure will be done one derivative at a time. Let us focus on the final step. For this, we assume that we have already obtained an equation of the form")

#align(center)[#mi("\\Delta_u \\rho(g,y) = P_u(g,y) \\Delta_g F_u(y)")#text(" (5”)")]

#text("for all ")#mi("u \\in U, g \\in {\\Bbb F}^\\omega")#text(", and almost every ")#mi("y \\in Y")#text(", where ")#mi("P_u(g,\\cdot)")#text(" is a phase polynomial of bounded degree and ")#mi("F_u(y)")#text(" is a measurable function taking values in ")#mi("S^1")#text("; thus every vertical derivative of ")#mi("\\rho")#text(" is cohomologous to a bounded degree phase polynomial. (A technical but important point: it is possible to select ")#mi("P_u")#text(" and ")#mi("F_u")#text(" so that ")#mi("F_u(y)")#text(" is ")#emph[#text("jointly")]#text(" measurable in both u and y, and similarly for ")#mi("P_u(g,y)")#text(". This is ultimately possible because the space of bounded degree phase polynomials turns out to be discrete modulo constants.) The task is now to integrate (5”) to obtain (2). Actually, we will establish a weaker form of (2), namely")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\rho(g,y) = P(g,y) \\rho^{\\prime}(g,z) \\Delta_g F(y)")]]

#text("where ")#mi("y = (z,u)")#text(" and ")#mi("\\rho^{\\prime}: {\\Bbb F}^\\omega \\times Z \\to S^1")#text(" is some measurable function. One can show that if (6) holds, then ")#mi("\\rho^{\\prime}")#text(" obeys similar properties to the cocycle ")#mi("\\rho")#text(", in particular the finite type condition (5). (It turns out to not quite be a cocycle, though, but merely a ")#emph[#text("quasi-cocycle")]#text(": a cocycle modulo phase polynomials. This is an important technical difficulty, but let us ignore it for this discussion.) Since Z is a simpler system than Y, it is possible to combine (6) with a suitable inductive argument to recover (2).")

#text("To summarise our progress so far, we are now at the point where every vertical derivative of ")#mi("\\rho")#text(" is cohomologous to a polynomial (equation (5”)), and wish to integrate this information to conclude that ")#mi("\\rho")#text(" itself is cohomologous to a polynomial, times a vertically-invariant function.")

#heading(level: 1)[#text("— Reduction to the finite U case —")]

#text("We now analyse the equation (5”) further. We have a cocycle relation")

#align(center)[#tao-fit-display[#mitex("\\Delta_{uv} \\rho(g,y) = \\Delta_u \\rho(g,y) \\Delta_v \\rho(g,V_u y)")]]

#text("where ")#mi("V_u: (z,v) \\mapsto (z,uv)")#text(" denotes the action of vertical rotation by u. Inserting this relation into our hypothesis (5”), we see that ")#mi("\\Delta_g [F_{uv} / ( F_u V_u F_v )]")#text(" is a phase polynomial of bounded degree, and thus ")#mi("F_{uv} / (F_u V_u F_v)")#text(" is also a phase polynomial of bounded degree. In other words, ")#mi("F_u")#text(" is a quasi-cocycle in u; it obeys the cocycle equation ")#mi("F_{uv} = F_u V_u F_v")#text(" modulo phase polynomials of bounded degree.")

#text("Suppose temporarily that ")#mi("F_u")#text(" was a genuine cocycle in u. Then, it is possible (using some Fourier analysis) to conclude that ")#mi("F_u")#text(" is in fact a coboundary in u, ")#mi("F_u = \\Delta_u F")#text("; this is basically because the action of U on Y is free and thus has no non-trivial cohomology. (One can get some idea of this by looking at the case when U and Y are finite.) We can now rewrite (5”) as")

#align(center)[#mi("\\Delta_u (\\rho(g,y)/\\Delta_g F(y)) = P_u(g,y)")#text(".")]

#text("In particular, ")#mi("P_u")#text(" must be a cocycle in U, and is thus also a coboundary: ")#mi("P_u = \\Delta_u P")#text(". Since the ")#mi("P_u")#text(" are phase polynomials of bounded degree, and the cocycle ")#mi("\\phi")#text(" underlying the extension ")#mi("Y = Z \\times_\\phi U")#text(" is also a phase polynomial of bounded degree, it is possible to ensure that the “antiderivative” P of the ")#mi("P_u")#text(" of the phase polynomials of bounded degree is also a polynomial of bounded degree. (Verifying this “integration lemma” requires a certain amount of algebraic computation – analogous to that required to show that the composition of two polynomials is again a polynomial, as was done for instance in ")#link("https://terrytao.wordpress.com/2008/11/13/some-notes-on-non-classical-polynomials-in-finite-characteristic/")[#text("this previous post of mine")]#text(" – but we will ignore this issue here.) We thus see that ")#mi("\\rho(g,y) / (P(g,y) \\Delta_g F(y))")#text(" has vanishing u derivative for every U, and is thus of the form ")#mi("\\rho^{\\prime}(g,z)")#text(" for some ")#mi("\\rho^{\\prime}")#text(", thus yielding (5”) as desired. Thus we see that we would be done if F was a genuine cocycle in U.")

#text("Unfortunately, F is only a quasi-cocycle in U; the cocycle equation only holds modulo phase polynomials. However, one can show that the space of phase polynomials (after quotienting out by constants) is discrete and thus at most countable. (This discreteness is closely related to the local testability of polynomials that was mentioned in a ")#link("https://terrytao.wordpress.com/2008/11/01/the-inverse-conjecture-for-the-gowers-norm-over-finite-fields-via-the-correspondence-principle/")[#text("previous post")]#text(".) Because of this, and the countable pigeonhole principle, we can find a single polynomial P for which the modified cocycle equation ")#mi("F_{uv} = F_u (V_u F_v) P")#text(" holds (modulo constants) for a set E of (u,v) of positive measure in ")#mi("U \\times U")#text(".")

#text("Now let us recall a basic fact from measure theory: if E is a positive measure subset of a compact abelian group U, then the difference set E-E contains an open neighbourhood of the origin. (This is basically because sets of positive measure can be approximated by open sets, as per ")#link("http://en.wikipedia.org/wiki/Littlewood%27s_three_principles_of_real_analysis")[#text("Littlewood’s principle")]#text(".). Using facts like this, and manipulating the above modified cocycle equation a few times, one eventually arrives at the conclusion that F is in fact a genuine cocycle on an open neighbourhood of the origin in U. (Here I am oversimplifying a number of technical details, which can be found in the paper. I will mention though that it was crucial here that ")#mi("F_u")#text(" was measurable in u, a fact alluded to earlier.)")

#text("Up until now, we have not used at all any properties of the underlying group ")#mi("{\\Bbb F}^\\omega")#text(" (other than that it is abelian, discrete, and amenable). Now, for the first time, we exploit the finite characteristic. Because of this finite characteristic, all phase polynomials take values in roots of unity (modulo constants); since Y is given by polynomials, it is possible to show that U is then a ")#link("http://en.wikipedia.org/wiki/Torsion_group")[#text("torsion group")]#text(" (in fact, one can show it is the direct product of at most countably many cyclic groups). As a consequence of this, every open neighbourhood of the origin in U contains an open subgroup. Thus, we have managed to show that ")#mi("F_u")#text(" is a cocycle, not for ")#mi("u \\in U")#text(", but rather for ")#mi("u \\in U^{\\prime}")#text(" where U’ is an open subgroup of U.")

#text("This is close enough to what we originally wanted that we can try repeating the above arguments. Doing this, we find at the end of the day that we can “quotient out” U’ from the problem and effectively reduce U to the quotient group U/U’. Since U is compact and U’ is open, U/U’ is finite. Thus, we have effectively reduced matters to the case in which U is finite.")

#heading(level: 1)[#text("— The finite U case —")]

#text("Now let U be finite. The ")#link("http://en.wikipedia.org/wiki/Finitely_generated_abelian_group")[#text("classification of finite abelian groups")]#text(" tells us that U is the product of cyclic groups. For simplicity let us suppose that U is a single cyclic group, and specifically the group ")#mi("C_p")#text(" of ")#mi("p^{th}")#text(" roots of unity; this is not the most general case, but it illustrates the method (the general case is handled by a more complicated version of the arguments below).")

#text("Let e be the generator of U, thus ")#mi("U = \\{1,e,\\ldots,e^{p-1}\\}")#text(". By the previous arguments, we know that F is a quasi-cocycle in U, thus")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("F_{e^{j+k}} = F_{e^j} V_e^j F_{e^k} \\times P_{j,k}")]]

#text("for some phase polynomial ")#mi("P_{j,k}")#text(" of bounded degree. We would like to eliminate the polynomials ")#mi("P_{j,k}")#text(" from this equation to get a genuine cocycle.")

#text("We can partially do this by redefining the ")#mi("F_{e^j}")#text(" for ")#mi("j=2,3,\\ldots,p-1")#text(" in terms of ")#mi("F_e")#text(" by the formula")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("F_{e^j} := \\prod_{i=0}^{j-1} V_e^i F_e.")]]

#text("One can show (using (6)) that this redefinition does not significantly affect (5”), and now we have the exact cocycle condition")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("F_{e^{j+k}} = F_{e^j} V_e^j F_{e^k}")]]

#text("whenever ")#mi("0 \\leq j,k")#text(" and ")#mi("j+k < p")#text(". However, (8) need not hold for all j, k. In order for this to be true, one must obey the ")#emph[#text("line cocycle condition")]

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\prod_{i=0}^{p-1} V_e^i F_e = 1")]]

#text("(which would make the definition in (7) periodic in j). Conversely, if (9) holds then the cocycle given by (7) is a true cocycle in U, thus this condition completely describes the “cohomology” of U-cocycles here.")

#text("Now, in general, the ")#mi("F_e")#text(" that we initially start with need not satisfy (9). However, by using (6), one can show that the left-hand side of (9), while not identically 1, is at least a phase polynomial of bounded degree. At this point we use a key algebraic lemma (which I hope to comment more on in a future post): every phase polynomial of bounded degree has a ")#mi("p^{th}")#text(" root which is also a phase polynomial of bounded (but slightly higher) degree. Thus we have")

#align(center)[#tao-fit-display[#mitex("\\prod_{i=0}^{p-1} V_e^i F_e = Q^p")]]

#text("for some polynomial Q of bounded degree. But then what we can do is divide each ")#mi("F_e")#text(" by Q; this does not significantly affect (5”), but now recovers the line cocycle condition (9), and allows us to make ")#mi("F_u")#text(" a cocycle on U, at which point one can argue as before.")

#text("The multidimensional case, when U is a product of cyclic groups, is a little more sophisticated than this; in addition to the line cocycle condition (9), there is an additional “zero curvature” condition ")#mi("\\Delta_{e_j} F_{e_i} = \\Delta_{e_i} F_{e_j}")#text(" that has to be obtained before one can build a cocycle in U, but it turns out that a suitably multidimensional generalisation of the formula (7) can ensure this.")

#heading(level: 1)[#text("Comments (9)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bengreen")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-35132")[#strong[#text("bengreen")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2009")])]

#text("A tour de force which I shall enjoy reading on a forthcoming train journey. But please, please can you think of an alternative to the triangle-with-a-dot notation for multiplicative derivative?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f42e57d1cd1776806a3dbf5ceaa693ac1d9a891e662e639cf34384cb7aee8d28-84a99841968724fbea2a3d7a343b8c191e5a9669490cca42ea591deb7e9f64fa.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-35140")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2009")])]

#text("Dear Terry, the paper is extremely well written and indeed a joy to read (even to an outsider like me). One typo: on page 8 (eq 1.2) there’s an extra 0 in the matrix.")

#text("Do you expect the sharpest constant ")#mi("c=c(p,k,\\delta)")#text(" in theorem 1.27 to have a nice explicit form (at least for k=1 or k=p)?")

#text("Finally I’d humbly concur that the current notation for the multiplicative derivative is a bit heavy to the eye, a trick to make the black dot a little smaller would to use the \\scriptscriptsize command, here’s a wordpress try without preview: either this ")#mi("\\Delta\\!\\!\\!\\!{\\scriptscriptstyle \\bullet}")#text(" or that ")#mi("\\Delta\\!\\!\\!\\!\\!{\\scriptscriptstyle \\bullet}")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-35146")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2009")])]

#text("Thanks for the correction! We actually had a lot of trouble deciding on the notation for the multiplicative derivative; we had considered ")#mi("\\dot \\Delta_h")#text(" or ")#mi("\\Delta^\\times_h")#text(" or ")#mi("{\\Delta\\!\\!\\!\\cdot\\ \\ \\!\\!}_h")#text(" but felt that the dots were too inconspicuous. I guess we erred in the other direction instead. I like the scriptsize idea (though my version of LaTeX is so far refusing to acknowledge \\scriptscriptsize), I’ll try to see if I can centre the dot in the middle of the triangle. [")#emph[#text("update")]#text(": OK, I managed to jerry rig this: ")#tao-math("{\\Delta\\!\\!\\!\\!\\!\\!\\text{\\raisebox{0.4ex}{\\tiny\\ \\ \\bullet}}\\ \\ \\!\\!}_h", block: false)#text(".]")

#text("(Alternatively, since we use multiplicative differentiation far more often than additive differentiation, another option is to make ")#mi("\\Delta_h")#text(" default to multiplicative and use some other notation for additive. But we felt that this might be confusing since ")#mi("\\Delta_h")#text(" denotes additive differentiation in many other places in the literature. Anyway, I welcome further suggestions.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-42811")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] with respect to the shift . (This need to consider families is an issue that also comes up in the finite field ergodic theory analogue of the inverse conjectures, due to the unbounded number of generators in that case, but […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-45032")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] handle the general case, which was worked out in two papers, one by myself and Ziegler, and one by Bergelson, Ziegler, and myself. It turns out that it is convenient to phrase these arguments in the language of ergodic theory. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-49532")[#strong[#text("The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")])]

#text("[…] for the Gowers norm, this time for vector spaces over a fixed finite field of prime order; with Vitaly Bergelson, we had previously established this claim when the characteristic of the field was large, so the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-230675")[#strong[#text("Multiple recurrence and convergence results associated to $F_{p}^{omega}$-actions | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2013")])]

#text("[…] analogue of the structural theory of Host and Kra was worked out by Vitaly, Tamar, and myself in these previous papers (treating the high characteristic and low characteristic cases respectively). In […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on inverse theorem entropy | What's new")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-644065")[#strong[#text("Notes on inverse theorem entropy | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 May 2022")])]

#text("[…] prime order (so that ), then the inverse theorem of Ziegler and myself (available in both high and low characteristic) allows one to obtain an -inverse theorem for some and the collection of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]], [#link("https://terrytao.wordpress.com/2009/01/19/an-inverse-theorem-for-the-uniformity-seminorms-associated-with-the-action-of-finfty_p/#comment-675857")[#strong[#text("A Host–Kra ${bf F}^omega_2$-system of order 5 that is not Abramov of order 5, and non-measurability of the inverse theorem for the $U^6({bf F}^n_2)$ norm; The structure of totally disconnected Host–Kra–Ziegler factors, and the inverse th")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2023")])]

#text("[…] of Towsner for a closely related principle, and this paper of Jamneshan and I for a refinement). In a paper with Bergelson and Ziegler, we were able to establish Conjecture 2 in the “high characteristic” case , thus also […]")
]
