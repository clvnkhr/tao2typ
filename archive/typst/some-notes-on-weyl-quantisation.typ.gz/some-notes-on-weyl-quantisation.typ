// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/
// Converted to Typst by tao2typ: "2026-10-14T16:36:54.488877+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Some notes on Weyl quantisation", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Some notes on Weyl quantisation")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 7 October 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/")[#text("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("One of the basic problems in the field of ")#link("http://en.wikipedia.org/wiki/Operator_algebra")[#text("operator algebras")]#text(" is to develop a ")#link("http://en.wikipedia.org/wiki/Functional_calculus")[#text("functional calculus")]#text(" for either a single operator ")#mi("{A}")#text(", or a collection ")#mi("{A_1, A_2, \\ldots, A_k}")#text(" of operators. These operators could in principle act on any function space, but typically one either considers complex matrices (which act on a complex finite dimensional space), or operators (either bounded or unbounded) on a complex Hilbert space. (One can of course also obtain analogous results for real operators, but we will work throughout with complex operators in this post.)")

#text("Roughly speaking, a functional calculus is a way to assign an operator ")#mi("{F(A)}")#text(" or ")#mi("{F(A_1,\\ldots,A_k)}")#text(" to any function ")#mi("{F}")#text(" in a suitable function space, which is linear over the complex numbers, preserve the scalars (i.e. ")#mi("{c(A) = c}")#text(" when ")#mi("{c \\in {\\bf C}}")#text("), and should be either an exact or approximate homomorphism in the sense that ")#metadata(none) <tao-f4a4ce5fa6340a35aa5d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("FG(A_1,\\ldots,A_k) = F(A_1,\\ldots,A_k) G(A_1,\\ldots,A_k),")]]

#text("should hold either exactly or approximately. In the case when the ")#mi("{A_i}")#text(" are self-adjoint operators acting on a Hilbert space (or Hermitian matrices), one often also desires the identity ")#metadata(none) <tao-525eca1d5089dbdcbb67>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\overline{F}(A_1,\\ldots,A_k) = F(A_1,\\ldots,A_k)^*")]]

#text("to also hold either exactly or approximately. (Note that one cannot reasonably expect ")#link(<tao-f4a4ce5fa6340a35aa5d>)[#text("(1)")]#text(" and ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(2)")]#text(" to hold exactly for all ")#mi("{F,G}")#text(" if the ")#mi("{A_1,\\ldots,A_k}")#text(" and their adjoints ")#mi("{A_1^*,\\ldots,A_k^*}")#text(" do not commute with each other, so in those cases one has to be willing to allow some error terms in the above wish list of properties of the calculus.) Ideally, one should also be able to relate the operator norm of ")#mi("{f(A)}")#text(" or ")#mi("{f(A_1,\\ldots,A_k)}")#text(" with something like the uniform norm on ")#mi("{f}")#text(". In principle, the existence of a good functional calculus allows one to manipulate operators as if they were scalars (or at least approximately as if they were scalars), which is very helpful for a number of applications, such as partial differential equations, spectral theory, noncommutative probability, and semiclassical mechanics. A functional calculus for multiple operators ")#mi("{A_1,\\ldots,A_k}")#text(" can be particularly valuable as it allows one to treat ")#mi("{A_1,\\ldots,A_k}")#text(" as being exact or approximate scalars ")#emph[#text("simultaneously")]#text(". For instance, if one is trying to solve a linear differential equation that can (formally at least) be expressed in the form")

#align(center)[#tao-fit-display[#mitex("F(X,D) u = f")]]

#text("for some data ")#mi("{f}")#text(", unknown function ")#mi("{u}")#text(", some differential operators ")#mi("{X,D}")#text(", and some nice function ")#mi("{F}")#text(", then if one’s functional calculus is good enough (and ")#mi("{F}")#text(" is suitably “elliptic” in the sense that it does not vanish or otherwise degenerate too often), one should be able to solve this equation either exactly or approximately by the formula")

#align(center)[#tao-fit-display[#mitex("u = F^{-1}(X,D) f,")]]

#text("which is of course how one would solve this equation if one pretended that the operators ")#mi("{X,D}")#text(" were in fact scalars. Formalising this calculus rigorously leads to the theory of ")#link("http://en.wikipedia.org/wiki/Pseudo-differential_operator")[#text("pseudodifferential operators")]#text(", which allows one to (approximately) solve or at least simplify a much wider range of differential equations than one what can achieve with more elementary algebraic transformations (e.g. integrating factors, change of variables, variation of parameters, etc.). In quantum mechanics, a functional calculus that allows one to treat operators as if they were approximately scalar can be used to rigorously justify the ")#link("http://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(" in physics, namely that the predictions of quantum mechanics approximate that of classical mechanics in the ")#emph[#text("semiclassical limit")]#text(" ")#mi("{\\hbar \\rightarrow 0}")#text(".")

#text("There is no universal functional calculus that works in all situations; the strongest functional calculi, which are close to being an exact *-homomorphisms on very large class of functions, tend to only work for under very restrictive hypotheses on ")#mi("{A}")#text(" or ")#mi("{A_1,\\ldots,A_k}")#text(" (in particular, when ")#mi("{k > 1}")#text(", one needs the ")#mi("{A_1,\\ldots,A_k}")#text(" to commute either exactly, or very close to exactly), while there are weaker functional calculi which have fewer nice properties and only work for a very small class of functions, but can be applied to quite general operators ")#mi("{A}")#text(" or ")#mi("{A_1,\\ldots,A_k}")#text(". In some cases the functional calculus is only formal, in the sense that ")#mi("{f(A)}")#text(" or ")#mi("{f(A_1,\\ldots,A_k)}")#text(" has to be interpreted as an infinite formal series that does not converge in a traditional sense. Also, when one wishes to select a functional calculus on non-commuting operators ")#mi("{A_1,\\ldots,A_k}")#text(", there is a certain amount of non-uniqueness: one generally has a number of slightly different functional calculi to choose from, which generally have the same properties but differ in some minor technical details (particularly with regards to the behaviour of “lower order” components of the calculus). This is a similar to how one has a variety of slightly different coordinate systems available to parameterise a Riemannian manifold or Lie group. This is on contrast to the ")#mi("{k=1}")#text(" case when the underlying operator ")#mi("{A = A_1}")#text(" is (essentially) normal (so that ")#mi("{A}")#text(" commutes with ")#mi("{A^*}")#text("); in this special case (which includes the important subcases when ")#mi("{A}")#text(" is unitary or (essentially) self-adjoint), spectral theory gives us a canonical and very powerful functional calculus which can be used without further modification in applications.")

#text("Despite this lack of uniqueness, there is one standard choice for a functional calculus available for general operators ")#mi("{A_1,\\ldots,A_k}")#text(", namely the ")#link("http://www.encyclopediaofmath.org/index.php/Weyl_calculus")[#text("Weyl functional calculus")]#text("; it is analogous in some ways to ")#link("http://en.wikipedia.org/wiki/Normal_coordinates")[#text("normal coordinates")]#text(" for Riemannian manifolds, or ")#emph[#text("exponential coordinates of the first kind")]#text(" for Lie groups, in that it treats lower order terms in a reasonably nice fashion. (But it is important to keep in mind that, like its analogues in Riemannian geometry or Lie theory, there will be some instances in which the Weyl calculus is not the optimal calculus to use for the application at hand.)")

#text("I decided to write some notes on the Weyl functional calculus (also known as ")#link("http://en.wikipedia.org/wiki/Wigner%E2%80%93Weyl_transform")[#text("Weyl quantisation")]#text("), and to sketch the applications of this calculus both to the theory of pseudodifferential operators. They are mostly for my own benefit (so that I won’t have to redo these particular calculations again), but perhaps they will also be of interest to some readers here. (Of course, this material is also covered in many other places. e.g. Folland’s “")#link("http://www.ams.org/mathscinet-getitem?mr=983366")[#text("harmonic analysis in phase space")]#text("“.)")

#metadata(none) <tao-a1c3c08078fa2271858d>

#heading(level: 1)[#strong[#text(" — 1. Weyl quantisation of polynomials — ")]]

#text("The simplest class of functions to which one can set up a functional calculus are the polynomials, as this does not require any analytic tools to define. To begin with we will ignore the conjugation structure, thus we will not attempt to implement ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(2)")]#text(".")

#text("In order to be able to freely compose all the operators ")#mi("{A_1,\\ldots,A_k}")#text(" under consideration, we will assume that there is some dense space of test functions (or perhaps Schwartz functions) which is preserved by all of the ")#mi("{A_1,\\ldots,A_k}")#text(", so that any composition of finitely many of the ")#mi("{A_1,\\ldots,A_k}")#text(" will be densely defined. (Alternatively, one could proceed at a purely formal level for this discussion, working in an abstract algebra generated by the ")#mi("{A_1,\\ldots,A_k}")#text(".)")

#text("In the ")#mi("{k=1}")#text(" case of a single operator ")#mi("{A}")#text(", the polynomial calculus is obvious: given any polynomial")

#align(center)[#tao-fit-display[#mitex("F(a) := \\sum_{i=0}^n c_i a^i")]]

#text("with complex coefficients ")#mi("{c_0,\\ldots,c_n}")#text(", one can define ")#mi("{F(A)}")#text(" to be the operator")

#align(center)[#tao-fit-display[#mitex("F(A) := \\sum_{i=0}^n c_i A^i.")]]

#text("In other words, the functional calculus ")#mi("{F \\mapsto F(A)}")#text(" is the linear map that takes each monomial ")#mi("{z^i}")#text(" to the operator ")#mi("{A^i}")#text(". This calculus is of course an exact homomorphism, as it is linear and obeys ")#link(<tao-f4a4ce5fa6340a35aa5d>)[#text("(1)")]#text(" exactly.")

#text("Now we consider the situation with multiple operators. For simplicity, let us just consider the case of two operators ")#mi("{A,B}")#text(". We then consider a polynomial")

#align(center)[#tao-fit-display[#mitex("F(a,b) := \\sum_{i=0}^n \\sum_{j=1}^m c_{i,j} a^i b^j")]]

#text("with complex coefficients ")#mi("{c_{i,j}}")#text(", and ask how to define the operator ")#mi("{F(A,B)}")#text(".")

#text("The most obvious way to define ")#mi("{F(A,B)}")#text(" is by direct substitution, which I will call the ")#emph[#text("Kohn-Nirenberg calculus")]#text(":")

#align(center)[#tao-fit-display[#mitex("F(A,B)_{KN} := \\sum_{i=0}^n \\sum_{j=1}^m c_{i,j} A^i B^j.")]]

#text("(Depending on the interpretation of the operators ")#mi("{A,B}")#text(", this calculus might also be referred to as the ")#link("http://en.wikipedia.org/wiki/Normal_order")[#text("Wick-ordered calculus")]#text(" or ")#emph[#text("normal-ordered calculus")]#text(".) This is certainly a well-defined calculus, but when ")#mi("{A}")#text(" and ")#mi("{B}")#text(" do not commute, the calculus has a bias in that it always places ")#mi("{A}")#text(" to the left of ")#mi("{B}")#text("; in particular, if one interchanges the roles of ")#mi("{a}")#text(" and ")#mi("{b}")#text(" then one obtains a different calculus, which one might call the ")#emph[#text("anti-Kohn-Nirenberg")]#text(" calculus:")

#align(center)[#tao-fit-display[#mitex("F(A,B)_{KN^*} := \\sum_{i=0}^n \\sum_{j=1}^m c_{i,j} B^j A^i.")]]

#text("Intermediate, and more symmetric, between these two calculi, is the ")#emph[#text("Weyl calculus")]

#align(center)[#tao-fit-display[#mitex("F(A,B)_{W} := \\sum_{i=0}^n \\sum_{j=1}^m c_{i,j} (A^i B^j)_W")]]

#text("where the Weyl ordering ")#mi("{(A^i B^j)_W}")#text(" of the monomial ")#mi("{A^i B^j}")#text(" is defined to be the average of all the ")#mi("{\\binom{i+j}{i}}")#text(" ways to multiply ")#mi("{i}")#text(" copies of ")#mi("{A}")#text(" and ")#mi("{j}")#text(" copies of ")#mi("{B}")#text(" together:")

#align(center)[#tao-fit-display[#mitex("(A^i B^j)_W := \\frac{1}{\\binom{i+j}{i}} \\sum_{C_1,\\ldots,C_{i+j}} C_1 \\ldots C_{i+j}")]]

#text("where ")#mi("{C_1,\\ldots,C_{i+j}}")#text(" range over all tuples which contain ")#mi("{i}")#text(" copies of ")#mi("{A}")#text(" and ")#mi("{j}")#text(" copies of ")#mi("{B}")#text(", thus for instance")

#tao-aligned(keep: true)[


#tao-math("(AB)_W  & = \\frac{1}{2}( AB + BA )", block: true)



#tao-math("(AB^2)_W  & = \\frac{1}{3}( ABB + BAB + BBA)", block: true)



#tao-math("(A^2 B^2)_W  & = \\frac{1}{6} (AABB + ABAB + ABBA", block: true)



#tao-math(" & + BAAB + BABA + BBAA).", block: true)
]

#text("and so forth.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Strictly speaking, the use of the terminology ")#mi("{(A^i B^j)_W}")#text(" here is an abuse of notation, because it suggests a functional relationship between ")#mi("{A^i B^j}")#text(" and ")#mi("{(A^i B^j)_W}")#text(" which need not be the case. In particular, if the monomials ")#mi("{A^i B^j}")#text(" and ")#mi("{A^k B^l}")#text(" are equal as operators, this does not necessarily imply that the Weyl-ordered monomials ")#mi("{(A^i B^j)_W}")#text(" and ")#mi("{(A^k B^l)_W}")#text(" are equal. One could fix this notation by working first with ")#emph[#text("formal")]#text(" symbols ")#mi("{{\\bf A}, {\\bf B}}")#text(" generating a free commutative algebra, and writing ")#mi("{({\\bf A}^i {\\bf B}^j)_W}")#text(" in place of ")#mi("{(A^i B^j)_W}")#text(", so that the Weyl map ")#mi("{F \\mapsto F_W}")#text(" becomes a not-quite-homomorphism from the commutative algebra generated by ")#mi("{{\\bf A}}")#text(" and ")#mi("{{\\bf B}}")#text(" to the non-commutative algebra generated by ")#mi("{A}")#text(" and ")#mi("{B}")#text(". We have chosen however to not be quite so formal, and allow some abuse of notation to simplify the exposition.")
]

#text("When ")#mi("{A}")#text(" and ")#mi("{B}")#text(" commute, of course, all these calculi coincide with each other; it is only in the non-commuting case that some distinctions between the calculi emerge. The Weyl calculus may seem complicated, but it has somewhat cleaner formulae with regard to products. For instance, the Weyl calculus works perfectly with respect to powers ")#mi("{(sA+tB+u)^n}")#text(" of affine combinations ")#mi("{sA+tB+u}")#text(" of ")#mi("{A,B}")#text(", where ")#mi("{s,t,u \\in {\\bf C}}")#text(" are scalars: ")#metadata(none) <tao-7865b7e6b9d241d744d3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("((sA+tB+u)^n)_W = (sA+tB+u)^n.")]]

#text("(By this equation, we mean that if ")#mi("{F}")#text(" is the polynomial ")#mi("{F(a,b) := (sa+tb)^n}")#text(", then ")#mi("{F(A,B)_W}")#text(" is the operator ")#mi("{F(A,B)_W = (sA+tB)^n}")#text(".) Thus for instance")

#tao-aligned(keep: true)[


#tao-math("((A+B)^2)_W  & = (A^2)_W + (2AB)_W + (B^2)_W", block: true)



#tao-math(" & = A^2 + AB + BA + B^2", block: true)



#tao-math(" & = (A+B)^2.", block: true)
]

#text("In contrast, the Kohn-Nirenberg calculus (or the anti-Kohn-Nirenberg calculus) distorts this ordering, for instance we have")

#align(center)[#tao-fit-display[#mitex("((A+B)^2)_{KN} = A^2 + 2AB + B^2 \\neq (A+B)^2")]]

#text("Indeed, by comparing coefficients in ")#link(<tao-7865b7e6b9d241d744d3>)[#text("(3)")]#text(" and using linearity we see that the identity ")#link(<tao-7865b7e6b9d241d744d3>)[#text("(3)")]#text(" (for arbitrary ")#mi("{s,t,u,n}")#text(") in fact uniquely defines the Weyl calculus. One consequence of this is that the Weyl calculus is not only symmetric with respect to interchange of the underlying operators ")#mi("{A,B}")#text(", but in fact respects all linear changes of variable: if ")#mi("{A^{\\prime} = cA + dB+e, B^{\\prime} = fA + gB+h}")#text(" are scalar affine combinations of ")#mi("{A,B}")#text(", ")#mi("{F^{\\prime}: {\\bf C} \\times {\\bf C} \\rightarrow {\\bf C}}")#text(" is a polynomial of two variables, and ")#mi("{F}")#text(" is the polynomial ")#mi("{F(a,b) ;= F^{\\prime}(ca+db+e,fa+gb+h)}")#text(", then we have that")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(A^{\\prime},B^{\\prime})_W = F(A,B)_W.")]]

#text("Indeed, from ")#link(<tao-7865b7e6b9d241d744d3>)[#text("(3)")]#text(" we see that this identity holds for the mixed monomials ")#mi("{F(a,b) = (sa+tb)^n}")#text(", and then by linearity it is true for all polynomials.")

#text("One can also extend the Weyl calculus to formal (i.e. not necessarily convergent) infinite series")

#align(center)[#tao-fit-display[#mitex("F(a,b) := \\sum_{i=0}^\\infty \\sum_{j=1}^\\infty c_{i,j} a^i b^j")]]

#text("by declaring ")#mi("{F(A,B)_W}")#text(" to be the formal series of operators")

#align(center)[#tao-fit-display[#mitex("F(A,B)_W := \\sum_{i=0}^\\infty \\sum_{j=1}^\\infty c_{i,j} (A^i B^j)_W.")]]

#text("In doing so, the identity ")#link(<tao-7865b7e6b9d241d744d3>)[#text("(3)")]#text(" can be expressed in a very convenient form ")#metadata(none) <tao-1d5072f894a9d4122cbb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("(\\exp(sA+tB+u))_W = \\exp(sA+tB+u)")]]

#text("where we view the exponential function ")#mi("{\\exp}")#text(" here as the formal infinite series ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\exp(z) = \\sum_{i=0}^\\infty \\frac{z^i}{i!}.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The fact that Weyl calculus preserves the exponential map is the reason why we view this calculus as being analogous to ")#link("http://en.wikipedia.org/wiki/Normal_coordinates")[#text("normal coordinates")]#text(" in Riemannian geometry, as well as exponential coordinates (of the first kind) on Lie groups, discussed for instance in ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("this previous blog post")]#text(". In contrast, the Kohn-Nirenberg quantisation gives")

#align(center)[#tao-fit-display[#mitex("(\\exp(sA+tB+u))_{KN} = \\exp(sA) \\exp(tB) \\exp(u)")]]

#text("which is analogous to exponential coordinates of the second kind on Lie groups.")
]

#text("Now we study the extent to which the homomorphism property ")#link(<tao-f4a4ce5fa6340a35aa5d>)[#text("(1)")]#text(" holds in the Weyl calculus, i.e. we study the discrepancy between ")#mi("{(FG)(A,B)_W}")#text(" and ")#mi("{F(A,B)_W G(A,B)_W}")#text(". When ")#mi("{A}")#text(" and ")#mi("{B}")#text(" commute, it is easy to see that ")#link(<tao-f4a4ce5fa6340a35aa5d>)[#text("(1)")]#text(" holds exactly. In general, these two expressions can be quite different; but when ")#mi("{A}")#text(" and ")#mi("{B}")#text(" ")#emph[#text("almost")]#text(" commute, so that the commutator ")#mi("{[A,B] = AB-BA}")#text(" is non-zero but small, we expect ")#link(<tao-f4a4ce5fa6340a35aa5d>)[#text("(1)")]#text(" to be approximately true. Motivated by quantum-mechanical examples, we will study a model case when ")#mi("{A}")#text(" and ")#mi("{B}")#text(" obey the Heisenberg commutator relationship ")#metadata(none) <tao-fb8e20fc2e4c3f248c60>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("[A,B] = i\\hbar")]]

#text("where ")#mi("{\\hbar}")#text(" is a small positive real number. (In some literature, the sign convention here is reversed.) In this case, we see that any two ways to multiply ")#mi("{j}")#text(" copies of ")#mi("{A}")#text(" and ")#mi("{k}")#text(" copies of ")#mi("{B}")#text(" together will differ by polynomials of degree strictly less than ")#mi("{j+k}")#text(". Among other things, this shows that any polynomial of ")#mi("{A}")#text(" and ")#mi("{B}")#text(" can be rewritten into a Weyl-ordered form, by first ordering the top degree terms (at the cost of introducing some messy lower degree terms) and then recursively working on the lower order terms. The same procedure also implies that this Weyl-ordered form is unique. For instance,")

#align(center)[#tao-fit-display[#mitex("AB = (AB)_W -\\frac{1}{2}[A,B] = (AB - \\frac{1}{2} i\\hbar)_W.")]]

#text("This already implies that for any two polynomials ")#mi("{F,G: {\\bf C}^2 \\rightarrow {\\bf C}}")#text(", there must be a unique “product” polynomial ")#mi("{F \\ast_\\hbar G: {\\bf C}^2 \\rightarrow {\\bf C}}")#text(" with the property that ")#metadata(none) <tao-b1abe2eca0d7e336afb7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("F(A,B)_W G(A,B)_W = (F \\ast_\\hbar G)(A,B)_W.")]]

#text("In the ")#emph[#text("classical limit")]#text(" ")#mi("{\\hbar=0}")#text(", this operation is simply pointwise product:")

#align(center)[#tao-fit-display[#mitex("F \\ast_0 G = FG.")]]

#text("Now we work out what the product operation ")#mi("{\\ast_\\hbar}")#text(" (known as the ")#link("http://en.wikipedia.org/wiki/Moyal_product")[#text("Moyal product")]#text(") is for non-zero ")#mi("{\\hbar}")#text(". To avoid some rather messy combinatorics, it turns out to be cleanest to proceed using the formal exponential function ")#link(<tao-1d5072f894a9d4122cbb>)[#text("(5)")]#text(" applied to various combinations ")#mi("{sA+tB}")#text(" of ")#mi("{A}")#text(" and ")#mi("{B}")#text(". (This is an instance of the method of ")#link("http://en.wikipedia.org/wiki/Generating_function")[#text("generating functions")]#text(" in action.)")

#text("We first observe from ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(6)")]#text(" that we have the general commutation relationship ")#metadata(none) <tao-56af4bde70a47ae7d0f1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("[sA+tB, s^{\\prime}A+t^{\\prime}B] = i\\hbar \\omega( (s,t), (s^{\\prime},t^{\\prime}) )")]]

#text("where ")#mi("{\\omega}")#text(" is the anti-symmetric form")

#align(center)[#tao-fit-display[#mitex("\\omega( (s,t), (s^{\\prime},t^{\\prime}) ) := st^{\\prime} - s^{\\prime}t.")]]

#text("This is already the first hint of the correspondence between quantum mechanics (whose dynamics is based on the commutator ")#mi("{\\frac{i}{\\hbar} [,]}")#text(") and classical mechanics (whose dynamics is based on the Poisson bracket ")#mi("{\\{f,g\\} = \\omega( \\nabla f, \\nabla g)}")#text("). From this and the ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula#The_Hadamard_lemma")[#text("Baker-Campbell-Hausdorff formula")]#text(", we conclude (formally, at least) that ")#metadata(none) <tao-833a61955631ab7a5609>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\exp(sA+tB) \\exp(s^{\\prime}A+t^{\\prime}B)")]]

#align(center)[#tao-fit-display[#mitex("= \\exp(sA+tB+s^{\\prime}A+t^{\\prime}B) \\exp( \\frac{1}{2} i\\hbar \\omega((s,t),(s^{\\prime},t^{\\prime})) ).")]]

#text("One can make this identity rigorous (at the level of formal power series) as follows. We first observe that the ")#link("http://en.wikipedia.org/wiki/Commutator")[#text("Hadamard lemma")]

#align(center)[#tao-fit-display[#mitex("\\exp(X) Y \\exp(-X) = \\exp(\\text{ad}(X)) Y")]]

#text("holds at the level of formal power series, where ")#mi("{\\text{ad}(X)}")#text(" is the commutator operation ")#mi("{\\text{ad}(X)(Y) := [X,Y]}")#text(". This can be seen by first establishing the formal differentiation identity")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\exp(tX) Y \\exp(-tX) = \\text{ad}(X)(\\exp(tX) Y \\exp(-tX))")]]

#text("(which comes from the formal identity ")#mi("{\\frac{d}{dt} \\exp(tX) = X \\exp(tX) = \\exp(tX) X}")#text(" and the product rule) and then using this to solve for ")#mi("{\\exp(tX) Y \\exp(-tX)}")#text(" as a formal power series to conclude that")

#align(center)[#tao-fit-display[#mitex("\\exp(tX) Y \\exp(-tX) = \\exp(t\\text{ad}(X)) Y,")]]

#text("and then setting ")#mi("{t=1}")#text(". Using this lemma together with ")#link(<tao-56af4bde70a47ae7d0f1>)[#text("(8)")]#text(", we see in particular that ")#metadata(none) <tao-fd429c3beb98517739e7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("\\exp(sA+tB) (s^{\\prime}A+t^{\\prime}B) \\exp(-sA-tB) = s^{\\prime}A+t^{\\prime}B + i\\hbar \\{ (s,t), (s^{\\prime},t^{\\prime}) \\}.")]]

#text("Now consider the expression")

#align(center)[#tao-fit-display[#mitex("C(\\lambda) := \\exp(\\lambda (sA+tB)) \\exp(\\lambda(s^{\\prime}A+t^{\\prime}B)) \\exp( - \\frac{\\lambda^2}{2} i\\hbar \\omega((s,t),(s^{\\prime},t^{\\prime})) )")]]

#text("as a formal power series in ")#mi("{\\lambda}")#text(". Then ")#mi("{C(0)}")#text(" is the identity, and the formal derivative ")#mi("{C^{\\prime}(\\lambda)}")#text(" can be expressed as")

#align(center)[#tao-fit-display[#mitex("C^{\\prime}(\\lambda) = (sA+tB) \\exp(\\lambda (sA+tB)) \\exp(\\lambda(s^{\\prime}A+t^{\\prime}B)) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\times \\exp( - \\frac{\\lambda^2}{2} i\\hbar \\omega((s,t),(s^{\\prime},t^{\\prime})) )")]]

#align(center)[#tao-fit-display[#mitex("+ \\exp(\\lambda (sA+tB)) (s^{\\prime}A+t^{\\prime}B) \\exp(\\lambda(s^{\\prime}A+t^{\\prime}B))\\times")]]

#align(center)[#tao-fit-display[#mitex("\\times \\exp( - \\frac{\\lambda^2}{2} i\\hbar \\omega((s,t),(s^{\\prime},t^{\\prime})) )")]]

#align(center)[#tao-fit-display[#mitex("- \\exp(\\lambda (sA+tB)) \\exp(\\lambda(s^{\\prime}A+t^{\\prime}B)) (\\lambda i\\hbar \\{(s,t),(s^{\\prime},t^{\\prime})\\}) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\times \\exp( - \\frac{\\lambda^2}{2} i\\hbar \\omega((s,t),(s^{\\prime},t^{\\prime})) )")]]

#text("which after using ")#link(<tao-fd429c3beb98517739e7>)[#text("(10)")]#text(" simplifies to")

#align(center)[#tao-fit-display[#mitex("C^{\\prime}(\\lambda) = (sA + tB + s^{\\prime}A + t^{\\prime}B) C(\\lambda)")]]

#text("which on solving the formal series leads to")

#align(center)[#tao-fit-display[#mitex("C(\\lambda) = \\exp( \\lambda(sA + tB + s^{\\prime}A + t^{\\prime}B) )")]]

#text("which gives ")#link(<tao-833a61955631ab7a5609>)[#text("(9)")]#text(" after setting ")#mi("{\\lambda=1}")#text(".")

#text("Combining ")#link(<tao-833a61955631ab7a5609>)[#text("(9)")]#text(", ")#link(<tao-1d5072f894a9d4122cbb>)[#text("(5)")]#text(" and ")#link(<tao-b1abe2eca0d7e336afb7>)[#text("(7)")]#text(" (as well as the uniqueness of the Weyl ordering), we conclude that")

#align(center)[#tao-fit-display[#mitex("\\exp(sa+tb) \\ast_{\\hbar} \\exp(s^{\\prime}a+t^{\\prime}b)")]]

#align(center)[#tao-fit-display[#mitex("= \\exp(sa+tb+s^{\\prime}a+t^{\\prime}b) \\exp( \\frac{1}{2} i\\hbar \\omega((s,t),(s^{\\prime},t^{\\prime})) )")]]

#text("where both sides are viewed as formal power series in indeterminates ")#mi("{a,b}")#text(". Comparing coefficients, we see that")

#align(center)[#tao-fit-display[#mitex("(sa+tb)^n \\ast_{\\hbar} (s^{\\prime}a+t^{\\prime}b)^m")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{j=0}^\\infty j! \\binom{n}{j} \\binom{m}{j} (sa+tb)^{n-j} (s^{\\prime}a+t^{\\prime}b)^{m-j} ( \\frac{i\\hbar}{2} \\omega((s,t),(s^{\\prime},t^{\\prime})) )^j")]]

#text("with the convention that ")#mi("{\\binom{n}{j}}")#text(" vanishes for ")#mi("{j>n}")#text(", and similarly for ")#mi("{\\binom{m}{j}}")#text(". We write")

#align(center)[#tao-fit-display[#mitex("\\omega((s,t),(s^{\\prime},t^{\\prime}))^j = \\omega^{\\otimes j}( (s,t)^{\\otimes j}, (s^{\\prime},t^{\\prime})^{\\otimes j} ),")]]

#text("where ")#mi("{\\omega^{\\otimes j}: ({\\bf C}^2)^{\\otimes j} \\times ({\\bf C}^2)^{\\otimes j} \\rightarrow {\\bf C}}")#text(" is the tensor product of ")#mi("{j}")#text(" copies of ")#mi("{\\omega: {\\bf C}^2 \\times {\\bf C}^2 \\rightarrow {\\bf C}}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("\\nabla^j (sa+tb)^n = j! \\binom{n}{j} (s,t)^{\\otimes j} (sa+tb)^{n-j}")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\nabla^j (s^{\\prime}a+t^{\\prime}b)^m = j! \\binom{n}{j} (s,t)^{\\otimes j} (s^{\\prime}a+t^{\\prime}b)^{m-j},")]]

#text("where ")#mi("{\\nabla}")#text(" denotes the gradient with respect to the ")#mi("{a,b}")#text(" variables, we conclude that")

#align(center)[#tao-fit-display[#mitex("(sa+tb)^n \\ast_{\\hbar} (s^{\\prime}a+t^{\\prime}b)^m")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_{j=0}^\\infty \\frac{1}{j!} (\\frac{i\\hbar}{2})^j \\omega^{\\otimes j}( \\nabla^j (sa+tb)^n, \\nabla^j (s^{\\prime}a+t^{\\prime}b)^m ).")]]

#text("This formula is valid for all monomials ")#mi("{(sa+tb)^n, (s^{\\prime}a+t^{\\prime}b)^m}")#text(", and so by bilinearity we conclude the explicit formula ")#metadata(none) <tao-6030984d10adab3535e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("F \\ast_\\hbar G = \\sum_{j=0}^\\infty \\frac{1}{j!} (\\frac{i\\hbar}{2})^j \\omega^{\\otimes j}(\\nabla^j F, \\nabla^j G)")]]

#text("for the Moyal product, thus")

#tao-aligned(keep: true)[


#tao-math("F \\ast_\\hbar G  & = F G + \\frac{i\\hbar}{2} \\omega(\\nabla F, \\nabla G) - \\frac{\\hbar^2}{8} \\omega^{\\otimes 2}(\\nabla^2 F, \\nabla^2 G)", block: true)



#tao-math(" & - \\frac{i\\hbar^3}{48} \\omega^{\\otimes 3}(\\nabla^3 F, \\nabla^3 G) + \\ldots.", block: true)
]

#text("The expression ")#mi("{\\omega(\\nabla F, \\nabla G)}")#text(" is also known as the ")#link("http://en.wikipedia.org/wiki/Poisson_bracket")[#text("Poisson bracket")]#text(" of ")#mi("{F}")#text(" and ")#mi("{G}")#text(", and is denoted ")#mi("{\\{F,G\\}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("F \\ast_\\hbar G = FG + \\frac{i\\hbar}{2} \\{F,G\\} + \\ldots.")]]

#text("Note that ")#mi("{\\omega^{\\otimes j}}")#text(" is symmetric for even ")#mi("{j}")#text(" and anti-symmetric for odd ")#mi("{j}")#text(". Subtracting, we conclude that")

#align(center)[#tao-fit-display[#mitex("F \\ast_\\hbar G - G \\ast_\\hbar F = \\sum_{j=0}^\\infty \\frac{2}{(2j+1)!} (\\frac{i\\hbar}{2})^{2j+1} \\omega^{\\otimes 2j+1}(\\nabla^{2j+1} F, \\nabla^{2j+1} G),")]]

#text("thus ")#metadata(none) <tao-a9fe349640f8fb9f795f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\frac{1}{i\\hbar} (F \\ast_\\hbar G - G \\ast_\\hbar F) = \\{ F,G\\} - \\frac{\\hbar^2}{24} \\omega^{\\otimes 3}(\\nabla^3 F, \\nabla^3 G) + \\ldots.")]]

#text("Thus we see that the normalised commutator ")#mi("{\\frac{1}{i\\hbar} (F \\ast_\\hbar G - G \\ast_\\hbar F)}")#text(" of the Moyal product converges in the semiclassical limit ")#mi("{\\hbar \\rightarrow 0}")#text("; this is one manifestation of the correspondence principle.")

#text("The above discussion was for two operators ")#mi("{A,B}")#text(" obeying the Heisenberg commutation relation ")#link(<tao-fb8e20fc2e4c3f248c60>)[#text("(6)")]#text(", but one can check that a similar calculus can also be developed for any tuple ")#mi("{A_1,\\ldots,A_k}")#text(" of operators, and if they obey a Heisenberg-like commutation law")

#align(center)[#tao-fit-display[#mitex("[ \\sum_{i=1}^k s_i A_i, \\sum_{j=1}^k t_j A_j] = \\omega( (s_1,\\ldots,s_k), (t_1,\\ldots,t_k) )")]]

#text("for some anti-symmetric form ")#mi("{\\omega:{\\bf C}^k\\times {\\bf C}^k \\rightarrow {\\bf C}}")#text(", then the Moyal product formula ")#link(<tao-6030984d10adab3535e6>)[#text("(11)")]#text(" holds; the arguments are basically identical to the two variable case (except for some notational complications) and are left as an exercise to the reader.")

#text("Once one has set up a calculus for complex polynomials ")#mi("{P( a_1,\\ldots,a_k)}")#text(" of some non-self-adjoint operators ")#mi("{A_1,\\ldots,A_k}")#text(", one can then extend it to polynomials ")#mi("{P(a_1,\\ldots,a_k,\\overline{a_1},\\ldots,\\overline{a_k})}")#text(" of the original arguments ")#mi("{a_1,\\ldots,a_k}")#text(" and their conjugates (or equivalently, to polynomials of the real and imaginary parts of the ")#mi("{a_1,\\ldots,a_k}")#text(") by using the calculus for ")#mi("{A_1,\\ldots,A_k,A_1^*,\\ldots,A_k^*}")#text(". This allows one to define operators ")#mi("{P(A_1,\\ldots,A_k)_W}")#text(" when ")#mi("{P: ({\\bf R}^2)^k \\rightarrow {\\bf C}}")#text(" is a polynomial of the real and imaginary parts of ")#mi("{A_1,\\ldots,A_k}")#text(", basically by substituting ")#mi("{\\frac{A_j+A_j^*}{2}}")#text(" and ")#mi("{\\frac{A_j-A_j^*}{2i}}")#text(" for ")#mi("{\\text{Re}(A_j)}")#text(" and ")#mi("{\\text{Im}(A_j)}")#text(" respectively. One advantage of the Weyl calculus, not shared in general by the Kohn-Nirenberg calculus, is that the identity ")#link(<tao-525eca1d5089dbdcbb67>)[#text("(2)")]#text(" holds exactly; this is basically a special case of the affine invariance properties of the Weyl calculus mentioned earlier. In a similar vein, the Weyl calculus ensures that")

#align(center)[#tao-fit-display[#mitex("F(A_1,\\ldots,A_k)^*_W = F^*(A_1^*,\\ldots,A_k^*)_W")]]

#text("for any complex polynomial ")#mi("{F}")#text(", where ")#mi("{F^*(z) := \\overline{F(\\overline{z})}}")#text(" is the complex polynomial whose coefficients are the complex conjugates of the coefficients of ")#mi("{F}")#text(". In particular, if ")#mi("{A_1,\\ldots,A_k}")#text(" are self-adjoint and ")#mi("{F}")#text(" has real coefficients, then ")#mi("{F(A_1,\\ldots,A_k)_W}")#text(" is again self-adjoint.")

#heading(level: 1)[#strong[#text(" — 2. Weyl quantisation of smooth symbols — ")]]

#text("The above algebraic formalism allowed one to define the Weyl quantisation ")#mi("{F(A_1,\\ldots,A_k)_W}")#text(" of any ")#mi("{k}")#text("-tuple of operators (preserving some dense space of test functions) as long as ")#mi("{f}")#text(" was a polynomial; one could also handle the case when ")#mi("{f}")#text(" was a formal power series, provided that one was willing to make ")#mi("{F(A_1,\\ldots,A_k)_W}")#text(" a formal power series also. But of course we would like to expand the calculus beyond the spaces of polynomials and formal power series.")

#text("One obvious way is to work with convergent power series instead of formal power series, but this approach, by definition, only applies for real analytic functions ")#mi("{F}")#text(". Also, being real analytic (which, by the root test, can be viewed as an exponential decay hypothesis on the coefficients ")#mi("{c_{i,j}}")#text(") may not be enough in some cases to ensure convergence of the formal power series ")#mi("{F(A_1,\\ldots,A_k)_W}")#text("; one may need faster decay on the ")#mi("{c_{i,j}}")#text(" (e.g. decay like ")#mi("{1/(i+j)!}")#text(" or something similar) before one can justify convergence in a suitable sense.")

#text("To get beyond the analytic category, it turns out that one can use Fourier-analytic methods, using Fourier expansions as a substitute for power series expansions. The key point, of course, is that Fourier analysis works well for spaces of functions that are significantly rougher than real analytic.")

#text("To illustrate the method, let us again work with just two operators ")#mi("{A}")#text(" and ")#mi("{B}")#text(". We will assume that ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are (essentially) self-adjoint, which by spectral theory suggests that one should be able to define ")#mi("{F(A,B)_W}")#text(" for (sufficiently nice) real-valued functions ")#mi("{F: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(". (The distinction between real and complex functions was not apparent at the polynomial level, since any polynomial on a real vector space can be automatically complexified uniquely to a polynomial on the associated complex vector space.) The starting point is the Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("F(a,b) = \\int_{\\bf R} \\int_{\\bf R} \\hat F(s,t) e^{i (a s + bt)}\\ ds dt")]]

#text("where ")#mi("{\\hat F(s,t)}")#text(" is the Fourier transform, which in our choice of normalisations becomes")

#align(center)[#tao-fit-display[#mitex("\\hat F(s,t) = \\frac{1}{(2\\pi)^2} \\int_{\\bf R} \\int_{\\bf R} F(a,b) e^{-i(as+bt)}\\ da db.")]]

#text("From the inversion formula, it is natural to expect that the Weyl quantisation ")#mi("{F(A,B)_W}")#text(" of ")#mi("{F(A,B)}")#text(" should be given by the formula")

#align(center)[#tao-fit-display[#mitex("F(A,B)_W = \\int_{\\bf R} \\int_{\\bf R} \\hat F(s,t) (e^{i (A s + Bt)})_W\\ ds dt")]]

#text("which in view of ")#link(<tao-1d5072f894a9d4122cbb>)[#text("(5)")]#text(" leads us to ")#metadata(none) <tao-c39e5817b2f3b3807592>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("F(A,B)_W := \\int_{\\bf R} \\int_{\\bf R} \\hat F(s,t) e^{i (A s + Bt)}\\ ds dt")]]

#text("which we will take as a ")#emph[#text("definition")]#text(" of ")#mi("{F(A,B)_W}")#text(" for general functions ")#mi("{F: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf C}}")#text(".")

#text("Of course, to make this definition rigorous, one has to specify some regularity hypotheses on ")#mi("{F}")#text(", and check that the integral actually converges in some suitable sense; also, it would be reassuring to verify that the definition is compatible with the polynomial calculus given earlier. At present, ")#mi("{A}")#text(" and ")#mi("{B}")#text(" are completely abstract operators, which makes this task quite difficult; so we will now work with a much more concrete situation, namely that of the one-dimensional position operator ")#mi("{X}")#text(" and momentum operator ")#mi("{D}")#text(", defined on test functions in ")#mi("{L^2({\\bf R})}")#text(" by the formulae")

#align(center)[#tao-fit-display[#mitex("X f(x) := xf(x), Df(x) := \\frac{\\hbar}{i} \\frac{d}{dx} f(x).")]]

#text("Note that this obeys the Heisenberg relation")

#align(center)[#tao-fit-display[#mitex("[X,D] = i \\hbar")]]

#text("and thus by ")#link(<tao-833a61955631ab7a5609>)[#text("(9)")]#text(" one has (formally, at least)")

#align(center)[#tao-fit-display[#mitex("\\exp(isX + itD) = \\exp( i\\hbar st/2) \\exp(isX) \\exp(itD)")]]

#text("for any ")#mi("{s,t \\in {\\bf R}}")#text(". On the other hand, we have")

#align(center)[#tao-fit-display[#mitex("\\exp(isX) f(x) = \\exp(isx) f(x)")]]

#text("while from solving the transport equation ")#mi("{\\frac{\\partial}{\\partial t} f(t,x) = iD f(t,x)}")#text(" we see that")

#align(center)[#tao-fit-display[#mitex("\\exp(itD) f(x) = f(x+\\hbar t)")]]

#text("for suitable test functions ")#mi("{f}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("\\exp(isX + itD) f(x) = \\exp( i\\hbar st/2) \\exp( isx ) f(x+\\hbar t).")]]

#text("Again working formally, we conclude that")

#align(center)[#tao-fit-display[#mitex("F(X,D)_W f(x) = \\int_{\\bf R} \\int_{\\bf R} \\hat F(s,t) \\exp( i\\hbar st/2) \\exp( isx ) f(x+\\hbar t)\\ ds dt")]]

#text("which we expand as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(2\\pi)^2} \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} F(\\tilde x,p) \\exp(-is\\tilde x-itp) \\exp( i\\hbar st/2) \\exp( isx )")]]

#align(center)[#tao-fit-display[#mitex("f(x+\\hbar t)\\ ds dt d\\tilde x dp.")]]

#text("Making the change of variables ")#mi("{t = \\frac{y-x}{\\hbar}}")#text(", we rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{(2\\pi)^2 \\hbar} \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} F(\\tilde x,p) \\exp(-is\\tilde x-i(y-x)p/\\hbar) \\exp( is(x+y)/2)")]]

#align(center)[#tao-fit-display[#mitex("f(y)\\ ds dy d\\tilde x dp.")]]

#text("Next, from the distributional Fourier inversion formula")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\int_{\\bf R} \\exp(isu)\\ ds = \\delta(u)")]]

#text("where ")#mi("{\\delta}")#text(" is the Dirac delta, we can rewrite this as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi \\hbar} \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} F(\\tilde x,p) \\exp(-i(y-x)p/\\hbar) \\delta( \\tilde x - (x+y)/2) f(y)\\ dy d\\tilde x dp")]]

#text("which on performing the ")#mi("{\\tilde x}")#text(" integral simplifies to")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi \\hbar} \\int_{\\bf R} \\int_{\\bf R} F(\\frac{x+y}{2},p) \\exp(-i(y-x)p/\\hbar)\\ dy dp")]]

#text("or after the change of variables ")#mi("{p = 2\\pi \\hbar \\xi}")#text(", ")#metadata(none) <tao-7f039e5efab4ad926191>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("F(X,D)_W f(x) = \\int_{\\bf R} (\\int_{\\bf R} F(\\frac{x+y}{2}, 2\\pi \\hbar \\xi) e^{-2\\pi i (y-x) \\xi} f(y)\\ dy)d\\xi.")]]

#text("We remark that the Kohn-Nirenberg calculus ")#mi("{F(X,D)_{KN}}")#text(" comes out almost identically, except that the argument ")#mi("{\\frac{x+y}{2}}")#text(" is replaced with ")#mi("{x}")#text(". Similarly for the anti-Kohn-Nirenberg calculus (in which ")#mi("{\\frac{x+y}{2}}")#text(" is replaced by ")#mi("{y}")#text("). The Weyl calculus treats the input variable ")#mi("{y}")#text(" and the output variable ")#mi("{x}")#text(" on equal footing, whereas the Kohn-Nirenberg calculus prefers one to the other. In particular, we have the convenient formal identity ")#metadata(none) <tao-a1dcbd2066be82d79e45>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("F(X,D)_W^* = \\overline{F}(X,D)_W")]]

#text("so that ")#mi("{F(X,D)_W}")#text(" formally self-adjoint when ")#mi("{F}")#text(" is real-valued.")

#text("We will take the formula ")#link(<tao-7f039e5efab4ad926191>)[#text("(14)")]#text(" as our ")#emph[#text("definition")]#text(" of the Weyl quantisation ")#mi("{F(X,D)_W f(x)}")#text(", at least when ")#mi("{f}")#text(" is a Schwarz function and ")#mi("{F}")#text(" obeys the weak regularity bounds ")#metadata(none) <tao-34dcda3f0cf99ccb47e9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\nabla_x^i \\nabla_p^j F(x,p)\\right| \\leq C_{i,j} (1+\\left|x\\right|+\\left|p\\right|)^C", block: true)]]

#text("for all ")#mi("{i,j \\geq 0}")#text(", all ")#mi("{x,p \\in {\\bf R}}")#text(", some constant ")#mi("{C>0}")#text(", and some constants ")#mi("{C_{i,j}>0}")#text(" depending on ")#mi("{i,j}")#text(". (This is weaker than the symbol bounds that usually arise in the theory of pseudodifferential operators, but will suffice for the discussion here.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that for ")#mi("{F}")#text(" and ")#mi("{f}")#text(" as above, the integrand ")#mi("{F(\\frac{x+y}{2}, 2\\pi \\hbar \\xi) e^{-2\\pi i (y-x) \\xi}}")#text(" is absolutely integrable in ")#mi("{y}")#text(", and that the integrand ")#mi("{\\int_{\\bf R} F(\\frac{x+y}{2}, 2\\pi \\hbar \\xi) e^{-2\\pi i (y-x) \\xi}\\ dy}")#text(" is absolutely integrable in ")#mi("{\\xi}")#text(", making ")#mi("{F(X,D)_W f(x)}")#text(" well-defined. Show in fact that ")#mi("{F(X,D)_W f}")#text(" is a Schwartz function.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Show that the above definition agrees with the previous definitions of ")#mi("{\\exp(sX+tD)_W}")#text(" and ")#mi("{(X^i D^j)_W}")#text(". (One approach is by direct computation; another is to try to make the above formal calculations fully rigorous.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3 (Translation invariance)")]#text(" ")#metadata(none) <tao-c48fee4ea1a9af170601>#text(" If ")#mi("{F}")#text(" obeys the weak regularity bound ")#link(<tao-34dcda3f0cf99ccb47e9>)[#text("(16)")]#text(" and ")#mi("{F_{x_0,p_0}(x,p) := F(x-x_0,p-p_0)}")#text(" for some ")#mi("{x_0,p_0 \\in {\\bf R}}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("F^{\\prime}(X,D)_W = \\mu_{p_0} \\tau_{x_0} F(X,D)_W \\tau_{x_0}^{-1} \\mu_{p_0}^{-1}")]]

#text("where ")#mi("{\\tau_{x_0} = \\exp(-ix_0D/\\hbar)}")#text(" is the translation operator")

#align(center)[#tao-fit-display[#mitex("\\tau_{x_0} f(x) := f(x-x_0)")]]

#text("and ")#mi("{\\mu_{p_0} = \\exp(ip_0X/\\hbar)}")#text(" is the modulation operator")

#align(center)[#tao-fit-display[#mitex("\\mu_{p_0} f(x) := e^{i p_0x /\\hbar} f(x).")]]

#text("One can in fact obtain similar symmetries for the entire ")#link("http://en.wikipedia.org/wiki/Metaplectic_group#Construction_of_the_Weil_representation")[#text("Weil representation of the (affine) metaplectic group")]#text(", but we will not do so here.")
]

#text("One can get some intuition as to what the operators ")#mi("{F(X,D)_W}")#text(" do by testing them on gaussian wave packets")

#align(center)[#tao-fit-display[#mitex("g_{x_0,p_0}(x) := e^{-(x-x_0)^2/\\hbar} e^{i p_0 x/\\hbar}.")]]

#text("It turns out that the Taylor series of ")#mi("{F}")#text(" around ")#mi("{(x_0,p_0)}")#text(" is a good approximation for the action of ")#mi("{F(X,D)_W}")#text(" on such a packet:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1")]#text(" ")#metadata(none) <tao-63acfa239a51e0a33c7f>#text(" For any ")#mi("{k \\geq 0}")#text(", one has ")#metadata(none) <tao-0ead5c5d188f5c48f823>

#tao-aligned(keep: true)[


#tao-math("F(X,D)_W g_{x_0,p_0}  & = \\sum_{i+j \\leq k} \\frac{\\partial_x^i \\partial_p^j F(x_0,p_0)}{i!j!} ( (X-x_0)^i (D-p_0)^j )_W g_{x_0,p_0}", block: true, numbering: n => [#text("(17)")])



#tao-math(" & + O_{k,L^2}(\\hbar^{k-O(1)})", block: true)
]

#text("as ")#mi("{\\hbar \\rightarrow 0}")#text(", where ")#mi("{O_{k,L^2}(\\hbar^{k-O(1)})}")#text(" denotes a quantity with ")#mi("{L^2}")#text(" norm of ")#mi("{O_k(\\hbar^{k-O(1)})}")#text(".")
]

#text("Thus we have the asymptotic series")

#tao-aligned(keep: true)[


#tao-math("F(X,D)_W g_{x_0,p_0}  & = F(x_0,p_0) g_{x_0,p_0} + (\\partial_x F(x_0,p_0)) (X-x_0) g_{x_0,p_0}", block: true)



#tao-math(" & + (\\partial_p F(x_0,p_0)) (D-p_0) g_{x_0,p_0}", block: true)



#tao-math(" & + \\frac{1}{2} (\\partial_{xx} F(x_0,p_0)) (X-x_0)^2 g_{x_0,p_0}", block: true)



#tao-math(" & + \\frac{1}{2} (\\partial_{pp} F(x_0,p_0)) (D-p_0)^2 g_{x_0,p_0}", block: true)



#tao-math(" & + (\\partial_{xp} F(x_0,p_0)) ((X-x_0)(D-p_0)) g_{x_0,p_0} + \\ldots", block: true)
]

#text("with each term of order ")#mi("{k}")#text(" being of ")#mi("{L^2}")#text(" norm ")#mi("{O_k(\\hbar^{k-O(1)})}")#text(". (Note that this does ")#emph[#text("not")]#text(" imply that the series is convergent in ")#mi("{L^2}")#text(", because we have no control of the dependence on ")#mi("{k}")#text(" of the implied constant in the ")#mi("{O_k()}")#text(" notation.)")

#emph[#text("Proof:")]#text(" (Sketch) By using the symmetries in Exercise ")#link(<tao-c48fee4ea1a9af170601>)[#text("3")]#text(", we may normalise ")#mi("{x_0=p_0=0}")#text(". If ")#mi("{F}")#text(" is a polynomial of degree at most ")#mi("{k}")#text(", then the the two sides of ")#link(<tao-0ead5c5d188f5c48f823>)[#text("(17)")]#text(" agree exactly, with no need for the error term ")#mi("{O_{k,L^2}(\\hbar^{k-O(1)})}")#text(". By subtracting off the order ")#mi("{k}")#text(" Taylor expansion, we thus see that it suffices to show that")

#align(center)[#tao-fit-display[#mitex("F(X,D)_W g_{0,0} = O_{k,L^2}( \\hbar^{k-O(1)} )")]]

#text("whenever ")#mi("{F}")#text(" vanishes to order at least ")#mi("{k}")#text(" at the origin. But this can be verified from ")#link(<tao-7f039e5efab4ad926191>)[#text("(14)")]#text(" and a routine stationary phase computation. ")#mi("\\Box")

#text("The same computation allows one to replace the ")#mi("{L^2}")#text(" norm by any other of the Frechet norms in the Schwartz space, as long as ")#mi("{x_0, p_0}")#text(" are assumed to be of polynomial size in ")#mi("{\\hbar}")#text(", i.e. ")#mi("{x_0, p_0 = O(\\hbar^{-O(1)})}")#text(".")

#text("From ")#link(<tao-7f039e5efab4ad926191>)[#text("(14)")]#text(", we see that any quantisation ")#mi("{F(X,D)_W}")#text(" is formally an integral operator ")#metadata(none) <tao-09d3f92cb7418e158e82>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#mitex("Tf(x) = \\int_{\\bf R} K(x,y) f(y)\\ dy")]]

#text("with distributional kernel")

#align(center)[#tao-fit-display[#mitex("K(x,y) := \\int_{\\bf R} F(\\frac{x+y}{2}, 2\\pi \\hbar \\xi) e^{-2\\pi i (y-x) \\xi}\\ d\\xi.")]]

#text("Applying the Fourier inversion formula, we thus see (formally, at least) that any integral operator ")#link(<tao-09d3f92cb7418e158e82>)[#text("(18)")]#text(" is also a quantisation ")#mi("{F(X,D)_W}")#text(" where ")#mi("{F}")#text(" is uniquely determined by the formula ")#metadata(none) <tao-9294ab38039f60d2ec53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("F(x,2\\pi \\hbar \\xi) := \\int_{\\bf R} K( x-a/2, x+a/2 ) e^{2\\pi i a \\xi}\\ da.")]]

#text("In particular, given two quantisations ")#mi("{F(X,D)_W}")#text(" and ")#mi("{G(X,D)_W}")#text(", their composition ")#mi("{F(X,D)_W G(X,D)_W}")#text(" is formally an integral operator with distributional kernel")

#align(center)[#tao-fit-display[#mitex("K(x,y) := \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} F(\\frac{x+z}{2}, 2\\pi \\hbar \\xi) G(\\frac{z+y}{2}, 2\\pi \\hbar \\eta) e^{-2\\pi i (z-x) \\xi} e^{-2\\pi i (y-z)\\eta}")]]

#align(center)[#tao-fit-display[#mitex("\\ d\\xi d\\eta dz")]]

#text("and hence is formally a quantisation ")#mi("{F \\ast_\\hbar G(X,D)_W}")#text(", where")

#align(center)[#tao-fit-display[#mitex("F \\ast_\\hbar G( x_0, 2\\pi \\hbar \\xi_0) := \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} F(\\frac{x_0+z-a/2}{2}, 2\\pi \\hbar \\xi) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\times G(\\frac{z+x_0+a/2}{2}, 2\\pi \\hbar \\eta) e^{-2\\pi i (z-x_0+a/2) \\xi} e^{-2\\pi i (x_0+a/2-z)\\eta} e^{2\\pi i a \\xi_0}\\ d\\xi d\\eta dz da.")]]

#text("Thus, for instance,")

#align(center)[#tao-fit-display[#mitex("F \\ast_\\hbar G( 0, 0) = \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} \\int_{\\bf R} F(\\frac{z-a/2}{2}, 2\\pi \\hbar \\xi) \\times")]]

#align(center)[#tao-fit-display[#mitex("\\times G(\\frac{z+a/2}{2}, 2\\pi \\hbar \\eta) e^{-2\\pi i (z+a/2) \\xi} e^{-2\\pi i (a/2-z)\\eta}\\ d\\xi d\\eta da dz.")]]

#text("This integral will, in general, not be absolutely integrable. However, the phase ")#mi("{(\\xi,\\eta,a,z) \\mapsto (z+a/2)\\xi + (a/2-z)\\eta}")#text(" is only stationary at ")#mi("{(\\xi,\\eta,a,z) = (0,0,0,0)}")#text(". By using a suitable smooth dyadic decomposition and many integrations by parts, we can then show that this integral can be given a convergent interpretation if ")#mi("{F,G}")#text(" obey the weak regularity bound ")#link(<tao-34dcda3f0cf99ccb47e9>)[#text("(16)")]#text(". Similarly for other evaluations ")#mi("{F \\ast_\\hbar G(x_0,2\\pi \\hbar \\xi_0)}")#text(", as well as higher derivatives of ")#mi("{F \\ast_\\hbar G}")#text(" evaluated at arbitrary points ")#mi("{(x_0,2\\pi\\hbar\\xi_0)}")#text(". Indeed, with a certain amount of technical effort (which we omit here) we see that ")#mi("{F \\ast_\\hbar G}")#text(" is well-defined and obeys ")#link(<tao-34dcda3f0cf99ccb47e9>)[#text("(16)")]#text(", and we can rigorously establish the composition law ")#metadata(none) <tao-6bc4c043d40ffe009e25>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("(F \\ast_\\hbar G)(X,D)_W = F(X,D)_W G(X,D)_W.")]]

#text("If ")#mi("{F}")#text(" and ")#mi("{G}")#text(" are polynomials, we see (using the fact that any operator has a unique symbol ")#mi("{F}")#text(") that the product ")#mi("{\\ast_\\hbar}")#text(" given here coincides exactly with the Moyal product ")#link(<tao-6030984d10adab3535e6>)[#text("(11)")]#text(". As a consequence, by testing on gaussian wave packets using Lemma ")#link(<tao-63acfa239a51e0a33c7f>)[#text("1")]#text(", one can show that this composition law ")#mi("{\\ast_\\hbar}")#text(" has an asymptotic series given by the Moyal product, thus for any ")#mi("{k}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("F \\ast_\\hbar G = \\sum_{j=0}^k \\frac{1}{j!} (\\frac{i\\hbar}{2})^j \\omega^{\\otimes j}(\\nabla^j F, \\nabla^j G) + \\hbar^{k-O(1)} E_{k,\\hbar}")]]

#text("where the error ")#mi("{E_{k,\\hbar}}")#text(" obeys the bound ")#link(<tao-34dcda3f0cf99ccb47e9>)[#text("(16)")]#text(" (with the constant ")#mi("{C}")#text(" independent of ")#mi("{k}")#text(" and ")#mi("{\\hbar}")#text(", and the constant ")#mi("{C_{i,j}}")#text(" depending on ")#mi("{k}")#text(" but uniform in ")#mi("{\\hbar}")#text("). We will not give full details here, but roughly speaking, bound ")#mi("{E_{k,\\hbar}}")#text(" to high order at some point ")#mi("{(x_0, 2\\pi \\hbar \\xi_0)}")#text(", one can subtract off a Taylor polynomial from both ")#mi("{F}")#text(" and ")#mi("{G}")#text(" to reduce to the case when at least one of ")#mi("{F,G}")#text(" vanishes to high order at ")#mi("{(x_0, 2\\pi \\hbar \\xi_0)}")#text(", at which point Lemma ")#link(<tao-63acfa239a51e0a33c7f>)[#text("1")]#text(" shows that ")#mi("{F \\ast_\\hbar G(X,D)_W}")#text(" almost annihilates any gaussian wave packet supported near ")#mi("{(x_0, 2\\pi \\hbar \\xi_0)}")#text(" in phase space, and thus must have very small symbol at ")#mi("{(x_0,2\\pi \\hbar \\xi_0)}")#text("; a similar (but more complicated) argument also allows one to control derivatives of the symbol of ")#mi("{F \\ast_\\hbar G}")#text(". In a similar vein, the commutator ")#mi("{\\frac{1}{\\hbar} [F(X,D)_W, G(X,D)_W]}")#text(" of two operators ")#mi("{F(X,D)_W, G(X,D)_W}")#text(" with symbols ")#mi("{F,G}")#text(" obeying ")#link(<tao-34dcda3f0cf99ccb47e9>)[#text("(16)")]#text(" can be described by a symbol with asymptotic series ")#link(<tao-a9fe349640f8fb9f795f>)[#text("(12)")]#text("; we omit the details. These facts form the basis for the ")#emph[#text("pseudodifferential calculus")]#text(", which we will not develop further here; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1766415")[#text("Taylor’s book")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=983366")[#text("Folland’s book")]#text(" for more details.")

#text("We can also relate the Moyal product to the ")#link("http://en.wikipedia.org/wiki/Gabor%E2%80%93Wigner_transform")[#text("Wigner transform")]

#align(center)[#tao-fit-display[#mitex("W(f)(x, 2\\pi\\hbar \\xi) := \\int_{\\bf R} f( x-a/2) \\overline{f}(x+a/2 ) e^{-2\\pi i a \\xi}\\ da.")]]

#text("Comparing this with ")#link(<tao-9294ab38039f60d2ec53>)[#text("(19)")]#text(", we see that ")#mi("{W(f)}")#text(" can also be interpreted as the symbol of the rank one operator")

#align(center)[#tao-fit-display[#mitex("T_f: g \\mapsto \\langle g, f \\rangle f")]]

#text("where ")#mi("{\\langle g,f \\rangle := \\int_{\\bf R} g(x) \\overline{f(x)}\\ dx}")#text(". Given a quantised operator ")#mi("{F(X,D)_W}")#text(", we (formally, at least) have the relatino")

#align(center)[#tao-fit-display[#mitex("F(X,D)_W T_f \\overline{F}(X,D)_W = T_{F(X,D)_W f}")]]

#text("and hence (by ")#link(<tao-a1dcbd2066be82d79e45>)[#text("(15)")]#text(" and ")#link(<tao-6bc4c043d40ffe009e25>)[#text("(20)")]#text(") we see (again formally, at least) that")

#align(center)[#tao-fit-display[#mitex("W( F(X,D)_W f ) = F \\ast_\\hbar W(f) \\ast_\\hbar \\overline{F},")]]

#text("so that the action of pseudodifferential operators such as ")#mi("{F(X,D)_W}")#text(" can be described through the Wigner transform by some applications of the Moyal product.")

#text("Continuing this line of thought, suppose that ")#mi("{\\psi}")#text(" is a time-dependent function obeying ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger’s equation")]

#align(center)[#tao-fit-display[#mitex("i\\hbar \\partial_t \\psi = H(X,D)_W \\psi")]]

#text("for some real-valued symbol ")#mi("{H}")#text(" (representing the Hamiltonian of the system). Passing from the wave function ")#mi("{\\psi}")#text(" to the ")#link("http://en.wikipedia.org/wiki/Density_matrix")[#text("density matrix")]#text(" ")#mi("{T_\\psi}")#text(", we observe that Schrödinger’s equation implies ")#link("http://en.wikipedia.org/wiki/Heisenberg_picture")[#text("Heisenberg’s equation")]

#align(center)[#tao-fit-display[#mitex("\\partial_t T_\\psi = \\frac{1}{i\\hbar} [H(X,D)_W, T_\\psi]")]]

#text("and hence (by formal applicaton of the Moyal product)")

#align(center)[#tao-fit-display[#mitex("\\partial_t W(\\psi) = \\frac{1}{i\\hbar} ( H \\ast_\\hbar W(\\psi) - W(\\psi) \\ast_\\hbar H ).")]]

#text("Applying ")#link(<tao-a9fe349640f8fb9f795f>)[#text("(12)")]#text(", we see that the Wigner transform of ")#mi("{\\psi}")#text(" obeys the perturbed Hamiltonian flow equation ")#metadata(none) <tao-b9f4a2f6912d20509334>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\partial_t W(\\psi) = \\{ H, W(\\psi) \\} - \\frac{\\hbar^2}{24} \\omega^{\\otimes 3}(\\nabla^3 H, \\nabla^3 W(\\psi)) + \\ldots.")]]

#text("This should be compared with the evolution of a classical density function ")#mi("{\\rho: {\\bf R} \\times {\\bf R} \\rightarrow {\\bf R}^+}")#text(" in phase space with respect to transport along ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamilton’s equation of motion")]

#align(center)[#tao-fit-display[#mitex("\\dot x = \\partial_\\xi H; \\quad \\dot \\xi = - \\partial_x H,")]]

#text("which is given by the transport equation ")#metadata(none) <tao-80080e80a4d2a095e23f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\partial_t \\rho = \\{ H,\\rho\\}.")]]

#text("Thus we see in the semiclassical limit ")#mi("{\\hbar \\rightarrow 0}")#text(", the equation of motion for the Wigner transform ")#link(<tao-b9f4a2f6912d20509334>)[#text("(21)")]#text(" under the Schrödinger flow converges formally to the equation of motion for a classical density transported under Hamiltonian flow. This is one of the basic manifestations of the ")#link("http://en.wikipedia.org/wiki/Correspondence_principle")[#text("correspondence principle")]#text(" relating quantum and classical mechanics, and suggests that the Wigner transform of a wave function is a quantum analogue of a density function in phase space. (But the analogy is not perfect; in particular, the Wigner transform is almost never a non-negative function. See ")#link("http://www.ams.org/mathscinet-getitem?mr=983366")[#text("Folland’s book")]#text(" for more discussion.) Making all of these formal calculations and heuristics rigorous is a non-trivial task, requiring the development of the theory of ")#link("http://en.wikipedia.org/wiki/Fourier_integral_operator")[#text("Fourier integral operators")]#text(", and will not be discussed here.")

#heading(level: 1)[#text("Comments (19)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ae19e9d07a160366a905e557f3da2f3c6de439dacaedd5967574f77792c3c013-3aef3b142ef6eb4a3a666a1f711b86efd1ef4002e31c79e42ef4cfec7fe69b9f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fred Lunnon")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-179555")[#strong[#text("Fred Lunnon")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2012")])]

#text("Section 1 penultimate sentence: F^*(z) definition contradictory?")

#emph[#text("[Sorry, I don’t see what the problem is here. Note that the use of the asterisk in ")#mi("F^*(z)")#text(" does not quite denote adjoint or complex conjugation, although it is of course related to those two concepts. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/59e7cc015abe36655329b57fc473d54b0124e40428d9299fab3212350430dace-d68dc7a9cd8bb487b1e36264fcdb4a497a80be48ec13c7aec300b89cdfa2d222.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Speyer")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-179583")[#strong[#text("David Speyer")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2012")])]

#text("I haven’t finished reading to the end yet, but I think the first section would be much easier to read if you started with the observation that Weyl quantization has a ")#mi("SL_2")#text(" symmetry. Namely, let ")#mi("V")#text(" be the two dimensional vector space generated by ")#mi("A")#text(" and ")#mi("B")#text("; let ")#mi("\\bigotimes^{\\bullet} V")#text(" be the tensor algebra ")#mi("\\mathbb{C} \\oplus V \\oplus V \\otimes V \\oplus \\cdots")#text(" and let ")#mi("R")#text(" be the ring generated by the operators ")#mi("A")#text(" and ")#mi("B")#text(". If ")#mi("g")#text(" is in ")#mi("SL(V)")#text(", and ")#mi("u")#text(" and ")#mi("v")#text(" are operators from ")#mi("V")#text(", then ")#mi("[gu, gv]= [u,v]")#text(". So ")#mi("SL(V)")#text(" acts on ")#mi("R")#text(", and the map ")#mi("\\bigoplus^{\\bullet} V \\to R")#text(" commutes with the ")#mi("SL(V)")#text(" action.")

#text("The Weyl quantization is to lift an element of ")#mi("R")#text(" to the unique preimage in ")#mi("\\bigoplus^{\\bullet} V")#text(" which lies in ")#mi("S^{\\bullet}(V)")#text(". This choice of lifts manifestly respects the ")#mi("SL(V)")#text(" symmetry.")

#text("Therefore, in section 1, there is no need to carry around the ")#mi("(sA+tB)")#text(" and ")#mi("(s^{\\prime}A + t^{\\prime} B)")#text(" terms. Just use the ")#mi("SL(V)")#text(" symmetry to reduce to the case where one operator is ")#mi("A")#text(" and the other is ")#mi("t B")#text(". Moreover, if you want to make life even simpler, you can work with just ")#mi("A")#text(" and ")#mi("B")#text(" and restore the powers of ")#mi("t")#text(" at the end by homogeneity.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-179717")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2012")])]

#text("Yes, this would work, although for the purposes of Section 1, one could also proceed without the SL_2 invariance just by writing ")#mi("A^{\\prime} := sA+tB")#text(", ")#mi("B^{\\prime} := s^{\\prime}A+t^{\\prime}B")#text(" and working with A’ and B’ throughout; this does not significantly affect the length of the presentation in this simple case, but is helpful when working with more than two variables as alluded to at the end of Section 1. To me it is a matter of taste – if one wants to prove some identity about finite-dimensional symplectic vector spaces, for instance, does one work in a coordinate free fashion, or does one apply the linear Darboux theorem first to place the symplectic form in a normal form? Both approaches are useful. (Of course, strictly speaking I did not work in a coordinate free fashion in my notes, since I did write everything in terms of A and B, but as mentioned above it is not too difficult to phrase things in the coordinate free formalism.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-179676")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2012")])]

#text("missing expository tag?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5b966165f041473617f81e50776e2c131afa821c5911f55e918a26ad0ee76638-2ee2f573e0661052db7e2dfb8a0d6b00ffcfb9eec3d7284b450e24cb162aba77.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steven Stadnicki")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-179801")[#strong[#text("Steven Stadnicki")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2012")])]

#text("Minor typo: your definition of the position operator ")#mi("X")#text(" is missing the factor of ")#mi("x")#text("; presumably it’s meant to be ")#mi("X(f(x)) := xf(x)")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91f2d5d3cc620cde0716551a9c140681def32044452bb86503a4e308c233dad9-9771e7221f6d26752c0ed4cd8eb973d214a1ceec966cc3e6071d86303236a715.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of degosson")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-179995")[#strong[#text("degosson")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2012")])]

#text("Perhaps I missed something, but it seems that you don’t mention a characteristic property of Weyl pseudodifferential operators: they are the only members of the Shubin class that have the property of symplectic/metaplectic covariance (Stein, Wong) . Also, the fact that Weyl operators is the “perfect” quantization procedure in QM is debatable, as has been pointed out by many physicists. In view of Schwartz’s kernel theorem “everything” which is continuous S–>S’ can be written as a Weyl operator, hence any quantum observable could be “dequantized”, but this is physically not true: there are quantum observables which have no classical analogue. A better (i.e. more physical) quantization procedure might very well be the Born-Jordan scheme, which is not always “dequantizable” (see my latest paper “Symplectic covariance properties for Shubin and Born–Jordan pseudo-differential operators” in the Trans. Amer. Math. Soc, online since last Saturday: ")#link("http://www.ams.org/journals/tran/0000-000-00/")[#text("http://www.ams.org/journals/tran/0000-000-00/")]#text(").")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d29cf08f82fb3a9d705f937a93242bf9c91e82debcf294bf8cd6a5fd5f672297-20935afc1f681cad3aca586dd7a891900803c4410bb11af7c4968fbc23ec5cec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam Sachdev")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-180711")[#strong[#text("Sam Sachdev")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2012")])]

#text("Totally fascinating. Thanks for taking time to make notes on Weyl quantisation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e84b6f8e0e937f4fb4aa554bcbc4ab0cfed90db5f356bcfca1a5dc032206eb-df0274d4fa00182253b22e6fdbcf17c1937d8d5713184d5d85ead37c4e2a9a72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ����Ԫ")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-184184")[#strong[#text("����Ԫ")]]#text(size: 9pt, fill: rgb("596477"), " · 20 October 2012")])]

#text("I appreciate it very much that you send every new post of ‘what’s new’, however could you please send me the whole post rather than just a part of it.")

#text("Yours sincere,")

#text("Han Daoyuan")

#text("Sent from my iPad")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cb3280d4a3ac59b59c4cf2c33043f35c9d5c9f277083c51cc4b2e3163aa25a7-6a9cd9f58b7183b2038ce7a394dc5461cc80a5a1b8a2711b65195916592b725c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marcelo de Almeida")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-189507")[#strong[#text("Marcelo de Almeida")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2012")])]

#text("Reblogged this on ")#link("http://nucaltiado.wordpress.com/2012/11/05/359/")[#text("Being simple")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lars Hormander « What’s new")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-198030")[#strong[#text("Lars Hormander « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2012")])]

#text("[…] to multiplying a phase space distribution by the symbol of that operator, as discussed in this previous blog post. Note that such operators only change the amplitude of the phase space distribution, but not the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b16b57b2061018808964e85b00b84d898a2186a561a818f9482831648fbf5a1-e17d544f392b6bfd0cc692da244bea947ad4973eb1a964f22aae0e67f2cfe30b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Review of wigner nj-Symbols | quantumtetrahedron")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-347735")[#strong[#text("Review of wigner nj-Symbols | quantumtetrahedron")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2014")])]

#text("[…] Some notes on Weyl quantisation (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9b16b57b2061018808964e85b00b84d898a2186a561a818f9482831648fbf5a1-e17d544f392b6bfd0cc692da244bea947ad4973eb1a964f22aae0e67f2cfe30b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Semiclassical Mechanics of the Wigner 6j-Symbol by Aquilanti et al | quantumtetrahedron")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-359224")[#strong[#text("Semiclassical Mechanics of the Wigner 6j-Symbol by Aquilanti et al | quantumtetrahedron")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2014")])]

#text("[…] Some notes on Weyl quantisation (terrytao.wordpress.com) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/716d7de7edeb28960631ec7e76fa52acfa436cc2a720dd9596f03a5a7fd86cb3-889e0865f621c1452c244b0bb6518ab0f9f5a6dad6ef86fdf335c9cf4a9b3b95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of João Cortes")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-497084")[#strong[#text("João Cortes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("Hi professor,")

#text("I am trying to understand why the weyl ordering results in an associative product rule for formal series.")

#text("I followed your steps up until you combine equations 5,7,9. However, I don’t understand how you “compare coefficients”. In the left hand side of the equation you obtain after that (not numbered), you isolate the term corresponding to the product of the n’th and m’th power of each exponential.")#linebreak()#text(" How do you find, in the left hand side, the terms that correspond to this?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-497103")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2018")])]

#text("Collect the terms whose ")#mi("s,t")#text(" total degree is ")#mi("n")#text(" and whose ")#mi("s^{\\prime},t^{\\prime}")#text(" total degree is ")#mi("m")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/716d7de7edeb28960631ec7e76fa52acfa436cc2a720dd9596f03a5a7fd86cb3-889e0865f621c1452c244b0bb6518ab0f9f5a6dad6ef86fdf335c9cf4a9b3b95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of João Cortes")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-497338")[#strong[#text("João Cortes")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("thanks for your reply. It’s weird being able to communicate with you. The wonders of the internet!")#linebreak()#text(" I have another question, if you don’t mind.")#linebreak()#text(" Do you know any simple argument to show that different orders of a monomial of operators (that is, different ways of multiplying n ")#mi("A^{\\prime}s")#text(" and m $B’s$) correspond to different polynomials, using the Weyl prescription?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-497393")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("Look at what such a monomial does to a monomial ")#mi("x^k")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5a9bee038ca4cdb25a2261f8d1d7beafbb27cfdd1a417186b7f292856529d386-86e68c79abf12ae7763315175339236dc18032ea70fcb6e8147ee5f567ef8450.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alwill")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-678148")[#strong[#text("alwill")]]#text(size: 9pt, fill: rgb("596477"), " · 19 May 2023")])]

#text("Thanks for the derivation, this helps me for doing my homework.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-686968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2024")])]

#text("Hello,")

#text("This blog post has been extremely educational for me. I apologize in advance for my simple question:")

#text("It appears to me that the Moyal product between functions f and g is defined when both are Schwarz functions. Why is it also well defined for polynomials?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/07/some-notes-on-weyl-quantisation/#comment-686978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2024")])]

#text("For polynomials, all but finitely many terms in the sum will vanish.")
]
]
