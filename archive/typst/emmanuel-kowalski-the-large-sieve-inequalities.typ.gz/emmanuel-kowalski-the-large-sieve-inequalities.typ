// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/
// Converted to Typst by tao2typ: "2026-10-14T06:52:42.142174+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "(Emmanuel Kowalski) The large sieve inequalities", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("(Emmanuel Kowalski) The large sieve inequalities")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/")[#text("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("[")#emph[#text("This post is authored by ")#link("http://www.ufr-mi.u-bordeaux.fr/~kowalski/")[#text("Emmanuel Kowalski")]]#text(".]")

#text("This post may be seen as complementary to the post “")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("The parity problem in sieve theory")]#text("“. In addition to a survey of another important sieve technique, it might be interesting as a discussion of some of the foundational issues which were discussed in the comments to that post.")

#text("Many readers will certainly have heard already of one form or another of the “large sieve inequality”. The name itself is misleading however, and what is meant by this may be something having very little, if anything, to do with sieves. What I will discuss are genuine sieve situations.")

#text("The framework I will describe is explained in the preprint ")#link("http://www.arxiv.org/abs/math.NT/0610021")[#text("arXiv:math.NT/0610021")]#text(", and in a forthcoming Cambridge Tract. I started looking at this first to have a common setting for the usual large sieve and a “sieve for Frobenius” I had devised earlier to study some arithmetic properties of families of zeta functions over finite fields. Another version of such a sieve was described by ")#link("http://math.berkeley.edu/~zywina/")[#text("Zywina")]#text(" (“The large sieve and Galois representations”, preprint), and his approach was quite helpful in suggesting more general settings than I had considered at first. The latest generalizations more or less took life naturally when looking at new applications, such as discrete groups.")

#text("Unfortunately (maybe), there will be quite a bit of notation involved; hopefully, the illustrations related to the classical case of sieving integers to obtain the primes (or other subsets of integers with special multiplicative features) will clarify the general case, and the “new” examples will motivate readers to find yet more interesting applications of sieves.")

#metadata(none) <tao-f15b71765398e92c52e6>

#heading(level: 1)[#text("— Setting up the sieve —")]

#text("The objects to sieve will be in a fixed set ")#mi("Y")#text(", typically infinite. The “sieve” is related to the assumed existence of a set of surjective maps ")#mi("\\rho_{\\ell}:Y\\rightarrow Y_{\\ell}")#text(", where ")#mi("{\\ell}")#text(" runs through another (arbitrary) set ")#mi("\\Lambda")#text(", and ")#mi("Y_{\\ell}")#text(" is a finite set. Combinatorialists can think of these maps as a family of colorings of ")#mi("Y")#text(", and number-theorists can think of “reduction” maps modulo ")#mi("{\\ell}")#text(", in the case where ")#mi("\\Lambda")#text(" is a subset of prime numbers. Indeed, the classical case occurs with ")#mi("Y := {\\mathbf Z}")#text(", ")#mi("\\Lambda")#text(" the set of primes, and ")#mi("\\rho_{\\ell}")#text(" being the reduction map.")

#text("We now want to define sifted sets and try to “count” them. This is where classically one would look at a discrete interval of integers, and one could think of taking a finite subset of ")#mi("Y")#text(" as a generalization. However, we will generalize this by looking at an arbitrary measure space ")#mi("(X,\\mu)")#text(", such that ")#mi("\\mu(X)")#text(" is finite, and assume there is a map (measurable in an obvious sense) ")#mi("x\\mapsto F_x")#text(" from ")#mi("X")#text(" to ")#mi("Y")#text(", and instead of “counting”, we will try to understand the measure (under ")#mi("\\mu")#text(") of sifted sets, of the following type:")

#align(center)[#tao-fit-display[#mitex("S(X,\\Omega,L):=\\{x\\in X : \\rho_{\\ell}(F_x)\\notin \\Omega_{\\ell}, {\\ell}\\in L\\}")]]

#text("whenever subsets ")#mi("\\Omega_{\\ell}\\subset Y_{\\ell}")#text(" have been chosen, say for a finite subset ")#mi("L")#text(" of ")#mi("\\Lambda")#text(".")

#text("Classically, we have ")#mi("X:=\\{1,\\ldots, N\\}")#text(" for some integer ")#mi("N")#text(", ")#mi("\\mu")#text(" is the counting measure, and one might consider ")#mi("\\Omega_{\\ell}")#text(", for ")#mi("{\\ell}")#text(" prime, to be e.g., ")#mi("\\{0,-2\\}")#text(" modulo ")#mi("{\\ell}")#text(": if ")#mi("L")#text(" is the set of primes ")#mi("\\leq \\sqrt{N}")#text(", we see that ")#mi("S(X,\\Omega,L)")#text(" is (essentially) the set of twin primes between ")#mi("\\sqrt{N}")#text(" and ")#mi("N")#text(". It is clear from this that in most applications we will really have a sequence of sets ")#mi("X")#text(" (with attending ")#mi("\\mu")#text(" and ")#mi("F")#text("), depending on some parameter (here ")#mi("N")#text("), and it will be when this parameter gets large that the results will be interesting. In particular, we need to be careful about the uniformity of our results if they are going to be useful.")

#heading(level: 1)[#text("— First examples —")]

#text("There are a great many different settings that can be phrased in such a way. Here are a few, beyond the case of integers, which are related to existing results and can be described fairly easily:")

#strong[#text("Example 1")]#text(". If we have a probability space ")#mi("(\\Omega,P)")#text(", and a (finite) family of events ")#mi("A_i\\subset \\Omega")#text(", ")#mi("i\\in I")#text(", we can set up a sieve by taking ")#mi("X:=Y:=\\Omega")#text(", ")#mi("\\mu:=P")#text(", ")#mi("\\Lambda:=I")#text(", ")#mi("Y_{i}:=\\{0,1\\}")#text(", and letting ")#mi("\\rho_i")#text(" be the characteristic function of ")#mi("A_i")#text(". Then the sifted set ")#mi("S")#text(" is simply the event which is the intersection of the complements of ")#mi("A_i")#text(", if we take ")#mi("\\Omega_i=1")#text("; the probability of ")#mi("S")#text(" can be expressed using the usual ")#link("http://en.wikipedia.org/wiki/Inclusion-exclusion_principle")[#text("inclusion-exclusion formula")]#text(". ")#mi("\\diamond")

#strong[#text("Example 2")]#text(". ")#link("http://www.ams.org/mathscinet-getitem?mr=332694")[#text("Gallagher used")]#text(" the large sieve in several variables to study the typical Galois group of a monic integral polynomial with height ")#mi("< T")#text(", ")#mi("T")#text(" getting large. Here ")#mi("Y")#text(" can be defined to be the space of monic integral polynomials of degree ")#mi("d")#text(", ")#mi("X")#text(" the subset of those with height ")#mi("<T")#text(", ")#mi("\\Lambda")#text(" is the set of primes, ")#mi("Y_{\\ell}")#text(" the space of monic polynomials of degree ")#mi("d")#text(" over the finite field ")#mi("\\mathbf{Z}/{\\ell}\\mathbf{Z}")#text(", and ")#mi("\\rho_{\\ell}")#text(" is the obvious restriction map. ")#mi("\\diamond")

#strong[#text("Example 3")]#text(".")#link("http://www.ams.org/mathscinet-getitem?mr=1075658")[#text(" Serre used")]#text(" a variant of the large sieve to study the density of quadratic forms over ")#mi("\\mathbf{Q}")#text(" in ")#mi("n")#text(" variables which have a non-trivial rational zero. Here, ")#mi("Y")#text(" can be described as the set of coefficients describing the quadratic forms, the sets ")#mi("X")#text(" are those quadratic forms with ")#link("http://en.wikipedia.org/wiki/Height_of_a_polynomial")[#text("height")]#text(" ")#mi("\\leq T")#text(", with ")#mi("T")#text(" getting large, ")#mi("\\Lambda")#text(" is the set of primes, and ")#mi("\\rho_{\\ell}")#text(" is the reduction modulo ")#mi("{\\ell}^2")#text(". ")#mi("\\diamond")

#strong[#text("Example 4")]#text(".")#link("http://www.ams.org/mathscinet-getitem?mr=2144974")[#text(" Poonen used")]#text(" a very nice sieve to find the density, among homogeneous polynomials ")#mi("f\\in \\mathbf{F}_q[x_0,...,x_n]")#text(", with coefficients in a finite field ")#mi("\\mathbf{F}_q")#text(", of those such that the intersection ")#mi("Z\\cap \\{f=0\\}")#text(" is smooth, where ")#mi("Z/\\mathbf{F}_q")#text(" is a fixed smooth subvariety ")#mi("Z")#text(" of projective ")#mi("n")#text("-space. One can set up the sieve more or less as follows: ")#mi("Y")#text(" is the set of all homogeneous polynomials with coefficients in ")#mi("\\mathbf{F}_q")#text(", for ")#mi("d\\geq 1")#text(" fixed, ")#mi("X")#text(" is the subset of polynomials of degree ")#mi("d")#text(" (and ")#mi("\\mu")#text(" the normalized counting measure on ")#mi("X")#text("), ")#mi("\\Lambda")#text(" is the set of closed points of ")#mi("Z")#text(" (which can be thought-of simply as the set of Galois-orbits of points of ")#mi("Z")#text(" over an algebraic closure of ")#mi("\\mathbf{F}_q")#text(") and ")#mi("\\rho_x")#text(", for ")#mi("x")#text(" such a point, maps ")#mi("Y")#text(" to the ")#mi("\\mathbf{F}_q")#text("-vector space of possible Taylor expansions of order 1. Poonen uses as sieving sets the ")#mi("\\Omega_x")#text(" which characterize ")#mi("x")#text(" to be a singular point, so that an ")#mi("f")#text(" survives sieving by all ")#mi("x")#text(" precisely when ")#mi("Z\\cap \\{f=0\\}")#text(" is smooth. ")#mi("\\diamond")

#link("http://www.ams.org/mathscinet-getitem?mr=332694")[#text("http://www.ams.org/mathscinet-getitem?mr=332694")]

#text("We will give a few more recent examples later in this post.")

#heading(level: 1)[#text("— Heuristics —")]

#text("Now, we will describe the general large-sieve inequality which can be used in many cases to obtain an ")#emph[#text("upper bound")]#text(" for the measure of the sifted set. Let us try first to guess what the “right” answer should be, which will highlight the need for a further piece of data, which is usually merely implicit in the classical cases.")

#text("The heuristic value for the measure of the sifted set arises from two fairly natural assumptions: first, one might expect that the various ")#mi("\\rho_{\\ell}")#text(" should be “independent”, so the measure of the sifted set should be roughly equal to")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\mu(X)\\prod_{{\\ell}\\in L}{(1-\\tilde{\\nu}_{\\ell}(\\Omega_{\\ell}))}")]]

#text("where ")#mi("\\tilde{\\nu}_{\\ell}")#text(" is the (normalized) image measure on ")#mi("Y_{\\ell}")#text(" of ")#mi("\\mu")#text(" via ")#mi("X\\rightarrow Y_{\\ell}")#text(" obtained by composition:")

#align(center)[#tao-fit-display[#mitex("\\tilde{\\nu}_{\\ell}(y)=\\frac{\\mu(\\{x:\\rho_{\\ell}(F_x)=y\\})}{\\mu(X)}.")]]

#text("This measure depends on ")#mi("X")#text(" (hence on some unspecified asymptotic parameter, such as the length of the interval of integers considered) and may be hard to understand; however, the second natural assumption is that this measure should be close to some “natural” measure ")#mi("\\nu_{\\ell}")#text(" on ")#mi("Y_{\\ell}")#text(" which is independent of ")#mi("X")#text(" (if ")#mi("Y")#text(" has some natural measure, it could be the image of this measure under ")#mi("\\rho_{\\ell}")#text("). In other words, we may hope that ")#mi("\\rho_{\\ell}(F_x)")#text(", for ")#mi("x\\in X")#text(", becomes equidistributed with respect to such a measure.")

#text("In the classical case, integers in large intervals are uniformly distributed modulo any fixed prime, so ")#mi("\\nu_{\\ell}(y)=1/\\ell")#text(" in this case. Note that assuming some form of asymptotic equidistribution is typically the content of standard “sieve axioms”, introducing sieve remainder terms measuring the default of exact equidistribution. In all the examples above, the target set ")#mi("Y_{\\ell}")#text(" are finite abelian groups, and the natural probability density is also the normalized counting measure, except in the case of inclusion-exclusion; there the natural measure is the distribution law of the characteristic function of ")#mi("A_i")#text(": it maps ")#mi("1\\mapsto P(A_i)")#text(", ")#mi("0\\mapsto 1-P(A_i)")#text(".")

#heading(level: 1)[#text("— Further examples —")]

#text("Here are now the promised “new” examples, which in particular show further examples of non-trivial sieve settings, and less trivial measures on the finite sets ")#mi("Y_{\\ell}")#text(".")

#strong[#text("Example 5")]#text(". Let ")#mi("E/\\mathbf{Q}")#text(" be an elliptic curve defined over the rationals, given in Weierstrass form ")#mi("y^2=x^3+Ax+B")#text(" with ")#mi("A")#text(", ")#mi("B")#text(" integers. We can take ")#mi("Y:=E(\\mathbf{Q})")#text(", the finitely generated ")#link("http://en.wikipedia.org/wiki/Mordell-Weil_group")[#text("Mordell-Weil group")]#text(" of rational points on ")#mi("E")#text(", ")#mi("\\Lambda")#text(" the set of primes (not dividing the discriminant for simplicity), ")#mi("Y_p")#text(" the image of ")#mi("Y")#text(" under the reduction map modulo ")#mi("p")#text(". In general, this image is badly understood (it certainly is not equal to the group of points on the reduction of ")#mi("E")#text(" modulo ")#mi("p")#text(", in most cases, for instance because the latter grows with ")#mi("p")#text(", whereas ")#mi("Y")#text(" may well be finite). If we take ")#mi("\\Omega_p")#text(" to be the origin of the group law, the sifted set has an interesting interpretation: it is the set of ")#mi("S")#text("-integer solutions of the equation which “is” ")#mi("E")#text(", where ")#mi("S")#text(" is the set of primes dividing the discriminant (i.e., it is the set of solutions to the equation where the denominators of ")#mi("x")#text(" and ")#mi("y")#text(" are divisible only by those primes). In particular, in contrast with classical sieves, those points are examples of interesting elements which survive after “infinite” sieving (though a famous ")#link("http://en.wikipedia.org/wiki/Siegel's_theorem_on_integral_points")[#text("theorem of Siegel")]#text(" states there are only finitely many). ")#mi("\\diamond")

#strong[#text("Example 6")]#text(". Let ")#mi("Y:=SL(n,\\mathbf{Z})")#text(", and ")#mi("S")#text(" a fixed finite symmetric set of generators (e.g., ")#mi("S")#text(" is the set of ")#link("http://en.wikipedia.org/wiki/Elementary_matrix")[#text("elementary matrices")]#text(" with ")#mi("\\pm 1")#text(" off the diagonal). For a prime ")#mi("{\\ell}")#text(", let ")#mi("Y\\rightarrow Y_{\\ell}")#text(" be reduction modulo ")#mi("{\\ell}")#text("; it is not obvious, but true, that the image is ")#mi("Y_{\\ell}=SL(n,\\mathbf{Z}/{\\ell}\\mathbf{Z})")#text(" for all primes ")#mi("{\\ell}")#text(". The natural measure is again the counting measure on ")#mi("Y_{\\ell}")#text(". We can define different types of sets to sieve (balls in ")#link("http://en.wikipedia.org/wiki/Word_metric")[#text("word length")]#text(" or archimedean metric for instance), but one that has interest as being quite different-looking from the standard ones is the following: take ")#mi("X")#text(" to be an abstract probability space, and ")#mi("F=X_k")#text(" a ")#mi("G")#text("-valued random variable ")#mi("X\\rightarrow Y")#text(" obtained as the ")#mi("k")#text("-th step of a ")#link("http://en.wikipedia.org/wiki/Random_walk")[#text("random walk")]#text(" defined by ")#mi("X_0=1")#text(", ")#mi("X_{k+1}=X_k\\xi_{k+1}")#text(", where the steps ")#mi("\\xi_k")#text(" are independent, uniformly distributed ")#mi("S")#text("-valued random variables (with ")#mi("P(\\xi_k=s)>0")#text(" for all ")#mi("s")#text("); for instance, ")#mi("\\xi_k")#text(" may be chosen independently and uniformly at random in ")#mi("S")#text(". In this setting, interesting sifted sets might be those where ")#mi("X_k")#text(" is a matrix with prime or almost prime entries (in this case the setup is closely related to ongoing work of Bourgain, Gamburd, and Sarnak, and other collaborators such as J. Liu, A. Nevo), or those ")#mi("X_k")#text(" has for instance a reducible characteristic polynomial, or one with small splitting field. This type of setting was considered first ")#link("http://www.arxiv.org/abs/math.NT/0604489")[#text("by I. Rivin")]#text(", with fairly remarkable applications in low-dimensional topology and for the theory of free-group automorphisms. One can do this type of things also for other discrete groups, of course. ")#mi("\\diamond")

#strong[#text("Example 7")]#text(". The last example is studied by ")#link("http://www.arxiv.org/abs/math.NT/0604489")[#text("Zywina")]#text(" in his preprint “The large sieve and Galois representations”, and is a number field analogue of the sieve for Frobenius over function fields considered earlier ")#link("http://www.ams.org/mathscinet-getitem?mr=2289204")[#text("by myself")]#text(" (the latter is notationally a bit more complicated). We select a special case again for concreteness, and disregard for simplicity some issues of ")#link("http://en.wikipedia.org/wiki/Ramification")[#text("ramification")]#text(". Let ")#mi("E/\\mathbf{Q}")#text(" be an elliptic curve without ")#link("http://en.wikipedia.org/wiki/Complex_multiplication")[#text("complex multiplication")]#text(". We consider for ")#mi("Y")#text(" the set of conjugacy classes in the group ")#mi("G")#text(" which is the image of the Galois group of ")#mi("\\mathbf{Q}")#text(" under the natural action on all ")#link("http://en.wikipedia.org/wiki/Torsion_%28algebra%29")[#text("torsion points")]#text(" of ")#mi("E")#text("; by ")#link("http://www.ams.org/mathscinet-getitem?mr=387283")[#text("work of Serre")]#text(", it is known that ")#mi("G")#text(" is naturally isomorphic to an open subgroup of ")#mi("GL(2,\\hat{\\mathbf{Z}})")#text(". We take ")#mi("\\Lambda")#text(" to be the set of primes such that ")#mi("G_{\\ell}")#text(", the Galois group ")#mi("G_{\\ell}")#text(" of the action on ")#mi("{\\ell}")#text("-torsion points, is isomorphic to ")#mi("GL(2,\\mathbf{F}_{\\ell})")#text(": the result of Serre mentioned above implies that ")#mi("\\Lambda")#text(" contains all primes except finitely many.There is a surjection ")#mi("G\\rightarrow G_{\\ell}")#text(", and correspondingly a surjective map ")#mi("Y\\rightarrow Y_{\\ell}")#text(" where ")#mi("Y_{\\ell}")#text(" is the set of conjugacy classes in ")#mi("G_{\\ell}")#text(". On ")#mi("Y_{\\ell}")#text(", the natural measure ")#mi("\\nu_{\\ell}")#text(" maps a conjugacy class ")#mi("C")#text(" to ")#tao-math("\\left|C\\right|/\\left|G_{\\ell}\\right|", block: false)#text("; since ")#mi("G_{\\ell}")#text(" is not abelian, this is ")#emph[#text("not")]#text(" counting measure on ")#mi("Y_{\\ell}")#text(". Now we take ")#mi("X")#text(" to be the set of prime numbers ")#mi("p\\leq T")#text(", for some ")#mi("T")#text(", which do not divide the discriminant of ")#mi("E")#text(". The map ")#mi("F")#text(" from ")#mi("X")#text(" to ")#mi("Y")#text(" maps ")#mi("p")#text(" to the conjugacy class of the ")#link("http://en.wikipedia.org/wiki/Frobenius_automorphism")[#text("Frobenius automorphism")]#text(" at ")#mi("p")#text(" (it is here that some care with ramification is needed to be precise).")

#text("Note that the ")#link("http://en.wikipedia.org/wiki/Equidistribution")[#text("equidistribution")]#text(" statement for a fixed ")#mi("{\\ell}")#text(" is valid, and is a special case of the ")#link("http://en.wikipedia.org/wiki/Chebotarev_density_theorem")[#text("Chebotarev Density Theorem")]#text(": for any conjugacy class ")#mi("C")#text(" in ")#mi("Y_{\\ell}")#text(", we have ")#tao-math("\\lim_{T\\rightarrow +\\infty} \\frac{\\left|\\{p\\leq T : \\rho_{\\ell}(F_p)=C \\}\\right|}{\\pi(T)} =\\frac{\\left|C\\right|}{\\left|G_{\\ell}\\right|}.", block: false)

#text("What are the applications of such a sieve setting? They arise because ")#mi("F_p")#text(" has the following properties: the trace of ")#mi("\\rho_{\\ell}(F_p)")#text(" (seen as an element of ")#mi("GL(2,\\mathbf{F}_{\\ell})")#text(") is the residue class modulo ")#mi("{\\ell}")#text(" of the integer ")#mi("a_p")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\left|E(\\mathbf{F}_p)\\right|=p+1-a_p", block: true)]]

#text("In particular, controlling the conjugacy class of ")#mi("F_p")#text(" implies that the order of the curve modulo ")#mi("p")#text(" is (somehow) controlled, and these orders (or ")#mi("a_p")#text(" equivalently) control (at least conjecturally!) much of the arithmetic properties of the elliptic curve. In particular, recall that the ")#link("http://en.wikipedia.org/wiki/Birch_and_Swinnerton-Dyer_conjecture")[#text("Birch and Swinnerton-Dyer conjecture")]#text(" states that the rank of ")#mi("E(\\mathbf{Q})")#text(" should be the order at ")#mi("s=1")#text(" of the Euler product")

#align(center)[#tao-fit-display[#mitex("\\prod_{p}{(1-a_p p^{-s}+p^{1-2s})^{-1}}.")]]

#text("Certainly, one can see how sieving in this context will lead to information on, say, almost-prime values of ")#tao-math("\\left|E(\\mathbf{F}_p)\\right|", block: false)#text(", and many other arithmetic properties of the ")#mi("a_p")#text(" which are of great importance for instance in understanding some algorithms such as ")#link("http://en.wikipedia.org/wiki/Elliptic_curve_primality_proving")[#text("elliptic curve primality proving")]#text(", ")#link("http://en.wikipedia.org/wiki/Elliptic_curve_cryptography")[#text("elliptic curve cryptography")]#text(", etc. ")#mi("\\diamond")

#heading(level: 1)[#text("— Two sieve inequalities —")]

#text("Coming back to the “large sieve inequalities”, we mentioned that they will provide one possible way to get upper bounds for the measure of ")#mi("S(X,\\Omega,L)")#text(", which are often comparable in size with the “expected” measure (1) above. There are two forms, which are inspired by the corresponding inequalities for integers due ")#link("http://www.ams.org/mathscinet-getitem?mr=31505")[#text("to Renyi")]#text(" and")#link("http://www.ams.org/mathscinet-getitem?mr=224585")[#text(" Montgomery")]#text(" respectively. Both depend on bounding a further quantity ")#mi("\\Delta")#text(", which is the crucial ingredient, and which is explained below (without knowing something about ")#mi("\\Delta")#text(", the inequalities are useless; they should be read assuming that ")#mi("\\Delta")#text(" is close to ")#mi("\\mu(X)")#text(", possibly up to a constant multiplicative factor).")

#strong[#text("I")]#text(". Renyi’s sieve takes the form")

#align(center)[#tao-fit-display[#mitex("\\int_{X}{\\Bigl( N(x,L)-M(L) \\Bigr)^2d\\mu(x)}\\leq \\Delta M(L)")]]

#text("where ")#mi("N(x,L)")#text(" is the number of ")#mi("{\\ell}\\in L")#text(" such that ")#mi("\\rho_{\\ell}(F_x)\\in \\Omega_{\\ell}")#text(", while ")#mi("M(L)")#text(" is the “expected” value of this quantity, namely the sum over ")#mi("{\\ell}\\in L")#text(" of ")#mi("\\nu_{\\ell}(\\Omega_{\\ell})")#text(".")

#text("So there is a clear interpretation: if ")#mi("\\Delta")#text(" is indeed close to ")#mi("\\mu(X)")#text(", this means that ")#mi("N(x,L)")#text(" is close to ")#mi("M(L)")#text(" for “most” ")#mi("x")#text(" (in mean-square sense). In the case of counting primes, this inequality becomes the Turán inequality")

#align(center)[#tao-fit-display[#mitex("\\sum_{n\\leq N}{(\\omega(n)-\\log\\log N)}^2 \\ll N(\\log\\log N)^{-1},")]]

#text("which is known to be sharp (in fact there is an asymptotic formula of this size for the left-hand side).")

#text("In the case of Example 5 (elliptic curves), this gives some lower bound for the number of prime divisors of the denominator of “most” rational points (not without some extra work; and note that the proof require the use of ")#link("http://en.wikipedia.org/wiki/Siegel's_theorem_on_integral_points")[#text("Siegel’s Theorem")]#text(": it does not provide another approach to it).")

#text("In general, note that we obtain the bound")

#align(center)[#tao-fit-display[#mitex("\\mu(S)\\leq \\Delta M(L)^{-1}")]]

#text("for the measure of the sifted set, using positivity. This is weak; in the case of primes, when ")#mi("\\nu(\\Omega_{\\ell})")#text(" tends to zero (it gives the bound ")#mi("N(\\log\\log N)^{-1}")#text(" for the number of primes ")#mi("\\leq N")#text("), but quite strong when ")#mi("\\nu(\\Omega_{\\ell})")#text(" is fairly large (bounded below); indeed, these are the situations which characterize what Linnik called the “large” sieve. ")#mi("\\diamond")

#strong[#text("II")]#text(". The second sieve inequality is stronger in case the local densities ")#mi("\\nu_{\\ell}(\\Omega_{\\ell})")#text(" are small, in fact as strong qualitatively as the best “small” sieves. (But of course small sieve theory is developed a lot looking at lower bounds, which the large sieve does not approach directly — see ")#link("https://terrytao.wordpress.com/2007/06/05/open-question-the-parity-problem-in-sieve-theory/")[#text("the former post on the parity problem")]#text(").")

#text("Here the idea is to combine the ")#mi("Y_{\\ell}")#text(" to look at the possible “multi-colorings” ")#mi("Y\\rightarrow Y_{{\\ell}_1}\\times Y_{{\\ell}_2}\\times \\cdots")#text(", which classically means looking at the reductions modulo ")#link("http://en.wikipedia.org/wiki/Square-free")[#text("square-free")]#text(" integers, not only modulo primes.")

#text("Abstractly, this is done as follows: let ")#mi("Y_m")#text(", for ")#mi("m")#text(" a finite subset of ")#mi("\\Lambda")#text(", be the product of ")#mi("Y_{\\ell}")#text(" for ")#mi("{\\ell}\\in m")#text(". Define ")#mi("\\rho_m")#text(" in the obvious manner, but notice it may not be surjective. If it is, this means some analogue of the ")#link("http://en.wikipedia.org/wiki/Chinese_remainder_theorem")[#text("Chinese Remainder Theorem")]#text(" holds, and this may be very difficult to show (think about the case of elliptic curves). Similarly, having chosen ")#mi("\\Omega_{\\ell}")#text(", we can define ")#mi("\\Omega_m")#text(" as the product over elements of ")#mi("m")#text(". Now choose an arbitrary finite set ")#mi("M")#text(" of finite subsets of ")#mi("L")#text("; e.g., ")#mi("M")#text(" could correspond by unique factorization to the set of all square-free integers ")#mi("\\leq Q")#text(", if ")#mi("L")#text(" is the set of primes at most ")#mi("Q")#text(".")

#text("We now have")

#align(center)[#tao-fit-display[#mitex("\\mu(S)\\leq \\Delta H^{-1}")]]

#text("where ")#mi("\\Delta")#text(" is as above, and will be explained below, and")

#align(center)[#tao-fit-display[#mitex("H := \\sum_{m\\in M}{\\prod_{{\\ell}\\in m}{\\frac{\\nu_m(\\Omega_{\\ell})}{1-\\nu_{\\ell}(\\Omega_{\\ell})}}}.")]]

#text("Now this may look strange, but observe the following: if ")#mi("M")#text(" is the set of ")#emph[#text("all")]#text(" subsets of ")#mi("L")#text(", a moment’s thought reveals that")

#align(center)[#tao-fit-display[#mitex("H^{-1}=\\prod_{{\\ell}\\in L}{(1-\\nu(\\Omega_{\\ell}))},")]]

#text("i.e., for ")#mi("\\Delta=\\mu(X)")#text(", the right-hand side of the large-sieve inequality is exactly the expected value in (1). The problem is that, typically, ")#mi("\\Delta")#text(" would be too large if ")#mi("M")#text(" is that big (this is shown for instance by the problem of explosion of the remainder term in applying the ")#link("http://en.wikipedia.org/wiki/Legendre_sieve")[#text("Eratosthenes-Legendre sieve")]#text(" to compute the number of primes less than ")#mi("X")#text("). The interpretation of this is then similar to that of the earlier sieves by V. Brun: using all subsets of ")#mi("L")#text(" (all integers divisible by primes ")#mi("\\leq L")#text(") is too costly, but a suitable “cutoff” yields approximations to the truth which can remain very useful. (One case where one can take ")#mi("M")#text(" so large is for Example 1, if the event ")#mi("A_i")#text(" are independent so that by the very definition of independence, the probability of the sifted set ")#mi("S")#text(" is exactly")

#align(center)[#tao-fit-display[#mitex("P(S)=\\prod_{i}{(1-P(A_i))}=H^{-1},")]]

#text("and it turns out that in this case one has exactly ")#mi("\\Delta=1")#text(", so that")#linebreak()#text(" the large-sieve inequality is sharp in the full generality considered). ")#mi("\\diamond")

#text("Now we need finally to define ")#mi("\\Delta")#text(". The reason it was delayed is")#linebreak()#text(" that it will need yet more notation…")

#text("First, for each ")#mi("{\\ell}")#text(" in ")#mi("\\Lambda")#text(", let ")#mi("V_{\\ell}")#text(" be the finite dimensional Hilbert space of functions of mean-zero on ")#mi("Y_{\\ell}")#text(", i.e., of those ")#mi("f")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\sum_{y\\in Y_{\\ell}}{\\nu_{\\ell}(y)f(y)}=0")]]

#text("(with the inner product defined using the density ")#mi("\\nu_{\\ell}")#text(").")

#text("Select (arbitrarily) an orthonormal basis ")#mi("B_{\\ell}")#text(" of ")#mi("V_{\\ell}")#text(". Then consider the set ")#mi("B_m")#text(" of functions on ")#mi("Y_m")#text(" of the type")

#align(center)[#tao-fit-display[#mitex("(y_{\\ell})\\mapsto \\prod_{{\\ell}\\in m}{\\varphi_{\\ell}(y_{\\ell})}")]]

#text("where ")#mi("\\varphi_{\\ell}")#text(" is an element of the chosen basis of ")#mi("V_{\\ell}")#text(". Those functions form themselves an orthonormal basis for a “primitive” subspace of the space of functions on ")#mi("Y_m")#text(", with respect to the “product” inner-product on ")#mi("Y_m")#text(".")

#text("Finally, ")#mi("\\Delta")#text(" is defined to be the least non-negative real number such that the inequality")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m\\in M}{\\sum_{\\varphi\\in B_m}{\\Big{\\left|\\int_{X}{\\alpha(x)\\varphi(\\rho_{m}(F_x))d\\mu(x)}\\right|}^2}} \\leq \\Delta \\left\\|\\alpha\\right\\|^2,", block: true)]]

#text("holds for any square-integrable function ")#mi("\\alpha")#text(" on ")#mi("X")#text(". For Renyi’s inequality, ")#mi("M")#text(" is simply the set of singletons ")#mi("\\{{\\ell}\\}")#text(" for ")#mi("{\\ell}\\in L")#text(".")

#text("One can see quite easily that ")#mi("\\Delta")#text(" is independent of the choice of basis (but practical estimates may well depend on a clever selection) by interpreting it as the norm of some operator between Hilbert spaces.")

#text("Let’s look at the classical example of integers: there, ")#mi("V_{\\ell}")#text(" is the space of functions on ")#mi("\\mathbf{Z}/{\\ell}\\mathbf{Z}")#text(" which sum to zero, and a particular basis is given by the additive ")#link("http://en.wikipedia.org/wiki/Character_%28mathematics%29")[#text("characters")]

#align(center)[#tao-fit-display[#mitex("x\\mapsto \\exp(2i\\pi ax/{\\ell})")]]

#text("for all non-zero ")#mi("a\\in \\mathbf{Z}/{\\ell}\\mathbf{Z}")#text(". Extending to all $m$, by the Chinese Remainder Theorem, amounts to looking at characters")

#align(center)[#tao-fit-display[#mitex("x\\mapsto \\exp(2i\\pi ax/m)")]]

#text("of ")#mi("\\mathbf{Z}/m\\mathbf{Z}")#text(" with ")#mi("a")#text(" coprime with ")#mi("m")#text(". So the defining inequality for sieving ")#mi("\\{1,\\ldots, N\\}")#text(" using square-free numbers up to ")#mi("L")#text(" is")

#align(center)[#tao-fit-display[#tao-math("\\sum_{m\\leq M}{\\sum_{(a,m)=1}{\\left|\\sum_{1\\leq n\\leq N}{a_n \\exp(2i\\pi an/m)}\\right|^2}}\\leq \\Delta \\sum_n{\\left|a_n\\right|^2}.", block: true)]]

#text("It is classical, by now, that ")#mi("\\Delta\\leq N-1+L^2")#text(". The first bound of this strength being due ")#link("http://www.ams.org/mathscinet-getitem?mr=197425")[#text("to Bombieri")]#text(", though this particular value is due ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("to Montgomery-Vaughan")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=374060")[#text("Selberg")]#text(" independently. In fact, stronger analytic inequalities are known, there it is not necessary to restrict to ")#mi("m")#text(" square-free on the left-hand side, and in fact one can look at arbitrary sets of well-spaced points in ")#mi("\\mathbf{R}/\\mathbf{Z}")#text(". This classical theory is very-well described in ")#link("http://www.ams.org/bull/1978-84-04/S0002-9904-1978-14498-X/S0002-9904-1978-14498-X.pdf")[#text("Montgomery’s survey paper")]#text(". [Incidentally, reading this paper was the subject of my first-year project at E.N.S. Lyon under the direction of É. Fouvry and H. Daboussi, and it is quite remarkable how much of my mathematical work has involved the large-sieve in one way or another…]")

#heading(level: 1)[#text("— An approach to concrete sieve estimates —")]

#text("Here is the most standard way to estimate directly ")#mi("\\Delta")#text(". It relies on duality: the defining inequality is equivalent with")

#align(center)[#tao-fit-display[#tao-math("\\int_X{\\Big{\\left|\\sum_{m\\in M}{\\sum_{\\varphi\\in B_m}{\\beta(m,\\varphi)\\varphi(\\rho_{m}(F_x))}} \\right|}^2} \\leq \\Delta \\sum_{m,\\varphi}{\\left|\\beta(m,\\varphi)\\right|^2}", block: true)]]

#text("for arbitrary complex numbers ")#mi("\\beta(m,\\pi)")#text(". Expanding the left-hand side, we find a quadratic form with coefficients")

#align(center)[#tao-fit-display[#mitex("W(\\varphi,\\psi) := \\int_X{\\varphi(\\rho_{m}(F_x)) \\overline{\\psi(\\rho_{n}(F_x))}d\\mu(x)}")]]

#text("with ")#mi("\\varphi\\in B_m")#text(" and ")#mi("\\psi\\in B_n")#text(". Those correlation coefficients then must be estimated. One expects that")

#align(center)[#tao-fit-display[#mitex("W(\\varphi,\\psi)=\\delta(\\varphi,\\psi)\\mu(X)+R(\\varphi,\\psi)")]]

#text("where the remainder R is estimated uniformly and explicitly, and is small compared with ")#mi("\\mu(X)")#text(", at least if ")#mi("m")#text(" and ")#mi("n")#text(" are not “too big” (in the appropriate sense). Then we have")

#align(center)[#tao-fit-display[#tao-math("\\Delta\\leq \\max_{m,\\varphi}\\sum_{n,\\psi}{\\left|W(\\varphi,\\psi)\\right|} \\leq \\mu(X)+\\max_{m,\\varphi}\\sum_{n,\\psi}{\\left|R(\\varphi,\\psi)\\right|},", block: true)]]

#text("and this will have the desired feature of being close to ")#mi("\\mu(X)")#text(" if ")#mi("L")#text(" and ")#mi("M")#text(" are suitably chosen.")

#text("Here are the two most important new examples where this approach gives strong results, and leads to links with very deep principles of harmonic analysis and number theory.")

#text("In the setting of Example 6 (and its generalizations), i.e., sieve for discrete groups and random walks, a natural basis ")#mi("B_{\\ell}")#text(" is given by the matrix coefficients of irreducible unitary representations of the finite groups ")#mi("G_{\\ell}=SL(n,\\mathbf{Z}/{\\ell}\\mathbf{Z})")#text(". Then estimating ")#mi("W(\\varphi,\\psi)")#text(" turns out to be very cleanly linked with ")#link("http://www.ams.org/notices/200506/what-is.pdf")[#text("Property ")#mi("(\\tau)")]#text(" for the congruence quotients of ")#mi("SL(n,\\mathbf{Z})")#text(" (or ")#link("http://en.wikipedia.org/wiki/Property_T")[#text("Property (T)")]#text(", though that applies only for ")#mi("n")#text(" at least ")#mi("3")#text("). Recall that this property states that there is a positive ")#mi("\\delta>0")#text(" such that, for any ")#mi("m\\geq 1")#text(", any map")

#align(center)[#tao-fit-display[#mitex("\\pi : SL(n,\\mathbf{Z})\\rightarrow SL(n,\\mathbf{Z}/m\\mathbf{Z}) \\rightarrow U(r)")]]

#text("where ")#mi("U(r)")#text(" is the unitary group of a finite-dimensional Hilbert space of dimension ")#mi("r")#text(", either there is a vector ")#mi("v\\in \\mathbf{C}^r")#text(" invariant under all ")#mi("\\pi(g)")#text(", ")#mi("g\\in SL(n,\\mathbf{Z})")#text(", or for any unit vector ")#mi("v\\in\\mathbf{C}^r")#text(", there exists ")#mi("s\\in S")#text(" (recall ")#mi("S")#text(" is a generating set of ")#mi("SL(n,\\mathbf{Z})")#text(") such that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\pi(s)v-v\\right\\|\\geq \\delta.", block: true)]]

#text("In other words, if a vector is not invariant under all ")#mi("s\\in S")#text(", it is uniformly non-invariant. This property is also equivalent with the fact that the ")#link("http://en.wikipedia.org/wiki/Cayley_graph")[#text("Cayley graphs")]#text(" of the congruence quotients form a family of ")#link("http://en.wikipedia.org/wiki/Expander_graph")[#text("expanders")]#text(".")

#text("(Note: we do not currently necessarily need fine knowledge of the ")#link("http://en.wikipedia.org/wiki/Character_theory#Character_tables")[#text("character table")]#text(" of ")#mi("G_{\\ell}")#text(", as described at least partly through ")#link("http://en.wikipedia.org/wiki/Deligne%E2%80%93Lusztig_theory")[#text("Deligne-Lusztig characters")]#text(", though, when ")#mi("n")#text(" is large, this can lead to small improvements in estimates, and interesting problems).")

#text("In Example 7, since we work with conjugacy classes, the natural basis ")#mi("B_{\\ell}")#text(" is the set of characters of irreducible unitary representations of ")#mi("G_{\\ell}")#text(". Estimating ")#mi("W(\\varphi,\\psi)")#text(" is then a problem of analytic number theory, amounting to uniform quantitative estimates for partial sums of coefficients (at primes) of ")#link("http://en.wikipedia.org/wiki/Artin_L-function")[#text("Artin")#linebreak()#text(" ")#mi("L")#text("-functions")]#text(". As such, there exist unconditional, but fairly weak, results, and much stronger ones when assuming the ")#link("http://en.wikipedia.org/wiki/Generalized_Riemann_hypothesis")[#text("Generalized Riemann Hypothesis")]#text(".")

#text("When dealing with the function field analogue, the Riemann Hypothesis is known, due to the amazing ")#link("http://www.ams.org/mathscinet-getitem?mr=340258")[#text("work of Deligne")]#text(" [in my mind, the most important number-theory result of the 20th century], building on the foundations of Grothendieck. However, this only gives a (very strong) result for fixed ")#mi("\\varphi")#text(", ")#mi("\\psi")#text(", a priori; getting uniform bounds is not trivial, and because the remainder terms after applying the Grothendieck-Lefschetz trace formula and the Riemann Hypothesis involve the dimension of some ")#link("http://en.wikipedia.org/wiki/Etale_cohomology")[#text("étale cohomology")]#text(" groups depending on ")#mi("\\varphi")#text(" and ")#mi("\\psi")#text(", some uniform estimates for those so-called ")#link("http://en.wikipedia.org/wiki/Betti_numbers")[#text("Betti numbers")]#text(" are required. They are proved either by analyzing the ramification behavior of the analogues of the Artin representations, or (for higher-dimensional parameter spaces) by adapting ")#link("http://www.ams.org/mathscinet-getitem?mr=1803934")[#text("an induction method o")]#link("http://www.ams.org/mathscinet-getitem?mr=1803934")[#text("f Katz")]#text(".")

#text("In applying concretely the sieve for Frobenius, it should be mentioned")#linebreak()#text(" that one of the main issues is in fact to compute ")#mi("Y_{\\ell}")#text(" precisely! This is a completely new phenomenon compared with the classical sieves, where ")#mi("Y_{\\ell}")#text(" is perfectly known and understood. Here, this amounts to computing certain Galois groups, such as those of torsion points on elliptic curves, or their analogues for function fields (which are often called monodromy groups because of their geometric origin). Serre’s theorem quoted above for non CM elliptic curves is one of the most famous examples, but the “baby” example of this is the fact that ")#link("http://en.wikipedia.org/wiki/Cyclotomic_polynomials")[#text("cyclotomic polynomials")]#text(" are irreducible over $\\mathbf{Q}$ (since this means that the Galois groups of cyclotomic extensions, generated by roots of unity, are “as big as possible”, which is usually the desired outcome). In the first application of the sieve for Frobenius, which concerned a conjecture of Katz already considered ")#link("http://www.ams.org/mathscinet-getitem?mr=1440067")[#text("by N. Chavdarov")]#text(", I used an unpublished result of J-K. Yu which has recently been given a ")#link("http://www.arxiv.org/abs/math.NT/0608718")[#text("new proof by C. Hall")]#text(".")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1c4ce8a41499c900b1c6ad09e186eff6e006bd898c0f04bcb46d7f2804f46f6b-b7760848356bd450835894190781cb4f300f6057ee7b69506c0c91caf17d0aca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jordan Ellenberg")]], [#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/#comment-6189")[#strong[#text("Jordan Ellenberg")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2007")])]

#text("Emmanuel,")

#text("I’ve only just started reading this enjoyable post! But let me make a couple of comments off the bat.")

#text("1. In Poonen’s theorem (your example 4), the “sieve-style” method really only works for the points of small degree — there is a very clever trick involving Frobenius to deal with the points of large degree (section 2.3 of Poonen’s paper.) But maybe this is what you meant by “more or less” — or maybe to you this material in section 2.3 can be thought of as “sieve-style” as well, in which case I’d like to hear more about it!")

#text("2. Yu’s unpublished theorem was also reproved by ")#link("http://www.math.colostate.edu/~achter/math/trigonal.pdf")[#text("Jeff Achter and Rachel Pries")]#text(", independently of Hall.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/#comment-6200")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2007")])]

#text("Hello Jordan !")

#text("(1) This is absolutely correct; what I wanted to say was simply that")#linebreak()#text(" the framework of Poonen’s work, which is quite unusual by the usual")#linebreak()#text(" standards of classical analytic number theory, does fall within the")#linebreak()#text(" general framework I described (a good test that it is at least close to the")#linebreak()#text(" “right” one, although whether one can expect a perfect abstract theory for")#linebreak()#text(" something like this is not clear at all). In fact, in sieve-theoretic terms,")#linebreak()#text(" Poonen’s application is something like a “zero-dimensional sieve”, which")#linebreak()#text(" is quite far from the standard “large-sieve” (very few residue classes are excluded, instead of a positive proportion). This means in particular that")#linebreak()#text(" it is possible to expect an asymptotic formula with a positive density, though proving such a formula is of course quite difficult usually (see for instance the remarkable recent work of Helfgott proving that values of")#linebreak()#text(" a cubic polynomial evaluated at primes represent the right number of squarefree values, when there is no trivial obstruction). For a zero")#linebreak()#text(" dimensional sieve, the large sieve useless results in general.")

#text("(2) I know of this work of Achter and Pries, but actually I was thinking of")#linebreak()#text(" the stronger version of Yu’s theorem for one-parameter families")#linebreak()#text(" y^2=f(x)(x-t)")#linebreak()#text(" and as far as I understood their paper, this does not follow from their")#linebreak()#text(" approach (but I may be mistaken…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesse Kass")]], [#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/#comment-6859")[#strong[#text("Jesse Kass")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2007")])]

#text("A) It should be noted that (as I understand it) Yu’s proof of this monodromy result uses a technique that is entirely different from the technique used both in Hall’s paper and Achter-Pries’ paper. For the families considered by Achter and Pries, his proof is fundamentally topological and uses the description of the fundamental group of the parameter space as a briad group. He handles the case of an arbitrary base field by proving a comparison result.")

#text("B) Kowalski is correct that the Achter and Pries do not compute the monodromy for the family ")#mi("y^2 = f(x)(x-t)")#text(" (considered as a family in the variable t). Furthermore, their technique can not be extended to handle this")#linebreak()#text(" family without some additional work.")

#text("Achter and Pries study the family")

#mi("U_d: y^2 = (x-r_1) \\ldots (x-r_{d})")

#text("given by allowing ")#mi("(r_1,\\ldots, r_d)")#text(" to be any d-tuple of distint points. Their technique is to partially compactify the family by adding in curves of compact type (curves with compact Jacobian). The boundary looks like a product of spaces of the same type but of smaller dimension, so the monodromy group can be computed inductively. Achter and Pries then use a result about semi-continuity of mondromy under degeneration to compare the monodromy group of the boundary to the monodromy group of ")#mi("U_d")#text(".")

#text("One way of extending this technique would be to put the ")#mi("y^2=f(x)(x-t)")#text(" into a larger family of smooth curves by allowing the coefficients of f(x) to vary in some continuous manner. One could try to do this in such a way so that the monodromy group of ")#mi("y^2=f(x)(x-t)")#text(" is the same as the monodromy group of the larger family. This larger family would then be a family for which it is natural to try to apply the technique from the Achter-Pries paper to.")

#text("The difficulty is that it is not immediately clear to me how to do this in such a manner that the larger family admits a partial compactification by curves of compact type. The wandering point (t,0) on the curve is the main source of difficulties.")

#text("For a partial compactification by curves that are not of compact type, it may still be possible to extend the method, but the difficulty lies proving an appropriate semi-continuity result. When all the curves in the family are of compact type, the monodromy group is the group associated to a sheaf (the sheaf ")#mi("R^1f_{*} Z/\\ell")#text(") that is locally constant on the entire partial compactification. This fact is used in a fundamental way by Achter and Pries and is no longer true when the family includes curves that are not of compact type.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/#comment-6997")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2007")])]

#text("Hello,")

#text("Thanks for the information on the methods of Achter and Pries, which are a bit far away from my current knowledge of algebraic geometry.")

#text("Incidentally there’s another question I’ve been wondering about concerning the families ")#mi("y^2=f(x)(x-t)")#text(", which is whether the curves in the family are generically ordinary. (This is partly motivated by applications where both big monodromy and ordinarity are useful, e.g. ")#link("http://www.math.u-bordeaux1.fr/~kowalski/weil-numbers.pdf")[#text("this paper")]#text("). I used to think this would probably be the case, but it’s not so clear since Achter and Pries have extended their results to get big monodromy results for the moduli spaces of curves with given ")#mi("p")#text("-rank (")#link("http://arxiv.org/abs/0707.2110")[#text("arXiv:0707.2110")]#text("), which implies in particular the existence of one-parameter families of curves with big monodromy, but not ordinary. (Though, of course, not necessarily of the form above.) (Katz had mentioned having found such families, but without details.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jesse Kass")]], [#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/#comment-7017")[#strong[#text("Jesse Kass")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2007")])]

#text("Hello,")#linebreak()#text(" I think that the curves in the family y^2 = f(x) (x-t) are generically ordinary, at least for f(x) a general polynomial. I know that the generic hyperelliptic curve of genus g is ordinary and I think that the same kind of technique can be applied to your question.")

#text("Here is a sketch of the argument: Fix an integer d and consider the family")

#text("V_d:")

#text("y^2 = f(x)(x-t)")

#text("considered as a family over an open subset of A^{d-1} \\times A^1 by varying both t and the coefficients of f(x) in a continuous manner. If this family is generically ordinary, then it follows that the family y^2 = g(x) (x-t) is generically ordinary for g(x) a general polynomial.")

#text("Now to prove that the larger family is generically ordinary, we induct on d. For d small (d <= 6), the family V_d contains every smooth curve of appropriate genus so we are ok.")

#text("For the inductive step, first compactify V_d by adding in nodal hyperelliptic curves. Now one can construct lots of ordinary curves that lie on the boundary of V_d by taking two curves in V_d’with d’ <d and gluing them together at a point. A deformation theory argument shows that these nodal, ordinary curves can be deformed into smooth, ordinary curves that lie in the interior of V_d. This proves that the generic element of V_d is ordinary.")

#text("Technical Note: For the inductive step, it is probably better to work with a finite quotient of V_d that has a nice moduli theoretic interpretation and then use a standard compactification of that space rather than to work with V_d directly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lecture IV: sieving for almost primes and expanders « What’s new")]], [#link("https://terrytao.wordpress.com/2007/08/08/emmanuel-kowalski-the-large-sieve-inequalities/#comment-33584")[#strong[#text("Marker lecture IV: sieving for almost primes and expanders « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2008")])]

#text("[…] The selection of the sieve weights is now a well-developed science (see also my earlier post, and Kowalski’s guest post, on this topic), and Bourgain, Gamburd and Sarnak basically use off-the-shelf sieves (in […]")
]
