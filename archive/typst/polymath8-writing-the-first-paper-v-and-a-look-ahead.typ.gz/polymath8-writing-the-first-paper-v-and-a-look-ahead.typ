// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/
// Converted to Typst by tao2typ: "2026-10-14T15:18:50.801475+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Polymath8: Writing the first paper, V, and a look ahead", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Polymath8: Writing the first paper, V, and a look ahead")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 November 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/")[#text("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#text("It’s time to (somewhat belatedly) roll over the ")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/")[#text("previous thread")]#text(" on writing ")#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("the first paper")]#text(" from the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("Polymath8 project")]#text(", as this thread is overflowing with comments. We are getting near the end of writing this large (173 pages!) paper, establishing a bound of 4,680 on the gap between primes, with only a few sections left to thoroughly proofread (and the last section should probably be removed, with appropriate changes elsewhere, in view of the more recent progress by Maynard). As before, one can access ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/wjFF8XoZVG/ek/newgap.pdf")[#text("the working copy")]#text(" of the paper at ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/8OKNGAmv5n/ek")[#text("this subdirectory")]#text(", as well as the ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/_5Sn7mNN3T")[#text("rest of the directory")]#text(", and the plan is to submit the paper to ")#link("http://msp.org/ant/about/cover/cover.html")[#text("Algebra and Number theory")]#text(" (and the arXiv) once there is consensus to do so. Even before this paper was submitted, it already has had some impact; Andrew Granville’s ")#link("http://www.dms.umontreal.ca/~andrew/CurrentEventsArticle.pdf")[#text("exposition of the bounded gaps between primes story")]#text(" for the Bulletin of the AMS follows several of the Polymath8 arguments in deriving the result.")

#text("After this paper is done, there is interest in continuing onwards with other Polymath8 – related topics, and perhaps it is time to start planning for them. First of all, we have an invitation from the ")#link("http://www.ems-ph.org/journals/journal.php?jrn=news")[#text("Newsletter of the European Mathematical Society")]#text(" to discuss our experiences and impressions with the project. I think it would be interesting to collect some impressions or thoughts (both positive and negative) from people who were highly active in the research and/or writing aspects of the project, as well as from more casual participants who were following the progress more quietly. This project seemed to attract a bit more attention than most other polymath projects (with the possible exception of the very first project, ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath1")[#text("Polymath1")]#text("). I think there are several reasons for this; the project builds upon a recent breakthrough (Zhang’s paper) that attracted an impressive amount of attention and publicity; the objective is quite easy to describe, when compared against other mathematical research objectives; and one could summarise the current state of progress by a single natural number H, which implied by ")#link("http://en.wikipedia.org/wiki/Proof_by_infinite_descent")[#text("infinite descent")]#text(" that the project was guaranteed to terminate at some point, but also made it possible to set up a “")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("scoreboard")]#text("” that could be quickly and easily updated. From the research side, another appealing feature of the project was that – in the early stages of the project, at least – it was quite easy to grab a new world record by means of making a small observation, which made it fit very well with the polymath spirit (in which the emphasis is on lots of small contributions by many people, rather than a few big contributions by a small number of people). Indeed, when the project first arose spontaneously as a ")#link("http://sbseminar.wordpress.com/2013/05/30/i-just-cant-resist-there-are-infinitely-many-pairs-of-primes-at-most-59470640-apart")[#text("blog post of Scott Morrrison")]#text(" over at the ")#link("http://sbseminar.wordpress.com")[#text("Secret Blogging Seminar")]#text(", I was initially hesitant to get involved, but soon found the “game” of shaving a few thousands or so off of ")#mi("H")#text(" to be rather fun and addictive, and with a much greater sense of instant gratification than traditional research projects, which often take months before a satisfactory conclusion is reached. Anyway, I would welcome other thoughts or impressions on the projects in the comments below (I think that the pace of comments regarding proofreading of the paper has slowed down enough that this post can accommodate both types of comments comfortably.)")

#text("Then of course there is the “Polymath 8b” project in which we build upon the recent breakthroughs of James Maynard, which have simplified the route to bounded gaps between primes considerably, bypassing the need for any Elliott-Halberstam type distribution results beyond the Bombieri-Vinogradov theorem. James has kindly shown me an advance copy of the preprint, which should be available on the arXiv in a matter of days; it looks like he has made a modest improvement to the previously announced results, improving ")#mi("k_0")#text(" a bit to 105 (which then improves H to the nice round number of 600). He also has a companion result on bounding gaps ")#mi("p_{n+m}-p_n")#text(" between non-consecutive primes for any ")#mi("m")#text(" (not just ")#mi("m=1")#text("), with a bound of the shape ")#mi("H_m := \\lim \\inf_{n \\to \\infty} p_{n+m}-p_n \\ll m^3 e^{4m}")#text(", which is in fact the first time that the finiteness of this limit inferior has been demonstrated. I plan to discuss these results (from a slightly different perspective than Maynard) in a subsequent blog post kicking off the Polymath8b project, once Maynard’s paper has been uploaded. It should be possible to shave the value of ")#mi("H = H_1")#text(" down further (or to get better bounds for ")#mi("H_m")#text(" for larger ")#mi("m")#text("), both unconditionally and under assumptions such as the Elliott-Halberstam conjecture, either by performing more numerical or theoretical optimisation on the variational problem Maynard is faced with, and also by using the improved distributional estimates provided by our existing paper; again, I plan to discuss these issues in a subsequent post. ( James, by the way, has expressed interest in participating in this project, which should be very helpful.)")

#heading(level: 1)[#text("Comments (93)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-264970")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2014")])]

#text("In the last line of the abstract, “which” already appears also before the parentheses (two lines above).")

#emph[#text("[Fixed, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-269628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("I’ve just heard from Emmanuel Kowalski, who has signed off on the latest version of the manuscript. As far as I know, everyone who was proofreading the paper is now happy with it, so if I don’t hear anything in the next day or so, I am going to put the Polymath8a paper on the arXiv and submit to Algebra & Number theory as previously planned.")

#text("Given this, and also given that Polymath8b has also achieved most of the goals it wanted, I think it may be time to start working on the retrospective article for the EMS newsletter, while memories of the Polymath8 collaboration are still fairly fresh. I’ll start a thread to discuss that when the Polymath8a paper is up on the arXiv.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-269808")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("I’ve concatenated all the LaTeX files into one enormous LaTeX file (newgap.tex) and submitted to the arXiv and to Algebra & Number theory. When the paper appears on the arXiv, I’ll start a new blog post to announce it, and also to begin work on the retrospective article.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-269970")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("Paper is now on arXiv: ")#link("http://arxiv.org/abs/1402.0811")[#text("http://arxiv.org/abs/1402.0811")]#text(" . I’m traveling today, but hope to put up a blog post on the paper and on kicking off the retrospective shortly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-270015")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2014")])]

#text("Thanks for posting the article, and thanks for putting so much work (so many ideas etc.) into it!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-269714")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2014")])]

#text("I’ve just received a request from Yoichi Motohashi to use one of the figures in our Polymath8a paper (more precisely, logic.png, appearing on page 11) in an expository talk he is giving on bounded gaps between primes for the annual meeting of the Japanese Mathematical Society in March. Of course he’ll cite the paper as the original source. I don’t see any problem with this, so if I don’t hear any objections in the next day or so, I’ll tell Yoichi that it is fine to use the figure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-269747")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2014")])]

#text("That’s certainly OK!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of “New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective | What's new")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-270282")[#strong[#text("“New equidistribution estimates of Zhang type, and bounded gaps between primes” – and a retrospective | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 February 2014")])]

#text("[…] second purpose is to roll over the previous thread on all remaining Polymath8a-related matters (e.g. updates on the submission status of the paper) to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9fafe9e439599de1e74e935585e36bbb1e5a44aa5e7d3da1fc564d69b77e2b1a-cbc0021b5ce784803ce72205d0bbb099c0ef4f6c0f89aa905abe26fcdfc6ce94.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-2/#comment-410872")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2014")])]

#text("P.1 in the document at ")#link("http://arxiv.org/pdf/1402.0811v2.pdf")[#text("http://arxiv.org/pdf/1402.0811v2.pdf")]#text(": Something is missing just before the ToC; “")#mi("H =")#text("”.")

#emph[#text("[The paper has been substantially revised from this arXiv version; see ")#link("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AAAumDozECHOx65jJSka0zk_a/newgap.pdf")[#text("https://www.dropbox.com/sh/0xb4xrsx4qmua7u/AAAumDozECHOx65jJSka0zk_a/newgap.pdf")]#text(" , which no longer has this portion of text. The next revision will be placed on the arXiv once it is complete. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251465")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("As soon as Polymath8B takes off, I’ll be happy to be part of (along with FKN I guess). That is a great playground for testing and developing ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d9de13c3c77059e2381357dce91d8408811e186d9d73d672aa8a814d24502a97-6908235e9bb52c626e6c19f1d38e16ef432f563317e7085fab69ed891489f3c0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sniffnoy")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251472")[#strong[#text("Sniffnoy")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("And the improved distributional estimates that didn’t quite make it into the existing paper. :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251581")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("Would this (once confirmed) best be termed “Type I Level 5a” on the wiki? I see that at present it has been referred to there just within the “Level 5” entry, but maybe it merits separating out?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/932d5849c64443a57be4bfeb5700701765eb15dac99496960d83ed27859dea26-66bac538cfa48dcada100f804266ac188691957460ac27653fe2779bb0ef5ffe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of musicsoundscapes2")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251475")[#strong[#text("musicsoundscapes2")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("Dear Dr. Tao,What about an algorithm for extracting primes?Robert Kimera")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251485")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("For what it’s worth, I’ve been following the progress since Peter Woit mentioned that Zhang was giving a talk on his (then unreleased) paper, and posting on Google+ about it. If people want an outsider’s perspective (I’m not a number theorist nor an analyst), then I’d like to contribute something to the EMS newsletter article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251498")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2013")])]

#text("I am close to finishing Section 9 and hope to upload the updated version later today. Then hopefully by the end of the week, I will be done reading through.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251543")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("Professionals in other disciplines are noticing problems in the traditional workflow. After much planning, the result is a product which is still defective and fails to achieve its intended purpose. It is as if we had done no work at all.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251546")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("A few corrections to chapter 2:")

#text("1. Just after the statement of Claim 2.4")#linebreak()#text(" unconditionnally -> unconditionally")

#text("2. Shortly after Theorem 2.6")#linebreak()#text(" need only by controlled -> need only be controlled")

#text("3. Just before Definition 2.7")#linebreak()#text(" $\\varpi\\geq 1/2$ -> $\\varpi>0$")

#text("4. Remark 2.9")#linebreak()#text(" less that -> less than")

#emph[#text("[Corrected in the main version, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fd4ee11e9561e0992302bd40eebde537c101ae33a0d92d3b7989b023a3a577d3-e0c8a4a37da773f1e33327b33382bbc603cf1f00fe1c2f1d21297f602e424cd3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alastair Irving")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251551")[#strong[#text("Alastair Irving")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("5. Shortly after Theorem 2.13")#linebreak()#text(" significanty -> significantly")

#emph[#text("[Corrected in the main version, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251561")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("Some typos in the proof of lemma 4.10:")

#text("1. In the proof of claim (i), the upper limit of the integral should be ")#mi("t")#text(" (instead of ")#mi("x")#text("), and the integration variable ")#mi("t")#text(" should be changed (e.g. to ")#mi("\\tau")#text(").")

#text("2. In the proof of claim (ii), it should be ")#mi("t+t^{\\prime} \\geq 1")#text(" (instead of ")#mi("t+t^{\\prime} > 1")#text(") – since ")#mi("f(1)=0")#text(" (note also that ")#mi("\\log f(t)")#text(" is undefined for ")#mi("t=1")#text(").")

#text("3. In the proof of claim (iii), “from from” should be “from”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39d042cd343763a0074f825ecdf61ade3a1f833c09d7322d7ed33b69d91748e0-004ee65ff1042e640b0bfa8bf9563704de056663a81b46994f471f2da9bfde76.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bogdan")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251567")[#strong[#text("Bogdan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("Probably, the world record (with question mark) should now be 600?")

#emph[#text("[I’ll update this when Maynard’s arXiv article comes out; thanks for the reminder. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00dce96a8f133030373101ce8143adc9771130191b44a90f4457703ef494751d-ad277ba9ac147bdceaa84f8d05974e6eec7da7a298f19da34081120bc5a5308b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Gibson")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251577")[#strong[#text("Andrew Gibson")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("As an undergrad mathematics student who has been following from the start, I don’t know if I qualify as one of those casual, quiet participants you’re interested in hearing from or not, but here’s my experience, for whatever it’s worth:")

#text("Shortly after Zhang announced his result and you proposed the project, my classmates and I began a small weekly seminar with a professor devoted to studying some of the theory involved (analytic number theory, sieve methods, etc.), albeit on a much more elementary level that was within our reach. Of course, the majority of the actual proof is still mostly over our heads, but at least I feel as if I’ve gained a birds’-eye-view of the strategy and, probably more importantly, how it fits into the larger field. (For instance, before any of this, I could never have explained the Bombieri-Vinogradov theorem or the Hardy-Littlewood prime tuple conjecture.) So for us the project was a great excuse to enter a new subject, and has been immensely educational.")

#text("More than that, though, reading the posts and following the ‘leader-board’ felt a lot like an academic spectator sport. It was surreal, a bit like watching a piece of history as it occurred. It made the mathematics feel much more alive and social, rather than just coming from a textbook. I don’t think us undergrads often get the chance to peak behind closed doors and watch professional mathematicians “in the wild” like this, so from a career standpoint, it was illuminating. I get the sense that this is the sort of activity I can look forward to in grad school and as a post-doc doing research (…hopefully.)")

#text("I also suspect that many other students from many other schools have had similar experiences but, like me, chose to stay quiet, as we had nothing to contribute. So, thank you all for organizing this project and for making it publicly available online.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251583")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("I was very busy with another project in the past 10 weeks, but I can now return to PolyMath8. I will try to read the whole paper in about 10 days, so that I can finish at about the same time as Emmanuel. I will only look for errors and typos, and I will report here in the traditional way for simplicity.")

#text("Of course I also look forward to PolyMath8b, it has been a fun experience so far!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251594")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("Previous thread rescue:")#linebreak()#text(" Quite a lot of typos and corrections are now buried in the previous thread, most were not fixed when there were 2 versions worked on:")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248417")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248417")]#text("): on 1. still missing an e in the middle of equalities, and 2. is not fixed.")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248519")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248519")]#text(")")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248801")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248801")]#text(") Although some points (3&6) have been discussed, most have not been fixed.")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248969")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248969")]#text(")")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-249311")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-249311")]#text(")")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-249812")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-249812")]#text(")")#linebreak()#text(" (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-249843")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-249843")]#text(")")#linebreak()#text(" The list is probably incomplete.")

#emph[#text("[Thanks for this! I went back and implemented these corrections. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251596")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("Dear Prof. Tao")#linebreak()#text(" I’m not sure what you mean by this sentence")#linebreak()#text(" “…and the last section should probably be removed, with appropriate changes elsewhere, in view of the more recent progress by Maynard”")#linebreak()#text(" Are all the prospective improvements in the last section superseded by Maynard?")

#text("To Gibson:")#linebreak()#text(" I’m also trying to organize an undergraduate reading group on this topic (possibly several weeks later). I’m curious what is the background and the goal you set for your seminar, and how long it runs. I want some frame of reference. Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251599")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")])]

#text("Regarding Section 11, these possible improvements are not directly superseded by Maynard’s work (with the exception of suggestion (iii)), but now that we have a Polymath8b project to be launched which will pursue many of the directions indicated there, there doesn’t seem to be much point to attaching Section 11 to the current paper. (But perhaps once Polymath8b concludes, we could have an analogous section at the end of that paper, assuming that there isn’t a Polymath8c of course…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00dce96a8f133030373101ce8143adc9771130191b44a90f4457703ef494751d-ad277ba9ac147bdceaa84f8d05974e6eec7da7a298f19da34081120bc5a5308b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Gibson")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251626")[#strong[#text("Andrew Gibson")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("It was very informal: we would meet and try to work through the posts. Soon a more structured plan emerged, but this unfortunately only lasted a few months and ended halfway through, as people simply gave up and stopped coming. But I’m sure this could be avoided with more thought and planning before-hand.")

#text("Most of us had taken standard courses in analysis, number theory, and so-on. But we had not really used sieves to much effect before and so began at the very start with Eratosthenes, then Brun’s sieve, Selberg, and so-on. Rademacher and another book I forget was used as a reference for Brun. There were some nice beginning sieve exercises from the Lovasz’ problem book. Dirichlet’s theorem was used as a segue into arithmetic progressions and as an intro to analytic number theory; we also talked about the prime number theorem for quite a while and went through much of its proof and related estimates. Halbertstam and Richert’s Sieve Methods was useful for the more advanced sieves. And there were the project’s posts themselves.")

#text("The original (too ambitious) goal was to reach the large sieve and prove Bombieri-Vinogradov, and to see Linnik’s dispersion method and some exponential sums, since we learned from the posts that so much of Zhang’s approach was based on modifying this existing machinery. (We didn’t dare unpack the Weil conjectures and took any reference to them as a black box.) I had hoped to do this and then dig into Zhang’s theorem and Polymath8 proper. However, as you can guess, this was still a bit out of our reach, probably more appropriate for graduate students with more background. Our meetings became instead an introduction to basic sieve methods and analytic number theory, with Zhang’s theorem lurking far away on the horizon. So we had the loose goal of understanding an outline of the proof, the improvements being made by the project, and as many of the ideas involved as possible.")

#text("We didn’t get as far as I would have hoped, but I believe the approach was sound and continued on my own for a ways. It was all very exciting. No doubt a formal class could be set up to much better effect.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251654")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("This thread should be added to the list of Polymath8 threads.")

#emph[#text("[Done, thanks for the reminder – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251681")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("A bunch of relevant links:")

#text("Maynard’s article is up on the arXiv! ")#link("http://arxiv.org/abs/1311.4600")[#text("http://arxiv.org/abs/1311.4600")]

#text("A new media article about bounded gaps between primes (covering Zhang’s work, our Polymath work, and Maynard’s new work): ")#link("https://www.simonsfoundation.org/quanta/20131119-together-and-alone-closing-the-prime-gap/")[#text("https://www.simonsfoundation.org/quanta/20131119-together-and-alone-closing-the-prime-gap/")]

#text("Also, Andrew Granville has a print version of the talk he’ll give at the joint AMS meeting covering the same material (but in less detail) than his longer Bulletin article: ")#link("http://www.dms.umontreal.ca/~andrew/CEBBrochureFinal.pdf")[#text("http://www.dms.umontreal.ca/~andrew/CEBBrochureFinal.pdf")]

#text("I am starting an expository post on Maynard’s arguments to kick off the Polymath8b project, and hope to have it ready in a day or so.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251682")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("Since any symmetric ")#mi("F(t_1, ..., t_k)")#text(" is a function of the symmetric polynomials ")#mi("P_1, ..., P_k")#text(" (appearing in Maynard’s article), it is possible to reduce the value $k = 105$ by adding more symmetric polynomials to ")#mi("P_1, P_2")#text(" (used in Maynard’s article.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251695")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2013")])]

#text("I’ve opened up a research thread for Polymath8b at ")#link("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")[#text("https://terrytao.wordpress.com/2013/11/19/polymath8b-bounded-intervals-with-many-primes-after-maynard/")]#text(" . This current thread can remain active for finishing the writing up of Polymath8a , and for all other Polymath8-related topics, such as collecting feedback on the project for a retrospective article.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251718")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("I’m done with typeiii.tex and I have merged also the last corrections in the main folders with those of the ek subfolder. I will copy the ek-files to the main folder.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251752")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("“(??)” appears in the line below (10.13) (and also in the fifth line above (10.14))")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251760")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("That’s just because I changed some references to equations in Chapter 7, but these will be corrected as I go through Section 10.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251719")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("I forgot to mention that there wasn’t much to report in typeiii.tex; I just gave a few more details for some steps (the separation of variable using Taylor expansion and the Euler product estimate at the end, in particular).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-251747")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2013")])]

#text("I made a few minor edits to Sections 1 and 2 and to the references.")

#text("Two things that I didn’t dare to change but that confused me:")#linebreak()#text(" * What is ")#mi("\\varepsilon")#text(" in the statement of Lemma 1.6?")#linebreak()#text(" * In the discussion below Theorem 2.6, we write that Motohashi and Pintz noticed that […] the residue classes a may be assumed to be essentially fixed, […]. What does ‘essentially fixed’ mean here?")

#emph[#text("[I reworded these two points to clarify – ")#mi("\\varepsilon>0")#text(" is any fixed quantity, and what Motohashi and Pintz essentially observed was that one only needed to work with a single residue class ")#mi("a\\ (q)")#text(" for each ")#mi("q")#text(" in which ")#mi("a")#text(" was independent of ")#mi("q")#text(" (but potentially very large). -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2934cb562ae458983e671622732f3b850ca0605d450dae97afc307d6a237f08-98f7afe2168c061903bf4deef1c906f4fc4afafbf4e1ee5065e8652fbbf3871a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marshall Flax")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-252192")[#strong[#text("Marshall Flax")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2013")])]

#text("Two notes about the polymath8 process:")

#text("1. Most of the active Polymath8 participants were clearly identifiable (either by human-sounding names, or actual links to their webpages). But I am curious as to who “v08ltu” is: a well-known mathematician, or a self-taught savant, or a precocious undergrand, or Dr. Zhang himself? He contributed as an equal in the early days of Polymath8, and his only apparent bona-fides were his contributions. This true egalitarianism might be unique to mathematics.")

#text("2. We all have seen how quickly Dr. Tao can work and write. Had he chosen to, he could have easily “scooped” Dr. Maynard once he learned they had both found finite limits to the M>1 case — especially since someone established like Dr. Tao can publish unfinished work and still record priority, whereas a relative unknown like Dr. Zhang or Dr. Maynard has to “dot all I’s and cross all T’s” before they can publish. Yet Dr. Tao was more-than-scrupulous in naming the theorem exclusively after Maynard. Again, I think mathematics is probably almost-unique in the consideration presigious full professors show to young postdocs.")

#text("p.s. Dr. Tao will probably claim that he didn’t even think of priority (even for as important a theorem as Polymath8b), but that just proves my point :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf6302e0d67b9deb354cb529edbd8f475a6fb55a5003b472f23df7b4d2366db-94f09221f7fbaf3b999af5ef8cfb6585fd6f92f359eb736cee14b6634d7d2e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-252586")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("I have now read through Section 8 (without being confident about the details, I must admit). There are a number of typos that I can fix myself (Emmanuel, is it safe to do so?). The following things I didn’t dare to change:")

#text("* (in the introduction) […] it is possible to all references to sheaves […]: something’s wrong with this phrase")

#text("* (section 8.1) […] in the case ")#mi("X = Y = \\mathbb{P}^1_k")#text(": what is ")#mi("Y")#text("?")

#text("* (definition 8.1) […] the eigenvalues of ")#mi("\\text{Fr}_x")#text(": should this be ")#mi("\\text{Fr}_{x,k}")#text("?")

#text("* (section 8.2.3) In particular, the product of two admissible trace functions ")#mi("t_\\mathcal{F}")#text(" and ")#mi("t_\\mathcal{G}")#text(" coincides with an admissible trace function except for at most ")#mi("\\text{cond}(\\mathcal{F}) + \\text{cond}(\\mathcal{G})")#text(", […]: at most that many points?")

#text("* (same sentence) […] and the complex conjugate of an admissible trace function is one.: is also an admissible trace function?")

#text("* (section 8.3) […] and denote with ")#mi("U = U_\\mathcal{F}")#text(" with open immersion ")#mi("j : U \\hookrightarrow \\mathbb{P}^1_k")#text(": something seems wrong with this phrase")

#text("* (below formula (8.18)) […] for each prime ")#mi("p \\mid")#text(": ")#mi("p \\mid q")#text("?")

#text("* (remark 8.22, the big formula): I guess the last term is not part of the summand? Maybe it’s better to write ")#mi("\\displaystyle N^{1-1/2^{l-1}}q_l^{1/2^l} + \\sum_{i=1}^{l-1} N^{1 - 1/2^i} q_i^{1/2^i}")

#text("One overall question: I didn’t get the point of excluding the asymptotic notation from Definition 1.4. ")#mi("O")#text(" and ")#mi("\\ll")#text(" seem to have the same meaning in Section 8 as in Definition 1.4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-252923")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Thanks, I will put in the corrections.")

#text("For the asymptotic notation, what is meant is that “x” is free from being the main asymptotic variable (which it is reserved for in the beginning of Def. 1.4) and that <<, O(…) do not implicitly refer to functions of x.")

#text("(In particular, \\lessapprox is not used in Sections 6 and 8 where the asymptotic convention is related, since it incorporates a factor x^o(1) that does not make sense then.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-252924")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("P.S. It is safe to make changes in the main folder, since I always use diff to check the files before copying from ek to main folder; it’s more dangerous to touch the ek subfolder, because I copy more often from my computer to this subfolder, and usually do not check whether the ek copy has changed or not.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-252958")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("Ok, thanks for the clarification! I have added half a line on this at the beginning of Section 8. I’ve now also fixed the typos that I mentioned, leaving the above remarks unaddressed. One additional question/remark about the new section on Sato-Tate distributions: in the formula ")#mi("2^{\\omega(q)}\\cos(\\theta(n;q))=\\mathcal{K}\\ell_2(n;q)")#text(", I guess the sheaf ")#mi("\\mathcal{K}\\ell_2(\\cdot)")#text(" should be replaced by the classical sum ")#mi("Kl(\\cdot)")#text(".")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-252726")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2013")])]

#text("Some more typos:")#linebreak()#text(" * p9, Table 4, ")#mi("{\\cal D}^i(y)")#text(" changes again, and should now be ")#mi("{\\cal D}^{(i)}(y)")#text(" according to the latest notation in Def 2.14.")#linebreak()#text(" * p18 l 1, in Def 2.14 itself, ")#mi("{\\cal D}(y)")#text(" has the left parenthese superscripted.")#linebreak()#text(" * p42, proof of lemma 4.2, it seems too strong a claim that the first display holds “for any ")#mi("\\varepsilon")#text(">0″; also, after the WLOG condition supp g = [0,1] is dropped, it is not obvious where the summation restriction ")#mi("d\\leq R/ab")#text(" comes from in the second display above (4.13). Maybe better to do the alternative way in (")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248837")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-248837")]#text(")?")#linebreak()#text(" * p67, last sentence of 3rd complete paragraph, “The preprocess function 4.55…” 4.55 missing parentheses (might be a \\ref instead of \\eqref).")#linebreak()#text(" * p87 statement of Lemma 6.9, R should be in blackboard font in ")#mi("x_0 \\in \\mathbb{R}")#text(".")#linebreak()#text(" * p90, (6.19) parentheses on the RHS are not balanced. More )’s then (‘s.")#linebreak()#text(" * p96 1st paragraph after Theorem 7.1, (9.4) should be (7.3) (reference conflict?). Next line, “the found” should be “the type found”? “estimate (iii)” might be better as “case (iii)”?")#linebreak()#text(" * p100 line above (7.5), “implies”; line below (7.6), “recall”.")#linebreak()#text(" * p101 line above (7.9), “therefore”.")#linebreak()#text(" * p103 display in statement of Lemma 7.6, LHS missing right “)”. Same for last line of the page (2nd display after end of proof).")#linebreak()#text(" * p105, l -1, “reunion” is “union”?")#linebreak()#text(" * p106, Remark 7.7, 1st sentence, “note” should probably be after the comma(,).")#linebreak()#text(" * p108, paragraph before sec7.4, the counting of cases is a bit confusing.")#linebreak()#text(" * p111, l -3 of proof of Prop7.10, “then” should be “the”.")#linebreak()#text(" * p116, l -1 of sec 7, ")#mi("w_2")#text(" should be ")#mi("w_1")#text(".")

#emph[#text("[Corrected (except for the reference error, which I presume Emmanuel will resolve) in the main version, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-252922")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2013")])]

#text("I will put in these corrections (and check the reference…)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253063")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("I read the first 47 pages carefully, and I hope I can read the rest by the end of the week. Here is my first list of corrections and suggestions, all of which are minor, but please check:")

#text("1. Page 1, Abstract: “")#mi("p_n, p_{n+1}")#text("” should be “")#mi("p_n")#text(", ")#mi("p_{n+1}")#text("”")

#text("2. Page 4, Footnote 1: Give a reference to Maynard’s preprint.")

#text("3. Page 14, Line -1: Insert a reference for the application to Titchmarsh’s divisor problem.")

#text("4. Page 15, Line -10: “will not dwell” should be “we will not dwell”")

#text("5. Page 19, Line 1: “large value” should be “larger value”")

#text("6. Page 21, (2.12): Interchange ")#mi("q")#text(" and ")#mi("r")#text(" to harmonize with later notation. Correspondingly, change ")#mi("a\\ (r)")#text(" to ")#mi("a\\ (q)")#text(" in the next line.")

#text("7. Page 21, (2.14): ")#mi("\\varphi(r)")#text(" should be ")#mi("\\varphi(q)")#text(".")

#text("8. Page 22, Line 6: I think only the ")#mi("\\psi_j")#text("‘s are smooth, ")#mi("\\alpha")#text(" is not. This is especially emphasized four lines above Lemma 2.22.")

#text("9. Page 24, Line 1: “last constraint” should be “penultimate constraint”")

#text("10. Page 28, Line -4: “can found” should be “can be found”")

#text("11. Page 29, Line -15: It would be worthwhile to give an example of ")#mi("k")#text(" for which ")#mi("H(k)<p_{k-1}")#text(".")

#text("12. Page 34, Footnote 12: \"Their proofs\" should be \"The proofs\"")

#text("13. Page 43, Line 10: Perhaps \"integration by parts\" would be better than \"Fubini's theorem\".")

#text("14. Page 44, display below (4.15): ")#mi("\\ll")#text(" should be ")#mi("\\leq")

#text("15. Page 45, Line 4: ")#mi("\\rho(d)")#text(" is missing from the denominator.")

#text("16. Page 46, (4.20): ")#mi("n=b")#text(" should be ")#mi("n=b+h_i")

#text("17. Page 46, (4.21): ")#mi("n+h_i=b")#text(" should be ")#mi("n=b")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253071")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("I implemented all of these corrections except for #11, as I did not have a good example of this in mind (Wikipedia ")#link("http://en.wikipedia.org/wiki/Second_Hardy%E2%80%93Littlewood_conjecture")[#text("suggests")]#text(" that k=447 is the first counterexample, but we should probably double-check this.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253073")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Thank you! It seems that ")#mi("k=597")#text(" works, since in this case ")#mi("H(k)\\leq 4362")#text(" and ")#mi("p_{k-1}=4363")#text(". Of course there might be a smaller counterexample. Probably Andrew is the best person to locate the smallest known example.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253074")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("Thanks! I’ll also merge in these corrections.")

#text("I haven’t yet had time to go through typei-advanced (reports and teaching, etc…), but I still hope to finish this week. I’ll also review the extra section that Philippe added in deligne.tex as additional application.")

#text("By the way, I’ve put the survey on trace functions that I had added as a reference on my web page.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253075")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("k=459 also satisfies ")#mi("H(k)<p_{k-1}")#text(": the LHS is at most 3240, the RHS is 3251.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf6302e0d67b9deb354cb529edbd8f475a6fb55a5003b472f23df7b4d2366db-94f09221f7fbaf3b999af5ef8cfb6585fd6f92f359eb736cee14b6634d7d2e7d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253080")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("I find the same value ")#mi("k = 459")#text(". Note that ")#mi("\\rho^*(p_{k-1}) > k - 1")#text(", where ")#mi("\\rho^\\ast(x)")#text(" is the largest integer ")#mi("d")#text(" for which there exists an admissible ")#mi("d")#text("-tuple of diameter strictly smaller than ")#mi("x")#text(". This implies that ")#mi("\\rho^\\ast(p_{k-1}) > \\pi(p_{k-1})")#text(", so we have found an ")#mi("x")#text(" such that ")#mi("\\rho^\\ast(x) > \\pi(x)")#text(", which is what one needs to contradict the second H-L conjecture, assuming the prime tuples conjecture.")

#text("But there are smaller values of ")#mi("x")#text(", that are not of the form ")#mi("p_i")#text(", for which ")#mi("\\rho^\\ast(x) > \\pi(x)")#text(": here one can take ")#mi("x = 3159")#text(", for which ")#mi("\\rho^\\ast(x) = 447")#text(" and ")#mi("\\pi(x) = 446")#text(" (see Engelsma’s site). That is probably what wikipedia refers to.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253098")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2013")])]

#text("OK, I put the k=459 example in a footnote to the paper; thanks for confirming the value and explaining the Wikipedia value also.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-253560")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 28 November 2013")])]

#text("I’m sorry that I am a bit late with Section 9 — a few urgent things came up early this week… I should be done either over the week-end or on Monday.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255170")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")])]

#text("I am working on Section 9 and at first thought everything went smoothly. However, I realized that the issue we had in section 7 with H being replaced by H/q_0 does also turn up here. Precisely, this is a problem when checking that the quantity D_1 of the main folder version is << R (since there is factor H^4 in the denominator, this increases the current D_1 by q_0^4, and the previous estimate << R was rather tight).")

#text("The first obvious \"solution\", namely replacing H^4 by q_0^4H^4 in defining D_1, hits a snag in the q_0 powers in the final estimates (because the quantities D_1 and D are now smaller), although I may have made computation mistakes in checking this — I will check again tomorrow before attempting other possible solutions (I remember having had sometimes the impression that the estimates were not optimal with respect to q_0, and not much is needed, but the bounds I have rechecked do seem to be tight).")

#text("I will put in the ek subfolder the current state of my files (the changes of this section are not finished, but the flow of the argument leading to the problem should be readable if one wishes to look through this instead of the old version). Note that D_1 became D and D became Delta in this version…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255174")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")])]

#text("Dear Emmanuel,")

#text("I unfortunately am busy for the next few days and won’t be able to check things directly, but perhaps the same fix we proposed for Section 7 (namely, isolating the k=0 case to be treated separately, see ")#link("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-250067")[#text("https://terrytao.wordpress.com/2013/10/15/polymath8-writing-the-paper-iv/#comment-250067")]#text(" ) works here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255177")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")])]

#text("I think this is already incorporated, since this step was done in the general Type I/II work. I will work on this tomorrow and I still hope this is just a computation mistake somewhere (since q_0 shouldn’t affect the basic argument).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255180")[#strong[#text("Deterministic RIP matrices: Breaking the square-root bottleneck | Short, Fat Matrices")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2013")]

#text("[…] then, the Polymath project exploded to decrease this number considerably. In a recent blog entry, Terry Tao took some time to reflect on why this Polymath project received so much attention. Here is one of the reasons he points […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255341")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("I checked the exponents of q_0 and there does not seem to be merely a computational mistake, so one has to find another workaround to get rid of this problem. I will continue thinking about it…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255350")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("Hmm, this is troubling, that even with the previous fix that essentially recovered one power of ")#mi("q_0")#text(", that we are still in the hole for another power – so the original argument in fact had two powers of ")#mi("q_0")#text(" missing? (or even more, once Cauchy-Schwarz is taken into account?) I will try to look through the argument carefully when I have a chance. (I did notice though a conflict of notation: ")#mi("\\Delta")#text(" is now being used for two different quantities in Section 10, one for what used to be called D, and another for the quantity ")#mi("h \\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1")#text(", but perhaps this is because the revision process is still incomplete.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255359")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("Concerning, Delta, I’m indeed still fixing the notation for some lemmas and other parts of Section 10. I will update the ek folder later today.")

#text("In the current state of things, we get stuck with the following dilemma (stated using old notation):")

#text("(1) either D and D_1 are kept as in the old text, but then the condition D_1 << R becomes problematic because there is an extra factor q_0^4")

#text("(2) or one changes the definition of D and D_1 (dividing by q_0^4 in effect) and then the final estimates have extra powers of q_0.")

#text("I tried fiddling with the power of q_0 in changing d_1, or trying to get rid of large q_0 using trivial estimates early on. The second seems most promising, but I couldn't get a good enough control on the size of q_0 to handle even those…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255360")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("(In other words, we have a constraint of a different kind than before: the final estimates are fine, but the condition D_1 << R involved in the splitting of moduli does not necessarily hold).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255489")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2013")])]

#text("Here is a possible fix. First observe that if the quantity H defined before Remark 7.7 (or in (10.1), which is essentially the same quantity) is less than 1, then ")#mi("\\hat \\Sigma(b_1,b_2)")#text(" vanishes and we have nothing to prove. So we may assume wlog that ")#mi("H \\geq 1")#text(". Next observe that the upper bound ")#mi("D \\lessapprox R")#text(" in (10.6) may be relaxed to ")#mi("D \\lessapprox x^\\delta R")#text(" and one still gets the factorisation ")#mi("r = dr_1")#text(" (when ")#mi("D \\geq R")#text(" one just sets ")#mi("d=r, r_1=1")#text("). So now it seems to me that we can set ")#mi("D")#text(" equal to ")#mi("x^{-5\\varepsilon} \\frac{N}{H^4}")#text(" (without the ")#mi("q_0^4")#text(" denominator) and one still has the weakened bound ")#mi("D \\lessapprox x^\\delta R")#text(" thanks to (7.12).")

#text("Incidentally there is also an “emergency exit” here, which is to revert back to the slightly weaker MPZ estimates of Zhang, in which the residue class ")#mi("a\\ (P_I)")#text(" is not completely arbitrary, but has the additional multiplicity constraint that for most ")#mi("n \\precsim x")#text(", there are only ")#mi("\\lessapprox 1")#text(" moduli ")#mi("q \\ll x^{1/2+2\\varpi}")#text(" such that ")#mi("n = a\\ (q)")#text(" (more precisely, one needs an L^2 bound on the number of such q as n varies). This sort of hypothesis lets us kill off the ")#mi("q_0 > 1")#text(" contributions as soon as they appear in ")#mi("\\Sigma(b_1,b_2)")#text(" by crude bounds (not exploiting any cancellation), without having to carry factors of ")#mi("q_0")#text(" all through the rest of the analysis; in the application to prime gaps in which the congruence class ")#mi("a\\ (P_I)")#text(" is the root of a fixed polynomial, the multiplicity hypothesis can be verified from standard estimates on the divisor function (Lemma 1.5(iii)). But I would prefer to avoid this route as it makes the MPZ statement less elegant (and less applicable to potential other applications than prime gaps).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255527")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("I had noted the fact that D<=1 condition suffices to make things work.")

#text("Another possibility would be to drop the dense-divisibility and deal with smooth numbers only — although that would lose a bit in the GPY step, this might not be so bad, and after all we are far from Maynard’s gap anyway…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255528")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 4 December 2013")])]

#text("Correction: D<=x^(delta)R…")

#text("We should actually mention this slight relaxation of the d.d. condition since it was used once or twice before.")

#text("And indeed, this solves the problem — I should be able then to finish the review of Section 10 today or tomorrow.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255904")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("I just put up in the ek subfolder the reviewed version of Section 10. I added the extended d.d. range (1<R<= yn) in the definition and remarked that the extra range is automatic in Lemma {fq} in gpy.tex")

#text("I also re-added a minor comment in exponential.tex concerning possible appearances of e_p(0/0), since these tend to appear in Section 10.4: basically, we are dealing with psi(infty) where psi is the trivial additive character e_p(0 \\times x), and the right definition of psi(infty) (from the trace function point of view) is that this is 0 if psi is non-trivial, and 1 if psi is trivial.")

#text("I will still have a look at improvements.tex, but more quickly (and to prune the parts now made obsolete by Maynard's work).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255925")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("OK, I will start going through the paper one last time from Section 1 onwards now. (If you could synchronise the ek folder with the main folder that would be helpful.) Thanks for all the careful reading!")

#text("Regarding improvements.tex, I’m increasingly inclined to postpone pretty much all of it for the Polymath8b paper; it was written at a time when the Polymath8a paper was likely to be our final word on these topics, and now with Maynard’s work and Polymath8b it seems that it is no longer so logical to place this sort of discussion here. (For instance, at some point we will have to revisit the MPZ estimates to flesh out Nelson’s idea to improve ")#mi("\\varpi")#text(" further.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255927")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("I’ll synchronize the file later today. I think there were no changes in the main folder since the last sync, but I’ll make sure.")

#text("In a few days, I’ll also read through quickly again to catch typos and inconsistencies in notation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-255936")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2013")])]

#text("I’ve merged the file from the subfolder to the main folder.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256144")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2013")])]

#text("In fig. 3, the numerator in the vertical caption should be ")#mi("H")#text(" (i.e. “best known upper bound”) instead of ")#mi("H(k)")#text(".")

#emph[#text("[This appears to have been fixed already – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("I’ve reread up to Section 8, making some minor typo changes etc. but nothing major. There were some existing “TODO”s in Section 8 that I didn’t touch (other than to colour them red to make them easier to find). Will go onwards to Section 9 and Section 10 next.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256610")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("I will look again myself this week-end up to Section 8 and take care of the TODO items.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256548")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("Interestingly, ")#mi("\\eta = \\alpha / \\beta")#text(". (coincidence?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256560")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("Just out of curiosity: Where in the document are ")#mi("\\eta")#text(", ")#mi("\\alpha")#text(", and ")#mi("\\beta")#text(" defined? (I’m asking as a curios non-mathematician.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256564")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("You can find both in p. 53 (")#mi("\\eta")#text(" is defined in lemma 4.10, and the ratio ")#mi("\\alpha / \\beta")#text(" is defined in (4.31) – and is minimized by the optimal weight function ")#mi("f")#text(")")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256552")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("Bibliography:")

#text("The titles should (I _think_) be in italic in [1], [20], [35], [51]–[53], [58], [65].")

#emph[#text("[Currently we are using the convention that article titles are italicised, but book titles are not. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256566")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("Between (4.33) and (4.34), p. 52: “Lemma” –> “lemma”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256585")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 December 2013")])]

#text("Second formula on p. 87: Load “")#link("http://www.ctan.org/pkg/mathtools")[#text("mathtools")]#text("”, define paired delimiters by “\\DeclarePairedDelimiter\\inner{\\langle}{\\rangle}”, and then use “\\inner{f,g}”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256643")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2013")])]

#text("I just updated the files after reviewing Terry’s changes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-256683")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2013")])]

#text("In the line below (10.15), it should be “… that ")#mi("m")#text(" is …”.")

#emph[#text("[Corrected, thanks. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257374")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("I am truly busy these days, but I try to catch up with proof-reading. Here are some new corrections and suggestions for the latest version:")

#text("1. Page 48, Line -8: A factor ")#mi("E^*(q)")#text(" is missing inside the first sum. This factor is ")#tao-math("\\ll (x\\log x)\\left|C_i(q)\\right|/\\varphi(q)", block: false)#text(" by trivial estimation of (4.21), hence the corrected first sum is ")#tao-math("\\ll (x\\log x)\\sum_{Wq\\in \\mathcal{Y}} h(q)^2\\left|C_i(q)\\right|^2/\\varphi(q)", block: false)#text(".")

#text("2. Page 48, Line -5: In accordance with the previous item, ")#tao-math("\\left|C_i(q)\\right|", block: false)#text(" should be ")#tao-math("\\left|C_i(q)\\right|^2/\\varphi(q)", block: false)#text(" in this display, and there should be no ")#mi("x^{1/2}")#text(" on the right hand side (instead, ")#mi("x^{1/2}")#text(" comes from the separate factor ")#mi("(x\\log x)^{1/2}")#text(").")

#text("3. Page 48, Line -3: ")#mi("R^2")#text(" should be ")#mi("WR^2")#text(", but this might be obsolete in the light of the next item.")

#text("4. Page 48, Line -1: I think this display is not good for the first display on page 49, because restricting ")#mi("q")#text(" to multiples of ")#mi("W")#text(" here, only those residue classes mod ")#mi("W")#text(" will occur that lie in ")#mi("C_i(W)")#text(". Instead, we should restrict (4.23) to ")#mi("q")#text(" divisible by ")#mi("W")#text(" first, and then average over those residue classes mod ")#mi("Wq")#text(" that reduce to some ")#mi("a\\in C_i(q)")#text(" and to ")#mi("b+h_i")#text(" mod ")#mi("W")#text(". This yields the second display on page 49 directly, with the necessary correction that ")#mi("b")#text(" should be ")#mi("b+h_i")#text(" there.")

#text("5. Page 49, Line 3: This display might be obsolete in the light of the previous item.")

#text("6. Page 49, Line 5: ")#mi("b")#text(" should be ")#mi("b+h_i")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257400")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("Gone through Section 9 fairly carefully, some rewording and rearranging of the logic, but nothing major. I also credited the simple but crucial trick of combining the triple sum over ")#mi("l_1,l_2,l_3")#text(" into a single sum over ")#mi("l=l_1l_2l_3")#text(" to Heath-Brown, who explicitly calls it “the key step” in his own d_3 distribution paper from 1986.")

#text("On to Section 10…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257426")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2013")])]

#text("I read another 12 pages. Here are some small corrections and suggestions:")

#text("1. Page 49, Line -5: Insert a reference to (4.8) after ")#mi("a_{de}")#text(".")

#text("2. Page 49, Line -3: ")#mi("mq")#text(" should be ")#mi("dm")#text(": 2 occurrences.")

#text("3. Page 50, four lines below (4.24): “estimated” should be “is estimated”.")

#text("4. Page 55, Line -1: This display is valid independent of the previous display.")

#text("5. Page 57, Line -6: ")#mi("\\delta")#text(" should be ")#mi("x^\\delta")#text(".")

#text("6. Page 59, Case (0) of Lemma 4.12: “$i$-tuple” should be “$i$-tuply”.")

#text("7. Small corrections for the list of references:")

#text("In item [13], “Deligne, P.” should be “P. Deligne”.")

#text("In item [17], “mathematics” should be “Mathematics”, and 155-161 should be 155–161.")

#text("In item [22], Birkhaüser should be Birkhäuser.")

#text("In item [28], “(2013)” should follow the volume number “155”.")

#text("In item [53], “(1988)” should be “, 1988”.")

#text("In item [54], “(1990)” should be “, 1990”.")

#text("In item [56], “pp.” should be omitted.")

#text("In item [70], “(1969)” should be followed by a comma.")

#text("In item [76], the authors should be separated by a comma instead of “and”.")

#text("In item [85], “1996” should be preceded by a comma.")

#text("In item [87], “1948” should be preceded by a comma.")

#text("In item [88], “Annals of Mathematics” should be “Ann. of Math.”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257593")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Dear Terry, thanks for taking care of my corrections. Some leftover:")

#text("On Page 56, Line 2, I would delete the words “and thus”.")

#text("In item [70], “(1969)” should be followed by a comma.")

#text("In item [76], the authors should be separated by a comma instead of a dot.")

#text("In item [85], “1996” should be preceded by a comma.")

#text("In item [88], “Ann. Math.” should be “Ann. of Math.”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257595")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("I’m wondering if we may have to change the title of the paper: “A new bound for gaps between primes” is, strictly speaking, no longer accurate as of late October. Our distribution theorem for the primes remains new though (and is a better improvement over Bombieri-Vinogradov than Zhang’s original bound by a factor of more than ten), so we could reword the title to emphasise that, e.g. “A new distribution theorem for the primes, and bounds for gaps between primes”. Of course the abstract and introduction would also be reworded slightly to reflect this new emphasis. I’m still on the fence though as to whether we should do this; alternatively we could maintain the convention that the paper mostly refers to the state of affairs at the time when it was first being written up in August. Anyway, I would be happy to hear of any opinions on this topic.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257610")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("I am happy with the old title, and also with the new suggestion. Here are two alternate suggestions:")

#text("Gaps between primes and equidistribution in arithmetic progressions")

#text("Bombieri-Vinogradov type results and bounded gaps between primes")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257600")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2013")])]

#text("Another possible title could be “Improving Zhang’s bound for gaps between primes”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-257747")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 19 December 2013")])]

#text("I have read through the first 8 sections (mainly from an editorial point of view; I only checked the proofs of some of the more elementary statements) and mainly fixed some typos along the way.")

#text("Below I list some of the choices that I made to make our notation more consistent (so that people making future changes can take them into account):")#linebreak()#text(" * ")#mi("i^{\\text{th}}")#text(" over ")#mi("i")#text("-th ")#emph[#text("[Note: the former “th” should be in the \\operatorname{} environment, but this is not recognised by WordPress LaTeX -T.]")]#linebreak()#text(" * “Chinese Remainder Theorem” over “Chinese remainder theorem” (and similarly for the Prime Number Theorem)")#linebreak()#text(" * “prime tuples conjecture” over “prime tuple conjecture”, “")#mi("k")#text("-tuples conjecture”, …")#linebreak()#text(" * ")#mi("\\neq")#text(" over ")#mi("\\not=")#text(" ")#emph[#text("[Note: the second inline here is $\\not =$, which in the paper is rendered with a vertical line rather than a slash – T.]")]#linebreak()#text(" * “Polymath project” over “polymath project”")#linebreak()#text(" * ")#mi("\\text{\\texttt{true}}")#text(" over ")#mi("\\text{\\emph{true}}")#text(" (for booleans)")#linebreak()#text(" * ")#mi("\\overline{\\mathbb{Q}_\\ell}")#text(" over ")#mi("\\overline{\\mathbb{Q}}_\\ell")

#text("At some points I also chose")#linebreak()#text(" * ")#mi("p \\mid q")#text(" (\\mid) over ")#mi("p|q")#linebreak()#text(" but I didn’t do the effort to trace every occurrence.")

#text("Here are some questions / unsolved issues:")#linebreak()#text(" * Right before Theorem 3.1: I added a footnote on the recent results on bounded gaps between prime triples, quadruples, … as an extra motivation for having efficient methods to find narrow admissible tuples. I’m not sure to what extent we want to keep things “chronological”, however.")#linebreak()#text(" * In formula (4.21)")#linebreak()#text(" ")#tao-math("\\displaystyle  E^*(q) := \\sum_{a \\in C_i(q)} \\Big{\\left| \\sum_{\\substack{x \\leq n \\leq 2x\\\\ n=b+h_i\\ (W)\\\\ n = a\\ (q)}} \\Lambda(n) - \\frac{x}{\\phi(Wq)}\\right|}", block: false)#linebreak()#text(" it’s not clear at first sight whether the last term is understood to be part of the summand or not, so maybe it’s better to switch terms, i.e. to write")#linebreak()#text(" ")#tao-math("\\displaystyle  E^*(q) := \\sum_{a \\in C_i(q)} \\Big{\\left| \\frac{x}{\\phi(Wq)} -  \\sum_{\\substack{x \\leq n \\leq 2x\\\\ n=b+h_i\\ (W)\\\\ n = a\\ (q)}} \\Lambda(n) \\right|}.", block: false)#linebreak()#text(" * There’s a similar issue with the formula in Remark 8.23.")#linebreak()#text(" * In the paragraph below the statement of Lemma 4.4: “… the archimedean size of elements of ")#mi("\\mathcal{Y}")#text(" (which make the statement harder to prove)” Does the “which” refer to the archimedean size here? (If yes, it should be “makes”.)")#linebreak()#text(" * In the proof of Lemma 4.12: “By induction, ")#mi("q")#text(" is therefore …” This phrase should be rewritten.")#linebreak()#text(" * In Section 6, sometimes ")#mi("\\overline{x}")#text(" refers to inversion modulo ")#mi("q")#text(", and sometimes to complex conjugation. Should we add a remark about this (it’s always clear from the context, of course)?")#linebreak()#text(" * In the paragraph below Example 6.1: “where ")#mi("a")#text(" and ")#mi("b")#text(" are integers that […] may apparently be simultaneously divisible by ")#mi("p")#text(".” After this, a case distinction between ")#mi("a \\neq 0 \\, (p)")#text(" and ")#mi("a = 0 \\, (p)")#text(" is made. So should it be just ")#mi("b")#text(" that is divisible by ")#mi("p")#text(" in the above phrase?")#linebreak()#text(" * In the last formula of Section 7.2: What is ")#mi("\\tilde{h}_2")#text("?")#linebreak()#text(" * In the phrase right before Remark 7.7: “which one must be careful to note depends on ")#mi("q_1")#text(" and ")#mi("q_2")#text("“: this sounds a bit twisted.")#linebreak()#text(" * In Remark 8.16 and in the proof of Theorem 8.17 we write")#linebreak()#text(" ")#mi("\\displaystyle [ax + b]^* \\mathcal{F}")#text(" and")#linebreak()#text(" ")#mi("\\displaystyle [z \\mapsto z(e-z)]* \\mathcal{K}\\ell_3")#linebreak()#text(" Maybe these should be changed in conformity with the notation introduced in Section 8.1?")#linebreak()#text(" * In the proof of Theorem 8.29: maybe I overlooked this, but what does ")#mi("\\ll_{k,k^{\\prime}}")#text(" mean?")

#emph[#text("[Corrections implemented, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-258651")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("I’ve gone through Section 10 (mostly focusing on tracking the powers of ")#mi("q_0")#text(", which were an issue recently), and also commented out Section 11, punting it to a subsequent paper (and thus shaving a few pages off of the length, though at 169 pages it’s still a monster of a paper). The title, abstract, and introduction still needs to be looked at again in view of all the recent progress, and there are some residual “TODO”s in the Deligne section, but other than that I’m happy to sign off on this paper for the purposes of submission, though I think a few people are still doing some additional proofreading.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-258667")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2013")])]

#text("In the fifth line above subsection 1.2, it should by “only”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Sutherland")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-259475")[#strong[#text("Andrew Sutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2013")])]

#text("At the suggestion of Christian Elsholtz, I added a footnote to section 3.5 explaining how ties were broken when obtaining the tuples listed in the “Shifted greedy” row of table 5.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5abba5dd562f9355e60dc4c9893442e683e37151512bafa0a62957a87138f8ac-758fe84da47080c2384192dc09d20727c346092a341b0ed9fcbbbdf425655802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wouter Castryck")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-261449")[#strong[#text("Wouter Castryck")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I’ve fixed some small typos in Sections 1-3 and 9-10, and have now read everything at least once (although rather superficially from Section 4 on). I also agree with a slight change of emphasis in the title. As a combination of Eytan’s and Gergely’s suggestion, maybe “Zhang type distribution results and bounded gaps between primes” would be a possible title?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-261502")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2014")])]

#text("I’ve now changed the title (and modified the introduction a bit accordingly). I think we’re getting very close to being able to submit; there are a few “TODO”s left in the text, mostly in the Deligne section, but apart from that and any further proofreading we should be good to go soon!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-262495")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2014")])]

#text("A small update: we had a reference to a strengthening of Zhang’s theorem in a recent survey of Friedlander and Iwaniec, in which the residue class a was allowed to vary in q. Unfortunately, I’ve just been informed by the authors that the proof of this strengthened version had a gap, and possibly an unfixable one, so I’ve removed the reference to this improved version of the theorem from the Polymath paper for now at least.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-267526")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2014")])]

#text("Thanks for the update. I could not read the manuscript further (I stopped around page 60) because of my other tasks, and it seems for another month I will still be very busy, so I definitely give a green light on my side to the paper, especially that Emmanuel has checked everything carefully. On the other hand, if others are still reading and this thread is not closed, I might throw in some typos later.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-262675")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("In subsection 7.2, the notation ")#mi("EMT")#text(" is defined as a certain term in definition 1.2 (which does not exist!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/11/17/polymath8-writing-the-first-paper-v-and-a-look-ahead/comment-page-1/#comment-262677")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2014")])]

#text("I’m sorry! I misunderstood def. (1.2) as def. 1.2.")
]
]
