// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/
// Converted to Typst by tao2typ: "2026-10-14T16:35:29.117638+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Math 245B: Real analysis (course announcement)", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Math 245B: Real analysis (course announcement)")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 17 December 2008")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/")[#text("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Starting on January 5th, the beginning of the winter quarter here at UCLA, ")#link("http://www.math.ucla.edu/~tao/245b.1.09w")[#text("I will be teaching Math 245B")]#text(", a graduate course on real analysis. As the name suggests, the course is a continuation of the ")#link("http://www.math.ucla.edu/~ralston/245a.1.08f/")[#text("Math 245A course")]#text(" that just concluded in this fall quarter, taught by ")#link("http://www.math.ucla.edu/~ralston/")[#text("Jim Ralston")]#text(", who covered the basics of measure theory and ")#mi("L^p")#text(" spaces. In this quarter, I plan to cover more of the foundational theory of graduate real analysis, specifically")

#list(
[#text("Signed measures, ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measures")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Radon-Nikodym_theorem")[#text("Radon-Nikodym theorem")]#text(";")],
[#text("The general theory of ")#mi("L^p")#text(" spaces;")],
[#text("Introduction to functional analysis, particularly the theory of ")#link("http://en.wikipedia.org/wiki/Hilbert_space")[#text("Hilbert spaces")]#text(" and ")#link("http://en.wikipedia.org/wiki/Banach_space")[#text("Banach spaces")]#text(";")],
[#text("Various aspects of point set topology of relevance to analysis, including ")#link("http://en.wikipedia.org/wiki/Tychonoff%27s_theorem")[#text("Tychonoff’s theorem")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Stone%E2%80%93Weierstrass_theorem")[#text("Stone-Weierstrass theorem")]#text(".")]
)

#text("I will be using Folland’s “Real analysis” as a primary text and Stein-Shakarachi’s “Real analysis” as a secondary text. These two texts already do quite a good job of covering the above material, but it is likely that I will supplement them as the course progresses with my own lecture notes, which I will post here, though I do not intend to make these notes nearly as self-contained and structurally interlinked as my ")#link("https://terrytao.wordpress.com/category/teaching/254a-ergodic-theory/")[#text("notes on ergodic theory")]#text(" or ")#link("https://terrytao.wordpress.com/category/teaching/285g-poincare-conjecture/")[#text("on the Poincaré conjecture")]#text(", being supporting material for the main texts rather than a substitute for them.")

#heading(level: 1)[#text("Comments (6)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/687285373811cc159f4584f2369fdad3c0807b71ebd81ddcca7ce198d4e365a1-e122baeb7933233bb22e269cc79bc86024113cd3d54c4453932bc0c67558b00c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christos Michalopoulos")]], [#link("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/#comment-34111")[#strong[#text("Christos Michalopoulos")]]#text(size: 9pt, fill: rgb("596477"), " · 17 December 2008")])]

#text("Dear Prof. Tao,")#linebreak()#text(" i am a PhD student in Econometrics and i am also interested in statistics and probability. You are using Folland’s book in your course. May i ask if you have ever heard of the book, Principles of Real Analysis by Charalambos D. Aliprantis and Owen Burkinshaw? I kind of enjoy this book and i think it is of graduate level. If you have read it do you think it is good?")#linebreak()#text(" Also, at graduate level analysis, what do you think are the most important mathematical ideas one definitely needs to master and be comfortable with?")#linebreak()#text(" Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/#comment-34123")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2008")])]

#text("Dear Terry:")

#text("It’s amusing to find this post by you. I’m taking an undergrad course in Buenos Aires (actually, there’s no precise parallel in levels, but let’s say it’s the first degree I’ll get), majoring in math. Most of the subjects you mention are usually covered in the fourth year here, in a course called “Real Analysis”. We basically go over Lebesgue Measure, first part of ")#mi("L^p")#text(" spaces (say, we get to the point were we prove that ")#mi("C^\\infty_c(\\Omega)")#text(" is a dense subset), and as far as Radon-Nyknodim’s theorem. We basically cover chapters 3-11 of Zygmund and Wheeden’s book, if that will do as refference.")

#text("Also, other subjects such as the Stone-Weierstrass theorem, basic functional analysis and Tychonoff’s theorem are covered in a few more undergraduate classes (all mandatory for the “pure math” branch, in the fifth year). There’s an ongoing discussion as to how important it is for this calsses to be mandatory and before PhD., and my attention was directed to your post. Can I ask your take on the subject? Thank you!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/#comment-34130")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2008")])]

#text("This is a first-year graduate course in real analysis, and it certainly does have some overlap with a final year undergraduate course in real analysis. (For instance, our own undergraduate honours real analysis course does cover Lebesgue measure – though only on the real line – and some function space stuff, such as l^p norms.) With this sort of material, though, one does need repeated exposure at various levels of depth in order to really understand it. We certainly have some students, though, who have already seen all this material and skip this course, proceeding directly to the analysis qualifying exam.")

#text("In my opinion, it is not so much the material which is of importance (although there is a lot of material here which really is quite fundamental to many branches of modern mathematics), but the depth and breadth at which it is treated, and what the students get to do with it. For instance, I plan to have a moderately intensive set of homework (primarily out of Folland) in which I expect to receive coherent proofs to various extensions, variations or applications of results I actually cover in the course.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Prashant V")]], [#link("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/#comment-34134")[#strong[#text("Prashant V")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2008")])]

#text("Dear Terry,")

#text("You don’t like to use Real and Complex Analysis by Rudin?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e8a2043e747555bde6b123c33dd1e2d7e5e89aefb84d2306fbe925c84eb3e71-116ab124e629586edbbe8884697fdbb262c13500b5506118b5d863a683626f04.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gradstudent")]], [#link("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/#comment-34141")[#strong[#text("gradstudent")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2008")])]

#text("Dear Prof Tao,")

#text("I’m delighted to see this, as I myself am currently taking a similar course at another university, and have greatly enjoyed your notes on other topics — it will be nice to have your take on what I am currently studying.")

#text("As an aspiring mathematician who will presumably teach such courses in the future, I’d like if possible to get your thoughts on how to go about planning a course like this. In particular: (somewhat following up on a previous comment) how do you decide whether to use an existing text, and if so which one to use? Assuming one uses a textbook, how does one plan lectures for such a course? How do you know just what to say to avoid being superfluous (in the sense that the students could simply be left to read the book themselves)?")

#text("Anything else you have to add about the experience of teaching a basic graduate course (and how that may differ from teaching an undergraduate course, or a more advanced graduate course) would also be of interest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2008/12/17/math-254b-real-analysis-course-announcement/#comment-34218")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 December 2008")])]

#text("Hi, Terry,")

#text("A typo: the course should be 245B, not 254B. ")#emph[#text("[Corrected – T.]")]
]
