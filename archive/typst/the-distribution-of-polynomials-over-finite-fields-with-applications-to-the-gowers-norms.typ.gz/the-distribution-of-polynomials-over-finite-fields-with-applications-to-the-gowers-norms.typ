// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/
// Converted to Typst by tao2typ: "2026-10-14T16:35:05.366215+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The distribution of polynomials over finite fields, with applications to the Gowers norms", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The distribution of polynomials over finite fields, with applications to the Gowers norms")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 November 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/")[#text("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Ben Green and I have just uploaded our joint paper, “")#link("http://arxiv.org/abs/0711.3191")[#text("The distribution of polynomials over finite fields, with applications to the Gowers norms")]#text("“, to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(", and submitted to ")#link("http://cdm.math.ca/index.php/cdm")[#text("Contributions to Discrete Mathematics")]#text(". This paper, which we ")#link("https://terrytao.wordpress.com/2007/10/23/focs-slides-structure-and-randomness-in-combinatorics/")[#text("first announced")]#text(" at the recent FOCS meeting, and then gave an update on ")#link("https://terrytao.wordpress.com/2007/11/07/an-update-on-the-inverse-conjecture-for-the-gowers-norm-over-finite-fields/")[#text("two weeks ago on this blog")]#text(", is now in final form. It is being made available simultaneously with a closely related ")#link("http://arxiv.org/abs/0711.3388")[#text("paper of Lovett, Meshulam, and Samorodnitsky")]#text(".")

#text("In the previous post on this topic, I focused on the negative results in the paper, and in particular the fact that the inverse conjecture for the Gowers norm fails for certain degrees in low ")#link("http://en.wikipedia.org/wiki/Characteristic_%28algebra%29")[#text("characteristic")]#text(". Today, I’d like to focus instead on the positive results, which assert that for polynomials in many variables over finite fields whose degree is less than the characteristic of the field, one has a satisfactory theory for the distribution of these polynomials. Very roughly speaking, the main technical results are:")

#list(
[#text("A ")#emph[#text("regularity lemma")]#text(": Any polynomial can be expressed as a combination of a bounded number of other polynomials which are ")#emph[#text("regular")]#text(", in the sense that no non-trivial linear combination of these polynomials can be expressed efficiently in terms of lower degree polynomials.")],
[#text("A ")#emph[#text("counting lemma")]#text(": A regular collection of polynomials behaves as if the polynomials were selected randomly. In particular, the polynomials are jointly ")#link("http://en.wikipedia.org/wiki/Equidistribution")[#text("equidistributed")]#text(".")]
)

#metadata(none) <tao-4a2e2093dbdc9ea9d977>

#text("To describe these results more precisely, let us fix a small finite field ")#mi("{\\Bbb F}")#text(" of prime order and a degree d (with ")#tao-math("d < \\left|{\\Bbb F}\\right|", block: false)#text("), and a large dimension n. Let ")#mi("P: {\\Bbb F}^n \\to {\\Bbb F}")#text(" be a polynomial in n variables over ")#mi("{\\Bbb F}")#text(" of degree at most d. Let us say that P is ")#emph[#text("equidistributed")]#text(" if it takes on each of its ")#tao-math("\\left|{\\Bbb F}\\right|", block: false)#text(" values close to equally often, in the sense that")

#align(center)[#tao-fit-display[#tao-math("\\left| \\{ x\\in {\\Bbb F}^n: P(x) = c \\}\\right| = (1 + O(\\varepsilon)) \\left|{\\Bbb F}\\right|^{n-1}", block: true)]]

#text("for all ")#mi("c \\in {\\Bbb F}")#text(", for some small ")#mi("\\varepsilon")#text(" (the exact value of this parameter will not be too relevant for this discussion). A basic question is then: which polynomials P are equidistributed?")

#text("For low degree polynomials, the answer can be worked out quickly:")

#list(
[#text("If P has degree 0, then it is never equidistributed.")],
[#text("If P has degree 1, then it is equidistributed as long as it is not constant (i.e. it is not actually of degree 0). This fact, of course, is the starting point of Fourier analysis on ")#mi("{\\Bbb F}^n")#text(".")],
[#text("If P has degree 2 (i.e. it is basically a quadratic form), then it is equidistributed as long as the quadratic form has ")#emph[#text("high rank")]#text(", or equivalently that it cannot be efficiently expressed in terms of a few degree 1 polynomials. This can be made more formal and rigorous by computing some ")#link("http://en.wikipedia.org/wiki/Quadratic_Gauss_sum")[#text("Gauss sums")]#text(" over finite fields.")]
)

#text("Extrapolating from these examples, we thus see that a polynomial P tends to be equidistributed, unless it is a combination of lower degree polynomials. Conversely, any combination of lower degree polynomials is unlikely to be equidistributed. For instance, if ")#mi("P = Q^2")#text(" for some polynomial Q of half the degree, then P cannot be equidistributed, since it only takes on square values. A polynomial P which factors as ")#mi("P=QR")#text(" for some lower degree polynomials Q, R is likely to be zero about twice as often as one would ordinarily expect, which would again contradict equidistribution. More generally, a polynomial which takes the form ")#mi("P = Q_1 R_1 + \\ldots + Q_k R_k")#text(" for some bounded k and “independent” polynomials ")#mi("Q_1,\\ldots,Q_k,R_1,\\ldots,R_k")#text(" is again likely to have slight irregularities in distribution, although the regularity should improve as k increases.")

#text("Let us informally say that polynomial P has ")#emph[#text("low rank")]#text(" if it can be expressed as a bounded combination of polynomials of lower degree, and ")#emph[#text("high rank")]#text(" otherwise. Our first main result is:")

#strong[#text("Equidistribution theorem")]#text(". Let P be a polynomial of degree less than ")#tao-math("\\left|{\\Bbb F}\\right|", block: false)#text(". If P is high rank, then it is equidistributed.")

#text("(The result may well be true for higher degree polynomials, but our methods do not extend to that case; we need the high characteristic in order to recover a polynomial from its derivatives using a version of the ")#link("http://en.wikipedia.org/wiki/Taylor_expansion")[#text("Taylor expansion")]#text(" formula.)")

#text("Our argument begins by invoking a recent lemma of Bogdanov and Viola (as discussed previously on this blog), which shows that if P is not equidistributed, then it is very close to a low rank function. The main remaining task is then to obtain a certain rigidity property for low rank polynomials, namely that any polynomial which is sufficiently close to a low rank polynomial, is itself a low rank polynomial. This is done by testing the polynomial on various cubes in order to “correct” for errors; the main difficulty is a combinatorial one, counting the number of “good” cubes and ensuring that they are in sufficiently plentiful supply. This requires using the above equidistribution theorem, but for polynomials of strictly lower degree, allowing for an inductive argument to go through.")

#text("The equidistribution theorem implies the counting lemma by standard Fourier analytic techniques, and the regularity lemma is obtained by following the obvious reduction algorithm to eliminate any low rank dependencies among polynomials, similarly to how one can replace a finite collection of linearly dependent vectors with linearly independent ones with the same span, by repeatedly substituting away any dependencies. Putting these lemmas together, one can rather quickly verify the inverse conjecture for the Gowers norm for polynomials of degree less than the characteristic.")

#text("The paper also has some assorted related results, such as a ")#link("http://en.wikipedia.org/wiki/Nullstellensatz")[#text("Nullstellensatz")]#text(" which shows that a polynomial can only vanish on a “high rank” variety when it is a linear combination (in the ring of polynomials) of its defining polynomials (with sharp control on the degrees of the coefficient polynomials involved in this combination), and a recurrence result which shows that if a collection of boundedly many polynomials of bounded degree vanish at one point, then they must vanish at a large number of other points as well. The usual nullstellensatz of Hilbert requires that the ambient field ")#mi("{\\Bbb F}")#text(" is algebraically closed, which is of course highly false for finite fields; however, the high-rank assumption can compensate for this (so much so, in fact, that one no longer needs to mess around with ")#link("http://en.wikipedia.org/wiki/Radical_of_an_ideal")[#text("radicals")]#text(").")

#text("[")#emph[#text("Update")]#text(", Nov 20: typo fixed.]")

#heading(level: 1)[#text("Comments (12)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbf445dd3ded972a5d1b62126dac2900bf47db6c85c39b95626f92b945e4f092-821d2a67ec2aa6fd2150e7112d80a9cf9bad4da7b90b8dab1f324d9a6a89f5c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-16542")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2007")])]

#text("“… in the sense that no non-trivial linear combination of these polynomials cannot be expressed efficiently in terms of lower degree polynomials.”")

#text("That double negative allows simplification to: “in the sense that every non-trivial linear combination of these polynomials can be expressed efficiently in terms of lower degree polynomials.”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-16544")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2007")])]

#text("Sorry, the “cannot” should have been a “can”. It’s fixed now.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-16606")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2007")])]

#text("The equidistribution statement is fascinating…")

#text("It is interesting to compare it with what follows directly by applying the results of Deligne on exponential sums over finite fields; say for ")#mi("\\mathbf{F}=\\mathbf{Z}/p\\mathbf{Z}")#text(", after using additive characters modulo ")#mi("p")#text(" to detect the condition ")#mi("P(x)=c")#text(", the trivial character gives the expected main term for the number of solutions ")#mi("x")#text(", and the rest is a sum of exponential sums of the type")

#mi("S_a=\\sum_{x}{\\exp(2i\\pi a(P(x)-c)/p)}")

#text("with ")#mi("a=0,\\ldots,p-1")#text(", for which one can apply the Riemann Hypothesis of Deligne to get cancellation. However, the dependency on the degree is not necessarily well-controlled in general.")

#text("A good example of what can happen is if the homogeneous part of degree ")#mi("d")#text(" of ")#mi("P")#text(" is non-singular (what is often called a Deligne polynomial from the side of algebraic geometry). Then Deligne showed that for ")#mi("a")#text(" non zero modulo ")#mi("p")#text(", we have")

#tao-math("\\left|S_a\\right|\\leq (d-1)^n p^{n/2}", block: false)#linebreak()#text(" and this, plugged into the remainder term, leads to equidistribution _only_ for")#linebreak()#text(" ")#mi("d<\\sqrt{p}")#text(", roughly. So even in this very favorable case, your result is much stronger.")

#text("Note that Deligne’s bound is best possible in general, and so by using the type of assumptions (high-rank) in your paper, one may hope to improve this. In the other direction, your result implies some control of the “dual” expressions for the exponential sums (after applying the trace formula) which it would be really interesting to understand on the algebraic-geometry side.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-16846")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2007")])]

#text("Dear Emmanuel: thanks for the comments! I had not realised that Deligne’s estimates were still so powerful in high dimension (the condition ")#mi("d \\leq \\sqrt{p}")#text(" is fairly similar to our own condition ")#mi("d < p")#text(", and we don’t have anywhere near as good explicit constants in our bounds, due to a heavy reliance on regularity lemmas).")

#text("The property of being non-singular is somewhat analogous to having “maximal” rank, though I am not sure what the precise connection is. For instance, if ")#mi("P = Q_1 R_1 + \\ldots + Q_k R_k")#text(", where all polynomials are homogeneous and of low degree, then the level set ")#mi("\\{ P = 0 \\}")#text(" contains the level set ")#mi("\\{ Q_1 = \\ldots = Q_k = 0 \\}")#text(" as a singularity if k is not too large compared with the dimension n and the degrees of the various polynomials. But perhaps the non-singularity hypothesis is not strong enough to detect all possible efficient representations of the polynomial in terms of lower degree polynomials.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20f84cef92794cf246f05dcb9261ab5fb8c27156c8baf7be823af31943851321-cf92ce41652929d5d2f92578b1747480bc0a4279f61d65d243114e59ea03d178.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Amr Alturky")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-469082")[#strong[#text("Amr Alturky")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2016")])]

#text("Sir Amwalima and dear Terence I enjoyed watching your lecture and I learned a lot from and become you first teacher in my life Can you help me in the examination Borhani has I think I proved Riemann hypothesis and intuitive Erdos Altalgah equations Aldivonteh but I can not publish any of it until after Mraadjatk these proofs and allowing me to publish Nenni to severe embarrassment to publish dimension to obtain a permit from you sir I am serious Loire")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-16990")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 25 November 2007")])]

#text("The non-singular case is the easiest to understand, but there are other more general results (mostly by Nick Katz), though they are more complicated to state (for instance in his paper “Estimates for ‘singular’ exponential sums”, IMRN 16, 1999).")

#text("In terms of being best possible, here is what happens for the non-singular case: then, for each")#linebreak()#text(" ")#mi("a")#text(", there exist ")#mi("B=(d-1)^n")#text(" numbers ")#mi("\\alpha_1")#text(", …, ")#mi("\\alpha_B")#text(", each with")#linebreak()#text(" ")#tao-math("\\left|\\alpha_i\\right|=p^{n/2}", block: false)#text(", so that")

#mi("S_a=(-1)^n (\\alpha_1+\\cdots + \\alpha_B)=(-1)p^{n/2}(\\theta_1+\\cdots+\\theta_B)")

#text("where ")#tao-math("\\left|\\theta_i\\right|=1", block: false)#text(". So having equidistribution here beyond ")#mi("d=\\sqrt{p}")#text(" means some additional compensation must exist in the sum over ")#mi("\\theta_i")#text(".")

#text("The worst case in Deligne’s theory would have something like")

#tao-math("\\left|S_a\\right|\\leq (Cd)^{n+1} p^{n-1/2}", block: false)

#text("(except in degenerate cases where the polynomial ")#mi("P")#text(" is constant over ")#mi("\\mathbf{F}_p")#text("), for some absolute constant ")#mi("C")#text(" (the dependency on ")#mi("d")#text(" also depends in such generality on works of Bombieri, Adolphson and Sperber.)")

#text("I will read your paper to see if I see further connections…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4d7ad465e7a4815be9bac585761f3342c6f83aabc679f7215eae882d0e0a7b2-b160a51fb585119b340da0e206c8176792be9c300467aec5c7d3f785b08aa1a6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Conference update, part I « The Accidental Mathematician")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-28864")[#strong[#text("Conference update, part I « The Accidental Mathematician")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2008")])]

#text("[…] Ben Green gave an update on the inverse Gowers conjecture. For the norm, this conjecture was proved by Green and Tao in 2005. Last year, Lovett-Meshulam-Samorodnitsky and (independently and about the same time) Green-Tao found finite fields counterexamples for norms with . However, these examples only work in finite fields of low characteristics. In a recent paper on distribution of polynomials over finite fields, Green and Tao proved that this particular type of counterexamples can’t occur if the characteristic of the fields is large enough; in particular there is still a good chance that the conjecture will be true in . (See Terry’s blog post on the subject.) […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11f8f9733188ac29658741fcb2337b3ea110f0e08346f6e4991eff99e6d7cb8a-24758efdbde1ea3bda03e742d234eafe93a69fad57c6befe2ebd69b2d0475fa3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alex")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-33300")[#strong[#text("Alex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2008")])]

#text("hi every body, i’m searching about some implementation (code source) about multivaraite polynomial over finite fields can anyone help me ?")#linebreak()#text(" plese, thx")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Approximate bases, sunflowers, and nonstandard analysis « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-42812")[#strong[#text("Approximate bases, sunflowers, and nonstandard analysis « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 December 2009")])]

#text("[…] over finite fields, which came up when studying the equidistribution of such polynomials (in this paper with Ben Green). The second comes up when is dealing not with a single finite collection of vectors, but rather […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-45029")[#strong[#text("254B, Notes 5: The inverse conjecture for the Gowers norm I. The finite field case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 May 2010")])]

#text("[…] cases (a fact first observed by Lovett, Meshulam, and Samorodnitsky, and independently by Ben Green and myself), for instance if and ; this is ultimately due to the existence in those cases of non-classical […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-49536")[#strong[#text("The inverse conjecture for the Gowers norm over finite fields in low characteristic « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2011")])]

#text("[…] the mean of is large). Applying a general equidistribution theorem of Kaufman and Lovett (based on this earlier paper of Green and myself) this implies that is a function of a bounded number of multilinear forms of lower degree. Using […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]], [#link("https://terrytao.wordpress.com/2007/11/23/the-distribution-of-polynomials-over-finite-fields-with-applications-to-the-gowers-norms/#comment-255865")[#strong[#text("Ultraproducts as a Bridge Between Discrete and Continuous Analysis | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2013")])]

#text("[…] infinitary statements, by giving an easy case of the polyomial regularity lemma, introduced by Ben Green and myself. Given a finite-dimensional vector space over a field and a natural number , we define a […]")
]
