// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/
// Converted to Typst by tao2typ: "2026-10-14T16:37:55.723417+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "How to assign partial credit on an exam of true-false questions?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("How to assign partial credit on an exam of true-false questions?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 1 June 2016")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/")[#text("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Note: the following is a record of some whimsical mathematical thoughts and computations I had after doing some grading. It is likely that the sort of problems discussed here are in fact well studied in the appropriate literature; I would appreciate knowing of any links to such.")

#text("Suppose one assigns ")#mi("{N}")#text(" true-false questions on an examination, with the answers randomised so that each question is equally likely to have “true” as the correct answer as “false”, with no correlation between different questions. Suppose that the students taking the examination must answer each question with exactly one of “true” or “false” (they are not allowed to skip any question). Then it is easy to see how to grade the exam: one can simply count how many questions each student answered correctly (i.e. each correct answer scores one point, and each incorrect answer scores zero points), and give that number ")#mi("{k}")#text(" as the final grade of the examination. More generally, one could assign some score of ")#mi("{A}")#text(" points to each correct answer and some score (possibly negative) of ")#mi("{B}")#text(" points to each incorrect answer, giving a total grade of ")#mi("{A k + B(N-k)}")#text(" points. As long as ")#mi("{A > B}")#text(", this grade is simply an affine rescaling of the simple grading scheme ")#mi("{k}")#text(" and would serve just as well for the purpose of evaluating the students, as well as encouraging each student to answer the questions as correctly as possible.")

#text("In practice, though, a student will probably not know the answer to each individual question with absolute certainty. One can adopt a probabilistic model, where for a given student ")#mi("{S}")#text(" and a given question ")#mi("{n}")#text(", the student ")#mi("{S}")#text(" may think that the answer to question ")#mi("{n}")#text(" is true with probability ")#mi("{p_{S,n}}")#text(" and false with probability ")#mi("{1-p_{S,n}}")#text(", where ")#mi("{0 \\leq p_{S,n} \\leq 1}")#text(" is some quantity that can be viewed as a measure of confidence ")#mi("{S}")#text(" has in the answer (with ")#mi("{S}")#text(" being confident that the answer is true if ")#mi("{p_{S,n}}")#text(" is close to ")#mi("{1}")#text(", and confident that the answer is false if ")#mi("{p_{S,n}}")#text(" is close to ")#mi("{0}")#text("); for simplicity let us assume that in ")#mi("{S}")#text("‘s probabilistic model, the answers to each question are independent random variables. Given this model, and assuming that the student ")#mi("{S}")#text(" wishes to maximise his or her expected grade on the exam, it is an easy matter to see that the optimal strategy for ")#mi("{S}")#text(" to take is to answer question ")#mi("{n}")#text(" true if ")#mi("{p_{S,n} > 1/2}")#text(" and false if ")#mi("{p_{S,n} < 1/2}")#text(". (If ")#mi("{p_{S,n}=1/2}")#text(", the student ")#mi("{S}")#text(" can answer arbitrarily.)")

#text("[Important note: here we are ")#emph[#text("not")]#text(" using the term “confidence” in the ")#link("https://en.wikipedia.org/wiki/Confidence_interval")[#text("technical sense used in statistics")]#text(", but rather as an informal term for “subjective probability”.]")

#text("This is fine as far as it goes, but for the purposes of evaluating how well the student actually knows the material, it provides only a limited amount of information, in particular we do not get to directly see the student’s subjective probabilities ")#mi("{p_{S,n}}")#text(" for each question. If for instance ")#mi("{S}")#text(" answered ")#mi("{7}")#text(" out of ")#mi("{10}")#text(" questions correctly, was it because he or she actually knew the right answer for seven of the questions, or was it because he or she was making educated guesses for the ten questions that turned out to be slightly better than random chance? There seems to be no way to discern this if the only input the student is allowed to provide for each question is the single binary choice of true/false.")

#text("But what if the student were able to give probabilistic answers to any given question? That is to say, instead of being forced to answer just “true” or “false” for a given question ")#mi("{n}")#text(", the student was allowed to give answers such as “")#mi("{60\\%}")#text(" confident that the answer is true” (and hence ")#mi("{40\\%}")#text(" confidence the answer is false). Such answers would give more insight as to how well the student actually knew the material; in particular, we would theoretically be able to actually see the student’s subjective probabilities ")#mi("{p_{S,n}}")#text(".")

#text("But now it becomes less clear what the right grading scheme to pick is. Suppose for instance we wish to extend the simple grading scheme in which an correct answer given in ")#mi("{100\\%}")#text(" confidence is awarded one point. How many points should one award a correct answer given in ")#mi("{60\\%}")#text(" confidence? How about an incorrect answer given in ")#mi("{60\\%}")#text(" confidence (or equivalently, a correct answer given in ")#mi("{40\\%}")#text(" confidence)?")

#text("Mathematically, one could design a grading scheme by selecting some grading function ")#mi("{f: [0,1] \\rightarrow {\\bf R}}")#text(" and then awarding a student ")#mi("{f(p)}")#text(" points whenever they indicate the correct answer with a confidence of ")#mi("{p}")#text(". For instance, if the student was ")#mi("{60\\%}")#text(" confident that the answer was “true” (and hence ")#mi("{40\\%}")#text(" confident that the answer was “false”), then this grading scheme would award the student ")#mi("{f(0.6)}")#text(" points if the correct answer actually was “true”, and ")#mi("{f(0.4)}")#text(" points if the correct answer actually was “false”. One can then ask the question of what functions ")#mi("{f}")#text(" would be “best” for this scheme?")

#text("Intuitively, one would expect that ")#mi("{f}")#text(" should be monotone increasing – one should be rewarded more for being correct with high confidence, than correct with low confidence. On the other hand, some sort of “partial credit” should still be assigned in the latter case. One obvious proposal is to just use a linear grading function ")#mi("{f(p) = p}")#text(" – thus for instance a correct answer given with ")#mi("{60\\%}")#text(" confidence might be worth ")#mi("{0.6}")#text(" points. But is this the “best” option?")

#text("To make the problem more mathematically precise, one needs an objective criterion with which to evaluate a given grading scheme. One criterion that one could use here is the avoidance of perverse incentives. If a grading scheme is designed badly, a student may end up overstating or understating his or her confidence in an answer in order to optimise the (expected) grade: the optimal level of confidence ")#mi("{q_{S,n}}")#text(" for a student ")#mi("{S}")#text(" to report on a question may differ from that student’s subjective confidence ")#mi("{p_{S,n}}")#text(". So one could ask to design a scheme so that ")#mi("{q_{S,n}}")#text(" is always equal to ")#mi("{p_{S,n}}")#text(", so that the incentive is for the student to honestly report his or her confidence level in the answer.")

#text("This turns out to give a precise constraint on the grading function ")#mi("{f}")#text(". If a student ")#mi("{S}")#text(" thinks that the answer to a question ")#mi("{n}")#text(" is true with probability ")#mi("{p_{S,n}}")#text(" and false with probability ")#mi("{1-p_{S,n}}")#text(", and enters in an answer of “true” with confidence ")#mi("{q_{S,n}}")#text(" (and thus “false” with confidence ")#mi("{1-q_{S,n}}")#text("), then student would expect a grade of")

#align(center)[#tao-fit-display[#mitex("p_{S,n} f( q_{S,n} ) + (1-p_{S,n}) f(1 - q_{S,n})")]]

#text("on average for this question. To maximise this expected grade (assuming differentiability of ")#mi("{f}")#text(", which is a reasonable hypothesis for a partial credit grading scheme), one performs the usual maneuvre of differentiating in the independent variable ")#mi("{q_{S,n}}")#text(" and setting the result to zero, thus obtaining")

#align(center)[#tao-fit-display[#mitex("p_{S,n} f^{\\prime}( q_{S,n} ) - (1-p_{S,n}) f^{\\prime}(1 - q_{S,n}) = 0.")]]

#text("In order to avoid perverse incentives, the maximum should occur at ")#mi("{q_{S,n} = p_{S,n}}")#text(", thus we should have")

#align(center)[#tao-fit-display[#mitex("p f^{\\prime}(p) - (1-p) f^{\\prime}(1-p) = 0")]]

#text("for all ")#mi("{0 \\leq p \\leq 1}")#text(". This suggests that the function ")#mi("{p \\mapsto p f^{\\prime}(p)}")#text(" should be constant. (Strictly speaking, it only gives the weaker constraint that ")#mi("{p \\mapsto p f^{\\prime}(p)}")#text(" is symmetric around ")#mi("{p=1/2}")#text("; but if one generalised the problem to allow for multiple-choice questions with more than two possible answers, with a grading scheme that depended only on the confidence assigned to the correct answer, the same analysis would in fact force ")#mi("{p f^{\\prime}(p)}")#text(" to be constant in ")#mi("{p}")#text("; we leave this computation to the interested reader.) In other words, ")#mi("{f(p)}")#text(" should be of the form ")#mi("{A \\log p + B}")#text(" for some ")#mi("{A,B}")#text("; by monotonicity we expect ")#mi("{A}")#text(" to be positive. If we make the normalisation ")#mi("{f(1/2)=0}")#text(" (so that no points are awarded for a ")#mi("{50-50}")#text(" split in confidence between true and false) and ")#mi("{f(1)=1}")#text(", one arrives at the grading scheme")

#align(center)[#tao-fit-display[#mitex("f(p) := \\log_2(2p).")]]

#text("Thus, if a student believes that an answer is “true” with confidence ")#mi("{p}")#text(" and “false” with confidence ")#mi("{1-p}")#text(", he or she will be awarded ")#mi("{\\log_2(2p)}")#text(" points when the correct answer is “true”, and ")#mi("{\\log_2(2(1-p))}")#text(" points if the correct answer is “false”. The following table gives some illustrative values for this scheme:")

#table(columns: 3, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Confidence that answer is “true”")],
table.cell(colspan: 1, rowspan: 1)[#text("Points awarded if answer is “true”")],
table.cell(colspan: 1, rowspan: 1)[#text("Points awarded if answer is “false”")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-\\infty}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.000}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-5.644}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.9855}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{2\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-4.644}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.9709}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{5\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-3.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.9260}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{10\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.8480}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{20\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-1.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.6781}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{30\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.737}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.4854}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{40\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.2630}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{50\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.000}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.000}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{60\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.2630}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{70\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.4854}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-0.737}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{80\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.6781}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-1.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{90\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.8480}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-2.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{95\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.9260}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-3.322}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{98\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.9709}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-4.644}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{99\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{0.9855}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-5.644}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{100\\%}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{1.000}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{-\\infty}")]
)

#text("Note the large penalties for being extremely confident of an answer that ultimately turns out to be incorrect; in particular, answers of ")#mi("{100\\%}")#text(" confidence should be avoided unless one really is absolutely certain as to the correctness of one’s answer.")

#text("The total grade given under such a scheme to a student ")#mi("{S}")#text(" who answers each question ")#mi("{n}")#text(" to be “true” with confidence ")#mi("{p_{S,n}}")#text(", and “false” with confidence ")#mi("{1-p_{S,n}}")#text(", is")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: \\text{ ans is true}} \\log_2(2 p_{S,n} ) + \\sum_{n: \\text{ ans is false}} \\log_2(2(1-p_{S,n})).")]]

#text("This grade can also be written as")

#align(center)[#tao-fit-display[#mitex("N + \\frac{1}{\\log 2} \\log {\\mathcal L}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("{\\mathcal L} := \\prod_{n: \\text{ ans is true}} p_{S,n} \\times \\prod_{n: \\text{ ans is false}} (1-p_{S,n})")]]

#text("is the ")#link("https://en.wikipedia.org/wiki/Likelihood_function")[#text("likelihood")]#text(" of the student ")#mi("{S}")#text("‘s subjective probability model, given the outcome of the correct answers. Thus the grade system here has another natural interpretation, as being an affine rescaling of the log-likelihood. The incentive is thus for the student to maximise the likelihood of his or her own subjective model, which ")#link("https://en.wikipedia.org/wiki/Maximum_likelihood")[#text("aligns well with standard practices in statistics")]#text(". From the perspective of ")#link("https://en.wikipedia.org/wiki/Bayesian_probability")[#text("Bayesian probability")]#text(", the grade given to a student can then be viewed as a measurement (in logarithmic scale) of how much the posterior probability that the student’s model was correct has improved over the prior probability.")

#text("One could propose using the above grading scheme to evaluate predictions to binary events, such as an upcoming election with only two viable candidates, to see in hindsight just how effective each predictor was in calling these events. One difficulty in doing so is that many predictions do not come with explicit probabilities attached to them, and attaching a default confidence level of ")#mi("{100\\%}")#text(" to any prediction made without any such qualification would result in an automatic grade of ")#mi("{-\\infty}")#text(" if even one of these predictions turned out to be incorrect. But perhaps if a predictor refuses to attach confidence level to his or her predictions, one can assign some default level ")#mi("{p}")#text(" of confidence to these predictions, and then (using some suitable set of predictions from this predictor as “training data”) find the value of ")#mi("{p}")#text(" that maximises this predictor’s grade. This level can then be used going forward as the default level of confidence to apply to any future predictions from this predictor.")

#text("The above grading scheme extends easily enough to multiple-choice questions. But one question I had trouble with was how to deal with ")#emph[#text("uncertainty")]#text(", in which the student does not know enough about a question to venture even a probability of being true or false. Here, it is natural to allow a student to leave a question blank (i.e. to answer “I don’t know”); a more advanced option would be to allow the student to enter his or her confidence level as an interval range (e.g. “I am between ")#mi("{50\\%}")#text(" and ")#mi("{70\\%}")#text(" confident that the answer is “true””). But now I do not have a good proposal for a grading scheme; once there is uncertainty in the student’s subjective model, the problem of that student maximising his or her expected grade becomes ill-posed due to the “unknown unknowns”, and so the previous criterion of avoiding perverse incentives becomes far less useful.")

#heading(level: 1)[#text("Comments (81)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a4f145af65396ec85eba4d146234a67530f843d3afb17be3a4d31002395bcd6-0c1c6ed62f1a38f8e9e17cf18f2589c5977b55b60837eae5fad70dfb734d9ed8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of adityaguharoy")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-2/#comment-595801")[#strong[#text("adityaguharoy")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2020")])]

#text("It reminds me of statistical hypothesis testing ( ")#link("https://en.wikipedia.org/wiki/Statistical_hypothesis_testing")[#text("https://en.wikipedia.org/wiki/Statistical_hypothesis_testing")]#text(" ), and its relation with confidence intervals ( ")#link("https://en.wikipedia.org/wiki/Confidence_interval")[#text("https://en.wikipedia.org/wiki/Confidence_interval")]#text(" ).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-2/#comment-693851")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 August 2026")])]

#text("Sir, why did you take the logarithm of $\\mathcal{L}$ at the end of the post?")

#emph[#text("[This is in order to relate the scoring rule developed in the blog post to the pre-existing concept of likelihood; in particular, it reveals that this scoring rule is essentially a measurement of log-likelihood. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/84c4a8d5a86a061a541111f7e74605d913d163b77dedecc3bf9dc8134822feb8-3955fdc0fc71582be4ddd28d66f275133f5638436bd1c608e2a7a620a7cb2a12.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sflicht")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469136")[#strong[#text("sflicht")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("One place to start looking for the relevant literature is ")#link("https://en.wikipedia.org/wiki/Scoring_rule#Logarithmic_scoring_rule")[#text("Wikipedia’s article on proper scoring rules")]#text(". The logarithmic rule makes a lot of sense, but you can relax it to something like a traditional quadratic loss (“Brier score” in the forecasting literature) while preserving the property that the student is incentivized to report his or her true subjective probability (assuming this is well-defined).")

#text("One nice extension is that when you give a true/false test where some questions are logically related to one another, you can assign partial credit to students who appreciate these logical interconnections. For example, a student might be able to prove quasi-rigorously that if problem 1 is True then so is problem 2, but they are only 75% confident about problem 1, and only 80% confident that their proof of 1 implies 2 is correct. While it might seem intractable to have students report a full joint distribution across the truth values for a whole test, or to grade such a distribution, ")#link("http://mason.gmu.edu/~rhanson/combobet.pdf")[#text("there has been work on implementing such schemes in practice")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469180")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Thanks for this! It’s remarkable how much one gains by knowing the right search term: “scoring rule” immediately gives many relevant hits, whereas the semantically similar “grading scheme” gives nothing. (I can’t wait for genuine semantic search to come along.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/56dbc9248da4f49f1958d08b0dba8714f2ad833efbb9c2b645221c6ba32b3e53-09efda4b3e332e3ad661afc7f8016a928c80f7ea07dfd5109c1a3a90aef7be2a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter McNamara")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469137")[#strong[#text("Peter McNamara")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("This is exactly the system used in the Monash probabilistic footy tipping competition (which doesn’t actually allow you to enter 100% or 0%)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469181")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Wow, you’re right! ")#link("http://www.csse.monash.edu.au/~footy/about.shtml")[#text("http://www.csse.monash.edu.au/~footy/about.shtml")]#text(" How very Aussie…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d9e338e0cd3c5854d68f121b5bf4dd9161377bdb81e3cdc27ffbef30ef3227b-78ebb2d5d5bd8641134d35ec8cda100165b35ec3350266a25bb780abe9cd2e13.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Mangual")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469140")[#strong[#text("John Mangual")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("I think you re-invented logistic regression. Honestly, all of these analysis are kind of repetetetetive and lame. Stick to analysis on ")#mi("\\{ 0, 1\\}^N")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469143")[#strong[#text("Philip")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("The grade almost looks like an measure of how much information the student has about their exam.")

#text("The score a student expects is an entropy formula (plus N, because of the factor of 2).")

#text("The score is exactly the amount of information one receives from their students. Is this score an average over many students, who answers in binary, and who makes random errors (in same way, with the same answering probability)?")

#text("I read in Khinchin that entropy satisfies the Cauchy functional equation, I don’t know how to further explain this scoring scheme.")

#text("On another note, are there equations which reach 0 in finite time? So that the velocity as well as position reaches 0 (position 0 has 0 force). These systems are irreversible, I think, in a novel way. 1 over a finite blow-up solution may be one of these systems. The region where such a solution can occur may not have a hamiltonian or lagrangian formulation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/227cb7e0092612e27b3eb967d96ae78814cd85f1f7f3b1f764d32bbec5f10259-38ca40244fa02c7149f8fdd0a4624ed005324901fa03fbe7e33240dac9e35152.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of maybe_slytherin")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469193")[#strong[#text("maybe_slytherin")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Yes, exactly.")

#text("This is precisely a measure of how *informed* the student is.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469844")[#strong[#text("Philip")]]#text(size: 9pt, fill: rgb("596477"), " · 16 June 2016")])]

#text("Another interesting aspect is when the questions are correlated, in a known or unknown way.")

#text("Despite a concrete score and an informational interpretation, these are rough tests of a specific set of knowledge. How it is used, and its relevance may not be clear.")

#text("As tests are compression, and models are compressions of reality (which are taught). In this sense, what do these things say about desired outcomes, on how these models will be developed or used after, or whether it guide and unfold in a way which allows progress.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/318c21e03549232532ba40248dbd7f1d212da5f84e4e003c954b80189feba4d4-038039ecb74a0d97e1ed2f8baed80547c8ee70949e03ee2a557bad902c5d3de8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philip")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-470165")[#strong[#text("Philip")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2016")])]

#text("I was incorrect, when I suggested that irreversibility would entail the non-conservation of energy. Noether’s theorem only says that energy conservation follows from reversibility. The Lagrangian does not depend on time.")

#text("This is not the same as irreversibility means that energy is not conserved, though I don’t know a system where energy is conserved but is irreversible.")

#text("Where can one find a differential geometry approach for classical mechanics?")

#text("I think there are also some topological constraints for vortex tubes, they can only end on boundaries, or upon themselves. There are real physical vortex tube knots, these are not ideal and they dissipate, although I am not sure if mathematical vortex tubes can dissipate.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/555ec034a1c782e7c81a0380d078e5823380d11099c72e6fa59b23bc2478db26-31cc9039be058478348af00c9480c9fc660910bb0caced6b949ebd389dd8e380.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Graystar")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469144")[#strong[#text("Graystar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("This is ")#link("https://en.wikipedia.org/wiki/Cross_entropy")[#text("https://en.wikipedia.org/wiki/Cross_entropy")]#text(". I’ve wondered before what makes it the “natural” loss for distributions, and your derivation explains it perfectly. Much obliged!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2ac08578e0edfc897ba8259f941762c2c4419cb63fb57bafed3975794bd8573a-78dfc549694bf79c3787425760bffa7b7a0389839d3af0e3c06010309348dcf7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of samuelfhopkins")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469149")[#strong[#text("samuelfhopkins")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("A related problem might be: you give students a true-false test and they can only answer true or false, but you want a system to award points that varies from question to question by taking into account how well all the students did on each question. For instance, you might be able to detect that someone randomly guessed for most of the test because they were as likely to get “hard” and “easy” questions right.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c7971c9b727dea8eb285e22f11f5e727cf8e7f5cabdc9cd54cfde24a877f3be9-20d475536437c7ceb5a3644c0df031c841a4c10a43adafb3cd40857773c69284.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Morgan")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469627")[#strong[#text("Morgan")]]#text(size: 9pt, fill: rgb("596477"), " · 8 June 2016")])]

#text("Look into item response theory for more on this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469150")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("The condition that p = q doesn’t seem necessary for the system to be ungamable. Another interesting question may be whether it’s possible to have an f thats bounded and yet can allow reverse engineering the students true confidence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d6f6142a037944771f6c6c5746bd4530059f85eeaf7e673ceb78a2ebb1e3ceb1-49a119a5a9b71f8710dff2b2ba52e643969f85071674620c57b03057a588e784.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Abu Bakar")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469151")[#strong[#text("Abu Bakar")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("It was an interesting read but I can’t afford to be 100% sure in my opinion. I can give this opinion, perhaps, 70% confidence of being true :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd0fe96489224e17d7fbf08c499b07568481538a8afb941759bbfc4a6a379d5d-f48134959c9b3594516f696bc2b69ec506704f7e5cb0cf7d203132e07d21a706.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sgschlesinger")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469155")[#strong[#text("sgschlesinger")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("Hey I loved this. You should totally do a version of this about the voting system in the United States, I’ve always found it funny how we only count positive votes and in an all or nothing way. It seems to imply we’ve already found the answer to whether or not it’s more important that the most people are happy than that the least people are upset, and I sure don’t know that answer.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f4ee9eb32cb4d05c84876ac136b9d4bc3c3d72ec193b73a803e9a55c8ad854d-1d0d0299c31ffffc7cd49371c46ed8bcc94088f6929e880648b7049c98d5b557.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Diego Alonso Cortez")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469157")[#strong[#text("Diego Alonso Cortez")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("In the case of total uncertainty for the student, shouldn’t the student assume the least informative prior (which, for this case, seems to me like the uniform distribution, ie. 50% confidence in true and 50% confidence in false)? This yields a 0 grade for such cases, while removing the need for a messy “I don’t know” option.")

#text("Also, since the log function is reasonably-behaved in neighborhoods of 0.01 but not in right-neighborhoods of 0, couldn’t we extrapolate from 0.01 to 0 using some other function, so that we don’t get that nasty $-\\infty$ at 0? Maybe map 0 to -6, or -10, or something like that.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("It’s true that one can use the least informative prior here as a proxy for an “I don’t know” option. But the situation becomes more complicated if one drops the hypothesis that each question has a prior probability of 50% of having “true” or “false” as the correct answer. For instance, suppose one is grading predictions of various future elections in which the conventional wisdom favours one candidate over another. Should an “I don’t know” answer then be judged using a default prior distribution, rather than the naive 50-50 split?")

#text("One could smooth out the grading function at the endpoint p=0, but a simpler fix would be to either strongly discourage, or even prohibit, the student from actually entering in a 100% confidence level. Of course this requires some “retraining”, since students taking traditional multiple choice exams are accustomed to at least appear to have 100% confidence in one’s answers…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/83647612e019f61cac83c24d1e0d3e18fb207594afa1928e697dfe94e9ea824d-b491f8a111d70f3918d00a47a5fc64833e9dca6b5ffc9e65e5348d6fed1e6fb1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nathaniel Virgo")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469426")[#strong[#text("Nathaniel Virgo")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("In the example here, wouldn’t you want to also test the student’s knowledge of the “conventional wisdom”? Then there is no need to use a different prior for the scoring system. If the student really doesn’t know at all they can still put 50% as their answer. (In which case, seen from the point of view of someone who adopts the conventional wisdom, their expected score is less than one.) Or, if they know that the conventional wisdom says candidate ‘A’ will win with 80% probability but they have no extra knowledge, they can just put 80%. Either way they gain the most by correctly assessing the extent to which they don’t know, and quantifying it correctly.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6a4e5568b0225ffe12de7de5faac2d4462686a99df5a4dfbfd04a038e602514b-589b2de89c21c52434b34332d0b401d73c053d857125ecff387a4251dc74b4c1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Subbak")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469785")[#strong[#text("Subbak")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2016")])]

#text("If you assume the students can only answer with multiples of 0.05 (seems like a reasonable assumption), can’t you design a grading scheme that respects the property of not creating perverse incentives without going to infinity? It seems to me that you should be able to but I haven’t done the math.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469159")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("Isn’t the special case N=1 sufficiently interesting? (I have difficulty understanding the text I’m afraid).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469160")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("If we have one question and N experts where the ith has probability p_i for giving the right answer then the log weights are well known to maximize the probability of making the right decision. Of course, if we need to estimates the probabilities p_i s themselves this complicates matters. (But there are some ways that people tried to deal with it; those may apply over many exams as ways to calibrate a student’s levels of certainty.)")

#text("It is not clear that we want the rule to be symmetric: namely loss for making a mistake and being very certain about it need not be the same as the gain for being right and very certain about it.")

#text("And it looks to me that in practice the traditional binary way of grading the answers is better than the proposed idea of adding certainty level and using weighted grading (unless it is an intentional purpose to grade the students ability to assign certainty levels.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469163")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Exactly: this scheme tests the students’ knowledge of themselves, not only of the material: the proof that the given function is optimal assumes students can accurately quantify their confidence in their understanding. I think the true optimal strategy depends not only on the values ")#mi("q_{S,n}")#text(" but on the students’ confidence in these values.")

#text("However, understanding your own understanding (and lack thereof) is a laudable course goal. So include it in the syllabus, and make computing the optimal strategy under various hypotheses a homework problem.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469183")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("The rule is in fact very asymmetric: ")#mi("f(1-p)")#text(" is very different from ")#mi("-f(p)")#text(" for most values of ")#mi("p")#text(".")

#text("One advantage of this sort of grading scheme is that it gives more useful information to the instructor as to how well the students are grasping the material, as well as which questions are causing more difficulty than others. It also strongly discourages random guessing (putting down “100% true” or “100% false” randomly is a FAR worse strategy than putting down “50% true, 50% false) which could reduce the amount of random noise in the final grade.")

#text("Regarding Lior’s comment: I came across a class where this scheme is actually used in a real midterm exam: ")#link("http://www.contrib.andrew.cmu.edu/~sbaugh/midterm_grading_function.pdf")[#text("http://www.contrib.andrew.cmu.edu/~sbaugh/midterm_grading_function.pdf")]#text(" . (They use the normalisation ")#mi("f(p) = \\log_4(4p)")#text(" rather than ")#mi("f(p) = \\log_2(2p)")#text(" because the exam is multiple choice with four options per question rather than two.) The class is in Decision Analysis, and analysing the grading scheme is in fact intentionally part of the coursework!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469196")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("One thing that can be done is to normalize a person level of confidence according to actual performance. For that we can assume that the questions are equally hard (otherwise we can estimate and weight their relative difficulty as well). Using it we can give the students separate score for academic performance and for self-evaluation. Two students with the same answers and each having constant but different confidence level will get the same academic score but different score for self assessment. (If the confidence levels are not constant the academic performance will depend on them, not only the answers.) Such a normalization will eliminate the annoying negative infinity scores.")

#text("(Yes, I miss the asymmetry. we can wonder if this is the asymmetry reflecting optimally our pedagogical goals.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chong Shang Shan")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469161")[#strong[#text("Chong Shang Shan")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2016")])]

#text("Let me summarize, tell me if I am wrong: What you are saying is that these methods of putting probability into a binomial model is all about certainty. One can be certain that Question 1 is 90% correct and 10% wrong. These models do not express uncertainty, even though it is still about probabilities, and Bayesian ones at that.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Consider the situation in which the student gives Qbits (i.e. true random bits) as answers (according to his/her subjective probabilities), what should be the grading rule for such (random) answers?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/608301e60fab2bd58541c2042c695aa15bcb825d453f8e352e9d464c6bac6e01-4f6462f98a0299791f129538419f9212dd94b4db819cac7db1aa97882002fcbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ken(neth)")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469165")[#strong[#text("Ken(neth)")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("I always have my students give a reason for their answer to a true or false question.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469167")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("One assumption which is important to your model and which may not be exactly true in practice is that students aim to maximize their expected grade. Many students might, for example aim to maximize their probability of scoring at least 90%, or their probability of not failing, and this difference in utility function may lead them to report their subjective probabilities unfaithfully. I wonder whether there is some way of aligning students’ utilities, but I’m doubtful.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469184")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("This was something I meant to put in the post but neglected to: when the number of questions ")#mi("N")#text(" is large, then the law of large numbers kicks in, and the grade should concentrate around the expected grade (this is why I didn’t focus just on the ")#mi("N=1")#text(" case, as suggested elsewhere in the comments). So the assumption should be fairly sound when dealing with lengthy exams, but I agree that for ")#mi("N=1")#text(" or ")#mi("N=2")#text(", other factors such as risk aversion may become important and distort the incentives.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sean Eberhard")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469204")[#strong[#text("Sean Eberhard")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Good point, but even when the number of questions is large, the difference in utility is likely to have some effect near the boundary. Specifically, the downside blowup will cause very certain students to underrepresent their certainty.")

#text("Suppose you set an exam with 100 questions, and because it’s so easy you decide that it takes 90 points to get an A. I, being a good student, am 99.9% sure of all my answers, but my scholarship depends on my getting an A. If I report my confidence everywhere as 99.9% then if I get a single answer wrong I will get a B and be deported. However if I artificially downgrade my confidence to 99% then I can afford to get one answer wrong and stay in the country.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff913fce26147313987800f9335adb5eddd44ec4fb127ee0f1500f8299b9cb8b-6f37f9465031760dfdfd3f5e7eb567f08dd6463da289658ceb8000d3511fec82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ethan")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469169")[#strong[#text("Ethan")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#link("http://users-cs.au.dk/mis/multiple.pdf")[#text("http://users-cs.au.dk/mis/multiple.pdf")]#text(" is different but maybe of interest. It looks at scoring multiple choice questions where multiple selections are allowed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40cb6dc44d34cf5764438c468e88ee6b050cde38be089623dfa133a776c60284-171e99929fc6d51e5a912d39e8d25845691cc3b455ea87ba1f276cf6dd86ca29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Waggoner")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469174")[#strong[#text("Bo Waggoner")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Hi Terry, you have rediscovered the logarithmic “proper scoring rule”. Proper scoring rules were first studied by [Brier 1950], followed by a general characterization of [McCarthy 1956, Savage 1971, Gneiting-Raftery 2007].")

#text("The characterization states that each “proper” (truthful) scoring rule corresponds to a convex function G(p), the expected score for truthfully reporting p when one’s true believed distribution is p. The scoring rule is given by subgradients of the convex function. For the log scoring rule, this convex function is the negative of Shannon entropy. In fact, axioms about scoring rules, such as symmetry, can be as interpreted as axioms on entropy functions.")

#text("Notes:")#linebreak()#text(" — this characterization works just as well for “multiple-choice” predictions.")#linebreak()#text(" — as you note with the election example, proper scoring rules form the basis of modern prediction markets [Hanson 2003].")#linebreak()#text(" — convexity seems to have a natural implication for your grading application: any proper scoring rule rewards “expertise”.")#linebreak()#text(" — I will address your last paragraph in a second post.")

#text("Brier, 1950. Verification of forecasts expressed in terms of probability. Monthly Weather Review.")

#text("McCarthy, 1956. Measures of the value of information. PNAS.")

#text("Savage, 1971. Elicitation of personal probabilities and expectations. Journal of the American Statistical Association.")

#text("Gneiting and Raftery, 2007. Strictly proper scoring rules, prediction, and estimation. Journal of the American Statistical Association.")

#text("Hanson, 2003. Combinatorial information market design. Information Systems Frontiers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40cb6dc44d34cf5764438c468e88ee6b050cde38be089623dfa133a776c60284-171e99929fc6d51e5a912d39e8d25845691cc3b455ea87ba1f276cf6dd86ca29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Waggoner")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469175")[#strong[#text("Bo Waggoner")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("To your last paragraph on uncertainty, I don’t know of research directly addressing this, but Yiling Chen, Madhu Sudan, and I recently looked at one formalization. Suppose a student facing a proper scoring rule has “uncertainty over her belief”, e.g. she thinks p lies in [0.5, 0.7]. If she were a Bayesian expected-utility-maximizer, then she should just integrate out the uncertainty and report her “expected” p, to maximize expected score.")

#text("So instead suppose the agent is risk-averse, so she has a set of possible beliefs and wants to maximize the worst-case expected score over all these beliefs. So she will report max_p min_{q in [0.5, 0.7]} “expected score for reporting p with belief q”.")

#text("In this case, if the set of possible beliefs is convex, then it turns out she should report the “maximum-entropy” distribution in her set of beliefs. Here max-entropy is measured by the convex function corresponding to the proper scoring rule according to the characterization I mentioned above. So for the log scoring rule, this really is the max-entropy distribution in the set. And actually, once you have a visual picture of the characterization, this result has a really nice geometric intuition. (Also, this doesn’t require a binary outcome but works just as well for multiple-choice questions.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469185")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Thanks, this is great! I’m happy to see that it is still possible to do some mathematical analysis in the presence of uncertainty, and the resulting answer (max-entropy reporting) is not as complicated as I had feared.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/40cb6dc44d34cf5764438c468e88ee6b050cde38be089623dfa133a776c60284-171e99929fc6d51e5a912d39e8d25845691cc3b455ea87ba1f276cf6dd86ca29.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Waggoner")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469213")[#strong[#text("Bo Waggoner")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Another comment: your analysis assumed that the score only depends on the predicted probability of the true answer. That’s why you derive the log scoring rule: it’s the unique proper scoring rule with this property. For all other scoring rules, the score depends on the predictions on all the options, not just on the correct outcome.")

#text("The cool part: I believe this is essentially the same fact as Shannon’s “chain rule” axiom leading to the uniqueness of Shannon entropy among all entropy measures.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469176")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("The Japanese Language Proficiency Test is a multiple choice test with an interesting method: it assigns a grade to the *sequence* of answers, rather than adding up the results for each answer. You can find more info here ")#link("http://www.jlpt.jp/e/about/pdf/scaledscore_e.pdf")[#text("http://www.jlpt.jp/e/about/pdf/scaledscore_e.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ef274d11880037ea629ae972bcf0876424d7bd85aa3fad3774cfe54b805430e5-b51040075ba8e8cc84fa990daad1df3a25b900317227e5b137367ad42509c471.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter Chindove")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469186")[#strong[#text("Peter Chindove")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Would you not need to also change the types of questions asked? Questions that demand binary answers are themselves restricted in what insight they can provide about the person providing the answers")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a616af039734b976bf4f0deae03acd9ee4f77a68c4f4e7e0c9c8864bb81f600e-4a4f46c28ed4a4cfd405b8a65a4b84a2304ee71d51ea228cc5f25ad827ed55b4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sanchay")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469187")[#strong[#text("Sanchay")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("This is good. Just concerned about using this “scoring rule” aka “grading scheme” (Google take notice) in the real world: assume 100% is not allowed")#linebreak()#text(" 1. Lets say the exam is for a technical subject which requires some calculations. If a student knows their subject well, but make a minor calculation mistake, they might mark an incorrect answer with high confidence and thus may receive large penalty (depending on the actual answer choices). Seems unfair.")#linebreak()#text(" 2. Also concerned about the actual brain cycles the student will spend on giving out their confidence levels instead of answering the questions in the first place. I give that this might not be bad since it better prepares one for the real world (my subjective opinion), but it sure will be more stressful for the students, esp. considering 1.")#linebreak()#text(" I think we should strive to abolish multiple choice type objective exams in favor of subjective exams. Takes more resources and creates some avenues of unfair grading given multiple graders, but I think it’s overall better. Thanks for the thought provoking article.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b94c26ac7948f48729c2eb235567ba7de54994a3585441aa5bf727a960291519-fb7bcad9c216adfd7c1e90041c6c100cb86fecd19e2fd7721469b972c2a32738.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of thelonewolfling")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469188")[#strong[#text("thelonewolfling")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("With this grading system, your EV is maximized when your guess has the same percentage certainty as your actual certainty, yes. But your standard deviation goes up much faster than your EV as a function of certainty of guess – which means that as you increase your guessed certainty towards your actual certainty, your percentage chance of doing relatively poorly actually goes *up*.")

#text("This assumes that students are straight EV maximizers, and that EV is linear with grades.")

#text("In practice this is not true.")

#text("Quick numbers (may be wrong):")

#text("If your actual certainty is 0.9, the possible outcomes of answering a question is [log2(2p) @ 0.9, log2(2(1-p)) @ 0.1]. Your mean is g(p) = log2(2p) * 0.9 + log2(2(1-p)) * 0.1, which peaks at p=0.9, g(p) = (9 log2(3)-5 log2(5))/5 , as expected. Your variance is then 0.9 * (log2(2p) – (log2(2p) * 0.9 + log2(2(1-p)) * 0.1))^2 + 0.1 * (log2(2(1-p)) – (log2(2p) * 0.9 + log2(2(1-p)) * 0.1))^2, and the standard deviation is just the square root of that.")

#text("Which does this: ")#link("https://www.wolframalpha.com/input/?i=plot+sqrt%280.9+*+%28log2%282p%29+-++%28log2%282p%29+*+0.9+%2B+log2%282%281-p%29%29+*+0.1%29%29")[#text("https://www.wolframalpha.com/input/?i=plot+sqrt%280.9+*+%28log2%282p%29+-++%28log2%282p%29+*+0.9+%2B+log2%282%281-p%29%29+*+0.1%29%29")]#text("^2+%2B+0.1+*+%28log2%282%281-p%29%29+-++%28log2%282p%29+*+0.9+%2B+log2%282%281-p%29%29+*+0.1%29%29^2%29,+%28log2%282p%29+*+0.9+%2B+log2%282%281-p%29%29+*+0.1%29+over+0.5+%3C%3D+p+%3C%3D+1")

#text("Note how the standard deviation increases (substantially!) faster than the mean. For instance: if you guess with certainty 0.8 (knowing that your actual certainty is 0.9), you’ll get a mean value of 0.478 and a standard deviation of 0.6. If you go ahead and use your actual certainty of 0.9, you’ll get a higher mean value of 0.531, but your standard deviation increases to 0.95. For comparison, that means your 25th percentile *drops* from 0.0733 to -1.10.")

#text("I’m glossing over a whole bunch of things here, but you get the picture.")

#text("What this means in practice is that anyone who crunches the numbers and who is adverse to failing is going to guess conservatively, probably extremely so given as no-one is absolutely certain how certain they are.")

#text("It would be curious to run through the numbers and come up with an equivalent scheme for students who maximize the probability of passing (for some definition of passing, or for some distribution of target marks).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469189")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("As I said in an earlier comment, this is a serious issue for small values of ")#mi("N")#text(", but becomes asymptotically negligible in the limit ")#mi("N \\to \\infty")#text(", because the expected value of the grade scales linearly with the number of questions ")#mi("N")#text(", whereas the standard deviation scales like ")#mi("\\sqrt{N}")#text(" (assuming that the probabilities for each question are uncorrelated or only very weakly correlated). So I would only propose this scheme when the number ")#mi("N")#text(" of questions is somewhat large (e.g. greater than 10).")

#text("Incidentally, my own personal views on the suitability of multiple choice exams in general can be found in ")#link("https://terrytao.wordpress.com/2008/12/14/on-multiple-choice-questions-in-mathematics/")[#text("this previous post")]#text("; roughly speaking, I don’t like using them for exams, but they can be a useful tool for self-assessment. However, I think these sorts of scoring systems could be more widely used beyond the classroom environment. Imagine for instance if political pundits were somehow required to attach confidence levels to their various predictions (e.g. “Candidate X will win the election (90% confidence)”), and that there was a neutral authority who could keep track of the cumulative score of the most prominent such pundits, seeing in particular which of them were excessively overconfident in their proclamations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a70bb7060e971a779144b627f5b33a4ec8983c8fbf836fef6454d7801e549d11-b79b37b1b3204e6eb074164bcbbe75d92edde7c41f35d2480abf8f40b37971e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469195")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("One place where this scoring mechanism is sometimes used is on Kaggle, a website that hosts data science competitions. For three years now, this scoring method has been used to score predictions for March Madness (the US college basketball tournament): ")#link("https://www.kaggle.com/c/march-machine-learning-mania-2016/details/evaluation")[#text("https://www.kaggle.com/c/march-machine-learning-mania-2016/details/evaluation")]

#text("Simplifying slightly, in March Madness, 64 teams play in a single-elimination tournament. A submission to this Kaggle contest consists of a prediction of the probability p that team A beats team B, if they play, for every pair of teams {A,B}. The scoring method is exactly the one you proposed, applied only to the 63 games that actually occur.")

#text("The issue mentioned more than once above — that people’s objective is not usually “maximize expected score” — comes up very strongly here. This Kaggle contest has a monetary prize that is only awarded to the top few finishers (5 teams this year, and even fewer before). Thus, if you are trying to win money, you only care if you score very highly (top 5) and not at all if you score “pretty well”: even 6th place is functionally much the same as last place.")

#text("Despite the fact that N=63 is more than “somewhat large” (ie it is much more than 10), this issue distorts the incentives very greatly. In particular, I estimated this year that if all you care about is winning money, then it is a pretty good strategy to assign a 100% probability to a single event that you actually believe has a ~10% probability. Otherwise, you can submit your “true” predictions (of course, they have to be somewhat decent predictions themselves). If your lucky event does not happen (a 90% probability), then you get negative infinity points and last place; if your lucky event does happen (10%), then you get a “boost” that is likely to propel you into the money.")

#text("Together with a teammate, I have followed this strategy for three years now. Many other teams do the same. If you look at my profile on Kaggle (linked to by my name), you can see that we have in fact done quite poorly in past years, when our lucky event did not happen; the only reason we are not literally last is essentially rounding issues. This year, however, our lucky event happened and we won money.")

#text("In talking with our colleagues, we have found that there are many interesting results in this area concerning the difference in strategies between “maximize expected score” and “maximize the probability of getting first”. We are in the process of preparing a paper on these phenomena. It is unclear at this point whether this paper will end up targeting a “math blog” audience or a more formal “math journal” audience (or both..).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/11f410d2385e1e40affa3713778fc8658732df03c09c9aeddbdb4f37ee99d711-17bb680652e8e4d8d511c8cd23ee731021ea6b53a6688483dcdf5ac638f8b802.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arul")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469190")[#strong[#text("Arul")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Hi Terence,")#linebreak()#text(" When there are a large number of students, can we assume that distribution of student confidences is same as the probability of true/false seen across students? In that case, we can use that as a metric of how “difficult” the question is (this is a different approach from what you described but occurred when I thought about the problem). One solution could be to assign unequal marks to different questions based on distribution of answers, e.g H(p) where H is the entropy function. If a student answers a “difficult” question right, he/she gets more marks vs a question that most others answered correctly. Thinking more about it, D(p||q) is probably a better metric because if most students answer incorrectly, we want to reward the person who answers that correctly :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469192")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Making the grading scheme dependent on the responses of the other students turns the system into a ")#link("https://en.wikipedia.org/wiki/Mean_field_game_theory")[#text("mean field game")]#text(", which can create all sorts of unpredictable emergent phenomena as each student tries to predict the behaviour of the others. For instance, if one question is exceptionally easy, many of the students may presume that the value of that question is going to be low, and focus their attention on the harder questions, allowing the weaker students who are only capable of tackling the easy question to end up with a higher than expected score; meanwhile, the value of the difficult questions are not as high as the stronger students may have hoped due to the fact that a large fraction of the class did better on these questions than expected due to the increased focus by the top students on these questions.")

#text("But one can certainly multiply the score for each question ")#mi("n")#text(" by a different weight ")#mi("w_n")#text(" which is dependent on some other factor than the performance of the rest of the class, e.g. by the instructor’s subjective opinion of the difficulty of the question, or using test records of previous classes that were given either the same question, or something similar to it. This should not create any unusually distorting effects (assuming of course that the values of the weights ")#mi("w_n")#text(" are publicly available to all students).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c4941ab895fbf71b4548c84156eada239ad1a9534cf5a00cc72356fb7a47fc5-46b35f6acd1b06ccb0630b80f6979500afd4185e8b7af13ada5af0f6a28ee050.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nishad")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469197")[#strong[#text("Nishad")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Hi All,")#linebreak()#text(" I was trying to work out how to solve the problem when you have multiple solutions and multiple correct answers (the puzzle put forth in the article) but was unable to figure out how the student assigns confidence values to the questions since two or more are correct. How do I calculate the corresponding expectation value? Any help is appreciated.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469198")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("I should clarify that I was referring to the situation where there are multiple answer options, but still only one of the answers is correct, which is the usual situation in multiple choice tests. For instance, there may be three possible answers A, B, C, and the student would assign confidences of ")#mi("q_A,q_B,q_C")#text(" to each of them respectively for some quantities ")#mi("q_A, q_B, q_C")#text(" adding up to one; the score for the question would then be ")#mi("f(q_A)")#text(" if ")#mi("A")#text(" was the correct answer, and so forth. One can then show that in order to avoid perverse incentives (or, to use the accepted terminology, obtain a proper scoring rule), ")#mi("f(q)")#text(" needs to be equal to ")#mi("\\log q")#text(" up to an affine transformation.")

#text("Perhaps it is still possible to construct a natural grading scheme in situations in which there are multiple correct answers, but this looks to be a rather tricky task.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6f6dd99a5b04d4a9fd59c097ec428f9b4e28351e8a70021eda50659472a40029-be15e6e271a6e95cb6b79428d340fd4216b18ecd5bf01d9c37e1a4902a9ff429.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anurag Sahay")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469637")[#strong[#text("Anurag Sahay")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2016")])]

#text("Couldn’t a situation whereby we have multiple options (say k per question) and multiple correct answers (bounded by say m <= k, so that the case m=1 is just the regular single correct answer case) be reinterpreted as a multiple options but single correct answer case with more options? In particular, we could take the number of options to be the sum of all C(k,i) with 1<= i <= m, where C(k,i) is the choose function.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9eea9c9c6df098ad10152cecf77b1d4fc92db95b3f6eec274e4ad4688638c24c-946d1b6e675d0dc49947a7f7491cbac98702b7fa1ec7918b71009ff0e9f2acc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Arthur Breitman")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469199")[#strong[#text("Arthur Breitman")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("If you’re feeling generous, you can optimally re-calibrate the student’s answer. That is find an increasing function ")#mi("g: [0,1] \\rightarrow [0,1]")#text(" which maximizes their score when the probabilities they pick are appropriately transformed.")

#text("If one only imposes that g be monotonous, then this is a form of isotonic regression, but that might be a little too generous for the student. One might instead choose ")#mi("g")#text(" from a parametric family, for instance an affine transform of the log odds.")

#mi("g(p) = \\sigma( a \\log(p/(1-p)) + b)")#linebreak()#text(" with ")#mi("\\sigma")#text(" being the logistic function. Optimize over ")#mi("a")#text(" and ")#mi("b")#text(". That way you do not over-penalize student for being biased.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/51eee64cf6cdb9bdd432f059bad9de05624a950e6c06eb4053fb6317754fa230-4657a12dea32bddbd152f45b929e95a4b6d90272f5780eedf3cc6240aeeb165f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of groglogic")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469200")[#strong[#text("groglogic")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("typo: “the student may {S} think”")

#text("I didn’t check your math too but will assume that is all correct. :-)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/434a458fc3808bb16ad93e76357302a0eee8a413e2e3b93ba31d2ab8e9dc3423-e5e7b5115442e4bfd3c908adba583046765bd272a140b8a20b9a7701b7c59253.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bryan A. Knowles")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469202")[#strong[#text("Bryan A. Knowles")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Have you considered limiting their confidence options?")

#text("E.g., a four or five point scale like: false/very confident; false/less confident; I don’t know;etc.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3033bfa8855b64521474bcf3ed5f6ee0ea8dd15aa5022aa6d9619caba0650ca0-8209bc03762b6e4ea7fdbc9e12086f85e9e27da4faa1078396d1e34ae7e2a236.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Miller")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469203")[#strong[#text("Matt Miller")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("I feel that this thread, being more accessible a read than your other posts, will attract many comments — that said here’s mine:")

#text("Do you think you could adapt this to use in a Tournament matrix way (where the Perron eigenvalue and associated eigenvector are used to determine tournament rankings), so that the ‘grade score’ is related to the rankings (either Kendall-Wei or Ramanujacharyula ranking) and those values are themselves determined not just by the answers of any individual but also to the answers of every other individual taking the test? I’m not sure how you could incorporate such a method into grading, or why you would want to other than to bring more interesting methods to bare on this problem (as has been done with the same sort of problems in ‘voting’ shemes). Anyway, fun post thanks! :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52199fa021c337c1315ca742cb5f11ddbb063546fdfab7b8e3ffdfe5bf11cf1b-7c732e386466770316e978619f8228a1388b783fbcf060fc75f647127b3efab3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Freddie Manners")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469205")[#strong[#text("Freddie Manners")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("My preferred solution to the grading problem is to get students to submit neither answers nor probabilities, but a customized compression / decompression algorithm pair.")

#text("The compression algorithm is then run with the correct answers to the test as input (as a 0/1 string). Not being a trusting person, I run the compressed output back into the decompression algorithm and check that it faithfully reproduces the test answers.")

#text("I then give the student a score of the size in bits of the compressed data (lower values being better).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469206")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Very nice! Of course this would be impractical for a real-world examination, but this criterion has the advantage of generalising very easily to many types of exams, and can incorporate features such as prior probability distributions of answers, correlations between questions, uncertainty in the student’s subjective model, etc..")

#text("From the theory of ")#link("https://en.wikipedia.org/wiki/Kullback%E2%80%93Leibler_divergence")[#text("Kullback-Leibler divergence")]#text(" it seems that this compression-based scheme essentially collapses to the logarithmic scoring rule when restricting to compression algorithms based on probabilistic models in the answers to each question are assumed to be jointly independent events. So this may well be the “correct” way to generalise the logarithmic scoring rule to more general contexts.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469210")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Neat! The machine precision of the instructor’s computer should be made public in case the game (oops, exam) only rewards a single winner.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0a90f7e421c77ae7b118079b951b6df0c33bca8f37bb01771acd1f43078a2da9-d425bc6075c5e3e586df04ae8c14c82e075feb5c3117c5e4875d2af557dfa7e5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469440")[#strong[#text("N")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("Given that the exam itself can be viewed as a compression algorithm, it seems somewhat inelegant to require a compression algorithm to work on another. Moreover, if the larger goal is to discriminate between students, it is not clear that the ideal grading solution can counter a poorly designed exam.")

#text("Instead, how about asking each student in the class to submit an algorithm that generates both the questions and the answers? Each of the exams provided by the students is administered to every individual in the class (in real life, students would be really unhappy…), and the exam that results in the most dispersion across students is used to assign the grades as above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c452aeb7466293c4d827463d0019c9e7e83db8113210de3cd436ad5a6093b6c-55babe53ec9286a3e73d2949aab1cc1cf2290a7ce6922e82b05f568081353233.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashok M Dhareshwaar")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-580410")[#strong[#text("Ashok M Dhareshwaar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2020")])]

#text("Looks intriguing and interesting, but I can’t work kit out. Would it be possible to give a gentle outline of the idea, with an example of, say, N=2?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dd4119b23b13c8944b31b898bab950c090191d4946c2ab672f4e61c0b3a12108-43d78e2599b504a9977f42bb573192ef0000a488c38a65b420e6731db0d103ce.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bigdudemakingbigmoves")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469215")[#strong[#text("bigdudemakingbigmoves")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("And here I was thinking that this article would be a joke. Not to be disrespectful. I mean joke in a satirical or whimsical manner. This actually is an interesting concept and pretty well written as well. Kudos.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469220")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("Students should not try to maximize their numerical grade, instead they should maximize their discrete letter grade (“A” or “B”) since letter grade determines GPA. Given this, the partial credit system becomes very misleading to students.")

#text("Students should not estimate confidence based on their true confidence, rather they should estimate confidence based on the minimum score needed to pass. This grants the student the most allowable wrong answers while still passing the class. This result does not rely on a quiz with a small number of questions.")

#text("For example, given a test with a large number of questions, a student who knows exactly that she has an 80% chance of answering any question correctly, and who needs a minimum score of 0.1 to pass the class, the student’s optimal decision is to pick a confidence level of 0.69 for each question. This would allow her to pass the class by answering 69% of the questions correctly. If she had picked the 80% confidence level she would have to answer 71% of the questions correctly to pass.")

#text("C = confidence")#linebreak()#text(" N_c = % correct")

#text("score = N_c*log2(2*C) + (1-N_c)*log2(2*(1-C))")

#text("The student’s approach could be to first determine the minimum score needed, then find the minimum value of N_c = C that produces that score, and use that confidence value. The equation could be expanded to allow questions of different confidence, but I wouldn’t bother. This example is just meant to show how a discrete grade scale subverts the intent of the logarithmic function to rewards students for accurately identifying their confidence.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2c29bcfc6c3969d37bd58c4f408965735860f1d0e11eb277a6c3bdc3d05c4a51-4a767a5858ee954fc4e20df6e7c0b5ff752baff3c334b20d5e49264d0d5b382f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469223")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2016")])]

#text("In game theory in economics there is a term called “strategyproofness” (")#link("https://en.wikipedia.org/wiki/Strategyproofness")[#text("https://en.wikipedia.org/wiki/Strategyproofness")]#text(") in which it is a best strategy for each player to be honest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0113d397181051dc71a0a4549572f4dd5f0482cc855f32ee15cf2c10bfae9a7-863d8b1c5b24baaf5e0074bff46eb856c0b64cde9c9a0a7f4985e721838dbfd5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Barren")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469232")[#strong[#text("James Barren")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2016")])]

#text("An interesting somewhat related work (see the partial knowledge section) is given here: ")#link("https://www.iacr.org/archive/pkc2008/49390088/49390088.pdf")[#text("https://www.iacr.org/archive/pkc2008/49390088/49390088.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469236")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2016")])]

#text("I think I’ve read that there is a human cognitive bias causing explicit probability estimates to tend to skew away from 0.5. Presumably such a persistent bias is maximizing something. It might be good to bear that something in mind when designing a scoring system of the kind discussed here.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a898df04ba68d2ef401b1372378d55674ae661d41b0223eec7d32bd296cb75c1-3dcef0464b925df8c05e5260c33989507c46b36894cb6a48850caf113ee4d778.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of asfarley")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469241")[#strong[#text("asfarley")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2016")])]

#text("How about using internally-consistent subsets of the answers? This would require dropping the independence assumption for each answer, though.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1aaca3734c789a8400092c7cca3f595dde674a3ac0b8cebff43a28279b029ec3-be87ce70e30d1073283265cf9c4e5c9e4724fc26344fc19de9100eac642e4d24.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1@gmail.com")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469243")[#strong[#text("arch1@gmail.com")]]#text(size: 9pt, fill: rgb("596477"), " · 3 June 2016")])]

#text("The comment about semantic vs syntactic search in the context of this posting reminded me of an article years ago in American Mathematical Monthly about partial credit scoring of multiple choice problems based on the kind of error associated with each choice:-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1cd1a8973230d426ec3ab3dcdaee82c8bebac86b13f347181024ee3e59490b7e-717f5d87c986865d056d26331680d8d4d2b4ba2d6c0cc51fc86aea738c273f14.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Saturday assorted links - Marginal REVOLUTION")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469258")[#strong[#text("Saturday assorted links - Marginal REVOLUTION")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("[…] 5. Goethe and the second price auction. And probabilistic grading for true-false exams. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ab3bf87acb9061287c20edc9d51c00b5cb5c0c75b0ee8c41710cfe7167a2406-26abcc268af3d89d3542bc89c6f72a86b458e169f397b3859f82a2c235059979.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matthew Moore")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469259")[#strong[#text("Matthew Moore")]]#text(size: 9pt, fill: rgb("596477"), " · 4 June 2016")])]

#text("You might want to look up the Revelation Principle in microeconomics/ game theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c2337dfa1d9cf1159de7cb9ca83a0b24ffda07a7195338b97b77c4d9105cfce7-e658b043fe1747e3ce3073cab290b84258078e606acc13a58ac0c0c30b6790f9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Evan")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469526")[#strong[#text("Evan")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2016")])]

#text("This paper (")#link("http://people.few.eur.nl/wakker/pdfspubld/09.2propscr.pdf")[#text("http://people.few.eur.nl/wakker/pdfspubld/09.2propscr.pdf")]#text(") published in the Review of Economic Studies in 2009 discusses applications of proper scoring rules when agents are not expected value maximizers. It also covers non-expected utility agents, providing a partial resolution for the case of non-probabilistic uncertainty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6177de1b157421feabe311888b515f06cc12782b0989502ef21804e4a8cf2a09-331e79ac95d6791d17471deb1dc0d5bc41868ef2b6f58b3c4efb84d0ca44e790.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew Howe")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469720")[#strong[#text("Andrew Howe")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2016")])]

#text("Having skimmed the comments I *think* this is a slightly different angle.")

#text("Instead of target the ‘ordinary’ score, an area known as probability calibration emphasizes the accuracy of the student’s probability assessment, almost independent of whether he is right/wrong about the underlying answer.")

#text("Thus, someone who scores 6/10 and says that he was 60% confident of each answer gets a ‘perfect’ probability calibration score while someone who scores 8/10 but says that he was 90% confident of each answer gets a lower probability calibration score (and a higher ‘ordinary score’).")

#text("This is an under-exploited area of risk management where, as at least one commenter mentioned, overconfidence is a challenge.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8465c018803d0d6d1f28ad9070d0a6f2757dbee4ae35ee4feffe7ecaf14e809d-d7d844221ae09f445ef0cca78728051c6329e13c41960bcf71b9048a46865980.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sebastian")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469737")[#strong[#text("Sebastian")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2016")])]

#text("Regarding scoring rules both for finite sets and more general spaces the (Gneiting and Raftery, JASA 2007) paper is really a gem that covers a lot of ground.")

#text("Any proper scoring rule can also be converted into a proper divergence between probability measures by taking their expectations over the true outcome. Such construction gives rise to divergences such as the “energy statistic” discussed in detail in the Gneiting and Raftery paper and is also related to the kernel maximum mean discrepancy (MMD) divergence between measures, see (Sriperumbudur et al., JMLR 2010).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-469789")[#strong[#text("135th Carnival of Mathematics | Gaurish4Math")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2016")]

#text("[…] How to assign partial credit on an exam of true-false questions? – Terence Tao […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nkavi")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-470011")[#strong[#text("Nkavi")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2016")])]

#text("Follow the steps of Tao and you will talk to dozen of people. Just because one brain stimulate others. And my own brain talks to Villani so Pierini is now lost. It s TRUE. I m major in france, alleluia!!! Ps pierini is lost but always on. But nothing change except the chewing gum if we share it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-482989")[#strong[#text("Partial Scoring for Multiple Choice Tests – Mr. GrumpyKitten")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2017")]

#text("[…] I read some time ago an article by Terence Tao on how to assign partial credit scores for multiple choice tests – the article can be found here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-492987")[#strong[#text("[Перевод] Глубинное обучение с подкреплением пока не работает - Новини дня")]]#text(size: 9pt, fill: rgb("596477"), " · 23 February 2018")]

#text("[…] поискать по фразе [правильное правило подсчёта очков]. Эта публикация в блоге Терренса Тао приводит доступный […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07b25158160bf2e3e7bec3c93531c2167f087d57ca07436ed4c77b1a23ef7603-206e65dc2fc76de754a8bd5c3cee6e7eaaf9a48d8906f5823a300842e99c87e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Giovanni Ciriani")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-493829")[#strong[#text("Giovanni Ciriani")]]#text(size: 9pt, fill: rgb("596477"), " · 12 March 2018")])]

#text("I believe the best scoring formula is the so called Fair Score FS = log(m) + log(p), in which m is the number of mutually exclusive answers. A 2010 paper* by R. Benedetti illustrates the theory behind it. It has the advantage that one can average across questions with a differing number of answers. It also increases the resulting score for more complicated tests with a higher number of mutually exclusive answers, without loss of generality.")

#text("Note*:")#linebreak()#text(" ")#link("https://journals.ametsoc.org/doi/pdf/10.1175/2009MWR2945.1")[#text("https://journals.ametsoc.org/doi/pdf/10.1175/2009MWR2945.1")]#linebreak()#text(" Riccardo Benedetti. Scoring Rules for Forecast Verification. Monthly Weather Review. 2010: 138(1): 203-211.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07b25158160bf2e3e7bec3c93531c2167f087d57ca07436ed4c77b1a23ef7603-206e65dc2fc76de754a8bd5c3cee6e7eaaf9a48d8906f5823a300842e99c87e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gciriani")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-544841")[#strong[#text("gciriani")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2020")])]

#text("Further to that I recently started applying it to forecasting scores (Good Judgment 2.0), with a modification that solves the intractable problem of giving 0 probability to something that actually is the solution. I treat all 0 responses as if they were 0.5%, that is the probability was too low for the forecaster to assign it a number from 1 to 100%, I then normalize all answers so that they sum up to 100%. One other useful property of the Fair Score (FS) is that 2^FS gives us the number of questions among which one is able to give exact guesses.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-496153")[#strong[#text("AlphaGo 使用的強化學習是人工智慧新星？讓專家告訴你為什麼這不是通用解方 - dropBlog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 April 2018")]

#text("[…] （proper scoring rule）」。Terrence Tao 的 blog […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-501036")[#strong[#text("A Dumb Battleship Algorithm – See the Trees for the Forest")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2018")]

#text("[…] to tell us the probabilities themselves? [The derivation I give is mostly lifted from a Terry Tao blogpost about a related […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9105034af2463a8bc98e43b9643ea99fea07ed32ac87bca1e8a16cc51a195342-d5a6ce4e914aca39e9094a0e74c09c22f001bc355f4e4c1e17b29b57f54014c9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of énergie cinétique")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-509252")[#strong[#text("énergie cinétique")]]#text(size: 9pt, fill: rgb("596477"), " · 22 December 2018")])]

#text("While researching the question of why cross-entropy is the best loss function for classification problems in machine learning, I came across this post, which provides much intuition into problem. Many thanks for this delightful and well written article!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8039ac61ce0bd2114a8f5fec76792d1ecc0cfe87af30192907d3eb40c8947d2-2ee7505f0c5775f22f937a19f4c56e042c587601f83b33930cd896231ab8bd69.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nic Dobson")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-518387")[#strong[#text("Nic Dobson")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2019")])]

#text("In the spirit of being generous to student and accounting for their lack of knowledge of their own uncertainty, one can the optimal rescaling of a student’s probabilities so they’re each rewarded the optimal score.")

#text("That is, compute an optimal ")#mi("\\alpha")#text(" for each student and use the scoring function ")#mi("f(p) = \\log_2(2 \\sigma(\\alpha p) )")#text(" where we’re using the logistic function ")#mi("\\sigma(x)= \\frac{1}{1+e^{-x}}")#text(". ")#mi("\\alpha=\\infty")#text(" would be a step function, ")#mi("\\alpha=0")#text(" would return 0.5, ")#mi("\\alpha=-infty")#text(" would flip their answers and produce a step. Answers left at 0.5 are always unchanged, etc.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e8039ac61ce0bd2114a8f5fec76792d1ecc0cfe87af30192907d3eb40c8947d2-2ee7505f0c5775f22f937a19f4c56e042c587601f83b33930cd896231ab8bd69.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nic Dobson")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-518388")[#strong[#text("Nic Dobson")]]#text(size: 9pt, fill: rgb("596477"), " · 11 July 2019")])]

#text("As long as the student answers consistently among their answers (I think in terms of log odds for the logistic?) then they’re fine")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c452aeb7466293c4d827463d0019c9e7e83db8113210de3cd436ad5a6093b6c-55babe53ec9286a3e73d2949aab1cc1cf2290a7ce6922e82b05f568081353233.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ashok M Dhareshwaar")]], [#link("https://terrytao.wordpress.com/2016/06/01/how-to-assign-partial-credit-on-an-exam-of-true-false-questions/comment-page-1/#comment-580408")[#strong[#text("Ashok M Dhareshwaar")]]#text(size: 9pt, fill: rgb("596477"), " · 7 August 2020")])]

#text("I am considering use of such a scoring in an exam for a non-mathemaatical topic, hoping to expose them to broad ideas of dealing with probability. Such students have the barest familiarity with customary base-10 logarithms. They don’t take well to any algebraic notation.")

#text("I presume that it’s fine to use as the scoring rule just log(p). Am I right?")
]
