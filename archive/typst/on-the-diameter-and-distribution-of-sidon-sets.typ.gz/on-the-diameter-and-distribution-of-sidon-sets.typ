// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2026/10/28/on-the-diameter-and-distribution-of-sidon-sets/
// Converted to Typst by tao2typ: "2026-10-29T13:27:00.607817+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "On the diameter and distribution of Sidon sets", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What’s new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("On the diameter and distribution of Sidon sets")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 28 October 2026")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2026/10/28/on-the-diameter-and-distribution-of-sidon-sets/")[#text("https://terrytao.wordpress.com/2026/10/28/on-the-diameter-and-distribution-of-sidon-sets/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-29 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("https://dcartermath.github.io/")[#text("Daniel Carter")]#text(", ")#link("https://www.math.csi.cuny.edu/People/faculty/OBryant-Kevin.html")[#text("Kevin O’Bryant")]#text(", and I have uploaded to the arXiv our paper ")#link("https://arxiv.org/abs/2610.36207")[#text("On the diameter and distribution of Sidon sets")]#text(". This is a paper stemming from an ")#link("https://terrytao.wordpress.com/2025/11/05/mathematical-exploration-and-discovery-at-scale/#comment-689052")[#text("interaction on my blog last year")]#text(", regarding the use of AlphaEvolve to improve the then state of the art on the size of Sidon sets. We obtained a series of further refinements to the bound until progress stalled; after several months of no further progress, we decided to release what we have in this preprint.")

#text("Recall that a Sidon set ")#mi("{A}")#text(" is a set of integers with the property that all the sums ")#mi("{a + b}")#text(" with ")#mi("{a, b \\in A}")#text(" and ")#mi("{a \\leq b}")#text(" are distinct. Equivalently, all the differences ")#mi("{a-b}")#text(", ")#mi("{a, b \\in A}")#text(" are distinct, except at ")#mi("{0}")#text(" where of course there is a large multiplicity. A basic question (")#link("https://www.erdosproblems.com/30")[#text("Erdős problem #30")]#text(") asks for the largest size ")#tao-math("{k = \\left|A\\right|}", block: false)#text(" of a Sidon set in ")#mi("{\\{1,\\dots,N\\}}")#text(". Several algebraic constructions of Sidon sets (by Singer, Bose, and Ruzsa) are known with ")#mi("{k = N^{1/2} - O(1)}")#text(" and special choices of ")#mi("{N}")#text("; see ")#link("https://arxiv.org/abs/math/0407117")[#text("this survey of O’Bryant")]#text(" for details. Erdős and Turán have conjectured that ")#mi("{k}")#text(" cannot exceed ")#mi("{N^{1/2} + O(N^{o(1)})}")#text(", with the bound ")#mi("{N^{1/2} + O(1)}")#text(" also proposed by Erdős as “perhaps too optimistic”.")

#text("For some time, the best upper bound was of the shape ")#metadata(none) <tao-74fec0c33e96ab90ac88>#mi("\\displaystyle  k \\leq N^{1/2} + N^{1/4} + O(1) \\ \\ \\ \\ \\ (1)")#text(" ")#text(" of which several proofs are now known. As ")#link("https://teorth.github.io/optimizationproblems/constants/5a.html")[#text("tracked in the optimization constants repository")]#text(", the constant factor in the second term has been gradually declining in the last few years; in our preprint we obtain the bound ")#metadata(none) <tao-1c32b3e5fbd14dfbabb2>#mi("\\displaystyle  k \\leq N^{1/2} + 0.94304 N^{1/4} + O(1) \\ \\ \\ \\ \\ (2)")#text(" ")#text(" but we appear to be reaching the limit of our current method. Very recently, a slightly sharper bound of 0.942809522 was ")#link("https://www.erdosproblems.com/forum/thread/30#post-9295")[#text("obtained by a different method")]#text(", but our focus here is on the method rather than the specific numerical constant obtained. (We also did not try to use 2026-level AI tools to optimize our own bound.)")

#text("To illustrate our approach, let us sketch a proof of the bound ")#link(<tao-74fec0c33e96ab90ac88>)[#text("(1)")]#text(". The fact that all the non-zero differences of ")#mi("{A}")#text(" are disjoint gives rise to a pointwise convolution bound")

#align(center)[#tao-fit-display[#mitex("1_A * \\tilde 1_A (x) \\leq 1 + k 1_{x=0}")]]

#text("where ")#mi("{\\tilde f(x) = f(-x)}")#text(" denotes the reflection of ")#mi("{f}")#text(". Taking inner products with a non-negative autocorrelation function ")#mi("{w * \\tilde w}")#text(" to be chosen later, we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| 1_A * w \\right\\|_2^2 \\leq \\left\\| w \\right\\|_1^2 + k \\left\\|w\\right\\|_2^2.", block: true)]]

#text("Taking the inner product of ")#mi("{1_A * w}")#text(" with a further weight ")#mi("{t}")#text(", and rearranging, we conclude the bound")

#align(center)[#tao-fit-display[#tao-math("\\langle 1_A, t * \\tilde w \\rangle^2 \\leq \\left\\|t\\right\\|_2^2 ( \\left\\| w \\right\\|_1^2 + k \\left\\|w\\right\\|_2^2 ).", block: true)]]

#text("On the other hand, if one has the pointwise lower bound")

#align(center)[#tao-fit-display[#mitex("t * \\tilde w \\geq \\lambda")]]

#text("on ")#mi("{\\{1,\\dots,N\\}}")#text(", then the left-hand side is at least ")#mi("{(\\lambda k)^2}")#text(". This gives an inequality")

#align(center)[#tao-fit-display[#tao-math("(\\lambda k)^2 \\leq \\left\\|t\\right\\|_2^2 ( \\left\\| w \\right\\|_1^2 + k \\left\\|w\\right\\|_2^2 )", block: true)]]

#text("that can be used to bound ")#mi("{k}")#text(" by choosing ")#mi("{t, w}")#text(" appropriately. For instance if one selects")

#align(center)[#tao-fit-display[#mitex("w := 1_{[1, k^{3/2}]}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("t := 1_{[-k^{3/2}, N]}")]]

#text("then one basically has ")#mi("{\\lambda = k^{3/2}}")#text(", and the above bound becomes (after ignoring some lower order terms)")

#align(center)[#tao-fit-display[#mitex("k^5 \\leq (N + k^{3/2}) (k^3 + k^{5/2})")]]

#text("which after some algebra gives ")#link(<tao-74fec0c33e96ab90ac88>)[#text("(1)")]#text(".")

#text("One can improve this bound by replacing the sharply truncated cutoff functions ")#mi("{w,t}")#text(" with more complicated cutoffs, which obey some biconvex constraints which one can explore using various optimization algorithms. It turns out that one can do even better by working not with deterministic choices of ")#mi("{w,t}")#text(", but with random choices of ")#mi("{w,t}")#text(", in which inequalities such as ")#mi("{0 \\leq w * \\tilde w}")#text(" are only true after performing an expectation. The calculations get quite messy (and highly computer-assisted), but eventually give ")#link(<tao-1c32b3e5fbd14dfbabb2>)[#text("(2)")]#text(". The method also extends to the more general class of ")#mi("{\\gamma}")#text("-Golomb rulers, in which a given non-zero difference is permitted to appear up to ")#mi("{\\gamma}")#text(" times.")
