// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/
// Converted to Typst by tao2typ: "2026-10-14T16:38:27.487616+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 3: Local well-posedness for the Euler equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 3: Local well-posedness for the Euler equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 October 2018")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We now turn to the local existence theory for the initial value problem for the incompressible Euler equations ")#metadata(none) <tao-c23c23a7c71feb7e0bd8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\partial_t u + (u \\cdot \\nabla) u = - \\nabla p")]]



#tao-aligned(keep: true)[


#tao-math("\\nabla \\cdot u  & = 0", block: true)



#tao-math("u(0,x)  & = u_0(x).", block: true)
]

#text("For sake of discussion we will just work in the non-periodic domain ")#mi("{{\\bf R}^d}")#text(", ")#mi("{d \\geq 2}")#text(", although the arguments here can be adapted without much difficulty to the periodic setting. We will only work with solutions in which the pressure ")#mi("{p}")#text(" is normalised in the usual fashion: ")#metadata(none) <tao-b667446e6eb2552fbe29>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("p = - \\Delta^{-1} \\nabla \\cdot \\nabla \\cdot (u \\otimes u).")]]

#text("Formally, the Euler equations (with normalised pressure) arise as the vanishing viscosity limit ")#mi("{\\nu \\rightarrow 0}")#text(" of the Navier-Stokes equations ")#metadata(none) <tao-5bda84779c07d3fa658d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\partial_t u + (u \\cdot \\nabla) u = - \\nabla p + \\nu \\Delta u")]]



#tao-aligned(keep: true)[


#tao-math("\\nabla \\cdot u  & = 0", block: true)



#tao-math("p  & = - \\Delta^{-1} \\nabla \\cdot \\nabla \\cdot (u \\otimes u)", block: true)



#tao-math("u(0,x)  & = u_0(x)", block: true)
]

#text("that was studied in previous notes. However, because most of the bounds established in previous notes, either on the lifespan ")#mi("{T_*}")#text(" of the solution or on the size of the solution itself, depended on ")#mi("{\\nu}")#text(", it is not immediate how to justify passing to the limit and obtain either a strong well-posedness theory or a weak solution theory for the limiting equation ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(". (For instance, weak solutions to the Navier-Stokes equations (or the approximate solutions used to create such weak solutions) have ")#mi("{\\nabla u}")#text(" lying in ")#mi("{L^2_{t,loc} L^2_x}")#text(" for ")#mi("{\\nu>0}")#text(", but the bound on the norm is ")#mi("{O(\\nu^{-1/2})}")#text(" and so one could lose this regularity in the limit ")#mi("{\\nu \\rightarrow 0}")#text(", at which point it is not clear how to ensure that the nonlinear term ")#mi("{u_j u}")#text(" still converges in the sense of distributions to what one expects.)")#linebreak()#text(" Nevertheless, by carefully using the energy method (which we will do loosely following an ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1867882")[#text("approach of Bertozzi and Majda")]#text("), it is still possible to obtain ")#emph[#text("local-in-time")]#text(" estimates on (high-regularity) solutions to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" that are uniform in the limit ")#mi("{\\nu \\rightarrow 0}")#text(". Such ")#emph[#text("a priori")]#text(" estimates can then be combined with a number of variants of these estimates obtain a satisfactory local well-posedness theory for the Euler equations. Among other things, we will be able to establish the ")#emph[#text("Beale-Kato-Majda criterion")]#text(" – smooth solutions to the Euler (or Navier-Stokes) equations can be continued indefinitely unless the integral")

#align(center)[#tao-fit-display[#tao-math("\\int_0^{T_*} \\left\\| \\omega(t) \\right\\|_{L^\\infty_x( {\\bf R}^d \\rightarrow \\wedge^2 {\\bf R}^d )}\\ dt", block: true)]]

#text("becomes infinite at the final time ")#mi("{T_*}")#text(", where ")#mi("{\\omega := \\nabla \\wedge u}")#text(" is the ")#emph[#text("vorticity")]#text(" field. The vorticity has the important property that it is transported by the Euler flow, and in two spatial dimensions it can be used to establish global regularity for both the Euler and Navier-Stokes equations in these settings. (Unfortunately, in three and higher dimensions the phenomenon of ")#link("https://en.wikipedia.org/wiki/Vortex_stretching")[#text("vortex stretching")]#text(" has frustrated all attempts to date to use the vorticity transport property to establish global regularity of either equation in this setting.)")#linebreak()#text(" There is a rather different approach to establishing local well-posedness for the Euler equations, which relies on the ")#emph[#text("vorticity-stream")]#text(" formulation of these equations. This will be discused in a later set of notes.")

#metadata(none) <tao-fa9639d5dbdbe6cc7b8b>

#heading(level: 1)[#strong[#text(" — 1. A priori bounds — ")]]

#text("We now develop some ")#emph[#text("a priori")]#text(" bounds for very smooth solutions to Navier-Stokes that are uniform in the viscosity ")#mi("{\\nu}")#text(". Define an ")#mi("{H^\\infty}")#text(" function to be a function that lies in every ")#mi("{H^s}")#text(" space; similarly define an ")#mi("{L^p_t H^\\infty_x}")#text(" function to be a function that lies in ")#mi("{L^p_t H^s_x}")#text(" for every ")#mi("{s}")#text(". Given divergence-free ")#mi("{H^\\infty({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" initial data ")#mi("{u_0}")#text(", an ")#mi("{H^\\infty}")#text(" mild solution ")#mi("{u}")#text(" to the Navier-Stokes initial value problem ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" is a solution that is an ")#mi("{H^s}")#text(" mild solution for all ")#mi("{s}")#text(". From the (non-periodic version of) Corollary 40 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text(", we know that for any ")#mi("{H^\\infty({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" divergence-free initial data ")#mi("{u_0}")#text(", there is unique ")#mi("{H^\\infty}")#text(" maximal Cauchy development ")#mi("{u: [0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", with ")#tao-math("{\\left\\|u\\right\\|_{L^\\infty_t L^\\infty_x([0,T_*) \\times {\\bf R}^d)}}", block: false)#text(" infinite if ")#mi("{T_*}")#text(" is finite.")

#text("Here are our first bounds:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (A priori bound)")]#text(" ")#metadata(none) <tao-292aee119f4956fd01b2>#text(" Let ")#mi("{u: [0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" be an ")#mi("{H^\\infty}")#text(" maximal Cauchy development to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" with initial data ")#mi("{u_0}")#text(".")

#list(
[#text("(i) For any integer ")#mi("{s > \\frac{d}{2}+1}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("T_* \\gtrsim_{s,d} \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}^{-1}.", block: true)]]

#text("Furthermore, if ")#tao-math("{0 \\leq t \\leq c_{s,d} \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}^{-1}}", block: false)#text(" for a sufficiently small constant ")#mi("{c_{s,d}>0}")#text(" depending only on ")#mi("{s,d}")#text(", then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d} \\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)]]],
[#text("(ii) For any ")#mi("{0 < T < T_*}")#text(" and integer ")#mi("{s \\geq 0}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{L^\\infty_t H^s_x([0,T] \\times{\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\exp( O_{s,d}( \\left\\| \\nabla u \\right\\|_{L^1_t L^\\infty_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2})} ) ) \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)]]]
)
]

#text("The hypothesis that ")#mi("{s}")#text(" is integer can be dropped by more heavily exploiting the theory of paraproducts, but we shall restrict attention to integer ")#mi("{s}")#text(" for simplicity.")

#text("We now prove this theorem using the energy method. Using the Navier-Stokes equations, we see that ")#mi("{u, p}")#text(" and ")#mi("{\\partial_t u}")#text(" all lie in ")#mi("{L^\\infty_t H^\\infty_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" for any ")#mi("{0 < T < T_*}")#text("; an easy iteration argument then shows that the same is true for all higher derivatives of ")#mi("{u,p}")#text(" also. This will make it easy to justify the differentiation under the integral sign that we shall shortly perform.")

#text("Let ")#mi("{s \\geq 0}")#text(" be an integer. For each time ")#mi("{t \\in [0,T)}")#text(", we introduce the energy-type quantity")

#align(center)[#tao-fit-display[#tao-math("E(t) := \\sum_{m=0}^s \\frac{1}{2} \\int_{{\\bf R}^d} \\left|\\nabla^m u(t,x)\\right|^2\\ dx.", block: true)]]

#text("Here we think of ")#mi("{\\nabla^m u}")#text(" as taking values in the Euclidean space ")#mi("{{\\bf R}^{d^{m+1}}}")#text(". This quantity is of course comparable to ")#tao-math("{\\left\\| u(t) \\right\\|_{H^m({\\bf R}^d \\rightarrow {\\bf R}^d)}^2}", block: false)#text(", up to constants depending on ")#mi("{d,s}")#text(". It is easy to verify that ")#mi("{E(t)}")#text(" is continuously differentiable in time, with derivative")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t) = \\sum_{m=0}^s \\int_{{\\bf R}^d} \\nabla^m u \\cdot \\nabla^m \\partial_t u\\ dx,")]]

#text("where we suppress explicit dependence on ")#mi("{t,x}")#text(" in the integrand for brevity. We now try to bound this quantity in terms of ")#mi("{E(t)}")#text(". We expand the right-hand side in coordinates using ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t) = -A - B +C")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("A  & := \\sum_{m=0}^s \\int_{{\\bf R}^d} \\nabla^m u_i \\cdot \\nabla^m (u_j \\partial_j u_i)\\ dx", block: true)



#tao-math("B  & := \\sum_{m=0}^s \\int_{{\\bf R}^d} \\nabla^m u_i \\cdot \\nabla^m \\partial_i p\\ dx", block: true)



#tao-math("C  & := \\nu \\sum_{m=0}^s \\int_{{\\bf R}^d} \\nabla^m u_i \\cdot \\nabla^m \\partial_j \\partial_j u_i\\ dx.", block: true)
]

#text("For ")#mi("{B}")#text(", we can integrate by parts to move the ")#mi("{\\partial_i}")#text(" operator onto ")#mi("{u_i}")#text(" and use the divergence-free nature ")#mi("{\\partial_i u_i=0}")#text(" of ")#mi("{u}")#text(" to conclude that ")#mi("{B=0}")#text(". Similarly, we may integrate by parts for ")#mi("{C}")#text(" to move one copy of ")#mi("{\\partial_j}")#text(" over to the other factor in the integrand to conclude")

#align(center)[#tao-fit-display[#tao-math("C = - \\nu \\sum_{m=0}^s \\int_{{\\bf R}^d} \\left|\\nabla^{m+1} u\\right|^2\\ dx", block: true)]]

#text("so in particular ")#mi("{C \\leq 0}")#text(" (note that as we are seeking bounds that are uniform in ")#mi("{\\nu}")#text(", we can’t get much further use out of ")#mi("{C}")#text(" beyond this bound). Thus we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t) \\leq -A.")]]

#text("Now we expand out ")#mi("{A}")#text(" using the Leibniz rule. There is one dangerous term, in which all the derivatives in ")#mi("{\\nabla^m (u_j \\partial_j u_i)}")#text(" fall on the ")#mi("{u_i}")#text(" factor, giving rise to the expression")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=0}^s \\int_{{\\bf R}^d} u_j \\nabla^m u_i \\cdot \\nabla^m \\partial_j u_i\\ dx.")]]

#text("But we can locate a total derivative to write this as")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\sum_{m=0}^s \\int_{{\\bf R}^d} u_j \\partial_j \\left|\\nabla^m u\\right|^2\\ dx,", block: true)]]

#text("and then an integration by parts using ")#mi("{\\partial_j u_j=0}")#text(" as before shows that this term vanishes. Estimating the remaining contributions to ")#mi("{A}")#text(" using the triangle inequality, we arrive at the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|A\\right| \\lesssim_{s,d} \\sum_{m=1}^s \\sum_{a=1}^m \\int_{{\\bf R}^d} \\left|\\nabla^m u\\right| \\left|\\nabla^a u\\right| |\\nabla^{m-a+1} u|\\ dx.", block: true)]]

#text("At this point we now need a variant of Proposition 35 from ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-e8b22d83b417e85ba4f2>#text(" Let ")#mi("{a,b \\geq 0}")#text(" be integers. For any ")#mi("{f,g \\in H^\\infty({\\bf R}^d \\rightarrow {\\bf R})}")#text(", show that")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\left|\\nabla^a f\\right| \\left|\\nabla^b g\\right| \\right\\|_{L^2({\\bf R}^d \\rightarrow {\\bf R})}  & \\lesssim_{a,b,d} \\left\\| f \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow {\\bf R})} \\left\\| g \\right\\|_{H^{a+b}({\\bf R}^d \\rightarrow {\\bf R})}", block: true)



#tao-math(" & + \\left\\| f \\right\\|_{H^{a+b}({\\bf R}^d \\rightarrow {\\bf R})} \\left\\| g \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow {\\bf R})}.", block: true)
]

#text("(")#emph[#text("Hint:")]#text(" for ")#mi("{a=0}")#text(" or ")#mi("{b=0}")#text(", use Hölder’s inequality. Otherwise, use a suitable Littlewood-Paley decomposition.)")
]

#text("Using this exercise and Hölder’s inequality, we see that")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^d} \\left|\\nabla^m u\\right| \\left|\\nabla^a u\\right| \\left|\\nabla^{m-a+1} u\\right| \\lesssim_{a,m,d} \\left\\| \\nabla^m u \\right\\|_{L^2({\\bf R}^d \\rightarrow {\\bf R}^{d^{m+1}})} \\left\\| \\nabla u \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow {\\bf R}^{d^2})}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla^m u \\right\\|_{L^2({\\bf R}^d \\rightarrow {\\bf R}^{d^{m+1}})}", block: true)]]

#text("and thus ")#metadata(none) <tao-1e22560cee2c4b727c6a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\partial_t E(t) \\leq O_{s,d}( E(t) \\left\\| \\nabla u(t) \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow {\\bf R}^{d^2})} ).", block: true)]]

#text("By Gronwall’s inequality we conclude that")

#align(center)[#tao-fit-display[#tao-math("E(t) \\leq E(0) \\exp( O_{s,d}( \\left\\| \\nabla u \\right\\|_{L^1_t L^\\infty_x( [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2} )} ) )", block: true)]]

#text("for any ")#mi("{0 < T < T_*}")#text(" and ")#mi("{t \\in [0,T]}")#text(", which gives part (ii).")#linebreak()#text(" Now assume ")#mi("{s > \\frac{d}{2}+1}")#text(". Then we have the Sobolev embedding")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla u(t) \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow {\\bf R}^{d^2})} \\lesssim_{s,d} E(t)^{1/2}", block: true)]]

#text("which when inserted into ")#link(<tao-1e22560cee2c4b727c6a>)[#text("(4)")]#text(" yields the differential inequality")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t) \\leq O_{s,d}( E(t)^{3/2} )")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t)^{-1/2} \\geq - C_{s,d}")]]

#text("for some constant ")#mi("{C_{s,d}}")#text(" (strictly speaking one should work with ")#mi("{(\\varepsilon + E(t))^{-1/2}}")#text(" for some small ")#mi("{\\varepsilon>0}")#text(" which one sends to zero later, if one wants to avoid the possibility that ")#mi("{E(t)}")#text(" vanishes, but we will ignore this small technicality for sake of exposition.) Since ")#tao-math("{E(0)^{-1/2} \\gtrsim_{s,d} \\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}^{-1}}", block: false)#text(", we conclude that ")#mi("{E(t)}")#text(" stays bounded for a time interval of the form ")#tao-math("{0 \\leq t < \\min( c_{s,d} \\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}^{-1}, T_*)}", block: false)#text("; this, together with the blowup criterion that ")#tao-math("{\\left\\|u(t)\\right\\|_{H^s}}", block: false)#text(" must go to infinity as ")#mi("{t \\rightarrow T_*}")#text(", gives part (i).")#linebreak()#text(" As a consequence, we can now obtain local existence for the Euler equations from smooth data:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Local existence for smooth solutions)")]#text(" ")#metadata(none) <tao-7b5454f75089acf2693b>#text(" Let ")#mi("{u_0 \\in H^\\infty({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence-free. Let ")#mi("{s > \\frac{d}{2}+1}")#text(" be an integer, and set")

#align(center)[#tao-fit-display[#tao-math("T := c_{s,d} \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}^{-1}.", block: true)]]

#text("Then there is a smooth solution ")#mi("{u: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", ")#mi("{p: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" to ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" with all derivatives of ")#mi("{u,p}")#text(" in ")#mi("{L^\\infty_t H^\\infty([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^m)}")#text(" for appropriate ")#mi("{m}")#text(". Furthermore, for any integer ")#mi("{s^{\\prime} \\geq 0}")#text(", one has ")#metadata(none) <tao-e8d0d04fea35d6890558>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\| u \\right\\|_{L^\\infty_t H^{s^{\\prime}}_x([0,T] \\times{\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,s^{\\prime},d} \\left\\| u_0 \\right\\|_{H^{s^{\\prime}}_x({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" We use the compactness method, which will be more powerful here than in the last section because we have much higher regularity uniform bounds (but they are only local in time rather than global). Let ")#mi("{\\nu_n > 0}")#text(" be a sequence of viscosities going to zero. By the local existence theory for Navier-Stokes (Corollary 40 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text("), for each ")#mi("{n}")#text(" we have a maximal Cauchy development ")#mi("{u^{(n)}: [0,T^{(n)}) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", ")#mi("{p^{(n)}: [0,T^{(n)}_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" to the Navier-Stokes initial value problem ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" with viscosity ")#mi("{\\nu_n}")#text(" and initial data ")#mi("{u_0}")#text(". From Theorem ")#link(<tao-292aee119f4956fd01b2>)[#text("1")]#text("(i), we have ")#mi("{T^{(n)}_* \\geq T}")#text(" for all ")#mi("{n}")#text(" (if ")#mi("{c_{s,d}}")#text(" is small enough), and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u^{(n)} \\right\\|_{L^\\infty_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d} \\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{n}")#text(". By Sobolev embedding, this implies that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla u^{(n)} \\right\\|_{L^\\infty_t L^\\infty_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2})} \\lesssim_{s,d} \\left\\| u_0 \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)},", block: true)]]

#text("and then by Theorem ")#link(<tao-292aee119f4956fd01b2>)[#text("1")]#text("(ii) one has ")#metadata(none) <tao-68bca10eea2ba33f6f15>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\| u^{(n)} \\right\\|_{L^\\infty_t H^{s^{\\prime}}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^{d})} \\lesssim_{s,s^{\\prime},d} \\left\\| u_0 \\right\\|_{H^{s^{\\prime}}({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("for every integer ")#mi("{s}")#text(". Thus, for each ")#mi("{s^{\\prime}}")#text(", ")#mi("{u^{(n)}}")#text(" is bounded in ")#mi("{L^\\infty_t H^{s^{\\prime}}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2})}")#text(", uniformly in ")#mi("{n}")#text(". By repeatedly using ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" and product estimates for Sobolev spaces, we see the same is true for ")#mi("{p^{(n)}}")#text(", and for all higher derivatives of ")#mi("{u^{(n)}, p^{(n)}}")#text(". In particular, all derivatives of ")#mi("{u^{(n)}, p^{(n)}}")#text(" are equicontinuous.")#linebreak()#text(" Using weak compactness (Proposition 2 of ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text("), one can pass to a subsequence such that ")#mi("{u^{(n)}, p^{(n)}}")#text(" converge weakly to some limits ")#mi("{u, p}")#text(", such that ")#mi("{u,p}")#text(" and all their derivatives lie in ")#mi("{L^\\infty_t H^{s^{\\prime}}_x}")#text(" on ")#mi("{[0,T] \\times {\\bf R}^d}")#text("; in particular, ")#mi("{u,p}")#text(" are smooth. From the Arzelá-Ascoli theorem (and Proposition 3 of ")#link("https://terrytao.wordpress.com/2018/10/02/254a-notes-2-weak-solutions-of-the-navier-stokes-equations/")[#text("Notes 2")]#text("), ")#mi("{u^{(n)}}")#text(" and ")#mi("{p^{(n)}}")#text(" converge locally uniformly to ")#mi("{u,p}")#text(", and similarly for all derivatives of ")#mi("{u,p}")#text(". One can then take limits in ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" and conclude that ")#mi("{u,p}")#text(" solve ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(". The bound ")#link(<tao-e8d0d04fea35d6890558>)[#text("(5)")]#text(" follows from taking limits in ")#link(<tao-68bca10eea2ba33f6f15>)[#text("(6)")]#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" We are able to easily pass to the zero viscosity limit here because our domain ")#mi("{{\\bf R}^d}")#text(" has no boundary. In the presence of a boundary, we cannot freely differentiate in space as casually as we have been doing above, and one no longer has bounds on higher derivatives on ")#mi("{u}")#text(" and ")#mi("{p}")#text(" near the boundary that are uniform in the viscosity. Instead, it is possible for the fluid to form a thin ")#link("https://en.wikipedia.org/wiki/Boundary_layer")[#text("boundary layer")]#text(" that has a non-trivial effect on the limiting dynamics. We hope to return to this topic in a future set of notes.")
]

#text("We have constructed a local smooth solution to the Euler equations from smooth data, but have not yet established uniqueness or continuous dependence on the data; related to the latter point, we have not extended the construction to larger classes of initial data than the smooth class ")#mi("{H^\\infty}")#text(". To accomplish these tasks we need a further ")#emph[#text("a priori")]#text(" estimate, now involving ")#emph[#text("differences")]#text(" of two solutions, rather than just bounding a single solution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 5 (A priori bound for differences)")]#text(" ")#metadata(none) <tao-ee09ac4e88f781bdd8c2>#text(" Let ")#mi("{R>0}")#text(", let ")#mi("{s > \\frac{d}{2}+1}")#text(" be an integer, and let ")#mi("{u_0, v_0 \\in H^\\infty({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence-free with ")#mi("{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" norm at most ")#mi("{R}")#text(". Let")

#align(center)[#tao-fit-display[#mitex("0 < T \\leq c_{s,d} R^{-1}")]]

#text("where ")#mi("{c_{s,d}>0}")#text(" is sufficiently small depending on ")#mi("{s,d}")#text(". Let ")#mi("{u: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" and ")#mi("{p: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be an ")#mi("{H^\\infty}")#text(" solution to ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" with initial data ")#mi("{u_0}")#text(" (this exists thanks to Corollary ")#link(<tao-7b5454f75089acf2693b>)[#text("3")]#text("), and let ")#mi("{v: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" and ")#mi("{q: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be an ")#mi("{H^\\infty}")#text(" solution to ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" with initial data ")#mi("{v_0}")#text(". Then one has ")#metadata(none) <tao-ad111dbf75c3d16af382>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left\\|u-v\\right\\|_{L^\\infty_t H^{s-1}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d} \\left\\|u_0-v_0\\right\\|_{H^{s-1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("and ")#metadata(none) <tao-9988dd169c7d91278e8f>

#tao-aligned(keep: true)[


#tao-math("\\left\\|u-v\\right\\|_{L^\\infty_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}  & \\lesssim_{s,d} \\left\\|u_0-v_0\\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true, numbering: n => [#text("(8)")])



#tao-math(" & + T \\left\\|u_0-v_0\\right\\|_{H^{s-1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)} \\left\\| v_0 \\right\\|_{H^{s+1}({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)
]
]

#text("Note the asymmetry between ")#mi("{u}")#text(" and ")#mi("{v}")#text(" in ")#link(<tao-9988dd169c7d91278e8f>)[#text("(8)")]#text(": this estimate requires control on the initial data ")#mi("{v_0}")#text(" in the high regularity space ")#mi("{H^{s+1}}")#text(" in order to be usable, but has no such requirement on the initial data ")#mi("{u_0}")#text(". This asymmetry will be important in some later applications.")

#emph[#text("Proof:")]#text(" From Corollary ")#link(<tao-7b5454f75089acf2693b>)[#text("3")]#text(" we have ")#metadata(none) <tao-780f86745746934c7b4b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\| u \\right\\|_{L^\\infty_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}, \\left\\| v \\right\\|_{L^\\infty_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d} R", block: true)]]

#linebreak()#text(" and ")#metadata(none) <tao-b0b2b80f7989704992fb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| v \\right\\|_{L^\\infty_t H^{s+1}_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d} \\left\\| v_0 \\right\\|_{H^{s+1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("Now we need bounds on the difference ")#mi("{w := u-v}")#text(". Initially we have ")#mi("{w(0)=w_0}")#text(", where ")#mi("{w_0 := u_0-v_0}")#text(". To evolve later in time, we will need to use the energy method. Subtracting ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" for ")#mi("{(u,p)}")#text(" and ")#mi("{(v,q)}")#text(", we have")

#tao-aligned(keep: true)[


#tao-math("\\partial_t w + w \\cdot \\nabla v + u \\cdot \\nabla w  & = - \\nabla (p-q)", block: true)



#tao-math("\\nabla \\cdot w  & = 0.", block: true)
]

#text("By hypothesis, all derivatives of ")#mi("{w}")#text(" and ")#mi("{p-q}")#text(" lie in ")#mi("{L^\\infty_t H^\\infty_x}")#text(" on ")#mi("{[0,T] \\times {\\bf R}^d}")#text(", which will allow us to justify the manipulations below without difficulty. We introduce the low regularity energy for the difference:")

#align(center)[#tao-fit-display[#mitex("E^{s-1}(t) = \\sum_{m=0}^{s-1} \\int_{{\\bf R}^d} \\nabla^m w \\cdot \\nabla^m w\\ dx.")]]

#text("Arguing as in the proof of Theorem ")#link(<tao-292aee119f4956fd01b2>)[#text("1")]#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_t E^{s-1}(t) = -A - B")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("A  & := \\sum_{m=0}^{s-1} \\int_{{\\bf R}^d} \\nabla^m w_i \\cdot \\nabla^m (w_j \\partial_j v_i + u_j \\partial_j w_i)\\ dx", block: true)



#tao-math("B  & := \\sum_{m=0}^{s-1} \\int_{{\\bf R}^d} \\nabla^m w_i \\cdot \\nabla^m \\partial_i (p-q)\\ dx.", block: true)
]

#text("As before, the divergence-free nature of ")#mi("{w}")#text(" ensures that ")#mi("{B}")#text(" vanishes. For ")#mi("{A}")#text(", we use the Leibniz rule and again extract out the dangerous term")

#align(center)[#tao-fit-display[#mitex("\\sum_{m=0}^{s-1} \\int_{{\\bf R}^d} u_j \\nabla^m w_i \\cdot \\nabla^m \\partial_j w_i\\ dx,")]]

#text("which again vanishes by integration by parts. We then use the triangle inequality to bound")

#tao-aligned(keep: true)[


#tao-math("\\left|A\\right|  & \\lesssim_{s,d} \\sum_{m=0}^{s-1} \\sum_{a=0}^m \\int_{{\\bf R}^d} \\left|\\nabla^m w\\right| \\left|\\nabla^a w\\right| |\\nabla^{m-a+1} v| \\ dx", block: true)



#tao-math(" & + \\sum_{m=1}^{s-1} \\sum_{a=1}^m \\int_{{\\bf R}^d} \\left|\\nabla^m w\\right| \\left|\\nabla^a w\\right| \\left|\\nabla^{m-a+1} v\\right| + \\left|\\nabla^m w\\right| \\left|\\nabla^a u\\right| \\left|\\nabla^{m-a+1} w\\right| \\ dx.", block: true)
]

#text("The key point here is that at most ")#mi("{s-1}")#text(" derivatives are being applied to ")#mi("{w}")#text(" at any given time, although the full ")#mi("{s}")#text(" derivatives may also hit ")#mi("{u}")#text(" or ")#mi("{v}")#text(". Using Exercise ")#link(<tao-e8b22d83b417e85ba4f2>)[#text("2")]#text(" and Hölder, we may bound the above expression by")

#tao-aligned(keep: true)[


#tao-math(" & \\lesssim_{s,d} \\sum_{m=0}^{s-1} \\left\\| \\nabla^m w\\right\\|_{L^2} ( \\left\\| w \\right\\|_{L^\\infty} \\left\\| \\nabla^{m+1} v \\right\\|_{L^2} + \\left\\| \\nabla^m w \\right\\|_{L^2} \\left\\| \\nabla v \\right\\|_{L^\\infty})", block: true)



#tao-math(" & + \\sum_{m=1}^{s-1} \\left\\| \\nabla^m w\\right\\|_{L^2} ( \\left\\| \\nabla u \\right\\|_{L^\\infty} \\left\\| \\nabla^{m} w \\right\\|_{L^2} + \\left\\| \\nabla^{m+1} u \\right\\|_{L^2} \\left\\| w \\right\\|_{L^\\infty})", block: true)
]

#text("which by Sobolev embedding gives")

#align(center)[#tao-fit-display[#tao-math("\\lesssim_{s,d} E^{s-1}(t) ( \\left\\| v(t) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)} + \\left\\| u(t) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)} ).", block: true)]]

#text("Applying ")#link(<tao-780f86745746934c7b4b>)[#text("(9)")]#text(" and Gronwall’s inequality, we conclude that")

#align(center)[#tao-fit-display[#mitex("E^{s-1}(t) \\lesssim_{s,d} E^{s-1}(0)")]]

#text("for ")#mi("{0 \\leq t \\leq T}")#text(", and ")#link(<tao-ad111dbf75c3d16af382>)[#text("(7)")]#text(" follows.")#linebreak()#text(" Now we work with the high regularity energy")

#align(center)[#tao-fit-display[#mitex("E^{s}(t) = \\sum_{m=0}^{s} \\int_{{\\bf R}^d} \\nabla^k w \\cdot \\nabla^k w\\ dx.")]]

#text("Arguing as before we have")

#tao-aligned(keep: true)[


#tao-math("\\partial_t E^s(t)  & \\lesssim_{s,d} \\sum_{m=0}^{s} \\sum_{a=0}^m \\int_{{\\bf R}^d} \\left|\\nabla^m w\\right| \\left|\\nabla^a w\\right| |\\nabla^{m-a+1} v| \\ dx", block: true)



#tao-math(" & + \\sum_{m=1}^{s} \\sum_{a=1}^m \\int_{{\\bf R}^d} \\left|\\nabla^m w\\right| \\left|\\nabla^a w\\right| \\left|\\nabla^{m-a+1} v\\right| + \\left|\\nabla^m w\\right| \\left|\\nabla^a u\\right| \\left|\\nabla^{m-a+1} w\\right| \\ dx.", block: true)
]

#text("Using Exercise ")#link(<tao-e8b22d83b417e85ba4f2>)[#text("2")]#text(" and Hölder, we may bound this by")

#tao-aligned(keep: true)[


#tao-math(" & \\lesssim_{s,d} \\sum_{m=0}^{s} \\left\\| \\nabla^m w\\right\\|_{L^2} ( \\left\\| w \\right\\|_{L^\\infty} \\left\\| \\nabla^{m+1} v \\right\\|_{L^2} + \\left\\| \\nabla^m w \\right\\|_{L^2} \\left\\| \\nabla v \\right\\|_{L^\\infty})", block: true)



#tao-math(" & + \\sum_{m=1}^{s} \\left\\| \\nabla^m w\\right\\|_{L^2} ( \\left\\| \\nabla u \\right\\|_{L^\\infty} \\left\\| \\nabla^{m} w \\right\\|_{L^2} + \\left\\| \\nabla^{m} u \\right\\|_{L^2} \\left\\| \\nabla w \\right\\|_{L^\\infty}).", block: true)
]

#text("Using Sobolev embedding we thus have")

#tao-aligned(keep: true)[


#tao-math("\\partial_t E^s(t)  & \\lesssim_{s,d} E^s(t)^{1/2} E^{s-1}(t)^{1/2} \\left\\|v(t)\\right\\|_{H^{s+1}} + E^s(t) \\left\\|v(t)\\right\\|_{H^s}", block: true)



#tao-math(" & + E^s(t) \\left\\|u(t)\\right\\|_{H^s} + E^s(t) \\left\\|u(t) \\right\\|_{H^s}", block: true)
]

#text("and hence by ")#link(<tao-780f86745746934c7b4b>)[#text("(9)")]#text(", ")#link(<tao-b0b2b80f7989704992fb>)[#text("(10)")]#text(", ")#link(<tao-ad111dbf75c3d16af382>)[#text("(7)")]

#align(center)[#tao-fit-display[#tao-math("\\partial_t E^s(t) \\lesssim_{s,d} E^s(t)^{1/2} \\left\\| w_0 \\right\\|_{H^{s-1}} \\left\\|v_0\\right\\|_{H^{s+1}} + R E^s(t).", block: true)]]

#text("By the chain rule, we obtain")

#align(center)[#tao-fit-display[#tao-math("\\partial_t (E^s(t)^{1/2}) \\lesssim_{s,d} \\left\\| w_0 \\right\\|_{H^{s-1}} \\left\\|v_0\\right\\|_{H^{s+1}} + R E^s(t)^{1/2}", block: true)]]

#text("(one can work with ")#mi("{(\\varepsilon + E^s(t))^{1/2}}")#text(" in place of ")#mi("{E^s(t)^{1/2}}")#text(" and then send ")#mi("{\\varepsilon \\rightarrow 0}")#text(" later if one wishes to avoid a lack of differentiability at ")#mi("{0}")#text("). By Gronwall’s inequality, we conclude that")

#align(center)[#tao-fit-display[#tao-math("E^s(t)^{1/2} \\lesssim_{s,d} E^s(0)^{1/2} + R \\left\\| w_0 \\right\\|_{H^{s-1}} \\left\\|v_0\\right\\|_{H^{s+1}}", block: true)]]

#text("for all ")#mi("{0 \\leq t \\leq T}")#text(", and ")#link(<tao-9988dd169c7d91278e8f>)[#text("(8)")]#text(" follows. ")#mi("\\Box")#linebreak()#text(" By specialising ")#link(<tao-ad111dbf75c3d16af382>)[#text("(7)")]#text(" (or ")#link(<tao-9988dd169c7d91278e8f>)[#text("(8)")]#text(") to the case where ")#mi("{u_0=v_0}")#text(", we see the solution constructed in Corollary ")#link(<tao-7b5454f75089acf2693b>)[#text("3")]#text(" is unique. Now we can extend to wider classes of initial data than ")#mi("{H^\\infty}")#text(" initial data. The following result is essentially ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=481652")[#text("due to Kato")]#text(" and ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=277929")[#text("to Swann")]#text(" (with a similar result obtained by different methods ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=271984")[#text("by Ebin-Marsden")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 6")]#text(" Let ")#mi("{s > \\frac{d}{2}+1}")#text(" be an integer, and let ")#mi("{u_0 \\in H^s({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence-free. Set")

#align(center)[#tao-fit-display[#tao-math("T := c_{s,d} \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}^{-1}", block: true)]]

#text("where ")#mi("{c_{s,d}>0}")#text(" is sufficiently small depending on ")#mi("{s,d}")#text(". Let ")#mi("{u_0^{(n)} \\in H^\\infty({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be a sequence of divergence-free vector fields converging to ")#mi("{u_0}")#text(" in ")#mi("{H^s}")#text(" norm (for instance, one could apply Littlewood-Paley projections to ")#mi("{u_0}")#text("). Let ")#mi("{u^{(n)}: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", ")#mi("{p^{(n)}: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be the associated solutions to ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" provided by Corollary ")#link(<tao-7b5454f75089acf2693b>)[#text("3")]#text(" (these are well-defined for ")#mi("{n}")#text(" large enough). Then ")#mi("{u^{(n)}}")#text(" and ")#mi("{p^{(n)}}")#text(" converge in ")#mi("{L^\\infty_t H^s_x}")#text(" norm on ")#mi("{[0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" to limits ")#mi("{u \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", ")#mi("{p \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(" respectively, which solve ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" in a distributional sense.")
]

#emph[#text("Proof:")]#text(" We use a variant of Kato’s argument (see also the ")#link("http://www.ams.org/mathscinet-getitem?mr=385355")[#text("paper of Bona and Smith")]#text(" for a related technique). It will suffice to show that the ")#mi("{u_0^{(n)}}")#text(" form a Cauchy sequence in ")#mi("{C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", since the algebra properties of ")#mi("{H^s}")#text(" then give the same for ")#mi("{p^{(n)}}")#text(", and one can then easily take limits (in this relatively high regularity setting) to obtain the limiting solution ")#mi("{u,p}")#text(" that solves ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" in a distributional sense.")

#text("Let ")#mi("{N}")#text(" be a large dyadic integer. By Corollary ")#link(<tao-7b5454f75089acf2693b>)[#text("3")]#text(", we may find an ")#mi("{H^\\infty}")#text(" solution ")#mi("{v^{(N)}: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d, q^{(N)}}")#text(" be the solution to the Euler equations ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" with initial data ")#mi("{P_{\\leq N} u_0}")#text(" (which lies in ")#mi("{H^\\infty}")#text("). From Theorem ")#link(<tao-ee09ac4e88f781bdd8c2>)[#text("5")]#text(", one has")

#tao-aligned(keep: true)[


#tao-math("\\left\\|u^{(n)}-v^{(N)}\\right\\|_{L^\\infty_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}  & \\lesssim_{s,d} \\left\\|u_0^{(n)}- P_{\\leq N} u_0\\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & + T \\left\\|u_0^{(n)}- P_{\\leq N} u_0\\right\\|_{H^{s-1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)} \\left\\| P_{\\leq N} u_0 \\right\\|_{H^{s+1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)
]

#text("Applying the triangle inequality and then taking limit superior, we conclude that")

#tao-aligned(keep: true)[


#tao-math("\\limsup_{n,m \\rightarrow \\infty} \\left\\|u^{(n)}-u^{(m)}\\right\\|_{L^\\infty_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}  & \\lesssim_{s,d} \\left\\|u_0- P_{\\leq N} u_0\\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)



#tao-math(" & + T \\left\\|u_0 - P_{\\leq N} u_0\\right\\|_{H^{s-1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)} \\left\\| P_{\\leq N} u_0 \\right\\|_{H^{s+1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)}.", block: true)
]

#text("But by Plancherel’s theorem and dominated convergence we see that")

#tao-aligned(keep: true)[


#tao-math("N \\left\\|u_0- P_{\\leq N} u_0\\right\\|_{H^{s-1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)}  & \\rightarrow 0", block: true)



#tao-math("\\left\\|u_0- P_{\\leq N} u_0\\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}  & \\rightarrow 0", block: true)



#tao-math("N^{-1} \\left\\|P_{\\leq N} u_0\\right\\|_{H^{s+1}_x({\\bf R}^d \\rightarrow {\\bf R}^d)}  & \\rightarrow 0", block: true)
]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\limsup_{n,m \\rightarrow \\infty} \\left\\|u^{(n)}-u^{(m)}\\right\\|_{L^\\infty_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)} = 0,", block: true)]]

#text("giving the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" Since the sequence ")#mi("{(u^{(n)}, p^{(n)})}")#text(" can converge to at most one limit ")#mi("{(u,p)}")#text(", we see that the solution ")#mi("{(u,p)}")#text(" to ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" is unique in the class of distributional solutions that are limits of smooth solutions (with initial data of those solutions converging to ")#mi("{u_0}")#text(" in ")#mi("{H^s}")#text("). However, this leaves open the possibility that there are other distributional solutions that do not arise as the limits of smooth solutions (or as limits of smooth solutions whose initial data only converge to ")#mi("{u_0}")#text(" in a weaker sense). It is possible to recover some uniqueness results for fairly weak solutions to the Euler equations if one also assumes some additional regularity on the fields ")#mi("{u,p}")#text(" (or on related fields such as the vorticity ")#mi("{\\omega = \\nabla \\wedge u}")#text("). In two dimensions, for instance, there is a celebrated ")#link("https://mathscinet.ams.org/mathscinet/search/publdoc.html?pg1=MR&s1=158189&loc=fromreflist")[#text("theorem of Yudovich")]#text(" that weak solutions to 2D Euler are unique if one has an ")#mi("{L^\\infty}")#text(" bound on the vorticity. In higher dimensions one can also obtain uniqueness results if one assumes that the solution is in a high-regularity space such as ")#mi("{C^0_t H^s_x}")#text(", ")#mi("{s > \\frac{d}{2}+1}")#text(". See for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1880646")[#text("this paper of Chae")]#text(" for an example of such a result.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Continuous dependence on initial data)")]#text(" Let ")#mi("{s > \\frac{d}{2}+1}")#text(" be an integer, let ")#mi("{R>0}")#text(", and set ")#mi("{T := c_{s,d} R^{-1}}")#text(", where ")#mi("{c_{s,d}>0}")#text(" is sufficiently small depending on ")#mi("{s,d}")#text(". Let ")#mi("{B}")#text(" be the closed ball of radius ")#mi("{R}")#text(" around the origin of divergence-free vector fields ")#mi("{u_0}")#text(" in ")#mi("{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(". The above proposition provides a solution ")#mi("{u \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" to the associated initial value problem. Show that the map from ")#mi("{u_0}")#text(" to ")#mi("{u}")#text(" is a continuous map from ")#mi("{B}")#text(" to ")#mi("{C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" The continuity result provided by the above exercise is not as strong as in Navier-Stokes, where the solution map is in fact Lipschitz continuous (see e.g., Exercise 43 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text("). In fact for the Euler equations, which is classified as a “quasilinear” equation rather than a “semilinear” one due to the lack of the dissipative term ")#mi("{\\nu \\Delta u}")#text(" in the equation, the solution map is not expected to be uniformly continuous on this ball, let alone Lipschitz continuous. See this ")#link("https://terrytao.wordpress.com/2010/02/21/quasilinear-well-posedness/")[#text("previous blog post")]#text(" for some more discussion.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Maximal Cauchy development)")]#text(" ")#metadata(none) <tao-c1f5def06c9c8066f238>#text(" Let ")#mi("{s > \\frac{d}{2}+1}")#text(" be an integer, and let ")#mi("{u_0 \\in H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence free. Show that there exists a unique ")#mi("{T_*>0}")#text(" and unique ")#mi("{u \\in C^0_{t,loc} H^s([0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", ")#mi("{p \\in C^0_{t,loc} H^s([0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(" with the following properties:")

#list(
[#text("(i) If ")#mi("{0 < T < T_*}")#text(" and ")#mi("{u_0^{(n)} \\in H^\\infty_x({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" is divergence-free and converges to ")#mi("{u_0}")#text(" in ")#mi("{H^s}")#text(" norm, then for ")#mi("{n}")#text(" large enough, there is an ")#mi("{H^\\infty}")#text(" solution ")#mi("{(u^{(n)}, p^{(n)})}")#text(" to ")#link(<tao-c23c23a7c71feb7e0bd8>)[#text("(1)")]#text(" with initial data ")#mi("{u_0^{(n)}}")#text(" on ")#mi("{[0,T] \\times {\\bf R}^d}")#text(", and furthermore ")#mi("{u^{(n)}}")#text(" and ")#mi("{p^{(n)}}")#text(" converge in ")#mi("{C^0_t H^s_x}")#text(" norm on ")#mi("{[0,T] \\times {\\bf R}^d}")#text(" to ")#mi("{u, p}")#text(".")],
[#text("(ii) If ")#mi("{T_* < \\infty}")#text(", then ")#tao-math("{\\left\\| u(t) \\right\\|_{H^s({\\bf R}^d \\rightarrow {\\bf R}^d)} \\rightarrow \\infty}", block: false)#text(" as ")#mi("{t \\rightarrow T_*}")#text(".")],
[#text("(iii) If ")#mi("{T_* < \\infty}")#text(", then we have the ")#emph[#text("weak Beale-Kato-Majda criterion")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla u \\right\\|_{L^1_t L^\\infty_x( [0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2} )} = +\\infty.", block: true)]]]
)

#text("Furthermore, show that ")#mi("{T_*, u, p}")#text(" do not depend on the particular choice of ")#mi("{s}")#text(", in the sense that if ")#mi("{u_0}")#text(" belongs to both ")#mi("{H^s}")#text(" and ")#mi("{H^{s^{\\prime}}}")#text(" for two integers ")#mi("{s,s^{\\prime} > \\frac{d}{2}+1}")#text(" then the time ")#mi("{T_*}")#text(" and the fields ")#mi("{u,p}")#text(" produced by the above claims are the same for both ")#mi("{s}")#text(" and ")#mi("{s^{\\prime}}")#text(".")
]

#text("We will refine part (iii) of the above exercise in the next section. It is a major open problem as to whether the case ")#mi("{T_* < \\infty}")#text(" (i.e., finite time blowup) can actually occur. (It is important here that we have some spatial decay at infinity, as represented here by the presence of the ")#mi("{H^s_x}")#text(" norm; when the solution is allowed to diverge at spatial infinity, it is not difficult to construct smooth solutions to the Euler equations that blow up in finite time; see e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=973917")[#text("this article of Stuart")]#text(" for an example.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 11")]#text(" The condition ")#mi("{s > \\frac{d}{2}+1}")#text(" that recurs in the above results can be explained using the heuristics from Section 5 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text(". Assume that a given time ")#mi("{t}")#text(", the velocity field ")#mi("{u}")#text(" fluctuates at a spatial frequency ")#mi("{N \\gtrsim 1}")#text(", with the fluctuations being of amplitude ")#mi("{A}")#text(". (We however permit the velocity field ")#mi("{u}")#text(" to contain a “bulk” low frequency component which can have much higher amplitude than ")#mi("{u}")#text("; for instance, the first component ")#mi("{u_1}")#text(" of ")#mi("{u}")#text(" might take the form ")#mi("{u_1 = B + A \\cos( N x_2)}")#text(" where ")#mi("{B}")#text(" is a quantity much larger than ")#mi("{A}")#text(".) Suppose one considers the trajectories of two particles ")#mi("{P,Q}")#text(" whose separation at time zero is comparable to the wavelength ")#mi("{1/N}")#text(" of the frequency oscillation. Then the relative velocities of ")#mi("{P,Q}")#text(" will differ by about ")#mi("{A}")#text(", so one would expect the particles to stay roughly the same distance from each other up to time ")#mi("{\\sim \\frac{1}{AN}}")#text(", and then exhibit more complicated and unpredictable behaviour after that point. Thus the natural time scale ")#mi("{T}")#text(" here is ")#mi("{T \\sim \\frac{1}{AN}}")#text(", so one only expects to have a reasonable local well-posedness theory in the regime ")#metadata(none) <tao-1367485dc3c39a2a918a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\frac{1}{AN} \\gtrsim 1.")]]

#text("On the other hand, if ")#mi("{u_0}")#text(" lies in ")#mi("{H^s}")#text(", and the frequency ")#mi("{N}")#text(" fluctuations are spread out over a set of volume ")#mi("{V}")#text(", the heuristics from the previous notes predict that")

#align(center)[#tao-fit-display[#mitex("N^s A V^{1/2} \\lesssim 1.")]]

#text("The uncertainty principle predicts ")#mi("{V \\gtrsim N^{-d}}")#text(", and so")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{AN} \\gtrsim N^{s - \\frac{d}{2} - 1}.")]]

#text("Thus we force the regime ")#link(<tao-1367485dc3c39a2a918a>)[#text("(11)")]#text(" to occur if ")#mi("{s > \\frac{d}{2}+1}")#text(", and barely have a chance of doing so in the endpoint case ")#mi("{s = \\frac{d}{2}+1}")#text(", but would not expect to have a local theory (at least using the sort of techniques deployed in this section) for ")#mi("{s < \\frac{d}{2} + 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Use similar heuristics to explain the relevance of quantities of the form ")#tao-math("{\\left\\| \\nabla u \\right\\|_{L^1_t L^\\infty_x}}", block: false)#text(" that occurs in various places in this section.")
]

#text("Because the solutions constructed in Exercise ")#link(<tao-c1f5def06c9c8066f238>)[#text("10")]#text(" are limits (in rather strong topologies) of smooth solutions, it is fairly easy to extend estimates and conservation laws that are known for smooth solutions to these slightly less regular solutions. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" ")#metadata(none) <tao-14de40b705b5a6ca9b0f>#text(" Let ")#mi("{s, u_0, T_*, u, p}")#text(" be as in Exercise ")#link(<tao-c1f5def06c9c8066f238>)[#text("10")]#text(".")

#list(
[#text("(i) (Energy conservation) Show that ")#tao-math("{\\left\\|u(t)\\right\\|_{L^2_x({\\bf R}^d \\rightarrow {\\bf R}^d)} = \\left\\| u_0 \\right\\|_{L^2_x({\\bf R}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" for all ")#mi("{0 \\leq t < T_*}")#text(".")],
[#text("(ii) Show that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\exp( O_{s,d}( \\int_0^t \\left\\| \\nabla u(t^{\\prime})\\right\\|_{L^\\infty_x({\\bf R}^d \\rightarrow {\\bf R}^{d^2})}\\ dt^{\\prime} )) \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}", block: true)]]

#text("for all ")#mi("{0 \\leq t < T_*}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14 (Vanishing viscosity limit)")]#text(" Let the notation and hypotheses be as in Corollary ")#link(<tao-7b5454f75089acf2693b>)[#text("3")]#text(". For each ")#mi("{\\nu>0}")#text(", let ")#mi("{u^{(\\nu)}: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(", ")#mi("{p^{(\\nu)}: [0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be the solution to ")#link(<tao-5bda84779c07d3fa658d>)[#text("(3)")]#text(" with this choice of viscosity and with initial data ")#mi("{u_0}")#text(". Show that as ")#mi("{\\nu \\rightarrow 0}")#text(", ")#mi("{u^{(\\nu)}}")#text(" and ")#mi("{p^{(\\nu)}}")#text(" converge locally uniformly to ")#mi("{u,p}")#text(", and similarly for all derivatives of ")#mi("{u^{(\\nu)}}")#text(" and ")#mi("{p^{(\\nu)}}")#text(". (In other words, there is actually no need to pass to a subsequence as is done in the proof of Corollary ")#link(<tao-7b5454f75089acf2693b>)[#text("3")]#text(".) ")#emph[#text("Hint:")]#text(" apply the energy method to control the difference ")#mi("{u^{(\\nu)} - u}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Local existence for forced Euler)")]#text(" Let ")#mi("{u_0 \\in H^\\infty_x({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence-free, and let ")#mi("{F \\in C^\\infty_{t,loc} H^\\infty([0,+\\infty) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", thus ")#mi("{F}")#text(" is smooth and for any ")#mi("{T>0}")#text(" and any integer ")#mi("{j \\geq 0}")#text(" and ")#mi("{s>0}")#text(", ")#mi("{\\partial_t^j F \\in C^0_t H^s_x([0,T] \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(". Show that there exists ")#mi("{T>0}")#text(" and a smooth solution ")#mi("{(u,p)}")#text(" to the forced Euler equation")

#tao-aligned(keep: true)[


#tao-math("\\partial_t u + (u \\cdot \\nabla) u  & = - \\nabla p + F", block: true)



#tao-math("\\nabla \\cdot u  & = 0", block: true)



#tao-math("p  & = - \\Delta^{-1} \\nabla \\cdot \\nabla \\cdot (u \\otimes u)", block: true)



#tao-math("u(0)  & = u_0.", block: true)
]

#emph[#text("Note:")]#text(" one will first need a local existence theory for the forced Navier-Stokes equation. It is also possible to develop forced analogues of most of the other results in this section, but we will not detail this here.")
]

#heading(level: 1)[#strong[#text(" — 2. The Beale-Kato-Majda blowup criterion — ")]]

#text("In Exercise ")#link(<tao-c1f5def06c9c8066f238>)[#text("10")]#text(" we saw that we could continue ")#mi("{H^s}")#text(" solutions, ")#mi("{s > \\frac{d}{2}+1}")#text(" to the Euler equations indefinitely in time, unless the integral ")#tao-math("{\\int_0^{T_*} \\left\\| \\nabla u(t) \\right\\|_{L^\\infty_x({\\bf R}^d \\rightarrow {\\bf R}^{d^2})}\\ dt}", block: false)#text(" became infinite at some finite time ")#mi("{T_*}")#text(". There is an important refinement of this blowup criterion, ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=763762")[#text("due to Beale, Kato, and Majda")]#text(", in which the tensor ")#mi("{\\nabla u}")#text(" is replaced by the ")#link("https://en.wikipedia.org/wiki/Vorticity")[#text("vorticity two-form")]#text(" (or vorticity, for short)")

#align(center)[#tao-fit-display[#mitex("\\omega := \\nabla \\wedge u,")]]

#text("that is to say ")#mi("{\\omega}")#text(" is essentially the anti-symmetric component of ")#mi("{\\nabla u}")#text(". Whereas ")#mi("{\\nabla u}")#text(" is the tensor field")

#align(center)[#tao-fit-display[#mitex("(\\nabla u)_{ij} = \\partial_i u_j,")]]

#mi("{\\omega}")#text(" is the anti-symmetric tensor field ")#metadata(none) <tao-f77f484ce99781cbf892>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\omega_{ij} = \\partial_i u_j - \\partial_j u_i.")]]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 16")]#text(" In two dimensions, ")#mi("{\\omega}")#text(" is essentially a scalar, since ")#mi("{\\omega_{11}=\\omega_{22}=0}")#text(" and ")#mi("{\\omega_{12} = -\\omega_{21}}")#text(". As such, it is common in fluid mechanics to refer to the scalar field ")#mi("{\\omega_{12} = \\partial_1 u_2 - \\partial_2 u_1}")#text(" as the vorticity, rather than the two form ")#mi("{\\omega}")#text(". In three dimensions, there are three independent components ")#mi("{\\omega_{23}, \\omega_{31}, \\omega_{12}}")#text(" of the vorticity, and it is common to view ")#mi("{\\omega}")#text(" as a vector field ")#mi("{\\vec \\omega = (\\omega_{23}, \\omega_{31}, \\omega_{12})}")#text(" rather than a two-form in this case (actually, to be precise ")#mi("{\\omega}")#text(" would be a ")#link("https://en.wikipedia.org/wiki/Pseudovector")[#text("pseudovector")]#text(" field rather than a vector field, because it behaves slightly differently to vectors with respect to changes of coordinate). With this interpretation, the vorticity is now the curl of the velocity field ")#mi("{u}")#text(". From a differential geometry viewpoint, one can view the two-form ")#mi("{\\omega}")#text(" as an antisymmetric bilinear map from vector fields ")#mi("{X,Y}")#text(" to scalar functions ")#mi("{\\omega(X,Y)}")#text(", and the relation between the vorticity two-form ")#mi("{\\omega}")#text(" and the vorticity (pseudo-)vector field ")#mi("{\\vec \\omega}")#text(" in ")#mi("{{\\bf R}^3}")#text(" is given by the relation")

#align(center)[#tao-fit-display[#mitex("\\omega(X,Y) = \\mathrm{vol}( \\vec \\omega, X, Y )")]]

#text("for arbitrary vector fields ")#mi("{X,Y}")#text(", where ")#mi("{\\mathrm{vol} = dx_1 \\wedge dx_2 \\wedge dx_3}")#text(" is the volume form on ")#mi("{{\\bf R}^3}")#text(", which can be viewed in three dimensions as an antisymmetric trilinear form on vector fields. The fact that ")#mi("{\\vec \\omega}")#text(" is a pseudovector rather than a vector then arises from the fact that the volume form changes sign upon applying a reflection.")
]

#text("The point is that vorticity behaves better under the Euler flow than the full derivative ")#mi("{\\nabla u}")#text(". Indeed, if one takes a smooth solution to the Euler equation in coordinates")

#align(center)[#tao-fit-display[#mitex("\\partial_t u_j + u_k \\partial_k u_j = -\\partial_j p")]]

#text("and applies ")#mi("{\\partial_i}")#text(" to both sides, one obtains")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\partial_i u_j + \\partial_i u_k \\partial_k u_j + u_k \\partial_k \\partial_i u_j = -\\partial_i \\partial_j p.")]]

#text("If one interchanges ")#mi("{i,j}")#text(" and then subtracts, the pressure terms disappear, and one is left with")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega_{ij} + \\partial_i u_k \\partial_k u_j - \\partial_j u_k \\partial_k u_i + u_k \\partial_k \\omega_{ij} = 0")]]

#text("which we can rearrange using the material derivative ")#mi("{D_t = \\partial_t + u_k \\partial_k}")#text(" as")

#align(center)[#tao-fit-display[#mitex("D_t \\omega_{ij} - \\partial_j u_k \\partial_k u_i + \\partial_i u_k \\partial_k u_j.")]]

#text("Writing ")#mi("{\\partial_k u_i = -\\omega_{ik} + \\partial_i u_k}")#text(" and ")#mi("{\\partial_k u_j = - \\omega_{jk} + \\partial_j u_k}")#text(", this becomes the ")#emph[#text("vorticity equation")]#text(" ")#metadata(none) <tao-8afc206291bb1adff485>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("D_t \\omega_{ij} + \\omega_{ik} \\partial_j u_k - \\omega_{jk} \\partial_i u_k = 0.")]]

#text("The vorticity equation is particularly simple in two and three dimensions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Transport of vorticity)")]#text(" ")#metadata(none) <tao-cbd31fe312a05a4718b4>#text(" Let ")#mi("{u,p}")#text(" be a smooth solution to Euler equation in ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{\\omega}")#text(" be the vorticity two-form.")

#list(
[#text("(i) If ")#mi("{d=2}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("D_t \\omega_{12} = 0.")]]],
[#text("(ii) If ")#mi("{d=3}")#text(", show that")

#align(center)[#tao-fit-display[#mitex("D_t \\vec \\omega = (\\vec \\omega \\cdot \\nabla) u")]]

#text("where ")#mi("{\\vec \\omega = (\\omega_{23}, \\omega_{31}, \\omega_{12})}")#text(" is the vorticity pseudovector.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" One can interpret the vorticity equation in the language of differential geometry, which is a more covenient formalism when working on more general Riemann manifolds than ")#mi("{{\\bf R}^d}")#text(". To be consistent with the conventions of differential geometry, we now write the components of the velocity field ")#mi("{u}")#text(" as ")#mi("{u^i}")#text(" rather than ")#mi("{u_i}")#text(" (and the coordinates of ")#mi("{{\\bf R}^d}")#text(" as ")#mi("{x^i}")#text(" rather than ")#mi("{x_i}")#text("). Define the ")#emph[#text("covelocity ")#mi("{1}")#text("-form")]#text(" ")#mi("{v}")#text(" as")

#align(center)[#tao-fit-display[#mitex("v = \\eta_{ij} u^i dx^j")]]

#text("where ")#mi("{\\eta_{ij}}")#text(" is the Euclidean metric tensor (in the standard coordinates, ")#mi("{\\eta_{ij} = \\delta_{ij}}")#text(" is the Kronecker delta, though ")#mi("{\\eta_{ij}}")#text(" can take other values than ")#mi("{\\delta_{ij}}")#text(" if one uses a different coordinate system). Thus in coordinates, ")#mi("{v_i = \\eta_{ij} u^j}")#text("; the covelocity field is thus the ")#link("https://en.wikipedia.org/wiki/Musical_isomorphism")[#text("musical isomorphism")]#text(" applied to the velocity field. The vorticity ")#mi("{2}")#text("-form ")#mi("{\\omega}")#text(" can then be interpreted as the ")#link("https://en.wikipedia.org/wiki/Exterior_derivative")[#text("exterior derivative")]#text(" of the covelocity, thus")

#align(center)[#tao-fit-display[#mitex("\\omega = dv")]]

#text("or in coordinates")

#align(center)[#tao-fit-display[#mitex("\\omega_{ij} = \\partial_i v_j - \\partial_j v_i.")]]

#text("The Euler equations can be rearranged as ")#metadata(none) <tao-61c857311c992564367e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\partial_t v + \\mathcal{L}_u v = - d \\tilde p,")]]

#text("where ")#mi("{\\mathcal{L}_u}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Lie_derivative")[#text("Lie derivative")]#text(" along ")#mi("{u}")#text(", which for ")#mi("{1}")#text("-forms is given in coordinates as")

#align(center)[#tao-fit-display[#mitex("\\mathcal{L}_u v_i = u^j \\partial_j v_i + (\\partial_i u^j) v_j")]]

#text("and ")#mi("{\\tilde p}")#text(" is the modified pressure")

#align(center)[#tao-fit-display[#mitex("\\tilde p := p - \\frac{1}{2} u^j v_j.")]]

#text("If one takes exterior derivatives of both sides of ")#link(<tao-61c857311c992564367e>)[#text("(14)")]#text(" using the basic differential geometry identities ")#mi("{d \\mathcal{L}_u = \\mathcal{L}_u d}")#text(" and ")#mi("{dd = 0}")#text(", one obtains the vorticity equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\omega + \\mathcal{L}_u \\omega = 0")]]

#text("where the Lie derivative for ")#mi("{2}")#text("-forms is given in coordinates as")

#align(center)[#tao-fit-display[#mitex("\\mathcal{L}_u \\omega_{ik} = u^j \\partial_j \\omega_{ik} + (\\partial_i u^j) \\omega_{jk} + (\\partial_k u^j) \\omega_{ij}")]]

#text("and so we recover ")#link(<tao-8afc206291bb1adff485>)[#text("(13)")]#text(" after some relabeling.")
]

#text("We now present the Beale-Kato-Majda condition.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 19 (Beale-Kato-Majda)")]#text(" ")#metadata(none) <tao-fa9f17e822dcb47d89b3>#text(" Let ")#mi("{s > \\frac{d}{2}+1}")#text(" be an integer, and let ")#mi("{u_0 \\in H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(" be divergence free. Let ")#mi("{u \\in C^0_{t,loc} H^s([0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^d)}")#text(", ")#mi("{p \\in C^0_{t,loc} H^s([0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R})}")#text(" be the maximal Cauchy development from Exercise ")#link(<tao-c1f5def06c9c8066f238>)[#text("10")]#text(", and let ")#mi("{\\omega}")#text(" be the vorticity.")

#list(
[#text("(i) For any ")#mi("{0 \\leq T < T_*}")#text(", one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#tao-math("\\left\\| u(T) \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)} \\lesssim_{s,d}", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\exp(O_{s,d}( T (1 + \\left\\| u_0 \\right\\|_{L^2({\\bf R}^d \\rightarrow {\\bf R}^d)} ) ))", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\exp(A \\exp( O_{s,d}( \\int_0^T \\left\\| \\omega(t)\\right\\|_{L^\\infty({\\bf R}^d \\rightarrow \\bigwedge^2 {\\bf R}^d)}\\ dt )))", block: true)]]

#text("where")#linebreak()#text(" ")#tao-math("\\displaystyle A := \\log (2 + \\left\\| u_0 \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}).", block: false)],
[#text("(ii) If ")#mi("{T_* < \\infty}")#text(", then we have the ")#emph[#text("Beale-Kato-Majda criterion")]

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\omega\\right\\|_{L^1_t L^\\infty_x( [0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2} ) }= +\\infty.", block: true)]]]
)
]

#text("The double exponential in (i) is not a typo! It is an open question though as to whether this double exponential bound can be at all improved, even in the simplest case of two spatial dimensions.")

#text("We turn to the proof of this theorem. Part (ii) will be implied by part (i), since if ")#tao-math("{\\left\\| \\omega\\right\\|_{L^1_t L^\\infty_x( [0,T_*) \\times {\\bf R}^d \\rightarrow {\\bf R}^{d^2} )}}", block: false)#text(" is finite then part (i) gives a uniform bound on ")#tao-math("{\\left\\|u(t)\\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)}}", block: false)#text(" as ")#mi("{t \\rightarrow T_*}")#text(", preventing finite time blowup. So it suffices to prove part (i). To do this, it suffices to do so for ")#mi("{H^\\infty}")#text(" solutions, since one can then pass to a limit (using the strong continuity in ")#mi("{C^0_t H^s_x}")#text(") to establish the general case. In particular, we can now assume that ")#mi("{u,p,u_0}")#text(" are smooth.")

#text("We would like to convert control on ")#mi("{\\omega}")#text(" back to control of the full derivative ")#mi("{\\nabla u}")#text(". If one takes divergences ")#mi("{\\partial_i \\omega_{ij}}")#text(" of the vorticity using ")#link(<tao-f77f484ce99781cbf892>)[#text("(12)")]#text(" and the divergence-free nature ")#mi("{\\partial_i u_i = 0}")#text(" of ")#mi("{u}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("\\partial_i \\omega_{ij} = \\Delta u_j.")]]

#text("Thus, we can recover the derivative ")#mi("{\\partial_k u_j}")#text(" from the vorticity by the formula ")#metadata(none) <tao-e72f8525f2ea4a2d0bbe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("\\partial_k u_j = \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij},")]]

#text("where one can define ")#mi("{\\Delta^{-1} \\partial_i \\partial_k}")#text(" via the Fourier transform as a multiplier bounded on every ")#mi("{H^s}")#text(" space.")#linebreak()#text(" If the operators ")#mi("{\\Delta^{-1} \\partial_i \\partial_k}")#text(" were bounded in ")#mi("{L^\\infty_x({\\bf R}^d \\rightarrow {\\bf R})}")#text(", then we would have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\nabla u(t) \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow {\\bf R}^{d^2})} \\lesssim_d \\left\\| \\omega(t)\\right\\|_{L^\\infty({\\bf R}^d \\rightarrow \\bigwedge^2 {\\bf R}^d)}", block: true)]]

#text("and the claimed bound ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#uths")[#text("(15)")]#text(" would follow from Theorem ")#link(<tao-292aee119f4956fd01b2>)[#text("1")]#text("(ii) (with one exponential to spare). Unfortunately, ")#mi("{\\Delta^{-1} \\partial_i \\partial_j}")#text(" is not quite bounded on ")#mi("{L^\\infty}")#text(". Indeed, from Exercise 18 of Notes 1 we have the formula")

#align(center)[#tao-fit-display[#tao-math("\\Delta^{-1} \\partial_i \\partial_k \\phi(y) = \\lim_{\\varepsilon \\rightarrow 0} \\int_{\\left|x\\right| > \\varepsilon} K_{ik}(x) \\phi(x+y)\\ dx + \\frac{\\delta_{ik}}{d} \\phi(y)", block: true)]]

#text("for any test function ")#mi("{\\phi}")#text(" and ")#mi("{y \\in {\\bf R}^d}")#text(", where ")#mi("{K_{ik}}")#text(" is the singular kernel")

#align(center)[#tao-fit-display[#tao-math("K_{ik}(x) := -\\frac{1}{\\left|S^{d-1}\\right|} (\\frac{d x_i x_k}{\\left|x\\right|^{d+2}} - \\frac{\\delta_{ik}}{\\left|x\\right|^d}).", block: true)]]

#text("If one sets ")#mi("{\\phi}")#text(" to be a (smooth approximation) to the signum ")#mi("{\\mathrm{sgn}(K_{ik})}")#text(" restricted to an annulus ")#tao-math("{\\varepsilon \\leq \\left|x\\right| \\leq R}", block: false)#text(", we conclude that the operator norm of ")#mi("{\\Delta^{-1} \\partial_i \\partial_k}")#text(" is at least as large as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\varepsilon \\leq \\left|x\\right| \\leq R} |K_{ik}(x)|\\ dx.", block: true)]]

#text("But one can calculate using polar coordinates that this expression diverges like ")#mi("{\\log \\frac{R}{\\varepsilon}}")#text(" in the limit ")#mi("{\\varepsilon \\rightarrow 0}")#text(", ")#mi("{R \\rightarrow \\infty}")#text(", giving unboundedness.")#linebreak()#text(" As it turns out, though, the Gronwall argument used to establish Theorem ")#link(<tao-292aee119f4956fd01b2>)[#text("1")]#text("(ii) can just barely tolerate an additional “logarithmic loss” of the above form, albeit at the cost of worsening the exponential term to a double exponential one. The key lemma is the following result that quantifies the logarithmic divergence indicated by the previous calculation, and is similar in spirit to a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=579997")[#text("well known inequality of Brezis and Wainger")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 20 (Near-boundedness of ")#mi("{\\Delta^{-1} \\partial_i \\partial_k}")#text(")")]#text(" ")#metadata(none) <tao-025da59d511235471cad>#text(" For any ")#mi("{s > \\frac{d}{2}+1}")#text(", one has ")#metadata(none) <tao-bd1505eba5af8be0aed5>

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow {\\bf R}^{d^2})}  & \\lesssim_{s,d} \\left\\| \\omega \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow \\bigwedge^2 {\\bf R}^d)} \\log(2 + \\left\\| u \\right\\|_{H^s_x({\\bf R}^d \\rightarrow {\\bf R}^d)})", block: true, numbering: n => [#text("(17)")])



#tao-math(" & + \\left\\| u \\right\\|_{L^2_x({\\bf R}^d \\rightarrow {\\bf R}^d)} + 1.", block: true)
]
]

#text("The lower order terms ")#tao-math("{\\left\\| u \\right\\|_{L^2_x({\\bf R}^d \\rightarrow {\\bf R}^d)} + 1}", block: false)#text(" will be easily dealt with in practice; the main point is that one can almost bound the ")#mi("{L^\\infty}")#text(" norm of ")#mi("{\\Delta^{-1} \\partial_i \\partial_k \\omega}")#text(" by that of ")#mi("{\\omega}")#text(", up to a logarithmic factor.")

#emph[#text("Proof:")]#text(" By a limiting argument we may assume that ")#mi("{u}")#text(" (and hence ")#mi("{\\omega}")#text(" are test functions. We apply Littlewood-Paley decomposition to write")

#align(center)[#tao-fit-display[#mitex("\\omega = P_{\\leq 1} \\omega + \\sum_{N>1} P_N \\omega")]]

#text("and hence by the triangle inequality we may bound the left-hand side of ")#link(<tao-bd1505eba5af8be0aed5>)[#text("(17)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| P_{\\leq 1} \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^\\infty} + \\sum_{N>1} \\left\\| P_{N} \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^\\infty}", block: true)]]

#text("where we omit the domain and range from the function space norms for brevity.")#linebreak()#text(" By Bernstein’s inequality we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| P_{\\leq 1} \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^\\infty}  & \\lesssim_d \\left\\| P_{\\leq 1} \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^2} \\lesssim_d \\left\\| P_{\\leq 1} \\omega \\right\\|_{L^2}", block: true)



#tao-math(" & \\lesssim_d \\left\\| u \\right\\|_{L^2}.", block: true)
]

#text("Also, from Bernstein and Plancherel we have")

#tao-aligned(keep: true)[


#tao-math("\\left\\| P_{N} \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^\\infty}  & \\lesssim_d N^{d/2} \\left\\| P_{N} \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^2}", block: true)



#tao-math(" & \\lesssim_d N^{d/2} \\left\\| P_{N} \\omega \\right\\|_{L^2}", block: true)



#tao-math(" & \\lesssim_d N^{d/2+1-s} \\left\\| u \\right\\|_{H^s}", block: true)
]

#text("and hence by geometric series we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{N > N_0} \\left\\| P_{N} \\Delta^{-1} \\partial_i \\partial_k \\omega_{ij} \\right\\|_{L^\\infty} \\lesssim_{s,d} N_0^{d/2+1-s} \\left\\| u \\right\\|_{H^s}", block: true)]]

#text("for any ")#mi("{N_0>1}")#text(". This gives an acceptable contribution if we select ")#tao-math("{N_0 := (2+\\left\\| u \\right\\|_{H^s})^{1/(s-d/2-1)}}", block: false)#text(". This leaves ")#tao-math("{O_{s,d}( \\log(2 + \\left\\| \\phi\\right\\|_{H^s}) )}", block: false)#text(" remaining values of ")#mi("{N}")#text(" to control, so if one can bound ")#metadata(none) <tao-2dd38553ab884146c33d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left\\| P_{N} \\Delta^{-1} \\partial_i \\partial_k w \\right\\|_{L^\\infty} \\lesssim_d \\left\\| w \\right\\|_{L^\\infty}", block: true)]]

#text("for each ")#mi("{N > 1}")#text(" and a test function ")#mi("{w}")#text(", we will be done.")#linebreak()#text(" Observe from applying the scaling ")#mi("{x \\mapsto Nx/2}")#text(" (that is, replacing ")#mi("{x \\mapsto w(x)}")#text(" with ")#mi("{x \\mapsto w(2x/N)}")#text(" that to prove ")#link(<tao-2dd38553ab884146c33d>)[#text("(18)")]#text(" for all ")#mi("{N}")#text(" it suffices to do so for ")#mi("{N=2}")#text(". By Fourier analysis, the function ")#mi("{P_2 \\Delta^{-1} \\partial_i \\partial_k w}")#text(" is the convolution of ")#mi("{w}")#text(" with the inverse Fourier transform ")#mi("{K}")#text(" of the function")

#align(center)[#tao-fit-display[#tao-math("\\xi \\mapsto (\\phi(\\xi/2) - \\phi(\\xi)) \\frac{\\xi_i \\xi_k}{\\left|\\xi\\right|^2}.", block: true)]]

#text("This function is a test function, so ")#mi("{K}")#text(" is a Schwartz function, and the claim now follows from Young’s inequality. ")#mi("\\Box")#linebreak()#text(" We return now to the proof of ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#uths")[#text("(15)")]#text(". We adapt the proof of Proposition ")#link(<tao-292aee119f4956fd01b2>)[#text("1")]#text("(i). As in that proposition, we introduce the higher energy")

#align(center)[#tao-fit-display[#mitex("\\partial_t E(t) = \\sum_{k=0}^s \\int_{{\\bf R}^d} \\nabla^k u \\cdot \\nabla^k \\partial_t u\\ dx.")]]

#text("We no longer have the viscosity term as ")#mi("{\\nu=0}")#text(", but that term was discarded anyway in the analysis. From ")#link(<tao-1e22560cee2c4b727c6a>)[#text("(4)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E(t) \\leq O_{s,d}( E(t) \\left\\| \\nabla u(t) \\right\\|_{L^\\infty} ).", block: true)]]

#text("Applying ")#link(<tao-e72f8525f2ea4a2d0bbe>)[#text("(16)")]#text(", ")#link(<tao-bd1505eba5af8be0aed5>)[#text("(17)")]#text(" one thus has")

#align(center)[#tao-fit-display[#tao-math("\\partial_t E(t) \\leq O_{s,d}( E(t) (\\left\\| \\omega(t) \\right\\|_{L^\\infty} \\log(2 + E(t)) + \\left\\| u(t) \\right\\|_{L^2} + 1) ).", block: true)]]

#text("From Exercise ")#link(<tao-14de40b705b5a6ca9b0f>)[#text("13")]#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u(t) \\right\\|_{L^2} = \\left\\| u_0 \\right\\|_{L^2}.", block: true)]]

#text("By the chain rule, one then has")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\log(2+E(t)) \\leq O_{s,d}( \\left\\| \\omega(t) \\right\\|_{L^\\infty} \\log(2 + E(t)) + \\left\\| u_0 \\right\\|_{L^2} + 1 )", block: true)]]

#text("and hence by Gronwall’s inequality one has")

#align(center)[#tao-fit-display[#tao-math("\\log(2+E(T)) \\lesssim_{s,d} (T (\\left\\|u_0\\right\\|_{L^2}+1) +", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\log(2+E(0))) \\exp( O_{s,d}( \\left\\|\\omega \\right\\|_{L^1_t L^\\infty_x([0,T] \\times {\\bf R}^d \\rightarrow \\bigwedge^2 {\\bf R}^d)} ) ).", block: true)]]

#text("The claim ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#uths")[#text("(15)")]#text(" follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 21")]#text(" The Beale-Kato-Majda criterion can be sharpened a little bit, by replacing the sup norm ")#tao-math("{\\left\\|\\omega(t) \\right\\|_{L^\\infty({\\bf R}^d \\rightarrow \\bigwedge^2 {\\bf R}^d)}}", block: false)#text(" with slightly smaller norms, such as the ")#link("https://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("bounded mean oscillation (BMO)")]#text(" norm of ")#mi("{\\omega(t)}")#text(", basically by improving the right-hand side of Lemma ")#link(<tao-025da59d511235471cad>)[#text("20")]#text(" slightly. See for instance ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1953068")[#text("this paper of Planchon")]#text(" and the references therein.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" An inspection of the proof of Theorem ")#link(<tao-fa9f17e822dcb47d89b3>)[#text("19")]#text(" reveals that the same result holds if the Euler equations are replaced by the Navier-Stokes equations; the energy estimates acquire an additional “")#mi("{C}")#text("” term by doing so (as in the proof of Proposition ")#link(<tao-292aee119f4956fd01b2>)[#text("1")]#text("), but the sign of that term is favorable.")
]

#text("We now apply the Beale-Kato-Majda criterion to obtain global well-posedness for the Euler equations in two dimensions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 23 (Global well-posedness)")]#text(" ")#metadata(none) <tao-c37f35d1c320e722729f>#text(" Let ")#mi("{u_0, s, T_*, u, p}")#text(" be as in Exercise ")#link(<tao-c1f5def06c9c8066f238>)[#text("10")]#text(". If ")#mi("{d=2}")#text(", then ")#mi("{T_* = +\\infty}")#text(".")
]

#text("This theorem will be immediate from Theorem ")#link(<tao-fa9f17e822dcb47d89b3>)[#text("19")]#text(" and the following conservation law:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 24 (Conservation of vorticity distribution)")]#text(" ")#text(" Let ")#mi("{u_0, s, T_*, u, p}")#text(" be as in Exercise ")#link(<tao-c1f5def06c9c8066f238>)[#text("10")]#text(" with ")#mi("{d=2}")#text(". Then one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\omega_{12}(t) \\right\\|_{L^q({\\bf R}^2 \\rightarrow {\\bf R})} = \\left\\| \\omega_{12}(0) \\right\\|_{L^q({\\bf R}^2 \\rightarrow {\\bf R})}", block: true)]]

#text("for all ")#mi("{2 \\leq q \\leq \\infty}")#text(" and ")#mi("{0 \\leq t < T_*}")#text(".")
]

#emph[#text("Proof:")]#text(" By a limiting argument it suffices to show the claim for ")#mi("{q < \\infty}")#text(", thus we need to show")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^2} \\left|\\omega_{12}(t, x)\\right|^q\\ dx = \\int_{{\\bf R}^2} \\left|\\omega_{12}(0, x)\\right|^q\\ dx.", block: true)]]

#text("By another limiting argument we can take ")#mi("{u}")#text(" to be an ")#mi("{H^\\infty}")#text(" solution. By the monotone convergence theorem (and Sobolev embedding), it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} F( \\omega_{12}(t, x) )\\ dx = \\int_{{\\bf R}^2} F( \\omega_{12}(0, x) )\\ dx")]]

#text("whenever ")#mi("{F: {\\bf R} \\rightarrow {\\bf R}}")#text(" is a test function that vanishes in a neighbourhood of the origin ")#mi("{0}")#text(". Note that as ")#mi("{\\omega_{12}}")#text(" and all its derivatives are in ")#mi("{L^\\infty_t H^\\infty_x}")#text(" on ")#mi("{[0,T] \\times {\\bf R}^2}")#text(" for every ")#mi("{0 < T < T_*}")#text(", it is Lipschitz in space and time, which among other things implies that the level sets ")#mi("{\\{ (t,x) \\in [0,T] \\times {\\bf R}^2: \\omega_{12}| \\geq \\varepsilon \\}}")#text(" are compact for every ")#mi("{\\varepsilon>0}")#text(", and so ")#mi("{F(\\omega_{12})}")#text(" is smooth and compactly supported in ")#mi("{[0,T] \\times {\\bf R}^2}")#text(". We may therefore may differentiate under the integral sign to obtain")

#align(center)[#tao-fit-display[#mitex("\\partial_t \\int_{{\\bf R}^2} F( \\omega_{12}(t, x) )\\ dx = \\int_{{\\bf R}^2} F^{\\prime}( \\omega_{12} ) \\partial_t \\omega_{12}\\ dx")]]

#text("where we omit explicit dependence on ")#mi("{t,x}")#text(" for brevity. By Exercise ")#link(<tao-cbd31fe312a05a4718b4>)[#text("17")]#text("(i), the right-hand side is")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} F^{\\prime}( \\omega_{12} ) (u \\cdot \\nabla) \\omega_{12}\\ dx")]]

#text("which one can write as a total derivative")

#align(center)[#tao-fit-display[#mitex("\\int_{{\\bf R}^2} (u \\cdot \\nabla) F(\\omega_{12})\\ dx")]]

#text("which vanishes thanks to integration by parts and the divergence-free nature of ")#mi("{u}")#text(". The claim follows. ")#mi("\\Box")#linebreak()#text(" The above proposition shows that in two dimensions, ")#tao-math("{\\left\\| \\omega(t)\\right\\|_{L^\\infty({\\bf R}^2 \\rightarrow \\bigwedge^2{\\bf R}^2)}}", block: false)#text(" is constant, and so the integral ")#tao-math("{\\int_0^{T_*} \\left\\| \\omega(t)\\right\\|_{L^\\infty({\\bf R}^2 \\rightarrow \\bigwedge^2{\\bf R}^2)}\\ dt}", block: false)#text(" cannot diverge for finite ")#mi("{T_*}")#text(". Applying Theorem ")#link(<tao-fa9f17e822dcb47d89b3>)[#text("19")]#text(", we obtain Theorem ")#link(<tao-c37f35d1c320e722729f>)[#text("23")]#text(". We remark that global regularity for two-dimensional Euler was established well before the Beale-Kato-Majda theorem, starting with the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1545430")[#text("work of Wolibner")]#text(".")

#text("One can adapt this argument to the Navier-Stokes equations:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" ")#metadata(none) <tao-75a288c0d6898c5f7b05>#text(" Let ")#mi("{s > 2}")#text(" be an integer, let ")#mi("{\\nu>0}")#text(", let ")#mi("{u_0 \\in H^s({\\bf R}^2 \\rightarrow {\\bf R}^2)}")#text(" be divergence-free, and let ")#mi("{u: [0,T_*) \\times {\\bf R}^2 \\rightarrow {\\bf R}^2}")#text(", ")#mi("{p: [0,T_*) \\times {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" be a maximal Cauchy development to the Navier-Stokes equations with initial data ")#mi("{u_0}")#text(". Let ")#mi("{\\omega}")#text(" be the vorticity.")

#list(
[#text("(i) Establish the vorticity equation ")#mi("{D_t \\omega_{12} = \\nu \\Delta \\omega_{12}}")#text(".")],
[#text("(ii) Show that ")#tao-math("{\\left\\| \\omega_{12}(t) \\right\\|_{L^q({\\bf R}^2 \\rightarrow {\\bf R})} \\leq \\left\\| \\omega_{12}(0) \\right\\|_{L^q({\\bf R}^2 \\rightarrow {\\bf R})}}", block: false)#text(" for all ")#mi("{2 \\leq q \\leq \\infty}")#text(" and ")#mi("{0 \\leq t < T_*}")#text(". (Note: to adapt the proof of Proposition ")#link(<tao-f77f484ce99781cbf892>)[#text("12")]#text(", one should restrict attention to functions ")#mi("{F}")#text(" that are convex on the range of ")#mi("{\\omega_{12}}")#text(" on, say, ")#mi("{[0,T] \\times {\\bf R}^2}")#text(". The ")#mi("{q=\\infty}")#text(" case of this inequality can also be established using the ")#link("https://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(" for parabolic equations.)")],
[#text("(iii) Show that ")#mi("{T_* = \\infty}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 26")]#text(" There are other ways to establish global regularity for two-dimensional Navier-Stokes (originally ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=254401")[#text("due to Ladyzhenskaya")]#text("); for instance, the ")#mi("{L^2}")#text(" bound on the vorticity in Exercise ")#link(<tao-75a288c0d6898c5f7b05>)[#text("25")]#text("(ii), combined with energy conservation, gives a uniform ")#mi("{H^1}")#text(" bound on the velocity field, which can then be inserted into (the non-periodic version of) Theorem 38 of ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("Notes 1")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" If ")#mi("{t \\mapsto u(t,x), t \\mapsto p(t,x)}")#text(" solve the Euler equations on some time interval ")#mi("{I}")#text(" with initial data ")#mi("{x \\mapsto u_0(x)}")#text(", then the time-reversed fields ")#mi("{t \\mapsto -u(-t,x), t \\mapsto p(-t,x)}")#text(" solve the Euler equations on the reflected interval ")#mi("{-I}")#text(" with initial data ")#mi("{x \\mapsto -u_0(x)}")#text(". Because of this time reversal symmetry, the local and global well-posedness theory for the Euler equations can also be extended backwards in time; for instance, in two dimensions any ")#mi("{H^\\infty}")#text(" divergence free initial data ")#mi("{u_0}")#text(" leads to an ")#mi("{H^\\infty}")#text(" solution to the Euler equations on the whole time interval ")#mi("{(-\\infty,\\infty)}")#text(". However, the Navier-Stokes equations are very much ")#emph[#text("not")]#text(" time-reversible in this fashion.")
]

#heading(level: 1)[#text("Comments (28)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-505800")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("There is no expression in (2).")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-505902")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 October 2018")])]

#text("Dear Terry,")

#text("Great post! I have a question on Remark 7. It seems to be an open problem if two dimensional Euler equation has unique weak solution assuming only L^p bound on the vorticity, for p<\\infty.")

#emph[#text("[Oops, I meant ")#mi("L^\\infty")#text(" here; now corrected. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed928eda8e15df5bf2160da170b694db3698e2f2708cf09b1bf9699ed507b941-661693d1b15a9ecf2c7cbf5141269b85d60fbf6abef0df6b36dda36c5c179071.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of yasin şale")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-505941")[#strong[#text("yasin şale")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2018")])]

#text("Dear Terry,")

#text("I would like to read your opinions about the proof of Riemann Hypothesis given by M. Atiyah.")

#text("Best regards.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-505971")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2018")])]

#text("Well, I can replace Pro Tao to response your question.According to our observation, Pro Tao seems to be difficult to answer your problem for public,if you meet him in private , he is willing to reply.Because there are many sensitive reasons,although he holds proofs of RH in your hands.On RH,he has 5 ways to approach to RH,every solution seems to constrast to Atiyah’s proof.The second reson , Pro.Tao is the member of Royal committee in England,while Atiyah is also a professor in England.The third reason, he is very old if compare to Tao,so he must respect to Atiyah.According to me,Clay millenium committee will invites Tao to remark Atiyah’sproof,because Pro Tao is the expert on RH,and only members in Clay institue know Atiyah’sproof right or wrong.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-505973")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2018")])]

#text("In order to check Atiyah’s claimed proof of RH, in addition of being expert on RH, it is even more important to be an expert on Todd function and its related functional equations (e.g. Hirzebruch functional equation) on which Atiyah’s claimed proof is based.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-505976")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2018")])]

#text("Hello. You must see the comments on the entry “Polymath15, tenth thread: numerics update.”6 September 2018")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-506618")[#strong[#text("far zeebra")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2018")]

#text("This is mere child’s play. What does the Barrett Series converge to?")

#text("The Barrett Series:")

#text("1-1/2-(1/2)^2 + (1/2)^3 – (1/2)^4 -(1/2)^5 + (1/2)^6 – (1/2)^7 -(1/2)^8 +(1/2)^9 …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3de0971aa98986c59e57f76238c236536bbf74450298b40bccba65aaefdc5ad9-4ea34b276d8ccaca362647255e28225be4a33c216c4e97d34fd82798bf1184c4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of YNWA")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-506712")[#strong[#text("YNWA")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2018")])]

#text("Dear all, you might be interested in this question concerning the Riemann zeta function on MathOverflow: ")#link("https://mathoverflow.net/q/314310/130815")[#text("https://mathoverflow.net/q/314310/130815")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-506742")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2018")])]

#text("Dear Terry,")#linebreak()#text(" Terry Tao-my lovely friend.You have never mett me,but you have a immortal friendliness- a friendliness without border,nothing and anyone can compare it.I am far away with you,I always follow every your step in your jobs.You can image that I am a sattelite.I always support you.In brief, under this great sky,you are lucky to have me,I confirm many times I am the only close friend to you.I know you very well like a clear mirror.No one in the world know that you have good enough on twin prime,navier stokes,birch swinnerton Dyer ,hodge cọnecture,yang mills,collatz conjecture,goldbach,riemann p vs np.But you are stiil silent .You do not want to boast.I like you this point:humble;good virture,patient,gentle,good heart,you have also the sixth sense;you know what someone is doing,but you keep silent.I know that after I write these sentences,many people reject me.Not sense to me.they are still under me with a suppernature head")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8ae7be71b847a3abcc83d829205bb92e53a53e741921a65183cbeb99291c7cb9-818522a0e468c31ee17fb59b57c4e9d683288fc0972489f0bdeb851ed9cea290.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hans")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-507359")[#strong[#text("Hans")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2018")])]

#text("So looking forward for part 4 :-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ad4c3e019150b140bc6294f3e40473e219b48a2efe695fd61fffd95ce371b23c-1911117f007cf12d1cf989d9df9995a20201c986ba4c70c42d080735f7970b92.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sergei Ofitserov")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-507464")[#strong[#text("Sergei Ofitserov")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2018")])]

#text("Dear Terence Tao! I am sorry by long silence. I am in shock! That no problem of publication! I am know, how to correct your equations outside of Riman hypothesis by theme Nanvier-Stokes. I am is your mate!! We is mutually dependent in following steps. In front transparent simultaneous decision of five sums of millennium! Class N=NP ?? for the time present questionable. I agree able to arrive to you, but how?? My means hardly that’s enough(suffice) only go to airport. But what your position in that situation?? Thanks. Sergei.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-508797")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2018")])]

#text("In the proof of Theorem 5, in defining the energy ")#mi("E^{s-1}(t)")#text(", should the summand be the L^2-norm squared of ")#mi("\\nabla^k w")#text(", rather than the dot product of ")#mi("\\nabla^k w")#text(" and ")#mi("\\nabla^k \\partial_t w")#text("?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 255B, Notes 2: Onsager’s conjecture | What's new")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-510686")[#strong[#text("255B, Notes 2: Onsager’s conjecture | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2019")])]

#text("[…] amount of energy at frequencies is at most . On the other hand, by the heuristics in Remark 11 of 254A Notes 3, the time needed for the portion of the solution at frequency to evolve to a higher frequency […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-515059")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2019")])]

#text("Thanks for the excellent notes. A couple of comments:")

#text("1) The definition of E^s around the middle of Theorem 5 is a typo (the limit of the sum should be s, and there shouldn’t be a \\partial_t on w).")

#emph[#text("[Corrected, thanks – T.]")]

#text("2) Aren’t the distributional solutions constructed in Proposition 6 actually strong since \\partial_t u \\in H^{s-1} ?")

#emph[#text("[Depends to some extent on what one means by “strong solution”, but yes, there should be enough regularity to verify that the Euler equations hold in a classical sense using classical derivatives here, though in practice this turns out to not be important so long as one knows that the solution is at least the limit of classical solutions.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-515060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2019")])]

#text("In the proof of Proposition 6, there seems to be a couple of typos: 1) after taking the limsup and using the triangle inequality, v^{(m)} should be u^{(m)} (two instances).")

#emph[#text("[Corrected, thanks – T.]")]

#text("2) We only have (and only need) a uniform upper bound on N^{-1} \\|P_{\\leq N} u_0 \\|_{H^{s+1}}")

#emph[#text("[Actually, I believe we do have convergence to zero in this case also, even though I agree boundedness would already be sufficient. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-515440")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2019")])]

#text("In the proof of Lemma 20 (forth and fifth display), d/2-s-1 should be d/2+1-s. Later appearances are correct.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-630102")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2021")])]

#text("In the proof of Corollary 3, you used Proposition 2,3 in notes 2 and the Arzela-Ascoli theorem.")

#text("It seems that for the Proposition 2, you meant to take ")#mi("X^* =  L^\\infty_t H^{s^{\\prime}}_x")#text(", and the assumption of Proposition 2 is satisfied since ")#mi("C_C^\\infty")#text(" is a subset of ")#mi("X = L^1_t H^{-s^{\\prime}}_x")#text(", which is separable by the fact that its dual ")#mi("X^*")#text(" is separable.")

#text("But for the Proposition 3 and Arzela Ascoli theorem, I’m confused about how you take ")#mi("X,Y")#text(" and which version of Arzela Ascoli you used here?")

#text("And the result you get from Proposition 3 confused me a lot. Why the weak convergence which you obtained from Proposition 2 is not sufficient to know ")#mi("u,p")#text(" are solutions to (3) by pairing (3) with test functions, taking limit, and by the smoothness of ")#mi("u,p")#text(" to know they are classical solutions?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-630324")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")])]

#text("On each ball ")#mi("B(0,n)")#text(", one can use the compact embedding of ")#mi("L^\\infty_t H^{s^{\\prime}}_x([0,T] \\times B(0,n))")#text(" into ")#mi("L^\\infty_t L^\\infty_x([0,T] \\times B(0,n))")#text(" (Rellich compactness) and Proposition 3 to obtain a subsequence that converges strongly in ")#mi("L^\\infty_t L^\\infty_x([0,T] \\times B(0,n))")#text(" for each ")#mi("n")#text(". Passing to subsequences once for each ")#mi("n")#text(" and then extracting the diagonal sequence (Arzela-Ascoli argument) one obtains a subsequence that converges strongly in ")#mi("L^\\infty_t L^\\infty_x([0,T] \\times B(0,n))")#text(" for all ")#mi("n")#text(", i.e., converges locally uniformly.")

#text("It is also possible to proceed here purely via distributional limits as you suggest since the weak-strong uniqueness one needs is indeed easy at this high level of regularity.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6b375c2b7bf216acdd980108eed6d03d1a720fe95faee715181790274d574ec-ea455139300983443b82df4b4b2c858777dfe4e37a1be96aa98fe5954020f439.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ning")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-630114")[#strong[#text("Ning")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2021")])]

#text("In Remark 4, you said that `In the presence of a boundary, we cannot freely differentiate in space as casually as we have been doing above’")#linebreak()#text(" Is that because we do not have the prior bound like that in Theorem 1, then we could not get the desired boundedness? I did not quite understand what you mean by casually differentiating in space.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-630325")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2021")])]

#text("Once one is working in a domain ")#mi("\\Omega \\subset {\\bf R}^d")#text(" with boundary, then one has to be careful because there are now several inequivalent notions of derivative one can use. For instance, consider the constant function ")#mi("1")#text(" on ")#mi("\\Omega")#text(". Naively this function has gradient zero. But if instead one extends this function by zero to all of ")#mi("{\\bf R}^d")#text(" to obtain the indicator function ")#mi("1_\\Omega")#text(" then the (weak) gradient of this function is instead a (vector-valued) distribution on the boundary ")#mi("\\partial \\Omega")#text(". Related to this, there are now several inequivalent Sobolev spaces ")#mi("H^s(\\Omega), H^s_0(\\Omega)")#text(", etc. that one can define on ")#mi("\\Omega")#text(", associated with different boundary conditions, and partial differentiation operations (such as the Laplacian) do not necessarily preserve these boundary conditions. (Also, it is not always true that test functions ")#mi("C^\\infty_c(\\Omega)")#text(" are dense in these spaces, which causes additional complications.) The book by Constantin and Foias on Navier-Stokes equations for instance treats these issues in some detail.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d10647b8474effe8d10e79ca204881b48f5762408c1fae8c2bac0c6c3965ec4c-e8398533bf0df9cd3ac1c8db7cba90c4d9f999efd548f1d3361c4d11fa5d2c95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Hu")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-636194")[#strong[#text("Kevin Hu")]]#text(size: 9pt, fill: rgb("596477"), " · 19 October 2021")])]

#text("Hi Dr. Tao, for the expression of \\p_tE(t) right below the proof of Lemma 20, I think the indices are inconsistent.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/717ce66206db2aaf143c003ce25dd9a28a288892fbd9a45f9ae3aa0665ffdbdf-51796807f78bdf967c62e6901cae86c28e45967747e3fc9bb72a7ba2fb9b0b40.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel Eriksson")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-636399")[#strong[#text("Daniel Eriksson")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2021")])]

#text("Before Remark 21, when we apply Gronwall shouldn’t there be an exponential factor on both terms, exp(O_{s,d}||omega||)_{L1Linf})(log(2+E(0))+T(||u_0||_{L^2}+1))?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/52978a0e6117c9343aeec0db336be18fa3293636ccd7667c7a72f9f1af5c4336-55092bd0e2627dd7319d069de70456711b9535b2ad82b458a7be3957513f4c0e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lorenzo Pompili")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-636476")[#strong[#text("Lorenzo Pompili")]]#text(size: 9pt, fill: rgb("596477"), " · 27 October 2021")])]

#text("Dear Professor Tao,")#linebreak()#text(" I think there is a typo in the definition of ")#mi("N_0")#text(" in the proof of Lemma 20: there should be ")#mi("u")#text(" instead of ")#mi("\\phi")#text(" (same thing for the very next sentence).")#linebreak()#text(" Also, in formula (18) and right after that, I think you are calling ")#mi("\\phi")#text(" a generic function in order to state and prove the estimate, but ")#mi("\\phi")#text(" is also the name of the test function that appears in the definition of the Littlewood-Paley projections. I would suggest to use another symbol, as the two appear quite close to each other and that can generate some confusion.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8d91c78bf515a6ce333ed5099d04688f286067f831815ef32988defe0653afe-5c740099477248b6f91993f8ab2abbadf6d8fde8c9d93b1dcaf3ee578475fecc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ABC")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-691578")[#strong[#text("ABC")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2026")])]

#text("Claim (15) should have some exponent on the ||u_0||_{H^s} term, after you take the exponential of the last display before Remark 21")

#emph[#text("[Fair enough, although it may be possible to remove that exponent with some additional effort. -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8d91c78bf515a6ce333ed5099d04688f286067f831815ef32988defe0653afe-5c740099477248b6f91993f8ab2abbadf6d8fde8c9d93b1dcaf3ee578475fecc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ABC")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-691903")[#strong[#text("ABC")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2026")])]

#text("I still dont see how (15) follows. In the last display before Remark 21, even $u_0 = 0$ does not force $u=0$.")

#emph[#text("[Added a lower order term to address this. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d8d91c78bf515a6ce333ed5099d04688f286067f831815ef32988defe0653afe-5c740099477248b6f91993f8ab2abbadf6d8fde8c9d93b1dcaf3ee578475fecc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ABC")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-691913")[#strong[#text("ABC")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2026")])]

#text("As written, its still not right. The exponent is not O(1), it depends on the vorticity and T. In fact the paper of Kiselev and Sverak suggests this is sharp.")

#text("The closest I can get it the following:")

#text("If we an assume an upper bound ")#tao-math("\\left|\\left|u_0\\right|\\right|_{H^\\gamma} < U", block: false)#text(" for some ")#mi("\\gamma>d/2+1")#text(", we obtain (15) with no exponent and a constant exponential in U and doubly exponential in T.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-691914")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 February 2026")])]

#text("Ah, I see the issue now. I’ve reworded again to move the H^s factor into the (first part of the) double exponential.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On classical solutions and singularity formation in incompressible fluids | What's new")]], [#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/#comment-696773")[#strong[#text("On classical solutions and singularity formation in incompressible fluids | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2026")])]

#text("[…] unforced three-dimensional Euler, the Beale–Kato–Majda continuation criterion states that breakdown of a sufficiently regular solution at a finite time […]")
]
