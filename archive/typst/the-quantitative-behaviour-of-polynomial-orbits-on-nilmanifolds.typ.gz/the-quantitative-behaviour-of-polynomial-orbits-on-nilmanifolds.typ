// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/
// Converted to Typst by tao2typ: "2026-10-14T06:52:49.004731+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The quantitative behaviour of polynomial orbits on nilmanifolds", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The quantitative behaviour of polynomial orbits on nilmanifolds")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 25 September 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")[#text("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.dpmms.cam.ac.uk/~bjg23/")[#text("Ben Green")]#text(" and I have just uploaded our paper “")#link("http://arxiv.org/abs/0709.3562")[#text("The quantitative behaviour of polynomial orbits on nilmanifolds")]#text("” to the ")#link("http://www.arxiv.org/")[#text("arXiv")]#text(" (and shortly to be submitted to a journal, once a companion paper is finished). This paper grew out of our efforts to prove the ")#emph[#text("Möbius and Nilsequences conjecture")]#text(" MN(s) from ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("our earlier paper")]#text(", which has applications to counting various linear patterns in primes (")#link("http://primes.utm.edu/glossary/page.php?sort=DicksonsConjecture")[#text("Dickson’s conjecture")]#text("). These efforts were successful – as the companion paper will reveal – but it turned out that in order to establish this number-theoretic conjecture, we had to first establish a purely dynamical quantitative result about polynomial sequences in nilmanifolds, very much in the spirit of the celebrated theorems of ")#link("http://en.wikipedia.org/wiki/Marina_Ratner")[#text("Marina Ratner")]#text(" on unipotent flows; I plan to discuss her theorems in more detail in a followup post to this one.In this post I will not discuss the number-theoretic applications or the connections with Ratner’s theorem, and instead describe our result from a slightly different viewpoint, starting from some very simple examples and gradually moving to the general situation considered in our paper.")

#text("To begin with, consider a infinite linear sequence ")#mi("(n \\alpha + \\beta)_{n \\in {\\Bbb N}}")#text(" in the unit circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(", where ")#mi("\\alpha, \\beta \\in {\\Bbb R}/{\\Bbb Z}")#text(". (One can think of this sequence as the orbit of ")#mi("\\beta")#text(" under the action of the shift operator ")#mi("T: x \\mapsto x +\\alpha")#text(" on the unit circle.) This sequence can do one of two things:")

#enum(start: 1, 
[#text("If ")#mi("\\alpha")#text(" is rational, then the sequence ")#mi("(n \\alpha + \\beta)_{n \\in {\\Bbb N}}")#text(" is periodic and thus only takes on finitely many values.")],
[#text("If ")#mi("\\alpha")#text(" is irrational, then the sequence ")#mi("(n \\alpha + \\beta)_{n \\in {\\Bbb N}}")#text(" is dense in ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(". In fact, it is not just dense, it is ")#link("http://en.wikipedia.org/wiki/Equidistributed")[#text("equidistributed")]#text(", or equivalently that")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\to \\infty} \\frac{1}{N} \\sum_{n=1}^N F( n \\alpha + \\beta ) = \\int_{{\\Bbb R}/{\\Bbb Z}} F")]]

#text("for all continuous functions ")#mi("F: {\\Bbb R}/{\\Bbb Z} \\to {\\Bbb C}")#text(". This statement is known as the ")#link("http://en.wikipedia.org/wiki/Equidistribution_theorem")[#text("equidistribution theorem")]#text(".")]
)

#text("We thus see that infinite linear sequences exhibit a sharp dichotomy in behaviour between periodicity and equidistribution; intermediate scenarios, such as concentration on a fractal set (such as a ")#link("http://en.wikipedia.org/wiki/Cantor_set")[#text("Cantor set")]#text("), do not occur with linear sequences. This dichotomy between structure and randomness is in stark contrast to exponential sequences such as ")#mi("( 2^n \\alpha)_{n \\in {\\Bbb N}}")#text(", which can exhibit an extremely wide spectrum of behaviours. For instance, the question of whether ")#mi("(10^n \\pi)_{n \\in {\\Bbb N}}")#text(" is equidistributed mod 1 is an old unsolved problem, equivalent to asking whether ")#mi("\\pi")#text(" is ")#link("http://en.wikipedia.org/wiki/Normal_number")[#text("normal")]#text(" base 10.")

#text("Intermediate between linear sequences and exponential sequences are ")#emph[#text("polynomial sequences")]#text(" ")#mi("(P(n))_{n \\in {\\Bbb N}}")#text(", where P is a polynomial with coefficients in ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(". A famous theorem of Weyl asserts that infinite polynomial sequences enjoy the same dichotomy as their linear counterparts, namely that they are either periodic (which occurs when all non-constant coefficients are rational) or equidistributed (which occurs when at least one non-constant coefficient is irrational). Thus for instance the fractional parts ")#mi("\\{ \\sqrt{2}n^2\\}")#text(" of ")#mi("\\sqrt{2} n^2")#text(" are equidistributed modulo 1. This theorem is proven by Fourier analysis combined with non-trivial bounds on ")#link("http://en.wikipedia.org/wiki/Weyl_sum")[#text("Weyl sums")]#text(".")

#text("For our applications, we are interested in strengthening these results in two directions. Firstly, we wish to generalise from polynomial sequences in the circle ")#mi("{\\Bbb R}/{\\Bbb Z}")#text(" to polynomial sequences ")#mi("(g(n)\\Gamma)_{n \\in {\\Bbb N}}")#text(" in other ")#link("http://en.wikipedia.org/wiki/Homogeneous_space")[#text("homogeneous spaces")]#text(", in particular ")#link("http://en.wikipedia.org/wiki/Nil_manifold")[#text("nilmanifolds")]#text(". Secondly, we need quantitative equidistribution results for finite orbits ")#mi("(g(n)\\Gamma)_{1 \\leq n \\leq N}")#text(" rather than qualitative equidistribution for infinite orbits ")#mi("(g(n)\\Gamma)_{n \\in {\\Bbb N}}")#text(".")

#metadata(none) <tao-314bbec842ae7d237fda>

#text("Before we extend to nilmanifolds, let us briefly review what happens for higher-dimensional torii ")#mi("{\\Bbb R}^m/{\\Bbb Z}^m")#text(". From the theory of Weyl sums, one can show that an infinite polynomial sequence ")#mi("(P(n) \\text{ mod } {\\Bbb Z}^m)_{n \\in {\\Bbb N}}")#text(" in a torus is either equidistributed, or is contained in a finite union of proper subtorii (cf. ")#link("http://en.wikipedia.org/wiki/Kronecker%27s_theorem")[#text("Kronecker’s theorem")]#text(" in the case when P is linear). Iterating this, we get a Ratner-type theorem for the torus, namely that every infinite polynomial sequence in a torus is equidistributed within a finite union of subtorii.")

#text("It turns out that a similar Ratner-type result holds for nilmanifolds, and is due ")#link("http://www.ams.org/mathscinet-getitem?mr=2122919")[#text("to Leibman")]#text(" (with some earlier results in this direction ")#link("http://www.ams.org/mathscinet-getitem?mr=126504")[#text("by Leon Green")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=267558")[#text("by Parry")]#text(", and ")#link("http://www.ams.org/mathscinet-getitem?mr=1699367")[#text("by Shah")]#text("). Recall that a nilmanifold is a quotient space ")#mi("G/\\Gamma")#text(", where G is a nilpotent Lie group (which for simplicity we shall take to be connected and simply connected, although these restrictions can be removed with a bit of effort), and ")#mi("\\Gamma")#text(" is a discrete cocompact subgroup. A good example is the ")#emph[#text("Heisenberg nilmanifold")]

#align(center)[#tao-fit-display[#mitex("G/\\Gamma := \\begin{pmatrix} 1 & {\\Bbb R} & {\\Bbb R} \\\\ 0 & 1 & {\\Bbb R} \\\\ 0 & 0 & 1 \\end{pmatrix} /\\begin{pmatrix} 1 & {\\Bbb Z} & {\\Bbb Z} \\\\ 0 & 1 & {\\Bbb Z} \\\\ 0 & 0 & 1 \\end{pmatrix}.")]]

#text("There is a well-defined notion of a polynomial sequence in G – a sequence ")#mi("g(n)")#text(" which becomes trivial after finitely many applications of the differentiation operator ")#mi("\\partial")#text(", defined as ")#mi("\\partial g(n) := g(n+1) g(n)^{-1}")#text(". Leibman showed that an infinite polynomial sequence ")#mi("(g(n)\\Gamma)_{n \\in {\\Bbb N}}")#text(" is either equidistributed in the nilmanifold ")#mi("G/\\Gamma")#text(", or is else contained in a finite union of proper subnilmanifolds; iterating this, one can conclude that every infinite polynomial sequence is equidistributed in a finite union of nilmanifolds. One can also phrase this as a factorisation theorem: every polynomial sequence is the product of a constant sequence, a sequence equidistributed in a nilmanifold, and a periodic (and rational) sequence.")

#text("A typical application of Leibman’s theorem would be the assertion that for any real numbers ")#mi("\\alpha, \\beta")#text(", the sequence ")#mi("( \\lfloor \\alpha n \\rfloor \\beta n )_{n \\in {\\Bbb N}}")#text(" is either periodic, or equidistributed modulo 1, where ")#mi("\\lfloor x \\rfloor")#text(" is the integer part of x (except in some rare but explicitly describable cases, when ")#mi("\\alpha, \\beta")#text(" lie in a quadratic extension of ")#mi("{\\Bbb Q}")#text(", in which one has a different distribution; see comments). I do not know of a way to prove this result which does not basically require one to prove a large part of Leibman’s theorem.")

#text("Leibman first proves his theorem in the linear case by heavy reliance on the ")#link("http://en.wikipedia.org/wiki/Ergodic_theorem")[#text("ergodic theorem")]#text(", an induction on the step of the nilmanifold, and some Fourier analysis (or representation theory) to handle the “vertical” behaviour of the nilmanifold, using some arguments of Parry. He then passes to the polynomial case by using a lifting trick of Furstenberg to linearise the sequence.")

#text("Extensions of these results beyond nilmanifolds, and in particular to finite volume homogeneous spaces, are certainly of interest (see for instance this ")#link("http://www.ams.org/mathscinet-getitem?mr=1754775")[#text("article of Margulis")]#text(") but are considerably more difficult, as one loses the ability to work by induction from the abelian case.")

#text("Now we turn to quantitative versions of the above statements, in which we look at the equidistribution properties of a finite polynomial sequence ")#mi("(g(n) \\Gamma)_{1 \\leq n \\leq N}")#text(". One can define the notion of a finite sequence being equidistributed up to some error ")#mi("\\delta")#text(", which roughly means that irregularities in the sequence can only be detected at scales ")#mi("O(\\delta)")#text(" or below. Our first main result is that a finite polynomial sequence is either equidistributed up to error ")#mi("\\delta")#text(", or is else concentrated within ")#mi("O(\\delta)")#text(" of ")#mi("O(\\delta^{-O(1)})")#text(" proper subnilmanifolds, whose “slopes” have ")#link("http://en.wikipedia.org/wiki/Height_function")[#text("height")]#text(" ")#mi("O(\\delta^{-O(1)})")#text(". One can iterate this and conclude a Ratner-type theorem, namely that every finite polynomial sequence is within ")#mi("O(\\delta)")#text(" of being equidistributed on a polynomial number of proper subnilmanifolds, whose slopes also have polynomially bounded heights. These polynomial bounds turn out to be important for our number theoretic applications, which will be discussed in a subsequent post. There is also a factorisation theorem, which asserts that every polynomial sequence can be expressed as the product of a slowly varying sequence, a sequence which is equidistributed in a nilmanifold, and a periodic rational sequence, with quantitative polynomial bounds on all of these assertions.")

#text("To illustrate our result with a concrete instance, we can assert that for any real numbers ")#mi("\\alpha, \\beta")#text(", any error tolerance ")#mi("\\delta > 0")#text(", and any large integer, one can subdivide ")#mi("\\{1,\\ldots,N\\}")#text(" into arithmetic progressions, each of density ")#mi("\\gg \\delta^{O(1)}")#text(", such that ")#mi("\\lfloor \\alpha n \\rfloor \\beta n")#text(" is either within ")#mi("\\delta")#text(" of a constant, or is ")#mi("\\delta")#text("-equidistributed, or is the push-forward of a ")#mi("\\delta")#text("-equidistributed sequence by a quadratic polynomial with coefficients ")#mi("O(\\delta^{O(1)})")#text(" (this latter case is technical, and rather rare, having to do with special subnilmanifolds of the Heisenberg nilmanifold).")

#text("One of the key difficulties in working in the quantitative setting (especially when one is insisting on polynomial bounds everywhere, and when N is fixed in advance) is that one can no longer use the ")#link("http://en.wikipedia.org/wiki/Ergodic_theorem")[#text("ergodic theorem")]#text(" (unless one has quantitative control on the ergodicity, such as spectral gaps, which appear to be unavailable in this setting). Because of this, we were eventually forced to find a different approach than Leibman’s to these problems, and ended up with one based primarily on Fourier analysis in the vertical direction combined with the van der Corput inequality (very much in the spirit of the Weyl’s theory of equidistribution and exponential sums). Another new feature of the quantitative setting is the presence of error terms: a sequence may not lie exactly in a subnilmanifold, but instead deviates from it by a small error. This error can be eliminated, but often at the cost of increasing the “degree” (or other measures of “complexity”) of the polynomial sequence ")#mi("g(n)")#text(". This makes it far from obvious that iterative arguments guaranteed to terminate; it also seems to prevent one from using the Furstenberg lifting trick to linearise a sequence in the middle of an iteration argument, and so we were forced to work directly with polynomial sequences. For similar reasons, we had to perform a fair amount of algebraic computation to set up a good notion of the “complexity” of a polynomial sequence, which decreased with every stage of the main iteration argument. (In the end, this complexity is modeled by three parameters: the step s of the nilmanifold, the “commutator degree” D of the sequence g(n), and the “nonlinearity dimension” of the coefficient spaces for g(n), thus leading to a triple induction on these parameters in order to conclude the argument.)")

#text("[Update, Sep 26: inaccuracies with the ")#mi("\\alpha n \\lfloor \\beta n \\rfloor")#text(" example fixed; thanks to Ben Green for the corrections.]")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (53)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-2/#comment-484812")[#strong[#text("The structure of logarithmically averaged correlations of multiplicative functions, with applications to the Chowla and Elliott conjectures | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2017")])]

#text("[…] the equidistribution theory of nilsequences (as developed in this previous paper of Ben Green and myself), one can break up further into a periodic piece and an “irrational” or “minor […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Goursat and Furstenberg-Weiss type lemmas | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-2/#comment-625745")[#strong[#text("Goursat and Furstenberg-Weiss type lemmas | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 May 2021")])]

#text("[…] were obtained by Leibman and are important in the equidistribution theory of nilmanifolds; see this paper of Ben Green and myself for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-2/#comment-625998")[#strong[#text("Goursat and Furstenberg-Weiss type lemmas – scroo0ooge")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2021")]

#text("[…] were obtained by Leibman and are important in the equidistribution theory of nilmanifolds; see this paper of Ben Green and myself for further […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10432")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2007")])]

#text("Terry,")

#text("Curiously enough I’ve just had my attention drawn to a paper of Bergelson and Leibman where they remark that ")#mi("n\\sqrt{2}[n\\sqrt{2}]")#text(" is *not* equidistributed modulo 1 (and it certainly isn’t periodic). If you replace square roots by cube roots, or in fact if you replace ")#mi("\\sqrt{2}")#text(" by more-or-less any other irrational number, you do get equidistribution. The complete theory was worked out in some papers of Inger Haland.")

#text("This doesn’t contradict your post in any serious way (or our paper :-)) but it is fun to try and understand this phenomenon in terms of nilmanifolds.")

#text("The thing is that ")#mi("p(n) = n\\sqrt{2}[n\\sqrt{2}]")#text(" can be viewed as coming from a polynomial sequence on a certain 4-dimensional, two step, nilmanifold G/L, where G is the product of a Heisnberg group and ")#mi("{\\Bbb R}")#text(", and L is the obvious lattice. The polynomial sequence is the map ")#mi("g : {\\Bbb Z} \\to G")#text(" given by ")#mi("n \\mapsto (n\\sqrt{2},n\\sqrt{2},n^2;n^2)")#text(", and then our bracket polynomial p(n) is just f(g(n)L), where f(x,y,z;t) = z – t (and I have identified G/L with the fundamental domain ")#mi("{}[-1/2,1/2]^4")#text(").")

#text("Now that polynomial sequence lies inside a 2-dimensional closed subgroup H of G, namely ")#mi("\\{(x,x,x^2/2;y) : x,y \\in {\\Bbb R}\\}")#text(", but the y coordinate is always an integer. So when you mod out by L you find that g(n)L lies inside H’/L, where ")#mi("H^{\\prime} = \\{(x,x,x^2/2;0) : x \\in {\\Bbb R}\\}")#text(". By our theorem it is equidistributed inside that group.")

#text("The point is that the map f does not send the natural measure on H’/L to Lebesgue measure on [-1/2,1/2] (Bergelson and Leibman calculate this measure explicitly – this isn’t too difficult, but I won’t do it here).")

#text("It *does* send the natural measure on H/L to Lebesgue measure, because")#linebreak()#text(" that freely varying y essentially takes that weird measure I just mentioned and convolves it with Lebsegue measure, thus producing Lebesgue measure again. This explains why this weird phenomenon is quite rare, and in particular why ")#mi("n\\alpha[n\\alpha]")#text(" is equidistributed mod 1 when alpha is the cube root of two.")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10480")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("Dear Ben,")

#text("Very nice! That was a subtlety I had not appreciated before. (For ")#mi("n \\sqrt{2} \\lfloor n\\sqrt{2}\\rfloor")#text(", one can explain the phenomenon by observing the identity ")#mi("2 n\\sqrt{2} \\lfloor n\\sqrt{2}\\rfloor = -\\{n\\sqrt{2}\\}^2 \\text{ mod } 1")#text(", which can be verified by writing ")#mi("\\lfloor n\\sqrt{2}\\rfloor = n\\sqrt{2} - \\{ n \\sqrt{2}\\}")#text(" and expanding out the fact that ")#mi("\\lfloor n\\sqrt{2}\\rfloor^2")#text(" is an integer.)")

#text("Incidentally, one does not need the additional torus adjoined to the Heisenberg nilmanifold to interpret the example; one can consider the polynomial sequence ")#mi("(n\\sqrt{2}, n\\sqrt{2},0)")#text(" in the Heisenberg nilmanifold and take ")#mi("f(x,y,z) = \\{z\\}")#text(" to obtain the same effect.")

#text("I see where I went wrong now – the three-dimensional Heisenberg nilmanifold does contain some interesting subnilmanifolds, such as ")#mi("\\{ (x,x,z) \\Gamma: 2z = x^2 \\text{ mod } 1 \\}")#text(", which as you say have a different pushforward under f than the 0-dimensional or full-dimensional subnilmanifolds do. I’ll reword the post appropriately.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d51afa4c127bba65957fa585ed74d60374b5fde6ae058675bc595d6a6e8642-3535e0ad0c7ff7db58b9ec86b407ef29e1b928d8dd3711aece7fe208e41676b8.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Green")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10482")[#strong[#text("Ben Green")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("Terry,")

#text("I was working inside the 4-dimensional thing because one can understand ")#mi("\\alpha n [\\alpha n]")#text(" there, whereas that doesn’t seem to come from something on the Heisenberg without the additional torus (though I prepare to be corrected….)")

#text("I think your proof that ")#mi("n\\sqrt{2}[n\\sqrt{2}]")#text(" isn’t equidistributed gets to the heart of the matter rather more swiftly than mine :-) Takes some of the mystery away.")

#text("Ben")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10487")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("Dear Ben,")

#text("One way to view Ratner’s theorem and its relatives is that the only obstructions to equidistribution of unipotent flows are algebraic ones. So if something like ")#mi("n\\sqrt{2}\\lfloor n\\sqrt{2} \\rfloor")#text(" is failing to be equidistributed modulo 1, there has to be some short algebraic explanation of that fact. It’s sort of a “proof theory” for equidistribution, if you will.")

#text("Regarding how to embed things into the Heisenberg nilmanifold, let me write [x,y,z] for the upper triangular matrix ")#mi("\\begin{pmatrix} 1 & x & z \\\\ 0 & 1 & y \\\\ 0 & 0 & 1\\end{pmatrix}")#text(". Then G is the space of all triples [x,y,z] with real entries, and ")#mi("G/\\Gamma")#text(" can be identified with triples with entries between -1/2 and 1/2, with an element [x,y,z] of G projecting to an element ")#mi("{}[ \\{ x \\}, \\{y\\}, \\{ z - x\\lfloor y \\rfloor\\} ]")#text(" of ")#mi("G/\\Gamma")#text(". In particular, the polynomial sequence ")#mi("{}[n\\sqrt{2}, n\\sqrt{2}, 0]")#text(" in G projects to the element ")#mi("{}[ \\{ n\\sqrt{2}\\}, \\{ n \\sqrt{2}\\}, -\\{ n \\sqrt{2} \\lfloor n \\sqrt{2}\\rfloor \\} ]")#text(" in ")#mi("G/\\Gamma")#text(". This element does not range freely there, but is constrained to the subnilmanifold ")#mi("G^{\\prime}/\\Gamma^{\\prime} := \\{ [x,x,z]: -1/2 < x \\leq 1/2; 2z = x^2 \\text{ mod } 1 \\}")#text(", which is also the orbit of the one-dimensional subgroup ")#mi("G^{\\prime} := \\{ [x,x,x^2/2]: x \\in {\\Bbb R} \\}")#text(". Of course, it was by locating this subnilmanifold that I found the algebraic relation alluded to above.")

#text("One thing this teaches me is that I should do more explicit calculations. Somehow I managed to write my half of our paper while working entirely with abstract nilmanifolds in mind (or at a pinch, abstract 1-step and 2-step nilmanifolds).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10491")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("I find both Ratner’s results and this new result of yours somewhat reminiscent (in flavor) of Deligne’s equidistribution theorem over finite fields. In all three cases, some sequence (or finite sets of Frobenius conjugacy classes, in Deligne’s case, because these sets are not naturally ordered) is shown to become equidistributed in “something”. Many problems can then be transferred to the (often easier) issue of knowing what the something is, but there definitely exist situations where the “something” is not as simple as the “generic” answer.")#linebreak()#text(" Deligne’s work is even more algebraic since equidistribution holds in a group, not in a manifold or orbit of some kind. Also, his work turns out to be surprisingly suitable for (strong) quantitative statements. (Partly because it is obtained by direct harmonic analysis using finite-dimensional representations of compact groups, and partly because of the always amazing effect of the Riemann Hypothesis).")

#text("I should also say that I’m looking forward to reading your next paper on the general form of the Möbius and Nilsequences Conjecture…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaspard")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10496")[#strong[#text("Gaspard")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("Dear Terry and Ben,")

#text("if I understand well, this proof of the Möbius and Nilsequences conjecture MN(s) means your previous conditionnal proof of Dickson’s conjecture in the non-binary case is now stronger and relies “only” on the Gowers Inverse GI(s) conjecture.")

#text("I was wondering if during this recent work you also gained knowledge on both the GI(s) conjecture and maybe on the binary case too. Thank you. (I’m just an outsider trying to assess how hard the Twin Prime and Golbach conjectures actually are, if I ever have to mention them in a lecture.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10498")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("The Twin Prime conjecture has great educational value, as it makes")#linebreak()#text(" an impression on any kid who has learned division. It makes one wonder")#linebreak()#text(" why it is not on the Clay Institute list. I once asked my closest")#linebreak()#text(" collaborator what he thought about it, but he hasn’t replied yet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10505")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2007")])]

#text("Dear Emmanuel: Thanks for the reference! One day I plan to go through Deligne’s Weil papers, clearly there is a lot of amazing stuff in there…")

#text("Dear Gaspard: You are correct, the only remaining obstacle to the non-binary Dickson conjecture is now the proof of the Gowers inverse conjecture GI(s). It looks like the Ratner-type theorem in this paper will also be useful for that conjecture (very roughly speaking, just as Fourier analysis is based on the ability to evaluate exponential sums such as ")#mi("\\sum_{n=1}^N e(n\\alpha)")#text(", the “higher order Fourier analysis” which presumably underlies GI(s) should be based on the ability to evaluate sums such as ")#mi("\\sum_{n=1}^N F(g(n)\\Gamma)")#text(", and this is now (in principle) achievable thanks to these Ratner-type theorems) but there are some additional issues (coming from additive combinatorics) that Ben and I are still trying to understand properly. We’re definitely looking at it, though…")

#text("There is a very slight chance that our methods may one day extend to the binary case, but it would require some substantial new breakthroughs; so far, everything we do requires averaging over at least two independent parameters, whereas in problems such as the twin prime and Goldbach conjectures, there is only one parameter to average over. This appears to be a fundamental limitation to these methods, but of course the addition of a powerful new idea could change the game entirely…")

#text("Dear Adam: I believe the Clay problems were selected not only for difficulty, but for the impact that their solution (or the search for a solution) would have on mathematical research (and possibly to applications as well, especially in the case of P=NP, and perhaps also Navier-Stokes). This is more or less orthogonal to how accessible the problem would be to, say, a high-school student (though I think at least 5 of the 7 problems can be explained in general terms to a such a student – I ")#link("http://www.math.ucla.edu/%7Etao/preprints/Slides/pnp.pdf")[#text("did exactly this")]#text(" for ")#mi("P \\neq NP")#text(" a few years ago, and ")#link("http://www.math.ucla.edu/~tao/preprints/Slides/primes.pdf")[#text("something similar")]#text(" for the Riemann Hypothesis last year). The Riemann hypothesis and the BSD conjecture have an enormous number of implications within number theory, and the partial results we already have on these problems has already generated many deep insights and powerful new techniques; a solution to the twin prime conjecture would achieve some of this, but on a substantially lesser scale. Also, the twin prime conjecture appears (to me, at least), to be marginally less impossible to solve than the other two (although with the current rate of progress in arithmetic geometry, it is entirely conceivable that BSD will not look as unsolvable in a few decades as it does right now).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10543")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("The difficulty of the twin-prime problem compared to the current best results in additive prime number theory may be somewhat suggested by the fact that the best result of the type")

#text("(Known widely believed conjecture) implies (Twin Prime-like Conjecture)")

#text("which is currently available is the consequence of the work of Goldston-Pintz-Yildirim according to which the Elliott-Halberstam conjecture implies that for some (small, less than 16 I think currently) fixed even integer $k$, there are infinitely many primes $p$ for which $p+k$ is also prime. The E-H conjecture is (at least in appearance) much stronger than what can be derived from the Generalized Riemann Hypothesis for all Dirichlet L-functions. Moreover, this conjecture is clearly borderline; more optimistic statements that might seem just as reasonable are known to be false by work of Friedlander and Granville, suggested by earlier works of Maier on primes in short intervals.")

#text("This is to be contrasted with the results about the ternary Goldbach problem, or 3 or 4-terms arithmetic progressions (and hopefully soon $k$-terms A.P., $k>2$) by Vinogradov, van der Corput, and of course Green-Tao, which rely “only”, as far as the precise asymptotic distribution of primes is concerned, on the Siegel-Walfisz theorem, which in turns “only” depends on the non-existence of zeros of L-functions at distance roughly $c/log q$ of the line $Re(s)=1$ (where $q$ is the conductor, and I’m glossing over the exceptional zero, which I shouldn’t…)")

#text("(And I should say all this is as far as I know; there’s enormous literature on these problems, so I may be unaware of other conditional approaches to twin prime problems; also I think I didn’t misread the papers of Ben and Terry concerning the amount of “prime distribution” they use, but I’m not the expert on those…).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10544")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("Dear Emmanuel,")#linebreak()#text(" Was the implication you mention established by Hardy and Littlewood?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10545")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("No, the implication is very recent: it’s part of the work of Goldston, Pintz and Yildirim, see for instance ")#link("http://arxiv.org/abs/math/0508185")[#text("this preprint")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10546")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("Then see:")#linebreak()#text(" Cherwell, E. M. Wright, The frequency of prime-patterns, Quart. J. Math.")#linebreak()#text(" Oxford Ser. (2) 11 (1960), 60-63, and what the authors claim in that")#linebreak()#text(" paper. Wright co-authored a book with Hardy on prime numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10548")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("Dear Adam: I think you are referring to the ")#link("http://mathworld.wolfram.com/k-TupleConjecture.html")[#text("Hardy-Littlewood prime tuples conjecture")]#text(", which does indeed imply the twin prime conjecture (but is much more general). But this is not really a deep reduction, the same way the Goldston-Yildirim-Pintz result is, because the HL conjecture is “on the same level” of complexity as the twin prime conjecture (it is a correlation estimate between primes and shifted primes), whereas the EH conjecture is a correlation estimate between primes and a simpler object, namely generic arithmetic progressions, and is thus simpler (the fewer primes are involved, the easier it is to actually estimate things). As Emmanuel says, the EH is in some sense a “super-GRH” and is thus looks wildly optimistic, on the other hand there is an additional averaging which does allow one to get EH-type estimates of comparable strength to GRH (the Bombieri-Vinogradov inequality) and there are also hints that one can do even better in some cases. I plan to write a little more about the Elliot-Halberstam conjecture on this blog at some point…")

#text("Emmanuel: You are correct, the only information about the distribution of primes we use in our linear equations in primes paper comes from Siegel-Walfisz. In our first paper we use almost nothing; one even can get by using Chebyshev’s level of understanding of the primes (basically, that zeta has a pole at s=1). [We use Dirichlet’s theorem in our paper, but one could substitute that by just the pigeonhole principle, as we only need one congruence class with a lot of primes in it.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10549")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("Dear Terry,")#linebreak()#text(" I will go to the library and do some reading, to be on the safe side.")#linebreak()#text(" To me, TPC has a “hard analysis” flavour, in constrast to your")#linebreak()#text(" arithmetic progressions in the primes result, which looks like “medium”.")#linebreak()#text(" If I were interested in it, I would use the new Perelman idea of")#linebreak()#text(" looking into appropriate physics theories for getting oneself")#linebreak()#text(" into the right mindset (however, it is quite hard to find a quiet job).")#linebreak()#text(" If one believes in some self-similarity in nature, maybe some inspiration")#linebreak()#text(" can be found in particle physics (bamboo bundles are good too")#linebreak()#text(" – for giant pandas). The great J. M. Hammersley called it “getting")#linebreak()#text(" to grips with a good problem”:")#linebreak()#text(" ")#link("http://www.statslab.cam.ac.uk/~grg/papers/ham1-ph.html")[#text("http://www.statslab.cam.ac.uk/~grg/papers/ham1-ph.html")]#linebreak()#text(" The search for the solution of the TPC has had quite an impact on")#linebreak()#text(" applied mathematics. Lord Cherwell considered a probabilistic heuristic")#linebreak()#text(" derivation, and in the process derived the equation")#linebreak()#text(" y'(x) = – ln2 y(x-1) [1+y(x)].")#linebreak()#text(" A generalization with a in place of ln2 was studied in the classical:")#linebreak()#text(" E. M. Wright, A non-linear difference-differential equation, J. Reine")#linebreak()#text(" Angew. Math. 194 (1955), 66-87,")#linebreak()#text(" and was later rediscovered in mathematical biology, where they call")#linebreak()#text(" such equations delayed ones. Interestingly, a longstanding open")#linebreak()#text(" problem in this area was recently completely solved (on a few pages)")#linebreak()#text(" with the help of Ikehara’s Theorem, a cult result in analytic number")#linebreak()#text(" theory, which gives the fastest proof of the Prime Number Theorem")#linebreak()#text(" (the biggest problem of the 19th century), in which one doesn’t need")#linebreak()#text(" to use the Fourier Transform on the line Re z = 1.")#linebreak()#text(" Those interested in such recent results are referred to the literature.")#linebreak()#text(" They are easy to check for errors, for those who understand calculus,")#linebreak()#text(" but a little harder to rediscover.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10556")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("The prime $k$-tuples conjecture is indeed not distinct enough from the twin prime conjecture that any implication could be considered “evidence” towards the latter. On the other hand, it is by means of an attack on a weakening of the $k$-tuples conjecture that Goldston, Pintz and Yildirim succeeded in proving their results (which, in addition to the conditional one I mentioned include the proof that")#linebreak()#text(" ")#tao-fit-display[#mitex("\\liminf (p_{n+1)-p_n)/(\\log p_n)=0")]#linebreak()#text(" which uses the Bombieri-Vinogradov theorem, or in other words information about primes in arithmetic progressions looking roughly equivalent with GRH for Dirichlet L-functions.)")

#text("One must always be careful when doing arguments of the type (Conjecture A implies Conjecture B); sometimes there is a definite danger of starting to kick big statements back and forth with no gain in knowledge. However, in this case I definitely think some insight has been gained. As Terry mentioned, there is definitely strong evidence towards the Elliott-Halberstam conjecture, and if one simply gave the statement to someone not ")#emph[#text("au courant")]#text(", there is little chance he/she could immediately see the connection with the Twin Prime or similar conjectures.")

#text("(For surveys on this, in addition to the papers, there is an excellent survey by Soundararajan, see ")#link("http://arxiv.org/abs/math/0605696")[#text("http://arxiv.org/abs/math/0605696")]#text(" ; I have also written a ")#link("http://www.math.u-bordeaux1.fr/~kowalski/goldston-pintz-yildirim.pdf")[#text("Bourbaki seminar report")]#text(" on this work, but it is in French only).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10559")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2007")])]

#text("Getting back to the subject, there is also the interesting looking:")#linebreak()#text(" J. Korevaar, Distributional Wiener-Ikehara theorem and twin primes,")#linebreak()#text(" Indag. Math. (N.S.) 16 (2005), 37-49.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10588")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("I was reading wikipedia in an attempt to better understand Ergodic theory [ET].")

#text("Chaos theory, John von Neumann and Alan Connes seem to be linked?")

#text("a- “In mathematics, a measure-preserving transformation T on a probability space is said to be ergodic if the only measurable sets invariant under T have measure 0 or 1. An older term for this property was metrically transitive. Ergodic theory, the study of ergodic transformations, grew out of an attempt to prove the ergodic hypothesis of statistical physics. Much of the early work in what is now called chaos theory was pursued almost entirely by mathematicians, and published under the title of “ergodic theory”, as the term “chaos theory” was not introduced until the last quarter of the 20th century.")#linebreak()#text(" “Less formally, ergodic theory is generally about what happens in dynamical systems when they are allowed to run for long periods of time. Markov chains are a particularly simple and common context for applications.”")#linebreak()#text(" and")#linebreak()#text(" Section: Mean Ergodic Theorem (Von Neumann’s Ergodic Theorem)")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Ergodic_theory")[#text("http://en.wikipedia.org/wiki/Ergodic_theory")]

#text("b- Section History: “Some of the theory developed by Alain Connes to handle noncommutative geometry [NCG] at a technical level has roots in older attempts, in particular in ergodic theory.”")#linebreak()#text(" ")#link("http://en.wikipedia.org/wiki/Noncommutative_geometry")[#text("http://en.wikipedia.org/wiki/Noncommutative_geometry")]

#text("Questions:")

#text("1 – As degree mapping linked von Neumann Algebras to his Minimax Theorem [MT], is there a mapping linking NCG to ET?")

#text("2 – If so, could NCG be linked to MT through John Nash game theory concepts?")#linebreak()#text(" – Does commutative correspond to cooperative?")#linebreak()#text(" – Does noncommutative correspond to noncooperative?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10589")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Hi Terence,")

#text("Another question:")

#text("Is there a mapping relating nilpotent to idempotent?")

#text("[I could not “idemmanifold” on google; thus this may not exist].")

#text("Physicists seem to prefer nilpotent.")

#text("Engineers seem to prefer idempotent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10598")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Dear Doug,")

#text("Von Neumann worked on a very diverse number of fields in mathematics, including ergodic theory, game theory, and (of course) von Neumann algebras. Game theory is not really connected to the other two, although they both use basic mathematical concepts such as convexity and linearity. Ergodic theory on a space X can be described to some extent using commutative von Neumann algebras such as ")#mi("L^\\infty(X)")#text(", whereas non-commutative geometry can be described using non-commutative von Neumann algebras, but other than that, there is not much of a direct connection between the two. Ergodic theory, like chaos theory, is centred around the study of a dynamical system, but they emphasise different aspects of such systems (ergodic theory focuses on long-term average behavior of orbits, while chaos theory focuses on the divergence of nearby orbits and on asymptotic attractors).")

#text("In general, any two fields of mathematics selected at random are likely to share some low-level features in common, because they use the same mathematical language and fundamental concepts, and because they often study different aspects of the same mathematical objects. But this usually does not correspond to any higher-level correspondence between these two fields; those correspondences which have been found (e.g. between arithmetic geometry and algebraic geometry) tend to be rather deep and not easily discernable from looking at the low-level “keywords” of the respective fields.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10600")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Doug’s intuitive questions remind me of the work on the gradient")#linebreak()#text(" flow of the nonlocal van der Waals field functional. A traveling wave")#linebreak()#text(" was constructed with degree theory (a homotopy version), however,")#linebreak()#text(" the critical droplet (a threshold between the domains of attraction")#linebreak()#text(" of two stable states) was obtained (1999) with a careful")#linebreak()#text(" mountain-pass construction (literature). The min-max concept")#linebreak()#text(" seems to be quite deep, as to this date only partial reconstructions")#linebreak()#text(" of that homoclinic have been obtained. It is an open question")#linebreak()#text(" whether a min-max approach is unique for that problem, which")#linebreak()#text(" also immediately gives a soliton solution of the nonlocal KdV equation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10602")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Dear Doug: The problem with giBbs postulates is that it leads")#linebreak()#text(" to a definition of a phase transition which is incompatible with")#linebreak()#text(" the experimental one (i.e., two distinct densities coexisting")#linebreak()#text(" at the same pressure, if you look at the liquid-gas isotherms).")#linebreak()#text(" Maxwell’s equal area rule correction of the van der Waals")#linebreak()#text(" equation of state is a great second step in establishing a phase")#linebreak()#text(" transition, but it doesn’t eliminate the values of the density in")#linebreak()#text(" the interior of the interval. For that, you need the additional")#linebreak()#text(" van der Waals postulate of pseudoassociations of complexes")#linebreak()#text(" of molecules (literature).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of teaspoon")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10604")[#strong[#text("teaspoon")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Terry, maybe people should have to answer a challenge question before they post?")

#text("Something like:")

#text("Please answer YES or NO: You have a theory that reconciles quantum gravity and special relativity and assumes only the Riemann Hypothesis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Adam")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10608")[#strong[#text("Adam")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("There is something fishy about the Riemann Hypothesis, due to")#linebreak()#text(" “near counterexamples” near Gram points. The author H. M. Edwards")#linebreak()#text(" (Riemann’s Zeta Function, Dover Publications 1974) thinks that if")#linebreak()#text(" Riemann knew about this phenomenon, he wouldn’t state this")#linebreak()#text(" conjecture. Conrey thinks any possible proof would have to be")#linebreak()#text(" of a combinatorial nature. However, such hard problems may")#linebreak()#text(" be beyond the technical capabilities of the human brain, much")#linebreak()#text(" like it is impossible to win with a desktop computer anymore.")#linebreak()#text(" There are plenty of other (entry level) challenging problems for")#linebreak()#text(" the foreseable future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10616")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("Just a reminder: please keep discussions relevant to the topic at hand; in particular, physics discussions should probably be held in some other venue than this blog. [Incidentally, regarding the interactions between physics and number theory: physical intuition has proven to be quite useful in making accurate ")#emph[#text("predictions")]#text(" about many mathematical objects, such as the distribution of zeroes of the Riemann zeta function, but has been significantly less useful in generating ")#emph[#text("rigorous proofs")]#text(" of these predictions. In number theory, our ability to make accurate predictions on anything relating to the primes (or related objects) is now remarkably good, but our ability to actually ")#emph[#text("prove")]#text(" these predictions rigorously lags behind quite significantly. So I doubt that the key to further rigorous progress on these problems lies with physics.]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of x")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10624")[#strong[#text("x")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("“the key to further rigorous progress on these problems lies with physics.”I can’t agree with you.Could you explain it detailly?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10625")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 September 2007")])]

#text("I ")#link("http://dictionary.reference.com/browse/doubt")[#emph[#text("doubt")]]#text(" that the key to further rigorous progress in analytic number theory lies with physics.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ratner’s theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10663")[#strong[#text("Ratner’s theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2007")])]

#text("[…] Marina Ratner, Oppenheim conjecture, orbits, Ratner’s theorem, unipotent flows While working on my recent paper with Ben Green, I was introduced to the beautiful theorems of Marina Ratner on unipotent flows on homogeneous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10664")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2007")])]

#text("Regarding an earlier question: there is not much of a link between nilpotents (such as matrices A with ")#mi("A^m = 0")#text(" for some m) and idempotents (such as matrices A with ")#mi("A^2 = A")#text("). For instance, in the ring of diagonal matrices, there are several non-trivial idempotents but no non-trivial nilpotents; conversely, in the ring of strictly upper-triangular matrices, all matrices are nilpotent but none are idempotent (indeed, it is clear that a non-zero nilpotent cannot be idempotent).")

#text("There is however a strong link between nilpotents and unipotents; by definition, a matrix A is unipotent if and only if A-I is nilpotent (and there are similar definitions for more abstract algebras).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Daniel")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10763")[#strong[#text("Daniel")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear Terry,")#linebreak()#text(" It may not be much of a revelation, but some rigorous attempts")#linebreak()#text(" at proving physically intuitive directions for the distribution of zeroes")#linebreak()#text(" are described in:")#linebreak()#text(" Percy Deift, Integrable systems and combinatorial theory, Notices")#linebreak()#text(" of the AMS (2000), 631-640,")#linebreak()#text(" where he builds on the computation of the limiting statistics of e-values")#linebreak()#text(" of a randon GUE matrix in terms of solutions of the Painleve II equation")#linebreak()#text(" in:")#linebreak()#text(" C. A. Tracy and H. Widom, Level-spacing distributions and the Airy")#linebreak()#text(" kernel, Comm. Math. Phys. 159 (1994), 151-174.")#linebreak()#text(" There was one more down-to-earth esthetic result, but I can’t kind")#linebreak()#text(" recall it at the moment.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5cd6b950004dd1c35c9f6a4a071cb30ee71979b6cbce015182861d72ed634263-b073529ba13093ef32cc921407d0457bbd360dfca8181636c4ded3cf4e45ee9e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alfonso Martinez")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10773")[#strong[#text("Alfonso Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear Terry,")

#text("after reading your post, I wondered whether one could possibly establish a connection between your quantitative results and the behaviour of a sum of independent random variables. In this case, and as $n\\to \\infty$, there is also a dichotomy between variables which converge to a lattice and continuous random variables. The proof also seems to make heavy use of Fourier analysis. For these extreme cases, it is also known that saddlepoint approximations to the sum are very accurate, even for low values of $n$.")

#text("But then, one can construct random variables with “peaky” densities, say a train of Dirac deltas placed at a lattice convolved by a Gaussian density with small variance, much smaller than the lattice spacing. As one adds many random variables, one moves from a lattice-like density towards a continuous density. Using a saddlepoint approximation would require switching from one formula (the lattice-like approximation) to another (the continuous random variable case).")

#text("It may be a silly or obvious question, but do you know if there are any quantitative results valid for low values of $n$ which would automatically include the “switching” between the two extreme cases? Could your analysis be applied to this case?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10777")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear Daniel,")

#text("There has indeed been a remarkable amount of progress in understanding eigenvalues of random matrices or random operators. But the trouble is that in number theory, objects such as the primes or the zeta function are not random; they are conjectured to be ")#emph[#text("pseudorandom")]#text(" in a number of senses, which is why we can confidently make several predictions about their statistics, but they are still, ultimately, deterministic objects. The fundamental problem, in my opinion, is to develop tools that can rigorously establish various types of pseudorandomness properties for these number-theoretic objects; once we can establish sufficiently high levels of pseudorandomness, we should be able to rigorously show that predictions from, say, random matrix theory, are in fact accurate. Intuition from physics has helped us understand the ")#emph[#text("consequences")]#text(" of randomness and pseudorandomness quite a bit, but has not really given us any means to ")#emph[#text("rigorously establish")]#text(" pseudorandomness (cf. “Maxwell’s demon”, which could theoretically create extremely improbable situations which violate statistical physical reasoning, such as the second law of thermodynamics, and thus prevents such reasoning from being completely rigorous). Here it seems to me that insights from arithmetic geometry, harmonic analysis, ergodic theory and dynamical systems, combinatorics, and possibly even complexity theory, will be important.")

#text("Dear Alfonso: It seems to me that the situation you describe is more a problem in harmonic analysis and high-dimensional geometry than in ergodic theory or group theory; in particular, there does not seem to be a dynamical system present in your setting (except possibly in the asymptotic limit ")#mi("n \\to \\infty")#text(", in which case a Bernoulli shift system begins to make an appearance). Your problem seems to be related to that of understanding the large Fourier coefficients of a probability measure on the real line, which is a question which has been intensively studied in harmonic analysis and also additive combinatorics, but is probably not directly related to my work with Ben (other than through use of common tools such as the Fourier transform, or by touching on common themes such as the dichotomy between structure and randomness).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10786")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("If we look at the pseudo-randomness related to random matrix models for values of the zeta function (and more general L-functions), we are currently in a very frustrating situation: the first tool we would like to use to prove rigorously ")#emph[#text("some")]#text(" of the consequences of pseudo-randomness is the Riemann Hypothesis (and its generalizations) which provide cancellation in various sums that parallel what one would expect from analogue random variables. However, GRH is precisely what we are trying to understand and hope to prove!")#linebreak()#text(" In a few basic (and important) cases, the current knowledge of zeros of L-functions (and other related things) is sufficient to confirm the random matrix models, and to build great confidence in it (analogues over finite fields are also helpful in that respect), but the limits of what we can do are clearly understood.")#linebreak()#text(" (I like to think, to avoid being depressed, that this state of affairs is similar to the beginning of the Langlands Program: lots of intuitions, a very coherent picture that emerges, quite a few impressive special cases, but a great fundamental mystery still unresolved… and quite possibly the Weil Conjectures looked the same around the time they were formulated).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10792")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Dear Emmanuel: In the spirit of “not getting depressed”, we can at least hope to rigorously derive strong versions of pseudorandomness from weak ones (e.g. it is conceivable that the GUE spacing of zeta could be deduced from something which looks weaker, such as GRH and pair correlations, especially if random matrix theory develops to the point where GUE statistics can be deduced from relatively weak pseudorandomness hypotheses). The Gowers inverse conjecture GI(s) is in this spirit, asserting that in order to obtain pseudorandomness in the sense of statistics of linear patterns, it suffices to establish the weaker pseudorandomness of not being correlated with nilsequences, which is a more feasible task when it comes to the primes (or proxies for the primes, such as the Mobius function) thanks to tools such as Vinogradov’s method. (I hope to discuss these issues in some subsequent posts.)")

#text("Vinogradov’s method, by the way, ultimately relies on the (additive) randomness extractor properties of integer multiplication, which is one of the few devices I know of with which one can generate rigorously pseudorandom outputs from inputs which are not known to be pseudorandom. It could be that a better understanding of this phenomenon could lead to more progress.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ceab6bd9705bb05759588ec747427b5a445200daa87bd88ea28b0182e39ab04-8403283141d4b3624795748214ef53a17144ca6b53d3dd1f0b15f61fe3fd5b23.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-10793")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2007")])]

#text("Yes, I definitely shouldn’t have written “the limits of what we can do are clearly understood”; it’s only what is done the way it has been done historically which seems clearly limited. New insights can come and show that previous expectations were wrong, as certainly is happening for patterns among primes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/88df63faf7cf9e865cd5885f26186ac889566dc1a60a51ff12aff31910a9fc32-389878d4e43285b5a62f0806a4b442f5358f565182b5c7b44b1d61339f60faa5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Doug")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-11379")[#strong[#text("Doug")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2007")])]

#text("Hi Terence,")

#text("Speculation:")#linebreak()#text(" From the perspective of Bifurcation Theory and tori, is it possible to unify the work of Connes, Yau, Witten, Borcherds and Tao?")

#text("In your paper with Ben Green is this phrase “… let us briefly review what happens for higher-dimensional torii”.")

#text("It seems possible that this may relate to the Monster, proved by Richard Borcherds?")#linebreak()#text(" In Scientific American Magazine, November 1998, Profile: Monstrous Moonshine is True by Gibbs, the symmetry of the monster is described as a ”folded doughnut”.")#linebreak()#text(" This may be equivalent to toroidal symmetry?")

#text("Edward Witten recently published Three-dimensional gravity revisited [arXiv:0706.3359] apparently embracing the Monster.")#linebreak()#text(" There may be a way of transforming 11-D M-theory to conform with the monster description of #-complex-D, string-[or coupling]-D, time-D where #=24 for monster and #=3 nested within 3 for M-theory, particularly if there should be 8 nestings of 3 in the monster?")

#text("The Calabi-[Shing-Tung]Yau manifolds may be complex tori?")#linebreak()#text(" The description of these quantum manifolds may suggest a likeness to celestial bodies such as the Earth and Sun when their respective magnetospheres are included?")

#text("There may be a tenuous relation between your work with ergodic theory and that of Alain Connes with noncommutative geometry through the perspective of Chaos Theory.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of teaspoon")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-11390")[#strong[#text("teaspoon")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2007")])]

#text("I think Doug has missed the fact that Publius ")#strong[#text("Terentius")]#text(" Afer was likely born around 185 BC, the same year that then Indian emperor Brhadrata passed away, and about 2000 years before the Indiana mathematician Ramanujan was born. Since we all known the relevance of Ramanujan’s modular function to the identities satisfied by Fermion strings and also the prominent role that reincarnation plays in Hinduism, is it possible that Professor Tao’s Roman playwright pre-incarnate foretold the future coming of M-theory, 2000 years before Witten?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Lecture 16: A Ratner-type theorem for nilmanifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-27068")[#strong[#text("254A, Lecture 16: A Ratner-type theorem for nilmanifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 March 2008")])]

#text("[…] series (which is the “minimal” filtration available to a group G); see for instance my paper with Ben Green on this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The van der Corput’s trick, and equidistribution on nilmanifolds « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-30357")[#strong[#text("The van der Corput’s trick, and equidistribution on nilmanifolds « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2008")])]

#text("[…] with Ben Green on the quantitative behaviour of polynomial sequences in nilmanifolds, which I have blogged about previously. During my talk (and inspired by the immediately preceding talk of Vitaly Bergelson), I stated […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-30681")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2008")])]

#text("This is just spectator curiosity but are the results of the recent preprint ")#link("http://arxiv.org/PS_cache/arxiv/pdf/0806/0806.4535v1.pdf")[#text("http://arxiv.org/PS_cache/arxiv/pdf/0806/0806.4535v1.pdf")]#text(" a strong enough to substitute for the Gowers inverse conjecture to establish the nondegenerate case of Dickson’s conjecture, or is more needed?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-30682")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2008")])]

#text("Dear anonymous,")

#text("Well, firstly the results you mention (and in the parent post) are for the finite field case rather than the integer case, but they would in principle be applicable to the finite field version of Dickson’s conjecture (though I don’t think anyone has worked this out fully in all details). The more serious issue is that these results are restricted to polynomials of reasonably bounded degree. For applications to Dickson’s conjecture, one needs to apply the inverse conjecture to functions that are something like the Mobius function (or some other similarly number-theoretic object). This function is not expected to behave polynomially (indeed, this is basically the content of the Mobius-nilsequences conjecture, which is another ingredient in the program to establish the non-degenerate case of Dickson’s conjecture). [Incidentally, I’ve recently been informed that our nomenclature for this conjecture is not too accurate; “generalised Hardy-Littlewood prime tuples conjecture” would be somewhat more appropriate, if wordier, than “Dickson’s conjecture”.]")

#text("On the other hand, what these results do imply is that a “weak” form of the Gowers inverse conjecture for finite fields (in which correlation is established with a high-degree polynomial rather than a polynomial of the correct degree) will automatically imply the strong form of the conjecture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anonymous")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-30838")[#strong[#text("anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("What would the statment of the finite field Dickson’s / “the generalised Hardy-Littlewood prime tuples conjecture” look like? At least to me, there doesn’t seem to be a way to form an obvious analog. Maybe I’m thinking about this incorrectly, but I think of these conjectures as vast generalizations of the PNT — but I’ve never seen a result called the finite field PNT?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-30844")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2008")])]

#text("Dear anonymous,")

#text("The finite field PNT would be the assertion that the number of monic irreducible polynomials (the analogue of primes) of degree at most n in a polynomial ring F[T] over a finite field F is equal to (1 + o(1)) |F|^n / n. Actually this is quite easy to prove compared to the PNT for integers (see e.g. my ")#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("post on dyadic models")]#text(").")

#text("The analogue of Dickson’s conjecture would then be an assertion about the number of polynomials ")#mi("P_1,\\ldots,P_d")#text(" in F[T] of degree at most n such that the linear forms ")#mi("a_{i,1} P_1 + \\ldots + a_{i,d} P_d + b_i")#text(" are simultaneously monic irreducible polynomials for ")#mi("1 \\leq i \\leq k")#text(", where ")#mi("a_{i,j}, b_i")#text(" are fixed polynomials. This number should be infinite provided that there are no local obstructions, and one can also predict an asymptotic for this number by the usual heuristics, in exact analogy with the integer case (for instance, one could adapt the discussion in the introduction of my ")#link("http://arxiv.org/abs/math.NT/0606088")[#text("linear equations in primes")]#text(" paper with Ben).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Mobius function is strongly orthogonal to nilsequences « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-31322")[#strong[#text("The Mobius function is strongly orthogonal to nilsequences « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 July 2008")])]

#text("[…] quantitative behaviour of polynomial orbits on nilmanifolds“, which I talked about in this post. In this paper, we apply our previous results on quantitative equidistribution polynomial orbits […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marker lectures II, “Linear equations in primes” « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-33588")[#strong[#text("Marker lectures II, “Linear equations in primes” « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2008")])]

#text("[…] enough for our purposes, and we had to develop a quantitative analogue of this theory; see these blog posts for more discussion. Anyway, it all works, and gives asymptotics for progressions of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the Gowers U^4 norm « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-42677")[#strong[#text("An inverse theorem for the Gowers U^4 norm « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2009")])]

#text("[…] using Ratner’ s theorem (or more precisely, a quantitative version of this theorem that Ben and I worked out a few years ago) by a certain subgroup H of the product of three Heisenberg groups (times an abelian group to take […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-43606")[#strong[#text("An arithmetic regularity lemma, an associated counting lemma, and applications « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("[…] The regularity lemma is a manifestation of the “dichotomy between structure and randomness”, as discussed for instance in my ICM article or FOCS article. In the degree case , this result is essentially due to Green. It is powered by the inverse conjecture for the Gowers norms, which we and Tamar Ziegler have recently established (paper to be forthcoming shortly; the case of our argument is discussed here). The counting lemma is established through the quantitative equidistribution theory of nilmanifolds, which Ben and I set out in this paper. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-45212")[#strong[#text("254B, Notes 6: The inverse conjecture for the Gowers norm II. The integer case « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2010")])]

#text("[…] and also follows from the above van der Corput lemma and some tedious additional computations; see this paper of Green and myself for details. For linear orbits, this result was established by Parry and by Leon Green. Using this […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An inverse theorem for the continuous Gowers uniformity norm | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-457579")[#strong[#text("An inverse theorem for the continuous Gowers uniformity norm | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 July 2015")])]

#text("[…] theorem, together with an equidistribution theorem for nilsequences that Ben and I worked out in a separate paper, implies a continuous […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Equidistribution for multidimensional polynomial phases | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-457999")[#strong[#text("Equidistribution for multidimensional polynomial phases | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2015")])]

#text("[…] nilsequence, and in which one does not necessarily assume the exponential sum is small, is given in this paper of Ben Green and myself, but it involves far more notation to even state […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Notes on nilcharacters and their symbols | What's new")]], [#link("https://terrytao.wordpress.com/2007/09/25/the-quantitative-behaviour-of-polynomial-orbits-on-nilmanifolds/comment-page-1/#comment-480134")[#strong[#text("Notes on nilcharacters and their symbols | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2017")])]

#text("[…] assume . Write . Now we appeal to the factorisation theorem for nilsequences (see Corollary 1.12 of this paper of myself and Ben Green to […]")
]
