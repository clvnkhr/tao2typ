// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:19:37.627450+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "275A, Notes 5: Variants of the central limit theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("275A, Notes 5: Variants of the central limit theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 19 November 2015")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/")[#text("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("the previous set of notes")]#text(" we established the ")#link("https://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text(", which we formulate here as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Central limit theorem)")]#text(" Let ")#mi("{X_1,X_2,X_3,\\dots}")#text(" be iid copies of a real random variable ")#mi("{X}")#text(" of mean ")#mi("{\\mu}")#text(" and variance ")#mi("{0 < \\sigma^2 < \\infty}")#text(", and write ")#mi("{S_n := X_1 + \\dots + X_n}")#text(". Then, for any fixed ")#mi("{a < b}")#text(", we have ")#metadata(none) <tao-4945a70fa7f9c13fe193>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\bf P}( a \\leq \\frac{S_n - n \\mu}{\\sqrt{n} \\sigma} \\leq b ) \\rightarrow \\frac{1}{\\sqrt{2\\pi}} \\int_a^b e^{-t^2/2}\\ dt")]]



#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#text("This is however not the end of the matter; there are many variants, refinements, and generalisations of the central limit theorem, and the purpose of this set of notes is to present a small sample of these variants.")

#text("First of all, the above theorem does not quantify the ")#emph[#text("rate")]#text(" of convergence in ")#link(<tao-4945a70fa7f9c13fe193>)[#text("(1)")]#text(". We have already addressed this issue to some extent with the ")#link("https://en.wikipedia.org/wiki/Berry%E2%80%93Esseen_theorem")[#text("Berry-Esséen theorem")]#text(", which roughly speaking gives a convergence rate of ")#mi("{O(1/\\sqrt{n})}")#text(" uniformly in ")#mi("{a,b}")#text(" if we assume that ")#mi("{X}")#text(" has finite third moment. However there are still some quantitative versions of ")#link(<tao-4945a70fa7f9c13fe193>)[#text("(1)")]#text(" which are not addressed by the Berry-Esséen theorem. For instance one may be interested in bounding the ")#emph[#text("large deviation probabilities")]#text(" ")#metadata(none) <tao-e7de46390a4a467a50ab>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("{\\bf P}( \\left|\\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}\\right| \\geq \\lambda )", block: true)]]



#text(" in the setting where ")#mi("{\\lambda}")#text(" grows with ")#mi("{n}")#text(". Chebyshev’s inequality gives an upper bound of ")#mi("{1/\\lambda^2}")#text(" for this quantity, but one can often do much better than this in practice. For instance, the central limit theorem ")#link(<tao-4945a70fa7f9c13fe193>)[#text("(1)")]#text(" suggests that this probability should be bounded by something like ")#mi("{O( e^{-\\lambda^2/2})}")#text("; however, this theorem only kicks in when ")#mi("{n}")#text(" is very large compared with ")#mi("{\\lambda}")#text(". For instance, if one uses the Berry-Esséen theorem, one would need ")#mi("{n}")#text(" as large as ")#mi("{e^{\\lambda^2}}")#text(" or so to reach the desired bound of ")#mi("{O( e^{-\\lambda^2/2})}")#text(", even under the assumption of finite third moment. Basically, the issue is that convergence-in-distribution results, such as the central limit theorem, only really control the ")#emph[#text("typical")]#text(" behaviour of statistics in ")#mi("{\\frac{S_n-n \\mu}{\\sqrt{n} \\sigma}}")#text("; they are much less effective at controlling the very rare ")#emph[#text("outlier")]#text(" events in which the statistic strays far from its typical behaviour. Fortunately, there are ")#link("https://en.wikipedia.org/wiki/Large_deviations_theory")[#text("large deviation inequalities")]#text(" (or ")#emph[#text("concentration of measure inequalities")]#text(") that do provide exponential type bounds for quantities such as ")#link(<tao-e7de46390a4a467a50ab>)[#text("(2)")]#text(", which are valid for both small and large values of ")#mi("{n}")#text(". A basic example of this is the Chernoff bound that made an appearance in Exercise 47 of ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("Notes 4")]#text("; here we give some further basic inequalities of this type, including versions of the Bennett and Hoeffding inequalities.")

#text("In the other direction, we can also look at the fine scale behaviour of the sums ")#mi("{S_n}")#text(" by trying to control probabilities such as ")#metadata(none) <tao-4a630b8e79a0cd2fbae3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf P}( a \\leq S_n \\leq a+h )")]]



#text(" where ")#mi("{h}")#text(" is now bounded (but ")#mi("{a}")#text(" can grow with ")#mi("{n}")#text("). The central limit theorem predicts that this quantity should be roughly ")#mi("{\\frac{h}{\\sqrt{2\\pi n} \\sigma} e^{-(a-n\\mu)^2 / 2n \\sigma^2}}")#text(", but even if one is able to invoke the Berry-Esséen theorem, one cannot quite see this main term because it is dominated by the error term ")#mi("{O(1/n^{1/2})}")#text(" in Berry-Esséen. There is good reason for this: if for instance ")#mi("{X}")#text(" takes integer values, then ")#mi("{S_n}")#text(" also takes integer values, and ")#mi("{{\\bf P}( a \\leq S_n \\leq a+h )}")#text(" can vanish when ")#mi("{h}")#text(" is less than ")#mi("{1}")#text(" and ")#mi("{a}")#text(" is slightly larger than an integer. However, this turns out to essentially be the only obstruction; if ")#mi("{X}")#text(" does not lie in a lattice such as ")#mi("{{\\bf Z}}")#text(", then we can establish a ")#emph[#text("local limit theorem")]#text(" controlling ")#link(<tao-4a630b8e79a0cd2fbae3>)[#text("(3)")]#text(", and when ")#mi("{X}")#text(" does take values in a lattice like ")#mi("{{\\bf Z}}")#text(", there is a discrete local limit theorem that controls probabilities such as ")#mi("{{\\bf P}(S_n = m)}")#text(". Both of these limit theorems will be proven by the Fourier-analytic method used in ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("the previous set of notes")]#text(".")

#text("We also discuss other limit theorems in which the limiting distribution is something other than the normal distribution. Perhaps the most common example of these theorems is the Poisson limit theorems, in which one sums a large number of indicator variables (or approximate indicator variables), each of which is rarely non-zero, but which collectively add up to a random variable of medium-sized mean. In this case, it turns out that the limiting distribution should be a ")#link("https://en.wikipedia.org/wiki/Poisson_distribution")[#text("Poisson random variable")]#text("; this again is an easy application of the Fourier method. Finally, we briefly discuss limit theorems for other stable laws than the normal distribution, which are suitable for summing random variables of infinite variance, such as the ")#link("https://en.wikipedia.org/wiki/Cauchy_distribution")[#text("Cauchy distribution")]#text(".")

#text("Finally, we mention a very important class of generalisations to the CLT (and to the variants of the CLT discussed in this post), in which the hypothesis of joint independence between the variables ")#mi("{X_1,\\dots,X_n}")#text(" is relaxed, for instance one could assume only that the ")#mi("{X_1,\\dots,X_n}")#text(" form a martingale. Many (though not all) of the proofs of the CLT extend to these more general settings, and this turns out to be important for many applications in which one does not expect joint independence. However, we will not discuss these generalisations in this course, as they are better suited for subsequent courses in this series when the theory of martingales, conditional expectation, and related tools are developed.")

#metadata(none) <tao-17aacd6c416033362e79>

#heading(level: 1)[#strong[#text(" — 1. Large deviation inequalities — ")]]

#text("We now look at some upper bounds for the large deviation probability ")#link(<tao-e7de46390a4a467a50ab>)[#text("(2)")]#text(". To get some intuition as to what kinds of bounds one can expect, we first consider some examples. First suppose that ")#mi("{X \\equiv N(0,1)}")#text(" has the standard normal distribution, then ")#mi("{\\mu=0}")#text(", ")#mi("{\\sigma^2=1}")#text(", and ")#mi("{S_n}")#text(" has the distribution of ")#mi("{N(0,n)}")#text(", so that ")#mi("{\\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}}")#text(" has the distribution of ")#mi("{N(0,1)}")#text(". We thus have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}\\right| \\geq \\lambda ) = \\frac{2}{\\sqrt{2\\pi}} \\int_\\lambda^\\infty e^{-t^2/2}\\ dt", block: true)]]

#text("which on using the inequality ")#mi("{e^{-t^2/2} \\leq e^{-\\lambda^2/2} e^{-\\lambda (t-\\lambda)}}")#text(" leads to the bound ")#metadata(none) <tao-2c371c2ada73a02e26e1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("{\\bf P}( \\left|\\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}\\right| \\geq \\lambda ) \\leq \\lambda^{-1} e^{-\\lambda^2/2}.", block: true)]]



#text(" Next, we consider the example when ")#mi("{X}")#text(" is a Bernoulli random variable drawn uniformly at random from ")#mi("{\\{0,1\\}}")#text(". Then ")#mi("{\\mu=1/2}")#text(", ")#mi("{\\sigma^2=1/4}")#text(", and ")#mi("{S_n}")#text(" has the standard binomial distribution on ")#mi("{\\{0,\\dots,n\\}}")#text(", thus ")#mi("{{\\bf P}(S_n=i) = \\binom{n}{i}/2^i}")#text(". By symmetry, we then have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}\\right| \\geq \\lambda ) = \\sum_{i \\geq \\frac{n}{2} + \\frac{\\lambda \\sqrt{n}}{2}} \\binom{n}{i} / 2^i.", block: true)]]

#text("We recall Stirling’s formula, which we write crudely as")

#align(center)[#tao-fit-display[#mitex("n! = n^n e^{-n + o(n)} = \\exp( n \\log n - n + o(n) )")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(", where ")#mi("{o(n)}")#text(" denotes a quantity with ")#mi("{o(n)/n \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" (and similarly for other uses of the ")#mi("{o()}")#text(" notation in the sequel). If ")#mi("{i = \\alpha n}")#text(" and ")#mi("{\\alpha}")#text(" is bounded away from zero and one, we then have the asymptotic")

#align(center)[#tao-fit-display[#mitex("\\binom{n}{i} = \\exp( h(\\alpha) n + o(n) )")]]

#text("where ")#mi("{h(\\alpha)}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Binary_entropy_function")[#text("entropy function")]

#align(center)[#tao-fit-display[#mitex("h(\\alpha) := \\alpha \\log \\frac{1}{\\alpha} + (1-\\alpha) \\log \\frac{1}{1-\\alpha}")]]

#text("(compare with Exercise 17 of ")#link("https://terrytao.wordpress.com/2015/10/23/275a-notes-3-the-weak-and-strong-law-of-large-numbers/")[#text("Notes 3")]#text("). One can check that ")#mi("{h(\\alpha)}")#text(" is decreasing for ")#mi("{1/2 \\leq \\alpha \\leq 1}")#text(", and so one can compute that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}\\right| \\geq \\theta \\sqrt{n} ) = \\exp( (h(\\frac{1+\\theta}{2}) - \\log 2 + o(1)) n )", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{0 < \\theta < 1}")#text(". To compare this with ")#link(<tao-2c371c2ada73a02e26e1>)[#text("(4)")]#text(", observe from Taylor expansion that")

#align(center)[#tao-fit-display[#mitex("h(\\frac{1+\\theta}{2}) = - \\frac{\\theta^2}{2} + o(\\theta^2)")]]

#text("as ")#mi("{\\theta \\rightarrow 0}")#text(".")

#text("Finally, consider the example where ")#mi("{X}")#text(" takes values in ")#mi("{\\{0,1\\}}")#text(" with ")#mi("{{\\bf P}(X=0)=1-p}")#text(" and ")#mi("{{\\bf P}(X=1)=p}")#text(" for some small ")#mi("{0 < p < 1/2}")#text(", thus ")#mi("{\\mu = p}")#text(" and ")#mi("{\\sigma^2 = p - p^2 \\approx p}")#text(". We have ")#mi("{{\\bf P}(S_n = n) = p^n}")#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n - n \\mu}{\\sqrt{n} \\sigma}\\right| \\geq \\lambda ) = p^n = \\exp( - n \\log \\frac{1}{p} )", block: true)]]

#text("with")

#align(center)[#tao-fit-display[#mitex("\\lambda := \\sqrt{n} \\frac{\\sqrt{1-p}}{\\sqrt{p}} \\approx \\sqrt{n} / \\sqrt{p}.")]]

#text("Here, we see that the large deviation probability ")#mi("{\\exp( - n \\log \\frac{1}{p} )}")#text(" is somewhat larger than the gaussian prediction of ")#mi("{\\exp( - c \\lambda^2 )}")#text(". Instead, the exponent ")#mi("{n \\log \\frac{1}{p}}")#text(" is approximately related to ")#mi("{\\lambda}")#text(" and ")#mi("{\\sigma}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("n \\log \\frac{1}{p} \\approx \\lambda \\sqrt{n} \\sigma \\log \\frac{\\lambda}{\\sqrt{n} \\sigma}.")]]

#text("We now give a general large deviations inequality that is consistent with the above examples.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Cheap Bennett inequality)")]#text(" Let ")#mi("{a > 0}")#text(", and let ")#mi("{X_1,\\dots,X_n}")#text(" be independent random variables, each of which takes values in an interval of length at most ")#mi("{a}")#text(". Write ")#mi("{S_n := X_1+\\dots+X_n}")#text(", and write ")#mi("{\\mu^{(n)}}")#text(" for the mean of ")#mi("{S_n}")#text(". Let ")#mi("{\\sigma^{(n)} > 0}")#text(" be such that ")#mi("{S_n}")#text(" has variance at most ")#mi("{(\\sigma^{(n)})^2}")#text(". Then for any ")#mi("{\\lambda > 0}")#text(", we have ")#metadata(none) <tao-1f6fa6f69d185e6086d0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("{\\bf P}( \\left|\\frac{S_n - \\mu^{(n)}}{\\sigma^{(n)}}\\right| \\geq \\lambda ) \\leq 2 \\exp( - c \\min( \\lambda^2, \\frac{\\lambda \\sigma^{(n)}}{a} \\log \\frac{a \\lambda}{\\sigma^{(n)}} ) )", block: true)]]



#text(" for some absolute constant ")#mi("{c>0}")#text(".")
]

#text("There is more precise form of this inequality known as ")#link("https://en.wikipedia.org/wiki/Bennett%27s_inequality")[#text("Bennett’s inequality")]#text(", but we will not prove it here.")

#text("The first term in the minimum dominates when ")#mi("{\\lambda \\ll \\frac{\\sigma^{(n)}}{a}}")#text(", and the second term dominates when ")#mi("{\\lambda \\gg \\frac{\\sigma^{(n)}}{a}}")#text(". Sometimes it is convenient to weaken the estimate by discarding the logarithmic factor, leading to")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n - \\mu^{(n)}}{\\sigma^{(n)}}\\right| \\geq \\lambda ) \\leq 2 \\exp( - c \\min( \\lambda^2, \\frac{\\lambda \\sigma^{(n)}}{a} ) )", block: true)]]

#text("(possibly with a slightly different choice of ")#mi("{c}")#text("); thus we have Gaussian type large deviation estimates for ")#mi("{\\lambda}")#text(" as large as ")#mi("{\\sigma^{(n)}/a}")#text(", and (slightly better than) exponential decay after that.")

#text("In the case when ")#mi("{X_1,\\dots,X_n}")#text(" are iid copies of a random variable ")#mi("{X}")#text(" of mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(" taking values in an interval of length ")#mi("{1}")#text(", we have ")#mi("{\\mu^{(n)} = n \\mu}")#text(" and ")#mi("{(\\sigma^{(n)})^2 \\leq n \\sigma^2}")#text(", and the above inequality simplifies slightly to")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\frac{S_n - n\\mu}{\\sqrt{n} \\sigma}\\right| \\geq \\lambda ) \\leq 2 \\exp( - c \\min( \\lambda^2, \\lambda \\sqrt{n} \\sigma \\log \\frac{\\lambda}{\\sqrt{n} \\sigma} ) ).", block: true)]]

#emph[#text("Proof:")]#text(" We first begin with some quick reductions. Firstly, by dividing the ")#mi("{X_i}")#text(" (and ")#mi("{S_n}")#text(", ")#mi("{\\mu^{(n)}}")#text(", and ")#mi("{\\sigma^{(n)}}")#text(") by ")#mi("{a}")#text(", we may normalise ")#mi("{a=1}")#text("; by subtracting the mean from each of the ")#mi("{X_i}")#text(", we may assume that the ")#mi("{X_i}")#text(" have mean zero, so that ")#mi("{\\mu^{(n)}=0}")#text(" as well. We also write ")#mi("{\\sigma_i^2}")#text(" for the variance of each ")#mi("{X_i}")#text(", so that ")#mi("{(\\sigma^{(n)})^2 \\geq \\sum_{i=1}^n \\sigma_i^2}")#text(". Our task is to show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|S_n\\right| \\geq \\lambda \\sigma^{(n)} ) \\leq 2 \\exp( - c \\min( \\lambda^2, \\lambda \\sigma^{(n)} \\log \\frac{\\lambda}{\\sigma^{(n)}} ) )", block: true)]]

#text("for all ")#mi("{\\lambda > 0}")#text(". We will just prove the upper tail bound")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n \\geq \\lambda \\sigma^{(n)} ) \\leq \\exp( - c \\min( \\lambda^2, \\lambda \\sigma^{(n)} \\log \\frac{\\lambda}{\\sigma^{(n)}} ) );")]]

#text("the lower tail bound then follows by replacing all ")#mi("{X_i}")#text(" with their negations ")#mi("{-X_i}")#text(", and the claim then follows by summing the two estimates.")

#text("We use the “exponential moment method”, previously seen in proving the Chernoff bound (Exercise 47 of ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("Notes 4")]#text("), in which one uses the exponential moment generating function ")#mi("{t \\mapsto {\\bf E} e^{tS_n}}")#text(" of ")#mi("{S_n}")#text(". On the one hand, from Markov’s inequality one has")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n \\geq \\lambda \\sigma^{(n)} ) \\leq \\exp( - t \\lambda \\sigma^{(n)}) {\\bf E} e^{t S_n}")]]

#text("for any real parameter ")#mi("{t}")#text(". On the other hand, from the joint independence of the ")#mi("{X_i}")#text(" one has")

#align(center)[#tao-fit-display[#mitex("{\\bf E} e^{t S_n} = \\prod_{i=1}^n {\\bf E} e^{tX_i}.")]]

#text("Since the ")#mi("{X_i}")#text(" take values in an interval of length at most ")#mi("{1}")#text(" and have mean zero, we have ")#mi("{X_i = O(1)}")#text(" and so ")#mi("{tX_i = O(t)}")#text(". This leads to the Taylor expansion")

#align(center)[#tao-fit-display[#mitex("e^{tX_i} = 1 + t X_i + O(e^{O(t)} t^2 X_i^2 )")]]

#text("so on taking expectations we have")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} e^{t X_i}  & = 1 + O( e^{O(t)} t^2 \\sigma_i^2 )", block: true)



#tao-math(" & = \\exp( O( e^{O(t)} t^2 \\sigma_i^2 ) ).", block: true)
]

#text("Putting all this together, we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n \\geq \\lambda \\sigma^{(n)} ) \\leq \\exp( - t \\lambda \\sigma^{(n)} + O(e^{O(t)} t^2 (\\sigma^{(n)})^2) ).")]]

#text("If ")#mi("{\\lambda \\leq 10 \\sigma^{(n)}}")#text(" (say), one can then set ")#mi("{t}")#text(" to be a small multiple of ")#mi("{\\lambda / \\sigma^{(n)}}")#text(" to obtain a bound of the form")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n \\geq \\lambda \\sigma^{(n)} ) \\leq \\exp( - c \\lambda^2 ).")]]

#text("If instead ")#mi("{\\lambda > 10 \\sigma^{(n)}}")#text(", one can set ")#mi("{t}")#text(" to be a small multiple of ")#mi("{\\log \\frac{\\lambda}{\\sigma^{(n)}}}")#text(" to obtain a bound of the form")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n \\geq \\lambda \\sigma^{(n)} ) \\leq \\exp( - c \\lambda \\sigma^{(n)} \\log \\frac{\\lambda}{\\sigma^{(n)}} ).")]]

#text("In either case, the claim follows. ")#mi("\\Box")

#text("The following variant of the above proposition is also useful, in which we get a simpler bound at the expense of worsening the quantity ")#mi("{\\sigma^{(n)}}")#text(" slightly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 3 (Cheap Hoeffding inequality)")]#text(" Let ")#mi("{X_1,\\dots,X_n}")#text(" be independent random variables, with each ")#mi("{X_i}")#text(" taking values in an interval ")#mi("{[a_i,b_i]}")#text(" with ")#mi("{b_i > a_i}")#text(". Write ")#mi("{S_n := X_1+\\dots+X_n}")#text(", and write ")#mi("{\\mu^{(n)}}")#text(" for the mean of ")#mi("{S_n}")#text(", and write")

#align(center)[#tao-fit-display[#mitex("(\\sigma^{(n)})^2 := \\sum_{i=1}^n (b_i-a_i)^2.")]]

#text("Then for any ")#mi("{\\lambda > 0}")#text(", we have ")#metadata(none) <tao-4d32c3ae3fee2d74c8d2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("{\\bf P}( \\left|\\frac{S_n - \\mu^{(n)}}{\\sigma^{(n)}}\\right| \\geq \\lambda ) \\leq 2 \\exp( - c \\lambda^2 )", block: true)]]



#text(" for some absolute constant ")#mi("{c>0}")#text(".")
]

#text("In fact one can take ")#mi("{c=2}")#text(", a fact known as ")#link("https://en.wikipedia.org/wiki/Hoeffding%27s_inequality")[#text("Hoeffding’s inequality")]#text("; see Exercise ")#link(<tao-632e93023886160a2a54>)[#text("6")]#text(" below for a special case of this.")

#emph[#text("Proof:")]#text(" We again normalise the ")#mi("{X_i}")#text(" to have mean zero, so that ")#mi("{\\mu^{(n)}=0}")#text(". We then have ")#tao-math("{\\left|X_i\\right| \\leq b_i-a_i}", block: false)#text(" for each ")#mi("{i}")#text(", so by Taylor expansion we have for any real ")#mi("{t}")#text(" that")

#align(center)[#tao-fit-display[#mitex("e^{tX_i} =1 + tX_i + O( t^2 (b_i-a_i)^2 \\exp( O( t (b_i-a_i) ) ) )")]]

#text("and thus")

#tao-aligned(keep: true)[


#tao-math("{\\bf E} e^{tX_i}  & = 1 + O( t^2 (b_i-a_i)^2 \\exp( O( t (b_i-a_i) ) ) )", block: true)



#tao-math(" & = \\exp( O( t^2 (b_i-a_i)^2 ) ).", block: true)
]

#text("Multiplying in ")#mi("{i}")#text(", we then have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} e^{tS_n} = \\exp( O( t^2 ( \\sigma^{(n)})^2 )")]]

#text("and one can now repeat the previous arguments (but without the ")#mi("{e^{O(t)}}")#text(" factor to deal with). ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" In the above examples, the underlying random variable ")#mi("{X}")#text(" was assumed to either be restricted to an interval, or to be subgaussian. This type of hypothesis is necessary if one wishes to have estimates on ")#link(<tao-e7de46390a4a467a50ab>)[#text("(2)")]#text(" that are similarly subgaussian. For instance, suppose ")#mi("{X}")#text(" has a ")#link("https://en.wikipedia.org/wiki/Zeta_distribution")[#text("zeta distribution")]

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X=m) = \\frac{1}{\\zeta(s)} \\frac{1}{m^s}")]]

#text("for some ")#mi("{s>1}")#text(" and all natural numbers ")#mi("{i}")#text(", where ")#mi("{\\zeta(s) := \\sum_{i=1}^\\infty \\frac{1}{m^s}}")#text(". One can check that this distribution has finite mean and variance for ")#mi("{s > 3}")#text(". On the other hand, since we trivially have ")#mi("{S_n \\geq X_1}")#text(", we have the crude lower bound")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(S_n \\geq m) \\geq {\\bf P}(X = m) = \\frac{1}{\\zeta(s)} \\frac{1}{m^s}")]]

#text("which shows that in this case the expression ")#link(<tao-e7de46390a4a467a50ab>)[#text("(2)")]#text(" only decays at a polynomial rate in ")#mi("{\\lambda}")#text(" rather than an exponential or subgaussian rate.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5 (Khintchine inequality)")]#text(" Let ")#mi("{\\varepsilon_1,\\dots,\\varepsilon_n}")#text(" be iid copies of a Bernoulli random variable ")#mi("{\\varepsilon}")#text(" drawn uniformly from ")#mi("{\\{-1,+1\\}}")#text(".")

#list(
[#text("(i) For any non-negative reals ")#mi("{a_1,\\dots,a_n}")#text(" and any ")#mi("{0 < p < \\infty}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\sum_{i=1}^n \\varepsilon_i a_i\\right|^p \\leq C_p (\\sum_{i=1}^n \\left|a_i\\right|^2)^{p/2}", block: true)]]

#text("for some constant ")#mi("{C_p}")#text(" depending only on ")#mi("{p}")#text(". When ")#mi("{p=2}")#text(", show that one can take ")#mi("{C_2=1}")#text(" and equality holds.")],
[#text("(ii) With the hypotheses in (i), obtain the matching lower bound")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left|\\sum_{i=1}^n \\varepsilon_i a_i\\right|^p \\geq c_p (\\sum_{i=1}^n \\left|a_i\\right|^2)^{p/2}", block: true)]]

#text("for some ")#mi("{c_p>0}")#text(" depending only on ")#mi("{p}")#text(". (")#emph[#text("Hint:")]#text(" use (i) and Hölder’s inequality.)")],
[#text("(iii) For any ")#mi("{0 < p < \\infty}")#text(" and any functions ")#mi("{f_1,\\dots,f_n \\in L^p(X)}")#text(" on a measure space ")#mi("{X = (X, {\\mathcal X},\\mu)}")#text(", show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\| \\sum_{i=1}^n \\varepsilon_i f_i \\right\\|_{L^p(X)}^p \\leq C_p \\left\\| (\\sum_{i=1}^n \\left|f_i\\right|^2)^{1/2} \\right\\|_{L^p(X)}^p", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("{\\bf E} \\left\\| \\sum_{i=1}^n \\varepsilon_i f_i \\right\\|_{L^p(X)}^p \\geq c_p \\left\\| (\\sum_{i=1}^n \\left|f_i\\right|^2)^{1/2} \\right\\|_{L^p(X)}^p", block: true)]]

#text("with the same constants ")#mi("{c_p, C_p}")#text(" as in (i), (ii). When ")#mi("{p=2}")#text(", show that one can take ")#mi("{c_2 = C_2=1}")#text(" and equality holds.")],
[#text("(iv) (Marcinkiewicz-Zygmund theorem) The Khintchine inequality is very useful in real analysis; we give one example here. Let ")#mi("{X, Y}")#text(" be measure spaces, let ")#mi("{1 < p < \\infty}")#text(", and suppose ")#mi("{T: L^p(X) \\rightarrow L^p(Y)}")#text(" is a linear operator obeying the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf\\right\\|_{L^p(Y)} \\leq A \\left\\|f\\right\\|_{L^p(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^p(X)}")#text(" and some finite ")#mi("{A}")#text(". Show that for any finite sequence ")#mi("{f_1,\\dots,f_n \\in L^p(X)}")#text(", one has the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\sum_{i=1}^n \\left|Tf_i\\right|^2)^{1/2} \\right\\|_{L^p(Y)} \\leq C^{\\prime}_p A \\left\\| (\\sum_{i=1}^n \\left|f_i\\right|^2)^{1/2} \\right\\|_{L^p(X)}", block: true)]]

#text("for some constant ")#mi("{C^{\\prime}_p}")#text(" depending only on ")#mi("{p}")#text(". (")#emph[#text("Hint:")]#text(" test ")#mi("{T}")#text(" against a random sum ")#mi("{\\sum_{i=1}^n \\varepsilon_i f_i}")#text(".)")],
[#text("(v) By using gaussian sums in place of random signs, show that one can take the constant ")#mi("{C^{\\prime}_p}")#text(" in (iv) to be one. (For simplicity, let us take the functions in ")#mi("{L^p(X), L^p(Y)}")#text(" to be real valued.)")]
)
]

#text("In this set of notes we have not focused on getting explicit constants in the large deviation inequalities, but it is not too difficult to do so with a little extra work. We give just one example here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" ")#metadata(none) <tao-632e93023886160a2a54>#text(" Let ")#mi("{\\varepsilon_1,\\dots,\\varepsilon_n}")#text(" be iid copies of a Bernoulli random variable ")#mi("{\\varepsilon}")#text(" drawn uniformly from ")#mi("{\\{-1,+1\\}}")#text(".")

#list(
[#text("(i) Show that ")#mi("{{\\bf E} e^{t \\varepsilon} \\leq \\exp( t^2/2 )}")#text(" for any real ")#mi("{t}")#text(". (")#emph[#text("Hint:")]#text(" expand both sides as an infinite Taylor series in ")#mi("{t}")#text(".)")],
[#text("(ii) Show that for any real numbers ")#mi("{a_1,\\dots,a_n}")#text(" and any ")#mi("{\\lambda > 0}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("{\\bf P}( \\left|\\sum_{i=1}^n \\varepsilon_i a_i\\right| > \\lambda (\\sum_{i=1}^n \\left|a_i\\right|^2)^{1/2} ) \\leq 2 e^{-\\lambda^2/2}.", block: true)]]

#text("(Note that this is consistent with ")#link(<tao-4d32c3ae3fee2d74c8d2>)[#text("(6)")]#text(" with ")#mi("{c=2}")#text(".)")]
)
]

#text("There are many further large deviation inequalities than the ones presented here. For instance, the ")#link("https://en.wikipedia.org/wiki/Azuma%27s_inequality")[#text("Azuma-Hoeffding inequality")]#text(" gives Hoeffding-type bounds when the random variables ")#mi("{X_1,\\dots,X_n}")#text(" are not assumed to be jointly independent, but are instead required to form a ")#link("https://en.wikipedia.org/wiki/Martingale_(probability_theory)")[#text("martingale")]#text(". Concentration of measure inequalities such as ")#link("https://en.wikipedia.org/wiki/Doob_martingale#McDiarmid.27s_inequality")[#text("McDiarmid’s inequality")]#text(" handle the situation in which the sum ")#mi("{S_n = X_1 + \\dots + X_n}")#text(" is replaced by a more nonlinear function ")#mi("{F(X_1,\\dots,X_n)}")#text(" of the input variables ")#mi("{X_1,\\dots,X_n}")#text(". There are also a number of refinements of the Chernoff estimate from the previous notes, that are collectively referred to as “")#link("https://en.wikipedia.org/wiki/Chernoff_bound")[#text("Chernoff bounds")]#text("“. The ")#link("https://en.wikipedia.org/wiki/Bernstein_inequalities_(probability_theory)")[#text("Bernstein inequalities")]#text(" handle situations in which the underlying random variable ")#mi("{X}")#text(" is not bounded, but enjoys good moment bounds. See ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("this previous blog post")]#text(" for these inequalities and some further discussion. Last, but certainly not least, there is an extensively developed ")#link("https://en.wikipedia.org/wiki/Large_deviations_theory")[#text("theory of large deviations")]#text(" which is focused on the precise exponent in the exponential decay rate for tail probabilities such as ")#link(<tao-e7de46390a4a467a50ab>)[#text("(2)")]#text(" when ")#mi("{\\lambda}")#text(" is very large (of the order of ")#mi("{\\sqrt{n}}")#text("); there is also a complementary theory of ")#emph[#text("moderate deviations")]#text(" that gives precise estimates in the regime where ")#mi("{\\lambda}")#text(" is much larger than one, but much less than ")#mi("{\\sqrt{n}}")#text(", for which we generally expect gaussian behaviour rather than exponentially decaying bounds. These topics are beyond the scope of this course.")

#heading(level: 1)[#strong[#text(" — 2. Local limit theorems — ")]]

#text("Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of a random variable ")#mi("{X}")#text(" of mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(", and write ")#mi("{S_n := X_1 + \\dots + X_n}")#text(". On the one hand, the central limit theorem tells us that ")#mi("{S_n}")#text(" should behave like the normal distribution ")#mi("{N(n\\mu, n\\sigma^2)}")#text(", which has probability density function ")#mi("{x \\mapsto \\frac{1}{\\sqrt{2\\pi n} \\sigma} e^{-(x-n\\mu)^2 / n \\sigma^2}}")#text(". On the other hand, if ")#mi("{X}")#text(" is discrete, then ")#mi("{S_n}")#text(" must also be discrete. For instance, if ")#mi("{X}")#text(" takes values in the integers ")#mi("{{\\bf Z}}")#text(", then ")#mi("{S_n}")#text(" takes values in the integers as well. In this case, we would expect (much as we expect a Riemann sum to approximate an integral) the probability distribution of ")#mi("{S_n}")#text(" to behave like the probability density function predicted by the central limit theorem, thus we expect ")#metadata(none) <tao-48b676e2b107da679512>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("{\\bf P}( S_n = m) \\approx \\frac{1}{\\sqrt{2\\pi n} \\sigma} e^{-(m-n\\mu)^2 / 2n \\sigma^2}")]]



#text(" for integer ")#mi("{m}")#text(". This is not a direct consequence of the central limit theorem (which does not distinguish between continuous or discrete random variables ")#mi("{X}")#text("), and in any case is not true in some cases: if ")#mi("{X}")#text(" is restricted to an infinite subprogression ")#mi("{a + q {\\bf Z}}")#text(" of ")#mi("{{\\bf Z}}")#text(" for some ")#mi("{q>1}")#text(" and integer ")#mi("{a}")#text(", then ")#mi("{S_n}")#text(" is similarly restricted to the infinite subprogression ")#mi("{na + q{\\bf Z}}")#text(", so that ")#link(<tao-48b676e2b107da679512>)[#text("(7)")]#text(" totally fails when ")#mi("{m}")#text(" is outside of ")#mi("{na+q{\\bf Z}}")#text(" (and when ")#mi("{m}")#text(" does lie in ")#mi("{na + q{\\bf Z}}")#text(", one would now expect the left-hand side of ")#link(<tao-48b676e2b107da679512>)[#text("(7)")]#text(" to be about ")#mi("{q}")#text(" times larger than the right-hand side, to keep the total probability close to ")#mi("{1}")#text("). However, this turns out to be the only obstruction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 7 (Discrete local limit theorem)")]#text(" ")#metadata(none) <tao-4b65a3a6e3cc23d53d88>#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an integer-valued random variable ")#mi("{X}")#text(" of mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(". Suppose furthermore that there is no infinite subprogression ")#mi("{a+q{\\bf Z}}")#text(" of ")#mi("{{\\bf Z}}")#text(" with ")#mi("{q>1}")#text(" for which ")#mi("{X}")#text(" takes values almost surely in ")#mi("{a+q{\\bf Z}}")#text(". Then one has")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n = m) = \\frac{1}{\\sqrt{2\\pi n} \\sigma} e^{-(m-n\\mu)^2 / 2n \\sigma^2} + o(1/n^{1/2})")]]

#text("for all ")#mi("{n \\geq 1}")#text(" and all integers ")#mi("{m}")#text(", where the error term ")#mi("{o(1/n^{1/2})}")#text(" is uniform in ")#mi("{m}")#text(". In other words, we have")

#align(center)[#tao-fit-display[#tao-math("\\sup_{m \\in {\\bf Z}} n^{1/2} \\left| {\\bf P}( S_n = m) - \\frac{1}{\\sqrt{2\\pi n} \\sigma} e^{-(m-n\\mu)^2 / 2n \\sigma^2}\\right| \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(".")
]

#text("Note for comparison that the Berry-Esséen theorem (writing ")#mi("{{\\bf P}( S_n = m)}")#text(" as, say, ")#mi("{{\\bf P}( m-1/2 \\leq S_n \\leq m+1/2 )}")#text(") would give (assuming finite third moment) an error term of ")#mi("{O(1/n^{1/2})}")#text(" instead of ")#mi("{o(1/n^{1/2})}")#text(", which would overwhelm the main term which is also of size ")#mi("{O(1/n^{1/2})}")#text(".")

#emph[#text("Proof:")]#text(" Unlike previous arguments, we do not have the luxury here use an affine change of variables to normalise to mean zero and variance one, as this would disrupt the hypothesis that ")#mi("{X}")#text(" takes values in ")#mi("{{\\bf Z}}")#text(".")

#text("Fix ")#mi("{n}")#text(" and ")#mi("{m}")#text(". Since ")#mi("{S_n}")#text(" and ")#mi("{m}")#text(" are integers, we have the Fourier identity")

#align(center)[#tao-fit-display[#mitex("1_{S_n = m} = \\frac{1}{2\\pi} \\int_{-\\pi}^{\\pi} e^{itS_n} e^{-itm}\\ dt,")]]

#text("which upon taking expectations and using Fubini’s theorem gives")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(S_n = m) = \\frac{1}{2\\pi} \\int_{-\\pi}^{\\pi} \\varphi_{S_n}(t) e^{-itm}\\ dt")]]

#text("where ")#mi("{\\varphi_{S_n}(t) := {\\bf E} e^{itS_n} }")#text(" is the characteristic function of ")#mi("{S_n}")#text(". Expanding ")#mi("{S_n = X_1 + \\dots + X_n}")#text(" and noting that ")#mi("{X_1,\\dots,X_n}")#text(" are iid copies of ")#mi("{X}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\varphi_{S_n}(t) = \\varphi_X(t)^n = e^{in \\mu t} \\varphi_{X-\\mu}(t)^n.")]]

#text("It will be convenient to make the change of variables ")#mi("{t = x/\\sqrt{n}}")#text(", to obtain")

#align(center)[#tao-fit-display[#mitex("\\sqrt{n} {\\bf P}(S_n = m) = \\frac{1}{2\\pi} \\int_{-\\pi \\sqrt{n}}^{\\pi \\sqrt{n}} \\varphi_{X-\\mu}(x/\\sqrt{n})^n e^{i\\mu x \\sqrt{n}} e^{-ixm/\\sqrt{n}}\\ dx.")]]

#text("As in the Fourier-analytic proof of the central limit theorem, we have ")#metadata(none) <tao-e96e02d8e47f2a7c03be>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\varphi_{X-\\mu}(t) = 1 - \\frac{\\sigma^2}{2} t^2 + o(t^2)")]]



#text(" as ")#mi("{t \\rightarrow 0}")#text(", so by Taylor expansion we have ")#metadata(none) <tao-df877645404747cb7973>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("\\varphi_{X-\\mu}(x/\\sqrt{n})^n \\rightarrow e^{-\\sigma^2 x^2 / 2}")]]



#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{x}")#text(". This suggests (but does not yet prove) that")

#align(center)[#tao-fit-display[#mitex("\\sqrt{n} {\\bf P}(S_n = m) \\rightarrow \\frac{1}{2\\pi} \\int_{\\bf R} e^{i \\mu x \\sqrt{n}} e^{-\\sigma^2 x^2/2} e^{-ixm/\\sqrt{n}}\\ dx.")]]

#text("A standard Fourier-analytic calculation gives")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2\\pi} \\int_{\\bf R} e^{i \\mu x \\sqrt{n}} e^{-\\sigma^2 x^2/2} e^{-ixm/\\sqrt{n}}\\ dx = \\frac{1}{\\sqrt{2\\pi} \\sigma} e^{-(m-n\\mu)^2 / 2n \\sigma^2}")]]

#text("so it will now suffice to establish that")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\pi \\sqrt{n}}^{\\pi \\sqrt{n}} e^{i \\mu x \\sqrt{n}} \\varphi_{X-\\mu}(x/\\sqrt{n})^n e^{-ixm/\\sqrt{n}}\\ dx")]]

#align(center)[#tao-fit-display[#mitex("= \\int_{\\bf R} e^{i \\mu x \\sqrt{n}} e^{-\\sigma^2 x^2/2} e^{-ixm/\\sqrt{n}}\\ dx + o(1)")]]

#text("uniformly in ")#mi("{m}")#text(". From dominated convergence we have")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|x\\right| \\geq \\pi \\sqrt{n}} e^{-\\sigma^2 x^2/2} e^{-ixm/\\sqrt{n}}\\ dx = o(1)", block: true)]]

#text("so by the triangle inequality, it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\int_{-\\pi \\sqrt{n}}^{\\pi \\sqrt{n}} |\\varphi_{X-\\mu}(x/\\sqrt{n})^n - e^{-\\sigma^2 x^2/2}| dx = o(1).")]]

#text("This will follow from ")#link(<tao-df877645404747cb7973>)[#text("(9)")]#text(" and the dominated convergence theorem, as soon as we can dominate the integrands ")#tao-math("{\\left|\\varphi_{X-\\mu}(x/\\sqrt{n})^n - e^{-\\sigma^2 x^2/2}\\right| 1_{\\left|x\\right| \\leq \\pi \\sqrt{n}}}", block: false)#text(" by an absolutely integrable function.")

#text("From ")#link(<tao-e96e02d8e47f2a7c03be>)[#text("(8)")]#text(", there is an ")#mi("{\\varepsilon > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("\\text{Re} \\varphi_{X-\\mu}(t) \\leq 1 - \\frac{\\sigma^2}{4} t^2 \\leq \\exp( - \\sigma^2 t^2 / 4)")]]

#text("for all ")#tao-math("{\\left|t\\right| \\leq \\varepsilon}", block: false)#text(", and hence")

#align(center)[#tao-fit-display[#tao-math("\\left|\\varphi_{X-\\mu}(x/\\sqrt{n})^n\\right| \\leq \\exp( - \\sigma^2 x^2 / 4 )", block: true)]]

#text("for ")#tao-math("{\\left|x\\right| \\leq \\varepsilon \\sqrt{n}}", block: false)#text(". This gives the required domination in the region ")#tao-math("{\\left|x\\right| \\leq \\varepsilon \\sqrt{n}}", block: false)#text(", so it remains to handle the region ")#tao-math("{\\varepsilon \\sqrt{n} < \\left|x\\right| \\leq \\pi \\sqrt{n}}", block: false)#text(".")

#text("From the triangle inequality we have ")#tao-math("{\\left|\\varphi_{X-\\mu}(t)\\right| \\leq 1}", block: false)#text(" for all ")#mi("{t}")#text(". Actually we have the stronger bound ")#tao-math("{\\left|\\varphi_{X-\\mu}(t)\\right| < 1}", block: false)#text(" for ")#tao-math("{0 < \\left|t\\right| \\leq \\pi}", block: false)#text(". Indeed, if ")#tao-math("{\\left|\\varphi_{X-\\mu}(t)\\right| = 1}", block: false)#text(" for some such ")#mi("{t}")#text(", this would imply that ")#mi("{e^{it(X-\\mu)}}")#text(" is a deterministic constant, which means that ")#mi("{t(X-\\mu)}")#text(" takes values in ")#mi("{a + 2\\pi {\\bf Z}}")#text(" for some real ")#mi("{a}")#text(", which implies that ")#mi("{X}")#text(" takes values in ")#mi("{\\mu + \\frac{a}{t} + \\frac{2\\pi}{t} {\\bf Z}}")#text("; since ")#mi("{X}")#text(" also takes values in ")#mi("{{\\bf Z}}")#text(", this would place ")#mi("{X}")#text(" either in a singleton set or in an infinite subprogression of ")#mi("{{\\bf Z}}")#text(" (depending on whether ")#mi("{\\frac{2\\pi}{t}}")#text(" and ")#mi("{\\mu + \\frac{a}{t}}")#text(" are rational), a contradiction. As ")#mi("{\\varphi_{X-\\mu}}")#text(" is continuous and the region ")#tao-math("{\\varepsilon \\leq \\left|t\\right| \\leq \\pi}", block: false)#text(" is compact, there exists ")#mi("{0<c<1}")#text(" such that ")#tao-math("{\\left|\\varphi_{X-\\mu}(t)\\right| \\leq c}", block: false)#text(" for all ")#tao-math("{\\varepsilon \\leq \\left|t\\right| \\leq \\pi}", block: false)#text(". This allows us to dominate ")#tao-math("{\\left|\\varphi_{X-\\mu}(x/\\sqrt{n})^n - e^{-\\sigma^2 x^2/2}\\right|}", block: false)#text(" by ")#mi("{c^n + e^{-\\sigma^2 \\varepsilon^2 n / 2}}")#text(" for ")#tao-math("{\\varepsilon \\sqrt{n} \\leq \\left|x\\right| \\leq \\pi \\sqrt{n}}", block: false)#text(", which is in turn bounded by ")#mi("{\\exp( - \\delta x^2 )}")#text(" for some ")#mi("{\\delta > 0}")#text(" independent of ")#mi("{n}")#text(", giving the required domination. ")#mi("\\Box")

#text("Of course, if the random variable ")#mi("{X}")#text(" in Theorem ")#link(<tao-4b65a3a6e3cc23d53d88>)[#text("7")]#text(" did take values almost surely in some subprogression ")#mi("{a + q{\\bf Z}}")#text(", then either ")#mi("{X}")#text(" is almost surely constant, or there is a minimal progression ")#mi("{a+q{\\bf Z}}")#text(" with this property (since ")#mi("{q}")#text(" must divide the difference of any two integers that ")#mi("{X}")#text(" attains with positive probability). One can then make the affine change of variables ")#mi("{X = a + q X^{\\prime}}")#text(" (modifying ")#mi("{\\mu}")#text(" and ")#mi("{\\sigma^2}")#text(" appropriately) and apply the above theorem to obtain a similar local limit theorem, which we will not write here. For instance, if ")#mi("{X}")#text(" is the uniform distribution on ")#mi("{\\{-1,1\\}}")#text(", then this argument gives")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( S_n = m) = \\frac{2}{\\sqrt{2\\pi n} \\sigma} e^{-2m^2 / n} + o(1/n^{1/2})")]]

#text("when ")#mi("{m}")#text(" is an integer of the same parity as ")#mi("{n}")#text(" (of course, ")#mi("{{\\bf P}(S_n=m)}")#text(" will vanish otherwise). A further affine change of variables handles the case when ")#mi("{X}")#text(" is not integer valued, but takes values in some other lattice ")#mi("{a+q{\\bf Z}}")#text(", where ")#mi("{q}")#text(" and ")#mi("{a}")#text(" are now real-valued.")

#text("We can complement these local limit theorems with the following result that handles the non-lattice case:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Continuous local limit theorem)")]#text(" ")#metadata(none) <tao-a19374912665f3b8820b>#text(" Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of an real-valued random variable ")#mi("{X}")#text(" of mean ")#mi("{\\mu}")#text(" and variance ")#mi("{\\sigma^2}")#text(". Suppose furthermore that there is no infinite progression ")#mi("{a+q{\\bf Z}}")#text(" with ")#mi("{a,q}")#text(" real for which ")#mi("{X}")#text(" takes values almost surely in ")#mi("{a+q{\\bf Z}}")#text(". Then for any ")#mi("{h > 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( a \\leq S_n \\leq a+h ) = \\frac{h}{\\sqrt{2\\pi n} \\sigma} e^{-(a-n\\mu)^2 / 2n \\sigma^2} + o(1/n^{1/2})")]]

#text("for all ")#mi("{n \\geq 1}")#text(" and all ")#mi("{a \\in {\\bf R}}")#text(", where the error term ")#mi("{o(1/n^{1/2})}")#text(" is uniform in ")#mi("{a}")#text(" (but may depend on ")#mi("{h}")#text(").")
]

#text("Equivalently, if we let ")#mi("{N_n}")#text(" be a normal random variable with mean ")#mi("{n\\mu}")#text(" and variance ")#mi("{n\\sigma^2}")#text(", then")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( a \\leq S_n \\leq a+h ) = {\\bf P}( a \\leq N_n \\leq a+h ) + o(1/n^{1/2})")]]

#text("uniformly in ")#mi("{a}")#text(". Again, this can be compared with the Berry-Esséen theorem, which (assuming finite third moment) has an error term of ")#mi("{O(1/n^{1/2})}")#text(" which is uniform in both ")#mi("{n}")#text(" and ")#mi("{h}")#text(".")

#emph[#text("Proof:")]#text(" Unlike the discrete case, we have the luxury here of normalising ")#mi("{\\mu=0}")#text(" and ")#mi("{\\sigma^2=1}")#text(", and we shall now do so.")

#text("We first observe that it will suffice to show that ")#metadata(none) <tao-68dd1c68ce45fa79143c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("{\\bf E} G(S_n-a) = {\\bf E} G(N_n-a) + o(1/n^{1/2}),")]]



#text(" whenever ")#mi("{G: {\\bf R} \\rightarrow {\\bf C}}")#text(" is a Schwartz function whose Fourier transform")

#align(center)[#tao-fit-display[#mitex("\\hat G(t) := \\frac{1}{2\\pi} \\int_{\\bf R} G(x) e^{-itx}\\ dx")]]

#text("is compactly supported, and where the ")#mi("{o(1/n^{1/2})}")#text(" error can depend on ")#mi("{G}")#text(" but is uniform in ")#mi("{a}")#text(". Indeed, if this bound ")#link(<tao-68dd1c68ce45fa79143c>)[#text("(10)")]#text(" holds, then (after replacing ")#mi("{G}")#text(" by ")#tao-math("{\\left|G\\right|^2}", block: false)#text(" to make it positive on some interval, and then rescaling) we obtain a bound of the form ")#metadata(none) <tao-4acc6cf53e90491a16df>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("{\\bf P}( a \\leq S_n \\leq a+h ) \\leq O(h / n^{1/2} ) + o(1/n^{1/2})")]]



#text(" for any ")#mi("{h>0}")#text(" and ")#mi("{a \\in {\\bf R}}")#text(", where the ")#mi("{o(1/n^{1/2})}")#text(" term can depend on ")#mi("{h}")#text(" but not on ")#mi("{a}")#text(". Then, by convolving ")#mi("{1_{[0,h]}}")#text(" by an approximation to the identity of some width ")#mi("{h^{\\prime}}")#text(" much smaller than ")#mi("{h}")#text(" with compactly supported Fourier transform, applying ")#link(<tao-68dd1c68ce45fa79143c>)[#text("(10)")]#text(" to the resulting function, and using ")#link(<tao-4acc6cf53e90491a16df>)[#text("(11)")]#text(" to control the error between that function and ")#mi("{1_{[0,h]}}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("{\\bf P}( a \\leq S_n \\leq a+h ) = {\\bf P}( a \\leq N_n \\leq a+h ) + O(h^{\\prime}/n^{1/2}) + o(1/n^{1/2})")]]

#text("uniformly in ")#mi("{a}")#text(", where the ")#mi("{o(1/n^{1/2})}")#text(" term can depend on ")#mi("{h}")#text(" and ")#mi("{h^{\\prime}}")#text(" but is uniform in ")#mi("{a}")#text(". Letting ")#mi("{h^{\\prime}}")#text(" tend slowly to zero, we obtain the claim.")

#text("It remains to establish ")#link(<tao-68dd1c68ce45fa79143c>)[#text("(10)")]#text(". We adapt the argument from the discrete case. By the Fourier inversion formula we may write")

#align(center)[#tao-fit-display[#mitex("G(x) = \\int_{\\bf R} \\hat G(t) e^{itx}\\ dt.")]]

#text("By Fubini’s theorem as before, we thus have")

#align(center)[#tao-fit-display[#mitex("{\\bf E} G(S_n-a) = \\int_{\\bf R} \\hat G(t) \\varphi_{S_n}(t) e^{-ita}\\ dt")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("{\\bf E} G(N_n-a) = \\int_{\\bf R} \\hat G(t) \\varphi_{N_n}(t) e^{-ita}\\ dt")]]

#text("so it suffices by the triangle inequality and the boundedness and compact support of ")#mi("{\\hat G}")#text(" to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t\\right| \\leq A} \\left|\\hat G(t)\\right| \\left|\\varphi_{S_n}(t) - \\varphi_{N_n}(t)\\right|\\ dt = o(1/n^{1/2})", block: true)]]

#text("for any fixed ")#mi("{A}")#text(" (where the ")#mi("{o(1/n^{1/2})}")#text(" term can depend on ")#mi("{A}")#text("). We have ")#mi("{\\varphi_{S_n}(t) = \\varphi_X(t)^n}")#text(" and ")#mi("{\\varphi_{N_n}(t) = e^{-n t^2 / 2}}")#text(", so by making the change of variables ")#mi("{x = \\sqrt{n} t}")#text(", we now need to show that")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\left|t\\right| \\leq A \\sqrt{n}} \\left|\\hat G(x/\\sqrt{n})\\right| \\left|\\varphi_X(x/\\sqrt{n})^n - e^{-x^2/2}\\right|\\ dx \\rightarrow 0", block: true)]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(". But this follows from the argument used to handle the discrete case. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. The Poisson central limit theorem — ")]]

#text("The central limit theorem (after normalising the random variables to have mean zero) studies the fluctuations of sums ")#mi("{\\frac{S_n}{\\sqrt{n}} = \\frac{X_1}{\\sqrt{n}} + \\dots + \\frac{X_n}{\\sqrt{n}}}")#text(" where each individual term ")#mi("{\\frac{X_i}{\\sqrt{n}}}")#text(" is quite small (typically of size ")#mi("{O(1/\\sqrt{n})}")#text("). Now we consider a variant situation, in which one considers a sum ")#mi("{S_n = X_1 + \\dots + X_n}")#text(" of random variables which are ")#emph[#text("usually")]#text(" zero, but occasionally equal to a larger value such as ")#mi("{1}")#text(". (This situation arises in many real-life situations when compiling aggregate statistics on rare events, e.g. the number of car crashes in a short period of time.) In these cases, one can get a different distribution than the gaussian distribution, namely a Poisson distribution with some intensity ")#mi("{\\lambda}")#text(" – that is to say, a random variable ")#mi("{X}")#text(" taking values in the non-negative integers ")#mi("{0,1,2,\\dots}")#text(" with probability distribution")

#align(center)[#tao-fit-display[#mitex("{\\bf P}(X = n) = \\frac{\\lambda^n}{n!} e^{-\\lambda}.")]]

#text("One can check that this distribution has mean ")#mi("{\\lambda}")#text(" and variance ")#mi("{\\lambda}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Poisson central limit theorem)")]#text(" ")#metadata(none) <tao-6abb3e96a695b473493e>#text(" Let ")#mi("{(X_{j,n})_{1 \\leq j \\leq n}}")#text(" be a triangular array of real random variables, where for each ")#mi("{n}")#text(", the variables ")#mi("{X_{1,n},\\dots,X_{n,n}}")#text(" are jointly independent. Assume furthermore that")

#list(
[#text("(i) (")#mi("{X_{j,n}}")#text(" mostly ")#mi("{0,1}")#text(") One has ")#mi("{\\sum_{j=1}^n {\\bf P}( X_{j,n} \\not \\in \\{0,1\\} ) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#text("(ii) (")#mi("{X_{j,n}}")#text(" rarely ")#mi("{1}")#text(") One has ")#mi("{\\sup_{j=1}^n {\\bf P}(X_{j,n} = 1 ) \\rightarrow 0}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(".")],
[#text("(iii) (Convergent expectation) One has ")#mi("{\\sum_{j=1}^n {\\bf P}(X_{j,n} = 1 ) \\rightarrow \\lambda}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(" for some ")#mi("{0 < \\lambda < \\infty}")#text(".")]
)

#text("Then the random variables ")#mi("{S_n := X_{1,n} + \\dots + X_{n,n}}")#text(" converge in distribution to a Poisson random variable of intensity ")#mi("{\\lambda}")#text(".")
]

#emph[#text("Proof:")]#text(" From hypothesis (i) and the union bound we see that for each ")#mi("{n}")#text(", we have that all of the ")#mi("{X_{1,n},\\dots,X_{n,n}}")#text(" lie in ")#mi("{\\{0,1\\}}")#text(" with probability ")#mi("{1-o(1)}")#text(" as ")#mi("{n \\rightarrow \\infty}")#text(". Thus, if we replace each ")#mi("{X_{j,n}}")#text(" by the restriction ")#mi("{X_{j,n} 1_{X_{j,n} \\in \\{0,1\\}}}")#text(", the random variable ")#mi("{S_n}")#text(" is only modified on an event of probability ")#mi("{o(1)}")#text(", which does not affect distributional limits (")#link("https://en.wikipedia.org/wiki/Slutsky%27s_theorem")[#text("Slutsky’s theorem")]#text("). Thus, we may assume without loss of generality that the ")#mi("{X_{j,n}}")#text(" take values in ")#mi("{\\{0,1\\}}")#text(".")

#text("By Exercise 20 of ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("Notes 4")]#text(", a Poisson random variable of intensity ")#mi("{\\lambda}")#text(" has characteristic function ")#mi("{t \\mapsto \\exp( \\lambda(e^{it}-1) )}")#text(". Applying the Lévy convergence theorem (Theorem 27 of ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("Notes 4")]#text("), we conclude that it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\varphi_{S_n}(t) \\rightarrow \\exp( \\lambda(e^{it}-1)")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any fixed ")#mi("{t}")#text(".")

#text("Fix ")#mi("{t}")#text(". By the independence of the ")#mi("{X_{j,n}}")#text(", we may write")

#align(center)[#tao-fit-display[#mitex("\\varphi_{S_n}(t) = \\prod_{j=1}^n \\varphi_{X_{j,n}}(t).")]]

#text("Since ")#mi("{X_{j,n}}")#text(" only takes on the values ")#mi("{0}")#text(" and ")#mi("{1}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\varphi_{X_{j,n}}(t) = 1 - p_{j,n} + p_{j,n} e^{it}")]]

#text("where ")#mi("{p_{j,n} := {\\bf P}( X_{j,n} = 1 )}")#text(". By hypothesis (ii), we have ")#mi("{p_{j,n} = o(1)}")#text(", so by using a branch of the complex logarithm that is analytic near ")#mi("{1}")#text(", we can write")

#align(center)[#tao-fit-display[#mitex("\\varphi_{S_n}(t) = \\exp( \\sum_{j=1}^n \\log( 1 - p_{j,n} + p_{j,n} e^{it} ) ).")]]

#text("By Taylor expansion we have")

#align(center)[#tao-fit-display[#mitex("\\log( 1 - p_{j,n} + p_{j,n} e^{it} ) ) = p_{j,n} (e^{it}-1) + O( p_{j,n}^2 )")]]

#text("and hence by (ii), (iii)")

#align(center)[#tao-fit-display[#mitex("\\sum_{j=1}^n \\log( 1 - p_{j,n} + p_{j,n} e^{it} ) ) = \\lambda (e^{it}-1) + o(1)")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10")]#text(" Establish the conclusion of Theorem ")#link(<tao-6abb3e96a695b473493e>)[#text("9")]#text(" directly from explicit computation of the probabilities ")#mi("{{\\bf P}(S_n = k)}")#text(" in the case when each ")#mi("{X_{j,n}}")#text(" takes values in ")#mi("{0,1}")#text(" with ")#mi("{{\\bf P}(X_{j,n}=1) = \\lambda/n}")#text(" for some fixed ")#mi("{\\lambda > 0}")#text(".")
]

#text("The Poisson central limit theorem can be viewed as a degenerate limit of the central limit theorem, as seen by the next two exercises.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Suppose we replace the hypothesis (iii) in Theorem ")#link(<tao-6abb3e96a695b473493e>)[#text("9")]#text(" with the alternative hypothesis that the quantities ")#mi("{\\lambda_n := \\sum_{j=1}^n {\\bf P}(X_{j,n} = 1)}")#text(" go to infinity as ")#mi("{n \\rightarrow \\infty}")#text(", while leaving hypotheses (i) and (ii) unchanged. Show that ")#mi("{(S_n - \\lambda_n) /\\sqrt{\\lambda_n}}")#text(" converges in distribution to the normal distribution ")#mi("{N(0,1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" For each ")#mi("{\\lambda>0}")#text(", let ")#mi("{P_\\lambda}")#text(" be a Poisson random variable with intensity ")#mi("{\\lambda}")#text(". Show that as ")#mi("{\\lambda \\rightarrow \\infty}")#text(", the random variables ")#mi("{(P_\\lambda - \\lambda)/\\sqrt{\\lambda}}")#text(" converge in distribution to the normal distribution ")#mi("{N(0,1)}")#text(". Discuss how this is consistent with Theorem ")#link(<tao-6abb3e96a695b473493e>)[#text("9")]#text(" and the previous exercise.")
]

#heading(level: 1)[#strong[#text(" — 4. Stable laws — ")]]

#text("Let ")#mi("{X}")#text(" be a real random variable. We say that ")#mi("{X}")#text(" has a ")#emph[#text("stable law")]#text(" or a ")#emph[#text("stable distribution")]#text(" if for any positive reals ")#mi("{a, b}")#text(", there exists a positive real ")#mi("{c}")#text(" and a real ")#mi("{d}")#text(" such that ")#mi("{a X_1 + b X_2 \\equiv c X + d}")#text(" whenever ")#mi("{X_1,X_2}")#text(" are iid copies of ")#mi("{X}")#text(". In terms of the characteristic function ")#mi("{\\varphi_X}")#text(" of ")#mi("{X}")#text(", we see that ")#mi("{X}")#text(" has a stable law if for any positive reals ")#mi("{a,b}")#text(", there exist a positive real ")#mi("{c}")#text(" and a real ")#mi("{d}")#text(" for which we have the functional equation")

#align(center)[#tao-fit-display[#mitex("\\phi_X(at) \\phi_X(bt) = \\phi_X(ct) e^{idt}")]]

#text("for all real ")#mi("{t}")#text(".")

#text("For instance, a normally distributed variable ")#mi("{X = N(\\mu,\\sigma^2)}")#text(" is stable thanks to Lemma 12 of ")#link("https://terrytao.wordpress.com/2015/11/02/275a-notes-4-the-central-limit-theorem/")[#text("Notes 4")]#text("; one can also see this from the characteristic function ")#mi("{\\phi_X(t) = e^{i \\mu t - \\sigma^2 t^2 / 2}}")#text(". A Cauchy distribution ")#mi("{X}")#text(", with probability density ")#mi("{\\frac{1}{\\pi} \\frac{\\gamma}{(x-x_0)^2 + \\gamma^2}}")#text(" can also be seen to be stable, as is most easily seen from the characteristic function ")#tao-math("{\\phi_X(t) = e^{ix_0 t - \\gamma \\left|t\\right|}}", block: false)#text(". As a more degenerate example, any deterministic random variable ")#mi("{X = x_0}")#text(" is stable. It is possible (though somewhat tedious) to completely classify all the stable distributions, see for instance the ")#link("https://en.wikipedia.org/wiki/Stable_distribution")[#text("Wikipedia entry on these laws")]#text(" for the full classification.")

#text("If ")#mi("{X}")#text(" is stable, and ")#mi("{X_1, X_2, \\dots}")#text(" are iid copies of ")#mi("{X}")#text(", then by iterating the stable law hypothesis we see that the sums ")#mi("{S_n := X_1 + \\dots + X_n}")#text(" are all equal in distribution to some affine rescaling ")#mi("{a_n X + b_n}")#text(" of ")#mi("{X}")#text(". For instance, we have ")#mi("{X_1 + X_2 \\equiv cX + d}")#text(" for some ")#mi("{c,d}")#text(", and a routine induction then shows that")

#align(center)[#tao-fit-display[#mitex("X_1 + \\dots + X_{2^k} \\equiv c^k X + \\frac{d (c^k - 1)}{c-1}")]]

#text("for all natural numbers ")#mi("{k}")#text(" (with the understanding that ")#mi("{\\frac{c^k-1}{c-1} = k}")#text(" when ")#mi("{c=1}")#text("). In particular, the random variables ")#mi("{\\frac{S_n - b_n}{a_n}}")#text(" all have the same distribution as ")#mi("{X}")#text(".")

#text("More generally, given two real random variables ")#mi("{X}")#text(" and ")#mi("{Y}")#text(", we say that ")#mi("{X}")#text(" is in the ")#emph[#text("basin of attraction")]#text(" for ")#mi("{Y}")#text(" if, whenever ")#mi("{X_1,X_2,\\dots}")#text(" are iid copies of ")#mi("{X}")#text(" and ")#mi("{S_n := X_1 + \\dots + X_n}")#text(", there exist constants ")#mi("{a_n > 0}")#text(" and ")#mi("{b_n}")#text(" such that ")#mi("{\\frac{S_n - b_n}{a_n}}")#text(" converges in distribution to ")#mi("{Y}")#text(". Thus, any stable law is in its own basin of attraction, while the central limit theorem asserts that any random variable of finite variance is in the basin of attraction of a normal distribution. One can check that every random variable lies in the basin of attraction of a deterministic random variable such as ")#mi("{0}")#text(", simply by letting ")#mi("{a_n}")#text(" go to infinity rapidly enough. To avoid this degenerate case, we now restrict to laws that are ")#emph[#text("non-degenerate")]#text(", in the sense that they are not almost surely constant. Then we have the following useful technical lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13 (Convergence of types)")]#text(" ")#metadata(none) <tao-f8dcb34308e5c69f46a3>#text(" Let ")#mi("{X_n}")#text(" be a sequence of real random variables converging in distribution to a non-degenerate limit ")#mi("{X}")#text(". Let ")#mi("{a_n>0}")#text(" and ")#mi("{b_n}")#text(" be real numbers such that ")#mi("{Y_n = a_n X_n + b_n}")#text(" converges in distribution to a non-degenerate limit ")#mi("{Y}")#text(". Then ")#mi("{a_n}")#text(" and ")#mi("{b_n}")#text(" converge to some finite limits ")#mi("{a,b}")#text(" respectively, and ")#mi("{aX + b \\equiv Y}")#text(".")
]

#emph[#text("Proof:")]#text(" Suppose first that ")#mi("{a_n}")#text(" goes to zero. The sequence ")#mi("{X_n}")#text(" converges in distribution, hence is tight, hence ")#mi("{Y_n - b_n = a_n X_n}")#text(" converges in probability to zero. In particular, if ")#mi("{Y^{\\prime}_n}")#text(" is an independent copy of ")#mi("{Y_n}")#text(", then ")#mi("{Y_n - Y^{\\prime}_n}")#text(" converges in probability to zero; but ")#mi("{Y_n - Y^{\\prime}_n}")#text(" also converges in distribution to ")#mi("{Y-Y^{\\prime}}")#text(" where ")#mi("{Y^{\\prime}}")#text(" is an independent copy of ")#mi("{Y}")#text(", and ")#mi("{Y-Y^{\\prime}}")#text(" is not almost surely zero since ")#mi("{Y}")#text(" is non-degenerate. This is a contradiction. Similarly if ")#mi("{a_n}")#text(" has any subsequence that goes to zero. We conclude that ")#mi("{a_n}")#text(" is bounded away from zero. Rewriting ")#mi("{Y_n = a_n X_n + b_n}")#text(" as ")#mi("{X_n = a_n^{-1} Y_n - a_n^{-1} b_n}")#text(" and reversing the roles of ")#mi("{X_n}")#text(" and ")#mi("{Y_n}")#text(", we conclude also that ")#mi("{a_n^{-1}}")#text(" is bounded away from zero, thus ")#mi("{a_n}")#text(" is bounded.")

#text("Since ")#mi("{X_n}")#text(" is tight and ")#mi("{a_n}")#text(" is bounded, ")#mi("{a_n X_n}")#text(" is tight; since ")#mi("{Y_n}")#text(" is also tight, this implies that ")#mi("{Y_n - a_n X_n = b_n}")#text(" is tight, that is to say ")#mi("{b_n}")#text(" is bounded.")

#text("Let ")#mi("{(a,b)}")#text(" be a limit point of the ")#mi("{(a_n,b_n)}")#text(". By Slutsky’s theorem, a subsequence of the ")#mi("{Y_n = a_n X_n + b_n}")#text(" then converges in distribution to ")#mi("{aX + b}")#text(", thus ")#mi("{Y \\equiv aX+b}")#text(". If the limit point ")#mi("{(a,b)}")#text(" is unique then we are done, so suppose there are two limit points ")#mi("{(a,b)}")#text(", ")#mi("{(a^{\\prime},b^{\\prime})}")#text(". Thus ")#mi("{aX+b \\equiv a^{\\prime}X+b^{\\prime}}")#text(", which on rearranging gives ")#mi("{X \\equiv cX + d}")#text(" for some ")#mi("{c>0}")#text(" and real ")#mi("{d}")#text(" with ")#mi("{(c,d) \\neq (1,0)}")#text(".")

#text("If ")#mi("{c=1}")#text(" then on iteration we have ")#mi("{X \\equiv X + dn}")#text(" for any natural number ")#mi("{n}")#text(", which clearly leads to a contradiction as ")#mi("{n \\rightarrow \\infty}")#text(" since ")#mi("{d \\neq 0}")#text(". If ")#mi("{c < 1}")#text(" then iteration gives ")#mi("{X = c^n X + d \\frac{c^n-1}{c-1}}")#text(" for any natural number ")#mi("{n}")#text(", which on passing to the limit in distribution as ")#mi("{n \\rightarrow \\infty}")#text(" gives ")#mi("{X=0}")#text(", again a contradiction. If ")#mi("{c>1}")#text(" then we rewrite ")#mi("{X \\equiv cX + d}")#text(" as ")#mi("{X \\equiv c^{-1} X - c^{-1} d}")#text(" and again obtain a contradiction, and the claim follows. ")#mi("\\Box")

#text("One can use this proposition to verify that basins of attraction of genuinely distinct laws are disjoint:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{Y}")#text(" and ")#mi("{Y^{\\prime}}")#text(" be non-degenerate real random variables. Suppose that a random variable ")#mi("{X}")#text(" lies in the basin of attraction of both ")#mi("{Y}")#text(" and ")#mi("{Y^{\\prime}}")#text(". Then there exist ")#mi("{a>0}")#text(" and real ")#mi("{b}")#text(" such that ")#mi("{Y^{\\prime} \\equiv aY+b}")#text(".")
]

#text("If ")#mi("{X}")#text(" lies in the basin of attraction for a non-degenerate law ")#mi("{Y}")#text(", then ")#mi("{\\frac{S_n - b_n}{a_n}}")#text(" converges in distribution to ")#mi("{Y}")#text("; since ")#mi("{S_{2n}}")#text(" is equal in distribution to the sum of two iid copies of ")#mi("{S_n}")#text(", we see that ")#mi("{\\frac{S_{2n}-2b_n}{a_n}}")#text(" converges in distribution to the sum ")#mi("{Y_1+Y_2}")#text(" of two iid copies of ")#mi("{Y}")#text(". On the other hand, ")#mi("{\\frac{S_{2n}-b_{2n}}{a_{2n}}}")#text(" converges in distribution to ")#mi("{Y}")#text(". Using Proposition ")#link(<tao-f8dcb34308e5c69f46a3>)[#text("13")]#text(" we conclude that ")#mi("{Y_1+Y_2 \\equiv cY + d}")#text(" for some ")#mi("{c>0}")#text(" and real ")#mi("{d}")#text(". One can go further and conclude that ")#mi("{Y}")#text(" in fact has a stable law; see the following exercise. Thus stable laws are the only laws that have a non-empty basin of attraction.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" Let ")#mi("{X}")#text(" lie in the basin of attraction for a non-degenerate law ")#mi("{Y}")#text(".")

#list(
[#text("(i) Show that for any iid copies ")#mi("{Y_1,\\dots,Y_k}")#text(" of ")#mi("{Y}")#text(", there exists a unique ")#mi("{c_k>0}")#text(" and ")#mi("{d_k \\in {\\bf R}}")#text(" such that ")#mi("{Y_1 + \\dots + Y_k \\equiv c_k Y + d_k}")#text(". Also show that ")#mi("{c_k Y_1 + c_l Y_2 \\equiv c_{k+l} Y + d_{k+l} - d_k - d_l}")#text(" for all natural numbers ")#mi("{k,l}")#text(".")],
[#text("(ii) Show that the ")#mi("{c_k}")#text(" are strictly increasing, with ")#mi("{c_{kl} = c_k c_l}")#text(" for all natural numbers ")#mi("{k,l}")#text(". (")#emph[#text("Hint:")]#text(" study the absolute value ")#tao-math("{\\left|\\phi_Y(t)\\right|}", block: false)#text(" of the characteristic function, using the non-degeneracy of ")#mi("{Y}")#text(" to ensure that this absolute value is usually strictly less than one.) Also show that ")#mi("{d_k l + c_k d_l = d_{kl}}")#text(" for all natural numbers ")#mi("{k,l}")#text(".")],
[#text("(iii) Show that there exists ")#mi("{\\alpha > 0}")#text(" such that ")#mi("{c_k = k^\\alpha}")#text(" for all ")#mi("{k}")#text(". (")#emph[#text("Hint:")]#text(" first show that ")#mi("{\\frac{\\log c_k}{\\log k}}")#text(" is a Cauchy sequence in ")#mi("{k}")#text(".)")],
[#text("(iv) If ")#mi("{\\alpha = 1}")#text(", and ")#mi("{Y_1,Y_2}")#text(" are iid copies of ")#mi("{Y}")#text(", show that ")#mi("{\\frac{k}{k+l} Y_1 + \\frac{l}{k+l} Y_2 \\equiv Y + \\theta_{k,l}}")#text(" for all natural numbers ")#mi("{k,l}")#text(" and some bounded real ")#mi("{\\theta_{k,l}}")#text(". Then show that ")#mi("{Y}")#text(" has a stable law in this case.")],
[#text("(v) If ")#mi("{\\alpha \\neq 1}")#text(", show that ")#mi("{d_k = \\mu ( k - k^\\alpha )}")#text(" for some real ")#mi("{\\mu}")#text(" and all ")#mi("{k}")#text(". Then show that ")#mi("{Y}")#text(" has a stable law in this case.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Classification of stable laws)")]#text(" Let ")#mi("{Y}")#text(" be a non-degenerate stable law, then ")#mi("{Y}")#text(" lies in its own basin of attraction and one can then define ")#mi("{c_k, d_k, \\alpha}")#text(" as in the preceding exercise.")

#list(
[#text("(i) If ")#mi("{\\alpha \\neq 1}")#text(", and ")#mi("{\\mu}")#text(" is as in part (v) of the preceding exercise, show that ")#mi("{\\varphi_Y(t)^k = \\varphi_Y(k^\\alpha t) e^{i \\mu (k - k^\\alpha)}}")#text(" for all ")#mi("{t}")#text(" and ")#mi("{k}")#text(". Then show that")

#align(center)[#tao-fit-display[#tao-math("\\varphi_Y(t) = \\exp( i t \\mu - \\left|ct\\right|^\\alpha (1 - i \\beta \\text{sgn}(t) ) )", block: true)]]

#text("for some real ")#mi("{c, \\beta}")#text(". (One can use the identity ")#mi("{\\varphi_Y(-t) = \\overline{\\varphi_Y(t)}}")#text(" to restrict attention to the case of positive ")#mi("{t}")#text(".)")],
[#text("(ii) Now suppose ")#mi("{\\alpha = 1}")#text(". Show that ")#mi("{d_{k+l} = d_k + d_l + O(k+l)}")#text(" for all ")#mi("{k,l}")#text(" (where the implied constant in the ")#mi("{O()}")#text(" notation is allowed to depend on ")#mi("{Y}")#text("). Conclude that ")#mi("{d_k = O(k \\log k)}")#text(" for all ")#mi("{k}")#text(".")],
[#text("(iii) We continue to assume ")#mi("{\\alpha = 1}")#text(". Show that ")#mi("{d_k = -\\beta k \\log k}")#text(" for some real number ")#mi("{k}")#text(". (")#emph[#text("Hint:")]#text(" first show this when ")#mi("{k}")#text(" is a power of a fixed natural number ")#mi("{k_0 > 1}")#text(" (with ")#mi("{\\beta}")#text(" possibly depending on ")#mi("{k_0}")#text("). Then use the estimates from part (ii) to show that ")#mi("{\\beta}")#text(" does not actually depend on ")#mi("{k_0}")#text(". (One may need to invoke the ")#link("https://en.wikipedia.org/wiki/Dirichlet%27s_approximation_theorem")[#text("Dirichlet approximation theorem")]#text(" to show that for any given ")#mi("{k_0,k_1 > 1}")#text(", one can find a power of ")#mi("{k_0}")#text(" that is somewhat close to a power of ")#mi("{k_1}")#text(".)")],
[#text("(iv) We continue to assume ")#mi("{\\alpha=1}")#text(". Show that ")#mi("{\\varphi_Y(t)^k = \\varphi_Y(kt) e^{-i \\beta k \\log k}}")#text(" for all ")#mi("{t}")#text(" and ")#mi("{k}")#text(". Then show that")

#align(center)[#tao-fit-display[#tao-math("\\varphi_Y(t) = \\exp(it \\mu - \\left|ct\\right| (1 - i \\beta \\text{sgn}(t) \\log t ) )", block: true)]]

#text("for all ")#mi("{t}")#text(" and some real ")#mi("{c}")#text(".")]
)

#text("It is also possible to determine which choices of parameters ")#mi("{\\mu,c,\\alpha,\\beta}")#text(" are actually achievable by some random variable ")#mi("{Y}")#text(", but we will not do so here.")
]

#text("It is possible to associate a central limit theorem to each stable law, which precisely determines their basin of attraction. We will not do this in full generality, but just illustrate the situation for the Cauchy distribution.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17")]#text(" Let ")#mi("{X}")#text(" be a real random variable which is symmetric (that is, ")#mi("{X}")#text(" has the same distribution as ")#mi("{-X}")#text(") and obeys the distribution identity")

#align(center)[#tao-fit-display[#tao-math("{\\mathbf P}( \\left|X\\right| \\geq x ) = L(x) \\frac{2}{\\pi x}", block: true)]]

#text("for all ")#mi("{x>0}")#text(", where ")#mi("{L: (0,+\\infty) \\rightarrow (0,+\\infty)}")#text(" is a function which is ")#emph[#text("slowly varying")]#text(" in the sense that ")#mi("{L(cx)/L(x) \\rightarrow 1}")#text(" as ")#mi("{x \\rightarrow \\infty}")#text(" for all ")#mi("{c>0}")#text(".")

#list(
[#text("(i) Show that")

#align(center)[#tao-fit-display[#tao-math("{\\bf E}( e^{itX} ) = 1 - \\left|t\\right| + o(\\left|t\\right|)", block: true)]]

#text("as ")#mi("{t \\rightarrow 0}")#text(", where ")#tao-math("{o(\\left|t\\right|)}", block: false)#text(" denotes a quantity such that ")#tao-math("{o(\\left|t\\right|)/\\left|t\\right| \\rightarrow 0}", block: false)#text(" as ")#mi("{t \\rightarrow 0}")#text(". (You may need to establish the identity ")#mi("{\\int_0^\\infty \\frac{1 - \\cos(x)}{x^2}\\ dx = \\frac{\\pi}{2}}")#text(", which can be done by contour integration.)")],
[#text("(ii) Let ")#mi("{X_1,X_2,\\dots}")#text(" be iid copies of ")#mi("{X}")#text(". Show that ")#mi("{\\frac{X_1+\\dots+X_n}{n}}")#text(" converges in distribution to a copy of the standard Cauchy distribution (i.e., to a random variable with probability density function ")#mi("{x \\mapsto \\frac{1}{\\pi} \\frac{1}{1+x^2}}")#text(").")]
)
]

#heading(level: 1)[#text("Comments (42)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462104")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("oh no i’m seeing ‘latex path not specified’ errors")

#emph[#text("[This is a very strange error. Currently I can get all the LaTeX rendered when viewing the blog (or other wordpress blogs with recent latex) on one machine, but when viewed on a different machine there are plenty of “latex path not specified” errors, regardless of what browser I use. I do not know what could be causing this. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462108")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 November 2015")])]

#text("In the second line of the proof of proposition 2, it seems that the normalization of ")#mi("a")#text(" should be ")#mi("a=1")#text(" (instead of ")#mi("a=0")#text(").")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/093b39a91ab78717ab21698c47970aba73f675b8eca4ab0839dece67211855d9-efb2fd2cf5aa51dc2e82e7cf92086f9c5ba7da51bdd081f24eba7b1bfd1ea5db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of arch1")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462154")[#strong[#text("arch1")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("I get this problem w/ this your latest blog entry, but not w/ your previous ones. I guess that a LaTeX version change occured between 10/16 and 10/19 which broke compatibility with my OS (Windows 7 Enterprise Service Pack 1), one of yours, and Anonymous #1’s.")

#text("But I’m sure someone here can do better than guess (come on, folks..:-)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d340339cbc25e13afb404a68620ca4c9ced5a72939928744cf39de9cb22e6de9-b1f3d2c41974b8626397d605e8f85022ee2e3b1ffa07472e344413487c82c7d2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pauljung")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462157")[#strong[#text("pauljung")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2015")])]

#text("Hi Terry, at the beginning of Section 4, I guess the pi in the Cauchy density should be in the denominator.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6849fcb9dc6381bf11d5aeac391975a706661cae10a97165e3c0355517fca122-7dbc60f032a5cff51668ac9079627c8ead9a115ddbbe72819df3e43a003603d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bruys")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462237")[#strong[#text("Bruys")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2015")])]

#text("Gee, I wish WordPress would fix this “latex path not specified.” problem. It’s not exclusive to this blog. I have viewed this blog on different machines and different versions of Windows, and different browsers.")

#text("Thanks for your blogs, Terry. When I can understand them, they’re wonderfully lucid. It would be no fun if I could understand them all ;)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462260")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("The explanation between proposition 3 and exercise 4 is not sufficiently clear (perhaps some lines are missing) – see e.g.")

#text("1. Large part of the three lines below proposition 3 appear in blue.")

#text("2. The eleventh line below proposition 3 is ended with “\\end”,")

#text("3. The 7 lines above exercise 4 are seemingly related to some (unclear – perhaps due to missing lines) example with polynomial decay rate in ")#mi("\\lambda")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462282")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("In Hoeffding’s inequality, is ")#mi("c=2")#text(" optimal ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462284")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("Yes, this can be seen from the Bernoulli example discussed at the start of the section (together with the Taylor expansion of the entropy function).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462287")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("Thanks!")#linebreak()#text(" Possible typo: It seems that in the third line below the definition of the entropy function ")#mi("h(\\alpha)")#text(", the threshold ")#mi("\\theta \\sqrt{n}")#text(" (used to define the probability in the RHS) should be ")#mi("\\theta")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("Actually, I believe the ")#mi("\\sqrt{n}")#text(" factor should be there (this is measuring a large deviation event, much larger than the standard deviation).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462296")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("I see. Thanks! (I missed the factor n in the exponent in the RHS.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/232c339814862abc0453cecd84389f47b92a6372f1aeb9c9329c9be0c929716d-aee78eec4cb1960b5a0243450a03f9f0d242b12c933ee8fc293a3320e9c17f63.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lior Silberman")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462286")[#strong[#text("Lior Silberman")]]#text(size: 9pt, fill: rgb("596477"), " · 23 November 2015")])]

#text("Exercise 5: shouldn’t there be ")#mi("p")#text("th roots on the LHS? It seems to me that otherwise the inequalities won’t scale properly with the ")#mi("a_i")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2015")])]

#text("The integral in exercise 17(i) may also be evaluated by its interpretation as")#linebreak()#text(" ")#tao-math("\\left|\\left|\\sin(x/2) / x\\right|\\right|_2^2", block: false)#text(" – using Plancherel theorem and its (much simpler!) Fourier transform.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462343")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2015")])]

#text("It seems quite surprising that the RHS of (6) has a Gaussian type decay (wrt ")#mi("lambda")#text("), while the RHS of (5) has a much slower (slightly faster than exponential) decay – in spite of using more(!) information (variance information) than (6). Is there any explanation for the slower decay (i.e. looser bound) in (5) ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462347")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2015")])]

#text("The left-hand side of (5) is larger than that of (6) (if ")#mi("\\lambda")#text(" is held fixed), because ")#mi("\\sigma^{(n)}")#text(" is smaller, and so it is harder to bound and one expects to have weaker decay in ")#mi("\\lambda")#text(" on the right-hand side. The difference between (5) and (6) is particularly highlighted in the case analysed just before Proposition 2, in which the underlying random variable ")#mi("X")#text(" takes values in ")#mi("\\{0,1\\}")#text(" but is mostly 0, so that its variance is much smaller than the square of the length of the interval containing ")#mi("X")#text(", and so the ")#mi("\\sigma^{(n)}")#text(" in (5) is much smaller than that in (6). In this case, the large deviations are predominantly caused by the event when most of the ")#mi("X_1,\\dots,X_n")#text(" are equal to 1, which is only an exponentially rare event (e.g. the probability that they are all 1 is ")#mi("p^n")#text(") rather than a quadratically-exponential event.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462354")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 November 2015")])]

#text("I asked about the slower decay of the RHS of (5) wrt varying threshold ")#mi("\\lambda")#text(" with all the other parameters (including ")#mi("n")#text(") held fixed,")#linebreak()#text(" To me it seems natural to expect that the RHS of (5) (having the additional variance information) should decay no slower with ")#mi("\\lambda")#text(" (for sufficiently large ")#mi("\\lambda")#text(").")#linebreak()#text(" But now I think that perhaps, the explanation is that the decay of the RHS of (5) is starting to be slower than that of (6) only(!) when ")#mi("\\lambda \\gg \\sqrt{n}")#text(", but for such large ")#mi("lambda")#text(" values, the LHS of both (5) and (6) should be zero(!) (since ")#mi("S_n = O(n)")#text(" – due to the uniform boundedness of ")#mi("X_1, ... , X_n")#text(").")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462685")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("In the introduction: {\\frac{S_n-n mu}{\\sqrt{n} \\sigma}}, mu is missing a \\ (search for ‘mu’)")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("In Theorem 7, the sup term, has a ‘=’ instead of a ‘-‘.")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462691")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("‘attains with positive probabilit’ should be ‘attains with positive probability’ (missing y at the end). (hope this typo checking helps)")

#emph[#text("[Corrected, thanks. I certainly appreciate the corrections, though if you could combine multiple corrections into a single comment that would be helpful. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c8371d943e11f2ee5630e1ad2f23ac18b7fbfc6e7f7e523227453d483bd27ebf-8dc2eb16c022b6652f932e7b7c23a69facf039f182263717919a45eb31c25dec.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-462692")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2015")])]

#text("‘Levy convergence theorem’ should be ‘Lévy convergence theorem’ (being annoying, I know)")

#emph[#text("[Corrected, thanks -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-463630")[#strong[#text("275A, Notes 5: Variants of the central limit theorem | jianchengblog")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2015")]

#text("[…] 来源： 275A, Notes 5: Variants of the central limit theorem […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-467315")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2016")])]

#text("Should replace the Uncategorized tag with math.CA")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-474459")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2016")])]

#text("If ")#mi("{X}")#text(" is stable, and ")#mi("{X_1, X_2, \\dots}")#text(" are iid copies of ")#mi("{X}")#text(", then by iterating the stable law hypothesis we see that the sums ")#mi("{S_n := X_1 + \\dots + X_n}")#text(" are all equal in distribution to some affine rescaling ")#mi("{a_n X + b_n}")#text(" of ")#mi("{X}")#text(". For instance, we have ")#mi("{X_1 + X_2 \\equiv cX + d}")#text(" for some ")#mi("{c,d}")#text(", and a routine induction then shows that")

#mi("\\displaystyle X_1 + \\dots + X_{2^k} \\equiv c^k X + \\frac{d (c^k - 1)}{c-1}")

#text("for all natural numbers ")#mi("{k}")#text(" (with the understanding that ")#mi("{\\frac{c^k-1}{c-1} = k}")#text(" when ")#mi("{c=1})")#text(".")

#text("Shouldn’t ")#mi("c")#text(" depend on ")#mi("a")#text(" and ")#mi("b")#text(" in the definition of “stable”? How do you get ")#mi("c^k")#text(" in the induction?")

#emph[#text("[Yes, ")#mi("c")#text(" will depend on ")#mi("a,b")#text(". If ")#mi("X_1 + \\dots + X_{2^k} \\equiv c^k X +  \\frac{d(c^k-1)}{c-1}")#text(" and ")#mi("X_1 + X_2 \\equiv cX + d")#text(", then a short computation will show that ")#mi("X_1 + \\dots + X_{2^{k+1}} \\equiv c^{k+1} X +  \\frac{d(c^{k+1}-1)}{c-1}")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-474460")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2016")])]

#text("Does the concept “basin of attraction” here have anything to do with that in dynamical systems (say an ODE)?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75602a486c8e5f6a1143c1b431e6f222e8fdd5ca4201af2e1131b288c4500c65-10b91e1c635bd69a55ef566154414f483e2368935c9dc885d7e86986cd44f2cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-477188")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2017")])]

#text("Hello, I would appreciate it if anyone could shed some lights on how the error term in Theorem 8 depends on “h”. In particular, how quickly can “h” grow without changing the o(1/sqrt(n)) error, and how could one read this off from the proofs in this article? Thank you for your time.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75602a486c8e5f6a1143c1b431e6f222e8fdd5ca4201af2e1131b288c4500c65-10b91e1c635bd69a55ef566154414f483e2368935c9dc885d7e86986cd44f2cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-477189")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2017")])]

#text("Based on the form of the leading term in Theorem 8, it should be that we need h = o(sqrt(n)) but I’d appreciate any further comments.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f9cb20c84e59602f034eccb45720a954020be6c3c7fa926eebc055b3c84a131a-4f8d0e74a8cabca151f1fd29b2aa9612b234b4eb7373b613a0dde1301d20c710.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-477201")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 January 2017")])]

#text("Interesting. Suppose we look at the most basic case in which ")#mi("X_1")#text(" is normally distributed with mean ")#mi("0")#text(" and variance ")#mi("1")#text(". Then direct computation via calculus seems to suggest that the error term in Theorem 8 behaves like")

#mi("-\\frac{h^2(h+3a)}{6\\sqrt{2\\pi}n^{\\frac{3}{2}}}")

#text("as ")#mi("n \\rightarrow \\infty")#text(". It this were correct, then it would contradict the fact that the error term is uniform in ")#mi("a")#text(".")

#text("If I made a mistake, please let me know.")

#emph[#text("[You are missing a term of the form ")#mi("e^{-(a-n\\nu)^2/2n\\sigma^2}")#text(" – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-477281")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2017")])]

#text("The proof here is not optimised to give good dependence on ")#mi("h")#text(". The precise convergence rate of local limit theorems has been extensively studied in the literature, but it is hard to give a succinct summary of the results, because the nature of the convergence often depends on the hypotheses one places on the ")#mi("X_i")#text(". Unfortunately I don’t know of a good survey of the latest bounds in this area (but these sorts of issues were studied extensively by the Russian school, so texts by authors from that school may be helpful).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/75602a486c8e5f6a1143c1b431e6f222e8fdd5ca4201af2e1131b288c4500c65-10b91e1c635bd69a55ef566154414f483e2368935c9dc885d7e86986cd44f2cd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-477312")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2017")])]

#text("Dear Prof. Tao, thank you for your reply! I have just looked up some classical papers by Petrov, etc.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/32bd0074513fc07c9a846a943a1a68be56aac3eaebb5c71cdd6fcb4aee37792f-25b82ede0f00ae5959d78803743671de128af0f41c789621029865abe3b505d0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Roth")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-624578")[#strong[#text("Jonathan Roth")]]#text(size: 9pt, fill: rgb("596477"), " · 7 April 2021")])]

#text("Say ")#mi("X_i")#text(" is continuous, ")#mi("Y_i")#text(" is discrete, and ")#mi("X_i")#text(" and ")#mi("Y_i")#text(" are uncorrelated. Let ")#mi("S_{X,n}, S_{Y,n}")#text(" denote the respective partial sums. Is there an extension to the discrete local limit theorem that you provided that says that ")#mi("P( S_{X,n} \\leq a, S_{Y,n} = b)")#text(" can be approximated by the product of a normal CDF at ")#mi("a")#text(" and a normal PDF at ")#mi("b")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-640046")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 February 2022")])]

#text("Typo: Two displays up from (8), you are missing a power of n in \\phi_{X-\\mu}.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/43974704f149dc9ced9f8384197441147d0a902ee03c02a428b220a3e2c6394c-d454b26e5bc0eba6808dd58b7ac7b30df3fa8a162b5ad39c014919ec9f58f233.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fransbern Liu")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-640273")[#strong[#text("Fransbern Liu")]]#text(size: 9pt, fill: rgb("596477"), " · 9 February 2022")])]

#text("Dear Prof.Tao, what does it mean exactly for a random variable to take value in a subprogession almost surely? if a random variable takes value in a finite subset of a subprogression a.s, wouldn’t that mean it takes value in the whole of the subprogression a.s as well?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-691845")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 February 2026")])]

#text("Dear Prof. Tao,")

#text("Is the notation X ≡ N(0,1) equivalent to X～N(0,1)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-691855")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2026")])]

#text("I mean in my country, when we say X follows a probability distribution, we write down things like X～μ_X instead of X ≡ μ_X. I wonder do they mean the same thing?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-691859")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2026")])]

#text("In these notes I am using ")#mi("X \\equiv \\mu")#text(" to denote the assertion that ")#mi("X")#text(" has the distribution of ")#mi("\\mu")#text(". Different texts may use slightly different notations for this concept.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-692247")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2026")])]

#text("Hi Professor Tao, for the proof of Theorem 8, I am gapped in my understanding of how the nonlattice assumption is used. Would sincerely appreciate any clarifying comments. Also, elsewhere in the literature, it is often common to assume Cramer’s condition on the underlying characteristic functions – Theorem 8 does not, so it appears to be a stronger version. Would also appreciate any insights into this. Thank you!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-692269")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2026")])]

#text("The non-lattice assumption is used as in the proof of Theorem 7: to show that the characteristic function is strictly less than 1 in magnitude away from the origin.")

#text("For this type of “averaged” LLT, a Cramer condition is not needed; this result goes back to the ")#link("https://projecteuclid.org/journals/annals-of-mathematical-statistics/volume-36/issue-2/A-Local-Limit-Theorem-for-Nonlattice-Multi-Dimensional-Distribution-Functions/10.1214/aoms/1177700165.full")[#text("1965 local limit theorem of Stone")]#text(". I think the Cramer condition only becomes necessary for the “pointwise” version of the LLT in which one controls the density itself, rather than the probability assigned to a given interval.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-692276")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2026")])]

#text("Dear Professor Tao, Thank you for the clarification on Theorem 8.")

#text("Having reread your proof of Theorem 7 carefully, I have a follow-up question about whether the same dominated convergence argument extends to Theorem 8. In the proof of Theorem 7, the dominated convergence argument handles the “middle annulus” cleanly. After establishing the Gaussian domination ")#tao-math("\\left|\\varphi_{X-\\mu}(x/\\sqrt{n})^n\\right| \\leq \\exp(-\\sigma^2 x^2/4)", block: false)#text(" for ")#tao-math("\\left|x\\right| \\leq \\varepsilon\\sqrt{n}", block: false)#text(", the remaining region ")#tao-math("\\varepsilon\\sqrt{n} < \\left|x\\right| \\leq \\pi\\sqrt{n}", block: false)#text(" corresponds under ")#mi("t = x/\\sqrt{n}")#text(" to the fixed compact set ")#tao-math("\\varepsilon \\leq \\left|t\\right| \\leq \\pi", block: false)#text(", independent of ")#mi("n")#text(". Continuity of ")#mi("\\varphi_{X-\\mu}")#text(" and the nonlattice condition give a uniform ")#mi("0 < c < 1")#text(" on this set, so ")#tao-math("\\left|\\varphi_{X-\\mu}(x/\\sqrt{n})^n - e^{-\\sigma^2 x^2/2}\\right|", block: false)#text(" is dominated by ")#mi("c^n + e^{-\\sigma^2\\varepsilon^2 n/2} \\leq \\exp(-\\delta x^2)")#text(" for some ")#mi("\\delta > 0")#text(" independent of ")#mi("n")#text(".")

#text("For Theorem 8, the integration domain is all of ")#mi("\\mathbb{R}")#text(", and the analogous middle annulus ")#tao-math("\\varepsilon\\sqrt{n} < \\left|x\\right| < \\infty", block: false)#text(" corresponds to ")#tao-math("\\varepsilon < \\left|t\\right| < \\infty", block: false)#text(". Of course, the integrand carries an additional factor ")#mi("\\hat{G}(x/\\sqrt{n})")#text(" where ")#mi("G")#text(" is a fixed Schwartz function independent of ")#mi("n")#text(". However, for fixed ")#mi("x")#text(" and ")#mi("n \\to \\infty")#text(", we have ")#mi("\\hat{G}(x/\\sqrt{n}) \\to \\hat{G}(0)")#text(", a nonzero constant, so the Schwartz decay in ")#mi("x")#text(" degrades as ")#mi("n")#text(" grows.")

#text("Does this Schwartz factor nonetheless resolve the domination issue? Or I wonder if additional input needed for the unbounded annulus, analogous to what Stone (1965) achieves by introducing a kernel with compactly supported Fourier transform ")#tao-math("k(\\theta) = (1 - \\left|\\theta\\right|)\\mathbf{1}_{\\left|\\theta\\right| < 1}", block: false)#text(", which eliminates the unbounded region entirely, with the remaining middle region estimate deferred to Rva\\v{c}eva (1954)?")

#text("Thank you again for your time!")

#text("PS: As a minor note, I think the key expression at the end of the proof of Theorem 8 should read ")#tao-math("\\int_{\\left|x\\right| \\leq A\\sqrt{n}} \\left|\\hat{G}(x/\\sqrt{n})\\right|\\left|\\varphi_X(x/\\sqrt{n})^n - e^{-x^2/2}\\right| \\, dx", block: false)#text(" for consistency.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-692277")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2026")])]

#text("We have localized to ")#tao-math("\\left|x\\right| \\leq A \\sqrt{n}", block: false)#text(" in a previous step, so we are already effectively working in a bounded annulus.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-693238")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2026")])]

#text("In the first section of this post, when estimating the binomial coefficients, why would you express the binomial coefficients in the form of the entropy function?")

#emph[#text("[This is what naturally comes out of using Stirling’s formula to estimate the asymptotic growth of such coefficients. See also ")#link("https://en.wikipedia.org/wiki/Asymptotic_equipartition_property")[#text("https://en.wikipedia.org/wiki/Asymptotic_equipartition_property")]#text(" -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-693244")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2026")])]

#text("Thank you for your comment. However, I don’t understand the connection between the wiki link you provided and the estimation here. In fact, I checked the entire wiki link and didn’t find any mention of the binomial coefficient or the entropy function. Could you explain in detail how the asymptotic equipartition property relates to them?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2015/11/19/275a-notes-5-variants-of-the-central-limit-theorem/#comment-693245")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2026")])]

#text("Apply asymptotic equipartition with ")#mi("X")#text(" being the boolean random variable that equals ")#mi("1")#text(" with probability ")#mi("\\alpha")#text(" and ")#mi("0")#text(" with probability ")#mi("1-\\alpha")#text(". The Shannon entropy of this variable is thus ")#mi("H(X) = h(\\alpha) = \\alpha \\log \\frac{1}{\\alpha} + (1-\\alpha) \\log \\frac{1}{1 - \\alpha}")#text(". This theorem then indicates that almost surely, the outcome ")#mi("(X_1,\\dots,X_n)")#text(" of ")#mi("n")#text(" independent samples ")#mi("(X_1,\\dots,X_n)")#text(" will have probability density about ")#mi("\\exp(-n H(X))")#text(", and so should occur about ")#mi("\\exp(n H(X))")#text(" times. On the other hand, the law of large numbers tells us that such samples should contain about ")#mi("k = \\alpha n")#text(" zeroes, which occurs about ")#mi("\\binom{n}{k}")#text(". This (at least heuristically) gives the same approximation ")#mi("\\binom{n}{k} \\approx \\exp(n h(\\alpha))")#text(" discussed in the blog post.")
]
]
]
