// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/
// Converted to Typst by tao2typ: "2026-10-14T16:37:12.140089+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An improved Type I estimate", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An improved Type I estimate")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 27 July 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/")[#text("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As in all previous posts in this series, we adopt the following asymptotic notation: ")#mi("{x}")#text(" is a parameter going off to infinity, and all quantities may depend on ")#mi("{x}")#text(" unless explicitly declared to be “fixed”. The asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" is then defined relative to this parameter. A quantity ")#mi("{q}")#text(" is said to be ")#emph[#text("of polynomial size")]#text(" if one has ")#mi("{q = O(x^{O(1)})}")#text(", and ")#emph[#text("bounded")]#text(" if ")#mi("{q=O(1)}")#text(". We also write ")#mi("{X \\lessapprox Y}")#text(" for ")#mi("{X \\ll x^{o(1)} Y}")#text(", and ")#mi("{X \\sim Y}")#text(" for ")#mi("{X \\ll Y \\ll X}")#text(".")

#text("The purpose of this (rather technical) post is both to roll over the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8")]#text(" research thread from ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("this previous post")]#text(", and also to record the details of the latest improvement to the Type I estimates (based on exploiting additional averaging and using Deligne’s proof of the Weil conjectures) which lead to a slight improvement in the numerology.")

#text("In order to obtain this new Type I estimate, we need to strengthen the previously used properties of “dense divisibility” or “double dense divisibility” as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Multiple dense divisibility)")]#text(" Let ")#mi("{y \\geq 1}")#text(". For each natural number ")#mi("{k \\geq 0}")#text(", we define a notion of ")#mi("{k}")#text("-tuply ")#mi("{y}")#text("-dense divisibility recursively as follows:")

#list(
[#text("Every natural number ")#mi("{n}")#text(" is ")#mi("{0}")#text("-tuply ")#mi("{y}")#text("-densely divisible.")],
[#text("If ")#mi("{k \\geq 1}")#text(" and ")#mi("{n}")#text(" is a natural number, we say that ")#mi("{n}")#text(" is ")#mi("{k}")#text("-tuply ")#mi("{y}")#text("-densely divisible if, whenever ")#mi("{i,j \\geq 0}")#text(" are natural numbers with ")#mi("{i+j=k-1}")#text(", and ")#mi("{1 \\leq R \\leq n}")#text(", one can find a factorisation ")#mi("{n = qr}")#text(" with ")#mi("{y^{-1} R \\leq r \\leq R}")#text(" such that ")#mi("{q}")#text(" is ")#mi("{i}")#text("-tuply ")#mi("{y}")#text("-densely divisible and ")#mi("{r}")#text(" is ")#mi("{j}")#text("-tuply ")#mi("{y}")#text("-densely divisible.")]
)

#text("We let ")#mi("{{\\mathcal D}^{(k)}_y}")#text(" denote the set of ")#mi("{k}")#text("-tuply ")#mi("{y}")#text("-densely divisible numbers. We abbreviate “")#mi("{1}")#text("-tuply densely divisible” as “densely divisible”, “")#mi("{2}")#text("-tuply densely divisible” as “doubly densely divisible”, and so forth; we also abbreviate ")#mi("{{\\mathcal D}^{(1)}_y}")#text(" as ")#mi("{{\\mathcal D}_y}")#text(".")
]

#text("Given any finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf C}}")#text(" and any primitive residue class ")#mi("{a\\ (q)}")#text(", we define the discrepancy")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\alpha; a \\ (q)) := \\sum_{n: n = a\\ (q)} \\alpha(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1} \\alpha(n).")]]

#text("We now recall the key concept of a coefficient sequence, with some slight tweaks in the definitions that are technically convenient for this post.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2")]#text(" A ")#emph[#text("coefficient sequence")]#text(" is a finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf R}}")#text(" that obeys the bounds ")#metadata(none) <tao-afd7bf72960f2f867380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\alpha(n)\\right| \\ll \\tau^{O(1)}(n) \\log^{O(1)}(x)", block: true)]]

#text("for all ")#mi("{n}")#text(", where ")#mi("{\\tau}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(".")

#list(
[#text("(i) A coefficient sequence ")#mi("{\\alpha}")#text(" is said to be ")#emph[#text("located at scale ")#mi("{N}")]#text(" for some ")#mi("{N \\geq 1}")#text(" if it is supported on an interval of the form ")#mi("{[cN, CN]}")#text(" for some ")#mi("{1 \\ll c < C \\ll 1}")#text(".")],
[#text("(ii) A coefficient sequence ")#mi("{\\alpha}")#text(" located at scale ")#mi("{N}")#text(" for some ")#mi("{N \\geq 1}")#text(" is said to ")#emph[#text("obey the Siegel-Walfisz theorem")]#text(" if one has")

#metadata(none) <tao-a543997d84f12798350c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left| \\Delta(\\alpha 1_{(\\cdot,q)=1}; a\\ (r)) \\right| \\ll \\tau(qr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{q,r \\geq 1}")#text(", any fixed ")#mi("{A}")#text(", and any primitive residue class ")#mi("{a\\ (r)}")#text(".")],
[#text("(iii) A coefficient sequence ")#mi("{\\alpha}")#text(" is said to be ")#emph[#text("smooth at scale ")#mi("{N}")]#text(" for some ")#mi("{N > 0}")#text(" is said to be ")#emph[#text("smooth")]#text(" if it takes the form ")#mi("{\\alpha(n) = \\psi(n/N)}")#text(" for some smooth function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on an interval of size ")#mi("{O(1)}")#text(" and obeying the derivative bounds")

#metadata(none) <tao-ab1e6be2000a7c9c3d39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left|\\psi^{(j)}(t)\\right| \\lesssim \\log^{O(1)} x", block: true)]]

#text("for all fixed ")#mi("{j \\geq 0}")#text(" (note that the implied constant in the ")#mi("{O()}")#text(" notation may depend on ")#mi("{j}")#text(").")]
)
]

#text("Note that we allow sequences to be smooth at scale ")#mi("{N}")#text(" without being located at scale ")#mi("{N}")#text("; for instance if one arbitrarily translates of a sequence that is both smooth and located at scale ")#mi("{N}")#text(", it will remain smooth at this scale but may not necessarily be located at this scale any more. Note also that we allow the smoothness scale ")#mi("{N}")#text(" of a coefficient sequence to be less than one. This is to allow for the following convenient rescaling property: if ")#mi("{n \\mapsto \\psi(n)}")#text(" is smooth at scale ")#mi("{N}")#text(", ")#mi("{q \\geq 1}")#text(", and ")#mi("{a}")#text(" is an integer, then ")#mi("{n \\mapsto \\psi(qn+a)}")#text(" is smooth at scale ")#mi("{N/q}")#text(", even if ")#mi("{N/q}")#text(" is less than one.")

#text("Now we adapt the Type I estimate to the ")#mi("{k}")#text("-tuply densely divisible setting.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 3 (Type I estimates)")]#text(" Let ")#mi("{0 < \\varpi < 1/4}")#text(", ")#mi("{0 < \\delta < 1/4+\\varpi}")#text(", and ")#mi("{0 < \\sigma < 1/2}")#text(" be fixed quantities, and let ")#mi("{k \\geq 1}")#text(" be a fixed natural number. We let ")#mi("{I}")#text(" be an arbitrary bounded subset of ")#mi("{{\\bf R}}")#text(", let ")#mi("{P_I := \\prod_{p \\in I} p}")#text(", and let ")#mi("{a\\ (P_I)}")#text(" a primitive congruence class. We say that ")#mi("{Type^{(k)}_I[\\varpi,\\delta,\\sigma]}")#text(" holds if, whenever ")#mi("{M, N \\gg 1}")#text(" are quantities with ")#metadata(none) <tao-2f48b881ea7073f1c6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("M N \\sim x")]]

#text("and ")#metadata(none) <tao-58e0413224af6b6d3505>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("x^{1/2-\\sigma} \\lessapprox N \\lessapprox x^{1/2-2\\varpi-c}")]]

#text("for some fixed ")#mi("{c>0}")#text(", and ")#mi("{\\alpha,\\beta}")#text(" are coefficient sequences located at scales ")#mi("{M,N}")#text(" respectively, with ")#mi("{\\beta}")#text(" obeying a Siegel-Walfisz theorem, we have ")#metadata(none) <tao-a8b405ab6f00d98196ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}^{(k)}: q \\leq x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha * \\beta; a\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(". Here, as in previous posts, ")#mi("{{\\mathcal S}_I}")#text(" denotes the square-free natural numbers whose prime factors lie in ")#mi("{I}")#text(".")
]

#text("The main theorem of this post is then")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Improved Type I estimate)")]#text(" ")#metadata(none) <tao-840c81157f3688e42875>#text(" We have ")#mi("{Type^{(4)}_I[\\varpi,\\delta,\\sigma]}")#text(" whenever")

#align(center)[#tao-fit-display[#mitex("\\frac{160}{3} \\varpi + 16 \\delta + \\frac{34}{9} \\sigma < 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("64\\varpi + 18\\delta + 2\\sigma < 1.")]]
]

#text("In practice, the first condition here is dominant. Except for weakening double dense divisibility to quadruple dense divisibility, this improves upon the previous Type I estimate that established ")#mi("{Type^{(2)}_I[\\varpi,\\delta,\\sigma]}")#text(" under the stricter hypothesis")

#align(center)[#tao-fit-display[#mitex("56 \\varpi + 16 \\delta + 4 \\sigma < 1.")]]

#text("As in previous posts, Type I estimates (when combined with existing Type II and Type III estimates) lead to distribution results of Motohashi-Pintz-Zhang type. For any fixed ")#mi("{\\varpi, \\delta > 0}")#text(" and ")#mi("{k \\geq 1}")#text(", we let ")#mi("{MPZ^{(k)}[\\varpi,\\delta]}")#text(" denote the assertion that ")#metadata(none) <tao-54d1cac47e17ad572009>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}^{(k)}: q \\leq x^{1/2+2\\varpi}} \\left|\\Delta(\\Lambda 1_{[x,2x]}; a\\ (q))\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A > 0}")#text(", any bounded ")#mi("{I}")#text(", and any primitive ")#mi("{a\\ (P_I)}")#text(", where ")#mi("{\\Lambda}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Von_Mangoldt_function")[#text("von Mangoldt function")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 5")]#text(" We have ")#mi("{MPZ^{(4)}[\\varpi,\\delta]}")#text(" whenever ")#metadata(none) <tao-42029ef215256f8fa9fe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("\\frac{600}{7} \\varpi + \\frac{180}{7} \\delta < 1")]]
]

#emph[#text("Proof:")]#text(" Setting ")#mi("{\\sigma}")#text(" sufficiently close to ")#mi("{1/10}")#text(", we see from the above theorem that ")#mi("{Type^{(4)}_{II}[\\varpi,\\delta]}")#text(" holds whenever")

#align(center)[#tao-fit-display[#mitex("\\frac{600}{7} \\varpi + \\frac{180}{7} \\delta < 1")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("80 \\varpi + \\frac{45}{2} \\delta < 1.")]]

#text("The second condition is implied by the first and can be deleted.")

#text("From ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("this previous post")]#text(" we know that ")#mi("{Type^{(4)}_{II}[\\varpi,\\delta]}")#text(" (which we define analogously to ")#mi("{Type^{\\prime}_{II}[\\varpi,\\delta], Type^{\\prime\\prime}_{II}[\\varpi,\\delta]}")#text(" from previous sections) holds whenever")

#align(center)[#tao-fit-display[#mitex("68 \\varpi + 14 \\delta < 1")]]

#text("while ")#mi("{Type^{(4)}_{III}[\\varpi,\\delta,\\sigma]}")#text(" holds with ")#mi("{\\sigma}")#text(" sufficiently close to ")#mi("{1/10}")#text(" whenever")

#align(center)[#tao-fit-display[#mitex("70 \\varpi + 5 \\delta < 1.")]]

#text("Again, these conditions are implied by ")#link(<tao-42029ef215256f8fa9fe>)[#text("(8)")]#text(". The claim then follows from the Heath-Brown identity and dyadic decomposition as in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(". ")#mi("\\Box")

#text("As before, we let ")#mi("{DHL[k_0,2]}")#text(" denote the claim that given any admissible ")#mi("{k_0}")#text("-tuple ")#mi("{{\\mathcal H}}")#text(", there are infinitely many translates of ")#mi("{{\\mathcal H}}")#text(" that contain at least two primes.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-730f75dafd73e047b86a>#text(" We have ")#mi("{DHL[k_0,2]}")#text(" with ")#mi("{k_0 = 632}")#text(".")
]

#text("This follows from the Pintz sieve, as discussed below the fold. Combining this with the ")#link("http://math.mit.edu/~primegaps/")[#text("best known prime tuples")]#text(", we obtain that there are infinitely many prime gaps of size at most ")#mi("{4,680}")#text(", improving slightly over the previous record of ")#mi("{5,414}")#text(".")

#metadata(none) <tao-daa8d4f4743e45edaa0e>

#heading(level: 1)[#strong[#text(" — 1. Multiple dense divisibility — ")]]

#text("We record some useful properties of dense divisibility.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Properties of dense divisibility)")]#text(" ")#metadata(none) <tao-b1b927541c77e69aea9d>#text(" Let ")#mi("{k \\geq 0}")#text(" and ")#mi("{y \\geq 1}")#text(".")

#list(
[#text("(i) If ")#mi("{n}")#text(" is ")#mi("{k}")#text("-tuply ")#mi("{y}")#text("-densely divisible, and ")#mi("{m}")#text(" is a factor of ")#mi("{n}")#text(", then ")#mi("{m}")#text(" is ")#mi("{k}")#text("-tuply ")#mi("{y (n/m)}")#text("-densely divisible. Similarly, if ")#mi("{l}")#text(" is a multiple of ")#mi("{n}")#text(", then ")#mi("{l}")#text(" is ")#mi("{y (l/n)}")#text("-densely divisible.")],
[#text("(ii) If ")#mi("{m,n}")#text(" are ")#mi("{y}")#text("-densely divisible, then ")#mi("{[m,n]}")#text(" is also ")#mi("{y}")#text("-densely divisible.")],
[#text("(iii) Any ")#mi("{y}")#text("-smooth number is ")#mi("{k}")#text("-tuply ")#mi("{y}")#text("-densely divisible.")],
[#text("(iv) If ")#mi("{n}")#text(" is ")#mi("{y^{\\prime}}")#text("-smooth and square-free for some ")#mi("{y^{\\prime} \\geq y}")#text(", and ")#mi("{\\prod_{p|n: p \\leq y} p \\geq (y^{\\prime})^k/y}")#text(", then ")#mi("{n}")#text(" is ")#mi("{k}")#text("-tuply ")#mi("{y}")#text("-densely divisible.")]
)
]

#emph[#text("Proof:")]#text(" (i) is easily established by induction on ")#mi("{k}")#text(", the idea being to start with a good factorisation of ")#mi("{n}")#text(" and perturb it into a factorisation of ")#mi("{m}")#text(" or ")#mi("{l}")#text(" by dividing or multiplying by a small number. To prove (ii), we may assume without loss of generality that ")#mi("{m \\leq n}")#text(", so that ")#mi("{n \\geq [m,n]^{1/2}}")#text(". If we set ")#mi("{a := \\frac{[m,n]}{n}}")#text(", then the factors of ")#mi("{n}")#text(", as well as the factors of ")#mi("{n}")#text(" multiplied by ")#mi("{a}")#text(", are both factors of ")#mi("{[m,n]}")#text(". From this we can deduce the ")#mi("{y}")#text("-dense divisibility of ")#mi("{[m,n]}")#text(" from the ")#mi("{y}")#text("-dense divisibility of ")#mi("{n}")#text(".")

#text("The claim (iii) is easily established by induction on ")#mi("{k}")#text(" and a greedy algorithm, so we turn to (iv). The claim is trivial for ")#mi("{k=0}")#text(". Next, we consider the ")#mi("{k=1}")#text(" case. Our task is to show that for any ")#mi("{1 \\leq R \\leq n}")#text(", one can find a factorisation ")#mi("{n=qr}")#text(" with ")#mi("{y^{-1} R \\leq r \\leq R}")#text(". If ")#mi("{\\prod_{p|n: p>y} p \\leq R}")#text(", we can achieve this factorisation by initialising ")#mi("{r}")#text(" to equal ")#mi("{\\prod_{p|n: p>y} p}")#text(" and then greedily multiplying the remaining factors of ")#mi("{n}")#text(" until one exceeds ")#mi("{y^{-1} R}")#text(", so we may assume instead that ")#mi("{\\prod_{p|n: p>y} p > R}")#text(". Then by the greedy algorithm we can find a factor ")#mi("{r^{\\prime}}")#text(" of ")#mi("{\\prod_{p|n: p>y} p}")#text(" with ")#mi("{(y^{\\prime})^{-1} R \\leq r^{\\prime} \\leq R}")#text("; if we then greedily multiply ")#mi("{r^{\\prime}}")#text(" by factors ")#mi("{p|n}")#text(" with ")#mi("{p<y}")#text(" we obtain the claim.")

#text("Finally we consider the ")#mi("{k>1}")#text(" case. We assume inductively that the claim has already been proven for smaller values of ")#mi("{k}")#text(". Let ")#mi("{i,j \\geq 0}")#text(" be such that ")#mi("{i+j=k-1}")#text(". By hypothesis, the ")#mi("{y}")#text("-smooth quantity ")#mi("{n^{\\prime} := \\prod_{p|n: p \\geq y} p}")#text(" is at least ")#mi("{(y^{\\prime})^i (y^{\\prime})^j (y^{\\prime}/y)}")#text(". By the greedy algorithm, we may thus factor ")#mi("{n^{\\prime} = n_1 n_2 n_3}")#text(" where")

#align(center)[#tao-fit-display[#mitex("(y^{\\prime})^i y^{-1} \\leq n_1 \\leq (y^{\\prime})^i")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(y^{\\prime})^j y^{-1} \\leq n_2 \\leq (y^{\\prime})^j")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("n_3 \\geq y^{\\prime}/y.")]]

#text("Now we divide into several cases. Suppose first that ")#mi("{n_1 \\leq R \\leq n/n_2}")#text(". Then ")#mi("{1 \\leq \\frac{R}{n_1} \\leq \\frac{n}{n_1 n_2}}")#text(", so by the ")#mi("{k=1}")#text(" case, we may find a factorisation ")#mi("{\\frac{n}{n_1 n_2} = q^{\\prime} r^{\\prime}}")#text(" with ")#mi("{y^{-1} \\frac{R}{n_1} \\leq r^{\\prime} \\leq \\frac{R}{n_1}}")#text(". Setting ")#mi("{r := n_1 r^{\\prime}}")#text(" and ")#mi("{q := n_2 q^{\\prime}}")#text(", the claim then follows from the induction hypothesis.")

#text("Now suppose that ")#mi("{R < n_1}")#text(". By the greedy algorithm, we may then find a factor ")#mi("{r}")#text(" of the ")#mi("{y}")#text("-smooth quantity ")#mi("{n_1}")#text(" with ")#mi("{y^{-1} R \\leq r \\leq R}")#text("; setting ")#mi("{q := n/r}")#text(", we see that ")#mi("{q}")#text(" is a multiple of ")#mi("{n_2}")#text(" and hence ")#mi("{\\prod_{p|q: p \\leq y} p \\geq (y^{\\prime})^j y^{-1}}")#text(". The claim now follows from the induction hypothesis and (iii).")

#text("Finally, suppose that ")#mi("{R > n/n_2}")#text(". By the greedy algorithm, we may then find a factor ")#mi("{q}")#text(" of the ")#mi("{y}")#text("-smooth quantity ")#mi("{n_2}")#text(" with ")#mi("{n/R \\leq q \\leq yn/R}")#text("; setting ")#mi("{r := n/q}")#text(", we see that ")#mi("{r}")#text(" is a multiple of ")#mi("{n_1}")#text(" and hence ")#mi("{\\prod_{p|r: p \\leq y} p \\geq (y^{\\prime})^i y^{-1}}")#text(". The claim now follows from the induction hypothesis and (iii). ")#mi("\\Box")

#text("Now we record the criterion for using ")#mi("{MPZ^{(k)}}")#text(" to deduce ")#mi("{DHL[k_0,2]}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8 (Criterion for DHL)")]#text(" Let ")#mi("{\\varpi, \\delta}")#text(" be such that ")#mi("{MPZ^{(k)}[\\varpi,\\delta]}")#text(" holds. Suppose that one can find a natural number ")#mi("{k_0 > 2}")#text(" and real numbers ")#mi("{\\delta \\leq \\delta^{\\prime} \\leq 1/4+\\varpi}")#text(" and ")#mi("{A > 0}")#text(" such that")

#align(center)[#tao-fit-display[#mitex("(1+4\\varpi) (1-2\\kappa_1 - 2\\kappa_2 - 2\\kappa_3) > \\frac{j^{2}_{k_0-2}}{k_0(k_0-1)}")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("\\kappa_1  & := \\int_{\\theta}^1 (1-t)^{(k_0-1)/2} \\frac{dt}{t}", block: true)



#tao-math("\\kappa_2  & := (k_0-1) \\int_{\\theta}^1 (1-t)^{k_0-1} \\frac{dt}{t}", block: true)



#tao-math("\\kappa_3  & := \\tilde \\theta \\frac{J_{k_0-2}(\\sqrt{\\tilde \\theta} j_{k_0-2})^2 - J_{k_0-3}(\\sqrt{\\tilde \\theta} j_{k_0-2}) J_{k_0-1}(\\sqrt{\\tilde \\theta} j_{k_0-2})}{ J_{k_0-3}(j_{k_0-2})^2 }", block: true)
]

#align(center)[#tao-fit-display[#mitex("\\times \\exp( A + (k_0-1) \\int_{\\tilde \\delta}^\\theta e^{-(A+2\\alpha)t} \\frac{dt}{t} )")]]

#tao-aligned(keep: true)[


#tao-math("\\alpha  & := \\frac{j_{k_0-2}^2}{4(k_0-1)}", block: true)



#tao-math("\\theta  & := \\frac{\\delta^{\\prime}}{1/4 + \\varpi}", block: true)



#tao-math("\\tilde \\theta  & := \\frac{k\\delta^{\\prime} - \\delta/2 + \\varpi}{1/4 + \\varpi}", block: true)



#tao-math("\\tilde \\delta  & := \\frac{\\delta}{1/4 + \\varpi}.", block: true)
]

#text("Then ")#mi("{DHL[k_0,2]}")#text(" holds.")
]

#emph[#text("Proof:")]#text(" We use the Pintz sieve from ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/")[#text("this post")]#text(", repeating the proof of Theorem 5 from that post (and using the explicit formulae for ")#mi("{G_{k_0-1}(0,0)}")#text(" and ")#mi("{G_{k_0-1,\\tilde \\theta}(0,0)}")#text(" from ")#link("https://terrytao.wordpress.com/2013/06/18/a-truncated-elementary-selberg-sieve-of-pintz/#comment-235454")[#text("this comment thread")]#text("). The main difference is that the exponent ")#mi("{(\\delta^{\\prime}-\\delta)/2 + \\varpi + \\epsilon/2}")#text(" in equation (10) of that post needs to be replaced with ")#mi("{(k\\delta^{\\prime}-\\delta)/2 + \\varpi + \\epsilon/2}")#text(" (and similarly for the displays up to (11)), and ")#mi("{{\\mathcal D}_{x^\\delta}}")#text(" needs to be replaced with ")#mi("{{\\mathcal D}_{x^\\delta}^{(k)}}")#text(". ")#mi("\\Box")

#text("Applying this proposition with ")#mi("{k_0 := 632}")#text(", ")#mi("{\\delta = 1/11500}")#text(", ")#mi("{\\delta^{\\prime} := 1/128}")#text(", ")#mi("{600 \\varpi/7 + 180 \\delta / 7}")#text(" sufficiently close to ")#mi("{1}")#text(", and ")#mi("{A := 200}")#text(" we obtain ")#mi("{DHL[632,2]}")#text(" as claimed.")

#heading(level: 1)[#strong[#text(" — 2. van der Corput estimates — ")]]

#text("In this section we generalise the van der Corput estimates from Section 1 of ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("this previous post")]#text(" to wider classes of “structured functions” than rational phases. We will adopt an axiomatic approach, laying out the precise axioms that we need a given class of structured functions to obey:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 9 (Structured functions)")]#text(" Let ")#mi("{I}")#text(" be a bounded subset of ")#mi("{{\\bf R}}")#text(". A ")#emph[#text("class of structured functions")]#text(" is a family ")#mi("{{\\mathcal C} = ({\\mathcal C}_{p,C})_{p,C}}")#text(" of collections ")#mi("{{\\mathcal C}_{p,C}}")#text(" of functions ")#mi("{K:U \\rightarrow {\\bf C}}")#text(" defined on subsets ")#mi("{U}")#text(" of ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" for each prime ")#mi("{p \\in I}")#text(" and every ")#mi("{C \\geq 1}")#text("; an element of ")#mi("{{\\mathcal C}_{p,C}}")#text(" is then said to be a ")#emph[#text("structured function")]#text(" of complexity at most ")#mi("{C}")#text(" and modulus ")#mi("{p}")#text(". Furthermore we place an equivalence relation ")#mi("{\\equiv}")#text(" on each class ")#mi("{{\\mathcal C}_{p,C}}")#text(" with ")#mi("{p}")#text(" sufficiently large depending on ")#mi("{C}")#text(". This class and this equivalence relation is assumed to obey the following axioms:")

#list(
[#text("(i) (Monotonicity) One has ")#mi("{{\\mathcal C}_{p,C} \\subset {\\mathcal C}_{p,C^{\\prime}}}")#text(" whenever ")#mi("{C^{\\prime} \\geq C}")#text(". Furthermore, if ")#mi("{p}")#text(" is sufficiently large depending on ")#mi("{C,C^{\\prime}}")#text(", the equivalence relations on ")#mi("{{\\mathcal C}_{p,C}}")#text(" and ")#mi("{{\\mathcal C}_{p,C^{\\prime}}}")#text(" agree on their common domain of definition.")],
[#text("(ii) (Near-total definition) If ")#mi("{K \\in {\\mathcal C}_{p,C}}")#text(", then the domain ")#mi("{U}")#text(" of ")#mi("{K}")#text(" consists of ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(" with at most ")#mi("{O_C(1)}")#text(" points removed.")],
[#text("(iii) (Pointwise bound) If ")#mi("{K \\in {\\mathcal C}_{p,C}}")#text(", then ")#mi("{K(x) = O_C(1)}")#text(" for all ")#mi("{x}")#text(" in the domain ")#mi("{U}")#text(" of ")#mi("{K}")#text(".")],
[#text("(iv) (Conjugacy) If ")#mi("{K \\in {\\mathcal C}_{p,C}}")#text(", then ")#mi("{\\overline{K} \\in {\\mathcal C}_{p,C^{\\prime}}}")#text(" for some ")#mi("{C^{\\prime} = O_C(1)}")#text(".")],
[#text("(v) (Multiplication) If ")#mi("{K,K^{\\prime} \\in {\\mathcal C}_{p,C}}")#text(", then the pointwise product ")#mi("{KK^{\\prime}}")#text(" (on the common domain of definition) can be expressed as the sum of ")#mi("{k=O_C(1)}")#text(" functions ")#mi("{K_1,\\ldots,K_k}")#text(" (which we will call the ")#emph[#text("components")]#text(" of ")#mi("{KK^{\\prime}}")#text(") in ")#mi("{{\\mathcal C}_{p,C^{\\prime}}}")#text(" for some ")#mi("{C^{\\prime} = O_C(1)}")#text(".")],
[#text("(vi) (Translation invariance) If ")#mi("{K \\in {\\mathcal C}_{p,C}}")#text(", and ")#mi("{h \\in {\\bf Z}/p{\\bf Z}}")#text(", then the function ")#mi("{x \\mapsto K(x+h)}")#text(" (defined on the translation ")#mi("{U-h}")#text(" of the domain of definition of ")#mi("{K}")#text(") lies in ")#mi("{{\\mathcal C}_{p,C^{\\prime}}}")#text(" for some ")#mi("{C^{\\prime} = O_C(1)}")#text(".")],
[#text("(vii) (Dilation invariance) If ")#mi("{K \\in {\\mathcal C}_{p,C}}")#text(", and ")#mi("{a \\in ({\\bf Z}/p{\\bf Z})^\\times}")#text(", then the function ")#mi("{x \\mapsto K(ax)}")#text(" (defined on the dilation ")#mi("{a^{-1} U}")#text(" of the domain of definition of ")#mi("{f}")#text(") lies in ")#mi("{{\\mathcal C}_{p,C^{\\prime}}}")#text(" for some ")#mi("{C^{\\prime} = O_C(1)}")#text(".")],
[#text("(viii) (Polynomial phases) If ")#mi("{P: {\\bf Z}/p{\\bf Z} \\rightarrow {\\bf Z}/p{\\bf Z}}")#text(" is a polynomial of degree at most ")#mi("{d}")#text(", then the function ")#mi("{x \\mapsto e_p(P(x))}")#text(" lies in ")#mi("{{\\mathcal C}_{p,C}}")#text(" for some ")#mi("{C = O_d(1)}")#text(". More generally, if ")#mi("{K \\in {\\mathcal C}_{p,C}}")#text(", then the product ")#mi("{x \\mapsto e_p(P(x)) K(x)}")#text(" lies in ")#mi("{{\\mathcal C}_{p,C^{\\prime}}}")#text(" for some ")#mi("{C^{\\prime} = O_{C,d}(1)}")#text(". Furthermore, if ")#mi("{p}")#text(" is sufficiently large depending on ")#mi("{d,C}")#text(", this operation respects the equivalence relation ")#mi("{\\equiv}")#text(": ")#mi("{K \\equiv K^{\\prime}}")#text(" if and only if ")#mi("{e_p(P) K \\equiv e_p(P) K^{\\prime}}")#text(". Finally, if ")#mi("{K \\equiv e_p(P)}")#text(" and ")#mi("{K}")#text(" is not identically zero, then ")#mi("{c_{K,e_p(P)} \\neq 0}")#text(".")],
[#text("(ix) (Almost orthogonality) If ")#mi("{K,K^{\\prime} \\in {\\mathcal C}_{p,C}}")#text(" have domains of definition ")#mi("{U, U^{\\prime}}")#text(" respectively, one has ")#mi("{\\sum_{x \\in U \\cap U^{\\prime}} K(x) \\overline{K^{\\prime}(x)} = c_{K,K^{\\prime}} p + O_C(p^{1/2})}")#text(" for an algebraic integer ")#mi("{c_{K,K^{\\prime}}}")#text(", with the error term ")#mi("{O_C(p^{1/2})}")#text(" being Galois-absolute in the sense that all Galois conjugates of the error term are also ")#mi("{O_C(p^{1/2})}")#text(". Furthermore, if ")#mi("{p}")#text(" is sufficiently large depending on ")#mi("{C}")#text(", then ")#mi("{c_{K,K^{\\prime}}}")#text(" vanishes whenever ")#mi("{K \\not \\equiv K^{\\prime}}")#text(".")],
[#text("(x) (Integration) Suppose that ")#mi("{K \\in {\\mathcal C}_{p,C}}")#text(" is such that ")#mi("{K(\\cdot+h) \\overline{K}}")#text(" contains a component equivalent to ")#mi("{1}")#text(" for some ")#mi("{h \\in ({\\bf Z}/p{\\bf Z})^\\times}")#text(". Suppose also that ")#mi("{p}")#text(" is sufficiently large depending on ")#mi("{C}")#text(". Then there exists ")#mi("{a \\in {\\bf Z}/p{\\bf Z}}")#text(" such that ")#mi("{K \\equiv e_p(a \\cdot)}")#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1 (Polynomial phases)")]#text(" Let ")#mi("{I}")#text(" be a bounded subset of ")#mi("{{\\bf R}}")#text(". If, for every prime ")#mi("{p \\in I}")#text(" and ")#mi("{C \\geq 1}")#text(", we define ")#mi("{{\\mathcal C}_{p,C}}")#text(" to be the set of all functions of the form ")#mi("{x \\mapsto e_p(f(x))}")#text(", where ")#mi("{f}")#text(" are polynomials of degree at most ")#mi("{C}")#text(" with integer coefficients, defined on all of ")#mi("{{\\bf Z}/p{\\bf Z}}")#text(", then this is a class of structured functions (note that the almost orthogonality axiom requires the Weil conjectures for curves). Two polyomial phases ")#mi("{e_p(f(x)), e_p(g(x))}")#text(" will be declared equivalent if ")#mi("{f,g}")#text(" differ only in the constant term. Note from the Chinese remainder theorem that the function ")#mi("{x \\mapsto e_q( f(x) )}")#text(" is then also a structured function of complexity at most ")#mi("{C}")#text(" and modulus ")#mi("{q}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Polynomial phases twisted by characters)")]#text(" Let ")#mi("{I}")#text(" be a bounded subset of ")#mi("{{\\bf R}}")#text(". If, for every prime ")#mi("{p \\in I}")#text(" and ")#mi("{C \\geq 1}")#text(", we define ")#mi("{{\\mathcal C}_{p,C}}")#text(" to be the set of all functions of the form ")#mi("{x \\mapsto e(\\theta) e_p(f(x)) \\prod_{i=1}^k \\chi_i( g_i(x) )}")#text(", where ")#mi("{e(\\theta)}")#text(" is a phase, ")#mi("{g_i,f}")#text(" are polynomials of degree at most ")#mi("{C}")#text(" with integer coefficients, ")#mi("{0 \\leq k \\leq C}")#text(", and the ")#mi("{\\chi_i}")#text(" are Dirichlet characters of order ")#mi("{p}")#text(", with the non-standard convention that ")#mi("{\\chi_i}")#text(" is undefined (instead of vanishing) at zero. Then this is a class of structured functions (again, the almost orthogonality axiom requires the Weil conjectures for curves). We declare two structured functions to be equivalent if they agree up to a constant phase on their common domain of definition. Note from the Chinese remainder theorem that the function ")#mi("{x \\mapsto e_q( f(x) ) \\prod_{i=1}^k \\chi_i(g_i(x))}")#text(" is then also a structured function of complexity at most ")#mi("{C}")#text(" if the ")#mi("{\\chi_i}")#text(" are Dirichlet characters of period ")#mi("{q}")#text(" (and conductor dividing ")#mi("{q}")#text("), again with the convention that ")#mi("{\\chi(x)}")#text(" is undefined (instead of vanishing) when ")#mi("{(x,q) \\neq 1}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3 (Rational phases)")]#text(" Let ")#mi("{I}")#text(" be a bounded subset of ")#mi("{{\\bf R}}")#text(". If, for every prime ")#mi("{p \\in I}")#text(" and ")#mi("{C \\geq 1}")#text(", we define ")#mi("{{\\mathcal C}_{p,C}}")#text(" to be the set of all functions of the form ")#mi("{x \\mapsto e_p(\\frac{f(x)}{g(x)})}")#text(", where ")#mi("{f,g}")#text(" are polynomials of degree at most ")#mi("{C}")#text(" with integer coefficients and with ")#mi("{g}")#text(" monic, with the function only defined when ")#mi("{g(x) \\neq 0}")#text(", then this is a class of structured functions (again, the almost orthogonality axiom requires the Weil conjectures for curves). We declare two structured functions to be equivalent if they agree up to a constant phase on their common domain of definition. Note from the Chinese remainder theorem that the function ")#mi("{x \\mapsto e_q( \\frac{f(x)}{g(x)})}")#text(" is then also a structured function of complexity at most ")#mi("{C}")#text(" and modulus ")#mi("{q}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 4 (Trace weights)")]#text(" ")#metadata(none) <tao-fe6ecff9a0b92a67f615>#text(" Let ")#mi("{I}")#text(" be a bounded subset of ")#mi("{{\\bf R}}")#text(". We fix a prime ")#mi("{\\ell}")#text(" not in ")#mi("{I}")#text(", and we fix an embedding ")#mi("{\\iota: {\\bf Q}_\\ell \\rightarrow {\\bf C}}")#text(" of the ")#mi("{\\ell}")#text("-adics into ")#mi("{{\\bf C}}")#text(". If, for every prime ")#mi("{p \\in I}")#text(" and ")#mi("{C \\geq 1}")#text(", we define ")#mi("{{\\mathcal C}_{p,C}}")#text(" to be the set of all functions ")#mi("{K = K_{\\mathcal F}: U \\rightarrow {\\bf C}}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("K(x) := \\iota( \\text{tr}( \\text{Frob}_x | {\\mathcal F}_x ) )")]]

#text("where ")#mi("{U}")#text(" is ")#mi("{{\\Bbb F}_p = {\\bf Z}/p{\\bf Z}}")#text(" with at most ")#mi("{C}")#text(" points removed, and ")#mi("{{\\mathcal F}}")#text(" is a lisse ")#mi("{\\ell}")#text("-adic sheaf on ")#mi("{U}")#text(" that is pure of weight ")#mi("{0}")#text(" and geometrically isotypic with conductor at most ")#mi("{C}")#text(" (see ")#link("https://terrytao.wordpress.com/2013/07/19/the-riemann-hypothesis-in-various-settings/")[#text("this previous post")]#text(" for definitions of these terms), then this is a class of structured functions. We declare two trace weights ")#mi("{K, K^{\\prime}}")#text(" to be equivalent if one has ")#mi("{K = K_{\\mathcal F}}")#text(" and ")#mi("{K^{\\prime} = K_{{\\mathcal F}^{\\prime}}}")#text(" for some geometrically isotypic sheaves ")#mi("{{\\mathcal F}, {\\mathcal F}^{\\prime}}")#text(" whose geometrically irreducible components are isomorphic. The almost orthogonality now is deeper, being a consequence of Deligne’s second proof of the Weil conjectures, and also using a form of Schur’s lemma for sheaves; see Section 5 of ")#link("http://arxiv.org/abs/1211.3282")[#text("this paper of Fouvry, Kowalski, and Michel")]#text(". The integration axiom follows from Lemma 5.3 of the same paper. This class of structured functions includes the previous three classes, but also includes Kloosterman-type objects such as ")#mi("{x \\mapsto \\frac{1}{\\sqrt{p}} \\sum_{y \\in {\\Bbb F}_p^\\times} e_p( \\frac{1}{y} + xy)}")#text(" (and many other exponential sums) besides. (Indeed, it basically closed under the operations of Fourier transforms, convolution, and pullback, as long as certain degenerate cases are avoided.)")
]

#text("We now turn to the problem of obtaining non-trivial bounds for the expression")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\psi_N(n) K_q(n)")]]

#text("where ")#mi("{q \\in {\\mathcal S}_I}")#text(", ")#mi("{K_q}")#text(" is a structured function of bounded complexity and modulus ")#mi("{q}")#text(", and ")#mi("{\\psi_N}")#text(" is a smooth function at scale ")#mi("{N}")#text(". The trivial bound here is")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\psi_N(n) K_q(n)| \\lessapprox N,")]]

#text("since one has ")#tao-math("{\\left|K_q(n)\\right| \\lessapprox 1}", block: false)#text(" from the divisor bound. In some cases we cannot hope to improve upon this bound; for instance, if ")#mi("{K_q}")#text(" is a constant phase ")#mi("{e(\\theta)}")#text(" then there is clearly no improvement available. Similarly, if ")#mi("{K_q}")#text(" is the linear phase ")#mi("{K_q(n) = e_q(n) e(\\theta)}")#text(", then there is no improvement in the regime ")#mi("{N \\ll q}")#text("; if ")#mi("{K_q}")#text(" is the quadratic phase ")#mi("{K_q(n) = e_q(n^2) e(\\theta)}")#text(" then there is no improvement in the regime ")#mi("{N \\ll q^{1/2}}")#text("; if ")#mi("{K_q}")#text(" is the cubic phase ")#mi("{K_q(n) = e_q(n^3) e(\\theta)}")#text(" then there is no improvement in the regime ")#mi("{N \\ll q^{1/3}}")#text("; and so forth. On the other hand, we will be able to establish a ")#emph[#text("van der Corput estimate")]#text(" which roughly speaking asserts that as long as these polynomial obstructions are avoided, and ")#mi("{q}")#text(" is smooth, one gets a non-trivial gain.")

#text("We first need a lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Fundamental theorem of calculus)")]#text(" ")#metadata(none) <tao-639f78fb7729d09dc606>#text(" Let ")#mi("{{\\mathcal C}}")#text(" be a class of structured functions. Let ")#mi("{C, d \\geq 0}")#text(", let ")#mi("{p \\in I}")#text(", and let ")#mi("{K}")#text(" be a structured function of complexity at most ")#mi("{C}")#text(" with modulus ")#mi("{p}")#text(". Assume that ")#mi("{p}")#text(" is sufficiently large depending on ")#mi("{C,d}")#text(". Let ")#mi("{h \\in ({\\bf Z}/p{\\bf Z})^\\times}")#text(", and suppose that there is a polynomial ")#mi("{P: {\\bf Z}/p{\\bf Z} \\rightarrow {\\bf Z}/p{\\bf Z}}")#text(" of degree at most ")#mi("{d}")#text(" such that ")#mi("{K(\\cdot+h) \\overline{K} \\equiv e_p(P)}")#text(" for all ")#mi("{n \\in {\\bf Z}/p{\\bf Z}}")#text(" for which this identity is well-defined. Then there exists a polynomial ")#mi("{Q: {\\bf Z}/p{\\bf Z} \\rightarrow {\\bf Z}/p{\\bf Z}}")#text(" of degree at most ")#mi("{d+1}")#text(" such that ")#mi("{K \\equiv e_p(Q)}")#text(" for all ")#mi("{n \\in {\\bf Z}/p{\\bf Z}}")#text(" for which this identity is well-defined.")
]

#emph[#text("Proof:")]#text(" By dilating by ")#mi("{h}")#text(" and using the dilation invariance of structured functions, we may assume without loss of generality that ")#mi("{h=1}")#text(". We can write ")#mi("{P}")#text(" in terms of the binomial functions ")#mi("{n \\mapsto \\binom{n}{i}}")#text(" for ")#mi("{i=0,\\ldots,d}")#text(" (which are well-defined if ")#mi("{p > d}")#text(") as")

#align(center)[#tao-fit-display[#mitex("P(n) = \\sum_{i=0}^d c_i \\binom{n}{i}")]]

#text("for some coefficients ")#mi("{c_0,\\ldots,c_d\\in {\\bf Z}/p{\\bf Z}}")#text(". If we then define")

#align(center)[#tao-fit-display[#mitex("Q_0(n) := \\sum_{i=0}^d c_i \\binom{n}{i+1}")]]

#text("then ")#mi("{Q_0}")#text(" is a polynomial of degree at most ")#mi("{d+1}")#text(" (if ")#mi("{p>d+1}")#text(") and ")#mi("{Q_0(n+1)-Q_0(n)=P(n)}")#text(" by Pascal’s identity. So if we multiply ")#mi("{K}")#text(" by ")#mi("{e_p(-Q_0)}")#text(" (using the polynomial phase invariance of structured functions) we may assume without loss of generality that ")#mi("{P=0}")#text(", thus ")#mi("{K(\\cdot+1) \\overline{K} \\equiv 1}")#text(". But then the claim follows from the integration axiom. ")#mi("\\Box")

#text("Now we can state the van der Corput estimate.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 11 (van der Corput)")]#text(" ")#metadata(none) <tao-e54a5df6ff5bc3208e2c>#text(" Let ")#mi("{{\\mathcal C}}")#text(" be a class of structured functions. Let ")#mi("{q \\in {\\mathcal S}_I}")#text(" be of polynomial size, and let ")#mi("{K_q = \\prod_{p|q} K_p}")#text(" be a structured function of modulus ")#mi("{q}")#text(" and complexity at most ")#mi("{O(1)}")#text(". Let ")#mi("{l \\geq 1}")#text(" be fixed, and let ")#mi("{{\\mathcal P}}")#text(" denote the set of sufficiently large primes ")#mi("{p}")#text(" dividing ")#mi("{q}")#text(" with the property that there exists a polynomial ")#mi("{P_p: {\\bf Z}/p{\\bf Z} \\rightarrow {\\bf Z}/p{\\bf Z}}")#text(" of degree at most ")#mi("{l}")#text(" such that ")#mi("{c_{K_p,e_p(P_p)} \\neq 0}")#text(", and let ")#mi("{q_0 := \\prod_{p|{\\mathcal P}} p}")#text(". Then for any ")#mi("{N > 0}")#text(" of polynomial size, any factorisation ")#mi("{q = q_1 \\ldots q_l}")#text(", and any coefficient sequence function ")#mi("{\\psi_N(n)}")#text(" which is smooth at scale ")#mi("{N}")#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox q_0 (1 + \\sum_{i=1}^{l-1} (N^{\\prime})^{1-1/2^i} (q^{\\prime}_i)^{1/2^i}", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ (N^{\\prime})^{1-1/2^{l-1}} (q^{\\prime}_l)^{1/2^l})+ N (q^{\\prime})^{-1/2}")]]

#text("where ")#mi("{q^{\\prime} := q / q_0}")#text(", ")#mi("{N^{\\prime} := N/q_0}")#text(", and ")#mi("{q^{\\prime}_i := (q_i,q^{\\prime})}")#text(", where the sum is implicitly assumed to range over those ")#mi("{n}")#text(" for which ")#mi("{K_q(n)}")#text(" is defined.")
]

#text("The ")#mi("{q_0}")#text(" parameter is technical, as is the ")#mi("{1}")#text(" term; heuristically one should view this estimate as asserting that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox \\sum_{i=1}^{l-1} N^{1-1/2^i} q_i^{1/2^i} + N^{1-1/2^{l-1}} q_l^{1/2^l}", block: true)]]

#text("under reasonable non-degeneracy conditions. Assuming sufficient dense divisibility and in the regime ")#mi("{N \\geq q^{1/(l+1)}}")#text(", the optimal value of the right-hand side is ")#mi("{\\epsilon N}")#text(", where ")#mi("{\\epsilon := (q/N^{l+1})^{1/(2^{l+1}-2)}}")#text(", which is attained when ")#mi("{q_i := N \\epsilon^{2^i}}")#text(" for ")#mi("{i=1,\\ldots,l-1}")#text(" and ")#mi("{q_{l} := q_{l-1}^2}")#text(".")

#emph[#text("Proof:")]#text(" We induct on ")#mi("{l}")#text(", assuming that the claim has already been proven for all smaller values of ")#mi("{l}")#text(".")

#text("We may factor ")#mi("{K_q = K_{q_0} K_{q^{\\prime}}}")#text(" where ")#mi("{K_{q_0} := \\prod_{p|q_0} K_p}")#text(" and ")#mi("{K_{q^{\\prime}} := \\prod_{p|q^{\\prime}} K_p}")#text(". Then we may write")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\psi_N(n) K_q(n) = \\sum_{a=0}^{q_0-1} K_{q_0}(a) \\sum_n \\psi_N( q_0 n + a ) K_{q^{\\prime}}(q_0n+a).")]]

#text("Observe that any given ")#mi("{a}")#text(", ")#mi("{K_{q_0}(a)}")#text(" has magnitude ")#tao-math("{\\left|K_{q_0}(a)\\right| \\lessapprox 1}", block: false)#text(" (from the divisor bound), the function ")#mi("{n \\mapsto \\psi_N(q_0n+a)}")#text(" is of the form ")#mi("{\\tilde \\psi( \\frac{n}{N^{\\prime}} )}")#text(" for some ")#mi("{\\tilde \\psi}")#text(" supported on an interval of length ")#mi("{\\lessapprox 1}")#text(" and obeying the bounds ")#tao-math("{\\left|\\nabla^j \\tilde \\psi(x)\\right| \\lessapprox 1}", block: false)#text(", and the function ")#mi("{n \\mapsto K_{q^{\\prime}}(q_0 n+a)}")#text(" is a structured function of modulus ")#mi("{q^{\\prime}}")#text(" and complexity at most ")#mi("{O(1)}")#text(" (here we use the dilation and translation invariance properties of structured functions). From this we see that to prove the proposition for a given value of ")#mi("{l}")#text(", it suffices to do so under the assumption ")#mi("{q_0=1}")#text(", in which case the objective is to prove that")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox 1  & + \\sum_{i=1}^{l-1} N^{1-1/2^i} q_i^{1/2^i} + N^{1-1/2^{l-1}} q_l^{1/2^l}", block: true)



#tao-math(" & + N q^{-1/2} 1_{N \\geq A q}.", block: true)
]

#text("The claim is trivial (from the divisor bound) with ")#mi("{N \\leq 1}")#text(", so we may assume ")#mi("{N \\geq 1}")#text(", in which case we will show that")

#tao-aligned(keep: true)[


#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox \\sum_{i=1}^{l-1} N^{1-1/2^i} q_i^{1/2^i}  & + N^{1-1/2^{l-1}} q_l^{1/2^l}", block: true)



#tao-math(" & + N q^{-1/2} 1_{N \\geq A q}.", block: true)
]

#text("By applying a similar reduction to before we may also assume that all prime factors of ")#mi("{q}")#text(" are larger than some large fixed constant ")#mi("{C}")#text(", which we will assume to be sufficiently large for the arguments below to work.")

#text("We begin with the base case ")#mi("{l=1}")#text(". In this case it will suffice to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox q^{1/2} + N q^{-1/2}.", block: true)]]

#text("By completion of sums, it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( hn) K_q(n)| \\lessapprox q^{1/2}")]]

#text("for all ")#mi("{h \\in {\\bf Z}/q{\\bf Z}}")#text(". By the Chinese remainder theorem and the divisor bound, it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/p{\\bf Z}} e_p( hn) K_p(n)| \\ll p^{1/2}")]]

#text("for all ")#mi("{p|q}")#text(" and all ")#mi("{h \\in {\\bf Z}/q{\\bf Z}}")#text(". However, by the hypothesis ")#mi("{q_0=1}")#text(", ")#mi("{e_p(h \\cdot) K_p \\not \\equiv 1}")#text(", and the claim now follows from the almost orthogonality properties of structured functions.")

#text("Now suppose that ")#mi("{l > 1}")#text(", and the claim has already been proven for smaller values of ")#mi("{l}")#text(". If ")#mi("{N \\geq q}")#text(" then the claim follows from the ")#mi("{l=1}")#text(" bound, so we may assume that ")#mi("{N < q}")#text(", in which case we will establish")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox \\sum_{i=1}^{l-1} N^{1-1/2^i} q_i^{1/2^i} + N^{1-1/2^{l-1}} q_l^{1/2^l}.", block: true)]]

#text("If we have ")#mi("{N \\geq q_l}")#text(", then")

#align(center)[#tao-fit-display[#mitex("N^{1-1/2^{l-1}} q_{l-1}^{1/2^{l-1}} + N^{1-1/2^{l-1}} q_l^{1/2^l} \\geq N^{1-1/2^{l-2}} (q_{l-1} q_l)^{1/2^{l-1}}")]]

#text("and the claim then follows by the induction hypothesis (concatenating ")#mi("{q_l}")#text(" and ")#mi("{q_{l-1}}")#text("). Similarly, if ")#mi("{N \\leq q_1}")#text(", then ")#mi("{N^{1/2} q_1^{1/2} \\geq N}")#text(", and the claim follows from the triangle inequality. Thus we may assume that")

#align(center)[#tao-fit-display[#mitex("q_1 < N < q_l.")]]

#text("Let ")#mi("{M := \\lfloor N/q_1\\rfloor}")#text(". We can rewrite ")#mi("{\\sum_n \\psi_N(n) K_q(n)}")#text(" as")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{M} \\sum_n \\sum_{m=1}^M \\psi_N(n+kq_1) K_q(n+mq_1).")]]

#text("We factor")

#align(center)[#tao-fit-display[#mitex("K_q(n+mq_1) = K_{q_1}(n) K_{q_2 \\ldots q_l}(n+mq_1)")]]

#text("and by the divisor bound ")#tao-math("{\\left|K_{q_1}(n)\\right| \\lessapprox 1}", block: false)#text(", and so by the triangle inequality and the Cauchy-Schwarz inequality")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox \\frac{1}{M} \\sum_n \\left|\\sum_{m=1}^M \\psi_N(n+mq_1) K_{q_2 \\ldots q_l}( n+mq_1 )\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\lessapprox \\frac{N^{1/2}}{M} (\\sum_n \\left|\\sum_{m=1}^M \\psi_N(n+mq_1) K_{q_2 \\ldots q_l}( n+mq_1 )\\right|^2)^{1/2}", block: true)]]

#text("since the summand is only non-zero when ")#mi("{n}")#text(" is supported on an interval of length ")#mi("{\\lessapprox N}")#text(". This last expression may be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\frac{N^{1/2}}{M} |\\sum_{1 \\leq m,m^{\\prime} \\leq M} \\sum_n \\psi_N(n+mq_1) \\overline{\\psi_N(n+m^{\\prime}q_1)}")]]

#align(center)[#tao-fit-display[#mitex("K_{q_2 \\ldots q_l}( n+mq_1 ) \\overline{K_{q_2 \\ldots q_l}}(n+m^{\\prime}q_1)|^{1/2}.")]]

#text("The diagonal contribution ")#mi("{m=m^{\\prime}}")#text(" can be estimated (using the pointwise bounds ")#tao-math("{\\left|K_{q_2\\ldots q_l}\\right| \\lessapprox 1}", block: false)#text(") by ")#mi("{\\lessapprox \\frac{N^{1/2}}{M} ( M N )^{1/2} \\lessapprox N^{1/2} q_1^{1/2}}")#text(", which is acceptable, so it suffices to show that ")#metadata(none) <tao-d0350a6064de840458ae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("|\\sum_{1 \\leq m,m^{\\prime} \\leq M: m \\neq m^{\\prime}} \\sum_n \\psi_N(n+mq_1) \\overline{\\psi_N(n+m^{\\prime}q_1)}")]]

#align(center)[#tao-fit-display[#mitex("K_{q_2 \\ldots q_l}( n+mq_1 )\\overline{K_{q_2 \\ldots q_l}}(n+m^{\\prime}q_1) |")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox M^2 ( \\sum_{i=2}^{l-1} N^{1-1/2^{i-1}} q_i^{1/2^{i-1}} + N^{1-1/2^{l-2}} q_l^{1/2^{l-1}} ).")]]

#text("We observe that ")#mi("{n \\mapsto K_{q_2 \\ldots q_l}( n+mq_1 )\\overline{K_{q_2 \\ldots q_l}}(n+m^{\\prime}q_1)}")#text(" is the sum of ")#mi("{\\lessapprox 1}")#text(" structured functions of modulus ")#mi("{q_2 \\ldots q_l}")#text(" and complexity ")#mi("{O(1)}")#text(", each of which the product of one of the components of ")#mi("{K_p( n+mq_1) \\overline{K_p}(n+m^{\\prime}q_1)}")#text(" of modulus ")#mi("{p}")#text(" and complexity ")#mi("{O(1)}")#text(" for all ")#mi("{p|q_2 \\ldots q_l}")#text(". We can of course delete any components that vanish identically. Suppose that for one of these primes ")#mi("{p}")#text(", one of the components of the function ")#mi("{K_p( n+mq_1) \\overline{K_p}(n+m^{\\prime}q_1)}")#text(" is equivalent to ")#mi("{e_p( P(n) )}")#text(" for some polynomial ")#mi("{P}")#text(" of degree at most ")#mi("{l-1}")#text(". Then by Lemma ")#link(<tao-639f78fb7729d09dc606>)[#text("10")]#text(", if ")#mi("{p}")#text(" is sufficiently large (larger than a fixed constant), either ")#mi("{p|m^{\\prime}-m}")#text(", or else ")#mi("{K_p(n)}")#text(" is equivalent ")#mi("{e_p(Q)}")#text(" for some polynomial ")#mi("{Q}")#text(" of degree at most ")#mi("{l}")#text(", but by the hypothesis ")#mi("{q_0=1}")#text(" the latter case cannot occur since ")#mi("{K_p}")#text(" is non-vanishing and ")#mi("{c_{K_p,e_p(Q)} = 0}")#text(". Thus if we set ")#mi("{\\tilde q_0}")#text(" to be the product of all the primes ")#mi("{p}")#text(" with this property, we see that ")#mi("{\\tilde q_0 \\ll (m^{\\prime}-m,q_2 \\ldots q_l)}")#text(".")

#text("Applying the induction hypothesis, we may thus bound")

#align(center)[#tao-fit-display[#mitex("|\\sum_n \\psi_N(n+mq_1) \\overline{\\psi_N(n+m^{\\prime}q_1)} K_{q_2 \\ldots q_l}( n+ mq_1) \\overline{K_{q_2 \\ldots q_l}}( n+ m^{\\prime}q_1)")]]

#text("by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox (q_2 \\ldots q_l, m-m^{\\prime}) [ \\sum_{i=2}^{l-1} N^{1-1/2^{i-1}} q_i^{1/2^{i-1}} + N^{1-1/2^{l-2}} q_l^{1/2^{l-1}} ]")]]

#align(center)[#tao-fit-display[#mitex("+ N (q_2 \\ldots q_l)^{-1/2} (q_2 \\ldots q_l, m-m^{\\prime})^{1/2}.")]]

#text("The contribution of the first two terms to ")#link(<tao-d0350a6064de840458ae>)[#text("(9)")]#text(" is acceptable thanks to Lemma 5 of ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(", so the only contribution remaining to control is")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq m,m^{\\prime} \\leq M: m \\neq m^{\\prime}} N (q_2 \\ldots q_l)^{-1/2} (q_2 \\ldots q_l, m-m^{\\prime})^{1/2}.")]]

#text("We may bound")

#align(center)[#tao-fit-display[#mitex("N (q_2 \\ldots q_l)^{-1/2} (q_2 \\ldots q_l, m-m^{\\prime})^{1/2} \\ll N^{1/2} + N^{3/2} (q_2 \\ldots q_l)^{-1} (q_2 \\ldots q_l, m-m^{\\prime}).")]]

#text("The first term is dominated by the ")#mi("{N^{1/2} q_1^{1/2}}")#text(" term appearing as the ")#mi("{i=1}")#text(" summand in ")#link(<tao-d0350a6064de840458ae>)[#text("(9)")]#text(", while the contribution of the second term may be bounded using another application of Lemma 5 of ")#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("this previous post")]#text(" and the bound ")#mi("{N < q_l}")#text(" by")

#align(center)[#tao-fit-display[#mitex("\\lessapprox K^2 N^{1-1/2^{l-2}} q_l^{1/2^{l-1}}")]]

#text("which is acceptable. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above arguments relied on a ")#mi("{q}")#text("-version of the van der Corput ")#mi("{A}")#text("-process, and in the case of Dirichlet characters is essentially due ")#link("http://www.ams.org/mathscinet-getitem?mr=1084186")[#text("to Graham and Ringrose")]#text(" (see also ")#link("http://www.ams.org/mathscinet-getitem?mr=485727")[#text("Heath-Brown")]#text("). If we work with a class of structured functions that is closed under Fourier transforms (such as the trace weights), then the ")#mi("{q}")#text("-version of the van der Corput ")#mi("{B}")#text("-process also becomes available (in principle, at least), thus potentially giving a slightly larger range of “exponent pairs”; however this looks complicated to implement (the role of polynomial phases now needs to be replaced by a more complicated class that involves things like the Fourier transforms of polynomial phases, as well as their “antiderivatives”) and will likely only produce rather small improvements in the final numerology.")
]

#text("We isolate a special case of the above result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 12")]#text(" ")#metadata(none) <tao-76c879a1f816ec064be5>#text(" Let the notation and assumptions be as in Proposition ")#link(<tao-e54a5df6ff5bc3208e2c>)[#text("11")]#text(" with ")#mi("{l=2}")#text(", ")#mi("{N \\geq 1}")#text(", and ")#mi("{q}")#text(" ")#mi("{y}")#text("-densely divisible. Then for any ")#mi("{N > 0}")#text(", one has the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox q_0 + q_0^{1/2} q^{1/2} + N q_0^{1/2} q^{-1/2}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox q_0 + q_0^{1/2} N^{1/2} q^{1/6} y^{1/6} + N q_0^{1/2} q^{-1/2}.", block: true)]]
]

#text("The dependence on ")#mi("{q_0}")#text(" in the first bound can be improved, but we will not need this improvement here.")

#emph[#text("Proof:")]#text(" From the ")#mi("{l=1}")#text(" case of the above proposition we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox q_0 (1 + (q/q_0)^{1/2}) + N (q/q_0)^{-1/2}", block: true)]]

#text("giving the first claim of the proposition.")

#text("Similarly, from the ")#mi("{l=2}")#text(" case of the above proposition we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\psi_N(n) K_q(n)\\right| \\lessapprox q_0 (1 + (N^{\\prime})^{1/2} (q_1)^{1/2} + (N^{\\prime})^{1/2} (q_2)^{1/4} )", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ N q_0^{1/2} q^{-1/2}")]]

#text("for any factorisation ")#mi("{q=q_1q_2}")#text(" of ")#mi("{q}")#text(". As ")#mi("{q}")#text(" is ")#mi("{y}")#text("-densely divisible, we may select ")#mi("{q_1}")#text(" so that")

#align(center)[#tao-fit-display[#mitex("y^{-2/3} q^{1/3} \\leq q_1 \\leq y^{1/3} q^{1/3}")]]

#text("so that")

#align(center)[#tao-fit-display[#mitex("y^{-1/3} q^{2/3} \\leq q_2 \\leq y^{2/3} q^{2/3}")]]

#text("and the second claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. A two-dimensional exponential sum — ")]]

#text("We now apply the above theory to obtain a new bound on a certain two-dimensional exponential sum that will show up in the Type I estimate.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13")]#text(" ")#metadata(none) <tao-3239f1a94e2725c66282>#text(" Let ")#mi("{u}")#text(" be a ")#mi("{y}")#text("-densely divisible squarefree integer of polynomial size for some ")#mi("{y \\geq 1}")#text(", let ")#mi("{D, N > 0}")#text(" be of polynomial size, and let ")#mi("{c,l,v,a,b \\in {\\bf Z}/u{\\bf Z}}")#text(". Let ")#mi("{\\psi_D, \\psi_N}")#text(" be smooth sequences at scale ")#mi("{D, N}")#text(" respectively. Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox (cl,u) (u^{1/2} + \\frac{N}{u^{1/2}}) ( 1 + D^{1/2} u^{1/6} y^{1/6} + \\frac{D}{u^{1/2}}).")]]

#text("Here the summations are implicitly restricted to those ")#mi("{d,n}")#text(" for which the denominator in the phase is non-zero. We also have the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox (cl,u) ( u^{1/2} + \\frac{N}{u^{1/2}}) ( u^{1/2} + \\frac{D}{u^{1/2}}).")]]
]

#text("The main term here is ")#mi("{(cl,u) u^{1/2} \\times (D^{1/2} u^{2/3} y^{1/6})}")#text(", which in certain regimes improves upon the bound of ")#mi("{((cl,u)^{-1/2} u^{1/2}) \\times D}")#text(" that one obtains by completing the sums in the ")#mi("{n}")#text(" variable but not exploiting any additional cancellation in the ")#mi("{d}")#text(" variable.")

#emph[#text("Proof:")]#text(" We first claim that it suffices to verify the proposition when ")#mi("{(cl,u)=1}")#text(". Indeed, if we set")

#tao-aligned(keep: true)[


#tao-math("u^{\\prime}  & := u / (cl,u)", block: true)



#tao-math("y^{\\prime}  & := y (cl,u)", block: true)



#tao-math("c^{\\prime}  & := c/(cl,u) = \\frac{c/(c,u)}{(cl,u)/(c,u)}", block: true)
]

#text("(where one computes the reciprocal of ")#mi("{(cl,u)/(c,u)}")#text(" inside ")#mi("{{\\bf Z}/(u/(cl,u)){\\bf Z}}")#text("), we see that ")#mi("{u^{\\prime}}")#text(" is ")#mi("{y^{\\prime}}")#text("-densely divisible (thanks to Lemma ")#link(<tao-b1b927541c77e69aea9d>)[#text("7")]#text("), squarefree, and polynomial size, that ")#mi("{(c^{\\prime}l,u^{\\prime})=1}")#text(", and that")

#align(center)[#tao-fit-display[#mitex("\\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} )")]]

#align(center)[#tao-fit-display[#mitex("= \\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_{u^{\\prime}}( \\frac{c^{\\prime}l}{(n+vd+a)(n+vd+ld+b)} )")]]

#align(center)[#tao-fit-display[#mitex("\\prod_{p|(cl,u)} 1_{p \\not | (n+vd+a)(n+vd+ld+b)}.")]]

#text("By the inclusion-exclusion formula and divisor bound, it thus suffices to show that for all ")#mi("{f | (cl,u)}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("|\\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_{u^{\\prime}}( \\frac{c^{\\prime}l}{(n+vd+a)(n+vd+ld+b)} )")]]

#align(center)[#tao-fit-display[#mitex("1_{f|(n+vd+a)(n+vd+ld+b)}| \\lessapprox X")]]

#text("where ")#mi("{X}")#text(" is either of the two right-hand sides in the proposition, i.e. either")

#align(center)[#tao-fit-display[#mitex("X = (cl,u) (u^{1/2} + \\frac{N}{u^{1/2}})")]]

#text("or")

#align(center)[#tao-fit-display[#mitex("X = (cl,u) ( u^{1/2} + \\frac{N}{u^{1/2}}) ( u^{1/2} + \\frac{D}{u^{1/2}}).")]]

#text("By the divisor bound, we see that there are ")#mi("{\\lessapprox f}")#text(" pairs ")#mi("{(n_0,d_0) \\in ({\\bf Z}/f{\\bf Z})^2}")#text(" such that ")#mi("{(n_0+vd_0+a)(n_0+vd_0+ld_0+b) = 0\\ (f)}")#text(". Thus it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{d=d_0\\ (f)} \\sum_{n=n_0\\ (f)} \\psi_D(d) \\psi_N(n) e_{u^{\\prime}}( \\frac{c^{\\prime}l}{(n+vd+a)(n+vd+ld+b)} )\\right| \\lessapprox X/f.", block: true)]]

#text("Making the change of variables ")#mi("{d = fd^{\\prime} +d_0}")#text(", ")#mi("{n = fn^{\\prime}+n_0}")#text(" and using the ")#mi("{(cl,u)=1}")#text(" case of the proposition, we can bound the left-hand side by")

#align(center)[#tao-fit-display[#mitex("((u^{\\prime})^{1/2} + \\frac{N/f}{(u^{\\prime})^{1/2}}) ( 1 + (D/f)^{1/2} (u^{\\prime})^{1/6} (y^{\\prime})^{1/6} + \\frac{D/f}{(u^{\\prime})^{1/2}})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("((u^{\\prime})^{1/2} + \\frac{N/f}{(u^{\\prime})^{1/2}}) ( (u^{\\prime})^{1/2} + \\frac{D/f}{(u^{\\prime})^{1/2}})")]]

#text("and one verifies that these two quantities bound the two possible values of ")#mi("{X/f}")#text(" respectively.")

#text("Henceforth ")#mi("{(cl,u)=1}")#text(". Note that the above reduction also allows us to assume that ")#mi("{u}")#text(" has no prime factors less than a sufficiently large fixed constant ")#mi("{C}")#text(" to be chosen later. Our task is now to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox (\\frac{N}{u}+1) (u^{1/2} + D^{1/2} u^{2/3} y^{1/6} + D)")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox (\\frac{N}{u}+1) (u + D).")]]

#text("From completion of sums we have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\sum_n \\psi_D(d) \\psi_N(n) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox (\\frac{N}{u}+1) \\sup_{m \\in{\\bf Z}/u{\\bf Z}} |\\sum_d \\sum_{n \\in {\\bf Z}/u{\\bf Z}} \\psi_D(d)")]]

#align(center)[#tao-fit-display[#mitex("e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} + mn)|")]]

#text("so it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\sum_{n \\in {\\bf Z}/u{\\bf Z}} \\psi_D(d) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} + mn)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox u^{1/2} + D^{1/2} u^{2/3} y^{1/6} + D")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\sum_{n \\in {\\bf Z}/u{\\bf Z}} \\psi_D(d) e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} + mn)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox u + D")]]

#text("for any given ")#mi("{m \\in {\\bf Z}/u{\\bf Z}}")#text(". We rewrite this as ")#metadata(none) <tao-a60ec1cf58f49cd2fab6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left|\\sum_d \\psi_D(d) K_u(d)\\right| \\lessapprox \\min( 1 + D^{1/2} u^{1/6} y^{1/6}, u^{1/2}) + D u^{-1/2}", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("K_u(d) := \\frac{1}{\\sqrt{u}} \\sum_{n \\in {\\bf Z}/u{\\bf Z}} e_u( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} + mn).")]]

#text("By the Chinese remainder theorem, this function factors as ")#mi("{K_u(d) = \\prod_{p|u} K_p(d)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("K_p(d) := \\frac{1}{\\sqrt{p}} \\sum_{n \\in {\\bf Z}/p{\\bf Z}} e_p( \\frac{1}{u_p} ( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} + mn ) )")]]

#text("and ")#mi("{u_p := u/p}")#text(". Note that for any prime ")#mi("{p}")#text(" dividing ")#mi("{u}")#text(" (and thus larger than ")#mi("{C}")#text("), the rational function ")#mi("{n \\mapsto \\frac{1}{u_p} ( \\frac{cl}{n(n+ld+b-a)} + mn )}")#text(" is not divisible by ")#mi("{p}")#text(". From the Weil conjectures for curves this implies that ")#mi("{K_p(d) = O(1)}")#text(". In fact, from Deligne’s theorem (and in particular the fact that cohomology groups of sheaves are again sheaves), we have the stronger assertion that ")#mi("{K_p}")#text(" is a sum of boundedly many trace weights at modulus ")#mi("{p}")#text(" with complexity ")#mi("{O(1)}")#text(" in the sense of Example ")#link(<tao-fe6ecff9a0b92a67f615>)[#text("4")]#text(". (In the Grothendieck-Lefschetz trace formula, only the first cohomology ")#mi("{H^1_c}")#text(" is non-trivial; the second cohomology ")#mi("{H^2_c}")#text(" disappears because the rational function is not divisible by ")#mi("{p}")#text(", and the zeroth cohomology ")#mi("{H^0_c}")#text(" disappears because the underlying curve is affine, although in any event the contribution of the zeroth cohomology could be absorbed into the ")#mi("{Du^{-1/2}}")#text(" term in ")#link(<tao-a60ec1cf58f49cd2fab6>)[#text("(10)")]#text(".) By the divisor bound, this implies that ")#mi("{K_u}")#text(" is the sum of ")#mi("{\\lessapprox 1}")#text(" trace weights at modulus ")#mi("{u}")#text(" with complexity ")#mi("{O(1)}")#text(". We can of course delete any components that vanish identically.")

#text("We claim that for any ")#mi("{p}")#text(" dividing ")#mi("{u}")#text(" (and hence larger than ")#mi("{C}")#text("), none of the components of ")#mi("{K_p(d)}")#text(" are equivalent to a quadratic phase ")#mi("{e_p( ed^2+fd )}")#text(". Assuming this claim for the moment, the required bound ")#link(<tao-a60ec1cf58f49cd2fab6>)[#text("(10)")]#text(" then follows from Corollary ")#link(<tao-76c879a1f816ec064be5>)[#text("12")]#text(". It thus suffices to verify the claim. If the claim failed, then we would have ")#metadata(none) <tao-9834876dcfb05cb167a5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\sum_{d \\in {\\bf Z}/p{\\bf Z}} K_p(d) e_p( - ed^2 - fd ) = \\alpha p + O(\\sqrt{p})")]]

#text("for some algebraic integer ")#mi("{\\alpha}")#text(", which is non-zero since ")#mi("{K_p(d)}")#text(" is equivalent to ")#mi("{e_p(ed^2+f d)}")#text(" and is non-zero. Since all non-zero algebraic integers have at least one Galois conjugate of modulus at least ")#mi("{1}")#text(", it will suffice (for ")#mi("{p}")#text(" large enough) to establish that all Galois conjugates of the left-hand side of ")#link(<tao-9834876dcfb05cb167a5>)[#text("(27)")]#text(" are ")#mi("{O(\\sqrt{p})}")#text(". In other words, it suffices to establish the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{d,n \\in {\\bf Z}/p{\\bf Z}} e_p( g ( \\frac{1}{u_p} ( \\frac{cl}{(n+vd+a)(n+vd+ld+b)} + mn ) - ed^2 - fd ) )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll p")]]

#text("for all ")#mi("{g \\in ({\\bf Z}/p{\\bf Z})^\\times}")#text(". Setting ")#mi("{x := n+vd+a}")#text(" and ")#mi("{y := ld+b}")#text(" and concatenating parameters, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x,y \\in {\\bf Z}/p{\\bf Z}} e_p( \\frac{c}{x (x+y)} - ax - by - dy^2 )\\right| \\ll p", block: true)]]

#text("whenever ")#mi("{c \\in ({\\bf Z}/p{\\bf Z})^\\times}")#text(" and ")#mi("{a,b,d \\in {\\bf Z}/p{\\bf Z}}")#text(".")

#text("We now use a ")#link("http://www.ams.org/mathscinet-getitem?mr=697259")[#text("result of Hooley")]#text(", which asserts that for any rational function ")#mi("{f(x,y)}")#text(" of two variables and bounded degree, one has")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{x,y \\in {\\bf Z}/p{\\bf Z}} e_p( f(x,y) )\\right| \\ll p", block: true)]]

#text("provided that")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): f(x,y)-T = 0\\}")]]

#text("is a geometrically generically irreducible curve (i.e. irreducible over an algebraic closure ")#mi("{k := \\overline{{\\Bbb F}_p(T)}}")#text(" of ")#mi("{k_0 := {\\Bbb F}_p(T)}")#text(") and also that")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y): f(x,y)-t = 0 \\}")]]

#text("is a (possibly reducible or empty) curve for any ")#mi("{t \\in \\overline{F}_p}")#text(". We apply this result to the rational function")

#align(center)[#tao-fit-display[#mitex("f(x,y) := \\frac{c}{x (x+y)} - ax - by - dy^2.")]]

#text("For any ")#mi("{t}")#text(", it is clear that ")#mi("{f(x,y)-t}")#text(" is not identically zero, so the second condition of Hooley is satisfied. It remains to verify the first. (Thanks to Brian Conrad for fixing some errors in the argument that follows.) Suppose that the claim failed, thus ")#mi("{f(x,y)-T}")#text(" is reducible for generic ")#mi("{T}")#text(", or equivalently that the polynomial")

#align(center)[#tao-fit-display[#mitex("P(x,y) := c - (ax + by + dy^2 - T) (x(x+y))")]]

#text("is reducible in ")#mi("{k[x,y]}")#text(". Being linear in ")#mi("{T}")#text(", this polynomial ")#mi("{P}")#text(" is clearly irreducible in ")#mi("{{\\Bbb F}_p[x,y,T] = {\\Bbb F}_p[T][x,y]}")#text("; since ")#mi("{P}")#text(" does not lie in ")#mi("{{\\Bbb F}_p[T]}")#text(", it remains irreducible in the larger ring ")#mi("{k_0[x,y]}")#text(" by ")#link("http://en.wikipedia.org/wiki/Gauss's_lemma_(polynomial)")[#text("Gauss’s lemma")]#text(".")

#text("We now perform a technical reduction to deal with the problem that the field ")#mi("{k_0}")#text(" is not ")#link("http://en.wikipedia.org/wiki/Perfect_field")[#text("perfect")]#text(". Since ")#mi("{P}")#text(" involves the nonzero term ")#mi("{Txy}")#text(" as its only ")#mi("{xy}")#text("-term, over ")#mi("{k}")#text(" it cannot be a constant multiple of a ")#mi("{p}")#text("-power. Hence, if it is irreducible over the ")#link("http://en.wikipedia.org/wiki/Separable_closure")[#text("separable closure")]#text(" ")#mi("{k_{0,s}}")#text(" of ")#mi("{k_0}")#text(" then it remains irreducible over the ")#link("http://en.wikipedia.org/wiki/Perfect_field#Perfect_closure_and_perfection")[#text("perfect closure")]#text(" ")#mi("{k}")#text(" of ")#mi("{k_{0,s}}")#text(", so it suffices to check irreducibility over the separable closure.")

#text("Assuming ")#mi("{P}")#text(" is reducible over the separable closure, then up to constant multipliers (i.e. multiples in ")#mi("{k_{0,s}}")#text(") its irreducible factors in ")#mi("{k_{0,s}[x,y]}")#text(" must be Galois conjugate to each other with respect to ")#mi("{{\\rm{Gal}}(k_{0,s}/k_0)}")#text(". Thus, none of these factors can lie in ")#mi("{k_{0,s}[x]}")#text(" or ")#mi("{k_{0,s}[y]}")#text(", as otherwise all the factors would and hence so would their product ")#mi("{P}")#text(" (a contradiction since ")#mi("{c \\ne 0}")#text("). Thus, the irreducible factorization over ")#mi("{k_{0,s}[x,y]}")#text(" remains an irreducible factorization in ")#mi("{k_{0,s}(x)[y]}")#text(" and over ")#mi("{k_{0,s}(y)[x]}")#text(". Since ")#mi("{P}")#text(" has nonzero constant term and degree at most ")#mi("{3}")#text(" in either ")#mi("{x}")#text(" or ")#mi("{y}")#text(", this implies that the irreducible factors of ")#mi("{P}")#text(" in ")#mi("{k[x,y]}")#text(" are linear in both ")#mi("{x}")#text(" and ")#mi("{y}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("P(x,y) = \\prod_{i=1}^3 (\\alpha_i x + \\beta_i y + \\gamma_i)")]]

#text("for some ")#mi("{\\alpha_i, \\beta_i \\in k}")#text(" and ")#mi("{\\gamma_i \\in k^{\\times}}")#text(". But ")#mi("{P(0,y)}")#text(" is visibly constant, so all ")#mi("{\\beta_i}")#text(" vanish and hence ")#mi("{P \\in k[x]}")#text(", an absurdity. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 4. Type I estimate — ")]]

#text("We begin the proof of Theorem ")#link(<tao-840c81157f3688e42875>)[#text("4")]#text(", closely following the arguments from Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(" or Section 2 of ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("this previous post")]#text(". One difference however will be that we will not discard the ")#mi("{r}")#text(" averaging as we will need it near the end of the argument. Let ")#mi("{I, a, N, M, \\alpha}")#text(" be as in the theorem. We can restrict ")#mi("{q}")#text(" to the range")

#align(center)[#tao-fit-display[#mitex("q \\gtrapprox x^{1/2}")]]

#text("for some sufficiently slowly decaying ")#mi("{o(1)}")#text(", since otherwise we may use the Bombieri-Vinogradov theorem (Theorem 4 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("). Thus, by dyadic decomposition, we need to show that ")#metadata(none) <tao-4b3d4a0dd732f791ca89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{d \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta}^4: D \\leq d < 2D} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (d))\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("for any fixed ")#mi("{A}")#text(" and for any ")#mi("{D}")#text(" in the range")

#align(center)[#tao-fit-display[#mitex("x^{1/2} \\lessapprox D \\lessapprox x^{1/2+2\\varpi}.")]]

#text("Let ")#metadata(none) <tao-352b5b6699d83cdc4efd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\epsilon > 0")]]

#text("be a sufficiently small fixed exponent.")

#text("By Lemma 11 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", we know that for all ")#mi("{d}")#text(" in ")#mi("{[D,2D]}")#text(" outside of a small number of exceptions, we have ")#metadata(none) <tao-3afbd5577a879d3382d9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("\\prod_{p|d: p \\leq D_0} p \\lessapprox 1")]]

#text("where ")#metadata(none) <tao-0ad52e338662c923b15f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("D_0 := \\exp(\\log^{1/3} x).")]]

#text("Specifically, the number of exceptions in the interval ")#mi("{[D,2D]}")#text(" is ")#mi("{O(D \\log^{-A} x)}")#text(" for any fixed ")#mi("{A>0}")#text(". The contribution of the exceptional ")#mi("{d}")#text(" can be shown to be acceptable by Cauchy-Schwarz and trivial estimates (see Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("), so we restrict attention to those ")#mi("{d}")#text(" for which ")#link(<tao-3afbd5577a879d3382d9>)[#text("(14)")]#text(" holds. In particular, as ")#mi("{d}")#text(" is restricted to be quadruply ")#mi("{x^\\delta}")#text("-densely divisible, we may factor")

#align(center)[#tao-fit-display[#mitex("d=qr")]]

#text("with ")#mi("{q,r}")#text(" coprime and square-free, with ")#mi("{q \\in {\\mathcal S}_{I^{\\prime}}}")#text(" ")#mi("{x^{\\delta+o(1)}}")#text("-densely divisible with ")#mi("{I^{\\prime} := [D_0,\\infty) \\cap I}")#text(", ")#mi("{r \\in {\\mathcal S}_I}")#text(" doubly ")#mi("{x^{\\delta+o(1)}}")#text("-densely divisible,and")

#align(center)[#tao-fit-display[#mitex("x^{-\\epsilon-\\delta} N \\lessapprox r \\lessapprox x^{-\\epsilon} N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{1/2} \\lessapprox qr \\lessapprox x^{1/2+2\\varpi}.")]]

#text("Here we use the easily verified fact that ")#mi("{N \\gtrapprox x^\\epsilon}")#text(", and we have also used Lemma ")#link(<tao-b1b927541c77e69aea9d>)[#text("7")]#text(" to ensure that dense divisibility is essentially preserved when transferring a factor of ")#mi("{x^{o(1)}}")#text(" from ")#mi("{r}")#text(" (namely, the portion of ")#mi("{r}")#text(" coming from primes up to ")#mi("{D_0}")#text(") to ")#mi("{q}")#text(".")

#text("By dyadic decomposition, it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_{I^{\\prime}} \\cap {\\mathcal D}_{x^\\delta+o(1)}: q \\sim Q} \\sum_{r \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^\\delta+o(1)}^{(2)}: r \\sim R} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (qr))\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{Q, R \\geq 1}")#text(" obey the size conditions ")#metadata(none) <tao-375676bd26868505668f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#mitex("x^{-\\epsilon-\\delta} N \\lessapprox R \\lessapprox x^{-\\epsilon} N")]]

#text("and ")#metadata(none) <tao-2617708489831f17c7b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("x^{1/2} \\lessapprox QR \\lessapprox x^{1/2 + 2\\varpi}.")]]

#text("Fix ")#mi("{Q,R}")#text(". We abbreviate ")#mi("{\\sum_{q \\in {\\mathcal S}_{I^{\\prime}} \\cap {\\mathcal D}_{x^\\delta+o(1)}: q \\sim Q}}")#text(" and ")#mi("{\\sum_{r \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^{\\delta+o(1)}}^2: r \\sim R}}")#text(" by ")#mi("{\\sum_q}")#text(" and ")#mi("{\\sum_r}")#text(" respectively, thus our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_q \\sum_{r: (q,r)=1} \\left|\\Delta(\\alpha \\ast \\beta; a\\ (qr))\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("We now split the discrepancy")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\alpha \\ast \\beta; a\\ (qr)) = \\sum_{n = a\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)")]]

#text("as the sum of the subdiscrepancies")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: n = a\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n).")]]

#text("In Section 5 of ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text(", it was established (using the Bombieri-Vinogradov theorem) that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q} \\sum_{r; (q,r)=1} \\left|\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("NM \\log^{-A} x")]]

#text("so it suffices to show that ")#metadata(none) <tao-c75de8c1b7c3ae525209>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\sum_{q} \\sum_{r; (q,r)=1} \\left|\\sum_{n: n = a\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM \\log^{-A} x.")]]

#text("It will suffice to prove the slightly stronger statement")

#metadata(none) <tao-53da29cd5a3142dbfa1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#tao-math("\\sum_r \\sum_{q: (q,r)=1} \\left|\\sum_{n: n = a\\ (r); n= b\\ (q)} \\alpha \\ast \\beta(n) - \\sum_{n: (n,q)=1; n = a\\ (r); n = b^{\\prime}\\ (q)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM \\log^{-A} x")]]

#text("for all ")#mi("{a,b,b^{\\prime}}")#text(" coprime to ")#mi("{P_I}")#text(", since if one then specialises to the case when ")#mi("{b=a}")#text(" and averages over all primitive ")#mi("{b^{\\prime}\\ (P_I)}")#text(" we obtain ")#link(<tao-c75de8c1b7c3ae525209>)[#text("(18)")]#text(" from the triangle inequality.")

#text("We use the dispersion method. We write the left-hand side of ")#link(<tao-53da29cd5a3142dbfa1f>)[#text("(19)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\sum_r \\sum_{q: (q,r)=1} c_{q,r} (\\sum_{n: n = a\\ (r); n= b\\ (q)} \\alpha \\ast \\beta(n) - \\sum_{n: n = a\\ (r); n = b^{\\prime}\\ (q)} \\alpha \\ast \\beta(n))")]]

#text("for some bounded sequence ")#mi("{c_{q,r}}")#text(". This expression may be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_r \\sum_m \\alpha(m) (\\sum_{q,n: mn = a\\ (r); (q,r)=1} c_{q,r} \\beta(n) (1_{mn = b\\ (q)} - 1_{mn = b^{\\prime}\\ (q)})),")]]

#text("so from the Cauchy-Schwarz inequality and crude estimates it suffices to show that ")#metadata(none) <tao-8dd42f9fc74cd334c8dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#tao-math("\\sum_r \\sum_{m} \\psi_M(m) \\left|\\sum_{q,n: mn = a\\ (r); (q,r)=1} c_{q,r} \\beta(n) (1_{mn = b\\ (q)} - 1_{mn = b^{\\prime}\\ (q)})\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll N^2 M R^{-1} \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(", where ")#mi("{\\psi_M}")#text(" is a smooth coefficient sequence at scale ")#mi("{M}")#text(". Expanding out the square, it suffices to show that ")#metadata(none) <tao-70848ccfe56d24288a89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#mitex("\\sum_r \\sum_{m} \\psi_M(m) \\sum_{q_1,q_2,n_1,n_2: mn_1=mn_2 = a\\ (r); (q_1q_2,r)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1,r} \\overline{c_{q_2,r}} \\beta(n_1) \\overline{\\beta(n_2)} 1_{mn_1 = b\\ (q_1)} 1_{mn_2 = b^{\\prime}\\ (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-1} \\log^{-A} x )")]]

#text("where ")#mi("{q_1,q_2}")#text(" is subject to the same constraints as ")#mi("{q}")#text(" (thus ")#mi("{q_i \\in {\\mathcal S}_{I^{\\prime}} \\cap {\\mathcal D}_{x^\\delta}}")#text(" and ")#mi("{q_i \\sim Q}")#text(" for ")#mi("{i=1,2}")#text("), and ")#mi("{X}")#text(" is some quantity that is independent of ")#mi("{b,b^{\\prime}}")#text(".")

#text("Observe that ")#mi("{n_1}")#text(" must be coprime to ")#mi("{q_1r}")#text(" and ")#mi("{n_2}")#text(" coprime to ")#mi("{q_2r}")#text(", with ")#mi("{n_1 = n_2\\ (r)}")#text(", to have a non-zero contribution to ")#link(<tao-70848ccfe56d24288a89>)[#text("(21)")]#text(". We then rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_r \\sum_{q_1,q_2: (q_1q_2,r)=1} \\sum_{m} \\psi_M(m) \\sum_{n_1,n_2: n_1=n_2\\ (r); (n_1,q_1r)=(n_2,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1,r} \\overline{c_{q_2,r}} \\overline{\\beta(n_1)} \\overline{\\beta(n_2)} 1_{m = a/n_1\\ (r); m = b/n_1\\ (q_1); m = b^{\\prime}/n_2 (q_2)};")]]

#text("note that these inverses in the various rings ")#mi("{{\\bf Z}/r{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_1{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_2{\\bf Z}}")#text(" are well-defined thanks to the coprimality hypotheses.")

#text("We may write ")#mi("{n_2 = n_1+kr}")#text(" for some ")#mi("{k = O(N/R)}")#text(". By the triangle inequality, and relabeling ")#mi("{n_1}")#text(" as ")#mi("{n}")#text(", it thus suffices to show that ")#metadata(none) <tao-a871c47a7f48a12b38a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\sum_r \\sum_{k = O(N/R)} \\sum_{q_1,q_2: (q_1q_2,r)=1} |\\sum_{n; (n,q_1r)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} \\overline{c_{q_2}} \\beta(n) \\overline{\\beta(n+kr)} \\sum_{m} \\psi_M(m) 1_{m = a/n\\ (r); m = b/n\\ (q_1); m = b^{\\prime}/(n+kr) (q_2)}|")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-1} \\log^{-A} x )")]]

#text("for some ")#mi("{X}")#text(" independent of ")#mi("{b}")#text(", ")#mi("{b^{\\prime}}")#text(".")

#text("At this stage in previous posts we isolated the coprime case ")#mi("{(q_1,q_2)=1}")#text(" as the dominant case, using a controlled multiplicity hypothesis to deal with the non-coprime case. Here, we will carry the non-coprime case with us for a little longer so as not to rely on a controlled multiplicity hypothesis; this introduces some additional factors of ")#mi("{q_0 := (q_1,q_2)}")#text(" into the analysis but they should be ignored on a first reading.")

#text("Applying completion of sums (Section 2 from ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("this previous post")]#text("), we can express the left-hand side of ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(22)")]#text(" as a main term ")#metadata(none) <tao-fc6def58fecc3ee66f39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("\\sum_r \\sum_{k = O(N/R)} \\sum_{q_1,q_2: (q_1q_2,r)=1} |\\sum_{n; (n,q_1r)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1,} \\overline{c_{q_2,r}} \\beta(n) \\overline{\\beta(n+kr)} (\\sum_{m} \\psi_M(m)) \\frac{1}{r[q_1,q_2]} 1_{b/n = b^{\\prime}/(n+kr)\\ ((q_1,q_2))}")]]

#text("plus an error term ")#metadata(none) <tao-a7a8572a4aabf25aac4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#tao-math("O( \\frac{1}{H} \\sum_r \\sum_{k=O(N/R)} \\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2} \\left|\\sum_{n} \\beta(n) \\beta(n+kr) \\Phi_{k,r}(h,q_1,q_2; n)\\right| )", block: true)]]

#align(center)[#tao-fit-display[#mitex("+ O( x^{-A} ),")]]

#text("where ")#metadata(none) <tao-a81ffb258bff4eddc451>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#mitex("H := x^\\epsilon Q^2 R/M")]]

#text("and ")#mi("{\\Phi_{k,r}}")#text(" is the phase ")#metadata(none) <tao-e46fd696bb4d24c149d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#mitex("\\Phi_{k,r}(h,q_1,q_2;n) := 1_{(n,r)=(n,q_1)=(n+kr,q_2)=1} 1_{q_1,q_2 \\in {\\mathcal S}_I \\cap {\\mathcal D}_{x^{\\delta+o(1)}}; (q_1q_2,r)=1}")]]

#align(center)[#tao-fit-display[#mitex("1_{b/n=b^{\\prime}/(n+kr)\\ ((q_1,q_2))}")]]

#align(center)[#tao-fit-display[#mitex("e_r( \\frac{ah}{nq_1 q^{\\prime}_2} ) e_{q_1}( \\frac{bh}{n r q^{\\prime}_2} ) e_{q^{\\prime}_2}( \\frac{b^{\\prime} h}{(n+kr) r q_1} ),")]]

#text("where ")#mi("{q^{\\prime}_2 := q_2/(q_1,q_2)}")#text(".")

#text("Let us first deal with the main term ")#link(<tao-fc6def58fecc3ee66f39>)[#text("(23)")]#text(". The contribution of the coprime case ")#mi("{(q_1,q_2)=1}")#text(" does not depend on ")#mi("{b,b^{\\prime}}")#text(" and can thus be absorbed into the ")#mi("{X}")#text(" term. Now we consider the contribution of the non-coprime case when ")#mi("{q_0 = (q_1,q_2) > 1}")#text(". We may estimate the contribution of this case by")

#align(center)[#tao-fit-display[#mitex("O( \\sum_r \\sum_{k = O(N/R)} \\sum_{q_0 \\in {\\mathcal S}_{I^{\\prime}}: 1 < q_0 \\ll Q, (q_0,r)=1} \\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0} |\\sum_{n: b/n = b^{\\prime}/(n+kr)\\ (q_0)}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta(n)\\right| |\\beta(n+kr)| M \\frac{1}{rq_0 q^{\\prime}_1 q^{\\prime}_2} ).", block: true)]]

#text("We may estimate ")#tao-math("{\\left|\\beta(n)\\right| \\left|\\beta(n+kr)\\right|}", block: false)#text(" by ")#tao-math("{\\left|\\beta(n)\\right|^2 + \\left|\\beta(n+kr)\\right|^2}", block: false)#text(". We just estimate the contribution of ")#tao-math("{\\left|\\beta(n)\\right|^2}", block: false)#text(", as the other case is treated similarly (after shifting ")#mi("{n}")#text(" by ")#mi("{kr}")#text("). We rearrange this contribution as")

#align(center)[#tao-fit-display[#mitex("O( \\sum_r \\sum_{q_0 \\in {\\mathcal S}_{I^{\\prime}}: 1 < q_0 \\ll Q, (q_0,r)=1} \\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0} |\\sum_{n}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta(n)\\right|^2 M \\frac{1}{Rq_0 q^{\\prime}_1 q^{\\prime}_2} \\sum_{k = O(N/R)} 1_{b/n = b^{\\prime}/(n+kr)\\ (q_0)} ).", block: true)]]

#text("The ")#mi("{k}")#text(" summation is ")#mi("{O( 1 + \\frac{N}{Rq_0} )}")#text(". Evaluating the ")#mi("{n, r, q^{\\prime}_1,q^{\\prime}_2}")#text(" summations, we obtain a bound of")

#align(center)[#tao-fit-display[#mitex("O( MN \\log^{O(1)} x \\sum_{q_0 \\in {\\mathcal S}_{I^{\\prime}}: 1 < q_0 \\ll Q} \\frac{1}{q_0} ( 1 + \\frac{N}{Rq_0} ) ).")]]

#text("Since ")#mi("{q_0 > 1}")#text(" and ")#mi("{q_0 \\in {\\mathcal S}_{I^{\\prime}}}")#text(", we have ")#mi("{q_0 \\geq D_0}")#text(", and so we may evaluate the ")#mi("{q_0}")#text(" summation as")

#align(center)[#tao-fit-display[#mitex("O( MN \\log^{O(1)} x (1 + \\frac{N}{RD_0} ) ).")]]

#text("By ")#link(<tao-375676bd26868505668f>)[#text("(16)")]#text(" and ")#link(<tao-0ad52e338662c923b15f>)[#text("(15)")]#text(", this is ")#mi("{O( N^2 M R^{-1} \\log^{-A} x )}")#text(" as required.")

#text("It remains to control ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("(24)")]#text(". We may assume that ")#mi("{H \\geq 1}")#text(", as the claim is trivial otherwise. It will suffice to obtain the bound")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{H} \\sum_r \\sum_{k=O(N/R)} \\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2 \\sim Q} \\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi_{k,r}(h,q_1,q_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^{-\\epsilon} N^2 M R^{-1}.")]]

#text("Using ")#link(<tao-a81ffb258bff4eddc451>)[#text("(25)")]#text(", it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_r \\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2 \\sim Q} \\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi_{k,r}(h,q_1,q_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^2 N R")]]

#text("for each ")#mi("{k = O(N/R)}")#text(".")

#text("We now work with a single ")#mi("{k}")#text(". To proceed further, we write ")#mi("{q_0 := (q_1,q_2)}")#text(" and ")#mi("{q_1 = q_0 q^{\\prime}_1}")#text(", ")#mi("{q_2 = q_0 q^{\\prime}_2}")#text("; it then suffices to show that ")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#mitex("\\sum_r \\sum_{1 \\leq h \\leq H} \\sum_{q^{\\prime}_1,q^{\\prime}_2 \\sim Q/q_0: (q^{\\prime}_1,q^{\\prime}_2) = 1}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi_{k,r}(h,q_0 q^{\\prime}_1,q_0 q^{\\prime}_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^2 N R / q_0")]]

#text("for each ")#mi("{q_0 \\geq 1}")#text(".")

#text("Henceforth we work with a single choice of ")#mi("{q_0}")#text(". We pause to verify the relationship")

#align(center)[#tao-fit-display[#mitex("H \\lessapprox Q.")]]

#text("From ")#link(<tao-a81ffb258bff4eddc451>)[#text("(25)")]#text(" and ")#link(<tao-2617708489831f17c7b6>)[#text("(17)")]#text(", this follows from the assertion that")

#align(center)[#tao-fit-display[#mitex("x^{1/2+2\\varpi+\\epsilon} \\lessapprox M,")]]

#text("but this follows from ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(4)")]#text(", ")#link(<tao-58e0413224af6b6d3505>)[#text("(5)")]#text(" if ")#mi("{\\epsilon}")#text(" is sufficiently small depending on ")#mi("{c}")#text(".")

#text("As ")#mi("{q_1}")#text(" is ")#mi("{x^{\\delta+o(1)}}")#text("-densely divisible, we may now factor ")#mi("{q_1 = s_1 t_1}")#text(" where")

#align(center)[#tao-fit-display[#mitex("x^{-\\delta} Q/H \\lessapprox s_1 \\lessapprox Q/H")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("H \\lessapprox t_1 \\lessapprox x^\\delta H.")]]

#text("Factoring out ")#mi("{q_0}")#text(", we may then write ")#mi("{q^{\\prime}_1 = s^{\\prime}_1 t^{\\prime}_1}")#text(" where")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} x^{-\\delta} Q/H \\lessapprox s^{\\prime}_1 \\lessapprox Q/H")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} H \\lessapprox t^{\\prime}_1 \\lessapprox x^\\delta H.")]]

#text("By dyadic decomposition, it thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_r \\sum_{1 \\leq h \\leq H} \\sum_{s^{\\prime}_1 \\sim S; t^{\\prime}_1 \\sim T; q^{\\prime}_2 \\sim Q/q_0: (s^{\\prime}_1 t^{\\prime}_1,q^{\\prime}_2) = 1}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n} \\beta(n) \\overline{\\beta(n+kr)} \\Phi_{k,r}(h,q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox Q^2 N R / q_0")]]

#text("whenever ")#mi("{S,T}")#text(" are such that")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} x^{-\\delta} Q/H \\lessapprox S \\lessapprox Q/H")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("q_0^{-1} H \\lessapprox T \\lessapprox x^\\delta H.")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("ST \\sim Q/q_0.")]]

#text("We rearrange this estimate as")

#align(center)[#tao-fit-display[#mitex("|\\sum_r \\sum_{n; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0} \\beta(n) \\overline{\\beta(n+kr)} \\sum_{1 \\leq h \\leq H; t^{\\prime}_1 \\sim T}")]]

#align(center)[#tao-fit-display[#mitex("c_{h,s^{\\prime}_1,t^{\\prime}_1,q^{\\prime}_2} \\Phi_{k,r}(h,q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n)|")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox QRSTN")]]

#text("for some bounded sequence ")#mi("{c_{h,s_1,t_1,q_2}}")#text(" which is only non-zero when")

#align(center)[#tao-fit-display[#mitex("(s^{\\prime}_1 t^{\\prime}_1,q^{\\prime}_2) = (q_0,s^{\\prime}_1t^{\\prime}_1) = (q_0,q^{\\prime}_2) = 1.")]]

#text("By Cauchy-Schwarz and crude estimates, it then suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_r \\sum_{n; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0} \\psi_N(n) \\left|\\sum_{1 \\leq h \\leq H; t^{\\prime}_1 \\sim T} c_{h,s^{\\prime}_1,t^{\\prime}_1,q^{\\prime}_2} \\Phi_{k,r}(h,q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q_2; n)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox QRST^2 N q_0")]]

#text("where ")#mi("{\\psi_N}")#text(" is a coefficient sequence at scale ")#mi("{N}")#text(". The left-hand side may be bounded by ")#metadata(none) <tao-cb6e53541e37a1d6076e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#mitex("\\sum_{1 \\leq h,\\tilde h \\leq H; t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0; (s^{\\prime}_1t^{\\prime}_1\\tilde t^{\\prime}_1,q_0q^{\\prime}_2)=1}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_r \\sum_n \\psi_N(n) \\Phi_{k,r}(h, q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{ \\Phi_{k,r}(\\tilde h,q_0 s^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2; n) } \\right|.", block: true)]]

#text("The contribution of the diagonal case ")#mi("{h \\tilde t^{\\prime}_1 = \\tilde h t^{\\prime}_1}")#text(" is ")#mi("{\\lessapprox RHTSQ N/q_0}")#text(" by the divisor bound, which is acceptable since ")#mi("{q_0 T \\gtrapprox H}")#text(". Thus it suffices to control the off-diagonal case ")#mi("{h\\tilde t^{\\prime}_1 \\neq \\tilde ht^{\\prime}_1}")#text(".")

#text("Note that ")#mi("{t^{\\prime}_1, \\tilde t^{\\prime}_1}")#text(" need to lie in ")#mi("{{\\mathcal S}_I}")#text(" for the summand to be non-vanishing. We use the following elementary lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 14")]#text(" ")#metadata(none) <tao-7ddcdc0ab8180b8893fa>#text(" We have")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h,\\tilde h \\leq H; t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T; t^{\\prime}_1,\\tilde t^{\\prime}_1 \\in {\\mathcal S}_I; s^{\\prime}_1 \\sim S; q^{\\prime}_2 \\sim Q/q_0: (s^{\\prime}_1t^{\\prime}_1\\tilde t^{\\prime}_1,q_0q^{\\prime}_2)=1; h\\tilde t^{\\prime}_1 \\neq \\tilde h t^{\\prime}_1}")]]

#align(center)[#tao-fit-display[#mitex("(h\\tilde t^{\\prime}_1-\\tilde h t^{\\prime}_1, q_0 s^{\\prime}_1 [t^{\\prime}_1, \\tilde t^{\\prime}_1] q^{\\prime}_2) \\lessapprox H^2 S T^2 Q / q_0.")]]
]

#emph[#text("Proof:")]#text(" Setting ")#mi("{w := q_0 s^{\\prime}_1 q^{\\prime}_2}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h,\\tilde h \\leq H; t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T: (t^{\\prime}_1\\tilde t^{\\prime}_1,w)=1; h\\tilde t^{\\prime}_1 \\neq \\tilde h t^{\\prime}_1} (h\\tilde t^{\\prime}_1-\\tilde h t^{\\prime}_1, [t^{\\prime}_1, \\tilde t^{\\prime}_1] w) \\lessapprox H^2 T^2")]]

#text("for each fixed ")#mi("{s^{\\prime}_1, q^{\\prime}_2}")#text(". Since")

#align(center)[#tao-fit-display[#mitex("(h\\tilde t^{\\prime}_1-\\tilde h t^{\\prime}_1, [t^{\\prime}_1, \\tilde t^{\\prime}_1] w) \\leq \\sum_{d|w} \\sum_{e: (d,e)=1} de 1_{de| h\\tilde t^{\\prime}_1-\\tilde h t^{\\prime}_1} 1_{e|[t^{\\prime}_1,\\tilde t^{\\prime}_1]}")]]

#text("it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq h,\\tilde h \\leq H; t^{\\prime}_1,\\tilde t^{\\prime}_1 \\sim T: (t^{\\prime}_1\\tilde t^{\\prime}_1,w)=1; h\\tilde t^{\\prime}_1 \\neq \\tilde h t^{\\prime}_1} 1_{de| h\\tilde t^{\\prime}_1-\\tilde h t^{\\prime}_1} 1_{e|[t^{\\prime}_1,\\tilde t^{\\prime}_1]} \\lessapprox \\frac{H^2 T^2}{de^2}")]]

#text("for all coprime ")#mi("{d,e}")#text(" of polynomial size.")

#text("If ")#mi("{e}")#text(" divides both ")#mi("{h\\tilde t^{\\prime}_1-\\tilde h t^{\\prime}_1}")#text(" and ")#mi("{[t^{\\prime}_1,\\tilde t^{\\prime}_1]}")#text(", then for each ")#mi("{p}")#text(" dividing ")#mi("{e}")#text(", ")#mi("{p}")#text(" must divide one of ")#mi("{(h, t^{\\prime}_1)}")#text(", ")#mi("{(\\tilde h, \\tilde t^{\\prime}_1)}")#text(", or ")#mi("{(t^{\\prime}_1, \\tilde t^{\\prime}_1)}")#text(". Thus we can factor ")#mi("{e = e_1 e_2 e_3}")#text(" and ")#mi("{h = e_1 h^{\\prime}}")#text(", ")#mi("{\\tilde h = e_2 \\tilde h^{\\prime}}")#text(", ")#mi("{t^{\\prime}_1 = e_1 e_3 t^{\\prime\\prime}_1}")#text(", ")#mi("{\\tilde t^{\\prime}_1 = e_2 e_3 \\tilde t^{\\prime\\prime}_1}")#text(", which implies that ")#mi("{d | h^{\\prime} \\tilde t^{\\prime\\prime}_1 -\\tilde h^{\\prime} t^{\\prime\\prime}_1}")#text(". For fixed ")#mi("{e}")#text(", we see from the divisor bound that there are ")#mi("{\\lessapprox 1}")#text(" choices for ")#mi("{e_1,e_2,e_3}")#text(". Fixing ")#mi("{e_1,e_2,e_3}")#text(", we see that ")#mi("{h^{\\prime} \\tilde t^{\\prime\\prime}_1, \\tilde h^{\\prime} t^{\\prime\\prime}_1}")#text(" have magnitude ")#mi("{O(HT/e)}")#text(", so there are ")#mi("{O( (HT/e)^2 / d )}")#text(" possible pairs of ")#mi("{h^{\\prime} \\tilde t^{\\prime\\prime}_1, \\tilde h^{\\prime} t^{\\prime\\prime}_1}")#text(" whose difference is non-zero and divisible by ")#mi("{d}")#text(". The claim then follows from the divisor bound. ")#mi("\\Box")

#text("From this lemma, we see that for each fixed choice of ")#mi("{h,\\tilde h, t^{\\prime}_1, \\tilde t^{\\prime}_1, s^{\\prime}_1, q^{\\prime}_2}")#text(" in the above sum, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_r \\sum_n \\psi_N(n) \\Phi_{k,r}(h, q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{ \\Phi_{k,r}(\\tilde h,q_0 s^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2; n) } \\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-2} q_0^2 RN (h\\tilde t^{\\prime}_1-\\tilde h t^{\\prime}_1, q_0 s^{\\prime}_1 [t^{\\prime}_1, \\tilde t^{\\prime}_1] q^{\\prime}_2)")]]

#text("Thus far the arguments have been essentially identical to that in the previous post, except that we have retained the ")#mi("{r}")#text(" averaging (and crucially, this averaging is inside the absolute values rather than outside). We now exploit the doubly dense divisibility of ")#mi("{r}")#text(" to factor ")#mi("{r=dr^{\\prime}}")#text(" where")

#align(center)[#tao-fit-display[#mitex("\\max(1,x^{-\\delta-\\epsilon} H^{-4} N) \\lessapprox d \\lessapprox x^{-\\epsilon} H^{-4} N")]]

#text("and ")#mi("{r^{\\prime}}")#text(" is ")#mi("{x^{\\delta+o(1)}}")#text("-densely divisible; this is admissible as long as ")#metadata(none) <tao-212429b8cdeeb8c98b51>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#mitex("1 \\lessapprox x^{-\\epsilon} H^{-4} N \\lessapprox R,")]]

#text("which are conditions which we will verify later. By dyadic decomposition, and the triangle inequality in ")#mi("{r^{\\prime}}")#text(", it thus suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\psi_D(d) \\sum_n \\psi_N(n) \\Phi_{k,dr^{\\prime}}(h, q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{ \\Phi_{k,dr^{\\prime}}(\\tilde h,q_0 s^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2; n) } \\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-2} q_0^2 DN (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u)")]]

#text("for all ")#metadata(none) <tao-ac4539bb82a3f8229a4f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\max(1,x^{-\\delta-\\epsilon} H^{-4} N) \\lessapprox D \\lessapprox x^{-\\epsilon} H^{-4} N")]]

#text("and all ")#mi("{x^{\\delta+o(1)}}")#text("-densely divisible ")#mi("{r^{\\prime} \\sim R/D}")#text(", where ")#mi("{\\psi_D}")#text(" is a smooth non-negative coefficient sequence at scale ")#mi("{D}")#text(", where ")#metadata(none) <tao-7822db94e8a3b588c53a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("u:= r^{\\prime}q_0 s^{\\prime}_1 [t^{\\prime}_1, \\tilde t^{\\prime}_1] q^{\\prime}_2.")]]

#text("Note that if the ")#mi("{\\Phi}")#text(" factors are to be non-vanishing, ")#mi("{q_0 s^{\\prime}_1 t^{\\prime}_1}")#text(", ")#mi("{q_0, s^{\\prime}_1 \\tilde t^{\\prime}_1}")#text(" are to be ")#mi("{x^{\\delta+o(1)}}")#text("-densely divisible, and so ")#mi("{u}")#text(" is ")#mi("{x^{\\delta+o(1)}}")#text("-densely divisible as well thanks to Lemma ")#link(<tao-b1b927541c77e69aea9d>)[#text("7")]#text(".")

#text("We write the above estimate as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\psi_D(d) \\sum_n \\psi_N(n) \\Psi(d,n)\\right| \\lessapprox H^{-2} q_0^2 DN (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u)", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\Psi(d,n) :=\\Phi_{k,dr^{\\prime}}(h, q_0 s^{\\prime}_1 t^{\\prime}_1,q_0 q^{\\prime}_2; n) \\overline{ \\Phi_{k,dr^{\\prime}}(\\tilde h,q_0 s^{\\prime}_1 \\tilde t^{\\prime}_1,q_0 q^{\\prime}_2; n) }.")]]

#text("We now perform Weyl differencing. Set ")#mi("{L := \\lfloor x^{-\\epsilon} N/D \\rfloor}")#text(", then ")#mi("{L \\geq 1}")#text(" and we can rewrite")

#align(center)[#tao-fit-display[#mitex("\\sum_d \\psi_D(d) \\sum_n \\psi_N(n) \\Psi(d,n) = \\frac{1}{L} \\sum_{d \\sim D} \\sum_n \\sum_{l=1}^L \\psi_N(n+dl) \\Psi(d,n+dl)")]]

#text("and so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_d \\psi_D(d) \\sum_n \\sum_{l=1}^L \\psi_N(n+dl) \\Psi(d,n+dl)\\right| \\lessapprox H^{-2} q_0^2 DNL (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u).", block: true)]]

#text("By Cauchy-Schwarz, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_d \\psi_D(d) \\sum_n \\left|\\sum_{l=1}^L \\psi_N(n+dl) \\Psi(d,n+dl)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-4} q_0^4 DNL^2 (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u)^2.")]]

#text("We restrict ")#mi("{n}")#text(" and ")#mi("{d}")#text(" to individual residue classes ")#mi("{n=n_0\\ (q_0)}")#text(" and ")#mi("{d = d_0\\ (q_0)}")#text("; it then suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{d=d_0\\ (q_0)} \\psi_D(d) \\sum_{n=n_0\\ (q_0)} \\left|\\sum_{l=1}^L \\psi_N(n+dl) \\Psi(d,n+dl)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-4} q_0^2 DNL^2 (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u)^2.")]]

#text("From ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(26)")]#text(" we see that the quantity ")#mi("{\\Psi(d,n)}")#text(" vanishes unless")

#align(center)[#tao-fit-display[#mitex("d r^{\\prime} q_0 s^{\\prime}_1 [t^{\\prime}_1,\\tilde t^{\\prime}_1] q^{\\prime}_2")]]

#text("is square-free, and in that case it takes the form")

#align(center)[#tao-fit-display[#mitex("\\Psi(d,n) = \\alpha_{n_0,d_0} e_d(\\frac{c_0}{n}) e_{r^{\\prime}s^{\\prime}_1[t^{\\prime}_1,\\tilde t^{\\prime}_1]}(\\frac{c_1}{dn} ) e_{q^{\\prime}_2}( \\frac{c_2}{d(n+kdr^{\\prime})} )")]]

#text("when restricted to ")#mi("{n=n_0\\ (q_0)}")#text(", ")#mi("{d = d_0\\ (q_0)}")#text(", where ")#mi("{c_0,c_1,c_2}")#text(" are quantities that may depend on ")#mi("{q_0,r^{\\prime},s_1,t_1,\\tilde t_1,q^{\\prime}_2}")#text(" but are independent of ")#mi("{n,d}")#text(" with")

#align(center)[#tao-fit-display[#mitex("(c_1,r^{\\prime}s^{\\prime}_1[t^{\\prime}_1,\\tilde t^{\\prime}_1]) = (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,r^{\\prime}s^{\\prime}_1[t^{\\prime}_1,\\tilde t^{\\prime}_1])")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(c_2,q^{\\prime}_2) = (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,q^{\\prime}_2).")]]

#text("adopting the convention that ")#mi("{e_q(\\frac{a}{b})}")#text(" vanishes when ")#mi("{(b,q) \\neq 1}")#text(", and ")#mi("{\\alpha_{n_0,d_0}}")#text(" is a bounded quantity depending on ")#mi("{n_0,d_0,q_0,r^{\\prime},s_1,t_1,\\tilde t_1,q^{\\prime}_2}")#text(" but otherwise independent of ")#mi("{n,d}")#text(". If we let ")#mi("{v \\in {\\bf Z}/u{\\bf Z}}")#text(" be such that ")#mi("{v = 0\\ (r^{\\prime}s^{\\prime}_1[t^{\\prime}_1,\\tilde t^{\\prime}_1])}")#text(" and ")#mi("{v = kr^{\\prime}\\ (q^{\\prime}_2)}")#text(", and let ")#mi("{c_3:= c_1 q^{\\prime}_2 + c_2 r^{\\prime}s^{\\prime}_1[t^{\\prime}_1,\\tilde t^{\\prime}_1]}")#text(", we can simplify the above as")

#align(center)[#tao-fit-display[#mitex("\\Psi(d,n) = \\alpha_{n_0,d_0} e_d(\\frac{c_0}{n}) e_u(\\frac{c_3}{d(n+vd)} )")]]

#text("and note that")

#align(center)[#tao-fit-display[#mitex("(c_3,u) = (h\\tilde t^{\\prime}_1 - \\tilde ht^{\\prime}_1,u).")]]

#text("We thus have")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{l=1}^L \\psi_N(n+dl) \\Psi(d,n+dl)\\right| \\ll |\\sum_{l=1}^L e_u(\\frac{c_3}{d(n+vd)} )", block: true)]]

#text("and therefore")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{l=1}^L \\psi_N(n+dl) \\Psi(d,n+dl)\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{1 \\leq l,l^{\\prime} \\leq L} \\psi_N(n+dl) \\psi_N(n+dl^{\\prime}) e_u(\\frac{c_3 l}{(n+vd+ld)(n+vd+l^{\\prime}d)} ).")]]

#text("It thus suffices to show that")

#align(center)[#tao-fit-display[#mitex("|\\sum_{d=d_0\\ (q_0)} \\psi_D(d) \\sum_{n=n_0\\ (q_0)} \\sum_{1 \\leq l,l^{\\prime} \\leq L} \\psi_N(n+dl) \\psi_N(n+dl^{\\prime})")]]

#align(center)[#tao-fit-display[#mitex("e_u(\\frac{c_3 l}{(n+vd+ld)(n+vd+l^{\\prime}d)} )|")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-4} q_0^2 DNL^2 (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u)^2.")]]

#text("Shifting ")#mi("{n}")#text(" by ")#mi("{dl}")#text(", then relabeling ")#mi("{l^{\\prime}-l}")#text(" as ")#mi("{l}")#text(", it suffices to show that ")#metadata(none) <tao-b23bdd6952cda0417398>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#tao-math("\\sum_{\\left|l\\right| \\leq L} |\\sum_{d=d_0\\ (q_0)} \\psi_D(d) \\sum_{n=n_0\\ (q_0)} \\psi_N(n) \\psi_N(n+dl)", block: true)]]

#align(center)[#tao-fit-display[#mitex("e_u(\\frac{c_3 l}{(n+vd+ld)(n+vd+l^{\\prime}d)} ) |")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-4} q_0^2 DNL (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u)^2.")]]

#text("The contribution of the diagonal case ")#mi("{l=0}")#text(" is ")#mi("{O( D N )}")#text(", which is acceptable thanks to ")#link(<tao-212429b8cdeeb8c98b51>)[#text("(29)")]#text(" (which implies ")#mi("{L \\gtrapprox H^4}")#text("; we have a factor of ")#mi("{q_0^4}")#text(" to spare which we will simply discard). It thus suffices to control the off-diagonal case ")#mi("{l \\neq 0}")#text(". It then suffices to show that")

#align(center)[#tao-fit-display[#mitex("|\\sum_{d=d_0\\ (q_0)} \\psi_D(d) \\sum_{n=n_0\\ (q_0)} \\psi_N(n) \\psi_N(n+dl)")]]

#align(center)[#tao-fit-display[#mitex("e_u(\\frac{c_3 l}{(n+vd+ld)(n+vd+l^{\\prime}d)} )|")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-4} q_0^2 DN (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u) (l,u)")]]

#text("for each non-zero ")#mi("{l}")#text(".")

#text("Performing a Taylor expansion, we can write")

#align(center)[#tao-fit-display[#mitex("\\psi_N(n+dl) = \\sum_{j=0}^J (\\frac{d}{D})^j \\psi_{N,j}(n) + O( x^{-\\epsilon J} )")]]

#text("for any fixed ")#mi("{J}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\psi_{N,j}(n) = \\frac{1}{j!} (\\frac{Dl}{N})^j \\psi^{(j)}(\\frac{n}{N}).")]]

#text("Absorbing the ")#mi("{(\\frac{d}{D})^j}")#text(" factor into ")#mi("{\\psi_D}")#text(", and taking ")#mi("{J}")#text(" large enough, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{d=d_0\\ (q_0)} \\tilde \\psi_D(d) \\sum_{n=n_0\\ (q_0)} \\tilde \\psi_N(n) e_u(\\frac{c_3 l}{(n+vd+ld)(n+vd+l^{\\prime}d)} )\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox H^{-4} q_0^2 DN (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u) (l,u)")]]

#text("for coefficient sequences ")#mi("{\\tilde \\psi_D, \\tilde \\psi_N}")#text(" which are smooth at scales ")#mi("{D,N}")#text(" respectively. But by applying Proposition ")#link(<tao-3239f1a94e2725c66282>)[#text("13")]#text(", and making the substitutions ")#mi("{d = q_0 d^{\\prime} + d_0}")#text(", ")#mi("{n = q_0 n^{\\prime} + n_0}")#text(", we may bound the left-hand side by")

#align(center)[#tao-fit-display[#mitex("(c_3l,u) (u^{1/2} + \\frac{N/q_0}{u^{1/2}}) ( 1 + (D/q_0)^{1/2} u^{1/6} x^{\\delta/6} + \\frac{D/q_0}{u^{1/2}})")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(c_3l,u) (u^{1/2} + \\frac{N/q_0}{u^{1/2}}) (u^{1/2} + \\frac{D/q_0}{u^{1/2}}).")]]

#text("Using the former bound when ")#mi("{N/q_0 \\leq u^{1/2}}")#text(" and the latter bound when ")#mi("{N/q_0 > u^{1/2}}")#text(", we obtain the upper bound of")

#align(center)[#tao-fit-display[#mitex("(c_3l,u) [ u^{1/2} ( 1 + (D/q_0)^{1/2} u^{1/6} x^{\\delta/6} + \\frac{D/q_0}{u^{1/2}}) + \\frac{N/q_0}{u^{1/2}} (u^{1/2} + \\frac{D/q_0}{u^{1/2}})].")]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("(c_3l,u) \\leq (c_3,u)(l,u) = (h\\tilde t^{\\prime}_1 - \\tilde h t^{\\prime}_1,u) (l,u)")]]

#text("and ")#mi("{q_0 \\geq 1}")#text(", it suffices to show that")

#align(center)[#tao-fit-display[#mitex("u^{1/2} ( 1 + D^{1/2} u^{1/6} x^{\\delta/6} + \\frac{D}{u^{1/2}}) + \\frac{N}{u^{1/2}} (u^{1/2} + \\frac{D}{u^{1/2}}) \\lessapprox H^{-4} DN q_0^2.")]]

#text("Since ")#mi("{D,u \\geq 1}")#text(", we can replace ")#mi("{1 + D^{1/2} u^{1/6} x^{\\delta/6} }")#text(" by ")#mi("{D^{1/2} u^{1/6} x^{\\delta/6}}")#text(". The above bounds then simplify to ")#metadata(none) <tao-8185d5e4c340bf13a2f2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("D^{1/2} u^{2/3} x^{\\delta/6} + D + N + DN u^{-1} \\lessapprox H^{-4} D N q_0^2.")]]

#text("From ")#link(<tao-212429b8cdeeb8c98b51>)[#text("(29)")]#text(" we already have ")#mi("{D \\lessapprox H^{-4} DN}")#text(". Also, from ")#link(<tao-7822db94e8a3b588c53a>)[#text("(31)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("u \\lessapprox \\frac{R}{D} q_0 S T^2 (Q/q_0)")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox R D^{-1} Q^2 T")]]

#align(center)[#tao-fit-display[#mitex("\\lessapprox x^\\delta R D^{-1} Q^2 H.")]]

#text("and conversely")

#align(center)[#tao-fit-display[#mitex("u \\gtrapprox \\frac{R}{D} q_0 S T (Q/q_0)")]]

#align(center)[#tao-fit-display[#mitex("\\gtrapprox R D^{-1} Q^2 / q_0.")]]

#text("Inserting these bounds and discarding the remaining powers of ")#mi("{q_0}")#text(", we reduce to")

#align(center)[#tao-fit-display[#mitex("D^{1/2} (x^\\delta R D^{-1} Q^2 H)^{2/3} x^{\\delta/6} \\lessapprox H^{-4} DN")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("N \\lessapprox H^{-4} DN")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("DN (R D^{-1} Q^2)^{-1} \\lessapprox H^{-4} DN.")]]

#text("We rearrange these as")

#align(center)[#tao-fit-display[#mitex("x^{5\\delta/6} R^{2/3} Q^{4/3} H^{14/3} \\lessapprox N D^{7/6}")]]

#align(center)[#tao-fit-display[#mitex("H^4 \\lessapprox D")]]

#align(center)[#tao-fit-display[#mitex("H^4 D \\lessapprox R Q^2.")]]

#text("Applying the bounds on ")#mi("{D}")#text(" from ")#link(<tao-ac4539bb82a3f8229a4f>)[#text("(30)")]#text(", these reduce to")

#align(center)[#tao-fit-display[#mitex("x^{2\\delta} x^{7\\epsilon/6} R^{2/3} Q^{4/3} H^{28/3} \\lessapprox N^{13/6}")]]

#metadata(none) <tao-3d099d0f13df9d0bb442>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("x^{\\delta+\\epsilon} H^8 \\lessapprox N")]]

#align(center)[#tao-fit-display[#mitex("x^{-\\epsilon} N \\lessapprox RQ^2.")]]

#text("The third bound follows since ")#mi("{N \\lessapprox x^{1/2} \\lessapprox QR}")#text(", and so may be dropped. We also recall the two bounds assumed from ")#link(<tao-212429b8cdeeb8c98b51>)[#text("(29)")]#text(": ")#metadata(none) <tao-2dd411308b37266d33c9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("x^\\epsilon H^4 \\lessapprox N")]]

#align(center)[#tao-fit-display[#mitex("N \\lessapprox x^\\epsilon H^4 R.")]]

#text("The bound ")#link(<tao-2dd411308b37266d33c9>)[#text("(35)")]#text(" is implied by ")#link(<tao-3d099d0f13df9d0bb442>)[#text("(34)")]#text(" and may thus be dropped. We have")

#align(center)[#tao-fit-display[#mitex("H = x^\\epsilon Q^2 R/M \\sim x^{-1+\\epsilon} Q^2 R N,")]]

#text("so the remaining three bounds may be rewritten as")

#align(center)[#tao-fit-display[#mitex("x^{2\\delta} x^{21\\epsilon/2} R^{10} Q^{20} N^{43/6} \\lessapprox x^{28/3}")]]

#align(center)[#tao-fit-display[#mitex("x^{\\delta+9\\epsilon} Q^{16} R^8 N^7 \\lesssim x^8")]]

#align(center)[#tao-fit-display[#mitex("x^4 \\lessapprox x^{5\\epsilon} Q^8 R^5 N^3.")]]

#text("Since ")#mi("{x^{1/2} \\lessapprox QR \\lessapprox x^{1/2+2\\varpi}}")#text(", these three bounds reduce to")

#align(center)[#tao-fit-display[#mitex("x^{2/3 + 40\\varpi + 2\\delta + 21\\epsilon/2} N^{43/6} \\lessapprox R^{10}")]]

#align(center)[#tao-fit-display[#mitex("x^{32\\varpi+\\delta+9\\epsilon} N^7 \\lesssim R^8")]]

#align(center)[#tao-fit-display[#mitex("R^3 \\lessapprox x^{5\\epsilon} N^3.")]]

#text("From ")#link(<tao-375676bd26868505668f>)[#text("(16)")]#text(" we have ")#mi("{x^{-\\delta-\\epsilon} N \\lessapprox R \\lessapprox x^{-\\epsilon} N}")#text(", so the third bound is automatic, and the other two bounds become")

#align(center)[#tao-fit-display[#mitex("x^{2/3 + 40\\varpi + 12\\delta + 41\\epsilon/2} \\lessapprox N^{17/6}")]]

#align(center)[#tao-fit-display[#mitex("x^{32\\varpi+9\\delta+17\\epsilon} \\lessapprox N.")]]

#text("Since ")#mi("{N \\gtrapprox 1/2-\\sigma}")#text(", these two bounds become")

#tao-aligned(keep: true)[


#tao-math("\\frac{2}{3} + 40\\varpi + 12\\delta  & < \\frac{17}{6} (\\frac{1}{2}-\\sigma )", block: true)



#tao-math("32 \\varpi + 9\\delta  & < \\frac{1}{2} - \\sigma", block: true)
]

#text("which we rearrange as")

#tao-aligned(keep: true)[


#tao-math("\\frac{160}{3} \\varpi + 16 \\delta + \\frac{34}{9} \\sigma  & < 1", block: true)



#tao-math("64\\varpi + 18\\delta + 2\\sigma  & < 1", block: true)
]

#text("and the claim follows.")

#heading(level: 1)[#text("Comments (63)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-239983")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("While writing the above post, I got the strong sense that any further pushing of our current methods will become increasingly complicated, and lead to increasingly smaller returns; each new appication of Cauchy-Schwartz, in particular, can make the main term in an estimate somewhat better behaved, but at the cost of making a lot of error terms worse (and more numerous), and it becomes increasingly tricky to ensure that all these error terms remain dominated by the main term. When the time comes to start writing up the results of this project (which will probably begin fairly soon), we may have to consider a tradeoff between simplicity of exposition and the optimality of the results; would it be worth it, for instance, to add ten pages to the argument in order to reduce H by 10%?")

#text("One nice thing about the basic structure of Zhang’s argument, though, is that it is very modular; one can, for instance, swap in one Type I estimate for a fancier one and keep everything else unchanged. (For instance, as noted before, we can swap out the Type III estimates entirely, and revert to the previous Type I estimate, thus eliminating the need to use Deligne’s theorems.) So it should be relatively easy to designate one set of estimates as the “primary” version of the argument, and then remark on various ways to either strengthen the bounds (at the cost of increased complexity) or simplify the proof (at the cost of worse bounds).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Armin")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-239990")[#strong[#text("Armin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("What this project is aiming for is different so, perhaps it is asking too much, but it would be nice to see the simplest possible argument no matter the quality of the estimate. Did you make any progress in this sense compared to Zhang’s original proof?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-239991")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("I would think the best currently available bound should be included and proved in the paper.")

#text("That said, the write-up could take advantage of the modularity of the result, perhaps starting with the argument in ")#link("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236995")[#text("https://terrytao.wordpress.com/2013/06/30/bounded-gaps-between-primes-polymath8-a-progress-report/#comment-236995")]#text(" and then have later sections improve the estimates that came before, highlighting the needed adjustments in the argument. (This organic approach would also make clear how the results developed through the project, which some readers may find just as fascinating as the proofs themselves.)")

#text("This makes the paper longer, of course, and harder to write, but perhaps most useful, as readers could stop at the end of essentially any given section, and walk out with a complete proof, a decent estimate, and an idea of what details of the argument would admit further improving.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240000")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("I like the idea of starting with the “minimal” proof needed to obtain a qualitative version of Zhang’s theorem (B[H] for some unspecified H) and then replacing things with fancier estimates later. Let me try to lay out what that “minimal” proof looks like.")

#text("1. First we need to show that ")#mi("DHL[k_0,2]")#text(" for some ")#mi("k_0")#text(" implies ")#mi("B[H]")#text(" for some finite H. This is easy; we can just follow Zhang here and observe that for any ")#mi("k_0")#text(", the first ")#mi("k_0")#text(" primes past ")#mi("k_0")#text(" form an admissible ")#mi("k_0")#text("-tuple.")

#text("2. Then we need to show that ")#mi("MPZ[\\varpi,\\delta]")#text(" for some ")#mi("\\varpi,\\delta>0")#text(" implies ")#mi("DHL[k_0,2]")#text(" for some sufficiently large ")#mi("k_0")#text(" (we can initially work with the original formulation of MPZ involving smoothness, rather than the fancier versions involving dense divisibility). This is not too bad; the elementary Selberg sieve in ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")[#text("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps/")]#text(" (using the “first-generation” weights ")#mi("f(t) = (1-t)^\\ell")#text(" from the original Goldston-Pintz-Yildirim paper (or from Zhang’s paper) rather than the optimised Bessel weight) can do this after a certain lengthy amount of elementary number theory (no contour integration is required). (For the “minimal” proof we can set ")#mi("\\varpi=\\delta")#text(" as Zhang does, although this does not actually lead to any significant simplifications in the argument.) Alternatively one could simply cite the paper of Motohashi-Pintz for this implication, although the implication is not completely explicit in that paper.")

#text("3. Then we need to show that ")#mi("MPZ[\\varpi,\\delta]")#text(" follows from Type I, Type II, and Type III estimates. Actually it turns out that we can do everything using a sufficiently good Type I/II estimate (one which can allow ")#mi("\\sigma")#text(" to be as large as 1/6), removing the need for Type III estimates. In this case, we can also use Vaughan’s identity rather than the Heath-Brown identity, which is not a major simplification but may be a bit more familiar to some readers (and allows one to avoid the combinatorial lemma on subset sums, although this lemma is rather easy). One still needs to use some sort of dyadic decomposition here (actually for technical reasons we use a finer-than-dyadic decomposition), but this is rather easy and standard.")

#text("4. To prove a type I/II estimate, it turns out that the Type II argument can be used to cover both cases. (The Type I and Type II arguments are very similar, except at one stage where Cauchy-Schwarz is applied slightly differently in the two cases.) The ingredients needed here are")

#text("4.1. The Bombieri-Vinogradov theorem (which in turn is proven using the large sieve inequality, a Fourier decomposition into Dirichlet characters, and the Siegel-Walfisz theorem). This is a little lengthy, but completely standard, and we can cite for instance ")#link("http://link.springer.com/article/10.1007%2FBF02399204")[#text("this paper of Bombieri-Friedlander-Iwaniec")]#text(" for the precise version of Bombieri-Vinogradov that we need.")

#text("4.2. The observation that most large numbers ")#mi("x^{1/2} \\ll d \\ll x^{1/2+2\\varpi}")#text(" do not have an enormous number of small prime factors (less than ")#mi("\\exp(\\log^{1/3} x)")#text("); this is elementary but a little technical.")

#text("4.3 A moderately complicated but elementary sequence of Cauchy-Schwarz and completion-of-sums type manipulations (based on the dispersion method), together with some standard bounds on mean values of divisor functions etc. (We have a minor simplification here over the textbook use of the dispersion method as used by Zhang and others, in that instead of having to estimate three different sums ")#mi("S_1,S_2,S_3")#text(", one only needs to control an ")#mi("S_3")#text(" type sum, although this is not a major simplification since ")#mi("S_3")#text(" is the hardest of the three sums to control anyway. There is also a technical tradeoff: early versions of the Type I/II estimates (including Zhang’s) required a certain “controlled multiplicity” hypothesis on the congruence classes involved (in order to reduce to the case when two moduli ")#mi("q_1,q_2")#text(" are coprime); we’ve now removed this hypothesis, but at the (minor) cost of having to carry around an additional parameter ")#mi("q_0")#text(" in the analysis (measuring the gcd of ")#mi("q_1,q_2")#text("). I’m not sure at this point which of these methods would be better for the “minimal” proof.")

#text("4.4 A van der Corput estimate that gives a power saving for sums such as ")#mi("\\sum_{n \\leq N} e_q(\\frac{a}{n})")#text(" for ")#mi("N")#text(" a small power of the smooth modulus ")#mi("q")#text(" (I think with ")#mi("\\sigma=1/6")#text(" and using the Type II argument, we need a power saving with ")#mi("N")#text(" as small as ")#mi("q^{1/3}")#text(", which can be achieved using a double van der Corput + the Weil conjectures for curves. By splitting into Type I and Type II I think we only need a power saving for ")#mi("N")#text(" as small as ")#mi("q^{2/5}")#text(", which requires only one van der Corput + Weil conjectures for curves. (One can do a little better than this by splitting up the moduli more optimally, which is what one does for the most advanced Type I estimates, but perhaps we can avoid this for the “minimal” argument.)")

#text("The van der Corput estimate is proven by an elementary application of Cauchy-Schwarz (following an old paper of Graham and Ringrose), together with the Weil conjectures for curves which in particular gives square root cancellation for sums of the form ")#mi("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(\\frac{P(n)}{Q(n)})")#text(". This bound can simply be cited in the literature, but actually for the purposes of getting a qualitative result, we don’t need square root cancellation; any power saving should suffice. I had claimed earlier that an elementary argument of Kloosterman gives a non-trivial power saving for any exponential sum ")#mi("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q(\\frac{P(n)}{Q(n)})")#text(" with")#mi("P/Q")#text(" non-constant, but actually, now that I look at it more carefully, I only see how to make Kloosterman’s argument work with the Kloosterman sum ")#mi("\\sum_{n \\in {\\bf Z}/q{\\bf Z}} e_q( \\frac{a}{n} + bn )")#text(" as it exploits a certain dilation symmetry in this sum which is not present in the general case. But presumably an elementary argument should be available (which would not need the Weil conjectures for curves; this can be proven using the elementary method of Stepanov, but even this requires the Riemann-Roch theorem and so is not completely elementary.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Armin")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240003")[#strong[#text("Armin")]]#text(size: 9pt, fill: rgb("596477"), " · 28 July 2013")])]

#text("One of the most inspiring aspects of this project was that it has brought to light so many different corners of various fields and linked them in such a beautiful way. Since you already have a number of experts involved in this project, why waste an opportunity to write a completely self-contained textbook? Each person will probably write a chapter or two. This would better serve future generations of mathematicians than a technical paper improving upon Zhang’s result. Right now you have to be a student of one of these experts to learn this material properly, but you have a chance to change this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240082")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("I think the aim of this project would be best fulfilled by a research paper containing the optimal result. The extra 10 pages would be amply justified by the 10% reduction in ")#mi("H")#text(". On the other hand, it would also be very useful to compile a set of lecture notes (for lecturing purposes) which are self-contained, avoid Deligne’s theorem, and yield a reasonably small ")#mi("H")#text(". Finally, these lecture notes could be expanded into a textbook in the farther future.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Armin")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240085")[#strong[#text("Armin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("The optimal result is H=2, and readers of this research paper are probably the same experts who already understand the arguments well enough following developments on this blog. The only real purpose of writing a technical paper is to create a template for the future book, and test run the collaborative process. For that reason, I certainly hope that Terry Tao will not be the one writing 95% of the paper. However, I am only an observer and I wish all the best for everyone involved in this project, regardless of the final product.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240098")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("I disagree that the optimal result is ")#mi("H=2")#text(", perhaps the twin prime conjecture is false! By optimal result I meant the smallest ")#mi("H")#text(" that the project was able to achieve. I also disagree that “The only real purpose of writing a technical paper is to create a template for the future book, and test run the collaborative process”. The aim of this project was to produce an ")#mi("H")#text(" that is as small as possible, and in my opinion the purpose of writing the paper is to publish the result and have it checked by referees as any other theorem in mathematics. Not all the experts followed the developments on this blog, and in fact some future experts are not even born yet! Publishing a weaker result with a simpler proof, or writing a textbook should be regarded as a secondary goal or outcome of the project.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Armin")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240101")[#strong[#text("Armin")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("Those unborn experts is my deepest concern. Without commitment, I fear that after the initial excitement you will take the easy way out and abandon them after 20 pages of technical summary, and will not bear the project to its full term.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240106")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("I am not following you. By unborn experts I meant that a paper is written not only for the present, but also for the future. So it is necessary to produce a decent paper that will be stored in hundreds of libraries and websites (not only on this blog) just as any other scientific paper. On the other hand, the full proof is already written up in detail on this blog, so producing the paper really means to compile the material without the twists and turns that are characteristic in the research process (and nicely reflected on this blog), and of course adding the usual introduction to put the results into context. The final paper will contain a full proof of the stated result, just as any other research paper in mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240116")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("There seem to me to be three possible outcomes, which maybe merit two papers. The first is as elementary a proof as is currently possible of a finite prime gap which occurs infinitely often. The second is the absolute best we can do to prove a minimal prime gap with the techniques currently to hand. The third, which gives a route-map fpr the future, is a record of what has been tried and hasn’t worked, and some intelligent commentary on where new ideas may be needed. ie “if you do better than us with these ideas you might get to … & if you want to do better than that you need an idea we haven’t thought of yet.”")

#text("I think the intensity of this project conceals how rare it has been for these three questions to be open and viable in the timescale achieved here.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240126")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("I think that, thanks to the modular structure of the argument, it should be possible to at least partially achieve the first and third of these objectives in a paper ostensibly focused on the second objective, since we can easily present multiple versions (including some conjectural ones that we can’t actually achieve yet) of each modular component of the argument.")

#text("It’s also not necessary for everything to go into a traditionally published paper; we can have a traditional refereed paper containing the best results we can currently establish, together with some additional blog posts, e.g. one post for the simplest possible proof and another for speculative improvements.")

#text("As for lecture notes and textbooks, my feeling here is that it is best to wait until the subject matures more. There will be more developments and followups to Zhang’s paper than the current polymath project (indeed, there have already been ")#link("http://arxiv.org/abs/1305.6289")[#text("several")]#text(" ")#link("http://arxiv.org/abs/1306.0511")[#text("other")]#text(" ")#link("http://arxiv.org/abs/1306.0948")[#text("research")]#text(" ")#link("http://arxiv.org/abs/1306.1497")[#text("papers")]#text(" that have built upon Zhang’s result outside of the polymath8 project) and it may take some time to get the proper perspective to digest all these results. (And actually it may be best for someone who is not as directly involved with the research to write a proper summary, cf. for instance ")#link("http://www.ams.org/mathscinet-getitem?mr=2265008")[#text("Soundararajan’s Bull. AMS survey")]#text(" of the previous Goldston-Pintz-Yildirim breakthrough on prime gaps.)")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3947db16505b0ca97e0bf34809ff93ed4f157191457c478aea86ed3f2c52aeb1-93302a4d2cfdc09e653a169f1998054a97a6051c5a6b9f42a74271089371a1b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Hilferty")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240066")[#strong[#text("James Hilferty")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("Dear Terry is there any truth in the rummer that you are a “pure mathematician” and not a practical one. I was having a discussion with my niece’s husband about the usefulness of the Gaussian Normal Distribution Curve (he is a professor of mathematics) and I think that I ran rings around and then he suggested without even a blush, that it was only a Hypothesis; and about the Central Limit Theory (which I believe in) and then that you are a Pure (not practical) mathematician; and I asked the obvious question “what’s the point of maths if it doesn’t work?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240114")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")])]

#text("Perhaps (for the next improvement) it is better to reduce the lower bound on ")#mi("\\sigma")#text(" than improving type I estimate in theorem 4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240208")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2013")])]

#text("That doesn’t seem to be the situation at this point, as I understand it. Not only is there an apparently very robust obstacle to reducing the lower bound on sigma (in the form of an inability to handle efficiently what are being termed Type V sums), but also there is not all that much out there in terms of avenues for improving the Type III estimate, which would be needed in order to get more than a rather small increase in varpi (to around 1/82 from the current 1/85) even if sigma were reduced. Conversely, a really big breakthrough for Type I could potentially allow a large varpi even with sigma up at the 1/6 boundary that obviates Type III entirely; this avenue becomes even more attractive when one bears in mind that there is currently a whole cluster of promising-looking options for improving the current Type II bound of varpi=1/68, which is independent of sigma.")

#text("Whether there is actually any real chance of significantly improving the Type I estimate is a different matter, of course, as Terry has noted above. Also, it might turn out that the Type III estimate can be greatly improved after all, in which case the rationale for hacking at the lower bound on sigma would correspondingly increase. Maybe this means it’s worth briefly exploring Type III again now, even though it’s currently irrelevant, just to get a feel for whether the bulk of future effort would be best focused on Type I or on sigma?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240165")[#strong[#text("Stephan Goldammer (@StephGoldammer)")]]#text(size: 9pt, fill: rgb("596477"), " · 29 July 2013")]

#text("Math is easy.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/425e9af440224f70b2fdf2ee6db0b25fa530d49b4abcefba86b2ac9a5c18ff6b-47fc0714a2a9f66e1a077dce6ad71eceabeab9c306a959e880a9194e3340d86f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kamran Alam Khan")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240209")[#strong[#text("Kamran Alam Khan")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2013")])]

#text("Reblogged this on ")#link("http://kamranrmp.wordpress.com/2013/07/30/an-improved-type-i-estimate/")[#text("Observer")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240270")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2013")])]

#text("I’ve been asked a few times what the best value of H we can get without Deligne’s theory (relying just on the Weil conjectures), so I am recording the numerology here.")

#text("Without Deligne’s theorems, we lose the Type III estimates and so need ")#mi("\\sigma")#text(" to be at least ")#mi("1/6")#text(" (rather than ")#mi("1/10")#text("). Also, the most advanced Type I estimate (the “Level 5” one given in this blog post) also relies on Deligne’s theory, and so we must fall back to the previous Type I estimate (confusingly numbered “Level 6”) from ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/")[#text("this previous post")]#text(", which holds (for doubly densely divisible moduli) for ")#mi("56\\varpi+16\\delta+4\\sigma < 1")#text(", which when ")#mi("\\sigma=1/6")#text(" becomes ")#mi("168 \\varpi + 48 \\delta < 1")#text(". There are also the Type II sums, but these hold for ")#mi("68 \\varpi + 14 \\delta < 1")#text(" without Deligne’s theorems and so are not dominant.")

#text("So one has to optimise ")#mi("k_0, \\delta^{\\prime}, A")#text(" subject to ")#mi("168 \\varpi + 48 \\delta < 1")#text(", using the doubly densely divisible value for ")#mi("\\tilde \\theta")#text(", namely")

#mi("\\displaystyle \\tilde \\theta = \\frac{\\delta^{\\prime} - \\delta/2 + \\varpi}{1/4+\\varpi}")

#text("(note that in previous posts the erroneous value of ")#mi("\\frac{\\delta^{\\prime}-\\delta+\\varpi}{1/4+\\varpi}")#text(" was used instead). Setting ")#mi("\\delta = 1/20000")#text(", ")#mi("\\delta^{\\prime} = 1/100")#text(", ")#mi("A = 200")#text(" I can reach ")#mi("k_0 = 1788")#text(" (and hence, ")#link("http://math.mit.edu/~primegaps/")[#text("by the prime tuples website")]#text(", ")#mi("H = 14,994")#text("); this can probably be optimised a little more. So currently Deligne’s theorems are giving a factor of three improvement or so. :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240300")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2013")])]

#text("Thank you! Out of interest: is it still the case that, at the cost of a further numerical hit from iterating vdC, one can also avoid the Weil conjectures, as you intimated a few weeks ago (replacing q^{1/2} by q^{3/4} ), or is that possibility precluded at this point by your concluding paragraph in the sketch of the minimal proof a few days ago? If it’s not precluded, can one yet say what minimal H would currently result in that case?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240314")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2013")])]

#text("I asked a question on MathOverflow about this last point (at ")#link("http://mathoverflow.net/questions/138193/is-there-a-cheap-proof-of-power-savings-for-exponential-sums-over-finite-fields")[#text("http://mathoverflow.net/questions/138193/is-there-a-cheap-proof-of-power-savings-for-exponential-sums-over-finite-fields")]#text(" ) but there is still no definitive answer on that point yet. If we do somehow get a cheap bound of ")#mi("q^{3/4}")#text(" for rational exponential sums (a typical thing we would need is a bound on ")#mi("\\sum_{x \\in {\\bf F}_p}^* e_p( \\frac{c}{x} - \\frac{c}{x+l} - \\frac{c}{x+k} + \\frac{c}{x+k+l})")#text(" for non-zero ")#mi("c,k,l")#text("), this wouldn’t increase the number of van der Corput’s needed, but it would roughly speaking halve the value of ")#mi("\\varpi")#text(" obtained as a result. (Basically, after all the Cauchy-Schwarz, one has to gain something like ")#mi("x^{-4\\varpi}")#text(" or ")#mi("x^{-8\\varpi}")#text(" in the exponential sum over the trivial bound; Weil lets you save ")#mi("q^{1/2}")#text(", but Kloosterman only saves ")#mi("q^{1/4}")#text(".) Halving ")#mi("\\varpi")#text(" roughly corresponds to multiplying ")#mi("k_0")#text(" by ")#mi("2^{3/2}")#text(", and ")#mi("H")#text(" would increase by a little more than that, so we’d be looking at ")#mi("H")#text(" in the 50K range or so.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240282")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2013")])]

#text("I think example 4 (“trace weights”) might not, literally, work with your definition of structured class. The issue is the distinction between geometrically irreducible and arithmetically irreducible sheaves (in my papers with Fouvry and Michel, this explains why we work with geometrically isotypic sheaves instead of irreducible ones).")#linebreak()#text(" But this is relatively technical, and I am sure that there is no problem with the specific weights used for bounded gaps…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240317")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2013")])]

#text("Hmm, this is a subtlety that I did not previously appreciate, and it may complicate the axiomatisation I was hoping to use (in order not to have to deal with specific sheaves). Specifically, if one works with geometric isotypic sheaves only, then one loses the normalisation axiom; the (square of the ) L^2 norm of a trace weight is no longer ")#mi("p + O(p^{1/2})")#text(", but instead ")#mi("cp + O(p^{1/2})")#text(" for some algebraic integer ")#mi("c")#text(" (I think one can’t assume it to be a natural number, though I would like it if we could somehow prevent ")#mi("c")#text(" from getting too small). As such, if two trace weights correlate, then they do not necessarily agree up to a phase, but instead could agree up to a more general algebraic number. In the specific application to the q-van der Corput process we are correlating trace weights which are translates of each other, so we probably can recover the phase property (at least if we have this lower bound on ")#mi("c")#text(").")

#text("I’ll have to think about how to fix this in a non-messy fashion…")

#text("[ADDED LATER: I think I can recover most of what is needed if one works over all embeddings of ")#mi("{\\bf Q}_l")#text(" into ")#mi("{\\bf C}")#text(" rather than just a fixed embedding, so that one never just works with a single algebraic integer, but all Galois conjugates of that integer (since at least one of them is guaranteed to be of magnitude at least one. Still working out the details…]")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240329")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2013")])]

#text("OK, I think I repaired the problem. Trace weights are now defined using geometrically isotypic sheaves instead of geometrically irreducible ones; also for technical reasons I have to exclude the zero function 0 from this class. I claim that the almost orthogonality relation (in the regime when ")#mi("p")#text(" is large compared to all the conductors) now takes the form ")#mi("\\sum_{x \\in U \\cap U^{\\prime}} K(x) \\overline{K^{\\prime}(x)} = c_{K,K^{\\prime}} p + O(\\sqrt{p})")#text(", where ")#mi("K,K^{\\prime}")#text(" are trace weights of bounded conductor defined on ")#mi("U,U^{\\prime}")#text(" respectively, and ")#mi("c_{K,K^{\\prime}}")#text(" is an algebraic integer (of potentially unbounded height and perhaps very close to zero in the Archimedean sense, e.g. ")#mi("1 - e_p(1)")#text("), which is non-vanishing if and only if the geometrically irreducible representations associated to ")#mi("K,K^{\\prime}")#text(" are isomorphic. (It is to get the “if” direction – which allows one to detect non-isomorphism through correlation – that I need to exclude 0 as a trace weight.) Furthermore, all Galois conjugates of the ")#mi("O(\\sqrt{p})")#text(" error remain of size ")#mi("O(\\sqrt{p})")#text(". In particular, I claim that if all Galois conjugates of ")#mi("\\sum_{x \\in U \\cap U^{\\prime}} K(x) \\overline{K^{\\prime}(x)}")#text(" are ")#mi("o(p)")#text(", then ")#mi("K,K^{\\prime}")#text(" do not have common geometrically irreducible components. This allows us to demonstrate that the sheaves we need do not contain quadratic phase components, by reducing matters to bounding (all Galois conjugates of) a two-dimensional exponential sum which we can do by Hooley’s argument.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240342")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2013")])]

#text("A slight correction: there is a complication due to the fact that even if ")#mi("K,K^{\\prime}")#text(" are non-zero and come from geometrically isotypic sheaves ")#mi("{\\mathcal F}, {\\mathcal F}^{\\prime}")#text(" with isomorphic geometric components, it is possible for the trace of Frobenius to cancel out to zero on the geometrically trivial component of ")#mi("{\\mathcal F} \\otimes \\check {\\mathcal F}^{\\prime}")#text(", so one cannot quite use the correlation ")#mi("\\sum_x K(x) \\overline{K^{\\prime}(x)}")#text(" to detect isomorphism of the geometric components in general. However, I don’t think this can occur when one of the sheaves is rank one, which is the case we care about (specifically, one of the sheaves will be the pullback of an Artin-Schreier sheaf by a polynomial).")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240434")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2013")])]

#text("In addition to what Emmanuel said, in order to insure that there no “accidental cancellation” one can compute the sum over all extension ")#mi("F_{p^k}")#text(" (say) of ")#mi("F_p")#text(" (which is possible here of course) the reason being that if ")#mi("\\alpha_1,\\cdots,\\alpha_d")#text(" are complex numbers of modulus one, ")#mi("\\limsup_{k}\\alpha_1^k+\\cdots+\\alpha_d^k=d")#text(".")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240405")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2013")])]

#text("The way we (i.e., FKM) handle this is to work with representatives of arithmetically irreducible, geometrically isotypic, weight 0 (middle extension) sheaves on P^1/F_p modulo geometric isomorphism.")

#text("Functions in such a set strongly quasi-orthogonal; when K=K’, the L^2 norm is about n^2, where n is the number of copies of the geometrically irreducible component of the sheaf.")

#text("They suffice to describe, e.g., general products, because the only missing (weight 0, etc) arithmetically irreducible sheaves are induced from P^1/F_q for some finite extension F_q/F_p, and the trace function of such an induced sheaf is zero.")

#text("(See, e.g., our paper on inverse theorems for Gowers norms of trace functions")

#link("http://www.math.ethz.ch/~kowalski/gowers-prime-fields.pdf")[#text("Click to access gowers-prime-fields.pdf")]

#text("to appear in Math. Proc. Cambridge Phil. Soc., especially section 5.)")

#text("I am not sure how good an axiomatiization one can really hope for (to my mind, this is somewhat similar to issues with the Selberg class compared with automorphic forms). For instance, one might want to add stabilitiy under the Fourier transform, and this adds further complexity; convolution (especially multiplicative convolution) is even trickier.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240471")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2013")])]

#text("Thanks for this! Yes, I have found Section 5 of your Gowers norm paper to be very helpful, thanks.")

#text("My motivation in trying to axiomatise things is not so much to try to get a complete axiomatisation of the trace weight functions (which is probably hopeless at this time, as you point out), but rather to try to “black box” all the information about trace weights that are needed for the application to bounded gaps between primes, for the benefit of readers who are not familiar with the trace weight formalism. I’ve tried to incorporate everything we actually use about trace weights into Definition 9 of this blog post; there is one additional thing we need beyond this, which is that functions of the form ")#mi("K(x) := \\frac{1}{\\sqrt{p}} \\sum_{y \\in {\\Bbb F}_p} e_p(f(x,y))")#text(" are sums of a bounded number of isotypic trace weights, where ")#mi("f")#text(" is a rational function of bounded degree such that ")#mi("y \\mapsto f(x,y)")#text(" is not constant for any ")#mi("x")#text(". (I think this follows from Deligne’s theorem and the Grothendieck-Lefschetz formula if one interprets the middle cohomology associated to the exponential sum ")#mi("K(x)")#text(" itself as a sheaf.)")

#text("For working over ")#mi("{\\bf C}")#text(", I can see that picking one representative modulo geometric isomorphism of each isotypic trace weight works well as one gets the nice quasi-orthogonality property over ")#mi("{\\bf C}")#text(" as a consequence. But I think I have to keep all coefficients algebraic integers in order to avoid cancellation issues (though, as Philippe points out, one could escape this by working with the companion sums instead, but this is much harder to “black box”, and would look quite a circuitous way to estimate an exponential sum over ")#mi("{\\Bbb F}_p")#text(" to readers not familiar with how the Weil conjectures are proven and used). Specifically, I need to show that the above trace weight ")#mi("K(x)")#text(" is associated to a sheaf does not contain any component that is the pullback of an Artin-Schreier sheaf by a quadratic polynomial. By decomposing ")#mi("K")#text(" into components (but not working with a fixed representative in each geometric isomorphism class), I think I can show that the only way the above assertion fails is if there is a quadratic phase whose inner product with ")#mi("K")#text(" is of the form ")#mi("\\alpha p + O(p^{1/2})")#text(" for some non-zero algebraic integer ")#mi("\\alpha")#text(", where all Galois conjugates of the error term ")#mi("O(p^{1/2})")#text(" are also ")#mi("O(p^{1/2})")#text(". Now this algebraic integer may be very small in the Archimedean sense (due to “unwanted cancellation”), but at least one Galois conjugate of it will be large, so one can win as long as one can show that all Galois conjugates of the inner product of ")#mi("K")#text(" with a quadratic phase are ")#mi("O(p^{1/2})")#text(", which one can do using Hooley’s results on two-dimensional exponential sums. But this argument relies heavily on the coefficients remaining algebraic integers (though it would also work to have algebraic numbers whose denominator has bounded height, which sounds like is what would happen if one worked with your quasi-orthogonal basis).")

#text("ADDED LATER: Actually, I can’t remember now why I thought I could ensure that the structure constant ")#mi("\\alpha")#text(" here was an algebraic integer, which means that my arguments above could fall apart (and then one would have to use Philippe’s suggestion of working with the companion sums instead). Have to run now, but will think about this…")

#emph[#text("[Note: I had taken down this comment for editing, and only restored it after Emmanuel’s response below, which is why the timestamps are out of order. -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240466")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2013")])]

#text("I am certain that the “summing over y” construction does indeed give a trace function (of some weight 0 sheaf that may not be a middle extension, but can be adjusted to be so by changing few values), by the existence of higher direct images with compact support. The only issue is to control the conductor of the resulting sheaf, and this doesn’t seem obvious. Since one sums an exponential (instead of considering a more general operator with kernel k(x,y) which is a trace function in two variables), one can use the “classical” bounds for Betti numbers of Bombieri (and later Katz) to control the rank, and probably the number of ramification points is also fairly accessible. On the other hand, I don’t think I know how to handle the Swan conductors in this generality.")

#text("I am also pretty confident that the c_{K,K’} are known to algebraic integers, provided the local traces of the two sheaves involved are themselves algebraic integers (this local condition must be checked, like weight 0-type conditions, at all points of the underlying scheme, not just the F_p-points): this is a result of Deligne in SGA 7, Appendix to exposé XXI.")

#text("For problems like excluding certain types of summands, algebro-geometric arguments can often be made to work that parallel more intuitive (in some sense…) analytic arguments — an excellent example of a similar type is in Katz’s paper “Four lectures on Weil 2” (see ")#link("https://web.math.princeton.edu/~nmk/arizona34.pdf")[#text("https://web.math.princeton.edu/~nmk/arizona34.pdf")]#text(", especially the interlude of Lecture IV and the following section). Our Gowers norms paper had similar features in early drafts where we tried to make the induction work using directly quasi-orthogonality instead of the current argument. One thing that algebraic arguments can exploit is that they don’t care about the conductor — orthogonality can be used at the level of Schur’s Lemma.")

#text("(But of course there are certainly cases where it is indeed easier or better to use Galois conjugation…)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240484")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2013")])]

#text("Hmm, based on what you say I think now that I am not going to get algebraic integer roots for the normalised exponential sum ")#mi("K(x,y) = \\frac{1}{\\sqrt{p}} \\sum_y e_p(f(x,y))")#text(" after all, but rather algebraic integers divided by ")#mi("1/\\sqrt{p}")#text(", which makes the Galois theory approach useless.")

#text("Here’s the specific claim I need. Let ")#mi("f(x,y)")#text(" be a rational function of bounded degree over ")#mi("{\\Bbb F}_p")#text(" which obeys Hooley’s non-degeneracy conditions, namely that ")#mi("f(x,y)-T")#text(" is generically geometrically irreducible, and for any given ")#mi("t")#text(", ")#mi("\\{ (x,y): f(x,y)-t\\}")#text(" is a curve. We also assume that for any ")#mi("x")#text(", the function ")#mi("y \\mapsto f(x,y)")#text(" is non-constant. Then I need the function ")#mi("K(x) = \\frac{1}{\\sqrt{p}} \\sum_y e_p(f(x,y))")#text(" to be expressible (after tweaking by an error of ")#mi("O(p^{-1/2})")#text(") as a pure middle extension trace weight of bounded conductor whose sheaf contains no geometrically trivial component. (I think I also need the sheaf to be arithmetically semisimple, but I understand that one can reduce to this case automatically?)")

#text("For our specific application we have an explicit form ")#mi("f(x,y) = \\frac{a}{y(x+y)} + hy + cx^2 + dx")#text(" of the rational function, but presumably this will not be too helpful (although it does allow one to verify Hooley’s criteria by ad hoc means).")

#text("Using Michel’s method of proceeding via the companion sums I think I can at least get the “no geometrically trivial” part of this claim, but not the boudned conductor claim. Namely,")

#text("If we set")

#mi("K_n(x) := \\frac{1}{p^{n/2}} \\sum_{y \\in {\\Bbb F}_{p^n}} e_p( \\text{Tr}( f(x,y) ) )")

#text("then I think Hooley’s argument shows that the sum")

#mi("\\sum_{x \\in {\\Bbb F}_{p^n}} K_n(x) = \\frac{1}{p^{n/2}} \\sum_{x,y \\in {\\Bbb F}_{p^n}} e_p( \\text{Tr}( f(x,y) ) )")

#text("takes the form")

#mi("-\\alpha_1^n - \\ldots - \\alpha_k^n + \\beta_1^n + \\ldots + \\beta_l^n")

#text("for some bounded number of complex numbers ")#mi("\\alpha_i, \\beta_j")#text(" of modulus at most ")#mi("p^{1/2}")#text(" (these weights are also algebraic integers divided by ")#mi("\\sqrt{p}")#text(", but this does not seem to be exploitable information). Presumably the pushforward (or direct image) construction ensures that the ")#mi("K_n")#text(" are the companion sums for the sheaf associated to ")#mi("K")#text(" (possibly up to a sign correction ")#mi("(-1)^{n-1}")#text("), which would then imply that these ")#mi("\\alpha_i,\\beta_j")#text(" must then be the weights for that sheaf after allowing for cancellation. In particular, the H^2 of this sheaf cannot contain any weights of magnitude ")#mi("p")#text(", as these cannot be canceled out by the ")#mi("H^1")#text(" weights, so this should imply that the sheaf has no geometrically trivial component. This argument almost controls the dimension of ")#mi("H^1")#text(" as well, except that there could potentially be ")#mi("H^1")#text(" weights of magnitude 1 rather than ")#mi("p^{1/2}")#text(" that get cancelled by the ")#mi("H^0")#text(" weights (or are we in a situation where we can assume that the weights in ")#mi("H^j")#text(" have magnitude exactly ")#mi("p^{j/2}")#text(" rather than being bounded above by ")#mi("p^{j/2}")#text("? I am a little confused as to which weights we can assume to be pure instead of mixed in this business.)")

#text("As you say, this is a fairly roundabout way to do things – presumably there is a geometric way to deduce vanishing of the H^2 of the pushforward sheaf in terms of vanishing of the H^3 of the original two-dimensional sheaf, which in turn should be deducible from geometric methods rather than by Hooley’s analytic argument. (This still doesn’t help with the problem of controlling the Swan conductor though.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240626")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2013")])]

#text("It occurs to me that one possible way to get a “soft” bound for the Swan conductor that is uniform in p is to take an ultraproduct in p and work with l-adic sheaves over a pseudo-finite field rather than a finite field, as is discussed in ")#link("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")[#text("https://terrytao.wordpress.com/2010/01/30/the-ultralimit-argument-and-quantitative-algebraic-geometry/")]#text(" . The key technical thing to check is that Swan conductors are continuous with respect to ultraproducts, and also that the pushforward (or direct image) operation on sheaves commutes with ultraproducts. This would require a certain amount of delving into the finer points of sheaf cohomology, but this might possibly be worthwhile for other applications than bounded gaps between primes because once these sorts of regularity properties of ultraproducts are set up, one usually gets uniformity with respect to choice of coefficients or of base field more or less for free.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240656")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2013")])]

#text("Actually, I think the Swan conductors can be bounded in many cases by using again the Bombieri bounds for sums of Betti numbers.")

#text("Assume the constructed sheaf parameterizing the exponential sums does not contain the trivial representation and in fact is pure of weight 0 (at least for the moment.)")

#text("Basically, up to quantities one knows how to bound, the sum of Swan conductors is bounded by the Euler-Poincaré characteristic which is bounded by the sum of Betti numbers. At least if the H^1 is pure of weight 1, we can then get at its dimension as the limsup of")

#text("Tr( global Frobenius of F_q | H_1)")

#text("where q =p^k —> infinity. But this trace is (by definition of the sheaf and the trace formula) the q-companion sum of the original 2-variable character sum, and its expression as a sum of Weil numbers is controlled by the zeta function of these, whose number of roots is bounded by Bombieri (and/or Adolphoson — Sperber and/or Katz’s bounds on Betti numbers.)")

#text("(I suspect this is very likely just a “concrete” version of a spectral sequence argument…)")

#text("What I don’t know is how to do this for a general “transformation” with kernel psi(f(x,y)), i.e., bounding the conductor of")

#text("L(x)=sum_y K(y) psi(f(x,y))")

#text("in terms of the conductor of K and invariants of f, if K is not a rank 1 sheaf itself.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240658")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2013")])]

#text("Typos: in the limsup, one must divide by sqrt(q), of course.")

#text("Also the sums of Betti numbers are not the same at the beginning of the third paragraph (where I refer to the sheaf parameterizing the one-variable sum) and at the tend (where they refer to the 2-variable Artin-Schreier sheaf…)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240706")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2013")])]

#text("Great! So it seems that the only remaining issue is to ensure purity of the H^1 of the sheaf representing the sum ")#mi("x \\mapsto \\sum_y \\psi(f(x,y))")#text(". (Presumably H^2 is automatically pure, so it should not be difficult to show that this sheaf has no geometrically trivial component if Hooley’s criteria for full square root cancellation in ")#mi("\\sum_{x,y} \\psi(f(x,y))")#text(" applies.) Would one have to try to use Poincare duality here? (But there is this distinction between cohomology and cohomology with compact supports that I don’t understand…)")

#text("p.s. I’m going on vacation starting today, so am going to have much slower response times for a while.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240710")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 3 August 2013")])]

#text("I will try to write down the argument carefully (and in suitable generality) in the next few days. Local purity has the advantage of being a pointwise property, and hence should be understandable (in that case) from properties of one variable character sums.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241693")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2013")])]

#text("Actually, it seems that one can also estimate the conductor for sum_y K(y) psi(f(x,y)) in some decent amount of generality, using similar ideas. We (FKM) are preparing a note on this.")

#text("If it works out in sufficient generality, this might lead to a bound for the conductor of the Fourier transform which does not require Laumon’s deep theory of local Fourier transforms. (But it is not yet clear that this will indeed work…)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241804")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2013")])]

#text("That’s great news! Modulo some checking of the remaining steps of the argument, I think this would be the only thing needed to complete the proof of the improved Type I estimate of this blog post.")

#text("Given the slowdown in activity in the last month or so, it looks to me like we have reached the stage where we should “declare victory” and start turning attention to the writing up of the results we have, and hopefully others in the future will be able to build further upon what we’ve done (or maybe find some dramatically different approach to these problems). Thanks to the modular nature of the argument, I think we can pull off a single paper that manages to contain both sides of the tradeoff between simplicity and optimality, e.g. containing the proof of both the improved Type I estimate that uses all the ell-adic cohomology theory, as well as the somewhat easier Type I estimate that “only” requires the Weil conjectures for curves, and similarly for a few other components of the argument. I can try to draft up a skeleton of what such a paper might look like and put it online for discussion.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241810")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2013")])]

#text("Just one question about that: how confident are the experts that k0 cannot be nudged down to 631? The difference to H is of course very slight compared to the strides achieved by each improvement made to varpi, but since the key headline of the paper will presumably be what H has been achieved, I would presume that there is quite a lot of value in being able to make a strong case that the advertised k0 really is the best that can be extracted from the best varpi/delta combination. I raise this partly because Eytan Paldi indicated two weeks ago that he had a potential improvement but then did not make further comment, and also because xfxie was historically leading the k0 charge but has not commented for a long while.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d25ededd92f44459c35afd4612e04350b852a7d8e15c0afe790fe277bdf66043-d0154497157a33220cedebb526e0afa9f871211603a104a064fdbd0b3f2dc363.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of xfxie")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241834")[#strong[#text("xfxie")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2013")])]

#text("@Aubrey: I just did some modifications on my code to handle the changes in Terence’s new maple code ( ")#link("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239872")[#text("https://terrytao.wordpress.com/2013/07/07/the-distribution-of-primes-in-doubly-densely-divisible-moduli/#comment-239872")]#text(" ) — I did not comment for a while since I was too lazy to make the necessary modifications as I was busy in catching up a deadline during that time period.")

#text("The code did find some other solutions for ")#mi("k_0")#text("=632 (Just put one of them to the ")#mi("k_0")#text(" table: ")#link("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")[#text("http://www.cs.cmu.edu/~xfxie/project/admissible/k0table.html")]#text(" ). However, for ")#mi("k_0")#text("=631, it cannot find a feasible solution in three runs — all three runs ended at a similar minimum value around (eps2-eps)=4.00414E-5. So it is highly possible that the solutions found by Terence and Gergely are already optimal for the current problem setting.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241903")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2013")])]

#text("Concerning Aubrey’s question, note that the criterion is")

#mi("2(\\kappa_1 + \\kappa_2 + \\kappa_3) < \\epsilon")#text(" .")

#text("Using the constraint on ")#mi("\\varpi , \\delta")#text(", we may express the best")#linebreak()#text(" ")#mi("\\varpi")#text(" as ")#mi("\\varpi = 7/600 - 0.3 \\delta")#text(", implying the following expressions for ")#mi("\\epsilon (k_0)")#text(" as a function of ")#mi("\\delta")

#mi("\\epsilon (632) = 1.1633024 \\times 10^{-4}  - 1.14636 \\delta                                        - 1.31436 \\delta ^2 - ...")

#mi("\\epsilon (631) = 7.09086 \\times 10^{-5} - 1.14642 \\delta                                       - 1.31436 \\delta ^2 - ...")

#mi("\\epsilon (630) = 2.53689 \\times 10^{-5} - 1.14647 \\delta                                       - 1.31442 \\delta ^2 - ...")

#mi("\\epsilon (629) = -2.02893 \\times 10^{-5} - 1.14652 \\delta                                      -1.31448 \\delta ^2 - ...")

#text("Therefore ")#mi("k_0 \\geq 630")#text(". For ")#mi("k_0 = 632")#text(" and Gergely's parameters ")#mi("\\delta = 10^{-4}, \\delta^{\\prime} = 1/105 , A = 200")#text(", we see that")#linebreak()#text(" ")#mi("\\epsilon \\approx 1.68 \\times 10^{-6}")#text(".")#linebreak()#text(" ")#mi("2 \\kappa_1 \\approx  1.29 \\times 10^{-6}")#text(" – which is much larger than")#linebreak()#text(" ")#mi("2 \\kappa_2 \\approx 3.50 \\times 10^{-9}")#text(" and")#linebreak()#text(" ")#mi("2 \\kappa_3 \\approx 1.40 \\times 10^{-7}")#text(".")#linebreak()#text(" It seems that the ")#mi("\\kappa")#text("'s are not \"too sensitive\" to small changes in")#linebreak()#text(" ")#mi("k_0")#text(", so the best strategy for ")#mi("k_0 = 631")#text(" (or even ")#mi("k_0 =630")#text(") seems to increase ")#mi("\\epsilon(631)")#text(" (which is negative for the current value of ")#mi("\\delta")#text(") by sufficiently decreasing ")#mi("\\delta")#text(" (but not too much – to keep ")#mi("\\kappa_3")#text(" sufficiently small) and by sufficiently decreasing ")#mi("\\kappa_1")#text(" (by slightly increasing ")#mi("\\delta^{\\prime}")#text(" and thereby ")#mi("\\theta")#text("). It seems that ")#mi("\\kappa_2")#text(" is \"too small\" to cause any problem. To get some feeling of the dependence of the current upper bound of ")#mi("\\kappa_1")#text(" on ")#mi("\\delta^{\\prime}")#text(", observe that integration by parts of this (integral) bound gives")

#mi("\\kappa_1 < (1 - \\theta)^{(k_0+1)/2} /((k_0 + 1) \\theta /2)")

#text("Note that ")#mi("\\theta")#text(" depends on ")#mi("\\delta^{\\prime}")#text(",. It follows that by slightly increasing ")#mi("\\delta^{\\prime}")#text(" to ")#mi("1/90")#text(", the last upper bound on")#linebreak()#text(" ")#mi("\\kappa_1")#text(" (for ")#mi("k_0 = 631")#text(") becomes")#linebreak()#text(" ")#mi("1.651 \\times 10^{-7}")#text(" – a dramatic reduction!")

#text("Therefore, it may be possible to get ")#mi("k_0 = 631")#text(" (or even")#linebreak()#text(" ")#mi("k_0 = 630")#text(".)")

#text("Remarks:")

#text("1. I found an improvement to the current upper bound on ")#mi("\\kappa_1")#text(" but unfortunately it seems to be numerically very minor one (few percents) so it is much better to use the above strategy of increasing ")#mi("\\delta^{\\prime}")#text(" to sufficiently reduce ")#mi("\\kappa_1")#text(" (Anyway, I intend to send this improvement in my next comment.)")

#text("2. It is possible that the current bound of ")#mi("\\kappa_1")#text(" (via the current bound of its integrand ")#mi("G_{k_0 - 1} (0, t)")#text(") is quite crude (using only the fact that the function ")#mi("f")#text(" is decreasing on ")#mi("[0, 1]")#text(".) But one can exploit this monotonicity to get tight lower and upper numerical bounds for ")#mi("\\kappa_1")#text(" and its integrand – via corresponding lower and upper Riemann sums!")

#text("3. The current bound on ")#mi("\\kappa_3")#text(" seems also to be quite crude. (the parameter A should be optimized – perhaps even for each dimension J – in its original formulation). It is interesting to note that a lower bound on ")#mi("\\kappa_3")#text(" is given by the G-ratio (the coefficient in front of the exp.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242193")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("Thank you Eytan. In passing, I’m also wondering whether the current Deligne-avoiding k0 of 1788 can be nudged down, though of course this is of more marginal interest to most observers than the headline 632 value.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d787948edf428911d8b15ad79b5f5085d83001cfe16cd3db1271d4701eef37f7-a4fe3e4cef12b0aa6c1709a44ed2b22bfbaf63fff877ed122b527744c8866059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin Maulhardt")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240878")[#strong[#text("Martin Maulhardt")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2013")])]

#text("Dear Mr Tao and Mr Harcos.")

#text("In connection with the papers you have suggested me to read, I have proved that there are infinitely many 4-tuples of consecutive primes of the form (Pk, Pk+1, Pk+2, Pk+3) where each dn+1 <= dn. An example is (31,37,41,43) and that this property is true for any finite length. This was the (still open) question raised by Erdos and Turan at the end of the paper Mr Harcos kindly provided.")#linebreak()#text(" I would be honored if you could take a look at my work on the address below and hope this might help you to continue the great work you (and others) are doing lowering the bound on Zhang's theorem.")#linebreak()#text(" ")#link("http://martinmaulhardt.com/?page_id=91")[#text("http://martinmaulhardt.com/?page_id=91")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/50cba2e9c408e910707e78607d5fa520fe0cea446c54f61f9256ed4d26e2a4e8-1b334582728ce27f74ba8f244ef4f8b72d76acc720a244f3f37dae6f2012b3d1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Fan")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241612")[#strong[#text("Fan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2013")])]

#text("I hate to point out that the gist of Erdos’s result is the *strict* inequality ")#mi("p_{n+2} - p_{n+1} < p_{n+1} - p_n")#text(" i.o. (and similarly for the conjecture of three consecutive differences). The *non-strict* inequality can be obtained by very crude versions of PNT, e.g. Chebyshev's bound ")#mi("\\pi(x) \\asymp x")#text(",")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d787948edf428911d8b15ad79b5f5085d83001cfe16cd3db1271d4701eef37f7-a4fe3e4cef12b0aa6c1709a44ed2b22bfbaf63fff877ed122b527744c8866059.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of martin maulhardt")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241621")[#strong[#text("martin maulhardt")]]#text(size: 9pt, fill: rgb("596477"), " · 11 August 2013")])]

#text("Dear Fan,")#linebreak()#text(" Thanks very much for your comment. I didn’t know it was so trivial with non strict inequality. So the only value of my work is the elementary proof of this (non strict) inequalities. Do you know if the generalization I made : the inequalities between “even indexed” consecutive primes (P2k+4 – P2k+2 <= P2k+2 – Pk) satisfied infinitely many times are already known too? (they are proved on theorem 4 of my work).")#linebreak()#text(" If you (or anyone) know if this generalization already exists I would truly appreciate the information. If you think I can somehow return the help please let me know.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91e58d71f0f6fed623003aa05efe0585d16ef93ffa28f35566bfb61f50623ecf-2a8a45a0582c8ce83139ff9a7a2fcc83164146aeb54123a9d43b62b9f617bd50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abqmathteacher")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240891")[#strong[#text("abqmathteacher")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2013")])]

#text("In a practical context, I’ll note that, according to equation (1) on p. 5 of Soundararajan’s Bulletin review article, one expects gaps as large as 4680 to start to show up (but of course still be unusually large) for primes around 10^28, which is very small by cryptographic standards. Even just using PNT, gap size 4680 will be _average_ for primes around 10^2000 = 2^6750. Note that “An RSA key length of 3072 bits should be used if security is required beyond 2030” (Wikipedia), and one would expect gap size 4680 to at least not be unusual by that point. So by a certain stretch of the imagination—say, to a cryptographer working in 2040—4680 really could be seen as a “smallish” prime gap. Nice!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240919")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 August 2013")])]

#text("Abqmathteacher, the bounded gap theorem doesn’t say anything about the expected gap between primes at arbitrary places. It just says that starting anywhere, if you keep searching upwards “forever”, you’ll eventually find a pair of primes separated by less than H. Remember H=4680 is just the best bound proved so far, but the problem inspiring all this work is actually to prove H=2. The expected gap at any particular place still gets arbitrarily large.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/91e58d71f0f6fed623003aa05efe0585d16ef93ffa28f35566bfb61f50623ecf-2a8a45a0582c8ce83139ff9a7a2fcc83164146aeb54123a9d43b62b9f617bd50.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of abqmathteacher")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-240955")[#strong[#text("abqmathteacher")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2013")])]

#text("@Anonymous, you misunderstand me; sorry I didn’t spell it out more in my original comment. My point is that the original Zhang result of H=70,000,000, while theoretically groundbreaking, is a little underwhelming psychologically. A result that says “small [in some sense] gaps between primes recur infinitely often” is more impressive than one that just says “a certain finite [but rather large] gap or smaller recurs infinitely often”. (Isn’t that partly the point of this polymath project?) Clearly H=2 qualifies as (amazingly) small; H = 70,000,000 is rather large since one has to consider quite large primes before that qualifies as even an attainable gap, much less average, much less “small”. I was pointing out that H = 4680, while not obviously “small”, could be seen as such from a certain viewpoint, and I wanted to congratulate the project on getting to that point.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241916")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2013")])]

#text("I’ve started an extremely minimal skeleton of a paper at")

#strike[#link("https://www.dropbox.com/sh/vmu141rph1xjqa0/buJWUGtsLD/Polymath8/newgap.pdf")[#text("https://www.dropbox.com/sh/vmu141rph1xjqa0/buJWUGtsLD/Polymath8/newgap.pdf")]]

#link("https://www.dropbox.com/s/16bei7l944twojr/newgap.pdf")[#text("Click to access newgap.pdf")]

#text("(with the source files available at ")#strike[#link("https://www.dropbox.com/sh/vmu141rph1xjqa0/buJWUGtsLD/Polymath8/")[#text("https://www.dropbox.com/sh/vmu141rph1xjqa0/buJWUGtsLD/Polymath8/")]]#text(" ")#link("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/_5Sn7mNN3T")[#text("https://www.dropbox.com/sh/j2r8yia6lkzk2gv/_5Sn7mNN3T")]#text(" )")

#text("At this point there is no actual maths in the paper, just a proposed section outline. I’ve used the latest values of H in the headline results but of course this can be easily updated if there are further developments.")

#text("Once we agree on the general section structure, perhaps the next thing to discuss is the notation used (e.g. for the claims DHL, MPZ, etc.); I would default to the notation that has been developed in the course of this project, but it should be easy to change if needed. (I will try to use macros for some of the more complicated notation, so that changing that notation can be done in a single line of LaTeX code.)")

#text("If anyone is interested in helping edit the files, let me know and I will see if I can share the Dropbox folder. (Certainly I will need help on writing at least two sections of the paper, namely the narrow prime tuples section and the Deligne theory section. For most of the other sections, I can draw from previous blog posts to write a first draft at least.)")

#emph[#text("[Dropbox files moved, to deal with the problem that dropbox files in the public folder cannot be shared. -T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dba4d4cf121d7684f0fd9be39346569cfc4ca9ca4e1d08a8f2ac118268e99b6e-ba5d3048b321b01053be4dbfc78a700cf8233cc951157c20bdd8a6423fd90435.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AndrewVSutherland")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241951")[#strong[#text("AndrewVSutherland")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2013")])]

#text("I can help with the narrow prime tuples section.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241998")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2013")])]

#text("Great! It should hopefully be not too hard to write, as one can already crib a lot from your blog post over at ")#link("http://sbseminar.wordpress.com/2013/07/02/the-quest-for-narrow-admissible-tuples/")[#text("http://sbseminar.wordpress.com/2013/07/02/the-quest-for-narrow-admissible-tuples/")]#text(" as well as from the wiki.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241979")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2013")])]

#text("In the main theorem, ")#mi("k_0")#text(" should be ")#mi("H")#text(".")

#emph[#text("[Corrected, thanks! -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67f6d558925f1807ad6fbdbcef237b8423309c57eabb757040f5d718dec4027f-3f01cbe21c342dbc7f48f28bb11fff0171d02bb44e31ed5a1744dcee37dcaacf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pigh3")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242012")[#strong[#text("pigh3")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2013")])]

#text("RIght after Thm 2.2, Zhang’s original paper had ")#mi("k_0=3500000")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242045")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 15 August 2013")])]

#text("I ll be happy to help")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242056")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")])]

#text("You could set up a git repository instead of dropbox, so that people could work on their own versions of the files and git can pull patches from them. I’m not a fan of github but it has very nice collaboration tools for this sort of thing beyond git itself.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2dd5a589f6a7aab46805e591406f1d392d985b3f14124850ced7ba1a6f699af2-ca24d4d37b3b811e9c9bda5ddb8acd16eb2f654891e6f0750abdd86742afe09e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Philippe Michel")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242083")[#strong[#text("Philippe Michel")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")])]

#text("Maybe this is a good time to start a fresh new post devoted to the effective writing of the paper (or to decide of an different way to proceed) to share views and ideas on how redaction should be done.")

#text("Needless say I am in for helping on the writing Deligne/exponential sum section(s) and probably for other parts as well.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242107")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2013")])]

#text("That’s a good idea, and thanks for offering to chip in! It may take a while before we get to the point where we can start writing seriously the Deligne stuff (it depends to some extent on how your writeup with Emmanuel and Etienne on the conductor bounds for pushforward sheaves turns out) but this is certainly something to discuss in the next post. I’ll try to set something up in a day or two (I’m hopping on a plane in a few hours).")

#text("Regarding alternatives to dropbox, I am familiar with Subversion, and with a lesser extent with Git, but the learning curve (particularly for the latter) is steeper with that for Dropbox, and for the fairly limited task we have at hand (writing a single paper) I think these more advanced version control platforms may be overkill. Of course, one pays a price for this, which is that Dropbox has more difficulty dealing with conflicts in which two people are trying to edit the same file. But I think we can coordinate this through the blog; I have split the paper up into one file for each section, and if people announce what section they are working on, one should be able to avoid serious conflicts in practice (particularly if we try to only modify the Dropbox files while connected to the internet). For instance, I am going to be working more or less exclusively on Section 2 (“Key subclaims”, or subtheorems.tex) for the next day or two to try to organise the overall logic, which of course we should also discuss in the next post.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2796b1de39cfcfed3b4edf4f232605d7330e2b4918df23e752addabe5684256d-0f9c03df6f3de5e30ef7c47ad588c3ff8ae6901f58e2effac1cd8acbb730ded1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Emmanuel Kowalski")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242169")[#strong[#text("Emmanuel Kowalski")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("I will also participate of course. I’ll also use my own subversion setup independently of the Dropbox, so this might also help limit any possible difficulties with editing conflicts.")

#text("I will probably sketch the conductor bound in a blog post next week. Interestingly, it really turns out to be better to proceed with the algebraic analogue of the companion sum argument, although the latter certainly gives the right idea of what is going on.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-241925")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 August 2013")])]

#text("Typographical comment on the paper: If you load the siunitx package (")#link("http://ctan.org/pkg/siunitx")[#text("http://ctan.org/pkg/siunitx")]#text("), you can write $H = \\num{70000000}$ and get the correct output for the large number. (What you have now doesn’t look too good, I think.)")

#emph[#text("[Change made, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Polymath8: Writing the paper | What's new")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-242165")[#strong[#text("Polymath8: Writing the paper | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2013")])]

#text("[…] some discussion at the previous post, we have tentatively decided on writing a single research paper, which contains (in a reasonably […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-248876")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("A question aside (maybe it was already asked in the previous threads):")#linebreak()#text(" Can the proof be generalized to arithmetic progressions ak+b, gcd(a,b)=1 ? That is, are there infinitely many pairs of primes at a distance at most Nb in such progression?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-248877")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("I meant at a distance Na.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-248878")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 October 2013")])]

#text("Yes, this should be the case; I currently have a graduate student checking the details of this. (One slight issue here is that whereas the original argument requires distribution results only for squarefree moduli, the extension to ak+b requires distribution results for moduli which are the product of a and a squarefree number, and so one needs a very slight generalisation of the existing distribution results. But this appears to only be a minor technical difficulty.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-251590")[#strong[#text("Math Blog Snippet | the Cyclic Grizzly")]]#text(size: 9pt, fill: rgb("596477"), " · 18 November 2013")]

#text("[…] He uses the Tarski theme with a modified CSS (to do things such as boxed theorems). As stated on his About page, he uses Luca Trevisan’s LaTeX to WordPress converter to write his more mathematically intensive posts. Above, you’ll see an example of how he uses LaTeX on his blog, excerpted from the post “An improved Type I estimate.” […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2013/07/27/an-improved-type-i-estimate/#comment-498610")[#strong[#text("Math Blog and how to write math equations using LaTeX $latex…$ | Adonis Diaries")]]#text(size: 9pt, fill: rgb("596477"), " · 16 May 2018")]

#text("[…] As stated on his About page, he uses Luca Trevisan’s LaTeX to WordPress converter to write his more mathematically intensive posts. Above, you’ll see an example of how he uses LaTeX on his blog, excerpted from the post “An improved Type I estimate.” […]")
]
