// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/
// Converted to Typst by tao2typ: "2026-10-14T08:51:05.473109+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A demonstration of the non-commutativity of the English language", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A demonstration of the non-commutativity of the English language")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 26 December 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/")[#text("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("This will be a more frivolous post than usual, in part due to the holiday season.")

#text("I recently happened across the following video, which exploits a simple rhetorical trick that I had not seen before:")

#text("If nothing else, it’s a convincing (albeit unsubtle) demonstration that the English language is non-commutative (or perhaps non-associative); a linguistic analogue of the ")#link("https://terrytao.wordpress.com/2009/10/05/mazurs-swindle/")[#text("swindle")]#text(", if you will.")

#text("Of course, the trick relies heavily on sentence fragments that negate or compare; I wonder if it is possible to achieve a comparable effect without using such fragments.")

#text("A related trick which I have seen (though I cannot recall any explicit examples right now; perhaps some readers know of some?) is to set up the verses of a song so that the last verse is identical to the first, but now has a completely distinct meaning (e.g. an ironic interpretation rather than a literal one) due to the context of the preceding verses. The ultimate challenge would be to set up a Möbius song, in which each iteration of the song completely reverses the meaning of the next iterate (cf. ")#link("http://xkcd.com/381/")[#text("this xkcd strip")]#text("), but this may be beyond the capability of the English language.")

#text("On a related note: when I was a graduate student in Princeton, I recall ")#link("http://en.wikipedia.org/wiki/John_Horton_Conway")[#text("John Conway")]#text(" (and another author whose name I forget) producing another light-hearted demonstration that the English language was highly non-commutative, by showing that if one takes the free group with 26 generators ")#mi("a,b,\\ldots,z")#text(" and quotients out by all relations given by anagrams (e.g. ")#mi("cat=act")#text(") then the resulting group was commutative. Unfortunately I was not able to locate this recreational mathematics paper of Conway (which also treated the French language, if I recall correctly); perhaps one of the readers knows of it?")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42918")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("Larry Washington had that paper on his door when I was an undergraduate at College Park. It actually shows that the group generated by the 26 letters is ")#emph[#text("trivial")]#text(" when you mod out by ")#emph[#text("homophones")]#text(" in English. That is, since “lead” and “led” are pronounced the same (or can be), we set ")#mi("lead=led")#text(". Cancellation shows that ")#mi("a=1")#text(".")

#text("The nifty thing was that they wrote this paper in French, and they ")#emph[#text("also")]#text(" wrote up the same result using French homophonies in English, and published them in parallel columns.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42919")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("Actually, here it is: ")#link("http://www.emis.de/journals/EM/restricted/2/2.3/mestre.ps")[#text("http://www.emis.de/journals/EM/restricted/2/2.3/mestre.ps")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42921")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("Thanks! I think my memory is playing tricks on me, though, and conflating two papers together. One is the homophone one you linked to; and there is another which I feel certain John Conway is associated with somehow, and which has something to do with anagrams.")

#text("Coincidentally, Larry Washington was my RSI mentor back in ’89…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42920")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("The video reminds me of the “Crab Canon” in ")#emph[#text("Godel, Escher, Bach")]#text(", which can also be read either forwards or backwards. (I think that’s the title; certainly there is a dialogue in the book with this property.)")

#text("I agree that it’s the non-commutativity of English demonstrated in the video, although of course the language isn’t associative either; there’s a throwaway joke in ")#emph[#text("Arrested Development")]#text(" taking advantage of this.")

#text("George Michael: My girlfriend Ann wants to have a Christian music bonfire here.")

#text("Michael: That sounds like some mild fun. I think we’ve got some Christmas music.")

#text("George Michael: Oh no, it’s not a “Christian music” bonfire. It’s a Christian “music bonfire.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24855c000459d469521dac1d33b7604ae613422dbb1568aecc5012386c434551-a2aef3bbf99bc1616122b299b154330ada3b9839c53565e3a9927d35881dc70a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Steve Flammia")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42922")[#strong[#text("Steve Flammia")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("Here is a link to a YouTube video which visualizes the Crab Canon by playing the music on a Moebius strip; it may be of interest.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sakura-Chan")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42926")[#strong[#text("Sakura-Chan")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("And how Maeby said it was a CD burning party. =D")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/708a19b98d9377bcb7b2f13011a7b4633ce1d9b5e9056f7cb6221ea0edf8d3e6-4778ea023a7a611b30d1fcb0af554348005b021f887a9dacc21e1f2ff23e479d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mike")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42923")[#strong[#text("mike")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("This video reminds me of the final level of Braid, a video game about time and saving a princess. In the game, the player can reverse time arbitrarily and without limit, and the time flows of objects are often either decoupled from each other or dependent on one another in interesting ways.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42925")[#strong[#text("Initiative » Blog Archive » Lost generation … or not?")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")]

#text("[…] read this amazing A demonstration of the non-commutativity of the English language on Terry Tao’s […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/032a5d148624d93070a005a38eea318b012ec736fca0469f9748d898469534db-822c0a1e2169bf75e28d5bf33d3e442d6e70ab99bb00f46fd5742c785f76afbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rose")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42927")[#strong[#text("Rose")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("Well,something unimportant, I’ve read your book which is written 17years ago, and I felt one thing: how could you read so many books that I haven’t seen before?? And these book cannot be found on the Internet now. Those books are really perfect.")#linebreak()#text(" I live in China and I want to read more. so can you tell me how can i find them or something else like them???? THANKS A LOT!!!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/032a5d148624d93070a005a38eea318b012ec736fca0469f9748d898469534db-822c0a1e2169bf75e28d5bf33d3e442d6e70ab99bb00f46fd5742c785f76afbc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rose")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42928")[#strong[#text("Rose")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("I think something like")#linebreak()#text(" Taylor 1989")#linebreak()#text(" Australian Methematics Competition 1987")#linebreak()#text(" Taylor 1987")#linebreak()#text(" Hajos")#linebreak()#text(" Shklarshy")

#text("Where can i find them ~~")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42960")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("I haven’t read Prof Tao’s book, so I’m not sure, but I’m guessing that similar books can be found here:")

#link("http://www.amtt.com.au/Home.php")[#text("http://www.amtt.com.au/Home.php")]

#link("http://www.amtt.com.au/documents/Pubsform2009.pdf")[#text("Click to access Pubsform2009.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/01ca781fd2282d3901c386bc583ebdf605c33f881197de7de490d0a8bbf45f91-eb1e92166f0b41343a064883c9f0e9a797c26d108525e401a3786eae9f2b2cc7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of BK Drinkwater")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42929")[#strong[#text("BK Drinkwater")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2009")])]

#text("The most spectacular examples in poetry are pantoums, where the second and fourth lines of each quatrain become the first and third of the next.")

#text("They’re ferociously difficult to write, so I won’t give an example of my own for fear of humiliation; rather, a link to Curnow: ")#link("http://www.ablemuse.com/erato/showthread.php?t=751")[#text("http://www.ablemuse.com/erato/showthread.php?t=751")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6981bafa5401060b1fd62a1bc81b103edb76feede94a0ca698b45526eddfd311-693d48fd4da572b496ecc1cdc44c234374b12046c456d3490a00eeb591c4c9d6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42931")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("A long time ago, it was a tv-spot (in greek) which was something like Professor Tao’s video. You could read in a way and vice-versa. And something I noted then, was that in one direction the ”sense” to the audience was not so bad, but when the speaker read the message backwards, everything was different. So, I suppose that and the greek language is not commutative.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Peake")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42932")[#strong[#text("Michael Peake")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("The Rec.puzzles archive contains the second question here")

#link("http://www.faqs.org/faqs/puzzles/archive/language/part2/")[#text("http://www.faqs.org/faqs/puzzles/archive/language/part2/")]

#text("and contains a reference to your original question in the American Mathematical Monthly, Vol. 93, Num. 8 (Oct. 1986), p. 637")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42933")[#strong[#text("Thomas")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("Only I hit him in the eye yesterday.")#linebreak()#text(" I only hit him in the eye yesterday.")#linebreak()#text(" I hit only him in the eye yesterday.")#linebreak()#text(" I hit him only in the eye yesterday.")#linebreak()#text(" (I hit him in only the eye yesterday.)")#linebreak()#text(" (I hit him in the only eye yesterday.)")#linebreak()#text(" I hit him in the eye only yesterday.")#linebreak()#text(" I hit him in the eye yesterday only.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PIERRE")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42935")[#strong[#text("PIERRE")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("Would that work with the French language?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bda1ef7a039cb7a56103f45dca37ee484528454fceaf575ca61b8070432fc46f-fad3c0521a971bd33a18b303957d4fcfcdfd2b2a8242a4507763b229c164ceef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Long")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42936")[#strong[#text("Chris Long")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("Terry,")

#text("As noted, there are two related puzzles involving the free group on the 26 letters. The first is to show that the group is trivial if you use homophones for equivalences, the second is to identify the center of the group if you use anagrams for equivalences. The first is rather simple (the solution in the rec.puzzles FAQ is actually mine, in fact); the second is much more difficult and involves the issue of which words are acceptable. Using rather strict rules, David Moews, myself and others working together managed to get it down to just a few pairs of letter that did not commute (the usual suspects). Conway, Sahi and Feit have written a paper on this problem, so you are not remembering incorrectly. See the discussion at: ")#link("http://groups.google.com/group/sci.math/browse_thread/thread/6e79a09657499256/b1260dec7eacc819")[#text("http://groups.google.com/group/sci.math/browse_thread/thread/6e79a09657499256/b1260dec7eacc819")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bda1ef7a039cb7a56103f45dca37ee484528454fceaf575ca61b8070432fc46f-fad3c0521a971bd33a18b303957d4fcfcdfd2b2a8242a4507763b229c164ceef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Long")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42937")[#strong[#text("Chris Long")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("There’s another relevant discussion at: ")#link("http://groups.google.com/group/rec.puzzles/browse_thread/thread/1ef8a13583b18395/e5a50b0cf7190520")[#text("http://groups.google.com/group/rec.puzzles/browse_thread/thread/1ef8a13583b18395/e5a50b0cf7190520")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42938")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("I’d say that the video demonstrates the non-commutativity. But non-associativity is beautifully demonstrated by certain poems, where you can group the lines in different ways and get completely opposite meanings. I’ve seen examples, but can’t immediately lay my hands on one. But if I manage to find one I’ll write another comment.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00d42bc6375c491a25232983a115f62976587f827a3756ae3bbfa9ed57c57709-ead29ea7d1f6b02d838b61cb7b214d3d06c1a4117da1e54dff7a0a33251caf72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Comenetz")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42956")[#strong[#text("Michael Comenetz")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("I saw a Peacock with a fiery tail,")#linebreak()#text(" I saw a blazing Comet drop down hail,")#linebreak()#text(" I saw a Cloud with ivy circled round,")#linebreak()#text(" I saw a sturdy Oak creep on the ground,")#linebreak()#text(" I saw a Pismire swallow up a whale,")#linebreak()#text(" I saw a raging Sea brim full of ale,")#linebreak()#text(" I saw a Venice Glass sixteen foot deep,")#linebreak()#text(" I saw a Well full of men’s tears that weep,")#linebreak()#text(" I saw their Eyes all in a flame of fire,")#linebreak()#text(" I saw a House as big as the moon and higher,")#linebreak()#text(" I saw the Sun even in the midst of night,")#linebreak()#text(" I saw the Man that saw this wondrous sight.")

#text("Anon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42976")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("That’s not the poem I was thinking of, but it’s the genre all right.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stephen")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42940")[#strong[#text("Stephen")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("My favourite example of non-commutativity in english sentences is")

#text("“only” [verb] != [verb] “only”")

#text("as in")

#text("“he only saw her” != “he saw only her”")

#text("Of course, “The Man Who Loved Only Numbers” is a carefully correct use of [verb] “only”, but not everyone is so careful.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a70bb7060e971a779144b627f5b33a4ec8983c8fbf836fef6454d7801e549d11-b79b37b1b3204e6eb074164bcbbe75d92edde7c41f35d2480abf8f40b37971e8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boris")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42941")[#strong[#text("Boris")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("Hi Terry,")

#text("John Armstrong and Chris Long have mostly answered your last question, but I thought I’d add what I remember. As a current graduate student at Princeton, I also heard about the anagram group question from Conway. My recollection is that this was a pastime that he engaged in at Cambridge, where they kept a big sheet of paper with all of the “proving relations” for the commutativity of each pair of letters. I recall that they showed almost all pairs of letters commuted, but could not get all of them. My understanding was that they never finished the problem and that no paper was finished. As such, I don’t know about the paper of Conway, Sahi, and Feit. A few people online mention it — I wonder if anyone has a copy?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42942")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("This morning I remembered a bit of noncommutativity that always bothered me when I used to ride the Amtrak from New Haven back down to DC. At a number of the stops, the conductor would announce that “All doors will not open”, when I’m pretty sure he meant that “Not all doors will open.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dave")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42943")[#strong[#text("Dave")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("I think my favorite example of noncommutativity is “all are not” versus “not all are” (with “all are” as a single element, of course).")

#text("When I was young I used to ask for clarification on things like that, and people would think I was stupid because they wanted to say “not all people like carrots” and didn’t recognize there was anything different about “all people don’t like carrots.”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42945")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("I just thought of another one. Instead of hinging on the semantics of negation (“not”) or modulation (“only”), this version exploits the asymmetric semantics of comparison (“like”).")

#text("Naïvely we might think of “A is like B” as an equivalence relation, but in practice it’s very asymmetric. Consider the pair:")

#text("“That professional baseball player throws like a little girl.”")#linebreak()#text(" “That little girl throws like a professional baseball player.”")

#text("This is related to another pair:")

#text("“Good food is not cheap.”")#linebreak()#text(" “Cheap food is not good.”")

#text("in which both sentences are logically equivalent (“No food is both cheap and good.”) but have a distinct feel.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d39c5b7fe87d446011308cd8e945dce85bde2d6f582f43707840d0294cef5dc9-b7b6bec90a864e7e3d2b10833032e7728bdd0129bbec856587cf1aa6a2011c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous Rex")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42947")[#strong[#text("Anonymous Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("If you don’t switch determiners, your first example seems symmetric enough (if a bit awkward-sounding):")

#text("“That professional baseball player throws like a little girl.”")#linebreak()#text(" “A little girl throws like that professional baseball player.”")

#text("“That little girl throws like a professional baseball player.”")#linebreak()#text(" “A professional baseball player throws like that little girl.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42953")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("They’re still not symmetric, in the same way that my second example isn’t. The first calls up an image of surprising ineptitude on the part of the baseball player, while the second calls up an image of surprising ability in the little girl.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42951")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("The logical equivalence of “All A are not B” and “All B are not A” is not robust with respect to perturbations, which explains the different feel: “Almost all A are not B” is quite a different statement from “Almost all B are not A”. e.g. “Almost all humans are not mathematicians” vs. “Almost all mathematicians are not human”. (See also the ")#link("http://en.wikipedia.org/wiki/Raven_paradox")[#text("Raven paradox")]#text(".)")

#text("There is now a reddit thread pointing to this article at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://www.reddit.com/r/math/comments/aivj6/a_demonstration_of_the_noncommutativity_of_the/")[#text("A demonstration of the non-commutativity of the English language.")]#linebreak()#text(" by")#link("https://www.reddit.com/user/day_sweetener/")[#text("u/day_sweetener")]#text(" in")#link("https://www.reddit.com/r/math/")[#text("math")]
]

#text("The first comment mentions one of my own favourite examples of linguistic asymmetry, this time ultimately stemming from temporal ambiguity:")

#text("“Like the ski resort with husbands looking for young ladies and young ladies looking for husbands, the situation was not as symmetric as it first seemed.”")

#text("While on the topic of witticisms, here is another favourite example of mine, by John Kenneth Galbraith, which has the unusual feature of simultaneously demonstrating both symmetry and antisymmetry:")

#text("“Under capitalism, man exploits man. Under communism, it’s just the opposite.”")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42954")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("The ski resort example is a great one, where the words are exactly the same, but the meaning of the individual words is completely reshaped by the order of the words around them.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9d692058b3170db4792107e161953922c74174c9aedb54dc7e8573cee314db-f8ae0f47bdb439ebcfb520a027a99b4623d616ede2f24bfeabe8b0a49a1ced27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42959")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("“Like the ski resort with husbands looking for young ladies and young ladies looking for husbands, the situation was not as symmetric as it first seemed.”")

#text("One of the things that I think might make this an atypical example is that ‘looking for a husband’ sounds like an idiom to me. So, we might expect abnormal semantics here anyway.")

#text("Second, I think it requires some social understanding in terms of what a young woman would be doing looking for a husband, or a husband looking for a young woman.")

#text("I feel that a child young enough not to have heard of the idiom and too young to understand the politics of men and women, would see the sentences as more symmetric.")

#text("If we thought these husbands were looking for a second wife and not an affair, again it might seem more symmetric. It is the presumption of unwholesomeness, which is essentially a social assumption, that I think introduces the asymmetry.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9d692058b3170db4792107e161953922c74174c9aedb54dc7e8573cee314db-f8ae0f47bdb439ebcfb520a027a99b4623d616ede2f24bfeabe8b0a49a1ced27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42946")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("Although there are only a few techniques being used, the author does a good job of deploying them. I certainly haven’t gotten around to looking at it in very much detail but a few observations, lack of commutativity comes out in phrases like,")

#text("1.")#linebreak()#text(" I hate cats.")#linebreak()#text(" It is not true that")#linebreak()#text(" I hate dogs.")

#text("2.")#linebreak()#text(" dogs")#linebreak()#text(" are better than")#linebreak()#text(" cats")

#text("But, in addition, lack of associativity comes out in places where subordinate clauses which can easily be put at the beginning or ends of sentences are being moved between groups. If we think of everything that is in one sentence as being between matching sets of brackets then we see that the brackets are moved around when we go backwards through the poem.")

#text("Cats are felines")#linebreak()#text(" (Experts tell me")#linebreak()#text(" Dogs are canines)")

#text("(Cats are felines")#linebreak()#text(" Experts tell me)")#linebreak()#text(" Dogs are canines")

#text("Sometimes the shifts are changing meaning and sometimes they seem to just break up the monotony.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9d692058b3170db4792107e161953922c74174c9aedb54dc7e8573cee314db-f8ae0f47bdb439ebcfb520a027a99b4623d616ede2f24bfeabe8b0a49a1ced27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42949")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("John,")

#text("I think there is ambiguity in the sentence “All doors will open”. Am I saying, each door individually will open by it’s own causal mechanism or am I saying that all doors collectively will open by the same causal mechanism. Typically, I think, one might say, ‘Each door will open’ to signal that we are thinking individually.")

#text("I thought to compare these two sentences:")

#text("1. “All doors will not open.”")#linebreak()#text(" 2. “All doors will not stay closed”")

#text("If the first means, none of the doors will open, then to be consistent the second should probably mean that all doors will open. However, I feel like the intuitive interpretation is that the second means some doors will open but not all of them.")

#text("A concurrent issue, of a more granular nature, is illustrated by this pair:")

#text("1. All doors (will not) open.")#linebreak()#text(" 2. All doors will (not open).")

#text("If the “not” modifies the meaning of “will”, it seems to favor the idea that some doors might open but not all of them. If it modifies meaning of “open” then it suggests all doors would remain closed.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42955")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("However, I feel like the intuitive interpretation is that the second means some doors will open but not all of them.")
]

#text("Except that’s not how the rules of grammar work. Or, rather, they do work that way in practice at the cost of ambiguity. The grammar of Standard English has unambiguous rules for how to deal with these nots, and it works exactly the way negations and quantifiers interact in prepositional logic.")

#text("In your second pair, each sentence starts with a universal quantifier. No matter how you parenthesize the predicate, the same predicate is asserted to obtain for all the doors.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42981")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("I am not even moderately read in this area. However,")

#text("1. what I was thinking is that the determiner “all” joins with the noun “doors” making the noun phrase or NP, “all doors” and that the statement was then about the subject ‘all doors’.")

#text("2. I think that it is difficult to make ‘all’ into something that behaves like a universal quantifier in a straightforward fashion:")

#text("a. “We are all for one.”")

#text("b. “We stand all together or each alone.”")

#text("c. “All men are equal.”")

#text("It requires some contortion of the sentences and plenty of exceptions.")

#text("3. When I say ‘intuitively’, I was meaning to signal that I was speaking in a descriptionist rather than a prescriptionist framework. In other words, I was hypothesizing about what types of mental models might lead a person to think “All doors will not open.” would mean what the conductor seemed to think it meant.")

#text("4. One further minor quibble, grammar is the study of the rules by which we construct sentences or phrases. Here, we are discussing semantics or the means by which we derive meaning from sentences and phrases. The latter, I believe, is more consensual than the former. The practical consequence is that it might be difficult to resolve issues such as these using rules of grammar.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42952")[#strong[#text("Top Posts — WordPress.com")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")]

#text("[…] A demonstration of the non-commutativity of the English language This will be a more frivolous post than usual, in part due to the holiday season. I recently happened across the […] […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7b172191ae1216757d5e6f19f334cf3827e607380bff0384ee8419016e2dba4d-33bc6fdd89980c1ff1f0fc18668cf2888853d2304d8aba987358f696038b7956.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pashupati")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42961")[#strong[#text("Pashupati")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("That’s interesting.")#linebreak()#text(" But, this may be a stupid question, is there any human language, artificial or natural but not a formal one, that is commutative, and that allow you to think, to speak about anything from philosophy to pizza?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42962")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("What is the difference between an “artificial” and a “formal” language? In any case, this is clearly possible in principle but not at all useful in practice. It makes sense for natural languages to be non-commutative because the order of words in a sentence conveys information. Requiring that a language be commutative is a waste of bits.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d39c5b7fe87d446011308cd8e945dce85bde2d6f582f43707840d0294cef5dc9-b7b6bec90a864e7e3d2b10833032e7728bdd0129bbec856587cf1aa6a2011c97.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous Rex")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42963")[#strong[#text("Anonymous Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("However, languages ARE commutative to different extents. For example, the sentence “Bob kissed Mary” is not commutative in English, but in a language with sufficient noun declension such as Latin or Russian, all six orderings of the sentence convey the same information. Of course, longer sentences are less commutative, although there exist impressively long fully-commutative sentences.")

#text("So yes, “requiring that a language be commutative is a waste of bits” is probably true, but “not at all useful in practice” misses the point a bit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42968")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("Sorry, I misspoke. I had a very specific thing in mind when I said “this is clearly possible”; by “this” I meant one could start with any language and “abelianize” it by choosing an appropriate encoding of sentences in the language by multisets of words. Although such an encoding would satisfy Pashupati’s constraint, I didn’t see the point in these artificial examples. I wasn’t commenting on the commutativity of natural languages.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/826a2728424b30ad8cc83000d2bfd8744edcd1bafba060e1c70b63281a0934f6-5e3de4a3d5bde314bee2c1b42ac7f851cee463773970099eaeb046cc61a7dd19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Harrison")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42964")[#strong[#text("Harrison")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("I don’t speak it fluently, but I’m told that Hungarian has a very loose word order. Apparently order is still used to add emphasis to certain words, though — like Qiaochu said, completely failing to use word order would be highly inefficient.")

#text("I still don’t think that Hungarian is “completely commutative,” whatever that means — you’d need a morphological way to distinguish between “If A, then B” and “If B, then A,” which (as far as I know) Hungarian doesn’t have.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ec7c6b0e3060e1c806f619bf4b492030a739cda006aaf0a178402739ff75194-2c3659f7497f4bb1cf1e6e85fafd68a9d10b53737c2f3b03f29c35b080ae39ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Allen Knutson")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42971")[#strong[#text("Allen Knutson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("The object of a Hungarian sentence is specified by having a -t appended, so is order independent. I saw one with “George Busht” as the object, for example.")

#text("The word order was partially explained to me as follows: the important bit (whatever it may be) goes before the verb. If the verb is the important bit, it goes at the beginning. Unfortunately the English word “is”, in Hungarian, is an empty word, so in sentences with that verb you have to infer its placement and hence the important bit.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42966")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("In principle all meaning in Latin comes from prefices and suffices, and none comes from word order.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20dad6bfbcb9227edbe4568b3b1daeec815c7b85c8240785827738f7b3ece12f-6102be506782b1d53c6921ce761670ea2b51e01730e09c2f76813c915cf7ec3b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of joe the rat")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42969")[#strong[#text("joe the rat")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2009")])]

#text("As a matter of fact latin is totally commutative and actually it is free! In latin the sentences “Bob eats a pizza” and ” a bob pizza eats” have the same meaning")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42974")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("Latin, like all human languages, should fail to be completely commutative. In particular, it might have difficulty with sentences that have clauses (“Bob thinks that Mary is nice”), prepositions (e/ex/in/ab/ad), negation, or causation/inference (“A causes B” or “if A, then B”).")

#text("The shortest example I can think of is “non ducor, duco” versus “non duco, ducor”. However, many other mottos seem to work, too. (Switch school and life in “non scholae sed vitae discimus” or others and self in “qui facit per alium facit per se”.) Any sufficiently long Latin sentence should demonstrate that switching word order doesn’t even preserve grammaticality. (“Facit facit per per alium se qui”?)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b5574fbce72f9a1ebb067e580d0e4f124b4d72ce14b3cdd0742c2b2244ded46a-fd88f31c5ee78045bc46c17d431b836d8a703877de4b34e07db451fc844f5249.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben Fairbairn")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42970")[#strong[#text("Ben Fairbairn")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("To return briefly to the non-associativity of the English language, one of the most beautiful illustrations is surely the inequivalence of the (simple finite) groups and simple (finite groups)???")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/00d42bc6375c491a25232983a115f62976587f827a3756ae3bbfa9ed57c57709-ead29ea7d1f6b02d838b61cb7b214d3d06c1a4117da1e54dff7a0a33251caf72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Comenetz")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42973")[#strong[#text("Michael Comenetz")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("In Plato’s dialogue “Phaedrus,” at 264d-e, Socrates recites the four-line inscription that they say is inscribed on the tomb of Midas the Phrygian, and observes that “it makes no difference whether any line of it is put first or last.” (This is not praise.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aba08e5b6c0690ad6d867d0931bfee12fc6a252b8e6ebb931b499f044df954a7-ecae79b80df089d705bd6b1d0f10d5a68531f30c10bc3529c6092b5df1bfc733.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of gowers")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42977")[#strong[#text("gowers")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("An example of non-associativity that comes up on the web in several places is the following pair of sentences.")

#text("A woman: without her, man is nothing.")

#text("A woman without her man is nothing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42978")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("One can also demonstrate non-associativity just by stressing a different word, without any need for punctuation. Consider for instance a short-lived slogan of Microsoft: “It just works”. It makes a huge difference whether one stresses the third word (“It just _works_”) or the second (“It _just_ works”). :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42982")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("In order of certainty:")

#text("It! Just! Works!")

#text("It. Just. Works.")

#text("It just works!")

#text("It just works.")

#text("It — just — works.")

#text("It (just) works.")

#text("It just … works.")

#text("It just works?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9dfd506431bdc82b623f4c4c75df1ca02cac8ffe0b080cdb73b83c6058bb838a-b436cbfacd459fdce34b9ba635d8f458b91eb525ecb76f956d24b02556b5db00.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42983")[#strong[#text("Matt")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")])]

#text("Here are some longer, and rather festive, demonstrations of the non-associativity of the English language:")

#link("http://news.bbc.co.uk/1/hi/magazine/4583594.stm")[#text("http://news.bbc.co.uk/1/hi/magazine/4583594.stm")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-42980")[#strong[#text("reads for 2009-12-28 | Strings of Curiosity")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2009")]

#text("[…] A demonstration of the non-commutativity of the English language […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John R Ramsden")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43013")[#strong[#text("John R Ramsden")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2009")])]

#text("I’m sure I remember a song whose meaning changes from line to line; but maybe I was thinking of the saucy World War 1 song, which is a simpler example where the final word is replaced.")

#text("It was one of many sung in the 1969 film ")#link("http://www.imdb.com/title/tt0064754/")[#text("Oh! What a Lovely War")]

#text("It was Christmas Day in the cookhouse, the happiest time of the year,")#linebreak()#text(" Men’s hearts were full of gladness and their bellies full of beer,")#linebreak()#text(" When up popped Private Shorthouse, his face as bold as brass,")#linebreak()#text(" He said We don’t want your puddings, you can stick them up your tidings of co-omfort and joy, comfort and joy, o-oh ti-idings of co-omfort and joy.")

#text("It was Christmas Day in the harem, the eunuchs were standing ’round,")#linebreak()#text(" And hundreds of beautiful women were stretched out on the ground,")#linebreak()#text(" Along came the wicked Sultan, surveying his marble halls, He said")#linebreak()#text(" Whaddya want for Christmas boys, and the eunuchs answered tidings of co-omfort and joy, comfort and joy, o-oh ti-idings of comfort and joy.")

#text(":::")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63019612d483b45501121cf9d412fb3731dbb51765842fc88cd5cae6319a7bdd-6afadcfa967e963a5a14a6f7b49a58abc01337b3720e3b989fa58ee43dc444dc.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mnemonaut")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43027")[#strong[#text("mnemonaut")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("For those interested in the rhetorical trick: ")#link("http://www.youtube.com/watch?v=mkTXgaWn1gQ")[#text("“It’s time to listen”")]#text(" (a video inspired by “Lost Generation”, not the author’s experience as a supervisee of John Conway, produced as part of an autistic response to Autism Speaks).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/253dc5352553961de9143da4a5f275b083ac853d24392156ae246c1115c7a2b1-1245c5cde5059014e3cd4d9f0f350fc402d44806b89548678f6bc2a68f7ffe9b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeanine")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43029")[#strong[#text("Jeanine")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("Maybe what you mean is something like this Tom Lehrer song, with respect to the first and last lines (not verses) whose meaning changed on the way:")

#text("I hold your hand in mine, dear,")#linebreak()#text(" I press it to my lips.")#linebreak()#text(" I take a healthy bite")#linebreak()#text(" From your dainty fingertips.")

#text("My joy would be complete, dear,")#linebreak()#text(" If you were only here,")#linebreak()#text(" But still I keep your hand")#linebreak()#text(" As a precious souvenir.")

#text("The night you died I cut it off.")#linebreak()#text(" I really don’t know why.")#linebreak()#text(" For now each time I kiss it")#linebreak()#text(" I get bloodstains on my tie.")

#text("I’m sorry now I killed you,")#linebreak()#text(" For our love was something fine,")#linebreak()#text(" And till they come to get me")#linebreak()#text(" I shall hold your hand in mine.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43030")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("Technically, this is a protocol rather than a language, but the ")#link("http://en.wikipedia.org/wiki/Internet_Protocol")[#text("internet protocol")]#text(" (IPv4 or IPv6) is designed to be commutative, in the sense that data packets can come in any order. The basic idea here is to encode order information inside each packet itself. An analogous method in English would be to append at the end of each word in a sentence, the position of that word, thus for instance “All men are mortal” would become any permutation of {all1 men2 are3 mortal4}, such as “mortal4 are3 all1 men2”. Except for the very important issue of punctuation (and to a lesser extent, capitalisation), this would be a commutative language.")

#text("Jeanine: yes, this was the type of example I had in mind! (It seems unlikely though that a similar set of intervening verses could perform the reverse changes of meaning.) I found a somewhat weaker version of this form in the song “Thank goodness” from the musical Wicked, with regard to the theme “couldn’t be happier”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9673d915f84e12dfe1e7fbb904fc0d6f465490295ac02bed471a1eaf6dc72b2d-47872c6ab8a527c325a3d79222dbad8800fd879db8314f158349b5daeeb08ef4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Max Souza")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43031")[#strong[#text("Max Souza")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2010")])]

#text("It might be of interest to know that similar examples of non-commutativity do exist in other languages. Here is an example in Portuguese, which read forward is a “non-love” letter , while read backwards is a love letter.")

#text("Não te amo mais.")#linebreak()#text(" Estarei mentindo dizendo que")#linebreak()#text(" Ainda te quero como sempre quis.")#linebreak()#text(" Tenho certeza que")#linebreak()#text(" Nada foi em vão.")#linebreak()#text(" Sinto dentro de mim que")#linebreak()#text(" Você não significa nada.")#linebreak()#text(" Não poderia dizer jamais que")#linebreak()#text(" Alimento um grande amor.")#linebreak()#text(" Sinto cada vez mais que")#linebreak()#text(" Já te esqueci!")#linebreak()#text(" E jamais usarei a frase")#linebreak()#text(" EU TE AMO!")#linebreak()#text(" Sinto, mas tenho que dizer a verdade")#linebreak()#text(" É tarde demais…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/631b57c510b1e97558c98ce79b699fc120a2a323ae4958ed9424d13c6e5c405c-c26befb15dfbc1f1a6cb15cdddd237e171039be65c91ad3375b11e4835c4912b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43038")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("Agreeing with you too often")#linebreak()#text(" (Remember we discussed this before?)")#linebreak()#text(" And being so predictable,")#linebreak()#text(" It feels dreary.")#linebreak()#text(" So often I yearn")#linebreak()#text(" To do the opposite.")#linebreak()#text(" But either way,")#linebreak()#text(" I am being reactionary.")#linebreak()#text(" I want to be my own person.")#linebreak()#text(" Despite all my efforts,")#linebreak()#text(" I am trapped in my ways;")#linebreak()#text(" And so,")#linebreak()#text(" I have not found myself")

#text("I don’t know if I want to call this a poem. It was composed solely in an attempt to have some prose with the Mobius-like property mentioned above. I envision, for the first iteration of the poem that the last line is completed by the first line of the next iteration: “I have not found myself agreeing with you too often.” The second iteration stops at “I have not found myself”. And it goes on like that.")

#text("There is some asymmetry introduced by the line “I am trapped in my ways” which makes the second reading make more sense if one stops at “I have not found myself”.")

#text("I would be the first to say the punctuation is a problem and it ain’t Shakespeare. :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43050")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("A clever solution!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2009/12/26/a-demonstration-of-the-non-commutativity-of-the-english-language/#comment-43057")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2010")])]

#text("Hello professor Tao:")#linebreak()#text(" It looks like one cannot use mathematics to explain the non-commutativity in the poem in the video simply because unlike Conway’s work on free groups, the anti-commutativity seems to be semantic which cannot possibly be “explained” by a theory including group generators standing alone.")#linebreak()#text(" Thank you,")#linebreak()#text(" AJ")
]
