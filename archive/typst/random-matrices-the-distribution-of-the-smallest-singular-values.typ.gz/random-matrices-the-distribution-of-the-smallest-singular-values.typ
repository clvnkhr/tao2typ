// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/
// Converted to Typst by tao2typ: "2026-10-14T07:12:29.225047+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: The distribution of the smallest singular values", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: The distribution of the smallest singular values")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 4 March 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/")[#text("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the ")#link("http://www.arxiv.org")[#text("arXiv")]#text(" our paper “")#link("http://arxiv.org/abs/0903.0614")[#text("Random matrices: The distribution of the smallest singular values")]#text("“, submitted to ")#link("http://link.springer.de/link/service/journals/00039/index.htm")[#text("Geom. Func. Anal.")]#text(". This paper concerns the least ")#link("http://en.wikipedia.org/wiki/Singular_value")[#text("singular value")]#text(" ")#mi("\\sigma_n(M)")#text(" of a random ")#mi("n \\times n")#text(" matrix ")#mi("M_n = (a_{ij})_{1 \\leq i,j \\leq n}")#text(" with ")#link("http://en.wikipedia.org/wiki/Independent_and_identically-distributed_random_variables")[#text("iid")]#text(" entries, which for simplicity we will take to be real (we also have analogues for complex random matrices), with mean zero and variance one. A typical model to keep in mind here is the ")#emph[#text("Bernoulli model")]#text(", when each ")#mi("a_{ij}")#text(" is equal to +1 or -1 with an equal probability of each, while a privileged role will be planed by the ")#emph[#text("gaussian model")]#text(", when each ")#mi("a_{ij} \\equiv N(0,1)")#text(" is given the standard gaussian distribution.")

#text("The distribution of the least singular value ")#mi("\\sigma_n(M_n)")#text(", which is of importance in ")#link("http://en.wikipedia.org/wiki/Smoothed_analysis")[#text("smoothed analysis")]#text(" and also has intrinsic interest within the field of random matrices, has been intensively studied in recent years. For instance, in the Bernoulli case, there have been several recent papers on the singularity probability ")#mi("{\\Bbb P}( \\sigma_n(M_n) = 0 )")#text("; it is not hard to obtain a lower bound of ")#mi("(\\frac{1}{2}+o(1))^n")#text(", and this is conjectured to be the correct asymptotic. The best upper bound so far is by Bourgain, Vu, and Wood, who obtain ")#mi("(\\frac{1}{\\sqrt{2}}+o(1))^n")#text(".")

#text("Upper and lower tail bounds have also been obtained, starting with the breakthrough paper ")#link("http://www.ams.org/mathscinet-getitem?mr=2196007")[#text("of Rudelson")]#text(" (building upon some earlier work on rectangular matrices ")#link("http://www.ams.org/mathscinet-getitem?mr=2146352")[#text("by Litvak, Pajor, Rudelson, and Tomczak-Jaegermann")]#text("), with subsequent ")#link("http://arxiv.org/abs/0805.3167")[#text("papers")]#text(" ")#link("http://arxiv.org/abs/math.PR/0511215")[#text("by")]#text(" ")#link("http://arxiv.org/abs/0708.2895")[#text("Van")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2402448")[#text("and")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2409368")[#text("myself")]#text(", ")#link("http://www.ams.org/mathscinet-getitem?mr=2441928")[#text("by Rudelson")]#text(", and also by ")#link("http://www.ams.org/mathscinet-getitem?mr=2407948")[#text("Rudelson")]#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=2441928")[#text("and")]#text(" ")#link("http://arxiv.org/abs/0802.3956")[#text("Vershynin")]#text(". To oversimplify somewhat, the conclusion of this work is that the least singular value ")#mi("\\sigma_n(M_n)")#text(" has size comparable to ")#mi("1/\\sqrt{n}")#text(" with high probability. The techniques are based in part on inverse Littlewood-Offord theorems.")

#text("However, in the case of the gaussian ensemble, we know more than just the expected size of the least singular value; we know its asymptotic distribution. Indeed, it was shown ")#link("http://www.ams.org/mathscinet-getitem?mr=964668")[#text("by Edelman")]#text(" in this case that one has")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("{\\Bbb P}( \\sigma_n(M_n) \\leq t/\\sqrt{n} ) = 1 - e^{-t^2/2 - t} + o(1)")]]

#text("for any fixed ")#mi("t > 0")#text(". This computation was highly algebraic in nature, relying on special identities that are available only for extremely symmetric random matrix ensembles, such as the gaussian random matrix model; in particular, it is not obvious at all that the Bernoulli ensemble necessarily obeys the same distribution as the gaussian one. Nevertheless, motivated in part by this computation, ")#link("http://www.ams.org/mathscinet-getitem?mr=1989210")[#text("Spielman and Teng")]#text(" conjectured that the bound")

#align(center)[#tao-fit-display[#mitex("{\\Bbb P}( \\sigma_n(M_n) \\leq t/\\sqrt{n} ) \\leq t + c^n")]]

#text("should hold for some ")#mi("c < 1")#text(" for, say, the Bernoulli ensemble. This conjecture was verified up to losses of a multiplicative constant ")#link("http://www.ams.org/mathscinet-getitem?mr=2407948")[#text("by Rudelson and Vershynin")]#text(".")

#text("The main result of our paper is to show that the distribution of the least singular value is in fact ")#emph[#text("universal")]#text(", being asymptotically the same for all iid (real) random matrix models with the same mean and variance, and with a sufficiently high number of moment conditions. In particular, the asymptotic (1) for the gaussian ensemble is also true for the Bernoulli ensemble. Furthermore the error term o(1) can be shown to be of the shape ")#mi("O(n^{-c})")#text(" for some c > 0, which in turn confirms the Spielman-Teng conjecture (without a loss of constant) in the polynomial size regime ")#mi("t \\geq n^{-c^{\\prime}}")#text(" for some ")#mi("c^{\\prime} > 0")#text(". We also have some further results for other low singular values (e.g. ")#mi("\\sigma_{n-k}(M_n)")#text(" for fixed k) but they are harder to state, and we will not do so here.")

#text("To our knowledge, this is the first universality result for the “hard edge” of the spectrum (i.e. the least few singular values) for iid square matrix models. [For rectangular matrices, where the hard edge is bounded away from zero, universality was recently established ")#link("http://arxiv.org/abs/0812.1961")[#text("by Feldheim and Sodin")]#text(".] The bulk distribution for the singular values of such matrices has been known for some time (it is governed by the famous ")#emph[#text("Marchenko-Pastur law")]#text("), while the distribution at the “soft edge” of the spectrum (i.e. the largest few singular values) was established to be universal ")#link("http://www.ams.org/mathscinet-getitem?mr=1933444")[#text("by Soshnikov")]#text(" (here the distribution is governed by the ")#emph[#text("Tracy-Widom law")]#text(" for the top singular value, and by the ")#emph[#text("Airy kernel")]#text(" for the next few singular values). Both of these results are basically obtained by the moment method (or close relatives of this method, such as the resolvent method). However, the moment method is not effective for discerning the hard edge of the spectrum, since the singular values here are very small compared with the bulk and so have a negligible influence on the moments. [In the rectangular case, where the hard edge is bounded away from zero, the moment method becomes available again, though the application of it is quite delicate; see the Feldheim-Sodin paper for details.] Instead, we proceed by observing a certain central limit theorem type behaviour for the geometry of the columns of ")#mi("M_n")#text(", which is enough to give us the desired universality; more details on the proof lie below the fold.")

#metadata(none) <tao-ca1de13ebb40813b1d3b>

#heading(level: 1)[#text("— Proof strategy —")]

#text("As with our earlier paper on the ")#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/")[#text("universality of the circular law")]#text(", we do not attempt to prove (1) for general ensembles such as the Bernoulli ensemble (say) directly. Instead, we use a Lindeberg-style approach to separate the analytic difficulties from the algebraic ones by first comparing the least singular value ")#mi("\\sigma_n(M_n)")#text(" of a Bernoulli matrix ")#mi("M_n")#text(" with the corresponding least singular value ")#mi("\\sigma_n(G_n)")#text(" of a gaussian matrix ")#mi("G_n")#text(". If we can show a universality property")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sigma_n(M_n) \\approx \\sigma_n(G_n)")]]

#text("where we use ")#mi("X \\approx Y")#text(" to denote the informal statement that two random variables X, Y have asymptotically the same distribution (after appropriate renormalisation, and in some appropriate metric), then the claim (1) for the Bernoulli matrix ")#mi("M_n")#text(" will then follow from the existing work of Edelman establishing (1) for the gaussian matrix ")#mi("G_n")#text(".")

#text("To establish the approximation (2) for the least singular value, the first thing we do is flip it around, so that we now seek an approximation for the ")#emph[#text("largest")]#text(" singular value for the inverse matrices:")

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\sigma_1(M_n^{-1}) \\approx \\sigma_1( G_n^{-1} ).")]]

#text("Experience has shown that largest singular values are easier to compute than least singular values (for instance, they are the same thing as the operator norm and can be computed by, say, the ")#link("http://en.wikipedia.org/wiki/Power_iteration")[#text("power method")]#text("). But there is a huge price to pay: whereas the matrices ")#mi("M_n, G_n")#text(" had iid entries and were thus tractable to manipulate, the inverse matrices ")#mi("M_n^{-1}, G_n^{-1}")#text(" have highly coupled entries and are quite difficult to manipulate; in particular, it is not easy at all to control high moments of ")#mi("M_n^{-1}")#text(". So the moment method does not work terribly well (although the second moment of ")#mi("M_n^{-1}")#text(" is computable, and already useful – we used this “negative second moment identity” to good effect in our ")#link("https://terrytao.wordpress.com/2008/10/18/from-the-littlewood-offord-problem-to-the-circular-law-universality-of-the-spectral-distribution-of-random-matrices/")[#text("earlier paper")]#text(").")

#text("So we do something else. It turns out that the singular values of ")#mi("M_n")#text(" tend to be spaced apart with spacing about ")#mi("1/\\sqrt{n}")#text("; in particular, ")#mi("\\sigma_{n-k+1}(M)")#text(" is heuristically about ")#mi("k / \\sqrt{n}")#text(". (This intuition is supported by the Marchenko-Pastur law, and is also backed up by the tail estimates ")#link("http://arxiv.org/abs/0802.3956")[#text("of Rudelson and Vershynin")]#text(" mentioned earlier.) Inverting this, we see that the ")#mi("k^{th}")#text(" largest singular value of ")#mi("M_n^{-1}")#text(" should be about ")#mi("\\sqrt{n} / k")#text(". Thus we see that (after dividing out the normalising factor ")#mi("\\sqrt{n}")#text(") the matrix ")#mi("M_n^{-1}")#text(" should behave like a ")#link("http://en.wikipedia.org/wiki/Compact_operator")[#text("compact operator")]#text("; its singular values decay to zero at a noticeable rate. In particular, ")#emph[#mi("M_n^{-1}")#text(" should behave approximately like a finite rank matrix")]#text(". (More accurately, “finite” should be “bounded uniformly in n”.)")

#text("At this point, we use the philosophy from the ")#link("http://en.wikipedia.org/wiki/Property_testing")[#text("property testing")]#text(" literature for finite rank matrices, which tells us that statistics of large finite rank matrix (and in particular, its largest eigenvalue) often can be computed accurately from a small random sample of that matrix. Indeed, if we pick a small integer s (in practice ")#mi("s \\sim n^\\varepsilon")#text(" for some small ")#mi("\\varepsilon > 0")#text(", and let ")#mi("B(M_n)")#text(" be the ")#mi("s \\times n")#text(" matrix formed by taking s rows of ")#mi("M_n^{-1}")#text(" at random (actually, given the iid nature of ")#mi("M_n")#text(", we can just take the ")#emph[#text("first")]#text(" s rows), then we expect (from the approximate finite rank nature of ")#mi("M_n^{-1}")#text(")")

#align(center)[#mi("\\sigma_1(M_n^{-1}) \\approx \\sqrt{\\frac{n}{s}} \\sigma_1( B(M_n) )")#text(".")]

#text("It turns out that one can justify this by an application of the moment method, coupled with some estimates on the size of the rows of ")#mi("M_n^{-1}")#text(" which can be obtained variants of the machinery used in previous papers (in particular, we need some new estimates on distances between random vectors and random hyperplanes).")

#text("Of course, everything we say about the Bernoulli ensemble has counterparts for the gaussian ensemble, and so we are reduced to showing that")

#align(center)[#mi("\\sigma_1(B(M_n)) \\approx \\sigma_1(B(G_n))")#text(".")]

#text("To show this, we invert again, viewing the largest singular value of ")#mi("B(M_n)")#text(" as the least non-trivial singular value of the (")#link("http://en.wikipedia.org/wiki/Generalized_inverse")[#text("pseudo")]#text("-)inverse of B(M_n). Indeed, some elementary linear algebra tells us that")

#align(center)[#tao-fit-display[#mitex("\\sigma_1(B(M_n)) = \\sigma_s(M_{n,s})^{-1}")]]

#text("where the ")#mi("s \\times s")#text(" matrix ")#mi("M_{n,s}")#text(" is formed by projecting the first s columns ")#mi("X_1,\\ldots,X_s")#text(" of M onto the s-dimensional space V defined as the orthocomplement of the span of the remaining columns ")#mi("X_{s+1},\\ldots,X_n")#text(", and then expressing those vectors using some arbitrarily chosen orthonormal basis for V. [This fact is perhaps most familiar in the simple case s=1, when it is saying that the size of a row of ")#mi("M_n^{-1}")#text(" is the reciprocal of the distance between the corresponding column of ")#mi("M_n")#text(" to the hyperplane spanned by the other columns of ")#mi("M_n")#text(".]")

#text("Of course, we have similar computations for the gaussian ensemble; so we are now reduced to showing that")

#align(center)[#mi("\\sigma_s(M_{n,s}) \\approx \\sigma_s( G_{n,s} )")#text(".")]

#text("It looks like we are more or less back to where we started (cf. (2)), but with ")#mi("s \\times s")#text(" matrices instead of ")#mi("n \\times n")#text(" matrices. Indeed, the projected gaussian matrix ")#mi("G_{n,s}")#text(" can easily be checked to have exactly the same distribution as the ")#mi("s \\times s")#text(" gaussian matrix ")#mi("G_s")#text(", basically because the projection of an n-dimensional gaussian random vector to an s-dimensional subspace is an s-dimensional gaussian vector.")

#text("But now for the punchline: the projected Bernoulli matrix ")#mi("M_{n,s}")#text(" ")#emph[#text("also")]#text(" has distribution very close to the ")#emph[#text("gaussian")]#text(" matrix ")#mi("G_s")#text(", because the projection of a n-dimensional Bernoulli random vector to a (sufficiently non-degenerate) s-dimensional subspace also behaves like an s-dimensional gaussian vector. This is basically a consequence of the ")#link("http://en.wikipedia.org/wiki/Central_limit_theorem")[#text("central limit theorem")]#text("; for technical reasons we need a modification of the ")#link("http://en.wikipedia.org/wiki/Berry-Esseen_theorem")[#text("Berry-Esseén version of this theorem")]#text(". One has to show that the space V is sufficiently non-degenerate, but this can be done by a modification of techniques already in the literature (specifically, we rely on Talagrand’s inequality and a quantitative form of the Marchenko-Pastur law). Once this is done, the claim follows from the stability properties of ")#mi("\\sigma_s")#text(" (specifically, we use the Hoffman-Weilandt inequality).")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-36308")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Have you considered whether the Lindeberg-style approach of this and your other recent paper could provide simpler proofs of Soshnikov’s universality results for the largest eigenvalues/singular values? Or maybe the invocation of the moment method in the “property testing” part of your proof would just lead one to repeat large parts of Soshnikov’s proof, or something like it?")

#text("Incidentally, explicit statements of still more general versions of Talagrand’s concentration inequality than your Theorem E.2 appear in the literature, for example ")#link("http://www.ams.org/mathscinet-getitem?mr=1999604")[#text("Theorem 9 here")]#text(" or ")#link("http://www.ams.org/mathscinet-getitem?mr=2057479")[#text("Corollary 4 here")]#text(". In slightly disguised form, it’s even in Ledoux’s book as Theorem 4.15, which originally appeared as ")#link("http://www.ams.org/mathscinet-getitem?mr=1097258")[#text("Theorem 3 here")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of R.A.")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-36312")[#strong[#text("R.A.")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear Prof. Tao,")

#text("is your result related to a recent work by Ohad N. Feldheim, and Sasha Sodin, available at ")#link("http://arxiv.org/abs/0812.1961")[#text("http://arxiv.org/abs/0812.1961")]#text(" ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-36314")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Dear RA,")

#text("Thanks for pointing out this paper (someone else just drew it to my attention also). The Feldheim-Sodin paper establishes a similar result to ours, but for rectangular matrices (with aspect ratio bounded away from 1) rather than square ones. In that setting, the hard edge of the spectrum is bounded away from zero and the moment method becomes (in principle) applicable, although it is extremely delicate (the Feldheim-Sodin paper is 51 pages long). In our setting the hard edge is at zero and we cannot use the moment method directly, so our techniques are rather different. But certainly the ")#emph[#text("conclusions")]#text(" are in the same spirit. (We’ll revise the paper shortly to reflect this and some other references that have been drawn to our attention.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of skoro")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-36315")[#strong[#text("skoro")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Nice paper! At a first look, the ”property testing” argument")#linebreak()#text(" seems very similar in spirit to the observation made by :")#linebreak()#text(" ")#link("http://arxiv.org/abs/0808.2521")[#text("http://arxiv.org/abs/0808.2521")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-36325")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Mark: Thanks for the references! Actually we cite Ledoux’ book (Corollary 4.10) already for this result, though there is the rather trivial distinction that we are dealing with complex random variables rather than real ones.")

#text("Our arguments rely to a large extent on the fact that M^{-1} is effectively behaving like a bounded rank matrix, so that it its largest singular value can be easily estimated by a sampling argument. In contrast, M itself does not behave like a finite rank matrix, but if there was some way to transform M so that the largest few singular values dominated and everything else became small (much like the inverse map brings the least singular values into a position of dominance) then perhaps one could do something similar. One can of course take high powers of M or MM^* to achieve this, but then this is nothing more than the classical moment method, which I believe is what Soshnikov’s method is based on. (Our property testing lemma uses only the fourth moment; in our essentially finite rank setting, this already gives enough concentration of measure for our application, which is fortunate as higher moments of M^{-1} beyond the fourth turn out to be rather difficult to compute.)")

#text("Dear skoro: Thanks for the interesting link! In that paper the authors show that a random submatrix of a given matrix has a universal spectral distribution even if the original matrix is not low rank – but it seems that they do not relate this distribution to the spectrum of the original matrix, so it isn’t quite the same sort of property testing phenomenon we exploit in our own work. Still, it certainly is part of the same wider body of ideas.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-36328")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 4 March 2009")])]

#text("Terry: The results I mentioned actually cover the case of complex random variables and more – you can replace them with bounded random vectors in an arbitrary collection of normed vector spaces.")

#text("Soshnikov’s method is as you say based on the classical moment method. What I find interesting is that his papers, like yours, don’t prove the limit results directly, but instead show that a large random matrix behaves in certain ways like a large Gaussian random matrix, and then cite the known limit results in the Gaussian setting. That’s what made me wonder if a Lindeberg-type approach might give an easier proof than the very difficult enumerative combinatorics in Soshnikov’s papers.")

#text("Regarding the paper of Chatterjee and Ledoux pointed out by skoro, the authors actually remark (rather in passing) that their result indeed does not in general relate well to the spectrum of the original matrix.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cd4bfb06bd050a989093ed573685723febc2f7fbc97be93869ddd8bab3257fc9-7fe956b9f8b7dae1686b686a0691c02b9667dd8802e8de59c9cf328efac02d71.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A semana nos arXivs… « Ars Physica")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-36412")[#strong[#text("A semana nos arXivs… « Ars Physica")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2009")])]

#text("[…] Random matrices: The distribution of the smallest singular values […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wdf")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-38192")[#strong[#text("wdf")]]#text(size: 9pt, fill: rgb("596477"), " · 15 April 2009")])]

#text("Dear Dr. Tao,")

#text("What about the random matrix (n by m) with its elements, iid, uniformly distribution on [-1,1]? esp for large n>>m, Is the spectral norm of its pseudo inverse very small? I tested in matlab.")

#text("Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-38355")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2009")])]

#text("Terry: Is there a reason I’m not seeing that for your Proposition 3.4 (Berry-Esseen theorem for frames) you can’t just use an off-the-shelf result like those in (I think) chapter 15 of ")#link("http://www.ams.org/mathscinet-getitem?mr=855460")[#text("this book")]#text(" for example?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-38383")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2009")])]

#text("Dear Mark,")

#text("That’s quite likely. I think when we found out we needed a multidimensional Berry-Esseen theorem, it was quicker to just write down a statement and proof of the type of result we needed than to hunt in the literature for a close enough match. But it’s certainly a standard result; that’s one reason why it’s in an appendix rather than in the main text. :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-39081")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2009")])]

#text("Dear Mark,")

#text("We finally got around to taking a look at the Berry-Esseen result you indicated. It is indeed very close to what we need, but unfortunately if one applies it directly there is an exponential loss in the dimension. For our applications, the dimension is a small power of ")#mi("n")#text(", so we needed a variant of the Berry-Esseen theory that only loses polynomial factors in the dmiension.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/36ec93f7c31c5bedf7684db65ddbd067cf7c9753ecc5a2966e08071096e04108-9ff08486ccbea7df374c97f6ceff1433c8a4a5f262127efa981060150e27b056.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Meckes")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-39097")[#strong[#text("Mark Meckes")]]#text(size: 9pt, fill: rgb("596477"), " · 30 May 2009")])]

#text("Terry,")

#text("Ah, I see. Well, there’s more recent literature out there on the dependence on the dimension in multivariate Berry-Esseen theorems, but in that case I’m sure you’re right that it’s easier just to prove what you needed.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88144531339e5ac96b6d549077071fa58f5a8dc026f31a8f8a05212898f2363-7cce7eb1dd58ce73b721df302093a3e33e7569b7272a9c7d1996547281a4c7fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-46694")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2010")])]

#text("Dear Terry,")

#text("Using dimensional analysis, we can easily rule out certain Sobolev embeddings as you discussed in 245C Notes 4 and in your notes on tensor power trick. Many of the estimates in random matrix theory seems out of the blue. Can some of these estimates, both for the square matrix and rectangular matrix case, be quickly derived as necessary condition by off the shelf dimensional analysis heuristics? Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88144531339e5ac96b6d549077071fa58f5a8dc026f31a8f8a05212898f2363-7cce7eb1dd58ce73b721df302093a3e33e7569b7272a9c7d1996547281a4c7fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-46695")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2010")])]

#text("In other words, what kind of scaling heuristic can one use (if at all) to guess tail bound inequalities rather than complete integral inequalities as in Sobolev embeddings?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-46710")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2010")])]

#text("Dimensional analysis is of limited value for random matrix theory since there are multiple scales in play, although if one adopts the heuristic that the tensor product of an ")#mi("n \\times n")#text(" and an ")#mi("m \\times m")#text(" matrix behaves like a random ")#mi("nm \\times nm")#text(" matrix, one can at least obtain the prediction that many key statistics of a matrix (e.g. largest and smallest singular values) should behave according to a power law in the dimension ")#mi("n")#text(". However this argument does not reveal what the exponent of such power laws should be.")

#text("Nevertheless, there are still ad hoc heuristics available. For instance, there is a close analogy between the ")#mi("i^{th}")#text(" largest singular value of a matrix, and the distance ")#mi("\\text{dist}(X_i,V_i)")#text(" between the ")#mi("i^{th}")#text(" row ")#mi("X_i")#text(" and the span ")#mi("V_i")#text(" of the preceding ")#mi("i-1")#text(" rows (assuming the rows are “generically ordered” in some sense). Using this together with concentration of measure heuristics, one can arrive at such conclusions as that the least singular value of a ")#mi("n \\times n")#text(" matrix should be comparable to ")#mi("1/\\sqrt{n}")#text(".")

#text("Another common way to obtain heuristics is to work with a tractable explicit model, such as GUE, and assume as a universality heuristic that other random matrix models with the same basic statistics as GUE (e.g. mean and variance of the entries) will enjoy similar behaviour.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2349d12672e95192918e28a36fada35dfca4cffa9a9abd11dc070723cbf4f15b-b86fad0271310ac49e7a773f3dd164343472c696df50b55eb7d530dbb36e4d1f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of PKG")]], [#link("https://terrytao.wordpress.com/2009/03/04/random-matrices-the-distribution-of-the-smallest-singular-values/#comment-48377")[#strong[#text("PKG")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("Can we apply any of this theory to determine the distribution of the (induced) ")#mi("p")#text(" -norm of a random square matrix?")
]
