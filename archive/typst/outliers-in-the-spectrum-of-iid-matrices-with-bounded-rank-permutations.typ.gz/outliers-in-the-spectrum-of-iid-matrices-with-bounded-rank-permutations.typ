// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/
// Converted to Typst by tao2typ: "2026-10-14T15:17:58.865620+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Outliers in the spectrum of iid matrices with bounded rank perturbations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Outliers in the spectrum of iid matrices with bounded rank perturbations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 December 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/")[#text("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("I’ve just uploaded to the arXiv my paper “")#link("http://arxiv.org/abs/1012.4818")[#text("Outliers in the spectrum of iid matrices with bounded rank perturbations")]#text("“, submitted to ")#link("http://www.springer.com/mathematics/probability/journal/440")[#text("Probability Theory and Related Fields")]#text(". This paper is concerned with outliers to the ")#emph[#text("circular law")]#text(" for iid random matrices. Recall that if ")#mi("{X_n}")#text(" is an ")#mi("{n \\times n}")#text(" matrix whose entries are iid complex random variables with mean zero and variance one, then the ")#mi("{n}")#text(" complex eigenvalues of the normalised matrix ")#mi("{\\frac{1}{\\sqrt{n}} X_n}")#text(" will almost surely be distributed according to the circular law distribution ")#tao-math("{\\frac{1}{\\pi} 1_{\\left|z\\right| \\leq 1} d^2 z}", block: false)#text(" in the limit ")#mi("{n \\rightarrow \\infty}")#text(". (See ")#link("https://terrytao.wordpress.com/2010/03/14/254a-notes-8-the-circular-law/")[#text("these lecture notes")]#text(" for further discussion of this law.)")

#text("The circular law is also stable under bounded rank perturbations: if ")#mi("{C_n}")#text(" is a deterministic rank ")#mi("{O(1)}")#text(" matrix of polynomial size (i.e. of operator norm ")#mi("{O(n^{O(1)})}")#text("), then the circular law also holds for ")#mi("{\\frac{1}{\\sqrt{n}} X_n + C_n}")#text(" (this is proven in a paper of myself, Van Vu, and Manjunath Krisnhapur). In particular, the bulk of the eigenvalues (i.e. ")#mi("{(1-o(1)) n}")#text(" of the ")#mi("{n}")#text(" eigenvalues) will lie inside the unit disk ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z\\right| \\leq 1 \\}}", block: false)#text(".")

#text("However, this leaves open the possibility for one or more ")#emph[#text("outlier")]#text(" eigenvalues that lie significantly outside the unit disk; the arguments in the paper cited above give some upper bound on the number of such eigenvalues (of the form ")#mi("{O(n^{1-c})}")#text(" for some absolute constant ")#mi("{c>0}")#text(") but does not exclude them entirely. And indeed, numerical data shows that such outliers can exist for certain bounded rank perturbations.")

#text("In this paper, some results are given as to when outliers exist, and how they are distributed. The easiest case is of course when there is no bounded rank perturbation: ")#mi("{C_n=0}")#text(". In that case, an old result ")#link("http://www.ams.org/mathscinet-getitem?mr=863545")[#text("of Bai and Yin")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=866352")[#text("of Geman")]#text(" shows that the ")#link("http://en.wikipedia.org/wiki/Spectral_radius")[#text("spectral radius")]#text(" of ")#mi("{\\frac{1}{\\sqrt{n}} X_n}")#text(" is almost surely ")#mi("{1+o(1)}")#text(", thus all eigenvalues will be contained in a ")#mi("{o(1)}")#text(" neighbourhood of the unit disk, and so there are no significant outliers. The proof is based on the moment method.")

#text("Now we consider a bounded rank perturbation ")#mi("{C_n}")#text(" which is nonzero, but which has a bounded operator norm: ")#tao-math("{\\left\\|C_n\\right\\|_{op} = O(1)}", block: false)#text(". In this case, it turns out that the matrix ")#mi("{\\frac{1}{\\sqrt{n}} X_n + C_n}")#text(" will have outliers if the deterministic component ")#mi("{C_n}")#text(" has outliers. More specifically (and under the technical hypothesis that the entries of ")#mi("{X_n}")#text(" have bounded fourth moment), if ")#mi("{\\lambda}")#text(" is an eigenvalue of ")#mi("{C_n}")#text(" with ")#tao-math("{\\left|\\lambda\\right| > 1}", block: false)#text(", then (for ")#mi("{n}")#text(" large enough), ")#mi("{\\frac{1}{\\sqrt{n}} X_n + C_n}")#text(" will almost surely have an eigenvalue at ")#mi("{\\lambda+o(1)}")#text(", and furthermore these will be the only outlier eigenvalues of ")#mi("{\\frac{1}{\\sqrt{n}} X_n + C_n}")#text(".")

#text("Thus, for instance, adding a bounded nilpotent low rank matrix to ")#mi("{\\frac{1}{\\sqrt{n}} X_n}")#text(" will not create any outliers, because the nilpotent matrix only has eigenvalues at zero. On the other hand, adding a bounded Hermitian low rank matrix will create outliers as soon as this matrix has an operator norm greater than ")#mi("{1}")#text(".")

#text("When I first thought about this problem (which was communicated to me by Larry Abbott), I believed that it was quite difficult, because I knew that the eigenvalues of non-Hermitian matrices were quite unstable with respect to general perturbations (as discussed in ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("this previous blog post")]#text("), and that there were no interlacing inequalities in this case to control bounded rank perturbations (as discussed ")#link("https://terrytao.wordpress.com/2010/01/12/254a-notes-3a-eigenvalues-and-sums-of-hermitian-matrices/")[#text("in this post")]#text("). However, as it turns out I had arrived at the wrong conclusion, especially in the exterior of the unit disk in which the resolvent is actually well controlled and so there is no pseudospectrum present to cause instability. This was pointed out to me by ")#link("http://www.umpa.ens-lyon.fr/~aguionne/")[#text("Alice Guionnet")]#text(" at an AIM workshop last week, after I had posed the above question during an open problems session. Furthermore, at the same workshop, ")#link("http://en.wikipedia.org/wiki/Percy_Deift")[#text("Percy Deift")]#text(" emphasised the point that the basic determinantal identity ")#metadata(none) <tao-88ea8da72e460308e52e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\det(1 + AB) = \\det(1 + BA)")]]

#text("for ")#mi("{n \\times k}")#text(" matrices ")#mi("{A}")#text(" and ")#mi("{k \\times n}")#text(" matrices ")#mi("{B}")#text(" was a particularly useful identity in random matrix theory, as it converted problems about large (")#mi("{n \\times n}")#text(") matrices into problems about small (")#mi("{k \\times k}")#text(") matrices, which was particularly convenient in the regime when ")#mi("{n \\rightarrow \\infty}")#text(" and ")#mi("{k}")#text(" was fixed. (Percy was speaking in the context of invariant ensembles, but the point is in fact more general than this.)")

#text("From this, it turned out to be a relatively simple manner to transform what appeared to be an intractable ")#mi("{n \\times n}")#text(" matrix problem into quite a well-behaved ")#mi("{k \\times k}")#text(" matrix problem for bounded ")#mi("{k}")#text(". Specifically, suppose that ")#mi("{C_n}")#text(" had rank ")#mi("{k}")#text(", so that one can factor ")#mi("{C_n = A_n B_n}")#text(" for some (deterministic) ")#mi("{n \\times k}")#text(" matrix ")#mi("{A_n}")#text(" and ")#mi("{k \\times n}")#text(" matrix ")#mi("{B_n}")#text(". To find an eigenvalue ")#mi("{z}")#text(" of ")#mi("{\\frac{1}{\\sqrt{n}} X_n + C_n}")#text(", one has to solve the characteristic polynomial equation")

#align(center)[#tao-fit-display[#mitex("\\det( \\frac{1}{\\sqrt{n}} X_n + A_n B_n - z ) = 0.")]]

#text("This is an ")#mi("{n \\times n}")#text(" determinantal equation, which looks difficult to control analytically. But we can manipulate it using ")#link(<tao-88ea8da72e460308e52e>)[#text("(1)")]#text(". If we make the assumption that ")#mi("{z}")#text(" is outside the spectrum of ")#mi("{\\frac{1}{\\sqrt{n}} X_n}")#text(" (which we can do as long as ")#mi("{z}")#text(" is well away from the unit disk, as the unperturbed matrix ")#mi("{\\frac{1}{\\sqrt{n}} X_n}")#text(" has no outliers), we can divide by ")#mi("{\\frac{1}{\\sqrt{n}} X_n - z}")#text(" to arrive at")

#align(center)[#tao-fit-display[#mitex("\\det( 1 + (\\frac{1}{\\sqrt{n}} X_n-z)^{-1} A_n B_n ) = 0.")]]

#text("Now we apply the crucial identity ")#link(<tao-88ea8da72e460308e52e>)[#text("(1)")]#text(" to rearrange this as")

#align(center)[#tao-fit-display[#mitex("\\det( 1 + B_n (\\frac{1}{\\sqrt{n}} X_n-z)^{-1} A_n ) = 0.")]]

#text("The crucial point is that this is now an equation involving only a ")#mi("{k \\times k}")#text(" determinant, rather than an ")#mi("{n \\times n}")#text(" one, and is thus much easier to solve. The situation is particularly simple for rank one perturbations")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\sqrt{n}} X_n + u_n v_n^*")]]

#text("in which case the eigenvalue equation is now just a scalar equation")

#align(center)[#tao-fit-display[#mitex("1 + \\langle (\\frac{1}{\\sqrt{n}} X_n-z)^{-1} u_n, v_n \\rangle = 0")]]

#text("that involves what is basically a single coefficient of the resolvent ")#mi("{(\\frac{1}{\\sqrt{n}} X_n-z)^{-1}}")#text(". (It is also an instructive exercise to derive this eigenvalue equation directly, rather than through ")#link(<tao-88ea8da72e460308e52e>)[#text("(1)")]#text(".) There is by now a very well-developed theory for how to control such coefficients (particularly for ")#mi("{z}")#text(" in the exterior of the unit disk, in which case such basic tools as ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series")]#text(" work just fine); in particular, one has precise enough control on these coefficients to obtain the result on outliers mentioned above.")

#text("The same method can handle some other bounded rank perturbations. One basic example comes from looking at iid matrices with a non-zero mean ")#mi("{\\mu}")#text(" and variance ")#mi("{1}")#text("; this can be modeled by ")#mi("{\\frac{1}{\\sqrt{n}} X_n + \\mu \\sqrt{n} \\phi_n \\phi_n^*}")#text(" where ")#mi("{\\phi_n}")#text(" is the unit vector ")#mi("{\\phi_n := \\frac{1}{\\sqrt{n}} (1,\\ldots,1)^*}")#text(". Here, the bounded rank perturbation ")#mi("{\\mu \\sqrt{n} \\phi_n \\phi_n^*}")#text(" has a large operator norm (equal to ")#tao-math("{\\left|\\mu\\right| \\sqrt{n}}", block: false)#text("), so the previous result does not directly apply. Nevertheless, the self-adjoint nature of the perturbation has a stabilising effect, and I was able to show that there is still only one outlier, and that it is at the expected location of ")#mi("{\\mu \\sqrt{n}+o(1)}")#text(".")

#text("If one moves away from the case of self-adjoint perturbations, though, the situation changes. Let us now consider a matrix of the form ")#mi("{\\frac{1}{\\sqrt{n}} X_n + \\mu \\sqrt{n} \\phi_n \\psi_n^*}")#text(", where ")#mi("{\\psi_n}")#text(" is a randomised version of ")#mi("{\\phi_n}")#text(", e.g. ")#mi("{\\psi_n := \\frac{1}{\\sqrt{n}} (\\pm 1, \\ldots, \\pm 1)^*}")#text(", where the ")#mi("{\\pm 1}")#text(" are iid Bernoulli signs; such models were proposed recently by ")#link("http://prl.aps.org/abstract/PRL/v97/i18/e188104")[#text("Rajan and Abbott")]#text(" as a model for neural networks in which some nodes are excitatory (and give columns with positive mean) and some are inhibitory (leading to columns with negative mean). Despite the superficial similarity with the previous example, the outlier behaviour is now quite different. Instead of having one extremely large outlier (of size ")#mi("{\\sim\\sqrt{n}}")#text(") at an essentially deterministic location, we now have a number of eigenvalues of size ")#mi("{O(1)}")#text(", scattered according to a random process. Indeed, (in the case when the entries of ")#mi("{X_n}")#text(" were real and bounded) I was able to show that the outlier point process converged (in the sense of converging ")#mi("{k}")#text("-point correlation functions) to the zeroes of a random Laurent series")

#align(center)[#tao-fit-display[#mitex("g(z) = 1 - \\mu \\sum_{j=0}^\\infty \\frac{g_j}{z^{j+1}}")]]

#text("where ")#mi("{g_0,g_1,g_2,\\ldots \\equiv N(0,1)}")#text(" are iid real Gaussians. This is basically because the coefficients of the resolvent ")#mi("{(\\frac{1}{\\sqrt{n}} X_n - zI)^{-1}}")#text(" have a Neumann series whose coefficients enjoy a central limit theorem.")

#text("On the other hand, as already observed numerically (and rigorously, in the gaussian case) by Rajan and Abbott, if one projects such matrices to have row sum zero, then the outliers all disappear. This can be explained by another appeal to ")#link(<tao-88ea8da72e460308e52e>)[#text("(1)")]#text("; this projection amounts to right-multiplying ")#mi("{\\frac{1}{\\sqrt{n}} X_n + \\mu \\sqrt{n} \\phi_n \\psi_n^*}")#text(" by the projection matrix ")#mi("{P}")#text(" to the zero-sum vectors. But by ")#link(<tao-88ea8da72e460308e52e>)[#text("(1)")]#text(", the non-zero eigenvalues of the resulting matrix ")#mi("{(\\frac{1}{\\sqrt{n}} X_n + \\mu \\sqrt{n} \\phi_n \\psi_n^*)P}")#text(" are the same as those for ")#mi("{P (\\frac{1}{\\sqrt{n}} X_n + \\mu \\sqrt{n} \\phi_n \\psi_n^*)}")#text(". Since ")#mi("{P}")#text(" annihilates ")#mi("{\\phi_n}")#text(", we thus see that in this case the bounded rank perturbation plays no role, and the question reduces to obtaining a circular law with no outliers for ")#mi("{P \\frac{1}{\\sqrt{n}} X_n}")#text(". As it turns out, this can be done by invoking the machinery of Van Vu and myself that we used to prove the circular law for various random matrix models.")

#heading(level: 1)[#text("Comments (18)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49111")[#strong[#text("Djalil")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2010")])]

#text("Hi!")

#text("This reminds me this paper by Silverstein: ")#link("http://www.ams.org/mathscinet-getitem?mr=1284550")[#text("http://www.ams.org/mathscinet-getitem?mr=1284550")]

#text("About these matrices with iid entries, I wonder if one can prove the universality of the Gumbel fluctuation of the spectral radius (the result is known for the complex Ginibre ensemble).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49114")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2010")])]

#text("Thanks for the reference, which I was not aware of! Silverstein’s paper does indeed much give the same control on the outlier eigenvalue of ")#mi("\\frac{1}{\\sqrt{n}} X_n + \\mu \\phi_n \\phi_n^*")#text(" as my paper does (and indeed the methods are basically the same).")

#text("As for your second question, we don’t yet have enough fine-scale control on the circular law to come close to answering this sort of question yet – the behaviour in the boundary region ")#tao-math("\\left|z\\right|=1+o(1)", block: false)#text(", in particular, is still too delicate to resolve. (The results here avoid this because they only need one to understand the resolvent etc. in the region ")#tao-math("\\left|z\\right| \\geq 1+\\varepsilon", block: false)#text(" for some fixed ")#mi("\\varepsilon > 0")#text(" independent of ")#mi("n")#text(".)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e0671028695df12570b85a13a89a7c69cc72f386f749196ab56a7db3314f0b26-833881ac4a66553b60e4bd9be52437f821ebebd02c75da2691247c0cb10f64c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Djalil")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49144")[#strong[#text("Djalil")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2010")])]

#text("There is also this paper by Andrew:")#linebreak()#text(" ")#link("http://www.ams.org/mathscinet-getitem?mr=1062321")[#text("http://www.ams.org/mathscinet-getitem?mr=1062321")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bbc22f19756d4d233d777c86509e4f3a078c4b5b7135ca9befd2440ff29eab-d0f5bc0e1c3d0ed08e8866d56e45d1c45133d09afce2714c6fb634efbd89347f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49160")[#strong[#text("Timothy")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2010")])]

#text("Should be “This paper is concerned with”")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2010")])]

#text("I’ve deleted a number of comments on this post that involved (or were in response to) attempts at spoofing the identity of an author. Needless to say, such attempts are not welcome at this blog.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bbc22f19756d4d233d777c86509e4f3a078c4b5b7135ca9befd2440ff29eab-d0f5bc0e1c3d0ed08e8866d56e45d1c45133d09afce2714c6fb634efbd89347f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Timothy")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49190")[#strong[#text("Timothy")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2010")])]

#text("Shouldn’t it be “uploaded my paper.”")

#emph[#text("[Corrected, thanks. It’s been a while since I wrote a singly authored paper – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49234")[#strong[#text("Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2010")])]

#text("Shouldn’t it be “perturbation” instead of “permutation” in the title ?")

#text("By the way, the same technics were used to locate the outliers in the spectrums of either additive or multiplicative perturbations of rather general matrices in ")#link("http://hal.archives-ouvertes.fr/hal-00423593/fr/")[#text("http://hal.archives-ouvertes.fr/hal-00423593/fr/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49244")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2010")])]

#text("Thanks for the correction and for the reference!")

#text("Best,")

#text("Terry")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb967dd337b4403a9dd36c9b48641d43352bb1797f4bc6907b1c51e6dc0471ee-3ed973f3dd88f0c3c371a4808972391fb81d5765640b1a0a7b91874832e861c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raj Rao")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49351")[#strong[#text("Raj Rao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2011")])]

#text("In the paper:")#linebreak()#text(" Restricted rank modification of the symmetric eigenvalue problem: Theoretical considerations by Arbenz, Gander, Golub")

#text("the formula in your Remark 2.2 is referred to as the “modified Weinstein determinant” following Weinstein and Stenger’s “Methods for Intermediate Problems for Eigenvalues”.")

#text("Just FYI :-)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49380")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2011")])]

#text("Thanks for the reference!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb967dd337b4403a9dd36c9b48641d43352bb1797f4bc6907b1c51e6dc0471ee-3ed973f3dd88f0c3c371a4808972391fb81d5765640b1a0a7b91874832e861c7.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Raj Rao")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49352")[#strong[#text("Raj Rao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2011")])]

#text("(Or at least its analogue in the symmetric case)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49637")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2011")])]

#text("Terry, didn’t you have a post discussing identity (1)? Seems to have disappeared. (Maybe I’m confused?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49641")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2011")])]

#text("I discussed this identity at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2010/12/17/the-mesoscopic-structure-of-gue-eigenvalues/")[#text("The mesoscopic structure of GUE eigenvalues")]
]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1a91dbbd5705f8085aa4b368877768575736327e83b5112c35d161fc17b40dd-f68febc147b1909b1d766de009db17c4fcd3eef72ebe543fc408a7b0c9d6ad8b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of andrescaicedo")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-49644")[#strong[#text("andrescaicedo")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2011")])]

#text("Thanks!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aca2bcc99cce82428d29d868e85c2d4e71fb03f3bb2291b1cf6891f3dff7600a-155a9c3a8ba8b70b4fe195a0d7f3a5868b512349ceed4db2ff9a0e86945bcaf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yashar")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-51892")[#strong[#text("Yashar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("Hi Terry,")

#text("I have a question about the non-self-adjoint case that was studied by Rajan and Abbott. Simulations suggest that the total number of outlier eigenvalues (at least in the “balanced” case where the components of \\psi_n sum up to 0) scales like \\sqrt(n) (up to n ~ 3000). But you say above that the outlier point process converges to the zeros of that random Laurent series which is independent of n, suggesting that the number of outliers is O(1), and not O(\\sqrt(n)), and my simulations are not actually showing the very large n behavior.")#linebreak()#text(" Am I right (in concluding the number is O(1) based on what you say), or am I missing something?")#linebreak()#text(" I would really appreciate your answer.")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aca2bcc99cce82428d29d868e85c2d4e71fb03f3bb2291b1cf6891f3dff7600a-155a9c3a8ba8b70b4fe195a0d7f3a5868b512349ceed4db2ff9a0e86945bcaf1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yashar")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-51893")[#strong[#text("Yashar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 April 2011")])]

#text("I guess I found my own mistake: the Laurent series has infinite zeros actually…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb9dc21dc7cde7e44ac43909b6717dfa4bab9a9ac2c7ad4d6a5dab7f6ebbac08-0c4104d2eb6cfe4979ba0b4a067ea203f3f95380a501b583446cdbb306994f58.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Char")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-168108")[#strong[#text("Char")]]#text(size: 9pt, fill: rgb("596477"), " · 8 September 2012")])]

#text("Hi Terry, I have a question about the distribution of the outliers. According to Silverstein’s paper, outliers are N~(mu*n,sigma^2) given that the outliers are not normalised. I ran a simulation with R. I tried different values of n, mu, sigma and roughly 1000 matrices. I got the mean of the outliers of mu*n but I got the standard deviation approximately sigma*sqrt(2) instead of sigma. Is it a correct result?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matrix identities as derivatives of determinant identities « What’s new")]], [#link("https://terrytao.wordpress.com/2010/12/22/outliers-in-the-spectrum-of-iid-matrices-with-bounded-rank-permutations/#comment-213090")[#strong[#text("Matrix identities as derivatives of determinant identities « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2013")])]

#text("[…] for some . (This type of situation is also common in random matrix theory, for instance it arose in this previous paper of mine on outliers to the circular law.) If is invertible, then from (1) and (2) one […]")
]
