// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T16:34:49.566837+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "255B, Notes 2: Onsager’s conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("255B, Notes 2: Onsager’s conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 8 January 2019")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")[#text("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("We consider the incompressible Euler equations on the (Eulerian) torus ")#mi("{\\mathbf{T}_E := ({\\bf R}/{\\bf Z})^d}")#text(", which we write in divergence form as ")#metadata(none) <tao-f01a253efa149dd743ea>#mi("\\displaystyle  \\partial_t u^i + \\partial_j(u^j u^i) = - \\eta^{ij} \\partial_j p \\ \\ \\ \\ \\ (1)")#text(" ")#text(" ")#metadata(none) <tao-2dac033c4b9865349f81>#mi("\\displaystyle  \\partial_i u^i = 0, \\ \\ \\ \\ \\ (2)")#text(" ")#text(" where ")#mi("{\\eta^{ij}}")#text(" is the (inverse) Euclidean metric. Here we use the summation conventions for indices such as ")#mi("{i,j,l}")#text(" (reserving the symbol ")#mi("{k}")#text(" for other purposes), and are retaining the convention from ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(" of denoting vector fields using superscripted indices rather than subscripted indices, as we will eventually need to change variables to Lagrangian coordinates at some point. In principle, much of the discussion in this set of notes (particularly regarding the positive direction of Onsager’s conjecture) could also be modified to also treat non-periodic solutions that decay at infinity if desired, but some non-trivial technical issues do arise non-periodic settings for the negative direction.")

#text("As noted previously, the kinetic energy")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{\\mathbf{T}_E} \\left|u(t,x)\\right|^2\\ dx = \\frac{1}{2} \\int_{\\mathbf{T}_E} \\eta_{ij} u^i(t,x) u^j(t,x)\\ dx", block: true)]]

#text("is formally conserved by the flow, where ")#mi("{\\eta_{ij}}")#text(" is the Euclidean metric. Indeed, if one assumes that ")#mi("{u,p}")#text(" are continuously differentiable in both space and time on ")#mi("{[0,T] \\times \\mathbf{T}}")#text(", then one can multiply the equation ")#link(<tao-f01a253efa149dd743ea>)[#text("(1)")]#text(" by ")#mi("{u^l}")#text(" and contract against ")#mi("{\\eta_{il}}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("\\eta_{il} u^l \\partial_t u^i + \\eta_{il} u^l \\partial_j (u^j u^i) = - \\eta_{il} u^l \\eta^{ij} \\partial_j p = 0")]]

#text("which rearranges using ")#link(<tao-2dac033c4b9865349f81>)[#text("(2)")]#text(" and the product rule to")

#align(center)[#tao-fit-display[#mitex("\\partial_t (\\frac{1}{2} \\eta_{ij} u^i u^j) + \\partial_j( \\frac{1}{2} \\eta_{il} u^i u^j u^l ) + \\partial_j (u^j p)")]]

#text("and then if one integrates this identity on ")#mi("{[0,T] \\times \\mathbf{T}_E}")#text(" and uses Stokes’ theorem, one obtains the required energy conservation law")

#metadata(none) <tao-9c9cb20e5958db544952>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\frac{1}{2} \\int_{\\mathbf{T}_E} \\eta_{ij} u^i(T,x) u^j(T,x)\\ dx = \\frac{1}{2} \\int_{\\mathbf{T}_E} \\eta_{ij} u^i(0,x) u^j(0,x)\\ dx.")]]

#text("It is then natural to ask whether the energy conservation law continues to hold for lower regularity solutions, in particular weak solutions that only obey ")#link(<tao-f01a253efa149dd743ea>)[#text("(1)")]#text(", ")#link(<tao-2dac033c4b9865349f81>)[#text("(2)")]#text(" in a distributional sense. The above argument no longer works as stated, because ")#mi("{u^i}")#text(" is not a test function and so one cannot immediately integrate ")#link(<tao-f01a253efa149dd743ea>)[#text("(1)")]#text(" against ")#mi("{u^i}")#text(". And indeed, as we shall soon see, it is now known that once the regularity of ")#mi("{u}")#text(" is low enough, energy can “escape to frequency infinity”, leading to failure of the energy conservation law, a phenomenon known in physics as ")#emph[#text("anomalous energy dissipation")]#text(".")

#text("But what is the precise level of regularity needed in order to for this anomalous energy dissipation to occur? To make this question precise, we need a quantitative notion of regularity. One such measure is given by the Hölder space ")#mi("{C^{0,\\alpha}(\\mathbf{T}_E \\rightarrow {\\bf R})}")#text(" for ")#mi("{0 < \\alpha < 1}")#text(", defined as the space of continuous functions ")#mi("{f: \\mathbf{T}_E \\rightarrow {\\bf R}}")#text(" whose norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| f \\right\\|_{C^{0,\\alpha}(\\mathbf{T}_E \\rightarrow {\\bf R})} := \\sup_{x \\in \\mathbf{T}_E} \\left|f(x)\\right| + \\sup_{x,y \\in \\mathbf{T}_E: x \\neq y} \\frac{\\left|f(x)-f(y)\\right|}{\\left|x-y\\right|^\\alpha}", block: true)]]

#text("is finite. The space ")#mi("{C^{0,\\alpha}}")#text(" lies between the space ")#mi("{C^0}")#text(" of continuous functions and the space ")#mi("{C^1}")#text(" of continuously differentiable functions, and informally describes a space of functions that is “")#mi("{\\alpha}")#text(" times differentiable” in some sense. The above derivation of the energy conservation law involved the integral")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbf{T}_E} \\eta_{ik} u^k \\partial_j (u^j u^i)\\ dx")]]

#text("that roughly speaking measures the fluctuation in energy. Informally, if we could take the derivative in this integrand and somehow “integrate by parts” to split the derivative “equally” amongst the three factors, one would morally arrive at an expression that resembles")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbf{T}} \\nabla^{1/3} u \\nabla^{1/3} u \\nabla^{1/3} u\\ dx")]]

#text("which suggests that the integral can be made sense of for ")#mi("{u \\in C^0_t C^{0,\\alpha}_x}")#text(" once ")#mi("{\\alpha > 1/3}")#text(". More precisely, one can make")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Conjecture 1 (Onsager’s conjecture)")]#text(" Let ")#mi("{0 < \\alpha < 1}")#text(" and ")#mi("{d \\geq 2}")#text(", and let ")#mi("{0 < T < \\infty}")#text(".")

#list(
[#text("(i) If ")#mi("{\\alpha > 1/3}")#text(", then any weak solution ")#mi("{u \\in C^0_t C^{0,\\alpha}([0,T] \\times \\mathbf{T} \\rightarrow {\\bf R})}")#text(" to the Euler equations (in the Leray form ")#mi("{\\partial_t u + \\partial_j {\\mathbb P} (u^j u) = u_0(x) \\delta_0(t)}")#text(") obeys the energy conservation law ")#link(<tao-9c9cb20e5958db544952>)[#text("(3)")]#text(".")],
[#text("(ii) If ")#mi("{\\alpha \\leq 1/3}")#text(", then there exist weak solutions ")#mi("{u \\in C^0_t C^{0,\\alpha}([0,T] \\times \\mathbf{T} \\rightarrow {\\bf R})}")#text(" to the Euler equations (in Leray form) which do not obey energy conservation.")]
)
]

#text("This conjecture was originally arrived at ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=36116")[#text("by Onsager")]#text(" by a somewhat different heuristic derivation; see Remark ")#link(<tao-2e23f8b81d15612b4207>)[#text("7")]#text(". The numerology is also compatible with that arising from the Kolmogorov theory of turbulence (discussed in ")#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/")[#text("this previous post")]#text("), but we will not discuss this interesting connection further here.")

#text("The positive part (i) of Onsager conjecture was established by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1298949")[#text("Constantin, E, and Titi")]#text(", building upon earlier ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1302409")[#text("partial results by Eyink")]#text("; the proof is a relatively straightforward application of Littlewood-Paley theory, and they were also able to work in larger function spaces than ")#mi("{C^0_t C^{0,\\alpha}_x}")#text(" (using ")#mi("{L^3_x}")#text("-based Besov spaces instead of Hölder spaces, see Exercise ")#link(<tao-b781ffe68e4ae6c4248b>)[#text("3")]#text(" below). The negative part (ii) is harder. Discontinuous weak solutions to the Euler equations that did not conserve energy were first constructed ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1231007")[#text("by Sheffer")]#text(", with an alternate construction later ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1476315")[#text("given by Shnirelman")]#text(". ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2600877")[#text("De Lellis and Szekelyhidi noticed")]#text(" the resemblance of this problem to that of the Nash-Kuiper theorem in the isometric embedding problem, and began adapting the ")#emph[#text("convex integration")]#text(" technique used in that theorem to construct weak solutions of the Euler equations. This began a long series of papers in which increasingly regular weak solutions that failed to conserve energy were constructed, culminating in a ")#link("https://arxiv.org/abs/1608.08301")[#text("recent paper of Isett")]#text(" establishing part (ii) of the Onsager conjecture in the non-endpoint case ")#mi("{\\alpha < 1/3}")#text(" in three and higher dimensions ")#mi("{d \\geq 3}")#text("; the endpoint ")#mi("{\\alpha = 1/3}")#text(" remains open. (In two dimensions it may be the case that the positive results extend to a larger range than Onsager’s conjecture predicts; see ")#link("https://arxiv.org/abs/1509.03213")[#text("this paper of Cheskidov, Lopes Filho, Nussenzveig Lopes, and Shvydkoy")]#text(" for more discussion.) Further work continues into several variations of the Onsager conjecture, in which one looks at other differential equations, other function spaces, or other criteria for bad behavior than breakdown of energy conservation. See ")#link("https://arxiv.org/abs/1901.02318")[#text("this recent survey of de Lellis and Szekelyhidi")]#text(" for more discussion.")

#text("In these notes we will first establish (i), then discuss the convex integration method in the original context of the Nash-Kuiper embedding theorem. Before tackling the Onsager conjecture (ii) directly, we discuss a related construction of high-dimensional weak solutions in the Sobolev space ")#mi("{L^2_t H^s_x}")#text(" for ")#mi("{s}")#text(" close to ")#mi("{1/2}")#text(", which is slightly easier to establish, though still rather intricate. Finally, we discuss the modifications of that construction needed to establish (ii), though we shall stop short of a full proof of that part of the conjecture.")

#text("We thank Phil Isett for some comments and corrections.")

#metadata(none) <tao-a6a214898df7eb79a2a0>

#heading(level: 1)[#strong[#text(" — 1. Energy conservation for sufficiently regular weak solutions — ")]]

#text("We now prove the positive part (i) of Onsager’s conjecture, which turns out to be a straightforward application of Littlewood-Paley theory. We need the following relation between Hölder spaces and Littlewood-Paley projections:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" ")#metadata(none) <tao-e8b22d83b417e85ba4f2>#text(" Let ")#mi("{u \\in C^{0,\\alpha}(\\mathbf{T}_E \\rightarrow {\\bf R})}")#text(" for some ")#mi("{0 < \\alpha < 1}")#text(" and ")#mi("{d \\geq 1}")#text(". Establish the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{C^{0,\\alpha}(\\mathbf{T}_E \\rightarrow {\\bf R})} \\sim_{\\alpha,d} \\left\\| P_{\\leq 1} u \\right\\|_{C^0(\\mathbf{T}_E \\rightarrow {\\bf R})} + \\sup_{N > 1} N^\\alpha \\left\\| P_N u \\right\\|_{C^0(\\mathbf{T}_E \\rightarrow {\\bf R})}.", block: true)]]
]

#text("Let ")#mi("{u \\in C^0_t C^{0,\\alpha}([0,T] \\times \\mathbf{T}_E \\rightarrow {\\bf R})}")#text(" be a weak solution to the Euler equations for some ")#mi("{1/3 < \\alpha < 1}")#text(", thus ")#metadata(none) <tao-506458aa914ab182fe45>#mi("\\displaystyle  \\partial_t u + \\partial_j {\\mathbb P} (u^j u) = u_0(x) \\delta_0(t). \\ \\ \\ \\ \\ (4)")#text(" ")#text(" To show ")#link(<tao-9c9cb20e5958db544952>)[#text("(3)")]#text(", it will suffice from dominated convergence to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_{\\mathbf{T}_E} \\eta_{ij} P_{\\leq N} u^i(T,x) P_{\\leq N} u^i(T,x)\\ dx")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{2} \\int_{\\mathbf{T}_E} \\eta_{ij} P_{\\leq N} u^i(0,x) P_{\\leq N} u^j(0,x)\\ dx + o(1)")]]

#text("as ")#mi("{N \\rightarrow \\infty}")#text(". Applying ")#mi("{P_{\\leq N}}")#text(" to ")#link(<tao-506458aa914ab182fe45>)[#text("(4)")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t P_{\\leq N} u + \\partial_j P_{\\leq N} {\\mathbb P} (u^j u) = P_{\\leq N} u_0(x) \\delta_0(t).")]]

#text("From Bernstein’s inequality we conclude that ")#mi("{\\partial_t P_{\\leq N} u \\in C^0_t C^\\infty_x( \\mathbf{T}_E \\rightarrow {\\bf R}^d)}")#text(", and thus ")#mi("{u \\in C^1_t C^\\infty_x( \\mathbf{T}_E \\rightarrow {\\bf R}^d)}")#text(". Thus ")#mi("{P_{\\leq N} u}")#text(" solves the PDE")

#tao-aligned(keep: true)[


#tao-math("\\partial_t P_{\\leq N} u + \\partial_j P_{\\leq N} {\\mathbb P} (u^j u)  & = 0", block: true)



#tao-math("P_{\\leq N} u(0,x)  & = P_{\\leq N} u_0(x)", block: true)
]

#text("in the classical sense. We can then apply the fundamental theorem of calculus to write")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{2} \\int_{\\mathbf{T}_E} \\eta_{ij} P_{\\leq N} u^i(T,x) P_{\\leq N} u^j(T,x)\\ dx")]]

#tao-aligned(keep: true)[


#tao-math(" & = \\frac{1}{2} \\int_{\\mathbf{T}_E} \\eta_{ij} P_{\\leq N} u^i(0,x) P_{\\leq N} u^j(0,x)\\ dx", block: true)



#tao-math(" & + \\int_0^T \\int_{\\mathbf{T}} P_{\\leq N} u \\cdot \\partial_t P_{\\leq N} u\\ dx dt", block: true)
]

#text("and so it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{\\mathbf{T}_E} P_{\\leq N} u \\cdot \\partial_j P_{\\leq N} {\\mathbb P} (u^j u)\\ dx dt = o(1).")]]

#text("We can integrate by parts to place the Leray projection ")#mi("{{\\mathbb P}}")#text(" onto the divergence-free factor ")#mi("{u}")#text(", at which point it may be removed. Moving the derivative ")#mi("{\\partial_j}")#text(" over there as well, we now reduce to showing that")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{\\mathbf{T}_E} \\partial_j P_{\\leq N} u \\cdot P_{\\leq N} (u^j u)\\ dx dt = o(1).")]]

#text("On the other hand, the expression ")#mi("{\\partial_j P_{\\leq N} u \\cdot P_{\\leq N} u^j P_{\\leq N} u}")#text(" is a total derivative (as ")#mi("{u}")#text(" is divergence-free), and thus has vanishing integral. Thus it will remain to show that")

#align(center)[#tao-fit-display[#mitex("\\int_0^T \\int_{\\mathbf{T}_E} \\partial_j P_{\\leq N} u \\cdot [ P_{\\leq N} (u^j u) - P_{\\leq N} u^j P_{\\leq N} u] dx dt = o(1).")]]

#text("From Bernstein’s inequality, Exercise ")#link(<tao-e8b22d83b417e85ba4f2>)[#text("2")]#text(", and the triangle inequality one has for any time ")#mi("{t}")#text(" that")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\partial_j P_{\\leq N} u(t) \\right\\|_{L^\\infty_x}  & \\lesssim_d \\left\\| P_{\\leq 1} u(t) \\right\\|_{L^\\infty_x} + \\sum_{1 < N^{\\prime} \\leq N} N^{\\prime} \\left\\| P_{N^{\\prime}} u(t) \\right\\|_{L^\\infty_x}", block: true)



#tao-math(" & \\lesssim_{d,\\alpha} \\left\\| u(t) \\right\\|_{C^{0,\\alpha}_x} + \\sum_{1 < N^{\\prime} \\leq N} (N^{\\prime})^{1-\\alpha} \\left\\| u(t) \\right\\|_{C^{0,\\alpha}_x}", block: true)



#tao-math(" & \\lesssim_{d,\\alpha} N^{1-\\alpha} \\left\\| u \\right\\|_{C^0_t C^{0,\\alpha}_x};", block: true)
]

#text("as ")#tao-math("{ \\left\\| u \\right\\|_{C^0_t C^{0,\\alpha}_x}}", block: false)#text(" is finite, it thus suffices to establish the pointwise bound")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} (u^j u) - P_{\\leq N} u^j P_{\\leq N} u = o( N^{\\alpha-1} ).")]]

#text("We split the left-hand side into the sum of")

#metadata(none) <tao-9294ab38039f60d2ec53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("P_{\\leq N} (P_{\\leq N/4} u^j u) - P_{\\leq N/4} u^j P_{\\leq N} u")]]

#metadata(none) <tao-6c6dab33994f8b98bb9d>#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("P_{\\leq N} (P_{> N/4} u^j P_{\\leq N/4} u) - P_{\\leq N} P_{> N/4} u^j P_{\\leq N/4} u")]]

#text("and")

#metadata(none) <tao-8f434346648f6b96df89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("P_{\\leq N} (P_{> N/4} u^j P_{> N/4} u) - P_{\\leq N} P_{> N/4} u^j P_{\\leq N} P_{> N/4} u")]]

#text("where we use the fact that ")#mi("{P_{\\leq N} P_{\\leq N/4} = P_{\\leq N/4}}")#text(".")

#text("To treat ")#link(<tao-8f434346648f6b96df89>)[#text("(7)")]#text(", we use Exercise ")#link(<tao-e8b22d83b417e85ba4f2>)[#text("2")]#text(" to conclude that")

#align(center)[#tao-fit-display[#tao-math("P_{> N/4} u \\lesssim_{d,\\alpha} N^{-\\alpha} \\left\\| u \\right\\|_{C^0_t C^{0,\\alpha}_x}", block: true)]]

#text("and so the quantity ")#link(<tao-8f434346648f6b96df89>)[#text("(7)")]#text(" is ")#mi("{O_{\\alpha,d,u}(N^{-2\\alpha})}")#text(", which is acceptable since ")#mi("{\\alpha > 1/3}")#text(". Now we turn to ")#link(<tao-9294ab38039f60d2ec53>)[#text("(5)")]#text(". This is a commutator of the form")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} (f u) - f P_{\\leq N} u")]]

#text("where ")#mi("{f := P_{\\leq N/4} u^j}")#text(". Observe that this commutator would vanish if ")#mi("{u}")#text(" were replaced by ")#mi("{P_{\\leq N/4} u}")#text(", thus we may write this commutator as")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} (f g) - f P_{\\leq N} g")]]

#text("where ")#mi("{g := P_{> N/4} u}")#text(". If we write")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} g(x) = \\int_{{\\bf R}^d} \\psi(y) g( x + y/N )\\ dy")]]

#text("for a suitable Schwartz function ")#mi("{\\psi}")#text(" of total mass one, we have")

#align(center)[#tao-fit-display[#mitex("P_{\\leq N} (f g)(x) - f P_{\\leq N} g(x)")]]

#align(center)[#tao-fit-display[#mitex("= \\int_{{\\bf R}^d} \\psi(y) g( x + y/N ) (f(x+y/N) - f(x))\\ dy;")]]

#text("writing ")#tao-math("{f(x+y/N) - f(x) = O( \\frac{\\left|y\\right|}{N} \\left\\|\\nabla f \\right\\|_{C^0})}", block: false)#text(", we thus have the bound")

#align(center)[#tao-fit-display[#tao-math("P_{\\leq N} (f g) - f P_{\\leq N} g = O_d( N^{-1} \\left\\| g \\right\\|_{C^0} \\left\\|\\nabla f \\right\\|_{C^0}.", block: true)]]

#text("But from Bernstein’s inequality and Exercise ")#link(<tao-e8b22d83b417e85ba4f2>)[#text("2")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|\\nabla f \\right\\|_{C^0} \\lesssim_{d,\\alpha} N^{1-\\alpha} \\left\\| u \\right\\|_{C^0_t C^{0,\\alpha}_x}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|g \\right\\|_{C^0} \\lesssim_{d,\\alpha} N^{-\\alpha} \\left\\| u \\right\\|_{C^0_t C^{0,\\alpha}_x}", block: true)]]

#text("and so we see that ")#link(<tao-9294ab38039f60d2ec53>)[#text("(5)")]#text(" is also of size ")#mi("{O_{\\alpha,d,u}(N^{-2\\alpha})}")#text(", which is acceptable since ")#mi("{\\alpha > 1/3}")#text(". A similar argument gives ")#link(<tao-6c6dab33994f8b98bb9d>)[#text("(6)")]#text(", and the claim follows.")

#text("As shown by ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1298949")[#text("Constantin, E, and Titi")]#text(", the Hölder regularity in the above result can be relaxed to Besov regularity, at least in non-endpoint cases:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" ")#metadata(none) <tao-b781ffe68e4ae6c4248b>#text(" Let ")#mi("{\\alpha > 1/3}")#text(". Define the Besov space ")#mi("{B^3_{\\alpha,\\infty}(\\mathbf{T}_E \\rightarrow {\\bf R}^d)}")#text(" to be the space of functions ")#mi("{u \\in L^3(\\mathbf{T}_E \\rightarrow {\\bf R}^d)}")#text(" such that the Besov space norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u \\right\\|_{B^3_{\\alpha,\\infty}(\\mathbf{T}_E \\rightarrow {\\bf R}^d)} := \\left\\| P_{\\leq 1} u \\right\\|_{L^3(\\mathbf{T}_E \\rightarrow {\\bf R}^d)} + \\sup_{N>1} N^{\\alpha} \\left\\| P_N u \\right\\|_{L^3(\\mathbf{T}_E \\rightarrow {\\bf R}^d)}.", block: true)]]

#text("Show that if ")#mi("{u \\in L^3_t B^3_{\\alpha,\\infty}([0,T] \\times \\mathbf{T}_E \\rightarrow {\\bf R}^d)}")#text(" is a weak solution to the Euler equations, the energy ")#tao-math("{t \\mapsto \\frac{1}{2} \\int_{\\mathbf{T}_E} \\left|u(t,x)\\right|^2\\ dx}", block: false)#text(" is conserved in time.")
]

#text("The endpoint case ")#mi("{\\alpha=1/3}")#text(" of the above exercise is still open; however energy conservation in the slightly smaller space ")#mi("{B^3_{1/3,c({\\bf N})}}")#text(" is known thanks to the ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2422377")[#text("work of Cheskidov, Constantin, Friedlander, and Shvydkoy")]#text(" (see also ")#link("https://arxiv.org/abs/1706.01549")[#text("this paper of Isett")]#text(" for further discussion, and ")#link("https://arxiv.org/abs/1310.7947")[#text("this paper of Isett and Oh")]#text(" for an alternate argument that also works on Riemannian manifolds).")

#text("As ")#link("https://arxiv.org/abs/1307.0565")[#text("observed")]#text(" ")#link("https://arxiv.org/abs/1706.01549")[#text("by Isett")]#text(" (see also the ")#link("https://arxiv.org/abs/1811.12870")[#text("recent paper of Colombo and de Rosa")]#text("), the above arguments also give some partial information about the energy in the low regularity regime:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{u \\in C^0_t C^{0,\\alpha}([0,T] \\times \\mathbf{T} \\rightarrow {\\bf R})}")#text(" be a weak solution to the Euler equations for ")#mi("{0 < \\alpha < 1}")#text(".")

#list(
[#text("(i) If ")#mi("{\\alpha=1/3}")#text(", show that the energy ")#tao-math("{t \\mapsto \\frac{1}{2} \\int_{\\mathbf{T}} \\left|u(t,x)\\right|^2\\ dx}", block: false)#text(" is a ")#mi("{C^1}")#text(" function of time. (")#emph[#text("Hint:")]#text(" express the energy as the uniform limit of ")#tao-math("{t \\mapsto \\frac{1}{2} \\int_{\\mathbf{T}} \\left|P_{\\leq N} u(t,x)\\right|^2\\ dx}", block: false)#text(".)")],
[#text("(ii) If ")#mi("{0 < \\alpha < 1/3}")#text(", show that the energy ")#tao-math("{t \\mapsto \\frac{1}{2} \\int_{\\mathbf{T}} \\left|u(t,x)\\right|^2\\ dx}", block: false)#text(" is a ")#mi("{C^{0,\\frac{2\\alpha}{1-\\alpha}}}")#text(" function of time.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" Let ")#mi("{u \\in C^0_t C^{0,\\alpha}([0,T] \\times \\mathbf{T} \\rightarrow {\\bf R})}")#text(" be a weak solution to the Navier-Stokes equations for some ")#mi("{1/3 < \\alpha < 1}")#text(" with initial data ")#mi("{u_0}")#text(". Establish the energy identity")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{2} \\int_{\\mathbf{T}} \\left|u(T,x)\\right|^2 + \\nu \\int_0^T \\int_{\\mathbf{T}} \\left|\\nabla u(t,x)\\right|^2\\ dx dt = \\frac{1}{2} \\int_{\\mathbf{T}} \\left|u_0(x)\\right|^2\\ dx.", block: true)]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" An alternate heuristic derivation of the ")#mi("{\\alpha = 1/3}")#text(" threshold for the Onsager conjecture is as follows. If ")#mi("{u \\in C^0_t C^{0,\\alpha}}")#text(", then from Exercise ")#link(<tao-e8b22d83b417e85ba4f2>)[#text("2")]#text(" we see that the portion of ")#mi("{u}")#text(" that fluctuates at frequency ")#mi("{N}")#text(" has amplitude ")#mi("{A}")#text(" at most ")#mi("{A = O(N^{-\\alpha})}")#text("; in particular, the amount of energy at frequencies ")#mi("{\\sim N}")#text(" is at most ")#mi("{O(N^{-2\\alpha})}")#text(". On the other hand, by the heuristics in Remark 11 of ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("254A Notes 3")]#text(", the time ")#mi("{T}")#text(" needed for the portion of the solution at frequency ")#mi("{N}")#text(" to evolve to a higher frequency scale such as ")#mi("{2N}")#text(" is of order ")#mi("{T \\sim \\frac{1}{AN} \\gg N^{2\\alpha-1}}")#text(". Thus the rate of ")#emph[#text("energy flux")]#text(" at frequency ")#mi("{N}")#text(" should be ")#mi("{O( N^{-2\\alpha}/T ) = O(N^{1-3\\alpha})}")#text(". For ")#mi("{\\alpha>1/3}")#text(", the energy flux goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(", and so energy cannot escape to frequency infinity in finite time.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" ")#metadata(none) <tao-2e23f8b81d15612b4207>#text(" Yet another alternate heuristic derivation of the ")#mi("{\\alpha = 1/3}")#text(" threshold arises by considering the dynamics of individual Fourier coefficients. Using a Fourier expansion")

#align(center)[#tao-fit-display[#mitex("u(t,x) = \\sum_{k \\in {\\bf Z}^d} \\hat u(t,k) e^{2\\pi i k \\cdot x},")]]

#text("the Euler equations may be written as")

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\hat u^i(t,k) + 2\\pi i k_j \\sum_{k = k^{\\prime} + k^{\\prime\\prime}} \\hat u^i(t,k^{\\prime}) \\hat u^j(t,k^{\\prime\\prime})  & = - 2\\pi i k_i \\hat p(t,k)", block: true)



#tao-math("k_i \\hat u^i(t,k)  & = 0.", block: true)
]

#text("In particular, the energy ")#tao-math("{\\left|\\hat u(t,k)\\right|^2}", block: false)#text(" at a single Fourier mode ")#mi("{k \\in {\\bf Z}^d}")#text(" evolves according to the equation")

#metadata(none) <tao-5744de7a518cd1adedec>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\partial_t \\left|\\hat u(t,k)\\right|^2 = - 4 \\mathrm{Re}( \\pi i k_j \\sum_{k = k^{\\prime} + k^{\\prime\\prime}} \\eta_{il} \\hat u^i(t,-k)\\hat u^l(t,k^{\\prime}) \\hat u^j(t,k^{\\prime\\prime}) ).", block: true)]]

#text("If ")#mi("{u \\in C^0_t C^{0,\\alpha}}")#text(", then we have ")#mi("{P_N u = O( N^{-\\alpha})}")#text(" for any ")#mi("{N > 1}")#text(", hence by Plancherel’s theorem")

#align(center)[#tao-fit-display[#tao-math("\\sum_{k \\in {\\bf Z}^d: \\left|k\\right| \\sim N} \\left|\\hat u(t,k)\\right|^2 \\lesssim N^{-2\\alpha}", block: true)]]

#text("which suggests that (up to logarithmic factors) one would expect ")#mi("{\\hat u(t,k)}")#text(" to be of magnitude about ")#mi("{N^{-\\alpha-d/2}}")#text(". Onsager posited that for typically “turbulent” or “chaotic” flows, the main contributions to ")#link(<tao-5744de7a518cd1adedec>)[#text("(8)")]#text(" come when ")#mi("{k^{\\prime},k^{\\prime\\prime}}")#text(" have magnitude roughly comparable to that of ")#mi("{k}")#text(", and that the various summands should not be correlated strongly to each other. For ")#mi("{k \\sim N}")#text(", one might expect about ")#mi("{N^d}")#text(" significant terms in the sum, which according to standard “square root cancellation heuristics” (cf. the central limit theorem) suggests that the sum is about as large as ")#mi("{N^{-d/2}}")#text(" times the main term. Thus the total flux of energy in or out of a single mode ")#mi("{k}")#text(" would be expected to be of size ")#mi("{O( N^{d/2} N N^{-3(\\alpha+d/2)} = N^{1-3\\alpha} N^{-d} )}")#text(", and so the total flux in or out of the frequency range ")#tao-math("{\\left|k\\right| \\sim N}", block: false)#text(" (which consists of ")#mi("{\\sim N^d}")#text(" modes ")#mi("{k}")#text(") should be about ")#mi("{O(N^{1-3\\alpha})}")#text(". As such, for ")#mi("{\\alpha>1/3}")#text(" the energy flux should decay in ")#mi("{N}")#text(" and so there is no escape of energy to frequency infinity, whereas for ")#mi("{\\alpha < 1/3}")#text(" such an escape should be possible. Related heuristics can also support Kolmogorov’s 1941 model of the distribution of energy in the vanishing viscosity limit; see ")#link("https://terrytao.wordpress.com/2014/05/15/kolmogorovs-power-law-for-turbulence/")[#text("this blog post")]#text(" for more discussion. On the other hand, while Onsager did discuss the dynamics of individual Fourier coefficients in his paper, it appears that he arrived at the ")#mi("{1/3}")#text(" threshold by a more physical space based approach, a rigorous version of which was ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=1734632")[#text("eventually established by Duchon and Robert")]#text("; see ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=2214822")[#text("this survey of Eyink and Sreenivasan")]#text(" for more discussion.")
]

#heading(level: 1)[#strong[#text(" — 2. The (local) isometric embedding problem — ")]]

#text("Before we develop the convex integration method for fluid equations, we first discuss the simpler (and historically earlier) instance of this technique for the isometric embedding problem for Riemannian manifolds. To avoid some topological technicalities that are not the focus of the present set of notes, we only consider the ")#emph[#text("local problem")]#text(" of embedding a small neighbourhood ")#mi("{U}")#text(" of the origin ")#mi("{0}")#text(" in ")#mi("{{\\bf R}^d}")#text(" into Euclidean space ")#mi("{{\\bf R}^n}")#text(".")

#text("Let ")#mi("{U}")#text(" be an open neighbourhood of ")#mi("{0}")#text(" in ")#mi("{{\\bf R}^d}")#text(". A (smooth) Riemannian metric on ")#mi("{U}")#text(", when expressed in coordinates, is a family ")#mi("{g = (g_{ij})_{1 \\leq i,j \\leq d}}")#text(" of smooth maps ")#mi("{g_{ij}: U \\rightarrow {\\bf R}}")#text(" for ")#mi("{i,j=1,\\dots,d}")#text(", such that for each point ")#mi("{x \\in U}")#text(", the matrix ")#mi("{(g_{ij}(x))_{1 \\leq i,j \\leq d}}")#text(" is symmetric and positive definite. Any such metric ")#mi("{g}")#text(" gives ")#mi("{U}")#text(" the structure of an (incomplete) Riemannian manifold ")#mi("{(U, g)}")#text(". An ")#emph[#text("isometric embedding")]#text(" of this manifold into a Euclidean space ")#mi("{{\\bf R}^n}")#text(" is a map ")#mi("{\\Phi: U \\rightarrow {\\bf R}^n}")#text(" which is continuously differentiable, injective, and obeys the equation ")#metadata(none) <tao-729ea967840f148437cd>#mi("\\displaystyle  \\langle \\partial_i \\Phi, \\partial_j \\Phi \\rangle_{{\\bf R}^n} = g_{ij} \\ \\ \\ \\ \\ (9)")#text(" ")#text(" pointwise on ")#mi("{U}")#text(", where ")#mi("{\\langle, \\rangle_{{\\bf R}^n}}")#text(" is the usual inner product (or dot product) on ")#mi("{{\\bf R}^n}")#text(". In the differential geometry language from ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(", we are looking for an injective map ")#mi("{\\Phi}")#text(" such that the Euclidean metric ")#mi("{\\eta}")#text(" on ")#mi("{{\\bf R}^n}")#text(" pulls back to ")#mi("{g}")#text(" via ")#mi("{\\Phi}")#text(": ")#mi("{\\Phi^* \\eta = g}")#text(".")

#text("The ")#emph[#text("isometric embedding problem")]#text(" asks, given a Riemannian manifold such as ")#mi("{(U,g)}")#text(", whether there is an isometric embedding from this manifold to a Euclidean space ")#mi("{{\\bf R}^n}")#text("; for simplicity we only discuss the simpler ")#emph[#text("local isometric embedding problem")]#text(" of constructing an isometric immersion of ")#mi("{(U^{\\prime}, g)}")#text(" into ")#mi("{{\\bf R}^n}")#text(" for some sufficiently small neighbourhood ")#mi("{U^{\\prime} \\subset U}")#text(" of the origin. In particular for the local problem we do not need to worry about injectivity since ")#link(<tao-729ea967840f148437cd>)[#text("(9)")]#text(" ensures that the derivative map ")#mi("{D\\Phi}")#text(" is injective at the origin, and hence ")#mi("{\\Phi}")#text(" is injective near the origin by the inverse function theorem (indeed it is an ")#link("https://en.wikipedia.org/wiki/Immersion_(mathematics)")[#text("immersion")]#text(" near the origin).")

#text("It is a celebrated ")#link("https://en.wikipedia.org/wiki/Nash_embedding_theorem")[#text("theorem of Nash")]#text(" (discussed in ")#link("https://terrytao.wordpress.com/2016/05/11/notes-on-the-nash-embedding-theorem/")[#text("this previous blog post")]#text(") that the isometric embedding problem is possible in the smooth category if the dimension ")#mi("{n}")#text(" is large enough. For sake of discussion we just present the local version:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Nash embedding theorem)")]#text(" ")#metadata(none) <tao-a08a0fcbdeafd3c1b3a4>#text(" Suppose that ")#mi("{n}")#text(" is sufficiently large depending on ")#mi("{d}")#text(". Then for any smooth metric ")#mi("{g}")#text(" on a neighbourhood ")#mi("{U}")#text(" of the origin, there is a smooth local isometric embedding ")#mi("{\\Phi: U^{\\prime} \\rightarrow {\\bf R}^n}")#text(" on some smaller neighbourhood ")#mi("{U^{\\prime}}")#text(" of the origin.")
]

#text("The optimal value of ")#mi("{n}")#text(" depending on ")#mi("{d}")#text(" is not completely known, but it grows roughly quadratically in ")#mi("{d}")#text(". Indeed, in ")#link("http://www.ams.org/mathscinet-getitem?mr=1159298")[#text("this paper of Günther")]#text(" it is shown that one can take")

#align(center)[#tao-fit-display[#mitex("n = \\frac{d(d+3)}{2} + 5.")]]

#text("In the other direction, one cannot take ")#mi("{n}")#text(" below ")#mi("{\\frac{d(d+1)}{2}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Suppose that ")#mi("{n < \\frac{d(d+1)}{2}}")#text(". Then there exists a smooth Riemannian metric ")#mi("{g}")#text(" on an open neighbourhood ")#mi("{U}")#text(" of the origin in ")#mi("{{\\bf R}^d}")#text(" such that there is no smooth embedding ")#mi("{\\Phi}")#text(" from any smaller neighbourhood ")#mi("{U^{\\prime}}")#text(" of the origin to ")#mi("{{\\bf R}^n}")#text(".")
]

#emph[#text("Proof:")]#text(" Informally, the reason for this is that the given field ")#mi("{g_{ij}}")#text(" has ")#mi("{\\frac{d(d+1)}{2}}")#text(" degrees of freedom (which is the number of independent fields after accounting for the symmetry ")#mi("{g_{ij}=g_{ji}}")#text("), but there are only ")#mi("{n}")#text(" degrees of freedom for the unknown ")#mi("{\\Phi}")#text(". To make this rigorous, we perform a Taylor expansion of both ")#mi("{g_{ij}}")#text(" and ")#mi("{\\Phi}")#text(" around the origin up to some large order ")#mi("{N}")#text(", valid for a sufficiently small neighbourhood ")#mi("{U^{\\prime}}")#text(":")

#tao-aligned(keep: true)[


#tao-math("g_{ij}(x)  & = \\sum_{r_1,\\dots,r_d \\geq 0: r_1 + \\dots + r_d \\leq N} g_{ij, r_1,\\dots, r_d} x_1^{r_1} \\dots x_d^{r_d} + O( \\left|x\\right|^{N+1})", block: true)



#tao-math("\\Phi(x)  & = \\sum_{r_1,\\dots,r_d \\geq 0: r_1 + \\dots + r_d \\leq N+1} \\Phi_{r_1,\\dots, r_d} x_1^{r_1} \\dots x_d^{r_d} + O( \\left|x\\right|^{N}).", block: true)
]

#text("Equating coefficients, we see that the coefficients")

#metadata(none) <tao-9141decb6da0e1d51501>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("(g_{ij,r_1,\\dots,r_d})_{1 \\leq i \\leq j \\leq d; r_1+\\dots+r_d \\leq N} \\in {\\bf R}^{\\frac{d(d+1)}{2} \\binom{N+d-1}{d-1}}")]]

#text("are a polynomial function of the coefficients")

#align(center)[#tao-fit-display[#mitex("(\\Phi_{r_1,\\dots, r_d})_{1 \\leq i \\leq j \\leq d; r_1+\\dots+r_d \\leq N} \\in {\\bf R}^{n \\binom{N+d}{d-1}};")]]

#text("this polynomial can be written down explicitly if desired, but its precise form will not be relevant for the argument. Observe that the space of possible coefficients contains an open ball, as can be seen by considering arbitrary perturbations ")#mi("{g_{ij}}")#text(" of the Euclidean metric ")#mi("{\\delta_{ij}}")#text(" on ")#mi("{\\mathbf{T}}")#text(" (here it is important to restrict to ")#mi("{i \\leq j}")#text(" in order to avoid the symmetry constraint ")#mi("{g_{ji} = g_{ij}}")#text("; also, the positive definiteness of the metric will be automatic as long as one restricts to sufficiently small perturbations). Comparing dimensions, we conclude that if every smooth metric ")#mi("{g}")#text(" had a smooth embedding ")#mi("{\\Phi}")#text(", one must have the inequality")

#align(center)[#tao-fit-display[#mitex("\\frac{d(d+1)}{2} \\binom{N+d-1}{d-1} \\geq n \\binom{N+d}{d-1}.")]]

#text("Dividing by ")#mi("{N^{d-1}}")#text(" and sending ")#mi("{N \\rightarrow \\infty}")#text(", we conclude that ")#mi("{\\frac{d(d+1)}{2} \\geq n}")#text(". Taking contrapositives, the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" If one replaces “smooth” with “analytic”, one can reverse the arguments here using the ")#link("https://en.wikipedia.org/wiki/Cauchy%E2%80%93Kowalevski_theorem")[#text("Cauchy-Kowaleski theorem")]#text(" and show that any analytic metric on ")#mi("{{\\bf R}^d}")#text(" can be locally analytically embedded into ")#mi("{{\\bf R}^{\\frac{d(d+1)}{2}}}")#text("; this is a ")#link("https://www.encyclopediaofmath.org/index.php/Janet_theorem")[#text("classical result of Cartan and Janet")]#text(".")
]

#text("Apart from the slight gap in dimensions, this would seem to settle the question of when a ")#mi("{d}")#text("-dimensional metric may be locally isometrically embedded in ")#mi("{{\\bf R}^n}")#text(". However, all of the above arguments required the immersion map ")#mi("{\\Phi}")#text(" to be smooth (i.e., ")#mi("{C^\\infty}")#text("), whereas the definition of an isometric embedding only required the regularity of ")#mi("{C^1}")#text(".")

#text("It is a remarkable (and somewhat counter-intuitive) result of ")#link("https://www.ams.org/mathscinet-getitem?mr=0065993")[#text("Nash")]#text(" ")#link("https://www.ams.org/mathscinet-getitem?mr=0075640")[#text("and Kuiper")]#text(" that if one only requires the embedding to be in ")#mi("{C^1}")#text(", then one can embed into a much lower dimensional space:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 11 (Nash-Kuiper embedding theorem)")]#text(" ")#metadata(none) <tao-c5ed41e1d1058ec59bd0>#text(" Let ")#mi("{n \\geq d+1}")#text(". Then for any smooth metric ")#mi("{g}")#text(" on a neighbourhood ")#mi("{U}")#text(" of the origin, there is a ")#mi("{C^1}")#text(" local isometric embedding ")#mi("{\\Phi: U^{\\prime} \\rightarrow {\\bf R}^n}")#text(" on some smaller neighbourhood ")#mi("{U^{\\prime}}")#text(" of the origin.")
]

#text("Nash originally proved this theorem with the slightly weaker condition ")#mi("{n \\geq d+2}")#text("; Kuiper then obtained the optimal condition ")#mi("{n \\geq d+1}")#text(". The case ")#mi("{n=d}")#text(" fails due to curvature obstructions; for instance, if the Riemannian metric ")#mi("{g}")#text(" has positive ")#link("https://en.wikipedia.org/wiki/Scalar_curvature")[#text("scalar curvature")]#text(", then small Riemannian balls of radius ")#mi("{r}")#text(" will have (Riemannian) volume slightly less than their Euclidean counterparts, whereas any ")#mi("{C^1}")#text(" embedding into ")#mi("{{\\bf R}^d}")#text(" will preserve both Riemannian length and volume, preventing such an isometric embedding from existing.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 12")]#text(" One striking illustration of the distinction between the ")#mi("{C^1}")#text(" and smooth categories comes when considering isometric embeddings of the round sphere ")#mi("{S^2}")#text(" (with the usual metric) into Euclidean space ")#mi("{{\\bf R}^3}")#text(". It is a classical result (see e.g., ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=532834")[#text("Spivak’s book")]#text(") that the only ")#mi("{C^2}")#text(" isometric embeddings of ")#mi("{S^2}")#text(" in ")#mi("{{\\bf R}^3}")#text(" are the obvious ones coming from composing the inclusion map ")#mi("{\\iota: S^2 \\rightarrow {\\bf R}^3}")#text(" with an isometry of the Euclidean space; however, the Nash-Kuiper construction allows one to create an ")#mi("{C^1}")#text(" embedding of ")#mi("{S^2}")#text(" into an arbitrarily small ball! Thus the ")#mi("{C^1}")#text(" embedding problem lacks the “rigidity” of the ")#mi("{C^2}")#text(" embedding problem. This is an instance of a more general principle that nonlinear differential equations such as ")#link(<tao-9141decb6da0e1d51501>)[#text("(10)")]#text(" can become much less rigid when one weakens the regularity hypotheses demanded on the solution.")
]

#text("To prove this theorem we work with a ")#link("https://en.wikipedia.org/wiki/Relaxation_(approximation)")[#text("relaxation")]#text(" of the isometric embedding problem. We say that ")#mi("{(\\Phi,R)}")#text(" is a ")#emph[#text("short isometric embedding")]#text(" on ")#mi("{U^{\\prime}}")#text(" if ")#mi("{\\Phi: U^{\\prime} \\rightarrow {\\bf R}^n}")#text(", ")#mi("{R: U^{\\prime} \\rightarrow {\\bf R}^{d^2}}")#text(" solve the equation ")#metadata(none) <tao-2a424d3e0b26e3e4055d>#mi("\\displaystyle  \\langle \\partial_i \\Phi, \\partial_j \\Phi \\rangle_{{\\bf R}^n} + R_{ij} = g_{ij} \t\\ \\ \\ \\ \\ (11)")#text(" ")#text(" on ")#mi("{U^{\\prime}}")#text(" with the matrix ")#mi("{R(x) = (R_{ij}(x))_{1 \\leq i,j \\leq d}}")#text(" symmetric and positive definite for all ")#mi("{x \\in U^{\\prime}}")#text(". With the additional unknown field ")#mi("{R_{ij}}")#text(" it is much easier to solve the short isometric problem than the true problem. For instance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 13")]#text(" ")#metadata(none) <tao-97c10efe01d5c9c88704>#text(" Let ")#mi("{n \\geq d}")#text(", and let ")#mi("{g}")#text(" be a smooth Riemannian metric on a neighbourhood ")#mi("{U}")#text(" of the origin in ")#mi("{{\\bf R}^d}")#text(". There is at least one short isometric embedding ")#mi("{(\\Phi, R)}")#text(".")
]

#emph[#text("Proof:")]#text(" Set ")#mi("{\\Phi(x) := \\varepsilon \\iota(x)}")#text(" and ")#mi("{R_{ij} := g_{ij} - \\varepsilon \\eta_{ij}}")#text(" for a sufficiently small ")#mi("{\\varepsilon>0}")#text(", where ")#mi("{\\iota: {\\bf R}^d \\rightarrow {\\bf R}^n}")#text(" is the standard embedding, and ")#mi("{\\eta}")#text(" the Euclidean metric on ")#mi("{U}")#text("; this will be a short isometric embedding on some neighbourhood of the origin. ")#mi("\\Box")

#text("To create a true isometric embedding ")#mi("{\\Phi}")#text(", we will first construct a sequence ")#mi("{(\\Phi^{(N)},R^{(N)})}")#text(" of short embeddings with ")#mi("{R^{(N)}}")#text(" converging to zero in a suitable sense, and then pass to a limit. The key observation is then that by using the fact that the positive matrices lie in the convex hull of the rank one matrices, one can add a high frequency perturbation to the first component ")#mi("{\\Phi}")#text(" of a short embedding ")#mi("{(\\Phi,R)}")#text(" to largely erase the error term ")#mi("{R}")#text(", replacing it instead with a much higher frequency error.")

#text("We now prove Theorem ")#link(<tao-c5ed41e1d1058ec59bd0>)[#text("11")]#text(". The key iterative step is")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Iterative step)")]#text(" ")#metadata(none) <tao-d2b5f37e1eef51deddc9>#text(" Let ")#mi("{n \\geq d+1}")#text(", let ")#mi("{B}")#text(" be a closed ball in ")#mi("{{\\bf R}^d}")#text(", let ")#mi("{g}")#text(" be a smooth Riemannian metric on ")#mi("{B}")#text(", and let ")#mi("{(\\Phi,R)}")#text(" be a short isometric embedding on ")#mi("{B}")#text(". Then for any ")#mi("{\\varepsilon > 0}")#text(", one can find a short isometric embedding ")#mi("{(\\Phi^{\\prime},R^{\\prime})}")#text(" to ")#link(<tao-2a424d3e0b26e3e4055d>)[#text("(11)")]#text(" on ")#mi("{B}")#text(" with")

#tao-aligned(keep: true)[


#tao-math("\\left\\| R^{\\prime} \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}  & \\lesssim_{d,n} \\varepsilon", block: true)



#tao-math("\\left\\| \\Phi^{\\prime} - \\Phi \\right\\|_{C^0(B \\rightarrow {\\bf R}^{n})}  & \\lesssim_{d,n} \\varepsilon", block: true)



#tao-math("\\left\\| \\Phi^{\\prime} - \\Phi \\right\\|_{C^1(B \\rightarrow {\\bf R}^{n})}  & \\lesssim_{d,n} \\left\\| R \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}^{1/2} + \\varepsilon.", block: true)
]
]

#text("Suppose for the moment that we had Theorem ")#link(<tao-d2b5f37e1eef51deddc9>)[#text("14")]#text(". Starting with the short isometric embedding ")#mi("{(\\Phi^{(0)}, R^{(0)})}")#text(" on a ball ")#mi("{B}")#text(" provided by Proposition ")#link(<tao-97c10efe01d5c9c88704>)[#text("13")]#text(", we can iteratively apply the above theorem to obtain a sequence of short isometric embeddings ")#mi("{(\\Phi^{(m)}, R^{(m)}, g)}")#text(" on ")#mi("{B}")#text(" with")

#tao-aligned(keep: true)[


#tao-math("\\left\\| R^{(m)} \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}  & \\lesssim_{d,n} 2^{-m}", block: true)



#tao-math("\\left\\| \\Phi^{(m)} - \\Phi^{(m-1)} \\right\\|_{C^0(B \\rightarrow {\\bf R}^{n})}  & \\lesssim_{d,n} 2^{-m}", block: true)



#tao-math("\\left\\| \\Phi^{(m)} - \\Phi^{(m-1)} \\right\\|_{C^1(B \\rightarrow {\\bf R}^{n})}  & \\lesssim_{d,n} \\left\\| R_{m-1} \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}^{1/2} + 2^{-m}.", block: true)
]

#text("for ")#mi("{m \\geq 1}")#text(". From this we see that ")#mi("{R^{(m)}}")#text(" converges uniformly to zero, while ")#mi("{\\Phi^{(m)}}")#text(" converges in ")#mi("{C^1}")#text(" norm to a ")#mi("{C^1}")#text(" limit ")#mi("{\\Phi}")#text(", which then solves ")#link(<tao-9141decb6da0e1d51501>)[#text("(10)")]#text(" on ")#mi("{B}")#text(", giving Theorem ")#link(<tao-c5ed41e1d1058ec59bd0>)[#text("11")]#text(". (Indeed, this shows that the space of ")#mi("{C^1}")#text(" isometric embeddings is dense in the space of ")#mi("{C^1}")#text(" short maps in the ")#mi("{C^0}")#text(" topology.)")

#text("We prove Theorem ")#link(<tao-d2b5f37e1eef51deddc9>)[#text("14")]#text(" through a sequence of reductions. Firstly, we can rearrange it slightly:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 15 (Iterative step, again)")]#text(" ")#metadata(none) <tao-31b44bb034859a747d92>#text(" Let ")#mi("{n \\geq d+1}")#text(", let ")#mi("{B}")#text(" be a closed ball in ")#mi("{{\\bf R}^d}")#text(", let ")#mi("{\\Phi: B \\rightarrow {\\bf R}^n}")#text(" be a smooth immersion, and let ")#mi("{R = (R_{ij})_{1 \\leq i,j \\leq d}}")#text(" be a smooth Riemannian metric on ")#mi("{B}")#text(". Then there exists a sequence ")#mi("{\\Phi^{(N)}: B \\rightarrow {\\bf R}^n}")#text(" of smooth immersions for ")#mi("{N=1,2,\\dots}")#text(" obeying the bounds")

#tao-aligned(keep: true)[


#tao-math("\\langle \\partial_i \\Phi^{(N)}, \\partial_j \\Phi^{(N)} \\rangle_{{\\bf R}^n}  & = \\langle \\partial_i \\Phi, \\partial_j \\Phi \\rangle_{{\\bf R}^n} + R_{ij} + o(1)", block: true)



#tao-math("\\Phi^{(N)}  & = \\Phi + o(1)", block: true)

#metadata(none) <tao-6199aecf23aba7e87b2d>

#tao-math("\\nabla \\Phi^{(N)}  & = \\nabla \\Phi + O_{d,n}( \\left\\| R \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}^{1/2} ) + o(1)", block: true, numbering: n => [#text("(12)")])
]

#text("uniformly on ")#mi("{B}")#text(" for ")#mi("{i,j=1,\\dots,d}")#text(", where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(" (for fixed choices of ")#mi("{n,d,B,\\Phi,R}")#text(").")
]

#text("Let us see how Theorem ")#link(<tao-31b44bb034859a747d92>)[#text("15")]#text(" implies Theorem ")#link(<tao-d2b5f37e1eef51deddc9>)[#text("14")]#text(". Let the notation and hypotheses be as in Theorem ")#link(<tao-d2b5f37e1eef51deddc9>)[#text("14")]#text(". We may assume ")#mi("{\\varepsilon>0}")#text(" to be small. Applying Theorem ")#link(<tao-31b44bb034859a747d92>)[#text("15")]#text(" with ")#mi("{R}")#text(" replaced by ")#mi("{R - \\varepsilon g}")#text(" (which will be positive definite for ")#mi("{\\varepsilon}")#text(" small enough), we obtain a sequence ")#mi("{\\Phi^{(N)}: B \\rightarrow {\\bf R}^n}")#text(" of smooth immersions obeying the estimates ")#metadata(none) <tao-a083e941775650d739e6>#tao-math("\\displaystyle  \\left\\| \\langle \\partial_i \\Phi^{(N)}, \\partial_j \\Phi^{(N)} \\rangle_{{\\bf R}^n} - \\langle \\partial_i \\Phi, \\partial_j \\Phi \\rangle_{{\\bf R}^n} - R_{ij} - \\varepsilon g_{ij} \\right\\|_{C^0( B \\rightarrow {\\bf R} )} = o(1) \\ \\ \\ \\ \\ (13)", block: false)

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\Phi^{(N)} - \\Phi \\right\\|_{C^0(B \\rightarrow {\\bf R}^n)}  & = o(1)", block: true)



#tao-math("\\left\\| \\Phi^{(N)} - \\Phi \\right\\|_{C^1(B \\rightarrow {\\bf R}^n)}  & \\lesssim_{d,n} \\left\\| R \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}^{1/2} + O(\\varepsilon) + o(1).", block: true)
]

#text("If we set")

#align(center)[#tao-fit-display[#mitex("R^{(N)}_{ij} := \\langle \\partial_i \\Phi, \\partial_j \\Phi \\rangle_{{\\bf R}^n} + R_{ij} - \\langle \\partial_i \\Phi^{(N)}, \\partial_j \\Phi^{(N)} \\rangle_{{\\bf R}^n}")]]

#text("then ")#mi("{R^{(N)}}")#text(" is smooth, symmetric, and (from ")#link(<tao-a083e941775650d739e6>)[#text("(13)")]#text(") will be positive definite for ")#mi("{N}")#text(" large enough. By construction, we thus have ")#mi("{(\\Phi^{(N)}, R^{(N)}, g)}")#text(" solving ")#link(<tao-2a424d3e0b26e3e4055d>)[#text("(11)")]#text(", and Theorem ")#link(<tao-d2b5f37e1eef51deddc9>)[#text("14")]#text(" follows.")

#text("To prove Theorem ")#link(<tao-31b44bb034859a747d92>)[#text("15")]#text(", it is convenient to break up the metric ")#mi("{R}")#text(" into more “primitive” pieces that are rank one matrices:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 16 (Rank one decomposition)")]#text(" ")#metadata(none) <tao-ae4a6acd7198ca1c9843>#text(" Let ")#mi("{B}")#text(" be a closed ball in ")#mi("{{\\bf R}^d}")#text(", and let ")#mi("{R = (R_{ij})_{1 \\leq i,j \\leq d}}")#text(" be a smooth Riemannian metric on ")#mi("{B}")#text(". Then there exists a finite collection ")#mi("{v^1,\\dots,v^K}")#text(" of unit vectors ")#mi("{v^k = (v^k_i)_{1 \\leq i \\leq d}}")#text(" in ")#mi("{{\\bf R}^d}")#text(", and smooth functions ")#mi("{a^1,\\dots,a^K: B \\rightarrow {\\bf R}}")#text(", such that")

#align(center)[#tao-fit-display[#mitex("R_{ij}(x) = \\sum_{k=1}^K a^k(x)^2 v^k_i v^k_j")]]

#text("for all ")#mi("{x \\in B}")#text(". Furthermore, for each ")#mi("{x \\in B}")#text(", at most ")#mi("{O_d(1)}")#text(" of the ")#mi("{a_k(x)}")#text(" are non-zero.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 17")]#text(" Strictly speaking, the unit vectors ")#mi("{v^k}")#text(" should belong to the dual space ")#mi("{({\\bf R}^d)^*}")#text(" of ")#mi("{{\\bf R}^d}")#text(" rather than ")#mi("{{\\bf R}^d}")#text(" itself, in order to have the index ")#mi("{i}")#text(" appear as subscripts instead of superscripts. A similar consideration occurs for the frequency vectors ")#mi("{k = (k_i)_{1 \\leq i \\leq d}}")#text(" from Remark ")#link(<tao-2e23f8b81d15612b4207>)[#text("7")]#text(". However, we will not bother to distinguish between ")#mi("{{\\bf R}^d}")#text(" and ")#mi("{({\\bf R}^d)^*}")#text(" here (since they are identified using the Euclidean metric).")
]

#emph[#text("Proof:")]#text(" Fix a point ")#mi("{x_0}")#text(" in ")#mi("{B}")#text(". Then the matrix ")#mi("{R = (R_{ij}(x_0))_{1 \\leq i,j \\leq d}}")#text(" is symmetric and positive definite; one can thus write ")#mi("{R = \\sum_{m=1}^d \\lambda_m (u^m)^T u^m}")#text(", where ")#mi("{u^1,\\dots,u^d}")#text(" is an orthonormal basis of (column) eigenvectors of ")#mi("{R}")#text(" and ")#mi("{\\lambda_m>0}")#text(" are the eigenvalues (we suppress for now the dependence of these objects on ")#mi("{x_0}")#text("). Using the parallelogram identity")

#align(center)[#tao-fit-display[#mitex("(u^m)^T (u^m) + (u^{m^{\\prime}})^T (u^{m^{\\prime}})")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{2} (u^m + u^{m^{\\prime}})^T (u^m + u^{m^{\\prime}}) + \\frac{1}{2} (u^m - u^{m^{\\prime}})^T (u^m - u^{m^{\\prime}})")]]

#text("we can then write")

#metadata(none) <tao-23721b788d0825539e5b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("R(x_0) = \\sum_{k=1}^{2d^2} (a^k)^2 (v^k)^T v^k")]]

#text("for some positive real numbers ")#mi("{a^k>0}")#text(", where ")#mi("{v^k}")#text(" are the ")#mi("{2d^2}")#text(" unit vectors of the form ")#mi("{\\frac{1}{\\sqrt{2}} (u^m \\pm u^{m^{\\prime}})}")#text(" for ")#mi("{1 \\leq m,m^{\\prime} \\leq d}")#text(", enumerated in an arbitrary order. From the further parallelogram identity")

#align(center)[#tao-fit-display[#mitex("(u^m)^T (u^{m^{\\prime}}) + (u^{m^{\\prime}})^T u^m")]]

#align(center)[#tao-fit-display[#mitex("= \\frac{1}{2} (u^m + u^{m^{\\prime}})^T (u^m + u^{m^{\\prime}}) - \\frac{1}{2} (u^m - u^{m^{\\prime}})^T (u^m - u^{m^{\\prime}})")]]

#text("we see that every sufficiently small symmetric perturbation of ")#mi("{R(x_0)}")#text(" also has a representation of the form ")#link(<tao-23721b788d0825539e5b>)[#text("(14)")]#text(" with slightly different coefficients ")#mi("{a^k}")#text(" that depend smoothly on the perturbation. As ")#mi("{R}")#text(" is smooth, we thus see that for ")#mi("{x}")#text(" sufficiently close to ")#mi("{x_0}")#text(" we have the decomposition")

#align(center)[#tao-fit-display[#mitex("R(x) = \\sum_{k=1}^{2d^2} a^k(x)^2 (v^k)^T (v^k)")]]

#text("for some positive quantities ")#mi("{a^k(x)}")#text(" varying smoothly with ")#mi("{x}")#text(". This gives the lemma in a small ball ")#mi("{B(x_0,r_0)}")#text(" centred at ")#mi("{x}")#text("; the claim then follows by covering ")#mi("{B}")#text(" by a finite number balls of the form ")#mi("{B(x_0,r_0/4)}")#text(" (say), covering these balls by balls ")#mi("{B(y_\\alpha,\\delta)}")#text(" of a fixed radius ")#mi("{\\delta}")#text(" smaller than all the ")#mi("{r_0/4}")#text(" in the finite cover, in such a way that any point lies in at most ")#mi("{O_d(1)}")#text(" of the balls ")#mi("{B(y_\\alpha,2\\delta)}")#text(", constructing a smooth partition of unity ")#mi("{1 = \\sum_\\alpha \\psi_\\alpha(x)^2}")#text(" adapted to the ")#mi("{B(y_\\alpha,2\\delta)}")#text(", multiplying each of the decompositions of ")#mi("{R(x)}")#text(" previously obtained on ")#mi("{B(y_i,2\\delta)}")#text(" (which each lie in one of the ")#mi("{B(x_0,r_0)}")#text(") by ")#mi("{\\psi_\\alpha(x)^2}")#text(", and summing to obtain the required decomposition on ")#mi("{B}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 18")]#text(" Informally, Lemma ")#link(<tao-ae4a6acd7198ca1c9843>)[#text("16")]#text(" lets one synthesize a metric ")#mi("{R_{ij}}")#text(" as a “")#link("https://www.encyclopediaofmath.org/index.php/Convex_integration")[#text("convex integral")]#text("” of rank one pieces, so that if the problem at hand has the freedom to “move” in the direction of each of these rank one pieces, then it also has the freedom to move in the direction ")#mi("{R_{ij}}")#text(", at least if one is working in low enough regularities that one can afford to rapidly change direction from one rank one perturbation to another. This convex integration technique was formalised ")#link("http://www.ams.org/mathscinet-getitem?mr=0864505")[#text("by Gromov")]#text(" in his interpretation of the Nash-Kuiper method as part of his “")#link("https://en.wikipedia.org/wiki/Homotopy_principle")[#mi("{h}")#text("-principle")]#text("“, which we will not discuss further here.")
]

#text("One can now deduce Theorem ")#link(<tao-31b44bb034859a747d92>)[#text("15")]#text(" from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 19 (Iterative step, rank one version)")]#text(" ")#metadata(none) <tao-fddd57f30ecef538db12>#text(" Let ")#mi("{n \\geq d+1}")#text(", let ")#mi("{B}")#text(" be a closed ball in ")#mi("{{\\bf R}^d}")#text(", let ")#mi("{\\Phi: B \\rightarrow {\\bf R}^n}")#text(" be a smooth immersion, let ")#mi("{v = (v_i)_{i=1,\\dots,d} \\in {\\bf R}^d}")#text(" be a unit vector, and let ")#mi("{a: B \\rightarrow {\\bf R}}")#text(" be smooth. Then there exists a sequence ")#mi("{\\Phi^{(N)}: B \\rightarrow {\\bf R}^n}")#text(" of smooth immersions for ")#mi("{N=1,2,\\dots}")#text(" obeying the bounds")

#metadata(none) <tao-6743572679faa7067f31>

#tao-aligned(keep: true)[


#tao-math("\\langle \\partial_i \\Phi^{(N)}, \\partial_j \\Phi^{(N)} \\rangle_{{\\bf R}^n}  & = \\langle \\partial_i \\Phi, \\partial_j \\Phi \\rangle_{{\\bf R}^n} + a^2 v_i v_j + o(1)", block: true, numbering: n => [#text("(15)")])



#tao-math("\\Phi^{(N)}  & = \\Phi + o(1)", block: true)



#tao-math("\\nabla \\Phi^{(N)}  & = \\nabla \\Phi + O_{d,n}(\\left\\| a \\right\\|_{C^0(B \\rightarrow {\\bf R})}) + o(1)", block: true)
]

#text("uniformly on ")#mi("{B}")#text(" for ")#mi("{i,j=1,\\dots,d}")#text(". Furthermore, the support of ")#mi("{\\Phi^{(N)}-\\Phi}")#text(" is contained in the support of ")#mi("{a}")#text(".")
]

#text("Indeed, suppose that Theorem ")#link(<tao-fddd57f30ecef538db12>)[#text("19")]#text(" holds, and we are in the situation of Theorem ")#link(<tao-31b44bb034859a747d92>)[#text("15")]#text(". We apply Lemma ")#link(<tao-ae4a6acd7198ca1c9843>)[#text("16")]#text(" to obtain the decomposition")

#align(center)[#tao-fit-display[#mitex("R_{ij}(x) = \\sum_{k=1}^K a^k(x)^2 v^k_i v^k_j")]]

#text("with the stated properties. On taking traces we see that")

#align(center)[#tao-fit-display[#tao-math("\\left\\|a^k\\right\\|_{C^0(B \\rightarrow {\\bf R})} \\lesssim_d \\left\\| R \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}^{1/2}", block: true)]]

#text("for all ")#mi("{k}")#text(". Applying Theorem ")#link(<tao-fddd57f30ecef538db12>)[#text("19")]#text(" ")#mi("{K}")#text(" times (and diagonalising the sequences as necessary), we obtain sequences ")#mi("{\\Phi^{(N,k)}: B \\rightarrow {\\bf R}^n}")#text(" of smooth immersions for ")#mi("{k=0,1,\\dots,K}")#text(" such that ")#mi("{\\Phi^{(N,0)} = \\Phi}")#text(" and one has")

#tao-aligned(keep: true)[


#tao-math("\\langle \\partial_i \\Phi^{(N,k)}, \\partial_j \\Phi^{(N,k)} \\rangle_{{\\bf R}^n}  & = \\langle \\partial_i \\Phi^{(N,k-1)}, \\partial_j \\Phi^{(N,k-1)} \\rangle_{{\\bf R}^n} + (a^k)^2 v^k_i v^k_j + o(1)", block: true)



#tao-math("\\Phi^{(N,k)}  & = \\Phi^{(N,k-1)} + o(1)", block: true)



#tao-math("\\Phi^{(N,k)}  & = \\Phi^{(N,k-1)} + O_{d,n}(\\left\\| R \\right\\|_{C^0(B \\rightarrow {\\bf R}^{d^2})}^{1/2}) + o(1),", block: true)
]

#text("an such that the support of ")#mi("{\\Phi^{(N,k)}-\\Phi^{(N,k-1)}}")#text(" is contained in that of ")#mi("{a^k}")#text(". The claim then follows from the triangle inequality, noting that the implied constant in ")#link(<tao-6199aecf23aba7e87b2d>)[#text("(12)")]#text(" will not depend on ")#mi("{K}")#text(" because of the bounded overlap in the supports of the ")#mi("{\\Phi^{(N,k)}-\\Phi^{(N,k-1)}}")#text(".")

#text("It remains to prove Theorem ")#link(<tao-fddd57f30ecef538db12>)[#text("19")]#text(". We note that the requirement that ")#mi("{\\Phi^{(N)}}")#text(" be an immersion will be automatic from ")#link(<tao-6743572679faa7067f31>)[#text("(15)")]#text(" for ")#mi("{N}")#text(" large enough since ")#mi("{\\Phi}")#text(" was already an immersion, making the matrix ")#mi("{(\\langle \\partial_i \\Phi(x), \\partial_j \\Phi(x) \\rangle_{{\\bf R}^n} )_{1 \\leq i,j \\leq n}}")#text(" positive definite uniformly for ")#mi("{x \\in B}")#text(", and this being unaffected by the addition of the ")#mi("{o(1)}")#text(" perturbation and the positive semi-definite rank one matrix ")#mi("{(a^2 v_i v_j)_{1 \\leq i,j \\leq n}}")#text(".")

#text("Writing ")#mi("{\\Phi^{(N)} = \\Phi + \\Psi^{(N)}}")#text(", it will suffice to find a sequence of smooth maps ")#mi("{\\Psi^{(N)}: B \\rightarrow {\\bf R}^n}")#text(" supported in the support of ")#mi("{a}")#text(" and obeying the approximate difference equation ")#metadata(none) <tao-d306c3ba79ff6256ca00>#mi("\\displaystyle  \\langle \\partial_i \\Psi^{(N)}, \\partial_j \\Phi \\rangle_{{\\bf R}^n} + \\langle \\partial_i \\Phi, \\partial_j \\Psi^{(N)} \\rangle_{{\\bf R}^n} + \\langle \\partial_i \\Psi^{(N)}, \\partial_j \\Psi^{(N)} \\rangle_{{\\bf R}^n} = a^2 v_i v_j + o(1) \\ \\ \\ \\ \\ (16)")#text(" ")#text(" and the bounds ")#metadata(none) <tao-0e857afd6f88a814e13d>#mi("\\displaystyle  \\Psi^{(N)} = o(1) \\ \\ \\ \\ \\ (17)")#text(" ")#text(" ")#metadata(none) <tao-3264257837ddf5883e2f>#tao-math("\\displaystyle  \\nabla \\Psi^{(N)} = O_{d,n}(\\left\\| a \\right\\|_{C^0(B \\rightarrow {\\bf R})}) + o(1) \\ \\ \\ \\ \\ (18)", block: false)#text(" ")#text(" uniformly on ")#mi("{B}")#text(".")

#text("To locate these functions ")#mi("{\\Psi^{(N)}}")#text(", we use the ")#emph[#text("method of slow and fast variables")]#text(". First we observe by applying a rotation that we may assume without loss of generality that ")#mi("{v}")#text(" is the unit vector ")#mi("{e_1}")#text(", thus ")#mi("{v_i = 1_{i=1}}")#text(". We then use the ansatz")

#align(center)[#tao-fit-display[#mitex("\\Psi^{(N)}(x) = \\frac{1}{N} \\mathbf{\\Psi}( x, N x \\text{ mod } {\\bf Z}^d )")]]

#text("where ")#mi("{\\mathbf{\\Psi}: B \\times \\mathbf{T}_F \\rightarrow {\\bf R}^n}")#text(" is a smooth function independent of ")#mi("{N}")#text(" to be chosen later; thus ")#mi("{\\Psi^{(N)}}")#text(" is a function both of the “slow” variable ")#mi("{x \\in B}")#text(" and the “fast” variable ")#mi("{y := Nx \\text{ mod } {\\bf Z}^d}")#text(" taking values in the“fast torus” ")#mi("{\\mathbf{T}_F := ({\\bf R}/{\\bf Z})^d}")#text(". (We adopt the convention here of using boldface symbols to denote functions of both the fast and slow variables. The fast torus is isomorphic to the Eulerian torus ")#mi("{\\mathbf{T}_E}")#text(" from the introduction, but we denote them by slightly different notation as they play different roles.) Thus ")#mi("{\\Psi^{(N)}}")#text(" is a low amplitude but highly oscillating perturbation to ")#mi("{\\Phi}")#text(". The fast variable oscillation means that ")#mi("{\\Psi^{(N)}}")#text(" will not be bounded in regularity norms higher than ")#mi("{C^1}")#text(" (and so this ansatz is not available for use in the smooth embedding problem), but because we only wish to control ")#mi("{C^0}")#text(" and ")#mi("{C^1}")#text(" type quantities, we will still be able to get adequate bounds for the purposes of ")#mi("{C^1}")#text(" embedding. Now that we have twice as many variables, the problem becomes more “underdetermined” and we can arrive at a simpler PDE by decoupling the role of the various variables (in particular, we will often work with PDE where the derivatives of the main terms are in the fast variables, but the coefficients only depend on the slow variables, and are thus effectively constant coefficient with respect to the fast variables).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 20")]#text(" ")#metadata(none) <tao-6ef7c9b15ecdd6908372>#text(" Informally, one should think of functions ")#mi("{f: B \\times \\mathbf{T}_F \\rightarrow {\\bf R}^m}")#text(" that are independent of the fast variable ")#mi("{y}")#text(" as being of “low frequency”, and conversely functions that have mean zero in the fast variable ")#mi("{y}")#text(" (thus ")#mi("{\\int_{{\\mathbf T}_F} f(x,y)\\ dy = 0}")#text(" for all ")#mi("{x}")#text(") as being of “high frequency”. Thus for instance any smooth function on ")#mi("{B \\times \\mathbf{T}_F}")#text(" can be uniquely decomposed into a “low frequency” component and a “high frequency” component, with the two components orthogonal to each other. In later sections we will start inverting “fast derivatives” ")#mi("{N \\nabla_y}")#text(" on “high frequency” functions, which will effectively gain important factors of ")#mi("{N^{-1}}")#text(" in the analysis. See also the table below for the dictionary between ordinary physical coordinates and fast-slow coordinates.")
]

#table(columns: 2, inset: 7pt, stroke: 0.5pt + rgb("d9dfe8"),
table.cell(colspan: 1, rowspan: 1)[#text("Position ")#mi("{x \\in U}")],
table.cell(colspan: 1, rowspan: 1)[#text("Slow variable ")#mi("{x \\in U}")],
table.cell(colspan: 1, rowspan: 1)[#text("Fast variable ")#mi("{Nx \\text{ mod } {\\bf Z}^d}")],
table.cell(colspan: 1, rowspan: 1)[#text("Fast variable ")#mi("{y \\in {\\bf T}_F}")],
table.cell(colspan: 1, rowspan: 1)[#text("Function ")#mi("{f( x, Nx \\text{ mod } {\\bf Z}^d)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Function ")#mi("{\\mathbf{f}(x,y)}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\partial_{x^i}}")],
table.cell(colspan: 1, rowspan: 1)[#mi("{\\partial_{x^i} + N \\partial_{y^i}}")],
table.cell(colspan: 1, rowspan: 1)[#text("Low-frequency function ")#mi("{f(x)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Function ")#mi("{f(x)}")#text(" independent of ")#mi("{y}")],
table.cell(colspan: 1, rowspan: 1)[#text("High-frequency function ")#mi("{f(x)}")],
table.cell(colspan: 1, rowspan: 1)[#text("Function ")#mi("{\\mathbf{f}(x,y)}")#text(" mean zero in ")#mi("{y}")],
table.cell(colspan: 1, rowspan: 1)[#text("N/A")],
table.cell(colspan: 1, rowspan: 1)[#text("Slow derivative ")#mi("{\\partial_{x^i}}")],
table.cell(colspan: 1, rowspan: 1)[#text("N/A")],
table.cell(colspan: 1, rowspan: 1)[#text("Fast derivative ")#mi("{\\partial_{y^i}}")]
)

#text("If we expand out using the chain rule, using ")#mi("{\\partial_{x_i}}")#text(" and ")#mi("{\\partial_{y_i}}")#text(" to denote partial differentiation in the coordinates of the slow and fast variables respectively, and noting that all terms with at least one power of ")#mi("{1/N}")#text(" can be absorbed into the ")#mi("{o(1)}")#text(" error, we see that we will be done as long as we can construct ")#mi("{\\mathbf{\\Psi}}")#text(" to obey the bounds ")#metadata(none) <tao-4bfc28283b1bceeb97d9>#tao-math("\\displaystyle  \\partial_{y_i} \\mathbf{\\Psi} = O_{d,n}(\\left\\| a \\right\\|_{C^0(B \\rightarrow {\\bf R})}) \\ \\ \\ \\ \\ (19)", block: false)#text(" ")#text(" and solve the exact equation ")#metadata(none) <tao-f0bf14acc6b4af5d29cc>#mi("\\displaystyle  \\langle \\partial_{y_i} \\mathbf{\\Psi}, \\partial_{x_j} \\Phi \\rangle_{{\\bf R}^n} + \\langle \\partial_{x_i} \\Phi, \\partial_{y_j} \\mathbf{\\Psi} \\rangle_{{\\bf R}^n} + \\langle \\partial_{y_i} \\mathbf{\\Psi}, \\partial_{y_j} \\mathbf{\\Psi} \\rangle_{{\\bf R}^n} = a^2 1_{i=j=1} \\ \\ \\ \\ \\ (20)")#text(" ")#text(" where ")#mi("{\\Phi, a}")#text(" are viewed as functions of the slow variable ")#mi("{x}")#text(" only. The original approach of Nash to solve this equation was to use a function ")#mi("{\\mathbf{\\Psi}}")#text(" that was orthogonal to the entire gradient of ")#mi("{\\Phi}")#text(", thus ")#metadata(none) <tao-584b5edc3da093d6bb49>#mi("\\displaystyle  \\langle \\partial_{x_i} \\Phi, \\mathbf{\\Psi} \\rangle_{{\\bf R}^n} = 0 \\ \\ \\ \\ \\ (21)")#text(" ")#text(" for ")#mi("{i=1,\\dots,d}")#text(". Taking derivatives in ")#mi("{y_j}")#text(" one would conclude that")

#align(center)[#tao-fit-display[#mitex("\\langle \\partial_{x_i} \\Phi, \\partial_{y_j} \\mathbf{\\Psi} \\rangle_{{\\bf R}^n} = 0")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("\\langle \\partial_{y_i} \\mathbf{\\Psi}, \\partial_{x_j} \\Phi \\rangle_{{\\bf R}^n} = 0,")]]

#text("and one now just had to solve the equation")

#metadata(none) <tao-0f0e99f465a65c3cb8a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\langle \\partial_{y_i} \\mathbf{\\Psi}, \\partial_{y_j} \\mathbf{\\Psi} \\rangle_{{\\bf R}^n} = a^2 1_{i=j=1}.")]]

#text("For this, Nash used a “spiral” construction")

#align(center)[#tao-fit-display[#mitex("\\mathbf{\\Psi}(x,y) = \\frac{a(x)}{2\\pi} ( u(x) \\cos(2\\pi y_1) + v(x) \\sin(2\\pi y_1) )")]]

#text("where ")#mi("{u,v: B \\rightarrow {\\bf R}^n}")#text(" were unit vectors varying smoothly with respect to the slow variable; this obeys ")#link(<tao-0f0e99f465a65c3cb8a7>)[#text("(22)")]#text(" and ")#link(<tao-4bfc28283b1bceeb97d9>)[#text("(19)")]#text(", and would also obey ")#link(<tao-584b5edc3da093d6bb49>)[#text("(21)")]#text(" if the vectors ")#mi("{u(x)}")#text(" and ")#mi("{v(x)}")#text(" were both always orthogonal to the entire gradient of ")#mi("{\\Phi}")#text(". This is not possible in ")#mi("{n=d+1}")#text(" (as ")#mi("{{\\bf R}^n}")#text(" cannot then support ")#mi("{d+2}")#text(" linearly independent vectors), but there is no obstruction for ")#mi("{n \\geq d+2}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 21 (Constructing an orthogonal frame)")]#text(" Let ")#mi("{\\Phi: B \\rightarrow {\\bf R}^n}")#text(" be an immersion. If ")#mi("{n \\geq d+2}")#text(", then there exist smooth vector fields ")#mi("{u,v: B \\rightarrow {\\bf R}^n}")#text(" such that at every point ")#mi("{x}")#text(", ")#mi("{u(x), v(x)}")#text(" are unit vectors orthogonal to each other and to ")#mi("{\\partial_{x_i} \\Phi(x)}")#text(" for ")#mi("{i=1,\\dots,d}")#text(".")
]

#emph[#text("Proof:")]#text(" Applying the Gram-Schmidt process to the linearly independent vectors ")#mi("{\\partial_{x_i} \\Phi(x)}")#text(" for ")#mi("{i=1,\\dots,d}")#text(", we can find an orthonormal system of vectors ")#mi("{w_1(x),\\dots,w_d(x)}")#text(", depending smoothly on ")#mi("{x \\in B}")#text(", whose span is the same as the span of the ")#mi("{\\partial_{x_i} \\Phi(x)}")#text(". Our task is now to find smooth functions ")#mi("{u,v: B \\rightarrow {\\bf R}^n}")#text(" solving the system of equations ")#metadata(none) <tao-e6184ce10e266134fdcf>#mi("\\displaystyle  \\langle u, u \\rangle_{{\\bf R}^n} = \\langle v,v \\rangle_{{\\bf R}^n} = 1 \\ \\ \\ \\ \\ (23)")#text(" ")#text(" ")#metadata(none) <tao-94582e5e0efa969706ef>#mi("\\displaystyle  \\langle u, v \\rangle_{{\\bf R}^n} = 0 \\ \\ \\ \\ \\ (24)")#text(" ")#text(" ")#metadata(none) <tao-61737afbdcf655054550>#mi("\\displaystyle  \\langle u, w_i \\rangle_{{\\bf R}^n} = \\langle v, w_i \\rangle_{{\\bf R}^n} = 0 \\ \\ \\ \\ \\ (25)")#text(" ")#text(" on ")#mi("{B}")#text(".")

#text("For ")#mi("{n \\geq d+2}")#text(" this is possible at the origin ")#mi("{x=0}")#text(" from the Gram-Schmidt process. Now we extend in the ")#mi("{e_1}")#text(" direction to the line segment ")#tao-math("{\\{ x_1 e_1: \\left|x_1\\right| \\leq 1 \\}}", block: false)#text(". To do this we evolve the fields ")#mi("{u,v}")#text(" by the ")#link("https://en.wikipedia.org/wiki/Parallel_transport")[#text("parallel transport")]#text(" ODE")

#tao-aligned(keep: true)[


#tao-math("\\partial_{x_1} u  & := - \\langle u, \\partial_{x_1} w_i \\rangle w_i", block: true)



#tao-math("\\partial_{x_1} v  & := - \\langle v, \\partial_{x_1} w_i \\rangle w_i", block: true)
]

#text("on this line segment. From the Picard existence and uniqueness theorem we can uniquely extend ")#mi("{u,v}")#text(" smoothly to this segment with the specified initial data at ")#mi("{0}")#text(", and a simple calculation using Gronwall’s inequality shows that the system of equations ")#link(<tao-e6184ce10e266134fdcf>)[#text("(23)")]#text(", ")#link(<tao-94582e5e0efa969706ef>)[#text("(24)")]#text(", ")#link(<tao-61737afbdcf655054550>)[#text("(25)")]#text(" is preserved by this evolution. Then, one can extend to the disk ")#mi("{\\{ x_1 e_1 + x_2 e_2: x_1^2+x_2^2 \\leq 1 \\}}")#text(" by using the previous extension to the segment as initial data and solving the parallel transport ODE")

#tao-aligned(keep: true)[


#tao-math("\\partial_{x_2} u  & := - \\langle u, \\partial_{x_2} w_i \\rangle w_i.", block: true)



#tao-math("\\partial_{x_2} v  & := - \\langle v, \\partial_{x_2} w_i \\rangle w_i.", block: true)
]

#text("Iterating this procedure we obtain the claim. ")#mi("\\Box")

#text("This concludes Nash’s proof of Theorem ")#link(<tao-c5ed41e1d1058ec59bd0>)[#text("11")]#text(" when ")#mi("{n \\geq d+2}")#text(". Now suppose that ")#mi("{n=d+1}")#text(". In this case we cannot locate two unit vector fields ")#mi("{u,v}")#text(" orthogonal to each other and to the entire gradient of ")#mi("{\\Phi}")#text("; however, we may still obtain one such vector field ")#mi("{u: B \\rightarrow {\\bf R}^n}")#text(" by repeating the above arguments. By Gram-Schmidt, we can then locate a smooth unit vector field ")#mi("{v: B \\rightarrow {\\bf R}^n}")#text(" which is orthogonal to ")#mi("{u}")#text(" and to ")#mi("{\\partial_i \\Phi}")#text(" for ")#mi("{i=2,\\dots,d}")#text(", but for which the quantity ")#mi("{c := 2\\langle v, \\partial_1 \\Phi \\rangle_{{\\bf R}^n}}")#text(" is positive. If we use the “Kuiper corrugation” ansatz")

#align(center)[#tao-fit-display[#mitex("\\mathbf{\\Psi}(x,y) = u(x) f(x, y_1) + v(x) g(x, y_1)")]]

#text("for some smooth functions ")#mi("{f,g: B \\times {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}}")#text(", one is reduced to locating such functions ")#mi("{f,g}")#text(" that obey the bounds")

#align(center)[#tao-fit-display[#mitex("\\partial_{y_1} f, \\partial_{y_1} g = O( a )")]]

#text("and the ODE")

#align(center)[#tao-fit-display[#mitex("(\\partial_{y_1} f)^2 + (\\partial_{y_1} g)^2 + c \\partial_{y_1} g = a^2.")]]

#text("This can be done by an explicit construction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22 (One-dimensional corrugation)")]#text(" For any positive ")#mi("{c>0}")#text(" and any ")#mi("{a \\geq 0}")#text(", show that there exist smooth functions ")#mi("{f,g: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}}")#text(" solving the ODE")

#align(center)[#tao-fit-display[#mitex("(f^{\\prime})^2 + (g^{\\prime})^2 + c g^{\\prime} = a^2")]]

#text("and which vary smoothly with ")#mi("{a,c}")#text(" (even at the endpoint ")#mi("{a=0}")#text("), and obey the bounds")

#align(center)[#tao-fit-display[#mitex("f^{\\prime}, g^{\\prime} = O(a).")]]

#text("(")#emph[#text("Hint:")]#text(" one can renormalise ")#mi("{c=1}")#text(". The problem is basically to locate a periodic function ")#mi("{t \\mapsto (X_a(t), Y_a(t))}")#text(" mapping ")#mi("{{\\bf R}/{\\bf Z}}")#text(" to the circle ")#mi("{\\{ (x,y): x^2 + y^2 + y = a^2 \\}}")#text(" of mean zero and Lipschitz norm ")#mi("{O(a)}")#text(" that varies smoothly with ")#mi("{a}")#text(". Choose ")#mi("{X_a(t) = a^2 X(t)}")#text(" for some smooth and small ")#mi("{X}")#text(" that is even and compactly supported in ")#mi("{(0,1/2) \\cup (1/2,1)}")#text(" with mean zero on each interval, and then choose ")#mi("{Y_a}")#text(" to be odd.)")
]

#text("This exercise supplies the required functions ")#mi("{f,g: B \\times {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}}")#text(", completing Kuiper’s proof of Theorem ")#link(<tao-c5ed41e1d1058ec59bd0>)[#text("11")]#text(" when ")#mi("{n \\geq d+1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 23")]#text(" For sake of discussion let us restrict attention to the surface case ")#mi("{d=2}")#text(". For the local isometric embedding problem, we have seen that we have rigidity at regularities at or above ")#mi("{C^2}")#text(", but lack of regularity at ")#mi("{C^1}")#text(". The precise threshold at which rigidity occurs is not completely known at present: a ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=116295")[#text("result")]#text(" ")#link("https://mathscinet.ams.org/mathscinet-getitem?mr=131225")[#text("of Borisov")]#text(" (also reproven ")#link("https://arxiv.org/abs/0905.0370")[#text("here")]#text(") gives rigidity at the ")#mi("{C^{1,\\alpha}}")#text(" level for ")#mi("{\\alpha > 2/3}")#text(", while ")#link("https://arxiv.org/abs/1510.01934")[#text("a result of de Lellis, Inauen, and Szekelyhidi")]#text(" (building upon a series of previous results) establishes non-rigidity when ")#mi("{\\alpha < 1/5}")#text(". For recent results in higher dimensions, see ")#link("https://arxiv.org/abs/1806.07335")[#text("this paper of Cao and Szekelyhidi")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 3. Low regularity weak solutions to Navier-Stokes in high dimensions — ")]]

#text("We now turn to constructing solutions (or near-solutions) to the Euler and Navier-Stokes equations. For minor technical reasons it is convenient to work with solutions that are periodic in both space and time, and normalised to have zero mean at every time (although the latter restriction is not essential for our arguments, since one can always reduce to this case after a Galilean transformation as in ")#link("https://terrytao.wordpress.com/2018/09/16/254a-notes-1-local-well-posedness-of-the-navier-stokes-equations/")[#text("254A Notes 1")]#text("). Accordingly, let ")#mi("{\\Omega}")#text(" denote the periodic spacetime")

#align(center)[#tao-fit-display[#mitex("\\Omega := ({\\bf R}/{\\bf Z}) \\times \\mathbf{T}_E,")]]

#text("and let ")#mi("{X^\\infty}")#text(" denote the space of smooth periodic functions ")#mi("{u: \\Omega \\rightarrow {\\bf R}^d}")#text(" that have mean zero and are divergence-free at every time ")#mi("{t \\in {\\bf R}/{\\bf Z}}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbf{T}_E} u(t,x)\\ dx = 0")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\partial_i u^i = 0.")]]

#text("We use ")#mi("{L^p_{t,x}}")#text(" as an abbreviation for ")#mi("{L^p_t L^p_x(\\Omega \\rightarrow {\\bf R}^m)}")#text(" for various vector spaces ")#mi("{{\\bf R}^m}")#text(" (the choice of which will be clear from context).")

#text("Let ")#mi("{\\nu \\geq 0}")#text(" (for now, our discussion will apply both to the Navier-Stokes equations ")#mi("{\\nu>0}")#text(" and the Euler equations ")#mi("{\\nu=0}")#text("). Smooth solutions to Navier-Stokes equations then take the form")

#align(center)[#tao-fit-display[#mitex("\\partial_t u^i + \\partial_j (u^i u^j) = \\nu \\Delta u^i - \\eta^{ij} \\partial_j p")]]

#text("for some ")#mi("{u \\in X^\\infty}")#text(" and smooth ")#mi("{p: \\Omega \\rightarrow {\\bf R}^d}")#text(". Here of course ")#mi("{\\Delta = \\eta^{ij} \\partial_i \\partial_j}")#text(" denotes the spatial Laplacian.")

#text("Much as we replaced the equation ")#link(<tao-9141decb6da0e1d51501>)[#text("(10)")]#text(" in the previous section with ")#link(<tao-2a424d3e0b26e3e4055d>)[#text("(11)")]#text(", we will consider the ")#link("https://en.wikipedia.org/wiki/Relaxation_(approximation)")[#text("relaxed")]#text(" version ")#metadata(none) <tao-7bfba6e0021f1fd1183d>#mi("\\displaystyle  \\partial_t u^i + \\partial_j( u^i u^j ) = \\nu \\Delta u^i + \\partial_j R^{ij} - \\eta^{ij} \\partial_j p \\ \\ \\ \\ \\ (26)")#text(" ")#text(" ")#metadata(none) <tao-cd35a2426062b7d58fd4>#mi("\\displaystyle  \\partial_i u^i = 0 \\ \\ \\ \\ \\ (27)")#text(" ")#text(" ")#metadata(none) <tao-571b0e35550136585f65>#mi("\\displaystyle  R^{ij} = R^{ji} \\ \\ \\ \\ \\ (28)")#text(" ")#text(" of the Navier-Stokes equations, where we have now introduced an additional field ")#mi("{R: \\Omega \\rightarrow {\\bf R}^{d^2}}")#text(", known as the ")#emph[#text("Reynolds stress")]#text(" (cf. the ")#link("https://en.wikipedia.org/wiki/Cauchy_stress_tensor")[#text("Cauchy stress tensor")]#text(" from ")#link("https://terrytao.wordpress.com/2018/09/03/254a-notes-0-physical-derivation-of-the-incompressible-euler-and-navier-stokes-equations/")[#text("254A Notes 0")]#text("). If ")#mi("{u: \\Omega \\rightarrow {\\bf R}^d}")#text(", ")#mi("{p: \\Omega \\rightarrow {\\bf R}}")#text(", ")#mi("{R: \\Omega \\rightarrow {\\bf R}^{d^2}}")#text(" are smooth solutions to ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(26)")]#text(", ")#link(<tao-cd35a2426062b7d58fd4>)[#text("(27)")]#text(", ")#link(<tao-571b0e35550136585f65>)[#text("(28)")]#text(", with ")#mi("{u}")#text(" having mean zero at every time, then we call ")#mi("{(u,p,R)}")#text(" a ")#emph[#text("Navier-Stokes-Reynolds flow")]#text(" (or ")#emph[#text("Euler-Reynolds flow")]#text(", if ")#mi("{\\nu=0}")#text("). Note that if ")#mi("{R=0}")#text(" then we recover a solution to the true Navier-Stokes equations. Thus, heuristically, the smaller ")#mi("{R}")#text(" is, the closer ")#mi("{u}")#text(" and ")#mi("{p}")#text(" should become to a solution to the true Navier-Stokes equations. (The Reynolds stress tensor ")#mi("{R^{ij}}")#text(" here is a rank ")#mi("{(2,0)}")#text(" tensor, as opposed to the rank ")#mi("{(0,2)}")#text(" tensor ")#mi("{R_{ij}}")#text(" used in the previous section to measure the failure of isometric embedding, but this will not be a particularly significant distinction.)")

#text("Note that if ")#mi("{(u,p,R)}")#text(" is a Navier-Stokes-Reynolds flow, and ")#mi("{v: \\Omega \\rightarrow {\\bf R}^d}")#text(", ")#mi("{q: \\Omega \\rightarrow {\\bf R}}")#text(", ")#mi("{S: \\Omega \\rightarrow {\\bf R}^{d^2}}")#text(" are smooth functions, then ")#mi("{(u+v, p+q, S)}")#text(" will also be a Navier-Stokes-Reynolds flow if and only if ")#mi("{v}")#text(" has mean zero at every time, and ")#mi("{(v,q,S)}")#text(" obeys the difference equation ")#metadata(none) <tao-49b34563133364660b1f>#mi("\\displaystyle  (\\partial_t - \\nu \\Delta) v^i + \\partial_j( u^i v^j + u^j v^i + v^i v^j + R^{ij} + q \\eta^{ij} - S^{ij} ) = 0 \\ \\ \\ \\ \\ (29)")#text(" ")#text(" ")#metadata(none) <tao-c46b1fd057d1817e00bc>#mi("\\displaystyle  \\partial_i v^i = 0 \\ \\ \\ \\ \\ (30)")#text(" ")#text(" ")#metadata(none) <tao-2c41142d00bc726bd9e3>#mi("\\displaystyle  S^{ij} = S^{ji}. \\ \\ \\ \\ \\ (31)")#text(" ")#text(" When this occurs, we say that ")#mi("{(v,q,S)}")#text(" is a ")#emph[#text("difference Navier-Stokes-Reynolds flow")]#text(" at ")#mi("{(u,p,R)}")#text(".")

#text("It will be thus of interest to find, for a given ")#mi("{(u,p,R)}")#text(", difference Navier-Stokes-Reynolds flows ")#mi("{(v,q,S)}")#text(" at ")#mi("{(u,p,R)}")#text(" with ")#mi("{S}")#text(" small, as one could hopefully iterate this procedure and take a limit to construct weak solutions to the true Euler equations. The main strategy here will be to choose a highly oscillating (and divergence-free) correction velocity field ")#mi("{v^i}")#text(" such that ")#mi("{v^i v^j}")#text(" approximates ")#mi("{-R^{ij} - q \\eta^{ij}}")#text(" up to an error which is also highly oscillating (and somewhat divergence-free). The effect of this error can then eventually be absorbed efficiently into the new Reynolds stress tensor ")#mi("{S^{ij}}")#text(". Of course, one also has to manage the other terms ")#mi("{\\partial_t v^i}")#text(", ")#mi("{\\nu \\Delta v^i}")#text(", ")#mi("{u^i v^j}")#text(", ")#mi("{u^j v^i}")#text(" appearing in ")#link(<tao-49b34563133364660b1f>)[#text("(29)")]#text(". In high dimensions it turns out that these terms can be made very small in ")#mi("{L^1_{t,x}}")#text(" norm, and can thus be easily disposed of. In three dimensions the situation is considerably more delicate, particularly with regards to the ")#mi("{\\nu \\Delta v^i}")#text(" and ")#mi("{u^i v^j}")#text(" terms; in particular, the transport term ")#mi("{u^i v^j}")#text(" term is best handled by using a local version of Lagrangian coordinates. We will discuss these subtleties in later sections.")

#text("To execute above strategy, it will be convenient to have an even more flexible notion of solution, in which ")#mi("{v}")#text(" is no longer required to be perfectly divergence-free and mean zero, and is also allowed to be slightly inaccurate in solving ")#link(<tao-49b34563133364660b1f>)[#text("(29)")]#text(". We say that ")#mi("{(v,q,S,f,F)}")#text(" is an ")#emph[#text("approximate difference Navier-Stokes-Reynolds flow")]#text(" at ")#mi("{(u,p,R)}")#text(" if ")#mi("{v, F: \\Omega \\rightarrow {\\bf R}^d}")#text(", ")#mi("{q, f: \\Omega \\rightarrow {\\bf R}}")#text(", ")#mi("{S: \\Omega \\rightarrow {\\bf R}^{d^2}}")#text(" are smooth functions obeying the system ")#metadata(none) <tao-da7de176ea67ac818876>#mi("\\displaystyle  (\\partial_t - \\nu \\Delta) v^i + \\partial_j( u^i v^j + u^j v^i + v^i v^j + R^{ij} + q \\eta^{ij} - S^{ij} ) = F^i \\ \\ \\ \\ \\ (32)")#text(" ")#text(" ")#metadata(none) <tao-ec3dcba4b8fa496834ba>#mi("\\displaystyle  \\partial_i v^i = f \\ \\ \\ \\ \\ (33)")#text(" ")#text(" ")#metadata(none) <tao-41f17140dcf1c647d8a2>#mi("\\displaystyle  S^{ij} = S^{ji}. \\ \\ \\ \\ \\ (34)")

#text("If the error terms ")#mi("{f,F}")#text(", as well as the mean of ")#mi("{v}")#text(", are all small, one can correct an approximate difference Navier-Stokes-Reynolds flow ")#mi("{(v,q,S,f,F)}")#text(" to a true difference Navier-Stokes-Reynolds flow ")#mi("{(v^{\\prime},q^{\\prime},S^{\\prime})}")#text(" with only small adjustments:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Removing the error terms)")]#text(" ")#metadata(none) <tao-e65e0af34a185a0d0c82>#text(" Let ")#mi("{(u,p,R)}")#text(" be a Navier-Stokes-Reynolds flow, and let ")#mi("{(v,q,S,f,F)}")#text(" be an approximate difference Navier-Stokes-Reynolds flow at ")#mi("{(u,p,R)}")#text(". Show that ")#mi("{(v^{\\prime},q^{\\prime},S^{\\prime})}")#text(" is an approximate difference Navier-Stokes-Reynolds flow at ")#mi("{(u,p,R)}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("(v^{\\prime})^i  & := v^i - c^i - \\Delta^{-1} \\eta^{ij} \\partial_j f", block: true)



#tao-math("q^{\\prime}  & := q - \\Delta^{-1} \\partial_j \\tilde F^j", block: true)



#tao-math("(S^{\\prime})^{ij}  & = S^{ij} - u^i ((v^{\\prime})^j-v^j) - u^j ((v^{\\prime})^i-v^i)", block: true)



#tao-math(" & - ((v^{\\prime})^i - v^i) v^j - v^i ((v^{\\prime})^j-v^j) - ((v^{\\prime})^i-v^i) ((v^{\\prime})^j - v^j)", block: true)



#tao-math(" & + \\Delta^{-1} \\eta^{jl} \\partial_l \\tilde F^i + \\Delta^{-1} \\eta^{il} \\partial_l \\tilde F^j", block: true)



#tao-math("\\tilde F^i  & := F^i - (\\partial_t - \\nu \\Delta) (v^i - (v^{\\prime})^i)", block: true)
]

#text("and ")#mi("{c: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}^d}")#text(" is the mean of ")#mi("{v}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("c^i(t) := \\int_{\\mathbf{T}} v^i(t,x)\\ dx.")]]

#text("(")#emph[#text("Hint:")]#text(" one will need at some point to show that ")#mi("{\\tilde F^i}")#text(" has mean zero in space at every time; this can be achieved by integrating ")#link(<tao-da7de176ea67ac818876>)[#text("(32)")]#text(" in space.)")
]

#text("Because of this exercise we will be able to tolerate the error terms ")#mi("{f,F}")#text(" if they (and the mean ")#mi("{c}")#text(") are sufficiently small.")

#text("As a simple corollary of Exercise ")#link(<tao-e65e0af34a185a0d0c82>)[#text("24")]#text(", we have the following analogue of Proposition ")#link(<tao-97c10efe01d5c9c88704>)[#text("13")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 25")]#text(" ")#metadata(none) <tao-459bd89743ffce17a522>#text(" Let ")#mi("{u \\in X^\\infty}")#text(". Then there exist smooth fields ")#mi("{p: \\Omega \\rightarrow {\\bf R}}")#text(", ")#mi("{R: \\Omega \\rightarrow {\\bf R}^{d^2}}")#text(" such that ")#mi("{(u,p,R)}")#text(" is a Navier-Stokes-Reynolds flow. Furthermore, if ")#mi("{u}")#text(" is supported in ")#mi("{I \\times \\mathbf{T}}")#text(" for some compact time interval ")#mi("{I}")#text(", then ")#mi("{p,R}")#text(" can be chosen to also be supported in this region.")
]

#emph[#text("Proof:")]#text(" Clearly ")#mi("{(u, 0, 0, 0, F)}")#text(" is an approximate difference Navier-Stokes-Reynolds flow at ")#mi("{(0,0,0)}")#text(", where")

#align(center)[#tao-fit-display[#mitex("F^i := (\\partial_t - \\nu \\Delta) u^i + \\partial_j (u^i u^j).")]]

#text("Applying Exercise ")#link(<tao-e65e0af34a185a0d0c82>)[#text("24")]#text(", we can construct an difference Navier-Stokes-Reynolds flow ")#mi("{(u,p,R)}")#text(" at ")#mi("{(0,0,0)}")#text(", which then verifies the claimed properties. ")#mi("\\Box")

#text("Now, we show that, in sufficiently high dimension, a Navier-Stokes-Reynolds flow ")#mi("{(u, p, R)}")#text(" can be approximated (in an ")#mi("{L^1}")#text(" sense) as the limit of Navier-Stokes-Reynolds flows ")#mi("{(u^{(N)}, p^{(N)}, R^{(N)})}")#text(", with the Reynolds stress ")#mi("{R^{(N)}}")#text(" going to zero.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 26 (Weak improvement of Navier-Stokes-Reynolds flows)")]#text(" ")#metadata(none) <tao-b10b18f906fcd1ca8784>#text(" Let ")#mi("{\\varepsilon>0}")#text(", and let ")#mi("{d}")#text(" be sufficiently large depending on ")#mi("{\\varepsilon}")#text(". Let ")#mi("{U = (u,p,R)}")#text(" be a Navier-Stokes-Reynolds flow. Then for sufficiently large ")#mi("{N}")#text(", there exists a Navier-Stokes-Reynolds flow ")#mi("{\\tilde U = (\\tilde u, \\tilde p, \\tilde R)}")#text(" obeying the estimates")

#metadata(none) <tao-1616a54c4065fb1c8b65>

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\partial_t^j \\nabla_x^k \\tilde u \\right\\|_{L^2_{t,x}}  & \\lesssim_{U,\\varepsilon,d,j,k} N^{k}", block: true, numbering: n => [#text("(35)")])



#tao-math("\\left\\| \\tilde R \\right\\|_{L^1_{t,x}}  & \\lesssim_{U,\\varepsilon,d} N^{-1+\\varepsilon}", block: true)
]

#text("for all ")#mi("{j,k \\geq 0}")#text(", and such that")

#metadata(none) <tao-b805470e1885d4371b44>

#tao-aligned(keep: true)[


#tao-math("\\left\\|\\tilde u - u \\right\\|_{L^2_{t,x}}  & \\lesssim_{\\varepsilon,d} \\left\\| R \\right\\|_{L^1_{t,x}}^{1/2}.", block: true, numbering: n => [#text("(36)")])



#tao-math("\\left\\|\\tilde u - u \\right\\|_{L^1_{t,x}}  & \\lesssim_{U,\\varepsilon,d} N^{-10}.", block: true)
]

#text("Furthermore, if ")#mi("{U}")#text(" is supported in ")#mi("{I \\times \\mathbf{T}_E}")#text(" for some interval ")#mi("{I \\subset {\\bf R}/{\\bf Z}}")#text(", then one can arrange for ")#mi("{\\tilde U}")#text(" to be supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(" for any interval ")#mi("{I^{\\prime}}")#text(" containing ")#mi("{I}")#text(" in its interior (at the cost of allowing the implied constants in the above to depend also on ")#mi("{I,I^{\\prime}}")#text(").")
]

#text("This proposition can be viewed as an analogue of Theorem ")#link(<tao-d2b5f37e1eef51deddc9>)[#text("14")]#text(". For an application at the end of this section it is important that the implied constant in ")#link(<tao-b805470e1885d4371b44>)[#text("(36)")]#text(" is uniform in the choice of initial flow ")#mi("{U}")#text(". The estimate ")#link(<tao-1616a54c4065fb1c8b65>)[#text("(35)")]#text(" can be viewed as asserting that the new velocity field ")#mi("{\\tilde u}")#text(" is oscillating at frequencies ")#mi("{O(N)}")#text(", at least in an ")#mi("{L^2_{t,x}}")#text(" sense. In the next section, we obtain a stronger version of this proposition with more quantitative estimates that can be iterated to obtain higher regularity weak solutions.")

#text("To simplify the notation we adopt the following conventions. Given an ")#mi("{n}")#text("-dimensional vector ")#mi("{(D_1,\\dots,D_n)}")#text(" of differential operators, we use ")#mi("{(D_1,\\dots,D_n)^m}")#text(" to denote the ")#mi("{n^m}")#text("-tuple of differential operators ")#mi("{D_{i_1} \\dots D_{i_m}}")#text(" with ")#mi("{i_1,\\dots,i_m \\in \\{1,\\dots,n\\}}")#text(". We use ")#mi("{(D_1,\\dots,D_n)^{\\leq m}}")#text(" to denote the ")#mi("{\\sum_{0 \\leq m^{\\prime} \\leq m} n^{m^{\\prime}}}")#text("-tuple formed by concatenating ")#mi("{(D_1,\\dots,D_n)^{m^{\\prime}}}")#text(" for ")#mi("{0 \\leq m^{\\prime} \\leq m}")#text(". Thus for instance the estimate ")#link(<tao-1616a54c4065fb1c8b65>)[#text("(35)")]#text(" can be abbreviated as")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} \\tilde u \\right\\|_{L^2_{t,x}} \\lesssim_{U,\\varepsilon,d,m} 1", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(". Informally, one should read the above estimate as asserting that ")#mi("{\\tilde u}")#text(" is bounded in ")#mi("{L^2_{t,x}}")#text(" with norm ")#mi("{O_{U,\\varepsilon,d}(1)}")#text(", and oscillates with frequency ")#mi("{O(1)}")#text(" in time and ")#mi("{O(N)}")#text(" in space (or equivalently, with a temporal wavelength of ")#mi("{\\gtrsim 1}")#text(" and a spatial wavelength of ")#mi("{\\gtrsim 1/N}")#text(").")

#emph[#text("Proof:")]#text(" We can assume that ")#mi("{R}")#text(" is non-zero, since if ")#mi("{R=0}")#text(" we can just take ")#mi("{U^{(N)} = U}")#text(". We may assume that ")#mi("{U}")#text(" is supported in ")#mi("{I \\times \\mathbf{T}}")#text(" for some interval ")#mi("{I \\subset {\\bf R}/{\\bf Z}}")#text(" (which may be all of ")#mi("{{\\bf R}/{\\bf Z}}")#text("), and let ")#mi("{I^{\\prime}}")#text(" be an interval containing ")#mi("{I}")#text(" in its interior. To abbreviate notation, we allow all implied constants to depend on ")#mi("{\\varepsilon,d,I,I^{\\prime}}")#text(".")

#text("Assume ")#mi("{N}")#text(" is sufficiently large. Using the ansatz")

#align(center)[#tao-fit-display[#mitex("(\\tilde u, \\tilde p, \\tilde R) = (u + v, p + q, \\tilde R),")]]

#text("and the triangle inequality, it suffices to construct a difference Navier-Stokes-Reynolds flow ")#mi("{(v, q, \\tilde R)}")#text(" at ")#mi("{U}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}}")#text(" and obeying the bounds")

#tao-aligned(keep: true)[


#tao-math("\\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} v \\right\\|_{L^2_{t,x}}  & \\lesssim_{U,m} 1", block: true)



#tao-math("\\left\\| \\tilde R \\right\\|_{L^1_{t,x}}  & \\lesssim_{U} N^{-1+\\varepsilon}", block: true)



#tao-math("\\left\\| v \\right\\|_{L^2_{t,x}}  & \\lesssim \\left\\| R \\right\\|_{L^1_{t,x}}^{1/2}", block: true)



#tao-math("\\left\\| v \\right\\|_{L^1_{t,x}}  & \\lesssim_{U} N^{-10}", block: true)
]

#text("for all ")#mi("{m \\geq 0}")#text(".")

#text("It will in fact suffice to construct an ")#emph[#text("approximate")]#text(" difference Navier-Stokes-Reynolds flow ")#mi("{(v, q, \\tilde R, f, F)}")#text(" at ")#mi("{U}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}}")#text(" and obeying the bounds ")#metadata(none) <tao-a23b2813ba86078fc28e>#tao-math("\\displaystyle  \\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} v \\right\\|_{L^2_{t,x}} \\lesssim_{U,m} 1 \\ \\ \\ \\ \\ (37)", block: false)#text(" ")#text(" ")#metadata(none) <tao-70be7c0df83e6895ab05>#tao-math("\\displaystyle  \\left\\| \\tilde R\\right\\|_{L^1_{t,x}} \\lesssim_{U} N^{-1+\\varepsilon} \\ \\ \\ \\ \\ (38)", block: false)#text(" ")#text(" ")#metadata(none) <tao-da3646e7efa8af09c67f>#tao-math("\\displaystyle  \\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} v \\right\\|_{L^1_{t,x}} \\lesssim_{U,m} N^{-20} \\ \\ \\ \\ \\ (39)", block: false)#text(" ")#text(" ")#metadata(none) <tao-b0c4c087eae523177d49>#tao-math("\\displaystyle  \\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} f \\right\\|_{L^2_{t,x}} \\lesssim_{U,m} N^{-20} \\ \\ \\ \\ \\ (40)", block: false)#text(" ")#text(" ")#metadata(none) <tao-bc6119426055b9a85e1f>#tao-math("\\displaystyle  \\left\\| F \\right\\|_{L^1_{t,x}} \\lesssim_{U} N^{-20} \\ \\ \\ \\ \\ (41)", block: false)#text(" ")#text(" ")#metadata(none) <tao-ba02876cbe868b624802>#tao-math("\\displaystyle  \\left\\| v \\right\\|_{L^2_{t,x}} \\lesssim \\left\\| R \\right\\|_{L^1_{t,x}}^{1/2} \\ \\ \\ \\ \\ (42)", block: false)#text(" ")#text(" for ")#mi("{m \\geq 0}")#text(", since an application of Exercise ")#link(<tao-e65e0af34a185a0d0c82>)[#text("24")]#text(" and some simple estimation will then give a difference Navier-Stokes-Reynolds flow ")#mi("{(v^{\\prime}, q^{\\prime}, R^{\\prime})}")#text(" obeying the desired estimates (using in particular the fact that ")#mi("{\\Delta^{-1} \\nabla_x}")#text(" is bounded on ")#mi("{L^1_{t,x}}")#text(" and ")#mi("{L^2_{t,x}}")#text(", as can be seen from Littlewood-Paley theory; also note that ")#link(<tao-da3646e7efa8af09c67f>)[#text("(39)")]#text(" can be used to ensure that the mean of ")#mi("{v^{(N)}}")#text(" is very small).")

#text("To construct this approximate solution, we again use the method of fast and slow variables. Set ")#mi("{N_1 := \\lfloor N^{1-\\varepsilon} \\rfloor}")#text(", and introduce the fast-slow spacetime ")#mi("{\\mathbf{\\Omega} := \\Omega \\times \\mathbf{T}_F = {\\bf R}/{\\bf Z} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(", which we coordinatise as ")#mi("{(t,x,y)}")#text("; we use ")#mi("{\\partial_{x^i}}")#text(" to denote partial differentiation in the coordinates of the slow variable ")#mi("{x \\in \\mathbf{T}_E}")#text(", and ")#mi("{\\partial_{y^i}}")#text(" to denote partial differentiation in the coordinates of the fast variable ")#mi("{y \\in \\mathbf{T}_F}")#text(". We also use ")#mi("{L^p_{t,x,y}}")#text(" as shorthand for ")#mi("{L^p_t L^p_x L^p_y(\\mathbf{\\Omega})}")#text(". Define an ")#emph[#text("approximate fast-slow solution")]#text(" to the difference Navier-Stokes-Reynolds equation at ")#mi("{(u,p,R)}")#text(" (at the frequency scale ")#mi("{N_1}")#text(") to be a tuple ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" of smooth functions ")#mi("{\\mathbf{v}, \\mathbf{f}: \\mathbf{\\Omega} \\rightarrow {\\bf R}^d}")#text(", ")#mi("{\\mathbf{q}, \\mathbf{f}: \\mathbf{\\Omega} \\rightarrow {\\bf R}}")#text(", ")#mi("{\\mathbf{R}: \\mathbf{\\Omega} \\rightarrow {\\bf R}^d}")#text(" that obey the system of equations")

#align(center)[#tao-fit-display[#mitex("(\\partial_t - \\nu \\Delta_x - 2 N_1 \\nu \\nabla x \\cdot \\nabla y - \\nu N_1^2 \\Delta_y) \\mathbf{v}^i")]]

#tao-aligned(keep: true)[
#metadata(none) <tao-3d73c9736c55b3556e18>

#tao-math("+ (\\partial_{x^j} + N_1 \\partial_{y^j}) ( u^i \\mathbf{v}^j + u^j \\mathbf{v}^i + \\mathbf{v}^i \\mathbf{v}^j + R^{ij} + \\mathbf{q} \\eta^{ij} - \\mathbf{R}^{ij} )  & = \\mathbf{F}^i", block: true, numbering: n => [#text("(43)")])

#metadata(none) <tao-5d65c2aca4c1ce096cff>

#tao-math("(\\partial_{x^i} + N_1 \\partial_{y^i}) \\mathbf{v}^i  & = \\mathbf{f}", block: true, numbering: n => [#text("(44)")])

#metadata(none) <tao-9d14d874e96a19686eb3>

#tao-math("\\mathbf{R}^{ij}  & = \\mathbf{R}^{ji}.", block: true, numbering: n => [#text("(45)")])
]

#text("Here we think of ")#mi("{u}")#text(" as a “low-frequency” function (in the sense of Remark ")#link(<tao-6ef7c9b15ecdd6908372>)[#text("20")]#text(") that only depends on ")#mi("{t}")#text(" and the slow variable ")#mi("{x}")#text(", but not on the fast variable ")#mi("{y}")#text(".")

#text("Let ")#mi("{D}")#text(" denote the tuple ")#mi("{D := (\\partial_t, \\nabla_x, N^{-\\varepsilon} \\nabla_y)}")#text(". Suppose that for any sufficiently large ")#mi("{N}")#text(", we can construct an approximate fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" to the difference equations at ")#mi("{(u,p,R)}")#text(" supported on supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" that obeys the bounds ")#metadata(none) <tao-c7ceb471ec271f3bb945>#tao-math("\\displaystyle  \\left\\| D^{\\leq m} \\mathbf{v} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} 1 \\ \\ \\ \\ \\ (46)", block: false)#text(" ")#text(" ")#metadata(none) <tao-42895a7f48b6e4f95ada>#tao-math("\\displaystyle  \\left\\| \\mathbf{R} \\right\\|_{L^1_{t,x}} \\lesssim_{U} N^{-1+\\varepsilon} \\ \\ \\ \\ \\ (47)", block: false)#text(" ")#text(" ")#metadata(none) <tao-fe52727132f95524f0a4>#tao-math("\\displaystyle  \\left\\| D^{\\leq m} \\mathbf{v} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U,m} N^{-20} \\ \\ \\ \\ \\ (48)", block: false)#text(" ")#text(" ")#metadata(none) <tao-b22ec3109b5961bf82c2>#tao-math("\\displaystyle  \\left\\| D^{\\leq m} \\mathbf{f} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} N^{-20} \\ \\ \\ \\ \\ (49)", block: false)#text(" ")#text(" ")#metadata(none) <tao-8178c50e44a36b32efcb>#tao-math("\\displaystyle  \\left\\| \\mathbf{F} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U} N^{-20} \\ \\ \\ \\ \\ (50)", block: false)#text(" ")#text(" ")#metadata(none) <tao-2698637778dfa475c114>#tao-math("\\displaystyle  \\left\\| \\mathbf{v} \\right\\|_{L^2_{t,x}} \\lesssim \\left\\| R \\right\\|_{L^1_{t,x}}^{1/2} \\ \\ \\ \\ \\ (51)", block: false)#text(" ")#text(" for all ")#mi("{m \\geq 0}")#text(". (Informally, the presence of the derivatives ")#mi("{D}")#text(" means that the fields involved are allowed to oscillate in time at wavelength ")#mi("{\\gtrsim 1}")#text(", in the slow variable ")#mi("{x}")#text(" at wavelength ")#mi("{\\gtrsim 1}")#text(", and in the fast variable ")#mi("{y}")#text(" at wavelength ")#mi("{\\gtrsim N^{-\\varepsilon}}")#text(".) From ")#link(<tao-c7ceb471ec271f3bb945>)[#text("(46)")]#text(" and the choice of ")#mi("{N_1}")#text(" we then have")

#align(center)[#tao-fit-display[#mitex("\\| (\\partial_t, N^{-1}(\\nabla_x + N_1 \\nabla_y)^{\\leq m} \\mathbf{v} \\|_{L^2_{t,x,y}} \\lesssim_{U,m} 1")]]

#text("for all ")#mi("{m \\geq 0}")#text(", and similarly for ")#link(<tao-fe52727132f95524f0a4>)[#text("(48)")]#text(", ")#link(<tao-b22ec3109b5961bf82c2>)[#text("(49)")]#text(". (Note here that there was considerable room in the estimates with regards to regularity in the ")#mi("{x}")#text(" variable; this room will be exploited more in the next section.) For any shift ")#mi("{\\theta \\in \\mathbf{T}_F}")#text(", we see from the chain rule that ")#mi("{(v^\\theta, q^\\theta, R^\\theta, f^\\theta, F^\\theta)}")#text(" is an approximate difference Navier-Stokes-Reynolds flow at ")#mi("{U}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("v^\\theta(t,x)  & := \\mathbf{v}( t, x, N_1 x + \\theta)", block: true)



#tao-math("q^\\theta(t,x)  & := \\mathbf{q}( t, x, N_1 x + \\theta)", block: true)



#tao-math("R^\\theta(t,x)  & := \\mathbf{R}( t, x, N_1 x + \\theta)", block: true)



#tao-math("f^\\theta(t,x)  & := \\mathbf{f}( t, x, N_1 x + \\theta)", block: true)



#tao-math("F^\\theta(t,x)  & := \\mathbf{F}( t, x, N_1 x + \\theta).", block: true)
]

#text("Also from ")#link(<tao-c7ceb471ec271f3bb945>)[#text("(46)")]#text(" and Fubini’s theorem we have")

#metadata(none) <tao-0814c706cc711b874d1f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(52)")])
#tao-math("\\int_{\\mathbf{T}_F} \\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} v^\\theta \\right\\|_{L^2_{t,x}}^2\\ d\\theta \\lesssim_{U,m} 1", block: true)]]

#text("and similarly")

#tao-aligned(keep: true)[


#tao-math("\\int_{\\mathbf{T}_F} \\left\\| R^\\theta \\right\\|_{L^1_{t,x}}\\ d\\theta  & \\lesssim_{U} N^{-1+\\varepsilon}", block: true)



#tao-math("\\int_{\\mathbf{T}_F} \\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} v^\\theta \\right\\|_{L^1_{t,x}}\\ d\\theta  & \\lesssim_{U,m} N^{-20}", block: true)



#tao-math("\\int_{\\mathbf{T}_F} \\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} f^\\theta \\right\\|_{L^2_{t,x}}^2\\ d\\theta  & \\lesssim_{U,m} N^{-40}", block: true)



#tao-math("\\int_{\\mathbf{T}_F} \\left\\| F^\\theta \\right\\|_{L^1_{t,x}}\\ d\\theta  & \\lesssim_{U} N^{-20}", block: true)



#tao-math("\\int_{\\mathbf{T}_F} \\left\\| v^\\theta \\right\\|_{L^2_{t,x}}^2\\ d\\theta  & \\lesssim \\left\\| R \\right\\|_{L^1_{t,x}}", block: true)
]

#text("for all ")#mi("{m \\geq 0}")#text(". By Markov’s inequality and ")#link(<tao-0814c706cc711b874d1f>)[#text("(52)")]#text(", we see that for each ")#mi("{m}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\partial_t, N^{-1} \\nabla_x)^{\\leq m} v^\\theta \\right\\|_{L^2_{t,x}} \\lesssim_{U,m} 1", block: true)]]

#text("for all ")#mi("{\\theta}")#text(" outside of an exceptional set of measure (say) ")#mi("{2^{-m-10}}")#text(". Similarly for the other equations above. Applying the union bound, we can then find a ")#mi("{\\theta}")#text(" such that ")#mi("{(v^\\theta, q^\\theta, R^\\theta, f^\\theta, F^\\theta)}")#text(" obeys all the required bounds ")#link(<tao-a23b2813ba86078fc28e>)[#text("(37)")]#text("–")#link(<tao-bc6119426055b9a85e1f>)[#text("(41)")]#text(" simultaneously for all ")#mi("{m}")#text(". (This is an example of the ")#link("https://en.wikipedia.org/wiki/Probabilistic_method")[#text("probabilistic method")]#text(", originally developed in combinatorics; one can think of ")#mi("{\\theta}")#text(" probabilistically as a shift drawn uniformly at random from the torus ")#mi("{\\mathbf{T}}")#text(", in order to relate the fast-slow Lebesgue norms ")#mi("{L^p_{t,x,y}}")#text(" to the original Lebesgue norms ")#mi("{L^p_{t,x}}")#text(".)")

#text("It remains to construct an approximate fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" with the required bounds ")#link(<tao-c7ceb471ec271f3bb945>)[#text("(46)")]#text("–")#link(<tao-2698637778dfa475c114>)[#text("(51)")]#text(". Actually, in this high-dimensional setting we can afford to simplify the situation here by removing some of the terms (and in particular eliminating the role of the reference velocity field ")#mi("{u}")#text("). Define a ")#emph[#text("simplified fast-slow solution")]#text(" at ")#mi("{U}")#text(" to be a tuple ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" of smooth functions on ")#mi("{\\mathbf{\\Omega}}")#text(" obeying the simplified equations ")#metadata(none) <tao-e3caefda8bb76df07880>#mi("\\displaystyle  (\\partial_{x^j} + N_1 \\partial_{y^j}) ( \\mathbf{v}^i \\mathbf{v}^j + R^{ij} + \\mathbf{q} \\eta^{ij} - \\mathbf{R}^{ij} ) = \\mathbf{F}^i \\ \\ \\ \\ \\ (53)")#text(" ")#text(" ")#metadata(none) <tao-fbb46b0900aebf725495>#mi("\\displaystyle  (\\partial_{x^i} + N_1 \\partial_{y^i}) \\mathbf{v}^i = \\mathbf{f} \\ \\ \\ \\ \\ (54)")#text(" ")#text(" ")#metadata(none) <tao-0c5fcc9f183611d96f66>#mi("\\displaystyle  \\mathbf{R}^{ij} = \\mathbf{R}^{ji}. \\ \\ \\ \\ \\ (55)")#text(" ")#text(" If we can find a simplified fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" of smooth functions on ")#mi("{\\mathbf{\\Omega}}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" obeying the bounds ")#metadata(none) <tao-df269ed991e4314f79ea>#tao-math("\\displaystyle  \\left\\| D^{\\leq m} \\mathbf{v} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} 1 \\ \\ \\ \\ \\ (56)", block: false)#text(" ")#text(" ")#metadata(none) <tao-2fd2c800046354fb0e84>#tao-math("\\displaystyle  \\left\\| \\mathbf{R} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U} N^{-1+\\varepsilon} \\ \\ \\ \\ \\ (57)", block: false)#text(" ")#text(" ")#metadata(none) <tao-de403f82428dd6ea6133>#tao-math("\\displaystyle  \\left\\| D^{\\leq m} \\mathbf{v} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U,m} N^{-30} \\ \\ \\ \\ \\ (58)", block: false)#text(" ")#text(" ")#metadata(none) <tao-71a889773a1344dec69c>#tao-math("\\displaystyle  \\left\\| D^{\\leq m} \\mathbf{f} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} N^{-30} \\ \\ \\ \\ \\ (59)", block: false)#text(" ")#text(" ")#metadata(none) <tao-a2d2c0953b4c6966b770>#tao-math("\\displaystyle  \\left\\| \\mathbf{F} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U} N^{-30} \\ \\ \\ \\ \\ (60)", block: false)#text(" ")#text(" ")#metadata(none) <tao-bbd166c30d35deba044f>#tao-math("\\displaystyle  \\left\\| \\mathbf{v} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U} \\left\\| R \\right\\|_{L^1_{t,x}}^{1/2} \\ \\ \\ \\ \\ (61)", block: false)#text(" ")#text(" for all ")#mi("{m \\geq 0}")#text(", then the ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}^{\\prime}, \\mathbf{f}, \\mathbf{F}^{\\prime})}")#text(" will be an approximate fast-slow solution supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" obeying the required bounds ")#link(<tao-c7ceb471ec271f3bb945>)[#text("(46)")]#text("–")#link(<tao-2698637778dfa475c114>)[#text("(51)")]#text(", where")

#tao-aligned(keep: true)[


#tao-math("(\\mathbf{R}^{\\prime})^{ij}  & := \\mathbf{R}^{ij} + u^i \\mathbf{v}^j + u^j \\mathbf{v}^i", block: true)



#tao-math("(\\mathbf{F}^{\\prime})^i  & := \\mathbf{F}^i + (\\partial_t - \\nu \\Delta_x - 2 N_1 \\nu \\nabla x \\cdot \\nabla y - \\nu N_1^2 \\Delta_y) \\mathbf{v}^i.", block: true)
]

#text("Now we need to construct a simplified fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" obeying the bounds ")#link(<tao-df269ed991e4314f79ea>)[#text("(56)")]#text("–")#link(<tao-a2d2c0953b4c6966b770>)[#text("(60)")]#text(". We do this in stages, first finding a solution that cancels off the highest order terms ")#mi("{N_1 \\partial_{y^j}(\\mathbf{v}^i \\mathbf{v}^j)}")#text(" and ")#mi("{N_1 \\partial_{y^i} \\mathbf{v}^i}")#text(", and also such that ")#mi("{\\mathbf{v}^i \\mathbf{v}^j + R^{ij} + q \\delta^{ij}}")#text(" has mean zero in the fast variable ")#mi("{y}")#text(" (so that it is “high frequency” in the sense of Remark ")#link(<tao-6ef7c9b15ecdd6908372>)[#text("20")]#text("). This still leads to fairly large values of ")#mi("{\\mathbf{F}}")#text(" and ")#mi("{\\mathbf{f}}")#text(", but we will then apply a “divergence corrector” to almost completely eliminate ")#mi("{\\mathbf{f}}")#text(", followed by a “stress corrector” that almost completely eliminates ")#mi("{\\mathbf{F}}")#text(", at which point we will be done.")

#text("We turn to the details. Our preliminary construction of the velocity field ")#mi("{\\mathbf{v}}")#text(" will be a “Mikado flow”, consisting of flows along narrow tubes. (Earlier literature used other flows, such as ")#link("https://en.wikipedia.org/wiki/Beltrami_flow")[#text("Beltrami flows")]#text("; however, Mikado flows have the advantage of being localisable to small subsets of spacetime, which is particularly useful in high dimensions.) We need the following modification of Lemma ")#link(<tao-ae4a6acd7198ca1c9843>)[#text("16")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" ")#metadata(none) <tao-fd8348c37e3c2786327d>#text(" Let ")#mi("{S}")#text(" be a compact subset of the space of positive definite ")#mi("{d \\times d}")#text(" matrices ")#mi("{A = (A^{ij})_{1 \\leq i,j \\leq d}}")#text(". Show that there exist non-zero lattice vectors ")#mi("{e_1,\\dots,e_K \\in {\\bf Z}^d}")#text(" and smooth functions ")#mi("{a_1,\\dots,a_K: S \\rightarrow {\\bf R}}")#text(" for some ")#mi("{K \\geq 0}")#text(" such that")

#metadata(none) <tao-27f2f62c844c8fc06f36>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(62)")])
#mitex("A^{ij} = \\sum_{k=1}^K a_k(A)^2 (e_k)^i (e_k)^j")]]

#text("for all ")#mi("{A \\in S}")#text(". (This decomposition is essentially ")#link("https://arxiv.org/abs/1202.1751")[#text("due to de Lellis and Szekelyhidi")]#text(". The subscripting and superscripting here is reversed from that in Lemma ")#link(<tao-ae4a6acd7198ca1c9843>)[#text("16")]#text("; this is because we are now trying to decompose a rank ")#mi("{(2,0)}")#text(" tensor rather than a rank ")#mi("{(0,2)}")#text(" tensor.)")
]

#text("We would like to apply this exercise to the matrix with entries ")#mi("{-R^{ij} - q \\eta^{ij}}")#text(". We thus need to select the pressure ")#mi("{q}")#text(" so that this matrix is positive definite. There are many choices available for this pressure; we will take")

#align(center)[#tao-fit-display[#tao-math("q := -( \\left\\| R \\right\\|_{L^1_{t,x}}^2 + 100 d \\left|R\\right|^2)^{1/2}", block: true)]]

#text("where ")#tao-math("{\\left|R\\right|}", block: false)#text(" is the Frobenius norm of ")#mi("{\\mathbf{R}}")#text(". Then ")#mi("{q}")#text(" is smooth and ")#mi("{-R^{ij} - q \\eta^{ij}}")#text(" is positive definite on all of the compact spacetime ")#mi("{\\Omega}")#text(" (recall that we can assume ")#mi("{R}")#text(" to not be identically zero), and in particular ranges in a compact subset of positive definite matrices. Applying the previous exercise and composing with the function ")#mi("{(t,x) \\mapsto -R(t,x)}")#text(", we conclude that there exist non-zero lattice vectors ")#mi("{e_1,\\dots,e_K \\in {\\bf Z}^d}")#text(" and smooth functions ")#mi("{a_1,\\dots,a_K: \\Omega \\rightarrow {\\bf R}}")#text(" for some ")#mi("{K \\geq 0}")#text(" such that")

#metadata(none) <tao-99735bd802460a9ee858>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(63)")])
#mitex("- R^{ij}(t,x) - q(t,x) \\delta^{ij} = \\sum_{k=1}^K a_k(t,x)^2 e_k^i e_k^j")]]

#text("for all ")#mi("{(t,x) \\in \\Omega}")#text(". As ")#mi("{K, e^k, a^k}")#text(" depend only on ")#mi("{d,R}")#text(", and ")#mi("{R}")#text(" is a component of ")#mi("{U}")#text(", all norms of these quantities are bounded by ")#mi("{O_{U}(1)}")#text("; they are independent of ")#mi("{N}")#text(". Furthermore, on taking traces and integrating on ")#mi("{\\Omega}")#text(", we obtain the estimate")

#metadata(none) <tao-03d506001a889aa1a0a1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(64)")])
#tao-math("\\sum_{k=1}^K \\left\\| a_k \\right\\|_{L^2_{t,x}}^2 \\left|e_k\\right|^2 \\lesssim \\left\\| R \\right\\|_{L^1_{t,x}}", block: true)]]

#text("(note here that the implied constant is uniform in ")#mi("{K}")#text(", ")#mi("{U}")#text("). By applying a smooth cutoff ")#mi("{\\varphi: {\\bf R}/{\\bf Z} \\rightarrow {\\bf R}}")#text(" in time that equals ")#mi("{1}")#text(" on ")#mi("{I}")#text(" and vanishes outside of ")#mi("{I^{\\prime}}")#text(" to ")#mi("{a_k}")#text(" (and applying ")#mi("{\\varphi^2}")#text(" to ")#mi("{q}")#text("), we may assume that the ")#mi("{a_k}")#text(" are supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}}")#text("; this redefines ")#mi("{q}")#text(" slightly to")

#align(center)[#tao-fit-display[#tao-math("q := -\\varphi^2 ( \\left\\| R \\right\\|_{L^1_{t,x}}^2 + 100 d \\left|R\\right|^2)^{1/2}", block: true)]]

#text("but this does not significantly affect the estimate ")#link(<tao-03d506001a889aa1a0a1>)[#text("(64)")]#text(".")

#text("Now for each ")#mi("{k=1,\\dots,K}")#text(", the closed subgroup ")#mi("{\\ell_k := \\{ t e_k \\text{ mod } {\\bf Z}^d: t \\in {\\bf R}/{\\bf Z} \\}}")#text(" is a one-dimensional subset of ")#mi("{\\mathbf{T}_F}")#text(", so the ")#mi("{N^{-\\varepsilon}}")#text("-neighbourhood of this subgroup has measure ")#mi("{O_{d,R}(N^{-\\varepsilon(d-1)})}")#text("; crucially, this will be a large negative power of ")#mi("{N}")#text(" when ")#mi("{d}")#text(" is very large. let ")#mi("{T_k \\subset \\mathbf{T}_F}")#text(" be a translate of this ")#mi("{N^{-\\varepsilon}}")#text("-neighbourhood such that all the ")#mi("{T_1,\\dots,T_K}")#text(" are disjoint; this is easily accomplished by the probabilistic method for ")#mi("{N}")#text(" large enough, translating each of the ")#mi("{T_k}")#text(" by an independent random shift and noting that the probability of a collision goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(" (here we need the fact that we are in at least three dimensions).")

#text("Let ")#mi("{M}")#text(" be a large integer (depending on ")#mi("{\\varepsilon}")#text(") to be chosen later. For any ")#mi("{k=1,\\dots,K}")#text(", let ")#mi("{\\mathbf{\\psi}_k: \\mathbf{T}_F \\rightarrow {\\bf R}}")#text(" be a scalar test function supported on ")#mi("{T_k}")#text(" that is constant in the ")#mi("{e_k}")#text(" direction, thus")

#align(center)[#tao-fit-display[#mitex("e_k^i \\partial_{y^i} \\mathbf{\\psi}_k(y) = 0,")]]

#text("and is not identically zero, which implies that the iterated Laplacian ")#mi("{\\Delta^M_y \\mathbf{\\psi}_k}")#text(" of ")#mi("{\\mathbf{\\psi}_k}")#text(" is also not identically zero (thanks to the unique continuation property of harmonic functions). We can normalise so that")

#align(center)[#tao-fit-display[#mitex("\\int_{\\mathbf{T}_F} (\\Delta^M_y \\mathbf{\\psi}^i_k \\Delta^M_y \\mathbf{\\psi}^j_k\\ dy = e_k^i e_k^j")]]

#text("and we can also arrange to have the bounds")

#align(center)[#tao-fit-display[#tao-math("\\left|e_k\\right|^2 \\left\\| (N^{-\\varepsilon} \\nabla_y)^{-m} \\mathbf{\\psi}_k \\right\\|_{L^2_y} \\lesssim_{m,M} N^{-2M\\varepsilon}", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(" (basically by first constructing a version of ")#mi("{\\mathbf{\\psi}_k}")#text(" on a standard cylinder ")#mi("{B^{d-1}(0,1) \\times {\\bf R}}")#text(" and the applying an affine transformation to map onto ")#mi("{T_k}")#text(").")

#text("Let ")#mi("{\\mathbf{w}_k: \\mathbf{T}_F \\rightarrow {\\bf R}^d}")#text(" denote the function")

#align(center)[#tao-fit-display[#mitex("\\mathbf{w}_k^i(y) := \\Delta^M_y \\mathbf{\\psi}_k(y) e_k^i;")]]

#text("intuitively this represents the velocity field of a fluid traveling along the tube ")#mi("{T_k}")#text(", with the presence of the Laplacian ")#mi("{\\Delta^M}")#text(" ensuring that this function is extremely well balanced (for instance, it will have mean zero, and thus “high frequency” in the sense of Remark ")#link(<tao-6ef7c9b15ecdd6908372>)[#text("20")]#text("). Clearly ")#mi("{\\mathbf{w}_k}")#text(" is divergence free, and one also has the steady-state Euler equation")

#metadata(none) <tao-d6ba8bf227ba2c637c44>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(65)")])
#mitex("\\partial_{y_j}( \\mathbf{w}_k^i \\mathbf{w}_k^j ) = 0")]]

#text("and the normalisation")

#metadata(none) <tao-733859c1fc6b9331793b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(66)")])
#mitex("\\int_{{\\mathbf T}_F} \\mathbf{w}_k^i \\mathbf{w}_k^j = e_k^i e_k^j")]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (N^{-\\varepsilon} \\nabla_y)^m (N^{-2\\varepsilon} \\Delta_y)^{-m^{\\prime}} \\mathbf{w}_k \\right\\|_{L^2_y} \\lesssim_{j,m} 1", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(" and ")#mi("{0 \\leq m^{\\prime} \\leq M}")#text(". If we then set")

#tao-aligned(keep: true)[


#tao-math("\\mathbf{v}^i(t,x,y)  & := \\sum_{k=1}^K a_k(t,x) \\mathbf{w}_k^i(y)", block: true)



#tao-math("\\mathbf{F}^i(t,x,y)  & := \\partial_{x^j}( \\sum_{k=1}^K a_k(t,x)^2 (\\mathbf{w}_k^i(y) \\mathbf{w}_k^j(y) - e_k^i e_k^j) )", block: true)



#tao-math("\\mathbf{f}(t,x,y)  & := \\sum_{k=1}^K \\partial_{x^i} a_k(t,x) \\mathbf{w}_k^i(y)", block: true)
]

#text("then one easily checks that ")#mi("{(\\mathbf{v}, q, 0, \\mathbf{f}, \\mathbf{F})}")#text(" is a simplified fast-slow solution supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(". Direct calculation using the Leibniz rule then gives the bounds")

#metadata(none) <tao-7a2953521a45e92654cd>

#tao-aligned(keep: true)[


#tao-math("\\left\\| D^{\\leq m} \\mathbf{v} \\right\\|_{L^2_{t,x,y}}  & \\lesssim_{U,m} 1", block: true, numbering: n => [#text("(67)")])

#metadata(none) <tao-ad5acd3fd661f6150381>

#tao-math("\\left\\| D^{\\leq m} \\mathbf{f} \\right\\|_{L^2_{t,x,y}}  & \\lesssim_{U,m} 1", block: true, numbering: n => [#text("(68)")])

#metadata(none) <tao-d75c020e53ff427ca45e>

#tao-math("\\left\\| \\mathbf{F} \\right\\|_{L^1_{t,x,y}}  & \\lesssim_{U} 1", block: true, numbering: n => [#text("(69)")])
]

#text("for all ")#mi("{m \\geq 0}")#text(", while from ")#link(<tao-03d506001a889aa1a0a1>)[#text("(64)")]#text(" one has")

#metadata(none) <tao-c4484d850a1f1915b77d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(70)")])
#tao-math("\\left\\| \\mathbf{v} \\right\\|_{L^2_{t,x,y}} \\lesssim \\left\\| R \\right\\|_{L^1_{t,x}}^{1/2}", block: true)]]

#text("(note here that the implied constant is uniform in ")#mi("{U}")#text(").")

#text("This looks worse than ")#link(<tao-df269ed991e4314f79ea>)[#text("(56)")]#text("–")#link(<tao-a2d2c0953b4c6966b770>)[#text("(60)")]#text(". However, observe that ")#mi("{\\mathbf{v}}")#text(" is supported on the set ")#mi("{\\Omega \\times \\bigcup_{k=1}^K T^k}")#text(", which has measure ")#mi("{O_{U,d}( N^{-\\varepsilon(d-1)})}")#text(", which for ")#mi("{d}")#text(" large enough can be taken to be (say) ")#mi("{O_{U,d}(N^{-100})}")#text(". Thus by Cauchy-Schwarz one has ")#metadata(none) <tao-e7250be176ea56cded30>#tao-math("\\displaystyle  \\left\\| D^{\\leq m} \\mathbf{v} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U,m} N^{-30} \\ \\ \\ \\ \\ (71)", block: false)#text(" ")#text(" for all ")#mi("{m \\geq 0}")#text(". Also, from construction (particularly ")#link(<tao-733859c1fc6b9331793b>)[#text("(66)")]#text(") we see that ")#mi("{\\mathbf{F}}")#text(" is of mean zero in the ")#mi("{y}")#text(" variable (thus it is “high frequency” in the sense of Remark ")#link(<tao-6ef7c9b15ecdd6908372>)[#text("20")]#text(").")

#text("We are now a bit closer to ")#link(<tao-df269ed991e4314f79ea>)[#text("(56)")]#text("–")#link(<tao-a2d2c0953b4c6966b770>)[#text("(60)")]#text(", but our bounds on ")#mi("{\\mathbf{f}, \\mathbf{F}}")#text(" are not yet strong enough. We now apply a “divergence corrector” to make ")#mi("{\\mathbf{f}}")#text(" much smaller. Observe from construction that ")#mi("{\\mathbf{f} = \\Delta_y^M \\mathbf{g}}")#text(" where")

#align(center)[#tao-fit-display[#mitex("\\mathbf{g}(t,x,y) := \\sum_{k=1}^K \\partial_{x^i} a_k(t,x) \\mathbf{\\psi}_k(y) e_k^i(y)")]]

#text("and ")#mi("{\\mathbf{g}}")#text(" is supported on ")#mi("{\\Omega \\times \\bigcup_{k=1}^K T_k}")#text(" and obeys the estimates")

#metadata(none) <tao-3bc6965647f3a0c6264f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(72)")])
#tao-math("\\left\\| D^{\\leq m} \\mathbf{g} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} N^{-2M \\varepsilon}", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(". Observe that")

#align(center)[#tao-fit-display[#mitex("\\mathbf{f} = (\\partial_{x^i} + N_1 \\partial_{y^i}) ( N_1^{-1} \\eta_{ij} \\Delta_y^{-1} \\partial_{y^j} \\mathbf{f} ) - N_1^{-1} \\Delta_y^{-1} \\eta_{ij} \\partial_{x^i} \\partial_{y^j} \\mathbf{f}.")]]

#text("We abbreviate the differential operator ")#mi("{\\eta_{ij} \\partial_{x^i} \\partial_{y^j}}")#text(" as ")#mi("{\\nabla_x \\cdot \\nabla_y}")#text(". Iterating the above identity ")#mi("{M}")#text(" times, we obtain")

#align(center)[#tao-fit-display[#mitex("\\mathbf{f} = (\\partial_{x^i} + N_1 \\partial_{y^i}) \\mathbf{d}^i + \\mathbf{f}^{\\prime}")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\mathbf{d}^i := \\sum_{m=1}^{M} (-1)^{m-1} N_1^{-m} \\Delta^{M-m}_y \\eta_{ij} \\partial_{y^j} (\\nabla_x \\cdot \\nabla_y)^{m-1} \\mathbf{g}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathbf{f}^{\\prime} := (-1)^M N_1^{-M} (\\nabla_x \\cdot \\nabla_y)^M \\mathbf{g}.")]]

#text("In particular, ")#mi("{\\mathbf{d}^i}")#text(" is supported in ")#mi("{\\Omega \\times \\bigcup_{k=1}^K T^k}")#text(". Observe that ")#mi("{(\\mathbf{v}^{\\prime}, 0, \\mathbf{R}, \\mathbf{f}^{\\prime}, \\mathbf{F})}")#text(" is a simplified fast-slow solution supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(", where")

#tao-aligned(keep: true)[


#tao-math("\\mathbf{v}^{\\prime}  & := \\mathbf{v}^i - \\mathbf{d}^i", block: true)



#tao-math("\\mathbf{R}^{ij}  & := - \\mathbf{d}^i \\mathbf{v}^j - \\mathbf{v}^i \\mathbf{d}^j - \\mathbf{d}^i \\mathbf{d}^j.", block: true)
]

#text("From ")#link(<tao-3bc6965647f3a0c6264f>)[#text("(72)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{\\leq m} \\mathbf{f}^{\\prime} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} N_1^{-M} N^{-\\varepsilon M}", block: true)]]

#text("so in particular for ")#mi("{M}")#text(" large enough")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{\\leq m} \\mathbf{f}^{\\prime} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} N^{-30}", block: true)]]

#text("for any ")#mi("{m \\geq 0}")#text(". Meanwhile, another appeal to ")#link(<tao-3bc6965647f3a0c6264f>)[#text("(72)")]#text(" yields")

#metadata(none) <tao-384f303b14bcda1ca2a4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(73)")])
#tao-math("\\left\\| D^{\\leq m} \\mathbf{d} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} \\sum_{m^{\\prime}=1}^M N_1^{-m^{\\prime}} N^{\\varepsilon (-2m^{\\prime}+1)} \\lesssim_U N^{-1}", block: true)]]

#text("for any ")#mi("{m \\geq 0}")#text(", and hence by ")#link(<tao-7a2953521a45e92654cd>)[#text("(67)")]#text(" and the triangle inequality")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{\\leq m} \\mathbf{v}^{\\prime} \\right\\|_{L^2_{t,x,y}} \\lesssim_{U,m} 1.", block: true)]]

#text("Similarly one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathbf{v}^{\\prime} \\right\\|_{L^2_{t,x,y}} \\lesssim \\left\\| R \\right\\|_{L^1_{t,x}}^{1/2}.", block: true)]]

#text("Since ")#mi("{\\mathbf{v}^{\\prime}}")#text(" continues to be supported on the thin set ")#mi("{\\Omega \\times \\bigcup_{k=1}^K T_k}")#text(", we can apply Hölder as before to conclude that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{\\leq m} \\mathbf{v}^{\\prime} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U,m} N^{-30}", block: true)]]

#text("for any ")#mi("{m \\geq 0}")#text(". Also, from ")#link(<tao-384f303b14bcda1ca2a4>)[#text("(73)")]#text(" and Hölder we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathbf{R} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U} N^{-1}.", block: true)]]

#text("We have now achieved the bound ")#link(<tao-71a889773a1344dec69c>)[#text("(59)")]#text("; the remaining estimate that needs to be corrected for is ")#link(<tao-a2d2c0953b4c6966b770>)[#text("(60)")]#text(". This we can do by a modification of the previous argument, where we now work to reduce the size of ")#mi("{\\mathbf{F}}")#text(" rather than ")#mi("{\\mathbf{f}}")#text(". Observe that as ")#mi("{\\mathbf{F}}")#text(" is “high frequency” (mean zero in the ")#mi("{y}")#text(" variable), one can write")

#tao-aligned(keep: true)[


#tao-math("\\mathbf{F}^i  & = (\\partial_{x^j} + N_1 \\partial_{y^j}) ( N_1^{-1} \\Delta_y^{-1} \\eta^{il} \\partial_{y^l} \\mathbf{F}^j + N_1^{-1} \\Delta_y^{-1} \\eta^{jl} \\partial_{y^j} \\mathbf{F}^i )", block: true)



#tao-math(" & - \\partial_{y^i} ( \\partial_{y_j} \\mathbf{F}^j )", block: true)



#tao-math(" & + N^{-1} T \\mathbf{F}^i", block: true)
]

#text("where ")#mi("{T}")#text(" is the linear operator on smooth vector-valued functions on ")#mi("{\\mathbf{\\Omega}}")#text(" of mean zero defined by the formula")

#align(center)[#tao-fit-display[#mitex("(T \\mathbf{F})^i := -\\eta^{il} \\Delta_y^{-1} \\partial_{x^j} \\partial_{y^l} \\mathbf{F}^j - \\eta^{jl} \\Delta_y^{-1} \\partial_{x^j} \\partial_{y^l} \\mathbf{F}^i.")]]

#text("Note that ")#mi("{T\\mathbf{F}}")#text(" also has mean zero. We can thus iterate and obtain")

#align(center)[#tao-fit-display[#mitex("\\mathbf{F}^i = (\\partial_{x^j} + N_1 \\partial_{y^j}) \\mathbf{S}^{ij} - \\partial_{y^i} \\mathbf{q} + (\\mathbf{F}^{\\prime})^i")]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("\\mathbf{S}^{ij}  & := \\sum_{m=1}^{M} N_1^{-m} \\eta^{il} \\Delta_y^{-1} \\partial_{y^l} T^{m-1} \\mathbf{F}^j + \\eta^{jl} \\Delta_y^{-1} \\partial_{y^l} T^{m-1} \\mathbf{F}^i", block: true)



#tao-math("\\mathbf{F}^{\\prime}  & := N_1^{-M} T^M \\mathbf{F}", block: true)
]

#text("and ")#mi("{\\mathbf{q}}")#text(" is a smooth function whose exact form is explicit but irrelevant for our argument. We then see that ")#mi("{(\\mathbf{v}^{\\prime}, \\mathbf{q}, \\mathbf{R} + \\mathbf{S}, \\mathbf{f}^{\\prime}, \\mathbf{F}^{\\prime})}")#text(" is a simplified fast-slow solution supported in ")#mi("{I^{\\prime} \\times \\mathbf{T} \\times \\mathbf{T}}")#text(". Since ")#mi("{\\Delta_y^{-1} \\partial_{y^i}}")#text(" is bounded in ")#mi("{L^1_y}")#text(", we see from ")#link(<tao-d75c020e53ff427ca45e>)[#text("(69)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathbf{S} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U,M} \\sum_{m=1}^M N_1^{-m} \\lesssim N^{-1+\\varepsilon},", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\mathbf{F} \\right\\|_{L^1_{t,x,y}} \\lesssim_{U,M} N_1^{-M} \\lesssim N^{-30}", block: true)]]

#text("if ")#mi("{M}")#text(" is large enough. Thus ")#mi("{(\\mathbf{v}^{\\prime}, \\mathbf{q}, \\mathbf{R} + \\mathbf{S}, \\mathbf{f}^{\\prime}, \\mathbf{F}^{\\prime})}")#text(" obeys the required bounds ")#link(<tao-df269ed991e4314f79ea>)[#text("(56)")]#text("–")#link(<tao-a2d2c0953b4c6966b770>)[#text("(60)")]#text(", concluding the proof. ")#mi("\\Box")

#text("As an application of this proposition we construct a low-regularity weak solution to high-dimensional Navier-Stokes that does not obey energy conservation. More precisely, for any ")#mi("{s \\geq 0}")#text(", let ")#mi("{X^s}")#text(" be the Banach space of periodic functions ")#mi("{u \\in C^0_t H^s_x(\\Omega \\rightarrow {\\bf R}^d)}")#text(" which are divergence free, and of mean zero at every time. For ")#mi("{\\nu \\geq 0}")#text(", define a ")#emph[#text("time-periodic weak ")#mi("{H^s}")#text(" solution")]#text(" ")#mi("{u}")#text(" of the Navier-Stokes (or Euler, if ")#mi("{\\nu=0}")#text(") equations to be a function ")#mi("{u \\in X^s}")#text(" that solves the equation")

#align(center)[#tao-fit-display[#mitex("\\partial_t u + \\partial_j {\\mathbb P} (u^j u) = \\nu \\Delta u")]]

#text("in the sense of distributions. (Note that one may easily define ")#mi("{{\\mathbb P}}")#text(" on ")#mi("{L^1_{t,x}}")#text(" functions in a distributional sense, basically because the adjoint operator ")#mi("{{\\mathbb P}^*}")#text(" maps test functions to bounded functions.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 28 (Low regularity non-trivial weak solutions)")]#text(" ")#metadata(none) <tao-94d186f8b721736d4962>#text(" Assume that the dimension ")#mi("{d}")#text(" is sufficiently large. Then for any ")#mi("{\\nu \\geq 0}")#text(", there exists a periodic weak ")#mi("{L^2}")#text(" solution ")#mi("{u}")#text(" to Navier-Stokes which equals zero at time ")#mi("{t=0}")#text(", but is not identically zero. In particular, periodic weak ")#mi("{L^2}")#text(" solutions are not uniquely determined by their initial data, and do not necessarily obey the energy inequality")

#metadata(none) <tao-e8c15873f5e9f4d0cde1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(74)")])
#tao-math("\\frac{1}{2} \\int_{\\mathbf{T}} \\left|u(t,x)\\right|^2\\ dx \\leq \\frac{1}{2} \\int_{\\mathbf{T}} \\left|u_0(x)\\right|^2\\ dx.", block: true)]]
]

#emph[#text("Proof:")]#text(" Let ")#mi("{u^{(0)}}")#text(" be an element of ")#mi("{X^0}")#text(" that is supported on ")#mi("{[0.4, 0.6] \\times \\mathbf{T}_E}")#text(" and is not identically zero (it is easy to show that such an element exists). By Proposition ")#link(<tao-459bd89743ffce17a522>)[#text("25")]#text(", we may then find a Navier-Stokes-Reynolds flow ")#mi("{(u^{(0)}, p^{(0)}, R^{(0)})}")#text(" also supported on ")#mi("{[0.4, 0.6] \\times \\mathbf{T}_E}")#text(". Let ")#mi("{N_0}")#text(" be sufficiently large. By applying Proposition ")#link(<tao-b10b18f906fcd1ca8784>)[#text("26")]#text(" repeatedly (with say ")#mi("{\\varepsilon=1/2}")#text(") and with a sufficiently rapidly increasing sequence ")#mi("{N_0 < N_1 < \\dots}")#text(", we can find a sequence ")#mi("{(u^{(n)}, p^{(n)}, R^{(n)})}")#text(" of Navier-Stokes-Reynolds flows supported on (say) ")#mi("{[0.3 + 2^{-n}/100, 0.7 - 2^{-n}/100] \\times \\mathbf{T}_E}")#text(" obeying the bounds")

#tao-aligned(keep: true)[


#tao-math("\\left\\| R^{(n+1)} \\right\\|_{L^1_{t,x}}  & \\lesssim N_n^{-1/4}", block: true)



#tao-math("\\left\\|u^{(n+1)} - u^{(n)} \\right\\|_{L^2_{t,x}}  & \\lesssim_d \\left\\| R^{(n)} \\right\\|_{L^1_{t,x}}^{1/2}", block: true)



#tao-math("\\left\\|u^{(n+1)} - u^{(n)} \\right\\|_{L^1_{t,x}}  & \\lesssim N_n^{-9}", block: true)
]

#text("(say) for ")#mi("{n \\geq 0}")#text(". For ")#mi("{N_n}")#text(" sufficiently rapidly growing, this implies that ")#mi("{R^{(n)}}")#text(" converges strongly in ")#mi("{L^1}")#text(" to zero, while ")#mi("{u^{(n)}}")#text(" converges strongly in ")#mi("{L^2}")#text(" to some limit ")#mi("{u \\in X^0}")#text(" supported in ")#mi("{[0.3, 0.7] \\times \\mathbf{T}_E}")#text(". From the triangle inequality we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\|u - u^{(0)} \\right\\|_{L^1_{t,x}} \\lesssim N_0^{-9}", block: true)]]

#text("(if ")#mi("{N_n}")#text(" is sufficiently rapidly growing) and hence ")#mi("{u}")#text(" is not identically zero if ")#mi("{N_0}")#text(" is chosen large enough. Applying Leray projections to the Navier-Stokes-Reynolds equation we have")

#align(center)[#tao-fit-display[#mitex("\\partial_t u^{(n)} + \\partial_j {\\mathbb P} ((u^{(n)})^j u^{(n)} ) = \\partial_j \\mathbf{P} (R^{(n)})^{\\cdot j} + \\nu \\Delta u^{(n)}")]]

#text("in the sense of distributions (where ")#mi("{(R^{(n)})^{\\cdot j}}")#text(" is the vector field with components ")#mi("{(R^{(n)})^{ij}}")#text(" for ")#mi("{i=1,\\dots,d}")#text("); taking distributional limits as ")#mi("{n \\rightarrow \\infty}")#text(", we conclude that ")#mi("{u}")#text(" is a periodic weak ")#mi("{L^2}")#text(" solution to the Navier-Stokes equations, as required. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 4. High regularity weak solutions to Navier-Stokes in high dimensions — ")]]

#text("Now we refine the above arguments to give a higher regularity version of Corollary ")#link(<tao-94d186f8b721736d4962>)[#text("28")]#text(", in which we can give the weak solutions almost half a derivative of regularity in the Sobolev scale:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 29 (Non-trivial weak solutions)")]#text(" ")#metadata(none) <tao-047de0f543c7e3596bb6>#text(" Let ")#mi("{0 < s < 1/2}")#text(", and assume that the dimension ")#mi("{d}")#text(" is sufficiently large depending on ")#mi("{s}")#text(". Then for any ")#mi("{\\nu \\geq 0}")#text(", there exists a periodic weak ")#mi("{H^s}")#text(" solution ")#mi("{u}")#text(" which equals zero at time ")#mi("{t=0}")#text(", but is not identically zero. In particular, periodic weak ")#mi("{H^s}")#text(" solutions are not uniquely determined by their initial data, and do not necessarily obey the energy inequality ")#link(<tao-e8c15873f5e9f4d0cde1>)[#text("(74)")]#text(".")
]

#text("This result is inspired by a three-dimensional result of ")#link("https://arxiv.org/abs/1709.10033")[#text("Buckmaster and Vicol")]#text(" (with a small value of ")#mi("{s>0}")#text(") and a higher dimensional result of Luo (taking ")#mi("{\\alpha = 1/200}")#text(", and restricting attention to time-independent solutions). In high dimensions one can create fairly regular functions which are large in ")#mi("{L^2}")#text(" type norms but tiny in ")#mi("{L^1}")#text(" type norms; when using the Sobolev scale ")#mi("{H^s}")#text(" to control the solution ")#mi("{u}")#text(" (and ")#mi("{L^1}")#text(" type norms to measure an associated stress tensor), this has the effect of allowing one to treat as negligible the linear terms ")#mi("{\\partial_t u - \\nu \\Delta u}")#text(" in (variants of) the Navier-Stokes equation, as well as interaction terms between low and high frequencies. As such, the analysis here is simpler than that required to establish the Onsager conjecture. The construction used to prove this theorem shows in fact that periodic weak ")#mi("{H^s}")#text(" solutions are in some sense “dense” in ")#mi("{X^s}")#text(", but we will not attempt to quantify this fact here.")

#text("In the proof of Corollary ")#link(<tao-94d186f8b721736d4962>)[#text("28")]#text(", we took the frequency scales ")#mi("{N_n}")#text(" to be extremely rapidly growing in ")#mi("{n}")#text(". This will no longer be good enough for proving Theorem ")#link(<tao-047de0f543c7e3596bb6>)[#text("29")]#text(", and in fact we need to take a fairly dense set of frequency scales in which ")#mi("{N_{n+1} = N_n^{1+\\varepsilon}}")#text(" for a small ")#mi("{\\varepsilon}")#text(". In order to do so, we have to replace Proposition ")#link(<tao-b10b18f906fcd1ca8784>)[#text("26")]#text(" with a more quantitative version in which the dependence of bounds on the size of the original Navier-Stokes-Reynolds flow ")#mi("{U}")#text(" is made much more explicit.")

#text("We turn to the details. We select the following parameters:")

#list(
[#text("A regularity ")#mi("{0 < s < 1/2}")#text(";")],
[#text("A quantity ")#mi("{\\varepsilon>0}")#text(", assumed to be sufficiently small depending on ")#mi("{s}")#text(";")],
[#text("An integer ")#mi("{M \\geq 1}")#text(", assumed to be sufficiently large depending on ")#mi("{s,\\varepsilon}")#text("; and")],
[#text("A dimension ")#mi("{d}")#text(", assumed to be sufficiently large depending on ")#mi("{s,\\varepsilon,M}")#text(".")]
)

#text("Then we let ")#mi("{\\nu\\geq 0}")#text(". To simplify the notation we allow all implied constants to depend on ")#mi("{s,\\varepsilon,M,d,\\nu}")#text(" unless otherwise specified. We recall from the previous section the notion of a Navier-Stokes-Reynolds flow ")#mi("{(u,p,R)}")#text(". The basic strategy is to start with a Navier-Stokes-Reynolds flow ")#mi("{(u,p,R)}")#text(" and repeatedly adjust ")#mi("{u}")#text(" by increasingly high frequency corrections in order to significantly reduce the size of the stress ")#mi("{R}")#text(" (at the cost of making both of these expressions higher in frequency).")

#text("As before, we abbreviate ")#mi("{L^p_t L^p_x(\\Omega \\rightarrow {\\bf R}^m)}")#text(" as ")#mi("{L^p_{t,x}}")#text(". We write ")#mi("{\\nabla_x}")#text(" for the spatial gradient to distinguish it from the time derivative ")#mi("{\\partial_t}")#text(".")

#text("The main iterative statement (analogous to Theorem ")#link(<tao-d2b5f37e1eef51deddc9>)[#text("14")]#text(") starts with a Navier-Stokes-Reynolds flow ")#mi("{(u_0,p_0,R_0)}")#text(" oscillating at spatial scales up to some small wavelength ")#mi("{1/N_0}")#text(", and modifies it to a Navier-Stokes-Reynolds flow ")#mi("{(u_1,p_1,R_1)}")#text(" oscillating at a slightly smaller wavelength ")#mi("{\\sim 1/N_0^{1+\\varepsilon}}")#text(", with a smaller Reynolds stress. It can be viewed as a more quantitative version of Proposition ")#link(<tao-b10b18f906fcd1ca8784>)[#text("26")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 30 (Iterative step)")]#text(" ")#metadata(none) <tao-36498366fa588fcaeaf2>#text(" Let ")#mi("{N_0}")#text(" be sufficiently large depending on the parameters ")#mi("{s,\\varepsilon,M,d,\\nu}")#text(". Set ")#mi("{s^{\\prime} := s + 10\\varepsilon}")#text(". Suppose that one has a Navier-Stokes-Reynolds flow ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" obeying the estimates")

#metadata(none) <tao-87a0acaec00fa34a3166>

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N_0^{-\\varepsilon} \\partial_t, N_0^{-1} \\nabla_x)^{\\leq M} \\nabla_x u^{(0)} \\right\\|_{L^2_{t,x}}  & \\leq A N_0^{1-s^{\\prime}}", block: true, numbering: n => [#text("(75)")])

#metadata(none) <tao-49f01202c6567a0ab4a7>

#tao-math("\\left\\| R^{(0)} \\right\\|_{L^1_{t,x}}  & \\leq A^2 N_0^{-2(1+\\varepsilon)s^{\\prime} - 10\\varepsilon^2}.", block: true, numbering: n => [#text("(76)")])
]

#text("for some ")#mi("{A \\geq 1}")#text(". Set ")#mi("{N_1 := N_0^{1+\\varepsilon}}")#text(". Then there exists a Navier-Stokes-Reynolds flow ")#mi("{(u^{(1)},p^{(1)},R^{(1)})}")#text(" obeying the estimates")

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N_1^{-\\varepsilon} \\partial_t, N_1^{-1} \\nabla_x)^{\\leq M} \\nabla_x u^{(1)} \\right\\|_{L^2_{t,x}}  & \\leq A N_1^{1-s^{\\prime}}", block: true)



#tao-math("\\left\\| R^{(1)} \\right\\|_{L^1_{t,x}}  & \\leq A^2 N_1^{-2(1+\\varepsilon)s^{\\prime} - 10\\varepsilon^2}", block: true)



#tao-math("\\left\\| (N_1^{-\\varepsilon} \\partial_t)^{\\leq 1} (u^{(1)} - u^{(0)}) \\right\\|_{L^2_{t,x}}  & \\lesssim A N_1^{-s^{\\prime}}", block: true)



#tao-math("\\left\\| u^{(1)} - u^{(0)} \\right\\|_{L^1_{t,x}}  & \\lesssim A N_1^{-10}.", block: true)
]

#text("Furthermore, if ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" is supported on ")#mi("{I \\times \\mathbf{T}_E}")#text(" for some interval ")#mi("{I}")#text(", then one can ensure that ")#mi("{(u^{(1)}, p^{(1)},R^{(1)})}")#text(" is supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(", where ")#mi("{I^{\\prime}}")#text(" is the ")#mi("{N_0^{-\\varepsilon^2}}")#text("-neighbourhood of ")#mi("{I}")#text(".")
]

#text("Let us assume Theorem ")#link(<tao-36498366fa588fcaeaf2>)[#text("30")]#text(" for the moment and establish Theorem ")#link(<tao-047de0f543c7e3596bb6>)[#text("29")]#text(". Let ")#mi("{u^{(0)} \\in X^\\infty}")#text(" be chosen to be supported on (say) ")#mi("{[0.4,0.6] \\times \\mathbf{T}_E}")#text(" and not be identically zero. By Proposition ")#link(<tao-459bd89743ffce17a522>)[#text("25")]#text(", we can then find a Navier-Stokes-Reynolds flow ")#mi("{U = (u^{(0)},p^{(0)},R^{(0)})}")#text(" supported on ")#mi("{[0.4,0.6] \\times \\mathbf{T}_E}")#text(". Let ")#mi("{N_0 > 1}")#text(" be a sufficiently large parameter, and set ")#mi("{A := N_0^{(1+\\varepsilon)s^{\\prime} + 10 \\varepsilon^2}}")#text(", then the hypotheses ")#link(<tao-87a0acaec00fa34a3166>)[#text("(75)")]#text(", ")#link(<tao-49f01202c6567a0ab4a7>)[#text("(76)")]#text(" will be obeyed for ")#mi("{N_0}")#text(" large enough. Set ")#mi("{N_{k+1} := N_k^{1+\\varepsilon}}")#text(" for all ")#mi("{i \\geq 0}")#text(". By iteratively applying Theorem ")#link(<tao-36498366fa588fcaeaf2>)[#text("30")]#text(", we may find a sequence ")#mi("{(u^{(k)}, p^{(k)}, R^{(k)})}")#text(" of Navier-Stokes-Reynolds flows, all supported on (say) ")#mi("{[0.3, 0.7] \\times \\mathbf{T}_E}")#text(", obeying the bounds")

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N_{k+1}^{-\\varepsilon} \\partial_t, N_{k+1}^{-1} \\nabla x)^{\\leq M} \\nabla_x u^{(k+1)} \\right\\|_{L^2_{t,x}}  & \\leq A N_{k+1}^{1-s^{\\prime}}", block: true)



#tao-math("\\left\\| R^{(k+1)} \\right\\|_{L^1_{t,x}}  & \\leq A^2 N_{k+1}^{-2(1+\\varepsilon)s^{\\prime} - 10\\varepsilon^2}", block: true)



#tao-math("\\left\\| (N_{k+1}^{-\\varepsilon} \\partial_t)^{\\leq 1} (u^{(k+1)} - u^{(k)}) \\right\\|_{L^2_{t,x}}  & \\lesssim A N_{k+1}^{-s^{\\prime}}", block: true)



#tao-math("\\left\\| u^{(k+1)} - u^{(k)} \\right\\|_{L^1_{t,x}}  & \\lesssim A N_k^{-10}.", block: true)
]

#text("for ")#mi("{k \\ge 0}")#text(". In particular, the ")#mi("{R^{(k)}}")#text(" converge weakly to zero on ")#mi("{\\Omega}")#text(", and we have the bound")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u^{(k+1)} - u^{(k)}\\right\\|_{H^1_t H^s_x} \\lesssim A N_{k+1}^{s-s^{\\prime}+\\varepsilon}", block: true)]]

#text("from Plancherel’s theorem, and hence by Sobolev embedding in time")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u^{(k+1)} - u^{(k)}\\right\\|_{C^0_t H^s_x} \\lesssim A N_{k+1}^{s-s^{\\prime}+\\varepsilon}.", block: true)]]

#text("Thus ")#mi("{u^{(k)}}")#text(" converges strongly in ")#mi("{C^0_t H^s_x}")#text(" (and in particular also in ")#mi("{C^0_t L^p_x}")#text(" for some ")#mi("{p>2}")#text(") to some limit ")#mi("{u^{(\\infty)}}")#text(" ; as the ")#mi("{u^{(k)}}")#text(" are all divergence-free, ")#mi("{u^{(\\infty)}}")#text(" is also. From applying Leray projections to ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(26)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("\\partial_t u^{(k)} + \\partial_j {\\mathbb P} ( (u^{(k)})^j u^{(k)} ) = \\nu \\Delta^{(k)} u^{(k)} + \\partial_j {\\mathbb P} (R^{(k)})^{\\cdot j}")]]

#text("Taking weak limits we conclude that ")#mi("{u^{(\\infty)}}")#text(" is a weak solution to Navier-Stokes. Also, from construction one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| u - u^{(\\infty)} \\right\\|_{L^1_{t,x}} \\lesssim A N_1^{-10} \\lesssim N_0^{-1}", block: true)]]

#text("(say), and so for ")#mi("{N_0}")#text(" large enough ")#mi("{u^{(\\infty)}}")#text(" is not identically zero. This proves Theorem ")#link(<tao-047de0f543c7e3596bb6>)[#text("29")]#text(".")

#text("It remains to establish Theorem ")#link(<tao-36498366fa588fcaeaf2>)[#text("30")]#text(". It will be convenient to introduce the intermediate frequency scales")

#align(center)[#tao-fit-display[#mitex("N_0 \\leq \\tilde N_0 \\leq N^{\\prime}_1 \\leq N_1")]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tilde N_0 := N_0^{1+\\varepsilon^2}")]]

#text("is slightly larger than ")#mi("{N_0}")#text(", and")

#align(center)[#tao-fit-display[#mitex("N^{\\prime}_1 := \\lfloor N_1^{1-\\varepsilon^2} \\rfloor")]]

#text("is slightly smaller than ")#mi("{N_1}")#text(" (and constrained to be integer).")

#text("Before we begin the rigorous argument, we first give a heuristic explanation of the numerology. The initial solution ")#mi("{u^{(0)}}")#text(" has about ")#mi("{M}")#text(" degrees of regularity controlled at ")#mi("{N_0}")#text(". For technical reasons we will upgrade this to an infinite amount of regularity, at the cost of worsening the frequency bound slightly from ")#mi("{N_0}")#text(" to ")#mi("{\\tilde N_0}")#text(". Next, to cancel the Reynolds stress ")#mi("{R^{(0)}}")#text(" up to a smaller error ")#mi("{R^{(1)}}")#text(", we will perturb ")#mi("{u^{(0)}}")#text(" by some high frequency correction ")#mi("{v}")#text(", basically oscillating at spatial frequency ")#mi("{N_1}")#text(" (and temporal frequency ")#mi("{N_1^\\varepsilon}")#text("), so that ")#mi("{v^i v^j}")#text(" is approximately equal to ")#mi("{-(R^{(0)})^{ij}}")#text(" (minus a pressure term) after averaging at spatial scales ")#mi("{1/N^{\\prime}_1}")#text(". Given the size bound ")#link(<tao-49f01202c6567a0ab4a7>)[#text("(76)")]#text(", one expects to achieve this with ")#mi("{v}")#text(" of ")#mi("{L^2_{t,x}}")#text(" norm about ")#mi("{A N_0^{-(1+\\varepsilon)s^{\\prime} - 5 \\varepsilon^2} = N_1^{-s^{\\prime}} N_0^{-5\\varepsilon^2}}")#text(". By exploiting the small gap between ")#mi("{N^{\\prime}_1}")#text(" and ")#mi("{N_1}")#text(", we can make ")#mi("{v}")#text(" concentrate on a fairly small measure set (of density something like ")#mi("{N_1^{-\\varepsilon^2(d-1)}}")#text("), which in high dimension allows us to make linear terms such as ")#mi("{\\partial_t v}")#text(" and ")#mi("{\\nu \\Delta v}")#text(" (as well as the correlation terms ")#mi("{\\partial_j ((u^{(0)})^i v^j)}")#text(" and ")#mi("{\\partial_j (v^i (u^{(0)})^j)}")#text(") negligible in size (as measured using ")#mi("{L^1}")#text(" type norms) when compared against quadratic terms such as ")#mi("{\\partial_j (v^i v^j)}")#text(" (cf. the proof of Proposition ")#link(<tao-b10b18f906fcd1ca8784>)[#text("26")]#text("). The defect ")#mi("{\\partial_j (v^i v^j) - \\partial_j R^{ij}}")#text(" will then oscillate at frequency ")#mi("{N^{\\prime}_1}")#text(", but can be selected to be of size about ")#mi("{A^2 N^{\\prime}_0 (N_1^{-s^{\\prime}} N_0^{-5\\varepsilon^2})^2}")#text(" in ")#mi("{L^1_{t,x}}")#text(" norm, because can choose ")#mi("{v}")#text(" to cancel off all the high-frequency (by which we mean ")#mi("{N^{\\prime}_1}")#text(" or greater) contributions to this term, leaving only low frequency contributions (at frequencies ")#mi("{N^{\\prime}_0}")#text(" or below). Using the ellipticity of the Laplacian, we can then express this defect as ")#mi("{\\partial_j \\tilde R^{ij}}")#text(" where the ")#mi("{L^1_{t,x}}")#text(" norm of ")#mi("{\\tilde R^{ij}}")#text(" is of order")

#align(center)[#tao-fit-display[#mitex("A^2 (N^{\\prime}_1)^{-1} \\tilde N_0 (N_1^{-s^{\\prime}} N_0^{-5\\varepsilon^2})^2 = N_1^{-2s^{\\prime} - \\varepsilon + O(\\varepsilon^2)}.")]]

#text("When ")#mi("{s<1/2}")#text(", this is slightly less than ")#mi("{A^2 N_1^{-2(1+\\varepsilon)s^{\\prime} - 10\\varepsilon^2} }")#text(", allowing one to close the argument.")

#text("We now turn to the rigorous details. In a later part of the argument we will encounter a ")#emph[#text("loss of derivatives")]#text(", in that the new Navier-Stokes-Reynolds flow ")#mi("{(u^{(1)},p^{(1)},R^{(1)})}")#text(" has lower amounts of controlled regularity (in both space and time) than the Navier-Stokes-Reynolds flow")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" used to construct it. To counteract this loss of derivatives we need to perform an initial ")#emph[#text("mollification step")]#text(", which improves the amount of regularity from ")#mi("{M}")#text(" derivatives in space and time to an unlimited number of derivatives in space and time, at the cost of worsening the estimates on ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" slightly (basically by replacing ")#mi("{N_0}")#text(" with ")#mi("{\\tilde N_0}")#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 31 (Mollification)")]#text(" ")#metadata(none) <tao-f74c418e07d82a11d903>#text(" Let the notation and hypotheses be as above. Then we can find a Navier-Stokes-Reynolds flow ")#mi("{(\\tilde u^{(0)}, \\tilde p^{(0)}, \\tilde R^{(0)})}")#text(" obeying the estimates")

#metadata(none) <tao-bfb2f0821be1ad17d369>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(77)")])
#tao-math("\\left\\| (\\tilde N_0^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla x)^m \\nabla_x \\tilde u^{(0)} \\right\\|_{L^2_{t,x}} \\lesssim_m A \\tilde N_0^{1-s^{\\prime}}", block: true)]]

#text("and")

#metadata(none) <tao-25fbf5e27e09acb6019e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(78)")])
#tao-math("\\left\\| (\\tilde N_0^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla x)^m \\tilde R \\right\\|_{L^1_{t,x}} \\lesssim_m A^2 N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}}", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(", and such that")

#metadata(none) <tao-8137a28e1099fc0fc2ca>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(79)")])
#tao-math("\\left\\| (N_1^{-\\varepsilon} \\partial_t)^{\\leq 1} (\\tilde u^{(0)} - u^{(0)}) \\right\\|_{L^2_{t,x}} \\lesssim A N_1^{-s^{\\prime}}", block: true)]]

#text("and")

#metadata(none) <tao-b73804d40134038d8336>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(80)")])
#tao-math("\\left\\| \\tilde u^{(0)} - u^{(0)} \\right\\|_{L^1_{t,x}} \\lesssim A N_1^{-10}.", block: true)]]

#text("Furthermore, if ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" is supported on ")#mi("{I \\times \\mathbf{T}_E}")#text(" for some interval ")#mi("{I}")#text(", then one can ensure that ")#mi("{(\\tilde u^{(0)}, \\tilde p^{(0)},\\tilde R^{(0)})}")#text(" is supported in ")#mi("{I^{\\prime\\prime} \\times \\mathbf{T}_E}")#text(", where ")#mi("{I^{\\prime\\prime}}")#text(" is the ")#mi("{N_0^{-\\varepsilon^2}/2}")#text("-neighbourhood of ")#mi("{I}")#text(".")
]

#text("We remark that this sort of mollification step is now a standard technique in any iteration scheme that involves loss of derivatives, including the Nash-Moser iteration scheme that was first used to prove Theorem ")#link(<tao-a08a0fcbdeafd3c1b3a4>)[#text("8")]#text(".")

#emph[#text("Proof:")]#text(" Let ")#mi("{\\phi: {\\bf R} \\times {\\bf R}^d \\rightarrow {\\bf R}}")#text(" be a bump function (depending only on ")#mi("{M}")#text(") supported on the region ")#tao-math("{\\{ (s,y): \\left|s\\right| \\leq 1/2M, \\left|y\\right| \\leq 1/M\\}}", block: false)#text(" of total mass ")#mi("{1}")#text(", and define the averaging operator ")#mi("{P}")#text(" on smooth functions ")#mi("{f: \\Omega \\rightarrow {\\bf R}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("Pf(t,x) := \\int_{{\\bf R} \\times {\\bf R}^d} \\phi(s,y) f(t-\\tilde N_0^{-\\varepsilon} s,x- \\tilde N_0^{-1} y)\\ ds dy.")]]

#text("From the fundamental theorem of calculus we have")

#align(center)[#tao-fit-display[#mitex("P = I - Q")]]

#text("where ")#mi("{I}")#text(" is the identity operator and")

#align(center)[#tao-fit-display[#mitex("Qf(t,x) := \\int_0^1 \\int_{{\\bf R} \\times {\\bf R}^d} \\phi(s,y)")]]

#align(center)[#tao-fit-display[#mitex("(s \\tilde N_0^{-\\varepsilon} \\partial_t + y \\cdot \\tilde N_0^{-1} \\nabla_x) f(t-\\theta \\tilde N_0^{-\\varepsilon} s, x- \\theta \\tilde N_0^{-1} y)\\ ds dy.")]]

#text("The operators ")#mi("{P}")#text(" and ")#mi("{Q}")#text(" will behave like low and high frequency Littlewood-Paley projections. (We cannot directly use these projections here because their convolution kernels are not localised in time.)")

#text("Observe that ")#mi("{P,Q}")#text(" are convolution operators and thus commute with each other and with the partial derivatives ")#mi("{\\partial_t, \\nabla_x}")#text(". If we apply the operator ")#mi("{I - Q^M}")#text(" to ")#link(<tao-7bfba6e0021f1fd1183d>)[#text("(26)")]#text(", ")#link(<tao-cd35a2426062b7d58fd4>)[#text("(27)")]#text(", ")#link(<tao-571b0e35550136585f65>)[#text("(28)")]#text(", we see that ")#mi("{(\\tilde u^{(0)}, \\tilde p^{(0)}, \\tilde R^{(0)})}")#text(" is Navier-Stokes-Reynolds flow, where")

#tao-aligned(keep: true)[


#tao-math("\\tilde u^{(0)}  & := (I-Q^M) u^{(0)}", block: true)



#tao-math("\\tilde p^{(0)}  & := (I-Q^M) p^{(0)}", block: true)



#tao-math("\\tilde R_{ij}^{(0)}  & := (I-Q^M) R_{ij}^{(0)}", block: true)



#tao-math(" & + (I-Q^M)(u_i^{(0)} u_j^{(0)}) - ((I-Q^M) u_i^{(0)}) ((I-Q^M) u_j^{(0)}).", block: true)
]

#text("Since ")#mi("{Q=I-P}")#text(", ")#mi("{I-Q^M}")#text(" is a linear combination of the operators ")#mi("{P, P^2, \\dots, P^M}")#text(". In particular, we see that ")#mi("{(\\tilde u^{(0)}, \\tilde p^{(0)}, \\tilde R^{(0)})}")#text(" is supported on ")#mi("{I^{\\prime\\prime} \\times \\mathbf{T}}")#text(".")

#text("We abbreviate ")#mi("{D := (\\tilde N_0^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla x)}")#text(". For any ")#mi("{m \\geq 0}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("D^m P f(t,x) = \\int_{{\\bf R} \\times {\\bf R}^d} (\\nabla_s, \\nabla_y)^m \\phi(s,y) f(t-\\tilde N_0^{-\\varepsilon} s,x- \\tilde N_0^{-1} y)\\ ds dy")]]

#text("and therefore deduce the bounds")

#metadata(none) <tao-df76040a115fce1b163e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(81)")])
#tao-math("\\left\\| D^m P f \\right\\|_{L^p_{t,x}} \\lesssim_{m} \\left\\| f \\right\\|_{L^p_{t,x}}", block: true)]]

#text("for any ")#mi("{1 \\leq p \\leq \\infty}")#text(", thanks to Young’s inequality. A similar application of Young’s inequality gives")

#metadata(none) <tao-4f4d57ee0d04dd2ada72>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(82)")])
#tao-math("\\left\\| Q^m f \\right\\|_{L^p_{t,x}} \\lesssim_{m} \\left\\| D^m f \\right\\|_{L^p_{t,x}}", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(" and ")#mi("{1 \\leq p \\leq \\infty}")#text(".")

#text("From ")#link(<tao-df76040a115fce1b163e>)[#text("(81)")]#text(" and decomposing ")#mi("{1-Q^M}")#text(" as linear combinations of ")#mi("{P,P^2,\\dots,P^M}")#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^m \\nabla_x \\tilde u^{(0)} \\right\\|_{L^2_{t,x}} \\lesssim_{m} \\left\\| \\nabla_x u^{(0)} \\right\\|_{L^2_{t,x}}", block: true)]]

#text("for any ")#mi("{m \\geq 0}")#text(", and hence ")#link(<tao-bfb2f0821be1ad17d369>)[#text("(77)")]#text(" follows from ")#link(<tao-87a0acaec00fa34a3166>)[#text("(75)")]#text(". In a similar spirit, from ")#link(<tao-4f4d57ee0d04dd2ada72>)[#text("(82)")]#text(", ")#link(<tao-87a0acaec00fa34a3166>)[#text("(75)")]#text(" one has")

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N_1^{-\\varepsilon} \\partial_t) (\\tilde u^{(0)} - u^{(0)}) \\right\\|_{L^2_{t,x}}  & \\lesssim \\left\\| D Q^{M-1} (1-P) u^{(0)} \\right\\|_{L^2_{t,x}}", block: true)



#tao-math(" & \\lesssim \\left\\| D^{M} u^{(0)} \\right\\|_{L^2_{t,x}}", block: true)



#tao-math(" & \\leq \\left\\| N_0^{-\\varepsilon^3 M} (N_0^{-1} \\nabla x, N_0^{-\\varepsilon} \\partial_t)^{M} u^{(0)} \\right\\|_{L^2_{t,x}}", block: true)



#tao-math(" & \\lesssim_{s,\\varepsilon,M,d,\\nu} A N_1^{-10}", block: true)
]

#text("if ")#mi("{M}")#text(" is large enough; similar arguments give the same bound if ")#mi("{(N_1^{-\\varepsilon} \\partial_t)}")#text(" is deleted. This gives ")#link(<tao-8137a28e1099fc0fc2ca>)[#text("(79)")]#text(", ")#link(<tao-b73804d40134038d8336>)[#text("(80)")]#text(".")

#text("Finally we prove ")#link(<tao-25fbf5e27e09acb6019e>)[#text("(78)")]#text(". By the triangle inequality it suffices to show that ")#metadata(none) <tao-41783996b4a00fd0567d>#tao-math("\\displaystyle  \\left\\| D^m (I-Q^M) R^{(0)} \\right\\|_{L^1_{t,x}} \\lesssim_m A^2 N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}} \\ \\ \\ \\ \\ (83)", block: false)#text(" ")#text(" and ")#metadata(none) <tao-bd9c3af75610052ac964>#tao-math("\\displaystyle  \\left\\| D^m ((I-Q^M)(u_i^{(0)} u_j^{(0)}) - ((I-Q^M) u_i^{(0)}) ((I-Q^M) u_j^{(0)})) \\right\\|_{L^1_{t,x}} \\lesssim_m A^2 N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}} \\ \\ \\ \\ \\ (84)", block: false)#text(" ")#text(" for any ")#mi("{m \\geq 0}")#text(". The claim ")#link(<tao-41783996b4a00fd0567d>)[#text("(83)")]#text(" follows from ")#link(<tao-df76040a115fce1b163e>)[#text("(81)")]#text(", ")#link(<tao-49f01202c6567a0ab4a7>)[#text("(76)")]#text(", after writing ")#mi("{1-Q^M}")#text(" as a linear combination of ")#mi("{P,\\dots,P^M}")#text(" and noting that ")#mi("{N_0^{-2(1+\\varepsilon)s^{\\prime} - 10\\varepsilon^2} = N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}}}")#text(". For ")#link(<tao-bd9c3af75610052ac964>)[#text("(84)")]#text(", if we again write ")#mi("{1-Q^M}")#text(" as a linear combination of ")#mi("{P,\\dots,P^M}")#text(" and uses ")#link(<tao-df76040a115fce1b163e>)[#text("(81)")]#text(" and the Leibniz rule, one can bound the left-hand side of ")#link(<tao-bd9c3af75610052ac964>)[#text("(84)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim_m \\sum_{m_1+m_2=m} \\left\\| D^{m_1} u^{(0)} \\right\\|_{L^2_{t,x}} \\left\\| D^{m_2} u^{(0)} \\right\\|_{L^2_{t,x}}", block: true)]]

#text("and hence by ")#link(<tao-87a0acaec00fa34a3166>)[#text("(75)")]#text(" (bounding ")#mi("{D}")#text(" by ")#mi("{N_0^{-\\varepsilon^2} (N_0^{-1} \\nabla x, N_0^{-\\varepsilon} \\partial_t)}")#text(") this is bounded by")

#align(center)[#tao-fit-display[#mitex("\\lesssim_m N_0^{-\\varepsilon^2 m} A^2 N_0^{2(1-s^{\\prime})}.")]]

#text("This gives ")#link(<tao-bd9c3af75610052ac964>)[#text("(84)")]#text(" when ")#mi("{m \\geq M/2}")#text(". For ")#mi("{m<M/2}")#text(", we rewrite the expression")

#align(center)[#tao-fit-display[#mitex("(I-Q^M)(u_i^{(0)} u_j^{(0)}) - ((I-Q^M) u_i^{(0)}) ((I-Q^M) u_j^{(0)})")]]

#text("as")

#align(center)[#tao-fit-display[#mitex("-Q^M(u_i^{(0)} u_j^{(0)}) + (Q^M u_i^{(0)}) ((I-Q^M) u_j^{(0)}) + u_i^{(0)} Q^M u_j^{(0)}.")]]

#text("The contribution of the first term to ")#link(<tao-bd9c3af75610052ac964>)[#text("(84)")]#text(" can be bounded using ")#link(<tao-4f4d57ee0d04dd2ada72>)[#text("(82)")]#text(", ")#link(<tao-df76040a115fce1b163e>)[#text("(81)")]#text(" (splitting ")#mi("{Q^M = Q^{M-k} (1-P)^k}")#text(") by")

#align(center)[#tao-fit-display[#tao-math("\\lesssim \\left\\| D^M (u_i^{(0)} u_j^{(0)}) \\right\\|_{L^1_{t,x}}", block: true)]]

#text("which by the Leibniz rule, bounding ")#mi("{D}")#text(" by ")#mi("{N_0^{-\\varepsilon^2} (N_0^{-1} \\nabla x, N_0^{-\\varepsilon} \\partial_t)}")#text(", and ")#link(<tao-87a0acaec00fa34a3166>)[#text("(75)")]#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\lesssim N_0^{-\\varepsilon^2 M} A^2 N_0^{2(1-s^{\\prime})}")]]

#text("which is again an acceptable contribution to ")#link(<tao-bd9c3af75610052ac964>)[#text("(84)")]#text(" since ")#mi("{M}")#text(" is large. The other terms are treated similarly. ")#mi("\\Box")

#text("We return to the proof of Theorem ")#link(<tao-36498366fa588fcaeaf2>)[#text("30")]#text(". We abbreviate ")#mi("{D_1 := (N_1^{-\\varepsilon} \\partial_t, N_1^{-1} \\nabla_x)}")#text(". Let ")#mi("{\\tilde U := (\\tilde u^{(0)}, \\tilde p^{(0)}, \\tilde R^{(0)})}")#text(" be the Navier-Stokes-Reynolds flow constructed by Proposition ")#link(<tao-f74c418e07d82a11d903>)[#text("31")]#text(". By using the ansatz")

#align(center)[#tao-fit-display[#mitex("(u^{(1)}, p^{(1)}, R^{(1)}) = (\\tilde u^{(0)} + v, \\tilde p^{(0)} + q, R^{(1)} ),")]]

#text("and the triangle inequality, it will suffice to locate a difference Navier-Stokes-Reynolds flow ")#mi("{(v, q, R^{(1)})}")#text(" at ")#mi("{\\tilde U}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(", obeying the estimates")

#metadata(none) <tao-e32939b51a3293028fd1>

#tao-aligned(keep: true)[


#tao-math("\\left\\| D_1^{\\leq M} \\nabla_x (\\tilde u^{(0)} + v) \\right\\|_{L^2_{t,x}}  & \\leq A N_1^{1-s^{\\prime}}", block: true, numbering: n => [#text("(85)")])

#metadata(none) <tao-7f70f60467ebf670bcbb>

#tao-math("\\left\\| R^{(1)} \\right\\|_{L^1_{t,x}}  & \\lesssim A^2 N_1^{-2(1+\\varepsilon)s^{\\prime} - 11\\varepsilon^2}", block: true, numbering: n => [#text("(86)")])

#metadata(none) <tao-459a1593a2ae2278e14c>

#tao-math("\\left\\| D_1^{\\leq 1} v \\right\\|_{L^2_{t,x}}  & \\lesssim A N_1^{-s^{\\prime}}", block: true, numbering: n => [#text("(87)")])

#metadata(none) <tao-5fc229b555e19a56d5ef>

#tao-math("\\left\\| v \\right\\|_{L^1_{t,x}}  & \\lesssim A N_1^{-10}.", block: true, numbering: n => [#text("(88)")])
]

#text("From ")#link(<tao-bfb2f0821be1ad17d369>)[#text("(77)")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D_1^{\\leq M} \\nabla_x \\tilde u^{(0)} \\right\\|_{L^2_{t,x}} \\leq A N_1^{1-s^{\\prime}}/2", block: true)]]

#text("so by the triangle inequality we can replace ")#link(<tao-e32939b51a3293028fd1>)[#text("(85)")]#text(" by")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D_1^{\\leq M} \\nabla_x v \\right\\|_{L^2_{t,x}} \\leq A N_1^{1-s^{\\prime}}/2", block: true)]]

#text("and then ")#link(<tao-e32939b51a3293028fd1>)[#text("(85)")]#text(", ")#link(<tao-459a1593a2ae2278e14c>)[#text("(87)")]#text(" may then be replaced by the single estimate")

#metadata(none) <tao-39c36a193f31abe7503e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(89)")])
#tao-math("\\left\\| D_1^{\\leq M+1} v \\right\\|_{L^2_{t,x}} \\lesssim A N_1^{-s^{\\prime}-\\varepsilon^2}", block: true)]]

#text("(say). By using Exercise ")#link(<tao-e65e0af34a185a0d0c82>)[#text("24")]#text(" as in the previous section, it then suffices to construct an ")#emph[#text("approximate")]#text(" difference Navier-Stokes-Reynolds flow ")#mi("{(v, q, R^{(1)}, f, F)}")#text(" to the difference equation at ")#mi("{U}")#text(" supported on supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(" obeying the bounds ")#link(<tao-7f70f60467ebf670bcbb>)[#text("(86)")]#text(", ")#link(<tao-5fc229b555e19a56d5ef>)[#text("(88)")]#text(", ")#link(<tao-39c36a193f31abe7503e>)[#text("(89)")]

#metadata(none) <tao-198df46d4a0267e4aab9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(90)")])
#tao-math("\\left\\| D_1^{\\leq M} f \\right\\|_{L^2_{t,x}} \\lesssim A N_1^{-20}", block: true)]]

#text("and")

#metadata(none) <tao-b9af1e8fc3117669a1f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(91)")])
#tao-math("\\left\\| F \\right\\|_{L^1_{t,x}} \\lesssim A N_1^{-20}.", block: true)]]

#text("Now, we pass to fast and slow variables. Let ")#mi("{\\mathbf{D}}")#text(" denote the tuple")

#align(center)[#tao-fit-display[#mitex("\\mathbf{D} := (N_1^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla_x, N_1^{-\\varepsilon^2} \\nabla_y);")]]

#text("informally, the use of ")#mi("{\\mathbf{D}}")#text(" is consistent with oscillations in time of wavelength ")#mi("{\\gtrsim N_1^{-\\varepsilon}}")#text(", in the slow variable ")#mi("{x}")#text(" of wavelength ")#mi("{\\gtrsim \\tilde N_0^{-1}}")#text(", and in the fast variable ")#mi("{y}")#text(" of wavelength ")#mi("{\\gtrsim N_1^{-\\varepsilon^2} \\sim N^{\\prime}_1/N_1}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" By using the method of fast and slow variables as in the previous section, show that to construct the approximate Navier-Stokes-Reynolds flow ")#mi("{(v, q, R^{(1)}, f, F)}")#text(" at ")#mi("{U}")#text(" obeying the bounds ")#link(<tao-7f70f60467ebf670bcbb>)[#text("(86)")]#text(", ")#link(<tao-5fc229b555e19a56d5ef>)[#text("(88)")]#text(", ")#link(<tao-39c36a193f31abe7503e>)[#text("(89)")]#text(", ")#link(<tao-198df46d4a0267e4aab9>)[#text("(90)")]#text(", ")#link(<tao-b9af1e8fc3117669a1f0>)[#text("(91)")]#text(", it suffices to locate an approximate fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" to the difference Navier-Stokes-Reynolds equation at ")#mi("{\\tilde U}")#text(" (at frequency scale ")#mi("{N^{\\prime}_1 \\sim N_1^{1-\\varepsilon^2}}")#text(" rather than ")#mi("{N_1}")#text(") and supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" that obey the bounds")

#metadata(none) <tao-cca69426221c643493f1>

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\mathbf{D}^{\\leq M+1} \\mathbf{v} \\right\\|_{L^2_{t,x,y}}  & \\lesssim A N_1^{-s^{\\prime}-\\varepsilon^2}.", block: true, numbering: n => [#text("(92)")])

#metadata(none) <tao-26d6cc846199111e82b2>

#tao-math("\\left\\| \\mathbf{R} \\right\\|_{L^1_{t,x,y}}  & \\lesssim A^2 N_1^{-2(1+\\varepsilon)s^{\\prime} - 11\\varepsilon^2}", block: true, numbering: n => [#text("(93)")])

#metadata(none) <tao-e0910feac9b21146d9eb>

#tao-math("\\left\\| \\mathbf{v} \\right\\|_{L^1_{t,x,y}}  & \\lesssim A N_1^{-20}", block: true, numbering: n => [#text("(94)")])

#metadata(none) <tao-193351b961747447b43d>

#tao-math("\\left\\| \\mathbf{D}^{\\leq M} \\mathbf{f} \\right\\|_{L^2_{t,x,y}}  & \\lesssim A N_1^{-20}", block: true, numbering: n => [#text("(95)")])

#metadata(none) <tao-15478d02c349cc270fa7>

#tao-math("\\left\\| \\mathbf{F} \\right\\|_{L^1_{t,x,y}}  & \\lesssim A N_1^{-20}.", block: true, numbering: n => [#text("(96)")])
]
]

#text("As in the previous section, we can then pass to simplified fast-slow soutions:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 33")]#text(" Show that to construct the approximate fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" to the difference equation at ")#mi("{\\tilde U}")#text(" obeying the estimates of the previous exercise, it will in fact suffice to locate a simplified fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" at ")#mi("{\\tilde U}")#text(" (again at frequency scale ")#mi("{N^{\\prime}_1}")#text(") supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(", obeying the bounds ")#link(<tao-cca69426221c643493f1>)[#text("(92)")]#text(", ")#link(<tao-26d6cc846199111e82b2>)[#text("(93)")]#text(", ")#link(<tao-193351b961747447b43d>)[#text("(95)")]#text(", ")#link(<tao-15478d02c349cc270fa7>)[#text("(96)")]#text(" and")

#metadata(none) <tao-68acee85933f38109ca9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(97)")])
#tao-math("\\left\\| \\mathbf{D}^{\\leq 2} \\mathbf{v} \\right\\|_{L^2_t L^2_x L^1_y} \\lesssim A N_1^{-30}.", block: true)]]

#text("(")#emph[#text("Hint:")]#text(" one will need the estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\tilde u \\right\\|_{L^2_t L^2_x L^\\infty_y} = \\left\\| \\tilde u \\right\\|_{L^2_{t,x}} \\lesssim A \\tilde N_0^{1-s^{\\prime}}", block: true)]]

#text("from Proposition ")#link(<tao-f74c418e07d82a11d903>)[#text("31")]#text(".)")
]

#text("Now we need to construct a simplified fast-slow solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F})}")#text(" at ")#mi("{\\tilde U}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" obeying the bounds ")#link(<tao-cca69426221c643493f1>)[#text("(92)")]#text(", ")#link(<tao-26d6cc846199111e82b2>)[#text("(93)")]#text(", ")#link(<tao-193351b961747447b43d>)[#text("(95)")]#text(", ")#link(<tao-15478d02c349cc270fa7>)[#text("(96)")]#text(", ")#link(<tao-68acee85933f38109ca9>)[#text("(97)")]#text(". As in the previous section, we do this in stages, first finding a solution that cancels off the top order terms ")#mi("{N^{\\prime}_1 \\partial_{y^j}(\\mathbf{v}^i \\mathbf{v}^j)}")#text(" and ")#mi("{N^{\\prime}_1 \\partial_{y^i} \\mathbf{v}^i}")#text(", and also such that ")#mi("{\\mathbf{v}^i \\mathbf{v}^j + \\tilde R^{ij} + q \\eta^{ij}}")#text(" is “ high frequency” (mean zero in ")#mi("{y}")#text("). Then we apply a divergence corrector to completely eliminate ")#mi("{\\mathbf{f}}")#text(", followed by a stress corrector that almost completely eliminates ")#mi("{\\mathbf{F}}")#text(".")

#text("As before, we need to select ")#mi("{q}")#text(" so that ")#mi("{-\\tilde R^{ij} - q \\eta^{ij}}")#text(" is positive definite. In the previous section we essentially took ")#mi("{q}")#text(" to be a large multiple of ")#tao-math("{\\left|\\tilde R\\right|}", block: false)#text(", but now we will need good control on the derivatives of ")#mi("{q}")#text(", which requires a little more care. Namely, we will need the following technical lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 34 (Smooth polar-type decomposition)")]#text(" ")#metadata(none) <tao-18797a12ad504b11e9a0>#text(" There exists a factorisation ")#mi("{\\tilde R = w^2 S}")#text(", where ")#mi("{w: \\Omega \\rightarrow {\\bf R}}")#text(", ")#mi("{S: \\Omega \\rightarrow {\\bf R}^{d^2}}")#text(" are smooth, supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(", and obey the estimates")

#metadata(none) <tao-11412745e4a857b4295d>

#tao-aligned(keep: true)[


#tao-math("\\left\\| (\\tilde N_0^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla x)^{\\leq 10M} w \\right\\|_{L^2_{t,x}}  & \\lesssim A N_0^{-5\\varepsilon^2} N_1^{-s^{\\prime}}", block: true, numbering: n => [#text("(98)")])

#metadata(none) <tao-f2e0b62a0155903aae2b>

#tao-math("\\left\\| (\\tilde N_0^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla x)^{\\leq 10M} S \\right\\|_{L^\\infty_{t,x}}  & \\lesssim 1.", block: true, numbering: n => [#text("(99)")])
]
]

#emph[#text("Proof:")]#text(" We may assume that ")#mi("{\\tilde R}")#text(" is not identically zero, since otherwise the claim is trivial. For brevity we write ")#mi("{D := (\\tilde N_0^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla x)}")#text(" and ")#mi("{Q := A^2 N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}}}")#text(". From ")#link(<tao-25fbf5e27e09acb6019e>)[#text("(78)")]#text(" we have ")#metadata(none) <tao-114c4758128858fd96b1>#tao-math("\\displaystyle  \\left\\| D^{\\leq 20M} \\tilde R \\right\\|_{L^1_{t,x}} \\lesssim Q. \\ \\ \\ \\ \\ (100)", block: false)#text(" ")#text(" Let ")#mi("{B}")#text(" denote the spacetime cylinder ")#tao-math("{B := \\{ (s,y) \\in {\\bf R} \\times {\\bf R}^d: \\left|s\\right| \\leq 1, \\left|y\\right| \\leq 1 \\}}", block: false)#text(", and let ")#mi("{F: \\Omega \\rightarrow {\\bf R}^+}")#text(" denote the maximal function")

#align(center)[#tao-fit-display[#tao-math("F(t,x) := \\sup_{(s,y) \\in B} \\left|D^{\\leq 10M} \\tilde R(t+\\tilde N_0^{-\\varepsilon} s,x+ \\tilde N_0^{-1} y)\\right|.", block: true)]]

#text("From the fundamental theorem of calculus (or Sobolev embedding) one has the pointwise estimate")

#align(center)[#tao-fit-display[#mitex("F(t,x) \\lesssim \\int_B |D^{\\leq 20M} \\tilde R(t+\\tilde N_0^{-\\varepsilon} s,x+ \\tilde N_0^{-1} y)|\\ ds dy,")]]

#text("thus by Fubini’s theorem and ")#link(<tao-114c4758128858fd96b1>)[#text("(101)")]



#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(101)")])
#tao-math("\\left\\| F \\right\\|_{L^1_{t,x}} \\lesssim Q.", block: true)]]

#text("We do not have good control on the derivatives of ")#mi("{F}")#text(", so we apply a smoothing operator. Let ")#mi("{G: \\Omega \\rightarrow {\\bf R}^+}")#text(" denote the function")

#align(center)[#tao-fit-display[#mitex("G(t,x) := \\int_{{\\bf R} \\times {\\bf R}^d} F( t + \\tilde N_0^{-\\varepsilon} s, x+ \\tilde N_0^{-1} y) \\langle (s,y) \\rangle^{-10d}\\ ds dy")]]

#text("where ")#tao-math("{\\langle (s,y) \\rangle := (1+\\left|s\\right|^2+\\left|y\\right|^2)^{1/2}}", block: false)#text(", then by Fubini’s theorem (or Young’s inequality)")

#metadata(none) <tao-9cf3886f2bbc9660b15a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(102)")])
#tao-math("\\left\\| G \\right\\|_{L^1_{t,x}} \\lesssim Q.", block: true)]]

#text("Also, ")#mi("{G}")#text(" is smooth and strictly positive everywhere, and from differentation under the integral sign and integration by parts we have")

#align(center)[#tao-fit-display[#mitex("D^m G(t,x) \\lesssim_{m} \\int_{{\\bf R} \\times {\\bf R}^d} F( t + \\tilde N_0^{-\\varepsilon} s, x+ \\tilde N_0^{-1} y) |\\nabla_{s,y} \\langle (s,y) \\rangle^{-10d}|\\ ds dy")]]

#text("and hence")

#metadata(none) <tao-b7d85587389c8e3ae15c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(103)")])
#mitex("D^m G \\lesssim_{m} G")]]

#text("for any ")#mi("{m \\geq 0}")#text(". Also, from construction one has")

#metadata(none) <tao-fae4cc860ae0bd31fb5e>

#tao-aligned(keep: true)[


#tao-math("\\left|D^{\\leq 2M} \\tilde R(t,x)\\right|  & \\lesssim \\int_B F( t + \\tilde N_0^{-\\varepsilon} s, x + \\tilde N_0^{-1} y)\\ ds dy", block: true, numbering: n => [#text("(104)")])



#tao-math(" & \\lesssim G(t,x).", block: true)
]

#text("Write ")#mi("{w := G^{1/2}}")#text(". From many applications of the chain rule (or the ")#link("https://en.wikipedia.org/wiki/Fa%C3%A0_di_Bruno%27s_formula")[#text("Faá di Bruno formula")]#text("), we see that for any ")#mi("{j \\geq 0}")#text(", ")#mi("{D^j w}")#text(" is a linear combination of ")#mi("{O_j(1)}")#text(" terms of the form")

#align(center)[#tao-fit-display[#mitex("(D^{m_1} G) \\dots (D^{m_k} G) G^{\\frac{1}{2} - k}")]]

#text("where ")#mi("{m_1,\\dots,m_k \\geq 1}")#text(" sum up to ")#mi("{m}")#text(" (more precisely, each component of ")#mi("{D^m w}")#text(" is a linear combination of expressions of the above form in which one works with individual components of each factor ")#mi("{D^{m_i} G}")#text(" rather than the full tuple ")#mi("{D^{m_i} G}")#text("). From ")#link(<tao-b7d85587389c8e3ae15c>)[#text("(103)")]#text(" we thus have the pointwise estimate")

#align(center)[#tao-fit-display[#mitex("D^m w \\lesssim_{m} G^{1/2}")]]

#text("for any ")#mi("{m}")#text(", and ")#link(<tao-11412745e4a857b4295d>)[#text("(98)")]#text(" now follows from ")#link(<tao-9cf3886f2bbc9660b15a>)[#text("(102)")]#text(". A similar argument gives")

#align(center)[#tao-fit-display[#mitex("D^m(G^{-1}) \\lesssim_{m} G^{-1}")]]

#text("for any ")#mi("{m \\geq 0}")#text(", hence if we set ")#mi("{S := G^{-1} \\tilde R}")#text(", then by the product rule")

#align(center)[#tao-fit-display[#mitex("D^{\\leq 20M} S \\lesssim_{m} G^{-1} D^{\\leq 20M} \\tilde R")]]

#text("and ")#link(<tao-f2e0b62a0155903aae2b>)[#text("(99)")]#text(" now follows from ")#link(<tao-fae4cc860ae0bd31fb5e>)[#text("(104)")]#text(".")

#text("Strictly speaking we are not quite done because ")#mi("{w}")#text(" is not supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(", but if one applies a smooth cutoff function in time that equals ")#mi("{1}")#text(" on ")#mi("{I^{\\prime\\prime}}")#text(" (where ")#mi("{\\tilde R}")#text(" is supported in time) and vanishes outside of ")#mi("{I^{\\prime}}")#text(", we obtain the required support property without significantly affecting the estimates. ")#mi("\\Box")

#text("Let ")#mi("{\\tilde R = w^2 S}")#text(" be the factorisation given by the above lemma. If we set ")#mi("{q := -C w^2}")#text(" for a sufficiently large constant ")#mi("{C}")#text(" depending only on ")#mi("{s,\\varepsilon,M,d}")#text(", then")

#align(center)[#tao-fit-display[#mitex("-\\tilde R^{ij} - q \\eta^{ij} = w^2 ( C \\eta^{ij} - \\tilde S^{ij} ).")]]

#text("For ")#mi("{C}")#text(" large enough, we see from ")#link(<tao-f2e0b62a0155903aae2b>)[#text("(99)")]#text(" that the matrix with entries ")#mi("{C \\eta^{ij} - \\tilde S^{ij}}")#text(" takes values in a compact subset of positive definite ")#mi("{d \\times d}")#text(" matrices) that depends only on ")#mi("{s,\\varepsilon,M,d}")#text(". Applying Exercise ")#link(<tao-fd8348c37e3c2786327d>)[#text("27")]#text(", we conclude that there exist non-zero lattice vectors ")#mi("{e_1,\\dots,e_K \\in {\\bf Z}^d}")#text(" and smooth functions ")#mi("{b_1,\\dots,b_K: \\Omega \\rightarrow {\\bf R}}")#text(" for some ")#mi("{K \\geq 0}")#text(" (depending only on ")#mi("{s,\\varepsilon,M,d}")#text(") such that")

#align(center)[#tao-fit-display[#mitex("- \\tilde S^{ij}(t,x) + C \\eta^{ij} = \\sum_{k=1}^K b_k(t,x)^2 e_k^i e_k^j")]]

#text("for all ")#mi("{(t,x) \\in \\Omega}")#text(", and furthermore (from ")#link(<tao-f2e0b62a0155903aae2b>)[#text("(99)")]#text(" and the chain rule) we have the derivative estimates")

#align(center)[#tao-fit-display[#tao-math("\\left\\| (\\tilde N_0^{-1} \\nabla x, \\tilde N_0^{-\\varepsilon} \\partial_t)^{\\leq 2M} b_k \\right\\|_{L^\\infty_{t,x}} \\lesssim 1", block: true)]]

#text("for ")#mi("{k=1,\\dots,K}")#text(". Setting ")#mi("{a_k := w b_k}")#text(", we thus have")

#align(center)[#tao-fit-display[#mitex("-\\tilde R^{ij} + q \\eta^{ij} = \\sum_{k=1}^K a_k(t,x)^2 e_k^i e_k^j")]]

#text("and from the Leibniz rule and ")#link(<tao-11412745e4a857b4295d>)[#text("(98)")]#text(" we have")

#metadata(none) <tao-eea4815e42a77716e5a0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(105)")])
#tao-math("\\left\\| (\\tilde N_0^{-\\varepsilon} \\partial_t, \\tilde N_0^{-1} \\nabla x)^{\\leq 10M} a_k \\right\\|_{L^2_{t,x}} \\lesssim A N_0^{-5\\varepsilon^2} N_1^{-s^{\\prime}}", block: true)]]

#text("for ")#mi("{k=1,\\dots,K}")#text(".")

#text("Let ")#mi("{T_1,\\dots,T_k}")#text(" be the disjoint tubes in ")#mi("{\\mathbf{T}_F}")#text(" from the previous section, with width ")#mi("{N_1^{-\\varepsilon^2}}")#text(" rather than ")#mi("{N^{-\\varepsilon}}")#text(". Construct the functions ")#mi("{\\mathbf{\\psi}_k: \\mathbf{T}_F \\rightarrow {\\bf R}}")#text(" as in the previous section, and again set")

#align(center)[#tao-fit-display[#mitex("\\mathbf{w}_k^i(y) := \\Delta^M_y \\mathbf{\\psi}_k(y) e_k^i.")]]

#text("Then as before, each ")#mi("{\\mathbf{w}_k}")#text(" is divergence free, and obeys the identities ")#link(<tao-d6ba8bf227ba2c637c44>)[#text("(65)")]#text(", ")#link(<tao-733859c1fc6b9331793b>)[#text("(66)")]#text(" and the b ounds")

#align(center)[#tao-fit-display[#mitex("\\partial_{y^j}( \\mathbf{w}_k^i \\mathbf{w}_k^j ) = 0")]]

#text("and the normalisation")

#metadata(none) <tao-b751eaa93fb50d519289>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(106)")])
#mitex("\\int_{\\mathbf{T}_F} \\mathbf{w}_k^i \\mathbf{w}_k^j = e_k^i e_k^j")]]

#text("and")

#metadata(none) <tao-89acf1cf7ec8ee1a300f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(107)")])
#tao-math("\\left\\| (N_1^{-\\varepsilon^2} \\nabla_y)^m (N_1^{-2\\varepsilon^2} \\Delta_y)^{-m^{\\prime}} \\mathbf{w}^k \\right\\|_{L^2_y} \\lesssim_{U,m} 1", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(" and ")#mi("{0 \\leq m^{\\prime} \\leq M}")#text(". As in the preceding section, we then set")

#tao-aligned(keep: true)[


#tao-math("\\mathbf{v}^i(t,x,y)  & := \\sum_{k=1}^K a_k(t,x) \\mathbf{w}_k^i", block: true)



#tao-math("\\mathbf{F}^i(t,x,y)  & := \\partial_{x^j}( \\sum_{k=1}^K a_k(t,x)^2 (\\mathbf{w}_k^i(y) \\mathbf{w}_k^j(y) - e_k^i e_k^j) )", block: true)



#tao-math("\\mathbf{f}(t,x,y)  & := \\sum_{k=1}^K \\partial_{x^i} a_k(t,x) \\mathbf{w}_k^i(y)", block: true)
]

#text("and one easily checks that ")#mi("{(\\mathbf{v}, q, 0, \\mathbf{f}, \\mathbf{F})}")#text(" is a simplified fast-slow solution supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(". Direct calculation using the Leibniz rule and ")#link(<tao-eea4815e42a77716e5a0>)[#text("(105)")]#text(", ")#link(<tao-89acf1cf7ec8ee1a300f>)[#text("(107)")]#text(" then gives the bounds")

#metadata(none) <tao-2676c85ea3f5fba89875>

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\mathbf{D}^{\\leq 10M} \\mathbf{v} \\right\\|_{L^2_{t,x,y}}  & \\lesssim_{M} A N_0^{-5\\varepsilon^2} N_1^{-s^{\\prime}}", block: true, numbering: n => [#text("(108)")])



#tao-math("\\left\\| \\mathbf{D}^{\\leq 10M-1} \\mathbf{f} \\right\\|_{L^2_{t,x,y}}  & \\lesssim_{M} A \\tilde N_0 N_0^{-5\\varepsilon^2} N_1^{-s^{\\prime}}", block: true, numbering: n => [#text("(109)")])

#metadata(none) <tao-baa0eba15ba14f283f2a>

#tao-math("\\left\\| \\mathbf{D}^{\\leq 10M-1} \\mathbf{F} \\right\\|_{L^1_{t,x,y}}  & \\lesssim_{M} A^2 \\tilde N_0 N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}}.", block: true, numbering: n => [#text("(110)")])
]

#text("As before, ")#mi("{\\mathbf{F}}")#text(" is “high frequency” (mean zero in the ")#mi("{y}")#text(" variable). Also, ")#mi("{\\mathbf{v}}")#text(" is supported on the set ")#mi("{\\Omega \\times \\bigcup_{k=1}^K T^k}")#text(", and for ")#mi("{d}")#text(" large enough the latter set ")#mi("{\\bigcup_{k=1}^K T_k}")#text(" has measure (say) ")#mi("{O_{s,\\varepsilon,M,d,\\nu}(N_1^{-100})}")#text(". Thus by Cauchy-Schwarz (in just the ")#mi("{y}")#text(" variable) one has")

#metadata(none) <tao-7dd0165e33b8644ef747>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(111)")])
#tao-math("\\left\\| \\mathbf{D}^{\\leq 10M} \\mathbf{v} \\right\\|_{L^2_t L^2_x L^1_y} \\lesssim A N_1^{-30}.", block: true)]]

#text("The divergence corrector can be applied without difficulty:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 35")]#text(" Show that there is a simplified fast-slow solution ")#mi("{(\\mathbf{v}^{\\prime}, q, \\mathbf{R}, \\mathbf{f}^{\\prime}, \\mathbf{F})}")#text(" supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" obeying the estimates")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\mathbf{D}^{\\leq 5M} \\mathbf{v}^{\\prime} \\right\\|_{L^2_{t,x,y}}  & \\lesssim A N_0^{-5\\varepsilon^2} N_1^{-s^{\\prime}}", block: true)



#tao-math("\\left\\| \\mathbf{D}^{\\leq 5M} \\mathbf{v}^{\\prime} \\right\\|_{L^2_t L^2_x L^1_y}  & \\lesssim A N^{-30}", block: true)



#tao-math("\\left\\| \\mathbf{D}^{\\leq 5M} \\mathbf{f}^{\\prime} \\right\\|_{L^2_{t,x,y}}  & \\lesssim A N^{-30}", block: true)



#tao-math("\\left\\| \\mathbf{D}^{\\leq 5M} \\mathbf{R} \\right\\|_{L^1_{t,x,y}}  & \\lesssim A^2 \\tilde N_0 N_1^{-1} N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}}.", block: true)
]
]

#text("The crucial thing here is the tiny gain ")#mi("{\\tilde N_0 N_1^{-1}}")#text(" in the third estimate, with the first factor ")#mi("{\\tilde N_0}")#text(" coming from a “slow” derivative ")#mi("{\\nabla_x}")#text(" and the second factor ")#mi("{N_1^{-1}}")#text(" coming from essentially inverting a “fast” derivative ")#mi("{\\nabla_y}")#text(".")

#text("Finally, we apply a stress corrector:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Show that there is a simplified fast-slow solution ")#mi("{(\\mathbf{v}^{\\prime}, \\mathbf{q}, \\mathbf{R}^{\\prime}, \\mathbf{f}^{\\prime}, \\mathbf{F}^{\\prime})}")#text(" supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E \\times \\mathbf{T}_F}")#text(" obeying the estimates")

#tao-aligned(keep: true)[


#tao-math("\\left\\| \\mathbf{F} \\right\\|_{L^1_{t,x,y}}  & \\lesssim A^2 N^{-30}", block: true)



#tao-math("\\left\\| \\mathbf{D}^{\\leq M} \\mathbf{R}^{\\prime} \\right\\|_{L^1_{t,x,y}}  & \\lesssim A^2 \\tilde N_0 (N^{\\prime}_1)^{-1} N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}}.", block: true)
]
]

#text("Again, we have a crucial gain of ")#mi("{\\tilde N_0 (N^{\\prime}_1)^{-1}}")#text(" coming from applying a slow derivative and inverting a fast one.")

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\tilde N_0 (N^{\\prime}_1)^{-1} N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}} \\lesssim N_1^{-2s^{\\prime} - \\varepsilon + O( \\varepsilon^2 )}")]]

#text("(with implied constant in the exponent uniform in ")#mi("{\\varepsilon}")#text(") and ")#mi("{s^{\\prime} < s < 1/2}")#text(", we see (for ")#mi("{\\varepsilon}")#text(" small enough) that")

#align(center)[#tao-fit-display[#mitex("\\tilde N_0 (N^{\\prime}_1)^{-1} N_0^{-10\\varepsilon^2} N_1^{-2s^{\\prime}} \\leq N_1^{-2(1+\\varepsilon)s^{\\prime} - 11\\varepsilon^2}")]]

#text("and the desired estimates ")#link(<tao-cca69426221c643493f1>)[#text("(92)")]#text(", ")#link(<tao-26d6cc846199111e82b2>)[#text("(93)")]#text(", ")#link(<tao-193351b961747447b43d>)[#text("(95)")]#text(", ")#link(<tao-15478d02c349cc270fa7>)[#text("(96)")]#text(", ")#link(<tao-68acee85933f38109ca9>)[#text("(97)")]#text(" now follow.")

#heading(level: 1)[#strong[#text(" — 5. Constructing low regularity weak solutions to Euler — ")]]

#text("Throughout this section, we specialise to the Euler equations ")#mi("{\\nu=0}")#text(" in the three-dimensional case ")#mi("{d=3}")#text(" (although all of the arguments here also apply without much modification to ")#mi("{d>3}")#text(" as well). In this section we establish an analogue of Corollary ")#link(<tao-94d186f8b721736d4962>)[#text("28")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 37 (Low regularity non-trivial weak solutions)")]#text(" ")#metadata(none) <tao-3e93f99709baf5d28a71>#text(" There exists a periodic weak ")#mi("{C^0}")#text(" solution ")#mi("{u}")#text(" to Euler which equals zero at time ")#mi("{t=0}")#text(", but is not identically zero.")
]

#text("This result was first established ")#link("https://arxiv.org/abs/1202.1751")[#text("by de Lellis and Szekelyhidi")]#text(". Our approach will deviate from the one in that paper in a number of technical respects (for instance, we use Mikado flows in place of Beltrami flows, and we place more emphasis on the method of fast and slow variables). A key new feature, which was not present in the high-dimensional Sobolev-scale setting, is that the material derivative term ")#mi("{(\\partial_t + u_j \\partial_j) v_i}")#text(" in the difference Euler-Reynolds equations is no longer negligible, and needs to be treated by working with an ansatz in Lagrangian coordinates (or equivalently, an ansatz transported by the flow). (This use of Lagrangian coordinates is implicit in ")#link("https://arxiv.org/abs/1211.4065")[#text("the thesis of Isett")]#text(", ")#link("https://arxiv.org/abs/1603.09714")[#text("this paper of de Lellis and Szekelyhidi")]#text(", and in the ")#link("https://arxiv.org/abs/1608.08301")[#text("later work of Isett")]#text(".)")

#text("Just as Corollary ")#link(<tao-94d186f8b721736d4962>)[#text("28")]#text(" was derived from Proposition ")#link(<tao-b10b18f906fcd1ca8784>)[#text("26")]#text(", the above proposition may be derived from")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 38 (Weak improvement of Euler-Reynolds flows)")]#text(" ")#metadata(none) <tao-7220a42316020de1e8df>#text(" Let ")#mi("{U = (u,p,R)}")#text(" be an Euler-Reynolds flow supported on a strict compact subinterval ")#mi("{I \\subsetneq {\\bf R}/{\\bf Z}}")#text(". Let ")#mi("{I^{\\prime}}")#text(" be another interval in ")#mi("{{\\bf R}/{\\bf Z}}")#text(" containing ")#mi("{I}")#text(" in its interior. Then for sufficiently large ")#mi("{N}")#text(", there exists a Euler-Reynolds flow ")#mi("{\\tilde U = (\\tilde u, \\tilde p, \\tilde R)}")#text(" supported in ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(" obeying the estimates")

#metadata(none) <tao-6037d7290bf6de6ffa17>

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N^{-1} \\partial_t, N^{-1} \\nabla_x)^{\\leq m} \\tilde u \\right\\|_{C^0_{t,x}}  & \\lesssim_{U,m,I,I^{\\prime}} 1", block: true, numbering: n => [#text("(112)")])

#metadata(none) <tao-ed5ad332c10604371270>

#tao-math("\\left\\| \\tilde R \\right\\|_{C^0_{t,x}}  & \\lesssim_{U,I,I^{\\prime}} N^{-1}", block: true, numbering: n => [#text("(113)")])
]

#text("for all ")#mi("{m \\geq 0}")#text(", and such that")

#metadata(none) <tao-57e690d812331bcc8b33>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(114)")])
#tao-math("\\left\\|\\tilde u - u \\right\\|_{C^0_{t,x}} \\lesssim_{I,I^{\\prime}} \\left\\| R \\right\\|_{C^0_{t,x}}^{1/2};", block: true)]]

#text("also, we have a decomposition")

#metadata(none) <tao-58b14bfc14497a933ba7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(115)")])
#mitex("\\tilde u^i - u^i = E^i + \\partial_j (E^{\\prime})^{ij}")]]

#text("where ")#mi("{E^i, (E^{\\prime})^{ij}: \\Omega \\rightarrow {\\bf R}}")#text(" are smooth functions obeying the bounds")

#metadata(none) <tao-ab7383bd91358f8839ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(116)")])
#tao-math("\\left\\| E^i \\right\\|_{C^0_{t,x}}, \\left\\|(E^{\\prime})^{ij} \\right\\|_{C^0_{t,x}} \\lesssim_{U,I,I^{\\prime}} N^{-1}.", block: true)]]
]

#text("The point of the decomposition ")#link(<tao-58b14bfc14497a933ba7>)[#text("(115)")]#text(" is that it (together with the smallness bounds ")#link(<tao-ab7383bd91358f8839ce>)[#text("(116)")]#text(") asserts that the velocity correction ")#mi("{\\tilde u_i - u_i}")#text(" is mostly “high frequency” in nature, in that its low frequency components are small. Together with ")#link(<tao-6037d7290bf6de6ffa17>)[#text("(112)")]#text(", the bounds roughly speaking assert that it is only the frequency ")#mi("{\\sim N}")#text(" components of ")#mi("{\\tilde u_i - u_i}")#text(" that can be large in ")#mi("{C^0_{t,x}}")#text(" norm. Unlike the previous estimates, it will be important for our arguments that ")#mi("{u}")#text(" is supported in a strict subinterval ")#mi("{I}")#text(" of ")#mi("{{\\bf R}/{\\bf Z}}")#text(", because we will not be able to extend Lagrangian coordinates periodically around the circle. Actually the long-time instability of Lagrangian coordinates causes significant technical difficulties to overcome when one wants to construct solutions in higher regularity Hölder spaces ")#mi("{C^{0,\\alpha}}")#text(", and in particular for ")#mi("{\\alpha}")#text(" close to ")#mi("{1/3}")#text("; we discuss this in the next section.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 39")]#text(" Deduce Proposition ")#link(<tao-3e93f99709baf5d28a71>)[#text("37")]#text(" from Proposition ")#link(<tao-7220a42316020de1e8df>)[#text("38")]#text(". (The decomposition ")#link(<tao-ab7383bd91358f8839ce>)[#text("(116)")]#text(" is needed to keep ")#mi("{\\tilde u}")#text(" close to ")#mi("{u}")#text(" in a very weak topology – basically the ")#mi("{C^0_t C^{-1}_{x}}")#text(" topology – but one which is still sufficent to ensure that the limiting solution constructed is not identically zero.)")
]

#text("We now begin the proof of Proposition ")#link(<tao-7220a42316020de1e8df>)[#text("38")]#text(", repeating many of the steps used to prove Proposition ")#link(<tao-b10b18f906fcd1ca8784>)[#text("26")]#text(". As before we may assume that ")#mi("{R}")#text(" is non-zero, and that ")#mi("{U}")#text(" is supported in ")#mi("{I \\times \\mathbf{T}_E}")#text(". We can assume that ")#mi("{I^{\\prime}}")#text(" is also a strict subinterval of ")#mi("{{\\bf R}/{\\bf Z}}")#text(".")

#text("Assume ")#mi("{N}")#text(" is sufficiently large; by rounding we may assume that ")#mi("{N}")#text(" is a natural number. Using the ansatz")

#align(center)[#tao-fit-display[#mitex("(\\tilde u, \\tilde p, \\tilde R) = (u + v, p + q, \\tilde R),")]]

#text("and the triangle inequality, it suffices to construct a difference Euler-Reynolds flow ")#mi("{(v, q, \\tilde R)}")#text(" at ")#mi("{U}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(" and obeying the bounds")

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N^{-1} \\partial_t, N^{-1} \\nabla)^{\\leq k} v \\right\\|_{C^0_{t,x}}  & \\lesssim_{U,k} 1", block: true)



#tao-math("\\left\\| \\tilde R \\right\\|_{C^0_{t,x}}  & \\lesssim_{U} N^{-1}", block: true)



#tao-math("\\left\\| v \\right\\|_{C^0_{t,x}}  & \\lesssim \\left\\| R \\right\\|_{C^0_{t,x}}^{1/2}", block: true)
]

#text("for all ")#mi("{k \\geq 0}")#text(", and for which we have a decomposition ")#mi("{v_i = E_i + \\partial_j E^{\\prime}_{ij}}")#text(" obeying ")#link(<tao-ab7383bd91358f8839ce>)[#text("(116)")]#text(".")

#text("As before, we permit ourselves some error:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" Show that it suffices to construct an ")#emph[#text("approximate")]#text(" difference Euler-Reynolds flow ")#mi("{(v, q, \\tilde R, f, F)}")#text(" at ")#mi("{U}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_E}")#text(" and obeying the bounds")

#metadata(none) <tao-51d014eb6bdd1ced5cc5>

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N^{-1} \\partial_t, N^{-1} \\nabla_x)^{\\leq m} v \\right\\|_{C^0_{t,x}}  & \\lesssim_{U,m} 1", block: true, numbering: n => [#text("(117)")])

#metadata(none) <tao-efcd16c1b6ac78f967c5>

#tao-math("\\left\\| \\tilde R\\right\\|_{C^0_{t,x}}  & \\lesssim_{U} N^{-1}", block: true, numbering: n => [#text("(118)")])

#metadata(none) <tao-afb8387f48e8b9f1464d>

#tao-math("\\left\\| (N^{-1} \\partial_t, N^{-1} \\nabla_x)^{\\leq m} f \\right\\|_{C^0_{t,x}}  & \\lesssim_{U} N^{-20}", block: true, numbering: n => [#text("(119)")])

#metadata(none) <tao-17ff1aa096cbc5d4e912>

#tao-math("\\left\\| F \\right\\|_{C^0_{t,x}}  & \\lesssim_{U} N^{-20}", block: true, numbering: n => [#text("(120)")])

#metadata(none) <tao-714e45899572707fc9b4>

#tao-math("\\left\\| v \\right\\|_{C^0_{t,x}}  & \\lesssim \\left\\| R \\right\\|_{C^0_{t,x}}^{1/2}", block: true, numbering: n => [#text("(121)")])
]

#text("for ")#mi("{m \\geq 0}")#text(", and for which we have a decomposition ")#mi("{v^i = E^i + \\partial_j (E^{\\prime})^{ij}}")#text(" obeying ")#link(<tao-ab7383bd91358f8839ce>)[#text("(116)")]#text(".")
]

#text("It still remains to construct the approximate difference Euler-Reynolds flow obeying the claimed estimates. By definition, ")#mi("{(v,q,\\tilde R, f, F)}")#text(" has to obey the system of equations ")#metadata(none) <tao-349942338a02fc592b43>#mi("\\displaystyle  \\partial_t v^i + \\partial_j( u^i v^j + u^j v^i + v^i v^j + R^{ij} + q \\eta^{ij} - \\tilde R^{ij} ) = F^i \\ \\ \\ \\ \\ (122)")#text(" ")#text(" ")#metadata(none) <tao-3f98114b0f77b7da78bc>#mi("\\displaystyle  \\partial_i v^i = f \\ \\ \\ \\ \\ (123)")#text(" ")#text(" ")#metadata(none) <tao-f159eaad90239a3a0ce8>#mi("\\displaystyle  \\tilde R^{ij} = \\tilde R^{ji} \\ \\ \\ \\ \\ (124)")#text(" ")#text(" with a decomposition ")#metadata(none) <tao-18ddf9044af20798fa01>#mi("\\displaystyle  v^i = E^i + \\partial_j (E^{\\prime})^{ij}. \\ \\ \\ \\ \\ (125)")#text(" ")#text(" As ")#mi("{u}")#text(" is divergence-free, the first equation ")#link(<tao-349942338a02fc592b43>)[#text("(122)")]#text(" may be rewritten as ")#metadata(none) <tao-8a7bc6881f93f93ddf1a>#mi("\\displaystyle  {\\mathcal D}_t v^i + u^i f + 2 v^j \\partial_j u^i + \\partial_j( v^i v^j + R^{ij} + q \\eta^{ij} - \\tilde R^{ij} ) = F^i \\ \\ \\ \\ \\ (126)")#text(" ")#text(" where ")#mi("{{\\mathcal D}_t v}")#text(" is the material Lie derivative of ")#mi("{v}")#text(", thus ")#metadata(none) <tao-0373eb1fac105affaa9c>#mi("\\displaystyle  {\\mathcal D}_t v^i := \\partial_t v^i + {\\mathcal L}_u v^i = \\partial_t v^i + u^j \\partial_j v^i - v^j \\partial_j u^i. \\ \\ \\ \\ \\ (127)")#text(" ")#text(" The lower order terms ")#mi("{u_i f + 2 v_j \\partial_j u_i}")#text(" in ")#link(<tao-8a7bc6881f93f93ddf1a>)[#text("(126)")]#text(" will turn out to be rather harmless; the main new difficulty is dealing with the material Lie derivative term ")#mi("{{\\mathcal D}_t v_i}")#text(". We will therefore invoke Lagrangian coordinates in order to convert the material Lie derivative ")#mi("{{\\mathcal D}_t}")#text(" into the more tractable time derivative ")#mi("{\\partial_t}")#text(" (at the cost of mildly complicating all the other terms in the system).")

#text("We introduce a “Lagrangian torus” ")#mi("{{\\mathbf T}_L := ({\\bf R}/{\\bf Z})^d}")#text(" that is an isomorphic copy of the Eulerian torus ")#mi("{{\\mathbf T}_E}")#text("; as in the previous section, we parameterise this torus by ")#mi("{a = (a^\\alpha)_{\\alpha=1,\\dots,d}}")#text(", and adopt the usual summation conventions for the indices ")#mi("{\\alpha,\\beta,\\gamma}")#text(". Let ")#mi("{X: I^{\\prime} \\times {\\mathbf T}_L \\rightarrow {\\mathbf T}_E}")#text(" be a trajectory map for ")#mi("{u}")#text(", that is to say a smooth map such that for every time ")#mi("{t \\in I^{\\prime}}")#text(", the map ")#mi("{X(t): {\\mathbf T}_L \\rightarrow {\\mathbf T}_E}")#text(" is a diffeomorphism and one obeys the ODE")

#align(center)[#tao-fit-display[#mitex("\\partial_t X(t,a) = u(t,X(t,a))")]]

#text("for all ")#mi("{(t,a) \\in I^{\\prime} \\times {\\mathbf T}}")#text(". The existence of such a trajectory map is guaranteed by the Picard existence theorem (it is important here that ")#mi("{I^{\\prime}}")#text(" is not all of the torus ")#mi("{{\\bf R}/{\\bf Z}}")#text("); see also Exercise 1 from ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(". From (the periodic version of) Lemma 3 of ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(", we can ensure that the map ")#mi("{X}")#text(" is volume-preserving, thus")

#align(center)[#tao-fit-display[#mitex("\\det(\\nabla X) = 1.")]]

#text("Recall from ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(" that")

#list(
[#text("(i) Any Eulerian scalar field ")#mi("{f}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_E}")#text(" can be pulled back to a Lagrangian scalar field ")#mi("{X^* f}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_L}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("X^* f(t, a) := f(t, X(t,a));")]]],
[#text("(ii) Any Eulerian vector field ")#mi("{v^i}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_E}")#text(" can be pulled back to a Lagrangian vector field ")#mi("{(X^* v)^\\alpha}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_L}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(X^* v)^\\alpha(t, a) := (\\nabla X(t,a)^{-1})^\\alpha_i v^i(t, X(t,a))")]]

#text("where ")#mi("{\\nabla X(t,a)^{-1} = ((\\nabla X(t,a)^{-1})^\\alpha_i)_{i,\\alpha=1,\\dots,d}}")#text(" is the inverse of the matrix ")#mi("{\\nabla X(t,a) = (\\nabla X(t,a)^i_\\alpha)_{i,\\alpha=1,\\dots,d}}")#text(", defined by")

#align(center)[#tao-fit-display[#mitex("\\nabla X(t,a)^i_\\alpha := \\partial_\\alpha X^i(t,a);")]]

#text("and")],
[#text("(iii) Any Eulerian rank ")#mi("{(2,0)}")#text(" tensor ")#mi("{T^{ij}}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_E}")#text(", can be pulled back to a Lagrangian rank ")#mi("{2}")#text(" tensor ")#mi("{(X^* T)^{\\alpha \\beta}}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_L}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("(X^* T)^{\\alpha \\beta}(t, a) := (\\nabla X(t,a)^{-1})^\\alpha_i (\\nabla X(t,a)^{-1})^\\beta_j T^{ij}(t, X(t,a)).")]]]
)

#text("(One can pull back other tensors also, but these are the only ones we will need here.) Each of these pullback operations may be inverted by the corresponding pullback operation for the labels map ")#mi("{X^{-1}: (t,X(t,a)) \\mapsto (t,a)}")#text(" (also known as ")#emph[#text("pushforward")]#text(" by ")#mi("{X}")#text("). One can compute how these pullbacks interact with divergences:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41 (Pullback and divergence)")]

#list(
[#text("(i) If ")#mi("{v^i}")#text(" is a smooth Eulerian vector field, show that the pullback of the divergence of ")#mi("{v}")#text(" equals the divergence of the pullback of ")#mi("{v}")#text(":")

#align(center)[#tao-fit-display[#mitex("X^* (\\partial_i v^i) = \\partial_\\alpha (X^* v)^\\alpha.")]]

#text("(")#emph[#text("Hint:")]#text(" you will need to use the fact that ")#mi("{X}")#text(" is volume-preserving. Similarly to Lemma 3 and Exercise 4 of ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(", one can establish this either using the laws of integration or the laws of differentiation.).")],
[#text("(ii) Show that there exist smooth functions ")#mi("{\\Gamma^\\alpha_{\\beta \\gamma}: I^{\\prime} \\times {\\mathbf T}_L \\rightarrow {\\bf R}}")#text(" for ")#mi("{\\alpha,\\beta,\\gamma =1,\\dots,d}")#text(" with the following property: for any smooth Eulerian rank ")#mi("{2}")#text(" tensor ")#mi("{T^{ij}}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_E}")#text(", with divergence ")#mi("{Y^i := \\partial_j T^{ij}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("(X^* Y)^\\alpha = \\partial_\\beta (X^* T)^{\\alpha \\beta} + \\Gamma^\\alpha_{\\beta \\gamma} (X^* T)^{\\gamma \\beta}.")]]

#text("(In fact, ")#mi("{\\Gamma^\\alpha_{\\beta \\gamma}}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Christoffel_symbol")[#text("Christoffel symbol")]#text(" ")#mi("{\\Gamma^\\alpha_{\\beta \\gamma}}")#text(" associated with the pullback ")#mi("{X^* \\eta}")#text(" of the Euclidean metric – but we will not need this precise formula. The right-hand side may also be written (in ")#link("https://en.wikipedia.org/wiki/Abstract_index_notation")[#text("Penrose abstract index notation")]#text(") as ")#mi("{\\nabla_\\alpha (X^* T)^{\\alpha \\beta}}")#text(", where ")#mi("{\\nabla_\\alpha}")#text(" is the ")#link("https://en.wikipedia.org/wiki/Covariant_derivative")[#text("covariant derivative")]#text(" associated to ")#mi("{X^* \\eta}")#text(".)")],
[#text("(iii) Show that for any smooth Eulerian vector fields ")#mi("{u^i, v^i}")#text(" on ")#mi("{I^{\\prime} \\times {\\mathbf T}_E}")#text(" with ")#mi("{w^i = v^j \\partial_j u^i}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("(X^* w)^\\alpha = (X^* v)^\\beta \\partial_\\beta (X^* u)^\\alpha + (X^* v)^\\beta \\Gamma^{\\alpha}_{\\beta \\gamma} (X^* u)^\\gamma.")]]

#text("(Hint: use (i), (ii), and the Leibniz rule.)")]
)
]

#text("As remarked upon in the exercise, these calculations can be streamlined using the theory of the covariant derivative in Riemannian geometry; we will not develop this theory further here, but see for instance ")#link("https://terrytao.wordpress.com/2008/03/26/285g-lecture-0-riemannian-manifolds-and-curvature/")[#text("these two")]#text(" ")#link("https://terrytao.wordpress.com/2008/03/28/285g-lecture-1-ricci-flow/")[#text("blog posts")]#text(".")

#text("If one now applies the pullback operation ")#mi("{X^*}")#text(" to the system ")#link(<tao-8a7bc6881f93f93ddf1a>)[#text("(126)")]#text(", ")#link(<tao-3f98114b0f77b7da78bc>)[#text("(123)")]#text(", ")#link(<tao-f159eaad90239a3a0ce8>)[#text("(124)")]#text(", ")#link(<tao-18ddf9044af20798fa01>)[#text("(125)")]#text(" (and uses Exercise 16 from ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(" to convert the material Lie derivative into the ordinary time derivative) one obtain the equivalent system")

#align(center)[#tao-fit-display[#mitex("\\partial_t (X^* v)^\\alpha + (X^* u)^\\alpha (X^* f) + 2 (X^* v)^\\beta \\partial_\\beta (X^* u)^\\alpha + 2 (X^* v)^\\beta \\Gamma^\\alpha_{\\beta \\gamma} (X^* u)^\\gamma + \\partial_\\beta \\underline{T}^{\\alpha \\beta} + \\Gamma^\\alpha_{\\beta \\gamma} \\underline{T}^{\\gamma \\beta}")]]

#tao-aligned(keep: true)[


#tao-math(" & = (X^* F)^\\alpha", block: true)



#tao-math("\\partial_\\alpha (X^* v)^\\alpha  & = X^* f", block: true)



#tao-math("(X^* \\tilde R)^{\\alpha \\beta}  & = (X^* \\tilde R)^{\\beta \\alpha}", block: true)



#tao-math("(X^* v)^\\alpha  & = (X^* E)^\\alpha + \\partial_\\beta (X^* E^{\\prime})^{\\alpha \\beta} + \\Gamma^\\alpha_{\\beta \\gamma} (X^* E^{\\prime})^{\\gamma \\beta}", block: true)
]

#text("where ")#mi("{\\underline{T}}")#text(" denotes the rank ")#mi("{(2,0)}")#text(" tensor")

#align(center)[#tao-fit-display[#mitex("\\underline{T}^{\\alpha \\beta} := (X^* v)^\\alpha (X^* v)^\\beta + (X^* R)^{\\alpha \\beta} + (X^* q) (X^* \\eta)^{\\alpha \\beta} - (X^* \\tilde R)^{\\alpha \\beta} .")]]

#text("Thus, if one introduces the Lagrangian fields")

#tao-aligned(keep: true)[


#tao-math("\\underline{v}  & := X^* v; \\quad \\underline{u} := X^* u; \\quad \\underline{F} := X^* F; \\quad \\underline{f} := X^* f;", block: true)



#tao-math("\\underline{\\tilde R}  & := X^* \\tilde R; \\quad \\underline{q} := X^* q; \\quad \\underline{\\eta} := X^* \\eta; \\underline{E^{\\prime}} := X^* E^{\\prime}", block: true)
]

#text("and also")

#align(center)[#tao-fit-display[#mitex("\\underline{E} := (X^* E)^\\alpha + \\Gamma^\\alpha_{\\beta \\gamma} (X^* E^{\\prime})^{\\gamma \\beta}")]]

#text("then (from many applications of the chain rule) we see that our task has now transformed to that of obtaining a ")#mi("{(\\underline{v},\\underline{q},\\underline{\\tilde R}, \\underline{f}, \\underline{F})}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_L}")#text(" obeying the equations")

#metadata(none) <tao-db7fdcbe47c2f8ed78e9>

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\underline{v}^\\alpha + \\underline{u}^\\alpha \\underline{f} + 2 \\underline{v}^\\beta \\partial_\\beta \\underline{u}^\\alpha + 2 \\underline{v}^\\beta \\Gamma^\\alpha_{\\beta \\gamma} \\underline{u}^\\gamma + \\partial_\\beta \\underline{T}^{\\alpha \\beta} + \\Gamma^\\alpha_{\\beta \\gamma} \\underline{T}^{\\gamma \\beta}) & = \\underline{F}^\\alpha", block: true, numbering: n => [#text("(128)")])

#metadata(none) <tao-89cd3481277fbd72f9ba>

#tao-math("\\partial_\\alpha \\underline{v}^\\alpha  & = \\underline{f}", block: true, numbering: n => [#text("(129)")])

#metadata(none) <tao-9faa979f7203d5a1d0b7>

#tao-math("\\underline{\\tilde R}^{\\alpha \\beta}  & = \\underline{\\tilde R}^{\\beta \\alpha}", block: true, numbering: n => [#text("(130)")])

#metadata(none) <tao-09195e381c355e309c22>

#tao-math("\\underline{v}^\\alpha  & = \\underline{E}^\\alpha + \\partial_\\beta \\underline{E^{\\prime}}^{\\alpha \\beta}", block: true, numbering: n => [#text("(131)")])
]

#text("where ")#mi("{\\underline{T}}")#text(" denotes the rank ")#mi("{(2,0)}")#text(" tensor")

#metadata(none) <tao-a1b4d1afa2c4b02a2288>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(132)")])
#mitex("\\underline{T}^{\\alpha \\beta} := \\underline{v}^\\alpha \\underline{v}^\\beta + \\underline{R}^{\\alpha \\beta} + \\underline{q} \\underline{\\eta}^{\\alpha \\beta} - \\underline{\\tilde R}^{\\alpha \\beta}")]]

#text("and obeying the estimates")

#metadata(none) <tao-091a89c741ae08a1f916>

#tao-aligned(keep: true)[


#tao-math("\\left\\| (N^{-1} \\partial_t, N^{-1} \\nabla_a)^{\\leq m} \\underline{v} \\right\\|_{C^0_{t,a}}  & \\lesssim_{U,m} 1", block: true, numbering: n => [#text("(133)")])

#metadata(none) <tao-01f29a19aa7ce18d9f4e>

#tao-math("\\left\\| \\underline{\\tilde R}\\right\\|_{C^0_{t,a}}  & \\lesssim_{U} N^{-1}", block: true, numbering: n => [#text("(134)")])

#metadata(none) <tao-9ad03c4a5f169dfe384d>

#tao-math("\\left\\| (N^{-1} \\partial_t, N^{-1} \\nabla_a)^{\\leq m} \\underline{f} \\right\\|_{C^0_{t,a}}  & \\lesssim_{U,m} N^{-20}", block: true, numbering: n => [#text("(135)")])

#metadata(none) <tao-d691af07ff4d2f70723a>

#tao-math("\\left\\| \\underline{F} \\right\\|_{C^0_{t,a}}  & \\lesssim_{U} N^{-20}", block: true, numbering: n => [#text("(136)")])



#tao-math("\\left\\| X_* \\underline{v} \\right\\|_{C^0_{t,x}}  & \\lesssim \\left\\| R \\right\\|_{C^0_{t,x}}^{1/2}", block: true, numbering: n => [#text("(137)")])

#metadata(none) <tao-cfffdd92e70b9c43f70c>

#tao-math("\\left\\| E \\right\\|_{C^0_{t,a}}, \\left\\|E^{\\prime} \\right\\|_{C^0_{t,a}}  & \\lesssim_{U} N^{-1}", block: true, numbering: n => [#text("(138)")])
]

#text("for ")#mi("{m \\geq 0}")#text(", where ")#mi("{C^0_{t,a}}")#text(" denotes the supremum on the Lagrangian spacetime ")#mi("{I^{\\prime} \\times \\mathbf{T}_L}")#text(". (In ")#link(<tao-714e45899572707fc9b4>)[#text("(137)")]#text(" we have to move back to Eulerian coordinates because the coefficients in the pushforward ")#mi("{X_*}")#text(" depend on ")#mi("{U}")#text(", and we want an estimate here uniform in ")#mi("{U}")#text(".)")

#text("This problem looks complicated, but the net effect of moving to the Lagrangian formulation is to arrive at a problem that is nearly identical to the Eulerian one, but in which the material Lie derivative ")#mi("{{\\mathcal D}_t}")#text(" has been replaced by the ordinary time derivative ")#mi("{\\partial_t}")#text(", and several lower order terms with smooth variable coefficients have been added to the system.")

#text("Now that the dangerous transport term in the material Lie derivative has been eliminated, it is now safe to use the method of fast-slow variables, but now on the Lagrangian torus ")#mi("{\\mathbf{T}_L}")#text(" rather than the Eulerian torus ")#mi("{\\mathbf{T}_E}")#text(". We now parameterise the fast torus ")#mi("{\\mathbf{T}_F}")#text(" by ")#mi("{b = (b^\\alpha)_{\\alpha=1,\\dots,d}}")#text(" (thus we think of ")#mi("{\\mathbf{T}_F}")#text(" now as a “Lagrangian fast torus” rather than a “Eulerian fast torus”) and use the ansatz")

#tao-aligned(keep: false)[


#tao-math("\\underline{v}(t,a)  & := \\mathbf{v}( t, a, N a \\text{ mod } 1)", block: true)



#tao-math("\\underline{q}(t,a)  & := \\mathbf{q}( t, a, N a \\text{ mod } 1)", block: true)



#tao-math("\\underline{R}(t,a)  & := \\mathbf{R}( t, a, N a \\text{ mod } 1)", block: true)



#tao-math("\\underline{f}(t,a)  & := \\mathbf{f}( t, a, N a \\text{ mod } 1)", block: true)



#tao-math("\\underline{F}(t,a)  & := \\mathbf{F}( t, a, N a \\text{ mod } 1)", block: true)



#tao-math("\\underline{E}(t,a)  & := \\mathbf{E}( t, a, N a \\text{ mod } 1)", block: true)



#tao-math("\\underline{E^{\\prime}}(t,a)  & := \\mathbf{E}^{\\prime}( t, a, N a \\text{ mod } 1)", block: true)
]

#text("so that the equations of motion now become")

#metadata(none) <tao-9bbf7e7a9e39a9fd0cfb>

#tao-aligned(keep: true)[


#tao-math("\\partial_t \\mathbf{v}^\\alpha + \\underline{u}^\\alpha \\mathbf{f} + 2 \\mathbf{v}^\\beta \\partial_{a^\\beta} \\underline{u}^\\alpha + 2 \\mathbf{v}^\\beta \\Gamma^\\alpha_{\\beta \\gamma} \\underline{u}^\\gamma + (\\partial_{a^\\beta} + N \\partial_{b^\\beta}) \\mathbf{T}^{\\alpha \\beta} + \\Gamma^\\alpha_{\\beta \\gamma} \\mathbf{T}^{\\gamma \\beta}  & = \\mathbf{F}^\\alpha", block: true, numbering: n => [#text("(139)")])

#metadata(none) <tao-808fc2f6d7458a65e421>

#tao-math("(\\partial_{a^\\alpha} + N \\partial_{b^\\alpha}) \\mathbf{v}^\\alpha  & = \\mathbf{f}", block: true, numbering: n => [#text("(140)")])

#metadata(none) <tao-240f9335b7b25fc12cd4>

#tao-math("\\mathbf{R}^{\\alpha \\beta}  & = \\mathbf{R}^{\\beta \\alpha}", block: true, numbering: n => [#text("(141)")])

#metadata(none) <tao-a635eb512a3101f31586>

#tao-math("\\mathbf{v}^\\alpha  & = \\mathbf{E}^\\alpha + (\\partial_{a^\\beta}+N\\partial_{b^\\beta}) \\mathbf{E^{\\prime}}^{\\alpha \\beta}", block: true, numbering: n => [#text("(142)")])
]

#text("where")

#metadata(none) <tao-f8608d6d8597bf47bb21>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(143)")])
#mitex("\\mathbf{T}^{\\alpha \\beta} := \\mathbf{v}^\\alpha \\mathbf{v}^\\beta + \\underline{R}^{\\alpha \\beta} + \\mathbf{q} \\underline{\\eta}^{\\alpha \\beta} - \\mathbf{R}^{\\alpha \\beta}")]]

#text("where we think of ")#mi("{\\underline{u}, \\Gamma, \\underline{\\eta}}")#text(" as “low frequency” functions of time ")#mi("{t}")#text(" and the slow Lagrangian variable ")#mi("{a}")#text(" only (thus they are independent of the fast Lagrangian variable ")#mi("{b}")#text("). Set")

#align(center)[#tao-fit-display[#mitex("D := (N^{-1} \\partial_t, N^{-1} \\nabla_a, \\nabla_b).")]]

#text("It will now suffice to find a smooth solution ")#mi("{(\\mathbf{v}, \\mathbf{q}, \\mathbf{R}, \\mathbf{f}, \\mathbf{F}, \\mathbf{E}, \\mathbf{E^{\\prime}})}")#text(" to the above system supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_L \\times \\mathbf{T}_F}")#text(" obeying the estimates")

#metadata(none) <tao-c7666a5062d373dce890>

#tao-aligned(keep: true)[


#tao-math("\\left\\| D^{\\leq m} \\mathbf{v} \\right\\|_{C^0_{t,a,b}}  & \\lesssim_{U,m} 1", block: true, numbering: n => [#text("(144)")])

#metadata(none) <tao-71c433a6032290359b95>

#tao-math("\\left\\| \\mathbf{R} \\right\\|_{C^0_{t,a,b}}  & \\lesssim_{U} N^{-1}", block: true, numbering: n => [#text("(145)")])

#metadata(none) <tao-ce20c1f5ace6dd0b6b55>

#tao-math("\\left\\| D^{\\leq m} \\mathbf{f} \\right\\|_{C^0_{t,a,b}}  & \\lesssim_{U,m} N^{-20}", block: true, numbering: n => [#text("(146)")])

#metadata(none) <tao-6831961fbfb10ac1211c>

#tao-math("\\left\\| \\mathbf{F} \\right\\|_{C^0_{t,a,b}}  & \\lesssim_{U} N^{-20}", block: true, numbering: n => [#text("(147)")])

#metadata(none) <tao-4956681c31ffad3a5377>

#tao-math("\\left\\| \\mathbf{E} \\right\\|_{C^0_{t,a,b}}, \\left\\|\\mathbf{E^{\\prime}} \\right\\|_{C^0_{t,a}}  & \\lesssim_{U} N^{-1}", block: true, numbering: n => [#text("(148)")])
]

#text("and obeying the pointwise estimate")

#metadata(none) <tao-992ba71bb1ffe9a06e08>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(149)")])
#tao-math("\\partial_\\alpha X^i(t,a) \\mathbf{v}^\\alpha(t,a,b) = O( \\left\\| R \\right\\|_{C^0_{t,x}}^{1/2} )", block: true)]]

#text("for ")#mi("{(t,a,b) \\in I^{\\prime} \\times \\mathbf{T}_L \\times \\mathbf{T}_F}")#text(".")

#text("If ")#mi("{\\mathbf{v}}")#text(" is chosen to be “high frequency” (mean zero in the fast variable ")#mi("{b}")#text("), then we can automatically obtain the estimate ")#link(<tao-4956681c31ffad3a5377>)[#text("(148)")]#text(", as one may obtain the decomposition ")#link(<tao-a635eb512a3101f31586>)[#text("(142)")]#text(" with")

#align(center)[#tao-fit-display[#mitex("\\mathbf{E^{\\prime}}^{\\alpha \\beta} := N^{-1} \\eta^{\\beta \\gamma} \\Delta_b^{-1} \\partial_{b^\\gamma} \\mathbf{v}^\\alpha")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\mathbf{E}^\\alpha := - \\partial_{a^\\beta} (\\mathbf{E^{\\prime}})^{\\alpha \\beta}")]]

#text("at which point the estimates ")#link(<tao-4956681c31ffad3a5377>)[#text("(148)")]#text(" follow from ")#link(<tao-c7666a5062d373dce890>)[#text("(144)")]#text(". Thus we may drop ")#link(<tao-4956681c31ffad3a5377>)[#text("(148)")]#text(" and ")#link(<tao-a635eb512a3101f31586>)[#text("(142)")]#text(" from our requirements as long as we instead require ")#mi("{\\mathbf{v}}")#text(" to be high frequency.")

#text("As in previous sections, we can relax the conditions on ")#mi("{\\mathbf{f}}")#text(" and ")#mi("{\\mathbf{F}}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42")]

#list(
[#text("(i) (Stress corrector) Show that we may replace the condition ")#link(<tao-6831961fbfb10ac1211c>)[#text("(147)")]#text(" with the condition that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{\\leq m} \\mathbf{F} \\right\\|_{C^0_{t,a,b}} \\lesssim_{U,m} 1", block: true)]]

#text("for all ")#mi("{m \\geq 0}")#text(", and that ")#mi("{\\mathbf{F}}")#text(" is of high frequency (mean zero in ")#mi("{b}")#text("). (")#emph[#text("Hint:")]#text(" add a corrector of size ")#mi("{O_U(N^{-1})}")#text(" to ")#mi("{\\mathbf{R}}")#text(", ")#mi("{\\mathbf{q}}")#text(" so that the main term ")#mi("{N \\partial_{b^\\beta} ( \\mathbf{q} \\underline{\\eta}^{\\alpha \\beta} - \\mathbf{R}^{\\alpha \\beta} )}")#text(" now cancels off ")#mi("{\\mathbf{F}}")#text(", and the other terms created by the correction are of size ")#mi("{O_U(N^{-1})}")#text(" and of mean zero in ")#mi("{y}")#text(". Then iterate.)")],
[#text("(ii) (Divergence corrector) After performing the modifications in (i), show that we may replace the condition ")#link(<tao-ce20c1f5ace6dd0b6b55>)[#text("(146)")]#text(" with the condition that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{\\leq m} \\mathbf{f} \\right\\|_{C^0_{t,a,b}} \\lesssim_{U,m} 1", block: true)]]

#text("for all ")#mi("{m}")#text(", and that ")#mi("{\\mathbf{f}}")#text(" has mean zero in ")#mi("{b}")#text(". (Note that correcting for ")#mi("{\\mathbf{f}}")#text(" will modify ")#mi("{\\mathbf{v}}")#text(" by ")#mi("{O_U(N^{-1})}")#text(", but this will make a negligible contribution to ")#link(<tao-992ba71bb1ffe9a06e08>)[#text("(149)")]#text(" for ")#mi("{N}")#text(" large enough.)")]
)
]

#text("We can now repeat the Mikado flow construction from previous sections:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 43")]#text(" ")#metadata(none) <tao-490ae03e180a3b4eef1e>#text(" Set ")#tao-math("{\\mathbf{q} := -100 \\left\\| R \\right\\|_{C^0_{t,x}}}", block: false)#text(". Construct a smooth vector field ")#mi("{\\mathbf{v}}")#text(" supported on ")#mi("{I^{\\prime} \\times \\mathbf{T}_L \\times \\mathbf{T}_F}")#text(", with ")#mi("{\\mathbf{v}}")#text(" of mean zero in ")#mi("{b}")#text(", obeying the equations")

#tao-aligned(keep: true)[


#tao-math("\\partial_{b^\\beta} (\\mathbf{v}^\\alpha \\mathbf{v}^\\beta)  & = 0", block: true)



#tao-math("\\partial_{b^\\beta} \\mathbf{v}^\\beta  & = 0", block: true)
]

#text("and such that")

#align(center)[#tao-fit-display[#mitex("\\mathbf{v}^\\alpha \\mathbf{v}^\\beta + \\underline{R}^{\\alpha \\beta} + \\mathbf{q} \\underline{\\eta}^{\\alpha \\beta}")]]

#text("is of mean zero in ")#mi("{b}")#text(", obeying the bounds ")#link(<tao-c7666a5062d373dce890>)[#text("(144)")]#text(" for all ")#mi("{m \\geq 0}")#text(". Also show that for a sufficiently large absolute constant ")#mi("{C= O(1)}")#text(" not depending on ")#mi("{U}")#text(", one can ensure that the matrix with entries")

#metadata(none) <tao-34a389d790fc2bdd8458>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(150)")])
#mitex("-C (\\underline{R}^{\\alpha \\beta} + \\mathbf{q} \\underline{\\eta}^{\\alpha \\beta}) - \\mathbf{v}^\\alpha \\mathbf{v}^\\beta")]]

#text("is positive semi-definite at every point ")#mi("{(t,a,b) \\in I^{\\prime} \\times \\mathbf{T}_L \\times \\mathbf{T}_F}")#text(". (Hint: You will need to apply Lemma ")#link(<tao-18797a12ad504b11e9a0>)[#text("34")]#text(" in order to place a certain positive definite matrix in a compact set independent of ")#mi("{U}")#text(", so that the number ")#mi("{K}")#text(" of rank one pieces produced by Exercise ")#link(<tao-fd8348c37e3c2786327d>)[#text("27")]#text(" is also independent of ")#mi("{U}")#text(".)")
]

#text("If we now set")

#tao-aligned(keep: true)[


#tao-math("\\mathbf{R}^{\\alpha \\beta}  & := 0", block: true)



#tao-math("\\mathbf{F}^\\alpha  & := \\partial_t \\mathbf{v}^\\alpha + \\underline{u}^\\alpha \\mathbf{f} + 2 \\mathbf{v}^\\beta \\partial_{a^\\beta} \\underline{u}^\\alpha + 2 \\mathbf{v}^\\beta \\Gamma^\\alpha_{\\beta \\gamma} \\underline{u}^\\gamma + \\partial_{a^\\beta}\\mathbf{T}^{\\alpha \\beta} + \\Gamma^\\alpha_{\\beta \\gamma} \\mathbf{T}^{\\gamma \\beta}", block: true)



#tao-math("\\mathbf{f}  & := \\partial_{a^\\alpha} \\mathbf{v}^\\alpha", block: true)
]

#text("one can verify that the equations ")#link(<tao-9bbf7e7a9e39a9fd0cfb>)[#text("(139)")]#text(", ")#link(<tao-808fc2f6d7458a65e421>)[#text("(140)")]#text(", ")#link(<tao-240f9335b7b25fc12cd4>)[#text("(141)")]#text(" hold, and that ")#mi("{\\mathbf{F}, \\mathbf{f}}")#text(" have mean zero in ")#mi("{b}")#text(". Furthermore, by pushing forward ")#link(<tao-34a389d790fc2bdd8458>)[#text("(150)")]#text(" by ")#mi("{X(t)}")#text(", we conclude that the matrix with entries")

#align(center)[#tao-fit-display[#tao-math("C (-R^{ij}(t,X(t,a)) + 100 \\left\\| R \\right\\|_{C^0_{t,x}} \\eta^{ij})", block: true)]]

#align(center)[#tao-fit-display[#mitex("- \\partial_\\alpha X^i(t,a) \\mathbf{v}^\\alpha(t,a,b) \\partial_\\beta X^j(t,a) \\mathbf{v}^\\beta(t,a,b)")]]

#text("is positive semi-definite for all ")#mi("{(t,a,b) \\in I^{\\prime} \\in \\mathbf{T}_L \\times \\mathbf{T}_F}")#text("; taking traces one concludes ")#link(<tao-992ba71bb1ffe9a06e08>)[#text("(149)")]#text(". Thus we have obtained all the properties required in Exercise ")#link(<tao-490ae03e180a3b4eef1e>)[#text("43")]#text(", concluding the proof of Proposition ")#link(<tao-7220a42316020de1e8df>)[#text("38")]#text(".")

#heading(level: 1)[#strong[#text(" — 6. Constructing high regularity weak solutions to Euler — ")]]

#text("We now informally discuss how to modify the arguments above to establish the negative direction (ii) of Onsager’s conjecture. The full details are rather complicated (and arranged slightly differently from the presentation here), and we refer to ")#link("https://arxiv.org/abs/1608.08301")[#text("Isett’s original paper")]#text(" for details. See also ")#link("https://arxiv.org/abs/1701.08678")[#text("a subsequent paper of Buckmaster, De Lellis, Szekelyhidi, and Vicol")]#text(" for a simplified argument establishing this statement (as well as some additional strengthenings of it).")

#text("Let ")#mi("{0 < \\alpha < 1/3}")#text(", let ")#mi("{\\varepsilon > 0}")#text(" be a small quantity, and let ")#mi("{M}")#text(" be a large integer. The main iterative step, analogous to Theorem ")#link(<tao-36498366fa588fcaeaf2>)[#text("30")]#text(", roughly speaking (ignoring some technical logarithmic factors) takes an Euler-Reynolds flow ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" obeying the estimates that look like ")#metadata(none) <tao-7c45d237d2c93594e7d0>#tao-math("\\displaystyle  \\left\\| (N_0^{-1} \\nabla_x)^{\\leq M} \\nabla_x u^{(0)} \\right\\|_{C^0_{t,x}} \\lesssim N_0^{1-\\alpha} \\ \\ \\ \\ \\ (151)", block: false)#text(" ")#text(" and ")#metadata(none) <tao-a09d4c989895c74f927a>#tao-math("\\displaystyle  \\left\\| (N_0^{-1} \\nabla_x)^{\\leq M} R^{(0)} \\right\\|_{C^0_{t,x}} \\lesssim N_0^{-2(1+\\varepsilon)\\alpha}. \\ \\ \\ \\ \\ (152)", block: false)#text(" ")#text(" for some sufficiently large ")#mi("{N_0>1}")#text(", and obtains a new Euler-Reynolds flow ")#mi("{(u^{(1)},p^{(1)},R^{(1)})}")#text(" close to ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" that obeys the estimates ")#metadata(none) <tao-ac7b467de6ffdcca6a18>#tao-math("\\displaystyle  \\left\\| (N_1^{-1} \\nabla_x)^{\\leq M} \\nabla_x u^{(1)} \\right\\|_{C^0_{t,x}} \\lesssim N_1^{1-\\alpha} \\ \\ \\ \\ \\ (153)", block: false)#text(" ")#text(" and ")#metadata(none) <tao-9fe02264c9145c04f26d>#tao-math("\\displaystyle  \\left\\| (N_0^{-1} \\nabla_x)^{\\leq M} R^{(1)} \\right\\|_{C^0_{t,x}} \\lesssim N_1^{-2(1+\\varepsilon)\\alpha}, \\ \\ \\ \\ \\ (154)", block: false)#text(" ")#text(" where ")#mi("{N_1 := N_0^{1+\\varepsilon}}")#text("; see Lemma 2.1 of ")#link("https://arxiv.org/abs/1608.08301")[#text("Isett’s original paper")]#text(" for a more precise statement (in a slightly different notation), which also includes various estimates on the difference ")#mi("{u^{(1)}-u^{(0)}}")#text(" that we omit here. In contrast to previous arguments, it is useful for technical reasons to not impose time regularity in the estimates. Once this claim is formalised and proved, conclusions such as Onsager’s conjecture follow from the usual iteration arguments.")

#text("To achieve this iteration step, the first step is a mollification step analogous to Proposition ")#link(<tao-f74c418e07d82a11d903>)[#text("31")]#text(" in which one perturbs the initial flow to obtain additional spatial regularity on the solution. Roughly speaking, this mollification allows one to replace the purely spatial differential operator ")#mi("{(N_0^{-1} \\nabla x)^{\\leq M}}")#text(" appearing in ")#link(<tao-7c45d237d2c93594e7d0>)[#text("(151)")]#text(", ")#link(<tao-ac7b467de6ffdcca6a18>)[#text("(153)")]#text(" with ")#mi("{(N_0^{-1} \\nabla x)^{\\leq m}}")#text(" for ")#mi("{m}")#text(" much larger than ")#mi("{M}")#text(" (in practice there are some slight additional losses, which we will ignore here).")

#text("Now one has to solve the difference equation. We focus on the equation ")#link(<tao-8a7bc6881f93f93ddf1a>)[#text("(126)")]#text(" and omit the small errors involving ")#mi("{f, F}")#text(". Suppose for the time being that we could magically replace the material Lie derivative ")#mi("{{\\mathcal D}_t}")#text(" here by an ordinary time derivative, thus we would be trying to construct ")#mi("{v}")#text(" solving an equation such as")

#align(center)[#tao-fit-display[#mitex("\\partial_t v^i + 2 v^j \\partial_j u^i + \\partial_j( v^i v^j + R^{ij} + q \\eta^{ij} - \\tilde R^{ij} ) \\approx 0.")]]

#text("As before, we can use the method of fast and slow variables to construct a ")#mi("{v}")#text(" of amplitude roughly ")#tao-math("{\\left\\| R \\right\\|_{C_0}^{1/2} = O( N_1^{-\\alpha})}", block: false)#text(", oscillating at frequency ")#mi("{N_1}")#text(", such that ")#mi("{v^i v^j + R^{ij} + q \\eta^{ij}}")#text(" is high frequency (mean zero in the fast variable) and has amplitude about ")#mi("{N_1^{-2\\alpha}}")#text(". We can also arrange matters (using something like ")#link(<tao-d6ba8bf227ba2c637c44>)[#text("(65)")]#text(") so that the fast derivative component of ")#mi("{\\partial_j( v^i v^j + R^{ij} + q \\eta^{ij})}")#text(" vanishes, leaving only a slower derivative of size about ")#mi("{N_0}")#text(". This makes the expression ")#mi("{\\partial_j( v^i v^j + R^{ij} + q \\eta^{ij})}")#text(" of magnitude about ")#mi("{O(N_0 N_1^{-2\\alpha})}")#text(" and oscillating at frequency about ")#mi("{N_1}")#text(", which can be cancelled by a stress corrector in ")#mi("{\\tilde R}")#text(" of magnitude about ")#mi("{O(N^{-1}_1 N_0 N_1^{-2\\alpha}) \\approx N_1^{-2\\alpha - \\varepsilon}}")#text(". Such a term would be acceptable (smaller than ")#mi("{N_1^{-2(1+\\varepsilon) \\alpha}}")#text(") for ")#mi("{\\alpha}")#text(" as large as ")#mi("{1/2}")#text(", in the spirit of Theorem ")#link(<tao-047de0f543c7e3596bb6>)[#text("29")]#text(".")

#text("However, one also has the terms ")#mi("{\\partial_t v^i}")#text(" and ")#mi("{v^j \\partial_j u^i}")#text(", which (in contrast to the high-dimensional Sobolev scale setting) cannot be ignored in this low-dimensional Hölder scale problem. The natural time scale of oscillation here is ")#mi("{O(N_0^{\\alpha-1})}")#text(", coming from the usual heuristics concerning the Euler equation (see Remark 11 from ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("254A Notes 3")]#text("). With this heuristic, ")#mi("{\\nabla u}")#text(" and ")#mi("{\\partial_t}")#text(" should both behave like ")#mi("{O(N_0^{1-\\alpha})}")#text(", these expressions would be expected to have amplitude ")#mi("{O(N_0^{1-\\alpha} N_1^{-\\alpha})}")#text(". They still oscillate at the high frequency ")#mi("{N_1}")#text(", though, and lead to a stress corrector of magnitude about ")#mi("{O( N_1^{-1} N_0^{1-\\alpha} N_1^{-\\alpha}) \\approx N_1^{-2\\alpha - \\varepsilon + \\alpha \\varepsilon}}")#text(". This however remains acceptable for ")#mi("{\\alpha}")#text(" up to ")#mi("{1/3}")#text(", which in principle resolves Onsager’s conjecture.")

#text("Now we have to remove the “cheat” of replacing the material Lie derivative by the ordinary time derivative. As we saw in the previous section, the natural way to fix this is to work in Lagrangian coordinates. However, we encounter a new problem: if one initialises the trajectory flow map ")#mi("{X}")#text(" to be the identity at some given time ")#mi("{t_0}")#text(", then it turns out that one only gets good control on the flow map and its derivatives for times ")#mi("{t = t_0 + O(N_0^{\\alpha-1})}")#text(" within the natural time scale ")#mi("{N_0^{\\alpha-1}}")#text(" of that initial time ")#mi("{t_0}")#text("; beyond this, the Gronwall-type arguments used to obtain bounds start to deteriorate exponentially. Because of this, one cannot rely on a “global” Lagrangian coordinate system as in the previous section. To get around this, one needs to partition the time domain ")#mi("{{\\bf R}/{\\bf Z}}")#text(" into intervals ")#mi("{I_k}")#text(" of length about ")#mi("{N_0^{\\alpha-1}}")#text(", and construct a separate trajectory map adapted to each such interval. One can then use these “local Lagrangian coordinates” to construct local components ")#mi("{v_k}")#text(" of the velocity perturbation ")#mi("{v}")#text(" that obey the required properties on each such interval. This construction is essentially the content of the “convex integration lemma” in Lemma 3.3 of ")#link("https://arxiv.org/abs/1608.08301")[#text("Isett’s paper")]#text(".")

#text("However, a new problem arises when trying to “glue” these local corrections ")#mi("{v_k}")#text(" together: two consecutive time intervals ")#mi("{I_k, I_{k+1}}")#text(" will overlap, and their corresponding local corrections ")#mi("{v_k, v_{k+1}}")#text(" will also overlap. This leads to some highly undesirable interaction terms between ")#mi("{v_k}")#text(" and ")#mi("{v_{k+1}}")#text(" (such as the fast derivative of ")#mi("{v_{k}^i v_{k+1}^j}")#text(") which are very difficult to make small (for instance, one cannot simply ensure that ")#mi("{v_k, v_{k+1}}")#text(" have disjoint spatial supports as they are constructed using different local Lagrangian coordinate systems). On the other hand, if the original Reynolds stress ")#mi("{R}")#text(" had a special structure, namely that it was only supported on every other interval ")#mi("{I_k}")#text(" (i.e., on the ")#mi("{I_k}")#text(" for all ")#mi("{k}")#text(" even, or the ")#mi("{I_k}")#text(" for all ")#mi("{k}")#text(" odd), then these interactions no longer occur and the iteration step can proceed.")

#text("One could try to then resolve the problem by correcting the odd and even interval components of the stress ")#mi("{R}")#text(" in separate stages (cf. how Theorem ")#link(<tao-fddd57f30ecef538db12>)[#text("19")]#text(" can be iterated to establish Theorem ")#link(<tao-31b44bb034859a747d92>)[#text("15")]#text("), but this is inefficient with regards to the ")#mi("{\\alpha}")#text(" parameter, in particular this makes the argument stop well short of the optimal ")#mi("{1/3}")#text(" threshold. To attain this threshold one needs the final ingredient of Isett’s argument, namely a “gluing approximation” (see Lemma 3.2 of ")#link("https://arxiv.org/abs/1608.08301")[#text("Isett’s paper")]#text("), in which one tales the (mollified) initial Euler-Reynolds flow ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" and replaces it with a nearby flow ")#mi("{(\\tilde u^{(0)},\\tilde p^{(0)},\\tilde R^{(0)})}")#text(" in which the new Reynolds stress ")#mi("{R^{(0)}}")#text(" is only supported on every other interval ")#mi("{I_k}")#text(". Combining this gluing approximation lemma with the mollification lemma and convex integration lemma gives the required iteration step. (One technical point is that this gluing has to create some useful additional regularity along the material derivative, in the spirit of Remark 38 of ")#link("https://terrytao.wordpress.com/2018/12/16/255b-notes-1-the-lagrangian-formulation-of-the-euler-equations/")[#text("Notes 1")]#text(", as such regularity will be needed in order to justify the convex integration step.)")

#text("To obtain this gluing approximation, one takes an ")#mi("{N_0^{1-\\alpha}}")#text("-separated sequence of times ")#mi("{t_k}")#text(", and for each such time ")#mi("{t_k}")#text(", one solves the ")#emph[#text("true")]#text(" Euler equations with initial data ")#mi("{u^{(0)}(t_k)}")#text(" at ")#mi("{t_k}")#text(" to obtain smooth Euler solutions ")#mi("{(u_k, p_k)}")#text(" on a time interval centred at ")#mi("{t_k}")#text(" of lifespan ")#mi("{\\sim N_0^{\\alpha-1}}")#text(", that agree with ")#mi("{u^{(0)}}")#text(" at time ")#mi("{t_k}")#text(". (It is non-trivial to check that these solutions even exist on such an interval, let alone obey good estimates, but this can be done if the initial data was suitably mollified, as is consistent with the heuristics in Remark 11 from ")#link("https://terrytao.wordpress.com/2018/10/09/254a-notes-3-local-well-posedness-for-the-euler-equations/")[#text("254A Notes 3")]#text(".) One can then glue these solutions together around the reference solution ")#mi("{(u^{(0)},p^{(0)},R^{(0)})}")#text(" by defining")

#tao-aligned(keep: true)[


#tao-math("\\tilde u^{(0)}  & := u^{(0)} + \\sum_k \\psi_k (u_k - u^{(0)})", block: true)



#tao-math("\\tilde p^{(0)}  & := p^{(0)} + \\sum_k \\psi_k (p_k - p^{(0)})", block: true)
]

#text("for a suitable partition of unity ")#mi("{1 = \\sum_k \\psi_k}")#text(" in time. This gives fields ")#mi("{(\\tilde u^{(0)}, \\tilde p^{(0)})}")#text(" that solve the Euler equation near each time ")#mi("{t_k}")#text(". To finish the proof of the gluing approximation lemma, one needs to then find a matching Reynolds stress ")#mi("{\\tilde R^{(0)}}")#text(" for the intervals at which the Euler equation is not solved exactly. Isett’s original construction of this stress was rather intricate; see Sections 7-10 of ")#link("https://arxiv.org/abs/1608.08301")[#text("Isett’s paper")]#text(" for the technical details. However, with improved estimates, a simpler construction was used in ")#link("https://arxiv.org/abs/1701.08678")[#text("a subsequent paper of Buckmaster, De Lellis, Szekelyhidi, and Vicol")]#text(", leading to a simplified proof of (the non-endpoint version of) this direction of Onsager’s conjecture.")

#heading(level: 1)[#text("Comments (29)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510834")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("The formatting is messed up (equations showing as raw TeX instead of being rendered) in several places in the article. Btw if you don’t mind my asking, how do you compose these entries? Do you write them out on paper before transcribing to TeX? Or just type TeX directly? Thanks.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510866")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("I didn’t see any raw TeX in the latest version (though there were some overflowing latex displays which I reformatted). It could have been a transient WordPress LaTeX rendering issue.")

#text("I use Luca Trevisan’s LateX to WordPress converter, see the bottom of ")#link("https://terrytao.wordpress.com/about/")[#text("https://terrytao.wordpress.com/about/")]#text(" as well as ")#link("http://lucatrevisan.wordpress.com/latex-to-wordpress/")[#text("http://lucatrevisan.wordpress.com/latex-to-wordpress/")]#text(" .")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510871")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("What a wonderful post. Thank you very much Terry")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2694e9ba85c688bdec2d3f427b259c8eb418214835c815fd566fa1726912ff3e-113eae99aed9a89a63e2194d0951b19217413071faec5515f8ac3d9fd785549a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Auf Achse")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510872")[#strong[#text("Auf Achse")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("Thank you very much for this very interesting post.")

#text("It is also worth checking out a beautiful recent survey on the developments towards Onsager‘s conjecture by De Lellis and Székelyhidi:")

#link("https://arxiv.org/pdf/1901.02318.pdf")[#text("Click to access 1901.02318.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f855e89792df26d06fb04b0f7e0e0c3567145de6003a70a2e2e0d4aba28462f0-b06935049563a990e727c33f4e9adcb164d4e211f3b5b8714a01799a219e13b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Camillo De Lellis")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510892")[#strong[#text("Camillo De Lellis")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("Dear Terry,")#linebreak()#text(" thanks for the beautiful post!")

#text("I am not sure whether I have understood correctly your last paragraph that naive attempts to invert the divergence operator lead to poor estimates. But it might be inaccurate, because in this note we do invert the divergence in the most “obvious way”, through an elliptic operator, after the glueing (cf. Section 4):")

#link("http://www.math.uzh.ch/fileadmin/user/delellis/publikation/Onsager96.pdf")[#text("Click to access Onsager96.pdf")]

#text("Best,")#linebreak()#text(" Camillo")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510908")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2019")])]

#text("Thanks for this reference, which I had somehow missed!")

#text("My discussion was based on that in the start of Section 7 of Isett’s paper ")#link("https://arxiv.org/pdf/1608.08301.pdf")[#text("https://arxiv.org/pdf/1608.08301.pdf")]#text(" where he says the best estimate he can get from naively inverting the divergence is estimate (50) of that paper which is unsatisfactory. I’m not sure how to reconcile this statement with the estimates in Proposition 4.3 of your paper. Is the point that the commutator estimates with the advective derivative provide a better estimate on the “obvious” choice of antidivergence than what is described in Section 7 of Isett’s paper?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f855e89792df26d06fb04b0f7e0e0c3567145de6003a70a2e2e0d4aba28462f0-b06935049563a990e727c33f4e9adcb164d4e211f3b5b8714a01799a219e13b0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Camillo De Lellis")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510935")[#strong[#text("Camillo De Lellis")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2019")])]

#text("Yes, the point is precisely that commuting the antidivergence with the advective derivative gives a better estimate. In a first draft of our proof we did have a lemma where we commuted the antidivergence and the advective derivative. Then we discovered that the proof becomes very elementary and simple if one instead commutes the Biot-Savart operator. So, in the version I linked above, the key is actually Proposition 3.4.")

#text("If I remember correctly (I have a bad connection at the moment and I don’t find a copy of Phil’s paper in my laptop), the improvement compared to Phil’s estimate (50) is, in our notation, the factor ")#mi("\\tau_q")#text(" in our estimate (3.16). The relevant computations on the commutator are between eq. (3.19) and eq. (3.21).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-510956")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 January 2019")])]

#text("Thanks for the clarification! The construction and estimation of the antidivergence was the one part of Isett’s paper that I didn’t delve into in detail as it seemed particularly technical; it’s good to know that in fact one can avoid much of this technicality. I have updated the lecture notes accordingly.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5da4b9b1fb5c55b28e110fd135bb36d736d9917a9acf0ace12522c94398278fe-6eb7fc4021d03446a6fb829b22607703bd652255e34081c679951682f05bbbbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Phil Isett")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511396")[#strong[#text("Phil Isett")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2019")])]

#text("About estimating the anti-divergence, one can say a little more about why it works. Commuting with the advective derivative produces a suitable bound for the anti-divergence only if one assumes a priori that the anti-divergence itself already obeys a suitable bound. To get this argument to close depends on the structure of the evolution equation obeyed by the anti-divergence; it is a dynamical estimate that is stronger than the bound one would get by trying to estimate the anti-divergence directly. A similar statement applies to the linearized Euler term that appears in this evolution equation; the direct bound is not sharp enough and the term has to be treated by a dynamical argument.")

#text("About improving the timescale: It is possible to improve the timescale of the gluing approximation by using a combination of the approach of Camillo and coauthors (Buckmaster et al.) and my own. Doing so helps to obtain the best known estimate towards the endpoint case of Onsager’s conjecture. The way this improvement works is explained in the last section of my endpoint paper:")

#link("https://arxiv.org/abs/1706.01549")[#text("https://arxiv.org/abs/1706.01549")]

#text("Note that obtaining any result of endpoint type requires avoiding power losses in frequency during the iteration, so the strategy I developed in my original proof of Onsager’s conjecture is important for this application because it avoids such power losses.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/92c509546c5312b8388119b71c770ef79c3261f152d5b36591b3c44d18beaac5-712ea3cee1a4e9a38803559a57f7a5d0d72d633adb33f667edf30419fb2c3a3f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chungachanga")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511221")[#strong[#text("Chungachanga")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2019")])]

#text("I’m an alien from nearby galaxy, and I wonder how stupid Terence Tao is. The problems he is trying to solve are actualy our elementary school homework.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2cd6e5aad292560f64aa9b45f206b0b28bb1653f6fa014816cacacbed78552fc-c80b60e7a5c2a123c91bafc7bcbdd6449b4a89fd888c4af3c56d500dd860cd71.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of test")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-512172")[#strong[#text("test")]]#text(size: 9pt, fill: rgb("596477"), " · 5 February 2019")])]

#text("An alien who can’t spell probably doesn’t know what they’re talking about.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511405")[#strong[#text("terminology: equation collapse | Physics Forums")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2019")]

#text("[…] happens. Another term are regular and abnormal solutions, I think. At least Tao used them here: ")#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")[#text("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/")]#text(" fresh_42, Jan 17, 2019 at 3:34 […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3682381787e9666fa65cd19b73df19989420731bc142046ebf8ea923c9159506-51c3e61dce9a74141e994731ffae0e4de0b4e513b62d6a9c980baac8c89700f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Javohir")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511408")[#strong[#text("Javohir")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2019")])]

#text("Mr. Terence Tao")#linebreak()#text(" What kind of email can I send you?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3682381787e9666fa65cd19b73df19989420731bc142046ebf8ea923c9159506-51c3e61dce9a74141e994731ffae0e4de0b4e513b62d6a9c980baac8c89700f1.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Javohir")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511428")[#strong[#text("Javohir")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2019")])]

#text("Dear prof. Tao")#linebreak()#text(" I have a simple question in math. How can I send you an email?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0b7e9fbd8e9e2395ffdafc271a04be9b617d62a87ea7cf1e6830fbfc9ceec513-237495d4f6a3cd0573a4334b3de0c08a78d822dadb01e0aab10f942bf17021f4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mohd")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511432")[#strong[#text("Mohd")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2019")])]

#text("Hi I learnt from your math thank you for your teaching moreover I am always looking forward for more mathematics journal entries.thank you sir")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511455")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2019")])]

#text("Please allow me express my idea here:over three years (2016,2017,2018)Pro.Tao has not still got any medal yet.What a sadly!While everyday , Pro Tao is very patient and active as well as very effective in doing math if comparison with the rest of mathematicians.I hope Pro Tao will make a hattrick in 2019(ProTao will receive Shaw prize,Wolf prize,Abel prize at the same time)I think Pro Tao is very worth having three honors in 2019.Who agrees with me , up like")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b058a3ee77e3032fe7c56319c823c0241460703cf7ca2db0ffbdcc27d4108719-db5a9eea494e1480a6e1d1d2d8f50aeab891d39afcbf734fb9026de2f0ff8ef6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jair2030")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511639")[#strong[#text("jair2030")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2019")])]

#text("Dear Professor Tao,")

#text("My name is jai Ramanathan and I really love math,i have a uncountable amount of mental problems and would like your advice in staying in math.I love problem solving but when I an “punished” for solving a question wrong during a assignment and hence affecting my grade,i am an extremely non-creative thinker and a rote learner,would you advise some strategries for me in real analysis courses,your reply would mean the whole world to me.")

#text("Many Thanks,")

#text("Jai")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-523810")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2019")])]

#text("“I have a uncountable amount of mental problems”")

#text("same here buddy")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b8f7a210ceb31b9bdad3c664abc6cd24fbaf7a9d77914328a97bbf7562647f2c-b6ef1b05afad5690aad265c0344970847c25be5be0538858eaaa5f9a37b9e301.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of claesjohnson")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511813")[#strong[#text("claesjohnson")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2019")])]

#text("Hi Terence")

#text("I argue that the Clay Problem can be answered by computation:")

#link("https://claesjohnson.blogspot.com/2019/01/solution-of-clay-navier-stokes-problem.html")[#text("https://claesjohnson.blogspot.com/2019/01/solution-of-clay-navier-stokes-problem.html")]

#text("Any comment?")

#text("Best regards")

#text("Claes")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-511858")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2019")])]

#text("On a different page of your blog you’ve also disproved P = NP. Wow!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of On the universality of the incompressible Euler equation on compact manifolds, II. Non-rigidity of Euler flows | What's new")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-512852")[#strong[#text("On the universality of the incompressible Euler equation on compact manifolds, II. Non-rigidity of Euler flows | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 February 2019")])]

#text("[…] equations provided by the “-principle” of Gromov and its variants (as discussed in these recent notes), although in this case the flexibility comes from adding additional dimensions, rather than by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8298e85e297768a7d544bf0fa51ebaacd867b5a709507209339782998e50f135-412da014b063d73201a5493fc42820594ad795c7d6f08ac6155a4155b14ff34d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of doing the homework")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-513575")[#strong[#text("doing the homework")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2019")])]

#text("Possible correction: in the definition of $\\mathbf d^i$, the $\\grad_x\\cdot\\grad_y$ should be done $m-1$ times.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-513720")[#strong[#text("Navies – Pages")]]#text(size: 9pt, fill: rgb("596477"), " · 11 March 2019")]

#text("[…] Euler equations provided by the “-principle” of Gromov and its variants (as discussed in these recent notes), although in this case the flexibility comes from adding additional dimensions, rather than by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-515178")[#strong[#text("On the universality of the incompressible Euler equation on compact manifolds, II. Non-rigidity of Euler flows – 刘展均工作室")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2019")]

#text("[…] as the Euler equations provided by the “-principle” of Gromov and its variants (as discussed in these recent notes), although in this case the flexibility comes from adding additional dimensions, rather than by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/777f6123d36e8575f10e9e5b262358daf825e8e68685cb8043248c9931afed26-6ac868861aed8e606d7464a152d0e7bcb9dfde33fbd2a2ba14f41e2dbef07c43.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michele Gorini")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-644844")[#strong[#text("Michele Gorini")]]#text(size: 9pt, fill: rgb("596477"), " · 9 June 2022")])]

#text("Dear Mr. Tao,")#linebreak()#text(" I have a small question.")#linebreak()#text(" In this post, you say «For any shift ")#mi("\\theta \\in \\mathbf{T}_F")#text(", we see from the chain rule that ")#mi("(v^\\theta, q^\\theta, R^\\theta, f^\\theta, F^\\theta)")#text(" is an approximate difference Navier-Stokes-Reynolds flow at U supported on ")#mi("I^{\\prime} \\times \\mathbf{T}_E")#text(", where» ")#mi("v_\\theta(t,x,y,z) := { v}(t,x,y,z,N_1x+\\theta,N_1y+\\theta,N_1z+\\theta)")#text(" and so on. I called the slow variables ")#mi("(x,y,z)")#text(", and the fast ones will be ")#mi("(X,Y,Z)")#text(".")#linebreak()#text(" From the chain rule, ")#mi("\\partial_xv(t,x,y,z)=(\\partial_x+N_1\\partial_X) v(t,x,y,z,N_1x+\\theta,N_1y+\\theta,N_1z+\\theta)")#text(", and similar relations. So when I compute the Laplacian, abbreviating ")#mi("\\underline x:=(x,y,z),\\underline X := (X,Y,Z)")#text(", I should get ")#mi("\\Delta_{\\underline x}v(t,\\underline x)=[(\\partial_x+N_1\\partial_X)^2+(\\partial_y+N_1\\partial_Y)^2+(\\partial_z+N_1\\partial_Z)^2] v(t,\\underline x,\\underline X)=[\\partial_x^2+2N_1\\partial_x\\partial_X+N_1^2\\partial_X^2+\\partial_y^2+2N_1\\partial_y\\partial_Y+N_1^2\\partial_Y^2+\\partial_z^2+2N_1\\partial_z\\partial_Z+N_1^2\\partial_Z^2] v(t,\\underline x,\\underline X)=(\\Delta_{\\underline x}+N_1^2\\Delta_{\\underline X}+2N_1\\nabla_{\\underline x}\\cdot\\nabla_{\\underline X}")#text(".")#linebreak()#text(" However, the equations that define approximate fast-slow solutions do not have any trace of those mixed terms. Am I missing something? Can we say those terms are zero? Otherwise what becomes of them?")#linebreak()#text(" PS You have an \\eqref[bd-5} which does not render because of that open square bracket, it is around the point where you define ")#mi("v_\\theta")#text(" and company.")

#emph[#text("[Corrected (and missing terms reinstated), thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-689484")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 December 2025")])]

#text("After formula 70, the formulas are not visible.")

#text("Could you correct them?")

#emph[#text("[I cannot reproduce this issue; it could have been a transient server error. -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-689547")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2026")])]

#text("Dear Mr. Tao,")

#text("I have three questions.")

#enum(start: 1, 
[#text("Theorem 29 has the hypothesis that the initial datum is zero; where is this hypothesis used? I was trying to see if it could be removed, but cannot see where it is used;")],
[#text("In the proof of this theorem, there is a step which performs a space-time mollification; does that not potentially change the initial datum, making it non-zero? If it does, how is this “set straight”? After all, we want infinitely many solutions with zero initial datum, correct?")],
[#text("Is there a published paper about this theorem?")]
)
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-689552")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2026")])]

#text("Regarding 2., the sequence of approximate solutions constructed by iterating Theorem 20 remain supported in $[0.3, 0.7] \\times {\\bf T}_E$ and so all vanish at time zero, and so the limit does also.")

#text("I did not publish this theorem elsewhere, but there has been followup work establishing stronger results. For instance the results here can also be recovered from adapting the arguments in ")#link("http://link.springer.com/article/10.1007/s00205-019-01366-9")[#text("this paper of Luo")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2019/01/08/255b-notes-2-onsagers-conjecture/#comment-689548")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2026")])]

#text("Re my previous comment, I thought the statement was there were infinitely many H^s weak solutions with zero initial datum. I was clearly misremembering from when I read this more carefully some 4 years ago. Generalizing this to nontrivial data is thus much more complex, presumably. The zero datum gives the trivial solution, and the theorem gives one nontrivial solution. Does the proof easily yield irregularity for the constructed solution, so that one could take smooth data and conclude non-uniqueness for them? My questions 2 and 3 still stand, of course.")
]
