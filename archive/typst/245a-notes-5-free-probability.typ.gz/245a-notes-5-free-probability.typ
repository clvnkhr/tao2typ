// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/
// Converted to Typst by tao2typ: "2026-10-14T16:36:05.126414+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "254A, Notes 5: Free probability", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("254A, Notes 5: Free probability")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 10 February 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the ")#link("http://en.wikipedia.org/wiki/Probability_axioms")[#text("foundations of modern probability")]#text(", as laid out by Kolmogorov, the basic objects of study are constructed in the following order:")

#enum(start: 1, 
[#text("Firstly, one selects a ")#link("http://en.wikipedia.org/wiki/Sample_space")[#text("sample space")]#text(" ")#mi("{\\Omega}")#text(", whose elements ")#mi("{\\omega}")#text(" represent all the possible states that one’s stochastic system could be in.")],
[#text("Then, one selects a ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("{\\sigma}")#text("-algebra")]#text(" ")#mi("{{\\mathcal B}}")#text(" of ")#link("http://en.wikipedia.org/wiki/Event_(probability_theory)")[#text("events")]#text(" ")#mi("{E}")#text(" (modeled by subsets of ")#mi("{\\Omega}")#text("), and assigns each of these events a ")#link("http://en.wikipedia.org/wiki/Probability")[#text("probability")]#text(" ")#mi("{{\\bf P}(E) \\in [0,1]}")#text(" in a countably additive manner, so that the entire sample space has probability ")#mi("{1}")#text(".")],
[#text("Finally, one builds (commutative) ")#link("http://en.wikipedia.org/wiki/Algebra_(ring_theory)")[#text("algebras")]#text(" of ")#link("http://en.wikipedia.org/wiki/Random_variable")[#text("random variables")]#text(" ")#mi("{X}")#text(" (such as complex-valued random variables, modeled by measurable functions from ")#mi("{\\Omega}")#text(" to ")#mi("{{\\bf C}}")#text("), and (assuming suitable integrability or moment conditions) one can assign ")#link("http://en.wikipedia.org/wiki/Expected_value")[#text("expectations")]#text(" ")#mi("{\\mathop{\\bf E} X}")#text(" to each such random variable.")]
)

#text("In ")#link("http://en.wikipedia.org/wiki/Measure_(mathematics)")[#text("measure theory")]#text(", the underlying measure space ")#mi("{\\Omega}")#text(" plays a prominent foundational role, with the measurable sets and measurable functions (the analogues of the events and the random variables) always being viewed as somehow being attached to that space. In probability theory, in contrast, it is the events and their probabilities that are viewed as being fundamental, with the sample space ")#mi("{\\Omega}")#text(" being abstracted away as much as possible, and with the random variables and expectations being viewed as derived concepts. See ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text(" for further discussion of this philosophy.")

#text("However, it is possible to take the abstraction process one step further, and view the ")#emph[#text("algebra of random variables and their expectations")]#text(" as being the foundational concept, and ignoring the presence of the original sample space, the algebra of events, and the probability measure.")

#text("There are two reasons for wanting to shed (or abstract away) these previously foundational structures. Firstly, it allows one to more easily take certain types of limits, such as the large ")#mi("{n}")#text(" limit ")#mi("{n \\rightarrow \\infty}")#text(" when considering ")#mi("{n \\times n}")#text(" random matrices, because quantities built from the algebra of random variables and their expectations, such as the normalised moments of random matrices tend to be quite stable in the large ")#mi("{n}")#text(" limit (as we have seen in previous notes), even as the sample space and event space varies with ")#mi("{n}")#text(". (This theme of using abstraction to facilitate the taking of the large ")#mi("{n}")#text(" limit also shows up in the application of ergodic theory to combinatorics via the correspondence principle; see ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this previous blog post")]#text(" for further discussion.)")

#text("Secondly, this abstract formalism allows one to generalise the classical, commutative theory of probability to the more general theory of ")#emph[#text("non-commutative probability theory")]#text(", which does not have a classical underlying sample space or event space, but is instead built upon a (possibly) ")#emph[#text("non-commutative")]#text(" algebra of random variables (or “observables”) and their expectations (or “traces”). This more general formalism not only encompasses classical probability, but also spectral theory (with matrices or operators taking the role of random variables, and the trace taking the role of expectation), random matrix theory (which can be viewed as a natural blend of classical probability and spectral theory), and quantum mechanics (with physical observables taking the role of random variables, and their expected value on a given quantum state being the expectation). It is also part of a more general “non-commutative way of thinking” (of which ")#link("http://en.wikipedia.org/wiki/Noncommutative_geometry")[#text("non-commutative geometry")]#text(" is the most prominent example), in which a space is understood primarily in terms of the ring or algebra of functions (or function-like objects, such as sections of bundles) placed on top of that space, and then the space itself is largely abstracted away in order to allow the algebraic structures to become less commutative. In short, the idea is to make ")#emph[#text("algebra")]#text(" the foundation of the theory, as opposed to other possible choices of foundations such as sets, measures, categories, etc..")

#text("[Note that this foundational preference is to some extent a metamathematical one rather than a mathematical one; in many cases it is possible to rewrite the theory in a mathematically equivalent form so that some other mathematical structure becomes designated as the foundational one, much as probability theory can be equivalently formulated as the measure theory of probability measures. However, this does not negate the fact that a different choice of foundations can lead to a different way of thinking about the subject, and thus to ask a different set of questions and to discover a different set of proofs and solutions. Thus it is often of value to understand multiple foundational perspectives at once, to get a truly ")#link("http://en.wikipedia.org/wiki/Depth_perception")[#text("stereoscopic")]#text(" view of the subject.]")

#text("It turns out that non-commutative probability can be modeled using operator algebras such as ")#link("http://en.wikipedia.org/wiki/C*-algebra")[#mi("{C^*}")#text("-algebras")]#text(", ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebras")]#text(", or algebras of bounded operators on a Hilbert space, with the latter being accomplished via the ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark%E2%80%93Segal_construction")[#text("Gelfand-Naimark-Segal construction")]#text(". We will discuss some of these models here, but just as probability theory seeks to abstract away its measure-theoretic models, the philosophy of non-commutative probability is also to downplay these operator algebraic models once some foundational issues are settled.")

#text("When one generalises the set of structures in one’s theory, for instance from the commutative setting to the non-commutative setting, the notion of what it means for a structure to be “universal”, “free”, or “independent” can change. The most familiar example of this comes from group theory. If one restricts attention to the category of abelian groups, then the “freest” object one can generate from two generators ")#mi("{e,f}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Free_abelian_group")[#text("free abelian group")]#text(" of commutative words ")#mi("{e^n f^m}")#text(" with ")#mi("{n,m \\in {\\bf Z}}")#text(", which is isomorphic to the group ")#mi("{{\\bf Z}^2}")#text(". If however one generalises to the non-commutative setting of arbitrary groups, then the “freest” object that can now be generated from two generators ")#mi("{e,f}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Free_group")[#text("free group")]#text(" ")#mi("{{\\Bbb F}_2}")#text(" of non-commutative words ")#mi("{e^{n_1} f^{m_1} \\ldots e^{n_k} f^{m_k}}")#text(" with ")#mi("{n_1,m_1,\\ldots,n_k,m_k \\in {\\bf Z}}")#text(", which is a significantly larger extension of the free abelian group ")#mi("{{\\bf Z}^2}")#text(".")

#text("Similarly, when generalising classical probability theory to non-commutative probability theory, the notion of what it means for two or more random variables to be independent changes. In the classical (commutative) setting, two (bounded, real-valued) random variables ")#mi("{X, Y}")#text(" are ")#link("http://en.wikipedia.org/wiki/Independence_(probability_theory)")[#text("independent")]#text(" if one has")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} f(X) g(Y) = 0")]]

#text("whenever ")#mi("{f, g: {\\bf R} \\rightarrow {\\bf R}}")#text(" are well-behaved functions (such as polynomials) such that ")#mi("{\\mathop{\\bf E} f(X)}")#text(", ")#mi("{\\mathop{\\bf E} g(Y)}")#text(" both vanish. In the non-commutative setting, one can generalise the above definition to two ")#emph[#text("commuting")]#text(" bounded self-adjoint variables; this concept is useful for instance in ")#link("http://en.wikipedia.org/wiki/Quantum_probability")[#text("quantum probability")]#text(", which is an abstraction of the theory of observables in quantum mechanics. But for two (bounded, self-adjoint) ")#emph[#text("non-commutative")]#text(" random variables ")#mi("{X, Y}")#text(", the notion of classical independence no longer applies. As a substitute, one can instead consider the notion of being ")#link("http://en.wikipedia.org/wiki/Free_independence")[#text("freely independent")]#text(" (or ")#emph[#text("free")]#text(" for short), which means that")

#align(center)[#tao-fit-display[#mitex("\\mathop{\\bf E} f_1(X) g_1(Y) \\ldots f_k(X) g_k(Y) = 0")]]

#text("whenever ")#mi("{f_1,g_1,\\ldots,f_k,g_k: {\\bf R} \\rightarrow {\\bf R}}")#text(" are well-behaved functions such that all of ")#mi("{\\mathop{\\bf E} f_1(X), \\mathop{\\bf E} g_1(Y), \\ldots, \\mathop{\\bf E} f_k(X), \\mathop{\\bf E} g_k(Y)}")#text(" vanish.")

#text("The concept of free independence was introduced by Voiculescu, and its study is now known as the subject of ")#link("http://en.wikipedia.org/wiki/Free_probability")[#text("free probability")]#text(". We will not attempt a systematic survey of this subject here; for this, we refer the reader to the ")#link("http://www.mast.queensu.ca/~speicher/survey.html")[#text("surveys of Speicher")]#text(" and ")#link("http://www.dma.ens.fr/~biane/articles/biane-QPC-Grenoble.ps")[#text("of Biane")]#text(". Instead, we shall just discuss a small number of topics in this area to give the flavour of the subject only.")

#text("The significance of free probability to random matrix theory lies in the fundamental observation that random matrices which are independent in the classical sense, also tend to be independent in the free probability sense, in the large ")#mi("{n}")#text(" limit ")#mi("{n \\rightarrow \\infty}")#text(". (This is only possible because of the highly non-commutative nature of these matrices; as we shall see, it is not possible for non-trivial commuting independent random variables to be freely independent.) Because of this, many tedious computations in random matrix theory, particularly those of an algebraic or enumerative combinatorial nature, can be done more quickly and systematically by using the framework of free probability, which by design is optimised for algebraic tasks rather than analytical ones.")

#text("Much as free groups are in some sense “maximally non-commutative”, freely independent random variables are about as far from being commuting as possible. For instance, if ")#mi("{X, Y}")#text(" are freely independent and of expectation zero, then ")#mi("{\\mathop{\\bf E} XYXY}")#text(" vanishes, but ")#mi("{\\mathop{\\bf E} XXYY}")#text(" instead factors as ")#mi("{(\\mathop{\\bf E} X^2) (\\mathop{\\bf E} Y^2)}")#text(". As a consequence, the behaviour of freely independent random variables can be quite different from the behaviour of their classically independent commuting counterparts. Nevertheless there is a remarkably strong ")#emph[#text("analogy")]#text(" between the two types of independence, in that results which are true in the classically independent case often have an interesting analogue in the freely independent setting. For instance, the central limit theorem (")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("Notes 2")]#text(") for averages of classically independent random variables, which roughly speaking asserts that such averages become gaussian in the large ")#mi("{n}")#text(" limit, has an analogue for averages of freely independent variables, the ")#emph[#text("free central limit theorem")]#text(", which roughly speaking asserts that such averages become ")#emph[#text("semicircular")]#text(" in the large ")#mi("{n}")#text(" limit. One can then use this theorem to provide yet another proof of Wigner’s semicircle law (")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text(").")

#text("Another important (and closely related) analogy is that while the distribution of sums of independent commutative random variables can be quickly computed via the characteristic function (i.e. the Fourier transform of the distribution), the distribution of sums of freely independent non-commutative random variables can be quickly computed using the ")#link("http://en.wikipedia.org/wiki/Stieltjes_transformation")[#text("Stieltjes transform")]#text(" instead (or with closely related objects, such as the ")#emph[#mi("{R}")#text("-transform")]#text(" of Voiculescu). This is strongly reminiscent of the appearance of the Stieltjes transform in random matrix theory, and indeed we will see many parallels between the use of the Stieltjes transform here and in ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text(".")

#text("As mentioned earlier, free probability is an excellent tool for computing various expressions of interest in random matrix theory, such as asymptotic values of normalised moments in the large ")#mi("{n}")#text(" limit ")#mi("{n \\rightarrow \\infty}")#text(". Nevertheless, as it only covers the asymptotic regime in which ")#mi("{n}")#text(" is sent to infinity while holding all other parameters fixed, there are some aspects of random matrix theory to which the tools of free probability are not sufficient by themselves to resolve (although it can be possible to combine free probability theory with other tools to then answer these questions). For instance, questions regarding the ")#emph[#text("rate")]#text(" of convergence of normalised moments as ")#mi("{n \\rightarrow \\infty}")#text(" are not directly answered by free probability, though if free probability is combined with tools such as concentration of measure (")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 1")]#text(") then such rate information can often be recovered. For similar reasons, free probability lets one understand the behaviour of ")#mi("{k^{th}}")#text(" moments as ")#mi("{n \\rightarrow \\infty}")#text(" for ")#emph[#text("fixed")]#text(" ")#mi("{k}")#text(", but has more difficulty dealing with the situation in which ")#mi("{k}")#text(" is allowed to grow slowly in ")#mi("{n}")#text(" (e.g. ")#mi("{k = O(\\log n)}")#text("). Because of this, free probability methods are effective at controlling the ")#emph[#text("bulk")]#text(" of the spectrum of a random matrix, but have more difficulty with the ")#emph[#text("edges")]#text(" of that spectrum (as well as with related concepts such as the operator norm, ")#link("https://terrytao.wordpress.com/2010/01/03/254a-notes-1-concentration-of-measure/")[#text("Notes 3")]#text(") as well as with fine-scale structure of the spectrum. Finally, free probability methods are most effective when dealing with matrices that are Hermitian with bounded operator norm, largely because the spectral theory of bounded self-adjoint operators in the infinite-dimensional setting of the large ")#mi("{n}")#text(" limit is non-pathological. (This is ultimately due to the stable nature of eigenvalues in the self-adjoint setting; see ")#link("https://terrytao.wordpress.com/2008/10/28/when-are-eigenvalues-stable/")[#text("this previous blog post")]#text(" for discussion.) For non-self-adjoint operators, free probability needs to be augmented with additional tools, most notably by bounds on least singular values, in order to recover the required stability for the various spectral data of random matrices to behave continuously with respect to the large ")#mi("{n}")#text(" limit. We will discuss this latter point in a later set of notes.")

#metadata(none) <tao-8cefa262c2b87c26433e>

#heading(level: 1)[#strong[#text(" — 1. Abstract probability theory — ")]]

#text("We will now slowly build up the foundations of non-commutative probability theory, which seeks to capture the abstract algebra of random variables and their expectations. The impatient reader who wants to move directly on to free probability theory may largely jump straight to the final definition at the end of this section, but it can be instructive to work with these foundations for a while to gain some intuition on how to handle non-commutative probability spaces.")

#text("To motivate the formalism of abstract (non-commutative) probability theory, let us first discuss the three key examples of non-commutative probability spaces, and then abstract away all features that are not shared in common by all three examples.")

#strong[#text("Example 1: Random scalar variables.")]#text(" We begin with ")#emph[#text("classical probability theory")]#text(" – the study of scalar random variables. In order to use the powerful tools of complex analysis (such as the Stieltjes transform), it is very convenient to allow our random variables to be complex valued. In order to meaningfully take expectations, we would like to require all our random variables to also be absolutely integrable. But this requirement is not sufficient by itself to get good algebraic structure, because the product of two absolutely integrable random variables need not be absolutely integrable. As we want to have as much algebraic structure as possible, we will therefore restrict attention further, to the collection ")#mi("{L^{\\infty-}:= \\bigcap_{k=1}^\\infty L^k(\\Omega)}")#text(" of random variables with all moments finite. This class is closed under multiplication, and all elements in this class have a finite trace (or expectation). One can of course restrict further, to the space ")#mi("{L^\\infty= L^\\infty(\\Omega)}")#text(" of (essentially) bounded variables, but by doing so one loses important examples of random variables, most notably gaussians, so we will work instead with the space ")#mi("{L^{\\infty-}}")#text(". (This will cost us some analytic structure – in particular, ")#mi("{L^{\\infty-}}")#text(" will not be a Banach space, in contrast to ")#mi("{L^\\infty}")#text(" – but as our focus is on the algebraic structure, this will be an acceptable price to pay.)")

#text("The space ")#mi("{L^{\\infty-}}")#text(" of complex-valued random variables with all moments finite now becomes an ")#link("http://en.wikipedia.org/wiki/Algebra_over_a_field")[#text("algebra")]#text(" over the complex numbers ")#mi("{{\\bf C}}")#text("; i.e. it is a vector space over ")#mi("{{\\bf C}}")#text(" that is also equipped with a bilinear multiplication operation ")#mi("{\\cdot: L^{\\infty-} \\times L^{\\infty-} \\rightarrow L^{\\infty-}}")#text(" that obeys the associative and distributive laws. It is also commutative, but we will suppress this property, as it is not shared by the other two examples we will be discussing. The deterministic scalar ")#mi("{1}")#text(" then plays the role of the multiplicative unit in this algebra.")

#text("In addition to the usual algebraic operations, one can also take the ")#emph[#text("complex conjugate")]#text(" or ")#emph[#text("adjoint")]#text(" ")#mi("{X^* = \\overline{X}}")#text(" of a complex-valued random variable ")#mi("{X}")#text(". This operation ")#mi("{*: L^{\\infty-} \\rightarrow L^{\\infty-}}")#text(" interacts well with the other algebraic operations: it is in fact an ")#emph[#text("anti-automorphism")]#text(" on ")#mi("{L^{\\infty-}}")#text(", which means that it preserves addition ")#mi("{(X+Y)^* = X^*+Y^*}")#text(", reverses multiplication ")#mi("{(XY)^* = Y^* X^*}")#text(", is anti-homogeneous (")#mi("{(cX)^* = \\overline{c} X^*}")#text(" for ")#mi("{c \\in {\\bf C}}")#text("), and it is invertible. In fact, it is its own inverse (")#mi("{(X^*)^* = X}")#text("), and is thus an ")#emph[#text("involution")]#text(".")

#text("This package of properties can be summarised succinctly by stating that the space ")#mi("{L^{\\infty-}}")#text(" of bounded complex-valued random variables is a (unital) ")#link("http://en.wikipedia.org/wiki/*-algebra")[#mi("{*}")#text("-algebra")]#text(".")

#text("The expectation operator ")#mi("{\\mathop{\\bf E}}")#text(" can now be viewed as a map ")#mi("{\\mathop{\\bf E}: L^{\\infty-} \\rightarrow {\\bf C}}")#text(". It obeys some obvious properties, such as being linear (i.e. ")#mi("{\\mathop{\\bf E}}")#text(" is a linear functional on ")#mi("{L^\\infty}")#text("). In fact it is ")#emph[#mi("{*}")#text("-linear")]#text(", which means that it is linear and also that ")#mi("{\\mathop{\\bf E}(X^*) = \\overline{\\mathop{\\bf E} X}}")#text(" for all ")#mi("{X}")#text(". We also clearly have ")#mi("{\\mathop{\\bf E} 1 = 1}")#text(". We will remark on some additional properties of expectation later.")

#strong[#text("Example 2: Deterministic matrix variables.")]#text(" A second key example is that of (finite-dimensional) ")#emph[#text("spectral theory")]#text(" – the theory of ")#mi("{n \\times n}")#text(" complex-valued matrices ")#mi("{X \\in M_n({\\bf C})}")#text(". (One can also consider infinite-dimensional spectral theory, of course, but for simplicity we only consider the finite-dimensional case in order to avoid having to deal with technicalities such as unbounded operators.) Like the space ")#mi("{L^{\\infty-}}")#text(" considered in the previous example, ")#mi("{M_n({\\bf C})}")#text(" is a ")#mi("{*}")#text("-algebra, where the multiplication operation is of course given by matrix multiplication, the identity is the matrix identity ")#mi("{1 = I_n}")#text(", and the involution ")#mi("{X \\mapsto X^*}")#text(" is given by the ")#link("http://en.wikipedia.org/wiki/Conjugate_transpose")[#text("matrix adjoint operation")]#text(". On the other hand, as is well-known, this ")#mi("{*}")#text("-algebra is not commutative (for ")#mi("{n \\geq 2}")#text(").")

#text("The analogue of the expectation operation here is the ")#emph[#text("normalised trace")]#text(" ")#mi("{\\tau(X) := \\frac{1}{n} \\text{tr} X}")#text(". Thus ")#mi("{\\tau: M_n({\\bf C}) \\rightarrow {\\bf C}}")#text(" is a *-linear functional on ")#mi("{M_n({\\bf C})}")#text(" that maps ")#mi("{1}")#text(" to ")#mi("{1}")#text(". The analogy between expectation and normalised trace is particularly evident when comparing the moment method for scalar random variables (based on computation of the moments ")#mi("{\\mathop{\\bf E} X^k}")#text(") with the moment method in spectral theory (based on a computation of the moments ")#mi("{\\tau(X^k)}")#text(").")

#strong[#text("Example 3: Random matrix variables.")]#text(" ")#emph[#text("Random matrix theory")]#text(" combines classical probability theory with finite-dimensional spectral theory, with the random variables of interest now being the random matrices ")#mi("{X \\in L^{\\infty-} \\otimes M_n({\\bf C})}")#text(", all of whose entries have all moments finite. It is not hard to see that this is also a ")#mi("{*}")#text("-algebra with identity ")#mi("{1 = I_n}")#text(", which again will be non-commutative for ")#mi("{n \\geq 2}")#text(". The normalised trace ")#mi("{\\tau}")#text(" here is given by")

#align(center)[#tao-fit-display[#mitex("\\tau(X) := \\mathop{\\bf E} \\frac{1}{n} \\text{tr} X,")]]

#text("thus one takes both the normalised matrix trace and the probabilistic expectation, in order to arrive at a deterministic scalar (i.e. a complex number). As before, we see that ")#mi("{\\tau: L^{\\infty-} \\otimes M_n({\\bf C}) \\rightarrow {\\bf C}}")#text(" is a ")#mi("{*}")#text("-linear functional that maps ")#mi("{1}")#text(" to ")#mi("{1}")#text(". As we saw in ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(", the moment method for random matrices is based on a computation of the moments ")#mi("{\\tau(X^k) = \\mathop{\\bf E} \\frac{1}{n} \\text{tr} X^k}")#text(".")

#text("Let us now simultaneously abstract the above three examples, but reserving the right to impose some additional axioms as needed:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Non-commutative probability space, preliminary definition)")]#text(" A ")#emph[#text("non-commutative probability space")]#text(" (or more accurately, a ")#emph[#text("potentially non-commutative")]#text(" probability space) ")#mi("{({\\mathcal A},\\tau)}")#text(" will consist of a (potentially non-commutative) ")#mi("{*}")#text("-algebra ")#mi("{{\\mathcal A}}")#text(" of (potentially non-commutative) ")#emph[#text("random variables")]#text(" (or ")#emph[#text("observables")]#text(") with identity ")#mi("{1}")#text(", together with a ")#emph[#text("trace")]#text(" ")#mi("{\\tau: {\\mathcal A} \\rightarrow {\\bf C}}")#text(", which is a ")#mi("{*}")#text("-linear functional that maps ")#mi("{1}")#text(" to ")#mi("{1}")#text(". This trace will be required to obey a number of additional axioms which we will specify later in this set of notes.")
]

#text("This definition is not yet complete, because we have not fully decided on what axioms to enforce for these spaces, but for now let us just say that the three examples ")#mi("{(L^{\\infty-}, \\mathop{\\bf E})}")#text(", ")#mi("{(M_n({\\bf C}), \\frac{1}{n} \\text{tr})}")#text(", ")#mi("{(L^{\\infty-} \\otimes M_n({\\bf C}), \\mathop{\\bf E} \\frac{1}{n} \\text{tr})}")#text(" given above will obey these axioms and serve as model examples of non-commutative probability spaces. We mention that the requirement ")#mi("{\\tau(1)=1}")#text(" can be viewed as an abstraction of Kolmogorov’s axiom that the sample space has probability ")#mi("{1}")#text(".")

#text("To motivate the remaining axioms, let us try seeing how some basic concepts from the model examples carry over to the abstract setting.")

#text("Firstly, we recall that every scalar random variable ")#mi("{X \\in L^{\\infty-}}")#text(" has a probability distribution ")#mi("{\\mu_X}")#text(", which is a probability measure on the complex plane ")#mi("{{\\bf C}}")#text("; if ")#mi("{X}")#text(" is self-adjoint (i.e. real valued), so that ")#mi("{X=X^*}")#text(", then this distribution is supported on the real line ")#mi("{{\\bf R}}")#text(". The condition that ")#mi("{X}")#text(" lie in ")#mi("{L^{\\infty-}}")#text(" ensures that this measure is rapidly decreasing, in the sense that ")#tao-math("{\\int_{\\bf C} \\left|z\\right|^k\\ d\\mu_X(x) <\\infty}", block: false)#text(" for all ")#mi("{k}")#text(". The measure ")#mi("{\\mu_X}")#text(" is related to the moments ")#mi("{\\tau(X^k) = \\mathop{\\bf E} X^k}")#text(" by the formula ")#metadata(none) <tao-d0e6b086d025b69432da>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\tau(X^k) = \\int_{\\bf C} z^k\\ d\\mu_X(z)")]]



#text(" for ")#mi("{k=0,1,2,\\ldots}")#text(". In fact, one has the more general formula ")#metadata(none) <tao-57da0581d92cfc865647>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\tau(X^k (X^*)^l) = \\int_{\\bf C} z^k \\overline{z}^l\\ d\\mu_X(z)")]]



#text(" for ")#mi("{k,l=0,1,2,\\ldots}")#text(".")

#text("Similarly, every deterministic matrix ")#mi("{X \\in M_n({\\bf C})}")#text(" has a ")#emph[#text("empirical spectral distribution")]#text(" ")#mi("{\\mu_X = \\frac{1}{n} \\sum_{i=1}^n \\delta_{\\lambda_i(X)}}")#text(", which is a probability measure on the complex plane ")#mi("{{\\bf C}}")#text(". Again, if ")#mi("{X}")#text(" is self-adjoint, then distribution is supported on the real line ")#mi("{{\\bf R}}")#text(". This measure is related to the moments ")#mi("{\\tau(X^k) = \\frac{1}{n} \\text{tr} X^k}")#text(" by the same formula ")#link(<tao-d0e6b086d025b69432da>)[#text("(1)")]#text(" as in the case of scalar random variables. Because ")#mi("{n}")#text(" is finite, this measure is finitely supported (and in particular is rapidly decreasing). As for ")#link(<tao-57da0581d92cfc865647>)[#text("(2)")]#text(", the spectral theorem tells us that this formula holds when ")#mi("{X}")#text(" is normal (i.e. ")#mi("{XX^*=X^* X}")#text("), and in particular if ")#mi("{X}")#text(" is self-adjoint (of course, in this case ")#link(<tao-57da0581d92cfc865647>)[#text("(2)")]#text(" collapses to ")#link(<tao-d0e6b086d025b69432da>)[#text("(1)")]#text("), but is not true in general. Note that this subtlety does not appear in the case of scalar random variables because in this commutative setting, all elements are automatically normal.")

#text("Finally, for random matrices ")#mi("{X \\in L^{\\infty-} \\otimes M_n({\\bf C})}")#text(", we can form the ")#emph[#text("expected empirical spectral distribution")]#text(" ")#mi("{\\mu_X = \\mathop{\\bf E} \\frac{1}{n} \\sum_{i=1}^n \\delta_{\\lambda_i(X)}}")#text(", which is again a rapidly decreasing probability measure on ")#mi("{{\\bf C}}")#text(", which is supported on ")#mi("{{\\bf R}}")#text(" if ")#mi("{X}")#text(" is self-adjoint. This measure is again related to the moments ")#mi("{\\tau(X^k) = \\mathop{\\bf E} \\frac{1}{n} \\text{tr} X^k}")#text(" by the formula ")#link(<tao-d0e6b086d025b69432da>)[#text("(1)")]#text(", and also by ")#link(<tao-57da0581d92cfc865647>)[#text("(2)")]#text(" if ")#mi("{X}")#text(" is normal.")

#text("Now let us see whether we can set up such a spectral measure ")#mi("{\\mu_X}")#text(" for an element ")#mi("{X}")#text(" in an abstract non-commutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(". From the above examples, it is natural to try to define this measure through the formula ")#link(<tao-d0e6b086d025b69432da>)[#text("(1)")]#text(", or equivalently (by linearity) through the formula ")#metadata(none) <tao-9c10a262287a7265c8e2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("\\tau( P(X) ) = \\int_{\\bf C} P(z)\\ d\\mu_X(z)")]]



#text(" whenever ")#mi("{P: {\\bf C} \\rightarrow {\\bf C}}")#text(" is a polynomial with complex coefficients (note that one can define ")#mi("{P(X)}")#text(" without difficulty as ")#mi("{{\\mathcal X}}")#text(" is a ")#mi("{*}")#text("-algebra). In the normal case, one may hope to work with the more general formula ")#metadata(none) <tao-f8acf81463cf20fb099f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\tau( P(X,X^*) ) = \\int_{\\bf C} P(z,\\overline{z})\\ d\\mu_X(z)")]]



#text(" whenever ")#mi("{P: {\\bf C} \\times {\\bf C} \\rightarrow {\\bf C}}")#text(" is a polynomial of two complex variables (note that ")#mi("{P(X,X^*)}")#text(" can be defined unambiguously precisely when ")#mi("{X}")#text(" is normal).")

#text("It is tempting to apply the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(" to ")#link(<tao-9c10a262287a7265c8e2>)[#text("(3)")]#text(" to define the desired measure ")#mi("{\\mu_X}")#text(", perhaps after first using the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(" to pass from polynomials to continuous functions. However, there are multiple technical issues with this idea:")

#list(
[#text("In order for the polynomials to be dense in the continuous functions in the uniform topology on the support of ")#mi("{\\mu_X}")#text(", one needs the intended support ")#mi("{\\sigma(X)}")#text(" of ")#mi("{\\mu_X}")#text(" to be on the real line ")#mi("{{\\bf R}}")#text(", or else one needs to work with the formula ")#link(<tao-f8acf81463cf20fb099f>)[#text("(4)")]#text(" rather than ")#link(<tao-9c10a262287a7265c8e2>)[#text("(3)")]#text(". Also, one also needs the intended support ")#mi("{\\sigma(X)}")#text(" to be bounded for the Weierstrass approximation theorem to apply directly.")],
[#text("In order for the Riesz representation theorem to apply, the functional ")#mi("{P \\mapsto \\tau(P(X,X^*))}")#text(" (or ")#mi("{P \\mapsto \\tau(P(X))}")#text(") needs to be continuous in the uniform topology, thus one must be able to obtain a bound of the form ")#tao-math("{\\left|\\tau(P(X,X^*))\\right| \\leq C \\sup_{z \\in \\sigma(X)} \\left|P(z,\\overline{z})\\right|}", block: false)#text(" for some (preferably compact) set ")#mi("{\\sigma(X)}")#text(". (To get a probability measure, one in fact needs to have ")#mi("{C=1}")#text(".)")],
[#text("In order to get a probability measure rather than a signed measure, one also needs some non-negativity: ")#mi("{\\tau(P(X,X^*))}")#text(" needs to be non-negative whenever ")#mi("{P(z,\\overline{z}) \\geq 0}")#text(" for ")#mi("{z}")#text(" in the intended support ")#mi("{\\sigma(X)}")#text(".")]
)

#text("To resolve the non-negativity issue, we impose an additional axiom on the non-commutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(":")

#list(
[#text("(Non-negativity) For any ")#mi("{X \\in {\\mathcal A}}")#text(", we have ")#mi("{\\tau(X^* X) \\geq 0}")#text(". (Note that ")#mi("{X^* X}")#text(" is self-adjoint and so its trace ")#mi("{\\tau(X^* X)}")#text(" is necessarily a real number.)")]
)

#text("In the language of ")#link("http://en.wikipedia.org/wiki/Von_neumann_algebra")[#text("von Neumann algebras")]#text(", this axiom (together with the normalisation ")#mi("{\\tau(1)=1}")#text(") is essentially asserting that ")#mi("{\\tau}")#text(" is a state. Note that this axiom is obeyed by all three model examples, and is also consistent with ")#link(<tao-f8acf81463cf20fb099f>)[#text("(4)")]#text(". It is the noncommutative analogue of the Kolmogorov axiom that all events have non-negative probability.")

#text("With this axiom, we can now define a positive semi-definite ")#link("http://en.wikipedia.org/wiki/Inner_product")[#text("inner product")]#text(" ")#mi("{\\langle, \\rangle_{L^2(\\tau)}}")#text(" on ")#mi("{{\\mathcal A}}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("\\langle X, Y \\rangle_{L^2(\\tau)} := \\tau(X^* Y).")]]

#text("This obeys the usual axioms of an inner product, except that it is only positive semi-definite rather than positive definite. One can impose positive definiteness by adding an axiom that the trace ")#mi("{\\tau}")#text(" is ")#emph[#text("faithful")]#text(", which means that ")#mi("{\\tau(X^* X) = 0}")#text(" if and only if ")#mi("{X=0}")#text(". However, we will not need the faithfulness axiom here.")

#text("Without faithfulness, ")#mi("{{\\mathcal A}}")#text(" is a semi-definite inner product space with semi-norm")

#align(center)[#tao-fit-display[#tao-math("\\left\\| X \\right\\|_{L^2(\\tau)} := (\\langle X, X \\rangle_{L^2(\\tau)})^{1/2} = \\tau(X^* X)^{1/2}.", block: true)]]

#text("In particular, we have the ")#emph[#text("Cauchy-Schwarz inequality")]

#align(center)[#tao-fit-display[#tao-math("\\left|\\langle X,Y\\rangle_{L^2(\\tau)}\\right| \\leq \\left\\|X\\right\\|_{L^2(\\tau)} \\left\\|Y\\right\\|_{L^2(\\tau)}.", block: true)]]

#text("This leads to an important monotonicity:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2 (Monotonicity)")]#text(" Let ")#mi("{X}")#text(" be a self-adjoint element of a non-commutative probability space ")#mi("{({\\mathcal A}, \\tau)}")#text(". Show that we have the monotonicity relationships")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau(X^{2k-1})\\right|^{1/(2k-1)} \\leq \\left|\\tau(X^{2k})\\right|^{1/(2k)} \\leq \\left|\\tau(X^{2k+2})\\right|^{1/(2k+2)}", block: true)]]

#text("for any ")#mi("{k \\geq 0}")#text(".")
]

#text("As a consequence, we can define the ")#emph[#text("spectral radius")]#text(" ")#mi("{\\rho(X)}")#text(" of a self-adjoint element ")#mi("{X}")#text(" by the formula ")#metadata(none) <tao-6d52343a4117959a3f24>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\rho(X) := \\lim_{k \\rightarrow \\infty} \\left|\\tau(X^{2k})\\right|^{1/( 2k)},", block: true)]]



#text(" in which case we obtain the inequality ")#metadata(none) <tao-8d18a370320836101147>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left|\\tau(X^k)\\right| \\leq \\rho(X)^k", block: true)]]



#text(" for any ")#mi("{k=0,1,2,\\ldots}")#text(". We then say that a self-adjoint element is ")#emph[#text("bounded")]#text(" if its spectral radius is finite.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 3")]#text(" In the case of random variables, the spectral radius is the essential supremum ")#tao-math("{\\left\\|X\\right\\|_{L^\\infty}}", block: false)#text(", while for deterministic matrices, the spectral radius is the operator norm ")#tao-math("{\\left\\|X\\right\\|_{op}}", block: false)#text(". For random matrices, the spectral radius is the essential supremum ")#tao-math("{\\left\\|\\left\\|X\\right\\|_{op}\\right\\|_{L^\\infty}}", block: false)#text(" of the operator norm.")
]

#text("Guided by the model examples, we expect that a bounded self-adjoint element ")#mi("{X}")#text(" should have a spectral measure ")#mi("{\\mu_X}")#text(" supported on the interval ")#mi("{[-\\rho(X),\\rho(X)]}")#text(". But how to show this? It turns out that one can proceed by tapping the power of complex analysis, and introducing the ")#emph[#text("Stieltjes transform")]#text(" ")#metadata(none) <tao-6b54ec6b07392f1fa26d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("s_X(z) := \\tau( (X-z)^{-1} )")]]



#text(" for complex numbers ")#mi("{z}")#text(". Now, this transform need not be defined for all ")#mi("{z}")#text(" at present, because we do not know that ")#mi("{X-z}")#text(" is invertible in ")#mi("{{\\mathcal A}}")#text(". However, we can avoid this problem by working ")#emph[#text("formally")]#text(". Indeed, we have the formal ")#link("http://en.wikipedia.org/wiki/Neumann_series")[#text("Neumann series expansion")]

#align(center)[#tao-fit-display[#mitex("(X-z)^{-1} = - \\frac{1}{z} - \\frac{X}{z^2} - \\frac{X^2}{z^3} - \\ldots")]]

#text("which leads to the formal Laurent series expansion ")#metadata(none) <tao-e08b9711deab3b365111>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("s_X(z) = - \\sum_{k=0}^\\infty \\frac{\\tau(X^k)}{z^{k+1}}.")]]



#text(" If ")#mi("{X}")#text(" is bounded self-adjoint, then from ")#link(<tao-8d18a370320836101147>)[#text("(6)")]#text(" we see that this formal series actually converges in the region ")#tao-math("{\\left|z\\right| > \\rho(X)}", block: false)#text(". We will thus ")#emph[#text("define")]#text(" the Stieltjes transform ")#mi("{s_X(z)}")#text(" on the region ")#tao-math("{\\left|z\\right| > \\rho(X)}", block: false)#text(" by this series expansion ")#link(<tao-e08b9711deab3b365111>)[#text("(8)")]#text(", and then extend to as much of the complex plane as we can by analytic continuation. (There could in principle be some topological obstructions to this continuation, but we will soon see that the only place where singularities can occur is on the real interval ")#mi("{[-\\rho(X),\\rho(X)]}")#text(", and so no topological obstructions will appear. One can also work with the original definition ")#link(<tao-6b54ec6b07392f1fa26d>)[#text("(7)")]#text(" of the Stieltjes transform, but this requires imposing some additional analytic axioms on the non-commutative probability space, such as requiring that ")#mi("{{\\mathcal A}}")#text(" be a ")#mi("{C^*}")#text("-algebra or a von Neumann algebra, and I wish to avoid discussing these topics here as they are not the main focus of free probability theory.)")

#text("We now push the domain of definition of ")#mi("{s_X(z)}")#text(" into the disk ")#tao-math("{\\{ \\left|z\\right| \\leq \\rho(X)\\}}", block: false)#text(". We need some preliminary lemmas.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4")]#text(" Let ")#mi("{X}")#text(" be bounded self-adjoint. For any real number ")#mi("{R}")#text(", show that ")#mi("{\\rho(R^2+X^2) = R^2 + \\rho(X)^2}")#text(". (Hint: use ")#link(<tao-6d52343a4117959a3f24>)[#text("(5)")]#text(", ")#link(<tao-8d18a370320836101147>)[#text("(6)")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-8f26d6fe2a3dafd82808>#text(" Let ")#mi("{X}")#text(" be bounded normal. Show that ")#tao-math("{\\left|\\tau(X^k)\\right| \\leq \\tau( (X^* X)^k )^{1/2} \\leq \\rho(X^* X)^{k/2}}", block: false)#text(".")
]

#text("Now let ")#mi("{R}")#text(" be a large positive real number. The idea is to rewrite the (formal) Stieltjes transform ")#mi("{\\tau((X-z)^{-1})}")#text(" using the formal identity ")#metadata(none) <tao-5423c19c53f0f7dec0a0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(X-z)^{-1} = ((X+iR)-(z+iR))^{-1}")]]



#text(" and take Neumann series again to arrive at the formal expansion ")#metadata(none) <tao-c0c2bd9fd36db47d1005>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("s_X(z) = - \\sum_{k=0}^\\infty \\frac{\\tau((X+iR)^k)}{(z+iR)^{k+1}}.")]]



#text(" From the previous two exercises we see that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau((X+iR)^k)\\right| \\leq (R^2+\\rho(X)^2)^{k/2}", block: true)]]

#text("and so the above Laurent series converges for ")#tao-math("{\\left|z+iR\\right| > (R^2+\\rho(X)^2)^{1/2}}", block: false)#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Give a rigorous proof that the two series ")#link(<tao-e08b9711deab3b365111>)[#text("(8)")]#text(", ")#link(<tao-c0c2bd9fd36db47d1005>)[#text("(10)")]#text(" agree for ")#mi("{z}")#text(" large enough.")
]

#text("We have thus extended ")#mi("{s_X(z)}")#text(" analytically to the region ")#tao-math("{\\{ z: \\left|z+iR\\right| > (R^2+\\rho(X)^2)^{1/2}\\}}", block: false)#text(". Letting ")#mi("{R \\rightarrow \\infty}")#text(", we obtain an extension of ")#mi("{s_X(z)}")#text(" to the upper half-plane ")#mi("{\\{ z: \\text{Im}(z) > 0 \\}}")#text(". A similar argument (shifting by ")#mi("{-iR}")#text(" instead of ")#mi("{+iR}")#text(") gives an extension to the lower half-plane, thus defining ")#mi("{s_X(z)}")#text(" analytically everywhere except on the interval ")#mi("{[-\\rho(X),\\rho(X)]}")#text(".")

#text("On the other hand, it is not possible to analytically extend ")#mi("{s_X(z)}")#text(" to the region ")#tao-math("{\\{ z: \\left|z\\right| > \\rho(X) - \\varepsilon \\}}", block: false)#text(" for any ")#mi("{0 < \\varepsilon < \\rho(X)}")#text(". Indeed, if this were the case, then from the ")#link("http://en.wikipedia.org/wiki/Cauchy%27s_integral_formula")[#text("Cauchy integral formula")]#text(" (applied at infinity), we would have the identity")

#align(center)[#tao-fit-display[#tao-math("\\tau(X^k) = -\\frac{1}{2\\pi i} \\int_{\\left|z\\right|=R} s_{X}(z) z^{k}\\ dz", block: true)]]

#text("for any ")#mi("{R > \\rho(X)-\\varepsilon}")#text(", which when combined with ")#link(<tao-6d52343a4117959a3f24>)[#text("(5)")]#text(" implies that ")#mi("{\\rho(X) \\leq R}")#text(" for all such ")#mi("{R}")#text(", which is absurd. Thus the spectral radius ")#mi("{\\rho(X)}")#text(" can also be interpreted as the radius of the smallest ball centred at the origin outside of which the Stieltjes transform can be analytically continued.")

#text("Now that we have the Stieltjes transform everywhere outside of ")#mi("{[-\\rho(X),\\rho(X)]}")#text(", we can use it to derive an important bound (which will soon be superceded by ")#link(<tao-9c10a262287a7265c8e2>)[#text("(3)")]#text(", but will play a key role in the proof of that stronger statement):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 7 (Boundedness)")]#text(" ")#metadata(none) <tao-5e1cf42878df58fea7bf>#text(" Let ")#mi("{X}")#text(" be bounded self-adjoint, and let ")#mi("{P: {\\bf C} \\rightarrow {\\bf C}}")#text(" be a polynomial. Then")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau(P(X))\\right| \\leq \\sup_{x \\in [-\\rho(X),\\rho(X)]} \\left|P(x)\\right|.", block: true)]]
]

#emph[#text("Proof:")]#text(" (Sketch) We can of course assume that ")#mi("{P}")#text(" is non-constant, as the claim is obvious otherwise. From Exercise ")#link(<tao-8f26d6fe2a3dafd82808>)[#text("5")]#text(" (replacing ")#mi("{P}")#text(" with ")#mi("{P \\overline{P}}")#text(", where ")#mi("{\\overline{P}}")#text(" is the polynomial whose coefficients are the complex conjugate of that of ")#mi("{P}")#text(") we may reduce to the case when ")#mi("{P}")#text(" has real coefficients, so that ")#mi("{P(X)}")#text(" is self-adjoint. Since ")#mi("{X}")#text(" is bounded, it is not difficult (using ")#link(<tao-6d52343a4117959a3f24>)[#text("(5)")]#text(", ")#link(<tao-8d18a370320836101147>)[#text("(6)")]#text(") to show that ")#mi("{P(X)}")#text(" is bounded also (Exercise!).")

#text("As ")#mi("{P(X)}")#text(" is bounded self-adjoint, it has a Stieltjes transform defined outside of ")#mi("{[-\\rho(P(X)),\\rho(P(X))]}")#text(", which for large ")#mi("{z}")#text(" is given by the formula ")#metadata(none) <tao-c31df101a9843c03ea3e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("s_{P(X)}(z) = - \\sum_{k=0}^\\infty \\frac{\\tau(P(X)^k)}{z^k}.")]]



#text(" By the previous discussion, to establish the proposition it will suffice to show that the Stieltjes transform can be continued to the domain")

#align(center)[#tao-fit-display[#tao-math("\\Omega := \\{ z \\in {\\bf C}: z > \\sup_{x \\in [-\\rho(X),\\rho(X)]} \\left|P(x)\\right| \\}.", block: true)]]

#text("For this, we observe the partial fractions decomposition")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{P(w)-z} = \\sum_{\\zeta: P(\\zeta)=z} \\frac{P^{\\prime}(\\zeta)^{-1}}{w-\\zeta}")]]

#text("of ")#mi("{(P(w)-z)^{-1}}")#text(" into linear combinations of ")#mi("{(w-\\zeta)^{-1}}")#text(", at least when the roots of ")#mi("{P-z}")#text(" are simple. Thus, formally, at least, we have the identity")

#align(center)[#tao-fit-display[#mitex("s_{P(X)}(z) = \\sum_{\\zeta: P(\\zeta)=z} \\frac{1}{P^{\\prime}(\\zeta)} s_X(\\zeta).")]]

#text("One can verify this identity is consistent with ")#link(<tao-c31df101a9843c03ea3e>)[#text("(11)")]#text(" for ")#mi("{z}")#text(" sufficiently large. (Exercise! ")#emph[#text("Hint:")]#text(" First do the case when ")#mi("{X}")#text(" is a scalar, then expand in Taylor series and compare coefficients, then use the agreement of the Taylor series to do the general case.)")

#text("If ")#mi("{z}")#text(" is in the domain ")#mi("{\\Omega}")#text(", then all the roots ")#mi("{\\zeta}")#text(" of ")#mi("{P(\\zeta)=z}")#text(" lie outside the interval ")#mi("{[-\\rho(X),\\rho(X)]}")#text(". So we can use the above formula as a ")#emph[#text("definition")]#text(" of ")#mi("{s_{P(X)}(z)}")#text(", at least for those ")#mi("{z \\in \\Omega}")#text(" for which the roots of ")#mi("{P-z}")#text(" are simple; but there are only finitely many exceptional ")#mi("{z}")#text(" (arising from zeroes of ")#mi("{P^{\\prime}}")#text(") and one can check (Exercise! ")#emph[#text("Hint:")]#text(" use the analytic nature of ")#mi("{s_X}")#text(" and the residue theoremto rewrite parts of ")#mi("{s_{P(X)}(z)}")#text(" as a contour integral.) that the singularities here are removable. It is easy to see (Exercise!) that ")#mi("{s_{P(X)}}")#text(" is holomorphic outside of these removable singularities, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8")]#text(" Fill in the steps marked (Exercise!) in the above proof.")
]

#text("From Proposition ")#link(<tao-5e1cf42878df58fea7bf>)[#text("7")]#text(" and the ")#link("http://en.wikipedia.org/wiki/Weierstrass_approximation_theorem")[#text("Weierstrass approximation theorem")]#text(", we see that the linear functional ")#mi("{P \\mapsto \\tau(P(X))}")#text(" can be uniquely extended to a bounded linear functional on ")#mi("{C([-\\rho(X),\\rho(X)])}")#text(", with an operator norm ")#mi("{1}")#text(". Applying the ")#link("http://en.wikipedia.org/wiki/Riesz_representation_theorem")[#text("Riesz representation theorem")]#text(", we thus can find a unique ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" (or equivalently, Borel measure) ")#mi("{\\mu_X}")#text(" on ")#mi("{[-\\rho(X),\\rho(X)]}")#text(" of ")#link("http://en.wikipedia.org/wiki/Total_variation")[#text("total variation")]#text(" ")#mi("{1}")#text(" obeying the identity ")#link(<tao-9c10a262287a7265c8e2>)[#text("(3)")]#text(" for all ")#mi("{P}")#text(". In particular, setting ")#mi("{P=1}")#text(" see that ")#mi("{\\mu_X}")#text(" has total mass ")#mi("{1}")#text("; since it also has total variation ")#mi("{1}")#text(", it must be a probability measure. We have thus shown the fundamental")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 9 (Spectral theorem for bounded self-adjoint elements)")]#text(" Let ")#mi("{X}")#text(" be a bounded self-adjoint element of a non-commutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(". Then there exists a unique Borel probability measure ")#mi("{\\mu_X}")#text(" on ")#mi("{[-\\rho(X),\\rho(X)]}")#text(" (known as the ")#emph[#text("spectral measure")]#text(" of ")#mi("{X}")#text(") such that ")#link(<tao-9c10a262287a7265c8e2>)[#text("(3)")]#text(" holds for all polynomials ")#mi("{P: {\\bf C} \\rightarrow {\\bf C}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" If one assumes some completeness properties of the non-commutative probability space, such as that ")#mi("{{\\mathcal A}}")#text(" is a ")#mi("{C^*}")#text("-algebra or a von Neumann algebra, one can use this theorem to meaningfully define ")#mi("{F(X)}")#text(" for other functions ")#mi("{F: [-\\rho(X),\\rho(X)] \\rightarrow {\\bf C}}")#text(" than polynomials; specifically, one can do this for continuous functions ")#mi("{F}")#text(" if ")#mi("{{\\mathcal A}}")#text(" is a ")#mi("{C^*}")#text("-algebra, and for ")#mi("{L^\\infty(\\mu_X)}")#text(" functions ")#mi("{F}")#text(" if ")#mi("{{\\mathcal A}}")#text(" is a von Neumann algebra. Thus for instance we can start to define absolute values ")#tao-math("{\\left|X\\right|}", block: false)#text(", or square roots ")#tao-math("{\\left|X\\right|^{1/2}}", block: false)#text(", etc.. Such an assignment ")#mi("{F \\mapsto F(X)}")#text(" is known as a ")#link("http://en.wikipedia.org/wiki/Functional_calculus")[#text("functional calculus")]#text("; it can be used for instance to go back and make rigorous sense of the formula ")#link(<tao-6b54ec6b07392f1fa26d>)[#text("(7)")]#text(". A functional calculus is a very convenient tool to have in operator algebra theory, and for that reason one often ")#emph[#text("completes")]#text(" a non-commutative probability space into a ")#mi("{C^*}")#text("-algebra or von Neumann algebra, much as how it is often convenient to complete the rationals and work instead with the reals. However, we will proceed here instead by working with a (possibly incomplete) non-commutative probability space, and working primarily with ")#emph[#text("formal")]#text(" expressions (e.g. formal power series in ")#mi("{z}")#text(") without trying to evaluate such expressions in some completed space. We can get away with this because we will be working exclusively in situations in which the spectrum of a random variable can be reconstructed exactly from its moments (which is in particular true in the case of bounded random variables). For unbounded random variables, one must usually instead use the full power of functional analysis, and work with the spectral theory of unbounded operators on Hilbert spaces.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11")]#text(" Let ")#mi("{X}")#text(" be a bounded self-adjoint element of a non-commutative probability space, and let ")#mi("{\\mu_X}")#text(" as the spectral measure of ")#mi("{X}")#text(". Establish the formula")

#align(center)[#tao-fit-display[#mitex("s_X(z) = \\int_{[-\\rho(X),\\rho(X)]} \\frac{1}{x-z}\\ d\\mu_X(x)")]]

#text("for all ")#mi("{z \\in {\\bf C} \\backslash [-\\rho(X),\\rho(X)]}")#text(". Conclude that the ")#link("http://en.wikipedia.org/wiki/Support_(measure_theory)")[#text("support")]#text(" of the spectral measure ")#mi("{\\mu_X}")#text(" must contain at least one of the two points ")#mi("{-\\rho(X), \\rho(X)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Let ")#mi("{X}")#text(" be a bounded self-adjoint element of a non-commutative probability space with faithful trace. Show that ")#mi("{\\rho(X)=0}")#text(" if and only if ")#mi("{X=0}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 13")]#text(" It is possible to also obtain a spectral theorem for bounded normal elements along the lines of the above theorem (with ")#mi("{\\mu_X}")#text(" now supported in a disk rather than in an interval, and with ")#link(<tao-9c10a262287a7265c8e2>)[#text("(3)")]#text(" replaced by ")#link(<tao-f8acf81463cf20fb099f>)[#text("(4)")]#text("), but this is somewhat more complicated to show (basically, one needs to extend the self-adjoint spectral theorem to a pair of commuting self-adjoint elements, which is a little tricky to show by complex-analytic methods, as one has to use several complex variables).")
]

#text("The spectral theorem more or less completely describes the behaviour of a single (bounded self-adjoint) element ")#mi("{X}")#text(" in a non-commutative probability space. As remarked above, it can also be extended to study multiple commuting self-adjoint elements. However, when one deals with multiple ")#emph[#text("non-commuting")]#text(" elements, the spectral theorem becomes inadequate (and indeed, it appears that in general there is no usable substitute for this theorem). However, we can begin making a little bit of headway if we assume as a final (optional) axiom a very weak form of commutativity in the trace:")

#list(
[#text("(Trace) For any two elements ")#mi("{X, Y}")#text(", we have ")#mi("{\\tau(XY)=\\tau(YX)}")#text(".")]
)

#text("Note that this axiom is obeyed by all three of our model examples. From this axiom, we can cyclically permute products in a trace, e.g. ")#mi("{\\tau(XYZ)=\\tau(YZX)=\\tau(ZXY)}")#text(". However, we cannot take non-cyclic permutations; for instance, ")#mi("{\\tau(XYZ)}")#text(" and ")#mi("{\\tau(XZY)}")#text(" are distinct in general. This axiom is a trivial consequence of the commutative nature of the complex numbers in the classical setting, but can play a more non-trivial role in the non-commutative setting. It is however possible to develop a large part of free probability without this axiom, if one is willing instead to work in the category of von Neumann algebras. Thus, we shall leave it as an optional axiom:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 14 (Non-commutative probability space, final definition)")]#text(" ")#metadata(none) <tao-6e6c40bb2448ddfe4588>#text(" A ")#emph[#text("non-commutative probability space")]#text(" ")#mi("{({\\mathcal A},\\tau)}")#text(" consists of a ")#mi("{*}")#text("-algebra ")#mi("{{\\mathcal A}}")#text(" with identity ")#mi("{1}")#text(", together with a ")#mi("{*}")#text("-linear functional ")#mi("{\\tau: {\\mathcal A} \\rightarrow {\\bf C}}")#text(", that maps ")#mi("{1}")#text(" to ")#mi("{1}")#text(" and obeys the non-negativity axiom. If ")#mi("{\\tau}")#text(" obeys the trace axiom, we say that the non-commutative probability space is ")#emph[#text("tracial")]#text(". If ")#mi("{\\tau}")#text(" obeys the faithfulness axiom, we say that the non-commutative probability space is ")#emph[#text("faithful")]#text(".")
]

#text("From this new axiom and the Cauchy-Schwarz inequality we can now get control on products of several non-commuting elements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15")]#text(" ")#metadata(none) <tao-cd42b60b78e8b2f54fe7>#text(" Let ")#mi("{X_1,\\ldots,X_k}")#text(" be bounded self-adjoint elements of a tracial non-commutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(". Show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\tau( X_1^{m_1} \\ldots X_k^{m_k} )\\right| \\leq \\rho(X_1)^{m_1} \\ldots \\rho(X_k)^{m_k}", block: true)]]

#text("for any non-negative integers ")#mi("{m_1,\\ldots,m_k}")#text(". (")#emph[#text("Hint:")]#text(" Induct on ")#mi("{k}")#text(", and use Cauchy-Schwarz to split up the product as evenly as possible, using cyclic permutations to reduce the complexity of the resulting expressions.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16")]#text(" Let ")#mi("{{\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" be those elements ")#mi("{X}")#text(" in a tracial non-commutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(" whose real and imaginary parts ")#mi("{\\text{Re}(X) := \\frac{X+X^*}{2}}")#text(", ")#mi("{\\text{Im}(X) := \\frac{X-X^*}{2i}}")#text(" are bounded and self-adjoint; we refer to such elements simply as ")#emph[#text("bounded")]#text(" elements. Show that this is a sub-*-algebra of ")#mi("{{\\mathcal A}}")#text(".")
]

#text("This allows one to perform the following ")#link("http://en.wikipedia.org/wiki/Gelfand%E2%80%93Naimark%E2%80%93Segal_construction")[#text("Gelfand-Naimark-Segal (GNS) construction")]#text(". Recall that ")#mi("{{\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" has a positive semi-definite inner product ")#mi("{\\langle,\\rangle_{L^2(\\tau)}}")#text(". We can perform the Hilbert space completion of this inner product space (quotienting out by the elements of zero norm), leading to a complex Hilbert space ")#mi("{L^2(\\tau)}")#text(" into which ")#mi("{{\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" can be mapped as a dense subspace by an isometry ")#mi("{\\iota: {\\mathcal A} \\cap L^\\infty(\\tau) \\rightarrow L^2(\\tau)}")#text(". (This isometry is injective when ")#mi("{{\\mathcal A}}")#text(" is faithful, but will have a non-trivial kernel otherwise.) The space ")#mi("{{\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" acts on itself by multiplication, and thus also acts on the dense subspace ")#mi("{\\iota({\\mathcal A} \\cap L^\\infty(\\tau))}")#text(" of ")#mi("{L^2(\\tau)}")#text(". We would like to extend this action to all of ")#mi("{L^2(\\tau)}")#text(", but this requires an additional estimate:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 17")]#text(" ")#metadata(none) <tao-b4c5ae2ae961fe88d128>#text(" Let ")#mi("{({\\mathcal A},\\tau)}")#text(" be a tracial non-commutative probability space. If ")#mi("{X, Y \\in {\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" with ")#mi("{X}")#text(" self-adjoint, then")

#align(center)[#tao-fit-display[#tao-math("\\left\\| XY \\right\\|_{L^2(\\tau)} \\leq \\rho(X) \\left\\|Y\\right\\|_{L^2(\\tau)}.", block: true)]]
]

#emph[#text("Proof:")]#text(" Squaring and cyclically permuting, it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\tau( Y^* X^2 Y ) \\leq \\rho(X)^2 \\tau( Y^* Y ).")]]

#text("Let ")#mi("{\\varepsilon > 0}")#text(" be arbitrary. By Weierstrass approximation, we can find a polynomial ")#mi("{P}")#text(" with real coefficients such that ")#mi("{x^2 + P(x)^2 = \\rho(X)^2 + O(\\varepsilon)}")#text(" on the interval ")#mi("{[-\\rho(X),\\rho(X)]}")#text(". By Proposition ")#link(<tao-5e1cf42878df58fea7bf>)[#text("7")]#text(", we can thus write ")#mi("{X^2 + P(X)^2 = \\rho(X)^2 + E}")#text(" where ")#mi("{E}")#text(" is self-adjoint with ")#mi("{\\rho(E) = O(\\varepsilon)}")#text(". Multiplying on the left by ")#mi("{Y^*}")#text(" and on the right by ")#mi("{Y}")#text(" and taking traces, we obtain")

#align(center)[#tao-fit-display[#mitex("\\tau( Y^* X^2 Y ) + \\tau( Y^* P(X)^2 Y ) \\leq \\rho(X)^2 \\tau(Y^* Y) + \\tau( Y^* E Y ).")]]

#text("By non-negativity, ")#mi("{\\tau(Y^* P(X)^2 Y) \\geq 0}")#text(". By Exercise ")#link(<tao-cd42b60b78e8b2f54fe7>)[#text("15")]#text(", we have ")#mi("{\\tau( Y^* E Y ) = O_Y(\\varepsilon)}")#text(". Sending ")#mi("{\\varepsilon \\rightarrow 0}")#text(" we obtain the claim. ")#mi("\\Box")

#text("As a consequence, we see that the self-adjoint elements ")#mi("{X}")#text(" of ")#mi("{{\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" act in a bounded manner on all of ")#mi("{L^2(\\tau)}")#text(", and so on taking real and imaginary parts, we see that the same is true for the non-self-adjoint elements too. Thus we can associate to each ")#mi("{X \\in L^\\infty(\\tau)}")#text(" a bounded linear transformation ")#mi("{\\overline{X} \\in B(L^2(\\tau))}")#text(" on the Hilbert space ")#mi("{L^2(\\tau)}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Gelfand-Naimark theorem)")]#text(" Show that the map ")#mi("{X \\mapsto \\overline{X}}")#text(" is a ")#mi("{*}")#text("-isomorphism from ")#mi("{{\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" to a ")#mi("{*}")#text("-subalgebra of ")#mi("{B(L^2(\\tau))}")#text(", and that one has the representation")

#align(center)[#tao-fit-display[#mitex("\\tau(X) = \\langle e, \\overline{X} e \\rangle")]]

#text("for any ")#mi("{X \\in L^\\infty(\\tau)}")#text(", where ")#mi("{e}")#text(" is the unit vector ")#mi("{e := \\iota(1)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 19")]#text(" The Gelfand-Naimark theorem required the tracial hypothesis only to deal with the error ")#mi("{E}")#text(" in the proof of Lemma ")#link(<tao-b4c5ae2ae961fe88d128>)[#text("17")]#text(". One can also establish this theorem without this hypothesis, by assuming instead that the non-commutative space is a ")#mi("{C^*}")#text("-algebra; this provides a continuous functional calculus, so that we can replace ")#mi("{P}")#text(" in the proof of Lemma ")#link(<tao-b4c5ae2ae961fe88d128>)[#text("17")]#text(" by a continuous function and dispense with ")#mi("{E}")#text(" altogether. This formulation of the Gelfand-Naimark theorem is the one which is usually seen in the literature.")
]

#text("The ")#link("http://en.wikipedia.org/wiki/Gelfand-Naimark_theorem")[#text("Gelfand-Naimark theorem")]#text(" identifies ")#mi("{{\\mathcal A} \\cap L^\\infty(\\tau)}")#text(" with a ")#mi("{*}")#text("-subalgebra of ")#mi("{B(L^2(\\tau))}")#text(". The closure of this ")#mi("{*}")#text("-subalgebra in the ")#link("http://en.wikipedia.org/wiki/Weak_operator_topology")[#text("weak operator topology")]#text(" is then a ")#link("http://en.wikipedia.org/wiki/Von_Neumann_algebra")[#text("von Neumann algebra")]#text(", which we denote as ")#mi("{L^\\infty(\\tau)}")#text(". As a consequence, we see that non-commutative probability spaces are closely related to von Neumann algebras (equipped with a tracial state ")#mi("{\\tau}")#text("). However, we refrain from identifying the former completely with the latter, in order to allow ourselves the freedom to work with such spaces as ")#mi("{L^{\\infty-}}")#text(", which is almost but not quite a von Neumann algebra. Instead, we use the following looser (and more algebraic) definition in Definition ")#link(<tao-6e6c40bb2448ddfe4588>)[#text("14")]#text(".")

#heading(level: 1)[#strong[#text(" — 2. Limits of non-commutative random variables — ")]]

#text("One benefit of working in an abstract setting is that it becomes easier to take certain types of limits. For instance, it is intuitively obvious that the cyclic groups ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" are “converging” in some sense to the integer group ")#mi("{{\\bf Z}}")#text(". This convergence can be formalised by selecting a distinguished generator ")#mi("{e}")#text(" of all groups involved (")#mi("{1 \\text{ mod } N}")#text(" in the case of ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(", and ")#mi("{1}")#text(" in the case of the integers ")#mi("{{\\bf Z}}")#text("), and noting that the set of relations involving this generator in ")#mi("{{\\bf Z}/N{\\bf Z}}")#text(" (i.e. the relations ")#mi("{ne=0}")#text(" when ")#mi("{n}")#text(" is divisible by ")#mi("{N}")#text(") converge in a pointwise sense to the set of relations involving this generator in ")#mi("{{\\bf Z}}")#text(" (i.e. the empty set). Here, to see the convergence, we viewed a group abstractly via the relations between its generators, rather than on a concrete realisation of a group as (say) residue classes modulo ")#mi("{N}")#text(". (For more discussion of this notion of convergence for finitely generated groups, see ")#link("https://terrytao.wordpress.com/2008/08/30/the-correspondence-principle-and-finitary-ergodic-theory/")[#text("this earlier blog post")]#text(".)")

#text("We can similarly define convergence of random variables in non-commutative probability spaces as follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 20 (Convergence)")]#text(" Let ")#mi("{({\\mathcal A}_n, \\tau_n)}")#text(" be a sequence of non-commutative probability spaces, and let ")#mi("{({\\mathcal A}_\\infty, \\tau_\\infty)}")#text(" be an additional non-commutative space. For each ")#mi("{n}")#text(", let ")#mi("{X_{n,1},\\ldots,X_{n,k}}")#text(" be a sequence of random variables in ")#mi("{{\\mathcal A}_n}")#text(", and let ")#mi("{X_{\\infty,1},\\ldots,X_{\\infty,k}}")#text(" be a sequence of random variables in ")#mi("{{\\mathcal A}_\\infty}")#text(". We say that ")#mi("{X_{n,1},\\ldots,X_{n,k}}")#text(" converges ")#emph[#text(" in the sense of moments")]#text(" to ")#mi("{X_{\\infty,1},\\ldots,X_{\\infty,k}}")#text(" if we have")

#align(center)[#tao-fit-display[#mitex("\\tau_n( X_{n,i_1} \\ldots X_{n,i_m} ) \\rightarrow \\tau_\\infty( X_{\\infty,i_1} \\ldots X_{\\infty,i_m} )")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for any sequence ")#mi("{i_1,\\ldots,i_m \\in \\{1,\\ldots,k\\}}")#text(". We say that ")#mi("{X_{n,1},\\ldots,X_{n,k}}")#text(" converge ")#emph[#text(" in the sense of ")#mi("{*}")#text("-moments")]#text(" to ")#mi("{X_{\\infty,1},\\ldots,X_{\\infty,k}}")#text(" if ")#mi("{X_{n,1},\\ldots,X_{n,k},X^*_{n,1},\\ldots,X^*_{n,k}}")#text(" converges in the sense of moments to ")#mi("{X_{\\infty,1},\\ldots,X_{\\infty,k},X^*_{\\infty,1},\\ldots,X^*_{\\infty,k}}")#text(".")

#text("If ")#mi("{X_1,\\ldots,X_k}")#text(" (viewed as a constant ")#mi("{k}")#text("-tuple in ")#mi("{n}")#text(") converges in the sense of moments (resp. ")#mi("{*}")#text("-moments) to ")#mi("{Y_1,\\ldots,Y_k}")#text(", we say that ")#mi("{X_1,\\ldots,X_k}")#text(" and ")#mi("{Y_1,\\ldots,Y_k}")#text(" have ")#emph[#text("matching joint moments")]#text(" (resp. ")#emph[#text("matching joint ")#mi("{*}")#text("-moments")]#text(").")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 21")]#text(" If ")#mi("{X_n,Y_n}")#text(" converge in the sense of moments to ")#mi("{X_\\infty, Y_\\infty}")#text(" then we have for instance that")

#align(center)[#tao-fit-display[#mitex("\\tau_n(X_n Y_n^k X_n) \\rightarrow \\tau_\\infty(X_\\infty Y_\\infty^k X_\\infty)")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" for each ")#mi("{k}")#text(", while if they converge in the stronger sense of ")#mi("{*}")#text("-moments then we obtain more limits, such as")

#align(center)[#tao-fit-display[#mitex("\\tau_n(X_n Y_n^k X_n^*) \\rightarrow \\tau_\\infty(X_\\infty Y_\\infty^k X_\\infty^*).")]]

#text("Note however that no uniformity in ")#mi("{k}")#text(" is assumed for this convergence; in particular, if ")#mi("{k}")#text(" varies in ")#mi("{n}")#text(" (e.g. if ")#mi("{ k= O(\\log n)}")#text("), there is now no guarantee that one still has convergence.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 22")]#text(" When the underlying objects ")#mi("{X_{n,1},\\ldots,X_{n,k}}")#text(" and ")#mi("{X_1,\\ldots,X_k}")#text(" are self-adjoint, then there is no distinction between convergence in moments and convergence in ")#mi("{*}")#text("-moments. However, for non-self-adjoint variables, the latter type of convergence is far stronger, and the former type is usually too weak to be of much use, even in the commutative setting. For instance, let ")#mi("{X}")#text(" be a classical random variable drawn uniformly at random from the unit circle ")#tao-math("{\\{ z \\in {\\bf C}: \\left|z\\right|=1\\}}", block: false)#text(". Then the constant sequence ")#mi("{X_n=X}")#text(" has all the same moments as the zero random variable ")#mi("{0}")#text(", and thus converges in the sense of moments to zero, but does not converge in the ")#mi("{*}")#text("-moment sense to zero.")

#text("It is also clear that if we require that ")#mi("{{\\mathcal A}_\\infty}")#text(" be generated by ")#mi("{X_{\\infty,1},\\ldots,X_{\\infty,k}}")#text(" in the ")#mi("{*}")#text("-algebraic sense (i.e. every element of ")#mi("{{\\mathcal A}_\\infty}")#text(" is a polynomial combination of ")#mi("{X_{\\infty,1},\\ldots,X_{\\infty,k}}")#text(" and their adjoints) then a limit in the sense of ")#mi("{*}")#text("-moments, if it exists, is unique up to matching joint ")#mi("{*}")#text("-moments.")
]

#text("For a sequence ")#mi("{X_n}")#text(" of a single, uniformly bounded, self-adjoint element, convergence in moments is equivalent to convergence in distribution:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23")]#text(" Let ")#mi("{X_n \\in {\\mathcal A}_n}")#text(" be a sequence of self-adjoint elements in non-commutative probability spaces ")#mi("{({\\mathcal A}_n, \\tau_n)}")#text(" with ")#mi("{\\rho(X_n)}")#text(" uniformly bounded, and let ")#mi("{X_\\infty \\in {\\mathcal A}_\\infty}")#text(" be another bounded self-adjoint element in a non-commutative probability space ")#mi("{({\\mathcal A}_\\infty, \\tau_\\infty)}")#text(". Show that ")#mi("{X_n}")#text(" converges in moments to ")#mi("{X_\\infty}")#text(" if and only if the spectral measure ")#mi("{\\mu_{X_n}}")#text(" converges in the vague topology to ")#mi("{\\mu_{X_\\infty}}")#text(".")
]

#text("Thus, for instance, one can rephrase the Wigner semi-circular law (in the convergence in expectation formulation) as the assertion that a sequence ")#mi("{M_n \\in L^{\\infty-} \\otimes M_n({\\bf C})}")#text(" of Wigner random matrices with (say) subgaussian entries of mean zero and variance one, when viewed as elements of the non-commutative probability space ")#mi("{(L^{\\infty-} \\otimes M_n({\\bf C}), \\mathop{\\bf E} \\frac{1}{n} \\text{tr})}")#text(", will converge to any bounded self-adjoint element ")#mi("{u}")#text(" of a non-commutative probability space with spectral measure given by the semi-circular distribution ")#mi("{\\mu_{sc} := \\frac{1}{2\\pi} (4-x^2)_+^{1/2}\\ dx}")#text(". Such elements are known as ")#emph[#text("semi-circular elements")]#text(". Here are some easy examples of semi-circular elements:")

#list(
[#text("A classical real random variable ")#mi("{u}")#text(" drawn using the probability measure ")#mi("{\\mu_{sc}}")#text(".")],
[#text("The identity function ")#mi("{x \\mapsto x}")#text(" in the Lebesgue space ")#mi("{L^\\infty(d\\mu_{sc})}")#text(", endowed with the trace ")#mi("{\\tau(f) := \\int_{\\bf R} f\\ d\\mu_{sc}}")#text(".")],
[#text("The function ")#mi("{\\theta \\mapsto 2\\cos\\theta}")#text(" in the Lebesgue space ")#mi("{L^\\infty([0,\\pi], \\frac{2}{\\pi} \\sin^2 \\theta\\ d\\theta)}")#text(".")]
)

#text("Here is a more interesting example of a semi-circular element:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24")]#text(" Let ")#mi("{({\\mathcal A},\\tau)}")#text(" be the non-commutative space consisting of bounded operators ")#mi("{B(\\ell^2({\\bf N}))}")#text(" on the natural numbers with trace ")#mi("{\\tau(X) := \\langle e_0, Xe_0 \\rangle_{\\ell^2({\\bf N})}}")#text(", where ")#mi("{e_0,e_1,\\ldots}")#text(" is the standard basis of ")#mi("{\\ell^2({\\bf N})}")#text(". Let ")#mi("{U: e_n \\mapsto e_{n+1}}")#text(" be the right shift on ")#mi("{\\ell^2({\\bf N})}")#text(". Show that ")#mi("{U+U^*}")#text(" is a semicircular operator. (")#emph[#text("Hint:")]#text(" one way to proceed here is to use Fourier analysis to identify ")#mi("{\\ell^2({\\bf N})}")#text(" with the space of odd functions ")#mi("{\\theta \\mapsto f(\\theta)}")#text(" on ")#mi("{{\\bf R}/2\\pi{\\bf Z}}")#text(", with ")#mi("{U}")#text(" being the operator that maps ")#mi("{\\sin(n\\theta)}")#text(" to ")#mi("{\\sin((n+1)\\theta)}")#text("; show that ")#mi("{U+U^*}")#text(" is then the operation of multiplication by ")#mi("{2\\cos \\theta}")#text(".) One can also interpret ")#mi("{U}")#text(" as a ")#emph[#text("creation operator")]#text(" in a ")#link("http://en.wikipedia.org/wiki/Fock_space")[#text("exercise")]#text(" when ")#mi("{k}")#text(" is odd. Note that this provides a (very) slightly different proof of the semi-circular law from that given from the moment method in ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text(".")
]

#text("Because we are working in such an abstract setting with so few axioms, limits exist in abundance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25")]#text(" For each ")#mi("{n}")#text(", let ")#mi("{X_{n,1},\\ldots,X_{n,k}}")#text(" be bounded self-adjoint elements of a tracial non-commutative space ")#mi("{({\\mathcal A}_n, \\tau_n)}")#text(". Suppose that the spectral radii ")#mi("{\\rho(X_{n,1}),\\ldots,\\rho(X_{n,k})}")#text(" are uniformly bounded in ")#mi("{n}")#text(". Show that there exists a subsequence ")#mi("{n_j}")#text(" and bounded self-adjoint elements ")#mi("{X_1,\\ldots,X_k}")#text(" of a tracial non-commutative space ")#mi("{({\\mathcal A}, \\tau)}")#text(" such that ")#mi("{X_{n_j,1}, \\ldots, X_{n_j,k}}")#text(" converge in moments to ")#mi("{X_1,\\ldots,X_k}")#text(" as ")#mi("{j \\rightarrow \\infty}")#text(". (Hint: use the Bolzano-Weierstrass theorem and the Arzelá-Ascoli diagonalisation trick to obtain a subsequence in which each of the joint moments of ")#mi("{X_{n_j,1},\\ldots,X_{n_j,k}}")#text(" converge as ")#mi("{j \\rightarrow \\infty}")#text(". Use these moments to build a noncommutative probability space.)")
]

#heading(level: 1)[#strong[#text(" — 3. Free independence — ")]]

#text("We now come to the fundamental concept in free probability theory, namely that of ")#link("http://en.wikipedia.org/wiki/Free_independence")[#text("free independence")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 26 (Free independence)")]#text(" A collection ")#mi("{X_1,\\ldots,X_k}")#text(" of random variables in a non-commutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(" is ")#emph[#text("freely independent")]#text(" (or ")#emph[#text("free")]#text(" for short) if one has")

#align(center)[#tao-fit-display[#mitex("\\tau( (P_1( X_{i_1} ) - \\tau(P_1(X_{i_1}))) \\ldots (P_m(X_{i_m}) - \\tau(P_m(X_{i_m}))) ) = 0")]]

#text("whenever ")#mi("{P_1,\\ldots,P_m}")#text(" are polynomials and ")#mi("{i_1,\\ldots,i_m \\in \\{1,\\ldots,k\\}}")#text(" are indices with no two adjacent ")#mi("{i_j}")#text(" equal.")

#text("A sequence ")#mi("{X_{n,1},\\ldots,X_{n,k}}")#text(" of random variables in a non-commutative probability space ")#mi("{({\\mathcal A}_n,\\tau_n)}")#text(" is ")#emph[#text("asymptotically freely independent")]#text(" (or ")#emph[#text("asymptotically free")]#text(" for short) if one has")

#align(center)[#tao-fit-display[#mitex("\\tau_n( (P_1( X_{n,i_1} ) - \\tau(P_1(X_{n,i_1}))) \\ldots (P_m(X_{n,i_m}) - \\tau(P_m(X_{n,i_m}))) )")]]

#align(center)[#tao-fit-display[#mitex("\\rightarrow 0")]]

#text("as ")#mi("{n \\rightarrow \\infty}")#text(" whenever ")#mi("{P_1,\\ldots,P_m}")#text(" are polynomials and ")#mi("{i_1,\\ldots,i_m \\in \\{1,\\ldots,k\\}}")#text(" are indices with no two adjacent ")#mi("{i_j}")#text(" equal.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 27")]#text(" The above example describes freeness of collections of random variables ")#mi("{{\\mathcal A}}")#text(". One can more generally define freeness of collections of subalgebras of ")#mi("{{\\mathcal A}}")#text(", which in some sense is the more natural concept from a category-theoretic perspective, but we will not need this concept here. (See e.g. ")#link("http://www.dma.ens.fr/~biane/articles/biane-QPC-Grenoble.ps")[#text("this survey of Biane")]#text(" for more discussion.)")
]

#text("Thus, for instance, if ")#mi("{X, Y}")#text(" are freely independent, then ")#mi("{\\tau( P(X) Q(Y) R(X) S(Y) )}")#text(" will vanish for any polynomials ")#mi("{P,Q,R,S}")#text(" for which ")#mi("{\\tau(P(X)), \\tau(Q(Y)), \\tau(R(X)), \\tau(S(Y))}")#text(" all vanish. This is in contrast to classical independence of classical (commutative) random variables, which would only assert that ")#mi("{\\tau(P(X) Q(Y))=0}")#text(" whenever ")#mi("{\\tau(P(X)), \\tau(Q(Y))}")#text(" both vanish.")

#text("To contrast free independence with classical independence, suppose that ")#mi("{\\tau(X)=\\tau(Y)=0}")#text(". If ")#mi("{X, Y}")#text(" were freely independent, then ")#mi("{\\tau(XYXY)=0}")#text(". If instead ")#mi("{X, Y}")#text(" were commuting and classically independent, then we would instead have ")#mi("{\\tau(XYXY) = \\tau(X^2Y^2) = \\tau(X^2)\\tau(Y^2)}")#text(", which would almost certainly be non-zero.")

#text("For a trivial example of free independence, ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" automatically are freely independent if at least one of ")#mi("{X, Y}")#text(" is constant (i.e. a multiple of the identity ")#mi("{1}")#text("). In the commutative setting, this is basically the only way one can have free independence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28")]#text(" Suppose that ")#mi("{X, Y}")#text(" are freely independent self-adjoint elements of a faithful non-commutative probability space which also commute. Show that at least one of ")#mi("{X, Y}")#text(" is equal to a scalar. (")#emph[#text("Hint:")]#text(" First normalise ")#mi("{X, Y}")#text(" to have trace zero, and consider ")#mi("{\\tau(XYXY)}")#text(".)")
]

#text("A less trivial example of free independence comes from the free group, which provides a clue as to the original motivation of this concept:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 29")]#text(" ")#metadata(none) <tao-12a5e06baa6e2ab3ffac>#text(" Let ")#mi("{{\\Bbb F}_2}")#text(" be the free group on two generators ")#mi("{g_1,g_2}")#text(". Let ")#mi("{{\\mathcal A} = B(\\ell^2({\\Bbb F}_2))}")#text(" be the non-commutative probability space of bounded linear operators on the Hilbert space ")#mi("{\\ell^2({\\Bbb F}_2)}")#text(", with trace ")#mi("{\\tau(X) := \\langle X e_0, e_0 \\rangle}")#text(", where ")#mi("{e_0}")#text(" is the Kronecker delta function at the identity. Let ")#mi("{U_1, U_2 \\in {\\mathcal A}}")#text(" be the shift operators")

#align(center)[#tao-fit-display[#mitex("U_1 f(g) := f(g_1 g); \\quad U_2 f(g) := f(g_2 g)")]]

#text("for ")#mi("{f \\in \\ell^2({\\Bbb F}_2)}")#text(" and ")#mi("{g \\in {\\Bbb F}_2}")#text(". Show that ")#mi("{U_1, U_2}")#text(" are freely independent.")
]

#text("For classically independent commuting random variables ")#mi("{X, Y}")#text(", knowledge of the individual moments ")#mi("{\\tau(X^k)}")#text(", ")#mi("{\\tau(Y^k)}")#text(" gave complete information on the joint moments: ")#mi("{\\tau(X^k Y^l) = \\tau(X^k) \\tau(Y^l)}")#text(". The same fact is true for freely independent random variables, though the situation is more complicated. We begin with a simple case: computing ")#mi("{\\tau(XY)}")#text(" in terms of the moments of ")#mi("{X, Y}")#text(". From free independence we have")

#align(center)[#tao-fit-display[#mitex("\\tau( (X-\\tau(X)) (Y-\\tau(Y)) = 0.")]]

#text("Expanding this using linear nature of trace, one soon sees that ")#metadata(none) <tao-94c05f1c45a1d1a913e0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#mitex("\\tau(X Y) = \\tau(X)\\tau(Y).")]]



#text(" So far, this is just as with the classically independent case. Next, we consider a slightly more complicated moment, ")#mi("{\\tau(XYX)}")#text(". If we split ")#mi("{Y = \\tau(Y) + (Y-\\tau(Y))}")#text(", we can write this as")

#align(center)[#tao-fit-display[#mitex("\\tau(XYX) = \\tau(Y) \\tau(X^2) + \\tau(X (Y-\\tau(Y)) X).")]]

#text("In the classically independent case, we can conclude the latter term would vanish. We cannot immediately say that in the freely independent case, because only one of the factors has mean zero. But from ")#link(<tao-94c05f1c45a1d1a913e0>)[#text("(12)")]#text(" we know that ")#mi("{\\tau( X (Y-\\tau(Y) ) = \\tau( (Y-\\tau(Y)) X ) = 0}")#text(". Because of this, we can expand")

#align(center)[#tao-fit-display[#mitex("\\tau(X (Y-\\tau(Y)) X) = \\tau( (X-\\tau(X)) (Y-\\tau(Y)) (X-\\tau(X)) )")]]

#text("and now free independence does ensure that this term vanishes, and so ")#metadata(none) <tao-29c762689ad32f89d320>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(13)")])
#mitex("\\tau(XYX) = \\tau(Y) \\tau(X^2).")]]



#text(" So again we have not yet deviated from the classically independent case. But now let us look at ")#mi("{\\tau(XYXY)}")#text(". We split the second ")#mi("{X}")#text(" into ")#mi("{\\tau(X)}")#text(" and ")#mi("{X-\\tau(X)}")#text(". Using ")#link(<tao-94c05f1c45a1d1a913e0>)[#text("(12)")]#text(" to control the former term, we have")

#align(center)[#tao-fit-display[#mitex("\\tau(XYXY) = \\tau(X)^2 \\tau(Y^2) + \\tau(XY(X-\\tau(X))Y).")]]

#text("From ")#link(<tao-29c762689ad32f89d320>)[#text("(13)")]#text(" we have ")#mi("{\\tau(Y(X-\\tau(X))Y)=0}")#text(", so we have")

#align(center)[#tao-fit-display[#mitex("\\tau(XYXY) = \\tau(X)^2 \\tau(Y^2) + \\tau((X-\\tau(X))Y(X-\\tau(X))Y).")]]

#text("Now we split ")#mi("{Y}")#text(" into ")#mi("{\\tau(Y)}")#text(" and ")#mi("{Y-\\tau(Y)}")#text(". Free independence eliminates all terms except")

#align(center)[#tao-fit-display[#mitex("\\tau(XYXY) = \\tau(X)^2 \\tau(Y^2) + \\tau((X-\\tau(X))\\tau(Y)(X-\\tau(X))\\tau(Y))")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("\\tau(XYXY) = \\tau(X)^2 \\tau(Y^2) + \\tau(X^2) \\tau(Y)^2 - \\tau(X)^2 \\tau(Y)^2")]]

#text("which differs from the classical independence prediction of ")#mi("{\\tau(X^2) \\tau(Y^2)}")#text(".")

#text("This process can be continued:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 30")]#text(" Let ")#mi("{X_1,\\ldots,X_k}")#text(" be freely independent. Show that any joint moment of ")#mi("{X_1,\\ldots,X_k}")#text(" can be expressed as a polynomial combination of the individual moments ")#mi("{\\tau(X_i^j)}")#text(" of the ")#mi("{X_i}")#text(". (Hint: induct on the complexity of the moment.)")
]

#text("The product measure construction allows us to generate classically independent random variables at will (after extending the underlying sample space): see Exercise 18 of ")#link("https://terrytao.wordpress.com/2010/01/01/254a-notes-0-a-review-of-probability-theory/")[#text("Notes 0")]#text(". There is an analogous construction, called the ")#emph[#text("amalgamated free product")]#text(", that allows one to generate families of freely independent random variables, each of which has a specified distribution. Let us give an illustrative special case of this construction:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 31 (Free products)")]#text(" ")#metadata(none) <tao-54fd0f5bc0e9cfb5a6d7>#text(" For each ")#mi("{1 \\leq i \\leq k}")#text(", let ")#mi("{({\\mathcal A}_i,\\tau_i)}")#text(" be a non-commutative probability space. Then there exists a non-commutative probability space ")#mi("{({\\mathcal A},\\tau)}")#text(" which contain embedded copies of each of the ")#mi("{({\\mathcal A}_i,\\tau_i)}")#text(", such that whenever ")#mi("{X_i \\in {\\mathcal A}_i}")#text(" for ")#mi("{i=1,\\ldots,k}")#text(", then ")#mi("{X_1,\\ldots,X_k}")#text(" are freely independent.")
]

#emph[#text("Proof:")]#text(" (Sketch) Recall that each ")#mi("{{\\mathcal A}_i}")#text(" can be given an inner product ")#mi("{\\langle,\\rangle_{L^2({\\mathcal A}_i)}}")#text(". One can then orthogonally decompose each space ")#mi("{{\\mathcal A}_i}")#text(" into the constants ")#mi("{{\\bf C}}")#text(", plus the trace zero elements ")#mi("{{\\mathcal A}_i^0 := \\{ X \\in {\\mathcal A}_i: \\tau(X)=0\\}}")#text(".")

#text("We now form the ")#link("http://en.wikipedia.org/wiki/Fock_space")[#text("Fock space")]#text(" ")#mi("{{\\mathcal F}}")#text(" to be the inner product space formed by the direct sum of tensor products ")#metadata(none) <tao-f5557d4fcf727a981a3c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(14)")])
#mitex("{\\mathcal A}_{i_1}^0 \\otimes \\ldots \\otimes {\\mathcal A}_{i_m}^0")]]



#text(" where ")#mi("{m \\geq 0}")#text(", and ")#mi("{i_1,\\ldots,i_m \\in \\{1,\\ldots,k\\}}")#text(" are such that no adjacent pair ")#mi("{i_j,i_{j+1}}")#text(" of the ")#mi("{i_1,\\ldots,i_m}")#text(" are equal. Each element ")#mi("{X_i \\in {\\mathcal A}_i}")#text(" then acts on this Fock space by defining")

#align(center)[#tao-fit-display[#mitex("X_i ( Y_{i_1} \\otimes \\ldots \\times Y_{i_m} ) := X_i \\otimes Y_{i_1} \\otimes \\ldots \\otimes Y_{i_m}")]]

#text("when ")#mi("{i \\neq i_1}")#text(", and")

#tao-aligned(keep: true)[


#tao-math("X_i ( Y_{i_1} \\otimes \\ldots \\times Y_{i_m} )  & := \\tau( X_i Y_{i_1} ) Y_{i_2} \\otimes \\ldots \\times Y_{i_m}", block: true)



#tao-math(" & + (X_i Y_{i_1} - \\tau(X_i Y_{i_1})) \\otimes Y_{i_2} \\otimes \\ldots \\otimes Y_{i_m}", block: true)
]

#text("when ")#mi("{i=i_1}")#text(". One can thus map ")#mi("{{\\mathcal A}_i}")#text(" into the space ")#mi("{{\\mathcal A} := \\text{Hom}({\\mathcal F}, {\\mathcal F})}")#text(" of linear maps from ")#mi("{{\\mathcal F}}")#text(" to itself. The latter can be given the structure of a non-commutative space by defining the trace ")#mi("{\\tau(X)}")#text(" of an element ")#mi("{X \\in {\\mathcal A}}")#text(" by the formula ")#mi("{\\tau(X) := \\langle X e_\\emptyset, e_\\emptyset \\rangle_{{\\mathcal F}}}")#text(", where ")#mi("{e_\\emptyset}")#text(" is the ")#emph[#text("vacuum state")]#text(" of ")#mi("{{\\mathcal F}}")#text(", being the unit of the ")#mi("{m=0}")#text(" tensor product. One can verify (Exercise!) that ")#mi("{{\\mathcal A}_i}")#text(" embeds into ")#mi("{{\\mathcal A}}")#text(" and that elements from different ")#mi("{{\\mathcal A}_i}")#text(" are freely independent. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 32")]#text(" Complete the proof of Lemma ")#link(<tao-54fd0f5bc0e9cfb5a6d7>)[#text("31")]#text(". (")#emph[#text("Hint:")]#text(" you may find it helpful to first do Exercise ")#link(<tao-12a5e06baa6e2ab3ffac>)[#text("29")]#text(", as the construction here is in an abstraction of the one in that exercise.)")
]

#text("Finally, we illustrate the fundamental connection between free probability and random matrices ")#link("http://www.ams.org/mathscinet-getitem?mr=1094052")[#text("observed by Voiculescu")]#text(", namely that (classically) independent families of random matrices are ")#emph[#text("asymptotically free")]#text(". The intuition here is that while a large random matrix ")#mi("{M}")#text(" will certainly correlate with itself (so that, for instance, ")#mi("{\\text{tr} M^* M}")#text(" will be large), once one interposes an independent random matrix ")#mi("{N}")#text(" of trace zero, the correlation is largely destroyed (thus, for instance, ")#mi("{\\text{tr} M^* N M}")#text(" will usually be quite small).")

#text("We give a typical instance of this phenomenon here:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 33 (Asymptotic freeness of Wigner matrices)")]#text(" ")#metadata(none) <tao-4e70ad1dd106c987c9b6>#text(" Let ")#mi("{M_{n,1},\\ldots,M_{n,k}}")#text(" be a collection of independent ")#mi("{n \\times n}")#text(" Wigner matrices, where the coefficients all have uniformly bounded ")#mi("{m^{th}}")#text(" moments for each ")#mi("{m}")#text(". Then the random variables ")#mi("{\\frac{1}{\\sqrt{n}} M_{n,1},\\ldots,\\frac{1}{\\sqrt{n}} M_{n,k} \\in (L^{\\infty-} \\otimes M_n({\\bf C}), {\\bf E}\\frac{1}{n}\\text{tr})}")#text(" are asymptotically free.")
]

#emph[#text("Proof:")]#text(" (Sketch) Let us abbreviate ")#mi("{\\frac{1}{\\sqrt{n}} M_{n,j}}")#text(" as ")#mi("{X_j}")#text(" (suppressing the ")#mi("{n}")#text(" dependence). It suffices to show that the traces")

#align(center)[#tao-fit-display[#mitex("\\tau( \\prod_{j=1}^m (X_{i_j}^{a_j} - \\tau(X_{i_j}^{a_j})) ) = o(1)")]]

#text("for each fixed choice of natural numbers ")#mi("{a_1,\\ldots,a_m}")#text(", where no two adjacent ")#mi("{i_j, i_{j+1}}")#text(" are equal.")

#text("Recall from ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(" that ")#mi("{\\tau(X_j^{a_j})}")#text(" is (up to errors of ")#mi("{o(1)}")#text(") equal to a normalised count of paths of length ")#mi("{a_j}")#text(" in which each edge is traversed exactly twice, with the edges forming a tree. After normalisation, this count is equal to ")#mi("{0}")#text(" when ")#mi("{a_j}")#text(" is odd, and equal to the Catalan number ")#mi("{C_{a_j/2}}")#text(" when ")#mi("{a_j}")#text(" is even.")

#text("One can perform a similar computation to compute ")#mi("{\\tau( \\prod_{j=1}^m X_{i_j}^{a_j} )}")#text(". Up to errors of ")#mi("{o(1)}")#text(", this is a normalised count of ")#emph[#text("coloured")]#text(" paths of length ")#mi("{a_1+\\ldots+a_m}")#text(", where the first ")#mi("{a_1}")#text(" edges are coloured with colour ")#mi("{i_1}")#text(", the next ")#mi("{a_2}")#text(" with colour ")#mi("{i_2}")#text(", etc. Furthermore, each edge is traversed exactly twice (with the two traversals of each edge being assigned the same colour), and the edges form a tree. As a consequence, there must exist a ")#mi("{j}")#text(" for which the block of ")#mi("{a_j}")#text(" edges of colour ")#mi("{i_j}")#text(" form their own sub-tree, which contributes a factor of ")#mi("{C_{a_j/2}}")#text(" or ")#mi("{0}")#text(" to the final trace. Because of this, when one instead computes the normalised expression ")#mi("{\\tau( \\prod_{j=1}^m (X_{i_j}^{a_j} - \\tau(X_{i_j}^{a_j})) )}")#text(", all contributions that are not ")#mi("{o(1)}")#text(" cancel themselves out, and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 34")]#text(" Expand the above sketch into a full proof of the above theorem.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 35")]#text(" This is by no means the only way in which random matrices can become asymptotically free. For instance, if instead one considers random matrices of the form ")#mi("{M_{n,i} = U_i^* A_i U_i}")#text(", where ")#mi("{A_i}")#text(" are deterministic Hermitian matrices with uniformly bounded eigenvalues, and the ")#mi("{U_i}")#text(" are iid unitary matrices drawn using Haar measure on the unitary group ")#mi("{U(n)}")#text(", one can also show that the ")#mi("{M_{n,i}}")#text(" are asymptotically free; again, see the ")#link("http://www.ams.org/mathscinet-getitem?mr=1094052")[#text("paper of Voiculescu")]#text(" for details.")
]

#heading(level: 1)[#strong[#text(" — 4. Free convolution — ")]]

#text("When one is summing two classically independent (real-valued) random variables ")#mi("{X}")#text(" and ")#mi("{Y}")#text(", the distribution ")#mi("{\\mu_{X+Y}}")#text(" of the sum ")#mi("{X+Y}")#text(" is the convolution ")#mi("{\\mu_X * \\mu_Y}")#text(" of the distributions ")#mi("{\\mu_X}")#text(" and ")#mi("{\\mu_Y}")#text(". This convolution can be computed by means of the characteristic function")

#align(center)[#tao-fit-display[#mitex("F_X(t) := \\tau(e^{itX}) = \\int_{\\bf R} e^{itx}\\ d\\mu_X(x)")]]

#text("by means of the simple formula")

#align(center)[#tao-fit-display[#mitex("\\tau(e^{it(X+Y)}) = \\tau(e^{itX}) \\tau(e^{itY}).")]]

#text("As we saw in ")#link("https://terrytao.wordpress.com/2010/01/05/254a-notes-2-the-central-limit-theorem/")[#text("Notes 2")]#text(", this can be used in particular to establish a short proof of the central limit theorem.")

#text("There is an analogous theory when summing two freely independent (self-adjoint) non-commutative random variables ")#mi("{X}")#text(" and ")#mi("{Y}")#text("; the distribution ")#mi("{\\mu_{X+Y}}")#text(" turns out to be a certain combination ")#mi("{\\mu_X \\boxplus \\mu_Y}")#text(", known as the ")#emph[#text("free convolution")]#text(" of ")#mi("{\\mu_X}")#text(" and ")#mi("{\\mu_Y}")#text(". To compute this free convolution, one does not use the characteristic function; instead, the correct tool is the ")#emph[#text("Stieltjes transform")]

#align(center)[#tao-fit-display[#mitex("s_X(z) := \\tau( (X-z)^{-1} ) = \\int_{\\bf R} \\frac{1}{x-z}\\ d\\mu_X(x)")]]

#text("which has already been discussed earlier.")

#text("Here’s how to use this transform to compute free convolutions. If one wishes, one can that ")#mi("{X}")#text(" is bounded so that all series involved converge for ")#mi("{z}")#text(" large enough, though actually the entire argument here can be performed at a purely algebraic level, using formal power series, and so the boundedness hypothesis here is not actually necessary.")

#text("The trick (which we already saw in ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text(") is not to view ")#mi("{s = s_X(z)}")#text(" as a function of ")#mi("{z}")#text(", but rather to view ")#mi("{z = z_X(s)}")#text(" as a function of ")#mi("{s}")#text(". Given that one asymptotically has ")#mi("{s \\sim -1/z}")#text(" for ")#mi("{z}")#text(", we expect to be able to perform this inversion for ")#mi("{z}")#text(" large and ")#mi("{s}")#text(" close to zero; and in any event one can easily invert ")#link(<tao-e08b9711deab3b365111>)[#text("(8)")]#text(" on the level of formal power series.")

#text("With this inversion, we thus have ")#metadata(none) <tao-ca2b25a9b0e7a993f09d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("s = \\tau((X-z_X(s))^{-1})")]]



#text(" and thus")

#align(center)[#tao-fit-display[#mitex("(X-z_X(s))^{-1} = s(1 - E_X)")]]

#text("for some ")#mi("{E_X = E_X(s)}")#text(" of trace zero. Now we do some (formal) algebraic sleight of hand. We rearrange the above identity as")

#align(center)[#tao-fit-display[#mitex("X = z_X(s) + s^{-1} (1 - E_X)^{-1}.")]]

#text("Similarly we have")

#align(center)[#tao-fit-display[#mitex("Y = z_Y(s) + s^{-1} (1 - E_Y)^{-1}")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("X + Y = z_X(s) + z_Y(s) + s^{-1} [ (1-E_X)^{-1} + (1-E_Y)^{-1} ].")]]

#text("We can combine the second two terms via the identity")

#align(center)[#tao-fit-display[#mitex("(1-E_X)^{-1} + (1-E_Y)^{-1} = (1-E_X)^{-1} (1- E_Y + 1- E_X) (1-E_Y)^{-1}.")]]

#text("Meanwhile")

#align(center)[#tao-fit-display[#mitex("1 = (1-E_X)^{-1} (1 - E_Y - E_X + E_X E_Y) (1-E_Y)^{-1}")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("X + Y = z_X(s) + z_Y(s) + s^{-1} + s^{-1} [(1-E_X)^{-1} (1 - E_X E_Y) (1-E_Y)^{-1}].")]]

#text("We can rearrange this a little bit as")

#align(center)[#tao-fit-display[#mitex("(X+Y - z_X(s)-z_Y(s)-s^{-1})^{-1} = s [(1-E_Y) (1 - E_X E_Y)^{-1} (1-E_X) ].")]]

#text("We expand out as (formal) Neumann series:")

#align(center)[#tao-fit-display[#mitex("(1-E_Y) (1 - E_X E_Y)^{-1} (1-E_X) = (1-E_Y) (1+E_X E_Y + E_X E_Y E_X E_Y + \\ldots ) (1-E_X).")]]

#text("This expands out to equal ")#mi("{1}")#text(" plus a whole string of alternating products of ")#mi("{E_X}")#text(" and ")#mi("{E_Y}")#text(".")

#text("Now we use the hypothesis that ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are free. This easily implies that ")#mi("{E_X}")#text(" and ")#mi("{E_Y}")#text(" are also free. But they also have trace zero, thus by the definition of free independence, all alternating products of ")#mi("{E_X}")#text(" and ")#mi("{E_Y}")#text(" have zero trace. (In the case when there are an odd number of terms in the product, one can obtain this zero trace property using the cyclic property of trace and induction.) We conclude that")

#align(center)[#tao-fit-display[#mitex("\\tau( (1-E_Y) (1 - E_X E_Y)^{-1} (1-E_X) ) = 1")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("\\tau((X+Y - z_X(s)-z_Y(s)-s^{-1})^{-1}) = s.")]]

#text("Comparing this against ")#link(<tao-ca2b25a9b0e7a993f09d>)[#text("(15)")]#text(" for ")#mi("{X+Y}")#text(" we conclude that")

#align(center)[#tao-fit-display[#mitex("z_{X+Y}(s) = z_X(s) + z_Y(s) + s^{-1}.")]]

#text("Thus, if we define the ")#emph[#mi("{R}")#text("-transform")]#text(" ")#mi("{R_X}")#text(" of ")#mi("{X}")#text(" to be (formally) given by the formula")

#align(center)[#tao-fit-display[#mitex("R_X(s) := z_X(-s) - s^{-1}")]]

#text("then we have the addition formula")

#align(center)[#tao-fit-display[#mitex("R_{X+Y} = R_X + R_Y.")]]

#text("Since one can recover the Stieltjes transform ")#mi("{s_X}")#text(" (and hence the ")#mi("{R}")#text("-transform ")#mi("{R_X}")#text(") from the spectral measure ")#mi("{\\mu_X}")#text(" and vice versa, this formula (in principle, at least) lets one compute the spectral measure ")#mi("{\\mu_{X+Y}}")#text(" of ")#mi("{X+Y}")#text(" from the spectral measures ")#mi("{\\mu_X, \\mu_Y}")#text(", thus allowing one to define free convolution.")

#text("For comparison, we have the (formal) addition formula")

#align(center)[#tao-fit-display[#mitex("\\log F_{X+Y} = \\log F_X + \\log F_Y")]]

#text("for classically independent real random variables ")#mi("{X, Y}")#text(". The following exercises carry this analogy a bit further.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 36")]#text(" Let ")#mi("{X}")#text(" be a classical real random variable. Working formally, show that")

#align(center)[#tao-fit-display[#mitex("\\log F_X(t) = \\sum_{k=1}^\\infty \\frac{\\kappa_{k}(X)}{k!} (it)^k")]]

#text("where the ")#link("http://en.wikipedia.org/wiki/Cumulant")[#text("cumulants")]#text(" ")#mi("{\\kappa_k(X)}")#text(" can be reconstructed from the moments ")#mi("{\\tau(X^k)}")#text(" by the recursive formula")

#align(center)[#tao-fit-display[#mitex("\\tau(X^k) = \\kappa_k(X) + \\sum_{j=1}^{k-1} \\kappa_j(X) \\sum_{a_1+\\ldots+a_j = k-j} \\tau(X^{a_1+\\ldots+a_j})")]]

#text("for ")#mi("{k \\geq 1}")#text(". (")#emph[#text("Hint:")]#text(" start with the identity ")#mi("{\\frac{d}{dt} F_X(t) = (\\frac{d}{dt} \\log F_X(t)) F_X(t)}")#text(".) Thus for instance ")#mi("{\\kappa_1(X) = \\tau(X)}")#text(" is the expectation, ")#mi("{\\kappa_2(X) = \\tau(X^2) - \\tau(X)^2}")#text(" is the variance, and the third and fourth cumulants are given by the formula")

#tao-aligned(keep: true)[


#tao-math("\\kappa_3(X)  & = \\tau(X^3) - 3 \\tau(X^2) \\tau(X) + 2 \\tau(X)^3.", block: true)



#tao-math("\\kappa_4(X)  & = \\tau(X^4) - 4 \\tau(X^3) \\tau(X) - 3 \\tau(X^2)^2 + 12 \\tau(X^2) \\tau(X)^2 - 6 \\tau(X)^4.", block: true)
]

#text("Establish the additional formula")

#align(center)[#tao-fit-display[#tao-math("\\tau(X^k) = \\sum_{\\pi} \\prod_{A \\in \\pi} \\kappa_{\\left|A\\right|}(X)", block: true)]]

#text("where ")#mi("{\\pi}")#text(" ranges over all partitions of ")#mi("{\\{1,\\ldots,k\\}}")#text(" into non-empty cells ")#mi("{A}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 37")]#text(" Let ")#mi("{X}")#text(" be a non-commutative random variable. Working formally, show that")

#align(center)[#tao-fit-display[#mitex("R_X(s) = \\sum_{k=1}^\\infty C_k(X) s^{k-1}")]]

#text("where the ")#emph[#text("free cumulants")]#text(" ")#mi("{C_k(X)}")#text(" can be reconstructed from the moments ")#mi("{\\tau(X^k)}")#text(" by the recursive formula")

#align(center)[#tao-fit-display[#mitex("\\tau(X^k) = C_k(X) + \\sum_{j=1}^{k-1} C_j(X) \\sum_{a_1+\\ldots+a_j = k-j} \\tau(X^{a_1}) \\ldots \\tau(X^{a_j})")]]

#text("for ")#mi("{k \\geq 1}")#text(". (")#emph[#text("Hint:")]#text(" start with the identity ")#mi("{s_X(z) R_X(-s_X(z)) = 1 + z s_X(z)}")#text(".) Thus for instance ")#mi("{C_1(X) = \\tau(X)}")#text(" is the expectation, ")#mi("{C_2(X) = \\tau(X^2) - \\tau(X)^2}")#text(" is the variance, and the third and fourth free cumulants are given by the formulae")

#tao-aligned(keep: true)[


#tao-math("C_3(X)  & = \\tau(X^3) - 3 \\tau(X^2) \\tau(X) + 2 \\tau(X)^3", block: true)



#tao-math("C_4(X)  & = \\tau(X^4) - 4 \\tau(X^3) \\tau(X) - 2 \\tau(X^2)^2 + 10 \\tau(X^2) \\tau(X)^2 - 5 \\tau(X)^4.", block: true)
]

#text("Establish the additional formula")

#align(center)[#tao-fit-display[#tao-math("\\tau(X^k) = \\sum_{\\pi} \\prod_{A \\in \\pi} C_{\\left|A\\right|}(X)", block: true)]]

#text("where ")#mi("{\\pi}")#text(" ranges over all partitions of ")#mi("{\\{1,\\ldots,k\\}}")#text(" into non-empty cells ")#mi("{A}")#text(" which are ")#emph[#text("non-crossing")]#text(", which means that if ")#mi("{a < b < c < d}")#text(" lie in ")#mi("{\\{1,\\ldots,k\\}}")#text(", then it cannot be the case that ")#mi("{a,c}")#text(" lie in one cell ")#mi("{A}")#text(" while ")#mi("{b,d}")#text(" lie in a distinct cell ")#mi("{A^{\\prime}}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 38")]#text(" These computations illustrate a more general principle in free probability, in that the combinatorics of free probability tend to be the “non-crossing” analogue of the combinatorics of classical probability; compare with Remark 7 of ")#link("https://terrytao.wordpress.com/2010/01/09/254a-notes-3-the-operator-norm-of-a-random-matrix/")[#text("Notes 3")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 39")]#text(" The ")#mi("{R}")#text("-transform allows for efficient computation of the spectral behaviour of sums ")#mi("{X+Y}")#text(" of free random variables. There is an analogous transform, the ")#emph[#mi("{S}")#text("-transform")]#text(", for computing the spectral behaviour (or more precisely, the joint moments) of products ")#mi("{XY}")#text(" of free random variables; see for instance ")#link("http://www.mast.queensu.ca/~speicher/papers/lectures-IHP.pdf")[#text("these notes of Speicher")]#text(".")
]

#text("The ")#mi("{R}")#text("-transform clarifies the privileged role of the semi-circular elements:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 40")]#text(" Let ")#mi("{u}")#text(" be a semi-circular element. Show that ")#mi("{R_{\\sqrt{t} u}(s) = t s}")#text(" for any ")#mi("{t>0}")#text(". In particular, the free convolution of ")#mi("{\\sqrt{t} u}")#text(" and ")#mi("{\\sqrt{t^{\\prime}} u}")#text(" is ")#mi("{\\sqrt{t+t^{\\prime}} u}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 41")]#text(" From the above exercise, we see that the effect of adding a free copy of ")#mi("{\\sqrt{t} u}")#text(" to a non-commutative random variable ")#mi("{X}")#text(" is to shift the ")#mi("{R}")#text("-transform by ")#mi("{ts}")#text(". Explain how this is compatible with the Dyson Brownian motion computations in ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text(".")
]

#text("It also gives a free analogue of the central limit theorem:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 42 (Free central limit theorem)")]#text(" Let ")#mi("{X}")#text(" be a self-adjoint random variable with mean zero and variance one (i.e. ")#mi("{\\tau(X)=0}")#text(" and ")#mi("{\\tau(X^2)=1}")#text("), and let ")#mi("{X_1, X_2, X_3, \\ldots}")#text(" be free copies of ")#mi("{X}")#text(". Let ")#mi("{S_n := (X_1+\\ldots+X_n)/\\sqrt{n}}")#text(". Show that the coefficients of the formal power series ")#mi("{R_{S_n}(s)}")#text(" converge to that of the identity function ")#mi("{s}")#text(". Conclude that ")#mi("{S_n}")#text(" converges in the sense of moments to a semi-circular element ")#mi("{u}")#text(".")
]

#text("The free central limit theorem implies the Wigner semi-circular law, at least for the GUE ensemble and in the sense of expectation. Indeed, if ")#mi("{M_n}")#text(" is an ")#mi("{n \\times n}")#text(" GUE matrix, then the matrices ")#mi("{\\frac{1}{\\sqrt{n}} M_n}")#text(" are a.s. uniformly bounded (by the Bai-Yin theorem, Notes 3), and so (after passing to a subsequence, if necessary), they converge in the sense of moments to some limit ")#mi("{u}")#text(".")

#text("On the other hand, if ")#mi("{M^{\\prime}_n}")#text(" is an independent copy of ")#mi("{M_n}")#text(", then ")#mi("{M_n + M^{\\prime}_n \\equiv \\sqrt{2} M_n}")#text(" from the properties of gaussians. Taking limits, we conclude that ")#mi("{u+u^{\\prime} \\equiv \\sqrt{2} u}")#text(", where (by Proposition ")#link(<tao-4e70ad1dd106c987c9b6>)[#text("33")]#text(") ")#mi("{u^{\\prime}}")#text(" is a free copy of ")#mi("{u}")#text(". Comparing this with the free central limit theorem (or just the additivity property of ")#mi("{R}")#text("-transforms we see that ")#mi("{u}")#text(" must have the semi-circular distribution. Thus the semi-circular distribution is the only possible limit point of the ")#mi("{\\frac{1}{\\sqrt{n}} M_n}")#text(", and the Wigner semi-circular law then holds (in expectation, and for GUE). Using concentration of measure, we can upgrade the convergence in expectation to a.s. convergence; using the Lindeberg replacement trick one can replace GUE with arbitrary Wigner matrices with (say) bounded coefficients; and then by using the truncation trick one can remove the boundedness hypothesis. (These latter few steps were also discussed in ")#link("https://terrytao.wordpress.com/2010/02/02/254a-notes-4-the-semi-circular-law/")[#text("Notes 4")]#text(".)")

#heading(level: 1)[#text("Comments (62)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f8bea315ca6359c18c15191e8c0d78193d6f3ea61bbb50218ad2e13c6988d461-c40618e8fab735dbbbfb1255ca0edd52d56248ddc2554fa418ec4270122523db.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Johan")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43573")[#strong[#text("Johan")]]#text(size: 9pt, fill: rgb("596477"), " · 11 February 2010")])]

#text("In example 1 I believe there are a few places where ")#mi("L^{\\infty -}")#text(" has become ")#mi("L^{\\infty}")#text(" because of typos.")

#text("Specifically, I believe the range of the multiplication operation should be ")#mi("L^{\\infty -}")#text(" , that this should also be both the domain and the range of the involution operation and that the expectation operator is a linear operator on ")#mi("L^{\\infty -}")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0d0e801c63af78a972ead42c0dabd6580013ff45c7700cc0d51147aa50a24a6-f11f451c7a8a3c4038c7de35c505d288f7d925587e81320e9e77a39a0cfc3548.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Lowther")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43601")[#strong[#text("George Lowther")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("I don’t know if I’m misunderstanding something here, but in Exercise 1 I don’t see any reason why the sequence should be non-decreasing. If X was a centered Gaussian, or any other symmetric RV, then it will be zero for odd k and positive and non-decreasing for even k.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43602")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 February 2010")])]

#text("Ah, right, the monotonicity is only partial for the odd moments (the odd moments are bounded by the next even moment, but not vice versa). I’ve changed the text accordingly.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a0d0e801c63af78a972ead42c0dabd6580013ff45c7700cc0d51147aa50a24a6-f11f451c7a8a3c4038c7de35c505d288f7d925587e81320e9e77a39a0cfc3548.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of George Lowther")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43610")[#strong[#text("George Lowther")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("Also, I think you should have exponent of k+1 rather than k in the denominator in expressions (8),(10),(11) for s_X.")

#emph[#text("[Corrected, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43608")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#emph[#text("In the non-commutative setting, the correct notion is now of two (bounded, self-adjoint) non-commutative random variables {X, Y} being freely independent (or free for short)")]

#text("I would say ")#strong[#text("a")]#text(" correct, not ")#strong[#text("the")]#text(" correct. If you accept von Neumann algebras and C*-algebras, but instead retain ordinary commutative independence, then the theory is standard quantum probability. In the context of empirical science, standard quantum probability is more often correct than classical probability (which it generalizes), and it is far more often correct than free probability (whose relevance to physics is credible but speculative).")

#emph[#text("However, we will proceed here instead by working with a (possibly incomplete) non-commutative probability space, and working primarily with formal expressions (e.g. formal power series in z) without trying to evaluate such expressions in some completed space.")]

#text("This amounts to reducing all probability to a theory of moments. This has led to all sorts of confusion in parts of the literature in quantum probability. Everyone understands that a classical distribution has more information in it than just its moments; thus axioms based only on moments aren’t very good axioms. The same thing happens in non-commutative probability of course. The only reason that this simplification is somewhat accountable in free probability is that typical limit laws (like the Wigner semicircle) are bounded. Of course this is not true in standard quantum probability, which again is non-commutative but with a commutative independence law. (It’s also not a full excuse to just look at moments, although you seem to acknowledge that completions could be important later.)")

#text("So I would put a stronger disclaimer here.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43613")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("Fair enough; I’ve amended the text accordingly.")

#text("Quantum observables, while not exactly commutative in general, are still often approximately commutative, thanks to the correspondence principle, which is why classical independence is still a useful concept; in contrast, a pair of random matrices tends to be “maximally non-commutative”, making free probability the more relevant concept. So in some sense they represent the two opposite extremes of non-commutative probability.")

#text("It’s also true that the moment-centric viewpoint of free probability, which makes computations purely algebraic in nature rather than analytic, breaks down for unbounded variables, which of course occur all the time in quantum mechanics. I mention this restriction to bounded variables in the introduction.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9237294e59b93cae0ca2c43235715ad770c11ef660c38ba4717c092245a3a2e3-747a7c3df778a893a962dc84a3d1b3ca304e53dfd2573ee527ecd6939407aaac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Greg Kuperberg")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43617")[#strong[#text("Greg Kuperberg")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#emph[#text("Quantum observables, while not exactly commutative in general, are still often approximately commutative, thanks to the correspondence principle, which is why classical independence is still a useful concept")]

#text("I have really learned something from this remark: Although I always knew that commutative independence (as opposed to free independence) is still important in quantum probability, I didn’t consider that you would want a dynamical reason to justify it. That said, I only half agree with you. One reason that commutative independence is still relevant in physics is indeed that we live in a semiclassical regime of the laws of physics. (So when you say “often”, it is in the same sense that if we were fish, we would think that 3-dimensional regions are “often” filled with water.)")

#text("But two other reasons that commutative independence are relevant in quantum probability are (1) finite communication speed, and (2) weak coupling. These two reasons, and not the semiclassical limit, are why quantum computation is premised on standard quantum probability rather than (say) free probability. One of the things that I did not realize, and which is definitely useful to say, is that in the human realm (again, if we were fish…), is that neither finite communication speed nor weak coupling are directly the point. If the price of groceries in Atlanta is statistically independent from the distribution of potholes in Seattle, it isn’t because of a bound on the speed of light or sound, nor a bound the strength of the electromagnetic field. Instead, there is an emergent statistical weak coupling, which is related to the emergent classical/semiclassical regime that we live in.")

#text("Actually, I guess there are also examples of emergent weak coupling in quantum physics. They are associated with classical limits, but that is not strictly necessary.")

#text("As you imply, free probability could be a relevant model when quantum random variables are as interdependent as possible. The nuclear physics motivation of random matrix theory reflects this. Voiculescu also told me that free probability models large N gauge theory, presumably for similar reasons.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 February 2010")])]

#text("Dear Prof. Tao,")

#text("How do we define infinite products?")

#text("is ")#mi("\\prod_{i=1}^{\\infty}f(i)")#text(" the limit of partial products?")

#text("Thanks")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43641")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("Yes")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/39a86bf5bf53ec79a7aaa204629397448b150f3fc5e1ab1022f40dcf79a42bbd-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Labair Abdelkader")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-381844")[#strong[#text("Labair Abdelkader")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2014")])]

#text("See here ")#link("http://en.wikipedia.org/wiki/Infinite_product")[#text("http://en.wikipedia.org/wiki/Infinite_product")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43645")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2010")])]

#text("Dear Pr. Tao,")

#text("In section: 3. Free Independence (in the text right after Remark5), I see you wrote “vanish” twice instead of once.")

#text("Regards,")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43652")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2010")])]

#text("Dear Pr. Tao,")

#text("There is an important loss, in section 3 again (at least with Explorer). In the definition box #7 of free independence, the right hand side term in the limit, i.e., the limit condition on tau for a sequence of variables to be asymptotically free, is out of the box, so one cannot read it at all.")

#text("Best,")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/087efbd64dbb2bf3003cb0fe9d7cf1229bad84470d1637450d2d5f36eaa73bc9-3cee5444008f795ba5d1dd46a139a06cdd7870234ded3639372d93dcdead54da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmailliw/william")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43742")[#strong[#text("mmailliw/william")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2010")])]

#text("In the proof of Theorem 2, you decompose 1/(P(w) – z) as the sum of")#linebreak()#text(" (P'(zeta))^(-1)/(w – zeta), summing over the values of zeta for which P(zeta) = z.")

#text("After integrating, you then conclude that ‘formally’,")#linebreak()#text(" s_(P(X))(z) = Sigma[1/(P'(zeta)) s_X(z)], summing over zeta with P(zeta) = z.")

#text("However, I’m wondering whether the s_X(z) should actually be an s_X(zeta). After all, we know that zeta lies outside the interval [-rho(X), rho(X)], so s_X is defined on zeta, but we don’t seem to have this same guarantee for z!")

#text("(In other words, should the formal formula really be")

#text("s_(P(X))(z) = Sigma[1/(P'(zeta)) s_X(zeta)]?)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0aa174104fef35bc1bac80e593405c8675a317adf59f457d32ab8e5e6dd17218-76ebe96909c7b7c253aaba98a3fb9ef62c529e334cd156ad4f8ab2fd4cfd74e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Brian Davies")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43803")[#strong[#text("Brian Davies")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2010")])]

#text("The heavy emphasis on the use of the trace in these notes reminds me of the theory of Hilbert algebras in Jacques Dixmier’s very old Operator Algebra book Chapter 1 section 5 and in his C*-algebra book Chapter 13. Algebras with traces are very special and have a correspondingly nice mathematical theory.")

#text("In quantum statistical mechanics it has been found that the non-commutative algebras involved do not have natural traces (except in the case of infinite temperature) and the corresponding theory involves Type 3 von Neumann algebras. The trace condition is replaced by a KMS condition, but it seems hard to define this in your purely algebraic context.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43804")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2010")])]

#text("In exercise 2, it seems that (5) and (6) give only = ?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/beeed5597923941b57f8b6628c32b825df93f93c87f5d099c69c3d39a2aab865-1f23b8cd15b3653b08bf6d1ea41ea9dbcc1dd08aecad4e897d884cd84dc0fa64.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sungjin Kim")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43805")[#strong[#text("Sungjin Kim")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2010")])]

#text("In exercise 2, it seems (5) and (6) give only $\\leq$, and it is enough for the rest of argument. How is it possible to obtain $\\geq$ ?")#linebreak()#text(" p.s. $\\leq$ and $\\geq$ has been disappeared in previous comment because of HTML..")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43832")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 March 2010")])]

#text("From (5), we have ")#mi("\\tau(X^k) \\geq (\\rho(X)-\\epsilon)^k")#text(" whenever k is even and sufficiently large depending on ")#mi("\\varepsilon")#text(". This is enough to obtain the lower bound (though, as you say, it is not strictly necessary to have this bound for the application at hand).")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 8: The circular law « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-43886")[#strong[#text("254A, Notes 8: The circular law « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 March 2010")])]

#text("[…] failure of the moment method also shows that methods of free probability (Notes 5) do not work directly. For instance, observe that for fixed , and (in the noncommutative […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2df8ddd7022a8e843e49120b9cf229e19d7492d7f64d0da0e56fda01048e8cd6-190153de264712b6c6d8de7f720f70f25413f519cda397fb2f2d92b2c2baa6bd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of wang")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-44060")[#strong[#text("wang")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2010")])]

#text("Maybe the title “245A, Notes 5: Free probability” should be “254A …”. When I search your")#linebreak()#text(" 245A notes in google (terrytao 245a), I get here :-)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cb8ba38b00d9b995f8af73bcb4496496fe1a96a0db20191f290a7b061325dc3e-5f6bb55c5f5c5e7e885ddd26df2209a39bdc5d2e7c6899a3b180448eb1fce7f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aaron F.")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-45295")[#strong[#text("Aaron F.")]]#text(size: 9pt, fill: rgb("596477"), " · 2 June 2010")])]

#text("Maybe it’s just my browser (Firefox 3.0.19), but some of the displayed equations seem to be missing! I’ve noticed gaps in the following places:")

#text("“The measure {\\mu_X} is related to the moments {\\tau(X^k) = \\mathop{\\mathbb E} X^k} by the formula…”")

#text("“it is natural to try to define this measure through the formula (1), or equivalently (by linearity) through the formula…”")

#text("“In fact, one has the more general formula…”")

#text("“In the normal case, one may hope to work with the more general formula…”")

#text("“we can define the spectral radius {\\rho(X)} of a self-adjoint element {X} by the formula…”")

#text("“in which case we obtain the inequality…”")

#emph[#text("[Fixed, thanks – T.]")]

#text("p.s. Even with missing equations, these notes are wonderful. :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-46294")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2010")])]

#text("It could be my browser, but I think there is a missing “1/2” in")

#text("is a semi-definite inner product space with semi-norm")#linebreak()#text(" []:=(_{L^2(\\tau)})^{1/2}=[]")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-46338")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2010")])]

#text("It seems like the last modification change some latex code, because the numered equation are missing and the equations are not centered.")

#emph[#text("[Fixed, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-46376")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2010")])]

#text("I have notice some typos (if I’m not misunderstanding something).")

#text("In the definition of spectral radius the exponent is 1/(2K) [instead 1/2k].")

#text("In Exercise 6 the formula must say \\mu_X(x) [instead \\mu_X(z)].")

#text("I think that the right side of the equation that follows “cyclic property of trace and induction.) We conclude that” must be 1. The next equation shouldn’t be \\tau(…)=s?")

#text("In the last formula of exercise 20, you use \\kappa instead C (but using C we have two letters C, for free cumulants and for cells).")

#text("In remark 8, I think there is a missing link in “these notes of Speicher”.")

#emph[#text("[Corrected, thanks – T.]")]

#text("Nice notes, I learned a lot. Thanks!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-46457")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2010")])]

#text("In the last formula of exercise 20, kappa is used for free cumulants, while the right letter is C.")

#text("Thanks a lot.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3a1c0729754a5831d15c016e49d8df86edee83e15d3d801b6bf09c34574b4a39-5221f8f2b3d20fe7a82fc382f4831eb20e1d23c3d9725bc1c36ba3c9b2112d74.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Free Probability | Honglang Wang's Blog")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-48396")[#strong[#text("Free Probability | Honglang Wang's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 30 November 2010")])]

#text("[…] link about the survey of free probability. I hope it will be useful for you. Terry Tao also have a post about […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1707bf3c9194bdac5671487a4413d60eda99a805670e2b6c759d86d43c3e3cd3-e5d5774ebda83023fddaf502d84963f1343ba57c0d144a9b22683696897d5674.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of FP Recent Follows « YW's E-Profile")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-50545")[#strong[#text("FP Recent Follows « YW's E-Profile")]]#text(size: 9pt, fill: rgb("596477"), " · 3 March 2011")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")[#text("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/22f0c527e265ed08bd12642d5c1becf053e15382d9ea72dfe4ee2982b6db1158-15b89af7dcc74921a108c6a3119208f32d5987777eb434a392002e8a41b551da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jérôme Chauvet")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-54069")[#strong[#text("Jérôme Chauvet")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2011")])]

#text("Dear Pr. Tao,")

#text("What if one is considering a setting {A,B}, with A and B being 2 (real-valued) sqaure matrices that do not commute with each other + a composition law on this set + a recursion that chooses at random for each step the multiplication order according to a Bernouilli law as follows:")

#text("u(n+1) = ABu(0) or u(n+1) = BAu(0)")

#text("I guess one instance of the recursion up to p (amongst 2^p of them) would look like:")

#text("u(n+p) = ABBABAAB….BAu(0)")

#text("And it would be akin to some sort of chaotic matrix K such that:")

#text("u(n+p) = K u(0) where X=ABBABAAB….BA")

#text("Though being not properly a random matrix (I mean matrices for which coefficients are gaussian variables…)")

#text("The question is: Would the probability measure of this system attainable by the theory you are presenting here?")

#text("Thanks a lot :)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-54085")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2011")])]

#text("Random products of fixed matrices are well studied, being related to random walks on groups and expander graphs, but the regime studied (long products of small matrices) is different from the one where free probability is useful (short products of large matrices) and other tools are used instead (entropy, representation theory, spectral gaps, etc.).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-135325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2012")])]

#text("Prof Tao,")#linebreak()#text(" Scalar (commutative) random variables should be a special case of non-commutative random variables, so I think that in this special case the two kinds of convolutions should be the same? But then we would have two central limit theorem with two different limit distribution?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-135328")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2012")])]

#text("Also, if A is a symmetric matrix, with entries i.i.d. Gaussian, the distribution of it is NOT the semicircle law. Then we take sum of n copies of it and divided by square root of n, and we get the same matrix, but on the other hand it converges to semicircle law?")

#text("I guess there is something fundamental that I misunderstood.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-135341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2012")])]

#text("Sorry I read your notes again, and found that freeness is not the same with independence even in the commuting case! Please ignore my question!")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-160893")[#strong[#text("Noncommutative probability « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 18 August 2012")]

#text("[…] noncommutative probability provides such an approach. Terence Tao’s notes on free probability develop a version of noncommutative probability approach geared towards applications to random […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-185895")[#strong[#text("Walsh’s ergodic theorem, metastability, and external Cauchy convergence « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 October 2012")])]

#text("[…] any , which we will use in the sequel without further comment; see e.g. these previous blog notes for proofs. (Actually, for the purposes of proving Theorem 3, one can specialise to the case (and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63ec942ae1060d42937a74c35b08d2ec7a2ef0a3833194d6f987d4c3cac41010-777c3130775f8467a4585aaa7a16722466118b96293272754ad4436a1b425267.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shubhashedthikere")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-271400")[#strong[#text("shubhashedthikere")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("Prof Tao,")

#text("I needed clarification regarding Example 3: Random matrix variables. Here is the space of random matrices a tensor product of the vector space L^{\\infty-}( which is infinite dimensional) and (finite dimensional) vector space M_n({\\bf C})? If yes, could you please tell me how would a tensor product for an infinite dimensional vector space is defined?")#linebreak()#text(" If {X \\in L^{\\infty-} \\otimes M_n({\\bf C})}, is not tensor product, then, could you please explain what exactly is this space of random matrices?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-271425")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 February 2014")])]

#text("If ")#mi("V")#text(" is an infinite-dimensional vector space and ")#mi("W")#text(" is a finite-dimensional vector space, one can define the tensor product by selecting a basis ")#mi("e_1,\\dots,e_n")#text(" for ")#mi("W")#text(" and defining ")#mi("V \\otimes W")#text(" to be the set of all formal vectors of the form ")#mi("v_1 \\otimes e_1 + \\dots + v_n \\otimes e_n")#text(" with ")#mi("v_1,\\dots,v_n \\in V")#text(", with the vector space operations defined in the obvious manner. This defines a vector space ")#mi("V \\otimes W")#text(" with a bilinear tensor product ")#mi("\\otimes: V \\times W \\to V \\otimes W")#text(" which obeys the usual tensor product axioms, and up to isomorphism this space does not depend on the choice of basis ")#mi("e_1,\\dots,e_n")#text(".")

#text("In the specific case ")#mi("L^{\\infty-} \\otimes M_n({\\bf C})")#text(", this construction gives the space of ")#mi("n \\times n")#text(" matrices whose entries are all in ")#mi("L^{\\infty-}")#text(", i.e. random matrices with all moments finite.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Algebraic probability spaces | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-381791")[#strong[#text("Algebraic probability spaces | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")])]

#text("[…] probability space, and is very similar to the non-commutative probability spaces studied in this previous post, except that these spaces are now commutative (and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9cd3293b17fc4102811ce87a71f982a006bff024f4fadf65e5afe06087907fc0-4ba76bf4fed42f8a2ca5c337f3ef79cd4db842b060b6a124a522d20c80bf75fd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mustafa Said")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-381830")[#strong[#text("Mustafa Said")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2014")])]

#text("Is there a version of the Erdos probabilistic method in the non-commutative setting?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c5c4c27718b941167be10cde6fc261956143f68fb87e4e025b71be9031dae19-b6d8d027ace0465da90fb89a1a3230df61924a8e0d886ed735f257853e0743ed.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-454167")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 April 2015")])]

#text("Could I ask for some hint to prove the first inequality in Exercise 3? My idea was to write the normal operator in terms of the bounded self-adjoint and commuting real and imaginary components. For the first two values of the exponent (1 and 2) it follows from the obvious identities (including Schwarz inequality). The case when the exponent is 3 or 4 has already some issues: some generalized (or perhaps smarter) versions of Schwarz inequality seem to be needed. I can handle the case 3 but the case 4 is even harder. Any suggestion?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-454177")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 17 April 2015")])]

#text("If ")#mi("X")#text(" is normal, then ")#mi("(X^* X)^k = (X^k)^* X^k")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a2974779f533889fb76725c17cf1336a8617164e207b1a801c673d9d309ae7a3-693dbb6eafdebd52a338e8e1177cfb49cb8cbe46296a6f4c9db502c0d48d2219.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tornado92")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-479411")[#strong[#text("tornado92")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2017")])]

#text("A few typos: In Exercises 19 and 20, the final “additional formulas” seem to be swapped. Also, I think the formula for the third cumulant should actually be equal to the formula given for the third free cumulant. I guess they start differing at ")#mi("k = 4")#text("…")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0552d206f45423abe782901b588a9c45106d274afb903231b49b9a583a34b1e-e4f2b6f49b92ff64fee5f8cd3d4d9fbf268d8b8882eece3b23bd45c57c8d1c34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ranjan")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-481225")[#strong[#text("Ranjan")]]#text(size: 9pt, fill: rgb("596477"), " · 25 May 2017")])]

#text("The Expected value of f(X) not necessarily 0 for being independent with Y, please change the above notation.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f0552d206f45423abe782901b588a9c45106d274afb903231b49b9a583a34b1e-e4f2b6f49b92ff64fee5f8cd3d4d9fbf268d8b8882eece3b23bd45c57c8d1c34.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of numberoftargets")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-485738")[#strong[#text("numberoftargets")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("It is never mentioned that expected of f(X) needs to be 0 for being independent with Y.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08d760d7d31285c7d925d34ea210680fd3049bc3ff0a6fd1243e2c9d5005aeb8-253f48a58ee9b3c67cecf14847b615b257ee5ddd3de765622f1696cf1c488010.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of burakcakmakblog")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-485721")[#strong[#text("burakcakmakblog")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("Professor, In section 4 (i.e. Free convolution), how do you guarantee that we can expand ")#mi("(1-E_XE_Y)^{-1}")#text(" into a (formal) Neumann series? Because it requires that ")#mi("E_XE_Y")#text(" has the bounded eigenvalues below one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-485726")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2017")])]

#text("A ")#link("https://en.wikipedia.org/wiki/Formal_power_series")[#text("formal series")]#text(" does not require the partial sums to converge; in particular, a formal Neumann series such as ")#mi("\\sum_{n=0}^\\infty T^n")#text(" is well-defined even if ")#mi("T")#text(" has spectral radius larger than 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-486311")[#strong[#text("Inverting the Schur complement, and large-dimensional Gelfand-Tsetlin patterns | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2017")])]

#text("[…] these previous notes for a discussion of free probability topics such as the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1ff7b7b97baaf91acd8359810205248984a41123b75c7f0baf0bb81e5b3a20bf-9fd4782f744e17e3c94836250b6b475824557c732960f19210e462d3a72dc775.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tornado92")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-497395")[#strong[#text("tornado92")]]#text(size: 9pt, fill: rgb("596477"), " · 27 April 2018")])]

#text("Possible typo: Example 3 states that for deterministic matrices, the spectral radius is the operator norm. This seems false–for example, what if the matrix is nilpotent? Then the spectral radius is zero, but the operator norm could easily be nonzero. I guess you need the matrix to be normal for this to work.")

#text("Another question: For bounded operators on a Hilbert space, there is already an existing notion of spectral radius, which is simply the radius of the smallest disc containing the spectrum. It turns out this is the limit of the kth root of the operator norm of the kth power, as k goes to infinity. However, in these notes, the spectral radius is defined in terms of the state. So my question is, is the spectral radius independent of the state you choose? If not, is there a state for which you recover the existing notion of spectral radius?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-497491")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2018")])]

#text("In these notes the spectral radius is only defined for self-adjoint elements. In the case where the noncommutative probability space is a space of bounded operators on a Hilbert space with trace given by a state, the spectral radius on this noncommutative space will always be bounded by the operator norm, and one will have equality as long as the state has a nontrivial component at the edge of the spectrum of the Hilbert space operator.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76a8c0d5eb2350f01abae1f66d91357ff482183aa1e2d8b786515df4ccb515fc-8a1f824969c9882fdf50f442379dff8ac43e376b2eeb7108e371c48375f6488f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tpfly")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-506723")[#strong[#text("tpfly")]]#text(size: 9pt, fill: rgb("596477"), " · 1 November 2018")])]

#text("Dear Mr. Tao,")

#text("I think I’ve found a counterexample of Exercise 28 (if I didn’t misunderstand the concept of free independence). Take ")#mi("X, Y")#text(" iid random variables uniformly distributed on the unit circle, with ")#mi("\\tau(\\cdot)=\\mathcal{E}(\\cdot)")#text(". then for any polynomial P, ")#mi("\\tau(P(X))=0")#text(" iff ")#mi("P(z)=a_1z+\\cdots+a_n z^n")#text(".")

#text("Now suppose ")#mi("P_i")#text(", ")#mi("Q_i")#text(" are polynomials without constant term, then we have")#linebreak()#text(" ")#mi("\\tau(P_1(X)\\cdots P_m(X) Q_1(Y)\\cdots Q_n(Y))=0")#text(". As defined, ")#mi("X,Y")#text(" are freely independent. But they are not scalars.")

#text("Maybe in the definition of free independence we should be able to take ")#mi("X_{i_m}^*")#text(" in the polynomials?")

#emph[#text("[Oops, I meant to insert the hypothesis that ")#mi("X,Y")#text(" are self-adjoint -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac46eaa43e27dcdb6b1743217499831f1cdd2b95be0a2adee8aa32156e73104f-e637336181be78c5564ad236116b9cc7648ed1100be329d8709208566fb6f349.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bharath Krishnan")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-521304")[#strong[#text("Bharath Krishnan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("Dear Professor Tao,")

#text("This does not directly address your post but is related to probability/measure theory. Measure theory, for continuous functions, has always been based on intuition. Currently, the most intuitive and well-known measure of functions defined in ")#mi("[a,b]\\cap\\mathbb{R}")#text(", is the Lebesgue measure. However, when the Lebesgue measure of a function’s domain, defined on a subset of ")#mi("[a,b]")#text(" is zero, the average could be outside the infimum and supremum of the function’s range. Since the average is strongly related to the measure and integration, we can say the Lebesgue measure is not intuitive enough.")

#text("If the Lebesgue measure is not intuitive enough what is an intuitive, unique average of a function on any domain.")

#text("There is a website below-showing intuitions and measures that I and other people think are alternatives to Lebesgue measure when the measure of the domain is zero.")

#link("https://math.stackexchange.com/questions/3329506/most-intuitive-average-of-p-for-all-x-in-a-cap-a-b-where-a-subseteq-m")[#text("https://math.stackexchange.com/questions/3329506/most-intuitive-average-of-p-for-all-x-in-a-cap-a-b-where-a-subseteq-m")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0afe674e2c853e9e295f7f676f20e24e0bc124693975dbc4932739adac2f362-e9ccd92a4c970b11469571570e1247f1522cb3805d4c3ef75595d819e6f16b5f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of States on *-Algebras | Almost Sure")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-531869")[#strong[#text("States on *-Algebras | Almost Sure")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2019")])]

#text("[…] the semi-norm defined above. Interestingly, Terry Tao uses exactly this definition of the norm in his posts on NC probability, although he does concentrate on tracial […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-638624")[#strong[#text("co.combinatorics - Combinatorial/diagrammatic fashions totally free significance partition polynomials Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2021")]

#text("[…] relationships“by Ebrahimi-Fard, Foissy, Kock and Patras; Ex. 37 by Terry Tao’s Notes on free chance; and P. 22 of “Enumeration geometry, tau capabilities and Heisenberg-Virasoro […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-638913")[#strong[#text("co.combinatorics - Combinatorics for the motion of Virasoro / Kac-Schwarz operators: partition polynomials of free chance principle Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2021")]

#text("[…] relationships“by Ebrahimi-Fard, Foissy, Kock and Patras; Ex. 37 by Terry Tao’s Notes on free chance; and P. 22 of “Enumeration geometry, tau features and Heisenberg-Virasoro algebra“by […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71ccf2c5c8d0ac4c0659e1f1b4454d91a63a6d84d79db49511d802fb984faa1a-0396fb41db75267c2009670e88689ec22e5079f0ade116f887b3667b2f79c0cd.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom Copeland")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-639241")[#strong[#text("Tom Copeland")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2022")])]

#text("The previous two spam pingbacks from Lord Web contain corrupted copies of my MO-Q that completely algebraically characterizes the transformations between the free cumulants and moments for the single variable case, an alternative to Ex. 37 above, related to Kac-Schwarz operators. Correct version: ")#link("https://mathoverflow.net/questions/412573/combinatorics-for-the-action-of-virasoro-kac-schwarz-operators-partition-poly")[#text("Combinatorics for the action of Virasoro / Kac–Schwarz operators: partition polynomials of free probability theory")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac23f4527e208bc0ab8b947a370ebbc247b1dac2dd09955f2903265e3bd8fbb2-b74bea799a6182730fb833c5e8ff2d075bce4d5d6c0dd0d6d47530cb3b04208b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of What is the trace? – Alexander Van Werde")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-650619")[#strong[#text("What is the trace? – Alexander Van Werde")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2022")])]

#text("[…] probability theory is a beautiful subject but it would lead us too far to go into detail here. See this blog post by Terrence Tao or the list of literature on Roland Speicher’s blog if you wish to […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-689249")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2025")])]

#text("Dr Tao,")

#text("Some typos here: ignoring “both” the presence of the original sample space, the algebra of events, “or” the probability measure should be: ignoring the…, the…, and the…")

#text("Also, in remark 10: …start define… should be start defining or start to define.")

#text("And I have a question: you said that Sample Space’s elements represent all the possible “states” that one’s “stochastic system” could be in, what do you mean “state” and “stochastic system”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-689251")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2025")])]

#text("Thanks for the corrections! “state” here refers to the interpretation of a sample space as a ")#link("https://en.wikipedia.org/wiki/State-space_representation")[#text("state space")]#text(", where the underlying physical system exhibits ")#link("https://en.wikipedia.org/wiki/Stochastic")[#text("stochasticity")]#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-689399")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2025")])]

#text("Thanks for the reply Dr Tao!")

#text("Found another small typo: …we can now define “an” positive… should be “a”.")

#text("I have other questions:")

#text("(a) I get what you mean by interpreting the Sample Space as the State Space now, but I seen you mentioned in other posts that Sample Space is interpreted as all the possible outcomes of sources of randomness. Thus, I think these two perspectives are equivalent because one can both interpret a coin flip as a source of randomness and also a stochastic system right?")

#text("(b) I asked two different AI if the terms stochastic/stochasticity and random/randomness are the same (eg stochastic system vs random system), but one said Yes while the other said..No? I am confused..")

#text("(c) In statistics and many probabilistic contexts, there is a term called Sample. Is there any connections between Sample Space and Sample? Or that’s just an accident?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/07f3454c94a4bacc4a3e7e3fe4810041d6350375554141c6a5334827cd714ab8-40a5b10c5ffe20e25a92756e57d2c620747fa01c99812ebbf0184750e2a85181.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Viktor Jahnke")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-691748")[#strong[#text("Viktor Jahnke")]]#text(size: 9pt, fill: rgb("596477"), " · 6 February 2026")])]

#text("Dear Professor Tao,")

#text("Have you consider a possible relevance of free probability to extend classical ergodic theory to the quantum realm?")

#text("As you know, in classical ergodic theory, one classifies the dynamics according to the degree of unpredictability under time evolution, which means future events become statistically independent from past events. Since a quantum mechanical system is a canonical example of a non-commutative probability space, it seems very natural to me that a quantum version of classical ergodic theory should be based on free probability theory, and one can in principle classify the dynamics by the degree to which Heisenberg time-evolved operators become freely independent from operators at the initial time.")

#text("Interestingly, the free independence between two centered operators A(0) and B(t), implies the vanishing of the following out-of-time-order correlators: <A(0)B(t)A(0)B(t)> , as well as many other correlators. These out-of-time-order correlators have received considerable attention in the physics community, as they diagnose how quantum information becomes delocalized under time evolution in quantum many-body systems, a phenomenon commonly referred to as scrambling of quantum information. To me, that suggests that quantum ergodic theory based on free probability would be very useful in physics.")

#text("I would appreciate hearing your thoughts on this idea.")

#text("Best,")#linebreak()#text("Viktor")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-691759")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2026")])]

#text("The (closely related) areas of ")#link("https://en.wikipedia.org/wiki/Quantum_chaos")[#text("quantum chaos")]#text(", ")#link("https://en.wikipedia.org/wiki/Quantum_ergodicity")[#text("quantum ergodicity")]#text(" (equidistribution of most eigenfunctions) and ")#link("https://austms.org.au/wp-content/uploads/Gazette/2011/Jul11/TechPaperHassell.pdf")[#text("quantum unique ergodicity")]#text(" (equidistribution of *all* eigenfunctions in the high energy limit) are quite well established; but while they do share the same basic language of noncommutative probability (or tracial von Neumann algebras) as free probability, the specific notions of free independence, free convolution, etc. typically do not play much of a role. See also ")#link("https://chatgpt.com/share/698bd77b-6d1c-800e-a992-9a9260b9403d")[#text("this AI answer")]#text(" to the same question.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-691762")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 February 2026")])]

#text("Technical issue: the AI answer did not appear for me. Cheers, Dr Hayes")

#emph[#text("[Link corrected – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-693403")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2026")])]

#text("Prof. Tao: Could de Finetti’s theorem be better understood from the perspective of free probability theory, as opposed to classical (Kolmogorov) probability theory? I’d like to hear your thoughts.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/02/10/245a-notes-5-free-probability/#comment-693404")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 July 2026")])]

#text("An ")#link("https://claude.ai/share/8dc1e9a3-690c-4bb9-b4d0-1604705b03b8")[#text("AI query")]#text(" uncovered ")#link("https://arxiv.org/abs/1511.05651")[#text("this paper")]#text(" on the topic.")
]
]
]
