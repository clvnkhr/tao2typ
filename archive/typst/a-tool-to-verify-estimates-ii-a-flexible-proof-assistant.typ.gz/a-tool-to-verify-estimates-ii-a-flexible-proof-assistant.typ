// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/
// Converted to Typst by tao2typ: "2026-10-14T15:21:05.878767+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "A tool to verify estimates, II: a flexible proof assistant", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("A tool to verify estimates, II: a flexible proof assistant")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 May 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/")[#text("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("In a ")#link("https://terrytao.wordpress.com/2025/05/01/a-proof-of-concept-tool-to-verify-estimates/")[#text("recent post")]#text(", I talked about a ")#link("https://terrytao.wordpress.com/2025/05/01/a-proof-of-concept-tool-to-verify-estimates/")[#text("proof of concept tool")]#text(" to verify estimates automatically. Since that post, I have overhauled the tool twice: ")#link("https://github.com/teorth/estimates/blob/main/src/ver_1_0/README.md")[#text("first")]#text(" to turn it into a rudimentary proof assistant that could also handle some propositional logic; and second into a much more flexible proof assistant (deliberately designed to mimic the Lean proof assistant in several key aspects) that is also powered by the extensive Python package ")#link("https://www.sympy.org/en/index.html")[#text("sympy")]#text(" for symbolic algebra, following the feedback from previous commenters. This I think is now a stable framework with which one can extend the tool much further; my initial aim was just to automate (or semi-automate) the proving of asymptotic estimates involving scalar functions, but in principle one could keep adding tactics, new sympy types, and lemmas to the tool to handle a very broad range of other mathematical tasks as well.")

#text("The current version of the proof assistant can be found ")#link("https://github.com/teorth/estimates")[#text("here")]#text(". (As with my previous coding, I ended up ")#link("https://chatgpt.com/share/681e61ec-2bf8-800e-8390-213ee0554015")[#text("relying heavily")]#text(" on large language model assistance to understand some of the finer points of Python and sympy, with the autocomplete feature of Github Copilot being particularly useful.) While the tool can support fully automated proofs, I have decided to focus more for now on semi-automated interactive proofs, where the human user supplies high-level “tactics” that the proof assistant then performs the necessary calculations for, until the proof is completed.")

#text("It’s easiest to explain how the proof assistant works with examples. Right now I have implemented the assistant to work inside the ")#link("https://en.wikibooks.org/wiki/Python_Programming/Interactive_mode")[#text("interactive mode of Python")]#text(", in which one enters Python commands one at a time. (Readers from my generation may be familiar with text adventure games, which have a broadly similar interface.) I would be interested developing at some point a graphical user interface for the tool, but for prototype purposes, the Python interactive version suffices. (One can also run the proof assistant within a Python script, of course.)")

#text("After downloading the relevant files, one can launch the proof assistant inside Python by typing ")#raw("from main import *")#text(" and then loading one of the pre-made exercises. Here is one such exercise:")

#raw(">>> from main import *\n>>> p = linarith_exercise()\nStarting proof.  Current proof state:\nx: pos_real\ny: pos_real\nz: pos_real\nh1: x < 2*y\nh2: y < 3*z + 1\n|- x < 7*z + 2", block: true)

#text("This is the proof assistant’s formalization of the following problem: If ")#mi("x,y,z")#text(" are positive reals such that ")#mi("x < 2y")#text(" and ")#mi("y < 3z+1")#text(", prove that ")#mi("x < 7z+2")#text(".")

#text("The way the proof assistant works is that one directs the assistant to use various “tactics” to simplify the problem until it is solved. In this case, the problem can be solved by linear arithmetic, as formalized by the ")#raw("Linarith()")#text(" tactic:")

#raw(">>> p.use(Linarith())\nGoal solved by linear arithmetic!\nProof complete!", block: true)

#text("If instead one wanted a bit more detail on how the linear arithmetic worked, one could have run this tactic instead with a ")#raw("verbose")#text(" flag:")

#raw(">>> p.use(Linarith(verbose=true))\nChecking feasibility of the following inequalities:\n1*z > 0\n1*x + -7*z >= 2\n1*y + -3*z < 1\n1*y > 0\n1*x > 0\n1*x + -2*y < 0\nInfeasible by summing the following:\n1*z > 0 multiplied by 1/4\n1*x + -7*z >= 2 multiplied by 1/4\n1*y + -3*z < 1 multiplied by -1/2\n1*x + -2*y < 0 multiplied by -1/4\nGoal solved by linear arithmetic!\nProof complete!", block: true)

#text("Sometimes, the proof involves case splitting, and then the final proof has the structure of a tree. Here is one example, where the task is to show that the hypotheses ")#mi("(x>-1) \\wedge (x<1)")#text(" and ")#mi("(y>-2) \\wedge (y<2)")#text(" imply ")#mi("(x+y>-3) \\wedge (x+y<3)")#text(":")

#raw(">>> from main import *\n>>> p = split_exercise()\nStarting proof.  Current proof state:\nx: real\ny: real\nh1: (x > -1) & (x < 1)\nh2: (y > -2) & (y < 2)\n|- (x + y > -3) & (x + y < 3)\n>>> p.use(SplitHyp(\"h1\"))\nDecomposing h1: (x > -1) & (x < 1) into components x > -1, x < 1.\n1 goal remaining.\n>>> p.use(SplitHyp(\"h2\"))\nDecomposing h2: (y > -2) & (y < 2) into components y > -2, y < 2.\n1 goal remaining.\n>>> p.use(SplitGoal())\nSplit into conjunctions: x + y > -3, x + y < 3\n2 goals remaining.\n>>> p.use(Linarith())\nGoal solved by linear arithmetic!\n1 goal remaining.\n>>> p.use(Linarith())\nGoal solved by linear arithmetic!\nProof complete!\n>>> print(p.proof())\nexample (x: real) (y: real) (h1: (x > -1) & (x < 1)) (h2: (y > -2) & (y < 2)): (x + y > -3) & (x + y < 3) := by\n  split_hyp h1\n  split_hyp h2\n  split_goal\n  . linarith\n  linarith", block: true)

#text("Here at the end we gave a “pseudo-Lean” description of the proof in terms of the three tactics used: a tactic ")#raw("cases h")#text("1 to case split on the hypothesis ")#raw("h1")#text(", followed by two applications of the ")#raw("simp_all")#text(" tactic to simplify in each of the two cases.")

#text("The tool supports asymptotic estimation. I found a way to implement the")#link("https://terrytao.wordpress.com/2025/05/04/orders-of-infinity/")[#text(" order of magnitude formalism from the previous post")]#text(" within sympy. It turns out that sympy, in some sense, already natively implements nonstandard analysis: its symbolic variables have an ")#raw("is_number")#text(" flag which basically corresponds to the concept of a “standard” number in nonstandard analysis. For instance, the ")#raw("sympy")#text(" version ")#raw("S(3)")#text(" of the number 3 has ")#raw("S(3).is_number == True")#text(" and so is standard, whereas an integer variable ")#raw("n = Symbol(\"n\", integer=true)")#text(" has ")#raw("n.is_number == False")#text(" and so is nonstandard. Within ")#raw("sympy")#text(", I was able to construct orders of magnitude ")#raw("Theta(X)")#text(" of various (positive) expressions ")#raw("X")#text(", with the property that ")#raw("Theta(n)=Theta(1)")#text(" if ")#raw("n")#text(" is a standard number, and use this concept to then define asymptotic estimates such as ")#mi("X \\lesssim Y")#text(" (implemented as ")#raw("lesssim(X,Y)")#text("). One can then apply a logarithmic form of linear arithmetic to then automatically verify some asymptotic estimates. Here is a simple example, in which one is given a positive integer ")#mi("N")#text(" and positive reals ")#mi("x,y")#text(" such that ")#mi("x \\leq 2N^2")#text(" and ")#mi("y < 3N")#text(", and the task is to conclude that ")#mi("xy \\lesssim N^4")#text(":")

#raw(">>> p = loglinarith_exercise()\nStarting proof.  Current proof state:\nN: pos_int\nx: pos_real\ny: pos_real\nh1: x <= 2*N**2\nh2: y < 3*N\n|- Theta(x)*Theta(y) <= Theta(N)**4\n>>> p.use(LogLinarith(verbose=True))\nChecking feasibility of the following inequalities:\nTheta(N)**1 >= Theta(1)\nTheta(x)**1 * Theta(N)**-2 <= Theta(1)\nTheta(y)**1 * Theta(N)**-1 <= Theta(1)\nTheta(x)**1 * Theta(y)**1 * Theta(N)**-4 > Theta(1)\nInfeasible by multiplying the following:\nTheta(N)**1 >= Theta(1) raised to power 1\nTheta(x)**1 * Theta(N)**-2 <= Theta(1) raised to power -1\nTheta(y)**1 * Theta(N)**-1 <= Theta(1) raised to power -1\nTheta(x)**1 * Theta(y)**1 * Theta(N)**-4 > Theta(1) raised to power 1\nProof complete!", block: true)

#text("The logarithmic linear programming solver can also handle lower order terms, by a rather brute force branching method:")

#raw(">>> p = loglinarith_hard_exercise()\nStarting proof.  Current proof state:\nN: pos_int\nx: pos_real\ny: pos_real\nh1: x <= 2*N**2 + 1\nh2: y < 3*N + 4\n|- Theta(x)*Theta(y) <= Theta(N)**3\n>>> p.use(LogLinarith())\nGoal solved by log-linear arithmetic!\nProof complete!", block: true)

#text("I plan to start developing tools for estimating function space norms of symbolic functions, for instance creating tactics to deploy lemmas such as Holder’s inequality and the Sobolev embedding inequality. It looks like the ")#raw("sympy")#text(" framework is flexible enough to allow for creating further object classes for these sorts of objects. (Right now, I only have ")#link("https://github.com/teorth/estimates/blob/main/docs/lemmas.md")[#text("one proof-of-concept lemma")]#text(" to illustrate the framework, the arithmetic mean-geometric mean lemma.)")

#text("I am satisfied enough with the basic framework of this proof assistant that I would be open to further suggestions or contributions of new features, for instance by introducing new data types, lemmas, and tactics, or by contributing example problems that ought to be easily solvable by such an assistant, but are currently beyond its ability, for instance due to the lack of appropriate tactics and lemmas.")

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ed81f0bdf6c0c13911a7b03c6f4b492a1451f540ab3ca25d66f415ad356a823c-0f6ae6ed4a34130e63579a733b88a3b05fea5f72b057ee72292072e5bd30b2da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-687970")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2025")])]

#text("Typo “$(y>-2) wedge (y<2)$” (unprocessed LaTeX)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-687995")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2025")])]

#text("minor typo: In this case, the problem can be solved by linear arithmetic, as formalize dby the ")#raw("Linarith()")#text(" tactic:")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-687996")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2025")])]

#text("Is there a particular reason why you decided to use SymPy/Python for this project, and not Lean4?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688007")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("I do eventually plan to have the ability to output the proof into a Lean certificate, but it will be significantly faster to proceed initially using the (not rigorously verified) Python/sympy tools rather than the fully verified Lean code, as the task of formally verifying proofs in Lean is still an order of magnitude slower than that of generating pseudo-proofs in say Python.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6ae709e4351caa78ecb5c5549127c27fe0e141b6036127389255b322082e9370-db00375cebf01103110634c72b4d811f003c27af23eb63b299d8694bceaf1b0d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Guanyuming He")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688015")[#strong[#text("Guanyuming He")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("Dear Prof. Tao,")

#text("If I understand correctly, your tool is like a collection of very high-level (w.r.t. proof assistants) tactics that are not fully verified down to basic axioms, because that would take too long. Are you interested in extending the tool to handle other less analysis-related jobs which are also tedious to do in a fully verified proof assistant?")

#text("More abstractly, I think an analogy can be made about your tool and compilers: many compilers can be divided into the front-end and the back-end, where the front-end analyzes the source code (making sure it is syntactically correct and semantically sound) and generates some intermediate representation of the source code, and where the back-end constructs the desired program from the intermediate presentation.")

#text("Do you like the idea to generalize your tool to act as some kind of front-end that transforms human proof ideas into some intermediate representation which are not immediately verifiable by proof assistants? This division makes such a process more modular and decouples the tool-chain, having many benefits. I don’t know if other people already have explored such an idea; your tool reminds me of the front/back-end division of compilers.")

#text("Thank you,")#linebreak()#text("Guanyuming He")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-687997")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2025")])]

#text("This is a very interesting tool, the asymptotic estimation examole is great!")

#text("Hopefully it quickly gets a largish crowd of contributors. This might be accelarated if some form of credit sytem is put in place (like a bimontly announcement of recent changes and valuable contributors, or MO like badges).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8106bb31d80e2ba791c0b1466c04ee0bb7e339ee8096f044fe14c1d90725db2f-ae81e0564290c622f39602db3f8df75da2f5c6be1f8e354be087f6dec2766850.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of brieflyhideout36ac0bd093")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-687999")[#strong[#text("brieflyhideout36ac0bd093")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2025")])]

#text("This tool can be used to prove asymptotic estimators, but is there a tool that can help to derive them? After all, to prove something, you need to have the object of proof in the first place.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688008")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("I initially view the use case for this tool as a way to certify proofs that were initially generated by traditional pen-and-paper calculations, without having to go through the more lengthy process of directly generating a proof in a full-featured proof assistant such as Lean. Once this more lightweight tool becomes stable and one has some moderately large data set of existing proofs using this tool, I could imagine that machine learning tools could then be applied to explore the proof space more, and in particular to discover new estimates that are variants of those in the training data, and supply proof certificates for them (perhaps through a two-step process in which a lightweight proof assistant such as this one is used to first produce a pseudocode proof, which is then formalized in Lean in a semi-automated or automated fashion using some other tool).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2bd3520a9a45f5a59cb99d16fec8a9fa83ec641045934efa4ed5305da1c7f76f-615006709b00526f7f45f54427581dab0e15ffd1011babc668f8c849a8f6cfe8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aidan Backus")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688001")[#strong[#text("Aidan Backus")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("A family of inequalities which might make good “targets” is given by Chapter 10 of Lindqvist’s book on the p-Laplacian (")#link("https://lqvist.folk.ntnu.no/p-laplace.pdf")[#text("https://lqvist.folk.ntnu.no/p-laplace.pdf")]#text("). These inequalities mostly follow from the usual suspects of fundamental theorem of calculus, Cauchy–Schwarz, convexity of x mapsto |x|^p, etc., but the manipulations involved are not so obvious and one may need more involved tactics to be able to prove them.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688009")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("Thanks for the suggestion! I’ll have to think about how to fit these sorts of manipulations into the current framework.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688002")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("Will you consider giving estimated probabilities (i.e. suggestions) for the next move to make in a proof? Or is that more advanced than intended?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688010")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 May 2025")])]

#text("I’m hoping that that sort of functionality can eventually be supplied by a separate layer of tools, probably powered by some sort of machine learning, once one has enough of a corpus of proofs performed using this sort of assistant to serve as suitable training data.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dc3a8747168de01c826830776cbe5d5e1094f29af68ba06adb13a4cb3f78dbe-84117f67361e0e1ed522159c7db71e9af41007b0ba41c1b1e3173c1d42172810.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of philzook58")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688016")[#strong[#text("philzook58")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("I’m interested to see where this goes! I’ve been working on a related tool in the sense that it is an interactive proof assistant in python based on z3 and to a lesser degree sympy. ")#link("https://github.com/philzook58/knuckledragger")[#text("https://github.com/philzook58/knuckledragger")]#link("https://github.com/philzook58/knuckledragger")[#text("https://github.com/philzook58/knuckledragger")]#text(" I have wondered what it would look like to switch that emphasis but found sympy to do an uncomfortable amount of unstoppable simplification under my feet, and to be developed from the CAS tradition more than a logical tradition, lacking good support for things like quantifiers, sorts, sets, or systematic logical discipline. Still very feature rich and closer to the desires, needs, and aesthetics of some engineers, physicists, and mathematicians. Asymptotic estimates was not on my radar as a good challenge problem but looks fun!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688027")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2025")])]

#text("Yes, I’m finding sympy’s simplifier to be a little too aggressive for this application. I used it in some of my tactics but I have since removed it as it was causing unwanted behavior. I may add it back as an optional flag though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688080")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2025")])]

#text("Somewhat tangential, but are you familiar with ")#link("https://en.wikipedia.org/wiki/Internal_set_theory")[#text("internal set theory")]#text("?")

#text("It is an approach to nonstandard analysis. I remember in a previous post you mentioned how in principle, you could iterate nonstandard analysis to give multiple “levels” of infinity, such that the next level sees the previous level as finite. IST natively supports this (you don’t need multiple levels of IST, it already does recursive nonstandard analysis). Not that iterating the levels manually is too hard, but it saves you some work.")

#text("It is an axiomatic approach which is ")#emph[#text("conservative")]#text(" over ZFC. In particular, it adds a “is standard” predicate such that st(0), st(1), st(2), st(3), … are all provable but so is exists H. forall n. st(n)⇒n < H. This isn’t the novel part, of course. It can also prove much more than this.")

#text("Proof that H exists: by axiom I there is a finite set G that contains every standard set, (since this is set theory, everything is sets). Let H be the maximum natural number in G. (Notice this proves that G isn’t *just* the standard sets. Any set containing all standard natural numbers must overspill. Also, by transfer, st(n) implies st(n+1).) Likewise, we can get an infinitesimal either as 1/H, or by taking the smallest positive real number in G.")

#text("Next I’ll show two of the ")#strong[#emph[#text("novel")]]#text(" things IST can do:")

#enum(start: 1, 
[#text("Given a parameter p (such as an infinite natural number, or a nonstandard sequence), define a nonstandard natural number that exceeds everything ")#emph[#text("definable")]#text(" from p. (Where by definable we always mean in the language of set theory ")#emph[#text("without")]#text(" st.)")],
[#text("Given an infinite natural number H, define a natural number J of a ")#emph[#text("lower")]#text(" level of infinity. That is, J is infinite but can not be used to define anything larger than H. H is infinite relative to J.")]
)

#text("And I’ll combine them as well.")

#text("One) Let G be a finite set such for every standard f, we have f(p) ∈ G. This exists by axiom I. Since every definable set in standard (by axiom of transfer, the definition must have a standard solution, and since it is a definition it is the unique solution), we have that the maximum natural number in G bounds every natural number definable from p.")

#text("Two) Let’s generalize a bit. Let B be a set such that every element of B is nonstandard. In our case, B is the set of natural numbers greater than or equal to H. Let G be a finite set such that for all standard x, we have x ∈ G, and if x is a function, we have forall y ∈ G. x(y) ∉ B. This exists by axiom I (since all the elements of B are nonstandard). Then the maximum natural number J in G exceeds every standard natural number, but every natural number definable from J is not in B, and so is less than H.")

#text("Combination) Let B be a set that does not contain the image of p under any standard function. (For example, the natural numbers greater than or equal to the H in the first theorem.) Let G be a finite set such that for every standard function f we have f(p) ∈ G and forall y ∈ G. f(p, y) ∉ B. Than the maximum natural number J in G exceeds anything definable from p but cannot define anything in B, even with help from p.")

#text("Note that you can replace “maximum natural number” with “maximum element in a ")#link("https://en.wikipedia.org/wiki/Directed_set")[#text("directed set")]#text("” in any of these examples. Just additionally stipulate that G has a maximum when using axiom I.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/71201f395df7767381e6f128fb702b6b806f8684a24a9f379cba33ba9c365fbe-44615daa6b4ed9c2ef237f863a907f77c1fe89e219bd8133ad8fcd03956ddad3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christopher")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688275")[#strong[#text("Christopher")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2025")])]

#text("Oh, even tho IST is interesting I just realized that these two properties aren’t too hard to achieve. In the semantic approach to nonstandard analysis, all you need is for the model to be countably saturated, or even just computably saturated. Consider a model M of, say, ZFC.")

#text("1) Finding a natural number H that is bigger than anything definable from parameters p (and thus 1/H will be an infinitesimal smaller than anything definable from p). Create a type with, for each formula φ(p, n) in the language of ZFC, the formula Ψ(H, p) := [∃ n ∈ ℕ. φ(p, n) => ∃ n ≤ H. φ(p, n)]. This is finitely satisfiable (given a finite list of Ψ, just let H be greater than a solution from each), and so by saturation there is a H that satisfies all of them. In particular, H will be greater than any natural number definable from p.")

#text("2) Finding a natural number K that is bigger than anything definable from parameters p, but such that H (satisfying the conclusion of the previous block) is bigger than anything definable from (p, K). Create a type with, for each formula φ_1(p, n) in the language of ZFC, the formula Ψ_1(K, p, H) := [∃ n ∈ ℕ. φ_1(p, n) => ∃ n ≤ K. φ_1(p, n)], and also for each formula φ_2(p, K, n) in the language of ZFC, the formula Ψ_2(K, p, H) := [∃ n ∈ ℕ. φ_2(p, K, n) => ∃ n ≤ H. φ_2(p, K, n)]. This again is finitely satisfiable. Given a finite list of Ψ, there exists N and K such that K bounds the solutions for n in the finitely many φ_1(p, n) and N bounds the solutions for n in the finitely many φ_2(p, K, n). By our hypothesis about H, we can find such a N that is ≤ H. Thus we can find K satisfying the type.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688423")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2025")])]

#text("What is the PA based on? Is it type theory, classical set theory, or …?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688425")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 July 2025")])]

#text("The PA is not designed for complete formal soundness; it uses tools such as sympy that are not certified in any formal frameworks, but are instead coded in Python and so may contain bugs like any other conventional software that has not been formally verified. I would imagine though that once a proof has been obtained in this “leaky” proof assistant, it should be relatively straightforward to translate this proof to a fully formalized proof (in one’s favorite foundations of mathematics, such as type theory or set theory), in a semi-automated or fully automated fashion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688439")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 July 2025")])]

#text("Dear Prof. Tao,")#linebreak()#text(" I’d like to work on this from the CS side, for I feel a very elegant solution is present.")

#text("Currently I’m looking for a better understanding of the problem space, i.e. the intended use cases of this tool. (for, currently class Basic contains many parameters that is never used in the examples)")

#text("Relatedly, I wish to understand if a ‘numerical test’ is possible (fitting larger numbers into variables) for your intended use case, which may provide insight to whether a direction of symbolic reasoning is correct.")

#text("Cheers! I’m quite impressed by the project, especially its well-documentedness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a3f2e143df231eb23887a4c074d3486e45ecac6b66a0676151e3e012b1280de1-36c93d88e6e96d32d599795b8e561791dc6c629fa889eace91fbc53c356885d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of -")]], [#link("https://terrytao.wordpress.com/2025/05/09/a-tool-to-verify-estimates-ii-a-flexible-proof-assistant/#comment-688872")[#strong[#text("-")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2025")])]

#text("We are happy to announce our tool O-Forge, which can prove the questions mentioned in this blogpost, as well as those mentioned in Professor Tao’s earlier MathOverflow post. You can try it here- ")#link("https://o-forge.com")[#text("https://o-forge.com")]#text(". The GitHub repo is here- ")#link("https://github.com/ayushkhaitanrutgers/decompositions-2")[#text("https://github.com/ayushkhaitanrutgers/decompositions-2")]

#text("We are very grateful to Professor Tao for suggesting several improvements to our tool and website, which have certainly made them much better.")

#text("We will also be grateful for any feedback from the users.")

#text("Some context: I was the OP on the MO post, and I spent quite some time trying to modify Alphageometry for this purpose. However, we eventually realized this summer that the set of algebraic manipulations was many orders of magnitude larger than that of plane geometry constructions, and hence this approach might not be a perfect fit here. It was only then that we learned about Mathematica’s Resolve[] function, which can rigorously complete proofs using first order logic.")

#text("We have integrated Mathematica with a frontier LLM to first divide a domain into the “correct” subdomains, which will facilitate an easy proof of the estimate, and then prompt pass code to Mathematica through an API call to complete the proof. Thanks very much, and we look forward to hearing from you. My email ID is ")#link("mailto:ayush.khaitan@rutgers.edu")[#text("ayush.khaitan@rutgers.edu")]
]
