// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/
// Converted to Typst by tao2typ: "2026-10-14T10:18:13.591001+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "An abstract ergodic theorem, and the Mackey-Zimmer theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("An abstract ergodic theorem, and the Mackey-Zimmer theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 June 2014")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")[#text("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("The ")#link("http://en.wikipedia.org/wiki/Ergodic_theory#Mean_ergodic_theorem")[#text("von Neumann ergodic theorem")]#text(" (the Hilbert space version of the mean ergodic theorem) asserts that if ")#mi("{U: H \\rightarrow H}")#text(" is a unitary operator on a Hilbert space ")#mi("{H}")#text(", and ")#mi("{v \\in H}")#text(" is a vector in that Hilbert space, then one has")

#align(center)[#tao-fit-display[#mitex("\\lim_{N \\rightarrow \\infty} \\frac{1}{N} \\sum_{n=1}^N U^n v = \\pi_{H^U} v")]]

#text("in the strong topology, where ")#mi("{H^U := \\{ w \\in H: Uw = w \\}}")#text(" is the ")#mi("{U}")#text("-invariant subspace of ")#mi("{H}")#text(", and ")#mi("{\\pi_{H^U}}")#text(" is the orthogonal projection to ")#mi("{H^U}")#text(". (See e.g. ")#link("https://terrytao.wordpress.com/2008/02/04/254a-lecture-9-ergodicity/")[#text("these previous lecture notes")]#text(" for a proof.) The same proof extends to more general ")#link("http://en.wikipedia.org/wiki/Amenable_group")[#text("amenable groups")]#text(": if ")#mi("{G}")#text(" is a countable amenable group acting on a Hilbert space ")#mi("{H}")#text(" by unitary transformations ")#mi("{g: H \\rightarrow H}")#text(", and ")#mi("{v \\in H}")#text(" is a vector in that Hilbert space, then one has ")#metadata(none) <tao-82523faea1b0f2da676a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\lim_{N \\rightarrow \\infty} \\frac{1}{\\left|\\Phi_N\\right|} \\sum_{g \\in \\Phi_N} gv = \\pi_{H^G} v", block: true)]]

#text("for any ")#link("http://en.wikipedia.org/wiki/F%C3%B8lner_sequence")[#text("Følner sequence")]#text(" ")#mi("{\\Phi_N}")#text(" of ")#mi("{G}")#text(", where ")#mi("{H^G := \\{ w \\in H: gw = w \\text{ for all }g \\in G \\}}")#text(" is the ")#mi("{G}")#text("-invariant subspace. Thus one can interpret ")#mi("{\\pi_{H^G} v}")#text(" as a certain average of elements of the orbit ")#mi("{Gv := \\{ gv: g \\in G \\}}")#text(" of ")#mi("{v}")#text(".")

#text("I recently discovered that there is a simple variant of this ergodic theorem that holds even when the group ")#mi("{G}")#text(" is not amenable (or not discrete), using a more abstract notion of averaging:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (Abstract ergodic theorem)")]#text(" ")#metadata(none) <tao-c59ddd3f7ba697a4b820>#text(" Let ")#mi("{G}")#text(" be an arbitrary group acting unitarily on a Hilbert space ")#mi("{H}")#text(", and let ")#mi("{v}")#text(" be a vector in ")#mi("{H}")#text(". Then ")#mi("{\\pi_{H^G} v}")#text(" is the element in the ")#link("http://en.wikipedia.org/wiki/Convex_hull")[#text("closed convex hull")]#text(" of ")#mi("{Gv := \\{ gv: g \\in G \\}}")#text(" of minimal norm, and is also the unique element of ")#mi("{H^G}")#text(" in this closed convex hull.")
]

#emph[#text("Proof:")]#text(" As the closed convex hull of ")#mi("{Gv}")#text(" is closed, convex, and non-empty in a Hilbert space, it is a classical fact (see e.g. Proposition 1 of ")#link("https://terrytao.wordpress.com/2009/01/17/254a-notes-5-hilbert-spaces/")[#text("this previous post")]#text(") that it has a unique element ")#mi("{F}")#text(" of minimal norm. If ")#mi("{g F \\neq F}")#text(" for some ")#mi("{g}")#text(", then the midpoint of ")#mi("{g F}")#text(" and ")#mi("{F}")#text(" would be in the closed convex hull and be of smaller norm, a contradiction; thus ")#mi("{F}")#text(" is ")#mi("{G}")#text("-invariant. To finish the first claim, it suffices to show that ")#mi("{v-F}")#text(" is orthogonal to every element ")#mi("{h}")#text(" of ")#mi("{H^G}")#text(". But if this were not the case for some such ")#mi("{h}")#text(", we would have ")#mi("{\\langle g v - F, h \\rangle = \\langle v-F,h\\rangle \\neq 0}")#text(" for all ")#mi("{g \\in G}")#text(", and thus on taking convex hulls ")#mi("{\\langle F-F,h\\rangle = \\langle f-F,h\\rangle \\neq 0}")#text(", a contradiction.")

#text("Finally, since ")#mi("{T_g v - F}")#text(" is orthogonal to ")#mi("{H^G}")#text(", the same is true for ")#mi("{F^{\\prime}-F}")#text(" for any ")#mi("{F^{\\prime}}")#text(" in the closed convex hull of ")#mi("{Gv}")#text(", and this gives the second claim. ")#mi("\\Box")

#text("This result is due ")#link("http://www.ams.org/mathscinet-getitem?mr=2026")[#text("to Alaoglu and Birkhoff")]#text(". It implies the amenable ergodic theorem ")#link(<tao-82523faea1b0f2da676a>)[#text("(1)")]#text("; indeed, given any ")#mi("{\\varepsilon>0}")#text(", Theorem ")#link(<tao-c59ddd3f7ba697a4b820>)[#text("1")]#text(" implies that there is a finite convex combination ")#mi("{v_\\varepsilon}")#text(" of shifts ")#mi("{gv}")#text(" of ")#mi("{v}")#text(" which lies within ")#mi("{\\varepsilon}")#text(" (in the ")#mi("{H}")#text(" norm) to ")#mi("{\\pi_{H^G} v}")#text(". By the triangle inequality, all the averages ")#tao-math("{\\frac{1}{\\left|\\Phi_N\\right|} \\sum_{g \\in \\Phi_N} gv_\\varepsilon}", block: false)#text(" also lie within ")#mi("{\\varepsilon}")#text(" of ")#mi("{\\pi_{H^G} v}")#text(", but by the Følner property this implies that the averages ")#tao-math("{\\frac{1}{\\left|\\Phi_N\\right|} \\sum_{g \\in \\Phi_N} gv}", block: false)#text(" are eventually within ")#mi("{2\\varepsilon}")#text(" (say) of ")#mi("{\\pi_{H^G} v}")#text(", giving the claim.")

#text("It turns out to be possible to use Theorem ")#link(<tao-c59ddd3f7ba697a4b820>)[#text("1")]#text(" as a substitute for the mean ergodic theorem in a number of contexts, thus removing the need for an amenability hypothesis. Here is a basic application:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 2 (Relative orthogonality)")]#text(" ")#metadata(none) <tao-78d8b6da76ce00e7228f>#text(" Let ")#mi("{G}")#text(" be a group acting unitarily on a Hilbert space ")#mi("{H}")#text(", and let ")#mi("{V}")#text(" be a ")#mi("{G}")#text("-invariant closed subspace of ")#mi("{H}")#text(". Then ")#mi("{V}")#text(" and ")#mi("{H^G}")#text(" are relatively orthogonal over their common subspace ")#mi("{V^G}")#text(", that is to say the restrictions of ")#mi("{V}")#text(" and ")#mi("{H^G}")#text(" to the orthogonal complement of ")#mi("{V^G}")#text(" are orthogonal to each other.")
]

#emph[#text("Proof:")]#text(" By Theorem ")#link(<tao-c59ddd3f7ba697a4b820>)[#text("1")]#text(", we have ")#mi("{\\pi_{H^G} v = \\pi_{V^G} v}")#text(" for all ")#mi("{v \\in V}")#text(", and the claim follows. (Thanks to Gergely Harcos for this short argument.) ")#mi("\\Box")

#text("Now we give a more advanced application of Theorem ")#link(<tao-c59ddd3f7ba697a4b820>)[#text("1")]#text(", to establish some “Mackey theory” over arbitrary groups ")#mi("{G}")#text(". Define a ")#emph[#mi("{G}")#text("-system")]#text(" ")#mi("{(X, {\\mathcal X}, \\mu, (T_g)_{g \\in G})}")#text(" to be a probability space ")#mi("{X = (X, {\\mathcal X}, \\mu)}")#text(" together with a measure-preserving action ")#mi("{(T_g)_{g \\in G}}")#text(" of ")#mi("{G}")#text(" on ")#mi("{X}")#text("; this gives an action of ")#mi("{G}")#text(" on ")#mi("{L^2(X) = L^2(X,{\\mathcal X},\\mu)}")#text(", which by abuse of notation we also call ")#mi("{T_g}")#text(":")

#align(center)[#tao-fit-display[#mitex("T_g f := f \\circ T_{g^{-1}}.")]]

#text("(In this post we follow the usual convention of defining the ")#mi("{L^p}")#text(" spaces by quotienting out by almost everywhere equivalence.) We say that a ")#mi("{G}")#text("-system is ")#emph[#text("ergodic")]#text(" if ")#mi("{L^2(X)^G}")#text(" consists only of the constants.")

#text("(A technical point: the theory becomes slightly cleaner if we interpret our measure spaces abstractly (or “")#link("http://en.wikipedia.org/wiki/Pointless_topology")[#text("pointlessly")]#text("“), removing the underlying space ")#mi("{X}")#text(" and quotienting ")#mi("{{\\mathcal X}}")#text(" by the ")#mi("{\\sigma}")#text("-ideal of null sets, and considering maps such as ")#mi("{T_g}")#text(" only on this quotient ")#mi("{\\sigma}")#text("-algebra (or on the associated von Neumann algebra ")#mi("{L^\\infty(X)}")#text(" or Hilbert space ")#mi("{L^2(X)}")#text("). However, we will stick with the more traditional setting of classical probability spaces here to keep the notation familiar, but with the understanding that many of the statements below should be understood modulo null sets.)")

#text("A ")#emph[#text("factor")]#text(" ")#mi("{Y = (Y, {\\mathcal Y}, \\nu, (S_g)_{g \\in G})}")#text(" of a ")#mi("{G}")#text("-system ")#mi("{X = (X,{\\mathcal X},\\mu, (T_g)_{g \\in G})}")#text(" is another ")#mi("{G}")#text("-system together with a ")#emph[#text("factor map")]#text(" ")#mi("{\\pi: X \\rightarrow Y}")#text(" which commutes with the ")#mi("{G}")#text("-action (thus ")#mi("{T_g \\pi = \\pi S_g}")#text(" for all ")#mi("{g \\in G}")#text(") and respects the measure in the sense that ")#mi("{\\mu(\\pi^{-1}(E)) = \\nu(E)}")#text(" for all ")#mi("{E \\in {\\mathcal Y}}")#text(". For instance, the ")#emph[#mi("{G}")#text("-invariant factor")]#text(" ")#mi("{Z^0_G(X) := (X, {\\mathcal X}^G, \\mu\\downharpoonright_{{\\mathcal X}^G}, (T_g)_{g \\in G})}")#text(", formed by restricting ")#mi("{X}")#text(" to the invariant algebra ")#mi("{{\\mathcal X}^G := \\{ E \\in {\\mathcal X}: T_g E = E \\text{ a.e. for all } g \\in G \\}}")#text(", is a factor of ")#mi("{X}")#text(". (This factor is the first factor in an important hierachy, the next element of which is the ")#emph[#text("Kronecker factor")]#text(" ")#mi("{Z^1_G(X)}")#text(", but we will not discuss higher elements of this hierarchy further here.) If ")#mi("{Y}")#text(" is a factor of ")#mi("{X}")#text(", we refer to ")#mi("{X}")#text(" as an ")#emph[#text("extension")]#text(" of ")#mi("{Y}")#text(".")

#text("From Corollary ")#link(<tao-78d8b6da76ce00e7228f>)[#text("2")]#text(" we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 3 (Relative independence)")]#text(" ")#metadata(none) <tao-7d25a2a61c34711e43fa>#text(" Let ")#mi("{X}")#text(" be a ")#mi("{G}")#text("-system for a group ")#mi("{G}")#text(", and let ")#mi("{Y}")#text(" be a factor of ")#mi("{X}")#text(". Then ")#mi("{Y}")#text(" and ")#mi("{Z^0_G(X)}")#text(" are relatively independent over their common factor ")#mi("{Z^0_G(Y)}")#text(", in the sense that the spaces ")#mi("{L^2(Y)}")#text(" and ")#mi("{L^2(Z^0_G(X))}")#text(" are relatively orthogonal over ")#mi("{L^2(Z^0_G(Y))}")#text(" when all these spaces are embedded into ")#mi("{L^2(X)}")#text(".")
]

#text("This has a simple consequence regarding the product ")#mi("{X \\times Y = (X \\times Y, {\\mathcal X} \\times {\\mathcal Y}, \\mu \\times \\nu, (T_g \\oplus S_g)_{g \\in G})}")#text(" of two ")#mi("{G}")#text("-systems ")#mi("{X = (X, {\\mathcal X}, \\mu, (T_g)_{g \\in G})}")#text(" and ")#mi("{Y = (Y, {\\mathcal Y}, \\nu, (S_g)_{g \\in G})}")#text(", in the case when the ")#mi("{Y}")#text(" action is trivial:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" ")#metadata(none) <tao-a8792157cb4f27fb949c>#text(" If ")#mi("{X,Y}")#text(" are two ")#mi("{G}")#text("-systems, with the action of ")#mi("{G}")#text(" on ")#mi("{Y}")#text(" trivial, then ")#mi("{Z^0_G(X \\times Y)}")#text(" is isomorphic to ")#mi("{Z^0_G(X) \\times Y}")#text(" in the obvious fashion.")
]

#text("This lemma is immediate for countable ")#mi("{G}")#text(", since for a ")#mi("{G}")#text("-invariant function ")#mi("{f}")#text(", one can ensure that ")#mi("{T_g f = f}")#text(" holds simultaneously for all ")#mi("{g \\in G}")#text(" outside of a null set, but is a little trickier for uncountable ")#mi("{G}")#text(".")

#emph[#text("Proof:")]#text(" It is clear that ")#mi("{Z^0_G(X) \\times Y}")#text(" is a factor of ")#mi("{Z^0_G(X \\times Y)}")#text(". To obtain the reverse inclusion, suppose that it fails, thus there is a non-zero ")#mi("{f \\in L^2(Z^0_G(X \\times Y))}")#text(" which is orthogonal to ")#mi("{L^2(Z^0_G(X) \\times Y)}")#text(". In particular, we have ")#mi("{fg}")#text(" orthogonal to ")#mi("{L^2(Z^0_G(X))}")#text(" for any ")#mi("{g \\in L^\\infty(Y)}")#text(". Since ")#mi("{fg}")#text(" lies in ")#mi("{L^2(Z^0_G(X \\times Y))}")#text(", we conclude from Corollary ")#link(<tao-7d25a2a61c34711e43fa>)[#text("3")]#text(" (viewing ")#mi("{X}")#text(" as a factor of ")#mi("{X \\times Y}")#text(") that ")#mi("{fg}")#text(" is also orthogonal to ")#mi("{L^2(X)}")#text(". Since ")#mi("{g}")#text(" is an arbitrary element of ")#mi("{L^\\infty(Y)}")#text(", we conclude that ")#mi("{f}")#text(" is orthogonal to ")#mi("{L^2(X \\times Y)}")#text(" and in particular is orthogonal to itself, a contradiction. (Thanks to Gergely Harcos for this argument.) ")#mi("\\Box")

#text("Now we discuss the notion of a group extension.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 5 (Group extension)")]#text(" Let ")#mi("{G}")#text(" be an arbitrary group, let ")#mi("{Y = (Y, {\\mathcal Y}, \\nu, (S_g)_{g \\in G})}")#text(" be a ")#mi("{G}")#text("-system, and let ")#mi("{K}")#text(" be a compact metrisable group. A ")#emph[#mi("{K}")#text("-extension")]#text(" of ")#mi("{Y}")#text(" is an extension ")#mi("{X = (X, {\\mathcal X}, \\mu, (T_g)_{g \\in G})}")#text(" whose underlying space is ")#mi("{X = Y \\times K}")#text(" (with ")#mi("{{\\mathcal X}}")#text(" the product of ")#mi("{{\\mathcal Y}}")#text(" and the Borel ")#mi("{\\sigma}")#text("-algebra on ")#mi("{K}")#text("), the factor map is ")#mi("{\\pi: (y,k) \\mapsto y}")#text(", and the shift maps ")#mi("{T_g}")#text(" are given by")

#align(center)[#tao-fit-display[#mitex("T_g ( y, k ) = (S_g y, \\rho_g(y) k )")]]

#text("where for each ")#mi("{g \\in G}")#text(", ")#mi("{\\rho_g: Y \\rightarrow K}")#text(" is a measurable map (known as the ")#emph[#text("cocycle")]#text(" associated to the ")#mi("{K}")#text("-extension ")#mi("{X}")#text(").")
]

#text("An important special case of a ")#mi("{K}")#text("-extension arises when the measure ")#mi("{\\mu}")#text(" is the product of ")#mi("{\\nu}")#text(" with the Haar measure ")#mi("{dk}")#text(" on ")#mi("{K}")#text(". In this case, ")#mi("{X}")#text(" also has a ")#mi("{K}")#text("-action ")#mi("{k^{\\prime}: (y,k) \\mapsto (y,k(k^{\\prime})^{-1})}")#text(" that commutes with the ")#mi("{G}")#text("-action, making ")#mi("{X}")#text(" a ")#mi("{G \\times K}")#text("-system. More generally, ")#mi("{\\mu}")#text(" could be the product of ")#mi("{\\nu}")#text(" with the Haar measure ")#mi("{dh}")#text(" of some closed subgroup ")#mi("{H}")#text(" of ")#mi("{K}")#text(", with ")#mi("{\\rho_g}")#text(" taking values in ")#mi("{H}")#text("; then ")#mi("{X}")#text(" is now a ")#mi("{G \\times H}")#text(" system. In this latter case we will call ")#mi("{X}")#text(" ")#emph[#mi("{H}")#text("-uniform")]#text(".")

#text("If ")#mi("{X}")#text(" is a ")#mi("{K}")#text("-extension of ")#mi("{Y}")#text(" and ")#mi("{U: Y \\rightarrow K}")#text(" is a measurable map, we can define the ")#emph[#text("gauge transform")]#text(" ")#mi("{X_U}")#text(" of ")#mi("{X}")#text(" to be the ")#mi("{K}")#text("-extension of ")#mi("{Y}")#text(" whose measure ")#mi("{\\mu_U}")#text(" is the pushforward of ")#mi("{\\mu}")#text(" under the map ")#mi("{(y,k) \\mapsto (y, U(y) k)}")#text(", and whose cocycles ")#mi("{\\rho_{g,U}: Y \\rightarrow K}")#text(" for ")#mi("{g \\in G}")#text(" are given by the formula")

#align(center)[#tao-fit-display[#mitex("\\rho_{g,U}(y) := U(gy) \\rho_g(y) U(y)^{-1}.")]]

#text("It is easy to see that ")#mi("{X_U}")#text(" is a ")#mi("{K}")#text("-extension that is isomorphic to ")#mi("{X}")#text(" as a ")#mi("{K}")#text("-extension of ")#mi("{Y}")#text("; we will refer to ")#mi("{X_U}")#text(" and ")#mi("{X}")#text(" as ")#emph[#text("equivalent")]#text(" systems, and ")#mi("{\\rho_{g,U}}")#text(" as ")#emph[#text("cohomologous")]#text(" to ")#mi("{\\rho_g}")#text(". We then have the following fundamental result ")#link("http://www.ams.org/mathscinet-getitem?mr=201562")[#text("of Mackey")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=409770")[#text("of Zimmer")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 6 (Mackey-Zimmer theorem)")]#text(" ")#metadata(none) <tao-1fd716531c7c018b09a7>#text(" Let ")#mi("{G}")#text(" be an arbitrary group, let ")#mi("{Y}")#text(" be an ergodic ")#mi("{G}")#text("-system, and let ")#mi("{K}")#text(" be a compact metrisable group. Then every ergodic ")#mi("{K}")#text("-extension ")#mi("{X}")#text(" of ")#mi("{Y}")#text(" is equivalent to an ")#mi("{H}")#text("-uniform extension of ")#mi("{Y}")#text(" for some closed subgroup ")#mi("{H}")#text(" of ")#mi("{K}")#text(".")
]

#text("This theorem is usually stated for amenable groups ")#mi("{G}")#text(", but by using Theorem ")#link(<tao-c59ddd3f7ba697a4b820>)[#text("1")]#text(" (or more precisely, Corollary ")#link(<tao-7d25a2a61c34711e43fa>)[#text("3")]#text(") the result is in fact also valid for arbitrary groups; we give the proof below the fold. (In the usual formulations of the theorem, ")#mi("{X}")#text(" and ")#mi("{Y}")#text(" are also required to be Lebesgue spaces, or at least standard Borel, but again with our abstract approach here, such hypotheses will be unnecessary.) Among other things, this theorem plays an important role in the Furstenberg-Zimmer structural theory of measure-preserving systems (as well as subsequent refinements of this theory by Host and Kra); see ")#link("https://terrytao.wordpress.com/2008/03/05/254a-lecture-15-the-furstenberg-zimmer-structure-theorem-and-the-furstenberg-recurrence-theorem/")[#text("this previous blog post")]#text(" for some relevant discussion. One can obtain similar descriptions of non-ergodic extensions by working relative to the invariant factor (or via the ergodic decomposition, if one has enough separability hypotheses on the system), but the result becomes more complicated to state, and we will not do so here; see ")#link("https://arxiv.org/abs/0905.0516")[#text("this paper of Austin")]#text(" for details.")

#metadata(none) <tao-83415e9053acf5078521>

#heading(level: 1)[#strong[#text(" — 1. Proof of theorem — ")]]

#text("Let ")#mi("{X, Y}")#text(" be the ")#mi("{G}")#text("-systems in Theorem ")#link(<tao-1fd716531c7c018b09a7>)[#text("6")]#text(". We can then form the product ")#mi("{G}")#text("-systems ")#mi("{X \\times K}")#text(" with trivial cocycle (endowing ")#mi("{K}")#text(" with the Haar measure ")#mi("{dk}")#text("), and also form the skew product ")#mi("{Y \\times_\\rho K}")#text(", with the shift")

#align(center)[#tao-fit-display[#mitex("(y,k) \\mapsto (S_g y, \\rho_g(y) k).")]]

#text("Our argument will hinge on the study of the factor map")

#align(center)[#tao-fit-display[#mitex("\\pi: X \\times K \\rightarrow Y \\times_\\rho K")]]

#text("defined by")

#align(center)[#tao-fit-display[#mitex("\\pi( (y,k), k^{\\prime} ) := (y, kk^{\\prime} ).")]]

#text("An application of Fubini’s theorem shows that this is indeed a factor map (because the projection from ")#mi("{X}")#text(" to ")#mi("{Y}")#text(" was already a factor map, and because multiplication in ")#mi("{K}")#text(" is associative). In fact this is a factor map of ")#mi("{G \\times K}")#text("-systems, not just ")#mi("{G}")#text("-systems, where ")#mi("{K}")#text(" acts on the right factors of ")#mi("{X \\times K}")#text(" and ")#mi("{Y \\times_\\rho K}")#text(" by ")#mi("{k^{\\prime}: (x,k) \\mapsto (x,k (k^{\\prime})^{-1})}")#text(" and ")#mi("{k^{\\prime}: (y,k) \\mapsto (y,k(k^{\\prime})^{-1})}")#text(".")

#text("Since ")#mi("{Y \\times_\\rho K}")#text(" is a factor of ")#mi("{X \\times K}")#text(" as a ")#mi("{G \\times K}")#text("-system, ")#mi("{Z^0_G(Y \\times_\\rho K)}")#text(" is a factor of ")#mi("{Z^0_G(X \\times K)}")#text(" as a ")#mi("{K}")#text("-system. But as ")#mi("{X}")#text(" is ergodic, ")#mi("{Z^0_G(X)}")#text(" is a point, and so by Lemma ")#link(<tao-a8792157cb4f27fb949c>)[#text("4")]#text(", ")#mi("{Z^0_G(X \\times K)}")#text(" is isomorphic to ")#mi("{K}")#text(". Thus ")#mi("{Z^0_G(Y \\times_\\rho K)}")#text(" is a factor of ")#mi("{K}")#text(" as a ")#mi("{K}")#text("-system. We now need a baby version of Theorem ")#link(<tao-1fd716531c7c018b09a7>)[#text("6")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" Let ")#mi("{K}")#text(" be a compact metrisable group. Then every factor of ")#mi("{K}")#text(" (as a ")#mi("{K}")#text("-system acting on the right) is equivalent to ")#mi("{H\\backslash K}")#text(" for some closed subgroup ")#mi("{H}")#text(" of ")#mi("{K}")#text(" (endowing ")#mi("{H \\backslash K}")#text(" with the quotiented Haar measure, of course).")
]

#emph[#text("Proof:")]#text(" If ")#mi("{W}")#text(" is a factor of ")#mi("{K}")#text(", then ")#mi("{L^2(W)}")#text(" can be identified with a subspace of ")#mi("{L^2(K)}")#text(" that is invariant with respect to the right ")#mi("{K}")#text("-action. By using the ")#mi("{K}")#text("-action to convolve with continuous approximations to the identity, we see that ")#mi("{A := C(K) \\cap L^2(W)}")#text(" is dense in ")#mi("{L^2(W)}")#text(", where ")#mi("{C(K)}")#text(" is the space of continuous functions on ")#mi("{K}")#text(". Let ")#mi("{H}")#text(" be the symmetry group of ")#mi("{A}")#text(", that is to say the set of all elements ")#mi("{h \\in K}")#text(" such that ")#mi("{hf = f}")#text(" for all ")#mi("{f \\in A}")#text(". Then ")#mi("{H}")#text(" is a closed subgroup of ")#mi("{K}")#text(", and ")#mi("{A}")#text(" may be identified with a subalgebra of ")#mi("{C(H \\backslash K)}")#text(". By construction, ")#mi("{A}")#text(" separates points in ")#mi("{H \\backslash K}")#text(", and is thus (by the Stone-Weierstrass theorem) dense in ")#mi("{C(H \\backslash K)}")#text(" in the uniform topology, and hence in ")#mi("{L^2(H \\backslash K)}")#text(" in the ")#mi("{L^2}")#text(" topology. From this it is not difficult to show that ")#mi("{W}")#text(" is equivalent to ")#mi("{H \\backslash K}")#text(" as claimed. ")#mi("\\Box")

#text("We conclude that ")#mi("{Z^0_G(Y \\times_\\rho K)}")#text(" is isomorphic to ")#mi("{H \\backslash K}")#text(" as a ")#mi("{K}")#text("-system for some closed subgroup ")#mi("{H}")#text(" of ")#mi("{K}")#text(". (This space is known as the ")#emph[#text("Mackey range")]#text(" of the cocycles ")#mi("{(\\rho_g)_{g \\in G}}")#text(".)")

#text("Now we need to build the gauge function ")#mi("{U}")#text(" to conjugate the cocycle ")#mi("{\\rho}")#text(" to lie in ")#mi("{H}")#text(". In the usual treatments of Theorem ")#link(<tao-1fd716531c7c018b09a7>)[#text("6")]#text(", this is achieved by the descriptive set theory device of Borel sections, but in keeping with our “pointless” approach in this post, we will avoid exploiting the point set structure of ")#mi("{X}")#text(" or ")#mi("{Y}")#text(" (although we will rely very much on the point set structure of ")#mi("{K}")#text(" and ")#mi("{H}")#text("). We begin with an approximate result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 8")]#text(" Let ")#mi("{V}")#text(" be a symmetric neighbourhood of the identity in ")#mi("{K}")#text(". Then there exists a measurable function ")#mi("{U: Y \\rightarrow K}")#text(" such that for each ")#mi("{g \\in G}")#text(", ")#mi("{\\rho_{g,U}}")#text(" takes values in ")#mi("{V^2 HV^2}")#text(" (modulo null sets, of course).")
]

#emph[#text("Proof:")]#text(" One can view ")#mi("{HV}")#text(" as a positive measure subset of ")#mi("{H \\backslash K}")#text(", which can then be identified with a positive measure ")#mi("{G}")#text("-invariant subset ")#mi("{\\Omega}")#text(" of ")#mi("{Y \\times_\\rho K}")#text(", since ")#mi("{Z^0_G(Y \\times_\\rho K)}")#text(" is isomorphic to ")#mi("{H\\backslash K}")#text(". Note that for any ")#mi("{k \\in K}")#text(" outside of ")#mi("{VHV}")#text(", ")#mi("{HV}")#text(" and ")#mi("{HVk^{-1}}")#text(" are disjoint, and so ")#mi("{\\Omega}")#text(" and ")#mi("{k \\Omega}")#text(" are also disjoint (recall that ")#mi("{k}")#text(" acts on the right on ")#mi("{Y \\times_\\rho K}")#text(").")

#text("The conditional expectation ")#mi("{{\\bf E}(1_\\Omega|Y)}")#text(" (that is, the orthogonal projection of ")#mi("{1_\\Omega}")#text(" to ")#mi("{L^2(Y)}")#text(") has positive mean and is ")#mi("{G}")#text("-invariant, and is hence equal to a positive constant by the ergodicity of ")#mi("{Y}")#text(".")

#text("As ")#mi("{K}")#text(" is compact, we can cover ")#mi("{K}")#text(" by a finite number ")#mi("{k_1 V,\\dots,k_n V}")#text(" of left-translates of ")#mi("{V}")#text(". In ")#mi("{Y \\times_\\rho K}")#text(", we thus have the inequality")

#align(center)[#tao-fit-display[#mitex("1_\\Omega \\leq \\sum_{i=1}^n 1_\\Omega 1_{Y \\times k_i V}.")]]

#text("We thus have the pointwise lower bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^n {\\bf E}( 1_\\Omega 1_{Y \\times k_i V} | Y ) > 0.")]]

#text("Thus, if for each ")#mi("{y \\in Y}")#text(" we let ")#mi("{i(y)}")#text(" be the first ")#mi("{i=1,\\dots,n}")#text(" for which ")#mi("{{\\bf E}( 1_\\Omega 1_{Y \\times k_i V} | Y ) > 0}")#text(", and let ")#mi("{U(y) := k_{i(y)}^{-1}}")#text(", then ")#mi("{U: Y \\rightarrow K}")#text(" is measurable and we have the pointwise lower bound ")#metadata(none) <tao-8c6fb1e9e37a1aea1d30>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("{\\bf E}( 1_\\Omega 1_{Y \\times U^{-1} V} | Y ) > 0")]]

#text("(indeed, from the pigeonhole principle we could assume a uniform lower bound away from zero if desired). We claim that ")#metadata(none) <tao-2e23f8b81d15612b4207>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("{\\bf E}( 1_\\Omega (1-1_{Y \\times U^{-1} V^2 HV}) | Y ) = 0.")]]

#text("Indeed, since ")#mi("{\\Omega}")#text(" and ")#mi("{k \\Omega}")#text(" are disjoint for ")#mi("{k \\not \\in VHV}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("[1_\\Omega 1_{Y \\times U^{-1} V}] \\times k [1_\\Omega (1-1_{Y \\times U^{-1} V^2 HV})] = 0")]]

#text("for all ")#mi("{k \\in K}")#text("; integrating this in ")#mi("{k}")#text(" and taking conditional expectations in ")#mi("{Y}")#text(", we obtain the claim thanks to ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("(2)")]#text(".")

#text("Meanwhile, applying the ")#mi("{G}")#text(" action to ")#link(<tao-8c6fb1e9e37a1aea1d30>)[#text("(2)")]#text(" and using the ")#mi("{G}")#text("-invariance of ")#mi("{\\Omega}")#text(", we have")

#align(center)[#tao-fit-display[#mitex("{\\bf E}( 1_\\Omega 1_{Y \\times (S_g \\rho_g) (S_g U^{-1}) V} | Y ) > 0")]]

#text("pointwise for any ")#mi("{g \\in G}")#text(". Comparing this with ")#link(<tao-2e23f8b81d15612b4207>)[#text("(3)")]#text(", we conclude that")

#align(center)[#tao-fit-display[#mitex("{\\bf E}( 1_{Y \\times U^{-1} V^2 HV} 1_{Y \\times (S_g \\rho_g) (S_g U^{-1}) V} | Y ) > 0")]]

#text("and in particular that")

#align(center)[#tao-fit-display[#mitex("U^{-1} V^2 H V \\cap (S_g \\rho_g) (S_g U^{-1}) V \\neq \\emptyset")]]

#text("almost everywhere, which may be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\rho_{g^{-1},U} \\in V^2 H V^2,")]]

#text("and the claim follows. ")#mi("\\Box")

#text("Now we use compactness to eliminate the neighbourhood ")#mi("{V}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" There exists a measurable function ")#mi("{U: Y \\rightarrow K}")#text(" such that, for each ")#mi("{g \\in G}")#text(", ")#mi("{\\rho_{g,U}}")#text(" takes values in ")#mi("{H}")#text(".")
]

#emph[#text("Proof:")]#text(" We place a metric on ")#mi("{K}")#text(". By the previous proposition, for each natural number ")#mi("{n}")#text(" we may find a measurable ")#mi("{U_n: Y \\rightarrow K}")#text(" such that ")#mi("{\\rho_{g,U_n}}")#text(" lies within ")#mi("{1/n}")#text(" of ")#mi("{H}")#text(" pointwise. It thus suffices to find a measurable ")#mi("{U: Y \\rightarrow K}")#text(" such that ")#mi("{U(y)}")#text(" is a limit point of the ")#mi("{U_n(y)}")#text(" for every ")#mi("{y}")#text(", so that ")#mi("{\\rho_{g,U}}")#text(" is always a limit point of the ")#mi("{\\rho_{g,U_n}}")#text(". If it were not for the measurability requirement, this would be immediate from the Heine-Borel theorem; so the only issue is to keep ")#mi("{U}")#text(" measurable. However, this can be done by an inspection of the proof of the Heine-Borel theorem. Namely, for each natural number ")#mi("{m}")#text(", we cover ")#mi("{K}")#text(" by a finite number of balls ")#mi("{B_{1,m},\\dots,B_{j_m,m}}")#text(" of radius ")#mi("{2^{-m}}")#text(". For each ")#mi("{y}")#text(", one of the ")#mi("{B_{i,m}}")#text(" must contain an infinite number of the ")#mi("{U_n(y)}")#text("; if we recursively select ")#mi("{i_m(y)}")#text(" to be the first such ")#mi("{i}")#text(" for which the ball ")#mi("{B_{i,m}}")#text(" intersects the previous ball ")#mi("{B_{i_{m-1}(y),m-1}}")#text(" (with this latter condition being ignored for ")#mi("{m=1}")#text("), we see that each ")#mi("{i_m(y)}")#text(" is measurable in ")#mi("{y}")#text(". The centres of the balls ")#mi("{B_{i_m(y),m}}")#text(" converge to a limit ")#mi("{U(y)}")#text(" which is then measurable and is a limit point of the ")#mi("{U_n(y)}")#text(" as required. ")#mi("\\Box")

#text("In view of this proposition, we may assume without loss of generality that the ")#mi("{\\rho_g}")#text(" take values in ")#mi("{H}")#text(" (replacing ")#mi("{X \\times K}")#text(" and ")#mi("{Y \\times_\\rho K}")#text(" with equivalent systems as necessary). The ")#mi("{G}")#text("-systems ")#mi("{X \\times K}")#text(" and ")#mi("{Y \\times_\\rho K}")#text(" now split into copies of the ")#mi("{G}")#text("-systems ")#mi("{X \\times H}")#text(" and ")#mi("{Y \\times_\\rho H}")#text(", with the copies indexed by ")#mi("{H \\backslash K}")#text(". As ")#mi("{Z^0_G(Y \\times K)}")#text(" was isomorphic to ")#mi("{H \\backslash K}")#text(" as a factor of ")#mi("{Z^0_G(X \\times K) = K}")#text(", it is then easy to see that ")#mi("{Z^0_G(Y \\times_\\rho H)}")#text(" is trivial. By Corollary ")#link(<tao-7d25a2a61c34711e43fa>)[#text("3")]#text(", this implies that ")#mi("{Y \\times_\\rho H}")#text(" and ")#mi("{Z^0_G(X \\times H)}")#text(" are independent factors of ")#mi("{X \\times H}")#text(". In particular, if ")#mi("{f \\in L^\\infty(Y)}")#text(" and ")#mi("{g \\in C(H)}")#text(", so that the function ")#mi("{F: (y,h) \\mapsto f(y) g(h)}")#text(" lies in ")#mi("{L^\\infty(Y \\times_\\rho H)}")#text(", which then embeds into the function ")#mi("{\\tilde F: ((y,h),h^{\\prime}) \\mapsto f(y) g(hh^{\\prime})}")#text(" in ")#mi("{L^\\infty(X \\times H)}")#text(", the orthogonal projection of ")#mi("{\\tilde F}")#text(" to ")#mi("{L^2(Z^0_G(X \\times H))}")#text(" is equal to the orthogonal projection of ")#mi("{F}")#text(" onto the trivial factor. Since ")#mi("{X}")#text(" is ergodic, we see from Lemma ")#link(<tao-a8792157cb4f27fb949c>)[#text("4")]#text(" that ")#mi("{Z^0_G(X \\times H) = H}")#text(", and so we arrive at the identity")

#align(center)[#tao-fit-display[#mitex("\\int_X f(y) g(hh^{\\prime})\\ d\\mu(y,h) = \\int_{Y \\times H} f(y) g(h)\\ d\\nu(y) dh")]]

#text("for almost all ")#mi("{h^{\\prime} \\in H}")#text("; as ")#mi("{g}")#text(" is continuous, this identity in fact holds for all ")#mi("{h^{\\prime} \\in H}")#text(", and in particular when ")#mi("{h^{\\prime}}")#text(" is the identity:")

#align(center)[#tao-fit-display[#mitex("\\int_X f(y) g(h)\\ d\\mu(y,h) = \\int_{Y \\times H} f(y) g(h)\\ d\\nu(y) dh.")]]

#text("From the monotone convergence theorem, the same claim is then true if ")#mi("{g}")#text(" is bounded semicontinuous (in particular, the indicator of an open or closed subset of ")#mi("{K}")#text("), and then (as Haar measure is inner and outer regular) the same claim is also true if ")#mi("{g}")#text(" is bounded Borel measurable. From this we conclude that ")#mi("{\\mu}")#text(" is the product measure of ")#mi("{\\nu}")#text(" and Haar measure ")#mi("{dh}")#text(", and the claim follows.")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d08842ff06592ef82904851a5629304fb39c94e18c79504c96584f270831404-3894fcc336f8f88ea1f08b4e5571759cef8fe6eacdb28d07eaee4fbe40630c7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rex")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-376260")[#strong[#text("Rex")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("The abstract ergodic theorem you mention appears as Theorem 5.7, Chapter 1 in Tempelman’s “Ergodic Theorems for Group Actions”, where it is set up in more general language. He attributes the result to Alaoglu and Garrett Birkhoff.")

#emph[#text("[Reference added, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a383ef3f7b8fdea58d6fa56395a429028f56a673bdfa87874403d5f73372388d-6877802060675ddcc7ae627a5206f67c62c7fe45147c812cce954853ff94368a.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of govwhistleblower")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-376317")[#strong[#text("govwhistleblower")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2014")])]

#text("Your proof does not look correct to me. Are you sure?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/535b8982adda52a880c72db15536b13f320f6cdc7d45a5fbbbf58a9095dde90d-bb5820a5c297e6e30da8807c8bdc1a4192224b1f1e5b1647554b8a04a7d394e2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of alabair")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-376368")[#strong[#text("alabair")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2014")])]

#text("Thank you for what you are doing. However it’s intersting i to see the relationship between the probabilistic version of ergodic theorem in the case of irreductible Markov chain.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c78b0635d3840666a45c47ec480483eec74e78e1328eea53434af3eeeb082d3-3c0ae74c521087079cf5898e23611ad0fbb5ac60f0d05fb90d163b5f2f251883.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of MrCactu5 (@MonsieurCactus)")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-376692")[#strong[#text("MrCactu5 (@MonsieurCactus)")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2014")])]

#text("I am having trouble picturing your main theorem.")

#mi("\\mathbb{Z}")#text(" is obviously amenable and Abelian groups in general have a clear notion of averaging. Finite groups are amenable since you can count the elements one by one – it may take a while.")

#text("Outside of these, what are “interesting” examples of amenable groups? I heard the braid group on 3 strands is amenable, perhaps is this part of something more general.")

#emph[#text("[The previous blog post ")#link("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/")[#text("https://terrytao.wordpress.com/2009/04/14/some-notes-on-amenability/")]#text(" has some examples. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lebesgue measure as the invariant factor of Loeb measure | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-379688")[#strong[#text("Lebesgue measure as the invariant factor of Loeb measure | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2014")])]

#text("[…] the abstract ergodic theorem from the previous post, one can also view this conditional expectation as the element in the closed convex hull of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-380028")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("I think the proof of Corollary 2 can be simplified. Namely, by Theorem 1, ")#mi("\\pi_{H^G}v=\\pi_{V^G}v=0")#text(", and we are done.")

#emph[#text("[Very nice! I’ve replaced my previous argument with yours. – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-380170")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("Thanks for displaying the new argument. I think there is a typo: ")#mi("=v")#text(" should be deleted, i.e. we only have and only need ")#mi("\\pi_{H^G}v=\\pi_{V^G}v")#text(" for ")#mi("v\\in V")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-380325")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("Dear Terry, I have trouble following the proof of Lemma 4. We observe first that ")#mi("L^2(Z^0_G(X\\times Y))")#text(" and ")#mi("L^2(X)")#text(" are relatively orthogonal over ")#mi("L^2(Z^0_G(X))")#text(" by Corollary 3. This should imply that ")#mi("L^2(Z^0_G(X\\times Y))\\subseteq L^2(Z^0_G(X)\\times Y)")#text(", but I don’t see how. Similarly, we should have ")#mi("L^2(Z^0_G(X\\times Y))\\subseteq L^2(X\\times Z^0_G(Y))")#text(", so that in the end ")#mi("L^2(Z^0_G(X\\times Y))\\subseteq L^2(Z^0_G(X)\\times Z^0_G(Y))")#text(". I don’t see this last step either, but at least I can finish differently:")

#text("We know that ")#mi("L^2(Z^0_G(X)\\times Z^0_G(Y))\\subseteq L^2(Z^0_G(X\\times Y))")#text(", hence it suffices to show that ")#mi("L^2(Z^0_G(X\\times Y))\\cap L^2(Z^0_G(X)\\times Z^0_G(Y))^\\perp=\\{0\\}")#text(". Assuming ")#mi("f")#text(" lies in this space, we can use Corollary 3 to deduce that ")#mi("f\\in L^2(X\\times Z^0_G(Y))^\\perp")#text(", whence using also ")#mi("f\\in L^2(Z^0_G(X\\times Y))\\subseteq L^2(X\\times Z^0_G(Y))")#text(" we can conclude ")#mi("f=0")#text(".")

#text("Can you please clarify or point to a more detailed reference? Thanks in advance.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-380375")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 June 2014")])]

#text("Oops, that lemma and proof are complete nonsense! I only meant to claim ")#mi("Z^0_G(X \\times Y) = Z^0_G(X) \\times Z^0_G(Y)")#text(" when the action of G on Y is trivial (the claim is false otherwise), and this requires more of an argument than just abstract nonsense, it seems. I’ve rewritten that part completely.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-380587")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 27 June 2014")])]

#text("Thank you! For the restricted situation there is a more direct argument, via Corollary 3. Let ")#mi("H=L^2(X\\times Y)")#text(" and ")#mi("V=L^2(Z^0_G(X)\\times Y)")#text(", then we need to prove ")#mi("H^G=V")#text(". We have ")#mi("V\\subseteq H^G")#text(", so taking an orthogonal decomposition ")#mi("H^G=V\\oplus W")#text(" it suffices to show that ")#mi("W=\\{0\\}")#text(". Let ")#mi("f\\in W")#text(", then for any ")#mi("g\\in L^2(Z^0_G(X))")#text(" and any ")#mi("h\\in L^2(Y)")#text(" we have ")#mi("gh\\in V")#text(", so ")#mi("{\\bf E}(fgh)=0")#text(". Here ")#mi("fh\\in H^G")#text(", hence applying Corollary 3 to ")#mi("X")#text(" as a factor of ")#mi("X\\times Y")#text(", we see that the relation ")#mi("{\\bf E}(fgh)=0")#text(" extends to any ")#mi("g\\in L^2(X)")#text(". As a result, ")#mi("f")#text(" is orthogonal to all of ")#mi("L^2(X\\times Y)")#text(", whence ")#mi("f=0")#text(".")

#emph[#text("[Nice! I’ve replaced my previous argument with this one – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/99bcdb306e666cef96e29dd9c6bac312c45cf53515b759da6996879dc23f214d-b7c3eb67ac712352e4fd5020a7ab69a709ed10e74ede9fe98e49b82649d96101.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Markus Haase")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-384232")[#strong[#text("Markus Haase")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2014")])]

#text("Dear Terry,")#linebreak()#text(" thank you for this extremely inspiring blog post.")

#text("With regard to your “abstract ergodic theorem” I would like to add the following comments:")#linebreak()#text(" The result is not bound to unitary groups but holds for all semigroups of contractions on a Hilbert space. Appropriately rephrased it even holds for contraction semigroups on a Banach space E such that E and its dual space E’ are both strictly convex. (In Krengel’s book this is Theorem 2.1.10 and is attributed also to Alaoglu-Birkhoff.) Actually, it is a consequence of a characterization of “mean ergodic semigroups”, due to Nagel (Krengel, Theorem 2.1.11).")#linebreak()#text(" According to Nagel (Ann. Inst. Fourier 23 (1973), 75-87) a semigroup of operators on a Banach space is called mean ergodic if its closed convex hull (in the weak=strong operator topology) has a zero element. This zero element, called the mean ergodic projection, is then a projection onto the fixed space of the semigroup. (In the case of a contraction semigroup, the mean ergodic projection is again a contraction, whence orthogonal if the space is a Hilbert space.)")#linebreak()#text(" There is a second approach to the result via the Jacobs-deLeeuw-Glicksberg theory. If S is a bounded (weakly=strongly) closed convex group of operators, then it is the trivial group, because according to a theorem of Kakutani the identity operator is an extremal point of the unit ball of operators on a Banach space (Krengel, Lemma 2.1.13). Now if T is a relatively weakly compact semigroup of operators one can form the closed convex hull S, say, of it, which is a compact semitopological semigroup. If S has a unique minimal idempotent Q, then S restricts to a convex compact group of operators on ran(Q), and hence, by the above, leaves ran(Q) fixed. So Q is a zero element in S, whence T is mean ergodic. One can now check for situations when S necessarily has a unique minimal idempotent, and here the standard assumptions are either amenability or the combination of contractivity of the operators with the strict convexity of E and E’.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-402022")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2014")])]

#text("Dear Terry, a few typos and a suggestion:")

#text("1. In Corollary 3, ")#mi("Z^0(Y)")#text(" should be ")#mi("Z_G^0(Y)")#text(".")

#text("2. In Section 1, Line 3, “which the same” should be “which is the same”.")

#text("3. In the proof of Proposition 8, in the first paragraph, ")#mi("Y\\times K")#text(" should be ")#mi("Y\\times_\\rho K")#text(" (three occurrences).")

#text("4. In the proof of Proposition 8, “for all ")#mi("k^{\\prime}\\in K")#text("” should be “for all ")#mi("k\\in K")#text("“.")

#text("5. In the last line of the post, “Haar measure” should be “")#mi("dh")#text("” for clarity.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The ergodic theorem and Gowers-Host-Kra seminorms without separability or amenability | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-453981")[#strong[#text("The ergodic theorem and Gowers-Host-Kra seminorms without separability or amenability | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 9 April 2015")])]

#text("[…] a previous blog post, I noted a variant of this ergodic theorem (due to Alaoglu and Birkhoff) that holds even when the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of An uncountable Mackey-Zimmer theorem | What's new")]], [#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-592719")[#strong[#text("An uncountable Mackey-Zimmer theorem | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2020")])]

#text("[…] this case the theorem in question is the Mackey-Zimmer theorem, previously discussed in this blog post. This theorem gives an important classification of group and homogeneous extensions of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2014/06/20/an-abstract-ergodic-theorem-and-the-mackey-zimmer-theorem/#comment-650381")[#strong[#text("gr.group theory - What does the unique mean on weakly almost periodic functions look like? Answer - Lord Web")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2022")]

#text("[…] can be seen through the Birkhoff-Alaoglu Ergodic Theorem (see Tao’s blog post on this), after looking at the relation between (1) the weak-closed convex hull in […]")
]
