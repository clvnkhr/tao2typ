// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/
// Converted to Typst by tao2typ: "2026-10-14T16:36:54.603196+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Einstein’s derivation of E=mc^2 revisited", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Einstein’s derivation of E=mc^2 revisited")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 October 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/")[#text("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Way back in 2007, I ")#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")[#text("wrote a blog post")]#text(" giving Einstein’s derivation of his famous equation ")#mi("{E=mc^2}")#text(" for the rest energy of a body with mass ")#mi("{m}")#text(". (Throughout this post, mass is used to refer to the ")#link("http://en.wikipedia.org/wiki/Invariant_mass")[#text("invariant mass")]#text(" (also known as ")#emph[#text("rest mass")]#text(") of an object.) This derivation used a number of physical assumptions, including the following:")

#enum(start: 1, 
[#text("The ")#link("http://en.wikipedia.org/wiki/Postulates_of_special_relativity")[#text("two postulates of special relativity")]#text(": firstly, that the laws of physics are the same in every inertial reference frame, and secondly that the speed of light in vacuum is equal ")#mi("{c}")#text(" in every such inertial frame.")],
[#link("https://en.wikipedia.org/wiki/Planck%E2%80%93Einstein_relation")[#text("Planck’s relation")]#text(" and de Broglie’s law for photons, relating the frequency, energy, and momentum of such photons together.")],
[#text("The ")#link("http://en.wikipedia.org/wiki/Conservation_of_energy")[#text("law of conservation of energy")]#text(", and the ")#link("http://en.wikipedia.org/wiki/Momentum#Conservation")[#text("law of conservation of momentum")]#text(", as well as the additivity of these quantities (i.e. the energy of a system is the sum of the energy of its components, and similarly for momentum).")],
[#text("The Newtonian approximations ")#tao-math("{E \\approx E_0 + \\frac{1}{2} m\\left|v\\right|^2}", block: false)#text(", ")#mi("{p \\approx m v}")#text(" to energy and momentum at low velocities.")]
)

#text("The argument was one-dimensional in nature, in the sense that only one of the three spatial dimensions was actually used in the proof.")

#text("As was pointed out in comments in the previous post by Laurens Gunnarsen, this derivation has the curious feature of needing some laws from quantum mechanics (specifically, the Planck and de Broglie laws) in order to derive an equation in special relativity (which does not ostensibly require quantum mechanics). One can then ask whether one can give a derivation that does not require such laws. As pointed out in previous comments, one can use the representation theory of the Lorentz group ")#mi("{SO(d,1)}")#text(" to give a nice derivation that avoids any quantum mechanics, but it now needs at least two spatial dimensions instead of just one. I decided to work out this derivation in a way that does not explicitly use representation theory (although it is certainly lurking beneath the surface). The concept of momentum is only barely used in this derivation, and the main ingredients are now reduced to the following:")

#enum(start: 1, 
[#text("The two postulates of special relativity;")],
[#text("The law of conservation of energy (and the additivity of energy);")],
[#text("The Newtonian approximation ")#tao-math("{E \\approx E_0 + \\frac{1}{2} m\\left|v\\right|^2}", block: false)#text(" at low velocities.")]
)

#text("The argument (which uses a little bit of calculus, but is otherwise elementary) is given below the fold. Whereas Einstein’s original argument considers a mass emitting two photons in several different reference frames, the argument here considers a large mass breaking up into two equal smaller masses. Viewing this situation in different reference frames gives a functional equation for the relationship between energy, mass, and velocity, which can then be solved using some calculus, using the Newtonian approximation as a boundary condition, to give the famous ")#mi("{E=mc^2}")#text(" formula.")

#emph[#text("Disclaimer:")]#text(" As with the previous post, the arguments here are physical arguments rather than purely mathematical ones, and thus do not really qualify as a rigorous mathematical argument, due to the implicit use of a number of physical and metaphysical hypotheses beyond the ones explicitly listed above. (But it would be difficult to say anything non-tautological at all about the physical world if one could rely solely on ")#mi("{100\\%}")#text(" rigorous mathematical reasoning.)")

#metadata(none) <tao-a9d946e89e8b352e5c34>

#heading(level: 1)[#strong[#text(" — 1. The main argument — ")]]

#text("We will assume that the total energy ")#mi("{E}")#text(" of a moving body depends only on the mass ")#mi("{m}")#text(" of that body, and the velocity ")#mi("{v}")#text(" of that body:")

#align(center)[#tao-fit-display[#mitex("E = E(m,v).")]]

#text("(This is actually a non-trivial assumption; it excludes the possibility that the energy might also be depenent on other features of the body, such as spin or charge.) At present, this functional relationship ")#mi("{E: (m,v) \\mapsto E(m,v)}")#text(" is arbitrary. However, we can use some physical arguments to constrain this relationship. We first use the following argument of Galileo. Consider two bodies side by side, traveling at the same velocity ")#mi("{v}")#text(", with the first body of mass ")#mi("{m_1}")#text(" and the second of mass ")#mi("{m_2}")#text(". Then, the first body has energy ")#mi("{E(m_1,v)}")#text(" and the second has energy ")#mi("{E(m_2,v)}")#text(", so the combined system of two bodies has total energy ")#mi("{E(m_1,v)+E(m_2,v)}")#text(". On the other hand, if we imagine connecting the two bodies by an infinitesimally thin thread, we can view the system as a single body of mass ")#mi("{m_1+m_2}")#text(" traveling at the same velocity ")#mi("{v}")#text(". This leads us to the relationship")

#align(center)[#tao-fit-display[#mitex("E(m_1,v) + E(m_2,v) = E(m_1+m_2,v)")]]

#text("for any ")#mi("{m_1,m_2,v}")#text(", which (under reasonable hypotheses of continuity) implies a linear relationship between energy and mass, thus")

#align(center)[#tao-fit-display[#mitex("E(m,v) = m f(v)")]]

#text("for some function ")#mi("{f: v \\mapsto f(v)}")#text(" depending only on the velocity ")#mi("{v}")#text(".")

#text("We still have to determine this unknown functional relationship ")#mi("{f: v \\mapsto f(v)}")#text(". We assume rotational symmetry of the laws of physics (which one can view as a special case of the first postulate of special relativity): if two bodies of equal mass move at the same speed, but at different directions, the energies should be the same. In other words, ")#mi("{f}")#text(" should be spherically symmetric, so by abuse of notation we write ")#metadata(none) <tao-ec38063c881f0a5edfef>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("f(v) = f(\\left|v\\right|).", block: true)]]





#text("Now consider a body ")#mi("{B}")#text(" of mass ")#mi("{M}")#text(" at rest at the origin(in some reference frame ")#mi("{O}")#text("), which somehow disintegrates (at time ")#mi("{t=0}")#text(", for simplicity) into two smaller bodies ")#mi("{B_+, B_-}")#text(" of equal mass ")#mi("{m}")#text(", one moving in the positive ")#mi("{x}")#text(" direction at some velocity ")#mi("{(+v,0,0)}")#text(", and the other moving in the negative ")#mi("{x}")#text(" direction at the opposite velocity ")#mi("{(-v,0,0)}")#text(" (note that this situation is consistent with the law of conservation of momentum). (If one prefers, one could also view the time-reversed situation, in which two masses of equal and opposite velocity collide to form a large stationary mass; the analysis of this situation is basically identical to the one given here.) In Newtonian mechanics, we have conservation and additivity of mass, so that ")#mi("{M}")#text(" must equal ")#mi("{m+m}")#text("; but we will not assume conservation and additivity of mass here (and in fact at least one of these laws must break down in special relativity, at least if one insists on using an invariant notion of mass). Instead, we can link ")#mi("{M}")#text(", ")#mi("{m}")#text(", and ")#mi("{v}")#text(" to each other by the law of conservation of energy. Before the disintegration, the body ")#mi("{B}")#text(" has total energy ")#mi("{E(M,0) = M f(0)}")#text(", while after the disintegration the system ")#mi("{B_++B_-}")#text(" has total energy ")#tao-math("{E(m,(+v,0,0)) + E(m,(-v,0,0)) = 2 m f(\\left|v\\right|)}", block: false)#text(" (using the spherically symmetric nature ")#link(<tao-ec38063c881f0a5edfef>)[#text("(1)")]#text(") of ")#mi("{f}")#text(", and so ")#metadata(none) <tao-4b6f50ec6e0629790e0d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("M f(0) = 2m f(v).")]]





#text("Now we view the same system relative to another reference frame ")#mi("{O^{\\prime}}")#text(", which relative to ")#mi("{O}")#text(" is moving at a velocity ")#mi("{(w,0,0)}")#text(" in the ")#mi("{x}")#text(" direction for some ")#mi("{w}")#text(", while keeping the ")#mi("{y}")#text(" and ")#mi("{z}")#text(" coordinates unchanged. The spacetime coordinates ")#mi("{(x^{\\prime},y^{\\prime},z^{\\prime},t^{\\prime})}")#text(" of ")#mi("{O^{\\prime}}")#text(" are then related to those ")#mi("{(x,y,z,t)}")#text(" of ")#mi("{O}")#text(" by the usual ")#link("http://en.wikipedia.org/wiki/Lorentz_transformation")[#text("Lorentz transformations")]

#tao-aligned(keep: true)[


#tao-math("x^{\\prime}  & = \\frac{x-wt}{\\sqrt{1-w^2/c^2}}", block: true)



#tao-math("y^{\\prime}  & = y", block: true)



#tao-math("z^{\\prime}  & = z", block: true)



#tao-math("t^{\\prime}  & = \\frac{t-wx/c^2}{\\sqrt{1-w^2/c^2}}", block: true)
]

#text("which can be deduced from the postulates of special relativity by a standard derivation that we will not give here (it is sketched in ")#link("https://terrytao.wordpress.com/2007/12/28/einsteins-derivation-of-emc2/")[#text("the previous blog post")]#text("). The pre-disintegration body ")#mi("{B}")#text(" is moving along the worldline ")#mi("{\\{ (0,0,0,t): t < 0\\}}")#text(" in the ")#mi("{O}")#text(" reference frame, and is thus moving along the line ")#mi("{\\{ (\\frac{-wt}{\\sqrt{1-w^2/c^2}}, 0, 0, \\frac{t}{\\sqrt{1-w^2/c^2}}): t < 0 \\}}")#text(" in the ")#mi("{O^{\\prime}}")#text(" reference frame; in particular, it has velocity ")#mi("{-w}")#text(" in this frame and thus has energy ")#mi("{M f(w)}")#text(" in this frame.")

#text("Now consider the first post-disintegration body ")#mi("{B_+}")#text(". It is moving along the worldline ")#mi("{\\{ (vt, 0,0,t): t>0 \\}}")#text(" in the ")#mi("{O}")#text(" reference frame, and thus along the line ")#mi("{\\{ (\\frac{vt-wt}{\\sqrt{1-w^2/c^2}}, 0, 0, \\frac{t-vwt/c^2}{\\sqrt{1-w^2/c^2}}): t > 0 \\}}")#text(" in the ")#mi("{O^{\\prime}}")#text(" reference frame; in particular, the speed of ")#mi("{B_+}")#text(" in this frame is ")#mi("{\\frac{v-w}{1-vw/c^2}}")#text(" (the well known ")#link("http://en.wikipedia.org/wiki/Velocity_addition_formula")[#text("velocity addition (or subtraction) formula")]#text("), and so the energy of this body is ")#mi("{m f( \\frac{v-w}{1-vw/c^2} )}")#text(". Similarly, ")#mi("{B_-}")#text(" has energy ")#mi("{m f( \\frac{v+w}{1+vw/c^2} )}")#text(". Equating energies, we are thus led to")

#align(center)[#tao-fit-display[#mitex("M f(w) = m (f( \\frac{v-w}{1-vw/c^2} ) + f(\\frac{v+w}{1+vw/c^2})).")]]

#text("We can eliminate ")#mi("{M,m}")#text(" using ")#link(<tao-4b6f50ec6e0629790e0d>)[#text("(2)")]#text(", to obtain a functional equation for ")#mi("{f}")#text(": ")#metadata(none) <tao-70cc0768d9b9f2b534ea>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("2f(v) f(w) = f(0) (f( \\frac{v-w}{1-vw/c^2} ) + f(\\frac{v+w}{1+vw/c^2})).")]]



#text("This equation should hold for all (physically attainable) velocities ")#mi("{v,w}")#text(". To solve this equation, it is convenient to work with the change of variables")

#align(center)[#tao-fit-display[#mitex("v = c \\tanh \\alpha; w = c \\tanh \\beta;")]]

#text("the hyperbolic angles ")#mi("{\\alpha,\\beta}")#text(" are known as the ")#link("http://en.wikipedia.org/wiki/Rapidity")[#text("rapidities")]#text("associated to ")#mi("{v}")#text(" and ")#mi("{w}")#text(" respectively. The point of using this change of variables is that the hyperbolic tangent addition formula yields")

#align(center)[#tao-fit-display[#mitex("\\frac{v+w}{1+vw/c^2} = c \\tanh(\\alpha+\\beta); \\quad \\frac{v-w}{1-vw/c^2} = c \\tanh(\\alpha-\\beta).")]]

#text("Thus if we make the change of variables")

#align(center)[#tao-fit-display[#mitex("g(\\alpha) := f( c \\tanh \\alpha )")]]

#text("then ")#link(<tao-70cc0768d9b9f2b534ea>)[#text("(3)")]#text("simplifies to")

#align(center)[#tao-fit-display[#mitex("2 g(\\alpha) g(\\beta) = g(0) ( g(\\alpha+\\beta) + g(\\alpha-\\beta) ).")]]

#text("It is tempting to plug in some special values into this equation, such as ")#mi("{\\beta=0}")#text(", but this only gives a trivial equation. However, if we first differentiate twice in ")#mi("{\\beta}")#text(" to obtain")

#align(center)[#tao-fit-display[#mitex("2 g(\\alpha) g^{\\prime\\prime}(\\beta) = g(0) ( g^{\\prime\\prime}(\\alpha+\\beta) + g^{\\prime\\prime}(\\alpha-\\beta) )")]]

#text("and ")#emph[#text("then")]#text("set ")#mi("{\\beta=0}")#text(", we obtain the non-trivial equation")

#align(center)[#tao-fit-display[#mitex("g(\\alpha) g^{\\prime\\prime}(0) = g(0) g^{\\prime\\prime}(\\alpha).")]]

#text("This is a differential equation in ")#mi("{g}")#text(", and can be solved as")

#align(center)[#tao-fit-display[#mitex("g(\\alpha) = A \\cosh(k \\alpha) + B \\sinh(k \\alpha)")]]

#text("for some unknowns ")#mi("{A,B}")#text(", where ")#mi("{k}")#text(" is the square root of ")#mi("{g^{\\prime\\prime}(0)/g(0)}")#text(". From ")#link(<tao-ec38063c881f0a5edfef>)[#text("(1)")]#text(", ")#mi("{g}")#text(" should have vanishing derivative at the origin, and so ")#mi("{B=0}")#text(", and so we have ")#metadata(none) <tao-d510ce394c546e3d2de9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("f( c \\tanh \\alpha ) = A \\cosh(k \\alpha).")]]



#text("This is significant progress in constraining the behaviour of ")#mi("{f}")#text(", but there are still two unknown parameters ")#mi("{A, k}")#text(". To proceed further, it becomes necessary to utilise a second dimension. Namely, we repeat the previous arguments, but with ")#mi("{O^{\\prime}}")#text(" now moving at velocity ")#mi("{(0,w,0)}")#text(" instead of ")#mi("{(w,0,0)}")#text(". The Lorentz transformations are now")

#tao-aligned(keep: true)[


#tao-math("x^{\\prime}  & = x", block: true)



#tao-math("y^{\\prime}  & = \\frac{y-wt}{\\sqrt{1-w^2/c^2}}", block: true)



#tao-math("z^{\\prime}  & = z", block: true)



#tao-math("t^{\\prime}  & = \\frac{t-wy/c^2}{\\sqrt{1-w^2/c^2}}.", block: true)
]

#text("The pre-disintegration body ")#mi("{B}")#text(" is moving along the worldline ")#mi("{\\{ (0,0,0,t): t < 0\\}}")#text(" in the ")#mi("{O}")#text(" reference frame, and is thus moving along the line ")#mi("{\\{ (0, \\frac{-wt}{\\sqrt{1-w^2/c^2}}, 0, \\frac{t}{\\sqrt{1-w^2/c^2}}): t < 0 \\}}")#text(" in the ")#mi("{O^{\\prime}}")#text(" reference frame; in particular, it has velocity ")#mi("{-w}")#text(" in this frame and thus has energy ")#mi("{M f(w)}")#text(" in this frame.")

#text("Now consider the first post-disintegration body ")#mi("{B_+}")#text(". It is moving along the worldline ")#mi("{\\{ (vt, 0,0,t): t>0 \\}}")#text(" in the ")#mi("{O}")#text(" reference frame, and thus along the line ")#mi("{\\{ (vt, \\frac{-wt}{\\sqrt{1-w^2/c^2}}, 0, \\frac{t}{\\sqrt{1-w^2/c^2}}): t > 0 \\}}")#text(" in the ")#mi("{O^{\\prime}}")#text(" reference frame; in particular, the speed of ")#mi("{B_+}")#text(" in this frame is ")#mi("{\\sqrt{ v^2 (1-w^2/c^2) + w^2 }}")#text(", and so the energy of this body is ")#mi("{m f( \\sqrt{ v^2 (1-w^2/c^2) + w^2 } )}")#text(". Similarly for ")#mi("{B_-}")#text(". Equating energies, we are thus led to")

#align(center)[#tao-fit-display[#mitex("M f(w) = 2m f( \\sqrt{ v^2 (1-w^2/c^2) + w^2 } ).")]]

#text("We can eliminate ")#mi("{M,m}")#text(" using ")#link(<tao-4b6f50ec6e0629790e0d>)[#text("(2)")]#text(", to obtain a functional equation for ")#mi("{f}")#text(":")

#align(center)[#tao-fit-display[#mitex("f(v) f(w) = f(0) f( \\sqrt{ v^2 (1-w^2/c^2) + w^2 } ).")]]

#text("This equation should hold for all (physically attainable) velocities ")#mi("{v,w}")#text(". To solve this equation, we work with infinitesimal ")#mi("{w}")#text(" and perform a Taylor expansion. From the symmetry ")#link(<tao-4b6f50ec6e0629790e0d>)[#text("(2)")]#text(", ")#mi("{f}")#text(" should be flat at the origin, and so (assuming sufficient smoothness for ")#mi("{f}")#text(") we have")

#align(center)[#tao-fit-display[#mitex("f(w) = f(0) + \\frac{1}{2} f^{\\prime\\prime}(0) w^2 + o(w^2),")]]

#text("while from the Taylor approximation")

#align(center)[#tao-fit-display[#mitex("\\sqrt{ v^2 (1-w^2/c^2) + w^2 } = v + \\frac{1-v^2/c^2}{2v} w^2")]]

#text("we have")

#align(center)[#tao-fit-display[#mitex("f( \\sqrt{ v^2 (1-w^2/c^2) + w^2 } ) = f(v) + \\frac{1-v^2/c^2}{2v} w^2 f^{\\prime}(v) + o(w^2).")]]

#text("Inserting these expansions and extracting the ")#mi("{w^2}")#text(" coefficient, we obtain the differential equation")

#align(center)[#tao-fit-display[#mitex("f(v) f^{\\prime\\prime}(0) = f(0) \\frac{1-v^2/c^2}{2v} f^{\\prime}(v).")]]

#text("which we can rewrite as")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dv} \\log f(v) = C \\frac{v}{1-v^2/c^2}")]]

#text("for some constant ")#mi("{C}")#text(". We can integrate this as")

#align(center)[#tao-fit-display[#mitex("\\log f(v) = -C \\log(1-v^2/c^2) + C^{\\prime}")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("f(v) = D (1-v^2/c^2)^{-C}")]]

#text("for some parameters ")#mi("{C, D}")#text(". In rapidity coordinates ")#mi("{v = c \\tanh \\alpha}")#text(", this becomes")

#align(center)[#tao-fit-display[#mitex("f( c \\tanh \\alpha) = D \\cosh^{2C} \\alpha.")]]

#text("Comparing this with ")#link(<tao-d510ce394c546e3d2de9>)[#text("(4)")]#text("(e.g. by performing a Taylor expansion to fourth order around ")#mi("{\\alpha=0}")#text(") we see that ")#mi("{k = 2C = 1}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("f(c \\tanh \\alpha) = A \\cosh \\alpha")]]

#text("or equivalently")

#align(center)[#tao-fit-display[#mitex("f(v) = \\frac{A}{\\sqrt{1-v^2/c^2}}.")]]

#text("Thus we have")

#align(center)[#tao-fit-display[#tao-math("E(m,v) = \\frac{Am}{\\sqrt{1-\\left|v\\right|^2/c^2}}.", block: true)]]

#text("For infinitesimal velocities ")#mi("{v}")#text(", we may Taylor expand")

#align(center)[#tao-fit-display[#tao-math("E(m,v) = A m + \\frac{1}{2} \\frac{A}{c^2} m\\left|v\\right|^2 + o(\\left|v\\right|^2)", block: true)]]

#text("and so the kinetic energy of a slowly moving mass is ")#tao-math("{\\frac{1}{2} \\frac{A}{c^2} m\\left|v\\right|^2 + o(\\left|v\\right|^2)}", block: false)#text(". Comparing this with the Newtonian approximation of ")#tao-math("{\\frac{1}{2} m\\left|v\\right|^2}", block: false)#text(" we conclude that ")#mi("{A=c^2}")#text(", and thus ")#metadata(none) <tao-f4bf4555bbfe3cfd24ff>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("E(m,v) = \\frac{mc^2}{\\sqrt{1-\\left|v\\right|^2/c^2}}.", block: true)]]



#text(" In particular, setting ")#mi("{v=0}")#text(" we see that the rest energy ")#mi("{E(m,0)}")#text(" of a body of mass ")#mi("{m}")#text(" is ")#mi("{mc^2}")#text(", as required.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above derivation did not explicitly use the law of conservation of momentum (other than to observe that the scenario of one mass at rest splitting into two smaller masses moving in equal and opposite directions was compatible with this law). Actually, if one ")#emph[#text("defines")]#text("the momentum ")#mi("{p(m,v)}")#text(" of a body of mass ")#mi("{m}")#text(" and velocity ")#mi("{v}")#text(" by the formula")

#align(center)[#tao-fit-display[#tao-math("p(m,v) := \\frac{mv}{\\sqrt{1-\\left|v\\right|^2/c^2}}", block: true)]]

#text("and the momentum of a system as the sum of the momenta of its components, one can use ")#link(<tao-f4bf4555bbfe3cfd24ff>)[#text("(5)")]#text(" and the Lorentz transformations to (after some algebra) express the total momentum of a system as a linear combination of the total energy of that system viewed in a couple reference frames (or, if one prefers, as the derivatives of the total energy with respect to infinitesimal reference frame changes), and as a consequence one can actually ")#emph[#text("derive")]#text(" the law of conservation of momentum from the law of conservation of energy, together with special relativity. (Actually, this can also be done in Galilean relativity as well, using the classical formula ")#tao-math("{E(m,v)=E(m,0) + \\frac{1}{2} m \\left|v\\right|^2}", block: false)#text("; we leave this as an exercise to the reader.) Indeed, in special relativity it is natural to unify energy and momentum together as a single quantity known as the ")#link("http://en.wikipedia.org/wiki/Four-momentum")[#text("four-momentum")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The above arguments ultimately rely on the fact that the Lorentz group ")#mi("{SO(d,1)}")#text(" has an essentially unique linear action on ")#mi("{{\\bf R}^{1+d}}")#text(" when the spatial dimension ")#mi("{d}")#text(" is at least two. For ")#mi("{d=1}")#text(", the group ")#mi("{SO(d,1)}")#text(" becomes abelian, and there is a multiplicity of such actions (parameterised by the different possibilities for the quantity ")#mi("{k}")#text(" appearing in ")#link(<tao-d510ce394c546e3d2de9>)[#text("(4)")]#text("), and one could ")#emph[#text("a priori")]#text("have a number of different laws relating energy and momentum with mass and velocity that are consistent with special relativity and the conservation laws. Indeed, for any choice of ")#mi("{k > 0}")#text(", one could postulate the laws")

#align(center)[#tao-fit-display[#mitex("E(m,c \\tanh \\alpha) = \\frac{m c^2}{k^2} \\cosh(k \\alpha)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("p(m, c \\tanh \\alpha) = \\frac{mc}{k} \\sinh(k \\alpha)")]]

#text("for the energy and momentum of a body of mass ")#mi("{m}")#text(" moving at rapidity ")#mi("{\\alpha}")#text(" (i.e. at velocity ")#mi("{c\\tanh \\alpha}")#text("). One can verify that such laws are consistent with the laws of conservation of mass and energy, with the postulates of special relativity, and with the Newtonian approximation, as long as one is only in one spatial dimension; one needs to use at least one other dimension to be able to reduce to the ")#mi("{k=1}")#text(" case. Thus we see that higher-dimensional relativity is more rigid than one-dimensional relativity. In the case of Einstein’s original argument, the quantum mechanical properties of photons are used instead to show that ")#tao-math("{E/\\left|p\\right| \\rightarrow c}", block: false)#text(" in the lightspeed limit ")#mi("{\\alpha \\rightarrow \\infty}")#text(", which gives the reduction to ")#mi("{k=1}")#text(".")
]

#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177582")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2012")])]

#text("Thank you Prof. Tao. It is a great post.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177611")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2012")])]

#text("isn’t m missing in the Taylor’s expression for E(m,v)?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/27e8412f888c569a9be1ea171fca277001b3529b40fd5b744477630ab233b68c-05bad328c0ff3a76596d1574691a67abec98c1884bc3f88e4c852126de63b9c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mircea")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177657")[#strong[#text("mircea")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Is Galileo’s reasoning about linearity of energy in mass ok with special relativity? In which reference frame do we compare the velocities?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177907")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Galileo’s argument only requires a single frame of reference. (But thanks to the first postulate of special relativity, the relationship between energy, mass, and velocity should be the same in all reference frames.)")

#text("EDIT: Actually, on thinking about it a bit more, Galileo’s argument also needs the fact that the combined mass of two bodies traveling together at the same velocity is the sum of the masses of each individual mass. By working in a comoving reference frame, it suffices to assume this when both bodies are at rest, which is a plausible enough assumption, but it does require the use of the additional reference frame.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4fb92c057dc48ec23e419aa1e88f637258974157358fbf3224cf0aaebf1655ab-ada19d236ac1083db55fc97d241f0a8e51463ae3af2ef8319291056fa1156da3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bo Jacoby")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177687")[#strong[#text("Bo Jacoby")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("If a is a constant and x is a variable the function y=ax is conventionally not written y=xa. How come that E=mc^2 is not written E=c^2m ?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f4ab4adfee914bed6ffc8861f1d7607f7529c2b7ccd2b6fa0907e55d97b6076-298bc1d107c0bd5ad8ad3aeace91875cd5806ec0b6e07e56a622bdea77aaeeda.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rn")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177706")[#strong[#text("Rn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Instead of using the one-dimensional velocity-addition (or subtraction) formula on two separate parts of the proof, what would happen if the two-dimensional formula is used just once. Would that work or would it just complicate things and not even give you two conditions ?")

#mi("\\mathbf{v} \\oplus\\mathbf{u}=\\frac{\\mathbf{v}+\\mathbf{u}_{\\parallel} + \\alpha_{\\mathbf{v}}\\mathbf{u}_{\\perp}}{1+\\frac{\\mathbf{v}\\cdot\\mathbf{u}}{c^2}}=\\frac{1}{1+\\frac{\\mathbf{v}\\cdot\\mathbf{u}}{c^2}}\\left\\{\\mathbf{v}+\\frac{1}{\\gamma_\\mathbf{v}}\\mathbf{u}+\\frac{1}{c^2}\\frac{\\gamma_\\mathbf{v}}{1+\\gamma_\\mathbf{v}}(\\mathbf{v}\\cdot\\mathbf{u})\\mathbf{v}\\right\\}")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177789")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Yes, this approach would work too (and ultimately leads back to understanding the representation theory of SO(3,1), which I alluded to earlier).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2f4ab4adfee914bed6ffc8861f1d7607f7529c2b7ccd2b6fa0907e55d97b6076-298bc1d107c0bd5ad8ad3aeace91875cd5806ec0b6e07e56a622bdea77aaeeda.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Rn")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177708")[#strong[#text("Rn")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Another blog with special relativity stuff is:")#linebreak()#text(" ")#link("http://thespectrumofriemannium.wordpress.com/")[#text("http://thespectrumofriemannium.wordpress.com/")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/80fefdda1e32fc499c20a4f5f602ce59bc80baf182c57ab11bf931d512e078ab-7173d4b95da47526ebaf0141ad89d795d1fda283936a33f7fd94c3a34607b64a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Number8")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177711")[#strong[#text("Number8")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("In Newtonian mechanics, we have conservation of mass, so that M must equal m+m ; but we will not assume conservation of mass here (and in fact this law turns out to be false in special relativity). Its still true for special relativity if the system is closed, The energy given out in a collision still has mass w.r.t to the systems frame even if its in the form of photons.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177786")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Ah, I realised that “conservation of mass” is a bit ambiguous. It’s really the conjunction of “conservation of mass” (total mass of a system remains constant), “additivity of mass” (mass of a system equals the sum of the masses of the components), and “invariance of mass” (mass is the same in every reference frame) which cannot simultaneously hold in special relativity. Depending on how exactly one defines mass, one can make two of these three properties true in SR, but not all three at once. I’ve reworded the text to reflect this. (Also I now realise, for similar reasons, that additivity of energy is implicitly being relied on rather crucially in the discussion.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/017f42d897a5f73c4cb8c135932009138e29432a07a924340a99475f2a6d6252-a3393f7ac09c9ef7a24930f5ca091c1e9adc4163938c5f5ca6428bde7c3c5dd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Douglas J. Callahan")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-681483")[#strong[#text("Douglas J. Callahan")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2023")])]

#text("Hypothesis on Energy")

#text("E=NC2")

#text("Energy equals Neutrinos times Velocity Squared")

#text("Energy never dissipates.")

#text("E=MC2 is a fallacy theory because the Neutrinos are the energy. How could Energy equal Mass without another factor?")

#text("The reason that hyper space travel is possible is because Neutrinos are the energy. Dark Matter is space with the absence of Neutrinos. The Neutrinos move freely because they are the Energy.")

#text("One Scientist was able to “catch” or isolate 3 Neutrinos. Those that travel among and between galaxies have learned to harvest neutrinos and pierce Dark Matter with them.")

#text("Douglas J. Callahan")#linebreak()#text(" American Scientist")#linebreak()#text(" ")#link("mailto:djcall242@gmail.com")[#text("djcall242@gmail.com")]#linebreak()#text(" September 4, 2023")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9ba4772b3009b4421181a3034b1d212501491a9a101e222603bcd1f9bb804570-265cfbd55ebcccb0521a23f8d76c8945b7ef27ea07690cf278a2831d393868b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of philh")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177738")[#strong[#text("philh")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Typo? In the equation just before (3), Mf(w) = 2m(f(…) + f(…)), I don’t think the 2 should be there.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/38daf98a103b7f317aea2fab2eff360305a23046e00210e18dd8c937a5acb64a-dae2ae56d3a5ea9663a5c09900fcbd8c3e3851481aec3dfcf15142659c591fbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of updog")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177763")[#strong[#text("updog")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Nice, but I’m not going to pretend to understand any of that at 7am.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/133755780b56fd1a8a37beac0471e8bac8a9bdf48835ca384aae9b0749300d34-18201dd24e44ad841d60fbf742f9d526a9e9257b78432e343b6293ce4bf3f899.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of quantummoxie")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177765")[#strong[#text("quantummoxie")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Tom Moore has a similar derivation in his fantastic textbook, Six Ideas That Shaped Physics, Unit R: The Laws of Physics Are Frame-Independent, Second Edition (McGraw-Hill, 2003). It’s a bit simpler than yours, but maybe slightly more heuristic.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5797e27772bb98b28c71aa661fcf6975a1e1e6781c807ef766a26d10426aac6d-792e1f463e5b22343458287a1d8885f7540cafdbf803933e27847e986b1927f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marco M")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177769")[#strong[#text("Marco M")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("I have somewhat similar derivation in section 11 of my paper ")#link("http://arxiv.org/abs/physics/0605204")[#text("http://arxiv.org/abs/physics/0605204")]#text(". There I do not use the Planck energy frequency relation, but use the relation between energy and momentum in a light wave, which was known before the theory of relativity or quantum mechanics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5797e27772bb98b28c71aa661fcf6975a1e1e6781c807ef766a26d10426aac6d-792e1f463e5b22343458287a1d8885f7540cafdbf803933e27847e986b1927f0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mmoriconi")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-182713")[#strong[#text("mmoriconi")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2012")])]

#text("oops, sorry about this comment. I had no intention to promote any results. Just read the “about” section. My apologies if the post was inappropriate…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177823")[#strong[#text("Hager El-Boghdady (@H_Sayed_M)")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")]

#text("It is a great post …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c353a7069a02cedeca28c93d58f21fbc34dad41b78198cef456419743ff6d3d-4efc3bd038dd54867bfc736b3b708c789ac5e43a10d96e6f08cb608d1917a209.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of teacher")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177901")[#strong[#text("teacher")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("You lost me right at equation (2). Why would we assume that the energies before and after the “disintegration” are equal in your scenario? You say that a body B of mass M “somehow disintegrates”… but in real life, massive bodies don’t split into two pieces flying off in equal and opposite directions without an energy input — some dynamite, perhaps. (Similarly, if you reverse time and have the two bodies collide, the energy of their motion will dissipate in one way or another, heat and light and sound, say.) So I’m not getting the physical intuition here that would lead me to equate the left and right sides in (2). Am I being too literal here, or missing some subtlety?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177904")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Well, the body can certainly contain within it some energy source (like the dynamite you mention, which contains energy and hence mass within its chemical bonds), and the total mass of that body will then have to take that energy into consideration. In the context of two bodies colliding, the new body might acquire some additional energy (through heat, etc.), and again this would be reflected in the total mass of the new body.")

#text("Note at the elementary particle level that it is quite common for one particle to spontaneously disintegrate into two or more particles (e.g. a neutron can decay into a proton, electron, and neutrino, a radioactive nucleus can decay into a smaller nucleus and an alpha particle, and so forth). Implicit in the above analysis is the assumption that there are enough interactions of this form to span enough physically realisable values of mass, velocity, etc. that one can safely extrapolate to arbitrary values of these parameters. (By the way, the assumption that the initial body splits into two bodies of equal mass is mostly for mathematical convenience; a similar argument would also work for more complicated collisions in which some number of bodies of various masses came together and formed some other number of bodies, again of various masses, moving with different velocities, but the mathematical analysis of such collisions becomes messier.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c353a7069a02cedeca28c93d58f21fbc34dad41b78198cef456419743ff6d3d-4efc3bd038dd54867bfc736b3b708c789ac5e43a10d96e6f08cb608d1917a209.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of teacher")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177916")[#strong[#text("teacher")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Thanks for the clarification! I guess the problem is that I’m not automatically taking into account the equivalence of mass and energy – I mean, I understand it abstractly well enough (in a limited, undergraduate-physics sense), but it’s not intuitive to me when I’m picturing concrete physical objects, as in your scenario. (I know, of course, that it can be measured concretely under the right experimental conditions — e.g. the gases released by the dynamite, cooled down and collected, would weigh ever so slightly less than the dynamite itself — but the effect is so far from perceptible under ordinary conditions that it doesn’t translate into real intuition.)")

#text("I think that the problem is that I was looking to your derivation of the relationship between mass and energy precisely in order to *supply* some of that intuition. And I guess to do so would be a bit circular, since in order to accept equation (2), I need to understand that the total mass of the object must take into account the potential energy of the “dynamite,” which means that I have to accept mass-energy equivalence in the first place. Which I suppose is OK — you’re not trying to prove mass-energy equivalence, just to quantify it (E=mc^2) — is that a reasonable assessment?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177924")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Yes, by assuming the functional relationship E = E(m,v), one is implicitly assuming some sort of mass-energy equivalence, which one is then trying to quantify. As mentioned at the start of the derivation, this is a non-trivial assumption. (But given that kinetic energy, at least, depends only on mass and velocity in Newtonian mechanics, it is not too unreasonable of a hypothesis.)")

#text("At the elementary particle level, this sort of assumption becomes more plausible because the particles have almost no internal structure which could conceivably supply a non-mass source of energy.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3c353a7069a02cedeca28c93d58f21fbc34dad41b78198cef456419743ff6d3d-4efc3bd038dd54867bfc736b3b708c789ac5e43a10d96e6f08cb608d1917a209.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of teacher")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-177972")[#strong[#text("teacher")]]#text(size: 9pt, fill: rgb("596477"), " · 3 October 2012")])]

#text("Gotcha! After reading the whole derivation through a couple of times I had a moment of sudden enlightenment – in which I, all at once, thoroughly understood, and more importantly felt intuition for, the whole story. Thanks for this post and for engaging with me here in the comments – I really learned something.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-178114")[#strong[#text("Wednesday/Thursday Highlights | Pseudo-Polymath")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2012")]

#text("[…] Einsteins most famous equation (relation?) revisited. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-178115")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e240v3n4")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2012")]

#text("[…] Einsteins most famous equation (relation?) revisited. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ac3777c587016dab77509585b33be624219e780d429b0da2d3fa17564b32278b-6d04649979a32e7b8ac1787a4b71ebef3d0c41f3a6534f5dc7772be030af2cc4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aleksey")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-178350")[#strong[#text("Aleksey")]]#text(size: 9pt, fill: rgb("596477"), " · 4 October 2012")])]

#text("In the part where you say that “The pre-disintegration body B is moving along the worldline in the O reference frame, and is thus moving along the line in the O’ reference frame” You are missing a 0 in the for one of the spacial coordinates.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-178449")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2012")])]

#text("Referring to second volume of Course of Theoretical Physics by Landau and Lifshitz, one can first find action principle for special relativity. Action must be invariant under lorentz transformations and integrand must be a differential of first order, so the integrand should be A*ds where A is a constant and ds = sqrt(c^2(dt)^2 – (dx)^2- (dy)^2 – (dz)^2). Limit in the low velocity should give the action for newton mechanics so A can be found. Then p = dL/dv and E = p.v – L .")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e43a3e894a7b8f93f28d334c1ac72f41f8fe7895d95629e07ab13aa0c03b12db-4dec058d8672b427036790bc5d4621cd1191797bea3a51812b3b65f570f3c571.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chorasimilarity")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-178469")[#strong[#text("chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2012")])]

#text("You take the soul out of the craft. On the other side Landau & Lifshitz derivation is clear and physical (i.e. frame independent, like in geometry).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-179080")[#strong[#text("Weekly Science Picks | Australian Science")]]#text(size: 9pt, fill: rgb("596477"), " · 6 October 2012")]

#text("[…] We all know the equation. Perhaps a lot less can actually tell you what it means. And then there are those special few that can decipher it, mathematically speaking, that is. Terence Tao, a name befitting of a mathematician, revisits the famous equation. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/04f2556cd4949ab5255faf7ce61f4c4abd48e0ce3dffb0634139a5c96fc092c5-29542f3a1cd293d3c8d3a0ba9731768de9693724efb5e09cd1356ce67834f658.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of tubinhpham")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-181651")[#strong[#text("tubinhpham")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2012")])]

#text("It’s great. But ")#mi("E=mc^2")#text(" remains forever true and beautiful.")#linebreak()#text(" Tkank Prof T. Tao")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88144531339e5ac96b6d549077071fa58f5a8dc026f31a8f8a05212898f2363-7cce7eb1dd58ce73b721df302093a3e33e7569b7272a9c7d1996547281a4c7fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit Nair")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-181801")[#strong[#text("Sujit Nair")]]#text(size: 9pt, fill: rgb("596477"), " · 13 October 2012")])]

#text("In Remark 1, you state that “…one can actually derive the law of conservation of momentum from the law of conservation of energy, together with special relativity.” I always think of conservation laws as a consequence of symmetry + action principle + Noether’s Theorem. I am curious to know if what you state in this remark is equivalent to the Noether approach.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-182010")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("When the least action principle is one of the laws of physics, yes; the fact that momentum conservation can be derived from energy conservation and Lorentz invariance is equivalent (via Noether’s theorem) to the fact that spatial translation symmetry can be derived from time translation symmetry and Lorentz invariance. But one could conceivably imagine alternate laws of physics in which there was no action principle, but for which Lorentz invariance and conservation of energy/momentum were still valid (but coming from some other source other than minimisation of a Lagrangian).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/cf439e996e29d20cb552d68ffe9f964d8919f4f9773b9c41c886fb326a5a9695-66573747b7b50dc2532a1c1acd7e23c9482f9aeb4a00f437399c08ade2278ee3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Jiang")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-181996")[#strong[#text("John Jiang")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("This really fills in the missing part of Einstein’s layman treatment of SR, where he derives all the Lorentz spatial time transformations like a charm but fell short of giving a convincing (or at least accessible) argument for the energy mass relation. I like the mention of rigidity of SO(1,2) representations, but wonder if anything special occurs in d =3. I remember reading an article in scientific American years ago on that we are actually living in 2-d, like a holograph. Maybe there is some evidence in this derivation?")#linebreak()#text(" It also seems to me all the non-rigorous part of the derivation attributes to smoothness or continuity assumptions. Is that correct? I wonder if there is a formalism that clarifies the relation between regularity assumptions and physics derivation of the kind above.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f2c4699af39d6e67f42f26e4f37f3764ee24c183deb651e3957ec0129bfcb3ca-7a803e7c9ef94a2af874c1479a84d6eda02163a89803ab17c35b84ba75194a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of E.L. Wisty")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-182267")[#strong[#text("E.L. Wisty")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2012")])]

#text("Reblogged this on ")#link("http://jsandber.wordpress.com/2012/10/15/10247/")[#text("Pink Iguana")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-193197")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 November 2012")])]

#text("I got it…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c4d6e8af213146738104b677e85a0b9615b39a735e4cce4c13c0bb017ccac8b5-d92cab546df915a02818b9a2307b08831ad6d885ef68e40c90414ae96a31894e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-194666")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 20 November 2012")])]

#text("You say that “it would be difficult to say anything non-tautological at all about the physical world if one could rely solely on 100% rigorous mathematical reasoning”.")

#text("I think, in fact, that even tautological statements could not be asserted, for in the absence of any information about the physical world, we can’t assume that we can even use logic (of any kind) and rules of inference to say anything about the world. It could very well be that there are worlds where completely different logical systems apply (or worlds where no such systems apply at all), and where tautologies deduced using rules of reasoning appropriate to our particular world would not apply.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-439043")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 November 2014")])]

#text("You are all mislead by not knowing what is the elements of matter called mass …? secondly what are the subtle elements that also matter which is unseen by naked eyes ………how can that be measured if no one knows ?haha")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-465231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2016")])]

#text("Your arguments can be made more precise by claiming that the very basic concepts of mass, energy and elementary particles (including the differences between real and virtual ones) still don’t have sufficiently rigorous mathematical definitions to allow any definite conclusion.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-465215")[#strong[#text("Parsing Ajay Sharma v. E = mc2 – gaplogs")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2016")]

#text("[…] this equation, Einstein was aware that it was held up by multiple approximations. As Terence Tao sets out, these would include (but not be limited to) p being equal to mv at low velocities, the laws of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-465806")[#strong[#text("Parsing Ajay Sharma v. E = mc 2 – The Wire – TheNews123")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2016")]

#text("[…] this equation, Einstein was aware that it was held up by multiple approximations. As Terence Tao sets out, these would include (but not be limited to) p being equal to mv at low velocities, the laws of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-471153")[#strong[#text("E=mc^2 – Making Sense of Complications")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2016")]

#text("[…] ")#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/")[#text("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-489723")[#strong[#text("Parsing Ajay Sharma v. E = mc2 – Regeneracy")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2017")]

#text("[…] this equation, Einstein was aware that it was held up by multiple approximations. As Terence Tao sets out, these would include (but not be limited to) p being equal to mv at low velocities, the laws of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-506630")[#strong[#text("Parsing Ajay Sharma v. E = mc2 – Panicking")]]#text(size: 9pt, fill: rgb("596477"), " · 28 October 2018")]

#text("[…] this equation, Einstein was aware that it was held up by multiple approximations. As Terence Tao sets out, these would include (but not be limited to) p being equal to mv at low velocities, the laws of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-512975")[#strong[#text("Parsing Ajay Sharma v. E = mc2 – Drizzly")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2019")]

#text("[…] this equation, Einstein was aware that it was held up by multiple approximations. As Terence Tao sets out, these would include (but not be limited to) p being equal to mv at low velocities, the laws of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-513154")[#strong[#text("Parsing Ajay Sharma v. E = mc2 – Excitations")]]#text(size: 9pt, fill: rgb("596477"), " · 26 February 2019")]

#text("[…] this equation, Einstein was aware that it was held up by multiple approximations. As Terence Tao sets out, these would include (but not be limited to) p being equal to mv at low velocities, the laws of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8408f74bc1f05afba4953cabd832bae38773e4b49022bb99014a1bbe4e7e5188-acedc02fa86d00434b908820f58316acc14313fd570bb96eb0ae4e9263feb3f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mike")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-515378")[#strong[#text("Mike")]]#text(size: 9pt, fill: rgb("596477"), " · 21 April 2019")])]

#text("Old post, sorry for the late comment.")

#text("Would just like to make a small correction (applies to your first post on this subject also): Einstein’s original derivation does NOT mention photons or use the Planck-Einstein relation. Rather, it cites the result from his previous SR paper that the energy and frequency of a classical light wave transform in the same way under a Lorentz boost. He obtains the light-energy transformation in the SR paper by: A) transforming the energy density of a plane wave; B) transforming the volume of a sphere enclosing part of the wave and moving along at the speed of light with it; and C) multiplying these two transformations. There’s nothing quantum about it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-516597")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("In order to make physics a true mathematical theory (i.e. a part of mathematics – as chemistry is by now a part of physics) one should give rigorous(!) definitions (in terms of the spacetime metric) for all the physical concepts (e.g. elementary particles and their intrinsic quantum parameters like mass, electric charge, spin and also all the classical observer dependent concepts like mass, electric charge, linear and angular momentum).")#linebreak()#text(" Clearly, the true mathematical foundations of the current physical theories are still incomplete(!) (the situation of physical theories today is similar to the situation of mathematical theories before the introduction of modern set theory and mathematical logic which provided the needed solid foundation for all currently used mathematical concepts.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-516605")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("There is no reason to believe physics can be made into a precise “mathematical theory.” Physical models make assumptions about the world to provide predictions about them. There is no sense in which you can simply have a “true” and physical meaningful concept of, say, mass following purely from mathematical axioms. You ultimately have to make some simplifying assumptions about the world and take some facts for granted if you want to get anywhere serious. Conversely, having a mathematically sound axiomatization of an effective physical theory doesn’t make the theory in any sense “true” as a model for the universe — “the map is not the territory.”")

#text("Chemistry can only be seen a part of physics in so far as the reduction to the axioms of quantum mechanics proves practical. In general, the systems studied in chemistry are often too complicated to be approached simply as a quantum many-body systems while also too structured for that approach to be the most fruitful. The parts of chemistry that can be fruitfully addressed as applications of AMO — so-called “quantum chemistry” — are the exceptions.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-516608")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2019")])]

#text("On the other hand, there is no reason to be pessimistic about the existence of a precise and rigorous representation of physics as a mathematical model (e.g. by explicit rigorous realization of Tegmark’s “Mathematical universe hypothesis” in which our physical universe is precisely represented by a certain mathematical structure.)")#linebreak()#text(" History tells us that pessimism and conservatism often delay the progress of scientific knowledge, so in order to make real fundamental progress on the true mathematical foundation of physics, one should try to seriously consider any logically consistent idea for such a theory (without making unnecessary “simplifying assumptions” – following Newton’s phrase “Hypothesis non fingo”)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/35be769bdad9098ac605a9c9ce3cd24aa3253fae607ae5fae402b405c9810ac0-6438823892145878189c64c1a160119326e7454f9dd24fe618fba43d210673f8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-570117")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2020")])]

#text("Dear Terence,")#linebreak()#text(" Thank you for your wonderful post.")#linebreak()#text(" Does your comment")

#text("“But it would be difficult to say anything non-tautological at all about the physical world if one could rely solely on 100% rigorous mathematical reasoning.”")

#text("confirm that the equation E = mc2 is an empirical claim about the physical world that could have different in another universe?")#linebreak()#text(" Thanks.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7675b826b1f93cadb15e129d15674d358e6fe1ab2a52307d0539fdf0181a958c-a16303ad71544ad0fd9654fb3be0dcdb6bd1cc46c59e29d1379baf708f2151c6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aziz Lokhandwala")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-617730")[#strong[#text("Aziz Lokhandwala")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2021")])]

#text("Mr tao,")#linebreak()#text(" Your arguments are appreciative. I would like to request you to derive Lorentz transformation by the concepts of four plane systems. In 4-plane system we know that a position of an object is determined by 3 coordinates regardless of 4th one. The reason is intersection of 3 planes is a point. Also, in 2d systems we know that it’s the distance which identifies relationship between coordinates, likewise in 3-plane systems it’s the sum of area and in 4-plane it is volume. For instance, consider a pyramid with triangular base. If a point P is inside this pyramid, and if we know three coordinates we can determine the fourth one by the volume of small pyramids formed inside bigger one. I am having discrete concepts in mind but I am not able to form a rigid block of those discrete ideas to derive Lorentz transformations. I would be thankful if you help me out with the same.")

#text("Sincerely,")#linebreak()#text(" Aziz Lokhandwala")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-638933")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2022")])]

#text("That’s not how it happened. He knew that energy and matter were related for existence. He chose the letter c to represent the speed of light because what he really meant was consciousness . But he was not in a world that was ready to accept that and he understood that light equals consciousness")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/10/02/einsteins-derivation-of-emc2-revisited/#comment-685366")[#strong[#text("Parsing Ajay Sharma v. E = mc2 – rndm walk")]]#text(size: 9pt, fill: rgb("596477"), " · 12 July 2024")]

#text("[…] this equation, Einstein was aware that it was held up by multiple approximations. As Terence Tao sets out, these would include (but not be limited to) p being equal to mv at low velocities, the laws of […]")
]
