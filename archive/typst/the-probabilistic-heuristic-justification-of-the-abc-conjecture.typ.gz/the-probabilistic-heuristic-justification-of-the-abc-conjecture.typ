// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/
// Converted to Typst by tao2typ: "2026-10-14T09:27:44.025653+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "The probabilistic heuristic justification of the ABC conjecture", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("The probabilistic heuristic justification of the ABC conjecture")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 18 September 2012")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")[#text("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("There has been a lot of recent interest in the ")#link("http://en.wikipedia.org/wiki/Abc_conjecture")[#text("abc conjecture")]#text(", since the ")#link("http://www.kurims.kyoto-u.ac.jp/~motizuki/Inter-universal%20Teichmuller%20Theory%20IV.pdf")[#text("release a few weeks ago")]#text(" of the last of a series of papers by Shinichi Mochizuki which, as one of its major applications, claims to establish this conjecture. It’s still far too early to judge whether this proof is likely to be correct or not (the entire argument encompasses several hundred pages of argument, mostly in the area of anabelian geometry, which very few mathematicians are expert in, to the extent that we still do not even have a full outline of the proof strategy yet), and I don’t have anything substantial to add to the existing discussion around that conjecture. (But, for those that are interested, ")#link("http://michaelnielsen.org/polymath1/index.php?title=ABC_conjecture")[#text("the Polymath wiki page on the ABC conjecture")]#text(" has collected most of the links to that discussion, and to various background materials.)")

#text("In the meantime, though, I thought I might give the standard probabilistic heuristic argument that explains why we expect the ABC conjecture to be true. The underlying heuristic is a common one, used throughout number theory, and it can be summarised as follows:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Heuristic 1 (Probabilistic heuristic)")]#text(" ")#metadata(none) <tao-1e76c19f7fab9415c41c>#text(" Even though number theory is a deterministic subject (one does not need to roll any dice to factorise a number, or figure out if a number is prime), one expects to get a good asymptotic prediction for the answers to many number-theoretic questions by pretending that various number-theoretic assertions ")#mi("{E}")#text(" (e.g. that a given number ")#mi("{n}")#text(" is prime) are probabilistic events (with a probability ")#mi("{\\mathop{\\bf P}(E)}")#text(" that can vary between ")#mi("{0}")#text(" and ")#mi("{1}")#text(") rather than deterministic events (that are either always true or always false). Furthermore:")

#list(
[#text("(Basic heuristic) If two or more of these heuristically probabilistic events have no obvious reason to be strongly correlated to each other, then we should expect them to behave as if they were (jointly) independent.")],
[#text("(Advanced heuristic) If two or more of these heuristically probabilistic events have ")#emph[#text("some")]#text(" obvious correlation between them, but no further correlations are suspected, then we should expect them to behave as if they were ")#emph[#text("conditionally")]#text(" independent, relative to whatever data is causing the correlation.")]
)
]

#text("This is, of course, an extremely vague and completely non-rigorous heuristic, requiring (among other things) a subjective and ")#emph[#text("ad hoc")]#text(" determination of what an “obvious reason” is, but in practice it tends to give remarkably plausible predictions, some fraction of which can in fact be backed up by rigorous argument (although in many cases, the actual argument has almost nothing in common with the probabilistic heuristic). A famous special case of this heuristic is the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Cramer's_random_model_for_the_primes")[#text("Cramér random model for the primes")]#text(", but this is not the only such instance for that heuristic.")

#text("To give the most precise predictions, one should use the advanced heuristic in Heuristic ")#link(<tao-1e76c19f7fab9415c41c>)[#text("1")]#text(", but this can be somewhat complicated to execute, and so we shall focus instead on the predictions given by the basic heuristic (thus ignoring the presence of some number-theoretic correlations), which tends to give predictions that are quantitatively inaccurate but still reasonably good at the qualitative level.")

#text("Here is a basic “corollary” of Heuristic ")#link(<tao-1e76c19f7fab9415c41c>)[#text("1")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Heuristic 2 (Heuristic Borel-Cantelli)")]#text(" Suppose one has a sequence ")#mi("{E_1, E_2, \\ldots}")#text(" of number-theoretic statements, which we heuristically interpet as probabilistic events with probabilities ")#mi("{\\mathop{\\bf P}(E_1), \\mathop{\\bf P}(E_2), \\ldots}")#text(". Suppose also that we know of no obvious reason for these events to have much of a correlation with each other. Then:")

#list(
[#text("If ")#mi("{\\sum_{i=1}^\\infty \\mathop{\\bf P}(E_i) < \\infty}")#text(", we expect only finitely many of the statements ")#mi("{E_n}")#text(" to be true. (And if ")#mi("{\\sum_{i=1}^\\infty \\mathop{\\bf P}(E_i)}")#text(" is much smaller than ")#mi("{1}")#text(", we in fact expect none of the ")#mi("{E_n}")#text(" to be true.)")],
[#text("If ")#mi("{\\sum_{i=1}^\\infty \\mathop{\\bf P}(E_i) = \\infty}")#text(", we expect infinitely many of the statements ")#mi("{E_n}")#text(" to be true.")]
)
]

#text("This heuristic is motivated both by the ")#link("http://en.wikipedia.org/wiki/Borel-Cantelli_Lemma")[#text("Borel-Cantelli lemma")]#text(", and by the standard probabilistic computation that if one is given jointly independent, and genuinely probabilistic, events ")#mi("{E_1, E_2, \\ldots}")#text(" with ")#mi("{\\sum_{i=1}^\\infty \\mathop{\\bf P}(E_i) = \\infty}")#text(", then one almost surely has an infinite number of the ")#mi("{E_i}")#text(" occuring.")

#text("Before we get to the ABC conjecture, let us give two simpler (and well known) demonstrations of these heuristics in action:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1 (Twin prime conjecture)")]#text(" One can heuristically justify the ")#link("http://en.wikipedia.org/wiki/Twin_prime")[#text("twin prime conjecture")]#text(" as follows. Using the ")#link("http://en.wikipedia.org/wiki/Prime_number_theorem")[#text("prime number theorem")]#text(", one can heuristically assign a probability of ")#mi("{1/\\log n}")#text(" to the event that any given large integer ")#mi("{n}")#text(" is prime. In particular, the probability that ")#mi("{n+2}")#text(" is prime will then be ")#mi("{1/\\log(n+2)}")#text(". Making the assumption that there are no strong correlations between these events, we are led to the prediction that the probability that ")#mi("{n}")#text(" and ")#mi("{n+2}")#text(" are ")#emph[#text("simultaneously")]#text(" prime is ")#mi("{\\frac{1}{(\\log n)(\\log n+2)}}")#text(". Since ")#mi("{\\sum_{n=1}^\\infty \\frac{1}{(\\log n) (\\log n+2)} = \\infty}")#text(", the Borel-Cantelli heuristic then predicts that there should be infinitely many twin primes.")

#text("Note that the above argument is a bit too naive, because there are some non-trivial correlations between the primality of ")#mi("{n}")#text(" and the primality of ")#mi("{n+2}")#text(". Most obviously, if ")#mi("{n}")#text(" is prime, this greatly increases the probability that ")#mi("{n}")#text(" is odd, which implies that ")#mi("{n+2}")#text(" is odd, which then elevates the probability that ")#mi("{n+2}")#text(" is prime. A bit more subtly, if ")#mi("{n}")#text(" is prime, then ")#mi("{n}")#text(" is likely to avoid the residue class ")#mi("{0 \\text{ mod } 3}")#text(", which means that ")#mi("{n+2}")#text(" avoids the residue class ")#mi("{2 \\text{ mod } 3}")#text(", which ends up decreasing the probability that ")#mi("{n+2}")#text(" is prime. However, there is a standard way to correct for these local correlations; see for instance in ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("this previous blog post")]#text(". As it turns out, these local correlations ultimately alter the prediction for the asymptotic density of twin primes by a constant factor (the ")#link("http://mathworld.wolfram.com/TwinPrimesConstant.html")[#text("twin prime constant")]#text("), but do not affect the qualitative prediction of there being infinitely many twin primes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 2 (Fermat’s last theorem)")]#text(" Let us now heuristically count the number of solutions to ")#mi("{x^n+y^n=z^n}")#text(" for various ")#mi("{n}")#text(" and natural numbers ")#mi("{x,y,z}")#text(" (which we can reduce to be coprime if desired). We recast this (in the spirit of the ABC conjecture) as ")#mi("{a+b=c}")#text(", where ")#mi("{a,b,c}")#text(" are ")#mi("{n^{th}}")#text(" powers. The number of ")#mi("{n^{th}}")#text(" powers up to any given number ")#mi("{N}")#text(" is about ")#mi("{N^{1/n}}")#text(", so heuristically any given natural number ")#mi("{a}")#text(" has a probability about ")#mi("{a^{1/n - 1}}")#text(" of being an ")#mi("{n^{th}}")#text(" power. If we make the naive assumption that (in the coprime case at least) there is no strong correlation between the events that ")#mi("{a}")#text(" is an ")#mi("{n^{th}}")#text(" power, ")#mi("{b}")#text(" is an ")#mi("{n^{th}}")#text(" power, and ")#mi("{a+b}")#text(" being an ")#mi("{n^{th}}")#text(" power, then for typical ")#mi("{a,b}")#text(", the probability that ")#mi("{a,b,a+b}")#text(" are all simultaneously ")#mi("{n^{th}}")#text(" powers would then be ")#mi("{a^{1/n-1} b^{1/n-1} (a+b)^{1/n-1}}")#text(". For fixed ")#mi("{n}")#text(", the total number of solutions to the Fermat equation would then be predicted to be")

#align(center)[#tao-fit-display[#mitex("\\sum_{a=1}^\\infty \\sum_{b=1}^\\infty a^{1/n-1} b^{1/n-1} (a+b)^{1/n-1}.")]]

#text("(Strictly speaking, we need to restrict to the coprime case, but given that a positive density of pairs of integers are coprime, it should not affect the qualitative conclusion significantly if we now omit this restriction.) It might not be immediately obvious as to whether this sum converges or diverges, but (as is often the case with these sorts of unsigned sums) one can clarify the situation by dyadic decomposition. Suppose for instance that we consider the portion of the sum where ")#mi("{c=a+b}")#text(" lies between ")#mi("{2^k}")#text(" and ")#mi("{2^{k+1}}")#text(". Then this portion of the sum can be controlled by")

#align(center)[#tao-fit-display[#mitex("\\sum_{a \\leq 2^{k+1}} \\sum_{b \\leq 2^{k+1}} a^{1/n-1} b^{1/n-1} O( ( 2^k )^{1/n - 1} )")]]

#text("which simplifies to")

#align(center)[#tao-fit-display[#mitex("O( 2^{(3/n - 1)k} ).")]]

#text("Summing in ")#mi("{k}")#text(", one thus expects infinitely many solutions for ")#mi("{n=2}")#text(", only finitely many solutions for ")#mi("{n>3}")#text(" (indeed, a refinement of this argument shows that one expects only finitely many solutions even if one considers all ")#mi("{n>3}")#text(" at once), and a borderline prediction of there being a barely infinite number of solutions when ")#mi("{n=3}")#text(". Here is of course a place where a naive application of the probabilistic heuristic breaks down; there is enough arithmetic structure in the equation ")#mi("{x^3+y^3=z^3}")#text(" that the naive probabilistic prediction ends up being an inaccurate model. Indeed, while this heuristic suggests that a typical homogeneous cubic should have a logarithmic number of integer solutions of a given height ")#mi("{N}")#text(", it turns out that some homogeneous cubics (namely, those associated to elliptic curves of positive rank) end up with the bulk of these solutions, while other homogeneous cubics (including those associated to elliptic curves of zero rank, including the Fermat curve ")#mi("{x^3+y^3=z^3}")#text(") only get finitely many solutions. The reasons for this are subtle, but certainly the high degree of arithmetic structure present in an elliptic curve (starting with the elliptic curve group law which allows one to generate new solutions from old ones, and which also can be used to exclude solutions to ")#mi("{x^3+y^3=z^3}")#text(" via the method of descent) is a major contributing factor.")
]

#text("Below the fold, we apply similar heuristics to suggest the truth of the ABC conjecture.")

#metadata(none) <tao-06b32544e6d9cd0e38e7>

#heading(level: 1)[#strong[#text(" — 1. The ABC conjecture — ")]]

#text("The ABC conjecture asserts that for every ")#mi("{\\epsilon > 0}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("c \\ll_\\epsilon \\text{rad}(abc)^{1+\\epsilon}")]]

#text("whenever ")#mi("{a+b=c}")#text(" are coprime natural numbers, and ")#mi("{\\text{rad}(abc)}")#text(" is the product of all the primes dividing ")#mi("{abc}")#text(". Since ")#mi("{a,b,c}")#text(" are coprime, ")#mi("{\\text{rad}(abc) = \\text{rad}(a) \\text{rad}(b) \\text{rad}(c)}")#text(", and an equivalent formulation of the conjecture is as follows: if ")#mi("{\\alpha,\\beta,\\gamma \\geq 0}")#text(" are real numbers with ")#mi("{\\alpha+\\beta+\\gamma < 1}")#text(", then for sufficiently large ")#mi("{N}")#text(", there does not exist any solution to the equation ")#mi("{a+b=c}")#text(" with ")#mi("{N \\leq c \\leq 2N}")#text(" (say), ")#mi("{a,b,c}")#text(" coprime, and")

#align(center)[#tao-fit-display[#mitex("\\text{rad}(a) \\leq N^\\alpha; \\text{rad}(b) \\leq N^\\beta; \\text{rad}(c) \\leq N^\\gamma.")]]

#text("Indeed, one can deduce the former version of the ABC conjecture from the latter by using a finite mesh of triples ")#mi("{(\\alpha,\\beta,\\gamma)}")#text(" with spacing equal to small multiple of ")#mi("{\\epsilon}")#text("; we leave the details to the interested reader.")

#text("We can now try to randomly find counterexamples to the abc conjecture as follows:")

#enum(start: 1, 
[#text("Pick a large ")#mi("{N}")#text(" (say, a power of two).")],
[#text("Pick coprime squarefree numbers ")#mi("{x \\leq N^\\alpha}")#text(", ")#mi("{y \\leq N^\\beta}")#text(", ")#mi("{z \\leq N^\\gamma}")#text(".")],
[#text("Pick numbers ")#mi("{a,b,c = O(N)}")#text(" with ")#mi("{\\text{rad}(a) = x, \\text{rad}(b) = y, \\text{rad}(c) = z}")#text(" with ")#mi("{c}")#text(" comparable to ")#mi("{N}")#text(".")],
[#text("Check if ")#mi("{a+b=c}")#text(".")]
)

#text("Steps 1, 2, and 4 are easy to apply probabilistic heuristics to. For Step 3, we need the following lemma, reminiscent of the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("classical divisor bound")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" Let ")#mi("{x \\leq N}")#text(" be a square-free integer. Then there are at most ")#mi("{O(N^{o(1)})}")#text(" integers ")#mi("{n}")#text(" less than ")#mi("{N}")#text(" with radical ")#mi("{x}")#text(".")
]

#emph[#text("Proof:")]#text(" Factorise ")#mi("{x = p_1 \\ldots p_k}")#text(". We are trying to establish the bound ")#mi("{A = O(N^{o(1)})}")#text(", where ")#mi("{A}")#text(" is the number of numbers ")#mi("{n}")#text(" less than ")#mi("{N}")#text(" which are divisible by ")#mi("{p_1,\\ldots,p_k}")#text(" but by no other primes, that is to say they lie in the set ")#mi("{S := \\{ p_1^{a_1} \\ldots p_k^{a_k}: a_1,\\ldots,a_k \\geq 1 \\}}")#text(". To do this, it is convenient to work with Dirichlet series, and specifically with the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in S} \\frac{1}{n^{\\epsilon}}")]]

#text("for some parameter ")#mi("{\\epsilon>0}")#text(" to be optimised in later. On the one hand, this expression is at least ")#mi("{N^{-\\epsilon} A}")#text(". On the other hand, we have the factorisation")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in S} \\frac{1}{n^{\\epsilon}} = \\prod_{i=1}^k (\\frac{1}{p_i^\\epsilon} + \\frac{1}{p_i^{2\\epsilon}} + \\ldots).")]]

#text("We crudely bound")

#align(center)[#tao-fit-display[#mitex("(\\frac{1}{p_i^\\epsilon} + \\frac{1}{p_i^{2\\epsilon}} + \\ldots) \\leq C_\\epsilon")]]

#text("for some ")#mi("{C_\\epsilon}")#text(" depending only on ")#mi("{\\epsilon}")#text(", using the trivial bound ")#mi("{p_i \\geq 2}")#text(" and the geometric series formula, leading to")

#align(center)[#tao-fit-display[#mitex("A \\leq N^\\epsilon C_\\epsilon^k.")]]

#text("On the other hand, since")

#align(center)[#tao-fit-display[#mitex("\\sum_{i=1}^k \\log p_i = \\log x \\leq \\log N,")]]

#text("we see from the prime theorem (which gives a lower bound on the sum of the logarithms of the first ")#mi("{k}")#text(" primes, which in turn lower bounds ")#mi("{\\sum_{i=1}^k \\log p_i}")#text(") that")

#align(center)[#tao-fit-display[#mitex("k \\ll \\frac{\\log N}{\\log \\log N} = o(\\log N),")]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("A \\leq N^{\\epsilon + o(1)}")]]

#text("for any fixed ")#mi("{\\epsilon}")#text("; as ")#mi("{\\epsilon>0}")#text(" can be arbitrarily small, the claim follows. ")#mi("\\Box")

#text("Now we can run the probabilistic heuristics. After selecting ")#mi("{N}")#text(" as a large power of two in Step 1, we have ")#mi("{O(N^{\\alpha+\\beta+\\gamma})}")#text(" choices for ")#mi("{x,y,z}")#text(" in Step 2. By the above lemma, for each ")#mi("{x,y,z}")#text(", there are ")#mi("{O(N^{o(1)})}")#text(" choices for ")#mi("{a,b,c}")#text(" that are of magnitude ")#mi("{O(N)}")#text(", and assuming (in the case when ")#mi("{a,b,c}")#text(" are coprime) that there is no prior correlation between ")#mi("{c}")#text(" and ")#mi("{a+b}")#text(", which we think of as being randomly distributed amongst the numbers of size ")#mi("{O(N)}")#text(", the probability that ")#mi("{a+b=c}")#text(" should be of order ")#mi("{1/N}")#text(". This leads to a total probability of ")#mi("{\\sum_N O( N^{\\alpha+\\beta+\\gamma-1+o(1)})}")#text("; since ")#mi("{\\alpha+\\beta+\\gamma<1}")#text(", this sum is convergent (for ")#mi("{N}")#text(" ranging over powers of ")#mi("{2}")#text("), so we expect only finitely many counterexamples, thus supporting the ABC conjecture.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" In the case of ")#mi("{x^3+y^3=z^3}")#text(", the naive heuristic prediction was incorrect, basically because of the algebraic structure in the Fermat curve ")#mi("{x^3+y^3=z^3}")#text(" (which, among other things, is an elliptic curve and thus enjoys a group law). In the case of the general ")#mi("{a+b=c}")#text(" equation, though, no analogous algebraic structure appears to be present. So there is no obvious correlation here. (Of course, this does not rule out the possibility of a much less obvious correlation; this is one of the reasons why the above arguments are only heuristic, and fall well short of a rigorous proof of anything.)")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (52)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3ac0f91483a48a9d93b1977df48bcd89d159e740253d523c87dcbd59fa832ee4-980fe49509e6b765c38f74227c18b5d6baa480d0f2c06444f6d190a0f7bdefc3.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The probabilistic heuristic justification of the ABC conjecture « Guzman's Mathematics Weblog")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172312")[#strong[#text("The probabilistic heuristic justification of the ABC conjecture « Guzman's Mathematics Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2012")])]

#text("[…] The probabilistic heuristic justification of the ABC conjecture. Share this:FacebookTwitterRedditStumbleUponTumblrDiggLinkedInPinterestEmailPrintLike this:LikeBe the first to like this. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172325")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2012")])]

#text("The equation x^3=y^3+z^3 is an elliptic curve, as are slight perturbations of it. Some of these curves have finitely many rational points and some have infinitely many. Can we build a probabilistic heuristic that suggests this ambiguity?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172331")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2012")])]

#text("This is a very delicate question (essentially that of understanding the rank of a typical elliptic curve), as the objects involved have a very rich algebraic structure, and the crude analytic heuristics given here only give a zeroth order approximation at best; also, deep conjectures such as BSD become relevant. There are a number of surveys on this topic, see e.g. ")#link("http://www.ams.org/journals/bull/2002-39-04/S0273-0979-02-00952-7/S0273-0979-02-00952-7.pdf")[#text("this one by Rubin and Silverberg")]#text(", or ")#link("http://www.math.harvard.edu/~mazur/preprints/average.ranks.pdf")[#text("this one by Bektemirov, Mazur, Stein and Watkins")]#text(".")

#text("ADDED LATER: The crude heuristics mentioned in the post, though, do support the fact that a “typical” cubic curves should a logarithmic number of integer points at a given height, or equivalently that a “typical” elliptic curves have a logarithmic number of rational points at a given height. This is consistent with the algebraic heuristics that suggest that the rank of a typical elliptic curve is typically zero or one.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1dab262b249e6b008de2defe2a9d55f776181f2faf2f8a2ae168348cdfb2adaf-097fe507317aee85ccf32427e06a89aeacc09d75464afe95cd265a14b70a7a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Will Sawin")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172337")[#strong[#text("Will Sawin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2012")])]

#text("Well I guess one can say that the group law induces an obvious correlation between the existence of rational points in different regions. Similarly, in the other case where the “actual” algebraic results give (much easier to resolve) ambiguity, which is affine conics, there is also a group law to provide correlation. This “explains” the failure of crude heuristics.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172504")[#strong[#text("Wednesday Highlights | Pseudo-Polymath")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2012")]

#text("[…] Probability and number theory. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172505")[#strong[#text("Stones Cry Out - If they keep silent… » Things Heard: e238v3")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2012")]

#text("[…] Probability and number theory. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0d841279bde782b1cb2e7ccda53cc7961fc14ed2c90a8bc7731bb0c74350c951-eee14fee51eb44b15d62bce8c494cea0959e98139d76d125f021dd3452b6c425.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tao on the ABC Conjecture « Pink Iguana")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172637")[#strong[#text("Tao on the ABC Conjecture « Pink Iguana")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2012")])]

#text("[…] What’s New, The probabilistic heuristic justification of the ABC conjecture, here. There has been a lot of recent interest in the abc conjecture, since the release a few weeks ago […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-172756")[#strong[#text("The abc conjecture and its consequences « Fight with Infinity")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2012")]

#text("[…] T.Tao The probabilistic heuristic justification of the ABC conjecture […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/182b87a5df38193ec84e2427882a865fccbe0cd42f235961dbbd870fc13d2e1c-daad961ac791038c43231002e83c852927f40266d26d9382d7adcdd0d8cb7282.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of William Schlieper")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173258")[#strong[#text("William Schlieper")]]#text(size: 9pt, fill: rgb("596477"), " · 20 September 2012")])]

#text("I think that there’s a slight error in the Fermat’s Last Theorem derivation for n=3, as the elements of the ring ")#mi("\\mathbf{Z}(\\omega)")#text(" have only two degrees of freedom, not three, as ")#mi("1+\\omega+\\omega^2=0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173427")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2012")])]

#text("Ugh, you’re right, that argument is in fact incorrect (even when one takes the factorisation in ")#mi("{\\mathbf Z}[\\omega]")#text(" into account, the probabilistic heuristic still suggests a logarithmic number of solutions). It appears that it is instead the group law for elliptic curves (")#strike[#text("and for singular cubic curves")]#text(" such as ")#mi("x^3+y^3=z^3")#text(") which is the additional structure that is defeating the probabilistic heuristic (cf. Euler’s proof by descent of FLT for n=3, which can be interpreted in terms of this group law).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1640199704d506f1b0a8d5ffd49c6640d08c1da111edb2e44c39f5aa2603916c-cd4c3a42a665d13f9cdef49e7a07df82014c5e1c57e65c70b4ae891febb54a86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Silverman")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173600")[#strong[#text("Joe Silverman")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2012")])]

#text("Are you using projective coordinates here? If so, then ")#mi("x^3+y^3=z^3")#text(" isn’t singular, it’s an elliptic curve. On a singular cubic, the non-singular points form a multiplicative group, so the number of rational points of bounded height grows even more rapidly than on elliptic curves. So it’s not just having a group law, but the kind of group, that determines how badly the heuristic fails. (Sorry for the quibble, this was a very nice post on why ABC should be true.)")

#emph[#text("[Gah, that was careless of me. Corrected now, thanks – T.]")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5ca27f910b4429ed53598d297c74beb010349a6d2d26ea11498e6b6e185e19fd-9af88c64276dad810b7eba14eaf34612d237552aea566dbaee93582f417e8b55.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Noname")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173424")[#strong[#text("Noname")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2012")])]

#text("If I apply the argument of Example 1 to the case when n, n+2, n+4 are all primes, do I also get the conclusion that there are infinitely many of them? But for any n, at least one of these three numbers must be 0 mod 3, do we get a contradiction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173430")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 September 2012")])]

#text("Yes, this is a failure of the naive Cramer heuristic in which there is no correlation between the primality of numbers such as n, n+2, and n+4, whereas in fact as you point out there are some correlations, in this case coming from the residue classes modulo 3. There is a refined heuristic to take care of this, which is discussed further in a previous blog post ( ")#link("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")[#text("https://terrytao.wordpress.com/2008/01/07/ams-lecture-structure-and-randomness-in-the-prime-numbers/")]#text(" ), which was also mentioned at the end of Example 1.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173754")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")])]

#text("Could you please inform how does one read the symbol ")#mi("\\ll_{\\epsilon }")#text(" that appears in the conjecture? I think I understand its meaning but I don’t know")#linebreak()#text(" how to read it, even in my native language.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bf595c8839d19252e55ac66a90d54befc1520302edc3ca669607e61232c3aff-b78a79f663aedb520c25de4f11848646f6da14c4c79622261b49bb34c769db8e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ruben")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173889")[#strong[#text("Ruben")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")])]

#text("Much Smaller <<")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6fafbe9ccf9cf67c29bbc6431088ce5a584d89a83e00ea79f0573f5a3f1cb955-2b2034230bc3334ee6424ff54d8f70770819c5e3fdfbd75f012e73edede7568f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173893")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")])]

#text("Thanks, but how do you read the dependence on ")#mi("\\epsilon")#text("?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/daf143f014f35667a2967aa381083188528243e857463986e10999fda8613c3c-f69db5b06e23919b2a96801e68efd7cced190e29c7b7d7408cbf753822a06928.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Américo Tavares")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174263")[#strong[#text("Américo Tavares")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")])]

#text("I had posted essentially this question on Mathematics Stack Exchange ")#link("http://math.stackexchange.com/q/199753/752")[#text("How does one read aloud Vinogradov’s notation ")#mi("\\ll")#text(" and ")#mi("\\ll_{\\epsilon }")]#link("http://math.stackexchange.com/q/199753/752")[#text("?")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-173845")[#strong[#text("Envy number theorists! « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")]

#text("[…] learned from some blogs (here, here and here) that the ABC-conjecture might be solved, and also (by extrapolation) that this is a very […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174031")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2012")])]

#text("Tao,")

#text("a bit misplaced, I’m sorry, but this may be of interest to you:")

#link("http://arxiv.org/pdf/1208.2473.pdf")[#text("Click to access 1208.2473.pdf")]

#text("Best,")

#text("Markus")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/815387abb27267e38e0a2f5283f676e11bbc6a335bc3cb3b21f217ced2c2319b-7a270c155a389afd795b534ca64eec559bec2a09b840c4cc7cb2b56940ad16d5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Duvall")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174079")[#strong[#text("Duvall")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")])]

#text("Markus,")#linebreak()#text(" the professor who posed this paper on arxiv also claims to have solved 3 Millenium problems on his web-page. I think the situation is clear now and does not require Terry’s attention.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174228")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")])]

#text("any given natural number {a} has a probability about {a^{1/n – 1}} of being an {n^{th}} power")

#text("—- any natural number no larger than {a} has a probability about {a^{1/n – 1}} of being an {n^{th}} power")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9558584a3ca6515d0fafc5021b7a439a04b9df1c75eed9e68b7d16aa4a2d59bd-9aa2f6a3bc9c0ce5b1be56e99194d974e8f662bedaed136b97e34d5b34578acf.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174229")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")])]

#text("any given natural number {a} has a probability about {a^{1/n – 1}} of being an {n^{th}} power")

#text("— any given natural number no larger than {a} has a probability about {a^{1/n – 1}} of being an {n^{th}} power")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174238")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")])]

#text("Well, yes, if you want to stay rigorous and treat the property of being an n^th power as a deterministic event, one has to perform an additional averaging such as the one you suggest. But for the purposes of applying the probabilistic heuristic, it is often simpler to pretend to work with a probabilistic model, where the property of being an n^th power has been replaced by a probabilistic event with a probability consistent with these averaged statistics; see Heuristic 1. While this model is of course inaccurate at the foundational level, the point of the heuristic is that it can still be remarkably accurate at the predictive level, particularly with regards to asymptotic statistics.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174325")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")])]

#text("P(for a given n-th power N, a number no larger than N is n-th power)")#linebreak()#text(" P(for a given n-th power N, there is a number ")#emph[#text("a")]#text(" smaller than N is n-th power and N-a is also a N-th power)")

#text("sum (P(a is n-th power)P(N-a is n-th power)=sum(N^(1/n-1)*N^(1/n-1)=sum(1/(k^(2n-2)) (with N=k^n) so the sum is always smaller than 1 when sum from k=2 and on for any n. When n=2, it is meaningless as we know there are lots of solutions.")

#text("This is originated from that P(for a given n-th power N, there is a number ")#emph[#text("a")]#text(" smaller than N is n-th power and N-a is also a N-th power) is not the same as P(a is n-th power)P(N-a is n-th power)")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174311")[#strong[#text("Weekly links for September 23 « God plays dice")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")]

#text("[…] Terry Tao has written a probablistic heuristic justification of the abc conjecture. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/69608b2c60140eba13205d9ee3f17b1591b184ffd1a2ed67f360ac55770c24cf-6dd1e87acc1ccca1621326f82f0693f6545e3e9b05366dbaa6488e221353cc6e.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of lkafle")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-174406")[#strong[#text("lkafle")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2012")])]

#text("Reblogged this on ")#link("http://lkafle.wordpress.com/2012/09/24/1705/")[#text("lava kafle kathmandu nepal")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5f4ed0453e3158d3fced2b27355ad51ee23420f59aedded412c3b6f3c1b5caf-75bead472e9b0e5bdbbc4391aa60fe3c202ae01417c29b7698dc24809899e5b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff Ezearn")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-178486")[#strong[#text("Jeff Ezearn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2012")])]

#text("One particular intriguing situation that sets FLT for n=3 (as in the pythagorean case n=2) from the higher cases is an old result of Perrin from the late 19th century, that a single solution to that (cubic) fermat curve implies an infinity of other (coprime) solutions.")#linebreak()#text(" This reinforces the reason why the heuristic must “turn in” an infinite number of solutions for the cubic case, since (implicitly) it assumes that there’s at least one solution (i.e. some a, b and a+b being simultaneously cubic integers). In that respect (juxtaposed with Perrin’s result), the heuristic is accurate!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5f4ed0453e3158d3fced2b27355ad51ee23420f59aedded412c3b6f3c1b5caf-75bead472e9b0e5bdbbc4391aa60fe3c202ae01417c29b7698dc24809899e5b6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jeff Ezearn")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-178545")[#strong[#text("Jeff Ezearn")]]#text(size: 9pt, fill: rgb("596477"), " · 5 October 2012")])]

#text("Aargh, on coming back to read I just realised that I should have said")

#text("“… (implicitly) assumes that there’s at least one PROBABLE solution…”")

#text("I had written in haste and perhaps I may give further thoughts. One may want to contrast and compare the heuristic for FLT n=3 and n>3 with Perrin’s and Falting’s theorem. i.e.")

#text("Theorem (Perrin): If Fermat curve for n=3 has one solution, then there are infinitely many (coprime) solutions")

#text("Theorem (after Falting’s): If Fermat curve for n>3 has at least one solution, then there can only be finitely many solutions.")

#text("Under these two DEFINITE results, an “accurate” heuristic should run as:")

#text("Heuristic (FLT n=3): If FLT n=3, has at least one PROBABLE counterexample (say some a, b and a+b being simultaneously cubic integers with an assumed non-zero probability), then there must be PROBABLY infinitely many other counterexamples.")

#text("Heuristic (FLT n>3): If FLT n>3 has at least one PROBABLE counterexample, then there can be PROBABLY only finitely many other counter")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-179165")[#strong[#text("News on the ABC conjecture | MathBlog")]]#text(size: 9pt, fill: rgb("596477"), " · 7 October 2012")]

#text("[…] that I have found two blog posts discussing it, one from Terrence Tao the other from the blog Quomodocumque, and just mentioning Terrence Tao, always seems to put some […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dc626e5eb2fdc7e3e1f6df624c40a5e6075e3b7a9ded910f8dd9b70c6f4cb71a-10356769ac249feba062c874db0d4a206c8c1a9d0d6a81bb97a7770b280d1749.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Martin")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-181320")[#strong[#text("Martin")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2012")])]

#text("New amazing prime numbers spiral: ")#link("http://www.youtube.com/watch?v=Dfar_AZub4Y")[#text("http://www.youtube.com/watch?v=Dfar_AZub4Y")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c26c98871eacf49aedbd22b1cca989c668501ccf720972a2d2eeb7d1ecb745bf-1e9f78b0bceb34e0016727f53551168dd719198dc57f31927f7234c43ac1c8e9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of James Tomson")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-181414")[#strong[#text("James Tomson")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2012")])]

#text("Beal Fermat and Pythagora’s Triplets ")#link("http://www.coolissues.com/mathematics/BealFermatPythagorasTriplets.htm")[#text("http://www.coolissues.com/mathematics/BealFermatPythagorasTriplets.htm")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The Chowla conjecture and the Sarnak conjecture « What’s new")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-182160")[#strong[#text("The Chowla conjecture and the Sarnak conjecture « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2012")])]

#text("[…] the amount that an analogous random sum would provide; cf. the probabilistic heuristic discussed in this recent blog post. There are a number of ways to make this heuristic precise. One of these is the following old […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f8f7893e9711cd18e131999a987810167b50261394d586fc63873db8d0d5f2c-80533e65bbb428895ea8cf2518ecc6b46f613ef794a9ef5ceb66c9350dea5a67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Salazar")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-217819")[#strong[#text("John Salazar")]]#text(size: 9pt, fill: rgb("596477"), " · 24 February 2013")])]

#text("What’s the current status of Mochizuki’s proof? Does it look like it will fly or have gaps been found that cannot be patched?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-234164")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("For a list of all known abc triples with quality > 1.4 see:")

#link("http://www.math.leidenuniv.nl/~desmit/abc/index.php?set=2")[#text("http://www.math.leidenuniv.nl/~desmit/abc/index.php?set=2")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fbc18fa1121b8fa9882913bae34c8ee95f5625eeca6286b1a2ad23ba28677eac-4b48c0ccfb856201ce86b093cbda2eddf8c25a173a1979df1f1fa74ff2800c19.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of observer")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-454297")[#strong[#text("observer")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2015")])]

#text("Progress: ")#link("https://www.maths.nottingham.ac.uk/personal/ibf/symcor.conf.html")[#text("https://www.maths.nottingham.ac.uk/personal/ibf/symcor.conf.html")]#text(". What would be the consequences of a person of his pedigree to be wrong?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1240566185f955dc972177295519b4b4d59e85a9305f64c325fba8ba1570a14a-f0ea6074c6f58edfe74cc6f6836ede99689ee0ff22bea52213431f7045a9f014.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Optimus Prime")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-458978")[#strong[#text("Optimus Prime")]]#text(size: 9pt, fill: rgb("596477"), " · 7 September 2015")])]

#text("Would be interested to see a Terry Tao update post on this theory given this post is from 2012 and the theory is still rumbling on.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-462652")[#strong[#text("ABC conjecture | fragments")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2015")]

#text("[…] A probabilistic heuristic justification for the ABC conjecture can be found at this blog post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-466714")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2016")])]

#text("Is there any classification of Diophantine equations which (at least in principle) can be solved by an effective version of the ABC conjecture?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-478110")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 16 February 2017")])]

#text("On the Search for a Valid Proof of the famous and important abc Conjecture, please refer to the following link for details:")

#link("https://www.researchgate.net/post/What_is_the_proof_of_the_ABC_Conjecture")[#text("https://www.researchgate.net/post/What_is_the_proof_of_the_ABC_Conjecture")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-480470")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2017")])]

#text("It is possible to formulate the abc conjecture in terms of c alone by defining the following function of c")

#mi("r(c) := \\min_{a, b} rad(a b c)")

#text("Where the minimum is over all coprime pairs (a,b) satisfying ")#mi("a+b=c")

#text("Clearly, ")#mi("r(c)")#text(" is well-defined for each ")#mi("c \\geq 2")#text(".")

#text("The abc conjecture is equivalent to the claim that ")#mi("r(c)")#text(" grows faster than any fractional power of ")#mi("c")#text(". This claim may be refined by making more refined lower bound estimates on the growth rate of ")#mi("r(c)")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-482828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2017")])]

#text("For a new approach (based on the theory of Shimura curves) to the abc conjecture and related problems, see Pasten’s paper")

#link("https://arxiv.org/pdf/1705.09251.pdf")[#text("Click to access 1705.09251.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b86d42e82de0383981f35411068f6ac1055505b0c141ccc7345be3525ce5b0c6-2284f8606b31475d25bb16f44d90b8b4f0d746a5aa035a2f2aec37835ec43aef.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Cole")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-505792")[#strong[#text("David Cole")]]#text(size: 9pt, fill: rgb("596477"), " · 9 October 2018")])]

#text("FYI: “Searching for a proof of the ABC-conjecture”,")

#link("https://www.math10.com/forum/viewtopic.php?f=63&t=1793")[#text("https://www.math10.com/forum/viewtopic.php?f=63&t=1793")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1da11d13512b376fa46920b9464cfbe51a53b88ea37069c9619892d35e40cdd3-2e309d20088f5da722b18e869ca7048d30d929b5ea4c60ecd08d1f5e71a84eef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of JF22")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-610401")[#strong[#text("JF22")]]#text(size: 9pt, fill: rgb("596477"), " · 15 December 2020")])]

#text("I came across this:")

#link("http://www.kurims.kyoto-u.ac.jp/~motizuki/Explicit%20estimates%20in%20IUTeich.pdf")[#text("Click to access Explicit%20estimates%20in%20IUTeich.pdf")]

#text("What’s the thinking about that among the specialists? (especially about the bit on FLT). Google yielded surprisingly little.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-635692")[#strong[#text("254A, Supplement 4: Probabilistic models and heuristics for the primes (optional) | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 11 October 2021")])]

#text("[…] spheres of application; they are also broadly compatible with the general heuristic (discussed in this previous post) that in the absence of any exploitable structure, asymptotic statistics should default to the most […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a474a2954360efecb5ae4ffca9f1da1667332bba7d2fd0de36a34a646a7d1096-59a12bc0abd4a2eac43ac9b84015872da39a13aa6e84b9332c4d065c9c6148d8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luis Martinez")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-639426")[#strong[#text("Luis Martinez")]]#text(size: 9pt, fill: rgb("596477"), " · 15 January 2022")])]

#text("I inform you of what appears to be the solution of the constant ")#mi("K_{\\epsilon}")#text(" called the constant of proportionality for the abc conjecture. Once verified, we see that with the defined value the statement of the abc conjecture is always holds ")#mi("c < K_{epsilon} rad(abc)")#text(".")

#link("https://doi.org/10.9734/bpi/ctmcs/v2/9639D")[#text("https://doi.org/10.9734/bpi/ctmcs/v2/9639D")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc525f059cb2a1ce9430ea9a4a1be87dd8b09115e869e22264d3e53b879d4537-a4e563afd9f888a5c097806e8fad1027d1b4a3dbd87cb792389f19390c6d6841.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paulfchristiano")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-671167")[#strong[#text("paulfchristiano")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2022")])]

#text("You’ve described the probabilistic heuristic informally, but it seems plausible that there is a formal version. We’ve written an article fleshing out that hope, heavily citing this blog post: ")#link("https://arxiv.org/abs/2211.06738")[#text("https://arxiv.org/abs/2211.06738")]

#text("If you have time to take a look (or have reactions to the general idea) we’d be very interested in your thoughts.")

#text("We are looking for an efficient program E that takes as input a mathematical quantity X and a set of arguments, and then outputs a heuristic estimate E[X] based on those arguments. We don’t expect to define “no obvious reason to be correlated,” instead we just want to make an estimate based on whatever arguments we’ve noticed so far while remaining open to the possibility that our estimate will change later.")

#text("It’s hard to precisely define the desiderata for E, but we can evaluate a proposal by seeing how it behaves in concrete cases. For example, E should accept a suitable formalization of the three heuristic arguments given in this post, and should output the expected estimates for the truth of the conjectures and density of solutions. Moreover, those estimates should be pretty stable, even if an adversary is allowed to try to write down arbitrary spurious arguments and give them to E alongside the valid argument.")

#text("My personal sense is that this reasoning is systematic enough that it’s fairly likely to have a formalization. And if we did find a formalization, I think it would both be mathematically interesting and have potentially important applications in machine learning.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-671253")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2022")])]

#text("An interesting direction of inquiry! My guess is that one may have to weaken the desiderata stated in order to actually obtain a program E that resembles human heuristic argument. For instance, the rearrangement invariance/repetition seems highly rational, but actual heuristic reasoning is, I believe “non-commutative” in the sense that the order in which the arguments are presented makes a difference, and repeating an argument may end up increasing its “weight” in the final heuristic. It may end up being more natural to consider non-commutative heuristic models even if they seem irrational (and could be symmetrized by averaging over all permutations); in particular the “respect for proofs” axiom may hinge on where in the ordering the heuristic argument ")#mi("\\pi_*")#text(" appears in.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc525f059cb2a1ce9430ea9a4a1be87dd8b09115e869e22264d3e53b879d4537-a4e563afd9f888a5c097806e8fad1027d1b4a3dbd87cb792389f19390c6d6841.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of paulfchristiano")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-671369")[#strong[#text("paulfchristiano")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2023")])]

#text("Invariance to repetition (and respect for proofs no matter where the proof appears) do seem like very restrictive properties, but unfortunately I suspect they are needed for the ML application. Two reasons for why I’m tentatively optimistic about achieving this even though it’s very strong:")

#text("* We don’t yet have any examples of a pair of “incompatible” heuristic arguments where the final estimate depends on what order we consider the arguments or how we weigh them. In every case we’ve found so far, we can compute a combined estimate that incorporates the considerations raised by both arguments. The algorithms for this are not always trivial, e.g. see appendix A.2.3. If any readers can think of candidate examples where merging two arguments is hard (or fundamentally order-dependent) we are very interested in those.")

#text("* In cases like the ones in the OP, the heuristic estimates look stable—I suspect there’s a standard of argument validity such that there are no valid arguments that would change our estimate for the asymptotic density of twin primes (and such that if we *did* find a valid argument then it would represent real structure we’d overlooked that should call into question our current estimate for the twin prime density). That kind of stable equilibrium seems order-dependent, so I think there’s at least something order-independent to formalize.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-681904")[#strong[#text("If there is no reason for structure, assume there is none. – Vasek Rozhon's blog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 October 2023")]

#text("[…] conjecture: see the blog post of Terence […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-687837")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2025")])]

#text("How do you think the ABC conjecture affects prime numbers? For example, let c be the product of the first n primes. Either a or b will be missing some prime. If c continues to increase the exponent of each prime in some way. There seems to be a controllable range of epsilon values ​​during that increase.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-688610")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 16 August 2025")])]

#text("Litchman’s paper on ABC asks if rad(abc) can be bounded by c^0.99. Then the number of ABC exceptions will decrease in the power of c, for example from 0.99 to 0.95. In place of rad(xy) there will be no more 2/3.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24a6e77567973bd548a06ba46cbbc75c7d37eb3612738fc16de4f083c6b081b6-68d6eaf1abd5bf564f2d449a44e084ca517ef40d64e2a31a86d42bb61b675ad5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ducduc2710")]], [#link("https://terrytao.wordpress.com/2012/09/18/the-probabilistic-heuristic-justification-of-the-abc-conjecture/#comment-688725")[#strong[#text("ducduc2710")]]#text(size: 9pt, fill: rgb("596477"), " · 5 September 2025")])]

#text("Litchman’s 4-page method only improves when there exists a sufficiently good triple abc, e.g. rad(abc)<c^0.5, so is |Epsilon(N)|<=O(N^1/3)?")

#link("https://arxiv.org/pdf/2505.13991")[#text("https://arxiv.org/pdf/2505.13991")]
]
