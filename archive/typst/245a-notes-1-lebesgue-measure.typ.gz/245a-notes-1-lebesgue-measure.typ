// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/
// Converted to Typst by tao2typ: "2026-10-14T09:01:57.319302+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "245A, Notes 1: Lebesgue measure", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("245A, Notes 1: Lebesgue measure")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 September 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")[#text("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In the prologue for this course, we recalled the classical theory of ")#link("http://en.wikipedia.org/wiki/Jordan_measure")[#text("Jordan measure")]#text(" on Euclidean spaces ")#mi("{{\\bf R}^d}")#text(". This theory proceeded in the following stages:")

#enum(start: 1, 
[#text("First, one defined the notion of a box ")#mi("{B}")#text(" and its volume ")#tao-math("{\\left|B\\right|}", block: false)#text(".")],
[#text("Using this, one defined the notion of an elementary set ")#mi("{E}")#text(" (a finite union of boxes), and defines the elementary measure ")#mi("{m(E)}")#text(" of such sets.")],
[#text("From this, one defined the inner and outer Jordan measures ")#mi("{m_{*,(J)}(E), m^{*,(J)}(E)}")#text(" of an arbitrary bounded set ")#mi("{E \\subset {\\bf R}^d}")#text(". If those measures match, we say that ")#mi("{E}")#text(" is ")#emph[#text("Jordan measurable")]#text(", and call ")#mi("{m(E) = m_{*,(J)}(E) = m^{*,(J)}(E)}")#text(" the ")#emph[#text("Jordan measure")]#text(" of ")#mi("{E}")#text(".")]
)

#text("As long as one is lucky enough to only have to deal with Jordan measurable sets, the theory of Jordan measure works well enough. However, as noted previously, not all sets are Jordan measurable, even if one restricts attention to bounded sets. In fact, we shall see later in these notes that there even exist bounded open sets, or compact sets, which are not Jordan measurable, so the Jordan theory does not cover many classes of sets of interest. Another class that it fails to cover is countable unions or intersections of sets that are already known to be measurable:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 1")]#text(" Show that the countable union ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" or countable intersection ")#mi("{\\bigcap_{n=1}^\\infty E_n}")#text(" of Jordan measurable sets ")#mi("{E_1, E_2, \\ldots \\subset {\\bf R}}")#text(" need not be Jordan measurable, even when bounded.")
]

#text("This creates problems with ")#link("http://en.wikipedia.org/wiki/Riemann_integral")[#text("Riemann integrability")]#text(" (which, as we saw in the preceding notes, was closely related to Jordan measure) and pointwise limits:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 2")]#text(" Give an example of a sequence of uniformly bounded, Riemann integrable functions ")#mi("{f_n: [0,1] \\rightarrow {\\bf R}}")#text(" for ")#mi("{n=1,2,\\ldots}")#text(" that ")#link("http://en.wikipedia.org/wiki/Pointwise_convergence")[#text("converge pointwise")]#text(" to a bounded function ")#mi("{f: [0,1] \\rightarrow {\\bf R}}")#text(" that is ")#emph[#text("not")]#text(" Riemann integrable. What happens if we replace pointwise convergence with ")#link("http://en.wikipedia.org/wiki/Uniform_convergence")[#text("uniform convergence")]#text("?")
]

#text("These issues can be rectified by using a more powerful notion of measure than Jordan measure, namely ")#link("http://en.wikipedia.org/wiki/Lebesgue_measure")[#text("Lebesgue measure")]#text(". To define this measure, we first tinker with the notion of the Jordan outer measure")

#align(center)[#tao-fit-display[#mitex("m^{*,(J)}(E) := \\inf_{B \\supset E; B \\text{ elementary}} m(B)")]]

#text("of a set ")#mi("{E \\subset {\\bf R}^d}")#text(" (we adopt the convention that ")#mi("{m^{*,(J)}(E) = +\\infty}")#text(" if ")#mi("{E}")#text(" is unbounded, thus ")#mi("{m^{*,(J)}}")#text(" now takes values in the extended non-negative reals ")#mi("{[0,+\\infty]}")#text(", whose properties we will briefly review below). Observe from the finite additivity and subadditivity of elementary measure that we can also write the Jordan outer measure as")

#align(center)[#tao-fit-display[#tao-math("m^{*,(J)}(E) := \\inf_{B_1 \\cup \\ldots \\cup B_k \\supset E; B_1,\\ldots, B_k \\text{ boxes}} \\left|B_1\\right| + \\ldots + \\left|B_k\\right|,", block: true)]]

#text("i.e. the Jordan outer measure is the infimal cost required to cover ")#mi("{E}")#text(" by a finite union of boxes. (The natural number ")#mi("{k}")#text(" is allowed to vary freely in the above infimum.) We now modify this by replacing the finite union of boxes by a countable union of boxes, leading to the ")#emph[#text("Lebesgue outer measure")]#text(" ")#mi("{m^*(E)}")#text(" of ")#mi("{E}")#text(":")

#align(center)[#tao-fit-display[#tao-math("m^*(E) := \\inf_{\\bigcup_{n=1}^\\infty B_n \\supset E; B_1, B_2, \\ldots \\text{ boxes}} \\sum_{n=1}^\\infty \\left|B_n\\right|,", block: true)]]

#text("thus the Lebesgue outer measure is the infimal cost required to cover ")#mi("{E}")#text(" by a ")#emph[#text("countable")]#text(" union of boxes. Note that the countable sum ")#tao-math("{\\sum_{n=1}^\\infty \\left|B_n\\right|}", block: false)#text(" may be infinite, and so the Lebesgue outer measure ")#mi("{m^*(E)}")#text(" could well equal ")#mi("{+\\infty}")#text(".")

#text("(Caution: the Lebesgue outer measure ")#mi("{m^*(E)}")#text(" is sometimes denoted ")#mi("{m_*(E)}")#text("; this is for instance the case in Stein-Shakarchi.)")

#text("Clearly, we always have ")#mi("{m^*(E) \\leq m^{*,(J)}(E)}")#text(" (since we can always pad out a finite union of boxes into an infinite union by adding an infinite number of empty boxes). But ")#mi("{m^*(E)}")#text(" can be a lot smaller:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Example 1")]#text(" Let ")#mi("{E = \\{ x_1, x_2, x_3, \\ldots \\} \\subset {\\bf R}^d}")#text(" be a countable set. We know that the Jordan outer measure of ")#mi("{E}")#text(" can be quite large; for instance, in one dimension, ")#mi("{m^{*,(J)}({\\bf Q})}")#text(" is infinite, and ")#mi("{m^{*,(J)}({\\bf Q} \\cap [-R,R]) = m^{*,(J)}([-R,R]) = 2R}")#text(" since ")#mi("{{\\bf Q} \\cap [-R,R]}")#text(" has ")#mi("{[-R,R]}")#text(" as its closure (see Exercise 18 of the ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("prologue")]#text("). On the other hand, all countable sets ")#mi("{E}")#text(" have Lebesgue outer measure zero. Indeed, one simply covers ")#mi("{E}")#text(" by the degenerate boxes ")#mi("{\\{x_1\\}, \\{x_2\\}, \\ldots}")#text(" of sidelength and volume zero.")

#text("Alternatively, if one does not like degenerate boxes, one can cover each ")#mi("{x_n}")#text(" by a cube ")#mi("{B_n}")#text(" of sidelength ")#mi("{\\epsilon/2^n}")#text(" (say) for some arbitrary ")#mi("{\\epsilon > 0}")#text(", leading to a total cost of ")#mi("{\\sum_{n=1}^\\infty (\\epsilon/2^n)^d}")#text(", which converges to ")#mi("{C_d \\epsilon^d}")#text(" for some absolute constant ")#mi("{C_d}")#text(". As ")#mi("{\\epsilon}")#text(" can be arbitrarily small, we see that the Lebesgue outer measure must be zero. We will refer to this type of trick as the ")#emph[#mi("{\\epsilon/2^n}")#text(" trick")]#text("; it will be used many further times in this course.")

#text("From this example we see in particular that a set may be unbounded while still having Lebesgue outer measure zero, in contrast to Jordan outer measure.")
]

#text("As we shall see later in this course, Lebesgue outer measure (also known as ")#emph[#text("Lebesgue exterior measure")]#text(") is a special case of a more general concept known as an ")#link("http://en.wikipedia.org/wiki/Outer_measure")[#text("outer measure")]#text(".")

#text("In analogy with the Jordan theory, we would also like to define a concept of “Lebesgue inner measure” to complement that of outer measure. Here, there is an asymmetry (which ultimately arises from the fact that elementary measure is subadditive rather than superadditive): one does not gain any increase in power in the Jordan inner measure by replacing finite unions of boxes with countable ones. But one can get a sort of Lebesgue inner measure by taking complements; see Exercise ")#link(<tao-c81cc8d3d2da2311b4a6>)[#text("18")]#text(". This leads to one possible definition for Lebesgue measurability, namely the ")#emph[#text("Carathéodory criterion")]#text(" for Lebesgue measurability, see Exercise ")#link(<tao-1fc5a1c310dedb062457>)[#text("17")]#text(". However, this is not the most intuitive formulation of this concept to work with, and we will instead use a different (but logically equivalent) definition of Lebesgue measurability. The starting point is the observation (see Exercise 5 of the ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("prologue")]#text(") that Jordan measurable sets can be efficiently contained in elementary sets, with an error that has small Jordan outer measure. In a similar vein, we will define Lebesgue measurable sets to be sets that can be efficiently contained in ")#emph[#text("open")]#text(" sets, with an error that has small ")#emph[#text("Lebesgue")]#text(" outer measure:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Lebesgue measurability)")]#text(" ")#metadata(none) <tao-108d621bf2580754dd59>#text(" A set ")#mi("{E \\subset {\\bf R}^d}")#text(" is said to be ")#emph[#text("Lebesgue measurable")]#text(" if, for every ")#mi("{\\epsilon > 0}")#text(", there exists an open set ")#mi("{U \\subset {\\bf R}^d}")#text(" containing ")#mi("{E}")#text(" such that ")#mi("{m^*(U \\backslash E) \\leq \\epsilon}")#text(". If ")#mi("{E}")#text(" is Lebesgue measurable, we refer to ")#mi("{m(E) := m^*(E)}")#text(" as the ")#emph[#text("Lebesgue measure")]#text(" of ")#mi("{E}")#text(" (note that this quantity may be equal to ")#mi("{+\\infty}")#text("). We also write ")#mi("{m(E)}")#text(" as ")#mi("{m^d(E)}")#text(" when we wish to emphasise the dimension ")#mi("{d}")#text(".")
]

#text("(The intuition that measurable sets are almost open is also known as ")#link("http://en.wikipedia.org/wiki/Littlewood's_three_principles_of_real_analysis")[#text("Littlewood’s first principle")]#text(", this principle is a triviality with our current choice of definitions, though less so if one uses other, equivalent, definitions of Lebesgue measurability.)")

#text("As we shall see later, Lebesgue measure extends Jordan measure, in the sense that every Jordan measurable set is Lebesgue measurable, and the Lebesgue measure and Jordan measure of a Jordan measurable set are always equal. We will also see a few other equivalent descriptions of the concept of Lebesgue measurability.")

#text("In the notes below we will establish the basic properties of Lebesgue measure. Broadly speaking, this concept obeys all the intuitive properties one would ask of measure, so long as one restricts attention to countable operations rather than uncountable ones, and as long as one restricts attention to Lebesgue measurable sets. The latter is not a serious restriction in practice, as almost every set one actually encounters in analysis will be measurable (the main exceptions being some pathological sets that are constructed using the axiom of choice). In the next set of notes we will use Lebesgue measure to set up the Lebesgue integral, which extends the Riemann integral in the same way that Lebesgue measure extends Jordan measure; and the many pleasant properties of Lebesgue measure will be reflected in analogous pleasant properties of the Lebesgue integral (most notably the convergence theorems).")

#text("We will treat all dimensions ")#mi("{d=1,2,\\ldots}")#text(" equally here, but for the purposes of drawing pictures, we recommend to the reader that one sets ")#mi("{d}")#text(" equal to ")#mi("{2}")#text(". However, for this topic at least, no additional mathematical difficulties will be encountered in the higher-dimensional case (though of course there are significant ")#emph[#text("visual")]#text(" difficulties once ")#mi("{d}")#text(" exceeds ")#mi("{3}")#text(").")

#text("The material here is based on Sections 1.1-1.3 of the Stein-Shakarchi text, though it is arranged somewhat differently.")

#metadata(none) <tao-3418a633020d6282ca18>

#heading(level: 1)[#strong[#text(" — 1. Two preliminaries: the extended non-negative real axis, and the axiom of choice — ")]]

#text("Before we start the main subject of discussion, let us review two basic mathematical tools that we will be using throughout the course: the extended non-negative real axis ")#mi("{[0,+\\infty]}")#text(" and the axiom of choice.")

#text("The extended non-negative real axis ")#mi("{[0,+\\infty]}")#text(" is the non-negative real axis ")#mi("{[0,+\\infty) := \\{ x\\in {\\bf R}: x \\geq 0 \\}}")#text(" with an additional element adjoined to it, which we label ")#mi("{+\\infty}")#text("; we will need to work with this system because many sets (e.g. ")#mi("{{\\bf R}^d}")#text(") will have infinite measure. Of course, ")#mi("{+\\infty}")#text(" is not a real number, but we think of it as an ")#emph[#text("extended")]#text(" real number. We extend the addition, multiplication, and order structures on ")#mi("{[0,+\\infty)}")#text(" to ")#mi("{[0,+\\infty]}")#text(" by declaring")

#align(center)[#tao-fit-display[#mitex("+\\infty + x = x + +\\infty = +\\infty")]]

#text("for all ")#mi("{x \\in [0,+\\infty]}")#text(",")

#align(center)[#tao-fit-display[#mitex("+\\infty \\cdot x = x \\cdot +\\infty = +\\infty")]]

#text("for all non-zero ")#mi("{x \\in (0,+\\infty]}")#text(",")

#align(center)[#tao-fit-display[#mitex("+\\infty \\cdot 0 = 0 \\cdot +\\infty = 0,")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x < +\\infty \\text{ for all } x \\in [0,+\\infty).")]]

#text("Most of the laws of algebra for addition, multiplication, and order continue to hold in this extended number system; for instance addition and multiplication are commutative and associative, with the latter distributing over the former, and an order relation ")#mi("{x \\leq y}")#text(" is preserved under addition or multiplication of both sides of that relation by the same quantity. However, we caution that the laws of cancellation do ")#emph[#text("not")]#text(" apply once some of the variables are allowed to be infinite; for instance, we cannot deduce ")#mi("{x=y}")#text(" from ")#mi("{+\\infty+x=+\\infty+y}")#text(" or from ")#mi("{+\\infty \\cdot x = +\\infty \\cdot y}")#text(". This is related to the fact that the forms ")#mi("{+\\infty - +\\infty}")#text(" and ")#mi("{+\\infty/+\\infty}")#text(" are indeterminate (one cannot assign a value to them without breaking a lot of the rules of algebra). A general rule of thumb is that if one wishes to use cancellation (or proxies for cancellation, such as subtraction or division), this is only safe if one can guarantee that all quantities involved are finite (and in the case of multiplicative cancellation, the quantity being cancelled also needs to be non-zero, of course). However, as long as one avoids using cancellation and works exclusively with non-negative quantities, there is little danger in working in the extended real number system.")

#text("We note also that once one adopts the convention ")#mi("{+\\infty \\cdot 0 = 0 \\cdot +\\infty = 0}")#text(", then multiplication becomes ")#emph[#text("upward continuous")]#text(" (in the sense that whenever ")#mi("{x_n \\in [0,+\\infty]}")#text(" increases to ")#mi("{x \\in [0,+\\infty]}")#text(", and ")#mi("{y_n \\in [0,+\\infty]}")#text(" increases to ")#mi("{y \\in [0,+\\infty]}")#text(", then ")#mi("{x_n y_n}")#text(" increases to ")#mi("{xy}")#text(") but not ")#emph[#text("downward continuous")]#text(" (e.g. ")#mi("{1/n \\rightarrow 0}")#text(" but ")#mi("{1/n \\cdot +\\infty \\not \\rightarrow 0 \\cdot +\\infty}")#text("). This asymmetry will ultimately cause us to define integration from below rather than from above, which leads to other asymmetries (e.g. the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(" applies for monotone increasing functions, but not necessarily for monotone decreasing ones).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" Note that there is a tradeoff here: if one wants to keep as many useful laws of algebra as one can, then one can add in infinity, or have negative numbers, but it is difficult to have both at the same time. Because of this tradeoff, we will see two overlapping types of measure and integration theory: the ")#emph[#text("non-negative")]#text(" theory, which involves quantities taking values in ")#mi("{[0,+\\infty]}")#text(", and the ")#emph[#text("absolutely integrable")]#text(" theory, which involves quantities taking values in ")#mi("{(-\\infty,+\\infty)}")#text(" or ")#mi("{{\\bf C}}")#text(". For instance, the fundamental convergence theorem for the former theory is the ")#link("http://en.wikipedia.org/wiki/Monotone_convergence_theorem")[#text("monotone convergence theorem")]#text(", while the fundamental convergence theorem for the latter is the ")#link("http://en.wikipedia.org/wiki/Dominated_convergence_theorem")[#text("dominated convergence theorem")]#text(". Both branches of the theory are important, and both will be covered in later notes.")
]

#text("One important feature of the extended nonnegative real axis is that all sums are convergent: given any sequence ")#mi("{x_1, x_2, \\ldots \\in [0,+\\infty]}")#text(", we can always form the sum")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty x_n \\in [0,+\\infty]")]]

#text("as the limit of the partial sums ")#mi("{\\sum_{n=1}^N x_n}")#text(", which may be either finite or infinite. An equivalent definition of this infinite sum is as the supremum of all finite subsums:")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty x_n = \\sup_{F \\subset {\\bf N}, F \\text{ finite}} \\sum_{n \\in F} x_n.")]]

#text("Motivated by this, given any collection ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" of numbers ")#mi("{x_\\alpha \\in [0,+\\infty]}")#text(" indexed by an arbitrary set ")#mi("{A}")#text(" (finite or infinite, countable or uncountable), we can define the sum ")#mi("{\\sum_{\\alpha \\in A} x_\\alpha}")#text(" by the formula ")#metadata(none) <tao-37a0025aa1f2e29f9f88>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("\\sum_{\\alpha \\in A} x_\\alpha = \\sup_{F \\subset A, F \\text{ finite}} \\sum_{\\alpha \\in F} x_\\alpha.")]]

#text("Note from this definition that one can relabel the collection in an arbitrary fashion without affecting the sum; more precisely, given any bijection ")#mi("{\\phi: B \\rightarrow A}")#text(", one has the change of variables formula ")#metadata(none) <tao-b5836afbcf79c53e3956>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\sum_{\\alpha \\in A} x_\\alpha = \\sum_{\\beta\\in B} x_{\\phi(\\beta)}.")]]

#text("Note that when dealing with signed sums, the above rearrangement identity can fail when the series is not absolutely convergent (cf. the ")#link("http://en.wikipedia.org/wiki/Riemann_series_theorem")[#text("Riemann rearrangement theorem")]#text(").")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 3")]#text(" If ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" is a collection of numbers ")#mi("{x_\\alpha \\in [0,+\\infty]}")#text(" such that ")#mi("{\\sum_{\\alpha \\in A} x_\\alpha < \\infty}")#text(", show that ")#mi("{x_\\alpha = 0}")#text(" for all but at most countably many ")#mi("{\\alpha \\in A}")#text(", even if ")#mi("{A}")#text(" itself is uncountable.")
]

#text("We will rely frequently on the following basic fact (a special case of the ")#link("http://en.wikipedia.org/wiki/Fubini's_theorem")[#text("Fubini-Tonelli theorem")]#text(", which we will encounter later in this course):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 2 (Tonelli’s theorem for series)")]#text(" ")#metadata(none) <tao-907ad71982803d7c1d4f>#text(" Let ")#mi("{(x_{n,m})_{n,m \\in {\\bf N}}}")#text(" be a doubly infinite sequence of extended non-negative reals ")#mi("{x_{n,m} \\in [0,+\\infty]}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("\\sum_{(n,m) \\in {\\bf N}^2} x_{n,m} = \\sum_{n=1}^\\infty \\sum_{m=1}^\\infty x_{n,m} = \\sum_{m=1}^\\infty \\sum_{n=1}^\\infty x_{n,m}.")]]
]

#text("Informally, Tonelli’s theorem asserts that we may rearrange infinite series with impunity as long as all summands are non-negative.")

#emph[#text("Proof:")]#text(" We shall just show the equality of the first and second expressions; the equality of the first and third is proven similarly.")

#text("We first show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{(n,m) \\in {\\bf N}^2} x_{n,m} \\leq \\sum_{n=1}^\\infty \\sum_{m=1}^\\infty x_{n,m}.")]]

#text("Let ")#mi("{F}")#text(" be any finite subset of ")#mi("{{\\bf N}^2}")#text(". Then ")#mi("{F \\subset \\{1,\\ldots,N\\} \\times \\{1,\\ldots,N\\}}")#text(" for some finite ")#mi("{N}")#text(", and thus (by the non-negativity of the ")#mi("{x_{n,m}}")#text(")")

#align(center)[#tao-fit-display[#mitex("\\sum_{(n,m) \\in F} x_{n,m} \\leq \\sum_{(n,m) \\in \\{1,\\ldots,N\\} \\times \\{1,\\ldots,N\\}} x_{n,m}.")]]

#text("The right-hand side can be rearranged as")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\sum_{m=1}^N x_{n,m},")]]

#text("which is clearly at most ")#mi("{\\sum_{n=1}^\\infty \\sum_{m=1}^\\infty x_{n,m}}")#text(" (again by non-negativity of ")#mi("{x_{n,m}}")#text("). This gives")

#align(center)[#tao-fit-display[#mitex("\\sum_{(n,m) \\in F} x_{n,m} \\leq \\sum_{n=1}^\\infty \\sum_{m=1}^\\infty x_{n,m}.")]]

#text("for any finite subset ")#mi("{F}")#text(" of ")#mi("{{\\bf N}^2}")#text(", and the claim then follows from ")#link(<tao-37a0025aa1f2e29f9f88>)[#text("(1)")]#text(".")

#text("It remains to show the reverse inequality")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty \\sum_{m=1}^\\infty x_{n,m} \\leq \\sum_{(n,m) \\in {\\bf N}^2} x_{n,m}.")]]

#text("It suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\sum_{m=1}^\\infty x_{n,m} \\leq \\sum_{(n,m) \\in {\\bf N}^2} x_{n,m}")]]

#text("for each finite ")#mi("{N}")#text(".")

#text("Fix ")#mi("{N}")#text(". As each ")#mi("{\\sum_{m=1}^\\infty x_{n,m}}")#text(" is the limit of ")#mi("{\\sum_{m=1}^M x_{n,m}}")#text(", the left-hand side is the limit of ")#mi("{\\sum_{n=1}^N \\sum_{m=1}^M x_{n,m}}")#text(" as ")#mi("{M \\rightarrow \\infty}")#text(". Thus it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^N \\sum_{m=1}^M x_{n,m} \\leq \\sum_{(n,m) \\in {\\bf N}^2} x_{n,m}")]]

#text("for each finite ")#mi("{M}")#text(". But the left-hand side is ")#mi("{\\sum_{(n,m) \\in \\{1,\\ldots,N\\} \\times \\{1,\\ldots,M\\}} x_{n,m}}")#text(", and the claim follows. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" Note how important it was that the ")#mi("{x_{n,m}}")#text(" were non-negative in the above argument. In the signed case, one needs an additional assumption of absolute summability of ")#mi("{x_{n,m}}")#text(" on ")#mi("{{\\bf N}^2}")#text(" before one is permitted to interchange sums; this is ")#emph[#text("Fubini’s theorem for series")]#text(", which we will encounter later in this course. Without absolute summability or non-negativity hypotheses, the theorem can fail (consider for instance the case when ")#mi("{x_{n,m}}")#text(" equals ")#mi("{+1}")#text(" when ")#mi("{n=m}")#text(", ")#mi("{-1}")#text(" when ")#mi("{n=m+1}")#text(", and ")#mi("{0}")#text(" otherwise).")
]

#text("Next, we recall the ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice")[#text("axiom of choice")]#text(", which we shall be assuming throughout the course:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Axiom 3 (Axiom of choice)")]#text(" Let ")#mi("{(E_\\alpha)_{\\alpha \\in A}}")#text(" be a family of non-empty sets ")#mi("{E_\\alpha}")#text(", indexed by an index set ")#mi("{A}")#text(". Then we can find a family ")#mi("{(x_\\alpha)_{\\alpha \\in A}}")#text(" of elements ")#mi("{x_\\alpha}")#text(" of ")#mi("{E_\\alpha}")#text(", indexed by the same set ")#mi("{A}")#text(".")
]

#text("This axiom is trivial when ")#mi("{A}")#text(" is a singleton set, and from mathematical induction one can also prove it without difficulty when ")#mi("{A}")#text(" is finite. However, when ")#mi("{A}")#text(" is infinite, one cannot deduce this axiom from the other axioms of set theory, but must explicitly add it to the list of axioms. We isolate the countable case as a particularly useful corollary (though one which is strictly weaker than the full axiom of choice):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 4 (Axiom of countable choice)")]#text(" ")#metadata(none) <tao-e2ed6d1f66d38483e6c7>#text(" Let ")#mi("{E_1, E_2, E_3, \\ldots}")#text(" be a sequence of non-empty sets. Then one can find a sequence ")#mi("{x_1, x_2, \\ldots}")#text(" such that ")#mi("{x_n \\in E_n}")#text(" for all ")#mi("{n=1,2,3,\\ldots}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 3")]#text(" The question of how much of real analysis still survives when one is not permitted to use the axiom of choice is a delicate one, involving a fair amount of logic and descriptive set theory to answer. We will not discuss these matters in this course. We will however note a ")#link("http://en.wikipedia.org/wiki/Axiom_of_choice#Independence")[#text("theorem of Gödel")]#text(" that states that any statement that can be phrased in the first-order language of ")#link("http://en.wikipedia.org/wiki/Peano_arithmetic")[#text("Peano arithmetic")]#text(", and which is proven with the axiom of choice, can also be proven without the axiom of choice. So, roughly speaking, Gödel’s theorem tells us that for any “finitary” application of real analysis (which includes most of the “practical” applications of the subject), it is safe to use the axiom of choice; it is only when asking questions about “infinitary” objects that are beyond the scope of Peano arithmetic that one can encounter statements that are provable using the axiom of choice, but are not provable without it.")
]

#heading(level: 1)[#strong[#text(" — 2. Properties of Lebesgue outer measure — ")]]

#text("We begin by studying the Lebesgue outer measure ")#mi("{m^*}")#text(", which was defined earlier, and takes values in the extended non-negative real axis ")#mi("{[0,+\\infty]}")#text(". We first record three easy properties of Lebesgue outer measure, which we will use repeatedly in the sequel without further comment:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 4 (The outer measure axioms)")]#text(" ")#metadata(none) <tao-2e37c8a01fb4b41fc028>

#list(
[#text("(Empty set) ")#mi("{m^*(\\emptyset) = 0}")#text(".")],
[#text("(Monotonicity) If ")#mi("{E \\subset F \\subset {\\bf R}^d}")#text(", then ")#mi("{m^*(E) \\leq m^*(F)}")#text(".")],
[#text("(Countable subadditivity) If ")#mi("{E_1, E_2, \\ldots \\subset {\\bf R}^d}")#text(" is a countable sequence of sets, then ")#mi("{m^*( \\bigcup_{n=1}^\\infty E_n ) \\leq \\sum_{n=1}^\\infty m^*(E_n)}")#text(". (")#emph[#text("Hint:")]#text(" Use the axiom of countable choice, Tonelli’s theorem for series, and the ")#mi("{\\epsilon/2^n}")#text(" trick used previously to show that countable sets had outer measure zero.)")]
)
]

#text("Note that countable subadditivity, when combined with the empty set axiom, gives as a corollary the finite subadditivity property")

#align(center)[#tao-fit-display[#mitex("m^*( E_1 \\cup \\ldots \\cup E_k ) \\leq m^*(E_1) + \\ldots + m^*(E_k)")]]

#text("for any ")#mi("{k \\ge 0}")#text(". These subadditivity properties will be useful in establishing ")#emph[#text("upper")]#text(" bounds on Lebesgue outer measure. Establishing ")#emph[#text("lower")]#text(" bounds will often be a bit trickier. (More generally, when dealing with a quantity that is defined using an infimum, it is usually easier to obtain upper bounds on that quantity than lower bounds, because the former requires one to bound just one element of the infimum, whereas the latter requires one to bound ")#emph[#text("all")]#text(" elements.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 4")]#text(" Later on in this course, when we study abstract measure theory on a general set ")#mi("{X}")#text(", we will define the concept of an ")#emph[#text("outer measure")]#text(" on ")#mi("{X}")#text(", which is an assigment ")#mi("{E \\mapsto m^*(E)}")#text(" of element of ")#mi("{[0,+\\infty]}")#text(" to arbitrary subsets ")#mi("{E}")#text(" of a space ")#mi("{X}")#text(" that obeys the above three axioms of the empty set, monotonicity, and countable subadditivity; thus Lebesgue outer measure is a model example of an abstract outer measure. On the other hand (and somewhat confusingly), Jordan outer measure will not be an abstract outer measure (even after adopting the convention that unbounded sets have Jordan outer measure ")#mi("{+\\infty}")#text("): it obeys the empty set and monotonicity axioms, but is only finitely subadditive rather than countably subadditive. (For instance, the rationals ")#mi("{{\\bf Q}}")#text(" have infinite Jordan outer measure, despite being the countable union of points, each of which have a Jordan outer measure of zero.) Thus we already see a major benefit of allowing countable unions of boxes in the definition of Lebesgue outer measure, in contrast to the finite unions of boxes in the definition of Jordan outer measure, in that finite subadditivity is upgraded to countable subadditivity.")
]

#text("Of course, one cannot hope to upgrade countable subadditivity to uncountable subadditivity: ")#mi("{{\\bf R}^d}")#text(" is an uncountable union of points, each of which has Lebesgue outer measure zero, but (as we shall shortly see), ")#mi("{{\\bf R}^d}")#text(" has infinite Lebesgue outer measure.")

#text("It is natural to ask whether Lebesgue outer measure has the finite additivity property, that is to say that ")#mi("{m^{*}(E \\cup F) = m^{*}(E) + m^{*}(F)}")#text(" whenever ")#mi("{E, F \\subset {\\bf R}^d}")#text(" are disjoint. The answer to this question is somewhat subtle: as we shall see later, we have finite additivity (and even countable additivity) when all sets involved are Lebesgue measurable, but that finite additivity (and hence also countable additivity) can break down in the non-measurable case. The difficulty here (which, incidentally, also appears in the theory of Jordan outer measure) is that if ")#mi("{E}")#text(" and ")#mi("{F}")#text(" are sufficiently “entangled” with each other, it is not always possible to take a countable cover of ")#mi("{E \\cup F}")#text(" by boxes and split the total volume of that cover into separate covers of ")#mi("{E}")#text(" and ")#mi("{F}")#text(" without some duplication. However, we can at least recover finite additivity if the sets ")#mi("{E, F}")#text(" are separated by some positive distance:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Finite additivity for separated sets)")]#text(" ")#metadata(none) <tao-2a8111ae3d7177778101>#text(" Let ")#mi("{E, F\\subset {\\bf R}^d}")#text(" be such that ")#mi("{\\text{dist}(E,F) > 0}")#text(", where")

#align(center)[#tao-fit-display[#tao-math("\\text{dist}(E,F) := \\inf \\{ \\left|x-y\\right|: x \\in E, y \\in F \\}", block: true)]]

#text("is the distance between ")#mi("{E}")#text(" and ")#mi("{F}")#text(". (Here and in the sequel we use the usual Euclidean metric ")#tao-math("{\\left|(x_1,\\ldots,x_d)\\right| := \\sqrt{x_1^2+\\ldots+x_d^2}}", block: false)#text(" on ")#mi("{{\\bf R}^d}")#text(".) Then ")#mi("{m^*(E \\cup F) = m^*(E)+m^*(F)}")#text(".")
]

#emph[#text("Proof:")]#text(" From subadditivity one has ")#mi("{m^*(E \\cup F) \\leq m^*(E)+m^*(F)}")#text(", so it suffices to prove the other direction ")#mi("{m^*(E)+m^*(F) \\leq m^*(E \\cup F)}")#text(". This is trivial if ")#mi("{E \\cup F}")#text(" has infinite Lebesgue outer measure, so we may assume that it has finite Lebesgue outer measure (and then the same is true for ")#mi("{E}")#text(" and ")#mi("{F}")#text(", by monotonicity).")

#text("We use the standard “")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("give yourself an epsilon of room")]#text("” trick. Let ")#mi("{\\epsilon > 0}")#text(". By definition of Lebesgue outer measure, we can cover ")#mi("{E \\cup F}")#text(" by a countable family ")#mi("{B_1, B_2, \\ldots}")#text(" of boxes such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^\\infty \\left|B_n\\right| \\leq m^*(E \\cup F) + \\epsilon.", block: true)]]

#text("Suppose it was the case that each box intersected at most one of ")#mi("{E}")#text(" and ")#mi("{F}")#text(". Then we could divide this family into two subfamilies ")#mi("{B^{\\prime}_1, B^{\\prime}_2, \\ldots}")#text(" and ")#mi("{B^{\\prime\\prime}_1,B^{\\prime\\prime}_2, B^{\\prime\\prime}_3, \\ldots}")#text(", the first of which covered ")#mi("{E}")#text(", and the second of which covered ")#mi("{F}")#text(". From definition of Lebesgue outer measure, we have")

#align(center)[#tao-fit-display[#tao-math("m^*(E) \\leq \\sum_{n=1}^\\infty \\left|B^{\\prime}_n\\right|", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("m^*(F) \\leq \\sum_{n=1}^\\infty \\left|B^{\\prime\\prime}_n\\right|;", block: true)]]

#text("summing, we obtain")

#align(center)[#tao-fit-display[#tao-math("m^*(E) + m^*(F) \\leq \\sum_{n=1}^\\infty \\left|B_n\\right|", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("m^*(E) + m^*(F) \\leq m^*(E \\cup F) + \\epsilon.")]]

#text("Since ")#mi("{\\epsilon}")#text(" was arbitrary, this gives ")#mi("{m^*(E) + m^*(F) \\leq m^*(E \\cup F)}")#text(" as required.")

#text("Of course, it is quite possible for some of the boxes ")#mi("{B_n}")#text(" to intersect both ")#mi("{E}")#text(" and ")#mi("{F}")#text(", particularly if the boxes are big, in which case the above argument does not work because that box would be double-counted. However, observe that given any ")#mi("{r > 0}")#text(", one can always partition a large box ")#mi("{B_n}")#text(" into a finite number of smaller boxes, each of which has ")#link("http://en.wikipedia.org/wiki/Diameter")[#text("diameter")]#text(" at most ")#mi("{r}")#text(", with the total volume of these sub-boxes equal to the volume of the original box. Applying this observation to each of the boxes ")#mi("{B_n}")#text(", we see that given any ")#mi("{r>0}")#text(", we may assume without loss of generality that the boxes ")#mi("{B_1, B_2, \\ldots}")#text(" covering ")#mi("{E \\cup F}")#text(" have diameter at most ")#mi("{r}")#text(". In particular, we may assume that all such boxes have diameter strictly less than ")#mi("{\\text{dist}(E, F)}")#text(". Once we do this, then it is no longer possible for any box to intersect both ")#mi("{E}")#text(" and ")#mi("{F}")#text(", and then the previous argument now applies. ")#mi("\\Box")

#text("In general, disjoint sets ")#mi("{E, F}")#text(" need not have a positive separation from each other (e.g. ")#mi("{E = [0,1)}")#text(" and ")#mi("{F = [1,2]}")#text("). But the situation improves when ")#mi("{E, F}")#text(" are closed, and at least one of ")#mi("{E, F}")#text(" is compact:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 5")]#text(" ")#metadata(none) <tao-897ce337f513a1ed0166>#text(" Let ")#mi("{E, F \\subset {\\bf R}^d}")#text(" be disjoint closed sets, with at least one of ")#mi("{E, F}")#text(" being compact. Show that ")#mi("{\\text{dist}(E,F) > 0}")#text(". Give a counterexample to show that this claim fails when the compactness hypothesis is dropped.")
]

#text("We already know that countable sets have Lebesgue outer measure zero. Now we start computing the outer measure of some other sets. We begin with elementary sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Outer measure of elementary sets)")]#text(" ")#metadata(none) <tao-7f1b55b860590406f84f>#text(" Let ")#mi("{E}")#text(" be an elementary set. Then the Lebesgue outer measure ")#mi("{m^*(E)}")#text(" of ")#mi("{E}")#text(" is equal to the elementary measure ")#mi("{m(E)}")#text(" of ")#mi("{E}")#text(": ")#mi("{m^*(E) = m(E)}")#text(".")
]

#text("Since countable sets have zero outer measure, we note that we have managed to give a proof of ")#link("http://en.wikipedia.org/wiki/Cantor's_theorem")[#text("Cantor’s theorem")]#text(" that ")#mi("{{\\bf R}^d}")#text(" is uncountable. Of course, much quicker proofs of this theorem are available. However, this observation shows that the proof this lemma must somehow use some crucial fact about the real line which is not true for countable subfields of ")#mi("{{\\bf R}}")#text(", such as the rationals ")#mi("{{\\bf Q}}")#text(". In the proof we give here, the key fact about the real line we use is the Heine-Borel theorem, which ultimately exploits the important fact that the reals are ")#emph[#text("complete")]#text(". In the one-dimensional case ")#mi("{d=1}")#text(", it is also possible to exploit the fact that the reals are ")#emph[#text("connected")]#text(" as a substitute for completeness (note that proper subfields of the reals are neither connected nor complete).")

#emph[#text("Proof:")]#text(" We already know that ")#mi("{m^*(E) \\leq m^{*,(J)}(E) = m(E)}")#text(", so it suffices to show that ")#mi("{m(E) \\leq m^*(E)}")#text(".")

#text("We first establish this in the case when the elementary set ")#mi("{E}")#text(" is closed. As the elementary set ")#mi("{E}")#text(" is also bounded, this allows us to use the powerful ")#link("http://en.wikipedia.org/wiki/Heine%E2%80%93Borel_theorem")[#text("Heine-Borel theorem")]#text(", which asserts that every open cover of ")#mi("{E}")#text(" has a finite subcover (or in other words, ")#mi("{E}")#text(" is ")#link("http://en.wikipedia.org/wiki/Compact_space")[#text("compact")]#text(").")

#text("We again use the epsilon of room strategy. Let ")#mi("{\\epsilon > 0}")#text(" be arbitrary, then we can find a countable family ")#mi("{B_1, B_2, \\ldots}")#text(" of boxes that cover ")#mi("{E}")#text(",")

#align(center)[#tao-fit-display[#mitex("E \\subset \\bigcup_{n=1}^\\infty B_n,")]]

#text("and such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^\\infty \\left|B_n\\right| \\leq m^*(E) + \\epsilon.", block: true)]]

#text("We would like to use the Heine-Borel theorem, but the boxes ")#mi("{B_n}")#text(" need not be open. But this is not a serious problem, as one can spend another epsilon to enlarge the boxes to be open. More precisely, for each box ")#mi("{B_n}")#text(" one can find an open box ")#mi("{B^{\\prime}_n}")#text(" containing ")#mi("{B_n}")#text(" such that ")#tao-math("{\\left|B^{\\prime}_n\\right| \\leq \\left|B_n\\right|+\\epsilon/2^n}", block: false)#text(" (say). The ")#mi("{B^{\\prime}_n}")#text(" still cover ")#mi("{E}")#text(", and we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^\\infty \\left|B^{\\prime}_n\\right| \\leq \\sum_{n=1}^\\infty (\\left|B_n\\right| + \\epsilon/2^n) = (\\sum_{n=1}^\\infty \\left|B_n\\right|) + \\epsilon \\leq m^*(E) + 2\\epsilon.", block: true)]]

#text("As the ")#mi("{B^{\\prime}_n}")#text(" are open, we may apply the Heine-Borel theorem and conclude that")

#align(center)[#tao-fit-display[#mitex("E \\subset \\bigcup_{n=1}^N B^{\\prime}_n")]]

#text("for some finite ")#mi("{N}")#text(". Using the finite subadditivity of elementary measure, we conclude that")

#align(center)[#tao-fit-display[#tao-math("m(E) \\leq \\sum_{n=1}^N \\left|B^{\\prime}_n\\right|", block: true)]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("m(E) \\leq m^*(E) + 2\\epsilon.")]]

#text("Since ")#mi("{\\epsilon > 0}")#text(" was arbitrary, the claim follows.")

#text("Now we consider the case when the elementary ")#mi("{E}")#text(" is not closed. Then we can write ")#mi("{E}")#text(" as the finite union ")#mi("{Q_1 \\cup \\ldots \\cup Q_k}")#text(" of disjoint boxes, which need not be closed. But, similarly to before, we can use the epsilon of room strategy: for every ")#mi("{\\epsilon > 0}")#text(" and every ")#mi("{1 \\leq j \\leq k}")#text(", one can find a closed sub-box ")#mi("{Q^{\\prime}_j}")#text(" of ")#mi("{Q_j}")#text(" such that ")#tao-math("{\\left|Q^{\\prime}_j\\right| \\geq \\left|Q_j\\right| - \\epsilon/k}", block: false)#text(" (say); then ")#mi("{E}")#text(" contains the finite union of ")#mi("{Q^{\\prime}_1 \\cup \\ldots \\cup Q^{\\prime}_k}")#text(" disjoint ")#emph[#text("closed")]#text(" boxes, which is a closed elementary set. By the previous discussion and the finite additivity of elementary measure, we have")

#tao-aligned(keep: true)[


#tao-math("m^*( Q^{\\prime}_1 \\cup \\ldots \\cup Q^{\\prime}_k )  & = m(Q^{\\prime}_1 \\cup \\ldots \\cup Q^{\\prime}_k )", block: true)



#tao-math(" & = m(Q^{\\prime}_1) + \\ldots + m(Q^{\\prime}_k)", block: true)



#tao-math(" & \\geq m(Q_1) + \\ldots + m(Q_k) - \\epsilon", block: true)



#tao-math(" & = m(E) - \\epsilon.", block: true)
]

#text("Applying by monotonicity of Lebesgue outer measure, we conclude that")

#align(center)[#tao-fit-display[#mitex("m^*(E) \\geq m(E) - \\epsilon")]]

#text("for every ")#mi("{\\epsilon > 0}")#text(". Since ")#mi("{\\epsilon > 0}")#text(" was arbitrary, the claim follows. ")#mi("\\Box")

#text("The above lemma allows us to compute the Lebesgue outer measure of a finite union of boxes. From this and monotonicity we conclude that the Lebesgue outer measure of any set is bounded below by its Jordan inner measure. As it is also bounded above by the Jordan outer measure, we have ")#metadata(none) <tao-d1fc31e6a69a29c2a0e4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("m_{*,(J)}(E) \\leq m^*(E) \\leq m^{*,(J)}(E)")]]

#text("for every bounded ")#mi("{E \\subset {\\bf R}^d}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" We are now able to explain why not every bounded open set or compact set is Jordan measurable. Consider the countable set ")#mi("{{\\bf Q} \\cap [0,1]}")#text(", which we enumerate as ")#mi("{\\{q_1,q_2,q_3,\\ldots\\}}")#text(", let ")#mi("{\\epsilon > 0}")#text(" be a small number, and consider the set")

#align(center)[#tao-fit-display[#mitex("U := \\bigcup_{n=1}^\\infty (q_n - \\epsilon/2^n, q_n + \\epsilon/2^n ).")]]

#text("This is the union of open sets and is thus open. On the other hand, by countable subadditivity, one has")

#align(center)[#tao-fit-display[#mitex("m^*(U) \\leq \\sum_{n=1}^\\infty 2\\epsilon/2^n = 2\\epsilon.")]]

#text("Finally, as ")#mi("{U}")#text(" is dense in ")#mi("{[0,1]}")#text(" (i.e. ")#mi("{\\overline{U}}")#text(" contains ")#mi("{[0,1]}")#text("), we have")

#align(center)[#tao-fit-display[#mitex("m^{*,(J)}(U) = m^{*,(J)}(\\overline{U}) \\geq m^{*,(J)}([0,1]) = 1.")]]

#text("For ")#mi("{\\epsilon}")#text(" small enough (e.g. ")#mi("{\\epsilon := 1/3}")#text("), we see that the Lebesgue outer measure and Jordan outer measure of ")#mi("{U}")#text(" disagree. Using ")#link(<tao-d1fc31e6a69a29c2a0e4>)[#text("(3)")]#text(", we conclude that the bounded open set ")#mi("{U}")#text(" is not Jordan measurable. This in turn implies that the complement of ")#mi("{U}")#text(" in, say, ")#mi("{[-2,2]}")#text(", is also not Jordan measurable, despite being a compact set.")
]

#text("Now we turn to countable unions of boxes. It is convenient to introduce the following notion: two boxes are ")#emph[#text("almost disjoint")]#text(" if their interiors are disjoint, thus for instance ")#mi("{[0,1]}")#text(" and ")#mi("{[1,2]}")#text(" are almost disjoint. As a box has the same elementary measure as its interior, we see that the finite additivity property ")#metadata(none) <tao-60482f178b25fa0855b3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("m( B_1 \\cup \\ldots \\cup B_k ) = \\left|B_1\\right| + \\ldots + \\left|B_k\\right|", block: true)]]

#text("holds for ")#emph[#text("almost")]#text(" disjoint boxes ")#mi("{B_1,\\ldots,B_k}")#text(", and not just for disjoint boxes. This (and Lemma ")#link(<tao-7f1b55b860590406f84f>)[#text("6")]#text(") has the following consequence:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7 (Outer measure of countable unions of almost disjoint boxes)")]#text(" ")#metadata(none) <tao-455af4f3104ff6a2df0c>#text(" Let ")#mi("{E = \\bigcup_{n=1}^\\infty B_n}")#text(" be a countable union of almost disjoint boxes ")#mi("{B_1,B_2,\\ldots}")#text(". Then")

#align(center)[#tao-fit-display[#mitex("m^*(E) = \\sum_{n=1}^\\infty |B_n|.")]]
]

#text("Thus, for instance, ")#mi("{{\\bf R}^d}")#text(" itself has an infinite outer measure.")

#emph[#text("Proof:")]#text(" From countable subadditivity and Lemma ")#link(<tao-7f1b55b860590406f84f>)[#text("6")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("m^*(E) \\leq \\sum_{n=1}^\\infty m^*(B_n) = \\sum_{n=1}^\\infty \\left|B_n\\right|,", block: true)]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^\\infty \\left|B_n\\right| \\leq m^*(E).", block: true)]]

#text("But for each natural number ")#mi("{N}")#text(", ")#mi("{E}")#text(" contains the elementary set ")#mi("{B_1 \\cup \\ldots \\cup B_N}")#text(", so by monotonicity and Lemma ")#link(<tao-7f1b55b860590406f84f>)[#text("6")]#text(",")

#tao-aligned(keep: true)[


#tao-math("m^*(E)  & \\geq m^*(B_1 \\cup \\ldots \\cup B_N)", block: true)



#tao-math(" & = m(B_1 \\cup \\ldots \\cup B_N)", block: true)
]

#text("and thus by ")#link(<tao-60482f178b25fa0855b3>)[#text("(4)")]#text(", one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^N \\left|B_n\\right| \\leq m^*(E).", block: true)]]

#text("Letting ")#mi("{N \\rightarrow \\infty}")#text(" we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 6")]#text(" The above lemma has the following immediate corollary: if ")#mi("{E = \\bigcup_{n=1}^\\infty B_n = \\bigcup_{n=1}^\\infty B^{\\prime}_n}")#text(" can be decomposed in two different ways as the countable union of almost disjoint boxes, then ")#tao-math("{\\sum_{n=1}^\\infty \\left|B_n\\right| = \\sum_{n=1}^\\infty \\left|B^{\\prime}_n\\right|}", block: false)#text(". Although this statement is intuitively obvious and does not explicitly use the concepts of Lebesgue outer measure or Lebesgue measure, it is remarkably difficult to prove this statement rigorously without essentially using one of these two concepts. (Try it!)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 6")]#text(" Show that if a set ")#mi("{E \\subset {\\bf R}^d}")#text(" is expressible as the countable union of almost disjoint boxes, then the Lebesgue outer measure of ")#mi("{E}")#text(" is equal to the Jordan inner measure: ")#mi("{m^*(E) = m_{*,(J)}(E)}")#text(", where we extend the definition of Jordan inner measure to unbounded sets in the obvious manner.")
]

#text("Not every set can be expressed as the countable union of almost disjoint boxes (consider for instance the irrationals ")#mi("{{\\bf R} \\backslash {\\bf Q}}")#text(", which contain no boxes other than the singleton sets). However, there is an important class of sets of this form, namely the ")#link("http://en.wikipedia.org/wiki/Open_set")[#text("open sets")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 8")]#text(" ")#metadata(none) <tao-63e8915b1106207c9bdd>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be an open set. Then ")#mi("{E}")#text(" can be expressed as the countable union of almost disjoint boxes (and, in fact, as the countable union of almost disjoint closed cubes).")
]

#emph[#text("Proof:")]#text(" We will use the ")#emph[#text("dyadic mesh")]#text(" structure of the Euclidean space ")#mi("{{\\bf R}^d}")#text(", which is a convenient tool for “discretising” certain aspects of real analysis.")

#text("Define a ")#emph[#text("closed dyadic cube")]#text(" to be a cube ")#mi("{Q}")#text(" of the form")

#align(center)[#tao-fit-display[#mitex("Q = [\\frac{i_1}{2^n}, \\frac{i_1+1}{2^n}] \\times \\ldots \\times [\\frac{i_d}{2^n}, \\frac{i_d+1}{2^n}]")]]

#text("for some integers ")#mi("{n, i_1,\\ldots, i_d}")#text(". To avoid some technical issues we shall restrict attention here to “small” cubes of sidelength at most ")#mi("{1}")#text(", thus we restrict ")#mi("{n}")#text(" to the non-negative integers, and we will completely ignore “large” cubes of sidelength greater than one. Observe that the closed dyadic cubes of a fixed sidelength ")#mi("{2^{-n}}")#text(" are almost disjoint, and cover all of ")#mi("{{\\bf R}^d}")#text(". Also observe that each dyadic cube of sidelength ")#mi("{2^{-n}}")#text(" is contained in exactly one “parent” cube of sidelength ")#mi("{2^{-n+1}}")#text(" (which, conversely, has ")#mi("{2^d}")#text(" “children” of sidelength ")#mi("{2^{-n}}")#text("), giving the dyadic cubes a structure analogous to that of a binary tree (or more precisely, an infinite forest of ")#mi("{2^d}")#text("-ary trees). As a consequence of these facts, we also obtain the important ")#emph[#text("dyadic nesting property")]#text(": given any two closed dyadic cubes (possibly of different sidelength), either they are almost disjoint, or one of them is contained in the other.")

#text("If ")#mi("{E}")#text(" is open, and ")#mi("{x \\in E}")#text(", then by definition there is an open ball centered at ")#mi("{x}")#text(" that is contained in ")#mi("{E}")#text(", and it is easy to conclude that there is also a closed dyadic cube containing ")#mi("{x}")#text(" that is contained in ")#mi("{E}")#text(". Thus, if we let ")#mi("{{\\mathcal Q}}")#text(" be the collection of all the dyadic cubes ")#mi("{Q}")#text(" that are contained in ")#mi("{E}")#text(", we see that the union ")#mi("{\\bigcup_{Q \\in {\\mathcal Q}} Q}")#text(" of all these cubes is exactly equal to ")#mi("{E}")#text(".")

#text("As there are only countably many dyadic cubes, ")#mi("{{\\mathcal Q}}")#text(" is at most countable. But we are not done yet, because these cubes are not almost disjoint (for instance, any cube ")#mi("{Q}")#text(" in ")#mi("{{\\mathcal Q}}")#text(" will of course overlap with its child cubes). But we can deal with this by exploiting the dyadic nesting property. Let ")#mi("{{\\mathcal Q}^*}")#text(" denote those cubes in ")#mi("{{\\mathcal Q}}")#text(" which are ")#emph[#text("maximal")]#text(" with respect to set inclusion, which means that they are not contained in any other cube in ")#mi("{{\\mathcal Q}}")#text(". From the nesting property (and the fact that we have capped the maximum size of our cubes) we see that every cube in ")#mi("{{\\mathcal Q}}")#text(" is contained in exactly one maximal cube in ")#mi("{{\\mathcal Q}^*}")#text(", and that any two such maximal cubes in ")#mi("{{\\mathcal Q}^*}")#text(" are almost disjoint. Thus, we see that ")#mi("{E}")#text(" is the union ")#mi("{E = \\bigcup_{Q \\in {\\mathcal Q}^*} Q}")#text(" of almost disjoint cubes. As ")#mi("{{\\mathcal Q}^*}")#text(" is at most countable, the claim follows (adding empty boxes if necessary to pad out the cardinality). ")#mi("\\Box")

#text("We now have a formula for the Lebesgue outer measure of any open set: it is exactly equal to the Jordan inner measure of that set, or of the total volume of any partitioning of that set into almost disjoint boxes. Finally, we have a formula for the Lebesgue outer measure of an arbitrary set:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9 (Outer regularity)")]#text(" ")#metadata(none) <tao-560e3e12b1e0dafa161e>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be an arbitrary set. Then one has")

#align(center)[#tao-fit-display[#mitex("m^*(E) = \\inf_{E \\subset U, U \\text{ open}} m^*(U).")]]
]

#emph[#text("Proof:")]#text(" From monotonicity one trivially has")

#align(center)[#tao-fit-display[#mitex("m^*(E) \\leq \\inf_{E \\subset U, U \\text{ open}} m^*(U)")]]

#text("so it suffices to show that")

#align(center)[#tao-fit-display[#mitex("\\inf_{E \\subset U, U \\text{ open}} m^*(U) \\leq m^*(E).")]]

#text("This is trivial for ")#mi("{m^*(E)}")#text(" infinite, so we may assume that ")#mi("{m^*(E)}")#text(" is finite.")

#text("Let ")#mi("{\\epsilon > 0}")#text(". By definition of outer measure, there exists a countable family ")#mi("{B_1, B_2, \\ldots}")#text(" of boxes covering ")#mi("{E}")#text(" such that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^\\infty \\left|B_n\\right| \\leq m^*(E) + \\epsilon.", block: true)]]

#text("We use the ")#mi("{\\epsilon/2^n}")#text(" trick again. We can enlarge each of these boxes ")#mi("{B_n}")#text(" to an ")#emph[#text("open")]#text(" box ")#mi("{B^{\\prime}_n}")#text(" such that ")#tao-math("{\\left|B^{\\prime}_n\\right| \\leq \\left|B_n\\right| + \\epsilon/2^n}", block: false)#text(". Then the set ")#mi("{\\bigcup_{n=1}^\\infty B^{\\prime}_n}")#text(", being a union of open sets, is itself open, and contains ")#mi("{E}")#text("; and")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n=1}^\\infty \\left|B^{\\prime}_n\\right| \\leq m^*(E) + \\epsilon + \\sum_{n=1}^\\infty \\epsilon/2^n = m^*(E) + 2\\epsilon.", block: true)]]

#text("By countable subadditivity, this implies that")

#align(center)[#tao-fit-display[#mitex("m^*( \\bigcup_{n=1}^\\infty B^{\\prime}_n) \\leq m^*(E) + 2\\epsilon")]]

#text("and thus")

#align(center)[#tao-fit-display[#mitex("\\inf_{E \\subset U, U \\text{ open}} m^*(U) \\leq m^*(E) + 2\\epsilon.")]]

#text("As ")#mi("{\\epsilon>0}")#text(" was arbitrary, we obtain the claim. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 7")]#text(" Give an example to show that the reverse statement")

#align(center)[#tao-fit-display[#mitex("m^*(E) = \\sup_{U \\subset E, U \\text{ open}} m^*(U)")]]

#text("is false. (For the corrected version of this statement, see Exercise ")#link(<tao-2a4da3b2935c57a57848>)[#text("15")]#text(".)")
]

#heading(level: 1)[#strong[#text(" — 3. Lebesgue measurability — ")]]

#text("We now define the notion of a Lebesgue measurable set as one which can be efficiently contained in open sets in the sense of Definition ")#link(<tao-108d621bf2580754dd59>)[#text("1")]#text(", and set out their basic properties.")

#text("First, we show that there are plenty of Lebesgue measurable sets.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 10 (Existence of Lebesgue measurable sets)")]#text(" ")#metadata(none) <tao-8c7ba4ba6fe81046d561>

#list(
[#text("(i) Every open set is Lebesgue measurable.")],
[#text("(ii) Every closed set is Lebesgue measurable.")],
[#text("(iii) Every set of Lebesgue outer measure zero is measurable. (Such sets are called ")#link("http://en.wikipedia.org/wiki/Null_set")[#text("null sets")]#text(".)")],
[#text("(iv) The empty set ")#mi("{\\emptyset}")#text(" is Lebesgue measurable.")],
[#text("(v) If ")#mi("{E \\subset {\\bf R}^d}")#text(" is Lebesgue measurable, then so is its complement ")#mi("{{\\bf R}^d \\backslash E}")#text(".")],
[#text("(vi) If ")#mi("{E_1, E_2, E_3, \\ldots \\subset {\\bf R}^d}")#text(" are a sequence of Lebesgue measurable sets, then the union ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" is Lebesgue measurable.")],
[#text("(vii) If ")#mi("{E_1, E_2, E_3, \\ldots \\subset {\\bf R}^d}")#text(" are a sequence of Lebesgue measurable sets, then the intersection ")#mi("{\\bigcap_{n=1}^\\infty E_n}")#text(" is Lebesgue measurable.")]
)
]

#emph[#text("Proof:")]#text(" Claim (i) is obvious from definition, as are Claims (iii) and (iv).")

#text("To prove Claim (vi), we use the ")#mi("{\\epsilon/2^n}")#text(" trick. Let ")#mi("{\\epsilon > 0}")#text(" be arbitrary. By hypothesis, each ")#mi("{E_n}")#text(" is contained in an open set ")#mi("{U_n}")#text(" whose difference ")#mi("{U_n \\backslash E_n}")#text(" has Lebesgue outer measure at most ")#mi("{\\epsilon/2^n}")#text(". By countable subadditivity, this implies that ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" is contained in ")#mi("{\\bigcup_{n=1}^\\infty U_n}")#text(", and the difference ")#mi("{(\\bigcup_{n=1}^\\infty U_n) \\backslash (\\bigcup_{n=1}^\\infty E_n)}")#text(" has Lebesgue outer measure at most ")#mi("{\\epsilon}")#text(". The set ")#mi("{\\bigcup_{n=1}^\\infty U_n}")#text(", being a union of open sets, is itself open, and the claim follows.")

#text("Now we establish Claim (ii). Every closed set ")#mi("{E}")#text(" is the countable union of closed and bounded sets (by intersecting ")#mi("{E}")#text(" with, say, the closed balls ")#mi("{\\overline{B(0,n)}}")#text(" of radius ")#mi("{n}")#text(" for ")#mi("{n=1,2,3,\\ldots}")#text("), so by (vi), it suffices to verify the claim when ")#mi("{E}")#text(" is closed and bounded, hence compact by the Heine-Borel theorem. Note that the boundedness of ")#mi("{E}")#text(" implies that ")#mi("{m^*(E)}")#text(" is finite.")

#text("Let ")#mi("{\\epsilon > 0}")#text(". By outer regularity (Lemma ")#link(<tao-560e3e12b1e0dafa161e>)[#text("9")]#text("), we can find an open set ")#mi("{U}")#text(" containing ")#mi("{E}")#text(" such that ")#mi("{m^*(U) \\leq m^*(E) + \\epsilon}")#text(". It suffices to show that ")#mi("{m^*(U \\backslash E) \\leq \\epsilon}")#text(".")

#text("The set ")#mi("{U \\backslash E}")#text(" is open, and so by Lemma ")#link(<tao-63e8915b1106207c9bdd>)[#text("8")]#text(" is the countable union ")#mi("{\\bigcup_{n=1}^\\infty Q_n}")#text(" of almost disjoint closed cubes. By Lemma ")#link(<tao-455af4f3104ff6a2df0c>)[#text("7")]#text(", ")#tao-math("{m^*(U \\backslash E) = \\sum_{n=1}^\\infty \\left|Q_n\\right|}", block: false)#text(". So it will suffice to show that ")#tao-math("{\\sum_{n=1}^N \\left|Q_n\\right| \\leq \\epsilon}", block: false)#text(" for every finite ")#mi("{N}")#text(".")

#text("The set ")#mi("{\\bigcup_{n=1}^N Q_n}")#text(" is a finite union of closed cubes and is thus closed. It is disjoint from the compact set ")#mi("{E}")#text(", so by Exercise ")#link(<tao-897ce337f513a1ed0166>)[#text("5")]#text(" followed by Lemma ")#link(<tao-2a8111ae3d7177778101>)[#text("5")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("m^*( E \\cup \\bigcup_{n=1}^N Q_n ) = m^*(E) + m^*( \\bigcup_{n=1}^N Q_n ).")]]

#text("By monotonicity, the left-hand side is at most ")#mi("{m^*(U)}")#text(", which is in turn at most ")#mi("{m^*(E)+\\epsilon}")#text(". Since ")#mi("{m^*(E)}")#text(" is finite, we may cancel it and conclude that ")#mi("{m^*( \\bigcup_{n=1}^N Q_n ) \\leq \\epsilon}")#text(", as required.")

#text("Next, we establish Claim (v). If ")#mi("{E}")#text(" is Lebesgue measurable, then for every ")#mi("{n}")#text(" we can find an open set ")#mi("{U_n}")#text(" containing ")#mi("{E}")#text(" such that ")#mi("{m^*(U_n \\backslash E) \\leq 1/n}")#text(". Letting ")#mi("{F_n}")#text(" be the complement of ")#mi("{U_n}")#text(", we conclude that the complement ")#mi("{{\\bf R}^d \\backslash E}")#text(" of ")#mi("{E}")#text(" contains all of the ")#mi("{F_n}")#text(", and that ")#mi("{m^*( ({\\bf R}^d \\backslash E) \\backslash F_n ) \\leq 1/n}")#text(". If we let ")#mi("{F := \\bigcup_{n=1}^\\infty F_n}")#text(", then ")#mi("{{\\bf R}^d \\backslash E}")#text(" contains ")#mi("{F}")#text(", and from monotonicity ")#mi("{m^*( ({\\bf R}^d \\backslash E) \\backslash F ) = 0}")#text(", thus ")#mi("{{\\bf R}^d \\backslash E}")#text(" is the union of ")#mi("{F}")#text(" and a set of Lebesgue outer measure zero. But ")#mi("{F}")#text(" is in turn the union of countably many closed sets ")#mi("{F_n}")#text(". The claim now follows from (ii), (iii), (vi).")

#text("Finally, Claim (vii) follows from (v), (vi), and ")#link("http://en.wikipedia.org/wiki/De_Morgan's_laws")[#text("de Morgan’s laws")]#text(" (which work for infinite unions and intersections without any difficulty). ")#mi("\\Box")

#text("Informally, the above lemma asserts (among other things) that if one starts with such basic subsets of ")#mi("{{\\bf R}^d}")#text(" as open or closed sets and then takes at most countably many boolean operations, one will always end up with a Lebesgue measurable set. This is already enough to ensure that the majority of sets that one actually encounters in real analysis will be Lebesgue measurable. (Nevertheless, using the axiom of choice one can construct sets that are not Lebesgue measurable; we will see an example of this later. As a consequence, we cannot generalise the countable closure properties here to uncountable closure properties.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" The properties (iv), (v), (vi) of Lemma ")#link(<tao-8c7ba4ba6fe81046d561>)[#text("10")]#text(" assert that the collection of Lebesgue measurable subsets of ")#mi("{{\\bf R}^d}")#text(" form a ")#link("http://en.wikipedia.org/wiki/Sigma-algebra")[#mi("{\\sigma}")#text("-algebra")]#text(", which is a strengthening of the more classical concept of a ")#link("http://en.wikipedia.org/wiki/Boolean_algebra_(structure)")[#text("boolean algebra")]#text(". We will study abstract ")#mi("{\\sigma}")#text("-algebras in more detail in subsequent notes.")
]

#text("Note how this Lemma ")#link(<tao-8c7ba4ba6fe81046d561>)[#text("10")]#text(" is significantly stronger than the counterpart for Jordan measurability (Exercise 6.1 of the ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/")[#text("prologue")]#text("), in particular by allowing countably many boolean operations instead of just finitely many. This is one of the main reasons why we use Lebesgue measure instead of Jordan measure.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 8 (Criteria for measurability)")]#text(" ")#metadata(none) <tao-b403a0fba8fd36e2bbc2>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{E}")#text(" is Lebesgue measurable.")],
[#text("(ii) (Outer approximation by open) For every ")#mi("{\\epsilon > 0}")#text(", one can contain ")#mi("{E}")#text(" in an open set ")#mi("{U}")#text(" with ")#mi("{m^*(U \\backslash E) \\leq \\epsilon}")#text(".")],
[#text("(iii) (Almost open) For every ")#mi("{\\epsilon > 0}")#text(", one can find an open set ")#mi("{U}")#text(" such that ")#mi("{m^*(U \\Delta E) \\leq \\epsilon}")#text(". (In other words, ")#mi("{E}")#text(" differs from an open set by a set of outer measure at most ")#mi("{\\epsilon}")#text(".)")],
[#text("(iv) (Inner approximation by closed) For every ")#mi("{\\epsilon > 0}")#text(", one can find a closed set ")#mi("{F}")#text(" contained in ")#mi("{E}")#text(" with ")#mi("{m^*(E \\backslash F) \\leq \\epsilon}")#text(".")],
[#text("(v) (Almost closed) For every ")#mi("{\\epsilon > 0}")#text(", one can find a closed set ")#mi("{F}")#text(" such that ")#mi("{m^*(F \\Delta E) \\leq \\epsilon}")#text(". (In other words, ")#mi("{E}")#text(" differs from a closed set by a set of outer measure at most ")#mi("{\\epsilon}")#text(".)")],
[#text("(vi) (Almost measurable) For every ")#mi("{\\epsilon > 0}")#text(", one can find a Lebesgue measurable set ")#mi("{E_\\epsilon}")#text(" such that ")#mi("{m^*(E_\\epsilon \\Delta E) \\leq \\epsilon}")#text(". (In other words, ")#mi("{E}")#text(" differs from a measurable set by a set of outer measure at most ")#mi("{\\epsilon}")#text(".)")]
)

#text("(")#emph[#text("Hint:")]#text(" Some of these deductions are either trivial or very easy. To deduce (i) from (vi), use the ")#mi("{\\epsilon/2^n}")#text(" trick to show that ")#mi("{E}")#text(" is contained in a Lebesgue measurable set ")#mi("{E^{\\prime}_\\epsilon}")#text(" with ")#mi("{m^*(E^{\\prime}_\\epsilon \\Delta E) \\leq \\epsilon}")#text(", and then take countable intersections to show that ")#mi("{E}")#text(" differs from a Lebesgue measurable set by a null set.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 9")]#text(" Show that every Jordan measurable set is Lebesgue measurable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 10 (Middle thirds Cantor set)")]#text(" Let ")#mi("{I_0 := [0,1]}")#text(" be the unit interval, let ")#mi("{I_1 := [0,1/3] \\cup [2/3,1]}")#text(" be ")#mi("{I_0}")#text(" with the interior of the middle third interval removed, let ")#mi("{I_2 := [0,1/9] \\cup [2/9,1/3] \\cup [2/3,7/9] \\cup [8/9,1]}")#text(" be ")#mi("{I_1}")#text(" with the interior of the middle third of each of the two intervals of ")#mi("{I_1}")#text(" removed, and so forth. More formally, write")

#align(center)[#tao-fit-display[#mitex("I_n := \\bigcup_{a_1,\\ldots,a_n \\in \\{0,2\\}} [ \\sum_{i=1}^n \\frac{a_i}{3^i}, \\sum_{i=1}^n \\frac{a_i}{3^i} + \\frac{1}{3^n} ].")]]

#text("Let ")#mi("{C := \\bigcap_{n=1}^\\infty I_n}")#text(" be the intersection of all the elementary sets ")#mi("{I_n}")#text(". Show that ")#mi("{C}")#text(" is compact, uncountable, and a null set.")
]

#text("Now we look at the Lebesgue measure ")#mi("{m(E)}")#text(" of a Lebesgue measurable set ")#mi("{E}")#text(", which is defined to equal its Lebesgue outer measure ")#mi("{m^*(E)}")#text(". If ")#mi("{E}")#text(" is Jordan measurable, we see from ")#link(<tao-d1fc31e6a69a29c2a0e4>)[#text("(3)")]#text(" that the Lebesgue measure and the Jordan measure of ")#mi("{E}")#text(" coincide, thus Lebesgue measure extends Jordan measure. This justifies the use of the notation ")#mi("{m(E)}")#text(" to denote both Lebesgue measure of a Lebesgue measurable set, and Jordan measure of a Jordan measurable set (as well as elementary measure of an elementary set).")

#text("Lebesgue measure obeys significantly better properties than Lebesgue outer measure, when restricted to Lebesgue measurable sets:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11 (The measure axioms)")]#text(" ")#metadata(none) <tao-b5d693905a169c659344>

#list(
[#text("(Empty set) ")#mi("{m(\\emptyset) = 0}")#text(".")],
[#text("(Countable additivity) If ")#mi("{E_1, E_2, \\ldots \\subset {\\bf R}^d}")#text(" is a countable sequence of disjoint Lebesgue measurable sets, then ")#mi("{m( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty m(E_n)}")#text(".")]
)
]

#emph[#text("Proof:")]#text(" The first claim is trivial, so we focus on the second. We deal with an easy case when all of the ")#mi("{E_n}")#text(" are compact. By repeated use of Lemma ")#link(<tao-2a8111ae3d7177778101>)[#text("5")]#text(" and Exercise ")#link(<tao-897ce337f513a1ed0166>)[#text("5")]#text(", we have")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{n=1}^N E_n ) = \\sum_{n=1}^N m(E_n).")]]

#text("Using monotonicity, we conclude that")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{n=1}^\\infty E_n ) \\geq \\sum_{n=1}^N m(E_n).")]]

#text("(We can use ")#mi("{m}")#text(" instead of ")#mi("{m^*}")#text(" throughout this argument, thanks to Lemma ")#link(<tao-8c7ba4ba6fe81046d561>)[#text("10")]#text("). Sending ")#mi("{N \\rightarrow \\infty}")#text(" we obtain")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{n=1}^\\infty E_n ) \\geq \\sum_{n=1}^\\infty m(E_n).")]]

#text("On the other hand, from countable subadditivity one has")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{n=1}^\\infty E_n ) \\leq \\sum_{n=1}^\\infty m(E_n),")]]

#text("and the claim follows.")

#text("Next, we handle the case when the ")#mi("{E_n}")#text(" are bounded but not necessarily compact. We use the ")#mi("{\\epsilon/2^n}")#text(" trick. Let ")#mi("{\\epsilon > 0}")#text(". Applying Exercise ")#link(<tao-b403a0fba8fd36e2bbc2>)[#text("8")]#text(", we know that each ")#mi("{E_n}")#text(" is the union of a compact set ")#mi("{K_n}")#text(" and a set of outer measure at most ")#mi("{\\epsilon/2^n}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("m(E_n) \\leq m(K_n) + \\epsilon/2^n")]]

#text("and hence")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty m(E_n) \\leq (\\sum_{n=1}^\\infty m(K_n)) + \\epsilon.")]]

#text("Finally, from the compact case of this lemma we already know that")

#align(center)[#tao-fit-display[#mitex("m(\\bigcup_{n=1}^\\infty K_n) = \\sum_{n=1}^\\infty m(K_n)")]]

#text("while from monotonicity")

#align(center)[#tao-fit-display[#mitex("m(\\bigcup_{n=1}^\\infty K_n) \\leq m(\\bigcup_{n=1}^\\infty E_n).")]]

#text("Putting all this together we see that")

#align(center)[#tao-fit-display[#mitex("\\sum_{n=1}^\\infty m(E_n) \\leq m(\\bigcup_{n=1}^\\infty E_n) + \\epsilon")]]

#text("for every ")#mi("{\\epsilon>0}")#text(", while from countable subadditivity we have")

#align(center)[#tao-fit-display[#mitex("m(\\bigcup_{n=1}^\\infty E_n) \\leq \\sum_{n=1}^\\infty m(E_n).")]]

#text("The claim follows.")

#text("Finally, we handle the case when the ")#mi("{E_n}")#text(" are not assumed to be bounded or closed. Here, the basic idea is to decompose each ")#mi("{E_n}")#text(" as a countable disjoint union of bounded Lebesgue measurable sets. First, decompose ")#mi("{{\\bf R}^d}")#text(" as the countable disjoint union ")#mi("{{\\bf R}^d = \\bigcup_{m=1}^\\infty A_m}")#text(" of bounded measurable sets ")#mi("{A_m}")#text("; for instance one could take the annuli ")#tao-math("{A_m := \\{ x \\in {\\bf R}^d: m-1 \\leq \\left|x\\right| < m\\}}", block: false)#text(". Then each ")#mi("{E_n}")#text(" is the countable disjoint union of the bounded measurable sets ")#mi("{E_n \\cap A_m}")#text(" for ")#mi("{m=1,2,\\ldots}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("m(E_n) = \\sum_{m=1}^\\infty m(E_n \\cap A_m)")]]

#text("by the previous arguments. In a similar vein, ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" is the countable disjoint union of the bounded measurable sets ")#mi("{E_n \\cap A_m}")#text(" for ")#mi("{n,m = 1,2,\\ldots}")#text(", and thus")

#align(center)[#tao-fit-display[#mitex("m(\\bigcup_{n=1}^\\infty E_n) = \\sum_{n=1}^\\infty \\sum_{m=1}^\\infty m(E_n \\cap A_m),")]]

#text("and the claim follows. ")#mi("\\Box")

#text("From Lemma ")#link(<tao-b5d693905a169c659344>)[#text("11")]#text(" one of course can conclude finite additivity")

#align(center)[#tao-fit-display[#mitex("m( E_1 \\cup \\ldots \\cup E_k ) = m(E_1) + \\ldots + m(E_k)")]]

#text("whenever ")#mi("{E_1,\\ldots,E_k \\subset {\\bf R}^d}")#text(" are Lebesgue measurable sets. We also have another important result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 11 (Monotone convergence theorem for measurable sets)")]#text(" ")#metadata(none) <tao-a16455ef48ce167dc393>

#enum(start: 1, 
[#text("(Upward monotone convergence) Let ")#mi("{E_1 \\subset E_2 \\subset \\ldots \\subset {\\bf R}^n}")#text(" be a countable non-decreasing sequence of Lebesgue measurable sets. Show that ")#mi("{m( \\bigcup_{n=1}^\\infty E_n ) = \\lim_{n \\rightarrow \\infty} m(E_n)}")#text(". (")#emph[#text("Hint:")]#text(" Express ")#mi("{\\bigcup_{n=1}^\\infty E_n}")#text(" as the countable union of the lacunae ")#mi("{E_n \\backslash \\bigcup_{n^{\\prime}=1}^{n-1} E_{n^{\\prime}}}")#text(".)")],
[#text("(Downward monotone convergence) Let ")#mi("{{\\bf R}^d \\supset E_1 \\supset E_2 \\supset \\ldots}")#text(" be a countable non-increasing sequence of Lebesgue measurable sets. If at least one of the ")#mi("{m(E_n)}")#text(" is finite, show that ")#mi("{m( \\bigcap_{n=1}^\\infty E_n ) = \\lim_{n \\rightarrow \\infty} m(E_n)}")#text(".")],
[#text("Give a counterexample to show that the hypothesis that at least one of the ")#mi("{m(E_n)}")#text(" is finite in the downward monotone convergence theorem cannot be dropped.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 12")]#text(" Show that any map ")#mi("{E \\mapsto m(E)}")#text(" from Lebesgue measurable sets to elements of ")#mi("{[0,+\\infty]}")#text(" that obeys the above empty set and countable additivity axioms will also obey the monotonicity and countable subadditivity axioms from Exercise ")#link(<tao-2e37c8a01fb4b41fc028>)[#text("4")]#text(", when restricted to Lebesgue measurable sets of course.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 13")]#text(" We say that a sequence ")#mi("{E_n}")#text(" of sets in ")#mi("{{\\bf R}^d}")#text(" ")#emph[#text("converges pointwise")]#text(" to another set ")#mi("{E}")#text(" in ")#mi("{{\\bf R}^d}")#text(" if the ")#link("http://en.wikipedia.org/wiki/Indicator_function")[#text("indicator functions")]#text(" ")#mi("{1_{E_n}}")#text(" converge pointwise to ")#mi("{1_E}")#text(".")

#list(
[#text("Show that if the ")#mi("{E_n}")#text(" are all Lebesgue measurable, and converge pointwise to ")#mi("{E}")#text(", then ")#mi("{E}")#text(" is Lebesgue measurable also. (")#emph[#text("Hint:")]#text(" use the identity ")#mi("{1_E(x) = \\liminf_{n \\rightarrow \\infty} 1_{E_n}(x)}")#text(" or ")#mi("{1_E(x) = \\limsup_{n \\rightarrow \\infty} 1_{E_n}(x)}")#text(" to write ")#mi("{E}")#text(" in terms of countable unions and intersections of the ")#mi("{E_n}")#text(".)")],
[#text("(Dominated convergence theorem) Suppose that the ")#mi("{E_n}")#text(" are all contained in another Lebesgue measurable set ")#mi("{F}")#text(" of finite measure. Show that ")#mi("{m(E_n)}")#text(" converges to ")#mi("{m(E)}")#text(". (")#emph[#text("Hint:")]#text(" use the upward and downward monotone convergence theorems.)")],
[#text("Give a counterexample to show that the dominated convergence theorem fails if the ")#mi("{E_n}")#text(" are not contained in a set of finite measure, even if we assume that the ")#mi("{m(E_n)}")#text(" are all uniformly bounded.")]
)
]

#text("In later notes we will generalise the monotone and dominated convergence theorems to measurable functions instead of measurable sets; these fundamental convergence theorems will be the foundation of much of the rest of the course.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 14")]#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(". Show that ")#mi("{E}")#text(" is contained in a Lebesgue measurable set of measure exactly equal to ")#mi("{m^*(E)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 15 (Inner regularity)")]#text(" ")#metadata(none) <tao-2a4da3b2935c57a57848>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be Lebesgue measurable. Show that")

#align(center)[#tao-fit-display[#mitex("m(E) = \\sup_{K \\subset E, K \\text{ compact}} m(K).")]]
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 8")]#text(" The inner and outer regularity properties of measure can be used to define the concept of a ")#link("http://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(", which will be encountered ")#link("https://terrytao.wordpress.com/2009/03/02/245b-notes-12-continuous-functions-on-locally-compact-hausdorff-spaces/")[#text("much later in this course series")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 16 (Criteria for finite measure)")]#text(" ")#metadata(none) <tao-98b37af37c6839d0f782>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{E}")#text(" is Lebesgue measurable with finite measure.")],
[#text("(ii) (Outer approximation by open) For every ")#mi("{\\epsilon > 0}")#text(", one can contain ")#mi("{E}")#text(" in an open set ")#mi("{U}")#text(" of finite measure with ")#mi("{m^*(U \\backslash E) \\leq \\epsilon}")#text(".")],
[#text("(iii) (Almost open bounded) ")#mi("{E}")#text(" differs from a bounded open set by a set of arbitrarily small Lebesgue outer measure. (In other words, for every ")#mi("{\\epsilon > 0}")#text(" there exists a bounded open set ")#mi("{U}")#text(" such that ")#mi("{m^*(E \\Delta U) \\leq \\epsilon}")#text(".)")],
[#text("(iv) (Inner approximation by compact) For every ")#mi("{\\epsilon > 0}")#text(", one can find a compact set ")#mi("{F}")#text(" contained in ")#mi("{E}")#text(" with ")#mi("{m^*(E \\backslash F) \\leq \\epsilon}")#text(".")],
[#text("(v) (Almost compact) ")#mi("{E}")#text(" differs from a compact set by a set of arbitrarily small Lebesgue outer measure.")],
[#text("(vi) (Almost bounded measurable) ")#mi("{E}")#text(" differs from a bounded Lebesgue measurable set by a set of arbitrarily small Lebesgue outer measure.")],
[#text("(vii) (Almost finite measure) ")#mi("{E}")#text(" differs from a Lebesgue measurable set with finite measure by a set of arbitrarily small Lebesgue outer measure.")],
[#text("(viii) (Almost elementary) ")#mi("{E}")#text(" differs from an elementary set by a set of arbitrarily small Lebesgue outer measure.")],
[#text("(ix) (Almost dyadically elementary) For every ")#mi("{\\epsilon > 0}")#text(", there exists an integer ")#mi("{n}")#text(" and a finite union ")#mi("{F}")#text(" of closed dyadic cubes of sidelength ")#mi("{2^{-n}}")#text(" such that ")#mi("{m^*(E \\Delta F) \\leq \\epsilon}")#text(".")]
)
]

#text("One can interpret the equivalence of (i) and (ix) in the above exercise as asserting that Lebesgue measurable sets are those which look (locally) “pixelated” at sufficiently fine scales. This will be formalised in later notes with the ")#link("http://en.wikipedia.org/wiki/Lebesgue's_density_theorem")[#text("Lebesgue density theorem")]#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 17 (Carathéodory criterion, one direction)")]#text(" ")#metadata(none) <tao-1fc5a1c310dedb062457>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(". Show that the following are equivalent:")

#list(
[#text("(i) ")#mi("{E}")#text(" is Lebesgue measurable.")],
[#text("(ii) For every elementary set ")#mi("{A}")#text(", one has ")#mi("{m(A) = m^*(A \\cap E) + m^*(A \\backslash E)}")#text(".")],
[#text("(iii) For every box ")#mi("{B}")#text(", one has ")#tao-math("{\\left|B\\right| = m^*(B \\cap E) + m^*(B \\backslash E)}", block: false)#text(".")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 18 (Inner measure)")]#text(" ")#metadata(none) <tao-c81cc8d3d2da2311b4a6>#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(" be a bounded set. Define the ")#emph[#text("Lebesgue inner measure")]#text(" ")#mi("{m_*(E)}")#text(" of ")#mi("{E}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("m_*(E) := m(A) - m^*(A \\backslash E)")]]

#text("for any elementary set ")#mi("{A}")#text(" containing ")#mi("{E}")#text(".")

#list(
[#text("Show that this definition is well defined, i.e. that if ")#mi("{A, A^{\\prime}}")#text(" are two elementary sets containing ")#mi("{E}")#text(", that ")#mi("{m(A) - m^*(A \\backslash E)}")#text(" is equal to ")#mi("{m(A^{\\prime}) - m^*(A^{\\prime} \\backslash E)}")#text(".")],
[#text("Show that ")#mi("{m_*(E) \\leq m^*(E)}")#text(", and that equality holds if and only if ")#mi("{E}")#text(" is Lebesgue measurable.")]
)
]

#text("Define a ")#link("http://en.wikipedia.org/wiki/G%CE%B4_set")[#mi("{G_\\delta}")#text(" set")]#text(" to be a countable intersection ")#mi("{\\bigcap_{n=1}^\\infty U_n}")#text(" of open sets, and an ")#link("http://en.wikipedia.org/wiki/F%CF%83_set")[#mi("{F_\\sigma}")#text(" set")]#text(" to be a countable union ")#mi("{\\bigcup_{n=1}^\\infty F_n}")#text(" of closed sets.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 19")]#text(" Let ")#mi("{E \\subset {\\bf R}^d}")#text(". Show that the following are equivalent:")

#list(
[#mi("{E}")#text(" is Lebesgue measurable.")],
[#mi("{E}")#text(" is a ")#mi("{G_\\delta}")#text(" set with a null set removed.")],
[#mi("{E}")#text(" is the union of a ")#mi("{F_\\sigma}")#text(" set and a null set.")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 9")]#text(" From the above exercises, we see that when describing what it means for a set to be Lebesgue measurable, there is a tradeoff between the type of approximation one is willing to bear, and the type of things one can say about the approximation. If one is only willing to approximate to within a null set, then one can only say that a measurable set is approximated by a ")#mi("{G_\\delta}")#text(" or a ")#mi("{F_\\sigma}")#text(" set, which is a fairly weak amount of structure. If one is willing to add on an epsilon of error (as measured in the Lebesgue outer measure), one can make a measurable set open; dually, if one is willing to take away an epsilon of error, one can make a measurable set closed. Finally, if one is willing to both add and subtract an epsilon of error, then one can make a measurable set (of finite measure) elementary, or even a finite union of dyadic cubes.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 20 (Translation invariance)")]#text(" If ")#mi("{E \\subset {\\bf R}^d}")#text(" is Lebesgue measurable, show that ")#mi("{E+x}")#text(" is Lebesgue measurable for any ")#mi("{x \\in {\\bf R}^d}")#text(", and that ")#mi("{m(E+x) = m(E)}")#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 21 (Change of variables)")]#text(" If ")#mi("{E \\subset {\\bf R}^d}")#text(" is Lebesgue measurable, and ")#mi("{T: {\\bf R}^d \\rightarrow {\\bf R}^d}")#text(" is a linear transformation, show that ")#mi("{T(E)}")#text(" is Lebesgue measurable, and that ")#tao-math("{m(T(E)) = \\left|\\det T\\right| m(E)}", block: false)#text(". We caution that if ")#mi("{T: {\\bf R}^d \\rightarrow {\\bf R}^{d^{\\prime}}}")#text(" is a linear map to a space ")#mi("{{\\bf R}^{d^{\\prime}}}")#text(" of strictly smaller dimension than ")#mi("{{\\bf R}^d}")#text(", then ")#mi("{T(E)}")#text(" need not be Lebesgue measurable; see Exercise ")#link(<tao-fd03c3b4c6526cf1ef7c>)[#text("26")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 22")]#text(" Let ")#mi("{d, d^{\\prime} \\geq 1}")#text(" be natural numbers.")

#list(
[#text("If ")#mi("{E \\subset {\\bf R}^d}")#text(" and ")#mi("{F \\subset {\\bf R}^{d^{\\prime}}}")#text(", show that ")#mi("{(m^{d+d^{\\prime}})^*(E \\times F) \\leq (m^d)^*(E) (m^{d^{\\prime}})^*(F)}")#text(", where ")#mi("{(m^d)^*}")#text(" denotes ")#mi("{d}")#text("-dimensional Lebesgue measure, etc.")],
[#text("Let ")#mi("{E \\subset {\\bf R}^d}")#text(", ")#mi("{F \\subset {\\bf R}^{d^{\\prime}}}")#text(" be Lebesgue measurable sets. Show that ")#mi("{E \\times F \\subset {\\bf R}^{d+d^{\\prime}}}")#text(" is Lebesgue measurable, with ")#mi("{m^{d+d^{\\prime}}(E \\times F) = m^d(E) \\cdot m^{d^{\\prime}}(F)}")#text(". (Note that we allow ")#mi("{E}")#text(" or ")#mi("{F}")#text(" to have infinite measure, and so one may have to divide into cases or take advantage of the monotone convergence theorem for Lebesgue measure, Exercise ")#link(<tao-a16455ef48ce167dc393>)[#text("11")]#text(".)")]
)
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 23 (Uniqueness of Lebesgue measure)")]#text(" Show that Lebesgue measure ")#mi("{E \\mapsto m(E)}")#text(" is the only map from Lebesgue measurable sets to ")#mi("{[0,+\\infty]}")#text(" that obeys the following axioms:")

#list(
[#text("(Empty set) ")#mi("{m(\\emptyset) = 0}")#text(".")],
[#text("(Countable additivity) If ")#mi("{E_1, E_2, \\ldots \\subset {\\bf R}^d}")#text(" is a countable sequence of disjoint Lebesgue measurable sets, then ")#mi("{m( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty m(E_n)}")#text(".")],
[#text("(Translation invariance) If ")#mi("{E}")#text(" is Lebesgue measurable and ")#mi("{x \\in {\\bf R}^d}")#text(", then ")#mi("{m(E+x) = m(E)}")#text(".")],
[#text("(Normalisation) ")#mi("{m( [0,1]^d ) = 1}")#text(".")]
)

#emph[#text("Hint:")]#text(" First show that ")#mi("{m}")#text(" must match elementary measure on elementary sets, then show that ")#mi("{m}")#text(" is bounded by outer measure.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 24 (Lebesgue measure as the completion of elementary measure)")]#text(" The purpose of the following exercise is to indicate how Lebesgue measure can be viewed as a metric completion of elementary measure in some sense. To avoid some technicalities we will not work in all of ")#mi("{{\\bf R}^d}")#text(", but in some fixed elementary set ")#mi("{A}")#text(" (e.g. ")#mi("{A = [0,1]^d}")#text(").")

#list(
[#text("Let ")#mi("{2^A := \\{ E: E \\subset A \\}}")#text(" be the power set of ")#mi("{A}")#text(". We say that two sets ")#mi("{E, F \\in 2^A}")#text(" are ")#emph[#text("equivalent")]#text(" if ")#mi("{E \\Delta F}")#text(" is a null set. Show that this is a equivalence relation.")],
[#text("Let ")#mi("{2^A/\\sim}")#text(" be the set of equivalence classes ")#mi("{[E] := \\{ F \\in 2^A: E \\sim F \\}}")#text(" of ")#mi("{2^A}")#text(" with respect to the above equivalence relation. Define a distance ")#mi("{d: 2^A/\\sim \\times 2^A/\\sim \\rightarrow {\\bf R}^+}")#text(" between two equivalence classes ")#mi("{[E], [E^{\\prime}]}")#text(" by defining ")#mi("{d([E], [E^{\\prime}]) := m^*(E \\Delta E^{\\prime})}")#text(". Show that this distance is well-defined (in the sense that ")#mi("{m(E \\Delta E^{\\prime}) = m(F \\Delta F^{\\prime})}")#text(" whenever ")#mi("{[E]=[F]}")#text(" and ")#mi("{[E^{\\prime}]=[F^{\\prime}]}")#text(") and gives ")#mi("{2^A/\\sim}")#text(" the structure of a complete metric space.")],
[#text("Let ")#mi("{{\\mathcal E} \\subset 2^A}")#text(" be the elementary subsets of ")#mi("{A}")#text(", and let ")#mi("{{\\mathcal L} \\subset 2^A}")#text(" be the Lebesgue measurable subsets of ")#mi("{A}")#text(". Show that ")#mi("{{\\mathcal L}/\\sim}")#text(" is the closure of ")#mi("{{\\mathcal E}/\\sim}")#text(" with respect to the metric defined above. In particular, ")#mi("{{\\mathcal L}/\\sim}")#text(" is a complete metric space that contains ")#mi("{{\\mathcal E}/\\sim}")#text(" as a dense subset; in other words, ")#mi("{{\\mathcal L}/\\sim}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Completion_(metric_space)#Completion")[#text("metric completion")]#text(" of ")#mi("{{\\mathcal E}/\\sim}")#text(".")],
[#text("Show that Lebesgue measure ")#mi("{m: {\\mathcal L} \\rightarrow {\\bf R}^+}")#text(" descends to a continuous function ")#mi("{m: {\\mathcal L}/\\sim \\rightarrow {\\bf R}^+}")#text(", which by abuse of notation we shall still call ")#mi("{m}")#text(". Show that ")#mi("{m: {\\mathcal L}/\\sim \\rightarrow {\\bf R}^+}")#text(" is the unique continuous extension of the analogous elementary measure function ")#mi("{m: {\\mathcal E}/\\sim \\rightarrow {\\bf R}^+}")#text(" to ")#mi("{{\\mathcal L}/\\sim}")#text(".")]
)

#text("For a further discussion of how measures can be viewed as completions of elementary measures, see ")#link("https://terrytao.wordpress.com/2009/01/03/254a-notes-0a-an-alternate-approach-to-the-caratheodory-extension-theorem/")[#text("these notes")]#text(".")
]

#heading(level: 1)[#strong[#text(" — 4. Non-measurable sets — ")]]

#text("In the previous section we have set out a rich theory of Lebesgue measure, which enjoys many nice properties when applied to Lebesgue measurable sets.")

#text("Thus far, we have not ruled out the possibility that every single set is Lebesgue measurable. There is good reason for this: a ")#link("http://en.wikipedia.org/wiki/Solovay_model")[#text("famous theorem of Solovay")]#text(" asserts that, if one is willing to drop the axiom of choice, there exist models of set theory in which all subsets of ")#mi("{{\\bf R}^d}")#text(" are measurable. So any demonstration of the existence of non-measurable sets must use the axiom of choice in some essential way.")

#text("That said, we can give an informal (and highly non-rigorous) motivation as to why non-measurable sets should exist, using intuition from probability theory rather than from set theory. The starting point is the observation that Lebesgue sets of finite measure (and in particular, bounded Lebesgue sets) have to be “almost elementary”, in the sense of Exercise ")#link(<tao-98b37af37c6839d0f782>)[#text("16")]#text(". So all we need to do to build a non-measurable set is to exhibit a bounded set which is not almost elementary. Intuitively, we want to build a set which has oscillatory structure even at arbitrarily fine scales.")

#text("We will non-rigorously do this as follows. We will work inside the unit interval ")#mi("{[0,1]}")#text(". For each ")#mi("{x \\in [0,1]}")#text(", we imagine that we flip a coin to give either heads or tails (with an independent coin flip for each ")#mi("{x}")#text("), and let ")#mi("{E \\subset [0,1]}")#text(" be the set of all the ")#mi("{x \\in [0,1]}")#text(" for which the coin flip came up heads. We suppose for contradiction that ")#mi("{E}")#text(" is Lebesgue measurable. Intuitively, since each ")#mi("{x}")#text(" had a ")#mi("{50\\%}")#text(" chance of being heads, ")#mi("{E}")#text(" should occupy about “half” of ")#mi("{[0,1]}")#text("; applying the ")#link("http://en.wikipedia.org/wiki/Law_of_large_numbers")[#text("law of large numbers")]#text(" in an extremely non-rigorous fashion, we thus expect ")#mi("{m(E)}")#text(" to equal ")#mi("{1/2}")#text(".")

#text("Moreover, given any subinterval ")#mi("{[a,b]}")#text(" of ")#mi("{[0,1]}")#text(", the same reasoning leads us to expect that ")#mi("{E \\cap [a,b]}")#text(" should occupy about half of ")#mi("{[a,b]}")#text(", so that ")#mi("{m(E \\cap [a,b])}")#text(" should be ")#tao-math("{\\left|[a,b]\\right|/2}", block: false)#text(". More generally, given any elementary set ")#mi("{F}")#text(" in ")#mi("{[0,1]}")#text(", we should have ")#mi("{m(E \\cap F) = m(F)/2}")#text(". This makes it very hard for ")#mi("{E}")#text(" to be approximated by an elementary set; indeed, a little algebra then shows that ")#mi("{m(E \\Delta F) = 1/2}")#text(" for any elementary ")#mi("{F \\subset [0,1]}")#text(". Thus ")#mi("{E}")#text(" is not Lebesgue measurable.")

#text("Unfortunately, the above argument is terribly non-rigorous for a number of reasons, not the least of which is that it uses an uncountable number of coin flips, and the rigorous probabilistic theory that one would have to use to model such a system of random variables is too weak to be able to assign meaningful probabilities to such events as “")#mi("{E}")#text(" is Lebesgue measurable”. (For some further discussion of this point, see ")#link("https://terrytao.wordpress.com/2008/10/14/non-measurable-sets-via-non-standard-analysis/")[#text("this post")]#text(".) So we now turn to more rigorous arguments that establish the existence of non-measurable sets. The arguments will be fairly simple, but the sets constructed are somewhat artificial in nature.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 12")]#text(" There exists a subset ")#mi("{E \\subset [0,1]}")#text(" which is not Lebesgue measurable.")
]

#emph[#text("Proof:")]#text(" We use the fact that the rationals ")#mi("{{\\bf Q}}")#text(" are an additive subgroup of the reals ")#mi("{{\\bf R}}")#text(", and so partition the reals ")#mi("{{\\bf R}}")#text(" into disjoint cosets ")#mi("{x + {\\bf Q}}")#text(". This creates a quotient group ")#mi("{{\\bf R}/{\\bf Q} := \\{ x +{\\bf Q}: x \\in {\\bf R} \\}}")#text(". Each coset ")#mi("{C}")#text(" of ")#mi("{{\\bf R}/{\\bf Q}}")#text(" is dense in ")#mi("{{\\bf R}}")#text(", and so has a non-empty intersection with ")#mi("{[0,1]}")#text(". Applying the axiom of choice, we may thus find an element ")#mi("{x_C \\in C \\cap [0,1]}")#text(" for each ")#mi("{C \\in {\\bf R}/{\\bf Q}}")#text(". We then let ")#mi("{E := \\{ x_C: C \\in {\\bf R}/{\\bf Q} \\}}")#text(" be the collection of all these coset representatives. By construction, ")#mi("{E \\subset [0,1]}")#text(".")

#text("Let ")#mi("{y}")#text(" be any element of ")#mi("{[0,1]}")#text(". Then it must lie in some coset ")#mi("{C}")#text(" of ")#mi("{{\\bf R}/{\\bf Q}}")#text(", and thus differs from ")#mi("{x_C}")#text(" by some rational number in ")#mi("{[-1,1]}")#text(". In other words, we have ")#metadata(none) <tao-938db8c9f82c8cb58d3f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("[0,1] \\subset \\bigcup_{q \\in {\\bf Q} \\cap [-1,1]} (E + q).")]]

#text("On the other hand, we clearly have ")#metadata(none) <tao-6b51d431df5d7f141cbe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\bigcup_{q \\in {\\bf Q} \\cap [-1,1]} (E + q) \\subset [-1,2].")]]

#text("Also, the different translates ")#mi("{E+q}")#text(" are disjoint, because ")#mi("{E}")#text(" contains only one element from each coset of ")#mi("{{\\bf Q}}")#text(".")

#text("We claim that ")#mi("{E}")#text(" is not Lebesgue measurable. To see this, suppose for contradiction that ")#mi("{E}")#text(" was Lebesgue measurable. Then the translates ")#mi("{E+q}")#text(" would also be Lebesgue measurable. By countable additivity, we thus have")

#align(center)[#tao-fit-display[#mitex("m( \\bigcup_{q \\in {\\bf Q} \\cap [-1,1]} (E + q) ) = \\sum_{q \\in {\\bf Q} \\cap [-1,1]} m(E+q),")]]

#text("and thus by translation invariance and ")#link(<tao-938db8c9f82c8cb58d3f>)[#text("(5)")]#text(", ")#link(<tao-6b51d431df5d7f141cbe>)[#text("(6)")]

#align(center)[#tao-fit-display[#mitex("1 \\leq \\sum_{q \\in {\\bf Q} \\cap [-1,1]} m(E) \\leq 3.")]]

#text("On the other hand, the sum ")#mi("{\\sum_{q \\in {\\bf Q} \\cap [-1,1]} m(E)}")#text(" is either zero (if ")#mi("{m(E)=0}")#text(") or infinite (if ")#mi("{m(E)>0}")#text("), leading to the desired contradiction. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 25 (Outer measure is not finitely additive)")]#text(" Show that there exists disjoint bounded subsets ")#mi("{E, F}")#text(" of the real line such that ")#mi("{m^*(E \\cup F) \\neq m^*(E) + m^*(F)}")#text(". (")#emph[#text("Hint:")]#text(" Show that the set constructed in the proof of the above proposition has positive outer measure.)")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 26 (Projections of measurable sets need not be measurable)")]#text(" ")#metadata(none) <tao-fd03c3b4c6526cf1ef7c>#text(" Let ")#mi("{\\pi: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" be the coordinate projection ")#mi("{\\pi(x,y) := x}")#text(". Show that there exists a measurable subset ")#mi("{E}")#text(" of ")#mi("{{\\bf R}^2}")#text(" such that ")#mi("{\\pi(E)}")#text(" is not measurable.")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 10")]#text(" The above discussion shows that, in the presence of the axiom of choice, one cannot hope to extend Lebesgue measure to arbitrary subsets of ")#mi("{{\\bf R}}")#text(" while retaining both the countable additivity and the translation invariance properties. If one drops the translation invariant requirement, then this question concerns the theory of ")#link("http://en.wikipedia.org/wiki/Measurable_cardinal")[#text("measurable cardinals")]#text(", and is not decidable from the standard ZFC axioms. On the other hand, one can construct ")#emph[#text("finitely additive")]#text(" translation invariant extensions of Lebesgue measure to the power set of ")#mi("{{\\bf R}}")#text(" by use of the ")#link("http://en.wikipedia.org/wiki/Hahn%E2%80%93Banach_theorem")[#text("Hahn-Banach theorem")]#text(" to extend the integration functional, though we will not do so here.")
]

#text("(Below are some miscellaneous exercises that were added after the main notes were written; I have not moved it up into a better place so as not to disturb the existing exercise numbering.)")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 27")]#text(" Define a ")#emph[#text("continuously differentiable curve")]#text(" in ")#mi("{{\\bf R}^d}")#text(" to be a set of the form ")#mi("{\\{ \\gamma(t): a \\leq t \\leq b\\}}")#text(" where ")#mi("{[a,b]}")#text(" is a closed interval and ")#mi("{\\gamma: [a,b] \\rightarrow {\\bf R}^d}")#text(" is a ")#link("http://en.wikipedia.org/wiki/Smooth_function")[#text("continuously differentiable")]#text(" function.")

#list(
[#text("If ")#mi("{d \\geq 2}")#text(", show that every continuously differentiable curve has Lebesgue measure zero. (Why is the condition ")#mi("{d \\geq 2}")#text(" necessary?)")],
[#text("Conclude that if ")#mi("{d \\geq 2}")#text(", then the unit cube ")#mi("{[0,1]^d}")#text(" cannot be covered by countably many continuously differentiable curves.")]
)

#text("We remark that if the curve is only assumed to be continuous, rather than continuously differentiable, then these claims fail, thanks to the existence of ")#link("http://en.wikipedia.org/wiki/Space-filling_curve")[#text("space-filling curves")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Exercise 28 (Tonelli’s theorem for series over arbitrary sets)")]#text(" ")#metadata(none) <tao-789fb9deac879d62eee9>#text(" Let ")#mi("{A, B}")#text(" be sets (possibly infinite or uncountable), and ")#mi("{(x_{n,m})_{n \\in A, m \\in B}}")#text(" be a doubly infinite sequence of extended non-negative reals ")#mi("{x_{n,m} \\in [0,+\\infty]}")#text(" indexed by ")#mi("{A}")#text(" and ")#mi("{B}")#text(". Show that")

#align(center)[#tao-fit-display[#mitex("\\sum_{(n,m) \\in A \\times B} x_{n,m} = \\sum_{n \\in A} \\sum_{m \\in B} x_{n,m} = \\sum_{m \\in B} \\sum_{n \\in A} x_{n,m}.")]]

#text("(")#emph[#text("Hint:")]#text(" although not strictly necessary, you may find it convenient to first establish the fact that if ")#mi("{\\sum_{n \\in A} x_n}")#text(" is finite, then ")#mi("{x_n}")#text(" is non-zero for at most countably many ")#mi("{n}")#text(".)")
]

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (168)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-226773")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2013")])]

#text("I think there is another method to prove the Countable")#linebreak()#text(" subadditivity(Exercise 4,(3)).")

#text("1.First,It is easy to verify that if ")#mi("E_1, E_2, \\cdots \\subset \\mathbf {R}")#text(" is a")#linebreak()#text(" countable sequence of sets,and ")#mi("\\forall i\\neq j")#text(",there exists open")#linebreak()#text(" boxes ")#mi("A_i,A_j")#text(",such that ")#mi("E_i\\subset A_i,E_j\\subset A_j")#text(",and ")#mi("A_i\\bigcap A_j=\\emptyset")#text(",Then we have")

#mi("\\displaystyle m^*( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty m^*(E_n)")#text(".")

#text("2.Then,based on the conclusion in 1,we can prove that if ")#mi("E_1, E_2, \\cdots \\subset \\mathbf {R}")#text(" is a")#linebreak()#text(" countable sequence of sets,and there exists ")#mi("i,j")#text(",for any open box")#linebreak()#text(" ")#mi("A_i")#text(" that covers ")#mi("E_i")#text(",")#mi("A_j")#text(" covers ")#mi("E_j")#text(",we must have")#linebreak()#text(" ")#mi("A_i\\bigcap A_j\\neq\\emptyset")#text(".")

#text("Then we must have ")#mi("\\displaystyle m^*( \\bigcup_{n=1}^\\infty E_n ) < \\sum_{n=1}^\\infty m^*(E_n)")#text(" if ")#mi("m^*( \\bigcup_{n=1}^\\infty E_n )")#text(" is finite,we must have")

#mi("\\displaystyle m^*( \\bigcup_{n=1}^\\infty E_n ) = \\sum_{n=1}^\\infty m^*(E_n)")#text(" if ")#mi("m^*( \\bigcup_{n=1}^\\infty E_n )")#text(" is infinite.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227016")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2013")])]

#text("A remark to Lemma 8:")

#text("“Let ")#mi("E\\subset \\mathbf{R}^d")#text(" be an open set. Then ")#mi("E")#text(" can be expressed as the countable union of almost disjoint boxes (and, in fact, as the countable union of almost disjoint closed cubes).”")

#text("I think that the following is also true:")

#text("Let ")#mi("E\\subset \\mathbf{R}^d")#text(" be an open set. Then ")#mi("E")#text(" can be expressed UNIQUELY as the countable union of disjoint open boxes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227019")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2013")])]

#text("A remark to Lemma 9(outer regularity)")

#text("Outer regularity can also be stated as this way,which is also the way I prefer:")

#mi("\\displaystyle m^*(\\bigcup_{j\\in \\mathbb{N}^+}E_j)=\\lim_{N\\to\\infty}m^*(\\bigcup_{j=1}^{N}E_j)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227158")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2013")])]

#text("A remark to lemma 11(countable additivity),(2).")

#text("This lemma tells us the simple fact that disjoint Lebesgue measurable sets has the property of countable additivity,the proof,however,is rather tough,and long.")

#text("When faced with such a proof,I usually do not like to read it,because even though I read it,the proof still belongs to the one who find out it.Mathematics,do not like other subjects such as language——Even if you see a proof many times , it still do not belongs to you.In order to truely understand a proof,you have to find it out yourself,or,if the proof is so hard that it does not worth to invest too much time in it, at least you should try to simplify it or rewrite it in your own way,or decompose it in simpler steps.")

#text("So I find a proof myself,I think my proof is a bit simpler than Mr.Tao’s proof.Now let me start the proof.")

#text("As a preliminary,I have already proved that a set is L-measurable iff it satisfy the Carathéodory criterion.")

#text("Let ")#mi("T=\\bigcup_{j\\in \\mathbf{N}^+}E_j")#text(",We first prove that ")#mi("T")#text(" is L-measurable,that is ,according to Caratheodory criterion,")#mi("\\forall A\\in\\mathbf{R}^d")#text(",")#mi("m^*(A)=m^*(A\\backslash T)+m^*(A\\bigcap T)")#text(".")

#text("According to the sub-additivity property of outer measure,we know that ")#mi("m^*(A)\\leq m^*(A\\backslash T)+m^*(A\\bigcap T)")#text(",so we only need to prove that ")#mi("m^*(A)\\geq m^*(A\\backslash T)+m^*(A\\bigcap T)")#text(".")

#text("According to the Morgan law,we just need to prove that")

#mi("\\displaystyle m^*(A)\\geq m^*(A\\backslash T)+m^*(\\bigcup_{j\\in \\mathbf{N}^+}(A\\bigcap E_j))")#text(".")

#text("According to the outer regularity(Lemma 9,see also my comment ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/#comment-227019")[#text("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/#comment-227019")]#text(" ),we just need to prove that")

#mi("\\displaystyle m^*(A)\\geq m^*(A\\backslash T)+\\lim_{N\\to\\infty}m^*((\\bigcup_{i=1}^N(A\\bigcap E_i)))")#text(".")

#text("According to the Monotonicity property of outer measure,we know that ")#mi("\\displaystyle m^*(A\\backslash T)+\\lim_{N\\to\\infty}m^*(\\bigcup_{i=1}^N(A\\bigcap E_i))\\leq m^*(A\\backslash \\lim_{N\\to\\infty}(\\bigcup_{j=1}^NE_j))+\\lim_{N\\to\\infty}m^*(\\bigcup_{i=1}^N(A\\bigcap E_i))")#text(".")

#text("So we just need to prove that")

#mi("\\displaystyle m^*(A)\\geq m^*(A\\backslash \\lim_{N\\to\\infty}(\\bigcup_{j=1}^NE_j))+\\lim_{N\\to\\infty}m^*((\\bigcup_{i=1}^N(A\\bigcap E_i)))")#text("………….(1)")

#text("According to the L-measurability of ")#mi("E_j")#text("(together with the mathematical induction),we know that")

#mi("\\displaystyle m^*(A)=m^*(A\\backslash \\lim_{N\\to\\infty}(\\bigcup_{j=1}^NE_j))+\\lim_{N\\to\\infty}m^*(A\\bigcap(\\bigcup_{i=1}^NE_i))")#text(",")

#text("so (1) holds.So ")#mi("T")#text(" is L-measurable.Now we prove that")

#mi("\\displaystyle m(\\bigcup_{j\\in \\mathbf{N}^+}E_j)=\\sum_{j\\in \\mathbf{N}^+}m(E_j)")#text(".")

#text("According to the outer regularity(Lemma 9,see also my comment ")#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/#comment-227019")[#text("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/#comment-227019")]#text(" ),we have")

#mi("\\displaystyle m(\\bigcup_{j\\in \\mathbf{N}^+}E_j)=\\lim_{N\\to\\infty}m^*(\\bigcup_{j=1}^NE_j)")#text(".")

#text("Then according to the finite additivity of disjoint L-measurable sets(The finite additivity of disjoint L-measurable sets can be easily proved by using Caratheodory criterion together with the mathematical induction.),we have ")#mi("\\displaystyle m(\\bigcup_{j\\in J}E_j)=\\lim_{N\\to\\infty}m^*(\\bigcup_{j=1}^NE_j)=\\lim_{N\\to\\infty}\\sum_{j=1}^Nm^*(E_j)")#text(".")

#text("Done.")#mi("\\Box")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227245")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2013")])]

#text("———-")#linebreak()#text(" A remark to Exercise 11,(2),(Downward")#linebreak()#text(" monotone convergence) .")

#text("It seems that the condition here is stronger than in Mr.Tao’s book")#linebreak()#text(" “Analysis”,exercise 18.2.3.")

#text("In that book,the Downward monotone convergence theorem is stated as")#linebreak()#text(" follows:")

#text("Show that if ")#mi("A_1\\supseteq A_2\\supseteq A_3\\cdots")#text(" is a decreasing")#linebreak()#text(" sequence of measurable sets,and ")#mi("m(A_1)\\prec +\\infty")#text(",then we have")#linebreak()#text(" ")#mi("m(\\bigcap_{j=1}^{\\infty}A_j)=\\lim_{j\\to\\infty}m(A_j)")#text(".")

#text("At that time,my proof to that exercise is stated as follows:")#linebreak()#text(" ——————————–")

#text("Firstly,by the ")#mi("\\sigma-")#text(" algebra property,we know that")#linebreak()#text(" ")#mi("m(\\bigcap_{j=1}^{\\infty}A_j)")#text(" is measurable.")

#text("Then,it is easy to verify that ")#mi("\\displaystyle A_1\\backslash\\bigcup_{i=1}^{\\infty}(A_i\\backslash A_{i+1})=\\bigcap _{i=1}^{\\infty}A_i")#text(".So ")#mi("\\displaystyle m(A_1\\backslash\\bigcup_{i=1}^{\\infty}(A_i\\backslash A_{i+1}))=m(\\bigcap_{i=1}^{\\infty}A_i)")#text(".")

#text("According to the finite additivity of disjoint measurable sets,we have")#linebreak()#text(" ")#mi("\\displaystyle m(A_1\\backslash\\bigcup_{i=1}^{\\infty}(A_i\\backslash A_{i+1}))=m(A_1)-m(\\bigcup_{i=1}^{\\infty}(A_i\\backslash A_{i+1}))")#text(".")#linebreak()#text(" (")#mi("m(A_1)")#text(" is finite,so the operation of minus makes sense).")

#text("According to Exercise 11,(1)(Upward monotone convergence),we have")#linebreak()#text(" ")#mi("\\displaystyle m(\\bigcup_{i=1}^{\\infty}(A_i\\backslash A_{i+1}))=m(A_1)-\\lim_{j\\to\\infty}(A_j)")#text(",so ")#mi("\\displaystyle m(\\bigcap_{j=1}^{\\infty}A_j)=m(A_1\\backslash\\bigcup_{i=1}^{\\infty}(A_i\\backslash A_{i+1}))=\\lim_{j\\to\\infty}A_j")#text(".")

#text("————————-")

#text("But,surprizingly,the condition in Exercise 11,(2) is a bit")#linebreak()#text(" stronger than in Mr.Tao’s book,")#mi("m(A_1)")#text(" does not need to be")#linebreak()#text(" finite,in the case of when ")#mi("m(A_1)")#text(" is not finite,")#mi("m(A_j)(j\\geq 2)")#text(" is")#linebreak()#text(" finite,the theorem also holds!")

#text("So I think I need to change my proof a bit to prove this stronger")#linebreak()#text(" theorem.Now I figure out it,I even do not need to change my")#linebreak()#text(" proof,because ”the stronger theorem” only make use of the fact that")#linebreak()#text(" the first finite elements of a sequence do not affect its limit!HaHaHaHa…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227380")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2013")])]

#text("A remark to Exercise 13,(1).")

#text("This exercise is stated as follows:")

#text("“Show that if the ")#mi("E_n")#text(" are all Lebesgue measurable, and converge pointwise to ")#mi("E")#text(" , then ")#mi("E")#text(" is Lebesgue measurable also.”")

#text("I love this exercise,because this exercise makes me think again about the distinction between the uniform convergence and pointwise convergence.")

#text("I think uniform convergence correspond to the finite intersection of sets,and pointwise convergence correspond to the infinite(countable or uncountable) intersection of sets.")

#text("In this particular exercise,pointwise convergence correspond to the countable intersection of sets(Because ")#mi("(E_n)_{n=1}^{\\infty}")#text(" is countable).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227390")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2013")])]

#text("A remark to Exercise 15,(inner regularity).")

#text("Inner regularity is just a counterpart to outer regularity.Just consider the complement of the measurable set ")#mi("E")#text(" will be enough.")

#text("But now I still have something to think.In the case of outer regularity(lemma 9),why ")#mi("U")#text(" has to be open?")

#text("Open set.I frequently see open set in real analysis.Why open set?I think one reason mathematician like open set,is that,open set has a good property:")

#text("Every open set in ")#mi("\\mathbf{R}^d")#text(" can be expressed uniquely into at most countable union of open boxes.")

#text("This property makes us define the outer measure more conveniently.Because it is easy to define the volume of at most countable union of open boxes.")

#text("So if we don’t use open set in outer measure,to reach the same effect,we have to use at most countable union of elementary boxes instead,this becomes more inconvenient in language.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227431")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")])]

#text("A remark to Exercise 21:")

#text("In my comment ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/#comment-226452,I")[#text("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/#comment-226452,I")]#text(" have proved this result in the case of Jordan measure.")

#text("Now I begin to prove this result in the case of Lebesgue measure.Of course,I will try to base my argument on my proof in the case of Jordan measure.")

#text("So the proof becomes simple,based on two facts:")

#text("1.A Lebesgue measurable set can be arbitrarily approximated by a Jordan measurable set.")

#text("2.A linear transformation from ")#mi("\\mathbf{R}^d")#text(" to itself will not transform a set whose outer measure is very small to a set whose outer measure is far larger.")

#text("Fact 1 can be easily proved by the definition of Lebesgue measure.")

#text("Fact 2 can be easily proved by the change of variables formula in Jordan measure.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227538")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2013")])]

#text("In fact,I think if there is no irrationional number in mathematical world,i.e,there exists only rational number system in mathematics,then Jordan measure will be enough,and we don’t need Lebesgue measure.")

#text("Unfortunately(Or fortunately?),there is real number system,so we need Lebesgue measure.")

#text("Jordan measure is suitable for ")#mi("\\mathbf{Q}")#text(" ,Lebesgue measure is suitable for ")#mi("\\mathbf{R}")#text(".")

#text("So if we only use Jordan measure in ")#mi("\\mathbf{R}")#text(",that will be not enough.")

#text("Jordan measure is dense,but Lebesgue measure is complete!")

#text("Complete stuff is real infinity,and dense stuff is not real infinity.Like a natural number,a natural number is finite,but the set of all the natural number is infinite!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-227612")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 4 May 2013")])]

#text("A remark to Exercise 27:")#linebreak()#text(" ———–")#linebreak()#text(" What is the use of the condition “continuously differentiable” ?")

#text("Continuously differentiable reminds of the motion of a mass point in physics.")#mi("S(t)")#text(" is continuously differentiable.")

#text("Maybe with this condition,we can compute the length of the curve?Does a curve which has length in higher dimensional space has outer measure zero?What does a curve which has length mean?")#linebreak()#text(" ———–")

#text("The above is what I thought when I didn’t know how to solve this problem.Now I figure out it,the condition “continuously differentiable” enable us to approximate this curve by a polygonal line very well!Note that “continuous” is also needed,otherwise,the curve may change so rapidly in an arbitrarily small scale that we can not approximate it well by using polygonal line.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-355048")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2014")])]

#text("in the remark, ")#mi("\\displaystyle m_{*,(J)}(E) \\leq m^*(E) \\leq m^{*,(J)}(E) \\ \\ \\ \\ \\ (3)")#text(", do we have all the combinations of these inequalities?")

#mi("E=Q\\cap[0,1]")#text(" gives ")#mi("\\displaystyle m_{*,(J)}(E) = m^*(E)  < m^{*,(J)}(E)")#text(" and when ")#mi("E")#text(" is a Jordan measurable set, we have the equalities. I don’t have examples for")#linebreak()#text(" ")#mi("\\displaystyle m_{*,(J)}(E)  < m^*(E)  < m^{*,(J)}(E)")#linebreak()#text(" and")#linebreak()#text(" ")#mi("\\displaystyle m_{*,(J)}(E)  < m^*(E)  = m^{*,(J)}(E)")#text(".")

#emph[#text("[Experiment with Boolean combinations of your original example ")#mi("{\\bf Q} \\cap [0,1]")#text(", e.g. taking complements in ")#mi("[0,1]")#text(", or taking unions or other combinations with translates ")#mi("{\\bf Q} \\cap [2,3]")#text(" of your original example. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-355060")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2014")])]

#text("I don’t quite understand the following remark:")

#text("“one does not gain any increase in power in the Jordan inner measure by replacing finite unions of boxes with countable ones.”")

#text("– Does “increase in power” for Lebesgue outer measure (which is defined by replacing finite unions of boxes with countable ones in Jordan out measure) refer to countable subadditivity?")#linebreak()#text(" – The asymmetry “ultimately arises from the fact that elementary measure is subadditive rather than superadditive”. Could you elaborate this point further?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-355165")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 May 2014")])]

#text("If one tries to define a “Lebesgue inner measure” by naive analogy with Lebesgue outer measure, that is to say by taking the sup over all countable collections of disjoint boxes inside the set, one gets exactly the same measure as Jordan inner measure. In contrast, the Lebesgue outer measure can be significantly smaller than the Jordan outer measure, and thus come much closer to measuring the “true” size of the set. In particular, Lebesgue outer measure gives the “correct” answer for the measure of a set far more often than Jordan inner or outer measure, which is what I mean by power (and countable subadditivity is of course further confirmation of this fact).")

#text("For the final remark, I am referring to the basic fact that if E and F are elementary sets (possibly overlapping), then we have the subadditivity property ")#mi("m(E \\cup F) \\leq m(E) + m(F)")#text(", but not the superadditivity property ")#mi("m(E \\cup F) \\geq m(E) + m(F)")#text(". This creates an asymmetry between lower and upper bounds, which is ultimately why Lebesgue outer measure obeys a useful countable subadditivity property, whereas “Lebesgue inner measure” as naively defined above enjoys no comparable property.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-356063")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")])]

#text("The conclusion in Exercise 6 seems very unnatural: on one side of the equality, ")#mi("E")#text(" is approximated by finite union of boxes from inside; one the other side, it is approximated by countable union of boxes from outside. Does the asymmetry here arise from the same fact?")

#text("In the elementary and Jordan measure theory (and Riemann integration), one can see the symmetry such as inner and outer measure, lower and upper integral and the terms “measurable”, “integrable” are defined when the “symmetric” concepts are equal to each other. Can one say that in Lebesgue measure and integration theory, such symmetry does not exist any more (one does have the correct version of the Lebesgue inner measure though, things are note defined as “when lower and upper or inner and outer stuffs match with each other…”) and it is this asymmetry that makes the Lebesgue theory more “powerful” than the Riemann integration theory?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-356042")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")])]

#text("I don’t see why “If one tries to define a “Lebesgue inner measure” by naive analogy with Lebesgue outer measure, one gets exactly the same measure as Jordan inner measure”.")

#text("Let ")#tao-math("\\displaystyle m_*(E):=\\sup_{\\cup_n^\\infty B_n\\subset E} \\sum_{n=1}^\\infty \\left|B_n\\right|", block: false)#text(" for any ")#mi("E\\subset{\\bf R}^d")#text(" be the naive definition. I’m trying to show as you said that")#linebreak()#text(" ")#mi("\\displaystyle m_*(E)=m_{*,(J)}(E)")#text(".")

#text("The direction ")#mi("m_*(E)\\geq m_{*,(J)}(E)")#text(" is obvious since one can replace the finite union with the infinite one using empty sets. I don’t see why ")#mi("m_*(E)\\leq m_{*,(J)}(E)")#text(" is true. I thought Lemma 7 might be useful since one could have the estimate")#linebreak()#text(" ")#tao-math("\\displaystyle m_*(E)-\\epsilon\\leq\\sum^\\infty_{n=1}\\left|B_n\\right|=m^*(\\cup_{n=1}^\\infty B_n)", block: false)#linebreak()#text(" ")#mi("\\displaystyle \\leq m^*(A)=m(A)\\leq m_{*,(J)}(E)")#text(" if one has the elementary set ")#mi("A")#text(" such that")#linebreak()#text(" ")#mi("\\displaystyle \\cup_{n=1}^\\infty B_n\\subset A\\subset E")#text(". But I don’t see why such ")#mi("A")#text(" exists.")

#text("Could you explain why one can achieve the second inequality?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-356065")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2014")])]

#text("For any ")#tao-math("X < \\sum_{n=1}^\\infty \\left|B_n\\right|", block: false)#text(", one can find ")#mi("N")#text(" such that ")#tao-math("\\sum_{n=1}^N \\left|B_n\\right| \\geq X", block: false)#text(". For instance, if ")#tao-math("\\sum_{n=1}^\\infty \\left|B_n\\right|", block: false)#text(" is finite, one can find ")#mi("N")#text(" such that ")#tao-math("\\sum_{n=1}^N \\left|B_n\\right| \\geq \\sum_{n=1}^\\infty \\left|B_n\\right| - \\varepsilon", block: false)#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2db4e13bf72ac3dc4006cf1adbed9a11452a63260eaddd23b3aa342d9f7eefc6-36f95523c8ddea955f4c66b5976eb3d5cdf8ae5a2de365e21525219312efb569.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Peter")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-359210")[#strong[#text("Peter")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2014")])]

#text("I don’t see why “If one tries to define a “Lebesgue inner measure” by naive analogy with Lebesgue outer measure, one gets exactly the same measure as Jordan inner measure”. Let \\displaystyle m_*(E):=\\sup_{\\cup_n^\\infty B_n\\subset E} \\sum_{n=1}^\\infty |B_n| for any E\\subset{\\bf R}^d be the naive definition. I’m trying to show as you said that […]")

#text("For any X < \\sum_{n=1}^\\infty |B_n|, one can find N such that \\sum_{n=1}^N |B_n| \\geq X. For instance, if \\sum_{n=1}^\\infty |B_n| is finite, one can find N such that \\sum_{n=1}^N |B_n| \\geq \\sum_{n=1}^\\infty |B_n| – \\vvarepsilon.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-359231")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 June 2014")])]

#text("An infinite sum ")#mi("\\sum_{n=1}^\\infty x_n")#text(" of non-negative quantities ")#mi("x_n")#text(" is the least upper bound of its partial sums ")#mi("\\sum_{n=1}^N x_n")#text(".")

#text("Also, to define inner measure in a reasonable way in this fashion, one would have to insist that the ")#mi("B_n")#text(" are disjoint or almost disjoint (if one could re-use the same box over and over again, then any set with non-trivial interior would have infinite inner measure.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 0: Foundations of probability theory | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-459864")[#strong[#text("275A, Notes 0: Foundations of probability theory | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 29 September 2015")])]

#text("[…] to say products of closed intervals. The construction of Lebesgue measure is a little tricky; see this previous blog post for […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 275A, Notes 2: Product measures and independence | What's new")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-460459")[#strong[#text("275A, Notes 2: Product measures and independence | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 12 October 2015")])]

#text("[…] We would like to extend to a countably additive probability measure on . The standard approach to do this is via the Carathéodory extension theorem in measure theory (or the closely related Hahn-Kolmogorov theorem); this approach is presented in these previous lecture notes, and a similar approach is taken in Durrett. Here, we will try to avoid developing the Carathéodory extension theorem, and instead take a more direct approach similar to the direct construction of Lebesgue measure, given for instance in these previous lecture notes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f855f110e556629543c52fe3ce1bd1037f07339c6a0ccd496876afcdf4143cc-4084d407bc10ac2a78153a58f3ca31f635ad33a02b07598f6b48150f0260faca.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dr. Bob")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-461913")[#strong[#text("Dr. Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 15 November 2015")])]

#text("Pls i need more explanations and examples on how to compute lebegue outer measure of a set. Thank")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-467329")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 March 2016")])]

#text("A bounded function on a compact interval ")#mi("[a, b]")#text(" is Riemann integrable if and only if it is continuous almost everywhere. Is this true for ")#mi("f:{\\bf R^n}\\to{\\bf R}")#text(" in general?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-478978")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 March 2017")])]

#text("I’m trying to understand Axiom 3 and Corollary 4. Without AC, is ZF enough to give the” axiom of finite choice”? For instance suppose ")#mi("f:\\mathbb{R}\\to B")#text(" is onto, where ")#mi("B")#text(" is finite. Can we *prove* without AC that there is a function ")#mi("g:B\\to\\mathbb{R}")#text(" such that ")#mi("f(g(b))=b")#text(" for each ")#mi("b\\in B")#text(".")

#emph[#text("[Finite choice can be proven without AC by induction on the cardinality of ")#mi("B")#text(". -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-483062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2017")])]

#text("What would be the trade-off for Definition 1 of Lebesgue measure? As you said under definition 1, Littlewood’s first principle is almost trivial. What’s the cost? What would be the advantage of the one using Carathéodory criterion? How about the one using Riesz representation theorem?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-483078")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2017")])]

#text("Regarding Exercise 8, is there a reason why we use open sets for the outer approximation and closed sets for the inner approximation but not the other way around (closed sets for the outer and open sets for the inner)? In the Definition 1 of Lebesgue measures, can we use closed ")#mi("U")#text(" containing ")#mi("E")#text(" instead?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-485449")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2017")])]

#text("In the proof of Lemma 10(ii), does one have to reduce to the case when ")#mi("E")#text(" is compact? In order to apply Exercise 5, one only needs one of the sets being compact. On the other hand the finite union of the closed cubes ")#mi("Q_j")#text(" is compact.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-485541")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2017")])]

#text("If ")#mi("E")#text(" is non-compact then it becomes possible for ")#mi("m^*(E)")#text(" to be infinite, and so one cannot easily cancel it at the end of the proof of Lemma 10(ii).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-485555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2017")])]

#text("I have a dumb question that I don’t know how to answer it myself. The inner regularity and out regularity imply that given any measurable set ")#mi("E\\subset{\\bf R}^d")#text(" and ")#mi("\\varepsilon>0")#text(", there exists an open set ")#mi("O\\supset E")#text(" and a closed set ")#mi("F\\subset E")#text(" such that")#linebreak()#text(" ")#mi("\\displaystyle m(O\\setminus E)\\leq \\varepsilon")#linebreak()#text(" and")#linebreak()#text(" ")#mi("\\displaystyle m(E\\setminus F)\\leq \\varepsilon")

#text("Is it still true if we switch “open” and “closed” in the statement above? (Do we have approximation by open sets from inside and closed sets from outside?)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-485605")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2017")])]

#text("Hint: try to think of a set which is “large” but contains no open sets (i.e. has empty interior). Or, conversely, think of a set which is “small” but has huge closure.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-488643")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("How should one understand “large” and “small” in the hint? In terms of cardinality or something else?")

#text("The first/only thing that has empty interior I can come up with is the Cantor set ")#mi("C")#text(". But it seems that it could not be a desired example: there indeed exists an open set ")#mi("O")#text(" (namely the empty set) contained in ")#mi("C")#text(" such that ")#mi("m(C\\backslash O)\\leqslant\\varepsilon")#text(". Also since ")#mi("C")#text(" is closed, one has ")#mi("m(F\\backslash C)=0\\leqslant\\varepsilon")#text(". :-(")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-488650")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 November 2017")])]

#text("Second hint: a set has no interior if and only if its complement is dense.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-485557")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 August 2017")])]

#text("Exercise 20 is done in Stein-Shakarchi by approximation of open sets. Is it possible to use the monotone class theorem, which is in later notes? Would it be a circular argument?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-485606")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 August 2017")])]

#text("Try it! The proof of the monotone class lemma is not exceedingly difficult, and does not require the construction of Lebesgue measure.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/421d1bc187822d1a425403c66768a0e4bc4bb7ae836128fffed2def83958afbc-32201946d05599d122add0dd8f4faf3cd32916378a0cb7d2554da8d3199319d6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of haonanz")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-488092")[#strong[#text("haonanz")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2017")])]

#text("Hello Prof. Tao, This might be a really trivial thing. But In the proof of lemma 8, wouldn’t it be more necessary to show that ")#mi("{{\\mathcal Q}^*}")#text(" is actually non-empty? I think intuitively it would be true, as I was thinking about an open interval case in ")#mi("\\mathbb{R}")#text(", but I am not sure how to show this for an arbitrary open set in ")#mi("\\mathbb{R}^d")#text(". Thanks,")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-488102")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 October 2017")])]

#text("Actually, ")#mi("{\\mathcal Q}^*")#text(" will be empty if and only if ")#mi("E")#text(" is empty, since (as shown in the proof) ")#mi("E")#text(" will be the union of all the cubes in ")#mi("{\\mathcal Q}^*")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-488935")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 17 November 2017")])]

#text("Given a bounded subset ")#mi("E")#text(" of ")#mi("{\\bf R}^d")#text(", it is not necessarily true that ")#mi("E")#text(" can be written as a countable union of Jordan measurable sets since there exits bounded non-Lebesgue measurable sets and any Jordan measurable sets are Lebesgue measurable.")

#text("In this argument, one would have to use the axiom of choice since one needs a non-Lebesgue measurable set.")

#text("Is it possible without using AC to show that any bounded set is not necessarily a countable union of Jordan measurable sets?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7bd79ccc17907103f59d86fb20316d47cd1b97b6e5da97c6784bb34597ecff0-0d4f3e22196665cd23c0b63eb88a1c5d6701288f8a5ee038d7b21ba2ca261e47.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Confused Student")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-521248")[#strong[#text("Confused Student")]]#text(size: 9pt, fill: rgb("596477"), " · 3 September 2019")])]

#text("One thing that is puzzling me is whether or not there an assumption that ")#mi("\\mathbb{R}^n")#text(" is equipped with the Euclidean distance metric when defining the Lebesgue Measure.")

#text("It feels like this is the case, but it is never explicitly stated. For instance if we equip ")#mi("\\mathbb{R}^n")#text(" with a different metric, say one based on the infinity norm, then we can still define the Lebesgue measure on that space, but now volumes have the property that they are invariant under isometries of the plane, whereas the underlying distance metric is not.")

#text("Thought?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-521297")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 September 2019")])]

#text("Good questions! Usually, ")#mi("{\\bf R}^n")#text(" is understood to be n-dimensional Euclidean space, and in particular is indeed equipped with the Euclidean metric. If one wanted to explicitly omit this structure, one should probably talk about an “")#mi("n")#text("-dimensional real vector space” or something similar instead of ")#mi("{\\bf R}^n")#text(".")

#text("On the other hand, it is true that every locally compact abelian group comes with a ")#link("https://en.wikipedia.org/wiki/Haar_measure")[#text("Haar measure")]#text(", which is unique up to multiplication by scalars. In the case of Euclidean space ")#mi("{\\bf R}^n")#text(", Lebesgue measure is the unique Haar measure ")#mi("m")#text(" that obeys the normalisation ")#mi("m([0,1]^n)=1")#text("; see Exercise 23 of this blog post. In other words, the only role that the Euclidean metric really plays in the definition of Lebesgue measure is in defining the set used to normalise Lebesgue measure, in this case the unit cube. One could use a different set for this normalisation, for instance one could define two-dimensional Lebesgue measure to be the unique Haar measure that assigns a measure of ")#mi("\\pi")#text(" to the unit disk ")#tao-math("\\{ x \\in {\\bf R}^2: \\left\\|x\\right\\| \\leq 1 \\}", block: false)#text(". (This may seem like an idiosyncratic way to define Lebesgue measure, but it has some advantages, for instance it makes it instantly obvious that Lebesgue measure is rotation-invariant.) More generally, one could define Lebesgue measure using the unit ball in one’s favourite norm on ")#mi("{\\bf R}^n")#text(", although the computation of the Lebesgue measure of such a ball may require some effort.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/206e8e1564fe2cc6d2a809779f3b0ce6c8ea77089adc6ea301f54990fa9b4cd7-a4c3307de364cd36c296fdf9920dc0344b0d718fed9a92128240fecf644311a5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sin")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-641642")[#strong[#text("sin")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2022")])]

#text("Dear Professor Tao:")#linebreak()#text(" For exercise 1.2.25 in the book (continuously differentiable curves), can we say that the condition ")#mi("d \\geq 2")#text(" is there to ensure that when we cover the curve by d-dimensional balls (boxes), though more is required for smaller balls (or boxes), the positive effect of “adding up many quantities” is exceeded by the ability to shrink each quantity by a greater factor, so that one is still able to upper bound the total volume?")

#emph[#text("[Yes. Also for ")#mi("d=1")#text(" there are easy counterexamples – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686843")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2024")])]

#text("Dear professor Tao:")

#text("In the proof of Lemma 10 the sentence “The claim now follows from (ii), (iii), (iv).” should be “The claim now follows from (ii), (iii), (vi)”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686864")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2024")])]

#text("Dear professor Tao:")

#text("To show that a Lebesgue measurable set ")#mi("E")#text(" is almost dyadically elementary, we outer approximate ")#mi("E")#text(" by an open set ")#mi("U")#text(" to within epsilon, writing ")#mi("U")#text(" as a countable union of dyadic cubes, and extract a finite union ")#mi("A")#text(" of these cubes such that ")#mi("m(A)")#text(" is within epsilon of ")#mi("m(U)")#text(". but then it’s unclear to me how this construction makes the scale ")#mi("n")#text(" be dependent on epsilon. Can provide some comment in this regard?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686871")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2024")])]

#text("Break up larger cubes into smaller cubes. Also, the exercise does not claim that ")#mi("n")#text(" will be independent of ")#mi("\\varepsilon")#text(" (and indeed this will not be the case in general).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686866")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 7 December 2024")])]

#text("Also, in the proof of Lemma 8, when do we need to pad out the cardinality? Isn’t it the case that the collection ")#mi("\\mathcal{Q}*")#text(" is at least countable as well, for otherwise ")#mi("E")#text(" will be a finite union of closed sets, and is thus closed?")

#emph[#text("[")#mi("E")#text(" could be empty – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686879")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2024")])]

#text("Dear professor Tao:")

#text("To show that ")#mi("T(E)")#text(" is measurable in Exercise 21, are we expected to use Exercise 19 and the fact that linear operators on finite dimensional normed spaces are continuous? Is there some other ways to go about it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686880")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2024")])]

#text("That is one way to proceed. One can also use the various characterizations of Lebesgue measurability from Exercise 8.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6d5142844ce0eb1c32810e27c1e76528e597453399d4c4d2febb9441011a031f-b509ca1f9964809c0a1a9de86a93bffa33ea858bfc2d4657fae50b6a8a745230.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sam")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686926")[#strong[#text("Sam")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2024")])]

#text("Dear professor Tao:")

#text("To show the metric space in Exercise 24 is complete, one considers a Cauchy sequence of ")#mi("[E_n]")#text(" and construct the limit using either the limit superior or the limit inferior of the ")#mi("E_n")#text(", but then one needs to control the sum of countable number of terms ")#mi("m^*(E_n \\Delta E_k)")#text(" for our choice of ")#mi("n")#text(", where the epsilon over two to the ")#mi("n")#text(" trick does not seem to directly apply. Can you provide some hint on this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-686927")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 18 December 2024")])]

#text("Try working with a fast Cauchy sequence (see ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("Trick 17.1")]#text("). Also, it will suffice to control adjacent differences ")#mi("m^*(E_n \\Delta E_{n+1})")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/923a0970bd6eabc4ade1663e26bfdd52b128322ef1e48b28252d015fa70b07fe-5e4d9c4d5e6c99ab6b043987062f58ce740137c3081af1d82f2a6d03c1c72bc9.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of magicaltechnically8b18566508")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-687230")[#strong[#text("magicaltechnically8b18566508")]]#text(size: 9pt, fill: rgb("596477"), " · 21 February 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[

]

#text("Dear Tao,")

#text("In (3), the Jordan inner measure is only defined for bounded sets. Is “every E” supposed to be “every bounded E”? or Can you give the definition of Jordan inner measure for unbounded sets here?")

#text("Thanks!")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689207")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Dr Tao,")#linebreak()#text(" There are lots of equivalent definitions of Lebesgue measurability —— Littlewood’s first principle, Carathedory criterion, and so forth. However, just like in undergrad real analysis course we first learn the Riemann Sum definition of Riemann integral, eventually we may turn to other equivalent definitions which are more comfortable to use in practice. Thus, What would be the advantageof the one using different equivalent definitions of Lebesgue measurability?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689210")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 December 2025")])]

#text("Once all the foundations are set up, it does not matter so much which definition one started with so long as one proves the equivalence with all the other definitions. But some definitions of Lebesgue measure, particularly those relating to open sets etc., are well suited for interactions with topology (e.g., checking that continuous functions are measurable, etc.), while others are suitable for generalization to more abstract settings (e.g., definitions involving the Caratheodory criterion). Also note that one can reverse the causal relationship between measure and integral, using the Riesz representation theorem to recover Lebesgue measure from the Riemann integral. But these are simply different aspects of the theory, I would not try to assign one of these definitions to be more “fundamental” or “better” than another. See also my answer to this MathOverflow question: ")#link("https://mathoverflow.net/questions/19152/why-is-a-topology-made-up-of-open-sets")[#text("https://mathoverflow.net/questions/19152/why-is-a-topology-made-up-of-open-sets")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689253")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Dr Tao,")

#text("You said that “we will use the dyadic mesh structure of the Euclidean space, which is a convenient tool for “discretising” certain aspects of real analysis”, I wonder what aspects are suitable for using the tool of the dyadic mesh structure? More generally, what is the general princeple or strategy of using discretisation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689262")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("Discretization is a way to use tools from discrete mathematics to apply to continuous mathematics problems. So if you have a continuous problem for which you have some idea of how to proceed solving it from your mathematical toolkit if it were discrete, this suggests a discretization approach. For instance, if your problem involves the volume of a solid body, but you have some techniques (e.g., double counting) that apply for cardinalities of finite sets rather than volumes of continuous bodies, this may suggest a discretization approach. (Alternatively, one can look for continuous analogues of your discrete tools; for instance, the Fubini-Tonelli theorem is a common continuous substitute for the technique of double counting from discrete mathematics.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689269")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 December 2025")])]

#text("I see. Could you provide us more examples using Dyadic Mesh Structure? I checked the book and I only found this proof using it.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689288")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 9 December 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2007/07/27/dyadic-models/")[#text("Dyadic models")]
]
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689311")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("Dr Tao")

#text("I don’t want to be annoying, but when I check the link you gave I don’t see any paragraph mentioneing the dyadic mesh structure. Could you please take some time explaining why would you come up with this structure when proving Lemma 8? What’s the motivation?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689315")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 December 2025")])]

#text("The usefulness of the dyadic grid (or related structures, such as martingale structures) is well established in harmonic analysis. An early paper on this for instance is the ")#link("https://projecteuclid.org/journals/pacific-journal-of-mathematics/volume-99/issue-2/BMO-from-dyadic-BMO/pjm/1102734020.full")[#text("1982 paper of Garnett and Jones")]#text(". More recently there is ")#link("https://arxiv.org/abs/1812.00850")[#text("this survey of Pereyra")]#text(". See also Notes 5 of ")#link("https://www.math.ucla.edu/~tao/254a.1.01w/")[#text("this old course of mine")]#text(", where the closely related analogy between the Walsh-Fourier transform and the Fourier transform is discussed. This is the kind of hard-won insight that took decades to discover and internalize through the cumulative contributions of many mathematicians; if you are looking for a one-sentence motivation for how this insight was realized, I’m afraid that I will have to disappoint you on this.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2026")])]

#text("Dear Dr Tao,")

#text("It seems that “adjointed” should be “adjoined” right?")

#text("I would like to ask what does ")#emph[#text("regularity")]#text(" means with the name of ")#emph[#text("outer")]#text(" ")#emph[#text("regularity")]#text(" ? It seems a bit vague. Generally speaking could you give a informal description of “regularity”?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689556")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2026")])]

#text("The term “")#link("https://en.wikipedia.org/wiki/Regular#Mathematics")[#text("regularity")]#text("” is incredibly overloaded in mathematics, but in within analysis it generally has connotations of smoothness, continuity, or otherwise being well-behaved with respect to limits. One can view inner and outer regularity of measures as being somewhat analogous to left and right continuity of functions.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689562")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2026")])]

#text("Dear Prof. Tao, I think the proof of Lemma 8 is somewhat “unusual” (compared to other proofs in these notes), because I don’t know what structures the “starting point” of the argument is based on. Could you please tell us what are the strategy of this proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689565")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2026")])]

#text("It is famously said that topologists cannot distinguish between doughnuts and coffee cups due to their topological equivalence. An analogous statement in analysis might be that analysts are often unable to distinguish between balls and cubes, because they are “equivalent up to constants”. On the other hand, cubes – especially dyadic cubes – tend to have better nesting properties: the intersection of two overlapping dyadic cubes, for instance, remains a dyadic cube, while the intersection of two balls is almost never a ball. Because of this, it is often convenient to take a statement that is ostensibly naturally stated using balls (e.g., “open sets are unions of balls”), and try to locate the analogous statement involving cubes (in this case, Lemma 8) as one may be able to obtain additional useful properties in the latter case (in this case, almost disjointness).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689597")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2026")])]

#text("Prof. Tao, Could you give us a hint on how to show Cantor set is uncountable? Generally speaking, if we want to prove a set is uncountable, what techniques or strategies do we need?")

#emph[#text("[Try to find a one-to-one correspondence (or at least a surjection) between that set (or a subset thereof) to a set that you already know to be uncountable, such as ")#mi("[0,1]")#text(" or ")#mi("\\{0,1\\}^{\\mathbb N}")#text(". -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-689606")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2026")])]

#text("Thanks for the general strategy. But I have given my best to find a 1-to-1 correspondence, such as linear functions, trigonometric functions, and so forth, and I still can’t find the on we need. Could you please go further on how to construct that map?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-690068")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2026")])]

#text("Dear professor Tao:")

#text("The Cantor set has so many topological properties: it’s compact, totally separated, and topologically complete, but not scattered. Meanwhile, The Cantor set is counterintuitive because it is uncountable but has 0 measure. Thus I wonder is there any profound reason behind the construction that leads to various and special properties of the Cantor set?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-691541")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 January 2026")])]

#text("Topologically, Cantor sets are typical representative examples of a ")#link("https://en.wikipedia.org/wiki/Cantor_space")[#text("Cantor space")]#text(", which is in turn a quintessential type of ")#link("https://en.wikipedia.org/wiki/Stone_space")[#text("Stone spaces")]#text(", but there are many other ways to generate topological Cantor or Stone spaces than the classic middle-thirds Cantor construction. It’s just that this middle-thirds set is usually the first example of a Cantor or Stone space that we teach to analysis undergraduates; it has historical significance and is pedagogically useful, but is ultimately not all that central to, say, descriptive set theory.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-691591")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("Dr. Tao,")

#text("The common technique for proving the Cantor set C is uncountable is through ")#emph[#text("ternary expansions")]#text(", but this technique doesn’t seem very common, compared to finding a 1-to-1 correspond. I want to ask why ternary expansions are used to prove C’s uncoutability?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-691593")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2026")])]

#text("I am ")#link("https://chatgpt.com/share/696e6e93-a09c-800e-a4c2-12b5718da55f")[#text("outsourcing this question to an AI")]#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-691720")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2026")])]

#text("Dr Tao,")

#text("In exercise 27, could you explain more why space-filling curves still serve as a counterexample even after weakening from continuously differentiable to Lipschitz continuous?")

#emph[#text("[I do not mention Lipschitz continuity in Exercise 27. (But the positive results for continuously differentiable curves also extend to the Lipschitz case without difficulty.) -T]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-692035")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2026")])]

#text("Dr Tao,")

#text("The standard method for proving the uncountability of the Cantor set is the ternary expansion. Is this related to the fact that both the process of constructing the Cantor set and the process of counting in base 3 are self-similar?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-692675")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2026")])]

#text("Dear Dr. Tao:")

#text("If we view the Lebesgue measure as the unique Haar measure on Rⁿ, is this understanding natural or intuitive for analysts like you? Under this perspective or definition, can measure-theoretic concepts such as Lebesgue integration and modes of convergence gain distinct insights?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-692679")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 May 2026")])]

#text("Sure, this can be a useful perspective, particularly when working with symmetries of Euclidean space, or things relating to such symmetries. For instance, the rotational invariance of Lebesgue measure is easily established from the uniqueness of (normalized) Haar measure, and the Euclidean Plancherel theorem can similarly be deduced from abstract Plancherel duality (after computing one single Fourier transform, e.g., of a gaussian, to get the normalization constant correct).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-693174")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2026")])]

#text("Dr Tao,")

#text("If a measurable set becomes a fractal—such as a space-filling curve, the Cantor set, Brownian motion, or other fractals—can the Lebesgue measure still serve as a suitable tool? Are there other measures that can better characterize fractals?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-693182")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2026")])]

#text("Yes, of which Hausdorff measure is the most common example. See ")#link("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/")[#text("https://terrytao.wordpress.com/2009/05/19/245c-notes-5-hausdorff-dimension-optional/")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-693751")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2026")])]

#text("I really find the construction of Lebesgue non-measurable sets somewhat artificial. What exactly was observed in this proof that led to the idea of constructing the set in this way?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-2/#comment-693765")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 August 2026")])]

#text("I am ")#link("https://claude.ai/share/8f959507-7737-4743-9119-53cb3f92621d")[#text("outsourcing this question to an AI")]#text(".")

#text("Another way to think about it (working in the torus instead of the line for some technical simplifications) is this: given a countably infinite additive group ")#mi("G")#text(", it is not possible to find a measure on it which is (a) non-trivial; (b) translation-invariant; (c) finite; and (d) is able to measure at least one singleton set. In particular, no measure on ")#mi("{\\bf Q} / {\\bf Z}")#text(" can obey all of (a)-(d). Now think of the torus ")#mi("{\\bf R}/{\\bf Z}")#text(" as a principal ")#mi("{\\bf Q}/{\\bf Z}")#text("-bundle over a (rather nasty) base ")#mi("{\\bf R}/{\\bf Q}")#text(", or in the language of short exact sequences:")

#mi("\\displaystyle 0 \\to {\\bf Q}/{\\bf Z} \\to {\\bf R}/{\\bf Z} \\to {\\bf R} / {\\bf Q} \\to 0.")

#text("The torus has a measure obeying (a)-(d), namely Lebesgue measure. The tension between (a)-(d) holding for the torus ")#mi("{\\bf R}/{\\bf Z}")#text(" but failing for ")#mi("{\\bf Q}/{\\bf Z}")#text(" forces something to break; in this case, it is the bundle version of (d) (that the torus is able to measure at least one section of the aforementioned bundle) that has to fail. The axiom of choice then comes in to assert that at least one such section exists.")

#text("I will also remark that the Banach-Tarski paradox can be interpreted from a similar perspective (viewing ")#mi("SO(3)")#text(" as a principal ")#mi("{\\bf F}_2")#text("-bundle).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46922")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2010")])]

#text("just above theorem 2, ”Motivated by this, given any countable sequence …” i guess we need to delete ”countable” from the sentence")

#text("Thanks")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46923")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("in the proof of thm 2 , summation after the sentence ” let F be e finite set….” should be over finite set F, NxN.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46924")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Dear Prof. Tao,")

#text("in exercise 17, i guess it should be ")#mi("m(T(E))")#text(" not ")#mi("m(E+x)")

#text("Thank you for this great post.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4c76a15e981a92d023731b417f6a400902ed482c0f8922b6601466fef56e9a73-8b74ccc28721a5d7abb0ffd5651815e1e314045571882416d81ea03a424552be.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46927")[#strong[#text("Real Analysis (=Measure Theory) by Terence Tao « UGroh's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("[…] Grundfragen und Jordansche Maß Lecture 1: Das Lebesguesche […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/70c29264fb486ceaec33223c77038ad1b8efd8aa68feb66d6cfa8871af18b07f-fdec1d329b3909327d05b13b92473ec66f3d60d5790e6fee1cf23b2d0d2988f6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Schwarzmann")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46928")[#strong[#text("Mark Schwarzmann")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Some typos: in lemma 9.7, in the definition of the Cantor set and in the definition of a $G_delta$ set, the symbol used is countable union, though it should be a countable intersection. Also, the sentence with the definition of a $G_delta$ set got cut in the middle.")

#text("The corollary which you mention in remark 6 can be proven using transfinite induction (at least in the one-dimensional case), no?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46932")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 10 September 2010")])]

#text("Thanks for the corrections!")

#text("I hadn’t considered the one-dimensional case, but yes, a transfinite induction (or a continuity argument) would indeed work here. In general, I think one has to use the Heine-Borel theorem at some point (or some other theorem which somehow “detects” the completeness, and hence uncountability, of the reals), since the claim is false for the rationals. But once one uses Heine-Borel one is basically using the Lemma 5 argument.")

#text("In one dimension one can use connectedness (Dedekind cuts, etc.) to access the information that the reals are complete, which is why one also has the continuity argument available.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fdf428f3ca9ced34f3e6d601e98b049d95e125d34d8352a38190a225857d80f4-af6a67fe370a9fb28d2aa23a90b7b68180fae9eb9342c4c843ed907898e52a7c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Nick Gill")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46967")[#strong[#text("Nick Gill")]]#text(size: 9pt, fill: rgb("596477"), " · 12 September 2010")])]

#text("Good post, although I got a bit confused about when things are being defined, and when they’re proved.")

#text("E.g1 (i) and (ii) of exercise 7 are equivalent by definition, right?")#linebreak()#text(" E.g.2 In exercise 10 the implication countable additivity => countable subadditivity is immediate, right? Am I missing something profound?!")

#text("Lem. 9 has a typo (apart from the double numbering which I’m guess is an accident). In 7 (vii) you should have \\cap not \\cup.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46971")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2010")])]

#text("Thanks for the corrections!")

#text("Yes, some of the implications in Exercise 7 are trivial. I phrased it this way so that the statement of the exercise becomes independent of the exact choice of definition of Lebesgue measurability (the definition used here (and in Stein-Shakarchi), based on outer regularity, is a convenient one, but certainly not the only one used in the literature).")

#text("Exercise 10 is indeed easy, but not completely trivial; countable additivity only works for disjoint sets, whereas countable subadditivity is for sets that can overlap, so one needs a little trick (more precisely, the lacuna trick from the preceding exercise) to finish the job.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46980")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("These are just some questions regarding how you implement your course with the notes: When do you tend to publish these notes to your blog in relation to when you lecture on the material? Are they up well in advance, immediately before, afterward..?")

#text("And when you do give the lectures, how many lectures or how much time does a post such as this one cover?")

#text("Thanks in advance!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-46984")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 September 2010")])]

#text("This is highly variable, depending on the natural length of each subject topic and the natural amount of material covered in lecture, and my work schedule. Generally, though, the notes are about a week or so ahead of lectures, and each set of notes is good for one to two weeks of lectures. (But my lectures don’t always adhere exactly to the notes.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/642435117a88049a941133b79ae9996891f2d2e527d80012d3a39f88c4626209-f8879366eacd64283a35ee8d8b8440d3f8745a126869f29e07f7c31c2a3161a8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Beetle B.")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47033")[#strong[#text("Beetle B.")]]#text(size: 9pt, fill: rgb("596477"), " · 15 September 2010")])]

#text("When you redefine the Jordan outer measure as the inf of a number of boxes, I take it that k is not a fixed quantity?")

#text("Thanks.")

#emph[#text("[Yes; I’ve added a note on this in the text. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Breeden")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47043")[#strong[#text("Chris Breeden")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2010")])]

#text("Professor Tao,")

#text("I just wanted to express my gratitude that you take your time to post these valuable lecture notes (among everything else you post on your blog). These notes provide a great source of support for some of us inspiring mathematicians (who undoubtably look up to you). However, do you think it would be possible to post (or put on your course website) a pdf rendering of these notes? I’d really like to use these notes to supplement an equivalent course that I am taking at my school.")

#text("v/r")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Chris Breeden")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47046")[#strong[#text("Chris Breeden")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2010")])]

#text("Professor Tao,")

#text("I guess you can disregard my inquiry about making these notes available in a more reader friendly format; I just read your comment: ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/#comment-46809")[#text("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/#comment-46809")]#text(", concerning making these notes available in latex format.")

#text("v/r")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d00b022403693721587ac65b5d73a200a73624330a2f57aa26138f61ddc4c1eb-93d8cbcbdce6c9bfc87b78023bf874b6dc5e6b38797afdaf6fa5df356a50429b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of B.")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47045")[#strong[#text("B.")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2010")])]

#text("Thanks for the notes. Exercise 23 should require the sets to be disjoint. ")#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/953b7bd32cf7eaa020006fc272d5a7cbc33654ae9d83278e8f02d0c21a6b5bc4-fa5c994a46b5ca481a9304fba98f508cded48261da3eed811a14fc11b6e65ebb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chandrasekhar")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47064")[#strong[#text("chandrasekhar")]]#text(size: 9pt, fill: rgb("596477"), " · 18 September 2010")])]

#text("Respected Sir,")

#text("I have always admired you as a Mathematician, and its good to see your wonderful posts which are very useful for undergraduate and Graduate students. These measure theory notes are excellent. By the one question. How do you put those boxes in wordpress.")

#text("Thanking you,")#linebreak()#text(" Chandrasekhar")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47148")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("The boxes come from a customised CSS for this blog, see")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/about/")[#text("About")]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/953b7bd32cf7eaa020006fc272d5a7cbc33654ae9d83278e8f02d0c21a6b5bc4-fa5c994a46b5ca481a9304fba98f508cded48261da3eed811a14fc11b6e65ebb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chandrasekhar")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47154")[#strong[#text("chandrasekhar")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("Respected Sir,")

#text("Thanks for taking time to reply. By the way, i have one question to ask. Lebesgue integral was discovered, due to the shortcoming of the Riemann integral, does Lebesgue integration have any shortcomings. If what are they, and has any new “Integral” been developed, which is more advanced than the Lebesgue integral.")

#text("Chandrasekhar")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47157")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("Well, among the class of absolutely integrable and Lebesgue measurable functions, the Lebesgue integral is the only operation that obeys reasonable axioms of integration (e.g. linearity, monotonicity, and countable additivity). So the only way to “improve” the integral further is to add in the ability to integrate some non-measurable, or non-absolutely-integrable functions. Regarding the former type of extension, we know that, due to things such as the Banach-Tarski paradox, we know that by doing so, one will have to give up one or more of the pleasant properties of the Lebesgue integral. Now it may be that one could avoid such problems by only enlarging the class of integrable functions in a very carefully controlled fashion, but it is not clear what benefit that would give, seeing that almost all functions that one actually encounters in practice are Lebesgue measurable (and the ones which are not are so pathological that probably no amount of tinkering with the integration concept can give a truly satisfactory integration theory for such functions).")

#text("So the main scope for improvement would then to consider integrals of functions that are measurable, but which oscillate so wildly, or are sufficiently singular (or sufficiently slowly decaying at infinity) that they are not absolutely integrable. In such cases, there are certainly non-Lebesgue ways to integrate such functions (e.g. improper Riemann integrals, principal value integrals, zeta function regularisation, etc.). However, one has to be quite careful with such integration concepts, as not every property that is true for the Lebesgue integral continues to hold for these more exotic integrals. For instance, it is entirely possible that an exotic integral of a non-negative function becomes negative (cf. the famous divergent series identity 1 + 2 + 3 + … = -1/12, which is valid for certain exotic interpretations of the infinite series). Such notions have their uses, but it is best to think of them as exotic variants of the Lebesgue integral, rather than “improvements” of that integral, so that one does not mistakenly apply results from the Lebesgue integration theory to the exotic integrals that lie outside the scope of those results.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47160")[#strong[#text("245A, Notes 2: The Lebesgue integral « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2010")])]

#text("[…] compatible. Conversely, the Lebesgue theory can be approximated by the Riemann theory; as we saw in the previous notes, every Lebesgue measurable set can be approximated (in various senses) by simpler sets, such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47196")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 September 2010")])]

#text("Dear Prof. Tao,")

#text("there is missing ")#mi("+")#text(" in ")#mi("0\\cdot \\infty")

#text("after remark 1, in formulas (1) and (2), you are using ")#mi("n \\in A, F")#text(" but I guess they should be ")#mi("\\alpha")

#text("is the bijection just after (2) from A to A or B to A?")

#text("in the last step of the proof of Lemma 8, do we use Lemma 7?")

#text("in Exercise 14, when you say ” E differs from a ….” do you mean outer measure of set differences?")

#text("Thanks for this great post and I hope you teach a grad level complex analysis after this course…")

#emph[#text("[Corrected, thanks. Lemma 7 is not used in the proof of Lemma 8; to obtain an upper bound for an inf, it suffices to bound a single instance of that infimum; one does not need to control arbitrary instances. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47216")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2010")])]

#text("Prof. Tao: Proving the existence of Lebesque nonmeasurable sets requires the axiom of choice. The above proof is by contradiction. Do existence proofs that require the axiom of choice have to be proofs by contradiction?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47217")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2010")])]

#text("Well, the example of the nonmeasurable set given is completely constructive, once one has the axiom of choice. The only reason the proof is by contradiction is beause the statement one is trying to prove is a negative one: that a set is not measurable. It’s hard to see how else to proceed with proving such a negative statement other than to assume that the set is measurable and derive a contradiction.")

#text("(Such arguments (“A implies a contradiction, hence not-A”) are sometimes classified as “proof by negation” rather than “proof by contradiction”, which is then reserved for arguments of the form “not-A implies a contradiction, hence A”). But in classical logic (for which one has the law of the excluded middle, and hence not-not-A is equivalent to A) there is no essential distinction between the two types of proofs.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47353")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("Although the set E in Prop. 11’s proof is constructed using the axiom of choice, this construction requires an infinite number of arbitrary choices, i.e., there seems to be no way to define E as {x_C : x_C is the unique element of the coset C in [0,1] with the property p}. What definition of a constructive proof do you use?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47356")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("The axiom of choice provides a choice function for any infinite family of non-empty sets. If you like, one can think of ZFC as a powerful computing language that contains a function call choicefunction() that returns a choice function for any such family. If one is permitted to use such a function, then the set described in the notes is constructive. Of course, if one is only working in the weaker computing language of ZF, one cannot do this.")

#text("There are however other ways to construct sets that do not involve choice in the construction, but for which the measurability is undecidable; but I do not know the specific details of these constructions.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47357")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 October 2010")])]

#text("Thank you for answering my questions.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47219")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2010")])]

#text("if E is unbounded, we define the Jordan outer measure of that set equals zero.")#linebreak()#text(" So ")#mi("R")#text(" has infinite Jordan outer measure in ")#mi("R^2")#text("? but any finite line has measure zero?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47220")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 September 2010")])]

#text("We give unbounded sets an outer Jordan measure of ")#mi("+\\infty")#text(", by convention, so yes, the entire real line in the plane would have infinite outer Jordan measure even though each bounded segment of that line has outer Jordan measure zero. This demonstrates in particular that outer Jordan measure is not countably subadditive, which is one of the reasons why Lebesgue measure is a superior measure to Jordan measure for the purposes of analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/953b7bd32cf7eaa020006fc272d5a7cbc33654ae9d83278e8f02d0c21a6b5bc4-fa5c994a46b5ca481a9304fba98f508cded48261da3eed811a14fc11b6e65ebb.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of chandrasekhar")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47228")[#strong[#text("chandrasekhar")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2010")])]

#text("Sir,")

#text("Regarding Exercise 1 i have a question. What does it mean when you say ")#mi("\\bigcup\\limits_{n=1}^{\\infty} E_{n}")#text(" is a countable union? If this was a countable union then it would contradict ")#mi("\\displaystyle \\mathbb{R} = \\bigcup\\limits_{i=1}^{\\infty} A_{i}")#text(" where ")#mi("A_{i}")#text("‘s are one point sets.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47229")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2010")])]

#text("A countable union is a union of countably many sets, in this case ")#mi("E_1, E_2, E_3, \\ldots")#text(".")

#text("It is of course possible for a set to be a countable union of one (countable) family of sets, and an uncountable union of another (uncountable) family of sets, as your example demonstrates (though it would be better to express it as ")#mi("{\\bf R} = \\bigcup_{x \\in {\\bf R}} \\{x\\}")#text(", as the formulation you indicate suggests countability.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47231")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2010")])]

#text("on your personal web page, I guess there are some mistakes in the codes of previous teaching. Random matrices and higher other fourier analysis’s codes should be 254 not 245. am I right?")

#emph[#text("[Corrected, thanks – T]")]

#text("Thanks for your great post")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47232")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 September 2010")])]

#text("when we click on the link random matrix theory from your web page, it send us to real analysis’ page.")

#emph[#text("[Fixed – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47251")[#strong[#text("245A, Notes 3: Integration on abstract measure spaces, and the convergence theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 25 September 2010")])]

#text("[…] the hypothesis that for at least one is dropped. (Hint: copy the argument used for Exercise 10 in Notes 1.) Exercise 24 (Dominated convergence for sets) Let be a measure space. Let be a sequence of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47486")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("In exercise 4, to prove countable subadditivity, the hint suggests using the axiom of countable choice, but it seems to me that it can be proved using only the Tonelli’s and the epsilon/2^n trick. Am I missing something here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47488")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 8 October 2010")])]

#text("Try writing out your proof in full. At some point, you will need to choose a way to cover each of the ")#mi("E_n")#text(" by boxes. The ability to make one such choice for each n requires the axiom of countable choice.")

#text("In many cases, the axiom of choice is so intuitively obvious that it is possible to use it without being fully aware of doing so…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc320250f2e23d5a4c9efd13c18aa4941157c4483224f5206fde5273e462a9e9-119f2a6769ba244433fc0111fff7bd89f9d8a8bca1c37d17b83bf61bd63fc0da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47590")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2010")])]

#text("Dear Professor Tao,")

#text("I had a quick question, if A,B are Lebesgue Measurable, we cannot assume that A\\B is also lebesgue measurable. Is that correct?")#linebreak()#text(" Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47623")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2010")])]

#text("The set difference of two Lebesgue measurable sets is Lebesgue measurable; this can be seen by applying parts (v) and (vii) of Lemma 10. (Note that ")#mi("A \\backslash B")#text(" is the intersection of A with the complement of B.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47624")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2010")])]

#text("Thank you Professor. Tao,")

#text("This is very clear now, thank you")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47625")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 14 October 2010")])]

#text("Dear Professor Tao,")

#text("Are there solutions to some of the Exercise problems that was assigned in class? I think this would really help to see how it is actually done right.")#linebreak()#text(" Some of these problems look trivial, but when one attempt to solve them, it is very challenging. If some solutions are available (maybe the TA if you are busy), it would help the class and students in general tremendously.")

#text("Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47628")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2010")])]

#text("There should be some presentations of solutions to the exercises (either assigned or unassigned) by students in the TA session (I am assigning a bonus participation point of 1% to the final grade to any student who makes such a presentation). I’ll ask the TA if there needs to be more encouragement to do these presentations.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/515ffc52b75890a0c3a33be711fdd621e5e83b3b096db74956bb1a7b2956c17f-30d9e70954aedc2521cfd048a5281954e22c25369e82e0f7d77e9a3208d381a0.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiang")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48093")[#strong[#text("Qiang")]]#text(size: 9pt, fill: rgb("596477"), " · 12 November 2010")])]

#text("Hi, Dr. Tao")

#text("Have you considered expose solutions of exercises in your lecture notes to the public (of course after submission of assignments in your class)? To people like me who doesn’t have a mathematics background, some exercises are too hard to figure out. I believe some solutions can really help here.")

#text("Thank you")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fc320250f2e23d5a4c9efd13c18aa4941157c4483224f5206fde5273e462a9e9-119f2a6769ba244433fc0111fff7bd89f9d8a8bca1c37d17b83bf61bd63fc0da.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Hossein Naderi")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47626")[#strong[#text("Hossein Naderi")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2010")])]

#text("Dear Professor Tao,")

#text("I was wondering if we have an uncountable bounded set, then its outer Lebesgue measure must always be non-zero (greater than 0). Since the only countable box that can cover it has measure non-zero.")#linebreak()#text(" Thank you")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47627")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 15 October 2010")])]

#text("The Cantor set is a one-dimensional example of an uncountable bounded set of measure zero; another simple example is that of line segment in the plane (note that if this line segment is oriented diagonally, then any cover by boxes must involve at least one box of positive volume). The point is that while any single countable cover of boxes will have positive measure, the infimum of all those measures can still be zero.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 5: Differentiation theorems « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47648")[#strong[#text("245A, Notes 5: Differentiation theorems « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 16 October 2010")])]

#text("[…] useful when it comes to the covering lemma stage of the argument, much as it was in Exercise 8 of Notes 1.) Exercise 20 (Besicovich covering lemma in one dimension) Let be a finite family of open […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47923")[#strong[#text("245A, Notes 6: Outer measures, pre-measures, and product measures « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2010")])]

#text("[…] for instance, Lebesgue outer measure is an outer measure (see Exercise 4 of Notes 1) is an outer measure. On the other hand, Jordan outer measure is only finitely subadditive rather […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b6715a79750c556f686b8e896bffa9cb269ab8c7e62dba6bb78f2f0246e9ac25-475e4d182f756401af52089fd4a48cf63b77e8dd7634e7d7a368b9a3ea5ba799.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of sabari")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-47928")[#strong[#text("sabari")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2010")])]

#text("This is regarding vitali’s construction of non measurable (Lebesgue)set … it is indeed a beautiful construction… My doubt is is it possible to give an answer to the question ”what might be the possible motivation for Vitali to apply this kind of equivalence relation and then axiom of choice etc for construction of non measurable set?” ..")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Y")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48220")[#strong[#text("Y")]]#text(size: 9pt, fill: rgb("596477"), " · 21 November 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" For the Exercise 1, the set ")#mi("[0,1]\\cap Q")#text(" in Ex. 18.4 (Notes 0) can give the desired countable union ")#mi("\\bigcup_{n=1}^{\\infty}E_n")#text(". Is possible to use ")#mi("[0,1]\\cap Q")#text(" or ")#mi("[0,1]\\setminus Q")#text(" to construct ")#mi("\\bigcap_{n=1}^{\\infty}E_n")#text("? Or does one need some other tools to do it?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48225")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2010")])]

#text("Use de Morgan’s laws (localised to a bounded region) to flip the example for the union to an example for the intersection (cf. Trick 4 from the ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("problem solving strategies")]#text(" page).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48341")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("Prof. Tao,")#linebreak()#text(" Could you explain where one needs the axiom of countable choice for “Countable subadditivity” in Exercise 3? Is it because when one says, for any ")#mi("k\\in \\mathbb{N}")#text(", there exists a cover for ")#mi("E_k")#text(", such that ")#mi("\\cup_{n=1}^{\\infty}B_{n,k}\\supset E_k")#text(", one needs this axiom? Or anywhere else? My reason seems not that convincing.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48343")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 November 2010")])]

#text("Yes. There are a countable number of k for which one needs to choose a cover, so one needs the axiom of countable choice.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48848")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2010")])]

#text("Prof. Tao,")#linebreak()#text(" In Exercise 3.3, I don’t quite understand exactly why one needs Tonelli’s theorem for series here. From the right hand side, by axiom of countable choice and the ")#mi("\\epsilon/2^n")#text(" trick, one can have the estimate ")#tao-math("\\sum_{n=1}^{\\infty}m^*(E_n)\\geq \\sum_{n=1}^{\\infty}\\sum_{k=1}^{\\infty}\\left|B_{n,k}\\right|-\\epsilon", block: false)#text(" where ")#mi("\\cup_{k=1}^{\\infty}B_{n,k}\\supset E_{n}")#text(". Since ")#mi("\\cup_{n=1}^{\\infty}(\\cup_{k=1}^{\\infty}B_{n,k})\\supset(\\cup_{n=1}^{\\infty}E_n)")#text(", can one directly use ")#tao-math("\\sum_{n=1}^{\\infty}\\sum_{k=1}^{\\infty}\\left|B_{n,k}\\right|\\geq m^*(\\cup_{n=1}^{\\infty} E_n)", block: false)#text("? Where is Tonelli here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48850")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2010")])]

#text("The doubly infinite family ")#mi("((B_{n,k})_{k=1}^\\infty)_{n=1}^\\infty")#text(" is not, strictly speaking, a countable cover of ")#mi("\\bigcup_{n=1}^\\infty E_n")#text(", but ")#mi("(B_{n,k})_{(n,k) \\in {\\bf N}^2}")#text(" is (relabeling ")#mi("{\\bf N}^2")#text(" to identify it with ")#mi("{\\bf N}")#text(" if desired). So it is the sum ")#tao-math("\\sum_{(n,k) \\in {\\bf N}^2} \\left|B_{n,k}\\right|", block: false)#text(", rather than ")#tao-math("\\sum_{n=1}^\\infty \\sum_{k=1}^\\infty \\left|B_{n,k}\\right|", block: false)#text(", which is relevant for computing the outer measure of ")#mi("\\bigcup_{n=1}^\\infty E_n")#text(". Tonelli’s theorem guarantees that these two sums are the same and so the distinction is largely invisible.")

#text("(More generally, Fubini-Tonelli is not ")#emph[#text("solely")]#text(" about interchanging sums or integrals, although this is certainly the most popular way to use this theorem; it is also about converting double sums or integrals into a sum or integral over the product space.)")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49237")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2010")])]

#text("Dear Sir,")

#text("I don’t quite understand why “the double infinite family is not, strictly speaking, a countable cover of the union of E_n”, as the latter is contained in the former (in particular, each E_n is contained in union of B_{n,k}) ?")

#text("Thanks!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49245")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2010")])]

#text("A countable cover needs to be a countable family of sets that cover the desired set (in this case, ")#mi("\\bigcup_{n=1}^\\infty E_n")#text("). Strictly speaking,")#linebreak()#text(" ")#mi("((B_{n,k})_{k=1}^\\infty)_{n=1}^\\infty")#text(" is not a countable family of sets that cover the desired set, but rather a countable family of countable families of sets, each of which cover a portion of the desired set. But, as mentioned above, if one rearranges the doubly infinite family into a singly infinite family ")#mi("(B_{n,k})_{(n,k) \\in {\\bf N}^2}")#text(", then one obtains a countable cover.")

#text("In practice, of course, one does not bother to make such pedantic distinctions, and usually “abuses notation” by identifying ")#mi("((B_{n,k})_{k=1}^\\infty)_{n=1}^\\infty")#text(" with ")#mi("(B_{n,k})_{(n,k) \\in {\\bf N}^2}")#text(". But at a foundational level they are slightly different objects, as can be seen by considering the standard encoding of tuples such as ")#mi("(x_\\alpha)_{\\alpha \\in A}")#text(" in set theory. (For similar reasons, a double sum ")#mi("\\sum_{n=1}^\\infty \\sum_{k=1}^\\infty c_{n,k}")#text(" is a slightly different object than the single sum ")#mi("\\sum_{(n,k) \\in {\\bf N}^2} c_{n,k}")#text(", although we are fortunate to have Tonelli’s theorem, which asserts that these two sums always have the same value, at least when the ")#mi("c_{n,k}")#text(" are non-negative.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49289")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2010")])]

#text("Thanks for pointing out the subtlties here!")

#text("So does it mean that the sum ")#tao-math("\\sum_{(n,k) \\in {\\bf N}^2}\\left|B_{n,k}\\right|", block: false)#text(" actually represents a whole ‘class’ of summation (e.g. we can do it as ")#tao-math("\\left|B_{1,1}\\right|+\\left|B_{1,2}\\right|+...", block: false)#text(" or ")#tao-math("\\left|B_{1,1}\\right|+\\left|B_{2,1}+....\\right|", block: false)#text(") and with the doubly infinite sumation $\\latex \\sum_{n=1}^\\infty\\sum_{k=1}^\\infty|B_{n,k}|$ as a special case?")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48449")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2010")])]

#text("Prof. Tao,")#linebreak()#text(" I’m confused for ")#mi("+\\infty")#text(" here. When one adds the ")#mi("+\\infty")#text(" to ")#mi("\\{x\\in\\mathbb{R}: x\\geq 0\\}")#text(", then any sequence in the non-negative real axis has a limit and every unsigned infinite sum exists. This is the bonus you pointed out. But what do you mean by defining a function like ")#mi("f:\\mathbb{R}^{d}\\rightarrow [0,+\\infty]")#text("? How can one clarify when one says ")#mi("f")#text(" takes the “value” ")#mi("+\\infty")#text(" at some point ")#mi("x")#text(", i.e. ")#mi("f(x)=+\\infty")#text("? Is it something like ")#mi("f(x)=\\frac{1}{x}:[0,1]\\to[0,+\\infty]")#text(", then ")#mi("f(0)=+\\infty")#text("? It seems that only when one deals with the “limit process”, the ")#mi("+\\infty")#text(" will come up. How should I understand it here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48457")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 December 2010")])]

#text("A function ")#mi("f: X \\to Y")#text(" can be defined from any domain ")#mi("X")#text(" to any range ")#mi("Y")#text(", by defining ")#mi("f(x) \\in Y")#text(" for each ")#mi("x \\in X")#text(" by whatever rule one pleases. For instance, the constant function ")#mi("f(x) := +\\infty")#text(" would be an example of a function from any given domain ")#mi("X")#text(" to ")#mi("[0,+\\infty]")#text(". The expression ")#mi("x \\mapsto 1/x")#text(" does not quite define a function on ")#mi("[0,1]")#text(", being undefined at 0, but the function ")#mi("f: [0,1] \\to [0,+\\infty]")#text(" defined by setting ")#mi("f(x) := 1/x")#text(" for ")#mi("x \\neq 0")#text(" and ")#mi("f(x) := +\\infty")#text(" for ")#mi("x = 0")#text(" is a function. So is the function ")#mi("g: [0,1] \\to [0,+\\infty]")#text(" defined by setting ")#mi("g(x) := 1/x")#text(" for ")#mi("x \\neq 0")#text(" and ")#mi("g(x) := 57")#text(" for ")#mi("x=0")#text(".")

#text("In real analysis, functions with some infinite values do indeed arise primarily from taking limits of sequences, or summing infinite series.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48847")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 December 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In remark 2 “before one is permitted to interchange integrals”, do you mean “before one is permitted to interchange Summation”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb60d0f893124fdbd4172c3dcf709a6c730e36cb9b0602fad4a0a85586a1d16-352be768f3a1f0853fd3d4a46d65b025ef1dc9f8a2979f28fb6def09a469a98c.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-48942")[#strong[#text("245A, Notes 2: The Lebesgue integral « mathTHÍCHinTOÁNmyHỌCbrain")]]#text(size: 9pt, fill: rgb("596477"), " · 16 December 2010")])]

#text("[…] compatible. Conversely, the Lebesgue theory can be approximated by the Riemann theory; as we saw in the previous notes, every Lebesgue measurable set can be approximated (in various senses) by simpler sets, such as […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49152")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 December 2010")])]

#text("Dear Prof. Tao,")#linebreak()#text(" In Remark 5, “On the other hand, by countable additivity”, do you mean “countable subadditivity”?")#linebreak()#text(" What’s more, considering the ")#mi("U")#text(" in “Finally, as ")#mi("U")#text(" is dense in ")#mi("[0,1]")#text("“, do you mean ")#mi("U=Q\\cap [0,1]")#text("? But the notation ")#mi("U")#text(" is for another set, i.e. , the union of the open set.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/623234b797d68d51d68c8940fc7c41be398874ef3a244975fae64a0e303d62bb-bc6e3174e72df5606bd2736d2c15aaeb4c99d24bf8ce5db7a911280020a81d37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49294")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2010")])]

#text("Might be nice to note that these arguments work more generally in the context of the (proof of the) Riesz representation theorem for positive measures.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/623234b797d68d51d68c8940fc7c41be398874ef3a244975fae64a0e303d62bb-bc6e3174e72df5606bd2736d2c15aaeb4c99d24bf8ce5db7a911280020a81d37.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49295")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 30 December 2010")])]

#text("Might also be nice to note that you can’t find non-measurable sets in ZF (without choice).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49386")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2011")])]

#text("Dear Prof. Tao,")

#text("I cannot read the whole passage for “give yourself an epsilon of room” in the following link,")#linebreak()#text(" ")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("http://www.tricki.org/article/Create_an_epsilon_of_room")]

#text("Could you help me with this?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49492")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 8 January 2011")])]

#text("Thanks for your comment at Tricki :)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49525")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2011")])]

#text("Glad to see that it works now! :)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-49389")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2011")])]

#text("“Of course, one cannot hope to upgrade countable additivity to uncountable additivity:”")

#text("Should “additivity” here be “subadditivity”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of 254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-85825")[#strong[#text("254A, Notes 3: Haar measure and the Peter-Weyl theorem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 September 2011")])]

#text("[…] a Haar measure. Example 1 A large part of the foundations of Lebesgue measure theory (e.g. most of these lecture notes of mine) can be summed up in the single statement that Lebesgue measure is a (bi-invariant) Haar measure on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/48aa3bf904bd44bf731b70340f5abeddd4ab827569630c3f27a5628fd5db2fb6-07d0e3b7bca0ba022173dc54c301a7ed49c2ae1774cab4b7184914ee6f058bc6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Del")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-141295")[#strong[#text("Del")]]#text(size: 9pt, fill: rgb("596477"), " · 2 May 2012")])]

#text("Professor Tao, in exercise 1.2.7 which countable intersections do we take? Thank you for all your wonderful notes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211132")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2012")])]

#text("Regarding Exercise 5 of giving a counterexample, ")#mi("E=\\{2n\\}_{n=1}^{\\infty}")#text(", ")#mi("F=\\{2n+1-1/n\\}_{n=1}^{\\infty}")#text(" should work. It seems that disjoint ")#mi("E")#text(" and ")#mi("F")#text(" can be close enough to each other at “infinity” in the 1 dimensional case. Can one find other fundamentally different counterexamples in ")#mi("{\\Bbb R}")#text("? What if we restrict the space as n-sphere (n=1,2,3)? If one uses the 1-1 correspondence between ")#mi("{\\Bbb R}\\cup{\\infty}")#text(" and ")#mi("S^1")#text(", that counterexample seems to fail.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-233288")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 7 June 2013")])]

#text("Yo dawg,")

#text("You made a small mistake. The E&F you described aren’t disjoint: perhaps you meant F=\\{2n+1/n\\}_{n=1}^{\\infty}.")

#text("Peace")#linebreak()#text(" – P-Dizzle")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211232")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("Can one prove Lemma 6 for the “boxes” first, and then use finite additivity for both side? Is Heine-Borel Theorem still needed?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211266")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("The proof of Lemma 6, even for a single box, is about as difficult as for a general elementary set, and still requires Heine-Borel. (In particular, since Lemma 6 fails for the rationals Q (even for a single box) as noted in the text, one must at some point use a fact – such as the Heine-Borel theorem – which is true for the reals but not for the rationals.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211279")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("“Even for a single box” — do you mean “even for the rationals Q in a single box”?")

#text("This is basically the remark following Lemma 6. I’m a little bit confused why “Countable sets have zero out measure” suggests the proof of this lemma use some crucial fact about the real line. What I think is that Lemma 6 fails for the rationals Q “because” Q is not Jordan measurable thus m(Q) does not exist and hence ")#mi("m^*(Q)=m(Q)")#text(" is not true (since there is no m(Q)). But I don’t see why this motivates the use of “some crucial fact” of the real line.")

#text("I guess what you indicate in the “remark” (which is Remark 1.2.7 in the book) is that ")#mi("m^*(E\\cap Q)=m(E\\cap Q)")#text(" is false where E is an elementary set (even when E is a single box), and this suggests that one needs some crucial fact about the real line to show ")#mi("m^*(E)=m(E)")#text(".")

#text("Is that precisely your point?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211292")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 December 2012")])]

#text("That is true, but is not quite the point I was getting at.")

#text("Suppose one had never heard of the real numbers at all, but instead only knew about the rational numbers ")#mi("{\\mathbf Q}")#text(". Then one could still define the notion of an interval ")#mi("[a,b]")#text(" for rational numbers ")#mi("a,b")#text(", except that to this person, the interval would consist only of rationals:")

#mi("[a,b] = \\{ x \\in {\\bf Q}: a \\leq x \\leq b \\}")#text(".")

#text("One could still define the notion of elementary set and Jordan measure in this setting: the above rational interval would be a “rational elementary set” with “rational Jordan measure” or “rational elementary measure” ")#mi("b-a")#text(", and similarly for “rational boxes”, finite unions of rational boxes, etc. (The theory of the Riemann integral works as well in the rational setting, provided that one works with uniformly continuous functions – note that because the rationals are not locally compact, continuity does not automatically imply uniform continuity.)")

#text("One can then also define the “rational outer measure ")#mi("m^*(E)")#text("” of any subset of the rationals, but this turns out to always be zero (because of the countability of the rationals), and so in this setting the assertion that ")#mi("m(E)=m^*(E)")#text(" is false (here ")#mi("m(E)")#text(" is interpreted as the rational elementary measure of a rational elementary set, rather than the real elementary measure of a real elementary set).")

#text("This tells us that any proof of ")#mi("m(E) = m^*(E)")#text(" for real elementary sets, real elementary measure, and real outer measure must use some fact about the reals which is not true for the rationals, for otherwise whatever argument one would come up with would also be able to prove ")#mi("m(E)=m^*(E)")#text(" for rational elementary sets, rational elementary measure, and rational outer measure, and this statement is false.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211441")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#text("I’ve seen the term “regularity” in many mathematical context lots of times. But it’s never defined mathematically. In this note, it is used in “outer regularity”. I also saw people use “regularity of a function” when they mean smoothness or differentiability of a function. (In complex analysis, some people use “regular” when they mean “holomorphic”. In some real analysis textbook, people say “Borel regularity of Lebesgue outer measure”.) And in set theory, there is an axiom called [axiom of regularity](")#link("http://en.wikipedia.org/wiki/Axiom_of_regularity")[#text("http://en.wikipedia.org/wiki/Axiom_of_regularity")]#text("). An quick search in MathOverflow returns this term in many different subjects in mathematics. People also use it in seminars without giving specific meaning. How should one understand this term?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211450")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 December 2012")])]

#link("http://en.wikipedia.org/wiki/Regular#Mathematics")[#text("http://en.wikipedia.org/wiki/Regular#Mathematics")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211674")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2013")])]

#text("Regarding Exercise 8, (ii)–>(iii) is trivial. (iii)–>(ii) is not obvious for me. If ")#mi("E")#text(" is open, then ")#mi("U\\cup E")#text(" is the desired open set in (ii). But this seems not helpful for the general case. How can one find the open set containing ")#mi("E")#text(" from hypothesis (iii)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211678")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 January 2013")])]

#text("Once one establishes the implication (vi)->(i) using the hint given in the exercise, getting from (iii) to (ii) will be easy. (It may help to draw a graph between the six statements depicting the implications you are able to establish.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211851")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")])]

#text("I don’t understand the hint for (vi)–>(i) for")#linebreak()#text(" 1. To show ")#mi("E")#text(" is Lebesgue measurable (L-measurable), one needs an open set ")#mi("U_{\\varepsilon}")#text(" containg E such that ")#mi("m^*(U_{\\varepsilon}\\setminus E)\\leq \\varepsilon")#text(". What’s the point of showing that ")#mi("E")#text(" differs from a Lebesgue measurable set by a null set? Do you mean ")#mi("m^*(E\\triangle U)=0")#text(" where ")#mi("U")#text(" is L-measurable implies ")#mi("E")#text(" is measurable? (It seems that this is nothing different from (vi) itself.)")

#text("2. Since ")#mi("E")#text(" is contained in ")#mi("E^{\\prime}_{\\varepsilon}")#text(" in the hint, ")#mi("E^{\\prime}_{\\varepsilon}\\triangle E=E^{\\prime}_{\\varepsilon}\\setminus E")#text(". Thus ")#mi("m^*(E^{\\prime}_{\\varepsilon}\\setminus E)\\leq \\varepsilon")#text(". This is almost the definition of L-measurable. Can one directly use the open set ")#mi("U")#text(" containing ")#mi("E^{\\prime}_{\\varepsilon}")#text(" with ")#mi("m^*(U\\setminus E^{\\prime}_{\\varepsilon})\\leq\\varepsilon")#text(" to show that ")#mi("m^*(U\\setminus E)\\leq c\\varepsilon")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211853")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")])]

#text("You don’t have to use first principles (i.e. Definition 1 directly) to deduce (i) from (vi) – this would indeed be quite difficult. Instead, you can use the results already established about Lebesgue measurability, and in particular Lemma 10.")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211855")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")])]

#text("In the hint, the first step is to find ")#mi("E^{\\prime}_{\\varepsilon}")#text(" “containing” ")#mi("E")#text(". But using the ")#mi("\\varepsilon/2^n")#text(" trick one could somehow get back and forth with ")#mi("m^*(E_{\\varepsilon}\\triangle E)\\leq \\varepsilon")#text(" in the hypothesis. How can make the union of some families of sets (where the ")#mi("\\varepsilon/2^n")#text(" trick is used) “cover” ")#mi("E")#text("? Could you elaborate the hint?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211859")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 2 January 2013")])]

#text("I found that the symmetric difference ")#mi("\\triangle")#text(" is usually not easy to handle in most of the exercises in this and previous note, unlike ")#mi("cup")#text(" and ")#mi("cap")#text(", which can be translated to each other by De Morgan’s law. If one wants to contain ")#mi("E")#text(" in some set, the symmetry difference only gives a set containing ")#mi("E")#text(" partially. How is this situation usually solved? I’ve never seen proofs of a theorem or proposition which includes symmetry difference are given in this notes. It appears only in the exercises. Is it because the manipulation is supposed to be “trivial”?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-211941")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2013")])]

#text("One can interpret a bound such as ")#mi("m(A \\Delta B) \\leq \\varepsilon")#text(" as an assertion that the set ")#mi("B")#text(" differs from the set ")#mi("A")#text(" by the addition and removal of sets of total measure at most ")#mi("\\varepsilon")#text(".")

#text("For these sorts of problems, visual, geometric, or analytic modes of thinking are more fruitful than formal or algebraic modes of thinking (in particular, I do not recommend using de Morgan’s laws, etc.). Drawing a picture of the situation, in particular, can be very helpful. See also ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" for general problem solving strategies.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-212797")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 10 January 2013")])]

#text("(i)(ii) is from the definition. (ii)–>(iii) is trivial. Using your hint I can show (iii)–>(vi)–>(ii). Thus the equivalence of (i)-(iii)and (vi) is established. (iv)–>(v)–>(vi) is also trivial. How can I get (iv) from any one of (ii),(iii) and (vi)?")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-212115")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 4 January 2013")])]

#text("Regarding Exercise 12, ")#mi("m(\\cup_{n=1}^{N}E_n)\\leq \\sum_{n=1}^{N}m(E_n)")#text(" can be established by induction. Hence ")#mi("m(\\cup_{n=1}^{N}E_n)\\leq \\sum_{n=1}^{\\infty}m(E_n)")#text(" for all ")#mi("N")#text(". But I don’t see how this implies ")#mi("m(\\cup_{n=1}^{\\infty}E_n)\\leq \\sum_{n=1}^{\\infty}m(E_n)")#text(". Should one show first that ")#mi("\\lim_{N\\to\\infty}m(\\cup_{n=1}^{N}E_n)=m(\\cup_{n=1}^{\\infty}E_n)")#text("?")

#emph[#text("[Yes – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-212162")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 5 January 2013")])]

#text("In Exercise 13, is there any relationship between ")#mi("\\limsup_{n\\to\\infty} E_n")#text(" and ")#mi("\\limsup_{n\\to\\infty}1_{E_n}(x)")#text("? The discrete metric is very “similar” to the indicator function. Is the pointwise convergence of sets defined in this exercise exactly the same as the “general set convergence” in [this wikipedia article](")#link("http://en.wikipedia.org/wiki/Limit_superior_and_limit_inferior#General_set_convergence")[#text("http://en.wikipedia.org/wiki/Limit_superior_and_limit_inferior#General_set_convergence")]#text(")?")

#emph[#text("[Yes, there is a connection; it is an instructive exercise to work out exactly what it is. – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-212278")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2013")])]

#text("For Exercise 15, Ex.8 (iv) gives the proof when ")#mi("E")#text(" is bounded. How should one deal with the unbounded ")#mi("E")#text("?")

#text("Regarding, Ex.16, most of the “Lebesgue measurable” part of implication is from Ex.8. I don’t see the way to get (i)–>(iii). The boundedness of the open set ")#mi("U")#text(" in (iii) should be somehow from the hypothesis ")#mi("m(E)<+\\infty")#text(". But how should one make such ")#mi("U")#text(" bounded?")

#emph[#text("[Take advantage of monotone convergence (Exercise 11). -T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-212295")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 6 January 2013")])]

#text("I don’t see why the monotone convergence would help for Exercise 15. When ")#mi("m(E)0")#text(", there exists a compact set ")#mi("K\\subset E")#text(" such that ")#mi("m(E)-\\epsilon\\leq m(K)")#text(", i.e., ")#mi("m(E\\setminus K)\\leq\\varepsilon")#text(". Exercise 8 gives a closed but not necessarily bounded ")#mi("K")#text(". (When ")#mi("E")#text(" is bounded, this is done.)")

#text("The technique used for handling an unbounded set ")#mi("E")#text(" in the proof of Lemma 11 is decomposing E with annulus. Locally one can get a compact set from inside, but when taking union, one may not get a compact set again. What I got so far is ")#mi("m(E)=\\sum_{m=1}^{\\infty}m(E\\cap A_{m})=\\sum_{m=1}^{\\infty}\\sup\\{m(K):K\\subset E\\cap A_m, K compact\\}")#text(" where ")#tao-math("A_m=\\{x\\in{\\bf R}^d: m-1\\leq \\left|x\\right|\\leq m\\}", block: false)#text(".")

#text("How would the the monotone convergence in Exercise 11 help??")

#emph[#text("[")#mi("m(E) = \\sup_R m(E \\cap B(0,R))")#text(". See also Trick 6 from ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" -T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-213862")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2013")])]

#text("As you pointed out in Remark 1, there is a tradeoff between having the negative number and infinity. Thus we either work on ")#mi("[0,+\\infty]")#text(" or ")#mi("(-\\infty,+\\infty)")#text(". Why would one not work on ")#mi("(-\\infty,+\\infty]")#text("?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8acfe4de5975e0a6647de3d5d766a58499401d0abbde7b47903a51d600b2efe2-c1e309bea1bf7c3ea035b8b1f0e683b467d4e287b2f6b829f20f2a670a077f2e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jack")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-214022")[#strong[#text("Jack")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2013")])]

#text("This is kind of a dumb question: it’s just because ")#mi("-1\\cdot +\\infty")#text(" would be undefined in ")#mi("(-\\infty,+\\infty]")#text(" I think.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-219793")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 18 March 2013")])]

#text("I saw some books misleadingly call the “Monotone convergence theorem for measurable sets” as “continuity of measure”. Probably because it looks like ")#mi("\\lim_{n\\to\\infty}f(x_n)=f(\\lim_{n\\to\\infty}x_n)")#text(" for a function on a metric space. Is it still possible to view the “MCT for measurable sets” as a result of continuity of ")#mi("m")#text(" on some topological space?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d5b52d01c290918240763d71dea26e2ecc1046280d688b0c3d25e02ebe12a486-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andy Qingyun Zeng")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-225479")[#strong[#text("Andy Qingyun Zeng")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2013")])]

#text("For the example of non-measurable set, can we infer some properties of it, such as density and countablility?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3e35a38a08750eca040933aaa6b9a8aabdad717d4cf37a7e40f835091b12141f-30024861242e6a7296727392800a7e99e8107e68965214fbb0b460b974da8a07.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-228930")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")])]

#text("A remark to unmeasurable set:")

#text("The unmeasurable constructed in the post is called Vitali unmeasurable set,in fact,from its construction,Vitali set is highly undetermined,because it uses Axiom of Choice. The outer measure of the Vitali set ranges over ")#mi("(0,1]")#text(",in fact,I think from its construction,we can that the outer measure of a Vitali set can be any real number in ")#mi("(0,1]")#text(".")

#text("It need not to be dense(But it could be dense),but it is must be uncountable,because any countable set is measurable.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-226659")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("I am particularly interested in Example 1.As had been said by me yesterday in ")#link("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/#comment-226505")[#text("https://terrytao.wordpress.com/2010/09/04/245a-prologue-the-problem-of-measure/#comment-226505")]

#text("I said:")

#text("“”")#linebreak()#text(" So,in the changing from arbitrary finite cover to arbitrary countable cover,there is really something significant happen that result in such difference!Finite cover,though arbitrary,is still finite,we do not expect any thing amazing from finite stuff.But countable infinite is a really big step,there must be something in it that makes things work !But I have to go to sleep first!")#linebreak()#text(" “”")

#text("Now I figure out why Lebesgue outer measure is better than Jordan outer measure,that is ,why arbitrary countable cover is better than arbitrary finite cover.")

#text("When covering finite number of points,in fact,those two types of cover are equivalent,one is not better than the other.")

#text("When covering countable infinite number of points,however,the superiority of the arbitratry countable cover begins to show up.When covering a point,in the case of countable cover,one can always be able to cover this point by “arbitrary” small box,so the “cost” of covering a point can be very small.But in the case of finite cover,the box which cover a point can not be arbitrary small because of the finiteness of the covering,so the “cost” of covering a point can not be very small!For example,the Jordan outer measure of ")#mi("\\mathbf{Z}")#text(" is infinite,but the Lebesgue outer measure of ")#mi("\\mathbf{Z}")#text(" is 0.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/545ded3345ad751bda72f465d06beee1139284ce4c29ed1900a105f0f9deec95-9c8094090b8af83e01f6d3dad22b768d7cc6a96b048fd32203b78d249556ac72.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Luqing Ye")]], [#link("https://terrytao.wordpress.com/2010/09/09/245a-notes-1-lebesgue-measure/comment-page-1/#comment-226664")[#strong[#text("Luqing Ye")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2013")])]

#text("I need to correct what I just said and make some supplements.")

#text("The last sentence of my commet should be deleted.”For example,the Jordan outer measure of \\mathbf{Z} is infinite,but the Lebesgue outer measure of \\mathbf{Z} is 0.”,this is not true,because $\\mathbf{Z}$ does not has Jordan outer measure.")

#text("So this also reflects a big disadvantage of Jordan outer measure,that is ,it can not measure any unbounded sets!")
]
]
