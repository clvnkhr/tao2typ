// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/
// Converted to Typst by tao2typ: "2026-10-14T08:53:27.270055+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“Density Hales-Jewett and Moser numbers” – nearing the final draft", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“Density Hales-Jewett and Moser numbers” – nearing the final draft")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 15 January 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/")[#text("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("After a hiatus of several months, I’ve made an effort to advance the writing of the second ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath1")[#text("Polymath1")]#text(" paper, entitled “")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/01/polymath.pdf")[#text("Density Hales-Jewett and Moser numbers")]#text("“. This is in part due to a request from the Szemeredi ")#strike[#text("60th")]#text(" 70th birthday conference proceedings (which solicited the paper) to move the submission date up from April to February. (Also, the recent launch of ")#link("http://michaelnielsen.org/polymath1/index.php?title=The_Erd%C5%91s_discrepancy_problem")[#text("Polymath5")]#text(" on Tim Gowers blog reminds me that I should get this older project out of the way.)")

#text("The current draft of the paper is ")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/01/polymath.pdf")[#text("here")]#text(", with source files ")#link("http://michaelnielsen.org/polymath1/index.php?title=Outline_of_second_paper")[#text("here")]#text(". I have been trimming the paper, in particular replacing some of the auxiliary or incomplete material in the paper with references to pages on the polymath wiki instead. Nevertheless this is still a large paper, at 51 pages. It is now focused primarily on the computation of the Density Hales-Jewett numbers ")#mi("c_{n,3}")#text(" and the Moser numbers ")#mi("c^{\\prime}_{n,3}")#text(" for all n up to 6, with the latter requiring a significant amount of computer assistance.")

#text("There are a number of minor issues remaining with the paper:")

#enum(start: 1, 
[#text("A picture of a Fujimura set for the introduction would be nice.")],
[#text("In the proof of Theorem 1.3 (asymptotic lower bound for DHJ numbers), it is asserted without proof that the circulant matrix with first row 1,2,…,k-1 is nonsingular. One can prove this claim by computing the Fourier coefficients ")#mi("\\sum_{j=1}^{k-1} j e^{2\\pi i j t / (k-1)}")#text(" for all t, but is there a slicker way to see this (e.g. by citing a reference?).")],
[#text("Reference [15] (which is Komlos’s lower bound on the Moser numbers) is missing a volume number. The reference is currently given as")

#metadata(none) <tao-f057d9ad07a460347579>

#text("J. Koml\u{13}os, solution to problem P.170 by Leo Moser, Canad. Math.. Bull. vol ??? (1972), 312-313, 1970.")]
)

#text("Finally, the text probably needs to be proofread one or two more times before it is ready to go, hopefully by early February. There is still also one last opportunity to propose non-trivial restructuring of the paper (in particular, if there are other ways to trim the size of the paper, this may be worth looking into).")

#pagebreak(weak: true)
#heading(level: 1)[#text("Comments (38)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8cc6267d870b157672601b54960410aac0f572b90ac5fcef987e6025e6dfc0d1-55f258c2e63d1c6d10765bf48cef53a407f1076ae69318e799666e31d3c3fb5e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Qiaochu Yuan")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43249")[#strong[#text("Qiaochu Yuan")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")])]

#text("2. The algebra of circulant matrices of order ")#mi("n")#text(" is isomorphic to ")#mi("\\mathbb{C}[x]/(x^n - 1)")#text(", where ")#mi("x")#text(" is the cyclic permutation matrix of order ")#mi("n")#text(". In this algebra, it’s clear that ")#mi("1 + 2x + 3x^2 + ... + nx^{n-1} = \\frac{-n(1-x)}{(1 - x)^2}")#text(", so the circulant matrix you’re looking at is invertible.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e4e27de4319aa4e997bf712ab1ca7d3c6f9f09351a9c421ccc3cd27ca9ba5dd6-110c739cd644f2b9aef0c5ed17caaa8a191dfc24fc30af110af84d2cb6f2190b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kevin Costello")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43251")[#strong[#text("Kevin Costello")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")])]

#text("Another way of approaching (2) is to look at the vectors ")#mi("(A_1-A_2) +(A_{i+1}-A_{i})")#text(", where ")#mi("A_i")#text(" denotes the ")#mi("i^{th}")#text(" row of ")#mi("A")#text(" and ")#mi("A_{k+1}")#text(" equals ")#mi("A_1")#text(".")

#text("Each such vector is of the form ")#mi("(0, 0, \\dots, -k, 0 \\dots, 0, k)")#text(", so a hypothetical vector in the nullspace would have to have all of its entries equal, which can immediately be rejected by considering the first row.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43279")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("With a proof this sweet, it would be wrong to omit it.")

#text("There’s a nice formula for the determinant of the circulant here:")#linebreak()#text(" ")#link("http://mathworld.wolfram.com/CirculantDeterminant.html")[#text("http://mathworld.wolfram.com/CirculantDeterminant.html")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5f409a895daf9488997fa09eb555aafdfb69c976b56a0467132e0c269d73ea69-b81323638f8768941359a1af430b6331294b2d10ce69e947684d77436c2d6e67.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jitse Niesen")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43254")[#strong[#text("Jitse Niesen")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")])]

#text("Theorem 3 of Daryl Geller, Irwin Kra, Sorin Popescu and Santiago Simanca, “On circulant matrices”, ")#link("http://www.math.sunysb.edu/~sorin/eprints/circulant.pdf")[#text("http://www.math.sunysb.edu/~sorin/eprints/circulant.pdf")]#text(", states that a circulant matrix whose first row is an increasing sequence of nonnegative numbers, is nonsingular.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b9946c9121e0cb957d136b5263170c8a16bc3714a9752b67f86f1a8e55f6903c-d05b29fec6ff76805e2997f2a2e0fd4a3c2f601ae9c890328792ae8a4468c320.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of jozsef")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43256")[#strong[#text("jozsef")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")])]

#text("” This is in part due to a request from the Szemeredi 60th birthday conference proceedings ”")#linebreak()#text(" I agree that Endre looks younger than 60, however this conference will celebrate his 70th birthday :)")

#emph[#text("[Oops! Corrected, thanks. I hope Endre won’t be offended – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43258")[#strong[#text("Density Hales-Jewett and Moser numbers « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")]

#text("[…] Density Hales-Jewett and Moser numbers By kristalcantwell The deadline for this paper has changed. The deadline has been moved from February to April. See the following post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43259")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")])]

#text("I looked at the Canadian Mathematic bulletin site here:")

#link("http://www.cms.math.ca/cmb/")[#text("http://www.cms.math.ca/cmb/")]

#text("It said that the volume number of 1972 is 15.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43260")[#strong[#text("Mathematics, Science, and Blogs « Combinatorics and more")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")]

#text("[…] (October 09 ) The paper with the DHJ proof is now uploaded. (January 2010) A draft of a second paper devoted to the study of DHJ and Moser numbers can be found here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/d2440d6a669b266b1e0ded0cf262bd8572dc362e7aa000fb14c6782e94a6cbf7-545719ca34e8c1d255335ce8638b341f6cc5ba0edfe9ede6f49618c2d9c7de51.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matemáticos colaboram num projecto aberto de investigação conjunta através do blogue do Professor Timothy Gowers « problemas | teoremas")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43262")[#strong[#text("Matemáticos colaboram num projecto aberto de investigação conjunta através do blogue do Professor Timothy Gowers « problemas | teoremas")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2010")])]

#text("[…] and Moser numbers”, em versão pdf é este. A este respeito, o Professor Terence Tao escreveu no seu […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43264")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 17 January 2010")])]

#text("I have been going through the paper and at page 20 it gives the following url: ")#link("http://abel.math.umu.se/klasm/Data/HJ/")[#text("http://abel.math.umu.se/klasm/Data/HJ/")]#text(" as a reference. I have tried this address and it gave me a 404 page. So there may be problems with this url.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43267")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("Kristal, as you have written it there is a missing tilde, or ~, before klasm in the address. If you add that it works.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43276")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("I looked at it again and I think what happen is that the missing symbol is in the paper but it is missing in the font and so I am getting a space. So at least my software is missing a font and leaving it out.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43280")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("Theorem 1.3 is not mentioned in the abstract.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43281")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("The comment in Theorem 1.4 stating that the sequence is now in the OEIS should be before the theorem.")

#text("BTW, the “corrections” I’m posting are just my opinion, so please accept or ignore them as you find appropriate.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43282")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("page 5: change “it gives a lower bound of $c’_{6,3}=344$” to “it gives a lower bound of $c’_{6,3} \\geq 344$”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43283")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("Footnote on page 5: change “no all equilateral” to “no equilateral”")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43284")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("If somebody emails me a good Fujimura set, I can make the picture (I made the other pics in the introduction, so the style would be the same).")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43291")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("I think the following article in the polymath wiki has some examples of Fujimura sets ")#link("http://michaelnielsen.org/polymath1/index.php?title=Fujimura%27s_problem")[#text("http://michaelnielsen.org/polymath1/index.php?title=Fujimura%27s_problem")]#text(" possibly one of them might work.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43285")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("On page 10, in the proof of Theorem 1.3, in the last line of text, we have “applying (2.1)”, but it is actually using something more general than (2.1). Can fix by changing (2.1), or by changing the reference to “applying the obvious generalization of (2.1) to arbitrary $k$”.")

#text("Also in this proof, change “simplices $\\Delta_{n,k}$” to “simplices in $\\Delta_{n,k}$”.")

#text("Also in this proof, we use the notation $n/k + \\vec{s}$ to mean the vector, all of whose components are Floor[n/k], plus the vector s. (notation used again two lines later.) Is this standard usage? I recommend changing the period at the end of the definition of B to a comma, and then continuing, “where \\vec{c} is the $k-1$ dimensional vector, all of whose entries are $\\lfloor n/k \\rfloor$.” Two lines later, change “c” to “M\\vec{c}$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43286")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 18 January 2010")])]

#text("Is the proof of Theorem 1.3 the only place we use “\\vec” to denote elements of ")#mi("\\Delta_{n,k}")#text("?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43298")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 January 2010")])]

#text("Thanks for all the corrections! I’ve uploaded a revised version at")

#link("https://terrytao.files.wordpress.com/2010/01/polymath1.pdf")[#text("Click to access polymath1.pdf")]

#text("The only outstanding issue now that I know of is the image of the Fujimura set (though of course more proofreading is very welcome).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43313")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 20 January 2010")])]

#text("I now see the tilde in the web address. I was looking at volume numbers in the bibliography and they don’t seem to be standardized. Some are boldfaced some are not, some are proceeded by the word volume or vol. So possibly one way could be chosen to write all the volume numbers.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db0fcf11c83d74b458130ac724f09dc2543635e762a976dfcd62ea929dfd26da-9c7ecc73c5e8ad0a107a2751887388a9cb6b66a617cb5026458d3e4aae55cd48.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of obryant")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43321")[#strong[#text("obryant")]]#text(size: 9pt, fill: rgb("596477"), " · 21 January 2010")])]

#text("The new abstract has “We also some”, which should perhaps be “we also prove some”.")

#text("The last equation of the abstract should be $2k>2^\\ell$.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43336")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("A new version of the paper, incorporating all the latest changes and also some nice new figures by Kevin:")

#link("https://terrytao.files.wordpress.com/2010/01/polymath2.pdf")[#text("Click to access polymath2.pdf")]

#text("It’s looking close to ready now…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43341")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Oops, I forgot to make the bibliography consistent as Kristal suggested. Here is a version with a better biblio:")

#link("https://terrytao.files.wordpress.com/2010/01/polymath3.pdf")[#text("Click to access polymath3.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43345")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 23 January 2010")])]

#text("Here are some further suggestions on references/bibliography:")

#text("1) On preprints/arxiv preprints:")#linebreak()#text(" consistently with arxiv number/link or consistently not.")#linebreak()#text(" [23] has the number, most others not.")

#text("2) On books: with place of publication. (This is an old tradition).")

#text("3) Abbreviation of Journals consistently, according to MathScinet")#linebreak()#text(" e.g. Canad. Math. Bull. is abbreviated several entries are not abbreviated.")

#text("some detailed comments below.")

#text("[2] arxiv, see above")#linebreak()#text(" [3] place of publication: Cambridge")#linebreak()#text(" [7] Bull. not Bull,")#linebreak()#text(" [13] tilde ~ before sorin missing (same latex problem as before)")#linebreak()#text(" [14] arxiv see above")#linebreak()#text(" [20] arxiv see above")#linebreak()#text(" [25] add hyphen between pages, I think, 332-344,")#linebreak()#text(" [27] add place of publication: Heidelberg")#linebreak()#text(" [28] year in brackets")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43371")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2010")])]

#text("I’ve made the changes to the bibliography at")

#link("https://terrytao.files.wordpress.com/2010/01/polymath4.pdf")[#text("Click to access polymath4.pdf")]

#text("To ensure that this process terminates, I’ll arbitrarily set Feb 1 as the self-imposed deadline for submission, and then submit to the Szemeredi conference proceedings and to the arXiv.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43403")[#strong[#text("Christian")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("Suggestion for section 4:")

#text("After a major part of the section was written, the results had been improved and put in front of the remainder of the section. The remaining part was kept since those constructions still give some insight.")

#text("In any case the following sentences could be adjusted:")

#text("1) formula 4.2 closer to the beginning of the section.")#linebreak()#text(" 2) page 22, 2nd paragraph, 2nd sentence (In this section…) is")#linebreak()#text(" obsolete now.")#linebreak()#text(" 3) page 23, last paragraph, comment that this construction gives the")#linebreak()#text(" best value C is not true any longer.")

#text("I am now looking forward to the Szemeredi Festsschrift!")

#text("Many thanks to Terry for his great supervision of the project, and to all others who contributed!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of misha")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43405")[#strong[#text("misha")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("LYM (e.g. on page 6) and LMY (e.g. on page 5) are used interchangeably.")

#text("m")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43406")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("A new version of the draft:")

#link("https://terrytao.files.wordpress.com/2010/01/polymath5.pdf")[#text("Click to access polymath5.pdf")]

#text("It includes a second picture of a Fujimura set by Jason Dyer, and incorporates the preceding corrections.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43407")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("I think the following (on the bottom of page 9) is missing a punctuation mark:")

#text("… to the following Fujimura set construction It is convenient to write …")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of misha")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43408")[#strong[#text("misha")]]#text(size: 9pt, fill: rgb("596477"), " · 28 January 2010")])]

#text("Sorry, the abstract is referring to LYM inequality, the body to LMY.")

#text("m")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43432")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2010")])]

#text("One of the participants pointed out to me by email that there is one last reference question which it may be good to resolve before submitting, namely to track down the reference of Fujimura in which he introduces (essentially) the concept of what we call a Fujimura set. Right now all we have is a web URL,")

#link("http://www.puzzles.com/PuzzlePlayground/CoinsAndTriangles/CoinsAndTriangles.htm")[#text("http://www.puzzles.com/PuzzlePlayground/CoinsAndTriangles/CoinsAndTriangles.htm")]

#text("but apparently in one of Martin Gardner’s columns “Eccentric Chess and Other Problems”, from 1979, he attributes the puzzle to a “recent book” of Fujimura. The one germane publication we know of of Fujimura is “the Tokyo puzzles”, but this puzzle does not appear to be in that book. We’ve had good luck with using the polymath community to settle other reference questions of this sort, so I’m tossing this out here in the hope that it works again…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43433")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2010")])]

#text("Just as a quick clarification, the article is in the book Mathematical Circus, so the original Scientific American article might be back a year or two.")

#text("The Tokyo Puzzles was from 1978 so it’s the most likely candidate, but it doesn’t seem to be in there. It is possible I am simply blind, but I checked through quite a few times. I’m guessing (since Gardiner was editor of The Tokyo Puzzles) he learned of the new puzzle simply through side personal correspondence, meaning likely the original book is only available in Japanese.")

#text("If someone has contact information for Martin Gardiner himself, he might be able to resolve this.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43435")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 31 January 2010")])]

#text("The weekand has given me time to do a bit of proof reading too.")

#text("On page 2 we have the sentence: “The proof of [2] also used ergodic theory, but the proof in [23] was combinatorial and gave e ffective bounds for cn;k in the limit n -> 1.” Should this sentence be in past tense? It sound a bit strange to me, but english is not my first language.")

#text("Page 9. “An integer program2 was run…” Strictly speaking one doesn’t run an integer program, after all it is a set of linear inequalities and an objective function. Maybe “An integer program was solved” instead?")

#text("Page 9. The same paragraph which contains the previous sentence ends with a “:” and the next paragraph is just a single line which should probably be merged into the same paragraph.")

#text("Section 3. It could possibly be helpful to divide this section into subsections for difference values of n.")

#text("Page 19. Again “An integer program was run”")

#text("Page 19. Same paragraph. Here the reference to the list of optimizers is done as an URL but on page 9 this was done as ref [17]. I think it is better to be consistent and use [17].")

#text("Reference 17 I wouldn’t mind getting some umlauts to have an ö instead on an o in my name :) They are even separate letters in the Swedish alphabet.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43445")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2010")])]

#text("Klas, in that reference, you list values up to n=20, but your link to the actual Fujimura sets only goes up to 10. Do you still have the Fujimura sets up to 20?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43446")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 1 February 2010")])]

#text("Michael,")#linebreak()#text(" The files with Fujimura sets which I have posted are only for values of n for which I have all such sets. I can put some partial files with example sets for larger n there as well, but i might have to generate some of them anew.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c20e3fc75eac33d9bdc9353bf824408e26824cb8c9c25024cd1420a0abee396d-3de07bdaf61827c67c4f641ac309247dd5e19c75f26050639e053bee3c391574.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael")]], [#link("https://terrytao.wordpress.com/2010/01/15/density-hales-jewett-and-moser-numbers-nearing-the-final-draft/#comment-43470")[#strong[#text("Michael")]]#text(size: 9pt, fill: rgb("596477"), " · 3 February 2010")])]

#text("I think it would be good to have an example of each n, if it is easy to regenerate.")
]
]
]
