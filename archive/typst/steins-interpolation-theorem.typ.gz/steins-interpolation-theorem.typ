// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:18:03.188119+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Stein’s interpolation theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Stein’s interpolation theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 3 May 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/")[#text("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In a few weeks, Princeton University will host a ")#link("http://www.math.princeton.edu/conference/stein2011/")[#text("conference in Analysis and Applications")]#text(" in honour of the 80th birthday of ")#link("http://en.wikipedia.org/wiki/Elias_M._Stein")[#text("Elias Stein")]#text(" (though, technically, Eli’s 80th birthday was actually in January). As one of Eli’s students, I was originally scheduled to be one of the speakers at this conference; but unfortunately, for family reasons I will be unable to attend. In lieu of speaking at this conference, I have decided to devote some space on this blog for this month to present some classic results of Eli from his many decades of work in harmonic analysis, ergodic theory, several complex variables, and related topics. My choice of selections here will be a personal and idiosyncratic one; the results I present are not necessarily the “best” or “deepest” of his results, but are ones that I find particularly elegant and appealing. (There will also inevitably be some overlap here with Charlie Fefferman’s article “")#link("http://www.ams.org/mathscinet-getitem?mr=1315540")[#text("Selected theorems by Eli Stein")]#text("“, which not coincidentally was written for Stein’s 60th birthday conference in 1991.)")

#text("In this post I would like to describe one of Eli Stein’s very first results that is still used extremely widely today, namely his ")#link("http://www.ams.org/mathscinet-getitem?mr=82586")[#text("interpolation theorem from 1956")]#text(" (and its refinement, the ")#link("http://www.ams.org/mathscinet-getitem?mr=447953")[#text("Fefferman-Stein interpolation theorem from 1972")]#text("). This is a deceptively innocuous, yet remarkably powerful, generalisation of the classic ")#link("http://en.wikipedia.org/wiki/Riesz%E2%80%93Thorin_theorem")[#text("Riesz-Thorin interpolation theorem")]#text(" which uses methods from complex analysis (and in particular, the ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f%27s_theorem")[#text("Lindelöf theorem")]#text(" or the ")#link("http://en.wikipedia.org/wiki/Phragm%C3%A9n%E2%80%93Lindel%C3%B6f_principle")[#text("Phragmén-Lindelöf principle")]#text(") to show that if a linear operator ")#mi("{T: L^{p_0}(X) + L^{p_1}(X) \\rightarrow L^{q_0}(Y) + L^{q_1}(Y)}")#text(" from one (")#mi("{\\sigma}")#text("-finite) measure space ")#mi("{X = (X,{\\mathcal X},\\mu)}")#text(" to another ")#mi("{Y = (Y, {\\mathcal Y}, \\nu)}")#text(" obeyed the estimates ")#metadata(none) <tao-512f26ada3c3d634ac3c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left\\| Tf \\right\\|_{L^{q_0}(Y)} \\leq B_0 \\left\\|f\\right\\|_{L^{p_0}(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^{p_0}(X)}")#text(" and ")#metadata(none) <tao-628b49d96dcde97a430d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#tao-math("\\left\\| Tf \\right\\|_{L^{q_1}(Y)} \\leq B_1 \\left\\|f\\right\\|_{L^{p_1}(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^{p_1}(X)}")#text(", where ")#mi("{1 \\leq p_0,p_1,q_0,q_1 \\leq \\infty}")#text(" and ")#mi("{B_0,B_1 > 0}")#text(", then one automatically also has the interpolated estimates ")#metadata(none) <tao-a34e092b08c15f05ec8b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left\\| Tf \\right\\|_{L^{q_\\theta}(Y)} \\leq B_\\theta \\left\\|f\\right\\|_{L^{p_\\theta}(X)}", block: true)]]

#text("for all ")#mi("{f \\in L^{p_\\theta}(X)}")#text(" and ")#mi("{0 \\leq \\theta \\leq 1}")#text(", where the quantities ")#mi("{p_\\theta, q_\\theta, B_\\theta}")#text(" are defined by the formulae")

#tao-aligned(keep: true)[


#tao-math("\\frac{1}{p_\\theta}  & = \\frac{1-\\theta}{p_0} + \\frac{\\theta}{p_1}", block: true)



#tao-math("\\frac{1}{q_\\theta}  & = \\frac{1-\\theta}{q_0} + \\frac{\\theta}{q_1}", block: true)



#tao-math("B_\\theta  & = B_0^{1-\\theta} B_1^\\theta.", block: true)
]

#text("The Riesz-Thorin theorem is already quite useful (it gives, for instance, by far the quickest proof of the ")#link("http://en.wikipedia.org/wiki/Hausdorff%E2%80%93Young_inequality")[#text("Hausdorff-Young inequality")]#text(" for the Fourier transform, to name just one application), but it requires the ")#emph[#text("same")]#text(" linear operator ")#mi("{T}")#text(" to appear in ")#link(<tao-512f26ada3c3d634ac3c>)[#text("(1)")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("(2)")]#text(", and ")#link(<tao-a34e092b08c15f05ec8b>)[#text("(3)")]#text(". Eli Stein realised, though, that due to the complex-analytic nature of the proof of the Riesz-Thorin theorem, it was possible to allow ")#emph[#text("different")]#text(" linear operators to appear in ")#link(<tao-512f26ada3c3d634ac3c>)[#text("(1)")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("(2)")]#text(", ")#link(<tao-a34e092b08c15f05ec8b>)[#text("(3)")]#text(", so long as the dependence was analytic. A bit more precisely: if one had a family ")#mi("{T_z}")#text(" of operators which depended in an analytic manner on a complex variable ")#mi("{z}")#text(" in the strip ")#mi("{\\{ z \\in {\\bf C}: 0 \\leq \\text{Re}(z) \\leq 1 \\}}")#text(" (thus, for any test functions ")#mi("{f, g}")#text(", the inner product ")#mi("{\\langle T_z f, g \\rangle}")#text(" would be analytic in ")#mi("{z}")#text(") which obeyed some mild regularity assumptions (which are slightly technical and are omitted here), and one had the estimates")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_{0+it} f \\right\\|_{L^{q_0}(Y)} \\leq C_t \\left\\|f\\right\\|_{L^{p_0}(X)}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_{1+it} f \\right\\|_{L^{q_1}(Y)} \\leq C_t\\left\\|f\\right\\|_{L^{p_1}(X)}", block: true)]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(" and some quantities ")#mi("{C_t}")#text(" that grew at most exponentially in ")#mi("{t}")#text(" (actually, any growth rate significantly slower than the double-exponential ")#tao-math("{e^{\\exp(\\pi \\left|t\\right|)}}", block: false)#text(" would suffice here), then one also has the interpolated estimates")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_\\theta f \\right\\|_{L^{q_\\theta}(Y)} \\leq C^{\\prime} \\left\\|f\\right\\|_{L^{p_\\theta}(X)}", block: true)]]

#text("for all ")#mi("{0 \\leq \\theta \\leq 1}")#text(" and a constant ")#mi("{C^{\\prime}}")#text(" depending only on ")#mi("{C, p_0, p_1, q_0, q_1}")#text(".")

#metadata(none) <tao-84d30be66876c00158db>

#text("In ")#link("http://www.ams.org/mathscinet-getitem?mr=1315540")[#text("Fefferman’s survey")]#text(", he notes the proof of the Stein interpolation theorem can be obtained from that of the Riesz-Thorin theorem simply “by adding a single letter of the alphabet”. Indeed, the way the Riesz-Thorin theorem is proven is to study an expression of the form")

#align(center)[#tao-fit-display[#mitex("F(z) := \\int_Y T f_z(y) g_z(y)\\ dy,")]]

#text("where ")#mi("{f_z, g_z}")#text(" are functions depending on ")#mi("{z}")#text(" in a suitably analytic manner, for instance taking ")#tao-math("{f_z = \\left|f\\right|^{\\frac{1-z}{p_0}+\\frac{z}{p_1}} \\text{sgn}(f)}", block: false)#text(" for some test function ")#mi("{f}")#text(", and similarly for ")#mi("{g}")#text(". If ")#mi("{f_z, g_z}")#text(" are chosen properly, ")#mi("{F}")#text(" will depend analytically on ")#mi("{z}")#text(" as well, and the two hypotheses ")#link(<tao-512f26ada3c3d634ac3c>)[#text("(1)")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("(2)")]#text(" give bounds on ")#mi("{F(0+it)}")#text(" and ")#mi("{F(1+it)}")#text(" for ")#mi("{t \\in {\\bf R}}")#text(" respectively. The ")#link("http://en.wikipedia.org/wiki/Lindel%C3%B6f%27s_theorem")[#text("Lindelöf theorem")]#text(" then gives bounds on intermediate values of ")#mi("{F}")#text(", such as ")#mi("{F(\\theta)}")#text("; and the Riesz-Thorin theorem can then be deduced by a duality argument. (This is covered in many graduate real analysis texts; I myself covered it ")#link("https://terrytao.wordpress.com/2009/03/30/245c-notes-1-interpolation-of-lp-spaces/")[#text("here")]#text(".)")

#text("The Stein interpolation theorem proceeds by instead studying the expression")

#align(center)[#tao-fit-display[#mitex("F(z) := \\int_Y T_z f_z(y) g_z(y)\\ dy.")]]

#text("One can then repeat the proof of the Riesz-Thorin theorem more or less ")#emph[#text("verbatim")]#text(" to obtain the Stein interpolation theorem.")

#text("The ability to vary the operator ")#mi("{T}")#text(" makes the Stein interpolation theorem significantly more flexible than the Riesz-Thorin theorem. We illustrate this with the following sample result:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" For any (test) function ")#mi("{f: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(", let ")#mi("{Tf: {\\bf R}^2 \\rightarrow {\\bf R}}")#text(" be the average of ")#mi("{f}")#text(" along an arc of a parabola:")

#align(center)[#tao-fit-display[#mitex("Tf(x_1,x_2) := \\int_{\\bf R} f(x_1-t, x_2-t^2)\\eta(t)\\ dt")]]

#text("where ")#mi("{\\eta}")#text(" is a bump function supported on (say) ")#mi("{[-1,1]}")#text(". Then ")#mi("{T}")#text(" is bounded from ")#mi("{L^{3/2}({\\bf R}^2)}")#text(" to ")#mi("{L^3({\\bf R}^2)}")#text(", thus ")#metadata(none) <tao-4e07408562bedb8b60ce>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#tao-math("\\left\\|Tf\\right\\|_{L^3({\\bf R}^2)} \\leq C \\left\\|f\\right\\|_{L^{3/2}({\\bf R}^2)}.", block: true)]]
]

#text("There is nothing too special here about the parabola; the same result in fact holds for convolution operators on any arc of a smooth curve with nonzero curvature (and there are many extensions to higher dimensions, to variable-coefficient operators, etc.). We will however restrict attention to the parabola for sake of exposition. One can view ")#mi("{Tf}")#text(" as a convolution ")#mi("{Tf = f * \\sigma}")#text(", where ")#mi("{\\sigma}")#text(" is a measure on the parabola arc ")#tao-math("{\\{ (t,t^2): \\left|t\\right| \\leq 1 \\}}", block: false)#text(". We will also be somewhat vague about what “test function” means in this exposition in order to gloss over some minor technical details.")

#text("By testing ")#mi("{T}")#text(" (and its adjoint) on the indicator function of a small ball of some radius ")#mi("{\\delta > 0}")#text(" (or of small rectangles such as ")#mi("{[-\\delta,\\delta] \\times [0,\\delta^2]}")#text(") one sees that the exponent ")#mi("{L^{3/2}}")#text(", ")#mi("{L^3}")#text(" here are best possible.")

#text("This proposition was first proven ")#link("http://www.ams.org/mathscinet-getitem?mr=358443")[#text("by Littman in 1973")]#text(" using the Stein interpolation theorem. To illustrate the power of this theorem, it should be noted that for almost two decades this was the only known proof of this result; a proof based on multilinear interpolation (exploiting the fact that the exponent ")#mi("{3}")#text(" in ")#link(<tao-4e07408562bedb8b60ce>)[#text("(4)")]#text(" is an integer) was obtained ")#link("http://www.ams.org/mathscinet-getitem?mr=1180631")[#text("by Oberlin")]#text(", and a fully combinatorial proof was only obtained in 2008 in ")#link("http://www.math.berkeley.edu/~mchrist/Papers/quasiextremal.pdf")[#text("an unpublished note of Christ")]#text(" (see also the recent papers ")#link("http://www.ams.org/mathscinet-getitem?mr=2727644")[#text("of Stovall")]#text(" and ")#link("http://www.ams.org/mathscinet-getitem?mr=2720243")[#text("of Dendrinos-Laghi-Wright")]#text(" for further extensions of the combinatorial argument).")

#text("To motivate the Stein interpolation argument, let us first try using the Riesz-Thorin interpolation theorem first. The exponent pair ")#mi("{L^{3/2} \\rightarrow L^3}")#text(" is an interpolant between ")#mi("{L^2 \\rightarrow L^2}")#text(" and ")#mi("{L^1 \\rightarrow L^\\infty}")#text(", so a first attempt to proceed here would be to establish the bounds ")#metadata(none) <tao-8541c2d149faea7b7e53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#tao-math("\\left\\|Tf\\right\\|_{L^2({\\bf R}^2)} \\leq C \\left\\|f\\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("and ")#metadata(none) <tao-fa3198053435549e9392>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("\\left\\|Tf\\right\\|_{L^\\infty({\\bf R}^2)} \\leq C \\left\\|f\\right\\|_{L^1({\\bf R}^2)}", block: true)]]

#text("for all (test) functions ")#mi("{f}")

#text("The bound ")#link(<tao-8541c2d149faea7b7e53>)[#text("(5)")]#text(" is an easy consequence of ")#link("http://en.wikipedia.org/wiki/Minkowski_inequality#Minkowski.27s_integral_inequality")[#text("Minkowski’s integral inequality")]#text("(or Young’s inequality, noting that ")#mi("{\\sigma}")#text(" is a finite measure). On the other hand, because the measure ")#mi("{\\sigma}")#text(" is not absolutely continuous, let alone arising from an ")#mi("{L^\\infty({\\bf R}^2)}")#text(" function, the estimate ")#link(<tao-fa3198053435549e9392>)[#text("(6)")]#text(" is very false. For instance, if one applies ")#mi("{Tf}")#text(" to the indicator function ")#mi("{1_{[-\\delta,\\delta] \\times [-\\delta,\\delta]}}")#text(" for some small ")#mi("{\\delta>0}")#text(", then the ")#mi("{L^1}")#text(" norm of ")#mi("{f}")#text(" is ")#mi("{\\delta^2}")#text(", but the ")#mi("{L^\\infty}")#text(" norm of ")#mi("{Tf}")#text(" is comparable to ")#mi("{\\delta}")#text(", contradicting ")#link(<tao-fa3198053435549e9392>)[#text("(6)")]#text(" as one sense ")#mi("{\\delta}")#text(" to zero.")

#text("To get around this, one first notes that there is a lot of “room” in ")#link(<tao-8541c2d149faea7b7e53>)[#text("(5)")]#text(" due to the smoothing properties of the measure ")#mi("{\\sigma}")#text(". Indeed, from Plancherel’s theorem one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\|f\\right\\|_{L^2({\\bf R}^2)} = \\left\\| \\hat f \\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\left\\|Tf\\right\\|_{L^2({\\bf R}^2)} = \\left\\| \\hat f \\hat \\sigma \\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("for all test functions ")#mi("{f}")#text(", where")

#align(center)[#tao-fit-display[#mitex("\\hat f(\\xi) := \\int_{{\\bf R}^2} e^{-2\\pi i x \\cdot \\xi} f(x)\\ dx")]]

#text("is the Fourier transform of ")#mi("{f}")#text(", and")

#align(center)[#tao-fit-display[#mitex("\\hat \\sigma(\\xi_1, \\xi_2) := \\int_{\\bf R} e^{-2\\pi i (t \\xi_1 + t^2 \\xi_2)} \\eta(t)\\ dt.")]]

#text("It is clear that ")#mi("{\\hat \\sigma(\\xi)}")#text(" is uniformly bounded in ")#mi("{\\xi}")#text(", which already gives ")#link(<tao-8541c2d149faea7b7e53>)[#text("(5)")]#text(". But a standard application of the method of stationary phase reveals that one in fact has a decay estimate ")#metadata(none) <tao-0d6d05d475fcf5fd0a53>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#tao-math("\\left|\\hat \\sigma(\\xi)\\right| \\leq \\frac{C}{\\left|\\xi\\right|^{1/2}}", block: true)]]

#text("for some ")#mi("{C > 0}")#text(". This shows that ")#mi("{Tf}")#text(" is not just in ")#mi("{L^2}")#text(", but is somewhat smoother as well; in particular, one has")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{1/2} Tf \\right\\|_{L^2({\\bf R}^2)} \\leq C \\left\\| f\\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("for any (fractional) differential operator ")#mi("{D^{1/2}}")#text(" of order ")#mi("{1/2}")#text(". (Here we adopt the usual convention that the constant ")#mi("{C}")#text(" is allowed to vary from line to line.)")

#text("Using the numerology of the Stein interpolation theorem, this suggests that if we can somehow obtain the counterbalancing estimate")

#align(center)[#tao-fit-display[#tao-math("\\left\\| D^{-1} Tf \\right\\|_{L^\\infty({\\bf R}^2)} \\leq C \\left\\|f\\right\\|_{L^1({\\bf R}^2)}", block: true)]]

#text("for some differential operator ")#mi("{D^{-1}}")#text(" of order ")#mi("{-1}")#text(", then we should be able to interpolate and obtain the desired estimate ")#link(<tao-4e07408562bedb8b60ce>)[#text("(4)")]#text(". And indeed, we can take an antiderivative in the ")#mi("{x_2}")#text(" direction, giving the operator")

#align(center)[#tao-fit-display[#mitex("\\partial_{x_2}^{-1} Tf(x_1,x_2) := \\int_{\\bf R} \\int_{-\\infty}^0 f(x_1-t, x_2-t^2-s)\\ \\eta(t) dt ds;")]]

#text("and a simple change of variables does indeed verify that this operator is bounded from ")#mi("{L^1({\\bf R}^2)}")#text(" to ")#mi("{L^\\infty({\\bf R}^2)}")#text(".")

#text("Unfortunately, the above argument is not rigorous, because we need an analytic family of operators ")#mi("{T_z}")#text(" in order to invoke the Stein interpolation theorem, rather than just two operators ")#mi("{T_0}")#text(" and ")#mi("{T_1}")#text(". This turns out to require some slightly tricky complex analysis: after some trial and error, one finds that one can use the family ")#mi("{T_z}")#text(" defined for ")#mi("{\\text{Re}(z) > 1/3}")#text(" by the formula")

#align(center)[#tao-fit-display[#mitex("T_z f(x_1,x_2) = \\frac{1}{\\Gamma((3z-1)/2)} \\int_{\\bf R} \\int_{-\\infty}^0 \\frac{1}{s^{(3-3z)/2}} f(x_1-t, x_2-t^2-s)\\ \\eta(t) dt ds")]]

#text("where ")#mi("{\\Gamma}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Gamma_function")[#text("Gamma function")]#text(", and extended to the rest of the complex plane by analytic continuation. The Gamma factor is a technical one, needed to compensate for the divergence of the weight ")#mi("{\\frac{1}{s^{(3-3z)/2}}}")#text(" as ")#mi("{z}")#text(" approaches ")#mi("{1/3}")#text("; it also makes the Fourier representation of ")#mi("{T_z}")#text(" cleaner (indeed, ")#mi("{T_z f}")#text(" is morally ")#mi("{\\partial_{x_2}^{(1-3z)/2} f * \\sigma}")#text("). It is then easy to verify the estimates ")#metadata(none) <tao-b3763d07241d7157fbfe>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\left\\|T_{1+it} f \\right\\|_{L^\\infty({\\bf R}^2)} \\leq C_t \\left\\|f\\right\\|_{L^1({\\bf R}^2)}", block: true)]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(" (with ")#mi("{C_t}")#text(" growing at a controlled rate), while from Fourier analysis one also can show that ")#metadata(none) <tao-24879481582d22931cd5>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#tao-math("\\left\\|T_{0+it} f \\right\\|_{L^2({\\bf R}^2)} \\leq C_t \\left\\|f\\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("for all ")#mi("{t \\in {\\bf R}}")#text(". Finally, one can verify that ")#mi("{T_{1/3} = T}")#text(", and ")#link(<tao-4e07408562bedb8b60ce>)[#text("(4)")]#text(" then follows from the Stein interpolation theorem.")

#text("It is instructive to compare this result with what can be obtained by real-variable methods. One can perform a smooth dyadic partition of unity")

#align(center)[#tao-fit-display[#mitex("\\delta(s) = \\phi(s) + \\sum_{j=1}^\\infty 2^j \\psi( 2^j s )")]]

#text("for some bump function ")#mi("{\\phi}")#text(" (of total mass ")#mi("{1}")#text(") and bump function ")#mi("{\\psi}")#text(" (of total mass zero), which (formally, at least) leads to the decomposition")

#align(center)[#tao-fit-display[#mitex("T f = T_0 f + \\sum_{j=1}^\\infty T_j f")]]

#text("where ")#mi("{T_0 f}")#text(" is a harmless smoothing operator (which certainly maps ")#mi("{L^{3/2}({\\bf R}^2)}")#text(" to ")#mi("{L^3({\\bf R}^2)}")#text(") and")

#align(center)[#tao-fit-display[#mitex("T_j f(x_1,x_2) := \\int_{\\bf R} \\int_{\\bf R} 2^j \\psi(2^j s) f(x_1-t, x_2-t^2-s) \\eta(t)\\ dt ds.")]]

#text("It is not difficult to show that ")#metadata(none) <tao-10317f55580c96626da9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\left\\| T_j f \\right\\|_{L^\\infty({\\bf R}^2)} \\leq C 2^j \\left\\|f\\right\\|_{L^1({\\bf R}^2)}", block: true)]]

#text("while a Fourier-analytic computation (using ")#link(<tao-0d6d05d475fcf5fd0a53>)[#text("(7)")]#text(") reveals that ")#metadata(none) <tao-5093a78d628ad93d0cdf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\left\\| T_j f \\right\\|_{L^2({\\bf R}^2)} \\leq C 2^{-j/2} \\left\\|f\\right\\|_{L^2({\\bf R}^2)}", block: true)]]

#text("which interpolates (by, say, the Riesz-Thorin theorem, or the real-variable ")#link("http://en.wikipedia.org/wiki/Marcinkiewicz_interpolation_theorem")[#text("Marcinkiewicz interpolation theorem")]#text(") to")

#align(center)[#tao-fit-display[#tao-math("\\left\\| T_j f \\right\\|_{L^3({\\bf R}^2)} \\leq C \\left\\|f\\right\\|_{L^{3/2}({\\bf R}^2)}", block: true)]]

#text("which is close to ")#link(<tao-4e07408562bedb8b60ce>)[#text("(4)")]#text(". Unfortunately, we still have to sum in ")#mi("{j}")#text(", and this creates a “logarithmic divergence” that just barely fails to recover ")#link(<tao-4e07408562bedb8b60ce>)[#text("(4)")]#text(". (With a slightly more refined real interpolation argument, one can at least obtain a restricted weak-type estimate from ")#mi("{L^{3/2,1}({\\bf R}^2)}")#text(" to ")#mi("{L^{3,\\infty}({\\bf R}^2)}")#text(" this way, but one can concoct abstract counterexamples to show that the estimates ")#link(<tao-10317f55580c96626da9>)[#text("(10)")]#text(", ")#link(<tao-5093a78d628ad93d0cdf>)[#text("(11)")]#text(" are insufficient to obtain an ")#mi("{L^{3/2} \\rightarrow L^3}")#text(" bound on ")#mi("{\\sum_{j=1}^\\infty T_j}")#text(".)")

#text("The key difference is that the inputs ")#link(<tao-b3763d07241d7157fbfe>)[#text("(8)")]#text(", ")#link(<tao-24879481582d22931cd5>)[#text("(9)")]#text(" used in the Stein interpolation theorem are more powerful than the inputs ")#link(<tao-10317f55580c96626da9>)[#text("(10)")]#text(", ")#link(<tao-5093a78d628ad93d0cdf>)[#text("(11)")]#text(" in the real-variable method. Indeed, ")#link(<tao-b3763d07241d7157fbfe>)[#text("(8)")]#text(" is roughly equivalent to the assertion that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^\\infty e^{2\\pi i j t} 2^{-j} T_j f \\right\\|_{L^\\infty({\\bf R}^2)} \\leq C_t \\left\\|f\\right\\|_{L^1({\\bf R}^2)}", block: true)]]

#text("and ")#link(<tao-24879481582d22931cd5>)[#text("(9)")]#text(" is similarly equivalent to the assertion that")

#align(center)[#tao-fit-display[#tao-math("\\left\\| \\sum_{j=1}^\\infty e^{2\\pi i j t} 2^{j/2} T_j f \\right\\|_{L^2({\\bf R}^2)} \\leq C_t \\left\\|f\\right\\|_{L^2({\\bf R}^2)}.", block: true)]]

#text("A Fourier averaging argument shows that these estimates imply ")#link(<tao-10317f55580c96626da9>)[#text("(10)")]#text(" and ")#link(<tao-5093a78d628ad93d0cdf>)[#text("(11)")]#text(", but not conversely. If one unpacks the proof of Lindelöf’s theorem (which is ultimately powered by an integral representation, such as that provided by the ")#link("http://en.wikipedia.org/wiki/Cauchy's_integral_formula")[#text("Cauchy integral formula")]#text(") and hence of the Stein interpolation theorem, one can interpret Stein interpolation in this case as using a clever integral representation of ")#mi("{\\sum_{j=1}^\\infty T_j f}")#text(" in terms of expressions such as ")#mi("{\\sum_{j=1}^\\infty e^{2\\pi i j t} 2^{-j} T_j f_{1+it}}")#text(" and ")#mi("{\\sum_{j=1}^\\infty e^{2\\pi i j t} 2^{j/2} T_j f_{0+it}}")#text(", where ")#mi("{f_{1+it}, f_{0+it}}")#text(" are various nonlinear transforms of ")#mi("{f}")#text(". Technically, it would then be possible to rewrite the Stein interpolation argument as a real-variable one, without explicit mention of Lindelöf’s theorem; but the proof would then look extremely contrived; the complex-analytic framework is much more natural (much as it is in analytic number theory, where the distribution of the primes is best handled by a complex-analytic study of the Riemann zeta function).")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" A useful strengthening of the Stein interpolation theorem is the ")#link("http://www.ams.org/mathscinet-getitem?mr=447953")[#text("Fefferman-Stein interpolation theorem")]#text(", in which the endpoint spaces ")#mi("{L^1}")#text(" and ")#mi("{L^\\infty}")#text(" are replaced by the ")#link("http://en.wikipedia.org/wiki/Hardy_space")[#text("Hardy space")]#text(" ")#mi("{{\\mathcal H}^1}")#text(" and the space ")#mi("{BMO}")#text(" of functions of ")#link("http://en.wikipedia.org/wiki/Bounded_mean_oscillation")[#text("bounded mean oscillation")]#text(" respectively. These spaces are more stable with respect to various harmonic analysis operators, such as singular integrals (and in particular, with respect to the Marcinkiewicz operators ")#tao-math("{\\left|\\nabla\\right|^{it}}", block: false)#text(", which come up frequently when attempting to use the complex method), which makes the Fefferman-Stein theorem particularly useful for controlling expressions derived from these sorts of operators.")
]

#heading(level: 1)[#text("Comments (10)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dbec86d4d19ceb013bcd20cdad1eec064c1a65c0a5082e43eb7f3db2ee0be421-c2b01aae15c2bcd758066982c1846bb8897514ec159767eb300b6b9188133545.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of pavel zorin")]], [#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-52206")[#strong[#text("pavel zorin")]]#text(size: 9pt, fill: rgb("596477"), " · 3 May 2011")])]

#text("One should mention that an easier proof of the Fefferman-Stein interpolation theorem is available:")

#link("http://www.ams.org/mathscinet-getitem?mr=671315")[#text("http://www.ams.org/mathscinet-getitem?mr=671315")]

#text("Instead of using the sharp maximal function and duality it proceeds by a decomposition argument similar to Thorin’s. Note that most of the technicalities in that article vanish if one is only interested in the case [H¹,L^p], p<\\infty.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-52446")[#strong[#text("Fifth Linkfest")]]#text(size: 9pt, fill: rgb("596477"), " · 9 May 2011")]

#text("[…] Tao: Stein’s interpolation theorem, Effective limiting absorption principles, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/002447eeaa89e2c139265914bbccf5594aff45624d4a45863017173ea5e8e0ed-6dfccb802b3cd8af04ba4a219a758a8ae4a5b2d040609fb1ce3a84820e98db2b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Lucas")]], [#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-52488")[#strong[#text("Lucas")]]#text(size: 9pt, fill: rgb("596477"), " · 10 May 2011")])]

#text("Dear Prof. Tao,")

#text("There are multilinear versions of the Stein’s Interpolation?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-52636")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2011")])]

#text("Yes, the proof method extends without much difficulty to the multilinear case. A quick web search reveals one such version here: ")#link("http://www.math.kit.edu/iana3/~alexander.ullmann/media/ullmann_alexander_diss_2010-12-22-online.pdf")[#text("http://www.math.kit.edu/iana3/~alexander.ullmann/media/ullmann_alexander_diss_2010-12-22-online.pdf")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-53028")[#strong[#text("Análisis y aplicaciones: conferencia en honor de Elias M. Stein | Series divergentes")]]#text(size: 9pt, fill: rgb("596477"), " · 23 May 2011")]

#text("[…] artículos sobre algunos de los resultados de Stein más importantes, entre los que se encuentran el teorema de interpolación, el principio maximal y el teorema maximal […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/937f16cefd2410593a90869bc6749a7a887d136ffa1339a52369db60e3be5594-2e13720b48db65221ea1e0fa47249b2109c6817e12227b40124c6eb7dc5388ef.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Alberto de la torre")]], [#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-228830")[#strong[#text("Alberto de la torre")]]#text(size: 9pt, fill: rgb("596477"), " · 11 May 2013")])]

#text("I have a question about the SteIn-Weiss interpolation with change of measures assumming weak type in the end points. Is there eny estimases about the norm of the operators in the intermitiste espaces")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/acd14d044fcf72b6a2d1f7e55d66cd3fab51c3093127e469061feddf36be5226-1f52d8c04a95ad76b4d56cd9d04797fd637d4935534b8d83c301b918a5e046ee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Marc Lengfield")]], [#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-474827")[#strong[#text("Marc Lengfield")]]#text(size: 9pt, fill: rgb("596477"), " · 3 December 2016")])]

#text("Is there a vector-valued version of the Stein-weiss change of measure theorem/")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-481164")[#strong[#text("Riesz-Thorin theorem | 江苏荣华投资公司")]]#text(size: 9pt, fill: rgb("596477"), " · 24 May 2017")]

#text("[…] Jr., is used to establish the desired bounds. See Stein and Weiss (1971) for a detailed proof, and a blog post of Tao for a high-level exposition of the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3b0ac47c44c1c2137d6691ab88b853598a1deee9c92d97fc6e83ace113c308ec-148f4a7f1d8de44ef77820e7d803793feecf75b4c23ba977a147179d3dc13385.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jacques")]], [#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-601200")[#strong[#text("Jacques")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2020")])]

#text("You say that estimates (10) and (11) do not imply the required estimates, as one needs to sum localized estimates and lose a logarithm somewhere and that this is possible to concoct a counterexample. Can you provide such a counter example, or indicate how to construct one? (I suspect a probabilistic method with Khinchine arguments may work, but I did not succeed!)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/05/03/steins-interpolation-theorem/#comment-601787")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 4 November 2020")])]

#text("Work on the real line and take for instance the rank one operators ")#mi("T_j f := 2^j \\langle f, 1_{[0,1]} \\rangle 1_{[0, 2^{-3j}]}")#text(".")
]
]
