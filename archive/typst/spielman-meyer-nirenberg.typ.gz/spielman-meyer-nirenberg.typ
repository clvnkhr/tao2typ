// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/
// Converted to Typst by tao2typ: "2026-10-14T16:36:15.683521+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Spielman, Meyer, Nirenberg", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Spielman, Meyer, Nirenberg")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 August 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/")[#text("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("In my previous post, I briefly discussed the work of the four Fields medalists of 2010 (Lindenstrauss, Ngo, Smirnov, and Villani). In this post I will discuss the work of ")#link("http://en.wikipedia.org/wiki/Daniel_Spielman")[#text("Dan Spielman")]#text(" (winner of the ")#link("http://en.wikipedia.org/wiki/Nevanlinna_Prize")[#text("Nevanlinna prize")]#text("), ")#link("http://en.wikipedia.org/wiki/Yves_Meyer")[#text("Yves Meyer")]#text(" (winner of the ")#link("http://en.wikipedia.org/wiki/Carl_Friedrich_Gauss_Prize")[#text("Gauss prize")]#text("), and ")#link("http://en.wikipedia.org/wiki/Louis_Nirenberg")[#text("Louis Nirenberg")]#text(" (winner of the ")#link("http://en.wikipedia.org/wiki/Chern_Medal_Award")[#text("Chern medal")]#text("). Again by chance, the work of all three of the recipients overlaps to some extent with my own areas of expertise, so I will be able to discuss a sample contribution for each of them. Again, my choice of contribution is somewhat idiosyncratic and is not intended to represent the “best” work of each of the awardees.")

#metadata(none) <tao-9fd9f50f8831322d4a93>

#heading(level: 1)[#strong[#text(" — 1. Dan Spielman — ")]]

#text("Dan Spielman works in numerical analysis (and in particular, numerical linear algebra) and theoretical computer science. Here I want to talk about one of his key contributions, namely his pioneering work with Teng on ")#link("http://en.wikipedia.org/wiki/Smoothed_analysis")[#text("smoothed analysis")]#text(". This is about an idea as much as it is about a collection of rigorous results, though Spielman and Teng certainly did buttress their ideas with serious new theorems.")

#text("Prior to this work, there were two basic ways that one analysed the performance (which could mean run-time, accuracy, or some other desirable quality) of a given algorithm. Firstly, one could perform a ")#emph[#text("worst-case")]#text(" analysis, in which one assumed that the input was chosen in such an “adversarial” fashion that the performance was as poor as possible. Such an analysis would be suitable for applications such as certain aspects of cryptography, in which the input really was chosen by an adversary, or in high-stakes situations in which there was zero tolerance for any error whatsoever; it is also useful as a “default” analysis for when no realistic input model is available.")

#text("At the other extreme, one could perform an ")#emph[#text("average-case")]#text(" analysis, in which the input was chosen in a completely random fashion (e.g. a random string of zeroes and ones, or a random vector whose entries were all distributed according to a Gaussian distribution). While such input models were usually not too realistic (except in situations where the signal-to-noise ratio was very low), they were usually fairly simple to analyse (using tools such as concentration of measure).")

#text("In many situations, the worst-case analysis is too conservative, and the average-case analysis is too optimistic or unrealistic. For instance, when using the popular ")#link("http://en.wikipedia.org/wiki/Simplex_algorithm")[#text("simplex method")]#text(" to solve linear programming problems, the worst-case run-time can be exponentially large in the size of the problem, whereas the average-case run-time (in which one is fed a randomly chosen linear program as input) is polynomial. However, the typical linear program that one encounters in practice has enough structure to it that it does not resemble a randomly chosen program at all, and so it is not clear that the average-case bound is appropriate for the type of inputs one has in practice. At the other extreme, the exponentially bad worst-case inputs were so rare that they never seemed to come up in practice either.")

#text("To obtain a better input model, Spielman and Teng considered a ")#emph[#text("smoothed-case")]#text(" model, in which the input was the sum of a deterministic (and possibly worst-case) input, and a small noise perturbation, which they took to be Gaussian to simplify their analysis. This reflected the presence of measurement error, roundoff error, and similar sources of noise in real-life applications of numerical algorithms. Remarkably, they were able to analyse the run-time of the simplex method for this model, concluding (after a lengthy technical argument) that under reasonable choices of parameters, the run time was polynomial time in the length, thus explaining the empirically observed phenomenon that the simplex method tended to run a lot better in practice than its worst-case analysis would predict, even if one started with extremely ill-conditioned inputs, provided that there was a bit of noise in the system.")

#text("One of the ingredients in their analysis was a quantitative bound on the ")#link("http://en.wikipedia.org/wiki/Condition_number")[#text("condition number")]#text(" of an arbitrary matrix when it is perturbed by a random gaussian perturbation; the point being that random perturbation can often make an ill-conditioned matrix better behaved. (This is perhaps analogous in some ways to the empirical experience that some pieces of machinery work better after being kicked.) Recently, new tools from additive combinatorics (in particular, inverse Littlewood-Offord theory) have enabled Rudelson-Vershynin, Vu and myself, and others to generalise this bound to other noise models, such as random Bernoulli perturbations, which are a simple model for modeling digital roundoff error.")

#heading(level: 1)[#strong[#text(" — 2. Yves Meyer — ")]]

#text("Yves Meyer has worked in many fields over the years, from number theory to harmonic analysis to PDE to signal processing. As the Gauss prize is concerned with impact on fields outside of mathematics, Meyer’s major contributions to the theoretical foundations of ")#link("http://en.wikipedia.org/wiki/Wavelet")[#text("wavelets")]#text(", which are now a basic tool in signal processing, were undoubtedly a major consideration in awarding this prize. But I would like to focus here on another of Yves’ contributions, namely the ")#emph[#text("Coifman-Meyer theory of paraproducts")]#text(" developed with Raphy Coifman, which is a cornerstone of the ")#emph[#text("para-differential calculus")]#text(" that has turned out to be an indispensable tool in the modern theory of nonlinear PDE.")

#text("Nonlinear differential equations, by definition, tend to involve a combination of differential operators and nonlinear operators. The simplest example of the latter is a pointwise product ")#mi("{uv}")#text(" of two fields ")#mi("{u}")#text(" and ")#mi("{v}")#text(". One is thus often led to study expressions such as ")#mi("{D(uv)}")#text(" or ")#mi("{D^{-1}(uv)}")#text(" for various differential operators ")#mi("{D}")#text(".")

#text("For first order operators ")#mi("{D}")#text(", we can handle derivatives using the ")#link("http://en.wikipedia.org/wiki/Product_rule")[#text("product rule")]#text(" (or ")#emph[#text("Leibniz rule")]#text(") from freshman calculus:")

#align(center)[#tao-fit-display[#mitex("D(uv) = (Du)v + u(Dv).")]]

#text("We can then iterate this to handle higher order derivatives. For instance, we have")

#align(center)[#tao-fit-display[#mitex("D^2(uv) = (D^2 u) v + 2 (Du) (Dv) + u (D^2 v),")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("D^3(uv) = (D^3 u) v + 3 (D^2u) (Dv) + 3 (Du) (D^2 v) + u (D^3 v),")]]

#text("and so forth, assuming of course that all functions involved are sufficiently regular so that all expressions make sense. For inverse derivative expressions such as ")#mi("{D^{-1}(uv)}")#text(", no such simple formula exists, although one does have the very important ")#link("http://en.wikipedia.org/wiki/Integration_by_parts")[#text("integration by parts")]#text(" formula as a substitute. And for fractional derivatives such as ")#tao-math("{\\left|D\\right|^\\alpha(uv)}", block: false)#text(" with ")#mi("{\\alpha > 0}")#text(" a non-integer, there is also no closed formula of the above form.")

#text("Note how the derivatives on the product ")#mi("{uv}")#text(" get ")#emph[#text("distributed")]#text(" to the individual factors ")#mi("{u,v}")#text(", with ")#mi("{u}")#text(" absorbing all the derivatives in one term, ")#mi("{v}")#text(" absorbing all the derivatives in another, and the derivatives being shared between ")#mi("{u}")#text(" and ")#mi("{v}")#text(" in other terms. Within the usual confines of differential calculus; we cannot pick and choose which of the terms we like to keep, and which ones to discard; we must treat every single one of the terms that arise from the Leibniz expansion. This can cause difficulty when trying to control the product of two functions of unequal regularity – a situation that occurs very frequently in nonlinear PDE. For instance, if ")#mi("{u}")#text(" is ")#mi("{C^1}")#text(" (once continuously differentiable), and ")#mi("{v}")#text(" is ")#mi("{C^3}")#text(" (three times continuously differentiable), then the product ")#mi("{uv}")#text(" is merely ")#mi("{C^1}")#text(" rather than ")#mi("{C^3}")#text("; intuitively, we cannot “prevent” the three derivatives in the expression ")#mi("{D^3(uv)}")#text(" from making their way to the ")#mi("{u}")#text(" factor, which is not prepared to absorb all of them. However, it turns out that if we split the product ")#mi("{uv}")#text(" into ")#emph[#text("paraproducts")]#text(" such as the ")#emph[#text("high-low paraproduct")]#text(" ")#mi("{\\pi_{hl}(u,v)}")#text(" and the ")#emph[#text("low-high paraproduct")]#text(", we can effectively separate these terms from each other, allowing for a much more flexible analysis of the situation.")

#text("The concept of a paraproduct can be motivated by using the Fourier transform. For simplicity let us work in one dimension, with ")#mi("{D}")#text(" being the usual differential operator ")#mi("{D = \\frac{d}{dx}}")#text(". Using a Fourier expansion (and assuming as much regularity and integrability as is needed to justify the formal manipulations) of ")#mi("{u}")#text(" into components of different frequencies, we have")

#align(center)[#tao-fit-display[#mitex("u(x) = \\int_{\\bf R} \\hat u(\\xi) e^{i x \\xi}\\ d\\xi")]]

#text("(here we use the usual PDE normalisation in which we try to hide the ")#mi("{2\\pi}")#text(" factor) and similarly")

#align(center)[#tao-fit-display[#mitex("v(x) = \\int_{\\bf R} \\hat v(\\eta) e^{i x \\eta}\\ d\\eta")]]

#text("and thus ")#metadata(none) <tao-40685fd53d8eb3b1e921>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("uv(x) = \\int_{\\bf R} \\int_{\\bf R} \\hat u(\\xi) \\hat v(\\eta) e^{ix(\\xi+\\eta)}\\ d\\xi d\\eta")]]

#text("and thus, by differentiating under the integral sign")

#align(center)[#tao-fit-display[#mitex("D^k(uv)(x) = i^k \\int_{\\bf R} \\int_{\\bf R} (\\xi+\\eta)^k \\hat u(\\xi) \\hat v(\\eta) e^{ix(\\xi+\\eta)}\\ d\\xi d\\eta.")]]

#text("In contrast, we have")

#align(center)[#tao-fit-display[#mitex("(D^j u) (D^{k-j} v)(x) = i^k \\int_{\\bf R} \\int_{\\bf R} \\xi^j \\eta^{k-j} \\hat u(\\xi) \\hat v(\\eta) e^{ix(\\xi+\\eta)}\\ d\\xi d\\eta;")]]

#text("thus, the iterated Leibnitz rule just becomes the binomial formula")

#align(center)[#tao-fit-display[#mitex("(\\xi+\\eta)^2 = \\xi^2 + 2\\xi\\eta + \\eta^2, \\quad (\\xi+\\eta)^3 = \\xi^3 + 3 \\xi^2 \\eta + 3 \\xi \\eta^2 + \\eta^3, \\ldots")]]

#text("after taking Fourier transforms.")

#text("Now, it is certainly true that when dealing with an expression such as ")#mi("{(\\xi+\\eta)^2}")#text(", all three terms ")#mi("{\\xi^2, 2\\xi\\eta, \\eta^2}")#text(" need to be present. But observe that when dealing with a “high-low” frequency interaction, in which ")#mi("{\\xi}")#text(" is much larger in magnitude than ")#mi("{\\eta}")#text(", then the first term dominates: ")#mi("{(\\xi+\\eta)^2 \\sim \\xi^2}")#text(". Conversely, with a “low-high” frequency interaction, in which ")#mi("{\\eta}")#text(" is much larger in magnitude than ")#mi("{\\xi}")#text(", we have ")#mi("{(\\xi+\\eta)^2 \\sim \\eta^2}")#text(". (There are also “high-high” interactions, in which ")#mi("{\\xi}")#text(" and ")#mi("{\\eta}")#text(" are comparable in magnitude, and ")#mi("{(\\xi+\\eta)^2}")#text(" can be significantly smaller than either ")#mi("{\\xi^2}")#text(" or ")#mi("{\\eta^2}")#text(", but for simplicity of discussion let us ignore this case.) It then becomes natural to try to decompose the product ")#mi("{uv}")#text(" into “high-low” and “low-high” pieces (plus a “high-high” error), for instance by inserting suitable cutoff functions ")#mi("{m_{hl}(\\xi,\\eta)}")#text(" or ")#mi("{m_{lh}(\\xi,\\eta)}")#text(" in ")#link(<tao-40685fd53d8eb3b1e921>)[#text("(1)")]#text(" to the regions ")#tao-math("{\\left|\\xi\\right| \\gg \\left|\\eta\\right|}", block: false)#text(" or ")#tao-math("{\\left|\\xi\\right| \\ll \\left|\\eta\\right|}", block: false)#text(" to create the ")#emph[#text("paraproducts")]

#align(center)[#tao-fit-display[#mitex("\\pi_{hl}(u,v)(x) = \\int_{\\bf R} \\int_{\\bf R} m_{hl}(\\xi,\\eta) \\hat u(\\xi) \\hat v(\\eta) e^{ix(\\xi+\\eta)}\\ d\\xi d\\eta")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\pi_{lh}(u,v)(x) = \\int_{\\bf R} \\int_{\\bf R} m_{lh}(\\xi,\\eta) \\hat u(\\xi) \\hat v(\\eta) e^{ix(\\xi+\\eta)}\\ d\\xi d\\eta")]]

#text("Such paraproducts were first introduced by Calderón, and more explicitly by Bony. Heuristically, ")#mi("{\\pi_{hl}(u,v)}")#text(" is the “high-low” portion of the product ")#mi("{uv}")#text(", in which the high frequency components of ")#mi("{u}")#text(" are “allowed” to interact with the low frequency components of ")#mi("{v}")#text(", but no other frequency interactions are permitted, and similarly for ")#mi("{\\pi_{lh}(u,v)}")#text(". The ")#emph[#text("para-differential calculus")]#text(" of Bony, Coifman, and Meyer then allows one to manipulate these paraproducts in ways that are very similar to ordinary pointwise products, except that they behave better with respect to the Leibniz rule or with more exotic differential or integral operators. For instance, one has")

#align(center)[#tao-fit-display[#mitex("D^k \\pi_{hl}(u,v) \\approx \\pi_{hl}(D^k u, v)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("D^k \\pi_{lh}(u,v) \\approx \\pi_{lh}(u, D^k v)")]]

#text("for differential operators ")#mi("{D^k}")#text(" (and more generally for pseudodifferential operators such as ")#tao-math("{\\left|D\\right|^\\alpha}", block: false)#text(", or integral operators such as ")#mi("{D^{-1}}")#text("), where we use the ")#mi("{\\approx}")#text(" symbol loosely to denote “up to lower order terms”. Furthermore, many of the basic estimates of the pointwise product, in particular Hölder’s inequality, have analogues for paraproducts; this is a special case of what is now known as the ")#link("http://www.ams.org/mathscinet-getitem?mr=518170")[#text("Coifman-Meyer theorem")]#text(", which is fundamental in this subject, and is proven using Littlewood-Paley theory. The same theory in fact gives some estimates for paraproducts beyond what are available for products. For instance, if ")#mi("{u}")#text(" is in ")#mi("{C^1}")#text(" and ")#mi("{v}")#text(" is in ")#mi("{C^3}")#text(", then the paraproduct ")#mi("{\\pi_{lh}(u,v)}")#text(" is “almost” in ")#mi("{C^3}")#text(" (modulo some technical logarithmic divergences which I will not elaborate on here), in contrast to the full product ")#mi("{uv}")#text(" which is merely in ")#mi("{C^1}")#text(".")

#text("Paraproducts also allow one to extend the classical product and chain rules to fractional derivative operators, leading to the ")#emph[#text("fractional Leibniz rule")]

#align(center)[#tao-fit-display[#tao-math("\\left|D\\right|^\\alpha(uv) \\approx (\\left|D\\right|^\\alpha u) v + u (\\left|D\\right|^\\alpha v)", block: true)]]

#text("and ")#emph[#text("fractional chain rule")]

#align(center)[#tao-fit-display[#tao-math("\\left|D\\right|^\\alpha(F(u)) \\approx (\\left|D\\right|^\\alpha u) F^{\\prime}(u)", block: true)]]

#text("which are both very useful in nonlinear PDE (see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=1766415")[#text("this book of Taylor")]#text(" for a thorough treatment). See also this ")#link("http://www.ams.org/notices/201007/rtx100700858p.pdf")[#text("brief Notices article on paraproducts")]#text(" by Benyi, Maldonado, and Naibo.")

#heading(level: 1)[#strong[#text(" — 3. Louis Nirenberg — ")]]

#text("Louis Nirenberg has made an amazing number of contributions to analysis, PDE, and geometry (e.g. John-Nirenberg inequality, Nirenberg-Treves conjecture (recently solved by Dencker), Newlander-Nirenberg theorem, Gagliardo-Nirenberg inequality, Caffarelli-Kohn-Nirenberg theorem, etc.), while also being one of the nicest people I know. I will mention only two results of his here, one of them very briefly.")

#text("Among other things, ")#link("http://www.ams.org/mathscinet-getitem?mr=176362")[#text("Nirenberg and Kohn introduced")]#text(" the ")#emph[#text("pseudo-differential calculus")]#text(" which, like the para-differential calculus mentioned in the previous section, is an extension of differential calculus, but this time focused more on generalisation to variable coefficient or fractional operators, rather than in generalising the Leibniz or chain rules. This calculus sits at the intersection of harmonic analysis, PDE, von Neumann algebras, microlocal analysis, and semiclassical physics, and also happens to be closely related to Meyer’s work on wavelets; it quantifies the positive aspects of the ")#link("http://en.wikipedia.org/wiki/Uncertainty_principle")[#text("Heisenberg uncertainty principle")]#text(", in that one ")#emph[#text("can")]#text(" observe position and momentum simultaneously so long as the uncertainty relation is respected. But I will not discuss this topic further today.")

#text("Instead, I would like to focus here instead on a gem of an argument of ")#link("http://www.ams.org/mathscinet-getitem?mr=544879")[#text("Gidas, Ni, and Nirenberg")]#text(", which is a brilliant application of Alexandrov’s ")#emph[#text("method of moving planes")]#text(", combined with the ubiquitous ")#link("http://en.wikipedia.org/wiki/Maximum_principle")[#text("maximum principle")]#text(". This concerns solutions to the ")#emph[#text("ground state equation")]#text(" ")#metadata(none) <tao-c1a421182e1fb908168f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Delta Q + Q^p = Q")]]

#text("where ")#mi("{Q: {\\bf R}^n \\rightarrow {\\bf R}^+}")#text(" is a smooth positive function that decays exponentially at infinity, ")#mi("{p > 1}")#text(" is an exponent, and ")#mi("{\\Delta := \\sum_{j=1}^n \\frac{\\partial^2}{\\partial x_j^2}}")#text(" is the Laplacian. This equation shows up in a number of contexts, including the nonlinear Schrödinger equation and also, by coincidence, in connection with the best constants in the Gagliardo-Nirenberg inequality. The existence of ground states ")#mi("{Q}")#text(" can be proven by the variational principle. But one can say much more:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 1 (Gidas-Ni-Nirenberg)")]#text(" All ground states ")#mi("{Q}")#text(" are radially symmetric with respect to some origin.")
]

#text("To show this radial symmetry, a small amount of Euclidean geometry shows that it is enough to show that there is a lot of reflection symmetry:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 2 (Gidas-Ni-Nirenberg, again)")]#text(" If ")#mi("{Q}")#text(" is a ground state and ")#mi("{\\omega \\in S^{n-1}}")#text(" is a unit vector, then there exists a hyperplane orthogonal to ")#mi("{\\omega}")#text(" with respect to which ")#mi("{Q}")#text(" is symmetric.")
]

#text("To prove this lemma, we use the moving planes method, sliding in a plane orthogonal to ")#mi("{\\omega}")#text(" from infinity. More precisely, for each ")#mi("{t \\in {\\bf R}}")#text(", let ")#mi("{\\Pi_t}")#text(" be the hyperplane ")#mi("{\\{ x: x \\cdot \\omega = t \\}}")#text(", let ")#mi("{H_t}")#text(" be the associated half-space ")#mi("{\\{ x: x \\cdot \\omega \\leq t\\}}")#text(", and let ")#mi("{Q_t: H_t \\rightarrow {\\bf R}}")#text(" be the function ")#mi("{Q_t(x) := Q(x) - Q(r_t(x))}")#text(", where")

#align(center)[#tao-fit-display[#mitex("r_t(x) := x + 2 (t - x \\cdot \\omega) \\omega")]]

#text("is the reflection through ")#mi("{\\Pi_t}")#text("; thus ")#mi("{Q_t}")#text(" is the difference between ")#mi("{Q}")#text(" and its reflection in ")#mi("{\\Pi_t}")#text(". In particular, ")#mi("{Q_t}")#text(" vanishes on the boundary ")#mi("{\\Pi_t}")#text(" of the half-space ")#mi("{H_t}")#text(".")

#text("Intuitively, the argument proceeds as follows. It is plausible that ")#mi("{Q_t}")#text(" is going to be positive in the interior of ")#mi("{H_t}")#text(" for large positive ")#mi("{t}")#text(", but negative in the interior of ")#mi("{H_t}")#text(" for large negative ")#mi("{t}")#text(". Now imagine sliding ")#mi("{t}")#text(" down from ")#mi("{+\\infty}")#text(" to ")#mi("{-\\infty}")#text(" until one reaches the first point ")#mi("{t = t_0}")#text(" where ")#mi("{Q_{t_0}}")#text(" ceases to be positive in the interior of ")#mi("{H_{t_0}}")#text(", then it attains its minimum at some zero in the interior of ")#mi("{H_{t_0}}")#text(". But by playing around with ")#link(<tao-c1a421182e1fb908168f>)[#text("(2)")]#text(" (using the Lipschitz nature of the map ")#mi("{Q \\mapsto Q^p}")#text(" when ")#mi("{Q}")#text(" is bounded) we know that ")#mi("{Q_{t_0}}")#text(" obeys an elliptic constraint of the form ")#tao-math("{\\Delta Q_{t_0} = O( \\left|Q_{t_0}\\right| )}", block: false)#text(". Applying the maximum principle, we can then conclude that ")#mi("{Q_{t_0}}")#text(" vanishes identically in ")#mi("{H_{t_0}}")#text(", which gives the desired reflectoin symmetry.")

#text("(Now it turns out that there are some technical issues in making the above sketch precise, mainly because of the non-compact nature of the half-space ")#mi("{H_t}")#text(", but these can be fixed with a little bit of fiddling; see for instance Appendix B of my ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("PDE textbook")]#text(".)")

#heading(level: 1)[#text("Comments (30)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/897c6732ccef8a11864e2746c5628d88e880427f6c7c1eb2ada8665d422afa39-ed3c90821187d034241a8f02b3f61ddea2d5b8cfe4069bae1ccf686ca896c114.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of UNSW")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46594")[#strong[#text("UNSW")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("Thanks a lot for the summarization.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/397530fd2887f612fba57abd32459442958e156e9a8d23305eb271a9f74ca393-fab68614ef7c5f8b6cbacb2fd16cb80a62d3801234d373e83bcfdb326cc5e905.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of oz")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46597")[#strong[#text("oz")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("A very nice post. There is one minor mistake I believe:")#linebreak()#text(" “Again, by chance, the work of all three of the recipients overlaps to some extent with my own areas of expertise ..”")#linebreak()#text(" I don’t see how can it be that by mere chance the work of 6 out of the 7 prize winners is related to prof. Tao’s areas of expertise.")#linebreak()#text(" Any reasonable statistical analysis will reject this null hypothesis and suggest that it is not chance but the enormous breadth of prof. Tao’s")#linebreak()#text(" mathematical knowledge and interests which is in act here")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/b0af042bf9b8c6afe3fb307f953857727093f6db41dd13a04c13db4366cc0572-8eb4d1511733286836c9547eec439829a3d38ec528b2a29183ae61577026f105.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anon")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46598")[#strong[#text("Anon")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("Thanks! I enjoyed reading this post. My favorite line is “This is perhaps analogous in some ways to the empirical experience that some pieces of machinery work better after being kicked.” I laughed out loud reading it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Zaher")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46599")[#strong[#text("Zaher")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("Thanks for the summaries.")#linebreak()#text(" Small typo: in the definition of $\\pi_{lh}$ the arguments (or subscripts) of $m_{hl}(.,.)$ should be permuted.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e9c3df0f0a0af35f57f79365582e39ff043f305952bdef96cec1fe0d9bc64de6-4d274defd655a60817e7a7e643636eefc6e72df5e3b3362898d6cb6d938bbf7a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Roger")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46601")[#strong[#text("Roger")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("Perhaps Tao’s expertise is not so broad, but the selection committee reads this blog, and they think that a subject is not important unless it is written about here! Maybe next we will see a prize for the empirical experiences of kicking machinery.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46609")[#strong[#text("ICM2010 — Ngo laudatio « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")]

#text("[…] for a general audience and Terence Tao has now posted about the work of the Fields medallists and the other prizewinners. And as I have already said, the ICM website has links to the full texts of the laudationes […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46610")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2010")])]

#text("I thought the complexity of the simplex method was figured out by Smale, Lemke, etc in the 1970s(?) in about the way you describe, establishing that it’s polynomial except on a measure-zero set that can be characterized precisely. I’m probably confused.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46619")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("I believe Smale addressed the average case complexity of the simplex method, but not the smoothed complexity, i.e. that the expected value of the run time was polynomial, if the inputs were chosen randomly. By applying Markov’s inequality, this does show that inputs with very large run time are rare, but unfortunately such bounds are not strong enough to directly say anything about the smoothed model, because the set of data which is very close to a specific input has tiny measure (exponentially small) with respect to a standard reference measure (e.g. gaussian).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/743ec659e95a03c26d192883fa7bbe7647704868ea113c827a627daa82ded8e0-dbc98e08ce176ef4ec67b629e09f1f3d2786817a4f2ebdb07194ca7cd341d047.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46713")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 30 August 2010")])]

#text("The “pathological” examples for which the simplex algorithm requires exponentially many steps represent a set of problems of positive measure. So we cannot expect a result of the kind described by Anonymous. One remaining mystery both in the average-case analysis and smoothed analysis of the simplex algorithm is to give tail-estimates for the running time which are better than what can simply be deduced by Markov’s inequality. As a first step, is there a way to understand the variance of the number of steps? Next, can we expect an exponentially small tail?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46616")[#strong[#text("Watch the Math! | Sun Ju's Blog")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")]

#text("[…] Terence Tao also gave his personal exposition (here and here) on the remarkable work of Prize winners in […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46624")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("Prof: I do not know why the random perturbation to make ill-conditioned matrix well-conditioned is an important work in Dan Spielman’s work. I would bet against some Engineering companies which already do not use that idea. It seems control theoretic in spirit.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c1ff67fe6d12fbf22cfce865d73f8624072beec7614558b3eb69ba57c7eb96d0-48271cd75ace021963a7ed38c137bc3d13fd9534b4495e526465ee3fe971695c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of AJ")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46625")[#strong[#text("AJ")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2010")])]

#text("I mean I doubt if some engineering companies already do not use the idea.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46650")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2010")])]

#text("A comment from one of my friends in response to your observation: This is perhaps analogous in some ways to the empirical experience that some pieces of machinery work better after being kicked.")

#text("“Perhaps this applies to ill-behaved children being ‘perturbed’ every once in a while by a dose of yelling too? Just wondering about the homely implications of abstract Math. :D “")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e3b3858905d1e619dba720b6d59871ea63848623ab01af61ad69a32d88ec9e6e-15ef47aa9408c16d4b058d1f819479ae2ddeb9e5766bdf1cf3404730ebec7ad4.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46651")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 24 August 2010")])]

#text("I think you are the best Terry. I have a nostalgic feeling seeing you get the prize in 2006. You are the only one who writes an excellent blog and tediously summarize other people’s results. The people who won it this year are nobodys compared to you. T.Tao you are the man.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46690")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 27 August 2010")])]

#text("I believe he has a little robot assistant beside him or he has secretly invented the time machine or he has access to cranial ability performance enhancing drugs. Take a look at the number of publications he has had before 30. And this blog. I wonder where he has time. Amazing!")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46657")[#strong[#text("ICM2010 — Niremberg and Meyer laudationes « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")]

#text("[…] finish this post with a reminder that the work of Nirenberg and Meyer is discussed by Terry Tao on his […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f144099848c2cb88f086b9ab8b79e9c220d9bef25a9764e3d60b93fb79c40696-d2ef7fd0be083d62bf9d68d41c72abbccb42e2b0b1443cda39fdde5e42ef8748.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of poiuyt")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46660")[#strong[#text("poiuyt")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("Typo: “the typical linear program that one encounters in PRACTICE”?")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/74d372202442996888e1ac57f72dce4321c7e3fc170d9c81ac9c2febe5a423f4-6d391662029176d3ba8dff40575b23fb0503065cb849e31d581fcd7856e7785b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Sidles")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46665")[#strong[#text("John Sidles")]]#text(size: 9pt, fill: rgb("596477"), " · 25 August 2010")])]

#text("The insight that “some pieces of machinery work better after being kicked” has been invoked to explain the generic feasibility of efficient (classical) descriptions of large-dimension quantum dynamical trajectories. See (for example) Wojciech Zurek’s ")#link("http://arxiv.org/abs/quant-ph/0105127")[#text("review")]#text(" “Decoherence, einselection, and the quantum origins of the classical” (Rev. Mod. Phys., 2003).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/495e58456a621fae090b33dc64bd9776147e4b72fbae600b00ff04af5bb8f7f8-e2aee4a32f9e9460fae8f28941f45415049dc4c05349582bd11f275fdde75c86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz Barak")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46672")[#strong[#text("Boaz Barak")]]#text(size: 9pt, fill: rgb("596477"), " · 26 August 2010")])]

#text("A minor correction: actually, cryptography is typically focused on the *average case* analysis of algorithms. The reason is that the algorithmic task at the heart of a cryptosystem is that task of *breaking* it. Hence the input is chosen by the designer of the cryptosystem from a fixed well defined distribution (i.e., the one obtained by choosing a random key), and the adversary picks a “worst-case choice of the algorithm” to try to break it. (However, it’s also true that one also needs worst-case analysis of algorithms to make sure that, for example, an decryption algorithm will always finish decoding no matter what input it’s provided, and to make sure that the reductions in the security proof of a cryptosystem are efficient.)")

#text("The reason worst-case analysis of algorithms is so prevalent is not because of crypto but rather because in most cases it’s very hard to find a clean model distribution of the inputs, and so worst-case performing general algorithms, that one can plug in any application without worrying about the input distributions are very useful. (The simplex algorithm is perhaps the canonical example for an algorithm that seems to have the latter usefulness property without having the former, and the Spielman-Teng work gives some reasons why.)")

#text("Another “justification” for worst-case analysis is that it’s also been observed that in many cases, if we have an efficient algorithm for many diverse families of natural inputs, there is also another efficient algorithm that works in the worst-case. This is the case for linear programming. Two interesting exceptions are the graph isomorphism problem and approximating so-called “unique games” (i.e., the problem underlying Khot’s unique games conjecture), where there are efficient algorithms for many natural input distributions, but there no known algorithms (yet?) proven to work on all inputs.")

#emph[#text("[Fair enough, although worst-case analysis is still relevant for some aspects of cryptography, particularly with regards to code design rather than code breaking. I’ve reworded the paragraph accordingly. – T]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/73b7d81349dc8c2affeaf8133bb2c86dc9bcfc62b5fec1a05c99a450903a47f7-cde4a32c00efe0674f735fa621ac8aff44973e7e81ead14708fc789fc1310c11.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gil Kalai")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46720")[#strong[#text("Gil Kalai")]]#text(size: 9pt, fill: rgb("596477"), " · 31 August 2010")])]

#text("It is worth mentioning also that there are various notions of “average case analysis”. The most naive notion is about uniform distribution on the inputs. A more sophisticated notion is about an arbitrary “computable” distribution of the inputs which is (I believe) what “Levin’s average case complexity” is more or less about. Levin’s notion of average case complexity is probably the more intimately connected with cryptography but I am sure Boaz can explain it much better than me.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/495e58456a621fae090b33dc64bd9776147e4b72fbae600b00ff04af5bb8f7f8-e2aee4a32f9e9460fae8f28941f45415049dc4c05349582bd11f275fdde75c86.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Boaz Barak")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46745")[#strong[#text("Boaz Barak")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2010")])]

#text("Hi Gil,")

#text("You are right that in crypto we have the freedom to choose the distribution over inputs that will make the problem hardest, and that distribution doesn’t have to be the uniform distribution. However, in many cases, crypto is concerned with clean distributions such as uniform strings, random matrices, product of two random primes etc.. In fact, crypto may be the only “real world” application where one indeed needs to solve instances generated by such clean distributions (in contrast, instances coming from “nature” will be at best only approximately from a model distribution).")

#text("Levin gave a general definition of what it means to have a “polynomial on the average” algorithm for a given problem F and a distribution D (it turns out there are some subtleties in defining these). He then showed some completeness results, although unfortunately the reductions seem to always either make the problem or the distribution “unnatural”.")

#text("There is a subtle reason why Levin’s notion is not immediately useful to cryptography. This is explained beautifully in ")#link("http://cseweb.ucsd.edu/~russell/average.ps")[#text("this survey of Russell Impagliazzo")]#text(" who calls it the difference between “Pessiland” and “Minicrypt”. Roughly speaking, to be useful for crypto, we need a way to sample “planted hard instances” of the distribution. For some natural distributions such as random clique and random 3SAT this is easy due to the symmetries of the distribution, but it can conceivably be the case that there is a problem F (in NP) and a distribution D such that we can efficiently sample an input from D, but we have no procedure to sample a pair (x,y) of an input from D and a solution (i.e. “witness”) y to this input. It is the latter procedure that is needed to use F as a basis for cryptography.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-46762")[#strong[#text("ICM2010 — final post « Gowers's Weblog")]]#text(size: 9pt, fill: rgb("596477"), " · 2 September 2010")]

#text("[…] Terence Tao on the work of Spielman, Meyer and Nirenberg […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4f32339931e6d5a23927cbf3292c0357279696dfd4f369ca295eca97f045399e-1ff92aed8dd633408b0eeb2a019bbec7e1ffd57e75d323af180fba36a5cf8ccf.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of It’s just another talk, to be honest « It's cold outside")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-49811")[#strong[#text("It’s just another talk, to be honest « It's cold outside")]]#text(size: 9pt, fill: rgb("596477"), " · 24 January 2011")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/")[#text("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-204470")[#strong[#text("Matthew Kennedy awarded CMS 2012 Doctoral Prize « Noncommutative Analysis")]]#text(size: 9pt, fill: rgb("596477"), " · 13 December 2012")]

#text("[…] work. Tim Gowers and Terry Tao have set a fine example in their expositions of the works of Fields Medalists or Abel Prize laureates. These are among the most interesting and important posts out there, I […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-420747")[#strong[#text("Econlinks: Of Maths, Efficiency, and Language | My great WordPress blog")]]#text(size: 9pt, fill: rgb("596477"), " · 26 September 2014")]

#text("[…] Terry Tao brief and informative on the 2010 Fields medalists (Le Monde est aussi très heureux et honoré pour Ngo et Villani, “deux facettes de l’école mathématique française“). Read also Tao’s intro to the winners of the Nevanlinna, Gauss and Chern prizes. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yves Meyer wins the 2017 Abel Prize | What's new")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-479249")[#strong[#text("Yves Meyer wins the 2017 Abel Prize | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2017")])]

#text("[…] within my own area of expertise. (I had previously written about some other work of Meyer in this blog post.) Indeed I had learned about Meyer’s wavelet constructions as a graduate student while […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-479375")[#strong[#text("Notes in Mathematics (March, 2017) – Cheenta Ganit Kendra")]]#text(size: 9pt, fill: rgb("596477"), " · 27 March 2017")]

#text("[…] You may read more about his work in the words of celebrated mathematician Terence Tao here: https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/ Presently I am reading a cult classic by Hilbert: Geometry and Imagination. In introductory […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c5dd54b2b2a36b0efa3be83c8fcf33c14f12dd4dcf8cbb6c1ef062c7af18ed41-be0a31a4129efdeb6183b9059935e199258a543208378954f353dd430c95e248.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jorge Losada")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-479922")[#strong[#text("Jorge Losada")]]#text(size: 9pt, fill: rgb("596477"), " · 18 April 2017")])]

#text("Dear Prof. Tao, thanks for your excellent work and for sharing with us such information. I am particularly interested in the section about Yves Meyer.")

#text("In usual calculus, exponential function plays a central role and this is due to (I believe) it links in a really beautiful way sums and (usual) products.")

#text("I have tried reading the suggested book “Tools for PDE” by M.E. Taylor, but I found it really hard for me. So, what can we say about functions with similar properties than exponential function considering paraproducts instead of usual products?")

#text("Please, if someone has any idea I would really appreciate her (or his) help. Thanks!! I have some conjectures…")

#text("You can find my e-mail on this website")#linebreak()#text(" ")#link("http://www.usc.es/es/centros/matematicas/profesor.html?Num_Puesto=16662&Num_Persona=198874&ano=66")[#text("http://www.usc.es/es/centros/matematicas/profesor.html?Num_Puesto=16662&Num_Persona=198874&ano=66")]

#text("I have tried reading the suggested book “Tools for PDE” but I found it really hard for me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Louis Nirenberg | What's new")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-537582")[#strong[#text("Louis Nirenberg | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 27 January 2020")])]

#text("[…] his beautiful moving planes argument with Gidas and Ni to establish symmetry of ground states in this post on the occasion of him receiving the Chern medal, and on how his extremely useful interpolation […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0407444868fc42987e0e767c3fa8c7571cd73af435533bcece7a36bd594b0514-2ae27efe97fcf1ece7ea67e36afa94eee62825664716dc4ee7cf030a881d77c1.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of shannon7774")]], [#link("https://terrytao.wordpress.com/2010/08/20/spielman-meyer-nirenberg/#comment-678900")[#strong[#text("shannon7774")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2023")])]

#text("A non-rigorous comment: in Gil Kalai’s consideration of quantum computing, he seems to be injecting a small amount of noise into the system. That seems reminiscent of the idea of Spielman and Teng for smoothed analysis.")
]
