// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/
// Converted to Typst by tao2typ: "2026-10-14T15:17:44.421614+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "DHJ Polymath paper accepted", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("DHJ Polymath paper accepted")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 22 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/")[#text("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#text("Ordinarily, I only mention my research papers on this blog when they are first submitted, or if a major update is required. With the paper arising from the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath1")[#text("DHJ Polymath “Low Dimensions” project")]#text(", though, the situation is a little different as the collaboration to produce the paper took place on this blog.")

#text("Anyway, the good news is that the paper has been accepted for the Szemerédi birthday conference proceedings. The referee was positive and recommended only some minor changes (I include the list of changes below the fold). I have incorporated these changes, and the new version of the paper ")#link("https://terrytao.wordpress.com/wp-content/uploads/2010/04/polymath.pdf")[#text("can be found here")]#text(". Within a few days I need to return the paper to the editor, so this is the last chance to propose any further corrections or changes (though at this stage any major changes are unlikely to be feasible).")

#text("The editor asked a good question: should we have a list of participants for this project somewhere? If so, it seems to make more sense to have this list as a link on the wiki, rather than in the paper itself. But making a list opens the can of worms of deciding what level of participation should be the threshold for inclusion in the list – should someone who only contributed, say, one tangential comment to one of the blog posts be listed alongside a substantially more active participant?")

#text("One possibility is that of self-reporting; we could set up a page for participants on the wiki and let anyone who felt like they contributed add their name, and rely on the honour code to keep it accurate. This might be feasible as long as the page is kept unofficial (so, in particular, it will not be used as the formal list of authors for the paper).")

#text("A related question is whether to add an explicit link to the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Timeline")[#text("timeline")]#text(" for progress on this project and on the sister “New proof” project. If so, this should also be kept unofficial (there was no formal guidelines as to what was included in the timeline and what was not).")

#text("These decisions do not necessarily have to be taken quickly; one can simply point to the wiki in the paper (as is already done in the current version), and update the wiki later if we decide to add these sorts of acknowledgments on that site.")

#text("Incidentally, if we have another successful Polymath project to write up, I would now strongly recommend using version control software (such as Subversion or git) to organise the writing process, both at the informal notes stage and also at the drafting stage. It is certainly far superior to our improvised solution of putting the raw TeX files on a wiki…")

#metadata(none) <tao-4f33df2888307c760c43>

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("In the referee’s opinion the paper is very well written and there were a few typos find only. I would like to ask you and the contributors to check it again (spell check) and send me the tex file.")

#text("Thank you and the contributors to write the paper and sending it to this special volume. I have one more question. Do you want to add a list of contributors with affiliation and/or the time-line as an appendix or anything like that? Please let me know.")

#text("================================")

#text("1. Page 5. First formula. “w(k)=” should be “w(k)\\in”")

#text("2 Page 15. Proof of lemma 3.6 Th proof begins with “Suppose not”, however since the lemma is a negative statement this is confusing. It would be preferable to say “Suppose that A has two parallel [3]^4 slices.”")

#text("3 Page 25. Last formula. This sum should have “\\alpha_i(A)” rather than a_i")

#text("==================================")
]

#heading(level: 1)[#text("Comments (20)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/3fb4d458bcbf1e9401688fe0b464ac401f7415e51ecfc5bf4839fdafa94a79e5-a00588b060c60eea3ef110bd9fbf6ad20e987038c99a3023d1bb2912ad7b78c3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jason Dyer")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44327")[#strong[#text("Jason Dyer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2010")])]

#text("I’d love to clear up the Fujimura reference thing, but I suppose it can wait for a dedicated paper.")

#text("The informal wiki list sounds good to me, but someone who is more affected by the CV issue should weight in.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ec5f78731edc201d99268e7ee5bebd4048b4ac34c2179a7eaef3942d18742858-f9923df6c91dc1e48da7945d10b89b1991a00ed102e3db0c701993c9edb15aac.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Matt Leifer")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44330")[#strong[#text("Matt Leifer")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2010")])]

#text("> Incidentally, if we have another successful Polymath project to write up, I")#linebreak()#text(" > would now strongly recommend using version control software (such as")#linebreak()#text(" > Subversion or git) to organise the writing process, both at the informal notes")#linebreak()#text(" > stage and also at the drafting stage. It is certainly far superior to our")#linebreak()#text(" > improvised solution of putting the raw TeX files on a wiki…")

#text("That is definitely true, but I would suggest Mercurial rather than Subversion or git, for the following reasons:")

#text("– It is distributed, like git, so it has all the same advantages of flexibility over Subversion.")#linebreak()#text(" – It is much easier to learn (and better documented) than git because it is simpler.")#linebreak()#text(" – Although git has more features, which makes it better in the eyes of many software developers, you don’t really need any of the advanced features for writing a paper in LaTeX.")#linebreak()#text(" – I am writing a series of tutorials on how to use Mercurial for LaTeX authoring (as opposed to software development), which will hopefully be easier to follow for those with little or no coding experience.")

#text("I am not a Mercurial evangelist in general and I would say that git is definitely better for a lot of tasks. It is just that authoring LaTeX documents with people who are new to VCS is not one of them.")

#text("For completeness I should mention that if you use Subversion there is a LaTeX package that prints the subversion version number on the document when you latex it (")#link("http://www.tug.org/pracjourn/2007-3/scharrer/")[#text("http://www.tug.org/pracjourn/2007-3/scharrer/")]#text("). This handy if you have a printout and want to know if it is the most recent version. There is no equivalent for Mercurial or git at the moment, but I think the advantages of DVCS outweigh the small inconvenience.")

#text("Incidentally, there are several wiki-engines available that use version control systems as a back end, i.e. every time you make a change to the wiki it is really doing a commit to a repository (here is one that uses Mercurial as a backend: ")#link("http://hatta.sheep.art.pl/")[#text("http://hatta.sheep.art.pl/")]#text(" ). Therefore, you could set up a system where those who don’t want to learn version control can edit via a wiki, but those who want to use their usual LaTeXing setup can checkout the repository and edit locally instead.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9f9d692058b3170db4792107e161953922c74174c9aedb54dc7e8573cee314db-f8ae0f47bdb439ebcfb520a027a99b4623d616ede2f24bfeabe8b0a49a1ced27.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kareem Carr")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44332")[#strong[#text("Kareem Carr")]]#text(size: 9pt, fill: rgb("596477"), " · 22 April 2010")])]

#text("Great news about the paper.")

#text("I think one solution to a very long list of participants, which seems to be used in biology, perhaps because they often have such lists of authors, is to specify what contribution was made by each person listed. It seems like some combination of self-reporting and specification of level of contribution might be fair to all concerned while still remaining practicable. The implicit suggestions of level of contribution embodied in having a list of participants are made explicit, thus avoiding confusion. In my admittedly limited experience with papers where author contribution is specified, we eventually developed a few stock phrases, that were reused as they applied, and were granular enough to say what part of the work we were involved with and at what level. This seemed better than free-form descriptions.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Christian Elsholtz")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44337")[#strong[#text("Christian Elsholtz")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("I am glad the paper has been accepted!")

#text("On the question of participants’ list:")#linebreak()#text(" In this project I always felt that there was a rather clear distinction between participants who contributed regularly, or those that made one entry only (and who would probably prefer not to be named as “active participant”).")

#text("What about the following idea:")#linebreak()#text(" a) producing a list of participants with at least 3 blog entries, where people can opt in or out, if they felt that their one or two entries were relevant or their 7 entries were of a rather non-mathematical nature. Probably that list consists of about 15 people only.")#linebreak()#text(" b) And a note like this at the end of the paper.")#linebreak()#text(" “About 50 (?) people contributed to the blog discussion on this part of the Polymath project. Of these the following made several contributions: list of names…”")

#text("Linking to the timeline is certainly a good idea, even though it only covers the first part of the project.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44353")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("That’s great news!")

#text("Regarding the remaining typos, if needed, I could spend a few hours tomorrow carefully going through each sentence (for instance in section 1.2 there’s “Polymath1, was was focused” which has an extra ‘was’).")

#text("As for an author list, yes there has been 6 or 7 key participants which should definitely be listed somewhere and Kareem’s suggestion is useful I think, but here’s a question about the wiki: what matters is that things remain accessible for the next generation of academics in 15 to 50 years time (when PCs, browsers and HTML will be found only in museums). The paper itself is as safe as any other published paper, but is there a plan to make the wiki long-lived?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0370d1a896797a6c35d6dcfd44d6754e09ccd8bbc0700b42d12133888202801f-a1c7c2ca13b5ac992b05a7c9dda2638098396ea50fd31bf4c95069b66ad37a4a.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Thomas Sauvaget")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44379")[#strong[#text("Thomas Sauvaget")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2010")])]

#text("Beyond the typo mentionned above, here are the other ones I’ve found (unless mistaken):")

#text("p13, lemma 3.4: change “OR is equal” to “OR are equal”")

#text("p21, middle of the page: the comma starting the line after ")#mi("B=...")#text(" might be removed")

#text("p22, two lines after (4.2): isn’t a word missing in “takes the [form] (4.1)” ?")

#text("p23, bottom of the page: in the sentence “It should…” change “lower bound gives” to “lower bound to give”")

#text("p23, last paragraph: missing ‘e’ in “paramters”")

#text("p41, section 5.7, end of third paragraph: space missing in “aremissing” :-)")

#text("p43, next to last paragraph: change “program yield” to “program yields”")

#text("p43, last paragraph: change “with 1 can be as large” to “with 1 to be as large”")

#text("p46, in proof of corollary 5.33: change “thirteen family” to “thirteen families”.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44393")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2010")])]

#text("In the middle paragraph on page 3 there is an “occuring” with only one r, and the same thing in paragrpah four of section 5.3, page 31")

#text("This is nitpicking. On page 22 we use “semi-sphere”, but isn’t hemisphere the more common term for one half of a sphere?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Klas Markström")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44394")[#strong[#text("Klas Markström")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2010")])]

#text("“Anonymous” at 1:24 was me in case anyone wonders.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44422")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2010")])]

#text("I don’t remember how the term “semi-sphere” originated, but in this context it means the portion of a discrete sphere in which the number of 1s is odd (or even). Geometrically, it doesn’t look all that much like a hemisphere, instead being more like a checkerboard colour class of a sphere, so perhaps it’s for the best that we call it something slightly different.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/825d232bb27eb4d9fb8a3ad2252cfc0d6e67c091c2626bac3e705d5fc14ab4fd-9a2ee901a428e13b01ee728668811457153a7709ce5850e6f2b6506935c02376.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of N. Bourbaki")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44356")[#strong[#text("N. Bourbaki")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("Vous les gars devrait le garder propre et simple et non pas la liste des participants partout. Si un jeune chercheur a largement contribué à ce projet, certains participants chevronnés pourraient en faire mention dans leurs lettres de recommandation.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44357")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("I just realised that there is already a page for grant acknowledgements for the “New Proof” and “Low dimensions projects” at")

#link("http://michaelnielsen.org/polymath1/index.php?title=%22New_Proof%22_grant_acknowledgments")[#text("http://michaelnielsen.org/polymath1/index.php?title=%22New_Proof%22_grant_acknowledgments")]

#text("and")

#link("http://michaelnielsen.org/polymath1/index.php?title=%22Low_Dimensions%22_grant_acknowledgments&action=edit&redlink=1")[#text("http://michaelnielsen.org/polymath1/index.php?title=%22Low_Dimensions%22_grant_acknowledgments&action=edit&redlink=1")]

#text("in the endnotes of the Polymath1 page at")

#link("http://michaelnielsen.org/polymath1/index.php?title=Polymath1")[#text("http://michaelnielsen.org/polymath1/index.php?title=Polymath1")]

#text("So I think the simplest thing to do is to add to the grant acknowledgement page some basic contact information and any acknowledgements of support. For instance, I added a link to my own web page. The paper already links to the polymath1 page, so I think we’re covered.")

#text("As for archiving the wiki, I don’t think the conference proceedings will have the technical capability to do so (certainly it would not be possible, nor particularly productive, to include a printout of the entire wiki as an appendix!) But it certainly makes sense to make a backup of the wiki every so often (I think we already did so once already).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44361")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("On the wiki: both the actual pages and the backing database are backed up regularly (daily, as I recall) by my host (Dreamhost). Some time back I sent a dump of everything to Ryan O’Donnell.")

#text("With that said, over the long run I agree that it would be good if a more systematic and more failsafe approach were being used – I’m not exactly an expert on the long-term preservation of wikis. Unfortunately, I don’t know of any services that I’d really trust to do the job. If other people do, please let me know!")

#text("The Library of Congress has recently begun archiving academic law blogs; I’m hopeful that they will consider tackling wikis as well.")

#text("I’ve also chatted with some University librarians about the problem of archiving wikis, and they’re well aware that this needs to be happening, but don’t know of any large-scale efforts. One thing that was mentioned to me, however, is that if anyone has a friendly local librarian at their University, they may be able to archive the wiki. I’m not at an academic institution, however, and am not in a position to do this.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/18d3eac2675001a208af5bcb7f6363e52721f3a204221192105b7aa310fad30a-2ddbbe94595aec02aaa718b27095eb61ce92635b86b377bb4650df795506ed02.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Michael Nielsen")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44362")[#strong[#text("Michael Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2010")])]

#text("On git and version control: I really like git, especially when used in conjunction with github. The two together are an amazing combination. But I’m not sure many academics would want to go through the pain of getting them set up. svn is a lot easier. I haven’t used mercurial, and don’t know how it compares.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44399")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 April 2010")])]

#text("Thanks for all the corrections! The finalised version is at")

#link("https://terrytao.files.wordpress.com/2010/04/polymath1.pdf")[#text("Click to access polymath1.pdf")]

#text("and I will replace the arXiv version shortly also.")

#text("I think from the discussion on listing contributors that the best compromise is to list name, contact information, and any other acknowledgments one wishes to make at")

#link("http://michaelnielsen.org/polymath1/index.php?title=%22Low_Dimensions%22_grant_acknowledgments")[#text("http://michaelnielsen.org/polymath1/index.php?title=%22Low_Dimensions%22_grant_acknowledgments")]

#text("One nice thing about this project is that it involved participants both within academia and outside of it; it would be nice to illustrate this with the participant list.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f4d2f9281a5820face44ca5c5760dc10b65b235a30a88c4468e405cccab22dfc-9d9b6ba916195ebba12a95614763ab09b9fae0c8f0787c620e322a5f44dc61c5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tyler Neylon")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44418")[#strong[#text("Tyler Neylon")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2010")])]

#text("Early in the DHJ polymath, I made a couple epsilon-helpful comments. I suspect there are a number of other people in a similar position – having participated to a small extent, and spent a lot of energy following along and trying to contribute, but ultimately being an infinitesimal mover. The humility of a mature math world tells me to leave my name off, but I’m still excited to have been a part of something so cool.")

#text("Any suggestions for the lesser participants here? Perhaps a place to put our names without pretending the paper needed us?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44421")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2010")])]

#text("Fair enough. A tricky issue, but what I’ve done is added an additional section for “Additional acknowledgments” in which anyone who contributed even the least non-trivial amount can be mentioned (either by themselves, or by others). For instance, I added your name and that of Michael (who, among other things, hosts the wiki). The trick now is to encourage the other participants to overcome their shyness and add their names also…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44425")[#strong[#text("Density Hales-Jewett and Moser numbers « Euclidean Ramsey Theory")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2010")]

#text("[…] The paper “Density Hales-Jewett and Moser numbers” has been accepted. I have just read a a post here in which this is discussed. Apparently a few minor changes are needed. That is good news. Also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/150c6ba05e5576f8678b868a454ee254f2847201e582e1a94d2bca09ed45361e-342b4cbdbe2dd115f4af754b862bf0b2ee350f9568a5764630c914d0d87ef473.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Kristal Cantwell")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44426")[#strong[#text("Kristal Cantwell")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2010")])]

#text("I am glad to hear that the paper has been accepted. My congratulations to all who worked on it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44479")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 29 April 2010")])]

#text("Darcs is in some ways more advanced than mercurial or git; it has some performance problems (which are getting better) but those are of concern mostly to large software projects with 1000’s of files. It has a more mathematical approach to version merging, called “patch algebra”. The website for it is darcs.net and it is written in Haskell, a functional programming language with a highly algebraic flavor.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Some links « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/22/dhj-polymath-paper-accepted/#comment-44555")[#strong[#text("Some links « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 1 May 2010")])]

#text("[…] and “Density Hales-Jewett and Moser Numbers”” for comments, which will precede our own polymath article in the Szemerédi birthday conference […]")
]
