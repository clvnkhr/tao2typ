// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/
// Converted to Typst by tao2typ: "2026-10-14T16:36:08.949417+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Amplitude-frequency dynamics for semilinear dispersive equations", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Amplitude-frequency dynamics for semilinear dispersive equations")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 2 April 2010")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/")[#text("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Semilinear dispersive and wave equations, of which the ")#emph[#text("defocusing nonlinear wave equation")]#text(" ")#metadata(none) <tao-7ade893d8bd880ac6133>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("-\\partial_{tt} u + \\Delta u = \\left|u\\right|^{p-1} u", block: true)]]

#text("is a typical example (where ")#mi("{p>1}")#text(" is a fixed exponent, and ")#mi("{u: {\\bf R}^{1+n} \\rightarrow {\\bf R}}")#text(" is a scalar field), can be viewed as a “tug of war” between a linear dispersive equation, in this case the ")#emph[#text("linear wave equation")]#text(" ")#metadata(none) <tao-7978518ec48e0fdadc9d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("-\\partial_{tt} u + \\Delta u = 0")]]

#text("and a nonlinear ODE, in this case the equation ")#metadata(none) <tao-87e5ad485acb89c18788>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("-\\partial_{tt} u = \\left|u\\right|^{p-1} u.", block: true)]]

#text("If the nonlinear term was not present, leaving only the dispersive equation ")#link(<tao-7978518ec48e0fdadc9d>)[#text("(2)")]#text(", then as the term “dispersive” suggests, in the asymptotic limit ")#mi("{t \\rightarrow \\infty}")#text(", the solution ")#mi("{u(t,x)}")#text(" would spread out in space and decay in amplitude. For instance, in the model case when ")#mi("{d=3}")#text(" and the initial position ")#mi("{u(0,x)}")#text(" vanishes (leaving only the initial velocity ")#mi("{u_t(0,x)}")#text(" as non-trivial initial data), the solution ")#mi("{u(t,x)}")#text(" for ")#mi("{t>0}")#text(" is given by the formula")

#align(center)[#tao-fit-display[#tao-math("u(t,x) = \\frac{1}{4\\pi t} \\int_{\\left|y-x\\right|=t} u_t(0,y)\\ d\\sigma", block: true)]]

#text("where ")#mi("{d\\sigma}")#text(" is surface measure on the sphere ")#tao-math("{\\{ y \\in {\\bf R}^3: \\left|y-x\\right| = t \\}}", block: false)#text(". (To avoid technical issues, let us restrict attention to classical (smooth) solutions.) Thus, if the initial velocity was bounded and compactly supported, then the solution ")#mi("{u(t,x)}")#text(" would be bounded by ")#mi("{O(1/t)}")#text(" and would thus would decay uniformly to zero as ")#mi("{t \\rightarrow \\infty}")#text(". Similar phenomena occur for all dimensions greater than ")#mi("{1}")#text(".")

#text("Conversely, if the dispersive term was not present, leaving only the ODE ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(", then one no longer expects decay; indeed, given the conserved energy ")#tao-math("{\\frac{1}{2} u_t^2 + \\frac{1}{p+1} \\left|u\\right|^{p+1}}", block: false)#text(" for the ODE ")#link(<tao-87e5ad485acb89c18788>)[#text("(3)")]#text(", we do not expect any decay at all (and indeed, solutions are instead periodic in time for each fixed ")#mi("{x}")#text(", as can easily be seen by viewing the ODE (and the energy curves) in phase space).")

#text("Depending on the relative “size” of the dispersive term ")#mi("{\\Delta u}")#text(" and the nonlinear term ")#tao-math("{\\left|u\\right|^{p-1} u}", block: false)#text(", one can heuristically describe the behaviour of a solution ")#mi("{u}")#text(" at various positions at times as either being ")#emph[#text("dispersion dominated")]#text(" (in which ")#tao-math("{\\left|\\Delta u\\right| \\gg \\left|u\\right|^p}", block: false)#text("), ")#emph[#text("nonlinearity dominated")]#text(" (in which ")#tao-math("{\\left|u\\right|^p \\gg \\left|\\Delta u\\right|}", block: false)#text("), or ")#emph[#text("contested")]#text(" (in which ")#tao-math("{\\left|\\Delta u\\right|}", block: false)#text(", ")#tao-math("{\\left|u\\right|^p}", block: false)#text(" are comparable in size). Very roughly speaking, when one is in the dispersion dominated regime, then ")#emph[#text("perturbation theory")]#text(" becomes effective, and one can often show that the solution to the nonlinear equation indeed behaves like the solution to the linear counterpart, in particular exhibiting decay as ")#mi("{t \\rightarrow \\infty}")#text(". In principle, perturbation theory is also available in the nonlinearity dominated regime (in which the dispersion is now viewed as the perturbation, and the nonlinearity as the main term), but in practice this is often difficult to apply (due to the nonlinearity of the approximating equation and the large number of derivatives present in the perturbative term), and so one has to fall back on non-perturbative tools, such as conservation laws and monotonicity formulae. The contested regime is the most interesting, and gives rise to intermediate types of behaviour that are not present in the purely dispersive or purely nonlinear equations, such as solitary wave solutions (solitons) or solutions that blow up in finite time.")

#text("In order to analyse how solutions behave in each of these regimes rigorously, one usually works with a variety of function spaces (such as Lebesgue spaces ")#mi("{L^p}")#text(" and Sobolev spaces ")#mi("{H^s}")#text("). As such, one generally needs to first establish a number of function space estimates (e.g. Sobolev inequalities, Hölder-type inequalities, Strichartz estimates, etc.) in order to study these equations at the formal level.")

#text("Unfortunately, this emphasis on function spaces and their estimates can obscure the underlying physical intuition behind the dynamics of these equations, and the field of analysis of PDE sometimes acquires a reputation for being unduly technical as a consequence. However, as noted in a ")#link("https://terrytao.wordpress.com/2010/03/11/a-type-diagram-for-function-spaces/")[#text("previous blog post")]#text(", one can view function space norms as a way to formalise the intuitive notions of the “height” (amplitude) and “width” (wavelength) of a function (wave).")

#text("It turns out that one can similarly analyse the behaviour of nonlinear dispersive equations on a similar heuristic level, as that of understanding the dynamics as the amplitude ")#mi("{A(t)}")#text(" and wavelength ")#mi("{1/N(t)}")#text(" (or frequency ")#mi("{N(t)}")#text(") of a wave. Below the fold I give some examples of this heuristic; for sake of concreteness I restrict attention to the nonlinear wave equation ")#link(<tao-7ade893d8bd880ac6133>)[#text("(1)")]#text(", though one can of course extend this heuristic to many other models also. Rigorous analogues of the arguments here can be found in several places, such as the ")#link("http://www.ams.org/mathscinet-getitem?mr=1674843")[#text("book of Shatah and Struwe")]#text(", or ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("my own book on the subject")]#text(".")

#metadata(none) <tao-ab6ee635b27a03bb3505>

#heading(level: 1)[#strong[#text(" — 1. Bump functions — ")]]

#text("To initiate the heuristic analysis, we make the assumption that any given time ")#mi("{t}")#text(", the wave ")#mi("{u(t,x)}")#text(" “resembles” (or is “dominated” by) a bump function ")#metadata(none) <tao-5fbde9bb9c3fd8c22402>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("u(t,x) \\approx A(t) e^{i\\theta(t)} \\phi( N(t) (x - x(t)) )")]]

#text("of some amplitude ")#mi("{A(t) > 0}")#text(", some phase ")#mi("{\\theta(t) \\in {\\bf R}}")#text(", some frequency ")#mi("{N(t) > 0}")#text(", and some position ")#mi("{x(t) \\in {\\bf R}^d}")#text(", where ")#mi("{\\phi}")#text(" is a bump function. We will leave the terms “resembles” and “dominated” deliberately vague; ")#mi("{u(t,x)}")#text(" might not consist entirely of this bump function, but could instead be a superposition of multiple components, with this bump function being the “strongest” of these components in some sense. It is of course possible for a solution to concentrate its mass and energy in a different configuration than a bump function; but experience has shown that the most nonlinear behaviour tends to occur when such a concentration occurs, and so this ansatz is expected to capture the “worst-case” behaviour of the solution. (Basically, if a wave splits its energy into too many distinct components, then the nonlinear effects of each component become quite weak, even when superimposed back together again.) In particular, this type of bump function dominance is often seen when the solution exhibits soliton or near-soliton like behaviour, and often occurs shortly prior to blowup (especially for equations with critical nonlinearity). There are a variety of tools to formalise these sorts of intuitions, such as concentration-compactness and the induction-on-energy method, but we will not focus on these tools here.")

#text("(One can also refine the above ansatz in a number of ways, for instance by also introducing a frequency modulation ")#mi("{e^{i x \\cdot \\xi(t)}}")#text(", which is particularly important in models such as the mass-critical NLS which admit a frequency modulation symmetry, but for simplicity we will not consider this more complicated situation here.)")

#text("For this analysis, we shall ignore the role of the phase ")#mi("{\\theta(t)}")#text(" and position ")#mi("{x(t)}")#text(", focusing instead on the amplitude ")#mi("{A(t)}")#text(" and frequency ")#mi("{N(t)}")#text(". This collapses the infinite numbers of degrees of freedom for the wave ")#mi("{u(t)}")#text(" down to just two degrees of freedom. Of course, there is a significant amount of information lost when performing this collapse – in particular, the exact PDE ")#link(<tao-7ade893d8bd880ac6133>)[#text("(1)")]#text(" will no longer retain its deterministic form when projected to these two coordinates – but one can still discern non-trivial features of the original dynamics from this two-dimensional viewpoint.")

#text("With the ansatz ")#link(<tao-5fbde9bb9c3fd8c22402>)[#text("(4)")]#text(", the solution ")#mi("{u(t,x)}")#text(" has magnitude comparable ")#mi("{A(t)}")#text(" to a ball of radius roughly ")#mi("{1/N(t)}")#text(". As a consequence, the nonlinearity ")#tao-math("{\\left|u\\right|^{p-1} u}", block: false)#text(" will have magnitude about ")#mi("{A(t)^p}")#text(" on this ball. Meanwhile, the dispersive term ")#mi("{\\Delta u}")#text(" would be expected to have magnitude about ")#mi("{A(t) N(t)^2}")#text(" (using a crude “rise-over-run” interpretation of the derivative, or else just computing the Laplacian of ")#link(<tao-5fbde9bb9c3fd8c22402>)[#text("(4)")]#text(" explicitly). We thus expect ")#emph[#text("dispersion dominant")]#text(" behaviour when ")#mi("{A(t) N(t)^2 \\gg A(t)^p}")#text(", or in other words when ")#metadata(none) <tao-9639b250b40b41d84ad2>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("A(t) \\ll N(t)^{2/(p-1)},")]]

#emph[#text("nonlinearity dominant")]#text(" behaviour when ")#mi("{A(t) N(t)^2 \\ll A(t)^p}")#text(", or in other words when ")#metadata(none) <tao-85686d225d31b6a3bfbf>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("A(t) \\gg N(t)^{2/(p-1)},")]]

#text("and ")#emph[#text("contested")]#text(" behaviour when ")#mi("{A(t) N(t)^2}")#text(" is comparable to ")#mi("{A(t)^p}")#text(", or in other words when ")#metadata(none) <tao-54c26a1ab342ef60f2f8>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("A(t) \\sim N(t)^{2/(p-1)}.")]]

#text("The evolution of the parameters ")#mi("{A(t), N(t)}")#text(" is partly constrained by a variety of conservation laws and monotonicity formulae. Consider for instance the energy conservation law, which asserts that the ")#emph[#text("energy")]

#align(center)[#tao-fit-display[#tao-math("E = \\int_{{\\bf R}^d} \\frac{1}{2} \\left|u_t\\right|^2 + \\frac{1}{2} \\left|\\nabla u\\right|^2 + \\frac{1}{p+1} \\left|u\\right|^{p+1}\\ dx", block: true)]]

#text("is conserved in time. Inserting the ansatz ")#link(<tao-5fbde9bb9c3fd8c22402>)[#text("(4)")]#text(" into the right-hand side, we obtain the heuristic bound")

#align(center)[#tao-fit-display[#mitex("A_t(t)^2 N(t)^{-d} + A(t)^2 N(t)^{2-d} + A(t)^{p+1} N(t)^{-d} \\ll E.")]]

#text("(We only write an upper bound here for the left-hand side, and not a lower bound, to allow for the possibility that most of the energy of the wave is not invested in the bump function ")#link(<tao-5fbde9bb9c3fd8c22402>)[#text("(4)")]#text(", but is instead dispersed elsewhere.) This gives us the ")#emph[#text("a priori")]#text(" bounds ")#metadata(none) <tao-7d8380df654872f9150a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("A(t) \\ll E^{1/2} N(t)^{(d-2)/2}, E^{1/(p+1)} N(t)^{d/(p+1)}")]]

#text("and ")#metadata(none) <tao-f7c5a225c5698db1c4f9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("A_t(t) \\ll E^{1/2} N(t)^{d/2}.")]]

#text("The bounds ")#link(<tao-7d8380df654872f9150a>)[#text("(8)")]#text(" can be viewed as describing a sort of “energy surface” that the parameters ")#mi("{A(t)}")#text(", ")#mi("{N(t)}")#text(" can vary in.")

#text("It is instructive to see how these bounds interact with the criteria ")#link(<tao-9639b250b40b41d84ad2>)[#text("(5)")]#text(", ")#link(<tao-85686d225d31b6a3bfbf>)[#text("(6)")]#text(", ")#link(<tao-54c26a1ab342ef60f2f8>)[#text("(7)")]#text(", for various choices of dimension ")#mi("{d}")#text(" and exponent ")#mi("{p}")#text(". Let us first see what happens in a ")#emph[#text("supercritical")]#text(" setting, such as ")#mi("{d=3}")#text(" and ")#mi("{p=7}")#text(", with bounded energy ")#mi("{E = O(1)}")#text(". In this case, the energy conservation law gives the bounds")

#align(center)[#tao-fit-display[#mitex("A(t) \\ll \\min( N(t)^{1/2}, N(t)^{3/8} ).")]]

#text("Meanwhile, the threshold between dispersive behaviour and nonlinear behaviour is when ")#mi("{A(t) \\sim N(t)^{1/3}}")#text(". We can illustrate this by performing a log-log plot between ")#mi("{\\log N(t)}")#text(" and ")#mi("{\\log A(t)}")#text(":")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/04/supercrit.png")[#image("../assets/f3d86c0061871c9621a83832b243b2851871e17b36f8b3e11ce0a21a1e560d3f-ce03ea9afac1d71b477f0edfd8766aa8d84cba4cf2d69fc4337e6f4bb4d8c530.png", width: 90%)]

#text("The region below the dotted line corresponds to dispersion-dominated behaviour, and the region above corresponds to nonlinearity-dominated behaviour. The region below the solid line corresponds to the possible values of amplitude and frequency that are permitted by energy conservation.")

#text("This diagram illustrates that for low frequencies ")#mi("{N(t) \\ll 1}")#text(", the energy constraint ensures dispersive behaviour; but for high frequencies ")#mi("{N(t) \\gg 1}")#text(", one can venture increasingly far into the nonlinearity dominated regime while still being consistent with energy conservation. In particular, energy conservation does not prevent a scenario in which the frequency and amplitude both increase to infinity in finite time, while staying inside the nonlinearity dominated regime. And indeed, global regularity for this supercritical equation is a notoriously hard open problem, analogous in many ways to the even more famous global regularity problem for Navier-Stokes (see my ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("previous blog post")]#text(" on this topic).")

#text("In contrast, let us consider a ")#emph[#text("subcritical")]#text(" setting, such as ")#mi("{d=3}")#text(" and ")#mi("{p=3}")#text(", again with bounded energy ")#mi("{E=O(1)}")#text(". Now, the energy conservation law gives the bounds")

#align(center)[#tao-fit-display[#mitex("A(t) \\ll \\min( N(t)^{1/2}, N(t)^{3/4} )")]]

#text("while the threshold between dispersive behaviour and nonlinear behaviour is when ")#mi("{A(t) \\sim N(t)}")#text(". The log-log plot now becomes")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/04/subcrit.png")[#image("../assets/5e6bbe30fdaef0585a280a193c652586e473a29d910986dda65312113d91a859-0e1c33497d2f7c7e0f6bbfdbc06e9ff1c088a7dc56abd4e14305d6a3ba8e19c5.png", width: 90%)]

#text("We now see that for high frequencies ")#mi("{N(t) \\gg 1}")#text(", the energy constraint ensures dispersive behaviour; but conversely, for low frequencies ")#mi("{N(t) \\ll 1}")#text(", one can have highly nonlinear behaviour. On the other hand, low frequencies cannot exhibit finite time blowup (as can be inferred from ")#link(<tao-f7c5a225c5698db1c4f9>)[#text("(9)")]#text("); however, other non-dispersive scenarios exist, such as a soliton-type solution in which ")#mi("{N(t)}")#text(" is low-frequency but essentially constant in time, or a self-similar decay in which ")#mi("{N(t)}")#text(" and ")#mi("{A(t)}")#text(" go slowly to ")#mi("{0}")#text(" as ")#mi("{t \\rightarrow \\infty}")#text(", while staying out of the dispersion-dominated regime. Again, this is reflected in the known theory for this equation for large (but finite energy) data: global regularity is known (there is no blowup), but it is unknown whether the solution disperses like a linear solution in the limit ")#mi("{t \\rightarrow \\infty}")#text(".")

#text("Finally, we look at a critical setting, in which ")#mi("{d=3}")#text(" and ")#mi("{p=5}")#text(". Here, energy conservation gives the bounds")

#align(center)[#tao-fit-display[#mitex("A(t) \\ll \\min(E^{1/2}, E^{1/6}) N(t)^{1/2}")]]

#text("and the threshold between dispersive and nonlinear behaviour is ")#mi("{A(t) \\sim N(t)^{1/2}}")#text(". Thus, when the energy ")#mi("{E}")#text(" is small, one expects only dispersive behaviour; and when the energy is large, then both dispersive and contested behaviour (at both high and low frequencies) are consistent with energy conservation. The large energy case is depicted in the diagram below, with the solid line slightly above the dashed line; in the small energy case, the positions of the two lines are reversed.")

#link("https://terrytao.wordpress.com/wp-content/uploads/2010/04/crit.png")[#image("../assets/125b504d0cf17a996a1eabfbf7084622f41fab10f4a2618929a95aca8b686a08-2235848c0e4164167d9a5b6d9c462b848de4eea53a7d3d123f86405aec34ba62.png", width: 90%)]

#text("Now, it turns out that for small energy, one indeed has global regularity and scattering (for both the defocusing nonlinearity ")#tao-math("{+\\left|u\\right|^4 u}", block: false)#text(" and the focusing nonlinearity ")#tao-math("{-\\left|u\\right|^4 u}", block: false)#text("), which is consistent with the above heuristics. For large energy, blowup can occur in the focusing case, but in the defocusing case what happens is that the solution can linger in the contested region for a finite period of time, but eventually the nonlinearity “concedes” to the dispersion, and the solution enters the dispersion-dominated regime and scatters. This cannot be deduced solely from energy conservation, but requires some additional inputs.")

#text("First, let us assume for contradiction that one never enters the dispersion-dominated regime, but instead remains in the contested regime ")#mi("{A(t) \\sim N(t)^{1/2}}")#text(" throughout. Then from ")#link(<tao-f7c5a225c5698db1c4f9>)[#text("(9)")]#text(" we see that for any time ")#mi("{t_0}")#text(", the quantities ")#mi("{A(t)}")#text(" and ")#mi("{N(t)}")#text(" will not change in magnitude much in the time interval ")#mi("{\\{ t: t = t_0 + O(1/N(t_0))\\}}")#text(". This means that one can subdivide time into intervals ")#mi("{I}")#text(", with ")#mi("{N(t)}")#text(" comparable to ")#tao-math("{\\left|I\\right|^{-1}}", block: false)#text(" on this time interval, and ")#mi("{A(t)}")#text(" comparable to ")#tao-math("{\\left|I\\right|^{-1/2}}", block: false)#text(". The asymptotic behaviour of the solution is then encoded in the combinatorial structure of these intervals. For instance, a soliton-like solution would correspond to a string of intervals ")#mi("{I}")#text(", all of roughly the same size, while a finite time blowup would correspond to a shrinking sequence of intervals converging to the blowup time, whereas a slow decay at infinity would be represented by a sequence of intervals of increasing length going off to infinity. (See Chapter 5 of ")#link("https://terrytao.wordpress.com/books/nonlinear-dispersive-equations-local-and-global-analysis/")[#text("my book")]#text(" for various depictions of these bubble evolutions.)")

#text("One can also take a spacetime view instead of a temporal view, and view the solution as a string of spacetime “bubbles”, each of which has some lifespan ")#mi("{I}")#text(" and amplitude comparable to ")#tao-math("{\\left|I\\right|^{-1/2}}", block: false)#text(", and lives on a spacetime cube of sidelength comparable to ")#tao-math("{\\left|I\\right|}", block: false)#text(". If the number of bubbles is finite, then the nonlinearity eventually concedes and one has dispersive behaviour; if instead the number of bubbles is infinite, then one has contested behaviour that can lead either to finite time blowup or infinite time blowup (where blowup is defined here as failure of dispersion to dominate asymptotically, rather than formation of a singularity). While “number of bubbles” is not a precise quantity, in the rigorous theory of the critical NLW, one uses more quantitative expressions, such as the ")#mi("{L^8}")#text(" norm")

#align(center)[#tao-fit-display[#tao-math("\\int_{I \\times {\\bf R}^3} \\left|u(t,x)\\right|^8\\ dx dt", block: true)]]

#text("or variants such as ")#tao-math("{\\left\\| u \\right\\|_{L^4_t L^{12}_x(I \\times {\\bf R}^3)}^4}", block: false)#text(", as proxies for this concept. Note that each bubble contributes an amount comparable to unity to each of the above expressions. This may help explain why obtaining bounds for these types of norms is so key to establishing global regularity and scattering for this equation.")

#text("The next ingredient is the ")#emph[#text("Morawetz inequality")]

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\int_{{\\bf R}^3} \\frac{\\left|u(t,x)\\right|^6}{\\left|x\\right|}\\ dx dt \\lesssim E", block: true)]]

#text("which can be established by an integration by parts argument. This inequality is easiest to exploit in the model case of spherical symmetry. To be consistent with the ansatz ")#link(<tao-5fbde9bb9c3fd8c22402>)[#text("(4)")]#text(", we must have ")#mi("{x(t)=0}")#text(" in this case. We then have")

#align(center)[#tao-fit-display[#tao-math("\\int_{{\\bf R}^3} \\frac{\\left|u(t,x)\\right|^6}{\\left|x\\right|}\\ dx \\gtrsim N(t)", block: true)]]

#text("and so")

#align(center)[#tao-fit-display[#mitex("\\int_{\\bf R} N(t)\\ dt \\lesssim E.")]]

#text("Each bubble of contested dynamics contributes roughly a unit amount to the integral on the left, and so the Morawetz inequality bounds the total number of bubbles and thus is a mechanism for forcing dispersive behaviour asymptotically.")

#text("In the non-spherically symmetric case, the position ")#mi("{x(t)}")#text(" of the bubble can vary. However, finite speed of propagation heuristics indicate that this position cannot move faster than the speed of light, which is normalised to be ")#mi("{1}")#text(", thus ")#tao-math("{x(t^{\\prime})-x(t) = O(\\left|t^{\\prime}-t\\right|)}", block: false)#text(". (The situation is more complicated if one generalises the ansatz ")#link(<tao-5fbde9bb9c3fd8c22402>)[#text("(4)")]#text(" to allow for the solution ")#mi("{u}")#text(" to consist of a superposition of several bump functions at several different places for each point in time. However, for the critical equation and in the contested regime, each bump function absorbs an amount of energy bounded from below, and so there can only be a bounded number of such bumps existing at any given time; as such, one should morally be able to decompose the evolution into independent “particle-like” components, each of which obeys finite speed of propagation.) The Morawetz inequality then instead gives bounds such as")

#align(center)[#tao-fit-display[#tao-math("\\int_{\\bf R} \\min( N(t), \\frac{1}{\\left|x(t)\\right|} )\\ dt \\lesssim E.", block: true)]]

#text("In the model case when ")#mi("{N(t)}")#text(" stay sroughly bounded, ")#mi("{x(t)}")#text(" can only grow at most linearly in ")#mi("{t}")#text(", and the logarithmic divergence of the integral ")#mi("{\\int \\frac{1}{t}\\ dt}")#text(" at infinity then again forces the number of bubbles to be finite (but this time the bound is exponential in the energy, rather than polynomial; see ")#link("http://www.ams.org/mathscinet-getitem?mr=2227039")[#text("this paper of mine")]#text(", as well as this ")#link("http://www.ams.org/mathscinet-getitem?mr=1666973")[#text("earlier paper of Nakanishi")]#text(", for further discussion.")

#text("One can extend this heuristic analysis to explain why the global regularity results for the energy-critical equation can extend very slightly to the supercritical regime, and in particular (in the spherically symmetric case) to the logarithmically supercritical equation")

#align(center)[#tao-fit-display[#tao-math("-\\partial_{tt} u + \\Delta u = \\left|u\\right|^4 u \\log( 2 + \\left|u\\right|^2 )", block: true)]]

#text("as was done in ")#link("http://arxiv.org/abs/math.AP/0606145")[#text("this paper of mine")]#text(" (and a non-spherically symmetric analogue, with a double logarithmically supercritical nonlinearity, ")#link("http://arxiv.org/abs/0810.5175")[#text("by Roy")]#text("). This equation behaves more or less identically to the critical NLW for low frequencies ")#mi("{N(t) \\ll 1}")#text(", but exhibits slightly different behaviour for high frequencies ")#mi("{N(t) \\gg 1}")#text(". In this regime, the dividing line between dispersive and nonlinear behaviour is now ")#mi("{A(t) \\sim N(t)^{1/2} \\log^{-1/4} N(t)}")#text(". Meanwhile, the energy bounds (assuming bounded energy) now give")

#align(center)[#tao-fit-display[#mitex("A(t) \\lesssim N(t)^{1/2} \\log^{-1/6} N(t)")]]

#text("so that there is now a logarithmically wide window of opportunity for nonlinear behaviour at high frequencies.")

#text("The energy bounds also give")

#align(center)[#tao-fit-display[#mitex("A_t(t) \\lesssim N(t)^{3/2}")]]

#text("from ")#link(<tao-f7c5a225c5698db1c4f9>)[#text("(9)")]#text(", but we can do a little bit better if we invoke the heuristic of ")#emph[#text("equipartition of energy")]#text(", which states that the kinetic portion ")#tao-math("{\\int_{{\\bf R}^3} \\frac{1}{2} \\left|u_t\\right|^2\\ dx}", block: false)#text(" of the energy is roughly in balance with the potential portion ")#tao-math("{\\int_{{\\bf R}^3} \\frac{1}{2} \\left|\\nabla u\\right|^2 + V(u)\\ dx}", block: false)#text(" (where ")#mi("{V(x)}")#text(" is the antiderivative of ")#mi("{x^5 \\log(2+x^2)}")#text("). There are several ways to make this heuristic precise; one is to start with the identity")

#align(center)[#tao-fit-display[#tao-math("\\partial_t \\int_{{\\bf R}^3} u u_t(x) = \\int_{{\\bf R}^3} \\left|u_t\\right|^2 - \\left|\\nabla u\\right|^2 - \\left|u\\right|^6 \\log(2+\\left|u\\right|^2)\\ dx", block: true)]]

#text("which suggests (together with the fundamental theorem of calculus) that the right-hand side should average out to zero after integration in time. Using this heuristic, one is soon led to the slight improvement")

#align(center)[#tao-fit-display[#mitex("A_t(t) \\lesssim A(t) N(t) + A(t)^3 \\log^{1/2} N(t)")]]

#text("of the previous bound.")

#text("The contested regions of the evolution then break up into bubbles in spacetime, each of which has some length and lifespan comparable to ")#mi("{1/N}")#text(", and amplitude ")#mi("{A}")#text(" comparable to ")#mi("{N^{1/2} \\log^{-1/4} N}")#text(" (in the high-frequency case ")#mi("{N \\gg 1}")#text(").")

#text("In contrast, the Morawetz inequality for this equation asserts that ")#metadata(none) <tao-e88b7f5b5d68912f4353>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\int_{\\bf R} \\int_{{\\bf R}^3} \\frac{\\left|u(t,x)\\right|^6 \\log(2+\\left|u(t,x)\\right|^2)}{\\left|x\\right|}\\ dx dt \\lesssim 1.", block: true)]]

#text("In the spherically symmetric case, a bubble of length ")#mi("{1/N}")#text(" and amplitude ")#mi("{A}")#text(" with ")#mi("{N \\gg 1}")#text(" contributes about ")#mi("{A^6 N^3 (\\log A) \\gg \\log^{-1/2} N}")#text(" to the integral in ")#link(<tao-e88b7f5b5d68912f4353>)[#text("(10)")]#text(". This quantity goes to zero as ")#mi("{N \\rightarrow \\infty}")#text(", but very slowly; in particular, as ")#mi("{N}")#text(" increases to infinity along dyadic scales ")#mi("{N=2^k}")#text(", the sum ")#mi("{\\log^{-1/2} N}")#text(" is divergent, which explains why the nonlinearity cannot sustain an infinite chain of such bubbles. (It also suggests that perhaps the logarithmic supercriticality is not quite the right threshold here, and that some slight improvement might be possible in this regard; I believe this is being looked into right now.)")

#heading(level: 1)[#text("Comments (11)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a56493f4090be339555de48007e41c20e4ec91456241820229768269e81c94ae-79e76ff517f05dfff796328eafa68390391628824c250f5cbec470526efb374f.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of timur")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-44080")[#strong[#text("timur")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2010")])]

#text("Thanks a lot!")

#text("In paragraph 3 of “Bump functions”, should phi be theta? And after (7), it seems that “r” is missing in “constained”.")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f88144531339e5ac96b6d549077071fa58f5a8dc026f31a8f8a05212898f2363-7cce7eb1dd58ce73b721df302093a3e33e7569b7272a9c7d1996547281a4c7fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Sujit")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-44086")[#strong[#text("Sujit")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2010")])]

#text("The amplitude/frequency constraint given by (8) does not treat the amplitude and frequency equally. The frequency can blow up and the amplitude can remain bounded while still preserving energy. Whereas it seems from (8) that one cannot have a situation where amplitude blows up and frequency remains bounded while preserving energy. It looks like when amplitude blows up, the frequency also has to blow up so that the integral of the amplitude multiplied with a highly oscillatory part somehow stays bounded.")

#text("Is this true or am I just reading something wrong?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-44088")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 April 2010")])]

#text("A scenario in which the amplitude remains bounded and the frequency goes off to infinity (and the width of the wave, i.e. the wavelength, shrinks to zero) is compatible with energy conservation; but will not actually occur in practice because one would soon enter the dispersion-dominated region (5), at which point the solution would disperse instead (at which point the ansatz (4) will be abandoned).")

#text("This is reflected in the classical fact (proven using the energy method) that smooth solutions stay smooth as long as they stay bounded in the ")#mi("L^\\infty")#text(" norm.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/057d8a48ad851fb9fa205854f2c1f7f4d9b39a838ada2c8f249acb39382c4c7f-79bce5f5624d478a41675641a0234eddc53314a4711adc4171cc9b41fecf82fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akmal")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-44149")[#strong[#text("Akmal")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("Hi Dr. Tao,")

#text("I am a Computational Mathematician, and completed some 82 units of PhD level courseworks related to Computational Mathematics. At my previous school (San Diego State Univ.), I once took a course with an Erdos no. 2 (Dr. Peter Salamon), an he gave me an inspiration to pursue more studies in Pure Mathematics.")

#text("I’d like to gain more insight into PDE and analysis, and realized this is also your interest. However, I do not have a background in pure mathematics; the only course I ever took that is relevant is Advanced Calculus (intro to set theory and topology, pretty much).")

#text("Therefore I’m designing my own track in order to pursue studies in PDE and analysis by starting from:")#linebreak()#text(" 1. Morash’s Bridge to Abstract Mathematics")#linebreak()#text(" 2. Mendelson’s Intro. To Topology")#linebreak()#text(" 3. Simmons’s Intro. To Topology and Modern Analysis")#linebreak()#text(" 4. Bridge’s Real Analysis (A Constructive Approach)")#linebreak()#text(" 5. Cohn’s Measure Theory")#linebreak()#text(" 6. Rudin’s Real and Complex Analysis")#linebreak()#text(" 7. Evans’s Partial Differential Equations (Grad Studies in Math)")#linebreak()#text(" 8. Folland’s Introduction to Partial Differential Equations.")

#text("If you or anybody else here can give me an advice or critique about the way I approach this, I really appreciate your kind help.")

#text("Thank you in advance Dr. Tao")

#text("Best wishes,")#linebreak()#text(" Akmal")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/057d8a48ad851fb9fa205854f2c1f7f4d9b39a838ada2c8f249acb39382c4c7f-79bce5f5624d478a41675641a0234eddc53314a4711adc4171cc9b41fecf82fe.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Akmal")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-44150")[#strong[#text("Akmal")]]#text(size: 9pt, fill: rgb("596477"), " · 10 April 2010")])]

#text("correction: my apology, the professor I mentioned (Dr. Peter Salamon) has an Erdos Number of 1, not 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-44168")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 11 April 2010")])]

#text("Dear Terry,")

#text("Request: Please consider an expository post on global climate modeling, a topic with close connections with nonlinear PDE, as well")#linebreak()#text(" as other subjects of interest to you, such as probability and decision theory. If you have anything particularly insightful to say about this topic, many of us would greatly enjoy reading it.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-52934")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2011")])]

#text("In the heuristic bound before equation 8, why is there no term where N is differentiated in the t-variable?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-52942")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 May 2011")])]

#text("One can certainly add such terms to the heuristics if desired, giving some predictions as to how fast N(t) will vary in time. But these bounds are not relevant for the discussion here as we are not trying to investigate the specific dynamics of N(t) in time. (But if one was interested in, say, blowup rates for such equations, then these heuristic computations would become relevant.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-63756")[#strong[#text("Localisation and compactness properties of the Navier-Stokes global regularity problem « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 4 August 2011")])]

#text("[…] one can guess at the existence of such a bound by using the amplitude-frequency heuristics, discussed in this post. If the Navier-Stokes solution has an amplitude and a frequency for a period of time over a […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-474062")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2016")])]

#text("I’m not sure if this question is appropriate here. I have heard in informal discussions the term “dynamics” of certain PDE (or ODE). For instance, “the long time ")#emph[#text("dynamics")]#text(" of the 2D NSE is entirely contained in the global attractor”. And even in the title of a journal (of which you are an editor): Dynamics of Partial Differential Equations. What does the term “dynamics” mean? Do you have a formal definition for it? Or is it only understood loosely?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/db070355fdb640ad2c7e83f2901c04633b4e24c7b6e1d2ee2589133350895006-f9da2e26c1544e14f1a4e3e3f414c5d1d407558530a6ed84bd66e870340def56.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of nightmartyr")]], [#link("https://terrytao.wordpress.com/2010/04/02/amplitude-frequency-dynamics-for-semilinear-dispersive-equations/#comment-474066")[#strong[#text("nightmartyr")]]#text(size: 9pt, fill: rgb("596477"), " · 5 November 2016")])]

#text("Typically dynamics refers to how a state changes in `time.’ This notion of time can be physical, as in, how celestial bodies move about in real time, or mathematical, as in iterating a function or evolving a flow that represents the solution to a differential equation. Depending on what you are interested in, Wikipedia has a good discussion of Dynamical Systems. ")#link("https://en.wikipedia.org/wiki/Dynamical_system")[#text("https://en.wikipedia.org/wiki/Dynamical_system")]
]
]
