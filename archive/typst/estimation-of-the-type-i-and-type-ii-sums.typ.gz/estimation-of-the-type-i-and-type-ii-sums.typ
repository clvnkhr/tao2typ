// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/
// Converted to Typst by tao2typ: "2026-10-14T15:18:40.164760+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Estimation of the Type I and Type II sums", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Estimation of the Type I and Type II sums")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 12 June 2013")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

#import "@preview/equate:0.3.3": equate, share-align
#let tao-aligned(body, keep: true) = {
  show: equate.with(sub-numbering: false)
  block(breakable: not keep, above: 1em, below: 1em, share-align(body))
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("This is one of the continuations of the ")#link("https://terrytao.wordpress.com/2013/06/04/online-reading-seminar-for-zhangs-bounded-gaps-between-primes/")[#text("online reading seminar")]#text(" of ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text(" for the ")#link("http://michaelnielsen.org/polymath1/index.php?title=Bounded_gaps_between_primes")[#text("polymath8 project")]#text(". (There are two other continuations; ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(", which deals with the combinatorial aspects of the second part of Zhang’s paper, and a post to come that covers the Type III sums.) The main purpose of this post is to present (and hopefully, to improve upon) the treatment of two of the three key estimates in Zhang’s paper, namely the Type I and Type II estimates.")

#text("The main estimate was already stated as Theorem 16 in ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("the previous post")]#text(", but we quickly recall the relevant definitions here. As in other posts, we always take ")#mi("{x}")#text(" to be a parameter going off to infinity, with the usual asymptotic notation ")#mi("{O(), o(), \\ll}")#text(" associated to this parameter.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 1 (Coefficient sequences)")]#text(" A ")#emph[#text("coefficient sequence")]#text(" is a finitely supported sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf R}}")#text(" that obeys the bounds ")#metadata(none) <tao-afd7bf72960f2f867380>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#tao-math("\\left|\\alpha(n)\\right| \\ll \\tau^{O(1)}(n) \\log^{O(1)}(x)", block: true)]]

#text("for all ")#mi("{n}")#text(", where ")#mi("{\\tau}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Divisor_function")[#text("divisor function")]#text(".")

#list(
[#text("(i) If ")#mi("{\\alpha}")#text(" is a coefficient sequence and ")#mi("{a\\ (q) = a \\text{ mod } q}")#text(" is a primitive residue class, the (signed) ")#emph[#text("discrepancy")]#text(" ")#mi("{\\Delta(\\alpha; a\\ (q))}")#text(" of ")#mi("{\\alpha}")#text(" in the sequence is defined to be the quantity")

#metadata(none) <tao-6cd4c9c389b460a1f603>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("\\Delta(\\alpha; a \\ (q)) := \\sum_{n: n = a\\ (q)} \\alpha(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1} \\alpha(n).")]]],
[#text("(ii) A coefficient sequence ")#mi("{\\alpha}")#text(" is said to be ")#emph[#text("at scale ")#mi("{N}")]#text(" for some ")#mi("{N \\geq 1}")#text(" if it is supported on an interval of the form ")#mi("{[(1-O(\\log^{-A_0} x)) N, (1+O(\\log^{-A_0} x)) N]}")#text(".")],
[#text("(iii) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to ")#emph[#text("obey the Siegel-Walfisz theorem")]#text(" if one has")

#metadata(none) <tao-a543997d84f12798350c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#tao-math("\\left| \\Delta(\\alpha 1_{(\\cdot,q)=1}; a\\ (r)) \\right| \\ll \\tau(qr)^{O(1)} N \\log^{-A} x", block: true)]]

#text("for any ")#mi("{q,r \\geq 1}")#text(", any fixed ")#mi("{A}")#text(", and any primitive residue class ")#mi("{a\\ (r)}")#text(".")],
[#text("(iv) A coefficient sequence ")#mi("{\\alpha}")#text(" at scale ")#mi("{N}")#text(" is said to be ")#emph[#text("smooth")]#text(" if it takes the form ")#mi("{\\alpha(n) = \\psi(n/N)}")#text(" for some smooth function ")#mi("{\\psi: {\\bf R} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{[1-O(\\log^{-A_0} x), 1+O(\\log^{-A_0} x)]}")#text(" obeying the derivative bounds")

#metadata(none) <tao-ab1e6be2000a7c9c3d39>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("\\psi^{(j)}(t) = O( \\log^{j A_0} x )")]]

#text("for all fixed ")#mi("{j \\geq 0}")#text(" (note that the implied constant in the ")#mi("{O()}")#text(" notation may depend on ")#mi("{j}")#text(").")]
)
]

#text("In Lemma 8 of ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(" we established a collection of “crude estimates” which assert, roughly speaking, that for the purposes of averaged estimates one may ignore the ")#mi("{\\tau^{O(1)}(n)}")#text(" factor in ")#link(<tao-afd7bf72960f2f867380>)[#text("(1)")]#text(" and pretend that ")#mi("{\\alpha(n)}")#text(" was in fact ")#mi("{O( \\log^{O(1)} n)}")#text(". We shall rely frequently on these “crude estimates” without further citation to that precise lemma.")

#text("For any ")#mi("{I \\subset {\\bf R}}")#text(", let ")#mi("{{\\mathcal S}_I}")#text(" denote the square-free numbers whose prime factors lie in ")#mi("{I}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Definition 2 (Singleton congruence class system)")]#text(" Let ")#mi("{I \\subset {\\bf R}}")#text(". A ")#emph[#text("singleton congruence class system")]#text(" on ")#mi("{I}")#text(" is a collection ")#mi("{{\\mathcal C} = (\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" of primitive residue classes ")#mi("{a_q \\in ({\\bf Z}/q{\\bf Z})^\\times}")#text(" for each ")#mi("{q \\in {\\mathcal S}_I}")#text(", obeying the Chinese remainder theorem property ")#metadata(none) <tao-793ff64f83b41b5d467a>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("a_{qr}\\ (qr) = (a_q\\ (q)) \\cap (a_r\\ (r))")]]

#text("whenever ")#mi("{q,r \\in {\\mathcal S}_I}")#text(" are coprime. We say that such a system ")#mi("{{\\mathcal C}}")#text(" has ")#emph[#text("controlled multiplicity")]#text(" if the")

#align(center)[#tao-fit-display[#tao-math("\\tau_{\\mathcal C}(n) := \\left|\\{ q \\in {\\mathcal S}_I: n = a_q\\ (q) \\}\\right|", block: true)]]

#text("obeys the estimate ")#metadata(none) <tao-cbf38e496835a79fe9ba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#mitex("\\sum_{C^{-1} x \\leq n \\leq Cx: n = a\\ (r)} \\tau_{\\mathcal C}(n)^2 \\ll \\frac{x}{r} \\tau(r)^{O(1)} \\log^{O(1)} x + x^{o(1)}.")]]

#text("for any fixed ")#mi("{C>1}")#text(" and any congruence class ")#mi("{a\\ (r)}")#text(" with ")#mi("{r \\in {\\mathcal S}_I}")#text(".")
]

#text("The main result of this post is then the following:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 3 (Type I/II estimate)")]#text(" ")#metadata(none) <tao-840c81157f3688e42875>#text(" Let ")#mi("{\\varpi, \\delta, \\sigma > 0}")#text(" be fixed quantities such that ")#metadata(none) <tao-810cc6914d7cb6597a00>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("11 \\varpi + 3\\delta + 2 \\sigma < \\frac{1}{4}")]]

#text("and ")#metadata(none) <tao-5b1b85d956c07f3e4d5f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#mitex("29\\varpi + 5 \\delta < \\frac{1}{4}")]]

#text("and let ")#mi("{\\alpha,\\beta}")#text(" be coefficient sequences at scales ")#mi("{M,N}")#text(" respectively with ")#metadata(none) <tao-2f48b881ea7073f1c6f0>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("x \\ll MN \\ll x")]]

#text("and ")#metadata(none) <tao-cd58add90c5a1937a32b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#mitex("x^{\\frac{1}{2}-\\sigma} \\ll N \\ll M \\ll x^{\\frac{1}{2}+\\sigma}")]]

#text("with ")#mi("{\\beta}")#text(" obeying a Siegel-Walfisz theorem. Then for any ")#mi("{I \\subset [1,x^\\delta]}")#text(" and any singleton congruence class system ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_I}}")#text(" with controlled multiplicity we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I: q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\beta; a_q)\\right| \\ll x \\log^{-A} x.", block: true)]]
]

#text("The proof of this theorem relies on five basic tools:")

#list(
[#text("(i) the Bombieri-Vinogradov theorem;")],
[#text("(ii) completion of sums;")],
[#text("(iii) the Weil conjectures;")],
[#text("(iv) factorisation of smooth moduli ")#mi("{q \\in {\\mathcal S}_I}")#text("; and")],
[#text("(v) the Cauchy-Schwarz and triangle inequalities (Weyl differencing and the dispersion method).")]
)

#text("For the purposes of numerics, it is the interplay between (ii), (iii), and (v) that drives the final conditions ")#link(<tao-810cc6914d7cb6597a00>)[#text("(7)")]#text(", ")#link(<tao-5b1b85d956c07f3e4d5f>)[#text("(8)")]#text(". The Weil conjectures are the primary source of power savings (")#mi("{x^{-c}}")#text(" for some fixed ")#mi("{c>0}")#text(") in the argument, but they need to overcome power losses coming from completion of sums, and also each use of Cauchy-Schwarz tends to halve any power savings present in one’s estimates. Naively, one could thus expect to get better estimates by relying more on the Weil conjectures, and less on completion of sums and on Cauchy-Schwarz.")

#metadata(none) <tao-e62bf6e395f8bc7531d8>

#heading(level: 1)[#strong[#text(" — 1. The Bombieri-Vinogradov theorem — ")]]

#text("One of the basic distribution results in this area of analytic number theory is the ")#link("http://en.wikipedia.org/wiki/Bombieri%E2%80%93Vinogradov_theorem")[#text("Bombieri-Vinogradov theorem")]#text(". As ")#link("http://www.ams.org/mathscinet-getitem?mr=422179")[#text("first observed by Motohashi")]#text(", this theorem in fact controls the distribution of a general class of Dirichlet convolutions in congruence classes. We will use the following formulation of this theorem, essentially Theorem 0 of ")#link("http://www.ams.org/mathscinet-getitem?mr=834613")[#text("Bombieri-Friedlander-Iwaniec")]#text(";")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 4 (Bombieri-Vinogradov theorem)")]#text(" ")#metadata(none) <tao-c5c8fcbf6d9460bd16fa>#text(" Let ")#mi("{M,N}")#text(" be such that")

#align(center)[#tao-fit-display[#mitex("x \\ll MN \\ll x")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^\\epsilon \\ll M,N \\ll x^{1-\\epsilon}")]]

#text("for some fixed ")#mi("{0 < \\epsilon < 1}")#text(". Let ")#mi("{\\alpha,\\beta}")#text(" be coefficient sequences at scale ")#mi("{M,N}")#text(" respectively. Suppose also that ")#mi("{\\beta}")#text(" obeys a Siegel-Walfisz theorem.")

#list(
[#text("(i) (First Bombieri-Vinogradov inequality) We have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq x^{-o(1)} N} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\beta; a)\\right|^2 \\ll N^2 \\log^{-A} x", block: true)]]

#text("for some sufficiently slowly decaying ")#mi("{o(1)}")#text(" and any fixed ")#mi("{A>0}")#text(".")],
[#text("(ii) (Second Bombieri-Vinogradov inequality) we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq x^{1/2-o(1)}} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha*\\beta; a)\\right| \\ll x \\log^{-A} x", block: true)]]

#text("for some sufficiently slowly decaying ")#mi("{o(1)}")#text(" and any fixed ")#mi("{A>0}")#text(".")]
)
]

#text("For sake of completeness we now recall the proof of this theorem, following the presentation in Bombieri-Friedlander-Iwaniec. (This is standard material, and experts may immediately skip to the next section.) We first need the large sieve inequality for Dirichlet characters:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 5 (Large sieve inequality)")]#text(" ")#metadata(none) <tao-9b9a3717eacd16206b4b>#text(" For any sequence ")#mi("{\\alpha: {\\bf N} \\rightarrow {\\bf C}}")#text(" supported on ")#mi("{\\{1,\\ldots,N\\}}")#text(" and any ")#mi("{Q > 1}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\sum_{\\chi\\ (q)}^* \\frac{q}{\\phi(q)} \\left|\\sum_n \\alpha(n) \\chi(n)\\right|^2 \\ll (Q^2+N) \\sum_n \\left|\\alpha(n)\\right|^2", block: true)]]

#text("where the ")#mi("{\\chi}")#text(" summation is over primitive ")#link("http://en.wikipedia.org/wiki/Dirichlet_character")[#text("Dirichlet characters")]#text(" of conductor ")#mi("{q}")#text(".")
]

#emph[#text("Proof:")]#text(" By enlarging ")#mi("{N}")#text(" we may assume that ")#mi("{N \\geq Q^2}")#text(".")

#text("We use the ")#mi("{TT^*}")#text(" method. By duality, the desired estimate is equivalent to")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{q \\leq Q} \\sum_{\\chi\\ (q)}^* \\frac{q}{\\phi(q)} c_\\chi \\sum_{n \\leq N} \\alpha(n) \\chi(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#tao-math("\\ll N^{1/2} (\\sum_{n \\leq N} \\left|\\alpha(n)\\right|^2)^{1/2} (\\sum_{q \\leq Q} \\sum_{\\chi\\ (q)}^* \\frac{q}{\\phi(q)} \\left|c_\\chi\\right|^2)^{1/2}", block: true)]]

#text("which is in turn equivalent to")

#align(center)[#tao-fit-display[#tao-math("\\sum_n 1_{n \\leq N} \\left|\\sum_{q \\leq Q} \\sum_{\\chi\\ (q)}^* \\frac{q}{\\phi(q)} c_\\chi \\chi(n)\\right|^2 \\ll N \\sum_{q \\leq Q} \\sum_{\\chi\\ (q)}^* \\frac{q}{\\phi(q)} \\left|c_\\chi\\right|^2.", block: true)]]

#text("We bound ")#mi("{1_{n \\leq N}}")#text(" by a Schwartz function ")#mi("{\\psi(n/N)}")#text(" whose Fourier transform is supported on ")#mi("{[-1/2Q^2,1/2Q^2]}")#text("; this is possible for a fixed ")#mi("{\\psi}")#text(" when ")#mi("{N \\geq Q^2}")#text(". The left-hand side then expands as")

#align(center)[#tao-fit-display[#mitex("\\sum_{q,q^{\\prime} \\leq Q} \\sum_{\\chi\\ (q)}^* \\sum_{\\chi^{\\prime}\\ (q^{\\prime})}^* \\frac{q}{\\phi(q)} c_\\chi \\frac{q^{\\prime}}{\\phi(q^{\\prime})} \\overline{c_{\\chi^{\\prime}}} (\\sum_n \\psi(n/N) \\chi\\overline{\\chi^{\\prime}}(n)).")]]

#text("The inner sum is ")#mi("{O(N \\frac{\\phi(q)}{q})}")#text(" when ")#mi("{\\chi=\\chi^{\\prime}}")#text(", and zero otherwise thanks to Fourier analysis (specifically, the Poisson summation formula combined with the support of the Fourier transform of ")#mi("{\\psi}")#text(" and the fact that ")#mi("{\\chi\\overline{\\chi^{\\prime}}}")#text(" is periodic of period ")#mi("{qq^{\\prime}}")#text(" with mean zero). The claim follows. ")#mi("\\Box")

#text("Now we prove part (i) of Theorem ")#link(<tao-c5c8fcbf6d9460bd16fa>)[#text("4")]#text(". By an ")#link("http://en.wikipedia.org/wiki/Overspill")[#text("overspill")]#text(" argument (cf. Lemma 7 of ")#link("https://terrytao.wordpress.com/2013/06/03/the-prime-tuples-conjecture-sieve-theory-and-the-work-of-goldston-pintz-yildirim-motohashi-pintz-and-zhang/")[#text("this previous post")]#text(") it suffices to show that ")#metadata(none) <tao-a31fe9656fc8d3a459e6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#tao-math("\\sum_{q \\leq x^{-\\epsilon} N} \\sum_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\beta; a)\\right|^2 \\ll N^2 \\log^{-A} x", block: true)]]

#text("for any fixed ")#mi("{A,\\epsilon > 0}")#text(".")

#text("Let ")#mi("{Q := x^{-\\epsilon} N}")#text(". By multiplicative Fourier analysis we may write the left-hand side of ")#link(<tao-a31fe9656fc8d3a459e6>)[#text("(11)")]#text(" as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\leq Q} \\frac{1}{\\phi(q)} \\sum_{\\chi \\neq \\chi_0\\ (q)} \\left|\\sum_n \\beta(n) \\chi(n)\\right|^2", block: true)]]

#text("where the inner sum ranges over non-principal Dirichlet characters ")#mi("{\\chi}")#text(" of modulus ")#mi("{q}")#text(", not necessarily primitive. Any such character can be written as ")#mi("{\\chi(n) = \\psi(n) 1_{(n,e)=1}}")#text(" where ")#mi("{q = de}")#text(" with ")#mi("{d > 1}")#text(", and ")#mi("{\\psi}")#text(" is a primitive Dirichlet character of conductor ")#mi("{d}")#text(". The above sum can then be rewritten as")

#align(center)[#tao-fit-display[#tao-math("\\sum_{e \\leq Q} \\sum_{1 < d < Q/e} \\frac{1}{\\phi(de)} \\sum_{\\psi\\ (d)}^* \\left|\\sum_n \\beta(n) \\psi(n) 1_{(n,e)=1}\\right|^2", block: true)]]

#text("where the ")#mi("{\\psi}")#text(" summation ranges over primitive characters modulo ")#mi("{d}")#text(". Since ")#mi("{\\frac{1}{\\phi(de)} \\leq \\frac{1}{\\phi(d)} \\frac{1}{\\phi(e)}}")#text(", we may bound this by")

#align(center)[#tao-fit-display[#tao-math("\\sum_{e \\leq Q} \\frac{1}{\\phi(e)} \\sum_{1 < d < Q/e} \\frac{1}{\\phi(d)} \\sum_{\\psi\\ (d)}^* \\left|\\sum_n \\beta(n) \\psi(n) 1_{(n,e)=1}\\right|^2,", block: true)]]

#text("which on performing the ")#mi("{e}")#text(" summation is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\ll (\\log x)^{O(1)} \\sup_{e \\leq Q} \\sum_{1 < d < Q/e} \\frac{1}{\\phi(d)} \\sum_{\\psi\\ (d)}^* \\left|\\sum_n \\beta(n) \\psi(n) 1_{(n,e)=1}\\right|^2,", block: true)]]

#text("and then by dyadic decomposition this is bounded by")

#align(center)[#tao-fit-display[#tao-math("\\ll (\\log x)^{O(1)} \\sup_{e, D \\leq Q} \\sum_{D < d < 2D} \\frac{1}{\\phi(d)} \\sum_{\\psi\\ (d)}^* \\left|\\sum_n \\beta(n) \\psi(n) 1_{(n,e)=1}\\right|^2.", block: true)]]

#text("Let us first consider the contribution of the small moduli, specifically when ")#mi("{D \\leq \\log^{C} x}")#text(" for some fixed ")#mi("{C>0}")#text(". From the Siegel-Walfisz theorem ")#link(<tao-a543997d84f12798350c>)[#text("(3)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_n \\beta(n) \\psi(n) 1_{(n,e)=1} \\ll \\tau(de)^{O(1)} N \\log^{-A^{\\prime} + O(C)} x")]]

#text("for any fixed ")#mi("{A^{\\prime}>0}")#text(", and then by crude estimates (see Lemma 8 of ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/")[#text("this previous post")]#text(") we see that this contribution is acceptable for ")#link(<tao-a31fe9656fc8d3a459e6>)[#text("(11)")]#text(". Thus we may restrict attention to those moduli with ")#mi("{D > \\log^{C} x}")#text(" for any fixed ")#mi("{C}")#text(". On the other hand, from Lemma ")#link(<tao-9b9a3717eacd16206b4b>)[#text("5")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{D \\leq d \\leq 2D} \\frac{1}{\\phi(d)} \\sum_{\\psi\\ (d)}^* \\left|\\sum_n \\beta(n) \\psi(n) 1_{(n,e)=1}\\right|^2 \\ll \\frac{N+D^2}{D} \\sum_n \\left|\\beta(n) 1_{(n,e)=1}\\right|^2", block: true)]]

#text("for any ")#mi("{\\log^C x \\ll D \\ll Q}")#text(". From crude estimates we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|\\beta(n) 1_{(n,e)=1}\\right|^2 \\ll N \\log^{O(1)} x.", block: true)]]

#text("Since")

#align(center)[#tao-fit-display[#mitex("\\frac{N+D^2}{D} = N/D + D \\ll N \\log^{-C} x + N x^{-\\epsilon}")]]

#text("the claim follows.")

#text("Now we prove (ii). We now set ")#mi("{Q := x^{1/2-\\epsilon}}")#text(" for some fixed ")#mi("{\\epsilon>0}")#text(". By overspill as before, it suffices to show that ")#metadata(none) <tao-0e07cf830957701d43c1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(12)")])
#tao-math("\\sum_{q \\leq Q} \\sup_{a \\in ({\\bf Z}/q{\\bf Z})^\\times} \\left|\\Delta(\\alpha \\ast \\beta; a)\\right| \\ll x \\log^{-A} x.", block: true)]]

#text("By multiplicative Fourier analysis we have")

#tao-aligned(keep: true)[


#tao-math("\\Delta(\\alpha \\ast \\beta; a)  & = \\frac{1}{\\phi(q)} \\sum_{\\chi \\neq \\chi_0\\ (q)} \\overline{\\chi(a)} \\sum_n \\alpha \\ast \\beta(n) \\chi(n)", block: true)



#tao-math(" & = \\frac{1}{\\phi(q)} \\sum_{\\chi \\neq \\chi_0\\ (q)} \\overline{\\chi(a)} (\\sum_m \\alpha \\chi(m)) (\\sum_n \\beta \\chi(n))", block: true)
]

#text("so by splitting into primitive characters as before we may bound the left-hand side of ")#link(<tao-0e07cf830957701d43c1>)[#text("(12)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll (\\log x)^{O(1)} \\sup_{e,D \\leq Q} \\sum_{D < d < 2D} \\frac{1}{\\phi(d)} \\sum_{\\psi\\ (d)}^*")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_m \\alpha \\psi(m) 1_{(m,e)=1}\\right| \\left|\\sum_n \\beta \\psi(n) 1_{(n,e)=1}\\right|", block: true)]]

#text("Arguing as before, the case ")#mi("{D \\leq \\log^C x}")#text(" is acceptable, so we assume ")#mi("{\\log^C x \\leq D \\leq x^{1/2-\\epsilon}}")#text(". From crude estimates we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_m \\left|\\alpha(m) 1_{(m,e)=1}\\right|^2 \\ll M \\log^{O(1)} x.", block: true)]]

#text("and")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|\\beta(n) 1_{(n,e)=1}\\right|^2 \\ll N \\log^{O(1)} x.", block: true)]]

#text("From Lemma ")#link(<tao-9b9a3717eacd16206b4b>)[#text("5")]#text(" and Cauchy-Schwarz we can thus bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{D < d < 2D} \\frac{1}{\\phi(d)} \\sum_{\\psi\\ (d)}^* \\left|\\sum_m \\alpha \\chi(m) 1_{(m,e)=1}\\right| \\left|\\sum_n \\beta \\chi(n) 1_{(n,e)=1}\\right|", block: true)]]

#text("by")

#align(center)[#tao-fit-display[#mitex("\\ll \\frac{\\log^{O(1)} x}{D} N^{1/2} M^{1/2} (N+D^2)^{1/2} (M+D^2)^{1/2};")]]

#text("as ")#mi("{NM}")#text(" is comparable to ")#mi("{x}")#text(", this simplifies to")

#align(center)[#tao-fit-display[#mitex("\\ll x \\log^{O(1)} x ( \\frac{1}{D} + N^{-1/2} + M^{-1/2} + x^{-1/2} D ),")]]

#text("which is acceptable from the hypotheses on ")#mi("{D, Q, N, M}")#text(" if ")#mi("{C}")#text(" is chosen large enough depending on ")#mi("{A}")#text(". This concludes the proof of Theorem ")#link(<tao-c5c8fcbf6d9460bd16fa>)[#text("4")]#text(".")

#text("We remark that an inspection of the proof reveals that the ")#mi("{x^{-o(1)}}")#text(" or ")#mi("{x^{-\\epsilon}}")#text(" factors in the threshold ")#mi("{Q}")#text(" for ")#mi("{q}")#text(" may be replaced by ")#mi("{\\log^{-A^{\\prime}} x}")#text(" provided that ")#mi("{A^{\\prime}}")#text(" is sufficiently large depending on ")#mi("{A}")#text(". However, this refinement of the Bombieri-Vinogradov inequality does not lead to any improvement in the final numerology for our purposes.")

#heading(level: 1)[#strong[#text(" — 2. Completion of sums — ")]]

#text("At several stages in the argument we will need to consider sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\psi_M(m) \\sum_{i \\in I: m = a_i\\ (d)} c_i")]]

#text("for some smooth coefficient sequence ")#mi("{\\psi_M}")#text(", sone congruence classes ")#mi("{a_i\\ (d)}")#text(" depending on a further parameter ")#mi("{i}")#text(", and further coefficients ")#mi("{c_i}")#text(". The ")#emph[#text("completion of sums")]#text(" technique replaces the ")#mi("{\\psi_M(m)}")#text(" term here with an exponential phase, leaving one with consideration of exponential sums such as")

#align(center)[#tao-fit-display[#mitex("\\sum_{i \\in I} c_i e_d(-a_i h)")]]

#text("for various ")#mi("{h}")#text(", where ")#mi("{e_d(n) := e^{2\\pi i n/d}}")#text(" for ")#mi("{n \\in {\\bf Z}/d{\\bf Z}}")#text(" (or ")#mi("{n \\in {\\bf Z}}")#text(") is the standard character on ")#mi("{{\\bf Z}/d{\\bf Z}}")#text(". More precisely, we have")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 6 (Completion of sums)")]#text(" ")#metadata(none) <tao-71b4f3a3748cd6843c01>#text(" Let ")#mi("{\\psi_M}")#text(" be a smooth coefficient sequence at some scale ")#mi("{1 \\ll M \\ll x}")#text(". Let ")#mi("{I}")#text(" be a finite set of indices, and for each ")#mi("{i \\in I}")#text(" let ")#mi("{c_i}")#text(" be a complex number and ")#mi("{a_i\\ (d)}")#text(" be a congruence class for some ")#mi("{d \\ll x}")#text(". we have ")#metadata(none) <tao-eebbf6457e46a7f63acd>

#tao-aligned(keep: true)[


#tao-math("\\sum_m \\psi_M(m) \\sum_{i \\in I: m = a_i\\ (d)} c_i  & = \\frac{1}{d} (\\sum_m \\psi_M(m)) (\\sum_i c_i)", block: true, numbering: n => [#text("(13)")])



#tao-math(" & + O( (\\log^{O(1)} x) \\frac{M}{d} \\sum_{1 \\leq h \\leq x^\\epsilon d M^{-1}} \\left|\\sum_i c_i e_d( a_i h )\\right| )", block: true)



#tao-math(" & + O( x^{-A} \\sum_i \\left|c_i\\right| )", block: true)
]

#text("for any fixed ")#mi("{\\epsilon,A>0}")#text(".")
]

#text("Specialising to the case ")#mi("{I = {\\bf Z}/d{\\bf Z}}")#text(" and ")#mi("{a_i = i}")#text(", we conclude in particular that ")#metadata(none) <tao-5a84a5711663cb5203e5>

#tao-aligned(keep: true)[


#tao-math("\\sum_m \\psi_M(m) c(m)  & = \\frac{1}{d} (\\sum_m \\psi_M(m)) (\\sum_{n \\in {\\bf Z}/d{\\bf Z}} c(n))", block: true, numbering: n => [#text("(14)")])



#tao-math(" & + O( (\\log^{O(1)} x) \\frac{M}{d} \\sum_{1 \\leq h \\leq x^\\epsilon d M^{-1}} \\left|\\sum_{n \\in {\\bf Z}/d{\\bf Z}} c(n) e_d( n h )\\right| )", block: true)



#tao-math(" & + O( x^{-A} \\sum_{n \\in {\\bf Z}/d{\\bf Z}} \\left|c(n)\\right| )", block: true)
]

#text("whenever ")#mi("{c: {\\bf Z} \\rightarrow {\\bf C}}")#text(" is periodic of degree ")#mi("{d}")#text(".")

#emph[#text("Proof:")]#text(" We rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{i \\in I} c_i \\sum_{m} \\psi_M(m) 1_{m=a_i\\ (d)}.")]]

#text("Using the Fourier expansion")

#align(center)[#tao-fit-display[#mitex("1_{m = a_i\\ (d)} = \\frac{1}{d} \\sum_{h \\in {\\bf Z}/d{\\bf Z}} e_d( a_i h) e_d(-m h)")]]

#text("and rearranging, the left-hand side then becomes")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{d} \\sum_{h \\in {\\bf Z}/d{\\bf Z}} [\\sum_m \\psi_M(m) e_d(-mh)] \\times [\\sum_{i \\in I} c_i e_d(a_i h)].")]]

#text("The ")#mi("{h=0}")#text(" term of this is the first term on the right-hand side of ")#link(<tao-eebbf6457e46a7f63acd>)[#text("(13)")]#text(". The terms coming from integers ")#mi("{h}")#text(" with ")#tao-math("{1 \\leq \\left|h\\right| \\leq x^\\epsilon d M^{-1}}", block: false)#text(" can be bounded by the second term in ")#link(<tao-eebbf6457e46a7f63acd>)[#text("(13)")]#text(", bounding ")#mi("{\\sum_m \\psi_M(m) e_d(mh)}")#text(" crudely by ")#mi("{O(M \\log^{O(1)} x)}")#text(" by crude estimates and also using conjugation symmetry when ")#mi("{h}")#text(" is negative. So it will suffice to show that")

#align(center)[#tao-fit-display[#mitex("\\sum_m \\psi_M(m) e_d(-mh) = O( x^{-A-2} )")]]

#text("(say) when ")#tao-math("{x^\\epsilon d M^{-1} \\leq \\left|h\\right| \\leq d/2}", block: false)#text(". Writing ")#mi("{\\psi_M(m) = \\psi(m/M)}")#text(" as in the definition of a smooth coefficient sequence, and applying Poisson summation, the left-hand side is")

#align(center)[#tao-fit-display[#mitex("M \\sum_n \\hat \\psi( M n + \\frac{Mh}{d} )")]]

#text("where ")#mi("{\\hat \\psi(t) := \\int_{\\bf R} e^{-2\\pi i st} \\psi(s)\\ ds}")#text(" is the Fourier transform of ")#mi("{\\psi}")#text(". But from the smoothness ")#link(<tao-ab1e6be2000a7c9c3d39>)[#text("(4)")]#text(" of ")#mi("{\\psi}")#text(" and integration by parts one has the bounds")

#align(center)[#tao-fit-display[#tao-math("\\hat \\psi(t) \\ll \\left|t\\right|^{-A^{\\prime}} \\log^{O(1)} x", block: true)]]

#text("for any fixed ")#mi("{A^{\\prime}}")#text(", and from the hypothesis ")#tao-math("{x^\\epsilon d M^{-1} \\leq \\left|h\\right| \\leq d/2}", block: false)#text(" we obtain the claim by taking ")#mi("{A^{\\prime}}")#text(" large enough depending on ")#mi("{\\epsilon,A}")#text(". ")#mi("\\Box")

#text("We remark that in the absence of cancellation in the exponential sum ")#mi("{\\sum_i c_i e_d(-a_i h)}")#text(", the first error term in ")#link(<tao-eebbf6457e46a7f63acd>)[#text("(13)")]#text(" could be as large as")

#align(center)[#tao-fit-display[#tao-math("O( x^{\\epsilon+o(1)} \\sum_i \\left|c_i\\right| )", block: true)]]

#text("which is about ")#mi("{x^{\\epsilon+o(1)} \\frac{d}{M}}")#text(" times as large as the main term in ")#link(<tao-eebbf6457e46a7f63acd>)[#text("(13)")]#text(". In practice we will apply this lemma with ")#mi("{d > x^c M}")#text(" for some fixed ")#mi("{c>0}")#text(", in which case completion of sums will cost a factor of ")#mi("{x^c}")#text(" or so in the bounds. However, it is still often desirable to pay this cost in order to exploit cancellation bounds for exponential sum, in particular those coming from the Weil conjectures as described below.")

#text("In our applications, the modulus ")#mi("{d}")#text(" will split into a product of two factors ")#mi("{q_1 q_2}")#text(" or three factors ")#mi("{q_1 q_2 q_3}")#text(". The following simple lemma lets us then split exponential phases of the form ")#mi("{e_d(-ah)}")#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 7")]#text(" ")#metadata(none) <tao-49002d515d1605d8e492>#text(" Suppose that ")#mi("{d=q_1 q_2}")#text(" for some coprime ")#mi("{q_1, q_2}")#text(", and let ")#mi("{a\\ (d)}")#text(" be the intersection of the congruence classes ")#mi("{b_1\\ (q_1)}")#text(" and ")#mi("{b_2\\ (q_2)}")#text(". Then for any integer ")#mi("{h}")#text(",")

#align(center)[#tao-fit-display[#mitex("e_d( a h ) = e_{q_1}( \\frac{b_1 h}{q_2} ) e_{q_2}( \\frac{b_2 h}{q_1} ).")]]

#text("Similarly, if ")#mi("{d=q_1q_2q_3}")#text(" for coprime ")#mi("{q_1,q_2,q_3}")#text(" and ")#mi("{a\\ (d)}")#text(" is the intersection of ")#mi("{b_1\\ (q_1)}")#text(", ")#mi("{b_2\\ (q_2)}")#text(", and ")#mi("{b_3\\ (q_3)}")#text(", then")

#align(center)[#tao-fit-display[#mitex("e_d( a h ) = e_{q_1}( \\frac{b_1 h}{q_2 q_3} ) e_{q_2}( \\frac{b_2 h}{q_1 q_3} ) e_{q_3}( \\frac{b_3 h}{q_1 q_2} ).")]]
]

#text("Here and in the sequel we are using the convention that ")#mi("{e_q( \\frac{a}{b} )}")#text(" means ")#mi("{e_q(a \\overline{b} )}")#text(" for ")#mi("{b}")#text(" coprime to ")#mi("{q}")#text(", where ")#mi("{\\overline{b}}")#text(" is the reciprocal of ")#mi("{b}")#text(" modulo ")#mi("{q}")#text(".")

#emph[#text("Proof:")]#text(" We just prove the first identity, as the second is similar. Let ")#mi("{\\bar{q_1}}")#text(" be an integer such that ")#mi("{q_1 \\bar{q_1} = 1 \\ (q_2)}")#text(", and similarly let ")#mi("{\\bar{q_2}}")#text(" be an integer such that ")#mi("{q_2 \\bar{q_2} = 1\\ (q_1)}")#text(". Then ")#mi("{b_1 q_2 \\bar{q_2} + b_2 q_1 \\bar{q_1}}")#text(" is equal to ")#mi("{b_1}")#text(" mod ")#mi("{q_1}")#text(" and ")#mi("{b_2}")#text(" mod ")#mi("{q_2}")#text(", and thus equal to ")#mi("{a}")#text(" mod ")#mi("{q_1 q_2}")#text(". Thus")

#align(center)[#tao-fit-display[#mitex("e_d( ah) = e_d( b_1 hq_2 \\bar{q_2} + b_2 h q_1 \\bar{q_1} )")]]

#text("and the claim follows by factoring the exponential. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 3. The Weil conjectures — ")]]

#text("For the purposes of this post, the ")#link("http://en.wikipedia.org/wiki/Weil_conjectures")[#text("Weil conjectures")]#text(" (as proven in full generality by Deligne) can be viewed as a black box device to obtain “square root cancellation” for various exponential sums of the form")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in G} \\xi( P(n) )")]]

#text("where ")#mi("{G}")#text(" is a finite abelian group (i.e. a finite product of cyclic groups) with some additive character ")#mi("{\\xi: H \\rightarrow S^1}")#text(" and some rational function ")#mi("{P: G \\rightarrow H}")#text(", basically by obtaining the analogue of the Riemann Hypothesis for a certain zeta function associated to an algebraic variety related to the function ")#mi("{P}")#text(". (This is by no means the full strength of the Weil conjectures; amongst other things, one can also twist such sums by multiplicative characters, and also work with more complicated schemes than classical algebraic varieties, though the exponential sum estimates are more difficult to state succinctly as a consequence.) A basic instance of this is Weil’s classical bound on the ")#link("http://en.wikipedia.org/wiki/Kloosterman_sum")[#text("Kloosterman sum")]

#metadata(none) <tao-a17b76f3e18937d6b3fb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(15)")])
#mitex("S(a,b;m) := \\sum_{n \\in ({\\bf Z}/m{\\bf Z})^\\times} e_m( an + \\frac{b}{n} ),")]]

#text("defined whenever ")#mi("{a,b,m}")#text(" are integers with ")#mi("{m}")#text(" positive.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Weil bound)")]#text(" ")#metadata(none) <tao-740fc4991133b1523bc4>#text(" For any ")#mi("{a,b,m}")#text(" one has")

#align(center)[#tao-fit-display[#tao-math("\\left|S(a,b;m)\\right| \\leq \\tau(m) (a,b,m)^{1/2} m^{1/2}", block: true)]]

#text("where ")#mi("{(a,b,m)}")#text(" is the greatest common divisor of ")#mi("{a,b,m}")#text(".")
]

#emph[#text("Proof:")]#text(" (Sketch only; see e.g. ")#link("http://www.ams.org/mathscinet-getitem?mr=2061214")[#text("Iwaniec-Kowalski")]#text(" for a full proof.) For simplicity we only address the case of square-free ")#mi("{m}")#text(", which is the case needed in our application. By the Chinese remainder theorem we may reduce to the case when ")#mi("{m}")#text(" is a prime ")#mi("{q}")#text(", then we may also reduce to the case when ")#mi("{a,b}")#text(" are coprime to ")#mi("{p}")#text(". It then suffices to show that ")#metadata(none) <tao-ad6b60c1ac2e3d95828b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(16)")])
#tao-math("\\left|\\sum_{(x,y) \\in C({\\bf F}_q)} \\psi(ax+by)\\right| \\leq 2 q^{1/2}", block: true)]]

#text("whenever ")#mi("{\\psi: {\\bf F}_q \\rightarrow S^1}")#text(" is an additive character and ")#mi("{C({\\bf F}_q)}")#text(" is the hyperbola")

#align(center)[#tao-fit-display[#mitex("C({\\bf F}_q) := \\{ (x,y) \\in {\\bf F}_q \\times {\\bf F}_q: xy = 1 \\}.")]]

#text("An important trick is then to generalise from ")#mi("{{\\bf F}_q}")#text(" to finite dimensional extensions ")#mi("{{\\bf F}_{q^n}}")#text(" of ")#mi("{{\\bf F}_q}")#text(", and then consider the Kloosterman sums")

#align(center)[#tao-fit-display[#mitex("S_n(\\psi) := \\sum_{(x,y) \\in C({\\bf F}_{q^n})} \\psi( \\text{Tr}(ax+by) )")]]

#text("associated to these extensions, where ")#mi("{\\text{Tr}: {\\bf F}_{q^n} \\rightarrow {\\bf F}_q}")#text(" is the ")#link("http://en.wikipedia.org/wiki/Field_trace")[#text("field trace")]#text(". For non-principal ")#mi("{\\psi}")#text(", it is possible to show the explicit formula ")#metadata(none) <tao-ebdb59143bdb3b4c2860>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(17)")])
#mitex("S_n(\\psi) = - \\alpha_\\psi^n - \\beta_\\psi^n")]]

#text("for some complex numbers ")#mi("{\\alpha_\\psi,\\beta_\\psi}")#text(" (depending of course on ")#mi("{a,b}")#text("); this is part of the general theory of ")#mi("{L}")#text("-functions associated to algebraic varieties, but can also be established by elementary means (e.g. by establishing a linear recurrence for the ")#mi("{S_n}")#text("). For the principal character ")#mi("{\\psi = \\psi_0}")#text(", of course, one has")

#align(center)[#tao-fit-display[#mitex("S_n(\\psi_0) = q^n - 1.")]]

#text("Next, one observes the basic identity")

#align(center)[#tao-fit-display[#tao-math("\\sum_\\psi \\psi(\\text{Tr}(x)) = \\left| \\{ z \\in {\\bf F}_{q^n}: z^q-z = x \\}\\right|", block: true)]]

#text("as can be seen by computing the kernel and range of the linear map ")#mi("{z \\mapsto z^q-z}")#text(" on ")#mi("{{\\bf F}_{q^n}}")#text(" (this identity is also related to ")#link("http://en.wikipedia.org/wiki/Hilbert's_Theorem_90")[#text("Hilbert’s Theorem 90")]#text("). From this we have a combinatorial interpretation of the quantity")

#align(center)[#tao-fit-display[#mitex("\\sum_\\psi S_n(\\psi),")]]

#text("namely as the number of points on the curve")

#align(center)[#tao-fit-display[#mitex("\\{ (x,y,z) \\in {\\bf F}_{q^n}^3: z^q-z = ax+by; xy=1 \\}.")]]

#text("One can show (e.g. using Stepanov’s method, cf. ")#link("https://terrytao.wordpress.com/2012/08/31/the-lang-weil-bound/")[#text("this previous post")]#text(") that the number of this points on this curve is equal to ")#mi("{q^n + O(q^{n/2+ O(1)})}")#text(", leading to the identity")

#align(center)[#tao-fit-display[#mitex("q^n - 1 - \\sum_{\\psi \\neq \\psi_0} (\\alpha_\\psi^n +\\beta_\\psi^n) = q^n + O(q^{n/2+ O(1)}).")]]

#text("Studying the asymptotics as ")#mi("{n \\rightarrow \\infty}")#text(", one is led to the conclusion that ")#tao-math("{\\left|\\alpha_\\psi\\right|, \\left|\\beta_\\psi\\right| \\leq \\sqrt{q}}", block: false)#text(" (this trick to “magically” delete the ")#mi("{O(q^{O(1)})}")#text(" error is a canonical example of the ")#link("https://terrytao.wordpress.com/2008/08/25/tricks-wiki-article-the-tensor-product-trick/")[#text("tensor power trick")]#text("), and the bound ")#link(<tao-ad6b60c1ac2e3d95828b>)[#text("(16)")]#text(" then follows from the ")#mi("{n=1}")#text(" case of ")#link(<tao-ebdb59143bdb3b4c2860>)[#text("(17)")]#text(". ")#mi("\\Box")

#text("In practice, we shall estimate ")#mi("{\\tau(m)}")#text(" crudely by the divisor bound ")#mi("{\\tau(m) = m^{o(1)}}")#text(" (where ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{m \\rightarrow \\infty}")#text("), and the factor ")#mi("{(a,b,m)}")#text(" will also be small in applications, so that we do indeed see the square root savings over the trivial bound ")#tao-math("{\\left|S(a,b,m)\\right| \\leq m}", block: false)#text(". For the Type I/II sums, the classical Weil bound is sufficient; but for the Type III sums that we will cover in a subsequent post, the full force of Deligne’s results are needed.")

#text("An important remark is that when ")#mi("{a=0}")#text(", we can apply the change of variables ")#mi("{n \\mapsto 1/n}")#text(" and convert the Kloosterman sum ")#mi("{S(0,b;m)}")#text(" into a ")#link("http://en.wikipedia.org/wiki/Ramanujan's_sum")[#text("Ramanujan sum")]

#align(center)[#tao-fit-display[#mitex("S(0,b,m) = \\sum_{n \\in ({\\bf Z}/m{\\bf Z})^\\times} e_m(bn)")]]

#text("which enjoys even better cancellation than square root cancellation; in particular it is not difficult to establish the bound ")#metadata(none) <tao-36cdb3872416d77c9fd4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(18)")])
#tao-math("\\left|S(0,b,m)\\right| \\ll m^{o(1)} (b,m)", block: true)]]

#text("using the Chinese remainder theorem to reduce to the case when ")#mi("{m}")#text(" is a power of a prime, and then using the divisor bound.")

#text("For the Type I and Type II sums we need a more complicated variant of this bound (Lemma 11 of ")#link("http://annals.math.princeton.edu/wp-content/uploads/YitangZhang.pdf")[#text("Zhang’s paper")]#text("):")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 9")]#text(" ")#metadata(none) <tao-efbaa8cbfffc1af3afcf>#text(" Let ")#mi("{d_1,d_2}")#text(" be square-free natural numbers, let")

#align(center)[#tao-fit-display[#mitex("d := [d_1,d_2]; \\quad d_0 := (d_1,d_2); \\quad t_1 := d_1/d_0, \\quad t_2 := d_2/d_0,")]]

#text("and let ")#mi("{c_1, c_2, l, m}")#text(" be integers. Then the double Kloosterman sum")

#align(center)[#tao-fit-display[#mitex("K(d_1,c_1; d_2,c_2; l,m) := \\sum_{n \\in {\\bf Z}/d{\\bf Z}: (n,d_1) = (n+l,d_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ) e_d( mn )")]]

#text("obeys the bound")

#align(center)[#tao-fit-display[#tao-math("\\left|K(d_1,c_1; d_2,c_2; l,m)\\right| \\leq d_0 \\left|S(m_1,b_1; t_1)\\right| \\left|S(m_2,b_2; t_2)\\right|", block: true)]]

#text("for some ")#mi("{m_1,m_2,b_1,b_2}")#text(" with")

#align(center)[#tao-fit-display[#mitex("(m_i,b_i,t_i) | (m,c_i,d_i)")]]

#text("for ")#mi("{i=1,2}")#text(". In particular, from Theorem ")#link(<tao-740fc4991133b1523bc4>)[#text("8")]#text(", we have")

#align(center)[#tao-fit-display[#tao-math("\\left|K(d_1,c_1; d_2,c_2; l,m)\\right| \\ll (d_1 d_2)^{o(1)}", block: true)]]

#align(center)[#tao-fit-display[#mitex("(m,c_1,d_1)^{1/2} (m,c_2,d_2)^{1/2} d_1^{1/2} d_2^{1/2}")]]

#text("while in the ")#mi("{m=0}")#text(" case we have from ")#link(<tao-36cdb3872416d77c9fd4>)[#text("(18)")]#text(" that")

#align(center)[#tao-fit-display[#tao-math("\\left|K(d_1,c_1; d_2,c_2; l,0)\\right| \\ll (d_1 d_2)^{o(1)} d_0 (c_1,d_1) (c_2,d_2).", block: true)]]

#text("Here ")#mi("{o(1)}")#text(" denotes a quantity that goes to zero as ")#mi("{d_1,d_2 \\rightarrow \\infty}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{d_0,t_1,t_2}")#text(" are coprime, we may refactor ")#mi("{e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ) e_d( mn )}")#text(" as")

#align(center)[#tao-fit-display[#mitex("e_{d_0}( \\frac{a_1}{n} + \\frac{a_2}{n+l} + m_0 n ) e_{t_1}( \\frac{b_1}{n} + m_1 n ) e_{t_2}( \\frac{b_2}{n+l} + m_2 n )")]]

#text("for some ")#mi("{a_1,a_2,m_0 \\in {\\bf Z}/d_0{\\bf Z}}")#text(", ")#mi("{b_1,m_1 \\in {\\bf Z}/t_1{\\bf Z}}")#text(" and ")#mi("{b_2,m_2 \\in {\\bf Z}/t_2{\\bf Z}}")#text(", with")

#align(center)[#tao-fit-display[#mitex("m = m_0 t_1 t_2 + m_1 d_0 t_2 + m_2 d_0 t_1\\ (d_0 t_1 t_2)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("c_i = a_i t_i + b_i d_0\\ (d_i)")]]

#text("for ")#mi("{i=1,2}")#text(", which in particular implies that ")#mi("{(m_i,b_i,t_i) | (m,c_i,d_i)}")#text(" as claimed. Using the Chinese remainder theorem, we may now factor ")#mi("{K(d_1,c_1; d_2,c_2; l,m)}")#text(" as the product of the sums")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/d_0{\\bf Z}: (n,d_0)=(n+l,d_0)=1} e_{d_0}( \\frac{a_1}{n} + \\frac{a_2}{n+l} + m_0 n ),")]]

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/t_1{\\bf Z}: (n,t_1) = 1} e_{t_1}( \\frac{b_1}{n} + m_1 n )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\sum_{n \\in {\\bf Z}/t_2{\\bf Z}: (n+l,t_2) = 1} e_{t_2}( \\frac{b_2}{n+l} + m_2 n ).")]]

#text("Bounding the first sum trivially by ")#mi("{d_0}")#text(" and shifting the third sum by ")#mi("{l}")#text(" we obtain the claim (note that ")#mi("{d_0 t_1^{1/2} t_2^{1/2} = d_1^{1/2} d_2^{1/2}}")#text(").")

#text("The treatment of the ")#mi("{d_0}")#text(" terms in the above analysis are crude, but in applications ")#mi("{d_0}")#text(" is often trivial anyway, so it is not essential to obtain the sharpest estimates here.")

#text("We can combine this with the method of completion of sums:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 10")]#text(" ")#metadata(none) <tao-f562267f2b6d890a7c0c>#text(" Let ")#mi("{d_1,d_2}")#text(" be square-free natural numbers with ")#mi("{d_1,d_2 \\ll x}")#text(", let ")#mi("{c_1,c_2,l}")#text(" be integers, and let ")#mi("{\\psi_N}")#text(" be a smooth coefficient sequence at a scale ")#mi("{1 \\ll N \\ll x}")#text(". Then")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{(n,d_1)=(n+l,d_2)=1} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ) \\psi_N(n) \\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} ( (d_1 d_2)^{1/2} + \\frac{N (d_1,d_2)^2}{d_1 d_2} (c_1,d_1) (c_2,d_2) ).")]]
]

#emph[#text("Proof:")]#text(" Write ")#mi("{d := [d_1,d_2]}")#text(". By ")#link(<tao-5a84a5711663cb5203e5>)[#text("(14)")]#text(" (and overspill) we may bound the left-hand side by")

#tao-aligned(keep: true)[


#tao-math(" & \\ll \\frac{1}{d} (\\sum_m \\psi_N(m)) (\\sum_{n \\in {\\bf Z}/d{\\bf Z}} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ) )", block: true)



#tao-math(" & + x^{o(1)} \\frac{N}{d} \\sum_{1 \\leq m \\leq x^{o(1)} d N^{-1}} \\left|\\sum_{n \\in {\\bf Z}/d{\\bf Z}} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ) e_d(mn)\\right|", block: true)



#tao-math(" & + x^{-A} d,", block: true)
]

#text("where we suppress the conditions ")#mi("{(n,d_1)=(n+l,d_2)}")#text(" from the ")#mi("{n}")#text(" summation for brevity. The first term is ")#mi("{O( x^{o(1)} \\frac{N}{d} (d_1,d_2) (c_1,d_1) (c_2,d_2))}")#text(" by Lemma ")#link(<tao-efbaa8cbfffc1af3afcf>)[#text("9")]#text(", which is acceptable. Another application of Lemma ")#link(<tao-efbaa8cbfffc1af3afcf>)[#text("9")]#text(" gives")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n \\in {\\bf Z}/d{\\bf Z}} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} ) e_d(mn)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} (m,c_1,d_1)^{1/2} (m,c_2,d_2)^{1/2} d_1^{1/2} d_2^{1/2}.")]]

#text("From the divisor bound one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{1 \\leq m \\leq M} (m,q) \\ll q^{o(1)} M")]]

#text("for any ")#mi("{M,q \\geq 1}")#text(", so from this and Cauchy-Schwarz the net contribution of the second term is")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} \\frac{N}{d} (x^{o(1)} d N^{-1}) d_1^{1/2} d_2^{1/2}")]]

#text("which is acceptable. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 4. Factoring a smooth number — ")]]

#text("We will need to take advantage of the smooth nature of the variable ")#mi("{q}")#text(" to factor it into two smaller pieces. We need an elementary lemma:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 11")]#text(" ")#metadata(none) <tao-0c030586945fe504b604>#text(" Let ")#mi("{D}")#text(" be a quantity of size ")#mi("{1 \\ll D \\ll x}")#text(", and set")

#align(center)[#tao-fit-display[#mitex("D_0 := \\exp( \\log^{1/3} x )")]]

#text("(say). Let ")#mi("{A > 0}")#text(" be fixed. Then, for all but ")#mi("{O(D \\log^{-A} x)}")#text(" exceptions, all integers ")#mi("{d \\in [D,2D]}")#text(" have the property that ")#metadata(none) <tao-a51146d38077ff992eba>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(19)")])
#mitex("\\prod_{p|d: p \\leq D_0} p \\leq \\exp( \\log^{2/3} x );")]]

#text("in particular,")

#align(center)[#tao-fit-display[#mitex("\\prod_{p|d: p \\leq D_0} p = x^{o(1)}.")]]
]

#emph[#text("Proof:")]#text(" Suppose that ")#link(<tao-a51146d38077ff992eba>)[#text("(19)")]#text(" failed, thus")

#align(center)[#tao-fit-display[#mitex("\\prod_{p|d: p \\leq D_0} p > \\exp( \\log^{2/3} x ) = D_0^{\\log^{1/3} x}.")]]

#text("In particular, we see that ")#mi("{d}")#text(" has at least ")#mi("{\\log^{1/3} x}")#text(" prime factors, which implies in particular that")

#align(center)[#tao-fit-display[#mitex("\\tau(d) \\geq 2^{\\log^{1/3} x}.")]]

#text("On the other hand, we have the standard bound")

#align(center)[#tao-fit-display[#mitex("\\sum_{D \\leq d \\leq 2D} \\tau(d) \\ll D \\log x")]]

#text("and the claim now follows from Markov’s inequality. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 12 (Good factorisation)")]#text(" ")#metadata(none) <tao-770e607624d689265ca6>#text(" Let ")#mi("{I = [1,x^\\delta]}")#text(", and let ")#mi("{R, D}")#text(" be quantities such that")

#align(center)[#tao-fit-display[#mitex("1 \\ll R \\ll D \\ll x.")]]

#text("Let ")#mi("{A>0}")#text(" be fixed. Then for all but ")#mi("{O(D\\log^{-A} x)}")#text(" exceptions, all ")#mi("{d \\in {\\mathcal S}_I \\cap [D,2D]}")#text(" have a factorisation")

#align(center)[#tao-fit-display[#mitex("d = qr")]]

#text("where ")#mi("{q,r \\in {\\mathcal S}_I}")#text(" are coprime with")

#align(center)[#tao-fit-display[#mitex("x^{-o(1)} R \\ll r \\ll x^{\\delta-o(1)} R.")]]

#text("Furthermore ")#mi("{q}")#text(" has no prime factors less than ")#mi("{D_0 := \\exp(\\log^{1/3} x)}")#text(", thus")

#align(center)[#tao-fit-display[#mitex("q \\in {\\mathcal S}_{I^{\\prime}}")]]

#text("where ")#mi("{I^{\\prime} := [D_0,x^\\delta]}")#text(".")
]

#text("The fact that ")#mi("{q}")#text(" has no tiny (i.e. less than ")#mi("{D_0}")#text(") prime factors will imply that any two such ")#mi("{q}")#text(" will typically be coprime to each other with high probability (at least ")#mi("{1-O(\\log^{-A} x)}")#text(" for any fixed ")#mi("{A}")#text("), which is a key technical fact which we will need to exploit later. (The ")#mi("{W}")#text("-trick achieves a qualitatively similar effect, but would only give such a claim with probability ")#mi("{1-o(1)}")#text(" or maybe ")#mi("{1-O(\\log^{-c} x)}")#text(" for some small ")#mi("{c>0}")#text(" if one really optimised it, which is insufficient for the applications at hand.)")

#emph[#text("Proof:")]#text(" By Lemma ")#link(<tao-0c030586945fe504b604>)[#text("11")]#text(" we may restrict attention to those ")#mi("{d \\in {\\mathcal S}_I \\cap [D,2D]}")#text(" for which")

#align(center)[#tao-fit-display[#mitex("\\prod_{p|d: p \\leq D_0} p = x^{o(1)}.")]]

#text("Now ")#mi("{d}")#text(" is the product of distinct primes of size at most ")#mi("{x^\\delta}")#text(", with ")#mi("{d \\gg R}")#text(". Applying the greedy algorithm, one can then find a factor ")#mi("{r^{\\prime}}")#text(" of ")#mi("{d}")#text(" with")

#align(center)[#tao-fit-display[#mitex("R \\ll r^{\\prime} \\ll x^{\\delta} R.")]]

#text("If one then multiplies ")#mi("{r^{\\prime}}")#text(" by all primes of size less than ")#mi("{D_0}")#text(" that divide ")#mi("{d/r^{\\prime}}")#text(" to create ")#mi("{r^{\\prime}}")#text(", then sets ")#mi("{q := d/r^{\\prime}}")#text(", the claim follows. ")#mi("\\Box")

#heading(level: 1)[#strong[#text(" — 5. The dispersion method — ")]]

#text("We begin the proof of Theorem ")#link(<tao-840c81157f3688e42875>)[#text("3")]#text(". The reader may wish to track the exponents involved in the model regime ")#metadata(none) <tao-9372c470eeadd5ecd9c3>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(20)")])
#mitex("\\varpi, \\delta \\approx 0; \\quad 0 < \\sigma < 1/8; \\quad M \\approx x^{1/2+\\sigma}; \\quad N \\approx x^{1/2-\\sigma}.")]]

#text("We can restrict ")#mi("{q}")#text(" to the range")

#align(center)[#tao-fit-display[#mitex("q \\geq x^{1/2-o(1)}")]]

#text("for some sufficiently slowly decaying ")#mi("{o(1)}")#text(", since otherwise we may use the Bombieri-Vinogradov theorem (Theorem ")#link(<tao-c5c8fcbf6d9460bd16fa>)[#text("4")]#text("). Thus we need to show that ")#metadata(none) <tao-4b3d4a0dd732f791ca89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(21)")])
#tao-math("\\sum_{q \\in {\\mathcal S}_I: x^{1/2-o(1)} \\leq q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\beta; a_q)\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("Let ")#metadata(none) <tao-352b5b6699d83cdc4efd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(22)")])
#mitex("\\mu > 0")]]

#text("be an exponent to be optimised later (in many cases, such as ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(20)")]#text(", it can be set very close to zero). By Corollary ")#link(<tao-770e607624d689265ca6>)[#text("12")]#text(", outside of a small number of exceptions, we may factor ")#mi("{q=q^{\\prime}r}")#text(" where ")#mi("{q^{\\prime} \\in {\\mathcal S}_{I^{\\prime}}}")#text(" with ")#mi("{I^{\\prime} := I \\cap [D_0,x^\\delta]}")#text(", ")#mi("{r \\in {\\mathcal S}_I}")#text(" is coprime to ")#mi("{q^{\\prime}}")#text(", and")

#align(center)[#tao-fit-display[#mitex("x^{-\\mu-\\delta-o(1)} N \\ll r \\ll x^{-\\mu+o(1)} N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{1/2-o(1)} \\ll q^{\\prime}r \\ll x^{1/2+2\\varpi+o(1)}.")]]

#text("Let us first dispose of the set ")#mi("{{\\mathcal E}}")#text(" of exceptional values of ")#mi("{q}")#text(" for which the above factorisation is unavailable. From Corollary ")#link(<tao-770e607624d689265ca6>)[#text("12")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal E}: x^{1/2-o(1)} \\leq q< x^{1/2+2\\varpi}} \\frac{x}{q} \\ll x \\log^{-A+O(1)} x.")]]

#text("On the other hand, we have the crude estimate")

#align(center)[#tao-fit-display[#tao-math("\\left|\\Delta(\\alpha \\ast \\beta; a_q)\\right| \\ll \\frac{x}{q} \\tau(q)^{O(1)} \\log^{O(1)} x", block: true)]]

#text("which when combined with crude estimates leads to the crude upper bound")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q: x^{1/2-o(1)} \\leq q< x^{1/2+2\\varpi}} \\frac{q}{x} \\left|\\Delta(\\alpha \\ast \\beta; a_q)\\right|^2 \\ll x \\log^{O(1)} x.", block: true)]]

#text("Applying Cauchy-Schwarz we conclude that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q \\in {\\mathcal S}_I \\cap {\\mathcal E}: x^{1/2-o(1)} \\leq q< x^{1/2+2\\varpi}} \\left|\\Delta(\\alpha \\ast \\beta; a_q)\\right| \\ll x \\log^{-A/2+O(1)} x.", block: true)]]

#text("and so ")#mi("{{\\mathcal E}}")#text(" gives a negligible contribution to ")#link(<tao-4b3d4a0dd732f791ca89>)[#text("(21)")]#text(" (increasing ")#mi("{A}")#text(" as necessary).")

#text("For the non-exceptional ")#mi("{q \\not \\in {\\mathcal E}}")#text(", we arbitrarily select a factorisation ")#mi("{q = q^{\\prime}r}")#text(" of the above form, and apply a dyadic decomposition. We conclude that it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q^{\\prime} \\in {\\mathcal S}_{I^{\\prime}}: Q \\ll q^{\\prime} \\ll Q} \\sum_{r \\in {\\mathcal S}_I: R \\ll r \\ll R; (q,r)=1} \\left|\\Delta(\\alpha \\ast \\beta; a_{q^{\\prime}r})\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("for any fixed ")#mi("{A > 0}")#text(", where ")#mi("{Q, R \\geq 1}")#text(" obey the size conditions ")#metadata(none) <tao-375676bd26868505668f>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(23)")])
#mitex("x^{-\\mu-\\delta-o(1)} N \\ll R \\ll x^{-\\mu+o(1)} N")]]

#text("and ")#metadata(none) <tao-2617708489831f17c7b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(24)")])
#mitex("x^{1/2-o(1)} \\ll QR \\ll x^{1/2 + 2\\varpi}.")]]

#text("Fix ")#mi("{Q,R}")#text(". We replace ")#mi("{q^{\\prime}}")#text(" by ")#mi("{q}")#text(", and abbreviate ")#mi("{\\sum_{q \\in {\\mathcal S}_{I^{\\prime}}: Q \\ll q \\ll Q}}")#text(" and ")#mi("{\\sum_{r \\in {\\mathcal S}_I: R \\ll r \\ll R}}")#text(" by ")#mi("{\\sum_q}")#text(" and ")#mi("{\\sum_r}")#text(" respectively, thus our task is to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_q \\sum_{r: (q,r)=1} \\left|\\Delta(\\alpha \\ast \\beta; a_{qr})\\right| \\ll NM \\log^{-A} x.", block: true)]]

#text("We now split the discrepancy")

#align(center)[#tao-fit-display[#mitex("\\Delta(\\alpha \\ast \\beta; a_{qr}) = \\sum_{n = a_{qr}\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)")]]

#text("as the sum of the subdiscrepancies")

#align(center)[#tao-fit-display[#mitex("\\sum_{n: n = a_{qr}\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n).")]]

#text("Of the two, the first discrepancy is significantly more difficult to handle. By the triangle inequality, it will suffice to show that ")#metadata(none) <tao-c75de8c1b7c3ae525209>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(25)")])
#tao-math("\\sum_{q} \\sum_{r; (q,r)=1} \\left|\\sum_{n: n = a_{qr}\\ (qr)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM \\log^{-A} x")]]

#text("and ")#metadata(none) <tao-bee98bf120e890638275>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(26)")])
#tao-math("\\sum_{q} \\sum_{r; (q,r)=1} \\left|\\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(qr)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)\\right| \\ll", block: true)]]

#align(center)[#tao-fit-display[#mitex("NM \\log^{-A} x.")]]

#text("We begin with ")#link(<tao-bee98bf120e890638275>)[#text("(26)")]#text(", which is easier. For each fixed ")#mi("{q}")#text(", it will suffice to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{r; (q,r)=1} \\left|\\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(r)} \\sum_{n: (n,qr)=1} \\alpha \\ast \\beta(n)\\right| \\ll NM \\log^{-A} x,", block: true)]]

#text("as the claim then follows by dividing by ")#mi("{\\phi(q)}")#text(" and summing using standard estimates (see Lemma 8 of ")#link("https://terrytao.wordpress.com/2013/06/08/the-elementary-selberg-sieve-and-bounded-prime-gaps")[#text("this previous post")]#text("). But this claim follows from the Bombieri-Vinogradov theorem (Theorem ")#link(<tao-c5c8fcbf6d9460bd16fa>)[#text("4")]#text("), after restricting ")#mi("{\\alpha,\\beta}")#text(" to the integers coprime to ")#mi("{q}")#text(" (which does not affect the property of being a coefficient sequence supported at a certain scale, nor does it affect the Siegel-Walfisz theorem).")

#text("Now we establish ")#link(<tao-c75de8c1b7c3ae525209>)[#text("(25)")]#text(". Here we will not take advantage of the ")#mi("{r}")#text(" summation, and use crude estimates to reduce to showing that ")#metadata(none) <tao-e9fa0453869469e08db9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(27)")])
#tao-math("\\sum_{q; (q,r)=1} \\left|\\sum_{n: n = a_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for each individual ")#mi("{r \\in {\\mathcal S}_I}")#text(" with ")#mi("{R \\ll r \\ll R}")#text(", which we now fix. Actually, we will prove the more general statement ")#metadata(none) <tao-73cce42f1f0e9099688b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(28)")])
#tao-math("\\sum_{q; (q,r)=1} \\left|\\sum_{n: n = b_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\sum_{n: n = b^{\\prime}_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("whenever ")#mi("{(b_q)_{q \\in {\\mathcal S}_{I^{\\prime}}}, (b^{\\prime}_q)_{q \\in {\\mathcal S}_{I^{\\prime}}}}")#text(" are good singleton congruence class systems. Let us see how ")#link(<tao-73cce42f1f0e9099688b>)[#text("(28)")]#text(" implies ")#link(<tao-e9fa0453869469e08db9>)[#text("(27)")]#text(". Observe that if ")#mi("{t = o(x)}")#text(" is any integer, then ")#mi("{(\\{a_q\\})_{q \\in {\\mathcal S}_{I^{\\prime}_t}}}")#text(" and ")#mi("{(\\{a_q+t\\})_{q \\in {\\mathcal S}_{I^{\\prime}_t}}}")#text(" are also good singleton congruence class systems, where ")#mi("{I^{\\prime}_t}")#text(" consists of the primes ")#mi("{p \\in I^{\\prime}}")#text(" with ")#mi("{a_p+t}")#text(" not divisible by ")#mi("{p}")#text(" (thus ")#mi("{q \\in {\\mathcal S}_{I^{\\prime}}}")#text(" lies in ")#mi("{{\\mathcal S}_{I^{\\prime}_t}}")#text(" when ")#mi("{a_q+t}")#text(" is coprime to ")#mi("{q}")#text("). By ")#link(<tao-73cce42f1f0e9099688b>)[#text("(28)")]#text(" we thus have")

#align(center)[#tao-fit-display[#mitex("\\sum_{q; (q,r)=1} 1_{(a_q+t,q)=1} |\\sum_{n: n = a_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n)")]]

#align(center)[#tao-fit-display[#mitex("- \\sum_{n: n = a_q + t\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n)|")]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x.")]]

#text("If we average ")#mi("{t}")#text(" over the interval ")#mi("{T := {\\bf Z} \\cap [-x^{1-\\epsilon},x^{1-\\epsilon}]}")#text(" for some sufficiently small fixed ")#mi("{\\epsilon>0}")#text(", we observe that")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|T\\right|} \\sum_{t \\in T} 1_{(a_q+t,q)=1} = \\frac{\\phi(q)}{q} + O( Q \\left|T\\right|^{-1} )", block: true)]]

#text("and similarly (using the crude ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(")")

#align(center)[#tao-fit-display[#tao-math("\\frac{1}{\\left|T\\right|} \\sum_{t \\in T} 1_{(a_q+t,q)=1} \\sum_{n: (n,q)=1; n = a_q + t\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n)", block: true)]]

#align(center)[#tao-fit-display[#tao-math("= \\frac{1}{q} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n) + O( NM \\left|T\\right|^{-1} x^{o(1)} ).", block: true)]]

#text("(The condition ")#mi("{(n,q)=1}")#text(" is redundant, but we include it for emphasis.) We conclude from the triangle inequality and the bounds on ")#mi("{Q,R}")#text(" (if ")#mi("{\\epsilon}")#text(" is small enough) that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q; (q,r)=1} \\frac{\\phi(q)}{q} \\left|\\sum_{n: n = a_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x.")]]

#text("On the other hand, from crude estimates one has")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q; (q,r)=1} \\frac{q}{\\phi(q)} \\left|\\sum_{n: n = a_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\frac{1}{\\phi(q)} \\sum_{n: (n,q)=1; n = a_r\\ (r)} \\alpha \\ast \\beta(n)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\log^{O(1)} x")]]

#text("and the claim ")#link(<tao-e9fa0453869469e08db9>)[#text("(27)")]#text(" then follows from Cauchy-Schwarz (noting from the Chinese remainder theorem that the two constraints ")#mi("{n = a_q\\ (q), n = a_r\\ (r)}")#text(" are equivalent to the single constraint ")#mi("{n = a_{qr}\\ (qr)}")#text(").")

#text("It remains to prove ")#link(<tao-73cce42f1f0e9099688b>)[#text("(28)")]#text(". We will use the dispersion method (or Cauchy-Schwarz), playing the two congruence conditions ")#mi("{n = b_q\\ (q)}")#text(" and ")#mi("{n = b^{\\prime}_q\\ (q)}")#text(" against each other. We first get rid of the absolute values in ")#link(<tao-73cce42f1f0e9099688b>)[#text("(28)")]#text(" by introducing an additional bounded coefficient. More precisely, to prove ")#link(<tao-73cce42f1f0e9099688b>)[#text("(28)")]#text(" it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{q; (q,r)=1} c_q (\\sum_{n: n = b_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n) - \\sum_{n: n = b^{\\prime}_q\\ (q); n = a_r\\ (r)} \\alpha \\ast \\beta(n))\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll NM R^{-1} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for any bounded real coefficients ")#mi("{c_q = O(1)}")#text(". We expand out the Dirichlet convolution")

#align(center)[#tao-fit-display[#mitex("\\alpha \\ast \\beta(n) = \\sum_{m,n^{\\prime}: mn^{\\prime} = n} \\alpha(m) \\beta(n^{\\prime})")]]

#text("then relabel ")#mi("{n^{\\prime}}")#text(" as ")#mi("{n}")#text(" to rearrange the left-hand side as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{m} \\alpha(m) \\sum_{q,n: mn = a_r\\ (r); (q,r)=1} c_{q} \\beta(n) (1_{mn = b_{q}\\ (q)} - 1_{mn = b^{\\prime}_{q}\\ (q)})\\right|.", block: true)]]

#text("We can write ")#mi("{\\alpha = \\alpha \\psi_M}")#text(" for some smooth non-negative coefficient sequence ")#mi("{\\psi_M}")#text(" at scale ")#mi("{M}")#text(". From crude bounds one has")

#align(center)[#tao-fit-display[#mitex("\\sum_{m} \\alpha^2(m) \\psi_M(m)\\ll M \\log^{O(1)} x")]]

#text("so by the Cauchy-Schwarz inequality it suffices to show that ")#metadata(none) <tao-8dd42f9fc74cd334c8dc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(29)")])
#tao-math("\\sum_{m} \\psi_M(m) \\left|\\sum_{q,n: mn = a_r\\ (r); (q,r)=1} c_{q} \\beta(n) (1_{mn = b_{q}\\ (q)} - 1_{mn = b^{\\prime}_{q}\\ (q)})\\right|^2", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll N^2 M R^{-2} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("for any fixed ")#mi("{A>0}")#text(". (As a sanity check, note that we are still only asking for a ")#mi("{\\log^{-A} x}")#text(" savings over the trivial bound.) Expanding out the square, it suffices to show that ")#metadata(none) <tao-70848ccfe56d24288a89>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(30)")])
#mitex("\\sum_{m} \\psi_M(m) \\sum_{q_1,q_2,n_1,n_2: mn_1=mn_2 = a_r\\ (r); (q_1,r)=(q_2,r)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n_1) \\beta(n_2) 1_{mn_1 = b_{q_1}\\ (q_1)} 1_{mn_2 = b^{\\prime}_{q_2}\\ (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-2} \\tau(r)^{O(1)} \\log^{-A} x )")]]

#text("where ")#mi("{q_1,q_2}")#text(" is subject to the same constraints as ")#mi("{q}")#text(" (thus ")#mi("{q_i \\in {\\mathcal S}_{I^{\\prime}}}")#text(" and ")#mi("{Q \\ll q_i \\ll Q}")#text(" for ")#mi("{i=1,2}")#text("), and ")#mi("{X}")#text(" is some quantity that is independent of the choice of congruence classes ")#mi("{(b_q)_{q \\in {\\mathcal S}_I}}")#text(", ")#mi("{(b^{\\prime}_q)_{q \\in {\\mathcal S}_I}}")#text(", since by replacing the ")#mi("{b_q}")#text(" with ")#mi("{b^{\\prime}_q}")#text(" or vice versa as necessary one can express ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("(29)")]#text(" as a linear combination ")#mi("{S_1-2S_2+S_3}")#text(" of terms ")#mi("{S_1,S_2,S_3}")#text(" of the form in ")#link(<tao-8dd42f9fc74cd334c8dc>)[#text("(29)")]#text(" in such a way that all the ")#mi("{X}")#text(" terms cancel out (")#mi("{X - 2X + X = 0}")#text(").")

#text("At this stage we need to deal with a technical problem that ")#mi("{q_1,q_2}")#text(" may share a common factor; fortunately, this event turns out to be negligible (but only thanks to the controlled multiplicity hypothesis ")#link(<tao-cbf38e496835a79fe9ba>)[#text("(6)")]#text("). More precisely, we split ")#link(<tao-70848ccfe56d24288a89>)[#text("(30)")]#text(" into the coprime case ")#metadata(none) <tao-c7d459bba7d890eb2690>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(31)")])
#mitex("\\sum_{m} \\psi_M(m) \\sum_{q_1,q_2,n_1,n_2: mn_1=mn_2 = a_r\\ (r); (q_1,r)=(q_2,r)=(q_1,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n_1) \\beta(n_2) 1_{mn_1 = b_{q_1}\\ (q_1)} 1_{mn_2 = b^{\\prime}_{q_2}\\ (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X + O( N^2 M R^{-2} \\log^{-A} x )")]]

#text("and the non-coprime case ")#metadata(none) <tao-1190a99d5fd01be099bc>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(32)")])
#mitex("|\\sum_{q_0>1} \\sum_{m} \\psi_M(m) \\sum_{q_1,q_2,n_1,n_2: mn_1=mn_2 = a_r\\ (r); (q_1,r)=(q_2,r)=1; (q_1,q_2)=q_0}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n_1) \\beta(n_2) 1_{mn_1 = b_{q_1}\\ (q_1)} 1_{mn_2 = b^{\\prime}_{q_2}\\ (q_2)}|")]]

#align(center)[#tao-fit-display[#mitex("\\ll N^2 M R^{-2} \\tau(r)^{O(1)} \\log^{-A} x")]]

#text("We first show ")#link(<tao-1190a99d5fd01be099bc>)[#text("(32)")]#text(". The basic point here is that because we have previously restricted ")#mi("{q_1,q_2}")#text(" to have no prime factor smaller than ")#mi("{D_0}")#text(", we can gain a factor of ")#mi("{D_0^{-1}}")#text(" in ")#link(<tao-1190a99d5fd01be099bc>)[#text("(32)")]#text(", which is strong enough to overcome logarithmic losses ")#mi("{\\log^{O(1)} x}")#text(" but not losses ")#mi("{x^{o(1)}}")#text(" coming from the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(". To avoid using the divisor bound we will need the controlled multiplicity hypothesis ")#link(<tao-cbf38e496835a79fe9ba>)[#text("(6)")]#text(" (and this is the only place in the argument where this hypothesis is actually used).")

#text("We turn to the details. The quantities ")#mi("{q_0,q_1,q_2}")#text(" must all lie in ")#mi("{{\\mathcal S}_{I^{\\prime}}}")#text(". We may split ")#mi("{q_1 = q_0 q^{\\prime}_1}")#text(" and ")#mi("{q_2 = q_0 q^{\\prime}_2}")#text(" where ")#mi("{q^{\\prime}_1,q^{\\prime}_2}")#text(" are coprime. By the Chinese remainder theorem, the constraints ")#mi("{mn_1 = b_{q_1}\\ (q_1)}")#text(" and ")#mi("{mn_2 = b^{\\prime}_{q_2}\\ (q_2)}")#text(" then imply that")

#align(center)[#tao-fit-display[#mitex("mn_1 = b_{q_0}\\ (q_0); \\quad mn_2 = b^{\\prime}_{q_0}\\ (q_0); \\quad mn_1 = b_{q^{\\prime}_1}\\ (q^{\\prime}_1); \\quad mn_2 = b^{\\prime}_{q^{\\prime}_2}\\ (q^{\\prime}_2)")]]

#text("so by the triangle inequality and interchange of summation we can bound the left-hand side by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{q_0>1} \\sum_{m} \\psi_M(m) \\sum_{n_1,n_2: mn_1=mn_2 =a_r\\ (r); mn_1 = b_{q_0}\\ (q_0); mn_2 = b^{\\prime}_{q_0}\\ (q_0)}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta(n_1)\\right| |\\beta(n_2)| \\sum_{q^{\\prime}_1,q^{\\prime}_2} 1_{mn_1 = b_{q^{\\prime}_1}\\ (q^{\\prime}_1); mn_2 = b^{\\prime}_{q^{\\prime}_2}\\ (q^{\\prime}_2)}", block: true)]]

#text("(with ")#mi("{q_0}")#text(" understood to lie in ")#mi("{{\\mathcal S}_{I^{\\prime}}}")#text(" and be at most ")#mi("{Q}")#text(") which we can write as")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{q_0>1} \\sum_{m} \\psi_M(m) \\sum_{n_1,n_2: mn_1=mn_2 =a_r\\ (r); mn_1 = b_{q_0}\\ (q_0); mn_2 = b^{\\prime}_{q_0}\\ (q_0)}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta(n_1)\\right| |\\beta(n_2)| \\tau_b(mn_1) \\tau_{b^{\\prime}}(mn_2)", block: true)]]

#text("where")

#align(center)[#tao-fit-display[#mitex("\\tau_b(n) := |\\{ q \\in {\\mathcal S}_{I^{\\prime}}: n = b_q\\ (q) \\}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("\\tau_{b^{\\prime}}(n) := |\\{ q \\in {\\mathcal S}_{I^{\\prime}}: n = b^{\\prime}_q\\ (q) \\}")]]

#text("are the multiplicity functions associated to the congruence class systems ")#mi("{(\\{b_q\\})_{q \\in {\\mathcal S}_{I^{\\prime}}}}")#text(" and ")#mi("{(\\{b^{\\prime}_q\\})_{q \\in {\\mathcal S}_{I^{\\prime}}}}")#text(".")

#text("By the elementary bound ")#mi("{\\tau_b(mn_1) \\tau_{b^{\\prime}}(mn_2) \\leq \\tau_b(mn_1)^2 + \\tau_{b^{\\prime}}(mn_2)^2}")#text(" and symmetry we may thus bound the left-hand side of ")#link(<tao-1190a99d5fd01be099bc>)[#text("(32)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{q_0>1} \\sum_{m} \\psi_M(m) \\sum_{n_1,n_2: mn_1=mn_2 =a_r\\ (r); mn_1 = b_{q_0}\\ (q_0); mn_2 = b^{\\prime}_{q_0}\\ (q_0)}")]]

#align(center)[#tao-fit-display[#tao-math("\\left|\\beta(n_1)\\right| |\\beta(n_2)| \\tau_b(mn_1)^2", block: true)]]

#text("plus a symmetric term which is treated similarly and will be ignored.")

#text("We rearrange the constraints")

#align(center)[#tao-fit-display[#mitex("mn_1=mn_2=a_r\\ (r); \\quad mn_1 = b_{q_0}\\ (q_0); \\quad mn_2 = b^{\\prime}_{q_0}\\ (q_0)\\ (q_0)")]]

#text("as a combination of the constraints")

#align(center)[#tao-fit-display[#mitex("n_1 = n_2\\ (r); \\quad b^{\\prime}_{q_0} n_1 = b_{q_0} n_2\\ (q_0)")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("mn_1 = a_r\\ (r); \\quad mn_1 = b_{q_0}\\ (q_0).")]]

#text("For a given choice of ")#mi("{n_1,n_2}")#text(" obeying the former set of constraints, the ")#mi("{mn_1}")#text(" obeying the second set of constraints lie in a single congruence class mod ")#mi("{q_0rn_1}")#text(" by the Chinese remainder theorem. From the controlled multiplicity hypothesis ")#link(<tao-cbf38e496835a79fe9ba>)[#text("(6)")]#text(" one thus has")

#align(center)[#tao-fit-display[#mitex("\\sum_{m: mn_1 = a_r\\ (r); mn_1 = b_{q_0}\\ (q_0)} \\psi_M(m) \\tau_b(mn_1)^2 \\ll \\frac{M}{q_0 R} \\tau(q_0 r n_1)^{O(1)} \\log^{O(1)} x + x^{o(1)}")]]

#text("and so the left-hand side of ")#link(<tao-1190a99d5fd01be099bc>)[#text("(32)")]#text(" has been bounded by")

#align(center)[#tao-fit-display[#tao-math("\\ll \\sum_{q_0>1} \\sum_{n_1,n_2: n_1=n_2\\ (r); b^{\\prime}_{q_0} n_1 = b_{q_0} n_2\\ (q_0)} \\left|\\beta(n_1)\\right| \\left|\\beta(n_2)\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("(\\frac{M}{q_0 R} \\tau(q_0 r n_1)^{O(1)} \\log^{O(1)} x + x^{o(1)}).")]]

#text("We first dispose of the ")#mi("{x^{o(1)}}")#text(" error term. From the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(" we have ")#tao-math("{\\left|\\beta(n_1)\\right| \\left|\\beta(n_2)\\right| = O(x^{o(1)})}", block: false)#text(". For a given choice of ")#mi("{n_1 \\sim N}")#text(", the ")#mi("{n_2}")#text(" sum then can be bounded by ")#mi("{x^{o(1)} (\\frac{N}{q_0 R} + 1)}")#text(", leading to a total contribution of")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} N (\\frac{N}{R} + Q).")]]

#text("We would like to bound this by ")#mi("{N^2 M R^{-2} \\log^{-A} x}")#text(". This is possible if we have ")#metadata(none) <tao-32ce8ef2313cde6b9536>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(33)")])
#mitex("R \\ll x^{-c+o(1)} M")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("QR \\times R \\ll x^{-c+o(1)} MN")]]

#text("for some fixed ")#mi("{c>0}")#text(". But the former bound is immediate from ")#link(<tao-375676bd26868505668f>)[#text("(23)")]#text(", ")#link(<tao-cd58add90c5a1937a32b>)[#text("(10)")]#text(", ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(", while from ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(9)")]#text(", ")#link(<tao-2617708489831f17c7b6>)[#text("(24)")]#text(", ")#link(<tao-375676bd26868505668f>)[#text("(23)")]#text(" we see that the latter bound will follow if we have ")#metadata(none) <tao-f45610b06fe1da76ca5b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(34)")])
#mitex("x^\\mu \\gg x^{-1/2+2\\varpi+c} N.")]]

#text("for some fixed ")#mi("{c>0}")#text(". We file away this necessary condition for now and move on, though we note that these conditions are weaker than ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(" except in the “Type II” case when ")#mi("{M,N}")#text(" are close to ")#mi("{\\sqrt{x}}")#text(".")

#text("Having disposed of the ")#mi("{x^{o(1)}}")#text(" error term, the remaining contribution to the left-hand side of ")#link(<tao-1190a99d5fd01be099bc>)[#text("(32)")]#text(" that we need to control is")

#align(center)[#tao-fit-display[#tao-math("\\sum_{q_0>1} \\sum_{n_1,n_2: n_1=n_2\\ (r); b^{\\prime}_{q_0} n_1 = b_{q_0} n_2\\ (q_0)} \\left|\\beta(n_1)\\right| \\left|\\beta(n_2)\\right| \\frac{M}{q_0 R} \\tau(q_0 r n_1)^{O(1)} \\log^{O(1)} x.", block: true)]]

#text("Summing in ")#mi("{n_2}")#text(" using crude bounds, this is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{q_0>1} \\sum_{n_1} |\\beta(n_1)| \\frac{M}{q_0 R} \\tau(q_0 r n_1)^{O(1)} \\log^{O(1)} x ( \\frac{N}{q_0 R} + x^{o(1)}),")]]

#text("and then by summing in ")#mi("{n_1}")#text(" this is in turn bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll \\sum_{q_0>1} \\frac{NM}{q_0 R} \\tau(q_0 r)^{O(1)} \\log^{O(1)} x ( \\frac{N}{q_0 R} + x^{o(1)}).")]]

#text("The ")#mi("{x^{o(1)}}")#text(" term sums to ")#mi("{O( x^{o(1)} NM / R )}")#text(", which is ")#mi("{O( N^2 M R^{-2} \\log^{-A} x)}")#text(" thanks to ")#link(<tao-375676bd26868505668f>)[#text("(23)")]#text(", ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(". The main term is then")

#align(center)[#tao-fit-display[#mitex("\\ll ( \\tau(r)^{O(1)} \\log^{O(1)} x) \\frac{N^2 M}{R^2} \\sum_{q_0>1} \\frac{\\tau(q_0)^{O(1)}}{q_0^2}.")]]

#text("Now we finally use the fact that ")#mi("{q_0}")#text(" has no small factors less than ")#mi("{D_0}")#text(" to bound the summation here by")

#align(center)[#tao-fit-display[#mitex("\\prod_{p \\geq D_0} (1 + O(\\frac{1}{p^2})) - 1 = O( \\frac{1}{D_0} )")]]

#text("and since ")#mi("{D_0}")#text(" grows faster than any power of ")#mi("{\\log x}")#text(" we see that this error term is also acceptable for ")#link(<tao-1190a99d5fd01be099bc>)[#text("(32)")]#text(". This concludes the proof of ")#link(<tao-1190a99d5fd01be099bc>)[#text("(32)")]#text(" (contingent of course on the lower bounds ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(", ")#link(<tao-f45610b06fe1da76ca5b>)[#text("(34)")]#text(" on ")#mi("{\\mu}")#text(" that we will deal with later).")

#text("It remains to verify ")#link(<tao-c7d459bba7d890eb2690>)[#text("(31)")]#text(". Observe that ")#mi("{n_1}")#text(" must be coprime to ")#mi("{q_1r}")#text(" and ")#mi("{n_2}")#text(" coprime to ")#mi("{q_2r}")#text(", with ")#mi("{n_1 = n_2\\ (r)}")#text(", to have a non-zero contribution to the sum. We then rearrange the left-hand side as")

#align(center)[#tao-fit-display[#mitex("\\sum_{q_1,q_2: (q_1,r)=(q_2,r)=(q_1,q_2)=1} \\sum_{m} \\psi_M(m) \\sum_{n_1,n_2: n_1=n_2\\ (r); (n_1,q_1r)=(n_2,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n_1) \\beta(n_2) 1_{m = a_r/n_1\\ (r); m = b_{q_1}/n_1\\ (q_1); m = b^{\\prime}_{q_2}/n_2 (q_2)};")]]

#text("note that these inverses in the various rings ")#mi("{{\\bf Z}/r{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_1{\\bf Z}}")#text(", ")#mi("{{\\bf Z}/q_2{\\bf Z}}")#text(" are well-defined thanks to the coprimality hypotheses.")

#text("We may write ")#mi("{n_2 = n_1+kr}")#text(" for some ")#mi("{k = O(N/R)}")#text(". By the triangle inequality, and relabeling ")#mi("{n_1}")#text(" as ")#mi("{n}")#text(", it thus suffices to show that for any particular ")#metadata(none) <tao-996e1ebb1203243399dd>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(35)")])
#mitex("k = O(N/R),")]]

#text("one has ")#metadata(none) <tao-a871c47a7f48a12b38a9>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(36)")])
#mitex("\\sum_{q_1,q_2: (q_1,r)=(q_2,r)=(q_1,q_2)=1} \\sum_{m} \\psi_M(m) \\sum_{n; (n,q_1r)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("c_{q_1} c_{q_2} \\beta(n) \\beta(n+kr) 1_{m = a_r/n\\ (r); m = b_{q_1}/n\\ (q_1); m = b^{\\prime}_{q_2}/(n+kr) (q_2)}")]]

#align(center)[#tao-fit-display[#mitex("= X_k + O( N M R^{-1} \\log^{-A} x )")]]

#text("for some ")#mi("{X_k}")#text(" independent of the ")#mi("{b_q}")#text(" and ")#mi("{b^{\\prime}_q}")#text(".")

#text("We remark that at this stage we are only needing to gain a factor of ")#mi("{\\log^{-A} x}")#text(" over the trivial bound. However, we will now perform the expensive step of completion of sums (Lemma ")#link(<tao-71b4f3a3748cd6843c01>)[#text("6")]#text("), which replaces the ")#mi("{\\psi_M}")#text(" factor by an exponential phase at the cost of requiring now a significantly larger gain over the trivial bound. Applying Lemma ")#link(<tao-71b4f3a3748cd6843c01>)[#text("6")]#text(" and Lemma ")#link(<tao-49002d515d1605d8e492>)[#text("7")]#text(", we can write the left-hand side of ")#link(<tao-a871c47a7f48a12b38a9>)[#text("(36)")]#text(" as the sum of the main term")

#align(center)[#tao-fit-display[#mitex("X_k := \\sum_{q_1,q_2: (q_1,r)=(q_2,r)=(q_1,q_2)=1} \\sum_{n: (n,q_1r)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("\\frac{c_{q_1} c_{q_2} \\beta(n) \\beta(n+kr)}{r q_1 q_2} (\\sum_m \\psi_M(m));")]]

#text("an error term")

#align(center)[#tao-fit-display[#tao-math("O( (\\log^{O(1)} x) \\frac{M}{Q^2R} \\sum_{1 \\leq h \\leq H} \\sum_{q_1,q_2} \\left|\\sum_{n} \\beta(n) \\beta(n+kr) \\Phi(h,q_1,q_2; n) \\right|)", block: true)]]

#text("where ")#metadata(none) <tao-a81ffb258bff4eddc451>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(37)")])
#mitex("H := x^\\epsilon Q^2 R/M,")]]

#mi("{\\epsilon > 0}")#text(" is an arbitrary small fixed quantity, and ")#mi("{\\Phi = \\Phi_{k,r}}")#text(" is the phase ")#metadata(none) <tao-e46fd696bb4d24c149d4>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(38)")])
#mitex("\\Phi(h,q_1,q_2;n) := 1_{(q_1,r)=(q_2,r)=(q_1,q_2)=(n,r)=(n,q_1)=(n+kr,q_2)=1}")]]

#align(center)[#tao-fit-display[#mitex("e_r( \\frac{a_r h}{nq_1 q_2} ) e_{q_1}( \\frac{b_{q_1}h}{n r q_2} ) e_{q_2}( \\frac{b^{\\prime}_{q_2} h}{(n+kr) r q_1} )")]]

#text("(here we use the bounded nature of the ")#mi("{c_{q_1}, c_{q_2}}")#text("); and another error term that can easily be shown to be ")#mi("{O(x^{-A+O(1)})}")#text(" for any fixed ")#mi("{A}")#text(". The term ")#mi("{X_k}")#text(" is independent of the ")#mi("{b_q}")#text(" and ")#mi("{b^{\\prime}_q}")#text(", so it will suffice to show that ")#metadata(none) <tao-a7a8572a4aabf25aac4c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(39)")])
#tao-math("\\sum_h \\sum_{Q \\ll q_1,q_2 \\ll Q} \\left|\\sum_{n} \\beta(n) \\beta(n+kr) \\Phi(h,q_1,q_2; n)\\right| \\ll x^{-\\epsilon+o(1)} Q^2 N", block: true)]]

#text("for a sufficiently small fixed ")#mi("{\\epsilon>0}")#text(", and we have dropped all hypotheses on ")#mi("{q_1,q_2}")#text(" other than magnitude, and we abbreviate ")#mi("{\\sum_{1 \\leq h \\leq H}}")#text(" as ")#mi("{\\sum_h}")#text(". As noted after Lemma ")#link(<tao-71b4f3a3748cd6843c01>)[#text("6")]#text(", we are no longer asking for just a ")#mi("{\\log^{-A} x}")#text(" savings over the trivial bound; we must instead gain a factor of ")#mi("{x^{\\epsilon} H}")#text(" to overcome the summation in ")#mi("{h}")#text(".")

#text("Although this is not strictly necessary for our analysis, let is confirm that ")#mi("{H}")#text(" is actually non-trivial in the sense that ")#metadata(none) <tao-3c2bd67b9b6dc8880990>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(40)")])
#mitex("H \\gg 1.")]]

#text("Indeed, from ")#link(<tao-375676bd26868505668f>)[#text("(23)")]#text(" and ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(9)")]#text(" one has")

#align(center)[#tao-fit-display[#mitex("RM \\ll x^{1-\\mu+o(1)}")]]

#text("and hence from ")#link(<tao-2617708489831f17c7b6>)[#text("(24)")]

#align(center)[#tao-fit-display[#mitex("RM \\ll x^{-\\mu+o(1)} Q^2 R^2")]]

#text("and ")#link(<tao-3c2bd67b9b6dc8880990>)[#text("(40)")]#text(" then follows from ")#link(<tao-a81ffb258bff4eddc451>)[#text("(37)")]#text(". Note though in the model case ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(20)")]#text(" with ")#mi("{\\mu \\approx 0}")#text(" that ")#mi("{H}")#text(" is close to ")#mi("{1}")#text(" (for any ")#mi("{\\sigma}")#text(" between ")#mi("{0}")#text(" and ")#mi("{1/8}")#text(").")

#text("We now split into two cases, one which works when ")#mi("{M, N}")#text(" are not too close to ")#mi("{x^{1/2}}")#text(", and one which works when ")#mi("{M,N}")#text(" are close to ")#mi("{x^{1/2}}")#text(".")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 13 (Type I case)")]#text(" ")#metadata(none) <tao-b5e509d769c77bd1fecf>#text(" If the inequalities ")#metadata(none) <tao-7c25b82c0ab03b1bca18>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(41)")])
#mitex("11\\varpi + 3\\mu + 3\\delta + 2 \\sigma < \\frac{1}{4}")]]

#text("and ")#metadata(none) <tao-628b49d96dcde97a430d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(42)")])
#mitex("M \\gg x^{1/2+2\\varpi+c}")]]

#text("hold for some fixed ")#mi("{c>0}")#text(", then ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("(39)")]#text(" holds for a sufficiently small fixed ")#mi("{\\epsilon>0}")#text(".")
]

#text("The condition ")#link(<tao-628b49d96dcde97a430d>)[#text("(42)")]#text(" represents a border between this case and the Type II case.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 14 (Type II case)")]#text(" ")#metadata(none) <tao-39f88196b45a1d7fb36b>#text(" If the inequality ")#metadata(none) <tao-22b1f82e804e2c285b47>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(43)")])
#mitex("24\\varpi + 10 \\mu + 10 \\delta + 7 \\sigma < \\frac{1}{2}")]]

#text("holds, then ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("(39)")]#text(" holds for a sufficiently small fixed ")#mi("{\\epsilon>0}")#text(".")
]

#text("Both of these theorems are established by using Cauchy-Schwarz to eliminate the absolute values and ")#mi("{\\beta}")#text(" factors in ")#link(<tao-a7a8572a4aabf25aac4c>)[#text("(39)")]#text(" until one is left with an expression only involving the phase ")#mi("{\\Phi(h,q_1,q_2;n)}")#text(" which can then be estimated using the Weil conjectures with a power saving to counteract the loss of ")#mi("{H}")#text(", however the use of Cauchy-Schwarz is slightly different in the two cases. In practice, the condition ")#link(<tao-22b1f82e804e2c285b47>)[#text("(43)")]#text(" is too strong to be satisfied by value of ")#mi("{\\sigma}")#text(" given in Theorem ")#link(<tao-840c81157f3688e42875>)[#text("3")]#text(", so we will only use Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("14")]#text(" in the case that ")#link(<tao-628b49d96dcde97a430d>)[#text("(42)")]#text(" fails, since in that case we may make ")#mi("{\\sigma}")#text(" small enough for ")#link(<tao-22b1f82e804e2c285b47>)[#text("(43)")]#text(" to hold.")

#text("Assuming these theorems, let us now conclude the proof of Theorem ")#link(<tao-840c81157f3688e42875>)[#text("3")]#text(". First suppose we are in the “Type I” regime when ")#link(<tao-628b49d96dcde97a430d>)[#text("(42)")]#text(" holds for some fixed ")#mi("{c>0}")#text(". Then by ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("N \\ll x^{1/2-2\\varpi-c}")]]

#text("which means that the condition ")#link(<tao-f45610b06fe1da76ca5b>)[#text("(34)")]#text(" is now weaker than ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(" and may be omitted. By ")#link(<tao-810cc6914d7cb6597a00>)[#text("(7)")]#text(" we can simultaneously obey ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(", ")#link(<tao-f45610b06fe1da76ca5b>)[#text("(34)")]#text(", ")#link(<tao-7c25b82c0ab03b1bca18>)[#text("(41)")]#text(" by setting ")#mi("{\\mu}")#text(" sufficiently close to zero, and the claim now follows from Theorem ")#link(<tao-b5e509d769c77bd1fecf>)[#text("13")]#text(".")

#text("Now suppose instead that we are in the “Type II” regime where ")#link(<tao-628b49d96dcde97a430d>)[#text("(42)")]#text(" fails for some small ")#mi("{c>0}")#text(", so that by ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(9)")]#text(" we have")

#align(center)[#tao-fit-display[#mitex("x^{1/2-2\\varpi-c} \\ll N \\ll M \\ll x^{1/2+2\\varpi+c}.")]]

#text("From this we see that we may replace ")#mi("{\\sigma}")#text(" by ")#mi("{2\\varpi+c}")#text(" in ")#link(<tao-cd58add90c5a1937a32b>)[#text("(10)")]#text(" and in all of the above analysis. If we set ")#mi("{\\mu := 2\\varpi + c}")#text(" then the conditions ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(", ")#link(<tao-f45610b06fe1da76ca5b>)[#text("(34)")]#text(" are obeyed. Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("14")]#text(" will then give us what we want provided that")

#align(center)[#tao-fit-display[#mitex("24\\varpi + 10 (2\\varpi+c) + 10 \\delta + 7 (2\\varpi+c) < \\frac{1}{2}")]]

#text("which is satisfied for ")#mi("{c}")#text(" small enough thanks to ")#link(<tao-5b1b85d956c07f3e4d5f>)[#text("(8)")]#text(".")

#text("In the next two sections we establish Theorem ")#link(<tao-b5e509d769c77bd1fecf>)[#text("13")]#text(" and Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("14")]#text(".")

#heading(level: 1)[#strong[#text(" — 6. The Type I sum — ")]]

#text("We now prove Theorem ")#link(<tao-b5e509d769c77bd1fecf>)[#text("13")]#text(". It suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_h \\sum_{Q \\ll q_1,q_2 \\ll Q} c_{h,q_1,q_2} \\sum_{n} \\beta(n) \\beta(n+kr) \\Phi(h,q_1,q_2; n)\\right| \\ll x^{-\\epsilon+o(1)} Q^2 N", block: true)]]

#text("for any bounded real coefficients ")#mi("{c_{h,q_1,q_2} = O(1)}")#text(" (which are vaguely related to the previous coefficients ")#mi("{c_q}")#text(", but this is not important for us here). We rearrange the left-hand side as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{Q\\ll q_1 \\ll Q} \\sum_n \\beta(n) \\beta(n+kr) \\sum_h \\sum_{Q \\ll q_2 \\ll Q} c_{h,q_1,q_2} \\Phi(h,q_1,q_2; n)\\right|.", block: true)]]

#text("From the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(" we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_{Q \\ll q_1 \\ll Q} \\sum_n \\left|\\beta(n) \\beta(n+kr)\\right|^2 \\ll x^{o(1)} Q N", block: true)]]

#text("and we may write ")#mi("{\\beta = \\beta \\psi_N}")#text(" for some smooth coefficient sequence at scale ")#mi("{N}")#text(", so by Cauchy-Schwarz it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{Q \\ll q_1 \\ll Q} \\sum_{n} \\psi_N(n) \\left|\\sum_h \\sum_{Q \\ll q_2 \\ll Q} c_{h,q_1,q_2} \\Phi(h,q_1,q_2; n)\\right|^2 \\ll x^{-2\\epsilon+o(1)} Q^3 N", block: true)]]

#text("(note now we have to gain more than ")#mi("{H^2}")#text(" over the trivial bound, rather than just ")#mi("{H}")#text("). We rearrange this as")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{h,h^{\\prime}} \\sum_{Q \\ll q_1, q_2,q^{\\prime}_2 \\ll Q} c_{h,q_1,q_2} \\overline{c_{h^{\\prime},q_1,q^{\\prime}_2}} \\sum_{n} \\psi_N(n)\\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right|", block: true)]]

#text("so by the triangle inequality it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{h,h^{\\prime}} \\sum_{Q\\ll q_1, q_2,q^{\\prime}_2 \\ll Q} \\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right| \\ll x^{-2\\epsilon+o(1)} Q^3 N", block: true)]]

#text("for some fixed ")#mi("{\\epsilon>0}")#text(". We discard the ")#mi("{q_1}")#text(" summation and reduce to showing that ")#metadata(none) <tao-5c255f4c58718acd41ac>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(44)")])
#tao-math("\\sum_{h,h^{\\prime}} \\sum_{Q\\ll q_2,q^{\\prime}_2 \\ll Q} \\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right| \\ll x^{-2\\epsilon+o(1)} Q^2 N", block: true)]]

#text("for any ")#mi("{Q \\ll q_1 \\ll Q}")#text(".")

#text("To prove ")#link(<tao-5c255f4c58718acd41ac>)[#text("(44)")]#text(", we isolate the ")#emph[#text("diagonal case")]#text(" ")#mi("{h^{\\prime}q_2 = hq^{\\prime}_2}")#text(" and the ")#emph[#text("non-diagonal case")]#text(" ")#mi("{h^{\\prime}q_2 \\neq h q^{\\prime}_2}")#text(". For the diagonal case, we make the crude bound")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right| \\ll x^{o(1)} N", block: true)]]

#text("The contribution of the diagonal case can now be bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll N | \\{ (h,h^{\\prime},q_2,q^{\\prime}_2): h,h^{\\prime} = O(H); q_2,q^{\\prime}_2 = O(Q); hq^{\\prime}_2=h^{\\prime}q_2 \\}|.")]]

#text("Writing ")#mi("{m := hq^{\\prime}_2 = h^{\\prime}q_2}")#text(" we have ")#mi("{m=O(HQ)}")#text(", and one can estimate this by")

#align(center)[#tao-fit-display[#mitex("\\ll N \\sum_{m = O(HQ)} \\tau(m)^2")]]

#text("which by the ")#link("https://terrytao.wordpress.com/2008/09/23/the-divisor-bound/")[#text("divisor bound")]#text(" is of the form")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} N H Q.")]]

#text("For this to be acceptable we need a bound of the form")

#align(center)[#tao-fit-display[#mitex("H \\ll x^{-2\\epsilon+o(1)} Q")]]

#text("which, by ")#link(<tao-a81ffb258bff4eddc451>)[#text("(37)")]#text(" is equivalent to")

#align(center)[#tao-fit-display[#mitex("QR \\ll x^{-3\\epsilon+o(1)} M,")]]

#text("but this follows from ")#link(<tao-2617708489831f17c7b6>)[#text("(24)")]#text(", ")#link(<tao-628b49d96dcde97a430d>)[#text("(42)")]#text(" for ")#mi("{\\epsilon}")#text(" small enough.")

#text("Now we treat the non-diagonal case ")#mi("{h^{\\prime}q_2 \\neq hq^{\\prime}_2}")#text(". The key estimate here is ")#metadata(none) <tao-4a0ba3b5a21b0257fa9c>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(45)")])
#tao-math("\\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q_1,q^{\\prime}_2;n)}\\right|", block: true)]]

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} (Q^{3/2} R^{1/2} + H Q R^{-1} N)")]]

#text("for all non-diagonal ")#mi("{h,q_2,h^{\\prime}_2,q^{\\prime}_2}")#text(". In the model case ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(20)")]#text(" with ")#mi("{\\mu \\approx 0}")#text(", the two terms on the right-hand side are approximately ")#mi("{x^{1/4+\\sigma+o(1)}}")#text(" and ")#mi("{x^{\\sigma+o(1)}}")#text(", which give the desired power saving compared to the trivial bound of ")#mi("{x^{1/2-\\sigma+o(1)}}")#text(" since ")#mi("{\\sigma < 1/8}")#text(" (and in ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(20)")]#text(", ")#mi("{H}")#text(" is small, so just about any power saving suffices). As the model case indicates, the first term in ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(" is the dominant one in practice.")

#text("Assume for the moment that the estimate ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(" holds; then the non-diagonal contribution to ")#link(<tao-5c255f4c58718acd41ac>)[#text("(44)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} ( H^2 Q^{7/2} R^{1/2} + H^3 Q^3 R^{-1} N )")]]

#text("so to conclude ")#link(<tao-5c255f4c58718acd41ac>)[#text("(44)")]#text(" we need to show that")

#align(center)[#tao-fit-display[#mitex("H^2 Q^{7/2} R^{1/2} \\ll x^{-2\\epsilon+o(1)} Q^2 N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H^3 Q^3 R^{-1} N \\ll x^{-2\\epsilon+o(1)} Q^2 N.")]]

#text("Using ")#link(<tao-a81ffb258bff4eddc451>)[#text("(37)")]#text(", ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(9)")]#text(" we can rewrite these criteria as")

#align(center)[#tao-fit-display[#mitex("(QR)^{11/2} \\ll x^{2-4\\epsilon+o(1)} N^2 (R/N)^3")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(QR)^7 \\ll x^{3-5\\epsilon+o(1)} N^2 (R/N)^5")]]

#text("respectively. Applying ")#link(<tao-2617708489831f17c7b6>)[#text("(24)")]#text(", ")#link(<tao-375676bd26868505668f>)[#text("(23)")]#text(", it suffices to verify that")

#align(center)[#tao-fit-display[#mitex("x^{\\frac{11}{4} + 11 \\varpi} \\ll x^{2-4\\epsilon-3\\mu-3\\delta+o(1)} N^2")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{\\frac{7}{2} + 14 \\varpi} \\ll x^{3-5\\epsilon-5\\mu-5\\delta+o(1)} N^2")]]

#text("but these follow from ")#link(<tao-cd58add90c5a1937a32b>)[#text("(10)")]#text(" and ")#link(<tao-7c25b82c0ab03b1bca18>)[#text("(41)")]#text(" (the latter inequality holds with considerable room to spare).")

#text("It remains to show ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(" in the non-diagonal case ")#mi("{h^{\\prime}q_2 \\neq hq^{\\prime}_2}")#text(". From ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(38)")]#text(" we may of course assume that")

#align(center)[#tao-fit-display[#mitex("(q_1,r) = (q_2,r) = (q_1,q_2) = (q^{\\prime}_2,r) = (q_1,q^{\\prime}_2) = 1")]]

#text("and the left-hand side of ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(" expands as")

#align(center)[#tao-fit-display[#mitex("| \\sum_{n} \\psi_N(n) 1_{(n,q_1r) = (n+kr,q_2q^{\\prime}_2)=1} e_r( \\frac{a_r (hq^{\\prime}_2-h^{\\prime}q_2)}{nq_1q_2q^{\\prime}_2} ) e_{q_1}( \\frac{b_{q_1} (h q^{\\prime}_2 - h^{\\prime} q_2)}{nrq_2q^{\\prime}_2})")]]

#align(center)[#tao-fit-display[#mitex("e_{q_2}( \\frac{b^{\\prime}_{q_2} h}{(n+kr) r q_1} ) e_{q^{\\prime}_2}( -\\frac{b^{\\prime}_{q^{\\prime}_2} h^{\\prime}}{(n+kr) r q_1} )|.")]]

#text("The first two phases")

#align(center)[#tao-fit-display[#mitex("e_r( \\frac{a_r (hq^{\\prime}_2-h^{\\prime}q_2)}{nq_1q_2q^{\\prime}_2} ) e_{q_1}( \\frac{b_{q_1} (h q^{\\prime}_2 - h^{\\prime} q_2)}{nrq_2q^{\\prime}_2})")]]

#text("can be combined as")

#align(center)[#tao-fit-display[#mitex("e_{d_1}( \\frac{c_1}{n} )")]]

#text("where ")#mi("{d_1 := q_1 r}")#text(" and ")#mi("{c_1 \\in {\\bf Z}/d_1{\\bf Z}}")#text(" is the residue class")

#align(center)[#tao-fit-display[#mitex("c_1 := (hq^{\\prime}_2 - h^{\\prime}q_2) (a_r \\bar{q_1} \\bar{q_2} \\bar{q^{\\prime}_2} q_1 + b_{q_1} \\bar{r} \\bar{q_2} \\bar{q^{\\prime}_2} r)\\ (d_1)")]]

#text("and the inverses ")#mi("{\\bar{x}}")#text(" are with respect to modulus ")#mi("{r}")#text(" in the first summand and ")#mi("{q_1}")#text(" in the second summand. For future reference we note that ")#metadata(none) <tao-21876c22edad493502a7>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(46)")])
#mitex("(c_1, r) = (hq^{\\prime}_2-h^{\\prime}q_2, r).")]]

#text("Similarly, the two phases")

#align(center)[#tao-fit-display[#mitex("e_{q_2}( \\frac{b^{\\prime}_{q_2} h}{(n+kr) r q_1} ) e_{q^{\\prime}_2}( -\\frac{b^{\\prime}_{q^{\\prime}_2} h^{\\prime}}{(n+kr) r q_1} )")]]

#text("can combine as")

#align(center)[#tao-fit-display[#mitex("e_{d_2}( \\frac{c_2}{n+kr} )")]]

#text("where ")#mi("{d_2 := [q_2,q^{\\prime}_2]}")#text(" and ")#mi("{c_2 \\in {\\bf Z}/d_2{\\bf Z}}")#text(" is the residue class")

#align(center)[#tao-fit-display[#mitex("c_2 := b^{\\prime}_{q_2} h \\bar{r} \\bar{q_1} \\frac{d_2}{q_2} - b^{\\prime}_{q^{\\prime}_2} h^{\\prime} \\bar{r} \\bar{q_1} \\frac{d_2}{q^{\\prime}_2}\\ (d_2),")]]

#text("although the precise value of ")#mi("{c_2}")#text(" will not be important for us. The left-hand side of ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(" is thus")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_{n} \\psi_N(n) 1_{(n,d_1) = (n+kr,d_2)=1} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+kr} )\\right|", block: true)]]

#text("and hence Corollary ")#link(<tao-f562267f2b6d890a7c0c>)[#text("10")]#text(" and the coprimality of ")#mi("{d_1,d_2}")#text(" is bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} ( (d_1 d_2)^{1/2} + \\frac{N}{d_1 d_2} (c_1,d_1) (c_2,d_2) ).")]]

#text("Note that")

#align(center)[#tao-fit-display[#mitex("d_1 d_2 \\leq q_1 r q_2 q^{\\prime}_2 \\ll Q^3 R")]]

#text("which is controlled by the first term on the right-hand side of ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(". So it remains to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{1}{d_1 d_2} (c_1,d_1) (c_2,d_2) \\ll H Q R^{-1}.")]]

#text("We crudely bound ")#mi("{(c_2,d_2)}")#text(" by ")#mi("{d_2}")#text(" and ")#mi("{(c_1,d_1)}")#text(" by ")#mi("{(c_1,r) q_1}")#text(". (This is inefficient, but this term is not dominant in the analysis in any case.) By ")#link(<tao-21876c22edad493502a7>)[#text("(46)")]#text(" we may bound ")#mi("{(c_1,r)}")#text(" by ")#mi("{HQ}")#text(", and the claim follows.")

#heading(level: 1)[#strong[#text(" — 7. The Type II sum — ")]]

#text("We now prove Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("14")]#text(". As before, it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_h \\sum_{Q \\ll q_1,q_2 \\ll Q} c_{h,q_1,q_2} \\sum_{n} \\beta(n) \\beta(n+kr) \\Phi(h,q_1,q_2; n)\\right| \\ll x^{-\\epsilon+o(1)} Q^2 N", block: true)]]

#text("for any bounded real coefficients ")#mi("{c_{h,q_1,q_2} = O(1)}")#text(". We rearrange the left-hand side slightly differently from the previous section:")

#align(center)[#tao-fit-display[#tao-math("\\left|\\sum_n \\beta(n) \\beta(n+kr) \\sum_h \\sum_{Q \\ll q_1, q_2 \\ll Q} c_{h,q_1,q_2} \\Phi(h,q_1,q_2; n)\\right|.", block: true)]]

#text("From crude bounds we have")

#align(center)[#tao-fit-display[#tao-math("\\sum_n \\left|\\beta(n) \\beta(n+kr)\\right|^2 \\ll x^{o(1)} N,", block: true)]]

#text("so by Cauchy-Schwarz it suffices to show that")

#align(center)[#tao-fit-display[#tao-math("\\sum_{n} \\psi_N(n) \\left|\\sum_h \\sum_{Q \\ll q_1,q_2 \\ll Q} c_{h,q_1,q_2} \\Phi(h,q_1,q_2; n)\\right|^2 \\ll x^{-2\\epsilon+o(1)} Q^4 N.", block: true)]]

#text("Expanding and using the triangle inequality as in the previous section, we reduce to showing that ")#metadata(none) <tao-f700da657a0e05cabc98>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(47)")])
#tao-math("\\sum_{h,h^{\\prime}} \\sum_{Q\\ll q_1, q^{\\prime}_1, q_2,q^{\\prime}_2 \\ll Q} \\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q^{\\prime}_1,q^{\\prime}_2;n)}\\right| \\ll x^{-2\\epsilon+o(1)} Q^4 N.", block: true)]]

#text("This is basically the same situation as in the previous section except that we have decoupled the ")#mi("{q_1,q^{\\prime}_1}")#text(" variables from each other.")

#text("As before, we isolate a diagonal case ")#mi("{h^{\\prime}q_1 q_2 = h q^{\\prime}_1 q^{\\prime}_2}")#text(", and now consider the contribution of this case. Arguing as in the previous section, the contribution of this case to ")#link(<tao-f700da657a0e05cabc98>)[#text("(47)")]#text(" can be bounded by")

#align(center)[#tao-fit-display[#mitex("\\ll N \\sum_{m = O(HQ^2)} \\tau(m)^{O(1)}")]]

#text("which by the divisor bound is of the form")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} N H Q^2")]]

#text("which will be acceptable if")

#align(center)[#tao-fit-display[#mitex("H \\ll x^{-2\\epsilon+o(1)} Q^2.")]]

#text("By ")#link(<tao-a81ffb258bff4eddc451>)[#text("(37)")]#text(" this is equivalent to")

#align(center)[#tao-fit-display[#mitex("R \\ll x^{-3\\epsilon+o(1)} M,")]]

#text("but this is automatic from ")#link(<tao-375676bd26868505668f>)[#text("(23)")]#text(" and ")#link(<tao-352b5b6699d83cdc4efd>)[#text("(22)")]#text(".")

#text("For the off-diagonal case, we use the following variant ")#metadata(none) <tao-a5a678fbc88d625d311d>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(48)")])
#tao-math("\\left|\\sum_{n} \\psi_N(n) \\Phi(h,q_1,q_2;n) \\overline{\\Phi(h^{\\prime},q^{\\prime}_1,q^{\\prime}_2;n)}\\right| \\ll", block: true)]]

#align(center)[#tao-fit-display[#mitex("x^{o(1)} (Q^{2} R^{1/2} + H Q^6 R^{-1} N)")]]

#text("of ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(", valid for all non-diagonal ")#mi("{h,q_1,q_2,h^{\\prime},q^{\\prime}_1,q^{\\prime}_2}")#text(". The bound here is weaker than in ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(", but in the model case ")#link(<tao-9372c470eeadd5ecd9c3>)[#text("(20)")]#text(" the right-hand side terms are approximately ")#mi("{x^{\\frac{1}{4} + \\frac{3\\sigma}{2}+o(1)}}")#text(" and ")#mi("{x^{6\\sigma+o(1)}}")#text(" respectively, which still represents a power saving over the trivial bound of approximately ")#mi("{x^{1/2-\\sigma}}")#text(" as long as ")#mi("{\\sigma < 1/14}")#text(". While this does not cover all the range ")#mi("{\\sigma<1/8}")#text(" that the Type I analysis does, it crucially is able to cover the case when ")#mi("{\\sigma}")#text(" is very close to zero, which the Type I analysis does not cover due to the condition ")#link(<tao-628b49d96dcde97a430d>)[#text("(42)")]#text(". The Type I/II border is not the critical border for optimising the exponents, so it is not a priority for us to improve bounds in the Type II analysis such as ")#link(<tao-a5a678fbc88d625d311d>)[#text("(48)")]#text(".")

#text("We assume ")#link(<tao-a5a678fbc88d625d311d>)[#text("(48)")]#text(" for now and finish the proof of Theorem ")#link(<tao-39f88196b45a1d7fb36b>)[#text("14")]#text(" by numerical computations similar to that in the previous section. The non-diagonal contribution to ")#link(<tao-f700da657a0e05cabc98>)[#text("(47)")]#text(" is now estimated by")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} ( H^2 Q^6 R^{1/2} + H^3 Q^{10} R^{-1} N )")]]

#text("so to conclude ")#link(<tao-f700da657a0e05cabc98>)[#text("(47)")]#text(" we need to show that")

#align(center)[#tao-fit-display[#mitex("H^2 Q^6 R^{1/2} \\ll x^{-2\\epsilon+o(1)} Q^4 N")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("H^3 Q^{10} R^{-1} N \\ll x^{-2\\epsilon+o(1)} Q^4 N.")]]

#text("Using ")#link(<tao-a81ffb258bff4eddc451>)[#text("(37)")]#text(", ")#link(<tao-2f48b881ea7073f1c6f0>)[#text("(9)")]#text(" we can rewrite these criteria as")

#align(center)[#tao-fit-display[#mitex("(QR)^6 \\ll x^{2-4\\epsilon+o(1)} N^{5/2} (R/N)^{7/2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("(QR)^{12} \\ll x^{3-5\\epsilon+o(1)} N^7 (R/N)^{10}")]]

#text("respectively. Applying ")#link(<tao-2617708489831f17c7b6>)[#text("(24)")]#text(", ")#link(<tao-375676bd26868505668f>)[#text("(23)")]#text(", it suffices to verify that")

#align(center)[#tao-fit-display[#mitex("x^{3 + 12 \\varpi} \\ll x^{2-4\\epsilon-\\frac{7}{2}\\mu-\\frac{7}{2}\\delta+o(1)} N^{5/2}")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("x^{6 + 24 \\varpi} \\ll x^{3-5\\epsilon-10\\mu-10\\delta+o(1)} N^7")]]

#text("but these follow from ")#link(<tao-cd58add90c5a1937a32b>)[#text("(10)")]#text(" and ")#link(<tao-22b1f82e804e2c285b47>)[#text("(43)")]#text(".")

#text("It remains to prove ")#link(<tao-a5a678fbc88d625d311d>)[#text("(48)")]#text(". This is very similar to the treatment of ")#link(<tao-4a0ba3b5a21b0257fa9c>)[#text("(45)")]#text(". From ")#link(<tao-e46fd696bb4d24c149d4>)[#text("(38)")]#text(" we may assume")

#align(center)[#tao-fit-display[#mitex("(q_1,r) = (q^{\\prime}_1,r) = (q_2,r) = (q^{\\prime}_2,r) = (q_1,q_2) = (q^{\\prime}_1,q^{\\prime}_2) = 1")]]

#text("and the left-hand side of ")#link(<tao-a5a678fbc88d625d311d>)[#text("(48)")]#text(" expands as")

#align(center)[#tao-fit-display[#mitex("| \\sum_{n} \\psi_N(n) 1_{(n,q_1q^{\\prime}_1r) = (n+kr,q_2q^{\\prime}_2)=1} e_r( \\frac{a_r (hq^{\\prime}_1q^{\\prime}_2-h^{\\prime}q_1q_2)}{nq_1q^{\\prime}_1q_2q^{\\prime}_2} )")]]

#align(center)[#tao-fit-display[#mitex("e_{q_1}( \\frac{b_{q_1} h}{nrq_2}) e_{q^{\\prime}_1}( -\\frac{b^{\\prime}_{q_1} h^{\\prime}}{nrq^{\\prime}_2})")]]

#align(center)[#tao-fit-display[#mitex("e_{q_2}( \\frac{b^{\\prime}_{q_2} h}{(n+kr) r q_1} ) e_{q^{\\prime}_2}( -\\frac{b^{\\prime}_{q^{\\prime}_2} h^{\\prime}}{(n+kr) r q^{\\prime}_1} )|.")]]

#text("If we set")

#align(center)[#tao-fit-display[#mitex("d_1 := [q_1,q^{\\prime}_1]r; \\quad d_2 := [q_2,q^{\\prime}_2]")]]

#text("then as before we can rewrite this sum as")

#align(center)[#tao-fit-display[#tao-math("\\left| \\sum_{n} \\psi_N(n) 1_{(n,d_1) = (n+kr,d_2)=1} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+kr} ) \\right|", block: true)]]

#text("where")

#tao-aligned(keep: true)[


#tao-math("c_1  & = a_r \\bar{q_1} \\bar{q^{\\prime}_1} \\bar{q_2} \\bar{q^{\\prime}_2} (hq^{\\prime}_1q^{\\prime}_2-h^{\\prime}q_1q_2) \\frac{d_1}{r}", block: true)



#tao-math(" & + b_{q_1} \\bar{r} \\bar{q_2} h \\frac{d_1}{q_1} - b^{\\prime}_{q^{\\prime}_1} \\bar{r} \\bar{q^{\\prime}_2} h^{\\prime} \\frac{d_1}{q^{\\prime}_1}\\ (d_1)", block: true)
]

#text("(with the inverses with respect to the moduli ")#mi("{r, q_1, q^{\\prime}_1}")#text(" in the first, second, and third summands respectively), and the value of ")#mi("{c_2}")#text(" is unimportant for us. We have an analogue of ")#link(<tao-21876c22edad493502a7>)[#text("(46)")]#text(", namely ")#metadata(none) <tao-147f22f0449f7157256e>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(49)")])
#mitex("(c_1, r) = (hq^{\\prime}_1q^{\\prime}_2-h^{\\prime}q_1q_2, r).")]]

#text("We apply Corollary ")#link(<tao-f562267f2b6d890a7c0c>)[#text("10")]#text(" as before, although things are not quite as favorable because ")#mi("{d_1,d_2}")#text(" need not be coprime in this case. This bounds the left-hand side of ")#link(<tao-a5a678fbc88d625d311d>)[#text("(48)")]#text(" by")

#align(center)[#tao-fit-display[#mitex("\\ll x^{o(1)} ( (d_1 d_2)^{1/2} + \\frac{N (d_1,d_2)^2}{d_1 d_2} (c_1,d_1) (c_2,d_2) ).")]]

#text("We have")

#align(center)[#tao-fit-display[#mitex("d_1 d_2 \\leq q_1 q^{\\prime}_1 r q_2 q^{\\prime}_2 \\ll Q^4 R")]]

#text("which is controlled by the first term on the right-hand side of ")#link(<tao-a5a678fbc88d625d311d>)[#text("(48)")]#text(". So it remains to show that")

#align(center)[#tao-fit-display[#mitex("\\frac{(d_1,d_2)^2}{d_1 d_2} (c_1,d_1) (c_2,d_2) \\ll H Q^6 R^{-1}.")]]

#text("We crudely bound ")#mi("{(c_2,d_2)}")#text(" by ")#mi("{d_2}")#text(" and ")#mi("{(c_1,d_1)}")#text(" by ")#mi("{(c_1,r) \\frac{d_1}{r}}")#text("; also")

#align(center)[#tao-fit-display[#mitex("(d_1,d_2) \\leq (q_1q^{\\prime}_1, q_2 q^{\\prime}_2) \\ll Q^2")]]

#text("and from ")#link(<tao-147f22f0449f7157256e>)[#text("(49)")]#text(" one has ")#mi("{(c_1,r) \\ll H Q^2}")#text(". The claim follows.")

#heading(level: 1)[#text("Comments (75)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/938039d8e9e20d3403dabd878685e0a6cc6fc81b9b3309ceae13ebeab92a29d2-85d65adada1ad6d83af1efd1431260184f7ed203e46c2001c73e4c1c44fd9983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mttpd")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234217")[#strong[#text("mttpd")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Shouldn’t that be “n” instead of “x” in the RHS of (1)?")#linebreak()#text(" // Argument of the log function.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/938039d8e9e20d3403dabd878685e0a6cc6fc81b9b3309ceae13ebeab92a29d2-85d65adada1ad6d83af1efd1431260184f7ed203e46c2001c73e4c1c44fd9983.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mttpd")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234219")[#strong[#text("mttpd")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Ah, no, just looked at the previous post (“As in previous posts, we let {x} be an asymptotic parameter tending to infinity”). NVM :-)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234252")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Some recording of parameters in the critical case: assuming")

#mi("\\varpi = 1/899 \\approx 0.00111")

#mi("\\delta = 71/154628 \\approx 0.000460")

#text("(following ")#link("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234015")[#text("https://terrytao.wordpress.com/2013/06/10/a-combinatorial-subset-sum-problem-associated-with-bounded-prime-gaps/#comment-234015")]#text(" ) we have")

#mi("\\sigma = 4569/38657 \\approx 0.118193")

#text("and the most critical case of the Type I/II analysis occurs when")

#mi("\\mu \\approx 0")

#mi("N \\approx x^{1/2-\\sigma} \\approx x^{0.381807}")

#mi("M \\approx x^{1/2+\\sigma} \\approx x^{0.618193}")

#mi("R \\approx x^{-\\delta} N \\approx x^{0.381347}")

#mi("Q \\approx x^{1/2+2\\varpi}/R \\approx x^{0.120877}")

#mi("H \\approx Q^2 R/M \\approx x^{0.00491}")

#text("Here one uses the Type I analysis and the non-diagonal case dominates, with the first term on the RHS of (43) giving the main contribution.")

#text("Due to the use of completion of sums, (45) has to gain a factor of ")#mi("H^2 \\approx x^{0.00981}")#text(" over the trivial bound, which it barely does; one is summing a Kloosterman-type sum of period ")#mi("\\approx Q^3 R \\approx x^{0.743979}")#text(" over an interval of scale ")#mi("N \\approx x^{0.381807}")#text(", and the square root cancellation basically estimates this sum by ")#mi("\\approx (Q^3 R)^{1/2} \\approx x^{.371990}")#text(" giving the desired savings of ")#mi("x^{0.00981}")#text(". In principle short Kloosterman sums might improve this (ideally we should get ")#mi("\\sqrt{N}")#text(" bounds and not ")#mi("\\sqrt{Q^3 R}")#text("), but N is already quite close to the square root of ")#mi("Q^3 R")#text(" so it doesn’t look so promising (unless the Chinese remainder theorem can somehow save us…). We also have all the averaging in ")#mi("r, q_1, q_2, q^{\\prime}_2, h, h^{\\prime}, k")#text(" that is just being discarded at present, and possibly one could take more advantage of these parameters, but it’s not clear to me how to do so (incidentally ")#mi("k")#text(" is of size ")#mi("\\approx N/R \\approx x^{0.000460}")#text(").")

#text("Random thought: is there a Burgess type squaring trick for short Kloosterman sums?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234255")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Another observation is that all the moduli involved (e.g. ")#mi("r,q_1,q_2,q^{\\prime}_2")#text(") are very smooth. For instance, since ")#mi("Q \\approx x^{262\\delta}")#text(", we know that ")#mi("q_1,q_2,q^{\\prime}_2")#text(" all have at least 262 prime factors, all of which are quite small. So even though the progression ")#mi("\\{1,\\ldots,N\\}")#text(" is quite short relative to the big modulus ")#mi("Q^3 R")#text(", it is quite long compared to each of the prime divisors of this modulus. But I don’t know of a way to exploit this; Bourgain and Chang have some clever tricks to stretch the Burgess bound for character sums to product spaces in a way that squeezes out additional gains (see ")#link("http://math.ucr.edu/~mcc/paper/138%20BurgessJB.pdf")[#text("http://math.ucr.edu/~mcc/paper/138%20BurgessJB.pdf")]#text(" ) but I have no idea if these ideas also work for Kloosterman sums.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234257")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Maybe something like Theorem 3 of FI, note that they use Holder with 4 in the exponent, but you can take this larger and gain more in some interval lengths (they remark this after Theorem 4, and do so in their Estimates on characters sums, for a related matter).")

#text("But the problem I had with such ideas, is that the sums are not all that “short” when I tried to apply these.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234263")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Luo has a paper on incomplete Burgess estimates for Hyper-Kloosterman sums: ")#link("http://www.sciencedirect.com/science/article/pii/S0022314X9892340X")[#text("http://www.sciencedirect.com/science/article/pii/S0022314X9892340X")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234265")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Shparlinski improves upon Luo, and mentions some related work. ")#link("http://www.sciencedirect.com/science/article/pii/S0022314X06003027")[#text("http://www.sciencedirect.com/science/article/pii/S0022314X06003027")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234266")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("Also a 2010 paper of Karatsuba (posthumously): ")#link("http://link.springer.com/article/10.1134%2FS0001434610090075")[#text("http://link.springer.com/article/10.1134%2FS0001434610090075")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234267")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("It seems that Karatsuba (and Korolev) only save logs, and for quite short sums.")

#text("The most relevant I can find to our situation is Theorem 1 of this paper by Ping Xi: ")#link("http://arxiv.org/pdf/1111.5459‎")[#text("http://arxiv.org/pdf/1111.5459‎")]

#text("The interval has to be as least ")#mi("p^{3/8}")#text(" in length for the result to be nontrivial (he demands the modulus be prime, but that might be technical).")

#text("His bound is ")#mi("L^{1/r}p^{1/2-(3r-1)/4r^2}\\log p")#text(" for any ")#mi("r")#text(" where the interval is length ")#mi("L")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234428")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("This preprint of Ping Xi is not easy to figure out, but it seems that at (6) on pg5 he uses Proposition 1 (from a different preprint) rather than Lemmas 2 and 3 as stated. So the main tool is actually a mean-value result of ")#link("http://arxiv.org/abs/1111.5455")[#text("http://arxiv.org/abs/1111.5455")]#linebreak()#text(" The Theorem 8 there is stated on pg18, but any proof exposition is deemed superfluous (“follow the arguments in this paper”). It also might be nontrivial to pass from prime moduli to composite, as FI note that much of the mess of their Section 1 is to extend as thus. However, if it all works out, it should beat ")#mi("\\sqrt{d_1d_2}")#text(" with ")#mi("(d_1d_2)^{3/16}\\sqrt {N}")#text(" (r=2 case in above formula), which is a win in our target region I think.")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234264")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("A recent preprint of Browning and Haynes does not mention anything other than the Weil bound, and the Hooley conjecture, though the point is slightly different. ")#link("http://arxiv.org/pdf/1204.6374‎")[#text("http://arxiv.org/pdf/1204.6374‎")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f64284d9c4595e03ea31ecd7f4f06eecc235a01ef1d10e8ef622f93a3660d8f-57ec4e7d7b31bf8451a65ff4b2f3adeb35b663a11811b6f561de23e7f86a5dbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaston Rachlou")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234290")[#strong[#text("Gaston Rachlou")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("A clash in terminology is always a bad thing in mathematics. This post contains two different uses of the adjective “smooth” (for coefficient sequences and for numbers). I think this is a good opportunity to definitely chose the adjective “friable” for numbers with small prime factors. See : ")#link("https://blogs.ethz.ch/kowalski/2008/12/08/more-mathematical-terminology-friable/")[#text("https://blogs.ethz.ch/kowalski/2008/12/08/more-mathematical-terminology-friable/")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234294")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("I certainly see where you’re coming from, but in this particular case I think that the two notions of smooth are not in conflict, and in fact if one adopts an “adelic” perspective then there is actually a conceptual overlap between the two notions. A coefficient sequence is smooth if its spectrum avoids large frequencies (as measured in the Archimedean sense); and a number is smooth if its spectrum avoids large primes.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f64284d9c4595e03ea31ecd7f4f06eecc235a01ef1d10e8ef622f93a3660d8f-57ec4e7d7b31bf8451a65ff4b2f3adeb35b663a11811b6f561de23e7f86a5dbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaston Rachlou")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234299")[#strong[#text("Gaston Rachlou")]]#text(size: 9pt, fill: rgb("596477"), " · 12 June 2013")])]

#text("If you vindicate an ambiguous use of “smooth” by an ambiguous use of “spectrum”, you’re likely to win any such debate:-)")

#text("By the way, congratulations for your blog in general and this “bounded gaps” series in particular!")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234380")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("A fair point, but it’s worth mentioning that (as ")#link("http://en.wikipedia.org/wiki/Spectrum_of_a_C*-algebra#Commutative_C.2A-algebras")[#text("observed by Gelfand")]#text("), these two notions of spectrum also have a lot of conceptual overlap: each frequency in the spectrum of a function ")#mi("f")#text(" corresponds to a prime ideal in the associated convolution algebra (of functions formed by convolving ")#mi("f")#text(" with other functions), whereas each prime in the spectrum of an integer ")#mi("n")#text(" corresponds to a prime ideal in the associated cyclic group ")#mi("{\\bf Z}/n{\\bf Z}")#text(". Thus in both cases the spectrum is the ")#link("http://en.wikipedia.org/wiki/Spectrum_of_a_ring")[#text("spectrum of a commutative ring")]#text(" that is naturally associated to the object.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f64284d9c4595e03ea31ecd7f4f06eecc235a01ef1d10e8ef622f93a3660d8f-57ec4e7d7b31bf8451a65ff4b2f3adeb35b663a11811b6f561de23e7f86a5dbd.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gaston Rachlou")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234402")[#strong[#text("Gaston Rachlou")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("Interesting! I am just still a bit puzzled as I tend to think about the set of prime divisors of ")#mi("n")#text(" more as the support of ")#mi("n")#text(" than as its spectrum. But, after all, this could be consistent with your identification of ")#mi("n")#text(" with the self-dual group ")#mi("\\mathbb{Z}/n\\mathbb{Z}")#text(".")

#text("So, you almost convinced me:-( Nevertheless, I still prefer “friable”, which has a more direct, almost visual, explanation.")
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/26e9c260291bf03be0ccb1490144a331365cfba656e16ae7c5685c3359361303-0dfe5f7e91931659ae303e3fde9212e715c4ca1b2813e5eee003534e035ee35b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eytan Paldi")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234400")[#strong[#text("Eytan Paldi")]]#text(size: 9pt, fill: rgb("596477"), " · 13 June 2013")])]

#text("This post should be added to the list of the polymath posts.")

#emph[#text("[Done, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2b9eda2558d5600a51e77983ac544b19be7082bb35cff57525d4c894bbcee842-2694b509de9d64d3577779b6df007dbbfc03a94b3403e60e819f63520c0172c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of CraigH")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234496")[#strong[#text("CraigH")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("Another followup question: MPZ[")#mi("\\varpi, \\delta")#text("] is a statement about the absolute deviation of ")#mi("\\theta(n)")#text(". What other number-theoretic functions can we make a similar statement about?")#linebreak()#text(" For example, could we take ")#mi("\\theta^{\\prime}(n) = \\log n")#text(" for ")#mi("n")#text(" prime 1 mod 4 (and 0 elsewhere)? If so, we could try to tailor admissible sets with ")#mi("k_0")#text(" elements such that the first ")#mi("k_0/2")#text(" of them are 1 mod 4, and the rest are 3 mod 4, and that would effectively divide the width by two.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Estimation of the Type III sums | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-234520")[#strong[#text("Estimation of the Type III sums | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 14 June 2013")])]

#text("[…] post, which deals with the combinatorial aspects of the second part of Zhang’s paper, and this previous post, that covers the Type I and Type II sums.) The main purpose of this post is to present (and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of A truncated elementary Selberg sieve of Pintz | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235111")[#strong[#text("A truncated elementary Selberg sieve of Pintz | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 18 June 2013")])]

#text("[…] in the proof of . Indeed, if one inspects the proof of this proposition (described in these three previous posts), one sees that the key property of needed is not so much the smoothness, but a weaker […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235308")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 June 2013")])]

#text("I am thinking that if we exploit the smoothness of the moduli, we can get (in some cases) better bounds from the incomplete Kloosterman-type sums by using Weyl differencing rather than by using completion of sums, in the spirit of what Zhang did for the Type III sums.")

#text("Let me illustrate this with the model problem of getting a non-trivial bound")

#mi("\\sum_{1 \\leq n \\leq N} e_q( a n + b \\overline{n} )  1_{(n,q)=1} = o(N)")

#text("for an incomplete Kloosterman sum over some squarefree modulus ")#mi("q")#text(", with ")#mi("a,b")#text(" coprime to ")#mi("q")#text(". The usual completion of sums method, combined with the Weil bound on Kloosterman sums, gives a non-trivial estimate of ")#mi("q^{1/2+o(1)}")#text(" for ")#mi("N \\ggg \\sqrt{q}")#text(", but does not give any non-trivial bound for ")#mi("N \\ll \\sqrt{q}")#text(". But if we have a good factorisation ")#mi("q = q_1 q_2")#text(" with ")#mi("q_1,q_2")#text(" in the right places, we can do better through Weyl differencing. Namely, suppose ")#mi("q_1 \\lll N  \\lll q_2")#text(", then by shifting ")#mi("n")#text(" by ")#mi("n + kq_1")#text(" where ")#mi("1 \\leq k \\leq K")#text(" and ")#mi("K = o( N / q_1 )")#text(", we can basically write the sum we want as")

#mi("\\frac{1}{K} \\sum_{1 \\leq n \\leq N} \\sum_{1 \\leq k \\leq K} e_q( a (n+kq_1) + b \\overline{n+kq_1} ) 1_{(n+kq_1,q)=1}")

#text("so after Cauchy-Schwarz and throwing away the diagonal term (acceptable as long as ")#mi("K \\ggg 1")#text(") it suffices to show that")

#mi("\\sum_{1 \\leq k \\leq K} | \\sum_{1 \\leq n \\leq N} e_q( a(n+kq_1) + b \\overline{n+kq_1} - an - b \\overline{n} )")

#mi("1_{(n,q)=(n+kq_1,q)=1}| = o(KN).")

#text("We can simplify the phase as")

#mi("e_q( akq_1 - \\frac{bq_1}{n(n+kq_1)} )")

#text("which collapses to a ")#mi("q_2")#text(" phase:")

#mi("e_{q_2}( ak - \\frac{b}{n(n+kq_1)} )")#text(".")

#text("NOW if we do completion of sums, the inner sum")

#mi("\\sum_{1 \\leq n \\leq N} e_{q_2}( ak - \\frac{b}{n(n+kq_1)} ) 1_{(n,q)=(n+kq_1,q)=1}")

#text("should be bounded by ")#mi("O(q_2^{1/2+o(1)})")#text(" (possibly times a factor of ")#mi("(k,q_2)")#text(", but this is negligible after averaging),. and so we get a non-trivial bound whenever we have a factorisation ")#mi("q=q_1 q_2")#text(" with")

#mi("q_2^{1/2}, q_1 \\lll N \\lll q_2")

#text("which (if ")#mi("q")#text(" is smooth) lets one get non-trivial bound for ")#mi("N")#text(" almost as small as ")#mi("q^{1/3}")#text(" rather than ")#mi("q^{1/2}")#text(".")

#text("Now, this sort of gain isn’t quite the type of gain we need to improve the Type I sums at the critical numerology; instead of trying to improve the trivial bound for very short Kloosterman sums (length less than ")#mi("q^{1/2}")#text("), our problem is closer to that of improving the completion of sums bound for moderate length Kloosterman sums (length greater than ")#mi("q^{1/2}")#text("). But it may be that one can flip one to the other via a Fourier transform. (Admittedly Kloosterman sums don’t Fourier transform as nicely as character sums, which I am more used to, so I may be a bit naive here, but still I think there is hope.)")

#text("More generally, I think one of the lessons of the Zhang analysis is that we really should be exploiting the smooth nature of our moduli whenever we can. Because of this the apparently “simpler” case of prime moduli may actually be a bit misleading; problems (such as estimating short Kloosterman sums) which are difficult for prime moduli may actually be a lot easier for smooth moduli due to the very flexible Weyl differencing technique that is available in this case.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235415")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("OK, the Fourier analysis wasn’t actually so bad. The new model problem is to obtain a bound on moderately long Kloosterman sums of the form")

#mi("\\sum_n \\psi_N(n) e_q( a \\bar{n} ) 1_{(n,q)=1} = O( q^{1/2-\\varepsilon+o(1)} )")#text(" (*)")

#text("for some ")#mi("\\varepsilon > 0")#text(", where ")#mi("q")#text(" is squarefree and smooth, ")#mi("a")#text(" is coprime to ")#mi("q")#text(", ")#mi("\\psi_N")#text(" is a smooth cutoff to an interval of length N, and ")#mi("N")#text(" is a bit larger than ")#mi("q^{1/2}")#text(" (the method described below gives a non-trivial bound basically for ")#mi("N")#text(" between ")#mi("q^{1/2}")#text(" and ")#mi("q^{2/3}")#text("). Note that completion of sums, together with the Weil bound on completed Kloosterman sums, only gives the bound of ")#mi("O(q^{1/2+o(1)})")#text(", so we are beating the methods used by Zhang, in a regime of interest. (But, as per Corollary 10 above, we will eventually also need to stick in an additional phase ")#mi("e_{q^{\\prime}}( a^{\\prime} \\overline{n+l} )")#text(" into the analysis.)")

#text("Anyway, by completion of sums or Poisson summation the LHS can be written as")

#mi("\\frac{1}{q} \\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\hat \\psi_N(\\frac{h}{q}) S(h,a; q)")

#text("where ")#mi("S(h,a;q)")#text(" is the completed Kloosterman sum")

#mi("S(h,a;q) := \\sum_{n \\in ({\\bf Z}/q{\\bf Z})^\\times} e_q( a \\bar{n} + h n )")

#text("and ")#mi("\\hat \\psi_N")#text(" is the Fourier transform")

#mi("\\hat \\psi_N(\\theta) := \\sum_n \\psi_N(n) e(-n\\theta).")

#text("Our objective is thus to show")

#tao-math("\\left|\\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\hat \\psi_N(\\frac{h}{q}) S(h,a; q)\\right| \\ll q^{3/2-\\varepsilon+o(1)}", block: false)#text(" (**)")

#text("which is a power saving over the Weil bound and standard bounds on ")#mi("\\hat \\psi_N")#text(" (which has amplitude about ")#mi("N")#text(" and is concentrated on about ")#mi("q/N")#text(" frequencies).")

#text("We factor ")#mi("q=q_1q_2")#text(" where ")#mi("q_1,q_2")#text(" are to be determined later.")

#text("We now perform Weyl differencing, replacing ")#mi("h")#text(" by ")#mi("h + k q_1")#text(" for ")#mi("1 \\leq k \\leq K")#text(", where ")#mi("K := \\lfloor q^{-\\varepsilon} q_2 / N \\rfloor")#text(". We assume that ")#mi("K \\geq q^{2\\varepsilon}")#text(", so that")

#mi("N \\ll q^{-3\\varepsilon} q_2")#text(".")

#text("Up to acceptable errors (exploiting the smooth nature of ")#mi("\\hat \\psi_N")#text(" at scale ")#mi("q/N")#text("), the LHS of (**) can then be rewritten as")

#mi("\\frac{1}{K} |\\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\sum_{1 \\leq k \\leq K} \\hat \\psi_N(\\frac{h+kq_1}{q}) S(h+kq_1,a; q)|.")

#text("From Lemma 7 we may factorise")

#mi("S(h+kq_1,a;q) = S(h/q_2,a/q_2; q_1) S(h/q_1 + k,a/q_1; q_2)")#text(".")

#text("By the Weyl bound, ")#mi("S(h/q_2,a/q_2; q_1) = O( q_1^{1/2+o(1)} )")#text(", so we may bound the previous expression by")

#mi("\\frac{q_1^{1/2+o(1)}}{K} \\sum_{h \\in {\\bf Z}/q{\\bf Z}} | \\sum_{1 \\leq k \\leq K} \\hat \\psi_N(\\frac{h+kq_1}{q}) S(h/q_1+k,a/q_1; q_2)|.")

#text("We can restrict ")#mi("h")#text(" to the range ")#mi("h=O(q^{1+o(1)}/N)")#text(" since ")#mi("\\hat \\psi_N")#text(" is negligible outside of this range. By Cauchy-Schwarz, it then suffices to show")

#tao-math("\\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\left| \\sum_{1 \\leq k \\leq K} \\hat \\psi_N(\\frac{h+kq_1}{q}) S(h/q_1+k,a/q_1; q_2)\\right|^2", block: false)

#mi("\\ll q^{-2\\varepsilon+o(1)} N q q_2 K^2.")

#text("Note that this goal represents a saving of ")#mi("q^{-2\\varepsilon}")#text(" over the Weil bound and standard bounds on ")#mi("\\hat \\psi_N")#text(". Expanding out the square and removing the diagonal ")#mi("k=k^{\\prime}")#text(" (which is acceptable since ")#mi("K \\gg q^{2\\varepsilon}")#text("), we reduce to showing that")

#tao-math("\\left|\\sum_{h \\in {\\bf Z}/q{\\bf Z}} \\hat \\psi_N(\\frac{h+kq_1}{q}) \\overline{\\hat \\psi_N}(\\frac{h}{q}) S(h/q_1+k,a/q_1; q_2) \\overline{S(h/q_1,a/q_1;q_2)}\\right|", block: false)

#mi("\\ll q^{-2\\varepsilon+o(1)} N q q_2")

#text("on the average for ")#mi("1\\leq k \\leq K")#text(". Writing ")#mi("h = h_1 q_2 + h_2 q_1")#text(" for ")#mi("h_i \\in {\\bf Z}/q_i {\\bf Z}")#text(", the left-hand side becomes")

#mi("|\\sum_{h_1 \\in {\\bf Z}/q_1{\\bf Z}} \\sum_{h_2 \\in {\\bf Z}/q_2{\\bf Z}} \\hat \\psi_N(\\frac{h_2+k}{q_2} + \\frac{h_1}{q_1}) \\overline{\\hat \\psi_N}(\\frac{h_2}{q_2} + \\frac{h_1}{q_1})")

#mi("S(h_2+k,a/q_1; q_2) \\overline{S(h_2,a/q_1;q_2)}|.")

#text("After some Fourier manipulation to evaluate the ")#mi("h_1,h_2")#text(" sums, we may write this as")

#mi("q_1 q_2 |\\sum_{n,m: n=m\\ (q_1)} \\psi_N(n) \\overline{\\psi_N(m)} \\sum_{n_2,m_2 \\in ({\\bf Z}/q_2{\\bf Z})^\\times: n_2-m_2 = n-m\\ (q_2)}")

#mi("e_{q_2} ( (n_2-n) k + \\bar{n_2} a/q_1 - \\bar{m_2} a/q_1 )|.")

#text("From Weil, the inner sum is (I think) bounded by ")#mi("O( q_2^{1/2+o(1)} )")#text(" (possibly times a factor of ")#mi("(k,q_2)")#text(" which is negligible after averaging in ")#mi("k")#text("), and if we assume ")#mi("N \\gg q_1")#text(", then we get a net bound of ")#mi("O( N^2 q_2^{3/2+o(1)} )")#text(", which gives the desired power saving in the regime")

#mi("q_1 \\ll N \\ll q^{-3\\varepsilon} q_2, q^{-2\\varepsilon} q_1 q_2^{1/2}")

#text("which in the smooth case allows one to take ")#mi("N")#text(" nearly as large as ")#mi("q^{2/3-3\\varepsilon}")#text(" by choosing ")#mi("q_1,q_2")#text(" close to ")#mi("q^{1/3}, q^{2/3}")#text(" respectively.")

#text("In principle the same sort of argument should work to get an improvement to Corollary 10 above, which in turn should lead to improvements in the Type I analysis. I haven’t checked the numerology and details yet though.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235428")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Just to get started on the numerology in the critical case: it’s looking like ")#mi("\\sigma=1/10")#text(" is going to be the key threshold, which upon setting ")#mi("\\delta \\approx 0")#text(" gives ")#mi("\\varpi = 1/220")#text(". We then have ")#mi("N \\approx x^{0.4}")#text(" and ")#mi("M \\approx x^{0.6}")#text(", and ")#mi("d = qr \\approx x^{1/2+2\\varpi}")#text(". ")#mi("r \\sim R")#text(" is taken close to ")#mi("N")#text(", so ")#mi("q \\sim Q \\approx x^{0.1 +2 \\varpi}")#text(", then ")#mi("H \\approx Q^2 R / M \\approx x^{4\\varpi}")#text(". In the Type I analysis, ")#mi("d_1 \\approx QR \\approx x^{1/2+2\\varpi}")#text(" and ")#mi("d_2 \\approx Q^2 \\approx x^{0.2 + 4 \\varpi}")#text(". The key sum that needs estimating is ")#mi("\\sum_n \\psi_N(n) 1_{(n,d_1)=(n+kr,d_2)=1} e_{d_1}(\\frac{c_1}{n}) e_{d_2}(\\frac{c_2}{n+kr})")#text(", where ")#mi("d_1,d_2")#text(" are coprime. The trivial bound is ")#mi("N \\approx x^{0.4}")#text(" and the Weil + completion of sums bound is ")#mi("(d_1 d_2)^{1/2+o(1)} \\approx x^{0.35 + 3 \\varpi}")#text(" (plus an extra term which is lower order), a saving of ")#mi("x^{1/20 - 3 \\varpi}")#text(", which matches the loss ")#mi("H^2 \\approx x^{8\\varpi}")#text(" coming from completion of sums compounded by Cauchy-Schwarz when ")#mi("\\varpi=1/220")#text(". So any improvement of the Weil + completion of sums bound here will lead to an improvement in the Type I analysis.")

#text("We have ")#mi("N \\approx (d_1 d_2)^{\\frac{0.4}{0.7 + 6\\varpi}} = (d_1 d_2)^{0.55}")#text(". ")#mi("0.55")#text(" is less than ")#mi("2/3")#text(", so I am optimistic that the methods from the previous comment will lead to some gain here. Still have to check the gory details, though…")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235450")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("I realised that with regards to the exponential sum")

#mi("S_N(c_1,c_2,a;d_1,d_2) := \\sum_n \\psi_N(n) 1_{(n,d_1)=(n+a,d_2)=1} e_{d_1}( \\frac{c_1}{n} ) e_{d_2}( \\frac{c_2}{n+l} )")

#text("we already ")#emph[#text("have")]#text(" a convenient factorisation ")#mi("d_1 d_2")#text(" of the modulus available so we don’t even need any smoothness hypothesis to improve upon Corollary 10 of the post (= Lemma 11 of Zhang) in the regime of interest – Weyl differencing (conjugated by a Fourier transform) already basically improves the ")#mi("(d_1 d_2)^{1/2}")#text(" main term in Corollary 10 to ")#mi("N^{1/2} d_1^{1/4} + N^{1/2} d_2^{1/2}")#text(" in the range ")#mi("d_2 \\ll N \\ll d_1")#text(", which is the range of interest here. This should propagate to a new value of ")#mi("\\varpi")#text(", but I’ll do that in the next comment. For now, the details of the above claimed bound.")

#text("I’ll need first a Weyl-type bound on completed exponential sums, namely that")

#tao-math("\\left| \\sum_{n \\in ({\\bf Z}/p{\\bf Z}): n \\neq 0,-l} e_p( \\frac{c_1}{n} + \\frac{c_2}{n+l} + c_3 n)\\right| \\ll \\sqrt{p}", block: false)

#text("except in the degenerate case ")#mi("c_3 = a = c_1 - c_2 = 0\\ (p)")#text(", in which case one only gets the trivial bound of ")#mi("p")#text(". I’m pretty sure this claim follows from the Riemann hypothesis for curves (plus some ad hoc computations in partially degenerate cases), so I’ll just take it for granted. By the Chinese remainder theorem it implies that")

#tao-math("\\left| \\sum_{n \\in ({\\bf Z}/q{\\bf Z}): (n,q)=(n+l,q)=1} e_q( \\frac{c_1}{n} + \\frac{c_2}{n+l} + c_3 n)\\right|", block: false)

#mi("\\ll q^{1/2+o(1)} ( c_3,l,c_1-c_2,q)^{1/2}.")#text(" (1)")

#text("Now we return to estimation of the sum ")#mi("S_N(c_1,c_2,l;d_1,d_2)")#text(", assuming that ")#mi("d_1,d_2")#text(" are squarefree and coprime, and that")#linebreak()#text(" ")#mi("d_2 \\ll N \\ll d_1")#text(". We follow the previous strategy of Weyl differencing conjugated by the Fourier transform. First, the Fourier transform lets us write ")#mi("S_N(c_1,c_2;l;d_1,d_2)")#text(" as")

#mi("\\frac{1}{d_1 d_2} \\sum_{h \\in {\\bf Z}/d_1 d_2{\\bf Z}} \\hat \\psi_N(\\frac{h}{d_1 d_2}) S(c_1,c_2,l,h; d_1,d_2)")

#text("where ")#mi("S(c_1,c_2,l,h;d_1,d_2)")#text(" is the complete Kloosterman-type sum")

#mi("S(c_1,c_2,l,h;d_1,d_2) := \\sum_{n \\in {\\bf Z}/d_1 d_2 {\\bf Z}} e_{d_1}(\\frac{c_1}{n}) e_{d_2}(\\frac{c_2}{n+l}) e_{d_1 d_2}(hn)")

#text("where for brevity we adopt the convention that ")#mi("e_{d_1}(\\frac{c_1}{n})")#text(" vanishes when the denominator ")#mi("n")#text(" is not coprime to the modulus ")#mi("d_1")#text(", and similarly for ")#mi("e_{d_2}(\\frac{c_2}{n+a})")#text(".")

#text("Next, we perform Weyl shifting, replacing ")#mi("h")#text(" by ")#mi("h+kd_2")#text(" for ")#mi("1 \\leq k \\leq K")#text(" and ")#mi("K := \\lfloor d_1 /N \\rfloor")#text(". The previous expression is then equal to")

#mi("\\frac{1}{K d_1 d_2} \\sum_{h \\in {\\bf Z}/d_1 d_2{\\bf Z}} \\sum_{k=1}^K")

#mi("\\hat \\psi_N(\\frac{h+kd_2}{d_1 d_2}) S(c_1,c_2,l,h+kd_2;d_1 d_2)")#text(".")

#text("The ")#mi("h=0")#text(" term contributes ")#mi("O( \\frac{N}{d_1 d_2} (c_1,d_1) (c_2,d_2)")#text(" exactly as in the main post and we now delete this term.")

#text("Now from the Chinese remainder theorem we have the twisted multiplicativity law")

#mi("S(c_1,c_2,l,h+kd_2;d_1 d_2) = e_{d_2}( - h l / d_1 ) S( h/d_2 + k, c_1; d_1)")

#mi("S( h/d_1, c_2; d_2)")#text(".")

#text("Here ")#mi("S(b,c;d)")#text(" are the usual completed Kloosterman sums. Using the Weil bound on the ")#mi("S( h/d_1, c_2; d_2)")#text(" factor, we can bound the previous expression in magnitude by")

#mi("\\frac{x^{o(1)}}{K d_1 d_2^{1/2}} \\sum_{h \\in {\\bf Z}/d_1 d_2{\\bf Z}: h \\neq 0} (h,c_2,d_2)^{1/2} |\\sum_{k=1}^K")

#mi("\\hat \\psi_N(\\frac{h+kd_2}{d_1 d_2}) S(h/d_2+k,c_1;d_1)|.")

#text("From the rapid decay of ")#mi("\\hat \\psi_N")#text(" we may localise ")#mi("h = O( x^{o(1)} d_1 d_2 ./ N )")#text(". We have")

#mi("\\sum_{h = O( x^{o(1)} d_1 d_2 / N ): h \\neq 0} (h,c_2,d_2) \\ll x^{o(1)} d_1 d_2 / N")

#text("so by Cauchy-Schwarz we may bound the previous expression by")

#mi("\\frac{x^{o(1)}}{K d_1^{1/2} N^{1/2}} ( \\sum_{h \\in {\\bf Z}/d_1 d_2{\\bf Z}} |\\sum_{k=1}^K")

#mi("\\hat \\psi_N(\\frac{h+kd_2}{d_1 d_2}) S(h/d_2+k,c_1;d_1)|^2)^{1/2}.")

#text("Expanding out, we encounter a diagonal term ")#mi("k=k^{\\prime}")#text(" which, if one applies the Weil bound on Kloosterman sums together with the decay bounds on ")#mi("\\hat \\psi_N")#text(", eventually gives a bound of ")#mi("x^{o(1)} K^{-1/2} (d_1 d_2)^{1/2} = x^{o(1)} N^{1/2} d_2^{1/2}")#text(" (gaining ")#mi("K^{-1/2}")#text(" over the “trivial” bound, which is typical for a diagonal contribution in Weyl differencing). Now we restrict to the off-diagonal terms ")#mi("k \\neq k^{\\prime}")#text(". Performing the ")#mi("h")#text(" summation first using Fourier analysis, one eventually arrives at")

#mi("\\frac{x^{o(1)} d_2^{1/2}}{K N^{1/2}} | \\sum_{n,n^{\\prime}: n = n^{\\prime}\\ (d_2)} \\psi_N(n) \\overline{\\psi_N}(n^{\\prime})")

#mi("\\sum_{1 \\leq k,k^{\\prime} \\leq K: k \\neq k^{\\prime}} \\sum_{n_1,n^{\\prime}_1 \\in {\\bf Z}/d_1{\\bf Z}: n-n^{\\prime} = n_1-n^{\\prime}_1\\ (d_1)}")

#mi("e_{d_1}( \\frac{c_1}{n_1} + k n_1 - \\frac{c_1}{n^{\\prime}_1} - k^{\\prime} n^{\\prime}_1 ) |^{1/2}.")

#text("By (1), the innermost summation (over ")#mi("n_1,n^{\\prime}_1")#text(") is ")#mi("O( x^{o(1)} d_1^{1/2} (k-k^{\\prime},d_1)^{1/2})")#text(". Inserting this bound and performing all the summations, one eventually arrives at ")#mi("O( x^{o(1)} N^{1/2} d_1^{1/4} )")#text(". Thus one has shown the following improvement to Corollary 10:")

#tao-math("\\left|S_N(c_1,c_2,l; d_1,d_2)\\right| \\ll x^{o(1)} ( N^{1/2} d_1^{1/4}  + N^{1/2} d_2^{1/2}", block: false)

#mi("+ \\frac{N}{d_1 d_2} (c_1,d_1) (c_2,d_2))")

#text("when ")#mi("d_1,d_2")#text(" are squarefree coprime and ")#mi("d_2 \\ll N \\ll d_1")#text(".")

#text("It is possible that one could improve upon this bound by using smoothness and working with a different factorisation than the factorisation ")#mi("d_1 d_2")#text(" that is naturally provided in Corollary 10, but this would be a bit messier and I will avoid doing that for now.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235473")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Incidentally, I now have a reference for the Weil type bound for exponentials of rational functions that I needed: Perelmuter (1969), ")#link("http://www.ams.org/mathscinet-getitem?mr=241424")[#text("http://www.ams.org/mathscinet-getitem?mr=241424")]#text(" . (This type of estimate can also be proven by Stepanov’s method: see Cochrane-Pinner (2006), ")#link("http://www.ams.org/mathscinet-getitem?mr=2195926")[#text("http://www.ams.org/mathscinet-getitem?mr=2195926")]#text(" .")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235648")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("I am confused when you say “Next, we perform Weyl shifting, replacing h by h+kd_2” as the next display seems (twice) to shift h by ")#mi("h+kd_1")#text(". One of these is corrected(?) a few lines later, but not the other?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235654")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Just thinking aloud, if one possessed say higher-dim Deligne at hand, would Holder win more than Cauchy with this shift? This is often feasible in Burgess analysis.(however, Ping Xi seemed to max out at ")#mi("r=2")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235663")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("I am not so sure that this divisibility is something like a red hering, for now. If you plain had ")#mi("d_2=1")#text(" you would still win via the Weyl shift in this ")#mi("(N,d)")#text(" range, according in your notes as somewhat like to the method of FI (they only fail to achieve much enough gain in Type III methinks? ). Though of course the divisibility and Zhang shift should be induced for greater gains if possible. But really here, you “just” worked a short Kloosterman bound, if I am correct, with the ")#mi("d_2")#text(" divisor effect largely negligent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235679")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Sorry about that, the shift should be by kd_2 throughout, I edited the comment accordingly.")

#text("I’m almost done with a post detailing these bounds a bit more carefully (in particular the refinement to Zhang Lemma 11 in the comments below did not quite treat some lower order terms properly, though fortunately this did not affect the dominant terms and ultimately did not affect ")#mi("\\varpi,\\delta")#text(" numerology). The case of short character sums is slightly simpler than that of short Kloosterman sums so I am giving that example instead in the post.")

#text("Certainly there is scope to play with these methods further and get even better bounds, e.g. by combining carefully chosen Weyl differencing with a Burgess argument.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235463")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Now it’s time to trace this improvement of Corollary 10 back through the rest of the argument. Let me first note that the new bound of ")#mi("x^{o(1)} ( N^{1/2} d_1^{1/4} + N^{1/2} d_2^{1/2} + \\frac{N}{d_1 d_2} (c_1,d_1) (c_2,d_2) )")#text(" was only proven in the range ")#mi("d_2 \\ll N \\ll d_1")#text(", but trivially holds outside this range also: when ")#mi("N \\gg d_1")#text(" then ")#mi("N^{1/2} d_2^{1/2} \\gg d_1^{1/2} d_2^{1/2}")#text(" and one can use the existing Corollary 10, while for ")#mi("N \\ll d_2")#text(" one has ")#mi("N^{1/2} d_2^{1/2} \\gg N")#text(" and one can use the trivial bound of ")#mi("O(N)")#text(". So the new bound in fact holds universally in ")#mi("N")#text(".")

#text("In the post, if we estimate the left-hand side of (45) using the new version of Corollary 10, we obtain an upper bound of")

#mi("\\ll x^{o(1)} ( N^{1/2} d_1^{1/4} + N^{1/2} d_2^{1/2} + \\frac{N}{d_1 d_2} (c_1,d_1) (c_2,d_2) )")

#text("which by using the bounds given near the end of Section 7 come out to")

#mi("\\ll x^{o(1)} ( N^{1/2} Q^{1/4} R^{1/4} + N^{1/2} Q + H Q R^{-1} N ).")

#text("giving an improvement to (45). The off-diagonal contribution to (44) is then")

#mi("\\ll x^{o(1)} ( H^2 N^{1/2} Q^{9/4} R^{1/4} + H^2 N^{1/2} Q^3 + H^3 Q^3 R^{-1} N )")

#text("so we win when")

#mi("H^2 N^{1/2} Q^{9/4} R^{1/4} \\ll x^{-2\\varepsilon+o(1)} Q^2 N")

#mi("H^2 N^{1/2} Q^3 \\ll x^{-2\\varepsilon+o(1)} Q^2 N")

#text("and")

#mi("H^3 Q^3 R^{-1} N \\ll x^{-2\\varepsilon+o(1)} Q^2 N")#text(".")

#text("Using (37), (9) these become")

#mi("(QR)^{17/4} \\ll x^{2-4\\varepsilon+o(1)} N^{1/2} (R/N)^2")

#mi("(QR)^5 \\ll x^{2-4\\varepsilon+o(1)} N^{3/2} (R/N)^3")

#mi("(QR)^7 \\ll x^{3-5\\varepsilon+o(1)} N^2 (R/N)^5")

#text("which from (24), (23), (10) reduces to")

#mi("\\frac{17}{8} + \\frac{17}{2} \\varpi < \\frac{9}{4} - \\frac{1}{2} \\sigma - 2\\mu - 2 \\delta")

#mi("\\frac{5}{2} + 10 \\varpi < \\frac{11}{4} - \\frac{3}{2} \\sigma - 3 \\mu - 3 \\delta")

#mi("\\frac{7}{2} + 14 \\varpi < 4 - 2 \\sigma - 5 \\mu - 5 \\delta")

#text("which we rearrange as")

#mi("17 \\varpi + \\sigma + 4 \\mu  + 4 \\delta < \\frac{1}{4}")

#mi("20 \\varpi + 3 \\sigma + 6 \\mu  + 6 \\delta <  \\frac{1}{2}")

#mi("14 \\varpi + 2 \\sigma + 5 \\mu + 5 \\delta < \\frac{1}{2}.")

#text("The third condition is implied by the second and may be dropped. These conditions replace (41) in Theorem 13 and are superior basically because they allow ")#mi("\\sigma")#text(" to be as large as 1/6 now instead of 1/8.")

#text("Following the arguments back to Theorem 3, we now see that we may replace (7) by the two essentially weaker conditions")

#mi("17 \\varpi + 4\\delta + \\sigma <  \\frac{1}{4}")#text(" (1′)")

#text("and")

#mi("20 \\varpi + 6\\delta + 3\\sigma <  \\frac{1}{2 }")#text(". (2′)")

#text("From the Type II analysis we have an additional constraint")

#mi("37 \\varpi + 5 \\delta < \\frac{1}{4}")#text(" (3′)")

#text("which could probably be improved with the new version of Corollary 10, but we won't do so here.")

#text("On the other hand, the Type III analysis currently works when")

#mi("\\frac{13}{2} (\\frac{1}{2} + \\sigma) > 4 + 16 \\varpi + \\delta")#text(" (4′)")

#text("and we also need the combinatorial constraint")

#mi("\\sigma > 1/10")#text(". (5′)")

#text("Playing (5′) off of (1′) and (2′) gives the constraints")

#mi("17 \\varpi + 4 \\delta < \\frac{1}{5}")#text(" (6′)")

#mi("20 \\varpi + 6 \\delta < \\frac{1}{5};")#text(" (7′)")

#text("(6′) is implied by (7′) and so may be dropped. Playing (4′) off of (1′), (2′) gives the additional constraints")

#mi("253 \\varpi + 54 \\delta < \\frac{7}{4}")#text(" (8′)")

#text("and")

#mi("178 \\varpi + 52 \\delta < 1")#text(". (9′)")

#text("(3′), (7′) and (8′) are implied by (9′) and may be dropped. So I claim that ")#mi("MPZ^{\\prime}[\\varpi,\\delta]")#text(" holds whenever")

#mi("178 \\varpi + 52 \\delta < 1")#text(".")

#text("But of course I should double-check all the computations here, there is plenty of scope for numerical error.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235465")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Actually, one should be able to do better than this, because I was using the older Type III estimate, not the newer Type III estimate that also takes advantage of ")#mi("\\alpha")#text(" averaging. Recalculating…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235467")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Recomputing the previous calculation with the improved Type III analysis. As stated in")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/14/estimation-of-the-type-iii-sums/")[#text("Estimation of the Type III sums")]
]

#text("this improvement replaces the condition")

#mi("\\frac{13}{2} (\\frac{1}{2}+\\sigma) > 4 + 16 \\varpi + \\delta")#text(" (4′)")

#text("by the combination of")

#mi("5 (\\frac{1}{2}+\\sigma) > 3 + 16 \\varpi + \\delta")#text(" (1”)")

#text("and")

#mi("\\frac{9}{2} (\\frac{1}{2} + \\sigma) > \\frac{5}{2} + 10 \\varpi + \\delta")#text(" (2”).")

#text("So now we need to play (1”), (2”) off of (1′), (2′) to replace (8′), (9′) with the new constraints")

#mi("101\\varpi + 21 \\delta < \\frac{3}{4}")#text(" (3'')")

#mi("148 \\varpi + 33 \\delta < 1")#text(" (4'')")

#mi("173 \\varpi + 38 \\delta < \\frac{7}{4}")#text(" (5'')")

#mi("80 \\varpi + 20 \\delta < 1")#text(". (6'')")

#text("The constraint (4'') implies (3''), (5''), (6''), (3') (barely!), and (7'), so I now claim (somewhat nervously) that ")#mi("MPZ^{\\prime}[\\varpi,\\delta]")#text(" holds whenever")

#mi("148 \\varpi + 33 \\delta < 1")#text(".")

#text("This is extremely tentative though; it is quite likely that there is at least one typo in the above (but hopefully the typos only affect secondary constraints and not the primary one). I will have to think about how to write things up so that it is easier to chase through the numerology. (I guess I will have to write up another blog post to try to describe the latest version of the argument.)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/9369a6abd185064e7974333b68ba6ab7e3e7a8345976ff0d35cd1991b6c7ecd7-8fae52720750ea4e4596c7b69853de2282645b16ae7d971f3f4ff48a99452402.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Roberts")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235468")[#strong[#text("David Roberts")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("So what k_0 do we get from these two new bounds on \\varpi?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235476")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 20 June 2013")])]

#text("Have to run, but I can do a quick projection: ")#mi("\\varpi")#text(" was previously close to 1/348, but with the latest bound (if it holds up) it will become close to 1/148 (since we now know that delta is essentially negligible), a multiplicative gain of 2.35. Ever since the Bessel function technology was introduced, ")#mi("k_0")#text(" scales like ")#mi("\\varpi^{-3/2}")#text(", so it should improve by about ")#mi("(2.35)^{3/2}")#text(", so from 5,452 to about 1,512. For this range of ")#mi("k_0")#text(" we now have tables in place for the best known H for such a k_0; specifically, ")#mi("k_0 =1512")#text(" gives ")#mi("H=12432")#text(", see ")#link("http://www.opertech.com/primes/webdata/k1000-1999/k1500-1599/")[#text("http://www.opertech.com/primes/webdata/k1000-1999/k1500-1599/")]#text(" . But this is all just a rough calculation…")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235542")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("I have rederived (mostly independently) 1′ and 3”, and 5” using 2” (which I never checked) from your “new bound” (which I have yet to check yet). I haven’t digested the post enough to figure out the ")#mi("\\mu")#text("-numerology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235544")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("I’ve lost the net thread of the arguments, but I do think that ")#mi("148\\omega+33\\delta\\le 1")#text(" is correct arithmetic. What exactly is the purpose of this ")#mi("\\mu")#text(" (besides to set it equal to 0)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235545")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("If it all works, ")#mi("k_0=1471")#text(" with ")#mi("\\omega=1/148-7/400000, \\delta^{\\prime}=1/170,A=2000")#text(".")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235546")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#mi("k_0=1470")#text(" with ")#mi("\\omega=1/148-5.9/400000, \\delta^{\\prime}=1/245,A=2100")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235550")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("Combining this with the newly set up systematic tables at ")#link("http://www.opertech.com/primes/webdata/")[#text("http://www.opertech.com/primes/webdata/")]#text(" and ")#link("http://math.mit.edu/~drew/records2.txt")[#text("http://math.mit.edu/~drew/records2.txt")]#text(" , this gives H = 12,042.")

#text("Double-checked your computation using Maple (taking advantage of Gergely and Eytan’s exact formulae for Bessel integrals). It checks out: ")#mi("2\\kappa_1+2\\kappa_2+2\\kappa_3")#text(" has to be bounded by ")#mi("0.132 \\times 10^{-5}")#text(", but is instead about ")#mi("0.123 \\times 10^{-5}")#text(". As usual, ")#mi("\\kappa_1 \\approx 0.603 \\times 10^{-6}")#text(" dominates, with ")#mi("\\kappa_2 \\approx 0.355 \\times 10^{-8}")#text(" well behind and ")#mi("\\kappa_3 \\approx 0.931 \\times 10^{-392}")#text(" again negligible.")

#linebreak()#text(" varpi := 1/148 - 5.9/400000;")#linebreak()#text(" k0 := 1470;")#linebreak()#text(" deltap := 1/245;")#linebreak()#text(" A := 2100;")

#text("delta := (1 - 148 * varpi) / 33;")#linebreak()#text(" theta := deltap / (1/4 + varpi);")#linebreak()#text(" thetat := (deltap - delta + varpi) / (1/4 + varpi);")#linebreak()#text(" deltat := delta / (1/4 + varpi);")

#text("j := BesselJZeros(k0-2,1);")

#text("eps := 1 - j^2 / (k0 * (k0-1) * (1+4*varpi));")

#text("kappa1 := int( (1-t)^((k0-1)/2)/t, t = theta..1, numeric);")#linebreak()#text(" kappa2 := (k0-1) * int( (1-t)^(k0-1)/t, t=theta..1, numeric);")

#text("e := exp( A + (k0-1) * int( exp(-A*t)/t, t=deltat..theta, numeric ) );")

#text("# using Gergely's exact expression for denominator")#linebreak()#text(" gd := (j^2/2) * BesselJ(k0-3,j)^2;")

#text("# using Eytan's exact expression for numerator")#linebreak()#text(" tn := sqrt(thetat)*j;")#linebreak()#text(" gn := (tn^2/2) * (BesselJ(k0-2,tn)^2 - BesselJ(k0-3,tn)*BesselJ(k0-1,tn));")

#text("kappa3 := (gn/gd) * e;")

#text("eps2 := 2*(kappa1+kappa2+kappa3);")

#text("# we win if eps2 < eps")#linebreak()
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235553")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("If I use these better bounds on ")#mi("\\kappa_3")#text(", I think I get ")#mi("k_0=1465")#text(" for ")#mi("\\omega=1/148-1/10^7,\\delta^{\\prime}=1/200,A=2400")#text(". This is best possible, even if the ")#mi("\\kappa,\\delta")#text(" did not exist.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235555")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("Unfortunately Maple is not confirming these numbers. ")#mi("2\\kappa_1+2\\kappa_2+2\\kappa_3")#text(" has to not exceed ")#mi("0.301 \\times 10^{-6}")#text(". We have ")#mi("\\kappa_1 = 0.361 \\times 10^{-7}")#text(" and ")#mi("\\kappa_2 := 0.153 \\times 10^{-10}")#text(" which is fine, but I’m getting ")#mi("\\kappa_3 = 0.159 \\times 10^{2589}")#text(" which is not fine. The exponential factor ")#mi("\\exp( A + (k_0-1) \\int_{\\tilde \\delta}^\\theta e^{-At}/t\\ dt )")#text(" is coming out as ")#mi("0.529 \\times 10^{4159}")#text(", while the Bessel numerator is ")#mi("0.242 \\times 10^{-1568}")#text(" and the denominator is ")#mi("80.3")#text(". Could there be a typo in your choice of parameters? For instance A does not appear to be optimal here (I accidentally entered in A=2400 and got a better bound on the exponential factor).")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235557")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("It seems to me that the numer/denom of the Bessel-integral quotient is so small that the ")#mi("A")#text(" parameter ends up being pointless. You can take ")#mi("A=0")#text(" if you want, I think. Although a diversion, ")#mi("A\\approx3.35")#text(" or about seems to minimize ")#mi("\\kappa_3")#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235558")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("OK, I found my typo, e(-A*t/t) instead of e(-A*t)/t… Sorry")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235548")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("Great, thanks!")

#mi("\\mu")#text(" is the quantity such that the factor ")#mi("r")#text(" of ")#mi("d")#text(" lies in the range")

#mi("x^{-\\delta} R \\leq r \\leq R")

#text("where ")#mi("R := x^{-\\mu} N")#text(". In (7.1), (7.2) of Zhang, ")#mi("\\mu")#text(" is set to be ")#mi("\\varepsilon")#text(" (i.e. infinitesimal) in the Type I case and equal to ")#mi("3\\varpi")#text(" in the Type II case (actually ")#mi("2\\varpi+\\varepsilon")#text(" would have worked here). So, yes, ")#mi("\\mu")#text(" can be ignored for the Type I analysis (although it plays a more non-trivial, but still minor, role in the Type II analysis).")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7233df3455422a04c8de943146c9cf3876cdf8eaaf118735cb28d6a89fc0de60-35787e42e334b199dfe6e428fe8aa02444b754aa373b5df4208c0fcd3a75c19b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of v08ltu")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235559")[#strong[#text("v08ltu")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("OK, try this again… ")#mi("\\omega=1/148-24/4000000,\\delta^{\\prime}=1/200,k_0=1467,A=1300")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235563")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2013")])]

#text("This one I can confirm :-). ")#mi("2\\kappa_1+2\\kappa_2+2\\kappa_3")#text(" has to be at most ")#mi("0.5922 \\times 10^{-6}")#text(", but is ")#mi("0.707 \\times 10^{-7}")#text(", with the overly sensitive ")#mi("\\kappa_3")#text(" now being ")#mi("0.453 \\times 10^{-24}")#text(". From tables, ")#mi("k_0=1467")#text(" gives ")#mi("H=12012")#text(".")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235650")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("I am a physisist, but I am interested in your project. Since \\kappa_i (i=1,2,3) is very small, can you rescale these quantities with some characterstic quantity, such that the rescaled \\kappa_{i} is not small, and the corresponding round-off error can be much reduced?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235694")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("Unfortunately, the ")#mi("\\kappa")#text(" quantities are dimensionless and cannot be rescaled. (Actually for number theory there is not much dimensional analysis available in general, because the fundamental domain of study is the integers (or natural numbers), which do not have any natural scaling (or, if you wish, it has a natural unit, namely 1).)")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf9f5133b77dc3c04d20269fe344d39f651a5dde17a0f8f6a11c1babebc89ab-972541ffe5a339311b9c69b12a779c0eecd6fce99594522bd0b7bc21d56694c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235807")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Gentlemen, H = 12012 and still falling. How low you can go with these methods?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235851")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Let’s at least hope they get to 11832, which in an almost completely meaningless sense would be half way from Zhang to the actual twin primes conjecture!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ebf9f5133b77dc3c04d20269fe344d39f651a5dde17a0f8f6a11c1babebc89ab-972541ffe5a339311b9c69b12a779c0eecd6fce99594522bd0b7bc21d56694c2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Tom")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235866")[#strong[#text("Tom")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("2^26 = 67108864, 2^13 = 8192, 2^1 = 2.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/682a3803378c2a4a01a7b351520d18ffe874a6f4abf0ee606e627c926e7c0042-9d7cc899594adb3f442075a2c983b3292b1e87d11dd2da9c43696595ffd1f2c8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Aubrey de Grey")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235880")[#strong[#text("Aubrey de Grey")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("Not sure why there is no “Reply” link at the bottom of Tom’s reply to mine, but: Tom, if your comment is meant to imply that my mention of 11832 as the symbolic half-way mark was incorrect, please note that 13+13-26 is 0, not 1. 11832 is simply sqrt(2*70000000).")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235690")[#strong[#text("Bounding short exponential sums on smooth moduli via Weyl differencing | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 22 June 2013")])]

#text("[…] Proof: See Lemma 7 of this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235920")[#strong[#text("The distribution of primes in densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("[…] for instead of . Inserting Theorem 4 into the Pintz sieve from this previous post gives for (see this blog comment), which when inserted in turn into newly set up tables of narrow prime tuples gives infinitely many […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235934")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 23 June 2013")])]

#text("In order to try to stop the discussion from fragmenting too much, I’m rolling both this Type I/II thread and the Type III thread into a single new thread at")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#link("https://terrytao.wordpress.com/2013/06/23/the-distribution-of-primes-in-densely-divisible-moduli/")[#text("The distribution of primes in densely divisible moduli")]
]

#text("which has the latest version of both arguments that incorporate all of the recent improvements to Zhang’s argument, in particular the use of the q-analogue of the van der Corput lemma to improve the exponential sums in the Type I/II analysis, and the use of alpha-averaging to improve the Type III analysis.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-236206")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("General question to anyone interested.")

#text("In Lemma 6, how much can one weaken the assumption that ")#mi("\\psi_M")#text(" is smooth? In particular, for what types of convolutions ")#mi("\\alpha_1\\ast \\alpha_2 \\ast \\cdots \\ast \\alpha_n")#text(" of functions ")#mi("\\alpha_i")#text(" coming from the Heath-Brown identity does Lemma 6 not apply?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-236216")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 25 June 2013")])]

#text("This is a good question! I think there are partial analogues of Lemma 6 in some cases but the bounds are weaker.")

#text("Roughly speaking, when dealing with a sum such as ")#mi("\\sum_n \\psi_M(n) f(n)")#text(" where ")#mi("f")#text(" is periodic of some period ")#mi("d > N")#text(", one should think of ")#mi("\\psi_M")#text(" as having a Fourier expansion roughly of the form")

#mi("\\psi_M(n) \\approx \\frac{M}{d} \\sum_{h = O(d/M)} e_d( hn ).")#text(" (*)")

#text("Here I am deliberately being vague as to what summation over ")#mi("h=O(d/M)")#text(" means. If one uses a sharp cutoff ")#mi("-d/M \\leq h \\leq d/M")#text(" then one gets a Dirichlet kernel at scale ")#mi("M")#text(" rather than a smooth compactly supported cutoff ")#mi("\\psi_M")#text("; if one inserts a Fejer weight one gets a Fejer kernel, and similarly for de Vallee-Poussin kernels, etc. To get a compactly supported kernel ")#mi("\\psi_M")#text(" one needs a weight which is not completely localised in the range ")#mi("h=O(d/M)")#text(", but is instead rapidly decreasing outside of this range.")

#text("If one pretends that (*) is a rigorous formula then one easily gets Lemma 6 as a consequence (and the real proof of Lemma 6 basically proceeds through a rigorous analogue of (*)).")

#text("Anyway, now suppose we replace ")#mi("\\psi_M")#text(" by ")#mi("\\alpha * \\psi_{N_2}")#text(" where ")#mi("M = N_1 N_2")#text(" and ")#mi("\\alpha")#text(" is some coefficient sequence at scale ")#mi("N_1")#text(". The same heuristic that gives (*) also gives")

#mi("\\psi_{N_2}(n) \\approx \\frac{N_2}{d} \\sum_{h = O(d/N_2)} e_d( hn ).")

#text("and hence")

#mi("\\alpha * \\psi_{N_2}(n) \\approx \\frac{N_2}{d} \\sum_{m = O(N_1)} \\alpha(m) \\sum_{h = O(d/N_2)} e_d( hn / m )")

#text("at least if we restrict ")#mi("\\alpha")#text(" to those integers coprime to ")#mi("d")#text(" for simplicity. If ")#mi("N_1 \\ll N_2 \\ll d")#text(", then the set of fractions ")#mi("h/m\\ (d)")#text(" in ")#mi("{\\bf Z}/d{\\bf Z}")#text(" with ")#mi("m = O(N_1)")#text(" and ")#mi("h = O(d/N_2)")#text(" has multiplicity ")#mi("d^{o(1)}")#text(" (from the divisor bound) and is thus spread out over a set of cardinality ")#mi("\\approx N_1 d / N_2 = N_1^2 d / M^2")#text(". So one can get a partial analogue of Lemma 6 in this case, in which one sums over ")#mi("N_1^2")#text(" times as many frequencies ")#mi("h")#text(", but divides by an additional ")#mi("N_1")#text(", for a net “loss” of ")#mi("N_1")#text(" over Lemma 6 applied to ")#mi("\\psi_M")#text(" (or one can think of this assertion as an averaged version of Lemma 6 applied to ")#mi("\\psi_{N_2}")#text(", in which case one is no longer losing anything and is in fact gaining (in principle, at least) because of the additional frequency averaging).")

#text("Incidentally this sort of “averaged completion of sums” shows up in the Type III analysis, and is the main source of our current improvement over Zhang’s Type III bound.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/55b7e5f6a903fb728f9ea14dd8471ba2d4d873e99f0b3711bcfcfb0c43c95a34-1db116e8d7e764af1fdfb3cf825e94d1d3f08f23fbf4757d2064dbc07b2de48b.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of சொல்வனம் » பகா எண் இடைவெளிகளின் எல்லைகள் – யீடாங் சாங், இருளைப் பிளந்த மின்னல் கீற்று")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-236691")[#strong[#text("சொல்வனம் » பகா எண் இடைவெளிகளின் எல்லைகள் – யீடாங் சாங், இருளைப் பிளந்த மின்னல் கீற்று")]]#text(size: 9pt, fill: rgb("596477"), " · 28 June 2013")])]

#text("[…] ")#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235545")[#text("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-235545")]#text(" […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-236724")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 29 June 2013")])]

#text("A comment and some typos:")

#text("1. Before Lemma 7 it should be emphasized that an expression ")#mi("e_q(\\frac{a}{b})")#text(" always means ")#mi("e_q(a\\bar{b})")#text(". This is because it is customary to use the notation ")#mi("e_q(x)")#text(" for any ")#mi("x\\in\\mathbb{R}")#text(", in which case division is meant in the ordinary sense. For example, without this warning, ")#mi("e_{q_1}( \\frac{b_1 h}{q_2} ) e_{q_2}( \\frac{b_2 h}{q_1} )")#text(" in Lemma 7 could be mistaken for ")#mi("e_{q_1q_2}( b_1 h ) e_{q_1q_2}( b_2 h )")#text(".")

#text("2. In the proof of Lemma 7, “")#mi("a")#text(" mod ")#mi("h")#text("” should be “")#mi("a")#text(" mod ")#mi("q_1q_2")#text("“, and ")#mi("e_d( b_1 q_2 \\bar{q_2} + b_2 q_1 \\bar{q_1})")#text(" should be ")#mi("e_d(b_1 h q_2 \\bar{q_2} + b_2 h q_1 \\bar{q_1})")#text(".")

#text("3. In the second display below (14), ")#mi("\\sum_{m = a_i\\ (d)}")#text(" should be ")#mi("1_{m=a_i\\ (d)}")#text(". In the next display, the factor ")#mi("\\frac{1}{d}")#text(" is missing.")

#text("4. In the fifth display below (14), ")#mi("\\hat\\psi( M + \\frac{Mh}{d} )")#text(" should be ")#mi("\\hat\\psi( Mn + \\frac{Mh}{d} )")#text(".")

#text("5. In (29), ")#mi("n=a_r")#text(" should be ")#mi("mn=a_r")#text(".")

#text("6. In the fourth display below (34), ")#mi("q_0^2")#text(" should be ")#mi("q_0^{-2}")#text(".")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bounded gaps between primes (Polymath8) – a progress report | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-236882")[#strong[#text("Bounded gaps between primes (Polymath8) – a progress report | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("[…] sketch of Zhang’s argument for establishing Type I estimates (details may be found at these two posts). It is based on previous arguments of Bombieri, Friedlander, and Iwaniec, relying on […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-236889")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 30 June 2013")])]

#text("Your new blog entry tells me you arrived safely. Welcome! Two small comments and some typos:")

#text("1. In the proof of Lemma 5, I would emphasize for the sake of the reader that the vanishing of ")#mi("\\sum_n \\psi(n/N) \\chi\\overline{\\chi^{\\prime}}(n)")#linebreak()#text(" follows by representing the nontrivial character ")#mi("\\chi\\overline{\\chi^{\\prime}}(n)")#text(" as a linear combination of ")#mi("e_{qq^{\\prime}}(rn)")#text(" with ")#mi("r\\not\\equiv 0\\ (qq^{\\prime})")#text(", and then applying Poisson summation for each subsum ")#mi("\\sum_n \\psi(n/N) e_{qq^{\\prime}}(rn)")#text(".")

#text("2. The inequality (16) and the preceding text might give the impression that it covers Theorem 8 for ")#mi("m=q=p^j")#text(" and ")#mi("(ab,p)=1")#text(". This is only true for ")#mi("j=1")#text(", since otherwise summing over ")#mi("({\\bf Z}/q{\\bf Z})^\\times")#text(" is different from summing over ")#mi("{\\bf F}_q^\\times")#text(". So I would add that for ")#mi("j\\geq 2")#text(" there is an elementary treatment that goes back to Salié.")

#text("3. In Theorem 4, ")#mi("x \\ll M,N \\ll x")#text(" should be ")#mi("x \\ll MN \\ll x")#text(".")

#text("4. In the last display of the proof of Lemma 5, ")#mi("\\sum_{\\chi^{\\prime}\\ (q)}^*")#text(" should be ")#mi("\\sum_{\\chi^{\\prime}\\ (q^{\\prime})}^*")#text(", and ")#mi("\\overline{c^{\\prime}_{\\chi}}")#text(" should be ")#mi("\\overline{c_{\\chi^{\\prime}}}")#text(".")

#text("5. In (12) and the next display, ")#mi("\\alpha\\beta")#text(" should be ")#mi("\\alpha\\ast\\beta")#text(".")

#text("6. In the second display below (12), ")#mi("\\chi(m)")#text(" and ")#mi("\\chi(n)")#text(" should be ")#mi("\\psi(m)")#text(" and ")#mi("\\psi(n)")#text(".")

#text("7. In the proof of Theorem 8, ")#mi("{\\bf F}_q^n")#text(" should be ")#mi("{\\bf F}_{q^n}")#text(": 3 occurrences.")

#text("8. In the last display of the proof of Theorem 8, ")#mi("\\sum_\\psi \\alpha_\\psi^n +\\beta_\\psi^n")#text(" should be ")#mi("\\sum_{\\psi\\neq\\psi_0} (\\alpha_\\psi^n +\\beta_\\psi^n)")#text(".")

#text("9. In the first display of the proof of Lemma 9, ")#mi("\\frac{b_2}{n}")#text(" should be ")#mi("\\frac{b_2}{n+l}")#text(".")

#text("10. In the sixth display of the proof of Lemma 9, ")#mi("e_{t_1}( \\frac{b_2}{n+l} + m_2 n )")#text(" should be ")#mi("e_{t_2}( \\frac{b_2}{n+l} + m_2 n )")#text(".")

#text("11. In the proof of Corollary 10, the conditions ")#mi("(n,d_1)=(n+l,d_2)=1")#text(" are missing under the three sums ")#mi("\\sum_{n \\in {\\bf Z}/d{\\bf Z}}")#text(".")

#text("12. In the second display of the proof of Corollary 10, the factor ")#mi("(d_1,d_2)")#text(" should be omitted.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237019")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("It seems that #6 has not been implemented. Note that “second display below (12)” really means “7 lines below (12)”. Also, in the last display of the proof of Theorem 8, I would put ")#mi("\\alpha_\\psi^n +\\beta_\\psi^n")#text(" into parentheses for clarity.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237080")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 1 July 2013")])]

#text("Just a few more typos:")

#text("1. The ")#mi("n")#text(" on the RHS of (6) should be ")#mi("x")#text(".")

#text("2. On the line below (10), the ")#mi("\\varpi")#text(" should be ")#mi("\\delta")#text(".")

#text("3. In Lemma 5, “whee” should be “where”.")

#text("4. Gergely’s point #6 above.")

#text("5. Three displays later, both of the ")#mi("=1")#text(" should be in the subscripts. (One already is.)")

#text("6. In (14), both in the first and third lines, ")#mi("c(d)")#text(" should be ")#mi("c(n)")#text(".")

#text("7. In the second line of the proof of Theorem 8, “needed our application” is missing the word “in”.")

#text("8. I believe that the second to last display of Lemma 9 is missing a factor of ")#mi("d_0")#text(". This factor thus also seems to be missing from the first term in the bound of Corollary 10 (since it is missing in the third to last, and then last, displayed equations of the proof). I don’t know how much further this missing factor propagates.")

#text("9. It might be helpful to define ")#mi("d")#text(" in the statement of Corollary 10 (rather than in the first line of the proof), so that in the display the summation can be over ")#mi("n\\in {\\bf Z}/d{\\bf Z}:(n,d_1)=(n+l,d_2)=1")#text(".")

#text("10. In the sentence before Section 5, the last ")#mi("r^{\\prime}")#text(" should just be ")#mi("r")#text(".")

#text("————–")

#text("I’ll try to finish reading the second half of the post tomorrow.")

#text("My impression of how the third display after (22) is established, is first to break the sum into a dyadic decompositions, then use Corollary 12, and the ")#mi("O(1)")#text(" comes (mostly) from the number of terms in the dyadic breakdown.")

#emph[#text("[Thanks for the corrections! Regarding point 8, the ")#mi("d_0")#text(" is buried in the ")#mi("d_1^{1/2} d_2^{1/2} = d_0 t_1^{1/2} t_2^{1/2}")#text(" factor. Regarding point 9, the initial sum is over integers ")#mi("n")#text(", but completion of sums converts this to sums over ")#mi("{\\bf Z}/d{\\bf Z}")#text(". And yes, this is how the third display after (22) is established. -T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237237")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 2 July 2013")])]

#text("Only made it through another quarter of the post, but here are some comments.")

#text("1. In the third display after (28), on the LHS the condition ")#mi("(n,q)=1")#text(" is redundant. It was actually helpful for me to have the condition there, but it also might be helpful to mention the redundance.")

#text("2. A few sentences before (33), it says “For fixed ")#mi("n_1, n_2")#text(" obeying…” and later it says “For fixed ")#mi("n_1\\sim N")#text(",…”. I would recommend changing the word “fixed” to “any given” (to avoid confusion with being fixed with respect to ")#mi("x")#text(").")

#text("3. In the third display above (33), it took me a while to figure out how the controlled multiplicity hypothesis was being applied. I think one transforms ")#mi("\\tau_{b}(mn_1)")#text(" to ")#mi("\\tau_{n_1^{-1}b}(m)")#text(" (essentially, replacing the old singleton congruence class system with a new one where we multiply by the inverse of ")#mi("n")#text(" modulo ")#mi("q")#text(" whenever possible). If that is correct, it might be good to say a word about why this new system still has controlled multiplicity.")

#text("4. In (34), I recommend changing ")#mi("\\geq")#text(" to ")#mi("\\gg")#text(" (to avoid trivial technicalities later when plugging in ")#mi("\\mu=2\\varpi +c")#text(").")

#text("5. In the sentence following (39), change “As noted after Lemma 13” to “As noted after Lemma 6” (the link is to equation (13), contained in Lemma 6).")

#text("6. In the sentence after (40) which reads “Indeed, from (33) and (9) one has…”, change (33) to (23). Then in the next two displays, replace ")#mi("c")#text(" by ")#mi("\\mu")#text(".")

#text("7. Directly before Theorem 13, change ")#mi("M,M")#text(" to ")#mi("M,N")#text(".")

#text("8. In the second paragraph after Theorem 14, there is a sentence which begins “By (7), (8) we can simultaneously…” The condition (8) is superfluous here.")

#text("9. I recommend either changing the next sentence to read: “Note that (43) is weaker than (41), so we can now suppose instead that we are in the “Type II” regime…” OR change the statement of Theorem 14 to include the assumption that (42) fails.")

#text("10. The computation following Theorem 14 shows that the ")#mi("39")#text(" in equation (6) should be ")#mi("29")#text(". (This new constant matches what I saw on the wiki.)")

#emph[#text("[Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237311")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("I can follow your argument involving controlled multiplicity now. Thanks for clarifying that. Here are the remainder of the comments/questions.")

#text("1. For the display following “For the diagonal case, we make the crude bound”, I believe the RHS should have an extra factor of ")#mi("\\log^{O(1)}x")#text(" (or just ")#mi("x^{o(1)}")#text(").")

#text("2. In the display which says ")#mi("x^{\\frac{7}{2}+7\\varpi} \\ll x^{3-5\\epsilon-5\\mu-3\\delta+o(1)}N^2")#text(", change ")#mi("7\\varpi")#text(" to ")#mi("14\\varpi")#text(", and also change ")#mi("3\\delta")#text(" to ")#mi("5\\delta")#text(". (Fortunately, these changes do not affect any later computations.)")

#text("3. Two displays later, on the second line of that display where it has ")#mi("b^{\\prime}_{q_2^{\\prime}}h")#text(", the ")#mi("h")#text(" should be ")#mi("h^{\\prime}")#text(". A similar change should be made to the display following (46).")

#text("4. Three displays after (46), the ")#mi("h,h^{\\prime}")#text(" are missing in the definition of ")#mi("c_2")#text(".")

#text("5. In Section 7, when it says “From we have” you can add “crude bounds” (or, “the divisor bound”) inbetween.")

#text("6. On the RHS of (48), there are parentheses missing (")#mi("x^{o(1)}")#text(" needs to multiply both factors).")

#text("7. In the fourth display above (49), on the second line the second ")#mi("b_{q_1}")#text(" should be ")#mi("b_{q_1}^{\\prime}")#text(". On the third line, the second ")#mi("h")#text(" should be ")#mi("h^{\\prime}")#text(".")

#text("8. On the last line of the display above (49) (where ")#mi("c_1")#text(" is being defined) there is a prime missing in the subscript of the ")#mi("b")#text(", and another prime missing from ")#mi("h")#text(".")

#text("———")

#text("When dealing with the Type I sum, when performing the Cauchy-Schwarz the choice is made to pull out the sum on ")#mi("q_1")#text(". What is the reason we don’t pull out the sum on ")#mi("q_2")#text(" as well?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237388")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 3 July 2013")])]

#text("Thanks for the corrections!")

#text("Regarding Cauchy-Schwarz, there is a lot of flexibility in what we pull outside of the Cauchy-Schwarz, and what stays inside (and gets “doubled”, e.g. from ")#mi("\\sum_{q_2}")#text(" to ")#mi("\\sum_{q_2,q^{\\prime}_2}")#text("). But one has to balance the “diagonal” terms and the “off-diagonal” terms, both to be small in order to win. If one pulls too much stuff outside the Cauchy-Schwarz then the diagonal terms get too big, but if one puts too much stuff inside then the off-diagonal terms get too big. (Some of the more recent refinements to the Type I sums have come by striking a better balance in this regard.)")

#text("If we pull both the ")#mi("q_1,q_2")#text(" sums outside then only the ")#mi("h")#text(" summation gets doubled. But then the diagonal contribution (which becomes ")#mi("h=h^{\\prime}")#text(" instead of ")#mi("hq^{\\prime}_2 = h^{\\prime}q_2")#text(") only saves us a factor of ")#mi("H^{-1}")#text(" (instead of ")#mi("(HQ)^{-1}")#text(") over the trivial bound, when we actually need to save ")#mi("H^{-2}")#text(". (The off-diagonal terms become a lot better, of course, but I don’t know how to exploit that when the diagonal terms are so bad.)")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237492")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")])]

#text("Some typos:")

#text("1. Four displays before (49), ")#mi("e_{q^{\\prime}_1}( -\\frac{b_{q_1} h^{\\prime})}{nrq^{\\prime}_2})")#text(" should be ")#mi("e_{q^{\\prime}_1}( -\\frac{b_{q^{\\prime}_1} h^{\\prime}}{nrq^{\\prime}_2})")#text(", and ")#mi("e_{q^{\\prime}_2}( -\\frac{b^{\\prime}_{q^{\\prime}_2} h}{(n+kr) r q_1} )")#text(" should be ")#mi("e_{q^{\\prime}_2}( -\\frac{b^{\\prime}_{q^{\\prime}_2} h^{\\prime}}{(n+kr) r q^{\\prime}_1} )")#text("; one typo in the first expression, two typos in the second one.")

#text("2. In the display before (49), ")#mi("- b_{q_1} \\bar{r} \\bar{q^{\\prime}_2} h \\frac{d_1}{q^{\\prime}_1}")#text(" should be ")#mi("- b_{q^{\\prime}_1} \\bar{r} \\bar{q^{\\prime}_2} h^{\\prime} \\frac{d_1}{q^{\\prime}_1}")#text("; two typos here. Also, this display would look better in two lines instead of three.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/714f9ef5d4b6eabb12a38768b478b8e060619a220d51eb18631650608b361092-5c6fa6c6b125450496dbb5c4356ce947f88bb4a5be634575c08b303e3487062e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Gergely Harcos")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237494")[#strong[#text("Gergely Harcos")]]#text(size: 9pt, fill: rgb("596477"), " · 4 July 2013")])]

#text("Forgot one:")

#text("3. In Line 6 of Section 7, “From we have” should be “From the divisor bound we have” (with link to the divisor bound).")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bcda9a0cddc829d7196551da91bf88d7e027843e29ce57ad05c8c8cbda20ecb5-82aa5ee39fffce3d5ae577f2e6700c3da1d53b8ef78de9d228c00baeae3ea0df.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237524")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("Is there a natural multidimensional analog of the “Completion of Sums” lemma? In particular, I’m looking for simplifications for a sum of the form")

#mi("\\sum_{m,m^{\\prime}}\\psi_{M}(m)\\psi_{M^{\\prime}}(m^{\\prime})\\sum_{i\\in I: mm^{\\prime}=a_i\\ (d)}c_i")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/08be7e2ca4ef5a0df94d8b768e99c69a3684b45448137112061fec7825372377-ee7e474ba2a4dd83473477a0c11a980e946a0317cce3a642270544b2615ae672.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pace Nielsen")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237544")[#strong[#text("Pace Nielsen")]]#text(size: 9pt, fill: rgb("596477"), " · 5 July 2013")])]

#text("From reading a few more comments on different threads, it appears that there is such an analog, but we run into the problem of higher dimensional Kloosterman sums.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The distribution of primes in doubly densely divisible moduli | What's new")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-237793")[#strong[#text("The distribution of primes in doubly densely divisible moduli | What's new")]]#text(size: 9pt, fill: rgb("596477"), " · 7 July 2013")])]

#text("[…] Proof: See Lemma 7 of this previous post. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/20c985f4eb5b5439d87e013f49140a9244f2ca5360859433cf56b46a07daccf3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Stefan Campbell Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-277418")[#strong[#text("Stijn Stefan Campbell Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2014")])]

#text("Sorry, I’ve been looking this over again and could you maybe explain a bit more why the case ")#mi("D < \\mathcal{L}^C")#text(" is acceptable in the proof of Bombieri-Vinogradov (ii)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-277457")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 21 March 2014")])]

#text("As I said in the post, the argument here is similar to the treatment of the ")#mi("D \\leq {\\mathcal L}^C")#text(" case of (i). If you could describe our own efforts to prove the estimate and where precisely you got stuck, I could be more able to try to diagnose the issue.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/12d404f409cfa929ed29832da558e59e322a910f2349ed86fa2a0156ac3d68b3-f5319c27a8a51bad81caeabb1ffdc72dd296a73ee1f426e1c462e7b42269eff6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Stijn Stefan Campbell Hanson")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-277567")[#strong[#text("Stijn Stefan Campbell Hanson")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2014")])]

#text("So we have the bound on the ")#mi("\\beta")#text(" sum using Siegel-Walfisz (I think, I’m not too clear on the precise steps) but how do we combine this with the ")#mi("\\alpha")#text(" sum? Also would we still need to use the crude estimates, in which case which ones as it wouldn’t be the same same one, surely?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2013/06/12/estimation-of-the-type-i-and-type-ii-sums/#comment-277607")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2014")])]

#text("Use Siegel-Walfisz to bound the term ")#tao-math("\\left|\\sum_n \\beta \\psi(n)1_{(n,e)}=1\\right|", block: false)#text(", and crude estimates to bound the sum ")#tao-math("\\left|\\sum_m \\alpha \\psi(m) 1_{(m,e)}\\right|", block: false)#text(", and then continue using crude estimates to bound all of the terms that appear afterwards. Since the Siegel-Walfisz factor is going to save arbitrarily many powers of ")#mi("\\log x")#text(", it is perfectly safe to lose bounded powers of ")#mi("\\log x")#text(" in all other estimates; thus for instance, once each term in the ")#mi("\\psi")#text(" summation is bounded by some uniform bound ")#mi("X")#text(", the ")#mi("\\psi")#text(" sum may then be crudely bounded by ")#mi("dX \\leq \\log^C X")#text(", since there are at most ")#mi("d")#text(" characters of conductor ")#mi("d")#text(". Similarly, it is safe to discard the ")#mi("\\frac{1}{\\phi(d)}")#text(" factor in this regime. I recommend actually inserting some estimates and seeing what you get; as I said, it doesn’t really matter if you are somewhat inefficient in your estimation because the gain of an arbitrary number of logarithms in Siegel-Walfisz will always rescue you. (See also Strategy 16 and Strategy 15 from ")#link("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")[#text("https://terrytao.wordpress.com/2010/10/21/245a-problem-solving-strategies/")]#text(" , and also my discussion of the value of attempting to partially implement a solution even when you do not yet have the full solution at ")#link("https://plus.google.com/u/1/114134834346472219368/posts/Xdm8eiPLWZp")[#text("https://plus.google.com/u/1/114134834346472219368/posts/Xdm8eiPLWZp")]#text(" .)")
]
]
]
]
