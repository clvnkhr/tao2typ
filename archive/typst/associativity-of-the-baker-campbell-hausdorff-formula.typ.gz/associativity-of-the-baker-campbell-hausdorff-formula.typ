// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/
// Converted to Typst by tao2typ: "2026-10-14T15:18:15.777328+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Associativity of the Baker-Campbell-Hausdorff formula", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Associativity of the Baker-Campbell-Hausdorff formula")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 29 October 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/")[#text("https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Evaluate paired vertical fences as a single native math atom before attaching scripts.
#let tao-lr(..args) = {
  let positional = args.pos()
  if positional.len() == 1 {
    let body = positional.first()
    let children = if body.has("children") { body.children } else { (body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        let inner = children.slice(1, -1).sum(default: [])
        if first.text == "|" { return math.abs(inner, ..args.named()) }
        if first.text == "‖" { return math.norm(inner, ..args.named()) }
      }
    }
  }
  math.lr(..args)
}
#let tao-big(body, size) = {
  // Preserve MiTeX's fixed \big/\Big/\bigg/\Bigg heights for a paired atom.
  if type(body) == content and body.func() == math.lr and body.has("body") {
    let children = if body.body.has("children") { body.body.children } else { (body.body,) }
    if children.len() >= 2 {
      let first = children.first()
      let last = children.last()
      if first.has("text") and last.has("text") and first.text == last.text {
        if first.text == "|" or first.text == "‖" { return tao-lr(body.body, size: size) }
      }
    }
    // Unicode ceil/floor glyphs introduce their own automatic Typst lr group
    // inside MiTeX's explicit lr. Resize the glyph-bearing pair itself.
    let paired = body.body
    while type(paired) == content and paired.func() == math.lr and paired.has("body") {
      paired = paired.body
    }
    return math.lr(paired, size: size)
  }
  math.lr(body, size: size)
}

// TeX ex dimensions use the current font's x-height, not a guessed em ratio.
#import "@preview/mitex:0.2.7": mitex-convert, mitex-scope
#let tao-raisebox(space, body) = context {
  let dimension = if space.has("children") {
    space.children.filter(it => it.has("text")).map(it => it.text).join("").replace(" ", "")
  } else { space.text }
  if dimension.ends-with("ex") {
    let magnitude = float(dimension.slice(0, -2))
    let x-height = measure(text(top-edge: "x-height", bottom-edge: "baseline", "x")).height
    text(baseline: -magnitude * x-height, body)
  } else { mitex-scope.at("raisebox")(space, body) }
}
#let tao-math(source, block: false, ..args) = {
  let converted = mitex-convert(source)
  let body = eval("$" + converted + "$", scope: mitex-scope + (
    raisebox: tao-raisebox, lr: tao-lr,
    big: body => tao-big(body, 1.2em), Big: body => tao-big(body, 1.8em),
    bigg: body => tao-big(body, 2.4em), Bigg: body => tao-big(body, 3em),
  ))
  math.equation(block: block, body, ..args)
}

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("Let ")#mi("{{\\mathfrak g}}")#text(" be a finite-dimensional Lie algebra (over the reals). Given two sufficiently small elements ")#mi("{x, y}")#text(" of ")#mi("{{\\mathfrak g}}")#text(", define the ")#emph[#text("right Baker-Campbell-Hausdorff-Dynkin law")]#text(" ")#metadata(none) <tao-6b4e8b48b0964d5fbcdb>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(1)")])
#mitex("R_y(x) := x + \\int_0^1 F_R( \\text{Ad}_x \\text{Ad}_{ty} ) y \\ dt")]]

#text("where ")#mi("{\\text{Ad}_x := \\exp(\\text{ad}_x)}")#text(", ")#mi("{\\text{ad}_x: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" is the adjoint map ")#mi("{\\text{ad}_x(y) := [x,y]}")#text(", and ")#mi("{F_R}")#text(" is the function ")#mi("{F_R(z) := \\frac{z \\log z}{z-1}}")#text(", which is analytic for ")#mi("{z}")#text(" near ")#mi("{1}")#text(". Similarly, define the ")#emph[#text("left Baker-Campbell-Hausdorff-Dynkin law")]#text(" ")#metadata(none) <tao-10086e7ab26cd4245716>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(2)")])
#mitex("L_x(y) := y + \\int_0^1 F_L( \\text{Ad}_{tx} \\text{Ad}_y ) x\\ dt")]]

#text("where ")#mi("{F_L(z) := \\frac{\\log z}{z-1}}")#text(". One easily verifies that these expressions are well-defined (and depend smoothly on ")#mi("{x}")#text(" and ")#mi("{y}")#text(") when ")#mi("{x}")#text(" and ")#mi("{y}")#text(" are sufficiently small.")

#text("We have the famous ")#link("http://en.wikipedia.org/wiki/Baker-Campbell-Hausdorff_formula")[#text("Baker-Campbell-Hausdoff-Dynkin formula")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 1 (BCH formula)")]#text(" Let ")#mi("{G}")#text(" be a finite-dimensional Lie group over the reals with Lie algebra ")#mi("{{\\mathfrak g}}")#text(". Let ")#mi("{\\log}")#text(" be a local inverse of the exponential map ")#mi("{\\exp: {\\mathfrak g} \\rightarrow G}")#text(", defined in a neighbourhood of the identity. Then for sufficiently small ")#mi("{x, y \\in {\\mathfrak g}}")#text(", one has")

#align(center)[#tao-fit-display[#mitex("\\log( \\exp(x) \\exp(y) ) = R_y(x) = L_x(y).")]]
]

#text("See for instance ")#link("https://terrytao.wordpress.com/2011/09/01/254a-notes-1-lie-groups-lie-algebras-and-the-baker-campbell-hausdorff-formula/")[#text("these notes of mine")]#text(" for a proof of this formula (it is for ")#mi("{R_y}")#text(", but one easily obtains a similar proof for ")#mi("{L_x}")#text(").")

#text("In particular, one can give a neighbourhood of the identity in ")#mi("{{\\mathfrak g}}")#text(" the structure of a local Lie group by defining the group operation ")#mi("{\\ast}")#text(" as ")#metadata(none) <tao-a969fe535ca445c5f6b6>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(3)")])
#mitex("x \\ast y := R_y(x) = L_x(y)")]]

#text("for sufficiently small ")#mi("{x, y}")#text(", and the inverse operation by ")#mi("{x^{-1} := -x}")#text(" (one easily verifies that ")#mi("{R_x(-x) = L_x(-x) = 0}")#text(" for all small ")#mi("{x}")#text(").")

#text("It is tempting to reverse the BCH formula and conclude (the local form of) ")#emph[#text("Lie’s third theorem")]#text(", that every finite-dimensional Lie algebra is isomorphic to the Lie algebra of some local Lie group, by using ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(3)")]#text(" to define a smooth local group structure on a neighbourhood of the identity. (See ")#link("https://terrytao.wordpress.com/2011/08/17/notes-on-local-groups/")[#text("this previous post")]#text(" for a definition of a local Lie group.) The main difficulty in doing so is in verifying that the definition ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(3)")]#text(" is well-defined (i.e. that ")#mi("{R_y(x)}")#text(" is always equal to ")#mi("{L_x(y)}")#text(") and locally associative. The well-definedness issue can be trivially disposed of by using just one of the expressions ")#mi("{R_y(x)}")#text(" or ")#mi("{L_x(y)}")#text(" as the definition of ")#mi("{\\ast}")#text(" (though, as we shall see, it will be very convenient to use both of them simultaneously). However, the associativity is not obvious at all.")

#text("With the assistance of ")#link("http://en.wikipedia.org/wiki/Ado%27s_theorem")[#text("Ado’s theorem")]#text(", which places ")#mi("{{\\mathfrak g}}")#text(" inside the general linear Lie algebra ")#mi("{\\mathfrak{gl}_n({\\bf R})}")#text(" for some ")#mi("{n}")#text(", one can deduce both the well-definedness and associativity of ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(3)")]#text(" from the Baker-Campbell-Hausdorff formula for ")#mi("{\\mathfrak{gl}_n({\\bf R})}")#text(". However, Ado’s theorem is rather difficult to prove (see for instance ")#link("https://terrytao.wordpress.com/2011/05/10/ados-theorem/")[#text("this previous blog post")]#text(" for a proof), and it is natural to ask whether there is a way to establish these facts without Ado’s theorem.")

#text("After playing around with this for some time, I managed to extract a direct proof of well-definedness and local associativity of ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(3)")]#text(", giving a proof of Lie’s third theorem independent of Ado’s theorem. This is not a new result by any means, (indeed, the original proofs of Lie and Cartan of Lie’s third theorem did not use Ado’s theorem), but I found it an instructive exercise to work out the details, and so I am putting it up on this blog in case anyone else is interested (and also because I want to be able to find the argument again if I ever need it in the future).")

#metadata(none) <tao-9feba2bf64462cee8af9>

#text("The key is to observe that the right and left BCH laws commute with each other:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 2 (Commutativity)")]#text(" ")#metadata(none) <tao-078ac4e4ab3872e671c7>#text(" Let ")#mi("{{\\mathfrak g}}")#text(" be a finite-dimensional Lie algebra. Then for sufficiently small ")#mi("{x,y,z}")#text(", one has ")#metadata(none) <tao-f28ddc82da0bb8956bae>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(4)")])
#mitex("L_y(R_z(x)) = R_z(L_y(x)).")]]
]

#text("Note that this commutativity has to hold if ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(3)")]#text(" is to be both well-defined and associative. Assuming Proposition ")#link(<tao-078ac4e4ab3872e671c7>)[#text("2")]#text(", we can set ")#mi("{x=0}")#text(" in ")#link(<tao-f28ddc82da0bb8956bae>)[#text("(4)")]#text(" and use the easily verified identities ")#mi("{R_z(0)=z}")#text(", ")#mi("{L_y(0)=y}")#text(" to conclude that ")#mi("{L_y(z)=R_z(y)}")#text(" for small ")#mi("{y,z}")#text(", ensuring that ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(3)")]#text(" is well-defined; and then inserting ")#link(<tao-a969fe535ca445c5f6b6>)[#text("(3)")]#text(" into ")#link(<tao-f28ddc82da0bb8956bae>)[#text("(4)")]#text(" we obtain the desired (local) associativity.")

#text("It remains to prove Proposition ")#link(<tao-078ac4e4ab3872e671c7>)[#text("2")]#text(". We first make a convenient observation. Thanks to the Jacobi identity, the adjoint representation ")#mi("{\\text{ad}: x \\mapsto \\text{ad}_x}")#text(" is a Lie algebra homomorphism from ")#mi("{{\\mathfrak g}}")#text(" to the Lie algebra ")#mi("{\\mathfrak{gl}({\\mathfrak g})}")#text(". As this latter Lie algebra is the Lie algebra of a Lie group, namely ")#mi("{GL({\\mathfrak g})}")#text(", the Baker-Campbell-Hausdorff formula is valid for that Lie algebra. In particular, one has")

#align(center)[#tao-fit-display[#mitex("\\log( \\exp( \\text{ad}_x ) \\exp( \\text{ad}_y ) ) = R_{\\text{ad}_y}(\\text{ad}_x) = L_{\\text{ad}_x}(\\text{ad}_y)")]]

#text("for sufficiently small ")#mi("{x,y}")#text(". But as ")#mi("{\\text{ad}}")#text(" is a Lie algebra homomorphism, one has")

#align(center)[#tao-fit-display[#mitex("R_{\\text{ad}_y}(\\text{ad}_x) = \\text{ad}_{R_y(x)}")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("L_{\\text{ad}_x}(\\text{ad}_y) = \\text{ad}_{L_x(y)}.")]]

#text("Exponentiating, we conclude that ")#metadata(none) <tao-a116a1e6cc53a1c07bd1>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(5)")])
#mitex("\\text{Ad}_x \\text{Ad}_y = \\text{Ad}_{R_y(x)} = \\text{Ad}_{L_x(y)}.")]]

#text("This would already give what we want if the adjoint representation was faithful. We unfortunately cannot assume this (and this is the main reason, by the way, why Ado’s theorem is so difficult), but we can at least use ")#link(<tao-a116a1e6cc53a1c07bd1>)[#text("(5)")]#text(" to rewrite the formulae ")#link(<tao-6b4e8b48b0964d5fbcdb>)[#text("(1)")]#text(", ")#link(<tao-10086e7ab26cd4245716>)[#text("(2)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("R_y(x) = x + \\int_0^1 F_R( \\text{Ad}_{R_{ty}(x)} )\\ dt")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("L_x(y) := y + \\int_0^1 F_L( \\text{Ad}_{L_{tx}(y)} )\\ dt.")]]

#text("This leads to the important ")#emph[#text("radial homogeneity identities")]

#align(center)[#tao-fit-display[#mitex("R_{(s+t)y}(x) = R_{sy}( R_{ty}(x) )")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("L_{(s+t)x}(y) = L_{sx}( L_{tx}(y) )")]]

#text("for all sufficiently small ")#mi("{x,y \\in {\\mathfrak g}}")#text(" and ")#mi("{0 \\leq s,t \\leq 1}")#text(", as can be seen by a short computation.")

#text("Because of these radial homogeneity identities (together with the smoothness of the right and left BCH laws), it will now suffice to prove the ")#emph[#text("approximate")]#text(" commutativity law ")#metadata(none) <tao-e00fbce5d6750395b762>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(6)")])
#tao-math("L_y(R_z(x)) = R_z(L_y(x)) + O(\\left|y\\right|^2 \\left|z\\right|) + O( \\left|y\\right| \\left|z\\right|^2 )", block: true)]]

#text("for all small ")#mi("{x,y,z}")#text(". Indeed, this law implies that ")#metadata(none) <tao-f765ed38729554cb0150>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(7)")])
#mitex("L_{y/n} \\circ R_{z/n} = R_{z/n} \\circ L_{y/n} + O(1/n^3)")]]

#text("for fixed small ")#mi("{y,z}")#text(", a large natural number ")#mi("{n}")#text(", and with the understanding that the operations are only applied to sufficiently small elements ")#mi("{x}")#text(". From radial homogeneity we have ")#mi("{L_y = L_{y/n}^n}")#text(" and ")#mi("{R_z = R_{z/n}^n}")#text(", and so a large number (")#mi("{O(n^2)}")#text(", to be more precise) of iterations of ")#link(<tao-f765ed38729554cb0150>)[#text("(7)")]#text(" (using uniform smoothness to control all errors) gives")

#align(center)[#tao-fit-display[#mitex("L_y \\circ R_z = R_z \\circ L_y + O(1/n),")]]

#text("and the claim ")#link(<tao-f28ddc82da0bb8956bae>)[#text("(4)")]#text(" then follows by sending ")#mi("{n \\rightarrow \\infty}")#text(".")

#text("It remains to prove ")#link(<tao-e00fbce5d6750395b762>)[#text("(6)")]#text(". When ")#mi("{y=0}")#text(", then ")#mi("{L_y}")#text(" is the identity map and the claim is trivial; similarly if ")#mi("{z=0}")#text(". By Taylor expansion, it thus suffices to establish the ")#emph[#text("infinitesimal")]#text(" commutativity law")

#align(center)[#tao-fit-display[#tao-math("\\frac{\\partial}{\\partial a} \\frac{\\partial}{\\partial b} L_{ay}(R_{bz}(x))\\left|_{a=b=0} = \\frac{\\partial}{\\partial a} \\frac{\\partial}{\\partial b} R_{bz}(L_{ay}(x))\\right|_{a=b=0}.", block: true)]]

#text("(One can interpret this infinitesimal commutativity as a commutativity of the vector fields corresponding to the infinitesimal generators of the left and right BCH laws, although we will not explicitly adopt that perspective here.) This is a simplification, because the infinitesimal versions of ")#link(<tao-6b4e8b48b0964d5fbcdb>)[#text("(1)")]#text(", ")#link(<tao-10086e7ab26cd4245716>)[#text("(2)")]#text(" are simpler than the non-infinitesimal versions. Indeed, from the fundamental theorem of calculus one has")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial a} L_{ay}(w)|_{a=0} = F_L(\\text{Ad}_w) y")]]

#text("for any fixed ")#mi("{y, w}")#text(", and similarly")

#align(center)[#tao-fit-display[#mitex("\\frac{\\partial}{\\partial b} R_{bz}(v)|_{b=0} = F_R(\\text{Ad}_v) z.")]]

#text("Thus it suffices (by ")#link("http://en.wikipedia.org/wiki/Symmetry_of_second_derivatives")[#text("Clairaut’s theorem")]#text(") to show that ")#metadata(none) <tao-c8fc6bf296faa18d058b>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(8)")])
#tao-math("\\frac{\\partial}{\\partial b} F_L( \\text{Ad}_{R_{bz}(x)} ) y\\left|_{b=0} = \\frac{\\partial}{\\partial a} F_R( \\text{Ad}_{L_{az}(x)} ) z\\right|_{a=0}.", block: true)]]

#text("It will be more convenient to work with the reciprocals ")#mi("{F_L^{-1}}")#text(", ")#mi("{F_R^{-1}}")#text(" of the functions ")#mi("{F_L, F_R}")#text(". Recall the general matrix identity")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} A^{-1}(t) = - A^{-1}(t) A^{\\prime}(t) A^{-1}(t)")]]

#text("for any smoothly varying invertible matrix function ")#mi("{A(t)}")#text(" of a real parameter ")#mi("{t}")#text(". Using this identity, we can write the left-hand side of ")#link(<tao-c8fc6bf296faa18d058b>)[#text("(8)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("- F_L( \\text{Ad}_x ) (\\frac{\\partial}{\\partial b} F_L^{-1}(\\text{Ad}_{R_{bz}(x)})|_{b=0}) F_L(\\text{Ad}_x) y.")]]

#text("If we write ")#mi("{Y := F_L(\\text{Ad}_x) y}")#text(" and ")#mi("{Z := F_R(\\text{Ad}_x) z}")#text(", then from Taylor expansion we have")

#align(center)[#tao-fit-display[#tao-math("R_{bz}(x) = x + bZ + O(\\left|b\\right|^2)", block: true)]]

#text("and so we can simplify the above expression as")

#align(center)[#tao-fit-display[#mitex("- F_L(\\text{Ad}_x) (\\frac{\\partial}{\\partial b} F_L^{-1}(\\text{Ad}_{x+bZ})|_{b=0}) Y.")]]

#text("Similarly, the right-hand side of ")#link(<tao-c8fc6bf296faa18d058b>)[#text("(8)")]#text(" is")

#align(center)[#tao-fit-display[#mitex("- F_R(\\text{Ad}_x) (\\frac{\\partial}{\\partial a} F_R^{-1}(\\text{Ad}_{x+aY})|_{a=0}) Z.")]]

#text("Since ")#mi("{F_R(\\text{Ad}_x) = \\text{Ad}_x F_L(\\text{Ad}_x)}")#text(", it thus suffices to show that ")#metadata(none) <tao-a540ec41a4e40d9a8485>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(9)")])
#mitex("(\\frac{\\partial}{\\partial b} F_L^{-1}(\\text{Ad}_{x+bZ})|_{b=0}) Y = \\text{Ad}_x (\\frac{\\partial}{\\partial a} F_R^{-1}(\\text{Ad}_{x+aY})|_{a=0}) Z.")]]

#text("Now, we write")

#align(center)[#tao-fit-display[#mitex("F_L^{-1}(\\text{Ad}_{x}) = \\int_0^1 \\text{Ad}_{tx}\\ dt")]]

#text("and")

#align(center)[#tao-fit-display[#mitex("F_R^{-1}(\\text{Ad}_{x}) = \\int_0^1 \\text{Ad}_{-tx}\\ dt")]]

#text("and thus expand ")#link(<tao-a540ec41a4e40d9a8485>)[#text("(9)")]#text(" as ")#metadata(none) <tao-ad0d6bcb97d5148a8a65>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(10)")])
#tao-math("\\int_0^1 (\\frac{\\partial}{\\partial b} \\text{Ad}_{tx+tbZ})\\left|_{b=0} Y\\ dt = \\text{Ad}_x \\int_0^1 (\\frac{\\partial}{\\partial b} \\text{Ad}_{-tx-taY})\\right|_{a=0} Z\\ dt.", block: true)]]

#text("We write ")#mi("{\\text{Ad}}")#text(" as the exponential of ")#mi("{\\text{ad}}")#text(". Using the Duhamel matrix identity")

#align(center)[#tao-fit-display[#mitex("\\frac{d}{dt} \\exp(A(t)) = \\int_0^1 \\exp(sA(t)) A^{\\prime}(t) \\exp((1-s)A(t))\\ dt")]]

#text("for any smoothly varying matrix function ")#mi("{A(t)}")#text(" of a real variable ")#mi("{t}")#text(", together with the linearity of ")#mi("{\\text{ad}}")#text(", we see that")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\partial}{\\partial b} \\text{Ad}_{tx+tbZ})|_{b=0} = \\int_0^1 \\text{Ad}_{stx} t\\text{ad}_Z \\text{Ad}_{(1-s)tx}\\ ds")]]

#text("and similarly")

#align(center)[#tao-fit-display[#mitex("(\\frac{\\partial}{\\partial b} \\text{Ad}_{-tx-taY})|_{a=0} = -\\int_0^1 \\text{Ad}_{-stx} t\\text{ad}_Y \\text{Ad}_{-(1-s)tx}\\ ds.")]]

#text("Collecting terms, our task is now to show that ")#metadata(none) <tao-30f643950f43480d9e14>

#align(center)[#block(width: 100%)[#set math.equation(numbering: n => [#text("(11)")])
#mitex("\\int_0^1 \\int_0^1 \\text{Ad}_{stx} \\text{ad}_Z \\text{Ad}_{(1-s)tx} Y\\ t ds dt = - \\int_0^1 \\int_0^1 \\text{Ad}_{(1-st)x} \\text{ad}_Y \\text{Ad}_{-(1-s)tx} Z\\ t ds dt.")]]

#text("For any ")#mi("{x \\in {\\mathfrak g}}")#text(", the adjoint map ")#mi("{\\text{ad}_x: {\\mathfrak g} \\rightarrow {\\mathfrak g}}")#text(" is a derivation in the sense that")

#align(center)[#tao-fit-display[#mitex("\\text{ad}_x [y,z] = [\\text{ad}_x y, z ] + [y, \\text{ad}_x z],")]]

#text("thanks to the Jacobi identity. Exponentiating, we conclude that")

#align(center)[#tao-fit-display[#mitex("\\text{Ad}_x [y,z] = [\\text{Ad}_x y, \\text{Ad}_x z]")]]

#text("(thus each ")#mi("{\\text{Ad}_x}")#text(" is a Lie algebra homomorphism) and thus")

#align(center)[#tao-fit-display[#mitex("\\text{Ad}_x \\text{ad}_y \\text{Ad}_x^{-1} = \\text{ad}_{\\text{Ad}_x y}.")]]

#text("Using this, we can simplify ")#link(<tao-30f643950f43480d9e14>)[#text("(11)")]#text(" as")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 \\int_0^1 \\text{ad}_{\\text{Ad}_{stx} Z} \\text{Ad}_{tx} Y\\ t ds dt = - \\int_0^1 \\int_0^1 \\text{ad}_{\\text{Ad}_{(1-st)x} Y} \\text{Ad}_{(1-t)x} Y\\ t ds dt")]]

#text("which we can rewrite as")

#align(center)[#tao-fit-display[#mitex("\\int_0^1 \\int_0^1 [\\text{Ad}_{stx} Z, \\text{Ad}_{tx} Y]\\ t ds dt = - \\int_0^1 \\int_0^1 [\\text{Ad}_{(1-st)x} Y, \\text{Ad}_{(1-t)x} Y]\\ t ds dt.")]]

#text("But by an appropriate change of variables (and the anti-symmetry of the Lie bracket), both sides of this equation can be written as")

#align(center)[#tao-fit-display[#mitex("\\int_{0 \\leq a\\leq b \\leq 1} [\\text{Ad}_{ax} Z, \\text{Ad}_{bx} Y]\\ da db")]]

#text("and the claim follows.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 1")]#text(" The above argument shows that every finite-dimensional Lie algebra ")#mi("{{\\mathfrak g}}")#text(" can be viewed as arising from a ")#emph[#text("local")]#text(" Lie group ")#mi("{G}")#text(". It is natural to then ask if that local Lie group (or a sufficiently small piece thereof) can in turn be extended to a global Lie group ")#mi("{\\tilde G}")#text(". The answer to this is affirmative, as was first shown by Cartan. I have been unable however to find a proof of this result that does not either use Ado’s theorem, the proof method of Ado’s theorem (in particular, the structural decomposition of Lie algebras into semisimple and solvable factors), or some facts about group cohomology (particularly with regards to central extensions of Lie groups) which are closely related to the structural decompositions just mentioned. (As noted ")#link("http://www.ams.org/mathscinet-getitem?mr=2179691")[#text("by Serre")]#text(", though, a certain amount of this sort of difficulty in the proof may in fact be necessary, given that the global form of Lie’s third theorem is known to fail in the infinite-dimensional case.)")
]

#heading(level: 1)[#text("Comments (5)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/063b675704132fba480f5d8523d45eaa6dc1a29606f3921d71f5ba0b6df3a79b-85ac7e85c91e2494dd2382e5ffdaa6d08684f7e06205f699a9f94f45d85b434f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ryancreich")]], [#link("https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/#comment-98135")[#strong[#text("ryancreich")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2011")])]

#text("This proof is a page-turner, but I lost track of the reductions after the second page. Is there any intuitive sense in which the transformations following equation (8) (or equivalently, after the infinitesimal commutativity law) have some meaning aside from advancing the proof?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/#comment-98213")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2011")])]

#text("Yes, I was stuck at this point for a while, because I found the functions F_R, F_L quite hard to differentiate at the matrix level. Eventually I realised that their reciprocals were easier to differentiate because they had a clean integral representation (see the equations between (9) and (10); this form of the inverse is in fact why these two functions arise in the Baker-Campbell-Hausdorff formula in the first place). Once I rewrote things in terms of the inverse, the F’s started melting away, and I ended up with just a bunch of ad’s and Ad’s which were relatively easy to differentiate and simplify.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e1237c72a2635e503c075ff63d09280f45c8179c4bab2d5efaf5a6f621457143-5ddb7acc767d49062409bcd31747caf3742efe9dab6349dc9d01fb0923bfebba.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Baker-Campbell-Hausdorff polynomials and Menelaus theorem | chorasimilarity")]], [#link("https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/#comment-98244")[#strong[#text("Baker-Campbell-Hausdorff polynomials and Menelaus theorem | chorasimilarity")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2011")])]

#text("[…] Associativity of the Baker-Campbell-Hausdorff formula […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/#comment-98355")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 October 2011")])]

#text("A minor editing suggestion, since this is expository after all:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("However, Ado’s theorem is rather difficult to prove (see for instance this previous blog post for a proof), and it is natural to ask whether there is a way to establish these facts without __Ado’s theorem__")
]

#text("doesn’t, as expected, link the text “this previous blog post”, but rather the concluding “Ado’s theorem”.")#linebreak()#text(" I suggest")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("However, Ado’s theorem is rather difficult to prove (see for instance ")#link("https://terrytao.wordpress.com/2011/05/10/ados-theorem/")[#text("this previous blog post")]#text(" for a proof), and it is natural to ask whether there is a way to establish these facts without it.")
]

#emph[#text("[Adjusted, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bc43da99bddf1772e2aad0a5e39d4ab5b94cebe25ebac976a36e6b99172f06cc-5d4726b87a45e50149eeab0837f7ef5e718ee455c882f1b0a907f1b5d0f9bdee.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of reader")]], [#link("https://terrytao.wordpress.com/2011/10/29/associativity-of-the-baker-campbell-hausdorff-formula/#comment-144905")[#strong[#text("reader")]]#text(size: 9pt, fill: rgb("596477"), " · 29 May 2012")])]

#text("Readers here may find these two recent related works of interest.")#linebreak()#text(" ")#link("http://www.unibo.it/faculty/andrea.bonfiglioli6")[#text("Bonfiglioli, Andrea")]#text("; Fulci, Roberta: ")#link("http://dx.doi.org/10.1007/978-3-642-22597-0")[#text("Topics in Noncommutative Algebra: The Theorem of Campbell, Baker, Hausdorff and Dynkin")]#text(". ")#text("LNM")#text(" ")#strong[#text("2034")]#text(", Springer, 2012, ")#emph[#text("xxii")]#text("+539 pp. ISBN 978-3-642-22596-3. ")#link("http://ams.org/mathscinet-getitem?mr=2883818")[#text("MR2883818")]#text("; ")#link("http://www.zentralblatt-math.org/zmath/search/?an=1231.17001")[#text("Zbl 1231.17001")]#text(".")#linebreak()#text(" ")#link("http://www.unibo.it/docenti/rudiger.achilles")[#text("Achilles, Rüdiger")]#text("; Bonfiglioli, Andrea: ")#link("http://dx.doi.org/10.1007/s00407-012-0095-8")[#text("The early proofs of the theorem of Campbell, Baker, Hausdorff, and Dynkin")]#text(". ")#text("Arch. Hist. Exact Sci.")#text(" ")#strong[#text("66")]#text(".3 (2012-05), 295–358. ")#link("http://www.zentralblatt-math.org/zmath/search/?an=pre06037475")[#text("Zbl pre06037475")]#text(".")
]
