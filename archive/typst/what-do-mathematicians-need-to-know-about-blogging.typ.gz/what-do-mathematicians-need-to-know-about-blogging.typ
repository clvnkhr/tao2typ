// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/
// Converted to Typst by tao2typ: "2026-10-14T16:35:50.731208+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "What do mathematicians need to know about blogging?", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("What do mathematicians need to know about blogging?")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 9 August 2009")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/")[#text("https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://en.wikipedia.org/wiki/John_C._Baez")[#text("John Baez")]#text(" has been invited to write a short opinion piece for ")#link("http://www.ams.org/notices")[#text("the Notices of the AMS")]#text(" to report about the maths blogging phenomenon to the wider mathematical community, and in the spirit of that phenomenon, has ")#link("http://golem.ph.utexas.edu/category/2009/08/what_do_mathematicians_need_to.html")[#text("opened up a blog post")]#text(" to solicit input for that piece, over at the ")#link("http://golem.ph.utexas.edu/category/")[#text("n-Category café")]#text(". Given that the readers here are, by definition, familiar with mathematical blogging, I thought that some of you might like to visit that thread to share your own thoughts on the advantages and disadvantages of this mode of mathematical communication.")

#heading(level: 1)[#text("Comments (4)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/c525dbb80380d49b39d66b3899a94cab193179b50b9b7143ceec37b7536137a2-b99ed5240b84b9fc5ff2d46571833825fd48270c8b1a1b54acda76545b423e48.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Bob")]], [#link("https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/#comment-40933")[#strong[#text("Bob")]]#text(size: 9pt, fill: rgb("596477"), " · 9 August 2009")])]

#text("Being a math teacher myself, and having read more than a few other math blogs, I think the major thing for new bloggers to remember is that they need to make sure that they’re clear on what they talk about, and to actively link to other articles they’ve written. Many people jump into a topic without really prepping the reader. That’s no good.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/#comment-40942")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 10 August 2009")])]

#text("Wonderful medium to keep people informed about advances in our subject. It complements conferences and conversations with clued-in colleagues. This blog (and at least one or two others) are a great service to the worldwide mathematical community.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/5c1e92edd989197e8184760d8353564b081d7294c72392ed01852c3cbd00a0fc-be36c809338bff845d7694ffd3279427f2125ba0e61806c4490895dc99646ad4.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Maria H. Andersen")]], [#link("https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/#comment-41096")[#strong[#text("Maria H. Andersen")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2009")])]

#text("I think there may be a difference between how mathematicians and how math instructors use blogging. For those of us with a primary teaching focus, math blogs are a great way to find relevant material for our classes, to learn about new technologies that we can use to teach online, and to bounce instructional ideas off of colleagues.")

#text("I suspect that the AMS article will be focused on blogging for research, but just for the record, there is a second tier of blogging “mathematicians” out there.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/fb5a24b9ef643fa601668d6b922d3f9a836775692710b3649679d1107ac49a8d-6ac51245ebad9c3779a35953f1070f5e0619e3378bcc532faec602454b1f30a5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Two quick updates « What’s new")]], [#link("https://terrytao.wordpress.com/2009/08/09/what-do-mathematicians-need-to-know-about-blogging/#comment-41643")[#strong[#text("Two quick updates « What’s new")]]#text(size: 9pt, fill: rgb("596477"), " · 30 September 2009")])]

#text("[…] In a previous post, I noted John Baez’s thread discussing his incipient article to the Notices of the AMS, “What do mathematicians need to know about blogging?”. John has now completed an initial draft of his article and is welcoming comments on it here. […]")
]
