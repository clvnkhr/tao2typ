// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/
// Converted to Typst by tao2typ: "2026-10-14T15:21:05.214056+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Stonean spaces, projective objects, the Riesz representation theorem, and (possibly) condensed mathematics", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Stonean spaces, projective objects, the Riesz representation theorem, and (possibly) condensed mathematics")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 23 April 2025")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/")[#text("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("A basic type of problem that occurs throughout mathematics is the ")#emph[#text("lifting problem")]#text(": given some space ")#mi("{X}")#text(" that “sits above” some other “base” space ")#mi("{Y}")#text(" due to a projection map ")#mi("{\\pi: X \\rightarrow Y}")#text(", and some map ")#mi("{f: A \\rightarrow Y}")#text(" from a third space ")#mi("{A}")#text(" into the base space ")#mi("{Y}")#text(", find a “lift” ")#mi("{\\tilde f}")#text(" of ")#mi("{f}")#text(" to ")#mi("{X}")#text(", that is to say a map ")#mi("{\\tilde f: A \\rightarrow X}")#text(" such that ")#mi("{\\pi \\circ \\tilde f = f}")#text(". In many applications we would like to have ")#mi("{\\tilde f}")#text(" preserve many of the properties of ")#mi("{f}")#text(" (e.g., continuity, differentiability, linearity, etc.).")

#text("Of course, if the projection map ")#mi("{\\pi: X \\rightarrow Y}")#text(" is not surjective, one would not expect the lifting problem to be solvable in general, as the map ")#mi("{f}")#text(" to be lifted could simply take values outside of the range of ")#mi("{\\pi}")#text(". So it is natural to impose the requirement that ")#mi("{\\pi}")#text(" be surjective, giving the following commutative diagram to complete:")

#image("../assets/0fdb70ddebf27a2b5285c948efd75df1e1719670992bb76b547225ef25dfc4bb-e8a9379c8d80fd725df16b799efaa0c94200b169a5c4134071227c481ddbf263.png", width: 90%)

#text("If no further requirements are placed on the lift ")#mi("{\\tilde f}")#text(", then the axiom of choice is precisely the assertion that the lifting problem is always solvable (once we require ")#mi("{\\pi}")#text(" to be surjective). Indeed, the axiom of choice lets us select a preimage ")#mi("{\\phi(y) \\in \\pi^{-1}(\\{y\\})}")#text(" in the fiber of each point ")#mi("{y \\in Y}")#text(", and one can lift any ")#mi("{f: A \\rightarrow Y}")#text(" by setting ")#mi("{\\tilde f := \\phi \\circ f}")#text(". Conversely, to build a choice function for a surjective map ")#mi("{\\pi: X \\rightarrow Y}")#text(", it suffices to lift the identity map ")#mi("{\\mathrm{id}_Y:Y \\rightarrow Y}")#text(" to ")#mi("{X}")#text(".")

#text("Of course, the maps provided by the axiom of choice are famously pathological, being almost certain to be discontinuous, non-measurable, etc.. So now suppose that all spaces involved are topological spaces, and all maps involved are required to be continuous. Then the lifting problem is not always solvable. For instance, we have a continuous projection ")#mi("{x \\mapsto x \\text{ mod } 1}")#text(" from ")#mi("{{\\bf R}}")#text(" to ")#mi("{{\\bf R}/{\\bf Z}}")#text(", but the identity map ")#mi("{\\mathrm{id}_{{\\bf R}/{\\bf Z}}:{\\bf R}/{\\bf Z} \\rightarrow {\\bf R}/{\\bf Z}}")#text(" cannot be lifted continuously up to ")#mi("{{\\bf R}}")#text(", because ")#mi("{{\\bf R}}")#text(" is contractable and ")#mi("{{\\bf R}/{\\bf Z}}")#text(" is not.")

#text("However, if ")#mi("{A}")#text(" is a ")#emph[#text("discrete")]#text(" space (every set is open), then the axiom of choice lets us solve the continuous lifting problem from ")#mi("{A}")#text(" for any continuous surjection ")#mi("{\\pi: X \\rightarrow Y}")#text(", simply because every map from ")#mi("{A}")#text(" to ")#mi("{X}")#text(" is continuous. Conversely, the discrete spaces are the only ones with this property: if ")#mi("{A}")#text(" is a topological space which is not discrete, then if one lets ")#mi("{A_{disc}}")#text(" be the same space ")#mi("{A}")#text(" equipped with the discrete topology, then the only way one can continuously lift the identity map ")#mi("{\\mathrm{id}_A: A \\rightarrow A}")#text(" through the “projection map” ")#mi("{\\pi: A_{disc} \\rightarrow A}")#text(" (that maps each point to itself) is if ")#mi("{A}")#text(" is itself discrete.")

#text("These discrete spaces are the ")#link("https://en.wikipedia.org/wiki/Projective_object")[#text("projective objects")]#text(" in the category of topological spaces, since in this category the concept of an ")#link("https://en.wikipedia.org/wiki/Epimorphism")[#text("epimorphism")]#text(" agrees with that of a surjective continuous map. Thus ")#mi("{A_{disc}}")#text(" can be viewed as the unique (up to isomorphism) projective object in this category that has a bijective continuous map to ")#mi("{A}")#text(".")

#text("Now let us narrow the category of topological spaces to the category of ")#emph[#text("compact Hausdorff (CH)")]#text(" spaces. Here things should be better behaved; for instance, it is a standard fact in this category that continuous bijections are homeomorphisms, and it is still the case that the epimorphisms are the continuous surjections. So we have a usable notion of a projective object in this category: CH spaces ")#mi("{A}")#text(" such that any continuous map ")#mi("{f: A \\rightarrow Y}")#text(" into another CH space can be lifted via any surjective continuous map ")#mi("{\\pi: X \\rightarrow Y}")#text(" to another CH space.")

#text("By the previous discussion, discrete CH spaces will be projective, but this is an extremely restrictive set of examples, since of course compact discrete spaces must be finite. Are there any others? The answer was worked out ")#link("https://zbmath.org/0083.17401")[#text("by Gleason")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 1")]#text(" A compact Hausdorff space ")#mi("{A}")#text(" is projective if and only if it is ")#link("https://en.wikipedia.org/wiki/Extremally_disconnected_space")[#text("extremally disconnected")]#text(", i.e., the closure of every open set is again open.")
]

#emph[#text("Proof:")]#text(" We begin with the “only if” direction. Let ")#mi("{A}")#text(" was projective, and let ")#mi("{U}")#text(" be an open subset of ")#mi("{A}")#text(". Then the closure ")#mi("{\\overline{U}}")#text(" and complement ")#mi("{A \\backslash U}")#text(" are both closed, hence compact, subsets of ")#mi("{A}")#text(", so the disjoint union ")#mi("{\\overline{U} \\uplus (A \\backslash U)}")#text(" is another CH space, which has an obvious surjective continuous projection map ")#mi("{\\pi: \\overline{U} \\uplus (A \\backslash U) \\rightarrow A}")#text(" to ")#mi("{A}")#text(" formed by gluing the two inclusion maps together. As ")#mi("{A}")#text(" is projective, the identity map ")#mi("{\\mathrm{id}_A: A \\rightarrow A}")#text(" must then lift to a continuous map ")#mi("{\\tilde f: A \\rightarrow \\overline{U} \\uplus (A \\backslash U) \\rightarrow A}")#text(". One easily checks that ")#mi("{f}")#text(" has to map ")#mi("{\\overline{U}}")#text(" to the first component ")#mi("{\\overline{U}}")#text(" of the disjoint union, and ")#mi("{A \\backslash \\overline{U}}")#text(" ot the second component; hence ")#mi("{f^{-1}(\\overline{U}) = \\overline{U}}")#text(", and so ")#mi("{\\overline{U}}")#text(" is open, giving extremal disconnectedness.")

#text("Conversely, suppose that ")#mi("{A}")#text(" is extremally disconnected, that ")#mi("{\\pi: X \\rightarrow Y}")#text(" is a continuous surjection of CH spaces, and ")#mi("{f: A \\rightarrow Y}")#text(" is continuous. We wish to lift ")#mi("{f}")#text(" to a continuous map ")#mi("{\\tilde f: A \\rightarrow X}")#text(".")

#text("We first observe that it suffices to solve the lifting problem for the identity map ")#mi("{\\mathrm{id}_A: A \\rightarrow A}")#text(", that is to say we can assume without loss of generality that ")#mi("{Y=A}")#text(" and ")#mi("{f}")#text(" is the identity. Indeed, for general maps ")#mi("{f: A \\rightarrow Y}")#text(", one can introduce the pullback space")

#align(center)[#tao-fit-display[#mitex("A \\times_Y X := \\{ (a,x) \\in A \\times X: \\pi(x) = f(a) \\}")]]

#text("which is clearly a CH space that has a continuous surjection ")#mi("{\\tilde \\pi: A \\times_Y X \\rightarrow A}")#text(". Any continuous lift of the identity map ")#mi("{\\mathrm{id}_A: A \\rightarrow A}")#text(" to ")#mi("{A \\times_Y X}")#text(", when projected onto ")#mi("{X}")#text(", will give a desired lift ")#mi("{\\tilde f: A \\rightarrow X}")#text(".")

#image("../assets/7ecba7adaa03b9286062f26ad5af9cd9cb75f173fd0039b4fc57ceba4b72fa70-e484872b01623b9f75f371283c6ea65b01e5f12497e60581631e4ecdafd0dcd1.png", width: 90%)

#text("So now we are trying to lift the identity map ")#mi("{\\mathrm{id}_A: A \\rightarrow A}")#text(" via a continuous surjection ")#mi("{\\pi: X \\rightarrow A}")#text(". Let us call this surjection ")#mi("{\\pi: X \\rightarrow A}")#text(" ")#emph[#text("minimally surjective")]#text(" if no restriction ")#mi("{\\pi|_K: K \\rightarrow A}")#text(" of ")#mi("{X}")#text(" to a proper closed subset ")#mi("{K}")#text(" of ")#mi("{X}")#text(" remains surjective. An easy application of Zorn’s lemma shows that every continuous surjection ")#mi("{\\pi: X \\rightarrow A}")#text(" can be restricted to a minimally surjective continuous map ")#mi("{\\pi|_K: K \\rightarrow A}")#text(". Thus, without loss of generality, we may assume that ")#mi("{\\pi}")#text(" is minimally surjective.")

#text("The key claim now is that every minimally surjective map ")#mi("{\\pi: X \\rightarrow A}")#text(" into an extremally disconnected space is in fact a bijection. Indeed, suppose for contradiction that there were two distinct points ")#mi("{x_1,x_2}")#text(" in ")#mi("{X}")#text(" that mapped to the same point ")#mi("{a}")#text(" under ")#mi("{X}")#text(". By taking contrapositives of the minimal surjectivity property, we see that every open neighborhood of ")#mi("{x_1}")#text(" must contain at least one fiber ")#mi("{\\pi^{-1}(\\{b\\})}")#text(" of ")#mi("{b}")#text(", and by shrinking this neighborhood one can ensure the base point is arbitrarily close to ")#mi("{a = \\pi(x_2)}")#text(". Thus, every open neighborhood of ")#mi("{x_1}")#text(" must intersect every open neighborhood of ")#mi("{x_2}")#text(", contradicting the Hausdorff property.")

#text("It is well known that continuous bijections between CH spaces must be homeomorphisms (they map compact sets to compact sets, hence must be open maps). So ")#mi("{\\pi:X \\rightarrow A}")#text(" is a homeomorphism, and one can lift the identity map to the inverse map ")#mi("{\\pi^{-1}: A \\rightarrow X}")#text(". ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 2")]#text(" The property of being “minimally surjective” sounds like it should have a purely category-theoretic definition, but I was unable to match this concept to a standard term in category theory (something along the lines of a “minimal epimorphism”, I would imagine).")
]

#text("In view of this proposition, it is now natural to look for extremally disconnected CH spaces (also known as ")#emph[#text("Stonean spaces")]#text("). The discrete CH spaces are one class of such spaces, but they are all finite. Unfortunately, these are the only “small” examples:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 3")]#text(" Any first countable extremally disconnected CH space ")#mi("{A}")#text(" is discrete.")
]

#emph[#text("Proof:")]#text(" If such a space ")#mi("{A}")#text(" were not discrete, one could find a sequence ")#mi("{a_n}")#text(" in ")#mi("{A}")#text(" converging to a limit ")#mi("{a}")#text(" such that ")#mi("{a_n \\neq a}")#text(" for all ")#mi("{A}")#text(". One can sparsify the elements ")#mi("{a_n}")#text(" to all be distinct, and from the Hausdorff property one can construct neighbourhoods ")#mi("{U_n}")#text(" of each ")#mi("{a_n}")#text(" that avoid ")#mi("{a}")#text(", and are disjoint from each other. Then ")#mi("{\\bigcup_{n=1}^\\infty U_{2n}}")#text(" and then ")#mi("{\\bigcup_{n=1}^\\infty U_{2n+1}}")#text(" are disjoint open sets that both have ")#mi("{a}")#text(" as an adherent point, which is inconsistent with extremal disconnectedness: the closure of ")#mi("{\\bigcup_{n=1}^\\infty U_{2n}}")#text(" contains ")#mi("{a}")#text(" but is disjoint from ")#mi("{\\bigcup_{n=1}^\\infty U_{2n+1}}")#text(", so cannot be open. ")#mi("\\Box")

#text("Thus for instance there are no extremally disconnected compact metric spaces, other than the finite spaces; for instance, the Cantor space ")#mi("{\\{0,1\\}^{\\bf N}}")#text(" is not extremally disconnected, even though it is ")#link("https://en.wikipedia.org/wiki/Totally_disconnected_space")[#text("totally disconnected")]#text(" (which one can easily see to be a property implied by extremal disconnectedness). On the other hand, once we leave the first-countable world, we have plenty of such spaces:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Lemma 4")]#text(" Let ")#mi("{\\mathcal{B}}")#text(" be a ")#link("https://en.wikipedia.org/wiki/Complete_Boolean_algebra")[#text("complete Boolean algebra")]#text(". Then the ")#link("https://en.wikipedia.org/wiki/Stone_duality")[#text("Stone dual")]#text(" ")#mi("{\\mathrm{Hom}(\\mathcal{B},\\{0,1\\})}")#text(" of ")#mi("{\\mathcal{B}}")#text(" (i.e., the space of boolean homomorphisms ")#mi("{\\phi: \\mathcal{B} \\rightarrow \\{0,1\\}}")#text(") is an extremally disconnected CH space.")
]

#emph[#text("Proof:")]#text(" The CH properties are standard. The elements ")#mi("{E}")#text(" of ")#mi("{{\\mathcal B}}")#text(" give a basis of the topology given by the clopen sets ")#mi("{B_E := \\{ \\phi: \\phi(E) = 1\\}}")#text(". Because the Boolean algebra is complete, we see that the closure of the open set ")#mi("{\\bigcup_{\\alpha} B_{E_\\alpha}}")#text(" for any family ")#mi("{E_\\alpha}")#text(" of sets is simply the clopen set ")#mi("{B_{\\bigwedge_\\alpha E_\\alpha}}")#text(", which obviously open, giving extremal disconnectedness. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 5")]#text(" In fact, every extremally disconnected CH space ")#mi("{X}")#text(" is homeomorphic to a Stone dual of a complete Boolean algebra (and specifically, the clopen algebra of ")#mi("{X}")#text("); see ")#link("https://zbmath.org/0083.17401")[#text("Gleason’s paper")]#text(".")
]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Corollary 6")]#text(" ")#metadata(none) <tao-58d118590928d0b20a75>#text(" Every CH space ")#mi("{X}")#text(" is the surjective continuous image of an extremally disconnected CH space.")
]

#emph[#text("Proof:")]#text(" Take the Stone-Čech compactification ")#mi("{\\beta X_{disc}}")#text(" of ")#mi("{X_{disc}}")#text(" equipped with the discrete topology, or equivalently the Stone dual of the power set ")#mi("{2^X}")#text(" (i.e., the ultrafilters on ")#mi("{X}")#text("). By the previous lemma, this is an extremally disconnected CH space. Because every ultrafilter on a CH space has a unique limit, we have a canonical map from ")#mi("{\\beta X_{disc}}")#text(" to ")#mi("{X}")#text(", which one can easily check to be continuous and surjective. ")#mi("\\Box")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Remark 7")]#text(" In fact, to each CH space ")#mi("{X}")#text(" one can associate an extremally disconnected CH space ")#mi("{Z}")#text(" with a ")#emph[#text("minimally")]#text(" surjective continuous map ")#mi("{\\pi: Z \\rightarrow X}")#text(". The construction is the same, but instead of working with the entire power set ")#mi("{2^X}")#text(", one works with the smaller (but still complete) Boolean algebra of ")#emph[#text("domains")]#text(" – closed subsets of ")#mi("{X}")#text(" which are the closure of their interior, ordered by inclusion. This ")#mi("{Z}")#text(" is unique up to homoeomorphism, and is thus a canonical choice of extremally disconnected space to project onto ")#mi("{X}")#text(". See ")#link("https://zbmath.org/0083.17401")[#text("the paper of Gleason")]#text(" for details.")
]

#text("Several facts in analysis concerning CH spaces can be made easier to prove by utilizing Corollary ")#link(<tao-58d118590928d0b20a75>)[#text("6")]#text(" and working first in extremally disconnected spaces, where some things become simpler. My vague understanding is that this is highly compatible with the modern perspective of ")#link("https://en.wikipedia.org/wiki/Condensed_mathematics")[#text("condensed mathematics")]#text(", although I am not an expert in this area. Here, I will just give a classic example of this philosophy, due to Garling and presented in ")#link("https://www.jstor.org/stable/2975760")[#text("this paper of Hartig")]#text(":")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Theorem 8 (Riesz representation theorem)")]#text(" Let ")#mi("{X}")#text(" be a CH space, and let ")#mi("{\\lambda: C(X) \\rightarrow {\\bf R}}")#text(" be a bounded linear functional. Then there is a (unique) ")#link("https://en.wikipedia.org/wiki/Radon_measure")[#text("Radon measure")]#text(" ")#mi("{\\mu}")#text(" on ")#mi("{X}")#text(" (on the ")#link("https://en.wikipedia.org/wiki/Baire_set")[#text("Baire ")#mi("{\\sigma}")#text("-algebra")]#text(", generated by ")#mi("{C(X)}")#text(") such ")#mi("{\\lambda(f) = \\int_X f\\ d\\mu}")#text(" for all ")#mi("{f \\in C(X)}")#text(".")
]

#text("Uniqueness of the measure is relatively straightforward; the difficult task is existence, and most known proofs are somewhat complicated. But one can observe that the theorem “pushes forward” under surjective maps:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 9")]#text(" Suppose ")#mi("{\\pi: A \\rightarrow X}")#text(" is a continuous surjection between CH spaces. If the Riesz representation theorem is true for ")#mi("{A}")#text(", then it is also true for ")#mi("{X}")#text(".")
]

#emph[#text("Proof:")]#text(" As ")#mi("{\\pi}")#text(" is surjective, the pullback map ")#mi("{\\pi^*: C(X) \\rightarrow C(A)}")#text(" is an isometry, hence every bounded linear functional on ")#mi("{C(X)}")#text(" can be viewed as a bounded linear functional on a subspace of ")#mi("{C(A)}")#text(", and hence by the Hahn–Banach theorem it extends to a bounded linear functional on ")#mi("{A}")#text(". By the Riesz representation theorem on ")#mi("{A}")#text(", this latter functional can be represented as an integral against a Radon measure ")#mi("{\\mu}")#text(" on ")#mi("{A}")#text(". One can then check that the pushforward measure ")#mi("{\\pi_* \\mu}")#text(" is then a Radon measure on ")#mi("{X}")#text(", and gives the desired representation of the bounded linear functional on ")#mi("{C(X)}")#text(". ")#mi("\\Box")

#text("In view of this proposition and Corollary ")#link(<tao-58d118590928d0b20a75>)[#text("6")]#text(", it suffices to prove the Riesz representation theorem for extremally disconnected CH spaces. But this is easy:")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Proposition 10")]#text(" The Riesz representation theorem is true for extremally disconnected CH spaces.")
]

#emph[#text("Proof:")]#text(" The Baire ")#mi("{\\sigma}")#text("-algebra is generated by the Boolean algebra of clopen sets. A functional ")#mi("{\\lambda: C(X)\\rightarrow {\\bf R}}")#text(" induces a finitely additive measure ")#mi("{\\mu}")#text(" on this algebra by the formula ")#mi("{\\mu(E) := \\lambda(1_E)}")#text(". This is in fact a ")#link("https://en.wikipedia.org/wiki/Pre-measure")[#text("premeasure")]#text(", because by compactness the only way to partition a clopen set into countably many clopen sets is to have only finitely many of the latter sets non-empty. By the ")#link("https://en.wikipedia.org/wiki/Carath%C3%A9odory%27s_extension_theorem")[#text("Carathéodory extension theorem")]#text(", ")#mi("{\\mu}")#text(" then extends to a Baire measure, which one can check to be a Radon measure that represents ")#mi("{\\lambda}")#text(" (the finite linear combinations of indicators of clopen sets are dense in ")#mi("{C(X)}")#text("). ")#mi("\\Box")

#heading(level: 1)[#text("Comments (16)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687819")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2025")])]

#text("this is very nice")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/f3672c5bb32afd30bc6b8fb086b180b3ec38ad24adb0992ab16725b2d61326b5-b049f18ececbb3da60d4908519ba58192f4310448c455d53c3dc71c287302b35.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jochen Wengenroth")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687820")[#strong[#text("Jochen Wengenroth")]]#text(size: 9pt, fill: rgb("596477"), " · 23 April 2025")])]

#text("For metrizable CH spaces $X$ this strategy simplifies because the Alexandrov-Hausdorff theorem yields a continuous linear surjection from the Cantor space ${0,1}^{mathbb N}$ onto $X$. In this case, the missing details of Proposition 10 are more elementary than in the general case of extremally disconnected CH spaces.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687821")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("In your argument about ‘every minimally surjective map into an extremally disconnected space is in fact a bijection’, I think there is a typo there where $b$ should be $a$.")

#emph[#text("[Corrected, thanks – T.]")]
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/60056590f059b00f9f42c9c1bf34ed4f8771eb624e77df9de9e6dd6d0aa6011b-78850c89d7b74cd5cd27061ecf21a6ed5f57b3513f40a85c231cc68842fb4cf6.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Robin")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687827")[#strong[#text("Robin")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("Also, at the end of the third paragraph under the diagram, that should be “lift $id_Y$ to $X$”.")

#emph[#text("[Corrected, thanks – T.]")]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687824")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("yay for Stonean spaces")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687828")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("This is likely a silly question, but are there any good resources covering material in this direction? Other than the Gleason and Hartig papers you referenced.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687831")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("I don’t know of a good modern treatment of these topics, but ")#link("https://arxiv.org/abs/2503.22699")[#text("https://arxiv.org/abs/2503.22699")]#text(" is a recent text presenting condensed mathematics from an analysts’s perspective, which has some conceptual overlap with the topics of this post.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/2335471dfa9e7af103048c202c1c190291b7d43d01981f857b62a887b4792acb-5113708adec8559827c596eb6f42cc9816ff15eb1fa02d3051111f9559a37149.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ritobanrc")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687829")[#strong[#text("ritobanrc")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#text("but there is a technicality here because the notion of projective object requires the concept of an ")#link("https://en.wikipedia.org/wiki/Epimorphism")[#text("epimorphism")]#text(", which is not quite the same thing as a surjective continuous map in this category.")
]

#text("Can you clarify what category this sentence is referring to? In the category of topological spaces with continuous maps, the epimorphisms are exactly the same thing as surjective continuous maps, right (or at least, ")#link("https://en.wikipedia.org/wiki/Category_of_topological_spaces")[#text("Wikipedia")]#text(" says so)?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687830")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("Ah, I was somehow implicitly assuming all my spaces were Hausdorff, but yes, without that restriction, the epimorphisms become surjective again. I’ve updated the post accordingly. My paper with Jamneshan with ")#link("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/")[#text("https://terrytao.wordpress.com/2020/10/04/foundational-aspects-of-uncountable-measure-theory-gelfand-duality-riesz-representation-canonical-models-and-canonical-disintegration/")]#text(" also touches on many of these topics, although there we used Riesz representation theorems from the literature as black boxes, rather than try to reprove them.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687833")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("What is the map x -> x mod 1? It sounds like it means the fractional component but if that’s the case then the map from R -> R/Z is discontinuous at the integers.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687834")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 24 April 2025")])]

#text("This is the quotient map: ")#mi("x \\text{ mod } 1")#text(" is a synonym for the coset ")#mi("x + {\\mathbb Z}")#text(".")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687856")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2025")])]

#text("I don’t quite understand this example. To me it seems that R -> R/Z is just the universal cover of the circle? But this map if continuous, so what am I missing here?")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687860")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 28 April 2025")])]

#text("It is true that the covering map from ")#mi("\\mathbb{R}")#text(" to ")#mi("\\mathbb{R}/\\mathbb{Z}")#text(" is continuous; but the problem is that there is no continuous lifting map from ")#mi("\\mathbb{R}/\\mathbb{Z}")#text(" to ")#mi("\\mathbb{R}")#text(" which lifts from the identity map on ")#mi("\\mathbb{R}/\\mathbb{Z}")#text(". (There are discontinuous lifts, such as the map from ")#mi("x \\text{ mod } 1")#text(" to ")#mi("x")#text(" for ")#mi("x \\in [0,1)")#text(", but no continuous ones.)")
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-687939")[#strong[#text("Carnival Of Mathematics | Reflections and Tangents")]]#text(size: 9pt, fill: rgb("596477"), " · 5 May 2025")]

#text("[…] Tao is doing much higher level mathematics than I can comprehend! The person who submitted this article said “[this is] One of Terence Tao’s posts that is too grown-up for me, I’d have […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-688273")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2025")])]

#text("Note that")#linebreak()#mi("A")#text(" is extremally disconnected iff the lifting problem is always solvable")#linebreak()#text("for a particular surjective proper map ")#linebreak()#text("of finite topological spaces of size ")#mi("\\leqslant 4")#text(".")#linebreak()#text("This is implicit in the first paragraph of the proof of Proposition 1:")#linebreak()#text("the map ")#mi("\\pi: \\overline{U} \\uplus (A \\backslash U) \\rightarrow A")#linebreak()#text("is the pullback of a map, in hopefully suggestive notation explained below,")#linebreak()#mi("\\overline \\pi:{ \\bullet_U \\rightarrow \\star_{\\overline{U}\\setminus U} } \\uplus {\\bullet_{A \\setminus \\overline{U}} \\rightarrow  \\star_{\\overline{U}\\setminus U}} \\longrightarrow{ \\bullet_U \\rightarrow \\star_{\\overline{U}\\setminus U} \\leftarrow \\bullet_{A \\setminus \\bar U}}")#linebreak()#text("of finite topological spaces of size ")#mi("4")#text(" and ")#mi("3")#text(".")

#text("The map ")#mi("\\bar\\pi")#text(" is surjective and projective, and this is related")#linebreak()#text("to use of surjectivity and compactness in Proposition 1 and Corollary 6.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2025/04/23/stonean-spaces-projective-objects-the-riesz-representation-theorem-and-possibly-condensed-mathematics/#comment-688274")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 June 2025")])]

#text("Moreover, it appears that Proposition 1 and Corollary 6 are roughly equivalent, and would follow from certain statements made in terms of finite topological spaces and standard diagram chasing in homotopy theory related to the lifting problem. More precisely, they would follow from certain properties of the weak factorisation system cogenerated by 4 maps of finite topological spaces of size at most 7, at least if we ignore Hausdorffness conditions. This places them into a rather more general context, as it is an open question whether any small set of maps (co)generates a weak factorisation system. Below I spell out what these four maps are and what weak factorisation systems are, but the post is too short for a complete proof and I’d rather not make a precise claim.")

#block(width: 100%, breakable: true, inset: (left: 12pt, right: 10pt, top: 5pt, bottom: 5pt), stroke: (left: 1.5pt + rgb("98a4b6")))[
#strong[#text("Claim 1.")]#linebreak()#text(" A space ")#mi("A")#text(" is ")#emph[#text("extremally disconnected")]#linebreak()#text(" iff ")#mi("A")#text(" solves the lifting problem with respect to the surjective proper map ")#mi("\\overline{\\pi}")#text(" of finite topological spaces of size at most ")#mi("4")#text(".")
]

#strong[#text("Proof.")]#linebreak()#text(" ")#linebreak()#text(" To give a map to a finite topological space is the same as to represent the space as a finite union of open and closed subsets with particular properties (namely, the preimages of open and closed subsets of the finite space). Thus, rewriting in this way the decomposition")#linebreak()#text(" ")#mi("A = \\overline{U} \\cup (A \\setminus U) = (\\overline{U} \\setminus U) \\cup (U \\cap \\overline{U}) \\cup (A \\setminus \\overline{U})")#linebreak()#text(" gives a map")#linebreak()#text(" ")#mi("A \\longrightarrow \\{ \\bullet_U \\rightarrow \\star_{\\overline{U} \\setminus U} \\leftarrow \\bullet_{A \\setminus \\overline{U}} \\}")#text(".")#linebreak()#text(" Similarly, rewriting the map")#linebreak()#text(" ")#mi("\\pi: \\overline{U} \\uplus (A \\setminus U) \\rightarrow A = \\overline{U} \\cup (A \\setminus U)")#linebreak()#text(" gives a map")#linebreak()#text(" ")#mi("\\bar{\\pi}: \\{ \\bullet_U \\rightarrow \\star_{\\overline{U} \\setminus U} \\} \\uplus \\{ \\bullet_{A \\setminus \\overline{U}} \\rightarrow \\star_{\\overline{U} \\setminus U} \\} \\longrightarrow \\{ \\bullet_U \\rightarrow \\star_{\\overline{U} \\setminus U} \\leftarrow \\bullet_{A \\setminus \\overline{U}} \\}")#text(".")#linebreak()#text(" It is straightforward to verify that ")#mi("\\pi")#text(" is the pullback of ")#mi("\\overline{\\pi}")#text(" along the map")#linebreak()#text(" ")#mi("A \\longrightarrow \\{ \\bullet_U \\rightarrow \\star_{\\overline{U} \\setminus U} \\leftarrow \\bullet_{A \\setminus \\overline{U}} \\}")#text(",")#linebreak()#text("and that the argument in the first paragraph of the proof of Proposition 1 essentially shows the claim. QED.")

#text("To reformulate Corollary 6 and Proposition 1, it helps to view “solving the lifting problem” as a relation between two morphisms, rather than an object and a morphism, and then consider the orthogonal complement with respect to that relation.")

#text("Namely, define a binary relation ")#mi("\\iota \\perp \\pi")#text(" on morphisms so that ")#mi("A")#text(" solves the lifting property for ")#mi("\\pi")#text(" iff ")#mi("\\emptyset \\rightarrow A \\perp \\pi")#text(", as follows:")#linebreak()#text(" ")#mi("A_0 \\xrightarrow{\\iota} A \\perp X \\xrightarrow{\\pi} Y")#text(" iff")#linebreak()#text(" for each ")#mi("f: A \\rightarrow Y")#text(" and each ")#mi("f_0: A_0 \\rightarrow X")#text(" making the square commute,")#linebreak()#text("there is a lift ")#mi("\\tilde{f}: A \\rightarrow X")#text(" making the whole diagram commute.")

#text("For a class ")#mi("P")#text(" of morphisms, denote its left and right orthogonal complements by ")#mi("P^{\\perp l}")#text(" and ")#mi("P^{\\perp r}")#text(":")#linebreak()#text(" ")#mi("P^{\\perp l} := \\{ \\iota : \\forall \\rho \\in P, \\iota \\perp \\rho \\}")#linebreak()#mi("P^{\\perp r} := \\{ \\rho : \\forall \\iota \\in P, \\iota \\perp \\rho \\}")

#text("I think it is an open question whether for each small set ")#mi("P")#text(" it holds that each map ")#mi("f: A_0 \\rightarrow X")#text(" decomposes as")#linebreak()#text(" ")#mi("A_0 \\xrightarrow{\\iota} A \\xrightarrow{\\tau} X")#text(" with ")#mi("\\iota \\in P^{\\perp l}")#text(" and ")#mi("\\tau \\in P^{\\perp lr} := (P^{\\perp l})^{\\perp r}")#text(",")#linebreak()#text(" and, dually,")#linebreak()#text(" ")#mi("A_0 \\xrightarrow{\\iota} A \\xrightarrow{\\tau} X")#text(" with ")#mi("\\iota \\in P^{\\perp rl} := (P^{\\perp r})^{\\perp l}")#text(" and ")#mi("\\tau \\in P^{\\perp r}")#text(".")#linebreak()#text("(If this happens, such a pair ")#mi("(P^{\\perp l}, P^{\\perp lr})")#text(" or ")#mi("(P^{\\perp rl}, P^{\\perp r})")#text(" would be called a weak factorisation system (co)generated by ")#mi("P")#text(".)")
]
