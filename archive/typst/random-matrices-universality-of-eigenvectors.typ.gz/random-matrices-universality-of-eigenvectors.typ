// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/
// Converted to Typst by tao2typ: "2026-10-14T16:36:26.929910+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "Random matrices: Universality of eigenvectors", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 12pt, lang: "en")
#set par(
  justify: true,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("Random matrices: Universality of eigenvectors")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 16 March 2011")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/")[#text("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

#link("http://www.math.rutgers.edu/~vanvu/")[#text("Van Vu")]#text(" and I have just uploaded to the arXiv our paper “")#link("http://arxiv.org/abs/1103.2801")[#text("Random matrices: Universality of eigenvectors")]#text("“, submitted to ")#link("http://www.worldscinet.com/rmta/")[#text("Random Matrices: Theory and Applications")]#text(". This paper concerns an extension of ")#link("https://terrytao.wordpress.com/2009/06/03/random-matrices-universality-of-local-eigenvalue-statistics/")[#text("our four moment theorem")]#text(" for eigenvalues. Roughly speaking, that four moment theorem asserts (under mild decay conditions on the coefficients of the random matrix) that the fine-scale structure of individual eigenvalues of a Wigner random matrix depend only on the first four moments of each of the entries.")

#text("In this paper, we extend this result from eigenvalues to eigen")#emph[#text("vectors")]#text(", and specifically to the coefficients of, say, the ")#mi("{i^{th}}")#text(" eigenvector ")#mi("{u_i(M_n)}")#text(" of a Wigner random matrix ")#mi("{M_n}")#text(". Roughly speaking, the main result is that the distribution of these coefficients also only depends on the first four moments of each of the entries. In particular, as the distribution of coefficients eigenvectors of invariant ensembles such as GOE or GUE are known to be asymptotically gaussian real (in the GOE case) or gaussian complex (in the GUE case), the same asymptotic automatically holds for Wigner matrices whose coefficients match GOE or GUE to fourth order.")

#text("(A technical point here: strictly speaking, the eigenvectors ")#mi("{u_i(M_n)}")#text(" are only determined up to a phase, even when the eigenvalues are simple. So, to phrase the question properly, one has to perform some sort of normalisation, for instance by working with the coefficients of the spectral projection operators ")#mi("{P_i(M_n) := u_i(M_n) u_i(M_n)^*}")#text(" instead of the eigenvectors, or rotating each eigenvector by a random phase, or by fixing the first component of each eigenvector to be positive real. This is a fairly minor technical issue here, though, and will not be discussed further.)")

#text("This theorem strengthens a four moment theorem for eigenvectors recently established ")#link("http://arxiv.org/abs/1102.0057")[#text("by Knowles and Yin")]#text(" (by a somewhat different method), in that the hypotheses are weaker (no level repulsion assumption is required, and the matrix entries only need to obey a finite moment condition rather than an exponential decay condition), and a slightly stronger conclusion (less regularity is needed on the test function, and one can handle the joint distribution of polynomially many coefficients, rather than boundedly many coefficients). On the other hand, the Knowles-Yin paper can also handle generalised Wigner ensembles in which the variances of the entries are allowed to fluctuate somewhat.")

#text("The method used here is a variation of that in our original paper (incorporating the subsequent improvements to extend the four moment theorem from the bulk to the edge, and to replace exponential decay by a finite moment condition). That method was ultimately based on the observation that if one swapped a single entry (and its adjoint) in a Wigner random matrix, then an individual eigenvalue ")#mi("{\\lambda_i(M_n)}")#text(" would not fluctuate much as a consequence (as long as one had already truncated away the event of an unexpectedly small eigenvalue gap). The same analysis shows that the projection matrices ")#mi("{P_i(M_n)}")#text(" obeys the same stability property.")

#text("As an application of the eigenvalue four moment theorem, we establish a four moment theorem for the coefficients of resolvent matrices ")#mi("{(\\frac{1}{\\sqrt{n}} M_n - zI)^{-1}}")#text(", even when ")#mi("{z}")#text(" is on the real axis (though in that case we need to make a level repulsion hypothesis, which has been already verified in many important special cases and is likely to be true in general). This improves on an earlier four moment theorem for resolvents ")#link("http://arxiv.org/abs/1001.3453")[#text("of Erdos, Yau, and Yin")]#text(", which required ")#mi("{z}")#text(" to stay some distance away from the real axis (specifically, that ")#mi("{\\text{Im}(z) \\geq n^{-1-c}}")#text(" for some small ")#mi("{c>0}")#text(").")

#heading(level: 1)[#text("Comments (15)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51069")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("Dear Professor Tao,")

#text("I have a question about your paper : I do not see what argument you use, in the beginning of the proof of Th. 17 page 16, when you say that Condition C1 allows to troncate to the case when the entries have size O(n^{10/C_0}) and that one can perturb the entries to make them continuous.")

#text("Yours,")

#text("Florent Benaych-Georges")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51073")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("By Condition C1 and Chebyshev’s inequality, each matrix entry will be at most ")#mi("n^{10/C_0}")#text(" in magnitude with probability ")#mi("1-O(n^{-10})")#text(", and so by the union, all the entries of this matrix will have this property with probability ")#mi("1-O(n^{-8})")#text(". So we may truncate the atom distribution to the ")#mi("O(n^{10/C_0})")#text(" regime with an error of only ")#mi("O(n^{-8})")#text(" in the final expectation. (There is a minor technical issue that this truncation changes the first four moments of this distribution very slightly (by ")#mi("O(n^{-10})")#text(" or so), but one can perturb the atom distribution slightly to correct for this, using the Weyl inequalities to measure the error which will be something like ")#mi("O(n^{-6})")#text(" (say), which is still acceptable.)")

#text("Similarly, if one has a discrete atom distribution, one can perturb it (e.g. by adding a small multiple of a gaussian) to obtain a new distribution that is continuous and has essentially the same first four moments (up to an arbitrarily small error). Again, one can use the Weyl inequalities to control the error (in fact, just a qualitative continuity argument would work in this case).")

#text("(These are examples of the more general “create an epsilon of room” argument: ")#link("http://www.tricki.org/article/Create_an_epsilon_of_room")[#text("http://www.tricki.org/article/Create_an_epsilon_of_room")]#text(" )")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51096")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("Drag Professor Tao,")#linebreak()#text(" Thanks a lot for your answer.")#linebreak()#text(" However, I do not see which inequality allows to control the eigenvectors of the Wigner matrix by the ones of the perturbed one.")#linebreak()#text(" Would you please indicate it to me?")#linebreak()#text(" Yours,")#linebreak()#text(" fbg")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51097")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 29 March 2011")])]

#text("In m’y previous message: “drag” –> “dear”.")#linebreak()#text(" Misprint!")
]

#pad(left: 9pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51101")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("Ah, right, one is dealing with eigenvectors here as well as eigenvalues. But one could use for instance Lemma 22 in the paper (noting that one is already truncated to the region where there is an eigenvalue gap) to provide a suitable bound for the error in the perturbation (with plenty of powers of n to spare). Alternatively, one could weaken the hypotheses of the four moment theorem a little by allowing each of the four moments to vary by, say, O(n^{-10}), rather than match exactly, in which case one can truncate without needing to adjust the atom distributions outside of an event of small probability. (One still needs an adjustment to make the distributions continuous, but this is a qualitative adjustment that requires no quantitative bounds, and the qualitative Lemma 21 would suffice here.) We’ll add a note to the text to clarify this point.")
]
]
]
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51109")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("Dear Professor Tao,")

#text("Thanks a lot for your answer.")

#text("In fact, what I am looking for (under possible additional hypotheses) is a rate of convergence for the convergence stated in Equation (2) of your paper (page 6).")

#text("To get it, I would need a result stating that for any finite set I of {1,..,n} (possibly depending on n, but with fixed cardinality), the eigenvalues with index in I (say, for example, the first, the fourth and the sixth eigenvalues) all have multiplicity one with overwhelming probability (whereas I only found results stating this with high probability).")

#text("I would rather say that this assertion is true, but I do not know where I could find it.")

#text("Do you know if such a result exists ?")

#text("Yours,")#linebreak()#text(" Florent Benaych-Georges")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51112")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 30 March 2011")])]

#text("This type of bound (overwhelming probability that eigenvalues are simple) is not yet in the literature, though Van and I are working on such a bound and hope to be able to have some results to announce in this direction soon. There are good repulsion estimates from a fixed energy E (i.e. the probability that some eigenvalue lambda_i is equal or very close to E can be bounded well), for instance by Erdos, Schlein, and Yau (under some smoothness hypotheses on the entries) and also recently by ")#strike[#text("Rudelson")]#text(" Vershynin (in the model case E=0) but this is not quite the same as getting estimates for simplicity of eigenvalues (though it may be enough to get good bounds on the event that eigenvalue multiplicity exceeds, say, three).")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51131")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 31 March 2011")])]

#text("Thanks a lot for your answer. I’m looking forward to read your new results in this direction.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51164")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2011")])]

#text("Dear Professor Tao,")#linebreak()#text(" I have another question : why do we have to suppose that m<=10 in Lemma 24 ? Could the number 10 be replaced by any fixed upper bound ?")#linebreak()#text(" Yours,")#linebreak()#text(" fbg")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51171")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 April 2011")])]

#text("Yes, any fixed m (which is at least 5) will work for the purposes of the four moment theorem.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/bb3ecdff714503271026e0b788f5d9f0b35183404929d38dc5c98c28bd3ea1a0-3844e5e2796c13322d5df07501a83d5f79a96168c262f95a485f2b8e6122ee95.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Vu ha Van")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51192")[#strong[#text("Vu ha Van")]]#text(size: 9pt, fill: rgb("596477"), " · 2 April 2011")])]

#text("Actually, Rudelson should be Vershynin. ")#emph[#text("[Gah! Corrected, thanks – T.]")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/aee8b264b23eab4a8ccdcdc0203b3d4da285321c2393053ae490290d2402c621-6051c260508c9a5c6bebd88a873dd2be62b8fc479a50f7353168143c373d680e.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Florent Benaych-Georges")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-51473")[#strong[#text("Florent Benaych-Georges")]]#text(size: 9pt, fill: rgb("596477"), " · 8 April 2011")])]

#text("Dear Professor Tao,")

#text("I have uploaded to the arXiv a paper called “Eigenvectors of Wigner matrices: universality of global fluctuations” ( ")#link("http://arxiv.org/abs/1104.1219")[#text("http://arxiv.org/abs/1104.1219")]#text(" ), where I give a kind of (weak) global version of the “eigenvectors part” of your result. In this paper, I use some of the estimates you prove in your paper, especially Equation (27) of your Lemma 24, a bound I had been looking for for a while.")

#text("Yours,")

#text("Florent Benaych-Georges")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-688519")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 30 July 2025")])]

#text("Dear Professor Tao,")

#text("I was wondering whether Theorem 7 in your paper—or similarly, Theorem 8—admits a sharper bound on the right-hand side. Specifically, is it possible to improve the error to O(1/N^x)")

#text("for some x>0, provided that more moments are matched between the matrices?")

#text("For instance, could one obtain x=2 if the matching holds up to higher moments? This seems analogous to the situation in the Lindeberg exchange method for proving the central limit theorem, where more moment matching yields better convergence.")

#text("Thank you very much for your time.")

#text("Best regards,")#linebreak()#text("Eric")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-688531")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 1 August 2025")])]

#text("I believe there is more recent work than this paper (eg., by Erdos and Yau) on eigenvector universality that does obtain this sort of polynomial convergence, though the universality is often phrased a little differently (e.g., in terms of universality of Greens’ functions) and it can require some non-trivial effort to translate the results to a comparable form.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2011/03/16/random-matrices-universality-of-eigenvectors/#comment-688555")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 6 August 2025")])]

#text("There has been certain work in this direction where one attempts to use further matching moments to derive bounds on the minimum eigenvalue gap. This is done in work of Albert Zhang ")#link("https://arxiv.org/pdf/2507.20442")[#text("https://arxiv.org/pdf/2507.20442")]#text(".")
]
]
]
