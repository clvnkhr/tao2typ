// Generated from tao2typ IR schema 1.
// Original article: https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/
// Converted to Typst by tao2typ: "2026-10-14T15:16:27.943273+00:00"
#import "@preview/mitex:0.2.7": mi, mitex
#set document(title: "“Math Doesn’t Suck”, and the Chayes-McKellar-Winn theorem", author: "Terence Tao")
#set page(paper: "a4", margin: (x: 24mm, y: 23mm), numbering: "1", number-align: center)
#set text(font: ("Libertinus Serif", "New Computer Modern"), size: 11pt, lang: "en")
#set block(spacing: 0.9em)
#set par(
  justify: true, leading: 0.65em, spacing: 0.65em,
  first-line-indent: (amount: 1.5em, all: false),
  justification-limits: (tracking: (min: -0.01em, max: 0.01em)),
)
#set heading(numbering: none)
#show heading: set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#show heading.where(level: 1): set text(size: 15pt, weight: "semibold")
#show heading.where(level: 2): set text(size: 12pt, weight: "semibold")
#show link: set text(fill: rgb("275d8c"))
#set list(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set enum(indent: 1.2em, body-indent: 0.6em, spacing: 0.6em)
#set math.equation(numbering: none)
#show raw.where(block: true): it => block(
  width: 100%, breakable: true, fill: rgb("f5f6f8"), inset: 9pt, radius: 3pt,
)[#text(size: 9pt)[#it]]

#text(size: 9pt, fill: rgb("596477"))[#text("What's new")]
#v(5pt)
#block(above: 0pt, below: 0pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#text(size: 23pt, weight: "semibold", hyphenate: false)[#text("“Math Doesn’t Suck”, and the Chayes-McKellar-Winn theorem")]]
#v(7pt)
#text(size: 10pt)[#text("Terence Tao · 20 August 2007")]
#v(3pt)
#text(size: 8pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/")[#text("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/")]]
#v(3pt)
#text(size: 6.5pt, fill: rgb("596477"))[#link("https://clvnkhr.github.io/tao2typ/")[#text("tao2typ")]#text(" · converted to Typst 2026-10-14 (UTC)")]
#v(9pt)
#line(length: 100%, stroke: 0.7pt + rgb("d9dfe8"))
#v(10pt)

// Fit an unnumbered single display to its actual local text measure.
#let tao-fit-display(body) = context layout(size => {
  let natural = [#show math.equation: set block(width: auto)
  #body]
  let width = measure(natural).width
  if width > size.width {
    align(center, scale((size.width / width) * 100%, reflow: true, natural))
  } else { body }
})

#text("As you may already know, ")#link("http://en.wikipedia.org/wiki/Danica_McKellar")[#text("Danica McKellar")]#text(", the actress and UCLA mathematics alumnus, has recently launched her book “")#link("http://www.mathdoesntsuck.com/")[#text("Math Doesn’t Suck")]#text("“, which is aimed at pre-teenage girls and is a friendly introduction to middle-school mathematics, such as the arithmetic of fractions. The book has received ")#link("http://www.mathdoesntsuck.com/main.php?p=reviews")[#text("quite a bit of publicity")]#text(", most of it rather favourable, and is selling quite well; at one point, it even made the ")#link("http://www.amazon.com/gp/bestsellers/books")[#text("Amazon top 20 bestseller list")]#text(", which is a remarkable achievement for a mathematics book. (The current Amazon rank can be viewed in the product details of ")#link("http://www.amazon.com/Math-Doesnt-Suck-Middle-School-Breaking/dp/1594630399/ref=pd_bbs_sr_1/102-8395369-2275314?ie=UTF8&s=books&qid=1187367796&sr=1-1")[#text("the Amazon page for this book")]#text(".)")

#text("I’m very happy that the book is successful for a number of reasons. Firstly, I got to know Danica for a few months (she took my Introduction to Topology class way back in 1997, and in fact was the second-best student there; the class web page has long since disappeared, but you can at least see the ")#link("http://www.math.ucla.edu/%7Etao/resource/general/121.1.00s/exam1.pdf")[#text("midterm")]#text(" and ")#link("http://www.math.ucla.edu/%7Etao/resource/general/121.1.00s/exam3.pdf")[#text("final")]#text("), and it is always very heartening to see a former student put her or his mathematical knowledge to good use :-) . Secondly, Danica is a wonderful role model and it seems that this book will encourage many school-age kids to give maths a chance. But the final reason is that the book is, in fact, rather good; the mathematical content is organised in a logical manner (for instance, it begins with prime factorisation, then covers least common multiples, then addition of fractions), well motivated, and interleaved with some entertaining, insightful, and slightly goofy digressions, anecdotes, and analogies. (To give one example: to motivate why dividing 6 by 1/2 should yield 12, she first discussed why 6 divided by 2 should give 3, by telling a story about having to serve lattes to a whole bunch of actors, where each actor demands two lattes each, but one could only carry the weight of six lattes at a time, so that only ")#mi("6/2=3")#text(" actors could be served in one go; she then asked what would happen instead of each actor only wanted half a latte instead of two. Danica also gives a very clear explanation of the concept of a variable (such as ")#mi("x")#text("), by using the familiar concept of a nickname given to someone with a complicated real name as an analogy.)")

#text("While I am not exactly in the target audience for this book, I can relate to its pedagogical approach. When I was a kid myself, one of my favourite maths books was a very obscure (and now completely out of print) book called “")#link("http://isbn2book.com/0-03-900031-1/creating_calculus/")[#text("Creating Calculus")]#text("“, which introduced the basics of single-variable calculus via concocting a number of slightly silly and rather contrived stories which always involved one or more ants. For instance, to illustrate the concept of a derivative, in one of these stories one of the ants kept walking up a mathematician’s shin while he was relaxing against a tree, but started slipping down at a point where the slope of the shin reached a certain threshold; this got the mathematician interested enough to compute that slope from first principles. The humour in the book was rather corny, involving for instance some truly awful puns, but it was perfect for me when I was 11: it inspired me to ")#emph[#text("play")]#text(" with calculus, which is an important step towards improving one’s understanding of the subject beyond a superficial level. (Two other books in a similarly playful spirit, yet still full of genuine scientific substance, are “")#link("http://www.amazon.com/Darwin-Beginners-Jonathan-Miller/dp/0679725113")[#text("Darwin for beginners")]#text("” and “")#link("http://www.cambridge.org/uk/popsci/catalogue/0521447712/")[#text("Mr. Tompkins in paperback")]#text("“, both of which I also enjoyed very much as a kid. They are of course no substitute for a serious textbook on these subjects, but they ")#emph[#text("complement ")]#text("such treatments excellently.)")

#text("Anyway, Danica’s book has already ")#link("http://scienceblogs.com/intersection/2007/08/review_of_math_doesnt_suck_bec_1.php")[#text("been")]#text(" ")#link("http://scienceblogs.com/aetiology/2007/07/danica_mckelllars_math_doesnt.php")[#text("reviewed")]#text(" ")#link("http://www.mathdoesntsuck.com/main.php?p=reviews")[#text("in")]#text(" ")#link("http://www.amazon.com/gp/product/customer-reviews/1594630399/sr=1-1/qid=1187367796/ref=cm_cr_dp_all_summary/102-8395369-2275314?ie=UTF8&n=283155&s=books&qid=1187367796&sr=1-1#customerReviews")[#text("several")]#text(" ")#link("http://www.gnxp.com/blog/2007/08/brains-and-beauty-review-of-math-doesnt.php")[#text("places")]#text(", and there’s not much more I can add to what has been said elsewhere. I thought however that I could talk about another of Danica’s contributions to mathematics, namely her paper “")#link("http://www.ams.org/mathscinet-getitem?mr=1654857")[#text("Percolation and Gibbs states multiplicity for ferromagnetic Ashkin-Teller models on ")#mi("{\\Bbb Z}^2")]#text("” (PDF available ")#link("http://www.danicamckellar.com/math/percolation.pdf")[#text("here")]#text("), joint with Brandy Winn and my colleague ")#link("http://www.math.ucla.edu/~lchayes/")[#text("Lincoln Chayes")]#text(". (Brandy, incidentally, was the only student in my topology class who did better than Danica; she has recently obtained a PhD in mathematics from U. Chicago, with a ")#link("http://www.springerlink.com/content/n82703w3105jh807/")[#text("thesis in PDE")]#text(".) This paper is noted from time to time in the above-mentioned publicity, and its main result is sometimes referred to there as the “Chayes-McKellar-Winn theorem”, but as far as I know, no serious effort has been made to explain exactly what this theorem is, or the wider context the result is placed in :-) . So I’ll give it a shot; this allows me an opportunity to talk about some beautiful topics in mathematical physics, namely ")#link("http://en.wikipedia.org/wiki/Statistical_mechanics")[#text("statistical mechanics")]#text(", ")#link("http://en.wikipedia.org/wiki/Spontaneous_magnetization")[#text("spontaneous magnetisation")]#text(", and ")#link("http://en.wikipedia.org/wiki/Percolation")[#text("percolation")]#text(".")

#text("[")#emph[#text("Update")]#text(", Aug 23: I added a non-technical “executive summary” of what the Chayes-McKellar-Winn theorem is at the very end of this post.]")

#heading(level: 1)[#metadata(none) <tao-b6c3a6e0f3c3c0224ea5>#text("— Statistical mechanics —")]

#text("To begin the story, I would like to quickly review the theory of ")#link("http://en.wikipedia.org/wiki/Statistical_mechanics")[#text("statistical mechanics")]#text(". This is the theory which bridges the gap between the microscopic (particle physics) description of many-particle systems, and the macroscopic (")#link("http://en.wikipedia.org/wiki/Thermodynamics")[#text("thermodynamic")]#text(") description, giving a semi-rigorous explanation of the empirical laws of the latter in terms of the fundamental laws of the former.")

#text("Statistical mechanics is a remarkably general theory for describing many-particle systems – for instance it treats classical and quantum systems in almost exactly the same way! But to simplify things I will just discuss a toy model of the microscopic dynamics of a many-particle system S – namely a finite ")#link("http://en.wikipedia.org/wiki/Markov_chain")[#text("Markov chain model")]#text(". In this model, time is discrete, though the interval between discrete times should be thought of as extremely short. The state space is also discrete; at any given time, the number of possible ")#link("http://en.wikipedia.org/wiki/Microstate_%28statistical_mechanics%29")[#text("microstates")]#text(" that the system S could be in is finite (though extremely large – typically, it is exponentially large in the number N of particles). One should view the state space of S as a directed graph with many vertices but relatively low degree. After each discrete time interval, the system may move from one microstate to an adjacent one on the graph, where the transition probability from one microstate to the next is independent of time, or on the past history of the system. We make the key assumption that the counting measure on microstates is invariant, or equivalently that the sum of all the transition probabilities that lead one away from a given microstate equals the sum of all the transition probabilities that lead one towards that microstate. (In classical systems, governed by ")#link("http://en.wikipedia.org/wiki/Hamiltonian_mechanics")[#text("Hamiltonian mechanics")]#text(", the analogue of this assumption is ")#link("http://en.wikipedia.org/wiki/Liouville%27s_theorem_%28Hamiltonian%29")[#text("Liouville’s theorem")]#text("; in quantum systems, governed by ")#link("http://en.wikipedia.org/wiki/Schr%C3%B6dinger_equation")[#text("Schrödinger’s equation")]#text(", the analogue is the unitarity of the evolution operator.) We also make the mild assumption that the transition probability across any edge is positive.")

#text("If the graph of microstates was connected (i.e. one can get from any microstate to any other by some path along the graph), then after a sufficiently long period of time, the probability distribution of the microstates will converge towards normalised counting measure, as can be seen by basic Markov chain theory. However, if the system S is isolated (i.e. not interacting with the outside world), ")#emph[#text("conservation laws")]#text(" intervene to disconnect the graph. In particular, if each microstate x had a total energy H(x), and one had a law of conservation of energy which meant that microstates could only transition to other microstates with the same energy, then the probability distribution could be trapped on a single ")#emph[#text("energy surface")]#text(", defined as the collection ")#mi("\\{ x: H(x) = E \\}")#text(" of all microstates of S with a fixed total energy E.")

#text("Physics has many conservation laws, of course, but to simplify things let us suppose that energy is the ")#emph[#text("only")]#text(" conserved quantity of any significance (roughly speaking, this means that no other conservation law has a significant impact on the entropy of possible microstates). In fact, let us make the stronger assumption that the energy surface is ")#emph[#text("connected")]#text("; informally, this means that there are no “secret” conservation laws beyond the energy which could prevent the system evolving from one side of the energy surface to the other.")

#text("In that case, Markov chain theory lets one conclude that if the solution started out at a fixed total energy E, and the system S was isolated, then the limiting distribution of microstates would just be the uniform distribution on the energy surface ")#mi("\\{ x: H(x) = E \\}")#text("; every state on this surface is equally likely to occur at any given instant of time (this is known as the ")#link("http://en.wikipedia.org/wiki/Statistical_mechanics#Fundamental_postulate")[#text("fundamental postulate of statistical mechanics")]#text(", though in this simple Markov chain model we can actually derive this postulate rigorously). This distribution is known as the ")#link("http://en.wikipedia.org/wiki/Microcanonical_ensemble")[#text("microcanonical ensemble")]#text(" of S at energy E. It is remarkable that this ensemble is largely independent of the actual values of the transition probabilities; it is only the energy E and the function H which are relevant. (This analysis is perfectly rigorous in the Markov chain model, but in more realistic models such as Hamiltonian mechanics or quantum mechanics, it is much more difficult to rigorously justify convergence to the microcanonical ensemble. The trouble is that while these models appear to have a chaotic dynamics, which should thus exhibit very pseudorandom behaviour (similar to the genuinely random behaviour of a Markov chain model), it is very difficult to demonstrate this pseudorandomness rigorously; the same difficulty, incidentally, is ")#link("https://terrytao.wordpress.com/2007/03/18/why-global-regularity-for-navier-stokes-is-hard/")[#text("present in the Navier-Stokes regularity problem")]#text(".)")

#text("In practice, of course, a small system S is almost never truly isolated from the outside world S’, which is a far larger system; in particular, there will be additional transitions in the combined system ")#mi("S \\cup S^{\\prime}")#text(", through which S can exchange energy with S’. In this case we do not expect the S-energy H(x) of the combined microstate (x,x’) to remain constant; only the global energy H(x) + H'(x’) will equal a fixed number E. However, we can still view the larger system ")#mi("S \\cup S^{\\prime}")#text(" as a massive isolated system, which will have some microcanonical ensemble; we can then project this ensemble onto S to obtain the ")#link("http://en.wikipedia.org/wiki/Canonical_ensemble")[#text("canonical ensemble")]#text(" for that system, which describes the distribution of S when it is in ")#link("http://en.wikipedia.org/wiki/Thermal_equilibrium")[#text("thermal equilibrium")]#text(" with S’. (Of course, since we have not yet experienced ")#link("http://en.wikipedia.org/wiki/Heat_death")[#text("heat death")]#text(", the entire outside world is not yet in the microcanonical ensemble; but in practice, we can immerse a small system in a ")#link("http://en.wikipedia.org/wiki/Heat_bath")[#text("heat bath")]#text(", such as the atmosphere, which accomplishes a similar effect.)")#linebreak()#text(" Now it would seem that in order to compute what this canonical ensemble is, one would have to know a lot about the external system S’, or the total energy E. Rather astonishingly, though, as long as S’ is much larger than S, and obeys some plausible physical assumptions, we can specify the canonical ensemble of S using only a single scalar parameter, the ")#link("http://en.wikipedia.org/wiki/Temperature")[#text("temperature")]#text(" T. To see this, recall in the microcanonical ensemble of ")#mi("S \\cup S^{\\prime}")#text(", each microstate (x,x’) with combined energy H(x)+H'(x’)=E has an equal probability of occurring at any given time. Thus, given any microstate x of S, the probability that x occurs at a given time will be proportional to the cardinality of the set ")#mi("\\{ x^{\\prime}: H(x^{\\prime}) = E - H(x) \\}")#text(". Now as the outside system S’ is very large, this set will be be enormous, and presumably very complicated as well; however, the key point is that it only depends on E and x through the quantity E-H(x). Indeed, we conclude that the canonical ensemble distribution of microstates at x is proportional to ")#mi("\\Omega(E - H(x))")#text(", where ")#mi("\\Omega(E^{\\prime})")#text(" is the number of microstates of the outside system S’ with energy E’.")

#text("Now it seems that it is hopeless to compute ")#mi("\\Omega(E^{\\prime})")#text(" without knowing exactly how the system S’ works. But, in general, the number of microstates in a system tends to grow exponentially in the energy in some fairly smooth manner, thus we have ")#mi("\\Omega(E^{\\prime}) = \\exp(F(E^{\\prime}))")#text(" for some smooth increasing function F of E’ (although in some rare cases involving ")#link("http://en.wikipedia.org/wiki/Population_inversion")[#text("population inversion")]#text(", F may be decreasing). Now, we are assuming S’ is much larger than S, so E should be very large compared with H(x). In such a regime, we expect Taylor expansion to be reasonably accurate, thus ")#mi("\\Omega(E - H(x)) \\approx \\exp( F(E) - \\beta H(x) )")#text(", where ")#mi("\\beta := F^{\\prime}(E)")#text(" is the derivative of F at E (or equivalently, the ")#link("http://en.wikipedia.org/wiki/Logarithmic_derivative")[#text("log-derivative")]#text(" of ")#mi("\\Omega")#text("); note that we are assuming ")#mi("\\beta")#text(" to be positive. The quantity ")#mi("\\exp(F(E))")#text(" doesn’t depend on x, and so we conclude that the canonical ensemble is proportional to counting measure, multiplied by the function ")#mi("\\exp( - \\beta H(x) )")#text(". Since probability distributions have total mass 1, we can in fact describe the probability ")#mi("P(x)")#text(" of the canonical ensemble being at x exactly as")

#align(center)[#tao-fit-display[#mitex("P(x) = \\frac{1}{Z} e^{-\\beta H(x)}")]]

#text("where ")#mi("Z")#text(" is the ")#link("http://en.wikipedia.org/wiki/Partition_function_%28statistical_mechanics%29")[#text("partition function")]

#align(center)[#tao-fit-display[#mitex("Z := \\sum_x e^{-\\beta H(x)}.")]]

#text("The canonical ensemble is thus specified completely except for a single parameter ")#mi("\\beta > 0")#text(", which depends on the external system S’ and on the total energy E. But if we take for granted the ")#link("http://en.wikipedia.org/wiki/Laws_of_thermodynamics")[#text("laws of thermodynamics")]#text(" (particularly the ")#link("http://en.wikipedia.org/wiki/Zeroth_law_of_thermodynamics")[#text("zeroth law")]#text("), and compare S’ with an ")#link("http://en.wikipedia.org/wiki/Ideal_gas")[#text("ideal gas")]#text(", we can obtain the relationship ")#mi("\\beta = 1/kT")#text(", where T is the ")#link("http://en.wikipedia.org/wiki/Temperature")[#text("temperature")]#text(" of S’ and k is ")#link("http://en.wikipedia.org/wiki/Boltzmann_constant")[#text("Boltzmann’s constant")]#text(". Thus the canonical ensemble of a system S is completely determined by the temperature, and on the energy functional H. The underlying transition graph and transition probabilities, while necessary to ensure that one eventually attains this ensemble, do not actually need to be known in order to compute what this ensemble is, and can now (amazingly enough) be discarded. (More generally, the microscopic laws of physics, whether they be classical or quantum, can similarly be discarded almost completely at this point in the theory of statistical mechanics; the only thing one needs those laws of physics to provide is a description of all the microstates and their energy [though in some situations one also needs to be able to compute other conserved quantities, such as particle number].)")

#text("At the temperature extreme ")#mi("T \\to 0")#text(", the canonical ensemble becomes concentrated at the minimum possible energy ")#mi("E_{\\text{min}}")#text(" for the system (this fact, incidentally, inspires the numerical strategy of ")#link("http://en.wikipedia.org/wiki/Simulated_annealing")[#text("simulated annealing")]#text("); whereas at the other temperature extreme ")#mi("T \\to \\infty")#text(", all microstates become equally likely, regardless of energy.")

#heading(level: 1)[#text("— Gibbs states —")]

#text("One can of course continue developing the theory of statistical mechanics and relate temperature and energy to other macroscopic variables such as volume, particle number, and entropy (see for instance Schrödinger’s classic little book “")#link("http://books.google.com/books?id=eW9VOZqHsXoC")[#text("Statistical thermodynamics")]#text("“), but I’ll now turn to the topic of ")#link("http://en.wikipedia.org/wiki/Gibbs_state")[#text("Gibbs states")]#text(" of infinite systems, which is one of the main concerns of the Chayes-McKellar-Winn paper.")

#text("A Gibbs state is simply a distribution of microstates of a system which is invariant under the dynamics of that system, physically, such states are supposed to represent an equilibrium state of the system. For systems S with finitely many degrees of freedom, the microcanonical and canonical systems given above are examples of Gibbs states. But now let us consider systems with infinitely many degrees of freedom, such as those arising from an infinite number of particles (e.g. particles in a lattice). One cannot now argue as before that the entire system is going to be in a canonical ensemble; indeed, as the total energy of the system is likely to be infinite, it is not even clear that such an ensemble still exists. However, one can still argue that any localised portion ")#mi("S_1")#text(" of the system (with finitely many degrees of freedom) should still be in a canonical ensemble, by treating the remaining portion ")#mi("S \\backslash S_1")#text(" of the system as a heat bath that ")#mi("S_1")#text(" is immersed in. Furthermore, the zeroth law of thermodynamics suggests that all such localised subsystems should be at the same temperature T. This leads to the definition of a Gibbs state at temperature T for a global system S: it is any probability distribution of microstates whose projection to any local subsystem ")#mi("S_1")#text(" is in the microcanonical ensemble at temperature T. (To make this precise, one needs probability theory on infinite dimensional spaces, but this can be put on a completely rigorous footing, using the theory of ")#link("http://en.wikipedia.org/wiki/Product_measure")[#text("product measures")]#text(". There are also some technical issues regarding compatibility on the boundary between ")#mi("S_1")#text(" and ")#mi("S \\backslash S_1")#text(" which I will ignore here.)")

#text("For systems with finitely many degrees of freedom, there is only one canonical ensemble at temperature T, and thus only one Gibbs state at that temperature. However, for systems with infinitely many degrees of freedom, it is possible to have more than one Gibbs state at a given temperature. This phenomenon manifests itself physically via ")#link("http://en.wikipedia.org/wiki/Phase_transitions")[#text("phase transitions")]#text(", the most familiar of which involves transitions between solid, liquid, and gaseous forms of matter, but also includes things like spontaneous magnetisation or demagnetisation. Closely related to this is the phenomenon of ")#link("http://en.wikipedia.org/wiki/Spontaneous_symmetry_breaking")[#text("spontaneous symmetry breaking")]#text(", in which the underlying system (and in particular, the energy functional H) enjoys some symmetry (e.g. translation symmetry or rotation symmetry), but the Gibbs states for that system do not. For instance, the laws of magnetism in a bar of iron are rotation symmetric, but there are some obviously non-rotation-symmetric Gibbs states, such as the magnetised state in which all the iron atoms have magnetic ")#link("http://en.wikipedia.org/wiki/Dipole")[#text("dipoles")]#text(" oriented with the north pole pointing in (say) the upward direction. [Of course, as the universe is finite, these systems do not truly have infinitely many degrees of freedom, but they do behave analogously to such systems in many ways.]")

#text("It is thus of interest to determine, for any given physical system, under what choices of parameters (such as the temperature T) one has non-uniqueness of Gibbs states. For “real-life” physical systems, this question is rather difficult to answer, so mathematicians have focused attention instead on some simpler toy models. One of the most popular of these is the ")#link("http://en.wikipedia.org/wiki/Square-lattice_Ising_model")[#text("Ising model")]#text(", which is a simplified model for studying phenomena such as spontaneous magnetism. A slight generalisation of the Ising model is the ")#link("http://en.wikipedia.org/wiki/Potts_model")[#text("Potts model")]#text("; the ")#link("http://en.wikipedia.org/wiki/Ashkin-Teller_model")[#text("Ashkin-Teller model")]#text(", which is studied by Chayes-McKellar-Winn, is an interpolant betwen a certain Ising model and a certain Potts model.")

#heading(level: 1)[#text("— Ising, Potts, and Ashkin-Teller models —")]

#text("All three of these models involve particles on the infinite two-dimensional lattice ")#mi("{\\Bbb Z}^2")#text(", with one particle at each lattice point (or ")#emph[#text("site")]#text("). (One can also consider these models in other dimensions, of course; the behaviour is quite different in different dimensions.) Each particle can be in one of a finite number of states, which one can think of as “magnetisations” of that particle. In the classical Ising model there are only two states (+1 and -1), though in the Chayes-McKellar-Winn paper, four-state models are considered. The particles do not move from their designated site, but can change their state over time, depending on the state of particles at nearby sites.")

#text("As discussed earlier, in order to do statistical mechanics, we do not actually need to specify the exact mechanism by which the particles interact with each other; we only need to describe the total energy of the system. In these models, the energy is contained in the bonds between adjacent sites on the lattice (i.e. sites which are a unit distance apart). The energy of the whole system is then the sum of the energies of all the bonds, and the energy of each bond depends only on the state of the particles at the two endpoints of the bond. (The total energy of the infinite system is then a divergent sum, but this is not a concern since one only needs to be able to compute the energy of finite subsystems, in which one only considers those particles within, say, a square of length R.) The Ising, Potts, and Ashkin-Teller models then differ only in the number of states and the energy of various bond configurations. Up to some harmless normalisations, we can describe them as follows:")

#enum(start: 1, 
[#text("In the ")#strong[#text("classical Ising model")]#text(", there are two magnetisation states (+1 and -1); the energy of a bond between two particles is -1/2 if they are in the same state, and +1/2 if they are in the opposite state (thus one expects the states to align at low temperatures and become non-aligned at high temperatures);")],
[#text("In the ")#strong[#text("four-state Ising model")]#text(", there are four magnetisation states (+1,+1), (+1,-1), (-1,+1), and (-1,-1) (which can be viewed as four equally spaced vectors in the plane), and the energy of a bond between two particles is the sum of the classical Ising bond energy between the first component of the two particle states, and the classical Ising bond energy between the second component. Thus for instance the bond energy between particles in the same state is -1, particles in opposing states is +1, and particles in orthogonal states (e.g. (+1,+1) and (+1,-1)) is 0. This system is equivalent to two non-interacting classical Ising models, and so the four-state theory can be easily deduced from the two-state theory.")],
[#text("In the ")#strong[#text("degenerate Ising model")]#text(", we have the same four magnetisation states, but now the bond energy between particles is +1 if they are in the same state or opposing state, and 0 if they are in an orthogonal state. This model essentially collapses to the two-state model after identifying (+1,+1) and (-1,-1) as a single state, and identifying (+1,-1) and (-1,+1) as a single state.")],
[#text("In the ")#strong[#text("four-state Potts model")]#text(", we have the same four magnetisation states, but now the energy of a bond between two particles is -1 if they are in the same state and 0 otherwise.")],
[#text("In the ")#strong[#text("Ashkin-Teller model")]#text(", we have the same four magnetisation states; the energy of a bond between two particles is -1 if they are in the same state, 0 if they are orthogonal, and ")#mi("\\epsilon")#text(" if they are in opposing states. The case ")#mi("\\epsilon = +1")#text(" is the four-state Ising model, the case ")#mi("\\epsilon = 0")#text(" is the Potts model, and the cases ")#mi("0 < \\epsilon < 1")#text(" are intermediate between the two, while the case ")#mi("\\epsilon=-1")#text(" is the degenerate Ising model.")]
)

#text("For the classical Ising model, there are two minimal-energy states: the state where all particles are magnetised at +1, and the state where all particles are magnetised at -1. (One can of course also take a probabilistic combination of these two states, but we may as well restrict attention to pure states here.) Since one expects the system to have near-minimal energy at low temperatures, we thus expect to have non-uniqueness of Gibbs states at low temperatures for the Ising model. Conversely, at sufficiently high temperatures the differences in bond energy should become increasingly irrelevant, and so one expects to have uniqueness of Gibbs states at high energy. (Nevertheless, there is an important ")#link("http://en.wikipedia.org/wiki/Kramers-Wannier_duality")[#text("duality relationship")]#text(" between the Ising model at low and high energies.)")

#text("Similar heuristic arguments apply for the other models discussed above, though for the degenerate Ising model there are many more minimal-energy states and so even at very low temperatures one only expects to obtain partial ordering rather than total ordering in the magnetisations.")

#text("For the Askhin-Teller models with ")#mi("0 < \\epsilon < 1")#text(", it ")#link("http://www.ams.org/mathscinet-getitem?mr=676932")[#text("was known for some time")]#text(" that there is a unique critical temperature ")#mi("T_c")#text(" (which has a physical interpretation as the ")#link("http://en.wikipedia.org/wiki/Curie_temperature")[#text("Curie temperature")]#text("), below which one has non-unique and magnetised Gibbs states (thus the expected magnetisation of any given particle is non-zero), and above which one has unique (non-magnetised) Gibbs states. (For ")#mi("\\epsilon")#text(" close to -1 there are ")#emph[#text("two")]#text(" critical temperatures, describing the transition from totally ordered magnetisation to partially ordered, and from partially ordered to unordered.) The problem of computing this temperature ")#mi("T_c")#text(" exactly, and to describe the nature of this transition, appears to be rather difficult, although there are a large number of partial results. What Chayes, McKellar, and Winn showed, though, is that this critical temperature ")#mi("T_c")#text(" is also the critical temperature ")#mi("T_p")#text(" for a somewhat simpler phenomenon, namely that of ")#link("http://en.wikipedia.org/wiki/Percolation_theory")[#text("site percolation")]#text(". Let us denote one of the magnetised states, say (+1,+1), as “blue”. We then consider the Gibbs state for a bounded region (e.g. an N x N square), subject to the boundary condition that the entire boundary is blue. In the zero temperature limit ")#mi("T \\to 0")#text(" the entire square would then be blue; in the high temperature limit ")#mi("T \\to +\\infty")#text(" each particle would have an independent random state. Consider the probability ")#mi("p_N")#text(" that a particle at the center of this square is part of the blue “boundary cluster”; in other words, the particle is not only blue, but there is a path of bond edges connecting this particle to the boundary which only goes through blue vertices. Thus we expect this probability to be close to 1 at very low temperatures, and close to 0 at very high temperatures. And indeed, standard percolation theory arguments show that there is a critical temperature ")#mi("T_p")#text(" below which ")#mi("\\lim_{N \\to \\infty} p_N")#text(" is positive (or equivalently, the boundary cluster has density bounded away from zero), and below which ")#mi("\\lim_{N \\to \\infty} p_N = 0")#text(" (thus the boundary cluster has asymptotic density zero). The “Chayes-McKellar-Winn theorem” is then the claim that ")#mi("T_c = T_p")#text(".")

#text("This result is part of a very successful program, initiated ")#link("http://www.ams.org/mathscinet-getitem?mr=359655")[#text("by Fortuin and Kasteleyn")]#text(", to analyse the statistical mechanics of site models such as the Ising, Potts, and Ashkin-Teller models via the random clusters generated by the bonds between these sites. (One of the fruits of this program, by the way, was the ")#link("http://www.ams.org/mathscinet-getitem?mr=309498")[#text("FKG correlation inequality")]#text(", which asserts that any two monotone properties on a lattice are positively correlated. This inequality has since proven to be incredibly useful in probability, combinatorics and computer science.) The claims ")#mi("T_c \\leq T_p")#text(" and ")#mi("T_p \\leq T_c")#text(" are proven separately. To prove ")#mi("T_c \\leq T_p")#text(" (i.e. multiple Gibbs states implies percolation), the main tool is a ")#link("http://www.math.ucla.edu/~lchayes/lchayes_website_folder/old_publications_folder/graph_rep_1.pdf")[#text("theorem of Chayes and Machta")]#text(" that relates the non-uniqueness of Gibbs states to positive magnetisation (the existence of states in which the expected magnetisation of a particle is non-zero). To prove ")#mi("T_p \\leq T_c")#text(" (i.e. percolation implies multiple Gibbs states), the main tool is a ")#link("http://www.ams.org/mathscinet-getitem?mr=942759")[#text("theorem of Gandolfi, Keane, and Russo")]#text(", which studied percolation on the infinite lattice and who showed that under certain conditions (in particular, that a version of the FKG inequality is satisfied), there can be at most one infinite cluster; basically, one can use the colour of this cluster (which will exist if percolation occurs) to distinguish between different Gibbs states. (The fractal structure of this infinite cluster, especially near the critical temperature, is quite interesting, but that’s a whole other story.) One of the main tasks in the Chayes-McKellar-Winn paper is to verify the FKG inequality for the Ashkin-Teller model; this is done by viewing that model as a perturbation of the Ising model, and expanding the former using the random clusters of the latter.")

#heading(level: 1)[#text("— Executive summary —")]

#text("When one heats an iron bar magnet above a certain special temperature – the ")#link("http://en.wikipedia.org/wiki/Curie_temperature")[#text("Curie temperature")]#text(" – the iron bar will cease to be magnetised; when one cools the bar again below this temperature, the bar can once again ")#link("http://en.wikipedia.org/wiki/Spontaneous_magnetization")[#text("spontaneously magnetise")]#text(" in the presence of an external magnetic field. This phenomenon is still not perfectly understood; for instance, it is difficult to predict the Curie temperature precisely from the fundamental laws of physics, although one can at least prove that this temperature exists. However, Chayes, McKellar, and Winn have shown that for a certain simplified model for magnetism (known as the ")#link("http://en.wikipedia.org/wiki/Ashkin-Teller_model")[#text("Ashkin-Teller model")]#text("), the Curie temperature is equal to the critical temperature below which ")#link("http://en.wikipedia.org/wiki/Percolation")[#text("percolation")]#text(" can occur; this means that even when the bar is unmagnetised, enough of the iron atoms in the bar spin in the same direction that they can create a connected path from one end of the bar to another. Percolation in the Ashkin-Teller model is not fully understood either, but it is a simpler phenomenon to deal with than spontaneous magnetisation, and so this result represents an advance in our understanding of how the latter phenomenon works.")

#text("See also this ")#link("http://golem.ph.utexas.edu/category/2007/08/gerbes_in_the_guardian.html#c011515")[#text("explanation by John Baez")]#text(".")

#heading(level: 1)[#text("Comments (60)")]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a25a32fb05c2052e4824ba5326aae6bc600d43377a459ee96a4cf8ab7545343d-92172839e9129ed4d21fd9c684f50943ec4afbbac867ecfe09ecb5a033260fea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Joe Kwiatkowski")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-2/#comment-471427")[#strong[#text("Joe Kwiatkowski")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2016")])]

#text("I was a poor math student all through the K-12 experience, and looking back on it, it occurs to me that the most important factor conducive to being a good math student is discipline. One has to pay attention inn class (which I did not do) nd make a sincere attempt at the homework nightly (which I did not do). I did manage to pass all of my math courses, but it was only when I took a remedial course in intermediate algebra and trig, in technical college, that I took on a math course with proper discipline. The result was an A.")

#text("So the question becomes, does Ms. McKellar include in her book any suggestions as to how to motivate the student to deliver the effort necessary to do well in math? I would be interested to see her suggestions.")

#text("Side note there: I wonder how I rated against the rest of my peer group, motivation-wise. My hypothesis is, the most difficult job a parent has is to motivate his or her kids to generate proper effort in school. This cuts across races and sexes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/819a4d6739dc729ce3bdfe2f99443d82e697d50f3eab72281962cc5a0d19e9c4-043889725b84220bb13c92dfdf62111c351f58d4c08bea90dc7ee29cc5032f82.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Dhill114")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-2/#comment-476038")[#strong[#text("Dhill114")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2017")])]

#text("The theme of Ms. McKellar’s childhood fictional drama series about learning or discovery seems to have transitioned nicely into reality for her adult life. Statistical mechanics is interesting but has many assumptions in practicality. I like the practical application of knowledge no matter who the audience is. Take it to the next level. For example a challenging concept probably just as relevant as the blog economic example or the concepts such as Pseudo-math applied Chayes-McKellar-which Winn seems to yield / correlate / implicate for the Energy or Heat transfer or Thermal effects on dipole or magnetic properties could be obscurely compared in a linear fashion to disruption of covalent bonds in molecules – research important for radioactive material compounds such as Tc-99m binding to pharmaceutical compounds or sodium iodide (I-131) valence +/- 1, may yield identification of high/low or Curie temperature or similar effects to render contaminated materials non-radioactive tangential to half life. If proven, in theory the relationship of heat or temperature effects to decontaminate or disassociate radioactive materials could allow for better adhesive filtration in applied science. Practical: incinerators used for disposal and disassociation and proper filtration of radioactive particulates and gas capture may be shown to be best practice vs. burial for disposal.")

#text("Math is just another language for communicating our understanding of things, just like the Internet of Things, whether truth or conjecture in real life. The abstract is growing in popularity. As a society we are constantly discovering what is already relational but hidden in plain sight.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-2/#comment-485064")[#strong[#text("Что такое огонь, и почему он жжёт — нанотехнологии.москва")]]#text(size: 9pt, fill: rgb("596477"), " · 17 August 2017")]

#text("[…] этого дано в блогпосте [28]Теренса Тао. Это […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-2/#comment-497314")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 26 April 2018")])]

#text("Just for anyone still reading this, the link to the PDF for the “Chayes-McKellar-Winn theorem” is now here (the old link has died): ")#link("http://www.danicamckellar.com/pdf/percolation.pdf")[#text("http://www.danicamckellar.com/pdf/percolation.pdf")]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-2/#comment-641838")[#strong[#text("What’s a fire and why does it burn? – A2Z Facts")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2022")]

#text("[…] this is the Boltzmann distribution. For one possible justification of this, see this blog post by Terence Tao. This means that the probability […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-2/#comment-641850")[#strong[#text("What’s a fire and why does it burn? (2016) by kvee - HackTech News")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2022")]

#text("[…] constant); this is the Boltzmann distribution. For one possible justification of this, see this blog post by Terence Tao. This means that the probability […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-7391")[#strong[#text("An explanation of a stat mech theorem « Entertaining Research")]]#text(size: 9pt, fill: rgb("596477"), " · 20 August 2007")]

#text("[…] explanation of a stat mech theorem Terence Tao has a nice post explaining a theorem of statistical mechanics that relates spontaneous m…. Along the way, Tao also discusses Ising and Potts models, and some interesting theorems of […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-7470")[#strong[#text("Pseudo-Polymath » Blog Archive » Morning Highlights")]]#text(size: 9pt, fill: rgb("596477"), " · 21 August 2007")]

#text("[…] Math doesn’t suck, a book and a proof by Fields Medalist Terrance Tao at his blog What’s New. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/64e4af16135ce86c4400b742ca1141f9aef69af8d1953f09a8a7b73bf27b51d4-7a4f4704062c8d33d0b54781cab1e93bb68cc3478615a7b4e2694a1dded67591.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of David Brown")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-8913")[#strong[#text("David Brown")]]#text(size: 9pt, fill: rgb("596477"), " · 9 September 2007")])]

#text("This is interesting because there are theoretical models in economics which delve into this notion of the effect of duality on group structure. Suppose we have discrete ring or field of economic “agents” with time discretized into turns, such as would be present in a game-theoretic approach. At each instant, an agent is allowed to choose whether to cooperate or defect (1 or 0) with the economic system as a whole. Payoffs for an agent are revealed in the next round, with the agent being aware of their own state/payoff and their local neighbors (arbitrarily definable) state/payoff. This means that if a player sees that their neighbor did very well last turn by cooperating, they too will cooperate in the current round.")

#text("While little progress has been made on this model as a whole, it brings to question whether an approach such as suggested here for rigorously explaining magnetism could be taken. This approach, if I’m correct, would be the full generalization of Nash’s equilibrium to N-agents.")

#text("An extreme example of this observed economic phenomenon can be seen with racially segregated neighborhoods, where a “tipping point” occurs when too many of one type of race moves in. The previously dominate race simultaneously rushes to sell their houses, flooding the market with an over-supply causing a mass-dumping of asset values and further exacerbating the problem. (It sort of reminds me of the complete yang becomes yin and vice versa from the I Ching, but thats another matter entirely.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/67e372850ec85972723c83f14c448facaa3d970c646adb0dee34efd0ae9a5c5f-d1f723bc5c22487ad9bf129c068afa62f84439142fe5e55dddeefec5852cdfd6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of anne")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-9798")[#strong[#text("anne")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("this book is horrible all u ppl who heav read it or bought it for your kid i mean seriously comon this book makes girls look stupid and its so cheesy its exactly the steriotypical type of reading content we are tired of and dont want to read! Imagine what it was like when you were younger and in school and people called you a dumb bolnde, this book is basicly saying its ok that your stupid, we are going to treat you special now and substitue everything for mascara and lipgloss so you dont heave to worry your pretty little head!!! AWW HOW STUPID! this book actually makes me feel sorry for danica mckallar, shes embarrasing herself and every single sensible girl who reads her book")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-9810")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Dear Anne,")

#text("Gender stereotyping is of course an important social problem. The obvious response is to “attack” it – and by extension perhaps, anyone who supports it, practices it, accepts it, condones it, or succumbs to it. But there is a limit as to how far a purely negative approach to a social problem can go before it becomes counterproductive.")

#text("Danica’s approach is not to attack gender stereotypes (although she does spend a lot of time debunking the “dumb blond” stereotype, if you actually read the book), but instead to ")#emph[#text("subvert")]#text(" them. She links the imagery that young girls are immersed in – shopping, boyfriends, etc. – to something more positive, in this case mathematical reasoning and problem-solving. If, after reading Danica’s book, a young girl mentally associates the decision of what shoes to buy (say) to a mathematical problem rather than to one of keeping up with the latest fashion trends, she has become ")#emph[#text("more")]#text(" empowered and resistant to stereotyping, not less; this approach may be more effective than, say, attacking the girl for considering buying shoes in the first place. Plus, she gets an opportunity to practice her mathematical reasoning skills in her everyday life, and not just in the school environment, which is valuable for a number of reasons. Personally, I think the book is a positive contribution both to mathematics education and to weakening the power of gender stereotypes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-9827")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 19 September 2007")])]

#text("Dr. Tao makes a very good point. Beside that one is this: the audience Ms. McKellar is trying to reach is exactly that group that ")#emph[#text("does")]#text(" behave like this.")

#text("All that said, did you ever think that you might not be making your best case? Your grammar and construction here are atrocious, which gives the impression that you yourself are one of the stereotyped group. Presentation means a lot, and that’s a lot of where the stereotype comes from. When you ")#emph[#text("act")]#text(" unintelligent, people will think you ")#emph[#text("are")]#text(" unintelligent.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/8faeba9182ed1728ce952dacca9fd91d111fc173d91b351328083a9b909cd206-66ba95f7ff8e0f4cd52669fcb57216bd4e24680e747286f570b2071e0599f39c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jay")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-12619")[#strong[#text("Jay")]]#text(size: 9pt, fill: rgb("596477"), " · 22 October 2007")])]

#text("Comparing math exams to bikini waxes??? Come on, one shouldn’t trivialize math to that extent. Mathematicians need to have more respect for themselves and not be submerged by pop culture.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-16298")[#strong[#text("Women in science « The Lumber Room")]]#text(size: 9pt, fill: rgb("596477"), " · 22 November 2007")]

#text("[…] I was reading a post by Terence Tao about the book Math Doesn’t Suck, which is aimed at girls in middle school. There is a review […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WA")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-22001")[#strong[#text("WA")]]#text(size: 9pt, fill: rgb("596477"), " · 25 December 2007")])]

#text("It’s all well and good to dismiss popular news coverage as being irrelevant to science, but mathematics is not a closed world, its practitioners have mundane lives and have to interact with people of disparate backgrounds, and when some former child actress dips her toe in the water and gets more public recognition than you’ll get in a lifetime, it’s disturbing on a philosophical level. I hope that McKellar understands her place in the broader context of science, but I’ve seen her interviewed, and she certainly doesn’t jump in to explain the relative importance of a junior author on an REU project when the interviewer describes her in terms usually reserved (in modern times) for people like Wiles. (“Groundbreaking theorem,” “mathematical genius”, etc. Actual quotes.)")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e841ba9acf04f70e175b3536d95f6fec1758020e90dcb65aa9b103d729f5d7c7-b0d4f8ffdf841d709a4914db222473d30c6b32769dd9c1381764a487a4b1a9cb.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Pacha Nambi")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-22102")[#strong[#text("Pacha Nambi")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2007")])]

#text("I don’t believe for one second that gender as any thing to do with mathematical ability. Both women and men are equally capable of making great contributions to the progress of any science including mathematics. My sister studied mathematics in college and she did very well in it, and I consider her the smartest person in my family. I personally know many women who have excelled in many science and engineering subjects. If there is a perceived difference between men and women in mathematics it is a cultural thing rather than genetic differences.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1bab8907ded083b4876e807a6fe3d5c5e0474a98dc47fde1ca4e772fa5815ecf-950564ad1f98ac8b4d4277585aca129c5fdb862040e160be396a7115b46176c5.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Terence Tao")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-22103")[#strong[#text("Terence Tao")]]#text(size: 9pt, fill: rgb("596477"), " · 26 December 2007")])]

#text("Dear WA,")

#text("It is true that mathematicians tend to care about our perceived reputation and position within our community, given that this impacts various career-related things (jobs, grants, letters of recommendation, prizes, etc.). But I would imagine that the interest of a member of the public in our own internal pecking order is essentially negligible (much as the ranking of two, say, biologists (to pick a discipline at random) would be to us); indeed, any distinction finer than “mathematician” and “non-mathematician” is typically not on the radar at all. In view of this, and also given that Danica is not competing with “real mathematicians” for jobs or grants, I think the question of whether she “knows her place” in our social hierarchy is thus somewhat moot. In any case, the overselling of one’s mathematical achievements is not exactly the principal reason why actors and actresses can attract far more public recognition than even the most famous mathematician.")

#text("In my opinion, the more pressing problem with the public image of mathematics comes not from it being perceived as being overly accessible (“Look! Even a child actress can do it!”), but from it being perceived as being overly inaccessible (“I was never any good at math”, etc.), and so it seems better to err on the side of inclusiveness than of exclusiveness.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of WA")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-22249")[#strong[#text("WA")]]#text(size: 9pt, fill: rgb("596477"), " · 27 December 2007")])]

#text("Dear Prof. Tao, thanks for your measured response. I wasn’t trying to imply that McKellar was /deliberately/ overselling the value of her work; if it came across that way, I apologize. I guess what I meant is that, at least in the interviews I’ve seen, not enough attention was paid to the /path/ by which McKellar achieved her status as a “published mathematician”: namely, the support of a rich & vital research program designed to train young researchers in the mathematical sciences just as they are trained in other fields, by beginning with results which (however original) are incremental and very probably known to be quickly solvable at the outset. A description of this support framework would have been eye-opening, I think, for a public whose notion of mathematicians is derived from cinema and television stereotypes, and I believe that publicizing the more egalitarian and communal aspects of mathematics—as a research science, specifically, as opposed to a general intellectual pursuit—is necessary if we are to break down the more harmful stereotypes.")

#text("But then—most of these interviews fell into the “human interest” category, and thus had no desire to illuminate their audience.")

#text("It’s widely known that, although romantic generalizations about a “science of patterns” are a wonderful thing to discuss at cocktail parties, they don’t really contribute to the average person’s understanding of the work: work which, as I know it, has invariant properties understood by researchers at every level. But since nature of these properties is difficult to communicate while remaining nontechnical, we usually can’t help but err, when discussing math in a general setting, by either being too rigid or too sloppy. This is perfectly evinced by one of the interviews I sampled—honestly, I’m interested in the “Math Doesn’t Suck” book, because there are young girls in my family—in which the host presented McKellar with an “heuristic proof” (which he’d concocted on the spot) of an old chestnut from precalc education, namely 0.999…=1. The proof was incorrect, but sounded good enough that McKellar let him have it. I can imagine her vacillating mind: do I correct him, and thus confirm the audience’s idea that math is “beyond them?” Or do I ignore his small error, however essential, and perhaps win a few new readers? I describe the scene not to criticize McKellar’s choice, but because it’s a perfect example of the classic dilemma. In her case, the dilemma truly had but one resolution: even if McKellar were serious about presenting correct mathematics, she didn’t really have much control over the interview’s content; the audience was tuning-in to hear a human-interest story, the producers knew that, and would have edited accordingly.")

#text("So I suppose the brunt of my dissatisfaction lies with that old bogey, the popular media, which has no compunction about throwing away all sense of perspective in the name of a cute happy-feel-good story from Hollywood to end the broadcast day on a light note. But that’s old news, right? (So to speak.)")

#text("Cheers—have a good weekend.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/4743621c9e4d54c91a4084fa0314cf9a27c1bbbe3b238e056b2c2feca4ad859a-8c9be0cbd9ac91f9b1b37a4cba45f3cc70187858ad92e162bf04581a1769b15d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Eximus")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-22675")[#strong[#text("Eximus")]]#text(size: 9pt, fill: rgb("596477"), " · 31 December 2007")])]

#text("McKellar has thoroughly validated my childhood crush.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-23658")[#strong[#text("‘Winnie Cooper’ writes a book… about math at Charles Apple")]]#text(size: 9pt, fill: rgb("596477"), " · 9 January 2008")]

#text("[…] In the meantime, she had graduated summa cum laude with a degree in mathematics from UCLA. While there, she and a couple of other folks developed and published a proof of a complicated mathematical theorem. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-24894")[#strong[#text("easternblot.net » SHOCKING! Former child actors turned geeks!")]]#text(size: 9pt, fill: rgb("596477"), " · 25 January 2008")]

#text("[…] to find time to get a math degree, have a mathematical theorem named after her (update: explained here), and write a book about math for girls. She tries to teach girls that being good at math does not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-25176")[#strong[#text("Marginalized Action Dinosaur » What happens when stars grow up.")]]#text(size: 9pt, fill: rgb("596477"), " · 30 January 2008")]

#text("[…] to find time to get a math degree, have a mathematical theorem named after her (update: explained here), and write a book about math for girls. She tries to teach girls that being good at math does not […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-32342")[#strong[#text("Review: Math Doesn’t Suck « Let’s Play Math!")]]#text(size: 9pt, fill: rgb("596477"), " · 1 September 2008")]

#text("[…] in fact was the second-best student there.” Tao writes about the Chayes-McKellar-Winn theorem here, and John Baez gives the short version […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-32607")[#strong[#text("Review: Kiss My Math « Let’s Play Math!")]]#text(size: 9pt, fill: rgb("596477"), " · 16 September 2008")]

#text("[…] math maven Danica McKellar has traveled through the pre-algebra jungle and beyond, up the slopes to higher math. She survived the journey, and now, on the heels of her bestselling book for math-phobic middle […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-33364")[#strong[#text("Matemáticas para jovencitas de la mano de una actriz de televisión « Francis (th)E mule Science’s News")]]#text(size: 9pt, fill: rgb("596477"), " · 2 November 2008")]

#text("[…] Terry Tao, Medalla Fields en Madrid 2006, fue profesor de Danica (en 1997). Brandy Winn, coautor de Danica, confiesa Tao que fue su mejor alumno (tras Danica) en […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/ff5e96bd4dcac5faca8fcc0c2d729900f2fe442bdd1a79f253098d5205c757cf-e4485f92af761c0acbe5d090ff70ba5a4346ab3859e94dd174f1b657c4027548.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of raj")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-37250")[#strong[#text("raj")]]#text(size: 9pt, fill: rgb("596477"), " · 24 March 2009")])]

#text("I was never good at calculus. But I memorized my way through it! and that is no way to learn anything. I was not good at maths also but practiced my way through it. I t depends a lot on teachers. I memorized because there was no help from teachers. It all depends on teachers. They shoould understand that god did not make everyone intellectually smart. And that weak students must be nurtured. But alas 99% of teachers, professors I came across were not interested in helping weak students. May be just my luck. I would still want to learn calculus. May be there is a way of thinking that can make calculus learning easier and hopefully someone here can help.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/6c76e16953b7ae11f62bb6b518796c5d930e57a539f6b1f226bdd0627032d6f9-42c2ca64a50dd8701161bb37eded5964a7fca4a88383a1759c24acd8220fb18d.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Andrew")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-50294")[#strong[#text("Andrew")]]#text(size: 9pt, fill: rgb("596477"), " · 17 February 2011")])]

#text("While I fully agree that memorizing is not the best, sometimes in math, I’ve found that it’s better to follow the “fake it til you make it” (where faking it is memorizing) plan. Sometimes I won’t get pieces of math until 6months or a year after a course or after reading the paper.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-37361")[#strong[#text("Run and Tumble - Congratulations to Danica McKellar…")]]#text(size: 9pt, fill: rgb("596477"), " · 25 March 2009")]

#text("[…] as Winnie Cooper on The Wonder Years. That was before she graduated summa cum laude in math, had a theorem named after her, wrote two bestselling books making math accessible to middle school girls, and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/0f572f2f4535a9fc335413178e3400eb5d6dd1685207d5221a009c7fb6e8d3ca-4b988b77d3d54816aaedfe4f6be383376badea945e680ce414a7306bb39e8ea3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Ben")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-37974")[#strong[#text("Ben")]]#text(size: 9pt, fill: rgb("596477"), " · 6 April 2009")])]

#text("I realize this is an old blog but … looking at some of the comments above, I couldn’t help but think that this is a great example of mediocre minds versus great ones. The mediocre ones always focus on how to look cool by putting down anything that is pedestrian and catering to plebeians. The great ones though don’t see a need to put on airs, focusing instead on how to reach those who may be at a lesser level than they are. Funny how the mathematical nobodies are making sniffing noises when the award-winning mathematician isn’t.")

#text("People never cease to amuse me.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-39957")[#strong[#text("Vain MagazineThe Wonder Years’ costar Book Signing… –")]]#text(size: 9pt, fill: rgb("596477"), " · 8 July 2009")]

#text("[…] Wonder Years. Holding a degree in Mathematics from UCLA, she is the coauthor of a physics theorem, The Chayes-McKellar-Winn Theorem and released her first book all about math. The summa cum laude graduate’s book, “Kiss […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/87253a5492d4efbd17fbdc17316998044363c757db7447f4b3416afc41389f7d-592e35107a4dd1000ef21256d436e404a68abf32a7a0217ecdfe49d11b4e216f.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Syd")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43237")[#strong[#text("Syd")]]#text(size: 9pt, fill: rgb("596477"), " · 14 January 2010")])]

#text("Wish you had put the executive summary at the top. lol")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/dcf67163acabbc85ec4bdc69408d6e6da41ba42ef3b9c44b29e1bbf640e6de7a-826164bf683066da1d36ddcb030f1dc9f52b35c5ce2a8880340749958547ef6c.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of ateixeira")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43253")[#strong[#text("ateixeira")]]#text(size: 9pt, fill: rgb("596477"), " · 16 January 2010")])]

#text("What a great article Prof. Tao. I’ve never heard of this girl before but I’m alreay a fan of her.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/7ff79cde29d05793940e6dcc66432e8d7aa982ebc6d28036725be78ce8ecd62b-98c8671f1aab4366053bd54a148e12ec3eab166785b58b2854b7a33639bdb6b5.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Wendy")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43956")[#strong[#text("Wendy")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2010")])]

#text("As a woman, I can tell you that Math is not boring. As much as I enjoy math itself, I can tell you why girls do not pursue it. It does not matter how cool she tried to make it sound. Matter of fact is that in college and currently in most math/engineering careers, there are more men than women. Girls like to do things together. We even go to the bathroom together. Imagine how lonely we are when we become one of the 2 or 3 women in a group of 20 -30 guys, every day. It is what it is. Women excel in many other areas such as marketing, medical field. If the environment for math/engineering ever become more pleasant for women (maybe from a corporate point of view), then it may change.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13dffc00ec3d9483f5884f71089bfdc8d49c03bc6c601fa1cee82adab2278c87-4fb9c357e80c7851dcc5b1a5f5c965b88a45c2d7e59599d18f8f3ce24be194e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The_MC")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-222561")[#strong[#text("The_MC")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2013")])]

#text("People always talk about there being too many men in a particular field therefore women cannot — or find it uncomfortable to — enter that field.")

#text("Wasn’t this always the case in all the fields that women have penetrated in large numbers and in some cases are dominating (business, law, medicine/life sciences etc.)? If anything, weren’t business and law firms more “old boy networks” than science and technology?")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43957")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 20 March 2010")])]

#text("So, Wendy, your explanation is that women don’t go into math because there aren’t enough women in math?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Anonymous")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43968")[#strong[#text("Anonymous")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("John, how is that not a valid explanation? You may disagree with whether it is the actual reason, but how does it not make sense?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43972")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("Anonymous: the problem is when you try to do something about it. If the reason women don’t go into math is that there aren’t enough women in math, then to get more women in math we need to… get more women in math?")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76b4241682db3965c77da42e1c61e3d3753c4bc313a67bae2943eb3eaebd261e-e525b651da1e411af29eb973e48b7ace7006346b7fda89de3e12992b5e0bc482.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43974")[#strong[#text("Jean")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("Yes. In order to get more women into math, we need to get more women into math. And one possible way to accomplish this is to encourage younger women to go into math. This book seems like it will be helpful in achieving that goal. Another helpful strategy would be to group women math students together. If there are 5 women math students attending your university, create a group for them. Doesn’t matter what level they are at, because what will help is knowing that each women is not the “only” women.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43975")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("Jean, those are some great suggestions. But the first step is still a tautology.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/1eceb844eca7eec52239c81eb63e508849eceab0eb700f7fee8655057c91e8c8-59235d2090f28b999f805c205371da8abf234bd7fcedbe5b6abf6da4b49b176b.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Yan Shen")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43978")[#strong[#text("Yan Shen")]]#text(size: 9pt, fill: rgb("596477"), " · 22 March 2010")])]

#text("Well maybe what Jean is suggesting is that initially at some starting point women had the capacity for mathematics/engineering, but that perhaps due to say some outside influence, the initial group of women didn’t go into those fields. Then once that initial negative influence subsided, subsequent generations of women were hindered by the fact that now there were relatively few women in those fields. I’m not sure if that’s what Jean had in mind, or do I necessarily agree with such an explanation, just throwing out a thought that would resolve the tautology…")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/76b4241682db3965c77da42e1c61e3d3753c4bc313a67bae2943eb3eaebd261e-e525b651da1e411af29eb973e48b7ace7006346b7fda89de3e12992b5e0bc482.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jean")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43981")[#strong[#text("Jean")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2010")])]

#text("Well, suppose you are an intelligent young women looking around at different universities and trying to decide which one to pick and which major to choose. You would have to be a very brave young women to put aside all fears of trying to integrate into an all male classroom. It would be much easier to select something equally intellectually challenging but where there are already other women, both faculty and other young students. This type of decision making isn’t unique to young women. All young people seek out places and people that make them feel included. So, yes, the only way to get more women into math is to get more women into math. Tautology or not, this is the only path that will last in the long run.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/13dffc00ec3d9483f5884f71089bfdc8d49c03bc6c601fa1cee82adab2278c87-4fb9c357e80c7851dcc5b1a5f5c965b88a45c2d7e59599d18f8f3ce24be194e6.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of The_MC")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-222565")[#strong[#text("The_MC")]]#text(size: 9pt, fill: rgb("596477"), " · 4 April 2013")])]

#text("That’s funny. You acknowledge that your solution is tautological but still assert that it’s a solution.")

#text("In order to {reduce pollution/increase graduation rates/stop hate crime}, we must {reduce pollution/increase graduation rates/stop hate crime}.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/366b3bbb97473a3aa8336c6963ca0ba0ab094b996bfac280cf0dae6f32c8f57c-0ec5bbe45b6b52d4da05b9f6662dd11f3194af4f43a7c5b144a8a9d6788918a3.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of John Armstrong")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43991")[#strong[#text("John Armstrong")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2010")])]

#text("Yes, I agree, but it’s still sounds like “fly by pulling on your own bootstraps”.")

#text("But your suggestions are still good, because they aren’t stemming from this self-referential effort. Instead, they work on increasing the ")#emph[#text("visibility")]#text(" of women already in math and science. What’s needed is, essentially, a marketing campaign to put out the message “there is a place for you and people like you here”.")
]

#pad(left: 18pt)[
#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/28ce656cdc1f1daebe8727fc7bbbf2efc7d7fbed8cef215831894a0422d29e9d-5cd76d116038be9e7fc9ea7ae4a547b92364c0d4ed72a9a6c69b5762ba700228.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Mark Bennet")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-47823")[#strong[#text("Mark Bennet")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")])]

#text("John Armstrong")

#text("Take some binary system in which “Type A” dominates “Type B”, and the proportion of “Type B” at time t is p(t). This is a dynamical system, and p(t+1) increases with p(t), and depends on it – or the model might be a differential equation. Some empirical data might constrain the model, and it is desirable, say, that the asymptotic value of p(t) is 0.5.")

#text("Suppose also that p(t+1) increases with v(t) (visibility). v(t) is quite strongly correlated with p(t) but is different from it. Given further empirical data it is then possible to create plausible models to determine the function p(t) and perhaps to identify a factor e(t) [effectiveness, say] which perhaps diminishes as v(t) and p(t) increase, which tends to reduce p(t+1).")

#text("The point is that the dominant factor in determining the number of female mathematicians in the ‘next generation’ may be the number of female mathematicians in the current generation [p(t)]. But is may also be affected by how good they are [e(t)] and how visible they are [v(t)]. Mathematicians have been modelling such systems for a very long time, and it is no surprise that there may be multiple factors involved.")

#text("p(0) is given, of course, as your comments suggest – so even though it may be the dominant factor, the initial value cannot be controlled. One naturally looks for other factors which are controllable and models those effects.")

#text("What I want to point out is that your comments may have a rigorous edge to them in identifying the precise meaning of mathematical statements – fine: but they are not directed at deploying the best mathematical resources to model this real-life situation. That may be the difference between pure mathematics and applied mathematics.")
]
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/24c56e7b1313ed2f67b343574bae02511142bdf4e75856b358cbeaf1488f34d8-cdc68faaac8724ea178eb7a9a84f93431f3f092b0cda6887b6c1f18ea7465737.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Jonathan Vos Post")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-43992")[#strong[#text("Jonathan Vos Post")]]#text(size: 9pt, fill: rgb("596477"), " · 23 March 2010")])]

#text("The crisis, in USA, Europe, Canada, other venues; and proposed cures; is well known in Math, Science, Engineering, and Technology. To use a well-known metaphor, there is a “leaky pipe.”")

#text("Attracting Women into Engineering – a Case Study, Malgorzata S. Zywno, Member, IEEE, Kimberley A. Gilbride, Peter D. Hiscocks, Judith K. Waalen, and Diane C. Kennedy, Member, IEEE {I’m having trouble posting the hitlink here}")

#text("Streaming, or the “Leaky Pipe Syndrome”: Women are diverted from math and science courses early in their high school careers. It has been argued [S. Tobias, “Women in Science – Women and Science”, JCST, March 1992, pp. 276-278.] that this is associated with issues of competition, isolation, lack of female role models and not of lack of academic ability. Systemic obstacles [M. Frize, 1992, “More Than Just Numbers”, Report of the Canadian Committee on Women in Engineering.] include: cultural influences and gender stereotyping at home and in school, peer pressure and images in the media.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-44543")[#strong[#text("Carnival of Mathematics XVI « Learning Computation")]]#text(size: 9pt, fill: rgb("596477"), " · 30 April 2010")]

#text("[…] models on Z2“. So, I was delighted to see that Terry Tao has done just that in his blog entry “Math Doesn’t Suck”, and the Chayes-McKellar-Winn theorem. Tao gives both a high-level and a fairly detailed explanation of what the theorem means, and also […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/63e4f02f00813e5d256db540b6602f14ad977ee9980518580896baeb783749f2-2a9ed58d811a9790fd6d8225fc0421f4f58f9affbb586c111cf4a074d7303eea.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of kevin o malley")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-44836")[#strong[#text("kevin o malley")]]#text(size: 9pt, fill: rgb("596477"), " · 13 May 2010")])]

#text("I know some women that studied mathematical modelling with me at university. they were gorgeous. look lets face it first get rid of the stereotype about mathematical type people. why are we saying they are not normal? and also why are we then trying our best to look fr that not normal part. it is because lesser mortals are jealous and can’t accept that people do not necessarily have to compensate intelligence beauty and normallity. its like stereotyping blonde hair. to steretype mathematical minded people as having no personality and not time to be normal. all norms can be present in someone that understands maths and lives a life similar to ours. just drop all those stereotypes.")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-45608")[#strong[#text("Potts model and Monte Carlo Slow Down « Journey into Randomness")]]#text(size: 9pt, fill: rgb("596477"), " · 21 June 2010")]

#text("[…] physics that I like a lot and a good survey of the Potts model here. Also T. Tao has a very nice exposition of related models. The blog of Georg von Hippel is dedicated to similar models on lattices, which […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/95346cbae5640bd22ad980b04311cb0b4e69be6296c10f8b5d4adb48103e492d-e0f1fd5d771f55fa3661eb04ab62d1f147f86a658d33005d4614c1a1434d8081.jpg", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Winnie Cooper Teaches Your Daughter Algebra « Pasco Phronesis")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-46304")[#strong[#text("Winnie Cooper Teaches Your Daughter Algebra « Pasco Phronesis")]]#text(size: 9pt, fill: rgb("596477"), " · 31 July 2010")])]

#text("[…] graduated with a degree in mathematics from UCLA, and has a named theorem to her credit (shared with two others), so she knows what she’s writing about. Arguably the […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-46477")[#strong[#text("Walks on graphs and statistical mechanics « Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 12 August 2010")]

#text("[…] is beautifully explained in this expository note by Keith Conrad. Terence Tao also describes the more typical physically-motivated route to this distribution, but I can’t […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-47821")[#strong[#text("From US Magazine’s 25 Smartest Stars list « Post Academic")]]#text(size: 9pt, fill: rgb("596477"), " · 24 October 2010")]

#text("[…] Winnie Cooper from Wonder Years, Danica McKellar, who has a mathematical theorem named after her (the Chayes-McKellar-Winn theorem) for her work as a standout undergrad at UCLA. Maybe there should be a sitcom or even reality […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-120266")[#strong[#text("dustbury.com » Let us all percolate together")]]#text(size: 9pt, fill: rgb("596477"), " · 3 January 2012")]

#text("[…] am indebted to Terence Tao for this highly comprehensible Executive Summary: When one heats an iron bar magnet above a certain special temperature — the Curie […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/54b3c62c773edc579fa63d92b06038841e636f0a8f6e23267c025394fd8ee5ce-e279d0a76efd868a1fbbf12d2c5202368e41bf3c0bb55131c15ee95ddaac4a90.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of bryan")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-217349")[#strong[#text("bryan")]]#text(size: 9pt, fill: rgb("596477"), " · 20 February 2013")])]

#text("When hearing of Ms. Mckellar’s accomplisments a few years ago, I immeadiately wanted to check out just what she had knowledge of. Having been a math whiz growing up, it interested me that someone better looking than me(well, almost) could fashion a theory more brilliant than even I could realize(surely not!). So, after perusing over the calculations, some of which I was not familar with(egad, I had become a little rusty at it), I realized that what she was trying to say was no hopscotch through the forest of numerical expressions. But, the one thing that received my attention was not how Mckellar was able to explain certain abstractions, and, therefore, add a seriously intellectual note to her already worthy career, but rather,")#linebreak()#text(" that she did it at UCLA. Not M.I.T. nor Cal-Poly Tech or even Princeton …")#linebreak()#text(" but Hollywood University, er UCLA. Don’t ge me wrong. A genius is a genius. Once one starts thinking about thought and such, one is already on their way. I am sure she can do anything with that mind of hers. And at the time I read `her’ theorem, I believed she could discuss any subject as abstractly as me, even. Perhaps better. And that made me think I should examine the world closer. Besides, I beat an M.I.T. professor to a theory when I was 10 … with some help from a friend the same age as me who eventually became a legal researcher. Too bad she didn’t go to U.S.C. I would never have blinked twice!")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-241827")[#strong[#text("Quomodocumque goes old-media | Quomodocumque")]]#text(size: 9pt, fill: rgb("596477"), " · 13 August 2013")]

#text("[…] on the blog: Sara Marcus interviews McKellar. And on Terry’s blog, a nice explanation of McKellar’s work in statistical mechanics, along with the tidbit that McKellar was second from the top in Terry’s intro topology course […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/90be308eed25ee97422b84bb02b87e52566d4e296322a811776b8ebbfeb5cf46-92174fba00f66eede65dbb894aba8b12eabf1776e9882fcc866f44f1799e58b2.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of mathtuition88")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-249559")[#strong[#text("mathtuition88")]]#text(size: 9pt, fill: rgb("596477"), " · 31 October 2013")])]

#text("Reblogged this on ")#link("http://mathtuition88.com/2013/11/01/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/")[#text("Singapore Maths Tuition")]#text(".")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/a7eacd066555d2553dad2786361f93ebb2b1d72f9468e6eccf54e23333feb93d-e800c92dc9e7530cccdb19b6a195fa03344541422a4d496266f804bea56c83b8.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Math and Motivation | Singapore Maths Tuition")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-453092")[#strong[#text("Math and Motivation | Singapore Maths Tuition")]]#text(size: 9pt, fill: rgb("596477"), " · 15 March 2015")])]

#text("[…] In Math, you must always believe that you can solve the answer, in order to solve it. Just like Thiru, if you believe in yourself, you can do it! A nice book to read about Math and Motivation is Math Doesn’t Suck: How to Survive Middle School Math Without Losing Your Mind or Breaking a Nail. Ideal for teenagers, this book features an award winning actress who struggled with math, but later overcame her fears to be one of the top in UCLA Math faculty. Even Terence Tao praised her. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#grid(columns: (22pt, 1fr), column-gutter: 7pt, align: (left + horizon), [#box(width: 22pt, height: 22pt, radius: 50%, clip: true)[#image("../assets/e49f44f181fdb99f747a443be07529dcb574f8df664c52656978cd3285595291-56fae26c211abc5dd95ddfe908a7ef1a80d2c0b5e2ede3c8849455606604fc67.png", width: 22pt, height: 22pt, fit: "cover", alt: "Avatar of Danica McKellar Smarter Than Every Miss America Contestant")]], [#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-459151")[#strong[#text("Danica McKellar Smarter Than Every Miss America Contestant")]]#text(size: 9pt, fill: rgb("596477"), " · 13 September 2015")])]

#text("[…] You can learn more about McKellar's role as co-author of the mathematical physics theorem, which bears her name (The Chayes-McKellar-Winn Theorem), here. […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-461112")[#strong[#text("MISS WORLD 2015 PHILIPPINES: STORM PORTENTS (PART 3) | Joseph Vitug's Views")]]#text(size: 9pt, fill: rgb("596477"), " · 29 October 2015")]

#text("[…] up to be babelicious, but earned summa cum laude with a degree in Mathematics (and reportedly has a theorem in her name, to boot), or for a more current example, hunky college math professor and supermodel Pietro Boselli) and […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-466670")[#strong[#text("Maximum entropy from Bayes’ theorem | Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 6 March 2016")]

#text("[…] prior is called the fundamental postulate of statistical mechanics. As Terence Tao explains here, in a suitable finite toy model involving Markov chains at equilibrium it can be proven rigorously, […]")
]

#block(width: 100%, breakable: true, above: 10pt, below: 6pt)[
#set par(justify: false, first-line-indent: 0pt, linebreaks: "optimized")
#block(sticky: true, above: 0pt, below: 4pt)[#link("https://terrytao.wordpress.com/2007/08/20/math-doesnt-suck-and-the-chayes-mckellar-winn-theorem/comment-page-1/#comment-468994")[#strong[#text("What’s a fire, and why does it – what’s the word – burn? | Annoying Precision")]]#text(size: 9pt, fill: rgb("596477"), " · 26 May 2016")]

#text("[…] constant); this is the Boltzmann distribution. For one possible justification of this, see this blog post by Terence Tao. This means that the probability […]")
]
